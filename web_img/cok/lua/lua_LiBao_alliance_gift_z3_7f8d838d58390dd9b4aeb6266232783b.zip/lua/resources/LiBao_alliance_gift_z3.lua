cfg_table = {
	["layerX"] = -17,
	["layerY"] = -50,
	["layerScale"] = 1,
	["particle"] = {
		["parName"] = {
			[1] = "",
			[2] = "",
			[3] = "KingdomIcon_2",
			[4] = "KingdomIcon_3",
		},
		["parPosX"] = 50,
		["parPosY"] = 50,
		["parScale"] = 0.9
	}
}