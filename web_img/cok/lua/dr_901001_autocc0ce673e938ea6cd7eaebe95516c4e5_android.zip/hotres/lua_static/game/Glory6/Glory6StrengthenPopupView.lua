local Glory6Manager = require("game.Glory6.Glory6Manager")
Glory6StrengthenPopupView = class("Glory6StrengthenPopupView", function()
        return PopupBaseView:create()
    end
)
Glory6StrengthenPopupView.__index = Glory6StrengthenPopupView

local cellHeight = 20
local cellWidthSide = 5
local pregressWidth = 465
local MAX_SPRITE_TAG = 10000
--------------------------- 强化信息 Start ---------------------------
Glory6StrengthenMakeCmd = class("Glory6StrengthenMakeCmd", LuaCommandBase)
function Glory6StrengthenMakeCmd.create(uuid)
   MyPrint("cjy Glory6StrengthenMakeCmd")
    local ret = Glory6StrengthenMakeCmd.new()
    ret:initWithName("strengthen.upgrade")
    ret:putParam("uuid", CCString:create(uuid))
    return ret
end

function Glory6StrengthenMakeCmd:handleReceive(dict)
    local cmdname = dict:valueForKey("cmd"):getCString()
    if cmdname ~= "strengthen.upgrade" then
        return false
    end
    --dump("Glory6StrengthenMakeCmd:handleReceive")
    local params = dict:objectForKey("params")
    if nil == params then
        --dump("Glory6StrengthenMakeCmd.create no params...")
        return true
    end
    params = tolua.cast(params, "CCDictionary")
    local tbl = dictToLuaTable(params)
    if tbl.errorCode and tbl.errorCode ~= "" then
        LuaController:flyHint("", "", getLang(tbl.errorCode))
        return true
    end
    require("game.Glory6.Glory6Manager").updateReduceData(tbl)
    CCSafeNotificationCenter:postNotification("Glory6_strengthen_make",params)

    return true
end
--------------------------- 强化信息 End ---------------------------

------------------------------------------ Glory6StrengthenPopupView Start --------------------------------------------

function Glory6StrengthenPopupView:create(armyId,origonSkillId,isTransfer)
    local view = Glory6StrengthenPopupView.new()
    if view:initView( armyId,origonSkillId,isTransfer) == false then
        return nil
    end
    return view
end

function Glory6StrengthenPopupView:initView( armyId,origonSkillId,isTransfer)
    if self:init(true, 0) == false then
       --MyPrint("Glory6StrengthenPopupView init error")
        return false
    end
    self.isTransfer = isTransfer
    self:setHDPanelFlag(true)
    self:setTitleName(getLang(""))
    CCLoadSprite:call("loadDynamicResourceByName", "goods")
    callItSelfCallFunc(LuaController, "doResourceByCommonIndex", 204, true)
    local m_bIsPad = CCCommonUtilsForLua:isIosAndroidPad()
    local proxy = cc.CCBProxy:create()
    local ccbiURL = ""
    ccbiURL = "ccbi/Glory6StrengthenPopupView.ccbi"
    self.m_bIsPad = m_bIsPad
    local nodeccb = CCBReaderLoad(ccbiURL,proxy, self)
    if nodeccb == nil then
       --MyPrint("Glory6StrengthenPopupView loadccb error")
        return false
    end

    if self.m_bIsPad then
        nodeccb:setScale(2)
    end
    self:setContentSize(nodeccb:getContentSize())
    self:addChild(nodeccb)

    local function onNodeEvent(event)
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end
    nodeccb:registerScriptHandler(onNodeEvent)

    function onTouch(eventType, x, y)  
        if eventType == "began" then  
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)  
        else  
            return self:onTouchEnded(x, y)  
        end
    end
    local touchif = tolua.cast(self,"cc.CCIFTouchNode")
    if touchif ~= nil then
        local dic1 = CCDictionary:create()
        dic1:setObject(CCBool:create(true),"1")
        touchif:comFunc("setTouchEnabled", dic1)

       --MyPrint("Glory6StrengthenPopupView:registerScriptTouchHandler")
        touchif:registerScriptTouchHandler(onTouch)
    end

    self.m_nowStrenResourceId = Glory6Manager.strenItemId
    self.m_armyId = armyId
    self.m_origonSkillId = origonSkillId
    -- dump(Glory6Manager.armyData,"cjy Glory6Manager.armyData "..origonSkillId)
    self.m_nowSkillId = Glory6Manager.armyData[self.m_origonSkillId].nowSkillId
    self.nowUseTransferToolNum = Glory6Manager.transferItemUse

    self.m_nowLevel = tonumber(Glory6Manager.armyData[self.m_origonSkillId].level)
    self.m_preLevel = self.m_nowLevel
    self.m_preScaleX = 0
    self.m_nowScaleX = 0
    self.m_isProgressing = false
    self:initUI()
    return true
end

function Glory6StrengthenPopupView:initUI()
    local skillPicName = CCCommonUtilsForLua:call("getPropById",tostring(self.m_nowSkillId),"icon")..".png"
    if skillPicName then
        self.node_skillIcon:addChild(CCLoadSprite:createSprite(skillPicName))
        self.node_skillIcon:setScale(1)
    end
    self.maxSpr = CCLoadSprite:createSprite("TxtMax.png")
    self.maxSpr:setPositionY(-self.maxSpr:getContentSize().height)
    self.node_skillIcon:addChild(self.maxSpr)
    self.maxSpr:setVisible(false)
   
    local skillName = CCCommonUtilsForLua:call("getPropById",tostring(self.m_nowSkillId),"name")
    self.txt_skillName:setString(getLang(skillName))
    self.node_resourceIcon:removeAllChildren()
    if self.isTransfer then
        self.txt_strenthBtn:setString(getLang("101725"))
        self.txt_strenthBtn:setPositionY(-3)
        self.m_nameLabel:setString(getLang("101725"))
        self.txt_strenTips:setString(getLang("101728"))     
        local itemId = 213759 --转化技能道具id
        local resourceName = CCCommonUtilsForLua:call("getPropByIdGroup", "goods", tostring(itemId), "icon")..".png"

        if resourceName then
            local iconSpr = CCLoadSprite:call("createSprite", resourceName)
            iconSpr:setScale(.55)
            self.node_resourceIcon:addChild(iconSpr)
        end
         
    else
        self.txt_strenthBtn:setString(getLang("5000030"))
        self.m_nameLabel:setString(getLang("5000030"))
        self.txt_strenTips:setString(getLang("5000101"))
        local resourceName = CCCommonUtilsForLua:call("getPropById",tostring(self.m_nowStrenResourceId),"icon")..".png"
        if resourceName then
            local iconSpr = CCLoadSprite:call("createSprite", resourceName)
            iconSpr:setScale(.55)
            self.node_resourceIcon:addChild(iconSpr)
        end
    end
    --pregress
    self.m_clipBarNode:removeAllChildren()
    self.m_clipNode = CCClipNode:call("create", 500, 60)
    self.m_clipNode = tolua.cast(self.m_clipNode, "cc.Node")
    self.m_clipNode:setAnchorPoint(ccp(0, 0))
    self.m_clipBarNode:addChild(self.m_clipNode)

    local bar = CCLoadSprite:call("createSprite", "Research_jingdutiao.png")
    bar:setAnchorPoint(ccp(0, 0))
    bar:setPosition(ccp(0, 0))
    bar:setScale(0.85,0.9)
    self.m_clipNode:addChild(bar)
    local bar1 = CCLoadSprite:call("createSprite", "Research_jingdutiao.png")
    bar1:setFlipX(true)
    bar1:setScale(0.85,0.9)
    bar1:setAnchorPoint(ccp(0, 0))
    bar1:setPosition(ccp(231, 0))
    self.m_clipNode:addChild(bar1)
    self.m_clipNode:setContentSize(cc.size( self.m_nowScaleX * pregressWidth, 60))
    self.node_particleProgress:setPositionX(self.m_clipBarNode:getPositionX() + self.m_nowScaleX * pregressWidth)
    self:createParticle("gloryProgress" , 2)
    if self.m_nowScaleX <= 0 then
        self.node_particleProgress:setVisible(false)
    end

    self:refreshData()
end

function Glory6StrengthenPopupView:onTouchBegan(x, y)
    return true
end

function Glory6StrengthenPopupView:onTouchMoved(x, y)
end

function Glory6StrengthenPopupView:onTouchEnded(x, y)
    if touchInside(self.m_longNodeBg0, x, y) == false then
        self:closeView()
    end
end

function Glory6StrengthenPopupView:closeView()
    CCSafeNotificationCenter:postNotification("SoldierSkillCell:refresh")
    CCSafeNotificationCenter:postNotification("msg_update_army_data")
    self = tolua.cast(self, "PopupBaseView")
    self:call("closeSelf")
end

function Glory6StrengthenPopupView:onEnter()
    local function onRefresh( ref )
        local params = tolua.cast(ref, "CCDictionary")
        local tbl = dictToLuaTable(params)
        -- dump(tbl,"hxq Glory6StrengthenPopupView ( tbl ) ")
        -- dump(tbl.count,"hxq Glory6StrengthenPopupView tbl.count is ")

        if self.isTransfer then

            local table = {}
            table[1] = tbl.sourceArmySkill
            table[2] = tbl.targetArmySkill
            Glory6Manager.RefreshArmyData( table ,nil)
        else
            Glory6Manager.RefreshArmyData( tbl ,tbl.count)
        end

        
        CCSafeNotificationCenter:postNotification("Glory6_strengthen_ChangeData")
        self:refreshData()
    end
    local t = tolua.cast(self, "cc.Node")
    local handler = t:registerHandler(onRefresh)
    CCSafeNotificationCenter:registerScriptObserver(self, handler, "Glory6_strengthen_make")
    self:onEnterFrame()

    if self.entry then
        cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
        self.entry = nil
    end
    self.entry = tonumber(self:getScheduler():scheduleScriptFunc(function (  )
        self:onEnterFrame()
    end, 0.1, false))

    local close = function ( )
        self:closeView()
    end
    local handler2 = t:registerHandler(close)
    CCSafeNotificationCenter:registerScriptObserver(self,handler2,"Glory6_transfer_close")
end

function Glory6StrengthenPopupView:onExit()
    CCSafeNotificationCenter:unregisterScriptObserver(self, "Glory6_strengthen_make")
    CCSafeNotificationCenter:unregisterScriptObserver(self, "Glory6_transfer_close")
    if self.entry then
        cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
        self.entry = nil
    end
end

function Glory6StrengthenPopupView:onEnterFrame( dt )
    if self.m_isProgressing then
        self.m_clipNode:setContentSize(cc.size(self.m_preScaleX * pregressWidth , 60))
        self.node_particleProgress:setPositionX(self.m_clipBarNode:getPositionX() + self.m_preScaleX * pregressWidth)
        self.m_preScaleX = 0.05 + self.m_preScaleX
        if self.m_preScaleX > self.m_nowScaleX and self.m_preLevel == self.m_nowLevel then
            self.m_preScaleX = self.m_nowScaleX 
            self.m_isProgressing = false
        elseif self.m_preScaleX > 1.05 and self.m_preLevel ~= self.m_nowLevel then
            self.m_preScaleX = 0
            self.m_preLevel = self.m_nowLevel
            self.node_particleProgress:setVisible(false)
        end
        --粒子
        if self.m_nowScaleX > 0 and not self.node_particleProgress:isVisible() then
            self.node_particleProgress:setVisible(true)
        end
        if self.m_clipNode:getContentSize().width >= pregressWidth then
            self:createParticle("gloryCircle" , 1)--chest_
        end
    end
end
function Glory6StrengthenPopupView:refreshData()
    self.m_nowSkillList = Glory6Manager.armyData[self.m_origonSkillId]

    dump( self.m_nowSkillList,"Glory6StrengthenPopupView---m_nowSkillList")

    local nowLevel = self.m_nowSkillList.level
    local nextLevel = self.m_nowSkillList.nextLevel
    local nowSkillId = self.m_nowSkillList.nowSkillId
    local nextSkillId = self.m_nowSkillList.nextSkillId
    local nowExp = self.m_nowSkillList.exp
    local expAdd = CCCommonUtilsForLua:getPropById(nowSkillId,"exp_add")

    --hxq nowUseResourceNum 转化使用道具数量固定 id=213759. num = item k9
    local nowUseResourceNum = CCCommonUtilsForLua:getPropById(nowSkillId,"item") + Glory6Manager.getTodayStrenCount() * Glory6Manager.strenAddK2
    self.bnt_strenth:setEnabled(true)
    self.txt_nowLevel:setString(getLang("121995",nowLevel))
    self.txt_nextLevel:setString(getLang("121996",nextLevel))
    self.txt_level:setString("Lv." .. nowLevel)
    if self.m_nowLevel ~= tonumber(nowLevel) then
        self.m_preLevel = self.m_nowLevel
        self.m_nowLevel = tonumber(nowLevel)
        local big = cc.ScaleTo:create(0.1, 2)
        local origon = cc.ScaleTo:create(0.2, 1)
        self.txt_level:runAction(cc.Sequence:create(big, origon))
    end

    self.m_nowSkillDescTbl = string.split(CCCommonUtilsForLua:call("getPropById",tostring(nowSkillId),"desc"),"|")
    self.m_nowSkillDescNumTbl = string.split(CCCommonUtilsForLua:call("getPropById",tostring(nowSkillId),"num"),"|")
    self.m_nextSkillDescTbl = string.split(CCCommonUtilsForLua:call("getPropById",tostring(nextSkillId),"desc"),"|")
    self.m_nextSkillDescNumTbl = string.split(CCCommonUtilsForLua:call("getPropById",tostring(nextSkillId),"num"),"|")
    -- dump(self.m_nowSkillDescTbl,"cjy self.m_nowSkillDescTbl")
    -- dump(self.m_nowSkillDescNumTbl,"cjy self.m_nowSkillDescNumTbl")

-- StrenType = 
-- {
--     normal = 1, -- 正常状态
--     tempMax = 2, -- 达到建筑限制上限
--     TopMax = 3, -- 达到配置上限
-- }
    -- MyPrint("cjy nowLevelttttt " , Glory6Manager.getStrenType(nowLevel) , StrenType.topMax)
    self.txt_strenthMaxBtn:setVisible(fasle)
   
    self.maxSpr:setVisible(false)
    if Glory6Manager.getStrenType(nowSkillId) == StrenType.TopMax then
        -- self.bnt_strenth:setEnabled(false)
        -- nowLevel = self.m_nowSkillList.preLevel
        -- nextLevel = self.m_nowSkillList.level
        -- nowSkillId = self.m_nowSkillList.preSkillId
        -- nextSkillId = self.m_nowSkillList.nowSkillId
        nowExp = tonumber(CCCommonUtilsForLua:call("getPropById",tostring(nowSkillId),"exp"))
        -- expAdd = 0
        -- nowUseResourceNum = 0
        -- self.txt_nowLevel:setString("")
        self.txt_nextLevel:setString("")      
        
    end

    if self.isTransfer then
        self.txt_strenthResourceNum:setVisible(false)
    else
        self.txt_strenthResourceNum:setString(getLang("5000102",expAdd))
    end
  
    self.m_AllExp = tonumber(CCCommonUtilsForLua:call("getPropById",tostring(nowSkillId),"exp"))--升级经验要求
    MyPrint("cjy m_nowSkillId m_AllExp",self.m_AllExp )

    if self.m_AllExp ~= 0 and nowExp then
        local nowScaleX = nowExp / self.m_AllExp
        self.m_preScaleX = self.m_nowScaleX
        self.m_nowScaleX = nowScaleX
      
        self.txt_skillExpProgress:setString(nowExp.."/"..self.m_AllExp)
        if self.m_nowScaleX ~= self.m_preScaleX then
            self.m_isProgressing = true
        end
    end
-- 道具消耗数=K2+（X-1）*K3
-- 增加的经验值数量=k4+(X-1)*K5

                    -- Glory6Manager.strenItemId = tonumber(glory6Data.k1) --强化道具id
                    -- Glory6Manager.strenCost = tonumber(glory6Data.k2) --基础花费
                    -- Glory6Manager.strenAddK2 = tonumber(glory6Data.k3) --k2增加值
                    -- Glory6Manager.strenExp = tonumber(glory6Data.k4) --基础经验
                    -- Glory6Manager.strenAddK4 = tonumber(glory6Data.k5) --k4增加值

                    -- strenCost + (todayStrenCount - 1) * strenAddK2
                    -- strenExp + (todayStrenCount - 1) * strenAddK4
                    -- x+（count-1)*Glory6Manager.strenAddK2
    local itemId = 213759 --转化技能道具id                    
    local toolInfo = ToolController:call("getToolInfoForLua", tonumber(self.m_nowStrenResourceId))
    local toolInfo2 = ToolController:call("getToolInfoByIdForLua", itemId)
    local toolNum
    if self.isTransfer then
        if toolInfo2 == nil then
            dump("error TransferToolInfo is nil")
        else
            toolNum = toolInfo2:call("getCNT")
            nowUseResourceNum = self.nowUseTransferToolNum
        end

    else
        if toolInfo == nil then
            MyPrint("HeroResetTalentCmd refresh fragmenttitem count fail with itemId ")
        else
            toolNum = toolInfo:call("getCNT")

        end
    end

    local hyperText = "<s 16><c fbecb3ff>"..toolNum.."/"..nowUseResourceNum
    if ( tonumber(nowUseResourceNum) > tonumber(toolNum) )then
        hyperText = "<s 16><c fbecb3ff>"..toolNum.."/".."<c ff0000ff>"..nowUseResourceNum
    end

    local reduceCount = atoi(Glory6Manager.reduceCount)
    local reduceNum = atoi(Glory6Manager.reduceNum)

    if CCCommonUtilsForLua:isFunOpenByKey("monthlypack_level") then
        self.txt_reduceTips:setString(getLang("350128", tostring(reduceCount)))
        self.txt_reduceTips:setVisible(not self.isTransfer)
    else
        reduceCount = 0
    end
    
    if reduceCount > 0 and not self.isTransfer then
        local temp = nowUseResourceNum
        nowUseResourceNum = nowUseResourceNum - reduceNum
        nowUseResourceNum = nowUseResourceNum > 0 and nowUseResourceNum or 0
        
        local toolLabel = cc.Label:createWithSystemFont(tostring(toolNum) .. " / ", "Helvetica", 18, cc.size(0.0,0))
        toolLabel:setColor(cc.c3b(251, 236, 179))
        toolLabel:setAnchorPoint(cc.p(1, 0.5))
        toolLabel:setPosition(90, 10)

        local width = toolLabel:getContentSize().width
        local useLabel = cc.Label:createWithSystemFont(tostring(temp), "Helvetica", 18, cc.size(0.0,0))
        useLabel:setColor(cc.c3b(251, 236, 179))
        useLabel:setPositionX(width)
        useLabel:setAnchorPoint(cc.p(0, 0.5))
        useLabel:setPosition(90, 10)

        self.node_itemNum:removeAllChildren()
        self.node_itemNum:addChild(toolLabel)
        self.node_itemNum:addChild(useLabel)

        setLabelReduce(useLabel, 1, CC_ITOA(nowUseResourceNum), true)
    else
        local dateLabel = IFHyperlinkText:call("create",hyperText,cc.size(self.node_itemNum:getContentSize().width,0),true)
        dateLabel:setAnchorPoint(cc.p(0,0))
        self.node_itemNum:removeAllChildren()
        self.node_itemNum:addChild(dateLabel)

        local function onRegisterHyper() self:onClickInfo() end
        local handlerSetHyperlink = self:registerHandler(onRegisterHyper)
        dateLabel:call("SetHyperlinkTextClickLuaCallback", handlerSetHyperlink)
    end

    if self.m_nowSkillDescTbl and #self.m_nowSkillDescTbl > 0 and self.m_nowSkillDescNumTbl and #self.m_nowSkillDescNumTbl == #self.m_nowSkillDescTbl then
        local scrollView = cc.ScrollView:create()
        if scrollView ~= nil then
            scrollView:setViewSize(self.node_nowSkillProperty:getContentSize())
            scrollView:setPosition(cc.p(0,0))
            scrollView:setScale(1.0)
            scrollView:ignoreAnchorPointForPosition(true)
            scrollView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)

            local cH = self.node_nowSkillProperty:getContentSize().height
            local height = 0
            local mainNode = cc.Node:create();
            for i=1,#self.m_nowSkillDescTbl do
                local tempNumTbl = string.split(self.m_nowSkillDescNumTbl[i],";")--0;0;0
                -- dump(tempNumTbl,"cjy tempNumTbl")
                if tonumber(tempNumTbl[1]) ~= 0 then
                    local txt_skillDesc = ""
                    if #tempNumTbl == 1 then
                        txt_skillDesc = getLang(self.m_nowSkillDescTbl[i],tempNumTbl[1])
                    elseif #tempNumTbl == 2 then 
                        txt_skillDesc = getLang(self.m_nowSkillDescTbl[i],tempNumTbl[1],tempNumTbl[2])
                    elseif #tempNumTbl == 3 then 
                        txt_skillDesc = getLang(self.m_nowSkillDescTbl[i],tempNumTbl[1],tempNumTbl[2],tempNumTbl[3])
                    end
                    local cell = self:addLabel(txt_skillDesc,18,cc.c3b(213,187,123),self.node_nowSkillProperty:getContentSize().width - cellWidthSide)
                    if cell then
                        mainNode:addChild(cell)
                        height = height + cellHeight + cell:getContentSize().height
                        cell:setPosition(cc.p(0, 0 - height))
                    end
                end
            end

            scrollView:addChild(mainNode);
            mainNode:setPosition(cc.p(0, height))
            scrollView:setContentSize(CCSize(self.node_nowSkillProperty:getContentSize().width,height))
            scrollView:setContentOffset(CCPoint(0, cH - height))
            self.node_nowSkillProperty:removeAllChildren()
            self.node_nowSkillProperty:addChild(scrollView);
        end
        
        self.node_nextSkillProperty:removeAllChildren()
        self.txt_nextProperty2:setString(getLang(""))
        if Glory6Manager.getStrenType(nowSkillId)  == StrenType.TopMax then
            self.txt_nextProperty2:setString(getLang("5000108"))
        else
            local scrollView1 = cc.ScrollView:create()
            if scrollView1 ~= nil then
                scrollView1:setViewSize(self.node_nextSkillProperty:getContentSize())
                scrollView1:setPosition(cc.p(0,0))
                scrollView1:setScale(1.0)
                scrollView1:ignoreAnchorPointForPosition(true)
                scrollView1:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)

                local cH = self.node_nextSkillProperty:getContentSize().height
                local height = 0
                local mainNode = cc.Node:create();
                for i=1,#self.m_nextSkillDescNumTbl do
                    local tempNumTbl = string.split(self.m_nextSkillDescNumTbl[i],";")--0;0;0
                    -- dump(tempNumTbl,"cjy tempNumTbl")
                    if tonumber(tempNumTbl[1]) ~= 0 then
                        local txt_skillDesc = ""
                        if #tempNumTbl == 1 then
                            txt_skillDesc = getLang(self.m_nextSkillDescTbl[i],tempNumTbl[1])
                        elseif #tempNumTbl == 2 then 
                            txt_skillDesc = getLang(self.m_nextSkillDescTbl[i],tempNumTbl[1],tempNumTbl[2])
                        elseif #tempNumTbl == 3 then 
                            txt_skillDesc = getLang(self.m_nextSkillDescTbl[i],tempNumTbl[1],tempNumTbl[2],tempNumTbl[3])
                        end

                        local cell = self:addLabel(txt_skillDesc,18,cc.c3b(213,187,123),self.node_nextSkillProperty:getContentSize().width - cellWidthSide)
                        if cell then
                            mainNode:addChild(cell)
                            height = height + cellHeight + cell:getContentSize().height
                            cell:setPosition(cc.p(0, 0 - height))
                        end
                    end
                end

                scrollView1:addChild(mainNode);
                mainNode:setPosition(cc.p(0, height))
                scrollView1:setContentSize(CCSize(self.node_nextSkillProperty:getContentSize().width,height))
                scrollView1:setContentOffset(CCPoint(0, cH - height))
                self.node_nextSkillProperty:addChild(scrollView1);
            end
        end
    end

    --强化最大等级
    if Glory6Manager.getStrenType(nowSkillId) == StrenType.TopMax then
       
    --最大等级显示  max
        self.txt_skillExpProgress:setString("max")
        self.bnt_strenth:setEnabled(fasle)
        self.txt_strenthMaxBtn:setVisible(true)
        self.txt_strenthMaxBtn:setString(getLang('101752'))
        --头像最大等级
        self.txt_strenthBtn:setVisible(false)
        self.txt_strenthResourceNum:setVisible(false)
     
        self.maxSpr:setVisible(true)
    end
end

function Glory6StrengthenPopupView:createParticle( name , tag)
    if tag == 1 then
        self.node_particle:removeAllChildren(true)
        for i=1,3 do
            local particle1 = callItSelfCallFunc(LuaController, "createParticleForLua", "particle/"..name.."_"..i)--gloryCircle_1
            if nil ~= particle1 then
                self.node_particle:addChild(particle1)
                particle1:setPosition(CCPoint(0, 0))
                particle1:setScale(3)
            end
        end
    elseif tag == 2 then
        self.node_particleProgress:removeAllChildren(true)
        for i=1,2 do
            local particle1 = callItSelfCallFunc(LuaController, "createParticleForLua", "particle/"..name)--gloryProgress
            if nil ~= particle1 then
                self.node_particleProgress:addChild(particle1)
                particle1:setPosition(CCPoint(0, 0))
            end
        end
    end
end
function Glory6StrengthenPopupView:onClickInfo(  )
    local ItemGetMethodView = Drequire("game.CommonPopup.ItemGetMethodView")
    if self.isTransfer then
        -- PopupViewController:addPopupView(ItemGetMethodView:create(self.m_nowStrenResourceId))
    else
        PopupViewController:addPopupView(ItemGetMethodView:create(self.m_nowStrenResourceId))
    end
    
end
function Glory6StrengthenPopupView:addLabel(labelText,fontSize,color3b,labelWidth)
    local label = cc.Label:createWithSystemFont(labelText, "Helvetica", fontSize)
    label:setDimensions(labelWidth, 0)
    label:setColor(color3b)
    label:setAnchorPoint(0,0)
    return label
end

function Glory6StrengthenPopupView:onClickSrenth(  )
    if self.m_isProgressing then
        self.m_isProgressing = false
        self.m_preScaleX = self.m_nowScaleX
        if self.m_nowScaleX == 0 then
            self.m_preScaleX = 1
            self.m_isProgressing = true
        end
        self.m_clipNode:setContentSize(cc.size( self.m_preScaleX * pregressWidth, 60))
        self.node_particleProgress:setPositionX(self.m_clipBarNode:getPositionX() + self.m_preScaleX * pregressWidth)
    end
    if Glory6Manager.getStrenType(self.m_nowSkillList.nowSkillId) == StrenType.TopMax then
        LuaController:flyHint("", "", getLang("5000093"))
    elseif Glory6Manager.getStrenType(self.m_nowSkillList.nowSkillId) == StrenType.tempMax and not self.isTransfer then
        LuaController:flyHint("", "", getLang("5000094"))
    else
        if self.isTransfer then
            --addview
            local view = Drequire("game.Glory6.Glory6SkillTransferSelectView"):create(self.m_origonSkillId,self.m_armyId)
            PopupViewController:call("addPopupView", view)
        else
            local cmd = Glory6StrengthenMakeCmd.create(tostring(self.m_nowSkillList.uuid))
            cmd:send()
        end       
    end
end

function Glory6StrengthenPopupView:onClickAddResource()
    local ItemGetMethodView = Drequire("game.CommonPopup.ItemGetMethodView")
    local toolId = self.m_nowStrenResourceId 
    if self.isTransfer then
       toolId = 213759
    end
    local view = ItemGetMethodView:create(toolId)
    PopupViewController:call("addPopupView", view)
end
return Glory6StrengthenPopupView
