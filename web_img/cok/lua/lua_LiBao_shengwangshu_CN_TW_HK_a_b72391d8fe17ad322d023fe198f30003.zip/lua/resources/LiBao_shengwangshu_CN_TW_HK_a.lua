cfg_table = {
	-- ["localize"]={["CN"]=1,["TW"]=2},
	["iconOrder"] = 2,  -- 是否显示图片  值大小为显示顺序，大的最后显示
}