local AdCellSize = cc.size(640, 570)
local DyLibaoCommonView = class("DyLibaoCommonView", function()
    return CCTableViewCell:new()
end)

local LibaoCommonFunc = require("game.LiBao.LibaoCommonFunc")
local LibaoGroupShowView = require("game.LiBao.LibaoGroupShowView")

-- showType 0:不显示下方逻辑，1:显示下方相信信息
function DyLibaoCommonView:create(param)
    dump(param, " DyLibaoCommonView is ~~~~~~~ create ~~~")
    callItSelfCallFunc(LuaController, "doResourceByCommonIndex", 8, true)
    callItSelfCallFunc(LuaController, "doResourceByCommonIndex", 11, true)
    callItSelfCallFunc(LuaController, "doResourceByCommonIndex", 513, true)
    self.rootPath = CCFileUtils:sharedFileUtils():getWritablePath() .. "lua/"
    loadLuaResource(self.rootPath .. "/resources/LiBaoCommonView.plist")
    local  proxy = cc.CCBProxy:create()
    local ccbiURL = ""
    ccbiURL = self.rootPath.."ccbi/DyGoldAdCommonCellUp.ccbi"
    local nodeccb = CCBReaderLoad(ccbiURL, proxy, self)
    if nodeccb == nil then
        print("DyLibaoCommonView loadccb Lua_GoldAdCommonCell error")
        return false
    end
    self.viewSize = param.viewSize or AdCellSize
    self.showType = param.showType or 0
    self:setContentSize(self.viewSize)
    self:addChild(nodeccb)
    nodeccb:setPosition(cc.p(self.viewSize.width*0.5, self.viewSize.height))

    if CCCommonUtilsForLua:isFunOpenByKey("pack_percentage") then
        self.m_percentNode:setVisible(true)
        if self.showType ~= 0 then
            self.m_percentNode:setPositionY(self.m_percentNode:getPositionY() + 27)
        end
    else
        self.m_percentNode:setVisible(false)
    end

    local function onNodeEvent(event)
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(onNodeEvent)
    
    if self.showType ~= 0 then
        self.m_downBaseNode:setVisible(true)
        self.m_upBuyNode:setVisible(false)
        self:initDownNodeInfo()
    else
        self.m_downBaseNode:setVisible(false)
    end

    self:refresh(param)
    --初始化界面
    return self
end

function DyLibaoCommonView:refresh(param)
    if param then
        self.itemData = param.itemData
    end
    local itemData = self.itemData

    self.m_titleSpr:removeAllChildren()
    if itemData.id == - 1 then
        -- 走默认界面
        self.m_baseInfoNode:setVisible(false)

        local frame = cc.SpriteFrameCache:getInstance():getSpriteFrame("c513_lbv4_morentu.png")
        self.m_titleSpr:setSpriteFrame(frame)
    else
        -- 名称
        self.m_titleLabel:setString(getLang(itemData.name))
        
        self.m_baseInfoNode:setVisible(true)
        -- 获得金币
        self.m_getGoldNumText:setString(itemData.gold_doller)

        -- 限购一次
        if itemData.popup_image ~= "envelope_gift" then
            self.m_desLabel:setVisible(true)
            self.m_desLabel:setString(getLang("101237"))
        else
            self.m_desLabel:setVisible(false)
        end

        self:updateLibaoTime()

        -- 支付价格
        local newPrice = LuaController:call("getDollarString", itemData.dollar, itemData.product_id)
        self.m_newPriceLabel:setString(newPrice)

        local popImg = itemData.popup_image
        -- 背景图
        local curLanguage = LocalController:call("getLanguageFileName")
        if curLanguage == "zh_CN" then
            curLanguage = "CN"
        elseif curLanguage == "zh_TW" then
            curLanguage = "TW"
        else
            curLanguage = string.upper(curLanguage)
        end

        local frame
        if curLanguage then
            local cfg_file = self.rootPath .. "/resources/"..popImg.."_localize.lua"--"LiBao_sh_test.lua"--
            local localizeList = nil
            if cc.FileUtils:getInstance():isFileExist(cfg_file) then
                localizeList = require("resources/"..popImg.."_localize.lua")
            end
            if localizeList then
                if localizeList[curLanguage] then
                    loadLuaResource(self.rootPath .. "/resources/"..popImg.."_localize".. localizeList[curLanguage] ..".plist")
                    frame = cc.SpriteFrameCache:getInstance():getSpriteFrame(popImg.."_localize"..localizeList[curLanguage]..".png")
                end
            else
                loadLuaResource(self.rootPath .. "/resources/"..popImg.."_localize.plist")
                frame = cc.SpriteFrameCache:getInstance():getSpriteFrame(popImg.."_"..curLanguage.."_view_v4.jpg")
                if frame == nil then
                    frame = cc.SpriteFrameCache:getInstance():getSpriteFrame(popImg.."_"..curLanguage.."_view_v4.png")
                end
            end
        end

        if not frame then
            loadLuaResource(self.rootPath .. "/resources/"..popImg..".plist")
            frame = cc.SpriteFrameCache:getInstance():getSpriteFrame(popImg.."_view_v4.jpg");
            if nil == frame then
                frame = cc.SpriteFrameCache:getInstance():getSpriteFrame(popImg.."_view_v4.png");
            end
        end

        if not frame then
            frame = cc.SpriteFrameCache:getInstance():getSpriteFrame("lbv4_morentu.png")
        end

        if not frame then
            -- 再为空取默认图片
            frame = cc.SpriteFrameCache:getInstance():getSpriteFrame("c513_lbv4_morentu.png")
        end

        self.m_titleSpr:setSpriteFrame(frame)

        if (isAndroid()) then
            targetPlatform = "android/"
        else
            targetPlatform = "ios/"
        end
        -- 判断是否有spine动画存在
        -- sk_LiBao_test_heiyaoshi_skin
        -- local popImg = "LiBao_test_heiyaoshi"
        local skin_file = self.rootPath .. "/skin_skeleton/"..targetPlatform.."sk_".. popImg.."_skin"--"LiBao_sh_test.lua"--
        local skin_json = skin_file..".json"
        if cc.FileUtils:getInstance():isFileExist(skin_json) then
            local animationObj = IFSkeletonAnimation:call("create", skin_json, skin_file..".atlas")
            dump("FileExist animationObj is: "..tostring(animationObj))
            if animationObj then
                self.m_titleSpr:addChild(animationObj)
                animationObj:setAnimation(0, "lbdh", true)
                animationObj:setContentSize(cc.size(99999, 99999))
                if popImg == "LiBao_lieyangkuanglong" then
                    animationObj:setPosition(cc.p(-30, 20))
                end
            end
        end

        -- 显示折扣比率
        self.m_percentLabel:setString(itemData.percent.."%")
    end

    if self.showType ~= 0 then
        self:setTableView()
        -- 支付价格
        local newPrice = LuaController:call("getDollarString", itemData.dollar, itemData.product_id)
        self.m_newDownPriceLabel:setString(newPrice)

        local oldPrice = LuaController:call("getDollarString", itemData.oldprice, "")
        self.m_oldDownPriceLabel:setString(oldPrice)

        self.m_soleOutSpr:setVisible(itemData.bought)

        local size = self.m_oldPriceSign:getContentSize()
        local lblSize = self.m_oldDownPriceLabel:getContentSize()
        self.m_oldPriceSign:setScaleX(lblSize.width/size.width)

        -- 中间的描述信息
        self.m_upDesLabel:setString(LibaoCommonFunc.getItemLangDes(itemData))

        if itemData.m_stamp == "" then
            self.m_stampNode:setVisible(false)
        else
            self.m_stampNode:setVisible(true)
            self.m_stampNode:removeAllChildren()
            local tbl = string.split(itemData.m_stamp, "|")
            
            for key, stampPath in pairs(tbl) do
                if stampPath ~= "" then
                    local img = CCLoadSprite:call("createSprite", stampPath..".png")
                    self.m_stampNode:addChild(img)
                    img:setPositionY(img:getContentSize().height*0.5)
                end
            end
        end
    else
        -- 礼包商店暂无展示组合礼包的地就只能再名字上想辙
        if itemData.options then
            local key = LibaoCommonFunc.getGroupIndexById(itemData.id)
            self.m_titleLabel:setString(getLang(itemData.name).."("..getLang("9450000", "#"..key)..")")
        end
    end
end

-- 更新礼包显示时间
function DyLibaoCommonView:updateLibaoTime()
    local curTime = getWorldTime()
    local lastTime = ""
    if self.itemData.time > 0 then
        local gapTime = self.itemData["end"] - curTime
        local count = math.floor(gapTime/(self.itemData.time*3600))
        lastTime = self.itemData["end"] - self.itemData.time*3600*count - curTime
    else
        lastTime = self.itemData["end"] - curTime
    end
    if lastTime < 0 then
        lastTime = 0
    end
    self.m_timeLabel:setString(format_time(lastTime))

    if lastTime <= 0 then
        -- PopupViewController:call("getInstance"):call("removeAllPopupView")
    end

end

function DyLibaoCommonView:update()
    if self.itemData.id ~= - 1 then
        self:updateLibaoTime()
    end
end

function DyLibaoCommonView:onClickCostBtn()
    if self.itemData.id ~= - 1 then
        PopupViewController:call("getInstance"):call("removeAllPopupView")
        LiBaoController.getInstance():callPayment(self.itemData.id, 1)
    end
end

function DyLibaoCommonView:onClickCommonCostBtn()
    if self.itemData.id ~= - 1 then
        PopupViewController:call("getInstance"):call("removeAllPopupView")
        LiBaoController.getInstance():callPayment(self.itemData.id, 2)
    end
end

function DyLibaoCommonView:onEnter()
    self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:update(dt) end, 1, false)
    registerScriptObserver(self, self.getLuaPackDown, msg_lua_pack_down)

    registerScriptObserver(self, self.refresh, GOLDEXCHANGE_SHOW_REFRESH)
end

function DyLibaoCommonView:onExit()
    self:getScheduler():unscheduleScriptEntry(self.m_entryId)
    unregisterScriptObserver(self, msg_lua_pack_down)
    unregisterScriptObserver(self, GOLDEXCHANGE_SHOW_REFRESH)
end

function DyLibaoCommonView:getLuaPackDown(ref)
    local popImg = ref:getCString()
    dump("self.itemData.popImg is: "..tostring(self.itemData.popImg))
    dump("DyLibaoCommonView:getLuaPackDown popImg is: "..popImg)
    if self.itemData.popup_image == popImg then
        self:refresh()
    end
end
---------------------------------------- 下方逻辑处理部分 Start----------------------------------------
function DyLibaoCommonView:initDownNodeInfo()
    local  proxy = cc.CCBProxy:create()
    local ccbiURL = ""
    ccbiURL = "ccbi/Lua_GoldAdCommonCellDown.ccbi"
    local nodeccb = CCBReaderLoad(ccbiURL, proxy, self)
    if nodeccb == nil then
        print("DyLibaoCommonView loadccb Lua_GoldAdCommonCell error")
        return false
    end

    self:addChild(nodeccb)
    nodeccb:setPosition(cc.p(self.viewSize.width*0.5, 0))
    local downHeight = self.m_nodeBuy:getContentSize().height

    if self.showType == 2 then
        -- 瀑布流方式，增加查看更多按钮
        local baseNode = cc.Node:create()
        self.m_nodeBuy:addChild(baseNode)
        baseNode:setPosition(cc.p(320, 130))

        local pic = CCLoadSprite:call("createSprite", "Activities_frame05.png")
        baseNode:addChild(pic)
        local txt = cc.Label:create()
        txt:setString(getLang("115331"))
        txt:setSystemFontSize(22)
        baseNode:addChild(txt)
        local menuItem = cc.ControlButton:create()
        menuItem:setPreferredSize(cc.size(150, 35))
        menuItem:setEnabled(true)
        menuItem:addHandleOfControlEvent(function(eventName,sender)
            self:onTouchMoreBtn()
        end, CCControlEventTouchUpInside)
        baseNode:addChild(menuItem)

        downHeight = downHeight + 56
    end

    local listHeight = self.viewSize.height + self.m_infolistNode:getPositionY() - AdCellSize.height - downHeight
    self.m_infolistNode:setContentSize(cc.size(self.viewSize.width, listHeight))
    local img = CCLoadSprite:call("createScale9Sprite", "Hospital_an.png")
    img:setContentSize(cc.size(self.viewSize.width, listHeight))
    img:setPosition(cc.p(self.viewSize.width*0.5, listHeight*0.5))
    self.m_infolistNode:addChild(img, -1)

    if self.showType ~= 2 then
        local touchLayer = cc.Layer:create()
        self.m_infolistNode:addChild(touchLayer, -1)
        touchLayer:setContentSize(cc.size(self.viewSize.width, listHeight))
        touchLayer:setPosition(cc.p(self.viewSize.width*0.5, listHeight*0.5))

        local function onTouch(eventType, x, y)  
            if eventType == "began" then  
                -- 只为了吞消息，避免上下滑动时还左右滑动。。
                return self:onTouchBegan(x, y)
            end
        end
        touchLayer:setTouchEnabled(true)
        touchLayer:registerScriptTouchHandler(onTouch)
        touchLayer:setSwallowsTouches(true)
    end
    CCCommonUtilsForLua:call("setButtonSprite", self.m_costBtn, "advbtn.png")
end

function DyLibaoCommonView:onTouchBegan(x, y)
    dump("DyLibaoCommonView:onTouchBegan ~~~~~~")
    if touchInside(self.m_infolistNode, x, y) then
        return true
    end
end

--itemCell
local itemCell = class("itemCell", function()
    return CCTableViewCell:new()
end)
local itemCellSize = cc.size(640, 70)
function itemCell:create(param)
    -- package.loaded["game.LiBao.LuaGoldExchangeCommonCell"] = nil
    -- local cell = require("game.LiBao.LuaGoldExchangeCommonCell").new(param)
    -- self:addChild(cell)
    -- self.cell = cell
    self:refresh(param)
    return self
end

function itemCell:refresh(param)
    if self.cell then
        self.cell:removeFromParent()
        self.cell = nil
    end
    self.itemData = param.itemData
    if self.itemData.type == 10 then
        local cell = LibaoGroupShowView.new({
            itemData = self.itemData,
            cellWidth = 580,
            cellHeight = itemCellSize.height,
            showType = 0,
        })
        self:addChild(cell)
        self.cell = cell
        cell:setPositionX(itemCellSize.width*0.5)
        cell:setPositionY(5)
    else
        -- package.loaded["game.LiBao.LuaGoldExchangeCommonCell"] = nil
        local cell = require("game.LiBao.LuaGoldExchangeCommonCell").new(param)
        self:addChild(cell)
        self.cell = cell
        self.cell:refresh(param)
    end
end

function itemCell.getCellSize(itemData)
    if itemData.type == 10 then
        return cc.size(itemCellSize.width, LibaoGroupShowView.getCellHeight(itemData, itemCellSize.height)+10)
    else
        return itemCellSize
    end
end
function DyLibaoCommonView:setTableView()
    self.m_itemListTbl = LibaoCommonFunc.getGoldItemList(self.itemData, true)
    dump(self.m_itemListTbl, "self.m_itemListTbl is: ")
    -- local groupHeight = 0
    local listViewSize = self.m_infolistNode:getContentSize()
    local groupBtnHeight = 80
    if self.itemData.options then
        -- 存在组合礼包
        if not self.groupBaseNode then
            local baseNode = cc.Node:create()
            self.groupBaseNode = baseNode
            self.m_infolistNode:addChild(baseNode)
            baseNode:setPosition(cc.p(listViewSize.width*0.5, listViewSize.height - groupBtnHeight*0.5-5))
            -- 更多组合按钮
            local groupMoreBtn = LibaoGroupShowView.createGetMoreGroupBtn(0)
            baseNode:addChild(groupMoreBtn)
            groupMoreBtn:setEnabled(true)
            groupMoreBtn:addHandleOfControlEvent(function(eventName,sender)
                self:onTouchGroupMoreBtn()
            end, CCControlEventTouchUpInside)
            CCCommonUtilsForLua:call("setButtonTitle", groupMoreBtn, getLang("9450001"))

            -- FAQ按钮
            local FAQBtn = cc.ControlButton:create()
            FAQBtn:setPreferredSize(cc.size(70, 70))
            local tmpNode = cc.Node:create()
            baseNode:addChild(tmpNode)
            tmpNode:addChild(FAQBtn)
            tmpNode:setScale(0.75)
            tmpNode:setPositionX(listViewSize.width*0.5 -40)

            FAQBtn:setEnabled(true)
            CCCommonUtilsForLua:call("setButtonSprite", FAQBtn, "btn_Lord_information.png")
            -- FAQBtn:setContentSize(cc.size(70, 70))
            FAQBtn:addHandleOfControlEvent(function(eventName,sender)
                dump("LibaoCommonView:showFAQ ~~~~~~() ")
                LuaController:call("showFAQ","45257")
            end, CCControlEventTouchUpInside)
        else
            self.groupBaseNode:setVisible(true)
        end
        -- groupHeight = groupBtnHeight
        listViewSize = cc.size(listViewSize.width, listViewSize.height - groupBtnHeight)
    else
        if self.groupBaseNode then
            self.groupBaseNode:setVisible(false)
        end
    end

    if self.m_itemListView then
        self.m_itemListView:setViewSize(listViewSize)
        self.m_itemListView:reloadData()
    else
        local function createFunc(index)
            local item = itemCell.new()
            return item:create({
                itemData = self.m_itemListTbl[index + 1],
            })
        end

        local function refreshFunc(cell, index)
            cell:refresh({
                itemData = self.m_itemListTbl[index + 1],
                })
        end

        local function cellSizeFunc(view, index)
            return itemCell.getCellSize(self.m_itemListTbl[index+1])
        end

        local function _numFunc()
            return #self.m_itemListTbl
        end
        self.m_itemListView = require("game.utility.TableViewExt").new({
            size        = listViewSize,
            direction   = kCCScrollViewDirectionVertical,
            createFunc  = createFunc,
            refreshFunc = refreshFunc,
            numFunc     = _numFunc,
            cellSize    = itemCellSize,
            cellSizeFunc = cellSizeFunc,
        })

        self.m_infolistNode:addChild(self.m_itemListView)
    end

    if self.showType == 2 then
        self.m_itemListView:setTouchEnabled(false)
    end
end

function DyLibaoCommonView:onTouchGroupMoreBtn()
    dump("LibaoCommonView:onTouchGroupMoreBtn() ")
    local path = "game.LiBao.LibaoGroupMoreListView"
    -- package.loaded[path] = nil
    local groupMoreView = require(path):create(self.itemData)
    PopupViewController:addPopupView(groupMoreView)
end

function DyLibaoCommonView:onTouchMoreBtn()
    LogController:postEventLog(LOG_LIBAO_PAGE, {
        itemId = self.itemData.id,
        is_smallType = false
        })

    local moreView = Drequire("game.LiBao.LuaGoldExchangeMoreListView"):create(self.itemData, false)
    PopupViewController:addPopupView(moreView)
end

---------------------------------------- 下方逻辑处理部分 Ended----------------------------------------




return DyLibaoCommonView

