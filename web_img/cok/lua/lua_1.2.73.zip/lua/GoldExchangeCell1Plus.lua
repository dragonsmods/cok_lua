GoldExchangeLuaCell1  = GoldExchangeLuaCell1 or {}
ccb["GoldExchangeLuaCell1"] = GoldExchangeLuaCell1

GoldExchangeCell1 = class("GoldExchangeCell1",
    function()
        return cc.Layer:create() 
    end
)
GoldExchangeCell1.__index = GoldExchangeCell1
function GoldExchangeCell1:create(path,params)
    local node = GoldExchangeCell1.new()
    node:init(path,params)
    return node
end
function GoldExchangeCell1:init(path,params)
    local dic1 = CCDictionary:create()
    self.rootPath = path
    self.data = params
    local  proxy = cc.CCBProxy:create()
    local ccbiUrl = self.rootPath .. "/ccbi/GoldExchangeLuaCell1.ccbi"
    -- local chechV = tostring(CCCommonUtilsForLua:getPropById("99020","k1"))
    dic1:setObject(CCString:create(tostring("99020")), "1")
    dic1:setObject(CCString:create(tostring("k1")), "2")
    local chechV = CCCommonUtilsForLua:comFunc("getPropById", dic1):getCString()
    -- if CCCommonUtilsForLua:checkVersion(chechV) == true then
    dic1:setObject(CCString:create(tostring(chechV)), "1")
    if CCCommonUtilsForLua:comFunc("checkVersion", dic1):getValue() == true then
        -- if CCCommonUtilsForLua:isFlip() then
        if CCCommonUtilsForLua:comFunc("isFlip", 0):getValue() == true then
            ccbiUrl = self.rootPath .. "/ccbi/GoldExchangeLuaCell1_flip.ccbi"
        end
    end
    local  node  = CCBReaderLoad(ccbiUrl,proxy,GoldExchangeLuaCell1)
    if(nil == node) then
        return
    end
    
    local  layer = tolua.cast(node,"cc.Layer")
    if nil ~= GoldExchangeLuaCell1["m_nameLabel"] then
        self.m_nameLabel = tolua.cast(GoldExchangeLuaCell1["m_nameLabel"],"cc.LabelTTF")
        if nil ~= self.m_nameLabel then
            --self.m_nameLabel:setString("")
        end
    end
    --print "GoldExchangeCell1:init___1"

    if nil ~= GoldExchangeLuaCell1["m_numLabel"] then
        --print "GoldExchangeCell1:init___1_1"
        self.m_numLabel = tolua.cast(GoldExchangeLuaCell1["m_numLabel"],"cc.LabelTTF")
        --print "GoldExchangeCell1:init___1_2"
        if nil ~= self.m_numLabel then
            --print "GoldExchangeCell1:init___1_3"
            local numStr = string.format(self.data[2])
            --print "GoldExchangeCell1:init___1_4"
            self.m_numLabel:setString(numStr)
        end
    end
    --print "GoldExchangeCell1:init___2"
    if nil ~= GoldExchangeLuaCell1["m_iconNode"] then
        self.m_iconNode = tolua.cast(GoldExchangeLuaCell1["m_iconNode"],"cc.LayerColor")
        if nil ~= self.m_iconNode then
            -- LuaController:addIconByType(self.m_iconNode,self.data[1],self.m_nameLabel,1,45)
            dic1:setObject(self.m_iconNode, "1")
            dic1:setObject(CCString:create(tostring(self.data[1])), "2")
            dic1:setObject(self.m_nameLabel, "3")
            dic1:setObject(CCInteger:create(1), "4")
            dic1:setObject(CCInteger:create(45), "5")
            LuaController:comFunc("addIconByType", dic1)
        end
    end
    --print "GoldExchangeCell1:init___3"
    self:addChild(node)
    -- local chechV = tostring(CCCommonUtilsForLua:getPropById("99020","k1"))
    dic1:setObject(CCString:create(tostring("99020")), "1")
    dic1:setObject(CCString:create(tostring("k1")), "2")
    local chechV = CCCommonUtilsForLua:comFunc("getPropById", dic1):getCString()
    -- if CCCommonUtilsForLua:checkVersion(chechV) == true then
    dic1:setObject(CCString:create(tostring(chechV)), "1")
    if CCCommonUtilsForLua:comFunc("checkVersion", dic1):getValue() == true then
        -- if CCCommonUtilsForLua:isFlip() then
        if CCCommonUtilsForLua:comFunc("isFlip", 0):getValue() == true then
            self:setFlip()
        end
    end
end
function GoldExchangeCell1:setFlip()
    if self.m_nameLabel ~= nil then
        self.m_nameLabel:setScaleX(-1)
        self.m_nameLabel:setPositionX(self.m_nameLabel:getPositionX()-self.m_nameLabel:getContentSize().width)
    end
    if self.m_numLabel ~= nil then
        self.m_numLabel:setScaleX(-1)
    end    
end