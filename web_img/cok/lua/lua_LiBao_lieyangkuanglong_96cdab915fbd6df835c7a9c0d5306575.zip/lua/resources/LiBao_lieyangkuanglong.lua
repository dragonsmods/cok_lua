cfg_table = {
	-- ["localize"]={["CN"]=1,["TW"]=2},
	["iconOrder"] = 2,  -- 是否显示图片  值大小为显示顺序，大的最后显示
	-- ["particleOrder"] = 3,  -- 是否显示粒子,particle 值大小为显示顺序，大的最后显示
	-- ["spineOrder"] = 1,   -- 是否显示spine, 与spineHide不共存 值大小为显示顺序，大的最后显示
	-- ["spineHide"] = true,  -- 为兼容旧版本的特殊处理，如果该礼包有旧的spine动画，且不打算显示spine动画，则必须配置这个参数，如果没有旧的spine动画，则无需配置
}