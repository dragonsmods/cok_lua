cfg_table = {
	["layerX"] = -13,
	["layerY"] = -33,
	["layerScale"] = 1,
	["particle"] = {
		["parName"] = {
			[1] = "KingdomIcon_1",
			[2] = "KingdomIcon_2",
			[3] = "KingdomIcon_3",
			[4] = "",
		},
		["parPosX"] = 50,
		["parPosY"] = 50,
		["parScale"] = 0.9
	}
}