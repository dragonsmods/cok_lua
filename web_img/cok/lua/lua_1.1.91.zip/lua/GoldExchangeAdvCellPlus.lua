GoldExchangeAdvLuaCell  = GoldExchangeAdvLuaCell or {}
ccb["GoldExchangeAdvLuaCell"] = GoldExchangeAdvLuaCell

GoldExchangeAdvCell = class("GoldExchangeAdvCell",
	function()
        return cc.Layer:create() 
	end
)
GoldExchangeAdvCell.__index = GoldExchangeAdvCell
function GoldExchangeAdvCell:create(parent,path,params)
    --print "function GoldExchangeAdvCell:create(parent,path,params)"
	local node = GoldExchangeAdvCell.new()
	node:init(parent,path,params)
	return node
end
function GoldExchangeAdvCell:init(parent,path,params)
    local dic1 = CCDictionary:create()
    self:initData(params)
    local popImg = string.format(self.data[19])
    print("(COK2-AdvCell)popImg___:" .. popImg)
    ----print "function GoldExchangeAdvCell:init(parent,path,params)"
    local strPath = string.format(path)
	self.rootPath = strPath
    local ccb_file = self.rootPath .. "/ccbi/GoldExchangeAdv"..popImg.."LuaCell_NEW.ccbi"
    print(ccb_file)
    local firstIdx = string.find(popImg,"_",1)

    local dict1 = CCDictionary:create()
    dict1:setObject(CCString:create(tostring("99023")), "1")
    dict1:setObject(CCString:create(tostring("k1")), "2")
    local verK1 = CCCommonUtilsForLua:comFunc("getPropById", dict1):getCString()
    dict1 = CCDictionary:create()
    dict1:setObject(CCString:create(tostring(verK1)),"1")
    local checkVersion = CCCommonUtilsForLua:comFunc("checkVersion",dict1):getValue()
    dict1 = CCDictionary:create()
    dict1:setObject(CCString:create(tostring("99023")),"1")
    -- local checkTestServer = CCCommonUtilsForLua:comFunc("checkTestServer",dict1):getValue()
    local checkTestServer = false
    if CCCommonUtilsForLua:comFunc("checkTestServer",dict1)~=nil then
        checkTestServer = CCCommonUtilsForLua:comFunc("checkTestServer",dict1):getValue()
    end

    local checkTestServer_test = false
    if CCCommonUtilsForLua:comFunc("checkTestServer_test",dict1)~=nil then
        checkTestServer_test = CCCommonUtilsForLua:comFunc("checkTestServer_test",dict1):getValue()
    end

    if (firstIdx ~= nil) then
        local firstStr = string.sub(popImg,1,firstIdx-1)

        local dic1 = CCDictionary:create()
        dic1:setObject(CCString:create("package"), "1")
        -- local newV2 = true;--CCCommonUtilsForLua:comFunc("isFunOpenByKey", dic1):getValue()
        local dict = CCDictionary:create()
        dict:setObject(CCString:create("2.17.0"),"1")
        local newV2 = CCCommonUtilsForLua:comFunc("checkVersion",dict):getValue()
        if self.data[dataCount]=="m_isNewPicture" then
            newV2=false
        end
        
        print("(COK2-AdvCell)firstStr:" .. firstStr..",checkVersion:"..tostring(checkVersion)..",checkTestServer:"..tostring(checkTestServer)..",checkTestServer_test:"..tostring(checkTestServer_test))
        if firstStr=="LiBao" or popImg=="envelope_gift" then
            self.openType = 1
            if not newV2 and (checkVersion==true or checkTestServer==true) then
                print("(COK2-AdvCell)initWithCommon_v3" )
                self:initWithCommon_v3(parent,path,params)
            else
                print("(COK2-AdvCell)initWithCommon" )
                self:initWithCommon(parent,path,params)
            end
            return
        end
    end
    
    ----print "parent....is....."
    ----print (parent)
    self.parentNode = parent
    
    self:initItems()
    self.startPos = cc.p(0, 0)

    loadLuaResource(self.rootPath .. "/resources/".. self.data[19] .."adv.plist")

    local  proxy = cc.CCBProxy:create()
    GoldExchangeAdvLuaCell.onClickCostBtn = function()
    	self:onClickCostBtn()
	end
    GoldExchangeAdvLuaCell.onPackageBtnClick = function()
        self:onPackageBtnClick()
    end
    local ccbiURL = strPath .. "/ccbi/GoldExchangeAdv"..self.data[19].."LuaCell_NEW.ccbi"
    ----print ("adv ccb :" .. ccbiURL)

	local ccbnode = CCBReaderLoad(ccbiURL,proxy,GoldExchangeAdvLuaCell)
    local  layer = tolua.cast(ccbnode,"cc.Layer")
    ----print "if nil ~= GoldExchangeAdvLuaCell[m_timeLabel] then"
    if nil ~= GoldExchangeAdvLuaCell["m_timeLabel"] then
        self.m_timeLabel = tolua.cast(GoldExchangeAdvLuaCell["m_timeLabel"],"cc.Label")
    end
    ----print "GoldExchangeAdvLuaCell m_percentLabel"
    if nil ~= GoldExchangeAdvLuaCell["m_percentLabel"] then
        self.m_percentLabel = tolua.cast(GoldExchangeAdvLuaCell["m_percentLabel"],"cc.Label")
    end
    ----print "GoldExchangeAdvLuaCell m_moreLabel"
    if nil ~= GoldExchangeAdvLuaCell["m_moreLabel"] then
        self.m_moreLabel = tolua.cast(GoldExchangeAdvLuaCell["m_moreLabel"],"cc.Label")
    end
    ----print "GoldExchangeAdvLuaCell m_desLabel"
    if nil ~= GoldExchangeAdvLuaCell["m_desLabel"] then
        self.m_desLabel = tolua.cast(GoldExchangeAdvLuaCell["m_desLabel"],"cc.Label")
    end
    ----print "GoldExchangeAdvLuaCell m_getLabel"
    if nil ~= GoldExchangeAdvLuaCell["m_getLabel"] then
        self.m_getLabel = tolua.cast(GoldExchangeAdvLuaCell["m_getLabel"],"cc.Label")
        if nil ~= self.m_getLabel then
    		--local getStr = string.format(LuaController:getLang1("115073",""))
    		--self.m_getLabel:setString(getStr)
    		self.m_getLabel:setVisible(false)
    	end
    end
    ----print "if nil ~= GoldExchangeAdvLuaCell[m_newPriceLabel] then"
    if nil ~= GoldExchangeAdvLuaCell["m_newPriceLabel"] then
        --print "nil ~= GoldExchangeAdvLuaCell[m_newPriceLabel]"
        self.m_newPriceLabel = tolua.cast(GoldExchangeAdvLuaCell["m_newPriceLabel"],"cc.Label")
    end
    ----print "if nil ~= GoldExchangeAdvLuaCell[m_newPriceLabel] then"

    if nil ~= GoldExchangeAdvLuaCell["m_getGoldNumText"] then
        self.m_getGoldNumText = tolua.cast(GoldExchangeAdvLuaCell["m_getGoldNumText"],"cc.LabelBMFont")
    end
    ----print "if nil ~= GoldExchangeAdvLuaCell[m_costBtn] then"

    if nil ~= GoldExchangeAdvLuaCell["m_costBtn"] then
        self.m_costBtn = tolua.cast(GoldExchangeAdvLuaCell["m_costBtn"],"cc.ControlButton")
        if nil ~= self.m_costBtn then
            --LuaController:addButtonLight(self.m_costBtn)
        end
    end
    ----print "if nil ~= GoldExchangeAdvLuaCell[m_showMoneyNode] then"

    if nil ~= GoldExchangeAdvLuaCell["m_showMoneyNode"] then
    	self.m_showMoneyNode = tolua.cast(GoldExchangeAdvLuaCell["m_showMoneyNode"],"cc.LayerColor")
    end
    ----print "if nil ~= GoldExchangeAdvLuaCell[m_showMoreNode] then"
    
    if nil ~= GoldExchangeAdvLuaCell["m_showMoreNode"] then
    	self.m_showMoreNode = tolua.cast(GoldExchangeAdvLuaCell["m_showMoreNode"],"cc.LayerColor")
    	if nil ~= self.m_showMoreNode then
    		--print ("show more node 111111")
            if self.m_showMoreNode:isVisible() == true then
                local function onTouchBegan(x, y)
                    --print "11"
                    if(nil ~= self.m_showMoreNode) then
                    --print "12"
                        if(nil ~= self.m_showMoreNode:getParent()) then
                    --print "13"
                            local pos = self.m_showMoreNode:getParent():convertToNodeSpace(CCPoint(x,y))
                    --print "14"
                            local rect = self.m_showMoreNode:getBoundingBox()
                    --print "15"
                            if(cc.rectContainsPoint(rect, pos) == true) then
                    --print "16"
                                self.startPos = cc.p(x, y)
                                return true
                            end 
                        end
                    end
                    return false
                end
                local function onTouchMoved(x, y)
                    --print "touch move"
                end
                local function onTouchEnded(x, y)
                    if(nil == self.m_showMoreNode) then
                        --print "touch node empty"
                        return
                    end

                    if self.m_showMoreNode:isVisible() == false then
                        --print "touch node hide"
                        return
                    end

                    if(nil == self.m_showMoreNode:getParent()) then
                        --print "touch node parent empty"
                        return
                    end

                    --print "local pos = self.m_showMoreNode:getParent():convertToNodeSpace(CCPoint(x,y))"
                    local pos0 = self.startPos
                    if nil == pos0 then
                        return
                    end
                    self.startPos = cc.p(0, 0)
                    local pos = self.m_showMoreNode:getParent():convertToNodeSpace(CCPoint(x,y))
                    --print "local pos = self.m_showMoreNode:getParent():convertToNodeSpace(CCPoint(x,y))"
                    local rect = self.m_showMoreNode:getBoundingBox()
                    if(cc.rectContainsPoint(rect, pos) == true) then
                        if cc.pGetDistance(pos0, cc.p(x, y)) < 10 then
                            local itemid = string.format(self.data[1])
                            -- LuaController:showDetailPopup(itemid)
                            dic1:setObject(CCString:create(tostring(itemid)), "1")
                            LuaController:comFunc("showDetailPopup", dic1)
                            --print "touch inside"
                            return
                        end
                    end
                    --print "touch outside"
                end

                local function onTouch(eventType, x, y)
                    --print (eventType)  
                    if eventType == "began" then
                        --print "return self:onTouchBegan(x, y)"  
                        return onTouchBegan(x, y)  
                    elseif eventType == "moved" then  
                        --print "return self:onTouchMoved(x, y) "
                        return onTouchMoved(x, y)  
                    else  
                        --print "return self:onTouchEnded(x, y) "
                        return onTouchEnded(x, y)  
                    end
                end
                ----print "self.m_showMoreNode:registerScriptTouchHandler(onTouch)"
                self.m_showMoreNode:registerScriptTouchHandler(onTouch)
                ----print "end self.m_showMoreNode:registerScriptTouchHandler(onTouch)"
                self.m_showMoreNode:setTouchEnabled(true)
                self.m_showMoreNode:setSwallowsTouches(false)
            end
        end
    end
    ----print "if nil ~= GoldExchangeAdvLuaCell[m_packageBtn] then"
    if nil ~= GoldExchangeAdvLuaCell["m_packageBtn"] then
        ----print "~~~~1"
        self.m_packageBtn = tolua.cast(GoldExchangeAdvLuaCell["m_packageBtn"],"cc.ControlButton")
        ----print(GoldExchangeAdvLuaCell["m_packageBtn"])
        ----print "~~~~2"

        if nil ~= self.m_packageBtn then
        ----print "~~~~3"
        
            local showPackBtn = false
        ----print "~~~~4"
            if self.data[21] ~= nil then
        ----print "~~~~5"
                if self.data[21] == "1" then
        ----print "~~~~6"
                    showPackBtn = true
        ----print "~~~~7"
                end
        ----print "~~~~8"
            end
        ----print "~~~~9"
            if showPackBtn == true then
        ----print "~~~~10"
                self.m_packageBtn:setVisible(true)
        ----print "~~~~11"
            else
        ----print "~~~~12"
                self.m_packageBtn:setVisible(false)
        ----print "~~~~13"
        ----print "~~~~19"
            end
        ----print "~~~~20"
            --LuaController:addButtonLight(self.m_costBtn)
        end
    end
    if nil ~= GoldExchangeAdvLuaCell["m_lblDesc1"] then
        self.m_lblDesc1 = tolua.cast(GoldExchangeAdvLuaCell["m_lblDesc1"],"cc.Label")
    end

    ----print "self:initView()"
    self:initView()
    ----print "after:initView()"
    local function scheduleBack()
    ----print "_____GoldExchangeAdvCell:scheduleBack"
    local dic2 = CCDictionary:create()
    if(nil ~= self.m_timeLabel) then
        -- local curTime = LuaController:getWorldTime()
        local curTime = LuaController:comFunc("getWorldTime", 0):getValue()
        local lastTime = 0
        local expTime = tonumber(self.data[14])
        local Dtime = 3600
        if self.data[28]~=nil and tostring(self.data[28])~="" and tonumber(self.data[28])~=nil and tonumber(self.data[28])>0 then
            expTime = tonumber(self.data[28])
            Dtime=60
        end
        -- print("Dtime:"..tostring(Dtime))
        local endTime = tonumber(self.data[13])
        if expTime>0 then
            local gapTime = endTime - curTime
            local count =  gapTime / (expTime * Dtime)
            count = math.floor(count)
            lastTime = endTime - (expTime*Dtime)*count-curTime;
        else
            lastTime = endTime - curTime
        end
        -- local timeStr = LuaController:getSECLang(lastTime)
        dic2:setObject(CCInteger:create(tonumber(lastTime)), "1")
        local timeStr = LuaController:comFunc("getSECLang", dic2):getCString()
        local sss = string.format(timeStr)
        self.m_timeLabel:setString(tostring(sss))
        if (endTime - curTime <= 0 ) then
            self.m_costBtn:setEnabled(false)
            self:removeAllEvent()
            -- LuaController:removeAllPopup()
            LuaController:comFunc("removeAllPopup", 0)
        end 
    end
    end

    local function eventHandler( eventType )
            if eventType == "enter" then
                ----print " GoldExchangeAdvCell enter"
                scheduleBack()
                self.m_entryId = tonumber(ccbnode:getScheduler():scheduleScriptFunc(scheduleBack, 1, false))
            elseif eventType == "exit" then
                ----print "GoldExchangeAdvCell exit"
                if nil ~= self.m_entryId then
                    ccbnode:getScheduler():unscheduleScriptEntry(self.m_entryId)
                end
            elseif eventType == "cleanup" then
                ----print "GoldExchangeAdvCell cleanup"
                ccbnode:unregisterScriptHandler()
            end
    end
    ----print "ccbnode:registerScriptHandler(eventHandler)"
    ccbnode:registerScriptHandler(eventHandler)
    ----print "self.parentNode:addChild(ccbnode)"
    local ttt = tolua.cast(self.parentNode, "cc.Node")
    local ttt2 = tolua.cast(ccbnode, "cc.Node")
    ----print(ttt)
    ----print (ttt2)
    -- self.parentNode:addChild(ccbnode)
    self.parentNode:addChild(self)
    self:addChild(ccbnode)
    ----print "self:setContentSize(CCSize(540, 220))"
    self:setContentSize(CCSize(616, 246))
    ----print "ccbnode:setPositionY(-66)"
    -- ccbnode:setPositionY(-66)
    ----print "self.ccbNode = ccbnode"
    self.ccbNode = ccbnode
----print "12313"
    --[[local function onNodeEvent(event)
        if event == "enter" then
            ------print "gold_exchange_adv_cell_enter"
        elseif event == "exit" then
            ------print "gold_exchange_adv_cell_exit"
            self:removeAllEvent()
        end
    end
    self.ccbNode:registerScriptHandler(onNodeEvent)]]
end

function GoldExchangeAdvCell:initData(params)
    local paramsStr = string.format(params)
    ------print("params:" .. paramsStr)
    self.data = {}
    local index = 1
    local startI = 1
    local fIndex = string.find(paramsStr,",",startI)
    local tmpValue = "" 
    while (true) do
        tmpValue = string.sub(paramsStr,startI,fIndex-1)
        ------print(string.format(startI) .. "," .. string.format(fIndex-1) .. ", params" .. string.format(index) .. ":" .. tmpValue)
        self.data[index] = tmpValue
        index = index + 1
        startI = fIndex + 1
        fIndex = string.find(paramsStr,",",startI)
        if (fIndex == nil) then
            tmpValue = string.sub(paramsStr,startI,string.len(paramsStr))
            ------print( string.format(startI) .. "," .. string.format(string.len(paramsStr)) .. ", params" .. string.format(index) .. ":" .. tmpValue)
            self.data[index] = tmpValue
            break
        end
    end
end
function GoldExchangeAdvCell:initItems()
    -----print("GoldExchangeAdvCell:initItems1")
    self.items = nil
    if nil == self.data[7] then
        ----print("GoldExchangeAdvCell:initItems2")
        return
    end
    local itemsStr = string.format(self.data[7])
    if(itemsStr == "") then
        ----print("GoldExchangeAdvCell:initItems3")
        return
    end
    
    ----print("items:"..itemsStr)
    self.items = {}
    local itemIndex = 1
    local itemSIndex = 1
    local itemFIndex = string.find(itemsStr,"|",itemSIndex)

    if itemFIndex == nil then
        local itemValueTmp = string.sub(itemsStr,itemSIndex,string.len(itemsStr))
        local itemFindIndex =  string.find(itemValueTmp,";",1)
        local tabelValue1 = string.sub(itemValueTmp,1,itemFindIndex-1)
        local tabelVaule2 = string.sub(itemValueTmp,itemFindIndex+1,string.len(itemValueTmp))
        local iValue = {tabelValue1,tabelVaule2}
        self.items[itemIndex] = iValue;
        ----print("items" .. string.format(itemIndex) .. ":" .. tabelValue1 .."," .. tabelVaule2)
        return
    end

--    while(true) do
--        local itemValueTmp = string.sub(itemsStr,itemSIndex,itemFIndex-1)
--        local itemFindIndex =  string.find(itemValueTmp,";",1);
--        local tabelValue1 = string.sub(itemValueTmp,1,itemFindIndex-1)
--        local tabelVaule2 = string.sub(itemValueTmp,itemFindIndex+1,string.len(itemValueTmp))
--        local iValue = {tabelValue1,tabelVaule2}
--        self.items[itemIndex] = iValue;
        ----print("items" .. string.format(itemIndex) .. ":" .. tabelValue1 .."," .. tabelVaule2)
--        itemIndex = itemIndex + 1
--        itemSIndex =  itemFIndex + 1
--        itemFIndex = string.find(itemsStr,"|",itemSIndex)
--        if itemFIndex == nil then
--            itemValueTmp = string.sub(itemsStr,itemSIndex,string.len(itemsStr))
--            itemFindIndex =  string.find(itemValueTmp,";",1)
--            tabelValue1 = string.sub(itemValueTmp,1,itemFindIndex-1)
--            tabelVaule2 = string.sub(itemValueTmp,itemFindIndex+1,string.len(itemValueTmp))
--            iValue = {tabelValue1,tabelVaule2}
--            self.items[itemIndex] = iValue;
            ----print("items" .. string.format(itemIndex) .. ":" .. tabelValue1 .."," .. tabelVaule2)
--            return
--        end
--    end
    while(true) do
        local itemValueTmp = string.sub(itemsStr,itemSIndex,itemFIndex-1)
        local itemFindIndex =  string.find(itemValueTmp,";",1);
        local tabelValue1 = string.sub(itemValueTmp,1,itemFindIndex-1)
        local tabelVaule2 = string.sub(itemValueTmp,itemFindIndex+1,string.len(itemValueTmp))
        local iValue = {tabelValue1,tabelVaule2}
        self.items[itemIndex] = iValue;
        ----print("items" .. string.format(itemIndex) .. ":" .. tabelValue1 .."," .. tabelVaule2)
        itemIndex = itemIndex + 1
        itemSIndex =  itemFIndex + 1
        itemFIndex = string.find(itemsStr,"|",itemSIndex)
        if itemFIndex == nil then
            itemValueTmp = string.sub(itemsStr,itemSIndex,string.len(itemsStr))
            itemFindIndex =  string.find(itemValueTmp,";",1)
            tabelValue1 = string.sub(itemValueTmp,1,itemFindIndex-1)
            tabelVaule2 = string.sub(itemValueTmp,itemFindIndex+1,string.len(itemValueTmp))
            iValue = {tabelValue1,tabelVaule2}
            self.items[itemIndex] = iValue;
            ----print("items" .. string.format(itemIndex) .. ":" .. tabelValue1 .."," .. tabelVaule2)
            return
        end
    end
end
function GoldExchangeAdvCell:initView()
    ----print "function GoldExchangeAdvCell:initView()"
    local dic1 = CCDictionary:create()
    if nil ~= self.m_getGoldNumText then
        local numKey = string.format(self.data[3]);
        if numKey~="" then
            local goldstr = "Gold+"
            -- local numStr = string.format(LuaController:getCMDLang(numKey))
            dic1:setObject(CCString:create(tostring(numKey)), "1")
            local numStr = LuaController:comFunc("getCMDLang", dic1):getCString()
            local strstr = goldstr .. numStr
            local sss = string.format(strstr)
            self.m_getGoldNumText:setString(sss)
        else
            self.m_getGoldNumText:setString("")
        end
    end
    ----print "1"
    if nil ~= self.m_percentLabel then
        local percentStr = string.format(self.data[8])
        -- percentStr = percentStr .. "%"
        if percentStr~="" then
            if self.data[19] == "hot_sale_1" then
                percentStr = percentStr .. "% OFF"
            else
                percentStr = percentStr .. "%"
            end
            print("(NEWCOK2-adv-cell)self.data[19]:"..self.data[19]..";percentStr:"..percentStr)
            -- local sss = string.format(percentStr)
            self.m_percentLabel:setString(percentStr)
            self.m_percentLabel:setScale(1.2)
        else
            self.m_percentLabel:setString("")
            if self.m_percentBg~=nil then
                self.m_percentBg:setVisible(false)
            end
        end
    end
    ----print "2"
    local itemNull = false
    local itemStr = string.format(self.data[7])
    ----print "3"
    if string.len(itemStr) == 0 then
    	if nil ~= self.m_moreLabel then
    		self.m_moreLabel:setString("")
    	end
    	if nil ~= self.m_showMoreNode then
    		self.m_showMoreNode:setVisible(false)
    	end
    	if nil ~= self.m_desLabel then
    		self.m_desLabel:setString("")
    	end
    else
        if self.data[19] ~= "envelope_gift" then
            if nil ~= self.m_moreLabel then
                -- local moreStr = string.format(LuaController:getLang("102271"))
                dic1:setObject(CCString:create(tostring("102271")), "1")
                local moreStr = LuaController:comFunc("getLang", dic1):getCString()
                self.m_moreLabel:setString(moreStr)
            end
            if nil ~= self.m_showMoreNode then
                self.m_showMoreNode:setVisible(true)
            end
            if nil ~= self.m_desLabel then
                -- local desStr = string.format(LuaController:getLang("101237"))
                dic1:setObject(CCString:create(tostring("101237")), "1")
                local desStr = LuaController:comFunc("getLang", dic1):getCString()
                self.m_desLabel:setString(desStr)
            end
        end
    end
    	
    ----print "4"
    if nil ~= self.m_newPriceLabel then
		local dollar = string.format(self.data[4])
    	local pID = string.format(self.data[11])
    	-- local newPrice = string.format(LuaController:getDollarString(dollar,pID))
        dic1:setObject(CCString:create(tostring(dollar)), "1")
        dic1:setObject(CCString:create(tostring(pID)), "2")
        local newPrice = LuaController:comFunc("getDollarString", dic1):getCString()
    	self.m_newPriceLabel:setString(newPrice)
	end
    ----print "5"

    if self.data[19] == "envelope_gift" then
        if nil ~= self.m_lblDesc1 then
            if self.items[1] ~= nil then
                if self.items[1][2] ~= nil then
                    local itemCount = string.format(self.items[1][2])
                    -- local desStr = string.format(LuaController:getLang1("101045",itemCount))
                    dic1:setObject(CCString:create(tostring("101045")), "1")
                    dic1:setObject(CCString:create(tostring(itemCount)), "2")
                    local desStr = LuaController:comFunc("getLang1", dic1):getCString()
                    self.m_lblDesc1:setString(desStr)
                end
            end
        end
        if nil ~= self.m_timeNode then
            self.m_timeNode:setVisible(false)
        end
        if nil ~= self.m_showMoneyNode then
            self.m_showMoneyNode:setVisible(false)
        end
        if nil ~= self.m_desLabel then
            self.m_desLabel:setVisible(false)
        end
        if nil ~= self.m_getLabel then
            self.m_getLabel:setVisible(false)
        end
    end
end
function GoldExchangeAdvCell:removeAllEvent()
    --releaseLuaResource(self.rootPath .. "/resources/".. self.data[19] .."adv")
    GoldExchangeAdvLuaCell.onClickCostBtn = nil
    if nil ~= self.m_showMoreNode then
        self.m_showMoreNode:unregisterScriptTouchHandler()
    end
    if nil ~= self.m_costBtn then
        self.m_costBtn:setEnabled(false)
    end
    if nil ~= self.m_timeLabel then
        self.m_timeLabel:stopAllActions()
    end
    --[[if nil ~= self.ccbNode then
        self.ccbNode:unregisterScriptHandler()
    end]]
end
--[[function GoldExchangeAdvCell:scheduleBack()
    ----print "_____GoldExchangeAdvCell:scheduleBack"
    if(self.m_timeLabel) then
        local curTime = LuaController:getWorldTime()
        local lastTime = 0
        local expTime = tonumber(self.data[14])
        local endTime = tonumber(self.data[13])
        if expTime>0 then
            local gapTime = endTime - curTime
            local count =  gapTime / (expTime * 3600)
            count = math.floor(count)
            lastTime = endTime - (expTime*3600)*count-curTime;
        else
            lastTime = endTime - curTime
        end
        local timeStr = LuaController:getSECLang(lastTime)
        self.m_timeLabel:setString(timeStr)
        if (endTime - curTime <= 0 ) then
            self.m_costBtn:setEnabled(false)
            self:removeAllEvent()
            LuaController:removeAllPopup()
        end 
    end
end]]
function GoldExchangeAdvCell:onClickCostBtn()
    local itemid = string.format(self.data[1])
    -- LuaController:callPayment(itemid)
    local dic1 = CCDictionary:create()
    dic1:setObject(CCString:create(tostring(itemid)), "1")
    LuaController:comFunc("callPayment", dic1)
    self:removeAllEvent()
    -- LuaController:removeAllPopup()
    LuaController:comFunc("removeAllPopup", 0)
end
function GoldExchangeAdvCell:onPackageBtnClick()
    if nil ~= self.data[21] then
        self:removeAllEvent()
        -- LuaController:removeAllPopup()
        LuaController:comFunc("removeAllPopup", 0)
        local itemid = string.format(self.data[1])
        -- LuaController:toSelectUser(itemid,false,2)
        local dic1 = CCDictionary:create()
        dic1:setObject(CCString:create(tostring(itemid)), "1")
        dic1:setObject(CCBool:create(false), "2")
        dic1:setObject(CCInteger:create(2), "3")
        LuaController:comFunc("toSelectUser", dic1)
    end
end
-- function GoldExchangeAdvCell:onTouchBegan(x, y)
--     --print "11"
-- 	if(nil ~= self.m_showMoreNode) then
--     --print "12"
--         if(nil ~= self.m_showMoreNode:getParent()) then
--     --print "13"
--             local pos = self.m_showMoreNode:getParent():convertToNodeSpace(CCPoint(x,y))
--     --print "14"
--             local rect = self.m_showMoreNode:getBoundingBox()
--     --print "15"
--             if(cc.rectContainsPoint(pos) == true) then
--     --print "16"
--                 return true
--             end 
--         end
--     end
--     return false
-- end
-- function GoldExchangeAdvCell:onTouchMoved(x, y)
-- 	--print "touch move"
-- end
-- function GoldExchangeAdvCell:onTouchEnded(x, y)
--     if(nil == self.m_showMoreNode) then
--     	--print "touch node empty"
--     	return
--     end

--     if self.m_showMoreNode:isVisible() == false then
--     	--print "touch node hide"
--     	return
--     end

--    	if(nil == self.m_showMoreNode:getParent()) then
--    		--print "touch node parent empty"
--    		return
--    	end

--     --print "local pos = self.m_showMoreNode:getParent():convertToNodeSpace(CCPoint(x,y))"
--     local pos = self.m_showMoreNode:getParent():convertToNodeSpace(CCPoint(x,y))
--     --print "local pos = self.m_showMoreNode:getParent():convertToNodeSpace(CCPoint(x,y))"
--     local rect = self.m_showMoreNode:getBoundingBox()
--     if(cc.rectContainsPoint(pos) == true) then
--     	local itemid = string.format(self.data[1])
--     	LuaController:showDetailPopup(itemid)
--     	--print "touch inside"
--     	return
--    	end
--    	--print "touch outside"
-- end
function GoldExchangeAdvCell:getCostBtnRect()
    ----print "function GoldExchangeAdvCell:getCostBtnRect()"
    if nil ~= self.m_costBtn then
        ----print "1"
        local size = self.m_costBtn:getContentSize()
        ----print "1"
        local pos = CCPoint(self.m_costBtn:getPosition())
        ------print ("pos1:[" .. string.format(pos.x) .. "," .. string.format(pos.y) .. "]")
        ----print "1"
        pos = self.m_costBtn:getParent():convertToWorldSpace(pos)
        ------print ("pos2:[" .. string.format(pos.x) .. "," .. string.format(pos.y) .. "]")
        ----print "1"
        pos = self.ccbNode:convertToNodeSpace(pos)
        ------print ("pos3:[" .. string.format(pos.x) .. "," .. string.format(pos.y) .. "]")
        ------print ("size:[" .. string.format(size.width) .. "," .. string.format(size.height) .. "]")
        return pos.x, pos.y, size.width, size.height
    end
    ----print "return 0,0,0,0"
    return 0,0,0,0
end


------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------

function GoldExchangeAdvCell:initWithCommon(parent,path,params)
    ----print "function GoldExchangeAdvCell:init(parent,path,params)"
    local dic1 = CCDictionary:create()
    local strPath = string.format(path)
    self.rootPath = strPath
    self.parentNode = parent
    
    self:initItems()
    self.startPos = cc.p(0, 0)

    loadLuaResource(self.rootPath .. "/resources/LiBaoCommonView.plist")
    print("initWithCommon  (COK2)path:"..self.rootPath .. "/resources/LiBaoCommonView.plist")
    local popImg = string.format(self.data[19])
    -- local firstIdx = string.find(popImg,"_",1)
    -- local secondStr = string.sub(popImg,firstIdx+1,string.len(popImg))
    -- print("(COK2)secondStr:"..secondStr);
    loadLuaResource(self.rootPath .. "/resources/"..popImg..".plist")
    print("initWithCommon  (COK2)path:"..self.rootPath .. "/resources/"..popImg..".plist")

    local  proxy = cc.CCBProxy:create()
    GoldExchangeAdvLuaCell.onClickCostBtn = function()
        self:onClickCostBtn()
    end
    GoldExchangeAdvLuaCell.onPackageBtnClick = function()
        self:onPackageBtnClick()
    end

    local dic1 = CCDictionary:create()
    dic1:setObject(CCString:create("package"), "1")
    -- local newV2 = true;--CCCommonUtilsForLua:comFunc("isFunOpenByKey", dic1):getValue()
    local dict = CCDictionary:create()
    dict:setObject(CCString:create("2.17.0"),"1")
    local newV2 = CCCommonUtilsForLua:comFunc("checkVersion",dict):getValue()
    local dataCount = table.getn(self.data)
    if self.data[dataCount]=="m_isNewPicture" then
        newV2=false
    end

    local ccbiURL = strPath .. "/ccbi/LiBaoCommonAdvCell_NEW.ccbi"
    print ("adv ccb :" .. ccbiURL)

    local ccbnode = CCBReaderLoad(ccbiURL,proxy,GoldExchangeAdvLuaCell)
    local  layer = tolua.cast(ccbnode,"cc.Layer")
    ----print "if nil ~= GoldExchangeAdvLuaCell[m_timeLabel] then"
    if nil ~= GoldExchangeAdvLuaCell["m_timeLabel"] then
        self.m_timeLabel = tolua.cast(GoldExchangeAdvLuaCell["m_timeLabel"],"cc.Label")
    end
    ----print "GoldExchangeAdvLuaCell m_percentLabel"
    if nil ~= GoldExchangeAdvLuaCell["m_percentLabel"] then
        self.m_percentLabel = tolua.cast(GoldExchangeAdvLuaCell["m_percentLabel"],"cc.Label")
    end
    ----print "GoldExchangeAdvLuaCell m_moreLabel"
    if nil ~= GoldExchangeAdvLuaCell["m_moreLabel"] then
        self.m_moreLabel = tolua.cast(GoldExchangeAdvLuaCell["m_moreLabel"],"cc.Label")
    end
    ----print "GoldExchangeAdvLuaCell m_desLabel"
    if nil ~= GoldExchangeAdvLuaCell["m_desLabel"] then
        self.m_desLabel = tolua.cast(GoldExchangeAdvLuaCell["m_desLabel"],"cc.Label")
    end
    ----print "GoldExchangeAdvLuaCell m_getLabel"
    if nil ~= GoldExchangeAdvLuaCell["m_getLabel"] then
        self.m_getLabel = tolua.cast(GoldExchangeAdvLuaCell["m_getLabel"],"cc.Label")
        if nil ~= self.m_getLabel then
            --local getStr = string.format(LuaController:getLang1("115073",""))
            --self.m_getLabel:setString(getStr)
            self.m_getLabel:setVisible(false)
        end
    end
    ----print "if nil ~= GoldExchangeAdvLuaCell[m_newPriceLabel] then"
    if nil ~= GoldExchangeAdvLuaCell["m_newPriceLabel"] then
        --print "nil ~= GoldExchangeAdvLuaCell[m_newPriceLabel]"
        self.m_newPriceLabel = tolua.cast(GoldExchangeAdvLuaCell["m_newPriceLabel"],"cc.Label")
    end
    ----print "if nil ~= GoldExchangeAdvLuaCell[m_newPriceLabel] then"

    if nil ~= GoldExchangeAdvLuaCell["m_getGoldNumText"] then
        self.m_getGoldNumText = tolua.cast(GoldExchangeAdvLuaCell["m_getGoldNumText"],"cc.LabelBMFont")
    end
    ----print "if nil ~= GoldExchangeAdvLuaCell[m_costBtn] then"

    if nil ~= GoldExchangeAdvLuaCell["m_costBtn"] then
        self.m_costBtn = tolua.cast(GoldExchangeAdvLuaCell["m_costBtn"],"cc.ControlButton")
        if nil ~= self.m_costBtn then
            --LuaController:addButtonLight(self.m_costBtn)
        end
    end
    ----print "if nil ~= GoldExchangeAdvLuaCell[m_showMoneyNode] then"

    if nil ~= GoldExchangeAdvLuaCell["m_showMoneyNode"] then
        self.m_showMoneyNode = tolua.cast(GoldExchangeAdvLuaCell["m_showMoneyNode"],"cc.LayerColor")
    end
    if nil ~= self.m_showMoneyNode then
        if self.data[19] == "LiBao_FathersDay" then
            self.m_showMoneyNode:setPosition(0,55)
        elseif self.data[19] == "LiBao_year2" then
            self.m_showMoneyNode:setPosition(300,0)
        else
            self.m_showMoneyNode:setPosition(0,0)
        end
    end
    ----print "if nil ~= GoldExchangeAdvLuaCell[m_showMoreNode] then"
    
    if nil ~= GoldExchangeAdvLuaCell["m_showMoreNode"] then
        self.m_showMoreNode = tolua.cast(GoldExchangeAdvLuaCell["m_showMoreNode"],"cc.LayerColor")
        if nil ~= self.m_showMoreNode then
            --print ("show more node 111111")
            if self.m_showMoreNode:isVisible() == true then
                local function onTouchBegan(x, y)
                    --print "11"
                    if(nil ~= self.m_showMoreNode) then
                    --print "12"
                        if(nil ~= self.m_showMoreNode:getParent()) then
                    --print "13"
                            local pos = self.m_showMoreNode:getParent():convertToNodeSpace(CCPoint(x,y))
                    --print "14"
                            local rect = self.m_showMoreNode:getBoundingBox()
                    --print "15"
                            if(cc.rectContainsPoint(rect, pos) == true) then
                    --print "16"
                                self.startPos = cc.p(x, y)
                                return true
                            end 
                        end
                    end
                    return false
                end
                local function onTouchMoved(x, y)
                    --print "touch move"
                end
                local function onTouchEnded(x, y)
                    if(nil == self.m_showMoreNode) then
                        --print "touch node empty"
                        return
                    end

                    if self.m_showMoreNode:isVisible() == false then
                        --print "touch node hide"
                        return
                    end

                    if(nil == self.m_showMoreNode:getParent()) then
                        --print "touch node parent empty"
                        return
                    end

                    --print "local pos = self.m_showMoreNode:getParent():convertToNodeSpace(CCPoint(x,y))"
                    local pos0 = self.startPos
                    if nil == pos0 then
                        return
                    end
                    self.startPos = cc.p(0, 0)
                    local pos = self.m_showMoreNode:getParent():convertToNodeSpace(CCPoint(x,y))
                    --print "local pos = self.m_showMoreNode:getParent():convertToNodeSpace(CCPoint(x,y))"
                    local rect = self.m_showMoreNode:getBoundingBox()
                    if(cc.rectContainsPoint(rect, pos) == true) then
                        if cc.pGetDistance(pos0, cc.p(x, y)) < 10 then
                            local itemid = string.format(self.data[1])
                            -- LuaController:showDetailPopup(itemid)
                            local dic1 = CCDictionary:create()
                            dic1:setObject(CCString:create(tostring(itemid)), "1")
                            LuaController:comFunc("showDetailPopup", dic1)
                            --print "touch inside"
                            return
                        end
                    end
                    --print "touch outside"
                end

                local function onTouch(eventType, x, y)
                    --print (eventType)  
                    if eventType == "began" then
                        --print "return self:onTouchBegan(x, y)"  
                        return onTouchBegan(x, y)  
                    elseif eventType == "moved" then  
                        --print "return self:onTouchMoved(x, y) "
                        return onTouchMoved(x, y)  
                    else  
                        --print "return self:onTouchEnded(x, y) "
                        return onTouchEnded(x, y)  
                    end
                end
                ----print "self.m_showMoreNode:registerScriptTouchHandler(onTouch)"
                self.m_showMoreNode:registerScriptTouchHandler(onTouch)
                ----print "end self.m_showMoreNode:registerScriptTouchHandler(onTouch)"
                self.m_showMoreNode:setTouchEnabled(true)
                self.m_showMoreNode:setSwallowsTouches(false)
            end
        end
    end

    print "m_titleSpr========1"
    if nil ~= GoldExchangeAdvLuaCell["m_titleSpr"] then
        self.m_titleSpr = tolua.cast(GoldExchangeAdvLuaCell["m_titleSpr"],"cc.Sprite")
        if nil ~= self.m_titleSpr then
            -- sprite change image test code
            -- local frame = cc.SpriteFrameCache:getInstance():getSpriteFrame(popImg.."_adv_new.png");
            -- if nil ~= frame then
            --     print "m_titleSpr========2"
            --    self.m_titleSpr:setSpriteFrame(frame)
            -- end

                -- sprite change image test code
            if newV2 then
                local frame = cc.SpriteFrameCache:getInstance():getSpriteFrame(popImg.."_view_v4.jpg");
                dump("frame "..popImg.."_view_v4.jpg is: "..tostring(frame))
                if nil ~= frame then
                    self.m_titleSpr:setSpriteFrame(frame)
                else
                    frame = cc.SpriteFrameCache:getInstance():getSpriteFrame(popImg.."_view_v4.png");
                    dump("frame "..popImg.."_view_v4.png is: "..tostring(frame))
                    if nil ~= frame then
                        self.m_titleSpr:setSpriteFrame(frame)
                    end
                end

                if frame then
                    -- 再为空取默认图片
                    frame = cc.SpriteFrameCache:getInstance():getSpriteFrame("lbv4_morentu.png");
                end
                local offset = 10
                local height = self.m_titleSpr:getContentSize().height;
                self.m_titleSpr:setPositionY((height-246)/2-offset);
                ccbnode:setPosition(cc.p(12, offset))
                self.m_showMoreNode:setContentSize(self.m_titleSpr:getContentSize())
            else
                local frame = cc.SpriteFrameCache:getInstance():getSpriteFrame(popImg.."_adv_new.png");
                if nil ~= frame then
                    print "m_titleSpr========2"
                   self.m_titleSpr:setSpriteFrame(frame)
                end
            end
            print "m_titleSpr========3"
        end
    end
    print "m_titleSpr========4"
    ----print "if nil ~= GoldExchangeAdvLuaCell[m_packageBtn] then"
    if nil ~= GoldExchangeAdvLuaCell["m_packageBtn"] then
        ----print "~~~~1"
        self.m_packageBtn = tolua.cast(GoldExchangeAdvLuaCell["m_packageBtn"],"cc.ControlButton")
        ----print(GoldExchangeAdvLuaCell["m_packageBtn"])
        ----print "~~~~2"

        if nil ~= self.m_packageBtn then
        ----print "~~~~3"
        
            local showPackBtn = false
        ----print "~~~~4"
            if self.data[21] ~= nil then
        ----print "~~~~5"
                if self.data[21] == "1" then
        ----print "~~~~6"
                    showPackBtn = true
        ----print "~~~~7"
                end
        ----print "~~~~8"
            end
        ----print "~~~~9"
            if showPackBtn == true then
        ----print "~~~~10"
                self.m_packageBtn:setVisible(true)
        ----print "~~~~11"
            else
        ----print "~~~~12"
                self.m_packageBtn:setVisible(false)
        ----print "~~~~13"
        ----print "~~~~19"
            end
        ----print "~~~~20"
            --LuaController:addButtonLight(self.m_costBtn)
        end
    end
    if nil ~= GoldExchangeAdvLuaCell["m_lblDesc1"] then
        self.m_lblDesc1 = tolua.cast(GoldExchangeAdvLuaCell["m_lblDesc1"],"cc.Label")
    end

    if nil ~= GoldExchangeAdvLuaCell["m_timeNode"] then
        self.m_timeNode = tolua.cast(GoldExchangeAdvLuaCell["m_timeNode"],"cc.Node")
    end

    ----print "self:initView()"
    self:initView()
    ----print "after:initView()"
    local function scheduleBack()
    ----print "_____GoldExchangeAdvCell:scheduleBack"
        local dic2 = CCDictionary:create()
        if(nil ~= self.m_timeLabel) then
            -- local curTime = LuaController:getWorldTime()
            local curTime = LuaController:comFunc("getWorldTime", 0):getValue()
            local lastTime = 0
            local expTime = tonumber(self.data[14])
            
            local Dtime = 3600
            if self.data[28]~=nil and tostring(self.data[28])~="" and tonumber(self.data[28])~=nil and tonumber(self.data[28])>0 then
                expTime = tonumber(self.data[28])
                Dtime=60
            end
            -- print("Dtime:"..tostring(Dtime))
            local endTime = tonumber(self.data[13])
            if expTime>0 then
                local gapTime = endTime - curTime
                local count =  gapTime / (expTime * Dtime)
                count = math.floor(count)
                lastTime = endTime - (expTime*Dtime)*count-curTime;
            else
                lastTime = endTime - curTime
            end

            -- local endTime = tonumber(self.data[13])
            -- if expTime>0 then
            --     local gapTime = endTime - curTime
            --     local count =  gapTime / (expTime * 3600)
            --     count = math.floor(count)
            --     lastTime = endTime - (expTime*3600)*count-curTime;
            -- else
            --     lastTime = endTime - curTime
            -- end
            -- local timeStr = LuaController:getSECLang(lastTime)
            local dic1 = CCDictionary:create()
            dic1:setObject(CCInteger:create(tonumber(lastTime)), "1")
            local timeStr = LuaController:comFunc("getSECLang", dic1):getCString()
            local sss = string.format(timeStr)
            self.m_timeLabel:setString(sss)
            if (endTime - curTime <= 0 ) then
                self.m_costBtn:setEnabled(false)
                self:removeAllEvent()
                -- LuaController:removeAllPopup()
                LuaController:comFunc("removeAllPopup", 0)
            end 
        end
    end

    local function eventHandler( eventType )
            if eventType == "enter" then
                ----print " GoldExchangeAdvCell enter"
                scheduleBack()
                self.m_entryId = tonumber(ccbnode:getScheduler():scheduleScriptFunc(scheduleBack, 1, false))
            elseif eventType == "exit" then
                ----print "GoldExchangeAdvCell exit"
                if nil ~= self.m_entryId then
                    ccbnode:getScheduler():unscheduleScriptEntry(self.m_entryId)
                end
            elseif eventType == "cleanup" then
                ----print "GoldExchangeAdvCell cleanup"
                ccbnode:unregisterScriptHandler()
            end
    end
    ----print "ccbnode:registerScriptHandler(eventHandler)"
    ccbnode:registerScriptHandler(eventHandler)
    ----print "self.parentNode:addChild(ccbnode)"
    local ttt = tolua.cast(self.parentNode, "cc.Node")
    local ttt2 = tolua.cast(ccbnode, "cc.Node")
    ----print(ttt)
    ----print (ttt2)
    -- self.parentNode:addChild(ccbnode)
    self.parentNode:addChild(self)
    self:addChild(ccbnode)
    ----print "self:setContentSize(CCSize(540, 220))"
    self:setContentSize(CCSize(616, 246))
    ----print "ccbnode:setPositionY(-66)"
    -- ccbnode:setPositionY(-66)
    ----print "self.ccbNode = ccbnode"
    self.ccbNode = ccbnode
----print "12313"
    --[[local function onNodeEvent(event)
        if event == "enter" then
            ------print "gold_exchange_adv_cell_enter"
        elseif event == "exit" then
            ------print "gold_exchange_adv_cell_exit"
            self:removeAllEvent()
        end
    end
    self.ccbNode:registerScriptHandler(onNodeEvent)]]
end
------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------
function GoldExchangeAdvCell:initWithCommon_v3(parent,path,params)
    ----print "function GoldExchangeAdvCell:init(parent,path,params)"
    local dic1 = CCDictionary:create()
    local strPath = string.format(path)
    self.rootPath = strPath
    self.parentNode = parent
    
    self:initItems()
    self.startPos = cc.p(0, 0)

    loadLuaResource(self.rootPath .. "/resources/LiBaoCommonView.plist")
    print(" initWithCommon_v3  (COK2)path:"..self.rootPath .. "/resources/LiBaoCommonView.plist")
    local popImg = string.format(self.data[19])
    -- local firstIdx = string.find(popImg,"_",1)
    -- local secondStr = string.sub(popImg,firstIdx+1,string.len(popImg))
    -- print("(COK2)secondStr:"..secondStr);
    loadLuaResource(self.rootPath .. "/resources/"..popImg..".plist")
    print("initWithCommon_v3 (COK2)path:"..self.rootPath .. "/resources/"..popImg..".plist")

    local  proxy = cc.CCBProxy:create()
    GoldExchangeAdvLuaCell.onClickCostBtn = function()
        self:onClickCostBtn()
    end
    GoldExchangeAdvLuaCell.onPackageBtnClick = function()
        self:onPackageBtnClick()
    end
    local ccbiURL = strPath .. "/ccbi/LiBaoCommonAdvCell_v3.ccbi"
    print ("adv ccb :" .. ccbiURL)

    local ccbnode = CCBReaderLoad(ccbiURL,proxy,GoldExchangeAdvLuaCell)
    local  layer = tolua.cast(ccbnode,"cc.Layer")
    ----print "if nil ~= GoldExchangeAdvLuaCell[m_timeLabel] then"
    if nil ~= GoldExchangeAdvLuaCell["m_timeLabel"] then
        self.m_timeLabel = tolua.cast(GoldExchangeAdvLuaCell["m_timeLabel"],"cc.Label")
    end
    ----print "GoldExchangeAdvLuaCell m_percentLabel"
    if nil ~= GoldExchangeAdvLuaCell["m_percentLabel"] then
        self.m_percentLabel = tolua.cast(GoldExchangeAdvLuaCell["m_percentLabel"],"cc.LabelBMFont")
    end
    ----print "GoldExchangeAdvLuaCell m_percentBg"
    if nil ~= GoldExchangeAdvLuaCell["m_percentBg"] then
        self.m_percentBg = tolua.cast(GoldExchangeAdvLuaCell["m_percentBg"],"cc.Sprite")
    end
    --print "GoldExchangeAdvLuaCell m_desLabel"
    if nil ~= GoldExchangeAdvLuaCell["m_desLabel"] then
        self.m_desLabel = tolua.cast(GoldExchangeAdvLuaCell["m_desLabel"],"cc.Label")
    end
    ----print "GoldExchangeAdvLuaCell m_getLabel"
    if nil ~= GoldExchangeAdvLuaCell["m_getLabel"] then
        self.m_getLabel = tolua.cast(GoldExchangeAdvLuaCell["m_getLabel"],"cc.Label")
        if nil ~= self.m_getLabel then
            --local getStr = string.format(LuaController:getLang1("115073",""))
            --self.m_getLabel:setString(getStr)
            self.m_getLabel:setVisible(false)
        end
    end
    ----print "if nil ~= GoldExchangeAdvLuaCell[m_newPriceLabel] then"
    if nil ~= GoldExchangeAdvLuaCell["m_newPriceLabel"] then
        --print "nil ~= GoldExchangeAdvLuaCell[m_newPriceLabel]"
        self.m_newPriceLabel = tolua.cast(GoldExchangeAdvLuaCell["m_newPriceLabel"],"cc.Label")
    end
    ----print "if nil ~= GoldExchangeAdvLuaCell[m_newPriceLabel] then"

    if nil ~= GoldExchangeAdvLuaCell["m_getGoldNumText"] then
        self.m_getGoldNumText = tolua.cast(GoldExchangeAdvLuaCell["m_getGoldNumText"],"cc.LabelBMFont")
    end
    ----print "if nil ~= GoldExchangeAdvLuaCell[m_costBtn] then"

    if nil ~= GoldExchangeAdvLuaCell["m_costBtn"] then
        self.m_costBtn = tolua.cast(GoldExchangeAdvLuaCell["m_costBtn"],"cc.ControlButton")
        if nil ~= self.m_costBtn then
            --LuaController:addButtonLight(self.m_costBtn)
        end
    end
    ----print "if nil ~= GoldExchangeAdvLuaCell[m_showMoneyNode] then"
    
    if nil ~= GoldExchangeAdvLuaCell["m_showMoreNode"] then
        self.m_showMoreNode = tolua.cast(GoldExchangeAdvLuaCell["m_showMoreNode"],"cc.LayerColor")
        if nil ~= self.m_showMoreNode then
            --print ("show more node 111111")
            if self.m_showMoreNode:isVisible() == true then
                local function onTouchBegan(x, y)
                    --print "11"
                    if(nil ~= self.m_showMoreNode) then
                    --print "12"
                        if(nil ~= self.m_showMoreNode:getParent()) then
                    --print "13"
                            local pos = self.m_showMoreNode:getParent():convertToNodeSpace(CCPoint(x,y))
                    --print "14"
                            local rect = self.m_showMoreNode:getBoundingBox()
                    --print "15"
                            if(cc.rectContainsPoint(rect, pos) == true) then
                    --print "16"
                                self.startPos = cc.p(x, y)
                                return true
                            end 
                        end
                    end
                    return false
                end
                local function onTouchMoved(x, y)
                    --print "touch move"
                end
                local function onTouchEnded(x, y)
                    if(nil == self.m_showMoreNode) then
                        --print "touch node empty"
                        return
                    end

                    if self.m_showMoreNode:isVisible() == false then
                        --print "touch node hide"
                        return
                    end

                    if(nil == self.m_showMoreNode:getParent()) then
                        --print "touch node parent empty"
                        return
                    end

                    --print "local pos = self.m_showMoreNode:getParent():convertToNodeSpace(CCPoint(x,y))"
                    local pos0 = self.startPos
                    if nil == pos0 then
                        return
                    end
                    self.startPos = cc.p(0, 0)
                    local pos = self.m_showMoreNode:getParent():convertToNodeSpace(CCPoint(x,y))
                    --print "local pos = self.m_showMoreNode:getParent():convertToNodeSpace(CCPoint(x,y))"
                    local rect = self.m_showMoreNode:getBoundingBox()
                    if(cc.rectContainsPoint(rect, pos) == true) then
                        if cc.pGetDistance(pos0, cc.p(x, y)) < 10 then
                            local itemid = string.format(self.data[1])
                            -- LuaController:showDetailPopup(itemid)
                            local dic1 = CCDictionary:create()
                            dic1:setObject(CCString:create(tostring(itemid)), "1")
                            LuaController:comFunc("showDetailPopup", dic1)
                            --print "touch inside"
                            return
                        end
                    end
                    --print "touch outside"
                end

                local function onTouch(eventType, x, y)
                    --print (eventType)  
                    if eventType == "began" then
                        --print "return self:onTouchBegan(x, y)"  
                        return onTouchBegan(x, y)  
                    elseif eventType == "moved" then  
                        --print "return self:onTouchMoved(x, y) "
                        return onTouchMoved(x, y)  
                    else  
                        --print "return self:onTouchEnded(x, y) "
                        return onTouchEnded(x, y)  
                    end
                end
                ----print "self.m_showMoreNode:registerScriptTouchHandler(onTouch)"
                self.m_showMoreNode:registerScriptTouchHandler(onTouch)
                ----print "end self.m_showMoreNode:registerScriptTouchHandler(onTouch)"
                self.m_showMoreNode:setTouchEnabled(true)
                self.m_showMoreNode:setSwallowsTouches(false)
            end
        end
    end

    if nil ~= GoldExchangeAdvLuaCell["m_nameLabel"] then
        self.m_nameLabel = tolua.cast(GoldExchangeAdvLuaCell["m_nameLabel"],"cc.Label")
        if nil ~= self.m_nameLabel then
            -- local getStr = string.format(LuaController:getLang1("115073",""))
            local dic1 = CCDictionary:create()
            dic1:setObject(CCString:create(tostring(self.data[10])), "1")
            local getStr = LuaController:comFunc("getLang", dic1):getCString()
            self.m_nameLabel:setString(getStr)
        end
    end

    -- print("self.data[26]:"..tostring(self.data[26]))
    if self.data[26]~=nil and tonumber(self.data[26])==1 then--限购一次
        self.m_desLabel:setVisible(true)
    else
        -- print("self.data[26]:"..tostring(self.data[26]))
        self.m_desLabel:setVisible(false)
    end

    --替换顶部图片
    print "m_titleSpr========1"
    if nil ~= GoldExchangeAdvLuaCell["m_titleSpr"] then
        self.m_titleSpr = tolua.cast(GoldExchangeAdvLuaCell["m_titleSpr"],"cc.Sprite")
        if nil ~= self.m_titleSpr then-- 新版图片已_view_v3结尾
            local frame = cc.SpriteFrameCache:getInstance():getSpriteFrame(popImg.."_view_v3.jpg");-- 优先使用jpg
            if nil ~= frame then
                print "m_titleSpr========2"
                self.m_titleSpr:setSpriteFrame(frame)
            else
                frame = cc.SpriteFrameCache:getInstance():getSpriteFrame(popImg.."_view_v3.png");
                if nil ~= frame then
                    print "m_titleSpr========22"
                    self.m_titleSpr:setSpriteFrame(frame)
                else --老版礼包兼容
                    frame = cc.SpriteFrameCache:getInstance():getSpriteFrame(popImg.."_view.jpg");-- 优先使用jpg
                    if nil ~= frame then
                        print "m_titleSpr========222"
                        self.m_titleSpr:setSpriteFrame(frame)
                        self.m_titleSpr:setPositionY(270)
                    else
                        frame = cc.SpriteFrameCache:getInstance():getSpriteFrame(popImg.."_view.png");
                        if nil ~= frame then
                            print "m_titleSpr========2222"
                            self.m_titleSpr:setSpriteFrame(frame)
                            self.m_titleSpr:setPositionY(270)
                        else
                            print "m_titleSpr========22222"
                            -- frame = cc.SpriteFrameCache:getInstance():getSpriteFrame(popImg.."_view.png");
                        end
                    end
                end
            end
            print "m_titleSpr========3"
        end
    end
    print "m_titleSpr========4"
    if nil ~= GoldExchangeAdvLuaCell["m_bestSellerNode"] then
        self.m_bestSellerNode = tolua.cast(GoldExchangeAdvLuaCell["m_bestSellerNode"],"cc.Node")
    end
    if nil ~= self.m_bestSellerNode and self.data[25]~=nil then
        print("load resource ____ m_bestSellerNode,self.data[25]:"..self.data[25])
        if tostring(self.data[25])=="1" then
            self.m_bestSellerNode:setVisible(true)
        else
            self.m_bestSellerNode:setVisible(false)
        end
    end
    print("load resource ____ m_bestSellerNode")

    -- if nil ~= GoldExchangeAdvLuaCell["m_lblDesc1"] then
    --     self.m_lblDesc1 = tolua.cast(GoldExchangeAdvLuaCell["m_lblDesc1"],"cc.Label")
    -- end

    ----print "self:initView()"
    self:initView()
    ----print "after:initView()"
    if nil ~= self.m_getGoldNumText then
        local numKey = string.format(self.data[3]);
        if numKey~="" then
            local goldstr = ""
            -- local numStr = string.format(LuaController:getCMDLang(numKey))
            dic1:setObject(CCString:create(tostring(numKey)), "1")
            local numStr = LuaController:comFunc("getCMDLang", dic1):getCString()
            local strstr = goldstr .. numStr
            local sss = string.format(strstr)
            self.m_getGoldNumText:setString(sss)
        else
            self.m_getGoldNumText:setString("")
        end
    end
    self.m_rwdNode={}
    self.m_iconNode={}
    self.m_numLabel={}
    for i=1,3 do
        local m_rwdNode_name = "m_rwdNode"..tostring(i)
        if nil ~= GoldExchangeAdvLuaCell[tostring(m_rwdNode_name)] then
        self.m_rwdNode[i] = tolua.cast(GoldExchangeAdvLuaCell[tostring(m_rwdNode_name)],"cc.Node")
        end

        local m_iconNode_name = "m_iconNode"..tostring(i)
        if nil ~= GoldExchangeAdvLuaCell[tostring(m_iconNode_name)] then
        self.m_iconNode[i] = tolua.cast(GoldExchangeAdvLuaCell[tostring(m_iconNode_name)],"cc.Node")
        end

        local m_numLabel_name = "m_numLabel"..tostring(i)
        if nil ~= GoldExchangeAdvLuaCell[tostring(m_numLabel_name)] then
        self.m_numLabel[i] = tolua.cast(GoldExchangeAdvLuaCell[tostring(m_numLabel_name)],"cc.Label")
        end
    end
    if nil~= self.items then
        local tCount = table.getn(self.items)
        print ("table.getn(self.items):"..tCount)
        local dl = 0
        for i=1,3 do
            if i>tCount then 
                self.m_rwdNode[i]:setVisible(false)
            else
                local x = tCount-i+1
                print ("m_touchCellSpr[x]:"..x..",self.items[x][1]:"..self.items[x][1]..",self.items[x][2]:"..self.items[x][2])
                -- self.items[x]
                -- local dict1 = CCDictionary:create()
                -- dic1:setObject(CCInteger:create(tonumber(self.items[x][1])), "1")
                -- dic1:setObject(self.m_picNode, "1")
                -- CCCommonUtilsForLua:comFunc("getPropById", dict1)

                -- LuaController:addItemIcon(self.m_iconNode,self.data[1],self.m_nameLabel)
                local dic1 = CCDictionary:create()
                dic1:setObject(self.m_iconNode[i], "1")
                dic1:setObject(CCString:create(tostring(self.items[x][1])), "2")
                LuaController:comFunc("addItemIcon", dic1)
                self.m_iconNode[i]:setScale(1.8)
                self.m_numLabel[i]:setString(tostring(self.items[x][2]))
            end
        end
    end
    -- CCCommonUtilsForLua:createGoodsIcon(tonumber(self.m_itemId), self.m_picNode, cc.size(68,68))
    if nil ~= GoldExchangeAdvLuaCell["m_goldNode"] then
        self.m_goldNode = tolua.cast(GoldExchangeAdvLuaCell["m_goldNode"],"cc.Node")
    end
    if nil ~= self.m_goldNode then
        if string.format(self.data[3])~="" and string.format(self.data[3])~="0" then
            self.m_goldNode:setVisible(true)
            self.m_rwdNode[1]:setScale(1.0)
        else
            self.m_goldNode:setVisible(false)
            self.m_rwdNode[1]:setScale(1.5)
        end
    end
    print("m_goldNode-1")
    if nil ~= GoldExchangeAdvLuaCell["m_goldParNode"] then
        self.m_goldParNode = tolua.cast(GoldExchangeAdvLuaCell["m_goldParNode"],"cc.Node")
    end
    if nil ~= GoldExchangeAdvLuaCell["m_goldParNode1"] then
        self.m_goldParNode1 = tolua.cast(GoldExchangeAdvLuaCell["m_goldParNode1"],"cc.Node")
    end
    --slogan
    if nil ~= GoldExchangeAdvLuaCell["m_sloganTxt"] then
        self.m_sloganTxt = tolua.cast(GoldExchangeAdvLuaCell["m_sloganTxt"],"cc.Label")
    end
    if nil ~= GoldExchangeAdvLuaCell["m_sloganTxt"] then
        self.m_sloganTxt = tolua.cast(GoldExchangeAdvLuaCell["m_sloganTxt"],"cc.Label")
        if nil ~= self.m_sloganTxt then
            local lblGet1Str = ""
            if self.data[24]~=nil then
                -- lblGet1Str = string.format(LuaController:getLang(tostring(self.data[24])))
                local dic1 = CCDictionary:create()
                dic1:setObject(CCString:create(tostring(self.data[24])), "1")
                lblGet1Str = LuaController:comFunc("getLang", dic1):getCString()
            end
            print("m_sloganTxt-lblGet1Str:"..lblGet1Str)
            if string.len(lblGet1Str) > 0 then
                self.m_sloganTxt:setString(lblGet1Str)
            elseif nil~= self.items then
                local dic1 = CCDictionary:create()
                --金币
                local goldNum = "0"
                local numKey = string.format(self.data[3]);
                if numKey~="" then
                    -- local numStr = string.format(LuaController:getCMDLang(numKey))
                    local dic1 = CCDictionary:create()
                    dic1:setObject(CCString:create(tostring(numKey)), "1")
                    local numStr = LuaController:comFunc("getCMDLang", dic1):getCString()
                    goldNum = string.format(numStr)
                end
                print("self.m_sloganTxt:setString(upDesStr)_goldNum:"..tostring(goldNum))
                --物品折合金币
                local goodsPrice = 0
                local tCount = table.getn(self.items)
                for i=1,tCount do
                    print("tCount:"..tCount)
                    local itemId = tostring(self.items[i][1])
                    local itemCount = self.items[i][2]
                    print("self.m_sloganTxt:setString(upDesStr)_itemId:"..tostring(itemId)..",itemCount:"..itemCount)
                    -- local itemType = CCCommonUtilsForLua:getPropById(itemId,"type")
                    local dic1 = CCDictionary:create()
                    dic1:setObject(CCString:create(tostring(itemId)), "1")
                    dic1:setObject(CCString:create(tostring("price")), "2")
                    local itemPrice = CCCommonUtilsForLua:comFunc("getPropById", dic1):getCString()
                    if tostring(itemPrice)~="" then
                        print("itemPrice:"..itemPrice)
                        goodsPrice = goodsPrice + tonumber(itemPrice)*tonumber(itemCount)
                    end
                end
                print("self.m_sloganTxt:setString(upDesStr)_goodsPrice:"..tostring(goodsPrice))
                if tostring(goldNum)~="0" or tonumber(goodsPrice)>0 then
                    local dic2 = CCDictionary:create()
                    dic2:setObject(CCString:create(tostring(goodsPrice)), "1")
                    local goodsPriceStr = LuaController:comFunc("getCMDLang", dic2):getCString()
                    -- local upDesStr = string.format(LuaController:getLang1("101175","")) --101175=内含：
                    local dic1 = CCDictionary:create()
                    dic1:setObject(CCString:create(tostring("9000032")), "1")--9000032    内含{0}金币和价值{1}金币的超值奖励！
                    dic1:setObject(CCString:create(tostring(goldNum)), "2")                  
                    dic1:setObject(CCString:create(tostring(goodsPriceStr)), "3")
                    local upDesStr = LuaController:comFunc("getLang2", dic1):getCString()
                    self.m_sloganTxt:setString(upDesStr)
                end
            else
                if nil~= self.items then
                    local res1 = 0--SVIP点数
                    local res2 = 0--VIP点数
                    local res3 = 0--分钟加速
                    local res4 = 0--木头
                    local res5 = 0--秘银
                    local res6 = 0--铁矿
                    local res7 = 0--粮食
                    local res8 = 0--钢
                    local res9 = 0--领主经验

                    local tCount = table.getn(self.items)
                    for i=1,tCount do
                        local itemData = self.items[i]
                        local itemId = "2016"..tostring(self.items[i][1])
                        local itemCount = self.items[i][2]
                        -- local itemType = CCCommonUtilsForLua:getPropById(itemId,"type")
                        dic1:setObject(CCString:create(tostring(itemId)), "1")
                        dic1:setObject(CCString:create(tostring("type")), "2")
                        local itemType = CCCommonUtilsForLua:comFunc("getPropById", dic1):getCString()

                        print("itemId:"..itemId..",itemCount:"..itemCount..",itemType:"..itemType)


                        if tonumber(itemType)==4 then
                            --木头
                            -- local resCount = CCCommonUtilsForLua:getPropById(itemId,"int")
                            dic1:setObject(CCString:create(tostring(itemId)), "1")
                            dic1:setObject(CCString:create(tostring("int")), "2")
                            local resCount = CCCommonUtilsForLua:comFunc("getPropById", dic1):getCString()

                            res4 = tonumber(res4) + (tonumber(resCount)*tonumber(itemCount))
                        elseif tonumber(itemType)==5 then
                            --秘银
                            -- local resCount = CCCommonUtilsForLua:getPropById(itemId,"int")
                            dic1:setObject(CCString:create(tostring(itemId)), "1")
                            dic1:setObject(CCString:create(tostring("int")), "2")
                            local resCount = CCCommonUtilsForLua:comFunc("getPropById", dic1):getCString()

                            res5 = tonumber(res5) + (tonumber(resCount)*tonumber(itemCount))
                        elseif tonumber(itemType)==6 then
                            --铁矿
                            -- local resCount = CCCommonUtilsForLua:getPropById(itemId,"int")
                            dic1:setObject(CCString:create(tostring(itemId)), "1")
                            dic1:setObject(CCString:create(tostring("int")), "2")
                            local resCount = CCCommonUtilsForLua:comFunc("getPropById", dic1):getCString()

                            res6 = tonumber(res6) + (tonumber(resCount)*tonumber(itemCount))
                        elseif tonumber(itemType)==7 then
                            --粮食
                            -- local resCount = CCCommonUtilsForLua:getPropById(itemId,"int")
                            dic1:setObject(CCString:create(tostring(itemId)), "1")
                            dic1:setObject(CCString:create(tostring("int")), "2")
                            local resCount = CCCommonUtilsForLua:comFunc("getPropById", dic1):getCString()

                            res7 = tonumber(res7) + (tonumber(resCount)*tonumber(itemCount))
                        elseif tonumber(itemType)==3 then
                            --分钟加速
                            -- local resCount = CCCommonUtilsForLua:getPropById(itemId,"int")
                            dic1:setObject(CCString:create(tostring(itemId)), "1")
                            dic1:setObject(CCString:create(tostring("int")), "2")
                            local resCount = CCCommonUtilsForLua:comFunc("getPropById", dic1):getCString()

                            res3 = tonumber(res3) + (tonumber(resCount)*tonumber(itemCount))
                        end
                    end
                    res3 = res3/60
                    print("res3:"..res3..",res4:"..res4..",res5:"..res5..",res6:"..res6..",res7:"..res7)

                    local res_max1 = 0
                    local res_max2 = 0
                    local res_maxDialog1 = ""
                    local res_maxDialog2 = ""
                    if tonumber(res4)>=tonumber(res7) and tonumber(res4)>=(tonumber(res5)*24) and tonumber(res4)>=(tonumber(res6)*8) then
                        res_max1 = tonumber(res4)
                        res_maxDialog1 = "101176"--101176=木材{0}
                        if (tonumber(res5)*24)>=(tonumber(res6)*8) and (tonumber(res5)*24)>=tonumber(res7) then
                            res_max2 = tonumber(res5)
                            res_maxDialog2 = "101179"--101179=秘银{0}
                        elseif (tonumber(res6)*8)>=(tonumber(res5)*24) and (tonumber(res6)*8)>=tonumber(res7) then
                            res_max2 = tonumber(res6)
                            res_maxDialog2 = "101178"--101178=铁{0}
                        else
                            res_max2 = tonumber(res7)
                            res_maxDialog2 = "101177"--101177=粮食{0}
                        end
                    end
                    if (tonumber(res5)*24)>=tonumber(res7) and (tonumber(res5)*24)>=tonumber(res4) and (tonumber(res5)*24)>=(tonumber(res6)*8) then
                        res_max1 = tonumber(res5)
                        res_maxDialog1 = "101179"--101179=秘银{0}
                        if tonumber(res4)>=(tonumber(res6)*8) and tonumber(res4)>=tonumber(res7) then
                            res_max2 = tonumber(res4)
                            res_maxDialog2 = "101176"--101176=木材{0}
                        elseif (tonumber(res6)*8)>=tonumber(res4) and (tonumber(res6)*8)>=tonumber(res7) then
                            res_max2 = tonumber(res6)
                            res_maxDialog2 = "101178"--101178=铁{0}
                        else
                            res_max2 = tonumber(res7)
                            res_maxDialog2 = "101177"--101177=粮食{0}
                        end

                    end
                    if (tonumber(res6)*8)>=tonumber(res7) and (tonumber(res6)*8)>=(tonumber(res5)*24) and (tonumber(res6)*8)>=tonumber(res4) then
                        res_max1 = tonumber(res6)
                        res_maxDialog1 = "101178"--101178=铁{0}
                        if tonumber(res4)>=(tonumber(res5)*24) and tonumber(res4)>=tonumber(res7) then
                            res_max2 = tonumber(res4)
                            res_maxDialog2 = "101176"--101176=木材{0}
                        elseif (tonumber(res5)*24)>=tonumber(res4) and (tonumber(res5)*24)>=tonumber(res7) then
                            res_max2 = tonumber(res5)
                            res_maxDialog2 = "101179"--101179=秘银{0}
                        else
                            res_max2 = tonumber(res7)
                            res_maxDialog2 = "101177"--101177=粮食{0}
                        end
                    end
                    if tonumber(res7)>=tonumber(res4) and tonumber(res7)>=(tonumber(res5)*24) and tonumber(res7)>=(tonumber(res6)*8) then
                        res_max1 = tonumber(res7)
                        res_maxDialog1 = "101177"--101177=粮食{0}
                        if tonumber(res4)>=(tonumber(res6)*8) and tonumber(res4)>=(tonumber(res5)*24) then
                            res_max2 = tonumber(res4)
                            res_maxDialog2 = "101176"--101176=木材{0}
                        elseif (tonumber(res5)*24)>=tonumber(res4) and (tonumber(res5)*24)>=(tonumber(res6)*8) then
                            res_max2 = tonumber(res5)
                            res_maxDialog2 = "101179"--101179=秘银{0}
                        else
                            res_max2 = tonumber(res6)
                            res_maxDialog2 = "101178"--101178=铁{0}
                        end
                    end

                    if res_max1>0 or res_max2>0 or res3>0 then
                        local res_maxStr1 = ""
                        local res_maxStr2 = ""
                        local resStr3 = ""
                        if res_max1>1000000 then
                            res_maxStr1 = string.format("%.1f", res_max1/1000000).."M"
                        elseif res_max1>1000 then
                            res_maxStr1 = string.format("%.1f", res_max1/1000).."K"
                        else
                            res_maxStr1 = tostring(res_max1)
                        end
                        if res_max2>1000000 then
                            res_maxStr2 = string.format("%.1f", res_max2/1000000).."M"
                        elseif res_max2>1000 then
                            res_maxStr2 = string.format("%.1f", res_max2/1000).."K"
                        else
                            res_maxStr2 = tostring(res_max2)
                        end
                        if res3>1000000 then
                            resStr3 = string.format("%.1f", res3/1000000).."M"
                        elseif res3>1000 then
                            resStr3 = string.format("%.1f", res3/1000).."K"
                        else
                            resStr3 = string.format("%.1f", res3)--tostring(res3)
                        end
                        -- print("res_maxStr1:"..res_maxStr1..",res_maxStr2:"..res_maxStr2..",resStr3:"..resStr3)
                        -- res_maxStr1=string.format(LuaController:getLang1(tostring(res_maxDialog1),res_maxStr1))
                        dic1:setObject(CCString:create(tostring(res_maxDialog1)), "1")
                        dic1:setObject(CCString:create(tostring(res_maxStr1)), "2")
                        res_maxStr1 = LuaController:comFunc("getLang1", dic1):getCString()

                        -- res_maxStr2=string.format(LuaController:getLang1(tostring(res_maxDialog2),res_maxStr2)) 
                        dic1:setObject(CCString:create(tostring(res_maxDialog2)), "1")
                        dic1:setObject(CCString:create(tostring(res_maxStr2)), "2")
                        res_maxStr2 = LuaController:comFunc("getLang1", dic1):getCString()

                        -- resStr3=string.format(LuaController:getLang1("101180",resStr3)) --101180=加速共{0}小时
                        dic1:setObject(CCString:create(tostring("101180")), "1")
                        dic1:setObject(CCString:create(tostring(resStr3)), "2")
                        resStr3 = LuaController:comFunc("getLang1", dic1):getCString()

                        print("res_maxStr1:"..res_maxStr1..",res_maxStr2:"..res_maxStr2..",resStr3:"..resStr3)

                        -- local upDesStr = string.format(LuaController:getLang1("101175","")) --101175=内含：
                        dic1:setObject(CCString:create(tostring("101175")), "1")
                        dic1:setObject(CCString:create(tostring("")), "2")
                        local upDesStr = LuaController:comFunc("getLang1", dic1):getCString()

                        if res_max1>0 then
                            upDesStr = upDesStr..res_maxStr1..","
                        end
                        if res_max2>0 then
                            upDesStr = upDesStr..res_maxStr2..","
                        end
                        if res3>0 then
                            upDesStr = upDesStr..resStr3..","
                        end
                        local txtStr = string.sub(upDesStr,1,string.len(upDesStr)-1)
                        self.m_sloganTxt:setString(txtStr)
                    end
                end
            end
        end
    end

----------------------------------------------------------------------------显示资源----------------------------------------------------------------------------
    if nil~= self.items then
        local res1 = 0--SVIP点数
        local res2 = 0--VIP点数
        local res3 = 0--分钟加速
        local res4 = 0--木头
        local res5 = 0--秘银
        local res6 = 0--铁矿
        local res7 = 0--粮食
        local res8 = 0--钢
        local res9 = 0--领主经验

        local tCount = table.getn(self.items)
        for i=1,tCount do
            local itemData = self.items[i]
            local itemId = "2016"..tostring(self.items[i][1])
            local itemCount = self.items[i][2]
            -- local itemType = CCCommonUtilsForLua:getPropById(itemId,"type")
            dic1:setObject(CCString:create(tostring(itemId)), "1")
            dic1:setObject(CCString:create(tostring("type")), "2")
            local itemType = CCCommonUtilsForLua:comFunc("getPropById", dic1):getCString()
            print("itemId:"..itemId..",itemCount:"..itemCount..",itemType:"..itemType)
            if tonumber(itemType)==4 then
                --木头
                -- local resCount = CCCommonUtilsForLua:getPropById(itemId,"int")
                dic1:setObject(CCString:create(tostring(itemId)), "1")
                dic1:setObject(CCString:create(tostring("int")), "2")
                local resCount = CCCommonUtilsForLua:comFunc("getPropById", dic1):getCString()

                res4 = tonumber(res4) + (tonumber(resCount)*tonumber(itemCount))
            elseif tonumber(itemType)==5 then
                --秘银
                -- local resCount = CCCommonUtilsForLua:getPropById(itemId,"int")
                dic1:setObject(CCString:create(tostring(itemId)), "1")
                dic1:setObject(CCString:create(tostring("int")), "2")
                local resCount = CCCommonUtilsForLua:comFunc("getPropById", dic1):getCString()

                res5 = tonumber(res5) + (tonumber(resCount)*tonumber(itemCount))
            elseif tonumber(itemType)==6 then
                --铁矿
                -- local resCount = CCCommonUtilsForLua:getPropById(itemId,"int")
                dic1:setObject(CCString:create(tostring(itemId)), "1")
                dic1:setObject(CCString:create(tostring("int")), "2")
                local resCount = CCCommonUtilsForLua:comFunc("getPropById", dic1):getCString()

                res6 = tonumber(res6) + (tonumber(resCount)*tonumber(itemCount))
            elseif tonumber(itemType)==7 then
                --粮食
                -- local resCount = CCCommonUtilsForLua:getPropById(itemId,"int")
                dic1:setObject(CCString:create(tostring(itemId)), "1")
                dic1:setObject(CCString:create(tostring("int")), "2")
                local resCount = CCCommonUtilsForLua:comFunc("getPropById", dic1):getCString()

                res7 = tonumber(res7) + (tonumber(resCount)*tonumber(itemCount))
            elseif tonumber(itemType)==3 then
                --分钟加速
                -- local resCount = CCCommonUtilsForLua:getPropById(itemId,"int")
                dic1:setObject(CCString:create(tostring(itemId)), "1")
                dic1:setObject(CCString:create(tostring("int")), "2")
                local resCount = CCCommonUtilsForLua:comFunc("getPropById", dic1):getCString()

                res3 = tonumber(res3) + (tonumber(resCount)*tonumber(itemCount))
            end
        end
        res3 = res3/60
        print("res3:"..res3..",res4:"..res4..",res5:"..res5..",res6:"..res6..",res7:"..res7)

        if nil ~= GoldExchangeAdvLuaCell["m_showResNode"] then
            self.m_showResNode = tolua.cast(GoldExchangeAdvLuaCell["m_showResNode"],"cc.Node")
        end
        if nil ~= self.m_showResNode then
            if nil ~= GoldExchangeAdvLuaCell["m_showNode1"] then
                self.m_showNode1 = tolua.cast(GoldExchangeAdvLuaCell["m_showNode1"],"cc.Node")
            end
            if nil ~= GoldExchangeAdvLuaCell["m_showNode2"] then
                self.m_showNode2 = tolua.cast(GoldExchangeAdvLuaCell["m_showNode2"],"cc.Node")
            end
            if nil ~= GoldExchangeAdvLuaCell["m_showNode3"] then
                self.m_showNode3 = tolua.cast(GoldExchangeAdvLuaCell["m_showNode3"],"cc.Node")
            end
            if nil ~= GoldExchangeAdvLuaCell["m_showNode4"] then
                self.m_showNode4 = tolua.cast(GoldExchangeAdvLuaCell["m_showNode4"],"cc.Node")
            end
            if nil ~= GoldExchangeAdvLuaCell["m_showNode5"] then
                self.m_showNode5 = tolua.cast(GoldExchangeAdvLuaCell["m_showNode5"],"cc.Node")
            end
            local nilCount = 0
            if self.m_showNode1~=nil then--木头
                if tonumber(res4)>0  then
                    self.m_showNode1:setVisible(true)
                    if nil ~= GoldExchangeAdvLuaCell["m_showTxt1"] then
                        self.m_showTxt1 = tolua.cast(GoldExchangeAdvLuaCell["m_showTxt1"],"cc.Label")
                    end
                    local res_maxStr1 = ""
                    if res4>1000000 then
                        res_maxStr1 = string.format("%.1f", res4/1000000).."M"
                    elseif res4>1000 then
                        res_maxStr1 = string.format("%.1f", res4/1000).."K"
                    else
                        res_maxStr1 = tostring(res4)
                    end
                    self.m_showTxt1:setString(tostring(res_maxStr1))
                else
                    self.m_showNode1:setVisible(false)
                    nilCount = nilCount+1
                end
            end
            if self.m_showNode2~=nil then--粮食
                if tonumber(res7)>0  then
                    self.m_showNode2:setVisible(true)
                    self.m_showNode2:setPositionX(self.m_showNode2:getPositionX()-(125*nilCount))
                    if nil ~= GoldExchangeAdvLuaCell["m_showTxt2"] then
                        self.m_showTxt2 = tolua.cast(GoldExchangeAdvLuaCell["m_showTxt2"],"cc.Label")
                    end
                    local res_maxStr1 = ""
                    if res7>1000000 then
                        res_maxStr1 = string.format("%.1f", res7/1000000).."M"
                    elseif res7>1000 then
                        res_maxStr1 = string.format("%.1f", res7/1000).."K"
                    else
                        res_maxStr1 = tostring(res7)
                    end
                    self.m_showTxt2:setString(tostring(res_maxStr1))
                else
                    self.m_showNode2:setVisible(false)
                    nilCount = nilCount+1
                end
            end
            if self.m_showNode3~=nil then--铁矿
                if tonumber(res6)>0  then
                    self.m_showNode3:setVisible(true)
                    self.m_showNode3:setPositionX(self.m_showNode3:getPositionX()-(125*nilCount))
                    if nil ~= GoldExchangeAdvLuaCell["m_showTxt3"] then
                        self.m_showTxt3 = tolua.cast(GoldExchangeAdvLuaCell["m_showTxt3"],"cc.Label")
                    end
                    local res_maxStr1 = ""
                    if res6>1000000 then
                        res_maxStr1 = string.format("%.1f", res6/1000000).."M"
                    elseif res6>1000 then
                        res_maxStr1 = string.format("%.1f", res6/1000).."K"
                    else
                        res_maxStr1 = tostring(res6)
                    end
                    self.m_showTxt3:setString(tostring(res_maxStr1))
                else
                    self.m_showNode3:setVisible(false)
                    nilCount = nilCount+1
                end
            end
            if self.m_showNode4~=nil then--秘银
                if tonumber(res5)>0  then
                    self.m_showNode4:setVisible(true)
                    self.m_showNode4:setPositionX(self.m_showNode4:getPositionX()-(125*nilCount))
                    if nil ~= GoldExchangeAdvLuaCell["m_showTxt4"] then
                        self.m_showTxt4 = tolua.cast(GoldExchangeAdvLuaCell["m_showTxt4"],"cc.Label")
                    end
                    local res_maxStr1 = ""
                    if res5>1000000 then
                        res_maxStr1 = string.format("%.1f", res5/1000000).."M"
                    elseif res5>1000 then
                        res_maxStr1 = string.format("%.1f", res5/1000).."K"
                    else
                        res_maxStr1 = tostring(res5)
                    end
                    self.m_showTxt4:setString(tostring(res_maxStr1))
                else
                    self.m_showNode4:setVisible(false)
                    nilCount = nilCount+1
                end
            end
            if self.m_showNode5~=nil then--加速
                if tonumber(res3)>0  then
                    self.m_showNode5:setVisible(true)
                    self.m_showNode5:setPositionX(self.m_showNode5:getPositionX()-(125*nilCount))
                    if nil ~= GoldExchangeAdvLuaCell["m_showTxt5"] then
                        self.m_showTxt5 = tolua.cast(GoldExchangeAdvLuaCell["m_showTxt5"],"cc.Label")
                    end
                    local res_maxStr1 = ""
                    if res3>1000000 then
                        res_maxStr1 = string.format("%.1f", res3/1000000).."MH"
                    elseif res3>1000 then
                        res_maxStr1 = string.format("%.1f", res3/1000).."KH"
                    else
                        res_maxStr1 = string.format("%.1f", res3).."H"
                    end
                    self.m_showTxt5:setString(tostring(res_maxStr1))
                else
                    self.m_showNode5:setVisible(false)
                    nilCount = nilCount+1
                end
            end  

            self.m_showResNode:setPositionX(self.m_showResNode:getPositionX()+(45*nilCount))     
        end
    end
----------------------------------------------------------------------------显示资源----------------------------------------------------------------------------

    local function scheduleBack()
        ----print "_____GoldExchangeAdvCell:scheduleBack"
        local dic1 = CCDictionary:create()
        if(nil ~= self.m_timeLabel) then
            -- local curTime = LuaController:getWorldTime()
            local curTime = LuaController:comFunc("getWorldTime", 0):getValue()
            local lastTime = 0
            local expTime = tonumber(self.data[14])
            local Dtime = 3600
            if self.data[28]~=nil and tostring(self.data[28])~="" and tonumber(self.data[28])~=nil and tonumber(self.data[28])>0 then
                expTime = tonumber(self.data[28])
                Dtime=60
            end
            -- print("Dtime:"..tostring(Dtime))
            local endTime = tonumber(self.data[13])
            if expTime>0 then
                local gapTime = endTime - curTime
                local count =  gapTime / (expTime * Dtime)
                count = math.floor(count)
                lastTime = endTime - (expTime*Dtime)*count-curTime;
            else
                lastTime = endTime - curTime
            end
            -- local timeStr = LuaController:getSECLang(lastTime)
            dic1:setObject(CCInteger:create(tonumber(lastTime)), "1")
            local timeStr = LuaController:comFunc("getSECLang", dic1):getCString()
            local sss = string.format(timeStr)
            self.m_timeLabel:setString(sss)
            if (endTime - curTime <= 0 ) then
                self.m_costBtn:setEnabled(false)
                self:removeAllEvent()
                -- LuaController:removeAllPopup()
                LuaController:comFunc("removeAllPopup", 0)
            end 
        end
    end

    local function eventHandler( eventType )
            if eventType == "enter" then
                ----print " GoldExchangeAdvCell enter"
                scheduleBack()
                self.m_entryId = tonumber(ccbnode:getScheduler():scheduleScriptFunc(scheduleBack, 1, false))
                local function refreshCellByNotification_n1Local( ref )
                    self:showParticle()
                end
                local handler1 = self:registerHandler(refreshCellByNotification_n1Local)
                -- CCSafeNotificationCenter:sharedNotificationCenter():registerScriptObserver(self, handler1, "ActivityPlayerBack.send.cellRefreshNode1")
                local dic1 = CCDictionary:create()
                dic1:setObject(self, "1")
                dic1:setObject(CCInteger:create(tonumber(handler1)), "2")
                dic1:setObject(CCString:create(tostring("goldExchangeAdvCell.showParticle")), "3")
                CCSafeNotificationCenter:comFunc("registerScriptObserver", dic1)
            elseif eventType == "exit" then
                ----print "GoldExchangeAdvCell exit"
                if nil ~= self.m_entryId then
                    self.m_goldParNode1:removeAllChildren(true)
                    ccbnode:getScheduler():unscheduleScriptEntry(self.m_entryId)
                end
                -- CCSafeNotificationCenter:sharedNotificationCenter():unregisterScriptObserver(self, "ActivityPlayerBack.send.cellRefreshNode1")
                local dic1 = CCDictionary:create()
                dic1:setObject(self, "1")
                dic1:setObject(CCString:create(tostring("goldExchangeAdvCell.showParticle")), "2")
                CCSafeNotificationCenter:comFunc("unregisterScriptObserver", dic1)
            elseif eventType == "cleanup" then
                ----print "GoldExchangeAdvCell cleanup"
                ccbnode:unregisterScriptHandler()
            end
    end
    ----print "ccbnode:registerScriptHandler(eventHandler)"
    ccbnode:registerScriptHandler(eventHandler)
    ----print "self.parentNode:addChild(ccbnode)"
    local ttt = tolua.cast(self.parentNode, "cc.Node")
    local ttt2 = tolua.cast(ccbnode, "cc.Node")
    self.parentNode:addChild(self)
    self:addChild(ccbnode)
    self:setContentSize(CCSize(616, 246))
    self.ccbNode = ccbnode
end

function GoldExchangeAdvCell:showParticle()
    print "showParticle"
    if nil ~= self.m_goldNode and self.m_goldNode:isVisible() then
        if self.m_goldParNode~=nil then
            self.m_goldParNode:removeAllChildren(true)
            print("m_goldNode-2")
            local dic1 = CCDictionary:create()
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/NewGift_0")), "1")
            local particle0 = LuaController:comFunc("createParticleForLua", dic1)
            if nil ~= particle0 then
                particle0:setTag(0)
                self.m_goldParNode:addChild(particle0)
                -- particle0:setPosition(cc.p(size.width*0.5,0))
            end
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/NewGift_1")), "1")
            local particle1 = LuaController:comFunc("createParticleForLua", dic1)
            if nil ~= particle1 then
                self.m_goldParNode:addChild(particle1)
                -- particle1:setPosition(cc.p(size.width*0.5,0))
            end
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/NewGift_2")), "1")
            local particle2 = LuaController:comFunc("createParticleForLua", dic1)
            if nil ~= particle2 then
                self.m_goldParNode:addChild(particle2)
                -- particle2:setPosition(cc.p(size.width*0.5,0))
            end
        end
        if self.m_goldParNode1~=nil then
            self.m_goldParNode1:removeAllChildren(true)
            print("m_goldParNode1-1")
            local dic1 = CCDictionary:create()
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/NewGift_3")), "1")
            local particle3 = LuaController:comFunc("createParticleForLua", dic1)
            if nil ~= particle3 then
                print("m_goldParNode1-2")
                particle3:setTag(0)
                self.m_goldParNode1:addChild(particle3)
                -- particle3:setPosition(cc.p(100,100))
            end
            print("m_goldParNode1-3")
        end
        if nil ~= GoldExchangeAdvLuaCell["m_goldParNode2"] then
            self.m_goldParNode2 = tolua.cast(GoldExchangeAdvLuaCell["m_goldParNode2"],"cc.Node")
        end
    else
        print "showParticle-m_goldNode-isVisible-false"
    end
    
end
