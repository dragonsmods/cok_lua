require "GoldExchangeCellPlus"
require "GoldExchangeCell1Plus"
require "GoldExchangeCommonCellPlus"

GoldExchangeLuaView  = GoldExchangeLuaView or {}
ccb["GoldExchangeLuaView"] = GoldExchangeLuaView

GoldExchangeView = class("GoldExchangeView",
	function()
        return cc.Layer:create() 
	end
)
GoldExchangeView.__index = GoldExchangeView
function GoldExchangeView:create(parent,path,params)
	local node = self:init(parent,path,params)
    print(node)
    if node~=nil then
        parent:addChild(node)
        return node
    end
    return nil
end

function GoldExchangeView:setData(params)
        --print "GoldExchangeIcon:setData(params)"
    local paramsStr = string.format(params)
    ----print("params:" .. paramsStr)
    self.data = {}
    local index = 1
    local startI = 1
    local fIndex = string.find(paramsStr,",",startI)
    local tmpValue = "" 
    while (true) do
        tmpValue = string.sub(paramsStr,startI,fIndex-1)
        ----print("params" .. string.format(index) .. ":" .. tmpValue)
        self.data[index] = tmpValue
        index = index + 1
        startI = fIndex + 1
        fIndex = string.find(paramsStr,",",startI)
        if (fIndex == nil) then
            tmpValue = string.sub(paramsStr,startI,string.len(paramsStr))
            ----print("params" .. string.format(index) .. ":" .. tmpValue)
            self.data[index] = tmpValue
            break
        end
    end
end

function GoldExchangeView:init(parent,path,params)
    local dic1 = CCDictionary:create()
    self:setData(params)

    local popImg = string.format(self.data[19])
    print("(COK2-View)popImg___:" .. popImg)
    local firstIdx = string.find(popImg,"_",1)
    if (firstIdx ~= nil) then
        local firstStr = string.sub(popImg,1,firstIdx-1)
        print("(COK2-View)firstStr:" .. firstStr)
        if firstStr=="LiBao" then
            self.openType = 1
            print("(COK2-View)firstStr==LiBao" )
            local node = GoldExchangeView.new()
            node:initWithCommon(parent,path,params)
            return node
        end
    end
    return nil
end

function GoldExchangeView:closeTween()
    local dic1 = CCDictionary:create()
    if self.isRemove == true then
        return
    end
    self.isRemove = true
    --self:removeAllEvent()
    if nil ~= self.ccbNode then
        self.ccbNode:runAction(cc.ScaleTo:create(0.2, 0))
        self.parentNode:runAction(cc.Sequence:create(cc.DelayTime:create(0.2), cc.Hide:create()))
        local pPar = self.parentNode:getParent():getParent()
        if pPar ~= nil then
            for i=1,3 do
                --local particle1 = LuaController:createParticleForLua("particle/Collection_expF_" .. string.format(i))
                -- local particle2 = LuaController:createParticleForLua("particle/Collection_expF_" .. string.format(i))
                dic1:setObject(CCString:create(tostring("particle/Collection_expF_" .. tostring(i))), "1")
                local particle2 = LuaController:comFunc("createParticleForLua", dic1)
                if nil ~=  particle2 then
                    if (i==1) then
                        --particle1:setStartColor(ccc4f(1.0, 0.77, 0, 1.0))
                        --particle1:setEndColor(ccc4f(0, 0, 0, 0))
                        --particle1:setPositionType(kCCPositionTypeRelative)

                        particle2:setStartColor(cc.c4f(1.0, 0.77, 0, 1.0))
                        particle2:setEndColor(cc.c4f(0, 0, 0, 0))
                        particle2:setPositionType(1)
                    elseif (i==2) then
                        --particle1:setStartColor(ccc4f(1.0, 0.55, 0, 1.0))
                        --particle1:setEndColor(ccc4f(1, 0.96, 0.5, 0))
                        --particle1:setPositionType(kCCPositionTypeFree)

                        particle2:setStartColor(cc.c4f(1.0, 0.55, 0, 1.0))
                        particle2:setEndColor(cc.c4f(1, 0.96, 0.5, 0))
                        particle2:setPositionType(0)
                    else
                        --particle1:setStartColor(ccc4f(1.0, 0.9, 0, 1.0))
                        --particle1:setEndColor(ccc4f(0, 0, 0, 0))
                        --particle1:setPositionType(kCCPositionTypeRelative)

                        particle2:setStartColor(cc.c4f(1.0, 0.9, 0, 1.0))
                        particle2:setEndColor(cc.c4f(0, 0, 0, 0))
                        particle2:setPositionType(1)
                    end

                    local winSize = cc.Director:getInstance():getWinSize()
                    --particle1:setPosition(CCPoint(winSize.width*0.5,winSize.height*0.5))
                    --particle1:setTag(1000+i)
                    --pPar:addChild(particle1)

                    particle2:setPosition(CCPoint(winSize.width*0.5,winSize.height*0.5))
                    particle2:setTag(2000+i)
                    pPar:addChild(particle2)
                    --local act1 = CCMoveTo:create(0.5, CCPoint(winSize.width-70,winSize.height-155))
                    --local ease1 = CCEaseExponentialOut:create(act1)
                    --particle1:runAction(ease1)

                    local act2 = cc.MoveTo:create(0.5, CCPoint(winSize.width-40,winSize.height-35))
                    local ease2 = cc.EaseExponentialOut:create(act2)
                    particle2:runAction(ease2)
                end
            end
        end
        print "333"
        performWithDelay(self.m_touchNode,delayDealWithFunc({target = self}),0.5)
    end
end
function GoldExchangeView:onClickCostBtn()
    local itemid = string.format(self.data[1])
    -- LuaController:callPayment(itemid)
    local dic1 = CCDictionary:create()
    dic1:setObject(CCString:create(tostring(itemid)), "1")
    LuaController:comFunc("callPayment", dic1)
    if(self.isRemove == false ) then
        self:destroySelf()
    end
end
function GoldExchangeView:onCloseBtnClick()
   self:closeTween()
end
function GoldExchangeView:destroySelf()
    print "GoldExchangeView:destroySelf"
    --self:removeAllEvent()
    -- LuaController:removeAllPopup()
    LuaController:comFunc("removeAllPopup", 0)
    --loadCommonResource(7,false)
    --loadCommonResource(8,false)
    --if nil~= self.equips then
    --    loadCommonResource(308,false)
    --end
    --releaseLuaResource(self.rootPath .. "/resources/"..self.data[19])
end
function GoldExchangeView:onExit()
    ----print ("gold_exchange_view_exit")
    self:removeAllEvent()
    --if nil~= self.equips then
    --    loadCommonResource(308,false)
    --end
    releaseLuaResource(self.rootPath .. "/resources/"..self.data[19])
end
function GoldExchangeView:onPackageBtnClick()
    if nil ~= self.data[21] then
        if self.data[21] == "1" then
            if(self.isRemove == false ) then
                self:destroySelf()
            end
            local itemid = string.format(self.data[1])
            -- LuaController:toSelectUser(itemid,false,1)
            local dic1 = CCDictionary:create()
            dic1:setObject(CCString:create(tostring(itemid)), "1")
            dic1:setObject(CCBool:create(false), "2")
            dic1:setObject(CCInteger:create(1), "3")
            LuaController:comFunc("toSelectUser", dic1)
        end
    end
end
function GoldExchangeView:removeAllEvent()
    if self.parentNode ~= nil then
        local pPar = self.parentNode:getParent():getParent()
        ----print ("gold_exchange_view_exit_1")
        if nil ~= pPar then
            for i=1,3 do
                --if pPar:getChildByTag(1000+i) ~= nil then
                --    pPar:removeChildByTag(1000+i,true)
                --end
                ----print ("gold_exchange_view_exit_2")
                if pPar:getChildByTag(2000+i) ~= nil then
                    ----print ("gold_exchange_view_exit_3_" .. i)
                    pPar:removeChildByTag(2000+i,true)
                end
            end
        end
    end

    GoldExchangeLuaView.onClickCostBtn = nil
    GoldExchangeLuaView.onCloseBtnClick = nil
    GoldExchangeLuaView.onPackageBtnClick = nil
    if nil~= self.m_touchNode then
        self.m_touchNode:unregisterScriptTouchHandler()
    end
    if nil ~= self.m_costBtn then
        self.m_costBtn:setTouchEnabled(false)
    end
    if nil ~=self.m_timeLabel then
        self.m_timeLabel:stopAllActions()
    end
    if nil ~= self.ccbNode then
        self.ccbNode:unregisterScriptHandler()
    end
end
function GoldExchangeView:callbackFunc()
    print "GoldExchangeView:callbackFunc"
    if nil ~= self.data[22] then
        if self.data[22] == "bindGuide" then
            -- LuaController:showBindGuide();
            LuaController:comFunc("showBindGuide", 0)
        end
    end
    print(self.isRemove)
	if(self.isRemove == true) then
        self:destroySelf()
    end
end
function GoldExchangeView:scheduleBack()
    local dic1 = CCDictionary:create()
    ----print "_____scheduleBack"
    if nil == self.data[14] then
        return
    end
    ----print("load resource scheduleBack1")
    if nil ==  self.data[13] then
        return
    end

    if nil == self.m_costBtn then
        return
    end

    -- print("load resource scheduleBack2")
    if self.m_timeLabel ~= nil then
        -- local curTime = LuaController:getWorldTime()
        -- print "LuaController:comFunc(getWorldTime):getValue()"
        local curTime = LuaController:comFunc("getWorldTime", 0):getValue()
        local lastTime = 0
        local expTime = tonumber(self.data[14])
        -- print("tonumber(self.data[28]):"..tostring(tonumber(self.data[28])))
        local Dtime = 3600
        if self.data[28]~=nil and tostring(self.data[28])~="" and tonumber(self.data[28])~=nil and tonumber(self.data[28])>0 then
            expTime = tonumber(self.data[28])
            Dtime=60
        end
        -- print("Dtime:"..tostring(Dtime))
        local endTime = tonumber(self.data[13])
        if expTime>0 then
            local gapTime = endTime - curTime
            local count =  gapTime / (expTime * Dtime)
            count = math.floor(count)
            lastTime = endTime - (expTime*Dtime)*count-curTime;
        else
            lastTime = endTime - curTime
        end
        -- local timeStr = LuaController:getSECLang(lastTime)
        dic1:setObject(CCInteger:create(tonumber(lastTime)), "1")
        local timeStr = LuaController:comFunc("getSECLang", dic1):getCString()
        -- print ("timeStr:"..timeStr)
        self.m_timeLabel:setString(timeStr)
        if (endTime - curTime <= 0 ) then
            self.m_soleOutSpr:setVisible(false)
            self.m_costBtn:setEnabled(true)
            if(self.isRemove == false ) then
                self:destroySelf()
            end
        end 
    end
    ----print("load resource scheduleBack3")
end
function GoldExchangeView:onTouchBegan(x, y)
    print "touch began"
    self.touchX = x
    self.touchY = y

    if nil ~= self.m_listNode and self.popType~="1" then
        if(nil ~= self.m_listNode:getParent()) then
            local pos = self.m_listNode:getParent():convertToNodeSpace(CCPoint(x,y))
            local rect = self.m_listNode:getBoundingBox()
            if(cc.rectContainsPoint(rect, pos) == true) then
                print "self.m_listNode"
                self.touchMove = 0
                return true
            end 
        end
    end

    -- if nil ~= self.m_touchCellSpr then
    --     local tCount = table.getn(self.m_touchCellSpr)
    --     for i=1,tCount do
    --         local idx = tCount-i+1
    --         if nil ~= self.m_touchCellSpr[idx] then
    --             if nil ~= self.m_touchCellSpr[idx]:getParent() then
    --                 self.touchMove = 0
    --                 return true
    --             end
    --         end
    --     end
    -- end

    print "GoldExchangeView:onTouchBegan——touch began"
    if(self.isRemove==false) then
        if(nil ~= self.m_touchNode) then
            if(nil ~= self.m_touchNode:getParent()) then
                local pos = self.m_touchNode:getParent():convertToNodeSpace(CCPoint(x,y))
                local rect = self.m_touchNode:getBoundingBox()
                --print "1"
                if (cc.rectContainsPoint(rect, pos) == true) then
                    return false
                end
            end
        end
        if nil ~= self.m_costBtn then
            if(nil ~= self.m_costBtn:getParent()) then
                local pos = self.m_costBtn:getParent():convertToNodeSpace(CCPoint(x,y))
                local rect = self.m_costBtn:getBoundingBox()
                --print "2"
                if(cc.rectContainsPoint(rect, pos) == true) then
                    return false
                end 
            end
        end
        -- if nil ~= self.m_packageBtn then
        --     if(nil ~= self.m_packageBtn:getParent()) then
        --         local pos = self.m_packageBtn:getParent():convertToNodeSpace(CCPoint(x,y))
        --         local rect = self.m_packageBtn:getBoundingBox()
        --         --print "3"
        --         if(cc.rectContainsPoint(rect, pos) == true) then
        --             return false
        --         end 
        --     end
        -- end
    end
    return false
end
function GoldExchangeView:onTouchMoved(x, y)
	print "touch move"
    local dis = (tonumber(x)-self.touchX)*(tonumber(x)-self.touchX)+(tonumber(y)-self.touchY)*(tonumber(y)-self.touchY)
    -- print("dis:"..dis)
    if dis>200 then
        self.touchMove = 1
    end
end
function GoldExchangeView:onTouchEnded(x, y)
    print "touch end"
    local dic1 = CCDictionary:create()
    if nil ~= self.m_touchCellSpr then
        if tonumber(self.touchMove) == 0 then
            local tCount = table.getn(self.m_touchCellSpr)
            print("Ended___itCount :"..tCount)
            for i=1,tCount do
                local idx = tCount-i+1
                if nil ~= self.m_touchCellSpr[idx] then
                    -- print("Ended___in 1")
                    if nil ~= self.m_touchCellSpr[idx]:getParent() then
                        -- print("Ended___in 2")
                        local pos = self.m_touchCellSpr[idx]:getParent():convertToNodeSpace(cc.p(x,y))
                        local rect = self.m_touchCellSpr[idx]:getBoundingBox()
                        if cc.rectContainsPoint(rect,pos) == true then
                            print("Ended___in self.m_touchCellSpr-[idx]="..idx..",i:"..i)
                            local data = self.items[idx]
                            local itemId = tostring(data[1])
                            -- local strName =tostring(LuaController:getLang(tostring(CCCommonUtilsForLua:getPropById(itemId,"name"))))
                            dic1:setObject(CCString:create(tostring(itemId)), "1")
                            dic1:setObject(CCString:create(tostring("name")), "2")
                            local pStr1 = CCCommonUtilsForLua:comFunc("getPropById", dic1)

                            dic1 = CCDictionary:create()
                            dic1:setObject(CCString:create(tostring(itemId)), "1")
                            dic1:setObject(CCString:create(tostring("para")), "2")
                            local para = CCCommonUtilsForLua:comFunc("getPropById", dic1)
                            dic1 = CCDictionary:create()
                            dic1:setObject(pStr1, "1")
                            if para~=nil then
                                dic1:setObject(para, "2")
                            end
                            local strName = LuaController:comFunc("getLang1", dic1):getCString()

                            -- local strDes =tostring(LuaController:getLang(tostring(CCCommonUtilsForLua:getPropById(itemId,"description"))))
                            dic1:setObject(CCString:create(tostring(itemId)), "1")
                            dic1:setObject(CCString:create(tostring("description")), "2")
                            pStr1 = CCCommonUtilsForLua:comFunc("getPropById", dic1)
                            dic1:setObject(pStr1, "1")
                            local strDes = LuaController:comFunc("getLang", dic1):getCString()

                            print("Ended___in strName:"..strName..",strDes:"..strDes)
                            local strTip = strName.."\n"..strDes
                            -- CCCommonUtilsForLua:flyHint("", "", tostring(strTip))
                            dic1:setObject(CCString:create(tostring("")), "1")
                            dic1:setObject(CCString:create(tostring("")), "2")
                            dic1:setObject(CCString:create(tostring(strTip)), "3")
                            CCCommonUtilsForLua:comFunc("flyHint", dic1)

                            return
                        end
                    end
                end
            end
        end
        return
    end







    -- self:onCloseBtnClick()
end
function GoldExchangeView:initItems()
    self.items = nil
    if nil == self.data[7] then
        return
    end
    local itemsStr = string.format(self.data[7])
    if(itemsStr == "") then
        return
    end
    
    ----print(itemsStr)
    self.items = {}
    local itemIndex = 1
    local itemSIndex = 1
    local itemFIndex = string.find(itemsStr,"|",itemSIndex)
    
    if itemFIndex == nil then
        local itemValueTmp = string.sub(itemsStr,itemSIndex,string.len(itemsStr))
        local itemFindIndex =  string.find(itemValueTmp,";",1)
        local tabelValue1 = string.sub(itemValueTmp,1,itemFindIndex-1)
        local tabelVaule2 = string.sub(itemValueTmp,itemFindIndex+1,string.len(itemValueTmp))
        local iValue = {tabelValue1,tabelVaule2}
        self.items[itemIndex] = iValue;
        --print("items" .. string.format(itemIndex) .. ":" .. tabelValue1 .."," .. tabelVaule2)
        return
    end

    while(true) do
        local itemValueTmp = string.sub(itemsStr,itemSIndex,itemFIndex-1)
        local itemFindIndex =  string.find(itemValueTmp,";",1);
        local tabelValue1 = string.sub(itemValueTmp,1,itemFindIndex-1)
        local tabelVaule2 = string.sub(itemValueTmp,itemFindIndex+1,string.len(itemValueTmp))
        local iValue = {tabelValue1,tabelVaule2}
        self.items[itemIndex] = iValue;
        ----print("items" .. string.format(itemIndex) .. ":" .. tabelValue1 .."," .. tabelVaule2)
        itemIndex = itemIndex + 1
        itemSIndex =  itemFIndex + 1
        itemFIndex = string.find(itemsStr,"|",itemSIndex)
        if itemFIndex == nil then
            itemValueTmp = string.sub(itemsStr,itemSIndex,string.len(itemsStr))
            itemFindIndex =  string.find(itemValueTmp,";",1)
            tabelValue1 = string.sub(itemValueTmp,1,itemFindIndex-1)
            tabelVaule2 = string.sub(itemValueTmp,itemFindIndex+1,string.len(itemValueTmp))
            iValue = {tabelValue1,tabelVaule2}
            self.items[itemIndex] = iValue;
            ----print("items" .. string.format(itemIndex) .. ":" .. tabelValue1 .."," .. tabelVaule2)
            return
        end
    end
end
function GoldExchangeView:initEquips()
    self.equips = nil
    if nil == self.data[20] then
        return
    end
    local itemsStr = string.format(self.data[20])
    if(itemsStr == "") then
        return
    end
    
    self.equips = {}
    local itemIndex = 1
    local itemSIndex = 1
    local itemFIndex = string.find(itemsStr,"|",itemSIndex)
    if itemFIndex == nil then
        local itemValueTmp = string.sub(itemsStr,itemSIndex,string.len(itemsStr))
        local itemFindIndex =  string.find(itemValueTmp,";",1)
        local tabelValue1 = string.sub(itemValueTmp,1,itemFindIndex-1)
        local tabelVaule2 = string.sub(itemValueTmp,itemFindIndex+1,string.len(itemValueTmp))
        local iValue = {tabelValue1,tabelVaule2}
        self.equips[itemIndex] = iValue;
        --print("equips" .. string.format(itemIndex) .. ":" .. tabelValue1 .."," .. tabelVaule2)
        return
    end

    while(true) do
        local itemValueTmp = string.sub(itemsStr,itemSIndex,itemFIndex-1)
        local itemFindIndex =  string.find(itemValueTmp,";",1);
        local tabelValue1 = string.sub(itemValueTmp,1,itemFindIndex-1)
        local tabelVaule2 = string.sub(itemValueTmp,itemFindIndex+1,string.len(itemValueTmp))
        local iValue = {tabelValue1,tabelVaule2}
        self.equips[itemIndex] = iValue;
        ----print("equips" .. string.format(itemIndex) .. ":" .. tabelValue1 .."," .. tabelVaule2)
        itemIndex = itemIndex + 1
        itemSIndex =  itemFIndex + 1
        itemFIndex = string.find(itemsStr,"|",itemSIndex)
        if itemFIndex == nil then
            itemValueTmp = string.sub(itemsStr,itemSIndex,string.len(itemsStr))
            itemFindIndex =  string.find(itemValueTmp,";",1)
            tabelValue1 = string.sub(itemValueTmp,1,itemFindIndex-1)
            tabelVaule2 = string.sub(itemValueTmp,itemFindIndex+1,string.len(itemValueTmp))
            iValue = {tabelValue1,tabelVaule2}
            self.equips[itemIndex] = iValue;
            ----print("equips" .. string.format(itemIndex) .. ":" .. tabelValue1 .."," .. tabelVaule2)
            return
        end
    end
end

---------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------
function GoldExchangeView:initWithCommon(parent,path,params)
    local dic1 = CCDictionary:create()
    -- debug test 
    --local opStart = os.clock()
    local strPath = string.format(path)
    self.rootPath = strPath
    self.parentNode = parent
    self.isRemove =false
    self.effid1 = nil
    self.effid2 = nil
    self.effid3 = nil
    self.effid4 = nil
    self.effid5 = nil

    self.m_touchCellSpr = {}

    self:initItems()
    self:initEquips()
    ----print("init data ____" .. string.format(os.clock() - opStart))

    local popImg = string.format(self.data[19])

    self.popType="0"
    local dataCount = table.getn(self.data)
    if tostring(self.data[dataCount-1])=="popType" then
        self.popType=tostring(self.data[dataCount])
        print("self.popType:"..self.popType)
    end
    ----print("popImg___:" .. popImg)
    --init resource
    --opStart = os.clock()
    --loadCommonResource(7,true)
    --loadCommonResource(8,true)
    --if nil~=self.equips then
    --    loadCommonResource(308,true)
    --end
    --loadCommonResource(102,true)
    loadLuaResource(self.rootPath .. "/resources/"..popImg..".plist")
    loadLuaResource(self.rootPath .. "/resources/"..popImg.."_localize.plist")
    loadLuaResource(self.rootPath .. "/resources/LiBaoCommonView.plist")
    ----print("load resource ____" .. string.format(os.clock() - opStart))

    -- init ccbi
    --opStart = os.clock()
    local  proxy = cc.CCBProxy:create()
    GoldExchangeLuaView.onClickCostBtn = function()
        self:onClickCostBtn()
    end
    GoldExchangeLuaView.onCloseBtnClick = function()
        self:onCloseBtnClick()
    end
    GoldExchangeLuaView.onPackageBtnClick = function ()
        self:onPackageBtnClick()
    end
    -- dump(self.data,"===1111")
    GoldExchangeLuaView.onViewMoreBtnClick = function ()
        local itemid = string.format(self.data[1])
        print("GoldExchangeLuaView.onViewMoreBtnClick===itmeId:"..tostring(itemid))
        -- dump(self.data,"===2222")
        -- LuaController:showDetailPopup(itemid)
        local dic1 = CCDictionary:create()
        dic1:setObject(CCString:create(tostring(itemid)), "1")
        LuaController:comFunc("showDetailPopup", dic1)
    end
    local ccbiURL = strPath .. "/ccbi/LiBaoInnerCommonView.ccbi"
    -- local chechV = tostring(CCCommonUtilsForLua:getPropById("99020","k1"))
    -- if CCCommonUtilsForLua:checkVersion(chechV) == true then
    --     if CCCommonUtilsForLua:isFlip() then
    --         ccbiURL = self.rootPath .. "/ccbi/LiBaoInnerCommonView_flip.ccbi"
    --     end
    -- end
    dic1:setObject(CCString:create(tostring("99020")), "1")
    dic1:setObject(CCString:create(tostring("k1")), "2")
    local chechV = CCCommonUtilsForLua:comFunc("getPropById", dic1):getCString()
    -- if CCCommonUtilsForLua:checkVersion(chechV) == true then
    dic1:setObject(CCString:create(tostring(chechV)), "1")
    if CCCommonUtilsForLua:comFunc("checkVersion", dic1):getValue() == true then
        -- if CCCommonUtilsForLua:isFlip() then
        if CCCommonUtilsForLua:comFunc("isFlip", 0):getValue() == true then
            ccbiURL = self.rootPath .. "/ccbi/LiBaoInnerCommonView_flip.ccbi"
        end
    end
    local  node  = CCBReaderLoad(ccbiURL,proxy,GoldExchangeLuaView)
    --print "1"
    ----print("load ccbi data ____" .. string.format(os.clock() - opStart))
    --opStart = os.clock()

    local  layer = tolua.cast(node,"cc.Layer")
    if nil ~= GoldExchangeLuaView["m_timeLabel"] then
        self.m_timeLabel = tolua.cast(GoldExchangeLuaView["m_timeLabel"],"cc.Label")
        if nil ~= self.m_timeLabel then
            self.m_timeLabel:setString("m_timeLabel")
        end
    end
    if nil ~= GoldExchangeLuaView["m_titleLabel"] then
        self.m_titleLabel = tolua.cast(GoldExchangeLuaView["m_titleLabel"],"cc.Label")
        if nil ~= self.m_titleLabel then
            if nil ~= self.data[10] then
                local keyStr = string.format(self.data[10])
                ----print(keyStr)
                -- local titleStr = string.format(LuaController:getLang(keyStr))
                dic1:setObject(CCString:create(tostring(keyStr)), "1")
                local titleStr = LuaController:comFunc("getLang", dic1):getCString()
                ----print(titleStr)
                self.m_titleLabel:setString(titleStr)
            end
        end
    end
    print("load resource ____ m_titleLabel")
    if nil ~= GoldExchangeLuaView["m_titleNode"] then
        self.m_titleNode = tolua.cast(GoldExchangeLuaView["m_titleNode"],"cc.Node")
    end
    -- if nil ~= self.m_titleNode then
    --     if self.data[19] == "LiBao_DragonStone" then
    --         self.m_titleNode:setPosition(100,10)
    --     elseif self.data[19] == "LiBao_ChildrensDay" then
    --         self.m_titleNode:setPosition(80,0)
    --     elseif self.data[19] == "LiBao_FathersDay" then
    --         self.m_titleNode:setPosition(-25,0)
    --     end
    -- end
    print("load resource ____ m_titleNode")

    if nil ~= GoldExchangeLuaView["m_bestSaleNode"] then
        self.m_bestSaleNode = tolua.cast(GoldExchangeLuaView["m_bestSaleNode"],"cc.Node")
    end
    if nil ~= self.m_bestSaleNode and self.data[25]~=nil then
        print("load resource ____ m_bestSaleNode,self.data[25]:"..self.data[25])
        if tostring(self.data[25])=="1" then
            self.m_bestSaleNode:setVisible(true)
        else
            self.m_bestSaleNode:setVisible(false)
        end
    end
    print("load resource ____ m_bestSaleNode")
    local winSize = cc.Director:getInstance():getWinSize()

    if nil ~= GoldExchangeLuaView["m_timeTxtBg"] then
        self.m_timeTxtBg = tolua.cast(GoldExchangeLuaView["m_timeTxtBg"],"ccui.Scale9Sprite")
    end
    if nil ~= GoldExchangeLuaView["m_nameTxtBg"] then
        self.m_nameTxtBg = tolua.cast(GoldExchangeLuaView["m_nameTxtBg"],"ccui.Scale9Sprite")
    end
    if nil ~= self.m_titleLabel then
        self.m_titleLabel:setColor(cc.c3b(0, 230, 0))
    end
    if nil ~= self.m_timeTxtBg then
        -- self.m_timeTxtBg:setVisible(false)
    end
    if nil ~= self.m_nameTxtBg then
        -- self.m_nameTxtBg:setVisible(false)
    end
    
    if nil ~= GoldExchangeLuaView["m_percentLabel"] then
        self.m_percentLabel = tolua.cast(GoldExchangeLuaView["m_percentLabel"],"cc.LabelBMFont")
        if nil ~= self.m_percentLabel then
            local percentStr = tonumber(self.data[3])
            -- print("(COK2)self.data[19]:"..self.data[19]..";percentStr:"..percentStr)
            if tonumber(percentStr)>0 then
                self.m_percentLabel:setString(tostring(percentStr))
            else
                self.m_percentLabel:setString("")
            end
            -- if nil ~= self.data[27] and tostring(self.data[27])~="" then
            --     local percentStr = tonumber(self.data[27])
            --     -- print("(COK2)self.data[19]:"..self.data[19]..";percentStr:"..percentStr)
            --     if tonumber(percentStr)>0 then
            --         self.m_percentLabel:setString(tostring(percentStr))
            --     else
            --         self.m_percentLabel:setString("")
            --     end
            -- end
        end
    end
    print("load resource ____m_percentLabel")

    if nil ~= GoldExchangeLuaView["m_getGoldNumText"] then
        self.m_getGoldNumText = tolua.cast(GoldExchangeLuaView["m_getGoldNumText"],"cc.LabelBMFont")
        if nil ~= self.m_getGoldNumText then
            if nil ~= self.data[3] then
                local numKey = string.format(self.data[3]);
                ----print(numKey)
                -- local numStr = string.format(LuaController:getCMDLang(numKey))
                dic1:setObject(CCString:create(tostring(numKey)), "1")
                local numStr = LuaController:comFunc("getCMDLang", dic1):getCString()
                ----print(numStr)
                self.m_getGoldNumText:setString(numStr)
            end
        end
    end
    print("load resource ____ m_getGoldNumText")

    if nil ~= GoldExchangeLuaView["m_goldNumText"] then
        self.m_goldNumText = tolua.cast(GoldExchangeLuaView["m_goldNumText"],"cc.Label")
        if nil ~= self.m_goldNumText then
            -- if nil ~= self.data[27] and tostring(self.data[27])~="" then
                -- local percentStr = tonumber(self.data[3])-tonumber(self.data[27])
                -- print("(COK2)self.data[19]:"..self.data[19]..";percentStr:"..percentStr)
                -- if tonumber(percentStr)>0 then
                --     self.m_goldNumText:setString("+"..tostring(percentStr))
                -- else
                    self.m_goldNumText:setString("")
                -- end
            -- end
        end
    end
    print("load resource ____m_goldNumText")

    if nil ~= GoldExchangeLuaView["m_upDesLabel"] then
        self.m_upDesLabel = tolua.cast(GoldExchangeLuaView["m_upDesLabel"],"cc.Label")
        if nil ~= self.m_upDesLabel then
            local lblGet1Str = ""
            if self.data[24]~=nil then
                -- lblGet1Str = string.format(LuaController:getLang(tostring(self.data[24])))
                dic1:setObject(CCString:create(tostring(self.data[24])), "1")
                lblGet1Str = LuaController:comFunc("getLang", dic1):getCString()
            end
            print("m_upDesLabel-lblGet1Str:"..lblGet1Str)
            if string.len(lblGet1Str) > 0 then
                self.m_upDesLabel:setString(lblGet1Str)
            elseif nil~= self.items then
                local dic1 = CCDictionary:create()
                --金币
                local goldNum = "0"
                local numKey = string.format(self.data[3]);
                if numKey~="" then
                    -- local numStr = string.format(LuaController:getCMDLang(numKey))
                    local dic1 = CCDictionary:create()
                    dic1:setObject(CCString:create(tostring(numKey)), "1")
                    local numStr = LuaController:comFunc("getCMDLang", dic1):getCString()
                    goldNum = string.format(numStr)
                end
                -- print("self.m_upDesLabel:setString(upDesStr)_goldNum:"..tostring(goldNum))
                --物品折合金币
                local goodsPrice = 0
                local tCount = table.getn(self.items)
                for i=1,tCount do
                    print("tCount:"..tCount)
                    local itemId = tostring(self.items[i][1])
                    local itemCount = self.items[i][2]
                    -- print("self.m_upDesLabel:setString(upDesStr)_itemId:"..tostring(itemId)..",itemCount:"..itemCount)
                    -- local itemType = CCCommonUtilsForLua:getPropById(itemId,"type")
                    local dic1 = CCDictionary:create()
                    dic1:setObject(CCString:create(tostring(itemId)), "1")
                    dic1:setObject(CCString:create(tostring("price")), "2")
                    local itemPrice = CCCommonUtilsForLua:comFunc("getPropById", dic1):getCString()
                    if tostring(itemPrice)~="" then
                        print("itemPrice:"..itemPrice)
                        goodsPrice = goodsPrice + tonumber(itemPrice)*tonumber(itemCount)
                    end
                end
                -- print("self.m_upDesLabel:setString(upDesStr)_goodsPrice:"..tostring(goodsPrice))
                if tostring(goldNum)~="0" or tonumber(goodsPrice)>0 then
                    local dic2 = CCDictionary:create()
                    dic2:setObject(CCString:create(tostring(goodsPrice)), "1")
                    local goodsPriceStr = LuaController:comFunc("getCMDLang", dic2):getCString()
                    -- local upDesStr = string.format(LuaController:getLang1("101175","")) --101175=内含：
                    local dic1 = CCDictionary:create()
                    dic1:setObject(CCString:create(tostring("9000032")), "1")--9000032    内含{0}金币和价值{1}金币的超值奖励！
                    dic1:setObject(CCString:create(tostring(goldNum)), "2")                  
                    dic1:setObject(CCString:create(tostring(goodsPriceStr)), "3")
                    local upDesStr = LuaController:comFunc("getLang2", dic1):getCString()
                    self.m_upDesLabel:setString(upDesStr)
                end
            else
                if nil~= self.items then
                    local res1 = 0--SVIP点数
                    local res2 = 0--VIP点数
                    local res3 = 0--分钟加速
                    local res4 = 0--木头
                    local res5 = 0--秘银
                    local res6 = 0--铁矿
                    local res7 = 0--粮食
                    local res8 = 0--钢
                    local res9 = 0--领主经验

                    local tCount = table.getn(self.items)
                    for i=1,tCount do
                        local itemData = self.items[i]
                        local itemId = "2016"..tostring(self.items[i][1])
                        local itemCount = self.items[i][2]
                        -- local itemType = CCCommonUtilsForLua:getPropById(itemId,"type")
                        dic1:setObject(CCString:create(tostring(itemId)), "1")
                        dic1:setObject(CCString:create(tostring("type")), "2")
                        local itemType = CCCommonUtilsForLua:comFunc("getPropById", dic1):getCString()

                        -- print("itemId:"..itemId..",itemCount:"..itemCount..",itemType:"..itemType)


                        if tonumber(itemType)==4 then
                            --木头
                            -- local resCount = CCCommonUtilsForLua:getPropById(itemId,"int")
                            dic1:setObject(CCString:create(tostring(itemId)), "1")
                            dic1:setObject(CCString:create(tostring("int")), "2")
                            local resCount = CCCommonUtilsForLua:comFunc("getPropById", dic1):getCString()

                            res4 = tonumber(res4) + (tonumber(resCount)*tonumber(itemCount))
                        elseif tonumber(itemType)==5 then
                            --秘银
                            -- local resCount = CCCommonUtilsForLua:getPropById(itemId,"int")
                            dic1:setObject(CCString:create(tostring(itemId)), "1")
                            dic1:setObject(CCString:create(tostring("int")), "2")
                            local resCount = CCCommonUtilsForLua:comFunc("getPropById", dic1):getCString()

                            res5 = tonumber(res5) + (tonumber(resCount)*tonumber(itemCount))
                        elseif tonumber(itemType)==6 then
                            --铁矿
                            -- local resCount = CCCommonUtilsForLua:getPropById(itemId,"int")
                            dic1:setObject(CCString:create(tostring(itemId)), "1")
                            dic1:setObject(CCString:create(tostring("int")), "2")
                            local resCount = CCCommonUtilsForLua:comFunc("getPropById", dic1):getCString()

                            res6 = tonumber(res6) + (tonumber(resCount)*tonumber(itemCount))
                        elseif tonumber(itemType)==7 then
                            --粮食
                            -- local resCount = CCCommonUtilsForLua:getPropById(itemId,"int")
                            dic1:setObject(CCString:create(tostring(itemId)), "1")
                            dic1:setObject(CCString:create(tostring("int")), "2")
                            local resCount = CCCommonUtilsForLua:comFunc("getPropById", dic1):getCString()

                            res7 = tonumber(res7) + (tonumber(resCount)*tonumber(itemCount))
                        elseif tonumber(itemType)==3 then
                            --分钟加速
                            -- local resCount = CCCommonUtilsForLua:getPropById(itemId,"int")
                            dic1:setObject(CCString:create(tostring(itemId)), "1")
                            dic1:setObject(CCString:create(tostring("int")), "2")
                            local resCount = CCCommonUtilsForLua:comFunc("getPropById", dic1):getCString()

                            res3 = tonumber(res3) + (tonumber(resCount)*tonumber(itemCount))
                        end
                    end
                    res3 = res3/60
                    -- print("res3:"..res3..",res4:"..res4..",res5:"..res5..",res6:"..res6..",res7:"..res7)

                    local res_max1 = 0
                    local res_max2 = 0
                    local res_maxDialog1 = ""
                    local res_maxDialog2 = ""
                    if tonumber(res4)>=tonumber(res7) and tonumber(res4)>=(tonumber(res5)*24) and tonumber(res4)>=(tonumber(res6)*8) then
                        res_max1 = tonumber(res4)
                        res_maxDialog1 = "101176"--101176=木材{0}
                        if (tonumber(res5)*24)>=(tonumber(res6)*8) and (tonumber(res5)*24)>=tonumber(res7) then
                            res_max2 = tonumber(res5)
                            res_maxDialog2 = "101179"--101179=秘银{0}
                        elseif (tonumber(res6)*8)>=(tonumber(res5)*24) and (tonumber(res6)*8)>=tonumber(res7) then
                            res_max2 = tonumber(res6)
                            res_maxDialog2 = "101178"--101178=铁{0}
                        else
                            res_max2 = tonumber(res7)
                            res_maxDialog2 = "101177"--101177=粮食{0}
                        end
                    end
                    if (tonumber(res5)*24)>=tonumber(res7) and (tonumber(res5)*24)>=tonumber(res4) and (tonumber(res5)*24)>=(tonumber(res6)*8) then
                        res_max1 = tonumber(res5)
                        res_maxDialog1 = "101179"--101179=秘银{0}
                        if tonumber(res4)>=(tonumber(res6)*8) and tonumber(res4)>=tonumber(res7) then
                            res_max2 = tonumber(res4)
                            res_maxDialog2 = "101176"--101176=木材{0}
                        elseif (tonumber(res6)*8)>=tonumber(res4) and (tonumber(res6)*8)>=tonumber(res7) then
                            res_max2 = tonumber(res6)
                            res_maxDialog2 = "101178"--101178=铁{0}
                        else
                            res_max2 = tonumber(res7)
                            res_maxDialog2 = "101177"--101177=粮食{0}
                        end

                    end
                    if (tonumber(res6)*8)>=tonumber(res7) and (tonumber(res6)*8)>=(tonumber(res5)*24) and (tonumber(res6)*8)>=tonumber(res4) then
                        res_max1 = tonumber(res6)
                        res_maxDialog1 = "101178"--101178=铁{0}
                        if tonumber(res4)>=(tonumber(res5)*24) and tonumber(res4)>=tonumber(res7) then
                            res_max2 = tonumber(res4)
                            res_maxDialog2 = "101176"--101176=木材{0}
                        elseif (tonumber(res5)*24)>=tonumber(res4) and (tonumber(res5)*24)>=tonumber(res7) then
                            res_max2 = tonumber(res5)
                            res_maxDialog2 = "101179"--101179=秘银{0}
                        else
                            res_max2 = tonumber(res7)
                            res_maxDialog2 = "101177"--101177=粮食{0}
                        end
                    end
                    if tonumber(res7)>=tonumber(res4) and tonumber(res7)>=(tonumber(res5)*24) and tonumber(res7)>=(tonumber(res6)*8) then
                        res_max1 = tonumber(res7)
                        res_maxDialog1 = "101177"--101177=粮食{0}
                        if tonumber(res4)>=(tonumber(res6)*8) and tonumber(res4)>=(tonumber(res5)*24) then
                            res_max2 = tonumber(res4)
                            res_maxDialog2 = "101176"--101176=木材{0}
                        elseif (tonumber(res5)*24)>=tonumber(res4) and (tonumber(res5)*24)>=(tonumber(res6)*8) then
                            res_max2 = tonumber(res5)
                            res_maxDialog2 = "101179"--101179=秘银{0}
                        else
                            res_max2 = tonumber(res6)
                            res_maxDialog2 = "101178"--101178=铁{0}
                        end
                    end

                    if res_max1>0 or res_max2>0 or res3>0 then
                        local res_maxStr1 = ""
                        local res_maxStr2 = ""
                        local resStr3 = ""
                        if res_max1>1000000 then
                            res_maxStr1 = string.format("%.1f", res_max1/1000000).."M"
                        elseif res_max1>1000 then
                            res_maxStr1 = string.format("%.1f", res_max1/1000).."K"
                        else
                            res_maxStr1 = tostring(res_max1)
                        end
                        if res_max2>1000000 then
                            res_maxStr2 = string.format("%.1f", res_max2/1000000).."M"
                        elseif res_max2>1000 then
                            res_maxStr2 = string.format("%.1f", res_max2/1000).."K"
                        else
                            res_maxStr2 = tostring(res_max2)
                        end
                        if res3>1000000 then
                            resStr3 = string.format("%.1f", res3/1000000).."M"
                        elseif res3>1000 then
                            resStr3 = string.format("%.1f", res3/1000).."K"
                        else
                            resStr3 = string.format("%.1f", res3)--tostring(res3)
                        end
                        -- print("res_maxStr1:"..res_maxStr1..",res_maxStr2:"..res_maxStr2..",resStr3:"..resStr3)
                        -- res_maxStr1=string.format(LuaController:getLang1(tostring(res_maxDialog1),res_maxStr1))
                        dic1:setObject(CCString:create(tostring(res_maxDialog1)), "1")
                        dic1:setObject(CCString:create(tostring(res_maxStr1)), "2")
                        res_maxStr1 = LuaController:comFunc("getLang1", dic1):getCString()

                        -- res_maxStr2=string.format(LuaController:getLang1(tostring(res_maxDialog2),res_maxStr2)) 
                        dic1:setObject(CCString:create(tostring(res_maxDialog2)), "1")
                        dic1:setObject(CCString:create(tostring(res_maxStr2)), "2")
                        res_maxStr2 = LuaController:comFunc("getLang1", dic1):getCString()

                        -- resStr3=string.format(LuaController:getLang1("101180",resStr3)) --101180=加速共{0}小时
                        dic1:setObject(CCString:create(tostring("101180")), "1")
                        dic1:setObject(CCString:create(tostring(resStr3)), "2")
                        resStr3 = LuaController:comFunc("getLang1", dic1):getCString()

                        print("res_maxStr1:"..res_maxStr1..",res_maxStr2:"..res_maxStr2..",resStr3:"..resStr3)

                        -- local upDesStr = string.format(LuaController:getLang1("101175","")) --101175=内含：
                        dic1:setObject(CCString:create(tostring("101175")), "1")
                        dic1:setObject(CCString:create(tostring("")), "2")
                        local upDesStr = LuaController:comFunc("getLang1", dic1):getCString()

                        if res_max1>0 then
                            upDesStr = upDesStr..res_maxStr1..","
                        end
                        if res_max2>0 then
                            upDesStr = upDesStr..res_maxStr2..","
                        end
                        if res3>0 then
                            upDesStr = upDesStr..resStr3..","
                        end
                        local txtStr = string.sub(upDesStr,1,string.len(upDesStr)-1)
                        self.m_upDesLabel:setString(txtStr)
                    end
                end
            end
        end
    end
    if nil ~= self.m_upDesLabel then
        if self.data[19] == "LiBao_FathersDay" then
            self.m_upDesLabel:setColor(cc.c3b(255, 0, 255))
        end
    end
    
    print("load resource ____ m_upDesLabel")

    if nil ~= GoldExchangeLuaView["m_getLabel1"] then
        self.m_getLabel1 = tolua.cast(GoldExchangeLuaView["m_getLabel1"],"cc.Label")
        if nil ~= self.m_getLabel1 then
            -- local lblGet1Str = string.format(LuaController:getLang1("101237",""))
            dic1:setObject(CCString:create(tostring("101237")), "1")
            dic1:setObject(CCString:create(tostring("")), "2")
            local lblGet1Str = LuaController:comFunc("getLang1", dic1):getCString()
            ----print(lblGet1Str)
            self.m_getLabel1:setString(lblGet1Str)
        end
    end
    print("load resource ____m_getLabel1")

    if nil ~= GoldExchangeLuaView["m_getLabel"] then
        self.m_getLabel = tolua.cast(GoldExchangeLuaView["m_getLabel"],"cc.Label")
        if nil ~= self.m_getLabel then
            -- local lblGetStr = string.format(LuaController:getLang1("115073",""))
            dic1:setObject(CCString:create(tostring("115073")), "1")
            dic1:setObject(CCString:create(tostring("")), "2")
            local lblGetStr = LuaController:comFunc("getLang1", dic1):getCString()
            ----print(lblGetStr)
            self.m_getLabel:setString(lblGetStr)
        end
    end
    --print("load resource ____m_getLabel")

    if nil ~= GoldExchangeLuaView["m_newPriceLabel"] then
        self.m_newPriceLabel = tolua.cast(GoldExchangeLuaView["m_newPriceLabel"],"cc.Label")
        if nil ~= self.m_newPriceLabel then
            if nil ~= self.data[4] then
                if nil ~=  self.data[11] then
                    local dollar = string.format(self.data[4])
                    ----print(dollar)
                    local pID = string.format(self.data[11])
                    ----print(pID)
                    -- local newPrice = string.format(LuaController:getDollarString(dollar,pID))
                    dic1:setObject(CCString:create(tostring(dollar)), "1")
                    dic1:setObject(CCString:create(tostring(pID)), "2")
                    local newPrice = LuaController:comFunc("getDollarString", dic1):getCString()

                    ----print(newPrice)
                    self.m_newPriceLabel:setString(newPrice)
                end
            end
        end
    end
    --print("load resource ____m_newPriceLabel")
    if nil ~= GoldExchangeLuaView["m_oldPriceLabel"] then
        self.m_oldPriceLabel = tolua.cast(GoldExchangeLuaView["m_oldPriceLabel"],"cc.Label")
        if nil ~= self.m_oldPriceLabel then
            if nil ~= self.data[9] then
                local dollar1 = string.format(self.data[9])
                ----print(dollar1)
                -- local oldPrice = string.format(LuaController:getDollarString(dollar1,""))
                dic1:setObject(CCString:create(tostring(dollar1)), "1")
                dic1:setObject(CCString:create(tostring("")), "2")
                local oldPrice = LuaController:comFunc("getDollarString", dic1):getCString()
                ----print(oldPrice)
                self.m_oldPriceLabel:setString(oldPrice)
            end
        end
    end
    --print("load resource ____m_oldPriceLabel")
    if nil ~= GoldExchangeLuaView["m_lblDes"] then
        self.m_lblDes = tolua.cast(GoldExchangeLuaView["m_lblDes"],"cc.Label")
        if nil ~= self.m_lblDes then
            local desString1 = nil
            --101379=购买后，所有联盟成员会获得一份联盟礼物！
            if self.data[19] == "alliance" then
                -- desString1 = string.format(LuaController:getLang("101379"))
                dic1:setObject(CCString:create(tostring("101379")), "1")
                desString1 = LuaController:comFunc("getLang", dic1):getCString()
            end
            if self.data[19] == "alliance1" then
                -- desString1 = string.format(LuaController:getLang("101379"))
                dic1:setObject(CCString:create(tostring("101379")), "1")
                desString1 = LuaController:comFunc("getLang", dic1):getCString()
            end
            -- if self.data[19] == "last_sale" then
            --     desString1 = string.format(LuaController:getLang("101379"))
            -- end
            if self.data[19] == "new_year" then
                -- desString1 = string.format(LuaController:getLang("101379"))
                dic1:setObject(CCString:create(tostring("101379")), "1")
                desString1 = LuaController:comFunc("getLang", dic1):getCString()
            end
            if self.data[19] == "build_alliance" then
                -- desString1 = string.format(LuaController:getLang("101379"))
                dic1:setObject(CCString:create(tostring("101379")), "1")
                desString1 = LuaController:comFunc("getLang", dic1):getCString()
            end
            if nil ~= desString1 then
                self.m_lblDes:setString(desString1)
            end

        end
    end
    --print("load resource ____m_lblDes")
    if nil ~= GoldExchangeLuaView["m_sloganLabel"] then
        self.m_sloganLabel = tolua.cast(GoldExchangeLuaView["m_sloganLabel"],"cc.Label")
        if nil ~= self.m_sloganLabel then
            local sloganString = nil
            if self.data[19] == "chinese_newyeargoogle" then
                -- sloganString = string.format(LuaController:getLang("9100001"))--9100001
                dic1:setObject(CCString:create(tostring("9100001")), "1")
                sloganString = LuaController:comFunc("getLang", dic1):getCString()
            end
            if self.data[19] == "dragon" then
                -- sloganString = string.format(LuaController:getLang("9100003"))--9100001
                dic1:setObject(CCString:create(tostring("9100003")), "1")
                sloganString = LuaController:comFunc("getLang", dic1):getCString()
            end
            if self.data[19] == "Spring_Festival" then
                -- sloganString = string.format(LuaController:getLang("9100001"))--9100001
                dic1:setObject(CCString:create(tostring("9100001")), "1")
                sloganString = LuaController:comFunc("getLang", dic1):getCString()
            end
            if self.data[19] == "Valentines_Day" then
                -- sloganString = string.format(LuaController:getLang("9100002"))--9100001
                dic1:setObject(CCString:create(tostring("9100002")), "1")
                sloganString = LuaController:comFunc("getLang", dic1):getCString()
            end
            if nil ~= sloganString then
                self.m_sloganLabel:setString(sloganString)
            end

        end
    end
    --print("load resource m_sloganLabel")
    if nil ~= GoldExchangeLuaView["m_lblDes1"] then
        self.m_lblDes1 = tolua.cast(GoldExchangeLuaView["m_lblDes1"],"cc.Label")
        if nil ~= self.m_lblDes1 then
            local desString2 = nil
            if self.data[19] == "alliance1" then
                -- desString2 = string.format(LuaController:getLang("101397"))
                dic1:setObject(CCString:create(tostring("101397")), "1")
                desString2 = LuaController:comFunc("getLang", dic1):getCString()
            end
            if self.data[19] == "build_alliance" then
                -- desString2 = string.format(LuaController:getLang("101397"))
                dic1:setObject(CCString:create(tostring("101397")), "1")
                desString2 = LuaController:comFunc("getLang", dic1):getCString()
            end
            if nil ~= desString2 then
                self.m_lblDes1:setString(desString2)
            end
        end
    end
    --print("load resource ____m_lblDes1")
    if nil ~= GoldExchangeLuaView["m_soleOutSpr"] then
        self.m_soleOutSpr = tolua.cast(GoldExchangeLuaView["m_soleOutSpr"],"cc.Sprite")
        if nil ~= self.m_soleOutSpr then
            -- sprite change image test code
            --local frame = cc.SpriteFrameCache:sharedSpriteFrameCache():spriteFrameByName("land.png");
            --if nil ~= frame then
            --    self.m_soleOutSpr:setDisplayFrame(frame)
            --end
            ----print "m_soleOutSpr___init____"
        end
    end
    --print("load resource ____m_soleOutSpr")
    if nil ~= GoldExchangeLuaView["m_moreNode"] then
        self.m_moreNode = tolua.cast(GoldExchangeLuaView["m_moreNode"],"cc.LayerColor")
        if nil ~= self.m_moreNode then
            local w = self.m_moreNode:getContentSize().width
            local h = self.m_moreNode:getContentSize().height
            self.m_moreNode:setVisible(false)
            ----print "m_moreNode___init____[" .. tostring(w) .. "," .. tostring(h) .. "]"
            ----print "m_moreNode___init____".. size.width .. "," .. size.height .."]"
        end
    end
    --print("load resource ____m_moreNode")
    if nil ~= GoldExchangeLuaView["m_moreSpr"] then
        self.m_moreSpr = tolua.cast(GoldExchangeLuaView["m_moreSpr"],"cc.Sprite")
        if nil ~= self.m_moreSpr then
            ----print "m_moreSpr___init____"
        end
    end
    --print("load resource ____m_moreSpr")
    if nil ~= GoldExchangeLuaView["m_sprCha"] then
        self.m_sprCha = tolua.cast(GoldExchangeLuaView["m_sprCha"],"cc.Sprite")
    end
    --print("load resource ____m_sprCha")
    if nil ~= GoldExchangeLuaView["m_moreLabel"] then
        self.m_moreLabel = tolua.cast(GoldExchangeLuaView["m_moreLabel"],"cc.Label")
        if nil ~= self.m_moreLabel then
            -- local moreStr = string.format(LuaController:getLang("102162"))
            dic1:setObject(CCString:create(tostring("102162")), "1")
            local moreStr = LuaController:comFunc("getLang", dic1):getCString()
            ----print(moreStr)
            self.m_moreLabel:setString(moreStr)
        end
    end
    --print("load resource ____m_moreLabel")
    if nil ~= GoldExchangeLuaView["m_touchMoreNode"] then
        self.m_touchMoreNode = tolua.cast(GoldExchangeLuaView["m_touchMoreNode"],"cc.LayerColor")
        if nil ~= self.m_touchMoreNode then
            local size = self.m_touchMoreNode:getContentSize()
            ----print "m_touchMoreNode___init____[" .. size.width .. "," .. size.height .."]"
        end
    end
    --print("load resource ____m_touchMoreNode")
    if nil ~= GoldExchangeLuaView["m_touchNode"] then
        -- print("load resource ____m_touchNode-1")
        self.m_touchNode = tolua.cast(GoldExchangeLuaView["m_touchNode"],"cc.LayerColor")
        if nil ~= self.m_touchNode then
            -- print("load resource ____m_touchNode-2")
            function onTouch(eventType, x, y)  
                -- print("load resource ____m_touchNode-4.eventType:"..tostring(eventType))
                if eventType == "began" then  
                    return self:onTouchBegan(x, y)  
                elseif eventType == "moved" then  
                    return self:onTouchMoved(x, y)  
                else  
                    return self:onTouchEnded(x, y)  
                end
            end
            self.m_touchNode:registerScriptTouchHandler(onTouch)
            self.m_touchNode:setTouchEnabled(true)
            -- print("load resource ____m_touchNode-3")
        end
    end
    print("load resource ____m_touchNode")
    if nil ~= GoldExchangeLuaView["m_buyNode"] then
        self.m_buyNode = tolua.cast(GoldExchangeLuaView["m_buyNode"],"cc.LayerColor")
    end
    --print("load resource ____m_buyNode")
    if nil ~= GoldExchangeLuaView["m_packageBtn"] then
        self.m_packageBtn = tolua.cast(GoldExchangeLuaView["m_packageBtn"],"cc.ControlButton")
    end
    --print("load resource ____m_packageBtn")
    if nil ~= GoldExchangeLuaView["m_costBtn"] then
        self.m_costBtn = tolua.cast(GoldExchangeLuaView["m_costBtn"],"cc.ControlButton")
        if nil ~= self.m_costBtn then
            local extWidth = 0
            local lableW = 0
            if nil ~= self.m_oldPriceLabel then
                lableW = self.m_oldPriceLabel:getContentSize().width
            end
            local maxWidth = (self.m_costBtn:getPreferredSize().width - 100) * 0.5
            ----print ("lua____[" .. string.format(lableW) .. "," .. string.format(maxWidth) .. "]" )

            if lableW > maxWidth then
                ----print ("lua____large1")
                extWidth = lableW - maxWidth
                if nil ~= self.m_sprCha then
                    local chaPosX = 0
                    if nil ~= self.m_oldPriceLabel then
                        if nil ~= self.m_sprCha then
                            self.m_oldPriceLabel:getPositionX()
                            self.m_sprCha:setPositionX(chaPosX - lableW * 0.5)
                        end
                    end
                end
            end
            if nil ~= self.m_newPriceLabel then
                lableW = self.m_newPriceLabel:getContentSize().width
                if lableW > maxWidth then
                    ----print ("lua____large2")
                    extWidth = lableW - maxWidth + extWidth
                end
            end

            if extWidth > 0 then
                ----print ("lua____large3")
                local costsize = self.m_costBtn:getContentSize()
                costsize.width = costsize.width + extWidth
                self.m_costBtn:setPreferredSize(costsize)
            end
            -- LuaController:addButtonLight(self.m_costBtn)
            dic1:setObject(self.m_costBtn, "1")
            LuaController:comFunc("addButtonLight", dic1)
            local showPackBtn = false
            if self.data[21] ~= nil then
                if self.data[21] == "1" then
                    showPackBtn = true
                end
            end
            if showPackBtn == true then
                if self.m_packageBtn ~= nil then
                    self.m_packageBtn:setVisible(true)
                    if extWidth > 0 then
                        self.m_packageBtn:setPositionX(self.m_packageBtn:getPositionX() + extWidth*0.5)
                    end
                end
                if self.m_buyNode ~= nil then
                    self.m_buyNode:setPositionX(-35)
                end
            else
                if self.m_packageBtn ~= nil then
                    self.m_packageBtn:setVisible(false)
                end
                if self.m_buyNode ~= nil then
                    self.m_buyNode:setPositionX(0)
                end
            end
        end
    end
    --print("load resource ____m_costBtn")
    if nil ~= GoldExchangeLuaView["m_ani1"] then
        self.m_ani1Layer = tolua.cast(GoldExchangeLuaView["m_ani1"],"cc.LayerColor")
    end
    if nil ~= GoldExchangeLuaView["m_ani2"] then
        self.m_ani2Layer = tolua.cast(GoldExchangeLuaView["m_ani2"],"cc.LayerColor")
    end
    --print("load resource ____m_ani2")
    ----print("init ccbi data ____" .. string.format(os.clock() - opStart))
    --opStart = os.clock()

    if nil ~= GoldExchangeLuaView["m_anlayer10"] then
        self.m_anlayer10 = tolua.cast(GoldExchangeLuaView["m_anlayer10"],"cc.LayerColor")
    end
    if nil ~= GoldExchangeLuaView["m_anlayer11"] then
        self.m_anlayer11 = tolua.cast(GoldExchangeLuaView["m_anlayer11"],"cc.LayerColor")
    end
    if nil ~= GoldExchangeLuaView["m_anlayer12"] then
        self.m_anlayer12 = tolua.cast(GoldExchangeLuaView["m_anlayer12"],"cc.LayerColor")
    end
    if nil ~= GoldExchangeLuaView["m_anlayer13"] then
        self.m_anlayer13 = tolua.cast(GoldExchangeLuaView["m_anlayer13"],"cc.LayerColor")
    end
    if nil ~= GoldExchangeLuaView["m_anlayer14"] then
        self.m_anlayer14 = tolua.cast(GoldExchangeLuaView["m_anlayer14"],"cc.LayerColor")
    end
    
    --print("load resource ____m_listNode")
    ----print("init scroll data ____" .. string.format(os.clock() - opStart))
    --opStart = os.clock()
    -- if nil ~= self.data[15] then
    --     if(self.data[15] == "1") then
    --         self.m_soleOutSpr:setVisible(true)
    --         self.m_costBtn:setEnabled(false)
    --     else
    --         self.m_soleOutSpr:setVisible(false)
    --         self.m_costBtn:setEnabled(true)
    --     end
    -- end
    
    --print "2"
    self:scheduleBack()
    --print "3"
    if nil ~= self.m_timeLabel then
        schedule(self.m_timeLabel,scheduleDealWithFunc({target = self}),1)  
    end
    -- print "m_titleSpr========1"
    if nil ~= GoldExchangeLuaView["m_titleSpr"] then
        self.m_titleSpr = tolua.cast(GoldExchangeLuaView["m_titleSpr"],"cc.Sprite")
        if nil ~= self.m_titleSpr then

            self.playerInfo = GlobalData:comFunc("getPlayerInfo",0)
            if self.playerInfo ~= nil then
                self.regCountry =  tostring(self.playerInfo:getProperty("regCountry"))
                print("self.regCountry:"..self.regCountry)
            end

            local frame = cc.SpriteFrameCache:getInstance():getSpriteFrame(popImg.."_view_v4.jpg");
            if nil ~= frame then
                self.m_titleSpr:setSpriteFrame(frame)
            else
                frame = cc.SpriteFrameCache:getInstance():getSpriteFrame(popImg.."_view_v4.png");
                if nil ~= frame then
                    self.m_titleSpr:setSpriteFrame(frame)
                end
            end

            if self.regCountry ~= nil then
                local frame = cc.SpriteFrameCache:getInstance():getSpriteFrame(popImg.."_"..self.regCountry.."_view_v4.jpg");
                if nil ~= frame then
                    self.m_titleSpr:setSpriteFrame(frame)
                end
            end
        end
    end

    self:addChild(node);
    local nodeSize = node:getContentSize()
    local moveY = 0
    local isPad = CCCommonUtilsForLua:comFunc("isIosAndroidPad", 0):getValue()
    if self.popType=="1" then
        winSize.height=980
    end
    if nil ~= self.m_bestSaleNode and self.m_bestSaleNode:isVisible()==false and self.data[28]~=nil and tostring(self.data[28])~="" and tostring(self.data[28])~="0" then
        local strName = tostring(self.data[28])..".png"
        print("strName28:"..tostring(strName))
        local frame = cc.SpriteFrameCache:getInstance():getSpriteFrame(tostring(strName));
        if frame ~= nil then
            self.m_bestSaleNode:setVisible(true)
            self.m_bestSaleNode:removeAllChildren()
            local dic1 = CCDictionary:create()
            dic1:setObject(CCString:create(tostring(strName)), "1")
            local sprN = CCLoadSprite:comFunc("createSprite", dic1)
            self.m_bestSaleNode:addChild(sprN)
        end
    end
    if nil ~= GoldExchangeLuaView["m_nodeStampM"] then
        self.m_nodeStampM = tolua.cast(GoldExchangeLuaView["m_nodeStampM"],"cc.Node")
    end
    if nil ~= self.m_nodeStampM and self.data[29]~=nil and tostring(self.data[29])~="" and tostring(self.data[29])~="0" then
        local strName = tostring(self.data[29])..".png"
        print("strName29:"..tostring(strName))
        local frame = cc.SpriteFrameCache:getInstance():getSpriteFrame(tostring(strName));
        if frame ~= nil then
            self.m_nodeStampM:setVisible(true)
            local dic1 = CCDictionary:create()
            dic1:setObject(CCString:create(tostring(strName)), "1")
            local sprM = CCLoadSprite:comFunc("createSprite", dic1)
            self.m_nodeStampM:removeAllChildren()
            self.m_nodeStampM:addChild(sprM)
            print("isPad:"..tostring(isPad))
            if isPad == false or self.popType=="1" then
                self.m_nodeStampM:setPositionY(self.m_nodeStampM:getPositionY()-(winSize.height-nodeSize.height))
            end
        end
    end
    
    if isPad == false or self.popType=="1"then
        node:setPositionY(winSize.height-nodeSize.height-moveY)
    else
        node:setPosition(CCPoint((winSize.width-nodeSize.width)*0.5,(winSize.height-nodeSize.height)*0.5-moveY))
    end
    -- node:setPosition(CCPoint((winSize.width-nodeSize.width)*0.5,(winSize.height-nodeSize.height)*0.5))
    if nil ~= GoldExchangeLuaView["m_downNode"] then
        self.m_downNode = tolua.cast(GoldExchangeLuaView["m_downNode"],"cc.LayerColor")
        if nil ~= self.m_downNode then
            local size = self.m_downNode:getContentSize()
            if isPad == false or self.popType=="1" then
                self.m_downNode:setPositionY(self.m_downNode:getPositionY()-(winSize.height-nodeSize.height))
            end
        end
        -- if self.popType=="1" then
        --     self.m_downNode:setPositionY(self.m_downNode:getPositionY()-20)
        -- end
    end
    if nil ~= GoldExchangeLuaView["m_downBgNode"] then
        self.m_downBgNode = tolua.cast(GoldExchangeLuaView["m_downBgNode"],"cc.Node")
        if nil ~= self.m_downBgNode then
            print("isPad:"..tostring(isPad))
            if isPad == false then
                self.m_downBgNode:setPositionY(self.m_downBgNode:getPositionY()-(winSize.height-nodeSize.height))
            end
        end
    end

    if nil ~= GoldExchangeLuaView["m_closeNode"] then
        self.m_closeNode = tolua.cast(GoldExchangeLuaView["m_closeNode"],"cc.Node")
        if nil ~= self.m_closeNode and self.popType=="1" then
            self.m_closeNode:setVisible(false)
        end
    end
    if nil ~= GoldExchangeLuaView["m_infoNode"] then
        self.m_infoNode = tolua.cast(GoldExchangeLuaView["m_infoNode"],"cc.Node")
        if nil ~= self.m_infoNode and self.popType=="0" then
            self.m_infoNode:setVisible(false)
        else
            if nil ~= GoldExchangeLuaView["m_viewMoreTxt"] then
                self.m_viewMoreTxt = tolua.cast(GoldExchangeLuaView["m_viewMoreTxt"],"cc.Label")
                if nil ~= self.m_viewMoreTxt then
                    -- local moreStr = string.format(LuaController:getLang("102162"))
                    dic1:setObject(CCString:create(tostring("115331")), "1")--115331=查看详情
                    local moreStr = LuaController:comFunc("getLang", dic1):getCString()
                    ----print(moreStr)
                    self.m_viewMoreTxt:setString(moreStr)
                end
            end
        end
    end

    if nil ~= GoldExchangeLuaView["m_listNode_bg"] then
        self.m_listNode_bg = tolua.cast(GoldExchangeLuaView["m_listNode_bg"],"ccui.Scale9Sprite")
        if isPad == false or self.popType=="1" then
            self.m_listNode_bg:setContentSize(CCSize(self.m_listNode_bg:getContentSize().width,self.m_listNode_bg:getContentSize().height + (winSize.height-nodeSize.height)));
            self.m_listNode_bg:setPositionY(self.m_listNode_bg:getPositionY() - (winSize.height-nodeSize.height))
        end
    end

    if nil ~= GoldExchangeLuaView["m_listNode"] then
        self.m_listNode = tolua.cast(GoldExchangeLuaView["m_listNode"],"cc.LayerColor")
        if nil ~= self.m_listNode then
            if isPad == false or self.popType=="1" then
                self.m_listNode:setContentSize(CCSize(self.m_listNode:getContentSize().width,self.m_listNode:getContentSize().height + (winSize.height-nodeSize.height)));--
                self.m_listNode:setPositionY(self.m_listNode:getPositionY() - (winSize.height-nodeSize.height))--
            end
            
            local size = self.m_listNode:getContentSize()
            local scrollView1 = cc.ScrollView:create()
            if nil ~= scrollView1 then
                scrollView1:setViewSize(self.m_listNode:getContentSize())
                scrollView1:setPosition(CCPoint(0,0))
                scrollView1:setScale(1.0)
                scrollView1:ignoreAnchorPointForPosition(true)
                scrollView1:setDirection(1)
                scrollView1:setClippingToBounds(true)
                scrollView1:setBounceable(true)
                local offsetY = 0
                if nil~= self.items then
                    local tCount = table.getn(self.items)
                    
                    if self.popType=="1" and tCount>3 then
                        for i=tCount-2,tCount do
                            -- local sprite =  GoldExchangeCommonCell:create(self.rootPath,self.items[i])
                            -- scrollView1:addChild(sprite)
                            -- sprite:setPositionX(0)
                            -- sprite:setPositionY(offsetY)
                            -- offsetY = offsetY + 70

                            self.m_touchCellSpr[i] =  GoldExchangeCommonCell:create(self.rootPath,self.items[i])
                            scrollView1:addChild(self.m_touchCellSpr[i])
                            self.m_touchCellSpr[i]:setPositionX(0)
                            self.m_touchCellSpr[i]:setPositionY(offsetY)
                            offsetY = offsetY + 70
                            
                        end
                    else
                        for i=1,tCount do
                            -- local sprite =  GoldExchangeCommonCell:create(self.rootPath,self.items[i])
                            -- scrollView1:addChild(sprite)
                            -- sprite:setPositionX(0)
                            -- sprite:setPositionY(offsetY)
                            -- offsetY = offsetY + 70

                            self.m_touchCellSpr[i] =  GoldExchangeCommonCell:create(self.rootPath,self.items[i])
                            scrollView1:addChild(self.m_touchCellSpr[i])
                            self.m_touchCellSpr[i]:setPositionX(0)
                            self.m_touchCellSpr[i]:setPositionY(offsetY)
                            offsetY = offsetY + 70
                        end
                    end                    
                end
                scrollView1:setContentSize(CCSize(450,offsetY))
                local cH = self.m_listNode:getContentSize().height
                scrollView1:setContentOffset(CCPoint(0, cH - offsetY))
                self.m_listNode:addChild(scrollView1);
            end
            if self.popType=="1" then
                scrollView1:setTouchEnabled(false)                
            end
        end
    end

    self.ccbNode = node
    -- local chechV = tostring(CCCommonUtilsForLua:getPropById("99020","k1"))
    -- if CCCommonUtilsForLua:checkVersion(chechV) == true then
    --     if CCCommonUtilsForLua:isFlip() then
    --         self:setCommonFlip()
    --     end
    -- end
    dic1:setObject(CCString:create(tostring("99020")), "1")
    dic1:setObject(CCString:create(tostring("k1")), "2")
    local chechV = CCCommonUtilsForLua:comFunc("getPropById", dic1):getCString()
    -- if CCCommonUtilsForLua:checkVersion(chechV) == true then
    dic1:setObject(CCString:create(tostring(chechV)), "1")
    if CCCommonUtilsForLua:comFunc("checkVersion", dic1):getValue() == true then
        -- if CCCommonUtilsForLua:isFlip() then
        if CCCommonUtilsForLua:comFunc("isFlip", 0):getValue() == true then
            self:setCommonFlip()
        end
    end

    local function onNodeEvent(event)
        if event == "enter" then
            ----print "gold_exchange_adv_cell_enter"
        elseif event == "exit" then
            ----print "gold_exchange_adv_cell_exit"
            if self.effid1 ~= nil then
                if self.m_anlayer10 ~= nil then
                    self.m_anlayer10:getScheduler():unscheduleScriptEntry(self.effid1)
                end
            end
            if self.effid2 ~= nil then
                if self.m_anlayer11 ~= nil then
                    self.m_anlayer11:getScheduler():unscheduleScriptEntry(self.effid2)
                end
            end
            if self.effid3 ~= nil then
                if self.m_anlayer12 ~= nil then
                    self.m_anlayer12:getScheduler():unscheduleScriptEntry(self.effid3)
                end
            end
            if self.effid4 ~= nil then
                if self.m_anlayer13 ~= nil then
                    self.m_anlayer13:getScheduler():unscheduleScriptEntry(self.effid4)
                end
            end
            if self.effid5 ~= nil then
                if self.m_anlayer14 ~= nil then
                    self.m_anlayer14:getScheduler():unscheduleScriptEntry(self.effid5)
                end
            end
            self:onExit()
        end
    end
    self.ccbNode:registerScriptHandler(onNodeEvent)
    ----print("finish init view ____" .. string.format(os.clock() - opStart))
    --PopupViewController:getInstance():addPopupView(self.parentNode,false,false)
    print("load resource ____finish")
end

function GoldExchangeView:setCommonFlip()
    self.ccbNode:setScaleX(-1)
    if self.m_titleLabel ~= nil then
        self.m_titleLabel:setScaleX(-1)
    end
    if self.m_percentLabel ~= nil then
        self.m_percentLabel:setScaleX(-1)
    end
    
    if self.m_timeLabel ~= nil then
        self.m_timeLabel:setScaleX(-1)
        self.m_timeLabel:setPositionX(self.m_timeLabel:getPositionX()+self.m_timeLabel:getContentSize().width)
    end
    
    if self.m_getGoldNumText ~= nil then
        self.m_getGoldNumText:setScaleX(-1)
    end
    
    if self.m_oldPriceLabel ~= nil then
        self.m_oldPriceLabel:setScaleX(-1)
        self.m_oldPriceLabel:setPositionX(self.m_oldPriceLabel:getPositionX()-self.m_oldPriceLabel:getContentSize().width)
    end
    
    if self.m_newPriceLabel ~= nil then
        self.m_newPriceLabel:setScaleX(-1)
        self.m_newPriceLabel:setPositionX(self.m_newPriceLabel:getPositionX()+self.m_newPriceLabel:getContentSize().width)
    end

    if self.m_goldNumText ~= nil then
        self.m_goldNumText:setScaleX(-1)
        self.m_goldNumText:setPositionX(self.m_goldNumText:getPositionX()+self.m_goldNumText:getContentSize().width)
    end

    if self.m_upDesLabel ~= nil then
        self.m_upDesLabel:setScaleX(-1)
        self.m_upDesLabel:setPositionX(self.m_upDesLabel:getPositionX()+self.m_upDesLabel:getContentSize().width)
    end
    
    
end
