----------------------------
-- Author: Elex
-- Date: 2019-12-20 Friday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CommercialView_ui = class("CommercialView_ui")

--#ui propertys


--#function
function CommercialView_ui:create(owner, viewType, paramTable)
	local ret = CommercialView_ui.new()
	CustomUtility:DoRes(0, true)
	CustomUtility:LoadUi("CommercialView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CommercialView_ui:initLang()
	LabelSmoker:setText(self.m_titleTxt, "41576000")
	ButtonSmoker:setText(self.m_mineBtn, "41576003")
	ButtonSmoker:setText(self.m_otherBtn, "41576004")
end

function CommercialView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CommercialView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CommercialView_ui:onClickTip(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickTip", pSender, event)
end

function CommercialView_ui:onClickMine(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickMine", pSender, event)
end

function CommercialView_ui:onClickOther(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickOther", pSender, event)
end

return CommercialView_ui

