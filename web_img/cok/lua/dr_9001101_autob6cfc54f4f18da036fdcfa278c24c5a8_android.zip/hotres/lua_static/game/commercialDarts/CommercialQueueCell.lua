local CommercialQueueCell = class("CommercialQueueCell", cc.Layer)

function CommercialQueueCell:create(uuid)
    local cell = CommercialQueueCell.new(uuid)
    Drequire("game.commercialDarts.CommercialQueueCell_ui"):create(cell, 0)
    if cell:initCell() then return cell end
end

function CommercialQueueCell:ctor(uuid)
    self.uuid = uuid
    self.ctrl = require("game.commercialDarts.CommercialController").getInstance()
end

function CommercialQueueCell:initCell()
    local marchInfo = self.ctrl:getMarchInfo(self.uuid)
    if not marchInfo then return false end

    registerTouchHandler(self)

    if marchInfo.tmpPointId > 0 then
        CCCommonUtilsForLua:setButtonTitle(self.ui.m_cdBtn, getLang("132169"))
    else
        CCCommonUtilsForLua:setButtonTitle(self.ui.m_cdBtn, getLang("104903"))
    end

    local size = self.ui.m_bar:getContentSize()
    local sf = CCLoadSprite:call("loadResource", "cd_tiao_02.png")
    self.ui.m_bar:setSpriteFrame(sf)
    self.ui.m_bar:setContentSize(size)

    if marchInfo:isDarts() then
        self.ui.m_cdBtn:setVisible(false)

        local bgSize = self.ui.m_bg:getContentSize()
        self.ui.m_bar:setContentSize(bgSize)
    else
        self.ui.m_cdBtn:setVisible(true)
    end

    return true
end

function CommercialQueueCell:update(dt)
    local marchInfo = self.ctrl:getMarchInfo(self.uuid)
    if not marchInfo then return end

    local now = WorldController:call("getTime")

    local startTime = 0
    local endTime = 0
    if marchInfo.tmpPointId > 0 then
        startTime = marchInfo.obtainStartTime
        endTime = marchInfo.obtainEndTime
    else
        startTime = marchInfo.startTime
        endTime = marchInfo.endTime
    end

    local leftTime = endTime - now
    leftTime = leftTime > 0 and leftTime or 0
    
    local totalTime = endTime - startTime
    local scale = 1 - leftTime / totalTime
    scale = scale < 1 and scale or 1
    self.ui.m_bar:setScaleX(scale)

    local temp = ""
    if marchInfo:isDarts() then
        if marchInfo:isRestState() then
            temp = getLang("41576055")
        elseif marchInfo:isTransferState() then
            temp = getLang("41576052")
        elseif marchInfo:isOccupyState() then
            temp = getLang("41576053")
        elseif marchInfo:isRepairState() then
            temp = getLang("41576054")
        end
    elseif marchInfo:isBack() then
        temp = getLang("132169")
    else
        temp = getLang("108740", tostring(math.floor(marchInfo.endPoint.x)), tostring(math.floor(marchInfo.endPoint.y)))
    end
    self.ui.m_nameLabel:setString(temp)
    self.ui.m_timeLabel:setString(format_time_q(leftTime / 1000))
end

function CommercialQueueCell:onEnter()
    self:update(0)
    local function update(dt) self:update(dt) end 
	self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(update, 1, false)
end

function CommercialQueueCell:onExit()
    cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
end

function CommercialQueueCell:onTouchBegan(x, y)
    local currentSceneId = SceneController:call("getCurrentSceneId")
    if currentSceneId == SCENE_ID_WORLD then
        if isTouchInside(self.ui.m_bg, x, y) and self:isVisible(true) then 
            return true
        end
    end
end

function CommercialQueueCell:onTouchEnded(x, y)
    local marchInfo = self.ctrl:getMarchInfo(self.uuid)
    if not marchInfo then return end

    local currentSceneId = SceneController:call("getCurrentSceneId")
    if currentSceneId == SCENE_ID_WORLD then
        local marchInfo = self.ctrl:getMarchInfo(self.uuid)
        local selfServerId = GlobalData:call("getPlayerInfo"):getProperty("selfServerId")
        if marchInfo.tmpPointId > 0 then
            WorldController:call("getInstance"):setProperty("openTargetIndex", marchInfo.tmpPointId)
            local point = WorldController:call("getPointByIndex", marchInfo.tmpPointId)
            WorldMapView:call("gotoTilePoint1", point, selfServerId)
        else
            local x, y = marchInfo:getMarchNodePos()
            if x and y then
                local point  = WorldController:call("getTilePointByViewPoint", ccp(x, y))
                WorldMapView:call("gotoTilePoint1", point, selfServerId)
                self.ctrl:showTroopInfo(marchInfo.uuid)
                self.ctrl.followMarchId = marchInfo.uuid
            end
        end
    end
end

function CommercialQueueCell:onCDClick()
    local marchInfo = self.ctrl:getMarchInfo(self.uuid)
    if not marchInfo then return end

    if marchInfo.tmpPointId > 0 then
        local dict = CCDictionary:create()
        dict:setObject(CCString:create(marchInfo.escortUuid), "uuid")
        local view = Drequire("game.CommonPopup.UseToolView"):create(USE_TOOL_COMMERCIAL_CANCEL, dict)
        PopupViewController:addPopupInView(view) 
    else
        local startTime = GlobalData:call("changeTime", marchInfo.startTime / 1000)
        local endTime = GlobalData:call("changeTime", marchInfo.endTime / 1000)

        local dict = CCDictionary:create()
        dict:setObject(CCString:create("UseCDToolView"), "name")
        dict:setObject(CCString:create(marchInfo.uuid), "uuid")
        dict:setObject(CCString:create("-3"), "qid")
        dict:setObject(CCString:create("1"), "timeFlag")
        dict:setObject(CCString:create(tostring(startTime)), "startTime")
        dict:setObject(CCString:create(tostring(endTime)), "endTime")
        LuaController:call("openPopViewInLua", dict) 
    end
end

return CommercialQueueCell

