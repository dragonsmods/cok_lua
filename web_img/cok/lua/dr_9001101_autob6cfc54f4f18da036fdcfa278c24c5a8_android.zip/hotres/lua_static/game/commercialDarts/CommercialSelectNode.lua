local CommercialSelectNode = class("CommercialSelectNode", cc.Layer)

function CommercialSelectNode:create(parentSize, receive, remainTimes)
    local node = CommercialSelectNode.new(parentSize, receive, remainTimes)
    if node:initNode() then return node end
end

function CommercialSelectNode:ctor(parentSize, receive, remainTimes)
    self.size = parentSize
    self.receive = receive
    self.remainTimes = atoi(remainTimes)
    self.guideBtn = nil
    self.ctrl = require("game.commercialDarts.CommercialController").getInstance()
end

function CommercialSelectNode:initNode()
    self:setContentSize(self.size)
   
	local cellSizeForTable = function(tab, idx) return self:cellSizeForTable(tab, idx) end
	local tableCellAtIndex = function(tab, idx) return self:tableCellAtIndex(tab, idx) end
	local numberOfCellsInTableView = function(tab) return self:numberOfCellsInTableView(tab) end

    self.m_tabView = cc.TableView:create(self.size)
	self.m_tabView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
	self.m_tabView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
	self.m_tabView:setDelegate()
	self.m_tabView:registerScriptHandler(cellSizeForTable,cc.TABLECELL_SIZE_FOR_INDEX)
	self.m_tabView:registerScriptHandler(numberOfCellsInTableView,cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
	self.m_tabView:registerScriptHandler(tableCellAtIndex,cc.TABLECELL_SIZE_AT_INDEX)
    self.m_tabView:reloadData()
    self:addChild(self.m_tabView)

    --行军页面引导在这里中断
    if GuideController:call("getCurrentId") == "41726006" 
        or GuideController:call("getCurrentId") == "41726007" 
        or GuideController:call("getCurrentId") == "41726009" then
       GuideController:call("setGuide", "")
   end
    
    return true
end

function CommercialSelectNode:onEnter()
    
end

function CommercialSelectNode:onExit()

end

function CommercialSelectNode:cellSizeForTable( view, idx )
	return 640, 128
end

function CommercialSelectNode:receiveCb(configId)
    if self.remainTimes < 1 then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("169948"))
        return
    end

    local actOpen = self.ctrl:isActivityOpen()
    if not actOpen then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("102517"))
        return
    end
        
    -- local dict = CCDictionary:create()
    -- dict:setObject(CCString:create("OpenBattleViewForCommercial"), "name")
    -- dict:setObject(CCString:create("-168"), "type")
    -- dict:setObject(CCString:create(configId), "id")
    -- dict:setObject(CCString:create("COMMERCIAL_RECEIVE"), "key")
    -- LuaController:call("openPopViewInLua", dict)
    local view = Drequire("game.CommonPopup.BattleView"):createViewForCommercial(-168, configId, "COMMERCIAL_RECEIVE")
    PopupViewController:addPopupInView(view)
    self.ctrl:getMarchTime()
end

function CommercialSelectNode:tableCellAtIndex( view, idx )
    local function receive(configId)
        self:receiveCb(configId)
    end

	local luaIdx = idx + 1
    if luaIdx > #self.receive then return end
    local cell = view:dequeueCell()
    if not cell then 
		cell = Drequire("game.commercialDarts.CommercialSelectCell"):create(idx, receive)
    end
    if luaIdx == 1 then self.guideBtn = cell:getGuideNode() end
    cell:refreshCell(self.receive[luaIdx], idx)
    return cell
end

function CommercialSelectNode:numberOfCellsInTableView( view )
	return #self.receive
end

function CommercialSelectNode:getGuideNode(key)
    if key == "commercial_pick" then
        if self.guideBtn then return self.guideBtn end
    end
end

return CommercialSelectNode
