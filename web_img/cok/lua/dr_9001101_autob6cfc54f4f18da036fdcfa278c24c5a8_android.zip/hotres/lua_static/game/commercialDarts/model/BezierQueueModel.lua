local BezierQueueModel = class("BezierQueueModel", Drequire("game.commercialDarts.model.BaseQueueModel"))

function BezierQueueModel:parse(data)
    if data.uuid then
        self.uuid = data.uuid
    end

    --地图用
    if self.marchTag == 0 then
        self.marchTag = WorldController:call("getMarchTag")
    end

    --队列用
    if self.marchQid == 0 then
        self.marchQid = QueueController:call("getQID", QueueType.TYPE_MARCH) + self.marchTag
    end

    local accelerate = false
    if data.endTime then 
        local endTime = atoi(data.endTime) 
        accelerate = (self.endTime ~= endTime)
        self.endTime = endTime
    end

    if data.startPoint then
        self.startPoint.x = atoi(data.startPoint.x)
        self.startPoint.y = atoi(data.startPoint.y)
    end

    if data.endPoint then
        self.endPoint.x = atoi(data.endPoint.x)
        self.endPoint.y = atoi(data.endPoint.y)
    end

    if data.caravanPoint then
        self.caravanPoint.x = atoi(data.caravanPoint.x)
        self.caravanPoint.y = atoi(data.caravanPoint.y)
    end

    if accelerate then
        self.startPointMap = nil
        self.endPointMap = nil
        self.caravanPointMap = nil
    end

    if data.startTime then self.startTime = atoi(data.startTime) end

    if data.ownerInfo then self.ownerInfo = data.ownerInfo end
    if data.marchType then self.marchType = atoi(data.marchType) end
    if data.obtainStartTime then self.obtainStartTime = atoi(data.obtainStartTime) end
    if data.obtainEndTime then self.obtainEndTime = atoi(data.obtainEndTime) end
    if data.tmpPointId then
        self.tmpPointId = atoi(data.tmpPointId)
    else
        self.tmpPointId = 0
    end

    if data.targetUuid then self.targetUuid = data.targetUuid end

    if data.attSkin then self.attSkin = atoi(data.attSkin) end
    if data.marchSkin then self.marchSkin = atoi(data.marchSkin) end

    if data.army then self.marchArmy = data.army end
    if data.dragonList then self.marchDragon = data.dragonList end
    if data.generalList then self.marchHero = data.generalList end
end

-- function BezierQueueModel:resetStartData()
--     local now = WorldController:call("getTime")
--     local t = (now - self.startTime) / (self.endTime - self.startTime)

--     local oneMinusT = 1 - t
--     self.startPointMap.x = math.pow(oneMinusT, 2) * self.startPointMap.x + 2 * t * oneMinusT * self.caravanPointMap.x + math.pow(t, 2) * self.endPointMap.x
--     self.startPointMap.y = math.pow(oneMinusT, 2) * self.startPointMap.y + 2 * t * oneMinusT * self.caravanPointMap.y + math.pow(t, 2) * self.endPointMap.y
--     self.endPointMap = nil
--     self.caravanPointMap = nil
-- end

function BezierQueueModel:setDartsCb(dartsCb)
    self.dartsCb = dartsCb
end

function BezierQueueModel:update(now, dt, followMarchId)
    local addFlag = false
    
    local t = (now - self.startTime) / (self.endTime - self.startTime)
    t = t > 1 and 1 or t

    if not self.startPointMap then
        self.startPointMap = WorldController:call("getViewPointByTilePoint", ccp(self.startPoint.x, self.startPoint.y))
    end

    if not self.endPointMap then
        self.endPointMap = WorldController:call("getViewPointByTilePoint", ccp(self.endPoint.x, self.endPoint.y))
    end

    if not self.caravanPointMap then
        self.caravanPointMap = WorldController:call("getViewPointByTilePoint", ccp(self.caravanPoint.x, self.caravanPoint.y))
    end

    local oneMinusT = 1 - t
    local x = math.pow(oneMinusT, 2) * self.startPointMap.x + 2 * t * oneMinusT * self.caravanPointMap.x + math.pow(t, 2) * self.endPointMap.x
    local y = math.pow(oneMinusT, 2) * self.startPointMap.y + 2 * t * oneMinusT * self.caravanPointMap.y + math.pow(t, 2) * self.endPointMap.y

    local marchNode = WorldMapView:call("getMarchNodeByTag", self.marchTag)
    if not marchNode then
        marchNode = self:createMarchNode()
        addFlag = true
    end
    marchNode:setPosition(x, y)

    if self.dartsCb then
        local dx, dy = self.dartsCb(self.targetUuid)
        if dx and dy then
            local marchLine = WorldMapView:call("getMarchLineByTag", self.marchTag)
            if not marchLine then 
                marchLine = self:createMarchLine() 
                addFlag = true
            end
            
            marchLine:call("updateStartAndEnd", ccp(x, y), ccp(dx, dy))
        end
    end

    if self.uuid == followMarchId then self:jumpToTarget(marchNode) end

    return addFlag
end

return BezierQueueModel