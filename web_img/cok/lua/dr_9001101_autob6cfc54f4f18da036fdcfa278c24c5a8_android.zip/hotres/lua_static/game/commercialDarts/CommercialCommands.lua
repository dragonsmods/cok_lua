local CommercialCommands = class("CommercialCommands")

----登录----
local LoginSynCmd = class("LoginSynCmd", LuaCommandBase)
function LoginSynCmd:send2Server()
    local cmd = LoginSynCmd.new()
    cmd:initWithName("escort.login")
    cmd:send()
end

function LoginSynCmd:handleReceive(dict)
    local tbl, params = self:parseMsg(dict, true)
	if type(tbl) == "boolean" then return tbl end

    --dump(tbl, "LoginSynCmd handleReceive")
    require("game.commercialDarts.CommercialController").getInstance():initQueue(tbl)
    return true
end

----押镖----
local RecieveCmd = class("RecieveCmd", LuaCommandBase)
function RecieveCmd:send2Server(data)
    local cmd = RecieveCmd.new()
    cmd:initWithName("escort.receive")
    cmd:putParam("type", CCInteger:create(data.type))
    cmd:putParam("generalId", CCString:create(data.generalId))
    cmd:putParam("petDragonUid", CCString:create(data.petDragonUid))
    cmd:putParam("aormationId", CCString:create(data.aormationId))
    if isFunOpenByKey('formation_train') then
        local formationTrain = tonumber(data.aormationId)
        if formationTrain then
            cmd:putParam("formationTrain",CCInteger:create(formationTrain))
        end
    end 
    cmd.soldiers = data.soldiers
    cmd:putParam("soldiers", luaToDict4Cmd(data.soldiers))
    cmd:putParam("unStop", CCBool:create(data.unStop))
	cmd:send()
end

function RecieveCmd:handleReceive(dict)
    local cmdname = dict:valueForKey("cmd"):getCString()
	if cmdname ~= "escort.receive" then
		return false
	end
	
	local params = dict:objectForKey("params")
	if nil == params then
		return true
    end
    
    local tbl = dictToLuaTable(params)
    if tbl.errorCode and tbl.errorCode ~= "" then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang(tbl.errorCode))
        require("game.commercialDarts.CommercialController").getInstance():revertSoilders(self.soldiers)
        return true
    end

    if tbl.gold then
        GlobalData:call("getPlayerInfo"):setProperty("gold", atoi(tbl.gold))
		CCSafeNotificationCenter:call("postNotification", "city_resources_update")
    end

    local selfPoint = WorldController:call("getInstance"):getProperty("selfPoint")
    local index = WorldController:call("getIndexByPoint", selfPoint)
	if SceneController:call("getCurrentSceneId") == SCENE_ID_WORLD then
		WorldMapView:call("instance"):call("gotoTilePoint", selfPoint)
	else
		SceneController:call("gotoScene", SCENE_ID_WORLD, false, true, index)
	end

    --跟踪接镖队伍
    if tbl.uuid then
        require("game.commercialDarts.CommercialController").getInstance().followMarchId = tbl.uuid
        require("game.commercialDarts.CommercialController").getInstance().willShowMarchId = tbl.uuid
    end

    --重置每个驿站刷新提示
    for index = 1, 4 do
        local setKey = "CommercialTip" .. index
        cc.UserDefault:getInstance():setBoolForKey(setKey, true)
    end
    cc.UserDefault:getInstance():flush()

    return true
end 

----抢镖----
local AttackCmd = class("AttackCmd", LuaCommandBase)
function AttackCmd:send2Server(data)
    local cmd = AttackCmd.new()
    cmd:initWithName("escort.attack")
    cmd:putParam("uuid", CCString:create(data.uuid))
    cmd:putParam("generalId", CCString:create(data.generalId))
    cmd:putParam("petDragonUid", CCString:create(data.petDragonUid))
    cmd:putParam("aormationId", CCString:create(data.aormationId))
    if isFunOpenByKey('formation_train') then
        local formationTrain = tonumber(data.aormationId)
        if formationTrain then
            cmd:putParam("formationTrain",CCInteger:create(formationTrain))
        end
    end 
    cmd.soldiers = data.soldiers
    cmd:putParam("soldiers", luaToDict4Cmd(data.soldiers))
	cmd:send()
end

function AttackCmd:handleReceive(dict)
    local cmdname = dict:valueForKey("cmd"):getCString()
	if cmdname ~= "escort.attack" then
		return false
	end
	
	local params = dict:objectForKey("params")
	if nil == params then
		return true
    end
    
    local tbl = dictToLuaTable(params)
    if tbl.errorCode and tbl.errorCode ~= "" then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang(tbl.errorCode))
        require("game.commercialDarts.CommercialController").getInstance():revertSoilders(self.soldiers)
        return true
    end

    return true
end 

----护卫/援助----
local AssistCmd = class("AssistCmd", LuaCommandBase)
function AssistCmd:send2Server(data)
    local cmd = AssistCmd.new()
    cmd:initWithName("escort.assist")
    cmd:putParam("uuid", CCString:create(data.uuid))
    cmd:putParam("generalId", CCString:create(data.generalId))
    cmd:putParam("petDragonUid", CCString:create(data.petDragonUid))
    cmd:putParam("aormationId", CCString:create(data.aormationId))
    if isFunOpenByKey('formation_train') then
        local formationTrain = tonumber(data.aormationId)
        if formationTrain then
            cmd:putParam("formationTrain",CCInteger:create(formationTrain))
        end
    end 
    cmd.soldiers = data.soldiers
    cmd:putParam("soldiers", luaToDict4Cmd(data.soldiers))
	cmd:send()
end

function AssistCmd:handleReceive(dict)
    local cmdname = dict:valueForKey("cmd"):getCString()
	if cmdname ~= "escort.assist" then
		return false
	end
	
	local params = dict:objectForKey("params")
	if nil == params then
		return true
    end
    
    local tbl = dictToLuaTable(params)
    if tbl.errorCode and tbl.errorCode ~= "" then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang(tbl.errorCode))
        require("game.commercialDarts.CommercialController").getInstance():revertSoilders(self.soldiers)
        return true
    end
    return true
end 

----加速----
local AccelerateCmd = class("AccelerateCmd", LuaCommandBase)
function AccelerateCmd:send2Server(uuid, itemId)
    local cmd = AccelerateCmd.new()
    cmd:initWithName("escort.accelerate")
    cmd:putParam("uuid", CCString:create(uuid))
    cmd:putParam("itemId", CCString:create(itemId))
	cmd:send()
end

function AccelerateCmd:handleReceive(dict)
    local tbl, params = self:parseMsg(dict, true)
	if type(tbl) == "boolean" then return tbl end

    --dump(tbl, "AccelerateCmd handleReceive")
    return true
end 

----召回----
local RecallCmd = class("RecallCmd", LuaCommandBase)
function RecallCmd:send2Server(uuid, itemId)
    local cmd = RecallCmd.new()
    cmd:initWithName("escort.recall")
    cmd:putParam("uuid", CCString:create(uuid))
    cmd:putParam("itemId", CCString:create(itemId))
	cmd:send()
end

function RecallCmd:handleReceive(dict)
    local tbl, params = self:parseMsg(dict, true)
	if type(tbl) == "boolean" then return tbl end

    --dump(tbl, "RecallCmd handleReceive")
    return true
end 

----部队----
local ViewTroopCmd = class("ViewTroopCmd", LuaCommandBase)
function ViewTroopCmd:send2Server(uuid)
    local cmd = ViewTroopCmd.new()
    cmd:initWithName("escort.troop")
    cmd:putParam("uuid", CCString:create(uuid))
	cmd:send()
end

function ViewTroopCmd:handleReceive(dict)
    local tbl, params = self:parseMsg(dict, true)
	if type(tbl) == "boolean" then return tbl end
    --dump(tbl, "ViewTroopCmd handleReceive")
    --旗帜页面通知
    CCSafeNotificationCenter:postNotification("GET_MARCH_DETAIL_UPDATE_COMMAND", params)
    --部队详情页面
    CCSafeNotificationCenter:postNotification("COMMERCIAL_TROOPVIEW", params)
    return true
end 

----伪装部队----
local RefreshMultCmd = class("RefreshMultCmd", LuaCommandBase)
function RefreshMultCmd:send2Server(uuid)
    local cmd = RefreshMultCmd.new()
    cmd:initWithName("escort.mask")
    cmd:putParam("uuid", CCString:create(uuid))
	cmd:send()
end

function RefreshMultCmd:handleReceive(dict)
    local tbl, params = self:parseMsg(dict, true)
	if type(tbl) == "boolean" then return tbl end
    -- dump(tbl, "RefreshMultCmd handleReceive")
    CCSafeNotificationCenter:postNotification("COMMERCIAL_REFRESH_MULT", params)
    return true
end 

--敌军速度降低信息
local ReqEnemySpeedCmd = class("ReqEnemySpeedCmd", LuaCommandBase)
function ReqEnemySpeedCmd:send2Server(uuid)
    local cmd = ReqEnemySpeedCmd.new()
    cmd:initWithName("escort.getDecrEnemySpeedRate")
    cmd:putParam("escortUuid", CCString:create(uuid))
	cmd:send()
end

function ReqEnemySpeedCmd:handleReceive(dict)
    local tbl, params = self:parseMsg(dict, true)
	if type(tbl) == "boolean" then return tbl end
    -- dump(tbl, "ReqEnemySpeedCmd handleReceive")
    CCSafeNotificationCenter:postNotification("msg.escort.speed", params)
    return true
end 

----援助----
local ReinforceCmd = class("ReinforceCmd", LuaCommandBase)
function ReinforceCmd:send2Server(uuid)
    local cmd = ReinforceCmd.new()
    cmd:initWithName("escort.reinforce")
    cmd:putParam("uuid", CCString:create(uuid))
	cmd:send()
end

function ReinforceCmd:handleReceive(dict)
    local tbl, params = self:parseMsg(dict, true)
	if type(tbl) == "boolean" then return tbl end
    --dump(tbl, "ReinforceCmd handleReceive")
    CCSafeNotificationCenter:postNotification("COMMERCIAL_ASSISTVIEW", params)
    return true
end 

----镖车----
local MineDataCmd = class("MineDataCmd", LuaCommandBase)
function MineDataCmd:send2Server()
    local cmd = MineDataCmd.new()
    cmd:initWithName("escort.data")
	cmd:send()
end

function MineDataCmd:handleReceive(dict)
    local tbl, params = self:parseMsg(dict, true)
	if type(tbl) == "boolean" then return tbl end
    --dump(tbl, "MineDataCmd handleReceive")
    CCSafeNotificationCenter:postNotification("COMMERCIAL_MINE_PAGE", params)
    return true
end 

----其他----
local OtherDataCmd = class("OtherDataCmd", LuaCommandBase)
function OtherDataCmd:send2Server()
    local cmd = OtherDataCmd.new()
    cmd:initWithName("escort.other")
	cmd:send()
end

function OtherDataCmd:handleReceive(dict)
    local tbl, params = self:parseMsg(dict, true)
	if type(tbl) == "boolean" then return tbl end
    --dump(tbl, "OtherDataCmd handleReceive")
    CCSafeNotificationCenter:postNotification("COMMERCIAL_OTHER_PAGE", params)
    return true
end

----跳转----
local JumpCamelCmd = class("JumpCamelCmd", LuaCommandBase)
function JumpCamelCmd:send2Server(uuid)
    local cmd = JumpCamelCmd.new()
    cmd:initWithName("escort.jump")
    cmd:putParam("uuid", CCString:create(uuid))
    cmd.uuid = uuid
	cmd:send()
end

function JumpCamelCmd:handleReceive(dict)
    local tbl, params = self:parseMsg(dict, true)
	if type(tbl) == "boolean" then return tbl end
    --dump(tbl, "JumpCamelCmd handleReceive")

    if tbl.tmpPointId then
        WorldController:call("getInstance"):setProperty("openTargetIndex", atoi(tbl.tmpPointId))
    else
        require("game.commercialDarts.CommercialController").getInstance().followMarchId = self.uuid
        require("game.commercialDarts.CommercialController").getInstance().willShowMarchId = self.uuid
    end

    if tbl.x and tbl.y then
        local point = ccp(atoi(tbl.x), atoi(tbl.y))
        if SceneController:call("getCurrentSceneId") == SCENE_ID_WORLD then
            local selfServerId = GlobalData:call("getPlayerInfo"):getProperty("selfServerId")
            WorldMapView:call("gotoTilePoint1", point, selfServerId)
        else
            local posIndex = WorldController:call("getIndexByPoint", point)
            SceneController:call("gotoScene", SCENE_ID_WORLD, false, true, posIndex)
        end
    end

    CCSafeNotificationCenter:postNotification("COMMERCIAL_JUMP")
    return true
end  

----祝福----
local PrayCamelCmd = class("PrayCamelCmd", LuaCommandBase)
function PrayCamelCmd:send2Server(uuid)
    local cmd = PrayCamelCmd.new()
    cmd:initWithName("escort.pray")
    cmd:putParam("uuid", CCString:create(uuid))
	cmd:send()
end

function PrayCamelCmd:handleReceive(dict)
    local tbl, params = self:parseMsg(dict, true)
	if type(tbl) == "boolean" then return tbl end
    LuaController:flyHint("", "", getLang("41576127"))
    return true
end

----刷新----
local RefreshCamelCmd = class("RefreshCamelCmd", LuaCommandBase)
function RefreshCamelCmd:send2Server(configId)
    local cmd = RefreshCamelCmd.new()
    cmd:initWithName("escort.refresh")
    cmd:putParam("configId", CCString:create(configId))
	cmd:send()
end

function RefreshCamelCmd:handleReceive(dict)
    local tbl, params = self:parseMsg(dict, true)
	if type(tbl) == "boolean" then return tbl end
    --dump(tbl, "RefreshCamelCmd handleReceive")
    
    if tbl.gold then
        GlobalData:call("getPlayerInfo"):setProperty("gold", atoi(tbl.gold))
		CCSafeNotificationCenter:call("postNotification", "city_resources_update")
    end
    
    CCSafeNotificationCenter:postNotification("COMMERCIAL_REFRESH", params)
    return true
end

----继续----
local ContinueCamelCmd = class("ContinueCamelCmd", LuaCommandBase)
function ContinueCamelCmd:send2Server(uuid)
    local cmd = ContinueCamelCmd.new()
    cmd:initWithName("escort.continue")
    cmd:putParam("uuid", CCString:create(uuid))
    cmd.uuid = uuid
	cmd:send()
end

function ContinueCamelCmd:handleReceive(dict)
    local tbl, params = self:parseMsg(dict, true)
	if type(tbl) == "boolean" then return tbl end
    --dump(tbl, "ContinueCamelCmd handleReceive")
    -- CCSafeNotificationCenter:postNotification("COMMERCIAL_CONTINUE", params)
    PopupViewController:call("removeAllPopupView")
    -- require("game.commercialDarts.CommercialController").getInstance().followMarchId = self.uuid    
    -- require("game.commercialDarts.CommercialController").getInstance().willShowMarchId = self.uuid
    return true
end

----时间----
local MarchTimeCmd = class("MarchTimeCmd", LuaCommandBase)
function MarchTimeCmd:send2Server(uuid)
    local cmd = MarchTimeCmd.new()
    cmd:initWithName("escort.time")
    if uuid then
        cmd:putParam("uuid", CCString:create(uuid))
    end
	cmd:send()
end

function MarchTimeCmd:handleReceive(dict)
    local tbl, params = self:parseMsg(dict, true)
	if type(tbl) == "boolean" then return tbl end
    --dump(tbl, "MarchTimeCmd handleReceive")
    CCSafeNotificationCenter:postNotification("COMMERCIAL_MARCHTIME", params)
    return true
end

----侦查----
local ScoutCmd = class("ScoutCmd", LuaCommandBase)
function ScoutCmd:send2Server(index, uuid, name)
    local cmd = ScoutCmd.new()
    cmd:initWithName("escort.scout")
    if index then
        cmd.index = index
        cmd:putParam("index", CCInteger:create(index))
    end
    if uuid then
        cmd.uuid = uuid
        cmd:putParam("uuid", CCString:create(uuid))
    end
    cmd.scoutName = name
	cmd:send()
end

function ScoutCmd:handleReceive(dict)
    local tbl, params = self:parseMsg(dict, true)
	if type(tbl) == "boolean" then return tbl end
    --dump(tbl, "ScoutCmd handleReceive")
    if self.index then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("41576227", self.scoutName))
    elseif self.uuid then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("41576228", self.scoutName))
    end
    return true
end

----保存----
local SaveRefreshCmd = class("SaveRefreshCmd", LuaCommandBase)
function SaveRefreshCmd:send2Server()
    local cmd = SaveRefreshCmd.new()
    cmd:initWithName("escort.save")
	cmd:send()
end

function SaveRefreshCmd:handleReceive(dict)
    local tbl, params = self:parseMsg(dict, true)
	if type(tbl) == "boolean" then return tbl end
    --dump(tbl, "SaveRefreshCmd handleReceive")
    CCSafeNotificationCenter:postNotification("COMMERCIAL_SAVEREFRESH", params)
    return true
end

--小地图
local MiniMapCmd = class("MiniMapCmd", LuaCommandBase)
function MiniMapCmd:send2Server()
    local cmd = MiniMapCmd.new()
    cmd:initWithName("escort.minimap")
	cmd:send()
end

function MiniMapCmd:handleReceive(dict)
    local tbl, params = self:parseMsg(dict, true)
	if type(tbl) == "boolean" then return tbl end
    --dump(tbl, "MiniMapCmd handleReceive")
    CCSafeNotificationCenter:postNotification("COMMERCIAL_MINIMAPDATA", params)
    return true
end

--商业之神
local RankCmd = class("RankCmd", LuaCommandBase)
function RankCmd:send2Server()
    local cmd = RankCmd.new()
    cmd:initWithName("escort.rank")
    cmd:send()
end

function RankCmd:handleReceive(dict)
    local tbl, params = self:parseMsg(dict, true)
    if type(tbl) == "boolean" then return tbl end
    CCSafeNotificationCenter:postNotification("COMMERCIAL_RANK", params)
    return true
end

--商业之神领奖
local RewardCmd = class("RewardCmd", LuaCommandBase)
function RewardCmd:send2Server(rwdIndex)
	local cmd = RewardCmd.new()
	cmd:initWithName("escort.reward")
	cmd:putParam("target_id", CCString:create(rwdIndex))
	cmd:send()
end

function RewardCmd:handleReceive(dict)
	local tbl, params = self:parseMsg(dict, true)
	if type(tbl) == "boolean" then return tbl end
	if tbl.reward then
		local allRewards = {}
		for k, v in pairs(tbl.reward) do
            table.insert(allRewards, v)
		end
		createTableFlyReward(allRewards, false)
    end
    
    return true
end

------地图------
function CommercialCommands:syncQueue()
    LoginSynCmd:send2Server()
end

function CommercialCommands:receive(cmdData)
    RecieveCmd:send2Server(cmdData)
end

function CommercialCommands:attack(cmdData)
    AttackCmd:send2Server(cmdData)
end

function CommercialCommands:assist(cmdData)
    AssistCmd:send2Server(cmdData)
end

function CommercialCommands:accelerate(uuid, itemId)
    AccelerateCmd:send2Server(uuid, tostring(itemId))
end

function CommercialCommands:recall(uuid, itemId)
    RecallCmd:send2Server(uuid, tostring(itemId))
end

function CommercialCommands:reinforce(uuid)
    ReinforceCmd:send2Server(uuid)
end

function CommercialCommands:viewTroop(uuid)
    ViewTroopCmd:send2Server(uuid)
end

function CommercialCommands:refreshMult(uuid)
    RefreshMultCmd:send2Server(uuid)
end

function CommercialCommands:reqEnemySpeed(uuid)
    ReqEnemySpeedCmd:send2Server(uuid)
end

-------页面-------
function CommercialCommands:reqMineData()
    MineDataCmd:send2Server()
end

function CommercialCommands:reqOtherData()
    OtherDataCmd:send2Server()
end

function CommercialCommands:jumpCamel(uuid)
    JumpCamelCmd:send2Server(uuid)
end

function CommercialCommands:prayCamel(uuid)
    PrayCamelCmd:send2Server(uuid)
end

function CommercialCommands:refreshCamel(configId)
    RefreshCamelCmd:send2Server(configId)
end

function CommercialCommands:continueCamel(uuid)
    ContinueCamelCmd:send2Server(uuid)
end

function CommercialCommands:getMarchTime(uuid)
    MarchTimeCmd:send2Server(uuid)
end

function CommercialCommands:scout(index, uuid, name)
    ScoutCmd:send2Server(index, uuid, name)
end

function CommercialCommands:saveRefresh()
    SaveRefreshCmd:send2Server()
end

function CommercialCommands:miniMap()
    MiniMapCmd:send2Server()
end

function CommercialCommands:getRank()
    RankCmd:send2Server()
end

function CommercialCommands:getReward(rwdIdx)
    RewardCmd:send2Server(rwdIdx)
end

return CommercialCommands