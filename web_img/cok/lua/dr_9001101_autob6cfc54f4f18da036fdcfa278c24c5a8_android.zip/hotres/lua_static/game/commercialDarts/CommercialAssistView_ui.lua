----------------------------
-- Author: Elex
-- Date: 2019-11-21 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CommercialAssistView_ui = class("CommercialAssistView_ui")

--#ui propertys


--#function
function CommercialAssistView_ui:create(owner, viewType, paramTable)
	local ret = CommercialAssistView_ui.new()
	CustomUtility:LoadUi("CommercialAssistView.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CommercialAssistView_ui:initLang()
	LabelSmoker:setText(self.m_titleText, "115151")
	LabelSmoker:setText(self.m_tipTxt1, "115152")
	ButtonSmoker:setText(self.m_cancelBtn, "cancel_btn_label")
	ButtonSmoker:setText(self.m_sendBtn, "115154")
end

function CommercialAssistView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CommercialAssistView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CommercialAssistView_ui:onCancelClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onCancelClick", pSender, event)
end

function CommercialAssistView_ui:onSendClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onSendClick", pSender, event)
end

return CommercialAssistView_ui

