-- @Author: yanwei
-- @Date:   2019-12-05 15:28:28
-- @Last Modified by:   yanwei
-- @Last Modified time: 2019-12-06 11:39:05
--商贸  商店
local MSG_TOOL_CHANGE = "msg.tool.change"
local CommercialStoreView = class('CommercialStoreView', PopupBaseView)

function CommercialStoreView:create()
    local view = CommercialStoreView.new()
    Drequire("game.commercialDarts.CommercialStoreView_ui"):create(view, 1)
    if view:initView() then return view end
end

function CommercialStoreView:ctor()
    self.shopCtrl = Drequire("game.shop.ShopMallController").new(109)
end

function CommercialStoreView:initView()
    if FunOpenController:isUnlock("fun_caravanStore", true) == false then
        return false
    end
    
	self.itemId = 36002353 --道具ID
    self:updateNumber()
    self.shopCtrl:getSellItem()
    self.ui.m_titleTxt:setString(getLang("41576114"))
    return true
end

function CommercialStoreView:initTableViewByOwner()
    local TableViewSmoker = Drequire("Editor.TableViewSmoker")
    TableViewSmoker:createView(self.ui, "m_listTableView", "game.commercialDarts.CommercialStoreCell", 1, 10, "FestivalStoreCell")
end

function CommercialStoreView:updateNumber()
    local comumeItemID = tonumber(self.itemId)
    if comumeItemID > 0 then
        -- self.ui.m_itemPicNode:removeAllChildren()
        -- local pic = CCCommonUtilsForLua:call("getIcon", tostring(comumeItemID))
        -- local icon = CCLoadSprite:call("createSprite", pic, CCLoadSpriteType.CCLoadSpriteType_RESOURCE)
        -- CCCommonUtilsForLua:setSpriteMaxSize(icon, 36, true)
        -- self.ui.m_itemPicNode:addChild(icon)
        CCCommonUtilsForLua:createGoodsIcon(tostring(comumeItemID), self.ui.m_itemPicNode, cc.size(36, 36))
        self.ui.m_itemPicNode:removeChildByTag(GOODS_BG_TAG)

        local tinfo = ToolController:call("getToolInfoForLua", comumeItemID)
        if tinfo == nil then
            return
        end

        local count = tinfo:call("getCNT")
        self.ui.m_itemNumLabel:setString('X' .. count)
    end
end

function CommercialStoreView:updateUI()
    self.itemData = self.shopCtrl:getShopItemInfo()
    -- dump(self.itemData, "self.itemData")
    self.ui:setTableViewDataSource("m_listTableView", self.itemData)
end

function CommercialStoreView:onConfirmBuy(dict)
    local tbl = dictToLuaTable(dict)
    if tbl.shopId and tbl.count then
        self.shopCtrl:buyShopItem(tostring(tbl.shopId), tonumber(tbl.count))
    end
end

function CommercialStoreView:onEnter()
    registerScriptObserver(self,self.updateNumber, MSG_TOOL_CHANGE)
    registerScriptObserver(self, self.updateUI, self.shopCtrl.m_getShopItemnotifyKey)
    registerScriptObserver(self, self.updateUI, self.shopCtrl.m_buyShopItemNotifyKey)
    registerScriptObserver(self, self.onConfirmBuy, "CommercialStore_BuyConfirm")
end

function CommercialStoreView:onExit()
	unregisterScriptObserver(self, MSG_TOOL_CHANGE)
    unregisterScriptObserver(self, self.shopCtrl.m_getShopItemnotifyKey)
    unregisterScriptObserver(self, self.shopCtrl.m_buyShopItemNotifyKey)
    unregisterScriptObserver(self, "CommercialStore_BuyConfirm")
end

return CommercialStoreView