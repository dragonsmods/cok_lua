----------------------------
-- Author: Elex
-- Date: 2019-12-17 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CommercialOtherCell_ui = class("CommercialOtherCell_ui")

--#ui propertys


--#function
function CommercialOtherCell_ui:create(owner, viewType, paramTable)
	local ret = CommercialOtherCell_ui.new()
	CustomUtility:DoRes(0, true)
	CustomUtility:LoadUi("CommercialOtherCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CommercialOtherCell_ui:initLang()
	LabelSmoker:setText(self.m_pLabelTTF9, "41576181")
end

function CommercialOtherCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CommercialOtherCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CommercialOtherCell_ui:onClickGo(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickGo", pSender, event)
end

return CommercialOtherCell_ui

