----------------------------
-- Author: Elex
-- Date: 2020-04-03 Friday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CommercialRankView_ui = class("CommercialRankView_ui")

--#ui propertys


--#function
function CommercialRankView_ui:create(owner, viewType, paramTable)
	local ret = CommercialRankView_ui.new()
	CustomUtility:LoadUi("CommercialRankView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CommercialRankView_ui:initLang()
	LabelSmoker:setText(self.m_titleTxt, "41576275")
	ButtonSmoker:setText(self.m_pageBtn1, "41576276")
	ButtonSmoker:setText(self.m_pageBtn2, "41576277")
	ButtonSmoker:setText(self.m_pageBtn3, "41576278")
end

function CommercialRankView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CommercialRankView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CommercialRankView_ui:onClickTip(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickTip", pSender, event)
end

function CommercialRankView_ui:onClickPage1(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickPage1", pSender, event)
end

function CommercialRankView_ui:onClickPage2(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickPage2", pSender, event)
end

function CommercialRankView_ui:onClickPage3(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickPage3", pSender, event)
end

return CommercialRankView_ui

