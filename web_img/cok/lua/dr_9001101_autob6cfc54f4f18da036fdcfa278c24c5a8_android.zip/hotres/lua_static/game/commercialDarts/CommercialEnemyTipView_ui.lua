----------------------------
-- Author: Elex
-- Date: 2020-11-10 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CommercialEnemyTipView_ui = class("CommercialEnemyTipView_ui")

--#ui propertys


--#function
function CommercialEnemyTipView_ui:create(owner, viewType, paramTable)
	local ret = CommercialEnemyTipView_ui.new()
	CustomUtility:DoRes(100, true)
	CustomUtility:LoadUi("CommercialEnemyTipView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CommercialEnemyTipView_ui:initLang()
	LabelSmoker:setText(self.m_tipTitle, "5504317")
	ButtonSmoker:setText(self.m_btn, "5504335")
end

function CommercialEnemyTipView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CommercialEnemyTipView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CommercialEnemyTipView_ui:onClickBtn(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtn", pSender, event)
end

function CommercialEnemyTipView_ui:onClickSet(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickSet", pSender, event)
end

return CommercialEnemyTipView_ui

