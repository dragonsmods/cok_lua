----------------------------
-- Author: Elex
-- Date: 2020-01-14 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CommercialSelectCell_ui = class("CommercialSelectCell_ui")

--#ui propertys


--#function
function CommercialSelectCell_ui:create(owner, viewType, paramTable)
	local ret = CommercialSelectCell_ui.new()
	CustomUtility:DoRes(0, true)
	CustomUtility:LoadUi("CommercialSelectCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CommercialSelectCell_ui:initLang()
	LabelSmoker:setText(self.m_text3, "105114")
	ButtonSmoker:setText(self.m_recieveBtn, "132112")
end

function CommercialSelectCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CommercialSelectCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CommercialSelectCell_ui:onClickRecieve(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickRecieve", pSender, event)
end

return CommercialSelectCell_ui

