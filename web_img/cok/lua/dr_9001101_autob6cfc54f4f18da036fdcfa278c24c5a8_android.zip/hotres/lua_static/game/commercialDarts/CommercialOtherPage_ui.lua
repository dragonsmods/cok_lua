----------------------------
-- Author: Elex
-- Date: 2019-12-20 Friday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CommercialOtherPage_ui = class("CommercialOtherPage_ui")

--#ui propertys


--#function
function CommercialOtherPage_ui:create(owner, viewType, paramTable)
	local ret = CommercialOtherPage_ui.new()
	CustomUtility:LoadUi("CommercialOtherPage.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function CommercialOtherPage_ui:initLang()
	LabelSmoker:setText(self.m_propText1, "41576030")
	LabelSmoker:setText(self.m_propText2, "41576031")
	LabelSmoker:setText(self.m_propText3, "41576032")
	LabelSmoker:setText(self.m_text4, "41576026")
	LabelSmoker:setText(self.m_text5, "41576029")
	ButtonSmoker:setText(self.m_refreshBtn, "41576215")
end

function CommercialOtherPage_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CommercialOtherPage_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CommercialOtherPage_ui:onClickCheckBox(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickCheckBox", pSender, event)
end

function CommercialOtherPage_ui:onClickFilter1(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickFilter1", pSender, event)
end

function CommercialOtherPage_ui:onClickFilter2(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickFilter2", pSender, event)
end

function CommercialOtherPage_ui:onClickFilter3(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickFilter3", pSender, event)
end

function CommercialOtherPage_ui:onClickFilter4(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickFilter4", pSender, event)
end

function CommercialOtherPage_ui:onClickFilter5(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickFilter5", pSender, event)
end

function CommercialOtherPage_ui:onClickFilter6(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickFilter6", pSender, event)
end

function CommercialOtherPage_ui:onClickFilter7(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickFilter7", pSender, event)
end

function CommercialOtherPage_ui:onClickInfo(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickInfo", pSender, event)
end

function CommercialOtherPage_ui:onClickRefresh(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickRefresh", pSender, event)
end

function CommercialOtherPage_ui:initTableView()
	TableViewSmoker:createView(self, "m_listView", "game.commercialDarts.CommercialOtherCell", 1, 6, "CommercialOtherCell")
end

function CommercialOtherPage_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return CommercialOtherPage_ui

