local CommercialSelectCell = class("CommercialSelectCell", cc.TableViewCell)

function CommercialSelectCell:create(idx, receive)
    local cell = CommercialSelectCell.new(receive)
    Drequire("game.commercialDarts.CommercialSelectCell_ui"):create(cell, 0)
    return cell
end

function CommercialSelectCell:ctor(receive)
    self.receiveCb = receive
end

function CommercialSelectCell:refreshCell(info, idx)
    self.info = info

    self.ui.m_text2:setString(CC_CMDITOA(atoi(info.cost)))
    local discount = atoi(info.discount)
    if discount > 0 and discount < 100 then
        local price = atoi(info.cost) * (discount / 100)
        setLabelReduce(self.ui.m_text2, 1, CC_CMDITOA(price), true)
    else
        setLabelReduce(self.ui.m_text2, 0)
        self.ui.m_goodsNode:setPositionX(550)
        self.ui.m_text2:setPositionX(575)
    end

    if info.configId then
        local desc = CCCommonUtilsForLua:call("getPropByIdGroup", "bodyguard_level", info.configId, "desc")
        self.ui.m_text1:setString(getLang(desc))

        local star = CCCommonUtilsForLua:call("getPropByIdGroup", "bodyguard_level", info.configId, "star")
        local starNode = getStarNode(atoi(star), SCROLLVIEW_DIR_VERTICAL)
        starNode:setAnchorPoint(ccp(0, 1))
        starNode:setScale(0.4)
        self.ui.m_starNode:removeAllChildren()
        self.ui.m_starNode:addChild(starNode)

        local icon = CCCommonUtilsForLua:call("getPropByIdGroup", "bodyguard_level", info.configId, "icon")
        local camelPath = string.format("%s.png", icon)
        local sf = CCLoadSprite:loadResource(camelPath)
        self.ui.m_iconCamel:setSpriteFrame(sf)
    end

    self:onRewardGetback()
end 

function CommercialSelectCell:onRewardGetback()
    local rwd = GlobalData:call("getCachedRewardData", self.info.rewardId)
    local rwdData = arrayToLuaTable(rwd)

    if #rwdData == 0 then return end

    local rewardItems = {}
    for _, rwd in ipairs(rwdData) do
        if rwd.type == "7" then
            rwd.value.type = 0
            table.insert(rewardItems, rwd.value)
        elseif rwd.type == "14" then
            rwd.value.type = 1
            table.insert(rewardItems, rwd.value)
        end
    end
    
    self.ui.m_rewardNode:removeAllChildren()
    
    local scrollView = cc.ScrollView:create()
    local viewSize = self.ui.m_rewardNode:getContentSize()
    scrollView:setViewSize(viewSize)
    scrollView:ignoreAnchorPointForPosition(true)
    scrollView:setDirection(0)
    scrollView:setClippingToBounds(true)
    scrollView:setBounceable(true)

    self.ui.m_rewardNode:addChild(scrollView)

    local isPad = CCCommonUtilsForLua:isIosAndroidPad()
    local contentNode = cc.Node:create()
    local width = 0
    local itemWidth = 58
    for index, reward in ipairs(rewardItems) do
        local itemNode = cc.Node:create()
        local numBg = CCLoadSprite:createSprite("W_tongyongjianbian01.png")
        numBg:setColor(cc.c3b(0, 0, 0))
        numBg:setScale(0.6, 0.6)
        numBg:ignoreAnchorPointForPosition(true)
        numBg:setAnchorPoint(ccp(0, 0))
        numBg:setPosition(-itemWidth / 2, -itemWidth / 2)
        
        local numLabel = cc.Label:createWithSystemFont("", "Helvetica", 12, cc.size(0.0,0))
        numLabel:setAnchorPoint(ccp(1, 0))
        numLabel:setHorizontalAlignment(cc.TEXT_ALIGNMENT_RIGHT)
        numLabel:setPosition(itemWidth / 2, -itemWidth / 2)
        numLabel:ignoreAnchorPointForPosition(false)

        LibaoCommonFunc.createDataItemTouchNode(
            {
                itemData = {
                                type = reward.type,
                                itemId = atoi(reward.id),
                                num = atoi(reward.num),
                                desScale = isPad and 1.8 or 1,
                            },
                iconNode = itemNode,
                iconSize = itemWidth - 4,
                numLabel = numLabel,
                beTouch = true,
                touchParentNode = self.ui.m_rewardNode,
            }
        )
        itemNode:setPosition((index - 0.5) * itemWidth, itemWidth / 2)
        itemNode:addChild(numBg)
        itemNode:addChild(numLabel)
        contentNode:addChild(itemNode)
        width = width + itemWidth
    end

    scrollView:addChild(contentNode)
    scrollView:setContentSize(CCSize(width, viewSize.height))
    if width <= viewSize.width then
        scrollView:setTouchEnabled(false)
    else
        scrollView:setTouchEnabled(true)
    end
end

function CommercialSelectCell:getGuideNode()
    return self.ui.m_recieveBtn
end

function CommercialSelectCell:onEnter()
    registerScriptObserver(self, self.onRewardGetback, "MSG_GET_REWARD_DETAIL_BACK")
end

function CommercialSelectCell:onExit()
    unregisterScriptObserver(self, "MSG_GET_REWARD_DETAIL_BACK")
end

function CommercialSelectCell:onClickRecieve()
    if GuideController:call("isInTutorial") then
        CCSafeNotificationCenter:call("postNotification", GUIDE_INDEX_CHANGE, CCString:create("commercial_pick"))
    end

    local cost = atoi(self.info.cost)
    local discount = atoi(self.info.discount)
    if discount > 0 and discount < 100 then
        cost = cost * (discount / 100)
    end

    if cost > GlobalData:call("getPlayerInfo"):getProperty("gold") then
        YesNoDialog:call("gotoPayTips")
        return
    end

    local function confirm()
        if self.receiveCb then self.receiveCb(self.info.configId) end
    end

    if cost > 0 then
        local mineUid = PlayerInfoController:getUid()
        -- YesNoDialog:show(getLang("41576214", CC_CMDITOA(cost)), confirm)
        local params = {}
        params.callback = confirm
        params.title = getLang("41576214", CC_CMDITOA(cost))
        params.desc = getLang("41576319")
        params.setKey = string.join("", "CommercialStop", mineUid)

        --重置接镖停留驿站设置
        cc.UserDefault:getInstance():setBoolForKey(params.setKey, true)
        cc.UserDefault:getInstance():flush()

        local view = Drequire("game.CommonPopup.CommonSetTipView"):create(params)
        PopupViewController:addPopupView(view)
    else
        confirm()
    end
end

return CommercialSelectCell