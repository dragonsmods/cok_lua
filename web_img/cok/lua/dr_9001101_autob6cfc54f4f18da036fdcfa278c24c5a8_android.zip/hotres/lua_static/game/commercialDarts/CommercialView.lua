local CommercialView = class("CommercialView", PopupBaseView)

function CommercialView:create(page)
    local view = CommercialView.new(page)
    view.isPadScale = 1
    --ipad pro11适配
    local platForm = SysUtiliesInLua:call("getDevicePlatformInfo") 
    if "iPad Pro (11-inch)" == platForm then
        view.isPad = true
    end

    CCLoadSprite:call("loadDynamicResourceByName", "commercial_face")
    Drequire("game.commercialDarts.CommercialView_ui"):create(view, 1)
    if view:initView() then return view end
end

function CommercialView:ctor(page)
    self.m_page = page
end

function CommercialView:initView()
    if self.m_page == 1 then
        self:onClickMine()
    else
        self:onClickOther()
    end
    
    return true
end

function CommercialView:onEnter()
    registerScriptObserver(self, self.close, "COMMERCIAL_RECEIVE")
    registerScriptObserver(self, self.close, "COMMERCIAL_JUMP")
end

function CommercialView:onExit()
    unregisterScriptObserver(self, "COMMERCIAL_JUMP")
    unregisterScriptObserver(self, "COMMERCIAL_RECEIVE")
end

function CommercialView:close()
    self:call("closeSelf")
end

function CommercialView:onClickMine()
    self.ui.m_mineBtn:setEnabled(false)
    self.ui.m_otherBtn:setEnabled(true)

    if not self.minePage then
        local parentSize = self.ui.m_listNode:getContentSize()
        self.minePage = Drequire("game.commercialDarts.CommercialMinePage"):create(parentSize)
        self.ui.m_listNode:addChild(self.minePage)
    end

    self.minePage:setVisible(true)
    if self.otherPage then self.otherPage:setVisible(false) end
end

function CommercialView:onClickOther()
    local isInAlliance = GlobalData:call("getPlayerInfo"):call("isInAlliance")
    if not isInAlliance then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("106204"))
        self:onClickMine()
        return
    end

    self.ui.m_mineBtn:setEnabled(true)
    self.ui.m_otherBtn:setEnabled(false)

    if not self.otherPage then
        local parentSize = self.ui.m_listNode:getContentSize()
        self.otherPage = Drequire("game.commercialDarts.CommercialOtherPage"):create(parentSize)
        self.ui.m_listNode:addChild(self.otherPage)
    end

    self.otherPage:setVisible(true)
    if self.minePage then self.minePage:setVisible(false) end
end

function CommercialView:onClickTip()
    FaqHelper:call("showSingleFAQ", "45310")
end

function CommercialView:getGuideNode(key)
    Dprint("CommercialView:getGuideNodeByKey", key)
    if key == "commercial_pick"     
        or key == "commercial_help"
        or key == "commercial_bless" 
        or key == "commercial_refresh" then
        if self.minePage then
            return self.minePage:getGuideNode(key)
        end
    elseif key == "commercial_jump" then
        if self.otherPage then
            return self.otherPage:getGuideNode(key)
        end
    end
end

return CommercialView