ArmedRankControllerInLua = class("ArmedRankControllerInLua")


function ArmedRankControllerInLua:getArmedLevelName( level )
	if level == 0 then
		return ""
	end
	local curCiviType = CivilizationController:getCivilizationType()
	local xmlData = CCCommonUtilsForLua:getGroupByKey("wr_rank")
	for k,v in pairs(xmlData) do
		-- MyPrint("ArmedRankControllerInLua:getArmedLevelName~~~~~~", v.id, (((tonumber(v.id)-tonumber(v.id)%100)/100)%10) )
		if ((tonumber(v.level) == level) and ( (((tonumber(v.id)-tonumber(v.id)%100)/100)%10) == curCiviType-1)) then --id倒数第二位表示文明类型
			return getLang(v.name)
		end
	end
	return ""
end

function ArmedRankControllerInLua:getGroupTblById(nowGroupId)
    local skillTbl = CCCommonUtilsForLua:getGroupByKey("wr_skill")
    if nil == self.m_xmlTbl then
        self.m_xmlTbl = {}
        for k,v in pairs(skillTbl) do
            if nil == self.m_xmlTbl[tonumber(v.group)] then
                self.m_xmlTbl[tonumber(v.group)] = {}
            end
            self.m_xmlTbl[tonumber(v.group)][tonumber(v.level)] = v
        end
    end
    return self.m_xmlTbl[tonumber(nowGroupId)]
end

function ArmedRankControllerInLua:setGotSkill( tempStr )
	-- 9;20020081|11;20020110|12;20020120
	self.m_gotSkillTbl = {}
    local tempTbl = string.split(tempStr, "|")
    for k,v in pairs(tempTbl) do
        local tempGotTbl = string.split(v, ";")
        self.m_gotSkillTbl[tempGotTbl[2]] = tempGotTbl[1]
    end
end

function ArmedRankControllerInLua:getGotSkill(  )
	return self.m_gotSkillTbl or {}
end

return ArmedRankControllerInLua