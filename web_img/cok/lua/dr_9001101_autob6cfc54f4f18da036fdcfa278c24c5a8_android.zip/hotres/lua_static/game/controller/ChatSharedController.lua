local ChatSharedController = {}

local touchMsgFunc = {}
local function touchHelpMakexxxFunc(keyTbl)
    -- dump(keyTbl,"touchHelpMakexxxFunc", 10)
    local idStr = keyTbl[2]
    local idInfo = string.split(idStr, ";")
    local toUid = idInfo[1]
    local time = idInfo[2]
    local goodsId = idInfo[3]
    local actId = idInfo[4]
    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
    local myUid = playerInfo:getProperty("uid")
    if myUid == toUid then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("110231")) --110231=无法向自己赠送哦！
        return true
    end
    require("game.FestivalActivities.FestivalActivitiesMakexxxController").getInstance():confirmSendGoods(toUid,time,goodsId,actId)
    return true
end

local function touchHelpMakePilafFunc(keyTbl)
    -- dump(keyTbl,"touchHelpMakePilafFunc", 10)
    local idStr = keyTbl[2]
    local idInfo = string.split(idStr, ";")
    local toUid = idInfo[1]
    local time = idInfo[2]
    local goodsId = idInfo[3]
    local actId = idInfo[4]
    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
    local myUid = playerInfo:getProperty("uid")
    if myUid == toUid then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("110231")) --110231=无法向自己赠送哦！
        return true
    end
    require("game.FestivalActivities.FestivalActivitiesMakexxxController").getInstance():confirmSendGoods(toUid,time,goodsId,actId)
    return true
end

touchMsgFunc[Chat_Key_reqHelpMakexxx] = touchHelpMakexxxFunc
touchMsgFunc["reqHelpMakePilaf"] = touchHelpMakePilafFunc

function ChatSharedController.touchMsg(keyTbl)
    if touchMsgFunc[keyTbl[1]] then
        touchMsgFunc[keyTbl[1]](keyTbl)
	elseif keyTbl[1] == "activityShared_57133" then
		local act = ActivityController:call("getActObj", "57133")
		local result = false
		if act then
			local time = getWorldTime()
			local endTime = tonumber(act:getProperty("endTime"))
			local startTime = tonumber(act:getProperty("startTime"))
            if endTime > time and startTime <= time then
            	-- ActivityController:call("shouActUIById", "57133")
                ActivityController.getInstance():shouActUIById("57133")
	        end
		end
	elseif keyTbl[1] == "civiMiracleShare" or keyTbl[1] == "flushBoss" or keyTbl[1] == "setAllianceBoss" or keyTbl[1] == "festivalVisitType" then
        if keyTbl[2] then
            if(string.find (keyTbl[2], "\"")) then
                keyTbl[2] = string.sub(keyTbl[2], 2, #keyTbl[2]-1)
            end
            WorldController:call("getInstance"):setProperty("openTargetIndex", atoi(keyTbl[2]))
            
            local point = WorldController:call("getPointByIndex", atoi(keyTbl[2]))
            if SceneController:call("getCurrentSceneId") == 11 then
                WorldMapView:call("gotoTilePoint", point)
            else
                local posIndex = WorldController:call("getIndexByPoint", point)
                SceneController:call("gotoScene", 11, false, true, tonumber(keyTbl[2]))
            end
            PopupViewController:call("forceClearAll", true)
        end
    elseif keyTbl[1] == "fourthAnniversaryBless" then
        --1.key 2.id 3.跳转类型：1跳转活动 2赠送
        local FourthAnniversaryBlessData = require("game.activity.FourthAnniversary.FourthAnniversaryBlessData").getInstance()
        if not FourthAnniversaryBlessData:isActiveOpen() then
            CCCommonUtilsForLua:call("flyHint","","",getLang("146313"))
            return
        end
        if keyTbl[2] then
            dump(keyTbl[2],"hxq keyTbl[2] is")
            local idStr = keyTbl[2]
            local idInfo = string.split(idStr, ";")
            local playerInfo = GlobalData:call("shared"):getProperty("playerInfo") --该玩家信息
            local to_uid = idInfo[1]  --被赠送玩家uid
            local timeStamp = idInfo[2] --记录时间戳
            local goodsId = idInfo[3] --物品id
            local myUid = playerInfo:getProperty("uid")

            --如果是自己点击
            if myUid == to_uid then
                CCCommonUtilsForLua:call("flyHint", "", "", getLang("110231"))
                return
            end
            
            local toolInfo = ToolController:call("getToolInfoForLua",tonumber(goodsId))
            
            if toolInfo then
                local toolNum = toolInfo:call("getCNT")
                if toolNum < 1 then
                    FourthAnniversaryBlessData:showGetToolView(tonumber(goodsId))
                    return
                end
            end
            
            local function callBack(param)
                local data = dictToLuaTable(param)
                local name = data.userName --此处根据uid获取联盟成员一人的name
                if nil == name then --1:已过时，有人已经赠送
                    LuaController:flyHint("","",getLang("110236"))
                else
                    FourthAnniversaryBlessData:openMailWritePopupViewByChatRoom(name,to_uid,timeStamp,goodsId)
                end
            end
            --聊天测试，暂时关闭
            FourthAnniversaryBlessData:shareBlessConfirmCommand(to_uid,timeStamp,callBack)

        end
        -- dump("hxq ----------------------")
    elseif keyTbl[1] =="fourthAnniversaryGold" then
        --跳转到活动
        local FourthAnniversaryBlessData = require("game.activity.FourthAnniversary.FourthAnniversaryBlessData").getInstance()
        if FourthAnniversaryBlessData:isActiveOpen() then
            local view = Drequire("game.activity.FourthAnniversary.FourthAnniversaryView"):create(3)
            PopupViewController:addPopupView(view)
        else
            CCCommonUtilsForLua:call("flyHint","","",getLang("146313"))
        end
    elseif keyTbl[1] == "fourthAnniversaryCake" then
        Drequire("game.JumpPageController"):jump2CommonPage( {mainViewId="FourthAnniversaryView", subViewId="2"} )
    elseif keyTbl[1] == "MarchFormationView" then
        dump(keyTbl,"hxq chat MarchFormationView+++")
        -- local strParam = keyTbl[2]
        -- local strTbl = string.split(strParam,";")
        -- local fromUid = strTbl[1]
        -- local index = strTbl[2]
        -- dump(fromUid,"hxq fromUid is")
        -- dump(index,"hxq index is")
        if not CCCommonUtilsForLua:isFunOpenByKey("march_queue_polish_share") then
            CCCommonUtilsForLua:call("flyHint","","",getLang("146313"))
            return
        end
        local dict = CCDictionary:create()
        dict:setObject(CCString:create("MarchFormationView"), "name")
        dict:setObject(CCString:create("-1"), "index") --先给个默认值
        LuaController:call("openPopViewInLua", dict)

        --数据整理
        local soldierInfo = keyTbl[2]
        local troopName = keyTbl[3]
        local mode = keyTbl[4]
        local heroId = ""
        local dragonId = ""
        if #keyTbl == 5 then
            local paramTbl = string.split(keyTbl[5],":")
            if paramTbl[1] == "hero" then
                heroId = paramTbl[2]
            else
                dragonId = paramTbl[2]
            end
        elseif #keyTbl == 6 then
            local paramTbl1 = string.split(keyTbl[5],":")
            dragonId = paramTbl1[2]
            local paramTbl2 = string.split(keyTbl[6],":")
            heroId = paramTbl2[2]
        end

        local dict2 = CCDictionary:create()
        --一共5项
        dict2:setObject(CCString:create(soldierInfo),"soldierInfo")
        dict2:setObject(CCString:create(troopName),"troopName")
        dict2:setObject(CCString:create(mode),"mode")
        dict2:setObject(CCString:create(dragonId),"dragonId")
        dict2:setObject(CCString:create(heroId),"heroId")
        CCSafeNotificationCenter:postNotification("msg_chat_marchFormation",dict2)
    elseif keyTbl[1] == "kingonlogin" then
        if #keyTbl >= 2 then
            local dict = CCDictionary:create()
            dict:setObject(CCString:create("GeneralsPopupView"), "name")
            dict:setObject(CCString:create(keyTbl[2]), "uid")
            LuaController:call("openPopViewInLua", dict)
        end
    elseif keyTbl[1] == "openWebActivityView" then
        local view = Drequire("game.activity.web.WebActivityView"):create()
        PopupViewController:addPopupInView(view)
    elseif keyTbl[1] == "ChatFavorShare" then
        local vec1 = string.split(keyTbl[2],",")
        local serverId = tonumber(string.split(vec1[1],"#")[2])
        local vec2 = string.split(vec1[2],":")
        local point = cc.p(tonumber(vec2[1]),tonumber(vec2[2]))
        WorldController:call("getInstance"):setProperty("openTargetIndex", WorldController:call("getIndexByPoint", point))
        if SceneController:call("getCurrentSceneId") == 11 and WorldMapView:call("instance") ~= nil then
            if serverId == GlobalData:call("getPlayerInfo"):getProperty("currentServerId") then
                WorldMapView:call("gotoTilePoint", point, true)
            else
                WorldMapView:call("gotoTilePoint1", point, serverId, true)
            end
        else
            if serverId == GlobalData:call("getPlayerInfo"):getProperty("currentServerId") then
                SceneController:call("gotoScene", 11, false, true, WorldController:call("getIndexByPoint", point))
            else
                GlobalData:call("getPlayerInfo"):setProperty("currentServerId", serverId)
                SceneController:call("gotoScene", 11, false, true, WorldController:call("getIndexByPoint", point))
            end
        end
        PopupViewController:call("forceClearAll", true)
    elseif keyTbl[1] == "AllianceAFHShare" then
        local myUid = GlobalData:call("shared"):getProperty("playerInfo"):getProperty("uid")
        local targetUid = keyTbl[2]
        if myUid ~= targetUid then
            local dict = CCDictionary:create()
            dict:setObject(CCString:create("AllianceWarView"), "name")
            LuaController:call("openPopViewInLua", dict)
        else
            CCCommonUtilsForLua:call("flyHint","","",getLang("610011"))  
        end          

    elseif keyTbl[1] == "LuckyReturnWantAlliance" then
        local uid = keyTbl[2]
        if uid and uid ~= "" then
            local playerInfo = GlobalData:call("getPlayerInfo")
            local myUid = playerInfo:getProperty("uid")
            if uid ~= myUid then
                local allianceInfo = playerInfo:getProperty("allianceInfo")
                local rank = allianceInfo:getProperty("rank")
                if rank > 3 then
                    local cmd = Drequire("game.command.InvitesAllianceCommand"):create(uid)
                    cmd:send()
                else
                    CCCommonUtilsForLua:call("flyHint", "", "", getLang("E100119"))
                end
            end
        end
    elseif keyTbl[1] == "Chat_Key_FestivalActBalloonWar" then
       --dump(keyTbl,"Chat_Key_FestivalActBalloonWar-------",10)
        ----气球大战
            if keyTbl[2]  and   keyTbl[2]~= "" then
                local param = string.split( keyTbl[2],";") 
                 
                if #param < 2 then
                    return
                end
                local FestivalActivitiesCtl =  require("game.FestivalActivities.FestivalActivitiesController").getInstance()
                 if not FestivalActivitiesCtl:isActivityOpenById(param[1]) or CCCommonUtilsForLua:isFunOpenByKey("fiveballoon")  then
                    
                    return
                 end
            
                 local point = tonumber(param[2])
                 CCCommonUtilsForLua.jumpToTarget(11,point)
             

            end
           
            
    elseif keyTbl[1] == "Chat_Key_FestivalBanquetAlliance" then
        ----犒赏三军
        require("game.FestivalActivities.FestivalActivitiesBanquetController"):getInstance():openActivityView()
    elseif keyTbl[1] == "Chat_Key_QueenWorldCupJoin" then
        ----女王世界杯
        local view = Drequire("game.QueenWorldCup.QueenWorldCupView"):create()
        PopupViewController:addPopupInView(view)
    elseif keyTbl[1] == "FortuneChatShare" then
        require("game.Fortune.FortuneController").getInstance():jumpToTarget(keyTbl[2])
    elseif keyTbl[1] == "FortuneChatAskHelp" then
        require("game.Fortune.FortuneController").getInstance():touchShareMsg(keyTbl[2])
    elseif keyTbl[1] == "CommercialChatPray" or keyTbl[1] == "CommercialChatHelp" then
        require("game.commercialDarts.CommercialController").getInstance():touchShareMsg(keyTbl[1], keyTbl[2])
    elseif keyTbl[1] == "FlowerNotifyHelp" then
        require("game.flower.FlowerController").getInstance():touchShareMsg(keyTbl[2])
    elseif keyTbl[1] == "LibaoGroupBuyAlli" then
        require("game.LiBao.GroupBuy.LibaoGroupBuyMgr").getInstance():touchShareMsg(keyTbl[2])
    elseif keyTbl[1] == "SkinActMsg" then
        require("game.WelfareIntegrate.integrateSkinAct.integrateSkinActMgr").getInstance():touchShareMsg(keyTbl[2])
    end
end


ChatSharedController.ChannelMsgType = {
    CHANNEL_TYPE_COUNTRY = 0,
    CHANNEL_TYPE_ALLIANCE = 1,
    CHANNEL_TYPE_USER = 2,
    CHANNEL_TYPE_CHATROOM = 3,
    CHANNEL_TYPE_OFFICIAL = 4,
    CHANNEL_TYPE_ALLIANCE_SHARE = 5,
    CHANNEL_TYPE_CUSTOM_CHAT = 6,
    CHANNEL_TYPE_BATTLE = 7,
}

function toChatString(str)
    if str == nil then
        return nil
    end
    return "\""..tostring(str).."\""
end

-- channel 分享的频道， 
-- dialog对应字段数据
-- param 字段参数 = {
-- 	{
--        "type":0,   0，纯字符串
--        "text":"type 0 is just a text"
--    },
--    {
--        "type":1,    不懂
--        "xmlId":"545257",
--        "proName":"monsterId"
--    },
--    {
--        "type":2,     2是dialog
--        "dialog":"104564"
          -- "textColor" : "0:0:255"
--    }
--  }
-- 
-- channel分享类型基础为联盟和国家
-- dialog 分享内容的主dailog 
-- param 分享内容的参数，例如 aaa{0}bbb{1}ccc，中的0和1
-- key为回调key值
-- info 为给消息携带的参数，可在touchMsg中的keyTbl中获取
-- touchMsg参数keyTbl[1]为 key，keyTbl[2]为info
-- 
-- 示例
-- local param = {
--     {
--         type = 0,
--         text = tostring(needNum),
--     },
--     {
--         type = 2,
--         dialog = tostring(self.nextRewardInfo.name),
--     },
-- }
-- local chat = require("game.controller.ChatSharedController")
-- chat.onSharedChatDialog(chat.ChannelMsgType.CHANNEL_TYPE_ALLIANCE, "152010", param, "activityShared_57133")
function ChatSharedController.onSharedChatDialog(channel, dialog, param, key, info)
	dialog = tostring(dialog)
    local msg = getLang(dialog)
    -- std::string attachmentId = "{\"description\":{\"useDialog\":true,\"text\":\""+shareDialog+"\"},\"actionArgs\":[\""+info+"\"]}";
    local attachmentTbl = {
    	description = {
    		useDialog = true,
    		text = dialog,
    		dialogExtra = param
    	},
    	actionArgs = {
    		key,
    		info,
    	},
	}
	local json = require("CommonLib.dkjson")
	local attachmentId = json.encode(attachmentTbl)
	dump("attachmentId is: "..tostring(attachmentId))

    -- 暂未完成，先注掉
    local post = 32. --发到小喇叭
    if key == "fourthAnniversaryBless" 
        or key == Chat_Key_reqHelpMakexxx 
        or key == "civiMiracleShare" 
        or key == "setAllianceBoss" 
        or key == "reqHelpMakePilaf"
        or key == "AllianceAFHShare"
        or (channel == ChatSharedController.ChannelMsgType.CHANNEL_TYPE_ALLIANCE and key == "Chat_Key_FestivalActBalloonWar")
        or key == "Chat_Key_FestivalBanquetAlliance"
        or key == "Chat_Key_QueenWorldCupJoin"
        or key == "FortuneChatShare"
        or key == "FortuneChatAskHelp"
        or key == "CommercialChatPray"
        or key == "CommercialChatHelp"
        or key == "festivalVisitType"
        or key == "FlowerNotifyHelp"
        or key == "LibaoGroupBuyAlli"
        then
        post = 34    --联盟联盟聊天频道     国家系统消息展示
    elseif key == "LuckyReturnWantAlliance" 
         or (channel == ChatSharedController.ChannelMsgType.CHANNEL_TYPE_COUNTRY and key == "Chat_Key_FestivalActBalloonWar")
         then
        post = 35   --联盟系统消息  国家普通消息
    end
	ChatController:call("getInstance"):call("sendCountryOldChatFromStandalone", channel, post, msg, dialog, "", attachmentId);
end

--新版聊天通用消息格式V2019
--说明参考  https://git.elex-tech.com/opt-connect/document/wikis/聊天通用消息格式V2019
function ChatSharedController.onSharedChatDialogV2019(tData)
    if type(tData) ~= "table" then return end

    local json = require("CommonLib.dkjson")
    local jsonStr = json.encode(tData)

    local dict = CCDictionary:create()
    dict:setObject(CCString:create(jsonStr), "jsonStr")
    dict:setObject(CCString:create("sendMessageCommonMethod"), "name")
    LuaController:call("openPopViewInLua", dict)
end


local clickHandler2019 = {}
function ChatSharedController.handleClickCommonMessage(param)
    local json = require("CommonLib.dkjson")
    local pData = json.decode(param)
    --别加if-else了，加表里
    if clickHandler2019[pData.key] then
        clickHandler2019[pData.key](pData)
        return
    end
    if pData.key == "GodGiftHelp" then
        require("game.WelfareIntegrate.godGift.GodGiftController").getInstance():handleClickMessage(pData)
    elseif pData.key == "CommercialChatPray" or pData.key == "CommercialChatHelp" then
        require("game.commercialDarts.CommercialController").getInstance():handleClickMessage(pData)
    elseif pData.key == "OpenGranary" then --开仓放粮
        require("game.OpenGranary.OpenGranaryController").getInstance():handleClickMessage(pData)
    elseif  pData.key == "BellShareChat" then
         require("game.FestivalActivities.FestivalActBellNodeCtr").getInstance():handleClickMessage(pData)
    elseif  pData.key == "makeDumplingShare" then
         require("game.activity.RamadanActivity.FestivalActMakeDumplingsCtr").getInstance():handleClickMessage(pData)

    elseif pData.key == "visiteSiteShare" then
         require("game.FestivalActivities.FestivalActVisiteSiteCtr").getInstance():handleClickMessage(pData)

    elseif pData.key == "openFightDeathList" or pData.key == "openFightDeathReady" then --领主死斗
        require("game.fightDeath.FightDeathController").getInstance():handleClickMessage(pData)
    elseif pData.key == "FortuneHelp" then
        require("game.Fortune.FortuneController").getInstance():handleClickMessage(pData)
    elseif pData.key == "FortuneNotifyChatShareNew" then
        require("game.Fortune.FortuneController").getInstance():handleClickShareMessage(pData)
    elseif pData.key == "LibaoGroupBuyAlli" then
        require("game.LiBao.GroupBuy.LibaoGroupBuyMgr").getInstance():handleClickMessage(pData)
    elseif pData.key == "FoXiaoBattle_share"then
         require("game.FestivalActivities.FestivalActivitiesFoXiaoBattleCtr").getInstance():handleClickMessage(pData)
    elseif pData.key == "AllianceMarkAdd" then -- 联盟标记
        require("game.WorldMapView.AllianceMark.AllianceMarkController").getInstance():handleClickMessage(pData)
    elseif pData.key == "BattleRallyMessage" then
        -- 出征没有Controller，直接写在这里
        local teamUuid = pData.teamUuid
        if teamUuid then
            local view_dict = CCDictionary:create()
            view_dict:setObject(CCString:create("AllianceWarDetailView"), "name")
            view_dict:setObject(CCString:create(tostring(pData.specialMass)), "specialMass")
            view_dict:setObject(CCString:create(teamUuid), "teamUuid")
            LuaController:call("openPopViewInLua", view_dict)
        end   
    elseif  pData.key == "FestivalActPuzzle_share" then 
        require("game.FestivalActivities.SixAnniversary.FestivalActPuzzleCtr").getInstance():handleClickMessage(pData)
    elseif pData.key == "SkinActMsg" then
        require("game.WelfareIntegrate.integrateSkinAct.integrateSkinActMgr").getInstance():handleClickMessage(pData)
    elseif pData.key == "ChristmasAgg" then
        require("game.activity.ChristmasGift.ChristmasGiftMgr").getInstance():handleClickMessage(pData)
    elseif pData.key == "BargainKing" then --砍价王
        require("game.FestivalActivities.BargainKing.BargainKingController").getInstance():handleClickMessage(pData)
    end
end

----------------------------clickHandler2019---------------------
clickHandler2019.knightTeamInviteKey = function (t)
    --验证消息有效性
    local ctl
    if t.activityId then
        ctl = require("game.knightActivity.KnightActivityController"):getInstance():getSubActControllerById(t.activityId)
    end
    if ctl then
        ctl:handlerMessageClick(t)
    end
end

clickHandler2019.NEW_INVITE_FRIENDS_CHAT = function (t)
    --验证消息有效性
    local ctl = require("game.callFriends_v2.inviteFriends.InviteFriendsController"):getInstance()
    if ctl then
        ctl:handlerMessageClick(t)
    end
end

return ChatSharedController
