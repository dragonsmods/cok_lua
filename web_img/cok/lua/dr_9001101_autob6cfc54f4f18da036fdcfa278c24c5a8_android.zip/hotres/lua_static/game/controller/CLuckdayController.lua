CLuckdayController = CLuckdayController or {}

function CLuckdayController.getInstance(  )
	return CLuckdayController:call("getInstance")
end

function CLuckdayController:isInHighTechLuckyDay(  )
	if self:call("checkLuckyDayType", 9) == false then
		return false
	end

	local leftTime = self:call("getRemainTimes")
	if leftTime <= 0 then
		return false
	end

	return true
end