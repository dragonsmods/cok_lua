-- 管理出征界面增益、技能、作用号等信息
local BattleViewActiveBuffController = class("BattleViewActiveBuffController")
local _instance = nil

function BattleViewActiveBuffController.getInstance()
    if not _instance then
    	_instance = BattleViewActiveBuffController.new()
    end

    return _instance
end

function BattleViewActiveBuffController:purge()
	if _instance then
		_instance = nil 
	end
end

function BattleViewActiveBuffController:ctor()
    self.m_buff_info = {}
end

function BattleViewActiveBuffController:sendBuffCommand(params)
    local cmd = Drequire("game.command.BattleViewBuffCommand").create(params)
    cmd:send()
end

function BattleViewActiveBuffController:updateBuffInfo(params)
    self.m_buff_info = params
    -- dump(self.m_buff_info, "updateBuffInfo m_buff_info")
end

function BattleViewActiveBuffController:getBuffInfo()
	return self.m_buff_info
end


return BattleViewActiveBuffController
