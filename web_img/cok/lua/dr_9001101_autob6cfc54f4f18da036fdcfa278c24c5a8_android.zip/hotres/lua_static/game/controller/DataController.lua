--@author:MM
--@date:2017.07.03
--@desc:类似GlobalData，用来放置普通数据。

--#pre decl
local Drequire = Drequire
local Dprint = Dprint

DataController = DataController or {}

DataController.isAddict = false --是否被防沉迷，默认no。android
DataController.isAuth = true --是否已实名认证，默认yes。android
DataController.realName = 0 --是否需要实名验证，默认不需要实名验证。ios
--MM: 测试版
-- DataController.isAddict = true --是否被防沉迷
-- DataController.isAuth = false --是否已实名认证

--以后不建议把控制类单例赋值给DataController  
--然后在其他地方通过DataController取控制类 
--因为切号不会重新require这个文件  
--控制类里面的保存数据可能是上一个号的数据   
--建议哪里用哪里用getInstance去取
--suhongping
function DataController.initController()
	if DataController.m_hadInit then
		return 
	end
	DataController.m_hadInit = true
	GreenServerGlobalData = require("game.greenServer.GreenServerGlobalData").getInstance()--怀旧服全局数据类
	PlayerInfoController = require("game.controller.PlayerInfoController").new()		-- 新增的player信息
	LuaWorldController = require("game.WorldMapView.LuaWorldController").new()
	GrowthFundController = require("game.LiBao.GrowthFundController").new()
	GoldVowController = require("game.LiBao.GoldVow.GoldVowController").new()
	NewRecallController = require("game.activity.NewRecall.NewRecallController").new()
	CivilizationController = require("game.civilization.CivilizationController").new()
	CivFortressController = require("game.CivFortress.CivFortressController").new()		-- 文明堡垒
	CivFortress2Controller = require("game.CivFortress2.CivFortress2Controller").new()	--【Awen】文明堡垒分城
	ActivityPageController = require("game.activity.ActivityPage.ActivityPageController").new()		-- 右上活动页控制类
	RechargeLegendController = require("game.RechargeLegend.RechargeLegendController").new() 
	HeroLuckDrawController = require("game.hero.LuckDraw.HeroLuckDrawController").new()				-- 英雄抽卡
	LibaoLocalizationController = require("game.LiBao.LibaoLocalizationController").new()			--礼包本图本地化	
	FeedBackController = require("game.FeedBack.FeedBackController").new()			--灰度逻辑处理
	AuctionHouseController = require("game.CommonPopup.AuctionHouse.AuctionHouseController").new()
	DressIntroductionController = require("game.DressIntroduction.DressIntroductionController").new()
	--MonthFundController = require("game.CommonPopup.MonthFundView.MonthFundController").new()
	DuoBaoActivityController = require("game.activity.DuoBaoActivity.DuoBaoActivityController").new()
	FuMoController = require("game.FuMo.FuMoController").new()
	MagicLuckDrawController = require("game.magic.LuckDraw.MagicLuckDrawController").new()				-- 魔法学院
	PermitCommandController = require("game.setting.PermitCommandController").new()				-- 首弹声明
	SakuraTreeController = require("game.activity.SakuraTree.SakuraTreeController").new()				-- 樱花树
	TacticalDepController = require("game.TacticalDeploy.TacticalDepController")--阵法
	FormationTrainCtr = require('game.formationTrain.FormationTrainCtr')--新阵法
	COSDataController = require("game.activity.CallOfSoldiresAct.COSDataController")--士兵消耗活动
	UserSettingController = require("game.setting.UserSettingController")--游戏选项控制类
	ActBossControllerInst = require("game.controller.ActBossController").getInstance()--年兽集结
	ActivityCalendarCtrlInst = require("game.controller.ActivityCalendarController").getInstance()--日历改版
	MoveDailyActiveCtrlInst = require("game.controller.MoveDailyActiveController").getInstance()--每日任务挪移
	ThemeMonthControllerInst = require("game.controller.ThemeMonthController").getInstance()--主题月
	DragonWarmUpManager = require("game.dragonWarmUpBattle.DragonWarmUpManager").getInstance()--巨龙演武场
	TournamentControllerInst = require("game.tournament.TournamentController").getInstance()--新版竞技场
	PinnacleControllerInst = require("game.tournament.pinnacle.PinnacleController").getInstance() --巅峰竞技场
	-- LongScheduleControllerInst = require("game.controller.LongScheduleController").getInstance()--长时间间隔调度
	CityNpcController = require("game.activity.AllianceQuicklyKillMonster.CityNpcController") --主城npc
	AvatarBuffController = require("game.avatar.avatarBuff.AvatarBuffController").new()
	FunOpenController = require("game.controller.FunOpenController").new()  --【Awen】功能开关控制类
	DataController.GoldBasinControllerInst = require("game.activity.GoldBasin.GoldBasinController").getInstance()--聚宝盆活动
	ConvertHappyFestivalContrllerInst = require("game.shop.ConvertHappyFestivalContrller").getInstance()  --转移节日狂欢控制类
	DataController.ModifyRechargeContinueControllerInst = require("game.activity.RechargeContinuous.ModifyRechargeContinueController").getInstance()  --连续充值新版
	DataController.DoubleGiftMgrInst = require("game.activity.DoubleGifts.DoubleGiftMgr").getInstance()  --豪礼双享控制类
	DataController.DragonSoulChaserMgrInst = require("game.activity.DragonSoulChaser.DragonSoulChaserMgr").getInstance()  --龙魂夺宝控制类
	DataController.ExtensionDataController = require("game.buildExtension.ExtensionDataController").getInstance()--新城建控制类
	DataController.LuaEffectController = require("game.controller.LuaEffectController").getInstance()--Lua端系统作用号维护类
	-- DataController.AlchemyHouseController = require("game.workShop.AlchemyHouseController").getInstance()
	DataController.ArmamentController = require("game.productionSoldier.armory.ArmamentController").getInstance()--军械库
	DataController.ArmyReformController = require("game.productionSoldier.armysReform.ArmyReformController").getInstance()--士兵改造
	DataController.ModifyLibaoMgrV1Inst = require("game.LiBao.ModifyLibaoMgrV1").getInstance()--礼包界面改版v1
	DataController.TimeEventController = require("game.controller.TimeEventController").getInstance()--统一的结束时间通知更新维护类
	DataController.AntiAddictionController = require("game.AntiAddiction.AntiAddictionController").new()
	DataController.CiviMiracleDefenceController = require("game.activity.CiviMiracleDefenceWar.CiviMiracleDefenceController").getInstance()
	DataController.UserLockedController = require("game.UsernameLock.UserLockedController").new()
	luaXmlController = require("game.controller.luaXmlController").new()		-- 新增的player信息
	HeroBadgeController = require('game.hero.badge.HeroBadgeController')
	NightCityController = require("game.NightCity.NightCityController")
	NCFunBuildController = require('game.NightCity.control.NCFunBuildController')

	-- 需要很早就初始化的管理类
	local init_arr = {
		"game.LiBao.LibaoPusher.LibaoPusherMgr",
	}

	DataController.init = function (  )
		for _,v in ipairs(init_arr) do
			require(v).getInstance()
		end
	end

	DataController.init()
end
