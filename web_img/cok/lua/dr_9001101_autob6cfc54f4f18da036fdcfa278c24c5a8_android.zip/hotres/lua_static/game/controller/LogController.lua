LogController = LogController or {}

LOG_GOLD_TOUCH_MORE_INFO = "logGoldTouchMoreInfo"    -- 点击右上礼包商店
LOG_LIBAO_PAGE = "logLibaoPage"    -- 点击礼包详情页打点
LOG_LIBAO_PAY = "logLibaoPay"    -- 点击购买礼包
LOG_TIME_REWARD_ENTERANCE = "logTimeRewardEntrance"
-- LOG_MONTH_CARD = "logMonthCard"
LOG_MONTH_CARD_DETAIL = "logMonthCardDetail"
LOG_SHOW_GIFT = "showgift"
LOG_SHOW_GIFT_ID = "showGiftId"
LOG_ITEM_GET_METHOD_SHOW = "itmeGetMethodShow"

--大王战活动玩家观战打点
LOG_CROSS_THRONE_OB = "logCrossThroneOb"
--大王战活动玩家参与打点
LOG_CROSS_THRONE_ENTER = "logCrossThroneEnter"
--跨服王战统计面板规则介绍点击打点
LOG_CROSS_THRONE_RULE = "logCrossThroneRule"
--跨服王战统计面板战况汇报点击打点
LOG_CROSS_THRONE_OCCUPY_RANK = "logCrossThroneOccupyRank"

LOG_NEWBIE_TASK = "newbieTask"

LOG_CITY_OPEN = "city.open"

LOG_AVATAR_OPEN = "avatar.open"
LOG_AVATAR_TOUCH_TAG = "avatar.touchTag"
LOG_AVATAR_TOUCH_BUY = "avatar.touchBuy"
LOG_AVATAR_CONFIRM_BUY = "avatar.confirmBuy"

--阵法拍卖行
LOG_FTAUCTION_OPEN = 'logFTAuctionOpen'
LOG_FTAUCTION_REFRESH = 'logFTAuctionRefresh'
LOG_FTAUCTION_SHOP = 'logFTAuctionShop'

-- 英雄信物
LOG_HEROBADGE_ENTERPANEL = 'logHeroBadgeEnterPanel'
LOG_HEROBADGE_CLICKPANELSUPER = 'logHeroBadgeClickPanelSuper'
LOG_HEROBADGE_CLICKPANELRule = 'logHeroBadgeClickPanelRule'
LOG_HEROBADGE_ENTERBAG = 'logHeroBadgeEnterBag'
LOG_HEROBADGE_CLICKPOS = 'logHeroBadgeClickPos'
LOG_HEROBADGE_CHANGEPOS = 'logHeroBadgeChangePos'

-- bi打点走新逻辑sendBiEvent，postEventLog是兼容老的写法
-- 示例： LogController:postEventLog("testLog", {itemId = "10001", name = "测试", "type" = 10, …})
function LogController:postEventLog(key, params)
    self:sendBiEvent(key, params)
end

function LogController:sendBiEvent(key, params)
    if not params or table_is_empty(params) then
        BIService:call("getInstance"):call("sendEvent", key)
    else
        BIService:call("getInstance"):call("sendEvent1", key, params)
    end
end

function LogController:sendUserBehaviorEvent(type, level, value1, value2, value3)
    BIService:call("getInstance"):call("sendUserBehaviorEvent1", type, level, value1, value2, value3)
end
