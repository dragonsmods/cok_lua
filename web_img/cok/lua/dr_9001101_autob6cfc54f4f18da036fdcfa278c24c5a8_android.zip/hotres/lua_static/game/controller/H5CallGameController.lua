---h5 调用游戏内部 处理逻辑  原生内部
local H5CallGameController = {}
local HandleH5CallGame = {}
HandleH5CallGame["showgameview"] = function ( param )
     -- body
     --处理 h5 跳转
     CCSafeNotificationCenter:postNotification("WebActivityView.close")
     CCCommonUtilsForLua.jumpToTarget(unpack(string.split(param,";")))
end

--Str = "showgameview?param=7;59"
H5CallGameController.parseH5CallGame = function ( str)
    -- body
   
    if str == "" then return end
    local  temp = string.split(str,"?")
    local type = "" 
    local param = ""
    if #temp >1 then
       type = temp[1]
       local paramTemp = string.split(temp[2],"=")
       if #paramTemp > 1 then
          param = paramTemp[2]
       end
    end
   
    if HandleH5CallGame[type] then
        HandleH5CallGame[type](param)
    end
 

end


return H5CallGameController
