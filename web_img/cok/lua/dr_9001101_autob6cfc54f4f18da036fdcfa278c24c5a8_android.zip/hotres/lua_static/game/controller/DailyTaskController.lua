DailyTaskController = class("DailyTaskController")
local _instance = nil
function DailyTaskController.getInstance()
    if _instance == nil then
        _instance = DailyTaskController.new()
    end
    MyPrint("DailyTaskController.getInstance",_instance)
    return _instance
end

function DailyTaskController:ctor()
    self.boxList = {}
    self.dtaskList = {}
    self.curTaskList = {}
    self.isTaskload = false
    self.isBoxload = false
    self.allianceTaskNum = 0
    self.m_boxOpenIndex = 0
end

function DailyTaskController:setbOxOpenIndex( index )
    self.m_boxOpenIndex = index
end

function DailyTaskController:getBoxRewardIndex(  )
   return self.m_boxOpenIndex 
end

function DailyTaskController:setTaskNum( num )
    self.allianceTaskNum = num
end

function DailyTaskController:getTaskNumCompleted(  )
    return self.allianceTaskNum
end

function DailyTaskController:initDailyTask(showTask)
    
    --防止重复初始化，造成泄露.

    if self.isTaskload == false then
        local group = LocalController:call("shared"):call("DBXMLManager"):call("getGroupByKey","daily_task_client")
        if group == nil then
            return
        end
        local temp = dictToLuaTable(group)
        for key, value in pairs(temp) do 
            local dailyTaskInfo = Drequire("game.Tavern.DailyTaskInfo").new()
            dailyTaskInfo:parse(value)
            self.dtaskList[key] = dailyTaskInfo
            MyPrint("DailyTaskController:initDailyTask",dailyTaskInfo,key)
        end
        self.isTaskload = true
    end
    if self.isBoxload == false then
        local group = LocalController:call("shared"):call("DBXMLManager"):call("getGroupByKey","daily_task_box")

        if group == nil then
            return
        end
        local temp = dictToLuaTable(group)
        for key, value in pairs(temp) do 
            self.boxList[key] = value.reward
        end
        self.isBoxload = true
    end
                MyPrint("DailyTaskController:showTask",showTask:count(),#self.dtaskList)

    if showTask then
        self.curTaskList = {}
        for i = 0, showTask:count()-1 do
            local dic = showTask:objectAtIndex(i)
            local itemId = dic:valueForKey("id"):getCString()

            for key, value in pairs(self.dtaskList) do 
                if key == itemId then

                    value:parseServerDic(dictToLuaTable(dic))
                    self.curTaskList[key] = value
                end
            end
        end
    end
end

function DailyTaskController:updateTask(itemId)
    MyPrint("DailyTaskController:updateTask")
    self.curTaskList[itemId].state = 2
end

function DailyTaskController:getReward(itemId,isMain,index,taskType) 
    local taskType = 0
    if(isMain) then
        local cmd = Drequire("game.command.DailyTaskBoxRewardCommand").create(itemId,index)
        cmd:send()
    else        

        local cmd = Drequire("game.command.DailyTaskRewardCommand").create(itemId,taskType)
        cmd:send()
    end
    --AdjustII:CompleteTaskReward
    local param = {itemId = itemId, isMain = isMain, taskType = taskType}
    sendAdjustStatistic("CompleteTaskReward", param)
end

function DailyTaskController:getRewardBylevel( normal_reward)
    local tmpdata = normal_reward
    local level_reward  = string.split(tmpdata,"|")
    local mainCityLv = FunBuildController:call("getMainCityLv")
    local default = ""
    for k,v in pairs(level_reward) do 
        local level_str = level_reward[k]
        local level2rid = string.split(level_str,";")

        if #level2rid == 2  and tostring(mainCityLv) == level2rid[1] then 
            return level2rid[2]
        end
        if #level2rid == 2 then 
            default = level2rid[2]
        end
    end
    return default
end

function DailyTaskController:goActTarget( itemId)--前往目的地

    if #itemId <= 0 then
        return
    end
    MyPrint("goActTarget",self.curTaskList,itemId)
    local info = self.curTaskList[itemId]
        MyPrint("goActTarget",info,info.go)
    if(info == nil) then
        return
    end
    
    local goType = tonumber(info.gotype)
    local goItemId = tonumber(info.go)
    CCCommonUtilsForLua.jumpToTarget(goType, goItemId)
end

function DailyTaskController:getCurTaskKeyList()
    local arr = CCArray:create()
    MyPrint("getCurTaskKeyList")
    for key, value in pairs(self.curTaskList) do 
        arr:addObject(CCString:create(key))
         MyPrint("getCurTaskKeyList",arr:count(),key)
    end
    return arr
end

function DailyTaskController:getDailyTaskInfo(itemId)
    for key, value in pairs(self.curTaskList) do 
        MyPrint("getDailyTaskInfo")
        if key == itemId then
           MyPrint("getDailyTaskInfo",key,value,value.state)
            return value
        end
    end
    return nil
end

function DailyTaskController:getNoFinishIconFlag()
    local isfind = false
    if self.curTaskList == nil then
        isfind = false
    else
        for key, value in pairs(self.curTaskList) do 
            if value.state ~= 2 then
                isfind = true
            end
        end
    end
    return isfind
end

function DailyTaskController:getTodayBoxRewardId(id)
    MyPrint("boxList",self.boxList,id)
    for key, value in pairs(self.boxList) do 
       MyPrint("boxList",key,value)
    end
    local boxReward = self.boxList[id]
    return boxReward
end

function DailyTaskController.purge()
    _instance = nil
    MyPrint("DailyTaskController:purge")
end