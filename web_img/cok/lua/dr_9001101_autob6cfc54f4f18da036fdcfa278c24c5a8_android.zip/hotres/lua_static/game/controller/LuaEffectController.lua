--@Description: Lua端新系作用号数据控制类,不要直接获取effectTbl数据，请用接口进行取值和赋值
--@Date: 2019-07-24 18:02:22
local LuaEffectController = class("LuaEffectController")
local _LuaEffectController = nil

--------------------pullCommand------------------
--各个功能汇总作用号
local PullEffectInfoCMD = class("PullEffectInfoCMD",LuaCommandBase)
function PullEffectInfoCMD.req()
    local ret = PullEffectInfoCMD.new()    
    ret:initWithName("effectCenter.all")
    ret:send()
end
function PullEffectInfoCMD:handleReceive(dict)
    local tbl = self:parseMsg(dict)
    if type(tbl)=='boolean' then
        return tbl
    end
    DataController.LuaEffectController:parseEffectBuffValue(tbl)
    return true
end

--请求某一功能作用号
local ReqEffectInfoByKeyCMD = class("ReqEffectInfoByKeyCMD",LuaCommandBase)
function ReqEffectInfoByKeyCMD.req(key)
    local ret = ReqEffectInfoByKeyCMD.new()    
    ret:initWithName("effectCenter.single")
    ret:putParam("type",CCString:create(key))
    ret:send()
end
function ReqEffectInfoByKeyCMD:handleReceive(dict)
    local tbl = self:parseMsg(dict)
    if type(tbl)=='boolean' then
        return tbl
    end
    DataController.LuaEffectController:updateEffectInfo(tbl)
    return true
end
--------------------pullCommand------------------

function LuaEffectController.getInstance()
    if not _LuaEffectController then
        _LuaEffectController = LuaEffectController.new()
    end
    return _LuaEffectController
end

local luaEffectListDesc = {
    "龙技能:","文明:","方尖碑:","王冠:","皮肤装扮","皮肤附魔","皮肤图鉴:","皮肤自身",
    "英雄图鉴:","士兵进阶:","文明星盘:","先祖战场:","魔法学院等级加成:","魔法学院星级加成:","魔法学院图鉴:","月卡等级:","竞技场:","","",
}
local effectEnum = {
    DragonSkill = 1,
    Civilization = 2,
    Fangjianbei = 3,
    Crown = 4,
    DressIntroductionDress = 5,
    DressIntroductionFumo = 6,
    DressIntroductionFetter = 7,
    DressIntroductionCastle = 8,
    HeroDress = 9,
    SoilderUp = 10,
    CiviMiracle = 11,
    Battlefield = 12,
    MagicLevel = 13,
    MagicStar = 14,
    MagicAtlas = 15,
    MonthCard = 16,
    Tournament = 17,
    Pinnacle = 18,
}

function LuaEffectController:ctor()
    --如果FestivalView系统作用号存在，就不走FestivalActivitiesController和FestivalActivitiesFiveAnniversaryBlessController    
    self.closeFestivalEffKey = false --当版本覆盖到最低43的时候，此处逻辑可以删除

    --作用号数值表
    self.effectTbl = {}
    --作用号缓存,更新作用号一定要从新建立缓存
    self.effectCacheTbl = {}
    --作用号活动检查表
    self.activityUpdateIdTbl={}
    --作用号其他数据表
    self._otherEffectDatas = {}
    self.lastUpdateTime = nil

    -- 存储lua里面的作用号值
    self.saveGameEffTbl = {}
    self.effectEnum = effectEnum
end

--登陆后主动请求所有系统信息
function LuaEffectController:pullEffectSystems()
    PullEffectInfoCMD.req()
end
--解析第一次请求的作用号信息
function LuaEffectController:parseEffectBuffValue(tbl)
    ------------------init---------------------
    -- self.effectTbl = {} --不可清空，其他几个旧的系统返回比这个协议早，继续添加   
    self.closeFestivalEffKey = false
    --作用号活动检查表
    self.activityUpdateIdTbl={}
    self.lastUpdateTime = nil
    if self.m_entryId then  
        local scheduler = cc.Director:getInstance():getScheduler()
        scheduler:unscheduleScriptEntry(self.m_entryId)              
        self.m_entryId = nil
    end
    ------------------init---------------------

    --------------------解析服务器下发的各系统作用号 START-----------------
    for moduleKey, effectInfo in pairs (tbl.effect or {}) do
        local _tempTbl = {}
        for key,value in pairs(effectInfo or {}) do
            _tempTbl[tostring(key)] = tonumber(value)
        end
        self.effectTbl[moduleKey] = _tempTbl
    end

    if self.effectTbl["FestivalView"] then
        self.closeFestivalEffKey = true
    end

    self.activityUpdateIdTbl = {}
    if tbl.effectFestival then
        self.activityUpdateIdTbl = string.split(tbl.effectFestival,";")
    end

    self._otherEffectDatas = {}
    if not table.isNilOrEmpty(tbl.effectOtherDataAll) then
        for k, v in pairs(tbl.effectOtherDataAll) do
            if not table.isNilOrEmpty(v) then
                local otherData = {}
                for attribute, value in pairs(v) do
                    otherData[attribute] = value
                end
                self._otherEffectDatas[k] = otherData
            end
        end
    end
    --------------------解析服务器下发的各系统作用号 END-----------------

    --主动添加系统模块作用号
    local function addOldModuleEffectInfo()
        --方尖碑
        if CCCommonUtilsForLua:isFunOpenByKey("miracle_buff") then
            FangJianBeiEffectMgr.getInstance():updateEffect()
        end
    end
    addOldModuleEffectInfo()

    --下次更新定时器
    self:registerUpdateFun()

    self.effectCacheTbl = {} --清空缓存
end

--请求单一系统的作用号信息
function LuaEffectController:reqEffectInfoByKey(key)
    if not key or key == "" then
        return
    end
    ReqEffectInfoByKeyCMD.req(key)
end

--更新单一系统作用号信息,如果要删除某一作用号务必让后端推数值为0过来
function LuaEffectController:updateEffectInfo(info)
    -- dump(info,"hxq LuaEffectController:updateEffectInfo info is ")
    -- dump(self.effectTbl,"hxq before update is ")
    if info and info.key and info.effect then
        local systemKey = info.key --推送某个系统的key
        local effTbl = info.effect --系统对应的作用号信息{"1101"="2","998"="2"...}
        for k,v in pairs(effTbl or {}) do            
            effTbl[k] = tonumber(v)
        end
        
        if info.key == "FestivalView" then
            self.closeFestivalEffKey = true
        end

        -- 经过与后端魏天翔沟通，后端要求前端直接覆盖具体key相关联的表 19.09.30
        self.effectTbl[systemKey] = effTbl
        -- if nil == self.effectTbl[systemKey] then            
        --     self.effectTbl[systemKey] = effTbl
        -- else
        --     for num,value in pairs(effTbl or {}) do
        --         self.effectTbl[systemKey][num] = value
        --     end
        -- end
        self.effectCacheTbl = {}
    end
    -- dump(self.effectTbl,"hxq after update is ")
end

--获取作用号数值
function LuaEffectController:getEffectValueByNum(num)
    local ret = 0    
    --整型做key,已有缓存，直接取值
    if self.effectCacheTbl[num] then
        return self.effectCacheTbl[num]
    end
    if next(self.effectTbl) then
        local key = tostring(num)
        for k,v in pairs(self.effectTbl) do
            if type(v) == "table" and v[key] then
                ret = ret + v[key]
            end
        end
    end
    if not self.closeFestivalEffKey then
        --节日活动
        ret = ret + require("game.FestivalActivities.FestivalActivitiesController").getInstance():getEffectValueByNum(num)
        -- 周年庆
        ret = ret + require("game.FestivalActivities.FestivalActivitiesFiveAnniversaryBlessController").getInstance():getEffectValueByNumT(num)
    end
    --缓存存值
    self.effectCacheTbl[num] = ret
    return ret
end

--获取系统的相关作用号信息,修改返回表不影响此处
function LuaEffectController:getEffectInfoByKey(key)
    local res = {}
    if not key or key == "" or not next(self.effectTbl[key]) then
        return res
    end
    for num,value in pairs(self.effectTbl[key]) do
        res[num] = value
    end
    return res
end

--被动添加系统模块作用号,供外部调用
function LuaEffectController:setEffectInfoByKey(key,effect_tbl)
    if not key or not effect_tbl or key == "" then
        return false
    end
    --key,value类型格式
    local _tempTbl = {}
    for key,value in pairs(effect_tbl) do
        _tempTbl[tostring(key)] = tonumber(value)
    end
    self.effectTbl[key] = _tempTbl
    self.effectCacheTbl = {}
end

--注册定时器
function LuaEffectController:registerUpdateFun()
    if self.m_entryId then  
        local scheduler = cc.Director:getInstance():getScheduler()
        scheduler:unscheduleScriptEntry(self.m_entryId)              
        self.m_entryId = nil
    end
    local now = getWorldTime() --活动类取本地时间

    --活动的更新时间
    if not table.isNilOrEmpty(self.activityUpdateIdTbl) then
        local function getActEndTime(actId)
            local res = 0
            if not actId then
                return res
            end
            local obj = ActivityController:call("getInstance"):call("getActObj", actId)
            if obj then
                res = tonumber(obj:getProperty("endTime"))
            end
            return res
        end
        for _,actId in pairs(self.activityUpdateIdTbl) do
            local endTime = getActEndTime(actId)
            if endTime > now then --更新的时间点:距离当前时间最近的未来时间点
                if not self.lastUpdateTime then
                    self.lastUpdateTime = endTime
                end
                self.lastUpdateTime = math.min(self.lastUpdateTime,endTime)
            else
                -- dump({actId=actId,endTime=endTime},"hxq error!!! LuaEffectController  后台返回了过期的活动ID:")
            end
        end
    end

    --其他功能的更新时间
    if not table.isNilOrEmpty(self._otherEffectDatas) then
        for key, otherEffectData in pairs(self._otherEffectDatas) do
            if otherEffectData.endTime and (-1 ~= otherEffectData.endTime) then       --非永久buff
                local endTime = GlobalData:call("changeTime", otherEffectData.endTime / 1000)
                if endTime > now then
                    if not self.lastUpdateTime then
                        self.lastUpdateTime = endTime
                    end
                    self.lastUpdateTime = math.min(self.lastUpdateTime, endTime)
                end
            end
        end
    end

    --找到了
    if self.lastUpdateTime then
        local lessTime = self.lastUpdateTime - now
        if lessTime > 0 then
            local scheduler = cc.Director:getInstance():getScheduler()
            self.m_entryId = scheduler:scheduleScriptFunc(function() self:schedulePullEffectInfo() end, lessTime+5, false)
        end
    else
        self.effectTbl["FestivalView"] = {}
    end  
end

function LuaEffectController:schedulePullEffectInfo()    
    if self.m_entryId then  
        local scheduler = cc.Director:getInstance():getScheduler()
        scheduler:unscheduleScriptEntry(self.m_entryId)              
        self.m_entryId = nil
    end
    self:pullEffectSystems()
end

function LuaEffectController:purge()
    self.effectTbl = {}
    self.effectCacheTbl = {}
    self.closeFestivalEffKey = false
    --作用号活动检查表
    self.activityUpdateIdTbl={}
    self.lastUpdateTime = nil
    self._otherEffectDatas = {}
    self.saveGameEffTbl = {}
    if self.m_entryId then  
        local scheduler = cc.Director:getInstance():getScheduler()
        scheduler:unscheduleScriptEntry(self.m_entryId)              
        self.m_entryId = nil
    end
end

    -- GAMESAVEEFF_STATE_EFF,          //
    -- GAMESAVEEFF_EFFECT_VALUE,       //
    -- GAMESAVEEFF_GENERAL,            //领主详情
    -- GAMESAVEEFF_HERO_OFFICE,        //英雄官职
    -- GAMESAVEEFF_NEUTRALLAND,        //中立地带buff
    -- GAMESAVEEFF_EQUIP_EFF,          //装备buff
    -- GAMESAVEEFF_SUIT_EFF,           //套装buff
    -- GAMESAVEEFF_KNIGHT_EFF,         //龙语buff
    -- GAMESAVEEFF_ALLI_SCIENCE,       //联盟科技
    -- GAMESAVEEFF_DRAGON_BATTLE,      //巨龙
    -- GAMESAVEEFF_ALLI_TREE,          //联盟树
    -- GAMESAVEEFF_ARMED_BUFF,         //军衔
    -- GAMESAVEEFF_LITTLE_HERO,        //小公主等内城英雄
    -- GAMESAVEEFF_LUCKDAY,            //幸运日
    -- GAMESAVEEFF_DRAGON_EFF,         //龙系统
    -- GAMESAVEEFF_BUILD_EFF,          //建筑
    -- GAMESAVEEFF_LUA_EFF,            //lua中的作用好
local cplusEffectListDesc = {
    "STATE_EFF:","USER_EFFECT:","领主详情:","英雄官职:","中立地带buff:","装备buff:","套装buff:","龙语buff:","联盟科技:","巨龙:","联盟树:","军衔:","内城英雄:","幸运日:","龙系统:","建筑:","lua中的作用好:",":",":",":",":",":",":",":",":",":",":",
}
local luaEffectListDesc = {
    "龙技能:","文明:","方尖碑:","王冠:","皮肤装扮","皮肤附魔","皮肤图鉴:","皮肤自身",
    "英雄图鉴:","士兵进阶:","文明星盘:","先祖战场:","魔法学院等级加成:","魔法学院星级加成:","魔法学院图鉴:","月卡等级:","竞技场:","","",
}

function LuaEffectController:getLuaEffectDumpList(effNum)
    local strTbl = {}
    table.insert( strTbl, "Lua通用系统:")
    effNum = tostring(effNum)    
    local enumKey = ""  
    for k,v in pairs(self.effectTbl) do
        if v[effNum] then
            enumKey = luaEffectListDesc[k] ~= nil and luaEffectListDesc[k] or "Tbl:["..k.."]:"
            table.insert(strTbl, enumKey)
            table.insert(strTbl, v[effNum])
            table.insert(strTbl, "; ")
        end
    end
        
    for i, value in pairs(self.saveGameEffTbl) do
        local num = tonumber(value)
        if num and num > 0 then
            table.insert(strTbl, luaEffectListDesc[i])
            table.insert(strTbl, tostring(num))
            table.insert(strTbl, "; ")
        end
    end
    local str = table.concat(strTbl)
    return str
end

function LuaEffectController:dumpLuaEffectList(params)
    local function getStr(effTbl, descTbl)
        local strTbl = {}
        for i, num in pairs(effTbl) do
            if num > 0 then
                table.insert(strTbl, descTbl[i])
                table.insert(strTbl, tostring(num))
                table.insert(strTbl, ";")
            end
        end
        local str = table.concat(strTbl)
        return str
    end

    local numList = tostring(params.numList or params.num or "")
    local splitChar = params.splitChar or ";"
    local numTbl = string.split(numList, splitChar)

    local showStr = {}
    table.insert(showStr, "numberList<<")
    table.insert(showStr, numList)
    table.insert(showStr, ">> detail info is:\n")
    local totalNum = 0
    for _, effNumStr in pairs(numTbl) do
        local effNum = tonumber(effNumStr)
        if effNum then
            local value = CCCommonUtilsForLua:call("getEffectValueByNum", effNum)
            totalNum = totalNum + value
            local tbl = CCCommonUtilsForLua:call("getGameSaveEffect")
            local c_str = getStr(tbl, cplusEffectListDesc)
            local lua_str = self:getLuaEffectDumpList(effNum)
            table.insert(showStr, "effcetNum[")
            table.insert(showStr, tostring(effNum))
            table.insert(showStr, "] total:")
            table.insert(showStr, tostring(value))
            table.insert(showStr, "\n    C_effect--")
            table.insert(showStr, tostring(c_str))
            table.insert(showStr, "\n    Lua_effct--")
            table.insert(showStr, tostring(lua_str))
            table.insert(showStr, "\n\n")
        end
    end
    local show = table.concat(showStr)
    -- YesNoDialog:call("show", show)
    local view = Drequire("commonView.debugDialogInfoView"):create(show)
    PopupViewController:addPopupView(view)
end

return LuaEffectController
