require("game.controller.ActivityEventObjForLua")
local DailyActivityManager = require("game.dailyActivity.DailyActivityManager")

ActivityController = ActivityController or {}
local open_act_handler = {}

local ActType = utils.toNumberEnum({
	{"All",0},
	{"Type1"},
	{"Type2"},
})

-- local ActivityController_call = ActivityController.call

-- function ActivityController:call( ... )
-- 	local callFunc,p2 = ...
-- 	cclog("ActivityController call trace %s %s %s",callFunc,p2,debug.traceback())
-- 	return ActivityController_call(self,...)
-- end

function ActivityController.getInstance()
	local tIns = ActivityController:call("getInstance")

	-- tIns:tryInitSubActivity()

	return tIns
end

function ActivityController:tryInitSubActivity(  )
	if not self.m_hadInitRequire then
		self.m_hadInitRequire = true
		self.m_mgrInsMap = self.m_mgrInsMap or {}
		-- self.m_mgrInsMap['57457'] = require("game.activity.MultiplyGift.MultiplyGiftMgr").getInstance()
		-- self.m_mgrInsMap['57476'] = require("game.activity.ValentinesDayWishes.ValentinesDayWishesController").getInstance()
		-- self.m_mgrInsMap['57492'] = require("game.activity.RandomBuy.RandomBuyMgr").getInstance()
		-- self.m_mgrInsMap['57468'] = require("game.activity.GoldDigTreasure.GoldDigTreasureController").getInstance()
		-- self.m_mgrInsMap['57499'] = require("game.activity.Windmill.WindmillMgr").getInstance()
		-- self.m_mgrInsMap['57225'] = require("game.RechargeLegendKingdom.RechargeLegendKingdomMgr").getInstance()
		-- self.m_mgrInsMap['57515'] = require("game.activity.LuckyRoulette.LuckyRouletteController").getInstance()
		-- self.m_mgrInsMap['57530'] = require("game.activity.LuckyDirectPurchase.LuckyDirectPurchaseController").getInstance()
		-- self.m_mgrInsMap['57554'] = require("game.activity.ExtendBuild.ExtendBuildMgr").getInstance()
		-- self.m_mgrInsMap['57556'] = require("game.activity.EveryoneDigGem.EveryoneDigGemMgr").getInstance()
		-- self.m_mgrInsMap['57189'] = ConvertHappyFestivalContrllerInst
		-- self.m_mgrInsMap['57565'] = require("game.activity.GeocentricTreasure.GeocentricTreasureMgr").getInstance()
		-- self.m_mgrInsMap["57571"] = require('game.activity.FormationTrainCarnival.FormationTrainCarnivalMgr').getInstance()

		local tbl = {}
		tbl['57457'] = "game.activity.MultiplyGift.MultiplyGiftMgr"
		tbl['57476'] = "game.activity.ValentinesDayWishes.ValentinesDayWishesController"
		tbl['57492'] = "game.activity.RandomBuy.RandomBuyMgr"
		tbl['57468'] = "game.activity.GoldDigTreasure.GoldDigTreasureController"
		tbl['57499'] = "game.activity.Windmill.WindmillMgr"
		tbl['57225'] = "game.RechargeLegendKingdom.RechargeLegendKingdomMgr"
		tbl['57515'] = "game.activity.LuckyRoulette.LuckyRouletteController"
		tbl['57530'] = "game.activity.LuckyDirectPurchase.LuckyDirectPurchaseController"
		tbl['57554'] = "game.activity.ExtendBuild.ExtendBuildMgr"
		tbl['57556'] = "game.activity.EveryoneDigGem.EveryoneDigGemMgr"
		tbl['57565'] = "game.activity.GeocentricTreasure.GeocentricTreasureMgr"
		tbl["57571"] = 'game.activity.FormationTrainCarnival.FormationTrainCarnivalMgr'
		tbl["57584"] = 'game.activity.ChristmasGift.ChristmasGiftMgr'
		tbl["57599"] = 'game.activity.newArmyAct.NewArmyCtr'--新兵起航
        tbl["57605"] = 'game.activity.DiamondFlop.DiamondFlopCtr'--钻石翻牌
		tbl["57268"] = 'game.CommonPopup.MonthFundView.MonthFundController'--钻石翻牌
		-- 57189特殊处理
		-- 57189特殊处理
		-- self.m_mgrInsMap['57189'] = ConvertHappyFestivalContrllerInst

		for id, path in pairs(tbl) do
			if self:isActivityOpen(id) then
				self.m_mgrInsMap[id] = require(path).getInstance()
			end
		end
		if self:isActivityOpen("57189") then
			self.m_mgrInsMap["57189"] = ConvertHappyFestivalContrllerInst
		end
	end
end

function ActivityController:purge()
	-- dump("ActivityController purge data ~~~~~~~~")
	self.updateExchangeAddList = {}
	self.m_xml_page = nil
	self.m_hadInitRequire = false
end

function ActivityController:fireActivityEvent(key, params)
	-- dump(key, "ActivityController:fireActivityEvent key is: ")
	if key == "initExchangeAddData" then
		self.updateExchangeAddList = {}
	elseif key == "updateExchangeAddData" then
		self:updateExchangeAddData(params)
	end
end

function ActivityController:updateExchangeAddData(dict)
	local tbl = dictToLuaTable(dict) or {}

	local rewardIdList = {}
	for key, goods in pairs(tbl) do
		local goodList = {}
		if goods ~= "" then
	        local tmp = string.split(goods, "|")
	        for _, str in pairs(tmp) do
	            if str ~= "" then
	                local tmp1 = string.split(str, ";")
	                local data = tbl[tmp1[1]] or {}
	                if #tmp1 == 2 then
		                data[#data + 1] = {
		                    type = 0,
		                    -- itemId = tmp1[2],
		                    -- num = tonumber(tmp1[3]) or 0,
		                    rewardId = tmp1[2],
		                }
		                rewardIdList[#rewardIdList + 1] = tmp1[2]
		            elseif #tmp1 == 3 then
		                data[#data + 1] = {
		                    type = 0,
		                    itemId = tmp1[2],
		                    num = tonumber(tmp1[3]) or 0,
		                }
		            end
		            goodList[tmp1[1]] = data
	            end
	        end
		end
		self.updateExchangeAddList[key] = goodList
	end
    if #rewardIdList > 0 then
        GlobalData:call("shared"):call("requestMultiRewardData", rewardIdList)
    end
end

-- 取活动给礼包添加的道具id
function ActivityController:getActExtraItemData(goldKey)
	local itemList = {}
	for id, tbl in pairs(self.updateExchangeAddList or {}) do
    	local getActObj = ActivityController:call("getActObj", id)
	    if getActObj then
		    local endTime = tonumber(getActObj:getProperty("endTime"))
		    --部分活动提前结束(鲜花榜)
		    local delay_time = atoi(CCCommonUtilsForLua:call("getPropByIdGroup", "activity_panel", id, "delay_time"))
		    endTime = endTime - delay_time
		    if endTime > 0 and getWorldTime() <= endTime then
	        	for _, data in pairs(tbl[goldKey] or {}) do
	        		if data.itemId == nil then
		        		local rwd = GlobalData:call("getCachedRewardData", data.rewardId)
        				local rwdData = arrayToLuaTable(rwd)
        				if #rwdData > 0 then
        					-- data.itemId
        					-- 暂时不支持多个道具，只显示第一个
        					for _, info in pairs(rwdData) do
        						if info.type == "7" then
        							data.itemId = info.value.id
        							data.num = tonumber(info.value.num)
        							break
        						end
        					end
        				end
		        	end
		        	if data.itemId then
		        		itemList[#itemList + 1] = data
		        	end
	        	end
		    end
		end
	end
	-- dump(itemList, "ActivityController:getActExtraItemData itemList is: ")
	if table_is_empty(itemList) then
	    return nil
	else
		return itemList
	end
end

function ActivityController:createActObjByParams( params )
	if nil == params then
		return nil
	end

	local actId = params:valueForKey("id"):getCString()
	local actType = CCCommonUtilsForLua:call("getPropById", actId, "type")
	if nil == actType or "" == actType then
		return nil
	end
	actType = tonumber(actType)

	if actType == 35 then
		local obj = require("game.activity.groupAct.groupActObj")
		return obj.create(params)
	elseif actType == 36 then
		-- local obj = require("game.recall.RecallEventObj")
		-- return obj.create(params)
	elseif actType == 37 then
		local obj = require("game.fortress.FortressActivityObj")
		return obj.create(params)

	elseif actType == 38 then
		return require("game.resBattleNew.NewResBattleObj").create(params)
	elseif actType == 39 then
		return require("game.dragonWorldCup.DragonWorldCupActivityObj").create(params)
	elseif actType == 8888 then
		-- 范例
		return testobj.create(params)
	elseif actType == 47 then --黄金蛋
		return require("game.eggRhexis.EggRhexisActivityObj").create(params)
	elseif actType == 54 then --霸主争夺战
		return require("game.crossThrone.CrossThroneDespotActivityObj").create(params)
	elseif actType == 58 then -- 联盟竞技赛
		return require("game.AllianceLegend.AllianceLegendActivityObj").create(params)
	elseif actType == 60 then --答题活动
		return require("game.QuestionActivity.QuestionActivityObj").create(params)
	elseif actType == 61 then
		return require("game.TreasureFam.TreasureFamActivityObj").create(params)
	elseif actType == 62 then
		return require("game.activity.armament.NewServerRankActivityObj").create(params)
	elseif actType == 64 then --【Awen】战场
		return require("game.Battlefield.BattlefieldActivityObj").create(params)
	elseif actType == 70 then --【Awen】新服活动：王者之路、进阶之路
		return require("game.WelfareIntegrate.kingRoad.KingRoadActivityObj").create(params)
	elseif actType == 71 then 
		return require("game.VoidBattlefield.VoidBattlefieldActivityObj").create(params)
	elseif actType == 77 then --hxq 巨龙演武场
		return require("game.dragonWarmUpBattle.DragonWarmUpActivityObj").create(params)
	elseif actType == 83 then -- 八国国战
		return require("game.NationalWar.NationalWarActivityObj").create(params)
	elseif actType == 85 then -- 皇家竞技场
		return require("game.tournament.TournamentActivityObj").create(params)
	elseif actType == 86 then -- 女王世界杯
		return require("game.QueenWorldCup.QueenWorldCupActivityObj").create(params)
	elseif actType == 87 then -- 商贸
		return require("game.commercialDarts.CommercialActivityObj").create(params)
	elseif actType == CiviMiracleConstData.activityType then --90 奇迹保卫战
		return require("game.activity.CiviMiracleDefenceWar.CiviMiracleDefenceActObj").create(params)
	elseif actType == 93 then -- 联盟对决
		return require("game.AllianceDuel.AllianceDuelActivityObj").create(params)
	elseif actType == 97 then -- 世界争霸
		return require("game.worldCraft.match.MatchActivityObj").create(params)
	elseif actType == 98 then -- 世界争霸娱乐赛
		return require("game.worldCraft.fun.FunActivityObj").create(params)
	elseif actType == 100 then --欢乐争霸房间模式
		return require("game.worldCraft.room.RoomActivityObj").create(params)
	elseif actType == 103 then --杀戮战场段位模式
		return require("game.Battlefield.room.RoomActivityObj").create(params)
	end

	return nil
end

function ActivityController:isActivityOpen(id )
	local obj = self:call("getActObj", id)
	if nil == obj then
		return false 
	end
	return true
end

function ActivityController:isActivityOpenWithTime( id )
	local obj = self:call("getActObj", id)
	if obj then
		local st = obj:getProperty("startTime") or 0
		local et = obj:getProperty("endTime") or 0xffffffff
		local now = GlobalData:call("getWorldTime")
		return now >= st and now < et, et - now
	end
	return false
end

function ActivityController:getActRangeTime( id,tKey )
	local obj = self:call("getActObj", id)
	if obj then
		tKey = tKey or "endTime"
		local def = tKey == "endTime" and 0xffffffff or 0
		return obj:getProperty(tKey) or def
	end
end

--openParams:打开页面时需要进入其子页的信息，可以为nil
function ActivityController:openActUI( id,openParams)
	MyPrint("ActivityController:openActUI ", id)
	dump(openParams, "openParams+++")
	-- do
	-- 	local view = Drequire("game.activity.GoldWish.GoldWishView").create()
 --        PopupViewController:addPopupInView(view)
 --        return
 --      end  
	local obj = self:call("getActObj", id)
	if nil == obj then
		dump("error:act obj not found+++")
		return
	end

	if isCrossServerNow() and ActivityController:isPayActivity(id) then
		LuaController:flyHint("", "", getLang("164891"))   --跨服状态,不能开启
		return
	end

	local hd = open_act_handler[id]
	if hd then
		hd(openParams, id)
	end
end

function ActivityController:checkAndPrepareDyRes( id_arr )
	local mIns_arr = {
		DataController.ModifyRechargeContinueControllerInst,
		DataController.DoubleGiftMgrInst,
		DataController.GoldBasinControllerInst,
		require("game.activity.LittlePayman.LittlePaymanMgr").getInstance(),
		require("game.activity.TimeTreasure.TimeTreasureMgr").getInstance(),
		require("game.activity.MultiplyGift.MultiplyGiftMgr").getInstance(),
	}

	for _,mIns1 in ipairs(mIns_arr) do
		for _,v in ipairs(id_arr) do
			if mIns1:makeResReadyById(v) then
				break
			end
	  	end
  	end
end

function ActivityController:shouActUIById(id)
	LogController:postEventLog("LogActivityEntrance", {actId = id, pos = 1 , TIME = getTimeStamp()})
	local v_type = CCCommonUtilsForLua:call("getPropByIdGroup", 'activity_panel', tostring(id), "type")
	Dprint('ActivityController:shouActUIById', id, v_type)
	
	if v_type then
		-- [awen-limengyao] 如果活动类型为59，直接打开周常活动
		if v_type=='59' then
			require('game.activity.week.ActivityWeekController')
			ActivityWeekController.getInstance():openUI(id)
	        return
    	end

		if v_type == "62" then
			local view = Drequire("game.activity.armament.ActivityArmamentGameView"):create(tostring(id))
			PopupViewController:addPopupInView(view)
			return
		end
	end
	local festival_info = CCCommonUtilsForLua:call("getPropByIdGroup", 'activity_panel', tostring(id), "festival_info")
	if festival_info and festival_info ~= "" then
		--节日活动
		local fesId = require("game.FestivalActivities.FestivalActivitiesController").getInstance():getOpenFestivalId()
        require("game.FestivalActivities.FestivalActivitiesHelper").openFestivalView(fesId, tostring(id))
		return
	end
	self:call("shouActUIById", id)
end

function ActivityController:getActObj(actId)
	return ActivityController:call("getActObj", actId)
end

function ActivityController:isPayActivity(actid)
	local pageIds = ActivityController:call("getSortedActivityPageIds")
	if pageIds == nil or pageIds:count() == 0 then
		return false
	end
	local tbl = arrayToLuaTable(pageIds)
	for i, id in pairs(tbl) do
		local activityId = CCCommonUtilsForLua:call("getPropByIdGroup","activity_page",id,"call_activity")
		if(actid == activityId) then 
			return true
		end
	end
	return false
end

function ActivityController:getSortedActivityPageIds( tType )
	tType = tType or ActType.All
	local pageIds = ActivityController:call("getSortedActivityPageIds")
	if pageIds == nil or pageIds:count() == 0 then
		return {}
	end

	local numCtrlConfig = CCCommonUtilsForLua:getPropDictByIdGroup("data_config", "activity_page")
	local k1,k2 = numCtrlConfig and numCtrlConfig.k1 or "-1",
					numCtrlConfig and numCtrlConfig.k2 or "-1"

	k1,k2 = tonumber(k1),tonumber(k2)
	local tbl = arrayToLuaTable(pageIds)

	table.sort(tbl, function(d1, d2)
        local _w1 = CCCommonUtilsForLua:call("getPropByIdGroup", "activity_page", d1, "weight")
        local _w2 = CCCommonUtilsForLua:call("getPropByIdGroup", "activity_page", d2, "weight")
        local _w1number = tonumber(_w1) or 0
        local _w2number = tonumber(_w2) or 0
        return _w1number > _w2number
    end)

	if tType == ActType.All then
		if k1 == -1 and k2 == -1 then
			return tbl
		else
			k1 = math.max(0,k1)
			k2 = math.max(0,k2)
			return table.sub(tbl,1,k1+k2)
		end
	else
		local xml_page = self:getActivityPageXml()
		local st = tostring(tType)

		local r1 = {}
		local r2 = {}

		for i,pageId in ipairs(tbl) do
			local v = xml_page[pageId]
			if v and v.Control_Type == "2" then
				table.insert(r2,pageId)
			else
				table.insert(r1,pageId)
			end
		end

		r1 = k1 == -1 and r1 or table.sub(r1,1,k1)
		r2 = k2 == -1 and r2 or table.sub(r2,1,k2)

		return tType == ActType.Type1 and r1 or r2
	end

	return {}
end

function ActivityController:hasControlType2(  )
	return not table.isNilOrEmpty(self:getSortedActivityPageIds(ActType.Type2))
end

function ActivityController:getActivityPageXml(  )
	local xml_page = self.m_xml_page
	if not xml_page then
		xml_page = CCCommonUtilsForLua:getGroupByKey("activity_page")
		self.m_xml_page = xml_page
	end
	return xml_page
end

function ActivityController:convertPageId2CallId( pageIds )
	local xml_page = self:getActivityPageXml()
	local res = {}
	for i,id in ipairs(pageIds) do
		res[i] = xml_page[id] and xml_page[id].call_activity
	end

	return res
end

function ActivityController:accessActMgrIns( actId,mgrIns )
	self.m_mgrInsMap = self.m_mgrInsMap or {}
	if mgrIns then
		self.m_mgrInsMap[actId] = mgrIns
	else
		return self.m_mgrInsMap[actId]
	end
end

-- 活动界面处理

open_act_handler[ "57193" ] = function( openParams, id )
	local view = Drequire("game.crossThrone.CrossThroneEntryView"):create()
	if view then
		PopupViewController:addPopupInView(view)
	end
end

open_act_handler[ "57386" ] = function( openParams, id )
	local view = Drequire("game.activity.HonorRoad.HonorRoadMainView"):create()
	PopupViewController:addPopupInView(view)
end

open_act_handler[ "57394" ] = function( openParams, id )	--【Awen】打开battlepass
	if DynamicResourceController2:call("checkDynamicResource", "57394_face") then
		if CCCommonUtilsForLua:isFunOpenByKey("battlepass_3level") then
            require("game.activity.battlepass6.BattlePassController").getInstance():openView()
        else
            local view = Drequire("game.activity.BattlePassNew.FestivalActivitiesBattlePassView"):create("57394")
            PopupViewController:addPopupInView(view)
        end
	else
		-- 169633=该功能正在下载中，请稍候
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("169633"))
	end
end

open_act_handler[ "57195" ] = function( openParams, id ) -- 以物易物
	local view = Drequire("game.activity.ResExchangeRes.ResExchangeResView"):create()
    PopupViewController:addPopupInView(view, false)
end

open_act_handler[ "57241" ] = function( openParams, id )  --幸运回归 
    local isSpeAct, endTime = DailyActivityManager.getSpecialActivityEndtime(id)
    if endTime > 0 then 
		local view = Drequire("game.activity.toNewServer.ReturnOfKing_V2.ToNewServerChooseView_V2"):create()
		PopupViewController:addPopupInView(view)
	end
end

open_act_handler[ "57370" ] = function( openParams, id )
	if COSDataController.getInstance():isOpen(true) then
		COSDataController.getInstance():fireEventRef("openUIInWorld")
	end
end

open_act_handler[ "57393" ] = function( openParams, id )	--【Awen】皮肤夺宝
	local view = Drequire("game.avatar.AvatarDuoBaoDrawView"):create()
	PopupViewController:addPopupInView(view)
end

open_act_handler[ "57242" ] = function( openParams, id )  --王者归来
	local isSpeAct, endTime = DailyActivityManager.getSpecialActivityEndtime(id)
    if endTime > 0 then 
		local view = Drequire("game.activity.toNewServer.KingReturnView"):create()
		PopupViewController:addPopupInView(view)
	else
		-- 王者归来 已激活但未开启时的提示
		local ctl = ToNewServerController.getInstance()
		if ctl.status == 2 or ctl.status == 5 then
			CCCommonUtilsForLua:call("flyHint", "", "", getLang("176400"))
		end
	end
end

open_act_handler[ "57403" ] = function( openParams, id )
	local view = Drequire("game.activity.EquipUpgradeCarnival.EquipUpgradeCarnivalView"):create()
	PopupViewController:addPopupInView(view) 
end

open_act_handler[ "57406" ] = function( openParams, id ) --聚宝盆
	DataController.GoldBasinControllerInst:requestBowlInfo()
end

open_act_handler[ "57284" ] = function( openParams, id ) 	--【Awen】先祖战场
    BattlefieldController.getInstance():openUI(Battlefield.Ancestral)
end

open_act_handler[ "57268" ] = function( openParams, id ) --月基金
	if CCCommonUtilsForLua:isFunOpenByKey("month_fund") then
		CCCommonUtilsForLua.jumpToTarget(113,nil)
	end   
end

open_act_handler[ "57275" ] = function( openParams, id )  -- 翻牌活动
	local view = Drequire("game.activity.festivalFlopCard.FlopCardView"):create()
    PopupViewController:addPopupInView(view)
end

open_act_handler[ "57199" ] = function( openParams, id ) 
	local view = Drequire("game.LiBao.LibaoCommonActivityView"):create()
    PopupViewController:addPopupInView(view)
end

open_act_handler[ "57222" ] = function( openParams, id )
	local view = Drequire("game.activity.GoldWish.GoldWishView").create()
    PopupViewController:addPopupInView(view)
end

open_act_handler[ "57155" ] = function( openParams, id )
	require("game.fortress.FortressController")
	local stage = FortressController.getInstance():getCurStage()
	if stage <= 2 then
        if FortressController.getInstance():isResultOpen() then
			--周日展示
            local view = Drequire("game.fortress.FortressResultView").create("57155")
			PopupViewController:call("addPopupInView", view)
			return
		end
		Drequire("game.CommonPopup.ActivityViewPlus")
		local view = ActivityViewPlus.create(id)
		PopupViewController:call("addPopupView", view)
	else						
		if CCCommonUtilsForLua:isFunOpenByKey("new_wonder_rule") and FortressController.getInstance():getCurStage() == 8 then
            local view = Drequire("game.fortress.FortressActViewV2").create()
			PopupViewController:call("addPopupInView", view)
		else
			local view = Drequire("game.fortress.FortressActView").create()
			PopupViewController:call("addPopupInView", view)
		end
	end
end

open_act_handler[ "57359" ] = function( openParams, id )   -- 文明堡垒限时
	local CivilizationTimeLimitedController = require("game.civilization.CivilizationTimeLimited.CivilizationTimeLimitedController").getInstance()
	if CivilizationTimeLimitedController:isOpen() then
		CivilizationTimeLimitedController:fireEventRef("openUI")
	else
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("146313"))	--146313=功能暂未开放，敬请期待！
	end
end

open_act_handler[ "57415" ] = function( openParams, id ) --双享好礼
	DataController.DoubleGiftMgrInst:showView()
end

open_act_handler[ "57153" ] = function( openParams, id )
	if isCrossServerNow() then
		LuaController:flyHint("", "", getLang("164891"))   --跨服状态,不能开启
		return
	end
	local lua_path = "game.CommonPopup.GoldBoxView"
    package.loaded[lua_path] = nil
    local view = require(lua_path):create(id)
    if view then
    	PopupViewController:addPopupInView(view)	
    else
    	LuaController:flyHint("", "", getLang("170035"))
    end
end

open_act_handler[ "57133" ] = function( openParams, id )
	local lua_path = "game.activity.57133.57133cell_new"
    local view = Drequire(lua_path):create()
    if view then
    	PopupViewController:addPopupInView(view)
	end
end

open_act_handler[ "57387" ] = function( openParams, id )
	local ctl = require("game.activity.RechargeAct.RechargeActController"):getInstance()
	if ctl:isOpen() then
		local view = Drequire("game.activity.RechargeAct.RechargeActMainView"):create()
		PopupViewController:addPopupInView(view)
	end
end

open_act_handler[ '57248' ] = function( openParams, id ) --57248：元宵节活动
	local view = Drequire("game.activity.week.ActivityWeekView").create(tostring(id))
    PopupViewController:addPopupInView(view)
end

open_act_handler[ "57194" ] = function( openParams, id )		
	local view = Drequire("game.NationalWar.NationalWarMainView"):create()
	PopupViewController:addPopupInView(view)
end

open_act_handler[ "57451" ] = function( openParams, id )  -- 女王世界杯	
	local view = Drequire("game.QueenWorldCup.QueenWorldCupView"):create()
	PopupViewController:addPopupInView(view)
end

open_act_handler[ "5740501" ] = function( openParams, id )
	if CCCommonUtilsForLua:isFunOpenByKey("csmod_store") then
		local view = Drequire("game.activity.CsmodStore.CsmodStoreView"):create()
		if view then
			PopupViewController:addPopupInView(view)
		end
	end
end

open_act_handler[ "5740502" ] = function( openParams, id )
	if CCCommonUtilsForLua:isFunOpenByKey("hero_store") then
		local view = Drequire("game.activity.CsmodItemStore.CsmodItemStoreView"):create()
		if view then
			PopupViewController:addPopupInView(view)
		end
	end
end

open_act_handler[ "57161" ] = function( openParams, id )
	local lua_path = "game.activity.GoldCoinCarnival.Activity_GoldCoinCarnival"
    local view = Drequire(lua_path):create(id)
    if view then
    	PopupViewController:addPopupView(view)
	end
--巨龙世界杯
end

open_act_handler[ "57399" ] = function( openParams, id )		
	local view = Drequire("game.dragonWarmUpBattle.DragonWarmUpView"):create()
	PopupViewController:addPopupInView(view)
end

open_act_handler[ "57186" ] = function( openParams, id )
	local view = Drequire("game.activity.GoldGroupBuy.GoldGroupBuyView").create()
	PopupViewController:call("addPopupInView", view)
end

open_act_handler[ "57426" ] = function( openParams, id ) --累计充值大回馈
	local view = Drequire("game.LiBao.Repay.RepayViewEx"):create()
	if view then
		PopupViewController:addPopupInView(view)
	end
end

open_act_handler[ "57188" ] = function( openParams, id ) 		-- 连续充值
    DataController.ModifyRechargeContinueControllerInst:showView()
end

open_act_handler[ "57224" ] = function( openParams, id ) --联盟传奇(充值)
	if  CCCommonUtilsForLua:isFunOpenByKey("alliance_recharge") then 
    	RechargeLegendController:setLegendType(Rechare_Legend_Alliance)
		local view = Drequire(RechargeLegendController:getViewPath()):create()
		PopupViewController:addPopupInView(view)
	end
end

open_act_handler[ "57160" ] = function( openParams, id )
	-- require("game.dragonWorldCup.DragonWorldCupManager").requestActivityData(true)
	local view = Drequire("game.dragonWorldCup.S4.DragonWorldCupS4EntranceView"):create()
	PopupViewController:addPopupInView(view)
end

open_act_handler[ "57225" ] = function( openParams, id ) --王国传奇(充值)
	if  CCCommonUtilsForLua:isFunOpenByKey("kingdom_recharge") then 
    	RechargeLegendController:setLegendType(Rechare_Legend_Kingdom)
		local view = Drequire("game.RechargeLegendKingdom.RechargeLegendKingdomView"):create()
		PopupViewController:addPopupInView(view)
	end
end

open_act_handler[ "57273" ] = function( openParams, id ) --夺宝活动
	if CCCommonUtilsForLua:isFunOpenByKey("win_super_gift") then
		CCCommonUtilsForLua.jumpToTarget(114,nil)
	end 
end

open_act_handler[ "57158" ] = function( openParams, id )
	NewRecallController:fireCommonEvent("createNewRecallView")
end

open_act_handler[ "57365" ] = function( openParams, id )
	local runingActCtl = require("game.activity.RunningRingAct.RunningRingActController").getInstance()
	if runingActCtl:isActivityOpen() then
		local view = Drequire("game.activity.RunningRingAct.RunningRingMainView"):create()
		if view then
			PopupViewController:addPopupView(view)
		end
	end
end

open_act_handler[ "57416" ] = function( openParams, id ) --周年打卡活动
	CCCommonUtilsForLua.jumpToTarget(7, "24")
end

open_act_handler[ "57159" ] = function( openParams, id )
	local lua_path = "game.activity.consumePoint.ConsumeActivityView"
	if CCCommonUtilsForLua:isFunOpenByKey("new_consume_view_switch") then 
		lua_path = "game.activity.consumePointEx.ConsumeActivityViewEx"
	end
    package.loaded[lua_path] = nil
    local view = require(lua_path):create()
    if view then
    	PopupViewController:addPopupView(view)	
    else
    	LuaController:flyHint("", "", getLang("170035"))
    end
end

open_act_handler[ "57568" ] = function( openParams, id ) -- 小累消
    local view = Drequire("game.activity.consumePointEx.ConsumeActivityViewExLittle"):create()
    if view then
    	PopupViewController:addPopupView(view)	
    else
    	LuaController:flyHint("", "", getLang("170035"))
    end
end

open_act_handler[ "57358" ] = function( openParams, id ) 	-- 虚空战场
	local index = WorldController:call("getIndexByPoint", ccp(VoidBattlefieldPoint.pointX,VoidBattlefieldPoint.pointY))
	SceneController:call("gotoScene", 11, false, true, index)
end

open_act_handler[ "57263" ] = function( openParams, id ) --联盟签到活动
	if CCCommonUtilsForLua:isFunOpenByKey("k_alliance_signin_reward_switch") then
		CCCommonUtilsForLua.jumpToTarget(108,nil)
	end 
end

open_act_handler[ "57189" ] = function( openParams, id )  
	local view = ConvertHappyFestivalContrllerInst:showShopView(id)
	view:setOpenParams(openParams)
end

open_act_handler[ "57190" ] = function( openParams, id ) 	-- 单笔充值
	local view = Drequire("game.activity.OneRecharge.OneRechargeView"):create()
    PopupViewController:addPopupInView(view)
end

open_act_handler[ "57375" ] = function( openParams, id )	--【Awen】战损玩家促活活动
	local _turntableId = CCCommonUtilsForLua:call("getPropByIdGroup","activity_panel", id, "para1")
	require('game.activity.Turntable.TurntableController').getInstance():openView(_turntableId)
end

open_act_handler[ "57420" ] = function( openParams, id ) -- 龙魂夺宝
	DataController.DragonSoulChaserMgrInst:showView()
end

open_act_handler[ "57175" ] = function( openParams, id ) 
	EggController:getInstance():openEggRhiexsView()
end

open_act_handler[ "57296" ] = function( openParams, id ) --钻石折扣活动
	if CCCommonUtilsForLua:isFunOpenByKey("diamond_discount_mall") then
		local view = Drequire("game.activity.DiamonDiscount.DiamondDiscountView"):create()
    	PopupViewController:addPopupInView(view)
	end
end
open_act_handler[ "57599" ] = function( openParams, id ) --新兵起航活动
	require("game.activity.newArmyAct.NewArmyCtr"):getInstance():showView()
end
open_act_handler[ "57605" ] = function( openParams, id ) --钻石翻牌活动
    require("game.activity.DiamondFlop.DiamondFlopCtr"):getInstance():showView()
end
open_act_handler[ "57607" ] = function( openParams, id ) --英雄BP活动
    require("game.HeroBP.HeroBPController"):getInstance():showPopView()
end
open_act_handler[ "57374" ] = function( openParams, id )	--【Awen】日常奖励：作战任务
	local view = Drequire("game.WelfareIntegrate.WelfareIntegrateMainView"):create({firstViewKey = "MergeServerActivity"})
	PopupViewController:addPopupInView(view)
end

open_act_handler[ "57227" ] = function( openParams, id )
	local view = Drequire("game.activity.web.WebActivityView"):create()
	PopupViewController:addPopupInView(view)
end

open_act_handler[ "57200" ] = function( openParams, id ) 
	local view = Drequire("game.activity.OnePurchaseActivity.OnePurchaseActivity"):create()
    PopupViewController:addPopupInView(view)
end

open_act_handler[ "57340" ] = function( openParams, id )	--【Awen】军团集结（造兵排行榜）
	local TrainingTroopsController = require("game.Training.troops.TrainingTroopsController").getInstance()
	if TrainingTroopsController:isOpen() then
		TrainingTroopsController:fireEventRef("openUI")
	else
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("146313"))	--146313=功能暂未开放，敬请期待！
	end
end

open_act_handler[ "57192" ] = function( openParams, id ) --四周年
	PopupViewController:call("addPopupInView", myRequire("game.anniversary3.anniversary3view").create())
end

open_act_handler[ "57208" ] = function( openParams, id ) 
	local view = Drequire("game.activity.ItemExchangeStore.ItemExchangeStoreView"):create()
    PopupViewController:addPopupInView(view)
	return
end

open_act_handler[ "57435" ] = function( openParams, id ) --小额连续付费
	require("game.activity.LittlePayman.LittlePaymanMgr").getInstance():requestInfo()
end

open_act_handler[ "57443" ] = function( openParams, id ) --王牌射手
	require("game.activity.MasterArcher.MasterArcherMgr").getInstance():requestInfo()
end

open_act_handler[ "57445" ] = function( openParams, id ) --时空宝藏
	require("game.activity.TimeTreasure.TimeTreasureMgr").getInstance():requestInfo()
end

open_act_handler[ "57457" ] = function( openParams, id ) --倍享好礼
	require("game.activity.MultiplyGift.MultiplyGiftMgr").getInstance():requestInfo()
end

open_act_handler[ "57468" ] = function( openParams, id ) --黄金探宝
	require("game.activity.GoldDigTreasure.GoldDigTreasureController").getInstance():showView()
end

open_act_handler[ "57476" ] = function( openParams, id ) -- 节日祝福
	require("game.activity.ValentinesDayWishes.ValentinesDayWishesController").getInstance():showView()
end

open_act_handler[ "57473" ] = function( openParams, id )
	require("game.commercialDarts.CommercialController").getInstance():showPopView()
end

open_act_handler[ "57485" ] = function( openParams, id ) --连续特惠
	require("game.activity.RechargeEveryDay.RechargeEveryDayController").getInstance():showView()
end

open_act_handler[ "57487" ] = function( openParams, id ) --新服累充
	require("game.activity.NewServerRepay.NewServerRepayController").getInstance():requestInfo()
end

open_act_handler[ "57492" ] = function( openParams, id ) --随选商城
	require("game.activity.RandomBuy.RandomBuyMgr").getInstance():showMainView()
end

open_act_handler[ "57500" ] = function( openParams, id ) --鲜花榜
	require("game.flower.FlowerController").getInstance():showPopView()
end

open_act_handler[ "57510" ] = function( openParams, id ) --联盟对决		
	local adCtrl = require("game.AllianceDuel.AllianceDuelController").getInstance()
	adCtrl:requestInfoData(1)
end

open_act_handler[ "57499" ] = function( openParams, id ) --丰收礼金
	require('game.activity.Windmill.WindmillMgr').getInstance():requestInfo()
end

open_act_handler[CiviMiracleConstData.activityId] = function ( openParams, id ) --奇迹保卫战
	DataController.CiviMiracleDefenceController:openActMainView()
end

open_act_handler[ "57517" ] = function( openParams, id ) --新英雄召集活动	
	local view = Drequire("game.activity.week.NewActivityWeekView"):create("57517")
	PopupViewController:addPopupInView(view)
end

open_act_handler[ "57515" ] = function( openParams, id ) --幸运轮盘活动	
	require('game.activity.LuckyRoulette.LuckyRouletteController').getInstance():showView()
end

open_act_handler[ "57520" ] = function( openParams, id ) --拼多多活动	
	require("game.LiBao.GroupBuy.LibaoGroupBuyMgr").getInstance():showMainView()
end

open_act_handler[ "57528" ] = function( openParams, id ) --商业之神
	require("game.commercialDarts.CommercialController").getInstance():showRankView()
end

open_act_handler[ "57459" ] = function( openParams, id ) --魔法抽卡界面
	require("game.activity.MagicDrawCard.MagicDrawCardMgr").getInstance():requestInfo()
end

open_act_handler[ "57530" ] = function( openParams, id ) --幸运直购
	require('game.activity.LuckyDirectPurchase.LuckyDirectPurchaseController').getInstance():showView()
end

open_act_handler["57546"] = function( openParams, id ) --世界争霸
	require("game.worldCraft.match.MatchController").getInstance():showOverView()
end

open_act_handler[ "57547" ] = function( openParams, id ) --新服连续特惠
	require("game.activity.RechargeEveryDayNS.RechargeEveryDayNSMgr").getInstance():showView()
end

open_act_handler["57549"] = function( openParams, id ) --世界争霸娱乐赛
	require('game.worldCraft.match.MatchController').getInstance():reqBaseData(true, true)
end

open_act_handler["57573"] = function( openParams, id ) --世界争霸娱乐赛房间模式
	require("game.worldCraft.room.RoomController").getInstance():showActivity()
end

open_act_handler["57548"] = function( openParams, id ) --皮肤活动
	local params = {}
	params.firstViewKey = "integrateSkinActView"
	local view = Drequire("game.WelfareIntegrate.WelfareIntegrateMainView"):create(params)
	PopupViewController:addPopupInView(view)
end

open_act_handler["57554"] = function( openParams, id ) --扩建活动
	require('game.activity.ExtendBuild.ExtendBuildMgr').getInstance():showView()
end

open_act_handler["57556"] = function( openParams, id ) --全民挖宝（宝石活动）
	require('game.activity.EveryoneDigGem.EveryoneDigGemMgr').getInstance():showView()
end

open_act_handler["57564"] = function( openParams, id ) --超级福利活动
	require("game.activity.SuperBenefits.SuperBenefitsMgr").getInstance():showView()
end

open_act_handler["57565"] = function( openParams, id ) --地心探宝
	require("game.activity.GeocentricTreasure.GeocentricTreasureMgr").getInstance():showView()
end

open_act_handler[ "57569" ] = function( openParams, id ) --小累充
	require("game.LiBao.Repay.RepayLittleMgr").getInstance():requestInfo()
end

open_act_handler[ "57571" ] = function( openParams, id ) --阵法演练活动
	require('game.activity.FormationTrainCarnival.FormationTrainCarnivalMgr').getInstance():showView()
end

open_act_handler[ "57578" ] = function( openParams, id ) --幸运抽奖
	require("game.activity.LuckyDrawSkin.LuckyDrawSkinMgr").getInstance():showView()
end

open_act_handler[ "57584" ] = function( openParams, id ) --圣诞献礼
	require("game.activity.ChristmasGift.ChristmasGiftMgr").getInstance():showView()
end

open_act_handler[ "57587" ] = function( openParams, id ) --自选礼包活动
	require("game.activity.OptionalLibao.OptionalLibaoMgr").getInstance():showView()
end

open_act_handler[ "57597" ] = function( openParams, id ) --COK年货节活动
	require("game.activity.SpringGiftFestival.SpringGiftFestivalMgr").getInstance():showView()
end

open_act_handler[ "57600" ] = function( openParams, id ) --杀戮战场段位模式
	require("game.Battlefield.room.RoomManager").getInstance():showView()
end

open_act_handler[ "57606" ] = function( openParams, id ) --点石成金活动（物品回收）
	require("game.activity.GoldenTouch.GoldenTouchMgr"):getInstance():showView()
end

open_act_handler[ "57613" ] = function( openParams, id ) --福利礼盒活动
	require("game.activity.WelfareGiftBox.WelfareGiftBoxMgr").getInstance():showView()
end

open_act_handler[ "57612" ] = function( openParams, id ) --金币献宝活动
	require('game.activity.GoldenGift.GoldenGiftMgr').getInstance():showView()
end

open_act_handler[ "57615" ] = function( openParams, id ) --周年庆礼包双倍活动 
	require('game.activity.LibaoMultiple.LibaoMultipleMgr').getInstance():showView()
end
open_act_handler[ "57616" ] = function( openParams, id ) --周年庆许愿树活动 
	require('game.WishTree.WishTreeController').getInstance():showPopView()
end
open_act_handler[ "57621" ] = function( openParams, id ) --对战棋活动 
	require('game.GameChess.GameChessController').getInstance():showPopView()
end