EquipmentController = EquipmentController or {}
-- 开始合成升品石
function EquipmentController:startComposeStone( itemId, num )
	MyPrint("EquipmentController:startComposeStone",itemId, num)
	if nil == itemId or nil == num then
		return false
	end

	local tinfo = ToolController:call("getToolInfoForLua", tonumber(itemId))
	if nil == tinfo then
		return false
	end

	local uuid = tinfo:getProperty("uuid")
	MyPrint("uuid", uuid)
	if "" == uuid or nil == uuid then
		return false
	end

	require("game.command.EquipmentCmd")
	local cmd = ComposeSuitStoneCmd.new(uuid, num)
	cmd:send()
end

function EquipmentController:endComposeStone( dict )
	MyPrint("endComposeStone")

	CCSafeNotificationCenter:call("postNotification", "msg_end_compose_stone")
end

-- 缓存一下放在槽里的石头id
function EquipmentController:cachStonePutOnData( groupId, itemId )
	if nil == groupId or nil == itemId  then
		return
	end

	local data = self:getCachedStonePutOnData()
	data[tonumber(groupId)] = tonumber(itemId)
end

-- 缓存一下放在槽里的装备uuid
function EquipmentController:cachEquipPutOnData( groupId, uuid )
	if nil == groupId or nil == itemId  then
		return
	end

	local data = self:getCachedEquipPutOnData()
	data[tonumber(groupId)] = uuid
end

function EquipmentController:getPutOnStoneByEquipGroupId( groupId )
	-- if true then
	-- 	return 211198
	-- end
	if nil == groupId then
		return 0
	end
	groupId = tonumber(groupId)
	local data = self:getCachedStonePutOnData()
	if nil == data[groupId] then
		return 0
	end
	return tonumber(data[groupId])
end

function EquipmentController:getPutOnEquipByEquipGroupId( groupId )
	-- if true then
	-- 	return 211198
	-- end
	MyPrint("getPutOnEquipByEquipGroupId ", groupId)
	if nil == groupId then
		return 0
	end
	groupId = tonumber(groupId)
	local data = self:getCachedEquipPutOnData()
	if nil == data[groupId] then
		return ""
	end
	return (data[groupId])
end

-- 获取放在槽里的某种石头的数量
function EquipmentController:getPutOnStoneCntById( itemId )
	if nil == itemId then
		return 0
	end
	itemId = tonumber(itemId)
	local ret = 0
	local data = self:getCachedStonePutOnData()
    local num = self:getCachedStonePutOnNumber()
    dump(data, "getPutOnStoneCntById data")
    dump(num, "getPutOnStoneCntById num")
	for k,v in pairs(data) do
		if v == itemId then
			-- ret = ret + 1
            for kk, vv in pairs(num) do
                if kk == itemId then
                    ret = ret + vv
                end
            end
		end
	end
    MyPrint("EquipmentController:getPutOnStoneCntById itemId ret",itemId, ret)
	return ret
end

function EquipmentController:isEquipAlreadyOn( uuid )
	-- body
	local data = self:getCachedEquipPutOnData()
	for k,v in pairs(data) do
		if v == uuid then
			return true
		end
	end
	return false
end

function EquipmentController:clearCachedStonePutOnData( )
	MyPrint("clearCachedStonePutOnData")
	self.cachedStonePutOnData = {}
    self.cachedStonePutOnNum = {}--放置在槽中的黑曜石的数量
end

function EquipmentController:clearCachedEquipPutOnData( )
	MyPrint("clearCachedStonePutOnData")
	self.cachedEquipPutOnData = {}
end

function EquipmentController:getCachedStonePutOnData(  )
	self.cachedStonePutOnData = self.cachedStonePutOnData or {}
	return self.cachedStonePutOnData
end

function EquipmentController:getCachedStonePutOnNumber()
    self.cachedStonePutOnNum = self.cachedStonePutOnNum or {}
    return self.cachedStonePutOnNum
end

function EquipmentController:getCachedEquipPutOnData( )
	-- body
	MyPrint("getCachedEquipPutOnData")
	self.cachedEquipPutOnData = self.cachedEquipPutOnData or {}
	dump(self.cachedEquipPutOnData, "self.cachedEquipPutOnData")
	return self.cachedEquipPutOnData
end

function EquipmentController:putOnStone( itemId, groupId ,needNum)
    needNum = needNum or 1
	MyPrint("EquipmentController:putOnStone",itemId, groupId, needNum)
	local data = self:getCachedStonePutOnData()
	data[tonumber(groupId)] = tonumber(itemId)
    local num = self:getCachedStonePutOnNumber()
    num[tonumber(itemId)] = tonumber(needNum)
end

function EquipmentController:putOnEquip( uuid, groupId )
	MyPrint("EquipmentController:putOnEquip", uuid, groupId)
	local data = self:getCachedEquipPutOnData()
	data[tonumber(groupId)] = uuid
end

function EquipmentController:takeOffStone(  groupId )
	MyPrint("takeOffStone", groupId)
	local data = self:getCachedStonePutOnData()
	data[tonumber(groupId)] = nil
    local num = self:getCachedStonePutOnNumber()
    num[tonumber(groupId)] = nil
end

function EquipmentController:takeOffEquip(  groupId )
	MyPrint("takeOffEquip", groupId)
	local data = self:getCachedEquipPutOnData()
	data[tonumber(groupId)] = nil
end

function EquipmentController:startForgeSuitEquipWithStone( groupId, subEquipUuid )

	if nil == groupId then
		return false
	end

	if CCCommonUtilsForLua:call("isFunOpenByKey", "equipment_rate_new") == false then
		return false
	end

	groupId = tonumber(groupId)

	-- 判断是否在锻造装备
	if (self:call("getCurForgingGroupId") ~= 0) then
		return false
	end
    
    local info = self:call("getBaseEquipmentInfoByGroupId", groupId)
    if info == nil then
    	return false
    end

    if info:call("isMaterialCntOkToForge") == false then
    	return false
    end
    
    local isUseGold = 0
    if info:call("isResourceCntOkToForge") == false then
    	isUseGold = 1
    end

    local uuid = "0"
    local itemId = self:getPutOnStoneByEquipGroupId(groupId)
    local tinfo = ToolController:call("getToolInfoForLua", itemId)
    if nil ~= tinfo then
    	uuid = tinfo:getProperty("uuid")
    end

    require("game.command.EquipmentCmd")
    local cmd = SuitEquipForgeStoneCmd.new(groupId, isUseGold, uuid)
    if nil ~= subEquipUuid and "" ~= subEquipUuid then
    	MyPrint("subEquipUuid not nil ", subEquipUuid)
    	cmd:putParam("sonEquipUUid", CCString:create(subEquipUuid))
    	cmd.subEquipUuid = subEquipUuid
    end
    cmd:send()
    
    return true 
end

function EquipmentController:endForgeSuitEquipWithStone( dict, groupId, subEquipUuid )
    MyPrint("endForgeSuitEquipWithStone", groupId, subEquipUuid)
	if (dict:objectForKey("errorCode")) then
        local errorCode = dict:valueForKey("errorCode"):getCString() 
        CCCommonUtilsForLua:call("flyText", getLang(errorCode))
    else
    	MyPrint("groupId", groupId)
    	local eInfo = self:call("getBaseEquipmentInfoByGroupId", groupId)
        
    	if nil == eInfo then
    		return
    	end

    	local mateMap = eInfo:getProperty("mateMap")
    	dump(mateMap, "mateMap")
    	-- 扣除材料
    	for k,v in pairs(mateMap) do
    		local kinfo = ToolController:call("getToolInfoForLua", tonumber(k))
    		if nil ~= kinfo then
    			local cnt = math.max(0, kinfo:call("getCNT") - tonumber(v))
    			kinfo:call("setCNT", cnt)
    		end
    	end

    	-- 加入队列
    	if nil ~= dict:objectForKey("queue") then
    		QueueController:call("addQueueInfo", dict:objectForKey("queue"))
    	end
        
        -- 同步资源
    	if nil ~= dict:objectForKey("resource") then
    		GlobalData:call("getResourceInfo"):call("setResourceData", dict:objectForKey("resource"))
    	end

    	if nil ~= dict:objectForKey("gold") then
    		local tmpInt = dict:valueForKey("gold"):intValue() 
    		UIComponent:call("updateGold", tmpInt)
    	end

    	local itemId = self:getPutOnStoneByEquipGroupId(groupId)
    	local tinfo = ToolController:call("getToolInfoForLua", itemId)
    	if tinfo ~= nil then
    		local cnt = tinfo:call("getCNT")
    		cnt = cnt - 1
    		cnt = math.max(0,cnt)
    		tinfo:call("setCNT", cnt)
    	end
    	self:takeOffStone(groupId)
    	if nil ~= subEquipUuid and "" ~= subEquipUuid then
    		MyPrint("delete equip !!! ", groupId, subEquipUuid)
	    	self:takeOffEquip(groupId)
	    	EquipmentController:call("deleteMyEquipment", subEquipUuid)
	    end

    	CCSafeNotificationCenter:call("postNotification", "city_resources_update")
        CCSafeNotificationCenter:call("postNotification", "group.equip.create.end", CCInteger:create(groupId)) 
        CCSafeNotificationCenter:call("postNotification", "showEquipTips")
    end
end

--制造材料完成同步CD
function EquipmentController:endCDCreateTool(dict)
	MyPrint("EquipmentController:endCDCreateTool")
	if nil == dict then return end
	
	local useLua = CCCommonUtilsForLua:call("isTestPlatformAndServer", "tool_create_ui")
	if useLua == false then return end

	local qid = dict:valueForKey("qid"):intValue()
	local _type = dict:valueForKey("type"):intValue()
	qid = QueueController:call("getQID", _type) + qid

	local allQueuesInfos = GlobalData:call("shared"):call("allQueuesInfo")
	local queueInfo = allQueuesInfos[qid]
	queueInfo:setProperty("finishTime", 0)
	queueInfo:setProperty("startTime", 0)
	CCSafeNotificationCenter:postNotification("msg_queue_remove")

	local curView = PopupViewController:call("getCurrentPopupView")
	local aniComplete = curView:call("isAniComplete")
	local toolView = require("game.equipment.ToolCreateView").getView()
	local equal = (toolView and (curView == toolView))
	local bid = FunBuildController:call("getMaxLvBuildByType", FUN_BUILD_WORKSHOP)
	if equal and aniComplete then
		local str = string.format("%d;%d", bid, 1)
		CCSafeNotificationCenter:postNotification("msg_quick_troops", CCString:create(str))
	else
		local str = string.format("%d;%d", bid, 0)
		CCSafeNotificationCenter:postNotification("msg_quick_troops", CCString:create(str))
	end
end

-- 根据equipid获取我的装备的uuid
function EquipmentController:getMyEquipsByEquipId( equipId )
	-- body
	equipId = math.tonumber(equipId)
	local ret = {}
	local function func( info )
		-- body
		if info:call("getEquipId") == equipId then
			ret[#ret + 1] = info:call("getUuid")
		end
	end
	local handler = luaRegisterHandler(func)
	EquipmentController:call("dumpMyEquipsForLua", handler)
	return ret
end

-- 根据equipid获取我的没有穿在身上的uuid
function EquipmentController:getMyEquipsByEquipIdNotOn( equipId )
	-- body
	-- body
	equipId = math.tonumber(equipId)
	local ret = {}
	local function func( info )
		-- body
		if info:call("getEquipId") == equipId and info:call("getBeOn") == false then
			ret[#ret + 1] = info:call("getUuid")
		end
	end
	local handler = luaRegisterHandler(func)
	EquipmentController:call("dumpMyEquipsForLua", handler)
	return ret
end


-- 根据equipid获取我的没有穿在身上的uuid
function EquipmentController:getMyEquipsByEquipIdOn( equipId )
    -- body
    -- body
    equipId = math.tonumber(equipId)
    local ret = {}
    local function func( info )
        -- body
        if info:call("getEquipId") == equipId and info:call("getBeOn") == true then
            ret[#ret + 1] = info:call("getUuid")
        end
    end
    local handler = luaRegisterHandler(func)
    EquipmentController:call("dumpMyEquipsForLua", handler)
    return ret
end

-------------------------------  NewEquip -------------------------------
equipBuildType = 
{
    EquipSingleWeapon = 0, -- 单件 武器
    EquipSingleHelmet = 1, -- 单件 头盔
    EquipSingleCloth = 2, -- 单件 衣服
    EquipSingleTrousers = 3, -- 单件 裤子
    EquipSingleShoes = 4, -- 单件 鞋子
    EquipSingleRing = 5, -- 单件 戒指
    EquipSuitReform = 6, -- 套装 改造
    EquipSuitNomal = 7, -- 套装 正常
}

suitBuildType = {
    SuitNomal = 1,
    SuitReform = 2,
}

colorState =
{
    ColorWhite = 1,
    ColorGreen = 2,
    ColorBlue = 3,
    ColorPurple = 4,
    ColorRed = 5,
    ColorGold = 6,
}
Color = {
    WHITE = 1,
    GREEN = 2,
    BLUE = 3,
    PURPLE = 4,
    ORANGE = 5,
    GOLDEN = 6,
}
function EquipmentController:initEquipXmlData(  ) -- 读取装备xml
    MyPrint("EquipmentController:initEquipXmlData")
    if not self.m_suitData or not self.m_suitReformData or not self.m_suitNomalData then
        self:initSuitXmlData()
    end

    if self.m_equipData and #self.m_equipData > 0 then
        return
    end
    local xmlData = CCCommonUtilsForLua:getGroupByKey("equipment")
    self.m_equipData = {} -- 所有装备列表
    self.m_equipDataMap = {}  -- 所有装备列表按ID存储
    self.m_equipSingleData = {} -- 单件、最高品质装备列表 0 -5
    self.m_equipSuitData = {} -- 套装、最高品质列表 nomal -- reform
    self.m_equipSuitNormalData = {} -- 套装、最高品质列表 nomal
    self.m_equipSuitReformData = {} -- 套装、最高品质列表 reform
    self.m_equipGuideData = {}
    local tempEquip0 = {}
    local tempEquip1 = {}
    local tempEquip2 = {}
    local tempEquip3 = {}
    local tempEquip4 = {}
    local tempEquip5 = {}
    local tempNormalEquip0 = {}
    local tempNormalEquip1 = {}
    local tempNormalEquip2 = {}
    local tempNormalEquip3 = {}
    local tempNormalEquip4 = {}
    local tempNormalEquip5 = {}
    local tempSuitNomal = {}
    local tempSuitRefom = {}

    if xmlData then
        for k,v in pairs(xmlData) do
            if v.show ~= "0" and v.show ~= "no" and v.no_forge ~= "1" then
                table.insert(self.m_equipData , v)
                self.m_equipDataMap[v.id] = v
                if v.color and tonumber(v.color) == 5  then -- 取最高品质
                    if v.suit_id and v.suit_id ~= "" then -- 套装
                        if v.reform and tonumber(v.reform) == 1 then
                            table.insert(tempSuitRefom , v)
                        else
                            table.insert(tempSuitNomal , v)
                        end
                    elseif not v.suit_id then
                        if not v.superior then 
                            v.superior = 0
                        end 
                        if v.superior == 0 then
                            if v.site and tonumber(v.site) == 0 then
                                table.insert(tempNormalEquip0 , v)
                            elseif v.site and tonumber(v.site) == 1 then
                                table.insert(tempNormalEquip1 , v)
                            elseif v.site and tonumber(v.site) == 2 then
                                table.insert(tempNormalEquip2 , v)
                            elseif v.site and tonumber(v.site) == 3 then
                                table.insert(tempNormalEquip3 , v)
                            elseif v.site and tonumber(v.site) == 4 then
                                table.insert(tempNormalEquip4 , v)
                            elseif v.site and tonumber(v.site) == 5 then
                                table.insert(tempNormalEquip5 , v)
                            end
                        else
                            if v.site and tonumber(v.site) == 0 then
                                table.insert(tempEquip0 , v)
                            elseif v.site and tonumber(v.site) == 1 then
                                table.insert(tempEquip1 , v)
                            elseif v.site and tonumber(v.site) == 2 then
                                table.insert(tempEquip2 , v)
                            elseif v.site and tonumber(v.site) == 3 then
                                table.insert(tempEquip3 , v)
                            elseif v.site and tonumber(v.site) == 4 then
                                table.insert(tempEquip4 , v)
                            elseif v.site and tonumber(v.site) == 5 then
                                table.insert(tempEquip5 , v)
                            end
                        end
                        
                    end
                end
            end
            -- MyPrint("qqqv.id", v.id)
            if tonumber(v.id) == 1001015 then
                table.insert(self.m_equipGuideData, v)
                dump(self.m_equipGuideData, "qqqm_equipGuideData")
            end
        end
    end
    if tempNormalEquip0 and tempNormalEquip1 and tempNormalEquip2 and tempNormalEquip3 and tempNormalEquip4 and tempNormalEquip5 then
        function sortByLevel(a,b)
            return tonumber(a.level) > tonumber(b.level)
        end
        function insertTable( a,b )
            for k,v in pairs(b) do
                table.insert(a,v)
            end
        end
        table.sort(tempNormalEquip0,sortByLevel)
        table.sort(tempNormalEquip1,sortByLevel)
        table.sort(tempNormalEquip2,sortByLevel)
        table.sort(tempNormalEquip3,sortByLevel)
        table.sort(tempNormalEquip4,sortByLevel)
        table.sort(tempNormalEquip5,sortByLevel)
        if #tempEquip0 > 0 then
            table.sort(tempEquip0,sortByLevel)
            insertTable(tempEquip0,tempNormalEquip0)
        end
        if #tempEquip1 > 0 then
            table.sort(tempEquip1,sortByLevel)
            insertTable(tempEquip1,tempNormalEquip1)
        end
        if #tempEquip2 > 0 then
            table.sort(tempEquip2,sortByLevel)
            insertTable(tempEquip2,tempNormalEquip2)
        end
        if #tempEquip3 > 0 then
            table.sort(tempEquip3,sortByLevel)
            insertTable(tempEquip3,tempNormalEquip3)
        end
        if #tempEquip4 > 0 then
            table.sort(tempEquip4,sortByLevel)
            insertTable(tempEquip4,tempNormalEquip4)
        end
        if #tempEquip5 > 0 then
            table.sort(tempEquip5,sortByLevel)
            insertTable(tempEquip5,tempNormalEquip5)
        end
        -- table.sort(tempEquip1,sortByLevel)
        -- table.sort(tempEquip2,sortByLevel)
        -- table.sort(tempEquip3,sortByLevel)
        -- table.sort(tempEquip4,sortByLevel)
        -- -- table.sort(tempEquip5,sortByLevel)
        -- table.sort(tempNormalEquip0,sortBySuperior)
        -- table.sort(tempNormalEquip1,sortBySuperior)
        -- table.sort(tempNormalEquip2,sortBySuperior)
        -- table.sort(tempNormalEquip3,sortBySuperior)
        -- table.sort(tempNormalEquip4,sortBySuperior)
        -- table.sort(tempNormalEquip5,sortBySuperior)
        -- for k, v in pairs(tempNormalEquip0) do

        table.insert(self.m_equipSingleData , #tempEquip0 == 0 and tempNormalEquip0 or tempEquip0)
        table.insert(self.m_equipSingleData , #tempEquip1 == 0 and tempNormalEquip1 or tempEquip1)
        table.insert(self.m_equipSingleData , #tempEquip2 == 0 and tempNormalEquip2 or tempEquip2)
        table.insert(self.m_equipSingleData , #tempEquip3 == 0 and tempNormalEquip3 or tempEquip3)
        table.insert(self.m_equipSingleData , #tempEquip4 == 0 and tempNormalEquip4 or tempEquip4)
        table.insert(self.m_equipSingleData , #tempEquip5 == 0 and tempNormalEquip5 or tempEquip5)
    end

    function sortBySite(a,b)
        return tonumber(a.site) < tonumber(b.site)
    end
    if tempSuitNomal then
        for k,v in pairs(self.m_suitNomalData) do
            if v.id then
                local suitIdTbl = {}
                for b,d in pairs(tempSuitNomal) do
                    if d.suit_id and tonumber(d.suit_id) == tonumber(v.id) then
                        table.insert(suitIdTbl , d)
                    end
                end
                table.sort(suitIdTbl , sortBySite)
                self.m_equipSuitNormalData[v.id] = suitIdTbl
            end
        end
    end
    if tempSuitRefom then
        for k,v in pairs(self.m_suitReformData) do
            if v.id then
                local suitIdTbl = {}
                for b,d in pairs(tempSuitRefom) do
                    if d.suit_id and tonumber(d.suit_id) == tonumber(v.id) then
                        table.insert(suitIdTbl , d)
                    end
                end
                table.sort(suitIdTbl , sortBySite)
                self.m_equipSuitReformData[v.id] = suitIdTbl
            end
        end
    end
    if self.m_equipSuitNormalData and self.m_equipSuitReformData then
        table.insert(self.m_equipSuitData , self.m_equipSuitNormalData)
        table.insert(self.m_equipSuitData , self.m_equipSuitReformData)
    end
    -- dump(self.tempEquip0, "~~~~~~~~self.tempEquip0~~~~~~~~")
    -- dump(self.m_equipData , "EquipmentController m_equipData")
    -- dump(self.m_equipSuitData , "EquipmentController m_equipSuitData")
    -- dump(self.m_equipSingleData , "EquipmentController m_equipSingleData")
    -- dump(self.m_equipSuitNormalData , "EquipmentController m_equipSuitNormalData")
end

function EquipmentController:initSuitXmlData(  ) -- 读取套装xml
    local xmlData = CCCommonUtilsForLua:getGroupByKey("suit")
    self.m_suitData = {} -- 套装列表
    self.m_suitNomalData = {} -- 正常套装、高品质列表 
    self.m_suitReformData = {} -- 改造套装、高品质列表
    if xmlData then
        for k,v in pairs(xmlData) do
            if v.show ~= "0" and v.show ~= "no" and v.no_forge ~= "1"  then
                table.insert(self.m_suitData , v)
                if v.suit_color and tonumber(v.suit_color) == 5  then
                    if v.reform and tonumber(v.reform) == 1 then
                        table.insert(self.m_suitReformData , v)
                    else
                        table.insert(self.m_suitNomalData , v)
                    end
                end
            end
        end
    end
    function sortByOrder(a,b)
        return tonumber(a.order) > tonumber(b.order)
    end
    table.sort(self.m_suitReformData,sortByOrder)
    table.sort(self.m_suitNomalData,sortByOrder)
    -- dump(self.m_suitData , "EquipmentController m_suitData")
    -- dump(self.m_suitReformData , "EquipmentController m_suitReformData")
    -- dump(self.m_suitNomalData , "EquipmentController m_suitNomalData")
end

function EquipmentController:getEquipXmlDataByType( equipType )
    MyPrint("EquipmentController:getEquipXmlDataByType")
    -- dump(self.m_equipSingleData, "~~~~~~~~self.m_equipSingleData~~~~~~~~")
    if not self.m_equipData or not self.m_equipSuitData or not self.m_equipSingleData then
        self:initEquipXmlData()
    end
    if tonumber(equipType) >= tonumber(equipBuildType.EquipSingleWeapon) and tonumber(equipType) <= tonumber(equipBuildType.EquipSingleRing) then
        return self.m_equipSingleData[tonumber(equipType) + 1] or {}
    elseif equipType == equipBuildType.EquipSuitNomal then
        return self.m_equipSuitData[1] or {}
    elseif equipType == equipBuildType.EquipSuitReform then
        return self.m_equipSuitData[2] or {}
    else
        return self.m_equipData or {}
    end
end

function EquipmentController:getEquipGuideData()
    self:initEquipXmlData()
    return self.m_equipGuideData
end

function EquipmentController:getEquipDataById(equipId)
    if self.m_equipDataMap == nil then
        self:initEquipXmlData()
    end
   return self.m_equipDataMap[equipId] 
end


function EquipmentController:getSuitXmlDataByType( suitType )
    if not self.m_suitData or not self.m_suitReformData or not self.m_suitNomalData then
        self:initSuitXmlData()
    end
    if suitType == suitBuildType.SuitNomal then
        return self.m_suitNomalData or {}
    elseif suitType == suitBuildType.SuitReform then
        return self.m_suitReformData or {}
    else
        return self.m_suitData or {}
    end
end

function EquipmentController:initRandomPowerXmlData(  )
    self.m_randomPowerData = {}
    local xmlData = CCCommonUtilsForLua:getGroupByKey("equipmentRandomPower")
    for k,v in pairs(xmlData) do 
        self.m_randomPowerData[#self.m_randomPowerData] = v
    end
end


function EquipmentController:initConfigData(dict)
    self.m_drawEffect = -1
    self.m_drawTimeMax = 2
    self.m_equipRanEffectNum = 0
    self.m_drawDeltPix = 50
    self.m_comboMax = 7
    self.m_recastRate = ""
    self.m_recastSumPercent = 0
    self.m_recastSumUpperLimit = 100
    local params = dict:objectForKey("equipment_combine")
    if params then
        local data = dictToLuaTable(params)
        if data.k1 then
            self.m_drawEffect = tonumber(data.k1)
        end
        if data.k4 then
            self.m_drawTimeMax = tonumber(data.k4)
        end
        if data.k5 then
            self.m_equipRanEffectNum = tonumber(data.k5)
        end
        if data.k6 then
            self.m_drawDeltPix = tonumber(data.k6)
        end
        if data.k8 then 
            self.m_comboMax = tonumber(data.k8)
        end
        if data.k9 then 
            self.m_recastRate = tostring(data.k9)
        end
        if data.k10 then 
            self.m_recastSumPercent = tonumber(data.k10)
        end
        if data.k11 then 
            self.m_recastSumUpperLimit = tonumber(data.k11)
        end
    end
end
--装备概率算法（LUA）
function EquipmentController:NewMakeEquipmentPro(uuid, toolUuids, paper, stoneId, rate)
    local colorNums = {}
    local tmpColorMap = {}
    tmpColorMap[Color.WHITE] = 0
    tmpColorMap[Color.GREEN] = 0
    tmpColorMap[Color.BLUE] = 0
    tmpColorMap[Color.PURPLE] = 0
    tmpColorMap[Color.ORANGE] = 0
    tmpColorMap[Color.GOLDEN] = 0
    local k2 = EquipmentController:call("getInstance"):getProperty("m_defPro")
    local k3 = EquipmentController:call("getInstance"):getProperty("m_equipmentCombineK3")
    local k9 = EquipmentController:call("getInstance"):getProperty("m_colorPro")
    local k10 = EquipmentController:call("getInstance"):getProperty("m_lvToCnt")
    local tmpVec = string.split(k3, "|")
    
    -- dump(toolUuids, "toolUuids~~~~~")
    -- dump(paper, "paper~~~~~")
    -- dump(rate, "rate~~~~~")
    local info = EquipmentController:call("getInstance"):call("getMyEquipInfoByUuid", uuid)
    -- MyPrint("342343224", info:call("getColor"), info:call("getLevel"))
    if info ~= nil then 
        local tmpCnt = 1 
        if k10[info:call("getLevel")] ~= nil then 
            tmpCnt = k10[info:call("getLevel")]
        end
        if rate == 5 and info:call("getColor") == 5 then 
            tmpColorMap[info:call("getColor")+1] = tmpColorMap[info:call("getColor")+1] + tmpCnt * 0.4
        else
            tmpColorMap[info:call("getColor")+1] = tmpColorMap[info:call("getColor")+1] + tmpCnt
        end
    end
    for i = 1, #toolUuids do 
        if paper[i] == -1 then
            local tool = ToolController:call("getInstance"):call("getToolInfoByIdForLua",toolUuids[i])
            tmpColorMap[tool:getProperty("color")+1] = tmpColorMap[tool:getProperty("color")+1] + 1
        else
            local needNum = paper[i]
            
            
            local curLevel = 0
            local curRate = toolUuids[i] / needNum
            local upperLimit = 0
            local lowerLimit = 0
            local level = 1
            for idx = 1, #tmpVec do 
                local tmpStr = tmpVec[idx]
                local k3Vec = string.split(tmpStr, ";")
                if #k3Vec == 2 then 
                    local curUpperLimit = tonumber(k3Vec[2])
                    local curLowerLimit = tonumber(k3Vec[1])
                    if curLowerLimit <= curRate and curUpperLimit >= curRate then 
                        upperLimit = curUpperLimit
                        lowerLimit = curLowerLimit
                        curLevel = level
                        break
                    end
                    level = level + 1
                end
            end 
            tmpColorMap[curLevel] = tmpColorMap[curLevel] + (1 + (curRate - lowerLimit) / (upperLimit - lowerLimit)) * 6
        end
    end
    -- dump(tmpColorMap, "tmpColorMap~~~~~")
    local minColor = 99
    local maxColor = 99
    local cntPro = 100
    local tmpColorPro = {}
    tmpColorPro[Color.WHITE] = 0
    tmpColorPro[Color.GREEN] = 0
    tmpColorPro[Color.BLUE] = 0
    tmpColorPro[Color.PURPLE] = 0
    tmpColorPro[Color.ORANGE] = 0
    tmpColorPro[Color.GOLDEN] = 0
    local TmpCNum = 1 
    for color = Color.GOLDEN, Color.WHITE , -1 do 
        -- MyPrint("23423456777", color)
        if tmpColorMap[color] > 0 then
            tmpColorPro[color] = 0
            if maxColor == 99 then 
                maxColor = color
                minColor = color
            else
                minColor = color 
            end
            colorNums[color] = TmpCNum
            TmpCNum = TmpCNum + 1 
        else
            if maxColor == 99 and minColor == 99 then 
                tmpColorPro[color] = k2[color-1]
                cntPro = cntPro - tmpColorPro[color]
                colorNums[color] = 0
            else
                tmpColorPro[color] = 0
                colorNums[color] = TmpCNum
                TmpCNum = TmpCNum + 1 
            end
        end
    end
    if minColor == maxColor then 
        tmpColorPro[maxColor] = cntPro
    else
        local sumWeight = 0
        local curWeightMap = {}
        for c = Color.GOLDEN, Color.WHITE, -1 do
            if colorNums[c] > 0 then 
                local tmpSum = 0
                local tmpC = c
                while tmpC >= Color.WHITE do
                    tmpSum = tmpSum + tmpColorMap[tmpC]
                    tmpC = tmpC - 1
                end
                local tmpCCNum = colorNums[c]
                local tmpCCSum = 0
                while tmpCCNum >= 1 do 
                    tmpCCSum = tmpCCSum + k9[tmpCCNum-1]
                    tmpCCNum = tmpCCNum - 1
                end
                curWeightMap[c] = tmpColorMap[c] + tmpSum * tmpCCSum
                sumWeight = sumWeight + curWeightMap[c]
            else
                curWeightMap[c] = 0
            end
        end
        -- dump(curWeightMap, "curWeightMap~~~~")
        local lastPro = cntPro
        for j = maxColor, minColor, -1 do
            if j == minColor then 
                tmpColorPro[j] = lastPro
            else
                local tmpProTT = cntPro * 100 * curWeightMap[j] / sumWeight
                tmpColorPro[j] = tmpProTT / 100
                lastPro = lastPro - tmpColorPro[j]
            end
        end
    end
    local value = CCCommonUtilsForLua:call("getEffectValueByNum", 2201) + CCCommonUtilsForLua:call("getEffectValueByNum", 2214)
    if value > 0.1 then 
        local maxColor = Color.WHITE
        local minColor = Color.GOLDEN
        for i = Color.WHITE, Color.GOLDEN do 
            if tmpColorPro[i] > 0.001 then 
                if i < minColor then 
                    minColor = i
                end
                if i > maxColor then 
                    maxColor = i
                end
            end
        end
        if maxColor > minColor then 
            local curValue = value
            for i = minColor, maxColor do
                if curValue <= 0 then 
                    break
                end
                local tmp = math.min(tmpColorPro[i], curValue)
                tmpColorPro[i] = tmpColorPro[i] - tmp
                curValue = curValue - tmp
            end
            tmpColorPro[maxColor] = tmpColorPro[maxColor] + value
            tmpColorPro[maxColor] = math.min(100, tmpColorPro[maxColor])
        end
    end
    local stonePercent = tonumber(CCCommonUtilsForLua:getPropById(tostring(stoneId), "para4"))
    if stonePercent and stonePercent ~= 0 then
        if tmpColorPro[Color.GOLDEN] + stonePercent > 100 then 
            for i = Color.WHITE, Color.ORANGE do 
                tmpColorPro[i] = 0
            end
            tmpColorPro[Color.GOLDEN] = 100
        else
            for i = Color.WHITE, Color.ORANGE do 
                tmpColorPro[i] = tmpColorPro[i] * (100 - tmpColorPro[Color.GOLDEN] - stonePercent) / (100 - tmpColorPro[Color.GOLDEN])
            end
            tmpColorPro[Color.GOLDEN] = tmpColorPro[Color.GOLDEN] + stonePercent
        end
    end
    -- dump(tmpColorPro, "tmpColorPro~~~~")
    return tmpColorPro

end

function EquipmentController:getEquipShowColor(colorType)
    if colorType == 0 then 
        return cc.c3b(199, 190, 179)
    elseif colorType == 1 then 
        return cc.c3b(86, 229, 120)
    elseif colorType == 2 then 
        return cc.c3b(69, 153, 248)
    elseif colorType == 3 then 
        return cc.c3b(175, 73, 234)
    elseif colorType == 4 then 
        return cc.c3b(232, 119, 31)
    elseif colorType == 5 then 
        return cc.c3b(255, 182, 0)
    else
        return cc.c3b(158, 130, 100)
    end
end

--激活精良装备随机属性
function EquipmentController:activeRandomProperty(uuid, extraCount)
    if uuid ~= "" then
        local cmd = require("game.command.ActivePropertyCommand"):create(uuid, extraCount)
        cmd:send()
    end
end


function EquipmentController:getRandomPropPower( equipUuid )
    local ret = 0
    local minfo = EquipmentController:call("getMyEquipInfoByUuid", equipUuid)
    if minfo ~= nil then 
        local extraCount = mInfo:getProperty("extraCount")
        local extraPropStr = mInfo:getProperty("extraPropStr")
        dump(extraPropStr, "EquipmentController:getRandomPropPower extraPropStr=")
        if self.m_randomPowerData == nil then 
            self:initRandomPowerXmlData()
        end
    end
    -- for i=extraCount+1, #parasMap do

    -- end 
    return ret
end

function EquipmentController:getRandomValuePro( itemId, dialog, value)
    local randomId = CCCommonUtilsForLua:getPropByIdGroup("equipment",itemId, "ran")
    local dialogs = CCCommonUtilsForLua:getPropByIdGroup("dg_refinement",randomId, "dialog")
    local minNums = CCCommonUtilsForLua:getPropByIdGroup("dg_refinement",randomId, "min")
    local maxNums = CCCommonUtilsForLua:getPropByIdGroup("dg_refinement",randomId, "max")
    local dialogVec = string.split(dialogs, "|")
    local minVec = string.split(minNums, "|")
    local maxVec = string.split(maxNums, "|")
    local ret = 0
    if #dialogVec ~= #minVec or #minVec ~= #maxVec then
        return ret
    end
    local count = #dialogVec
    for i=1, count do 
        if dialog == dialogVec[i] then 
            local min = tonumber(minVec[i])
            local max = tonumber(maxVec[i])
            ret = (value - min) / (max- min)
            break
        end
    end
    return ret
end

function EquipmentController:getColorByValue(pro)
    local ret = cc.c3b(0,0,0)
    local idx = 1
    local k9 = EquipmentController:call("getInstance"):getProperty("m_k9")
    local tmpVec = string.split(k9, "|")
    local colorToValueVec = {}
    for i=1, #tmpVec do
        local tmpColorVec = string.split(tmpVec[i], ";")
        if #tmpColorVec >= 3 then
            colorToValueVec[tonumber(tmpColorVec[3])] = ccp(tonumber(tmpColorVec[1]), tonumber(tmpColorVec[2]))
        end
    end
    for i=1, 6 do
        if colorToValueVec[i] ~= nil then 
            if colorToValueVec[i].x <= pro and colorToValueVec[i].y > pro then 
                idx = i
                break
            end
        end
    end
    if idx == 1 then 
        ret = cc.c3b(180,172,163)
    elseif idx == 2 then 
        ret = cc.c3b(107,153,26)
    elseif idx == 3 then 
        ret = cc.c3b(33,122,179)
    elseif idx == 4 then 
        ret = cc.c3b(137,91,231)
    elseif idx == 5 then 
        ret = cc.c3b(179,102,33)
    elseif idx == 6 then 
        ret = cc.c3b(219,176,58)
    end
    return ret
end



function EquipmentController:findDarkRateOfLongjing( itemId, dialog )
    local ret = 0
    local ranId = CCCommonUtilsForLua:getPropByIdGroup("equipment",tostring(itemId), "ran")
    local dialogVec = string.split(CCCommonUtilsForLua:getPropByIdGroup("dg_refinement",ranId, "dialog"),"|")
    local darkRateVec = string.split(CCCommonUtilsForLua:getPropByIdGroup("dg_refinement",ranId, "dark_rate"),"|")
    if #dialogVec == #darkRateVec then
        for i=1, #dialogVec do 
            if tostring(dialogVec[i]) == tostring(dialog) then 
                ret = tonumber(darkRateVec[i])
                break
            end
        end
    end
    return ret
end

function EquipmentController:strengthPerfectEquip(data)
    local _worldTime = GlobalData:call("shared"):call("getWorldTime") 
    _worldTime = _worldTime * 1000
    _worldTime = GlobalData:call("shared"):call("renewTime", _worldTime)

    local _time = _worldTime + 1000 * 60
    --221211=不可思议，恭喜{0}的{1}成功强化到{2}等级！

    local eName = CCCommonUtilsForLua:getPropByIdGroup("equipment", data.itemId, "name")
    local _tip = getLang("221211", data.userName or "", getLang(eName), data.level)
    CCCommonUtilsForLua:call("flySystemUpdateHint", _time, true, _tip, FlyHintType.FLY_HINT_NORMAL)
end

function EquipmentController:tryAddStrengthNumOnEquip(equipId,node,heroId,pos)
    local info
    for i = 0, 5 do
        local equipUuid = EquipmentController:call("FindOnEquipBySite", i, heroId)
        if equipUuid ~= "" then
            local equipInfo = EquipmentController:call("getMyEquipInfoByUuid", equipUuid)
            if equipInfo and equipInfo:call("getEquipId") == equipId then
                info = equipInfo
                break
            end
        end
    end

    local showFlag = false

    if info then
        local equipId = info:call("getEquipId")
        -- cclog("equipId is %s",equipId)
        local isCanStrength = info:call("getCanStrength") and isFunOpenByKey("equipment_strengthen")
        if isCanStrength then
            local strLv = math.numInRange(info:call("getStrengthLevel"),0,10)
            if strLv > 0 then
                local strLvPicPath = string.format("equipment_strength_%s.png",strLv)
                -- cclog("strLv and pic is %s,%s",strLv,strLvPicPath)
                local strengthLvFrame = CCLoadSprite:call("getSF",strLvPicPath)
                if strengthLvFrame then
                    showFlag = true
                    pos = pos or cc.p(35,47)
                    local checkTag = 115
                    if node:getChildByTag(checkTag) then
                        node:removeChildByTag(checkTag)
                    end
                    local spr = cc.Sprite:createWithSpriteFrame(strengthLvFrame)
                    node.m_strengthTxt = spr
                    spr:setPosition(pos)
                    spr:setTag(checkTag)
                    node:addChild(spr)
                    -- node.m_strengthTxt
                    -- if not spr then
                    --     spr = cc.Sprite:createWithSpriteFrame(strengthLvFrame)
                    --     node.m_strengthTxt = spr
                    --     spr:setPosition(pos)
                    --     node:addChild(spr)
                    -- else
                    --     -- spr:setVisible(true)
                    --     -- spr:setSpriteFrame(strengthLvFrame)
                    -- end
                end
            end
        end
    end

    -- if not showFlag and node.m_strengthTxt and tolua.isnull then
    --     node.m_strengthTxt:setVisible(false)
    -- end
end

function EquipmentController:getSuitColor( suitId,useGrey )
    if useGrey then
        return cc.c3b(126, 116, 104)
    end

    local color = tonumber(CCCommonUtilsForLua:call("getPropByIdGroup", "suit", tostring(suitId), "suit_color"))
    local lblColor = cc.c3b(199, 190, 179)
    if color == 1 then
        lblColor = cc.c3b(86, 229, 120)
    elseif color == 2 then
        lblColor = cc.c3b(69, 153, 248)
    elseif color == 3 then
        lblColor = cc.c3b(175, 73, 234)
    elseif color == 4 then
        lblColor = cc.c3b(232, 119, 31)
    elseif color == 5 then
        lblColor = cc.c3b(237, 213, 56)
    end
    return lblColor
end
