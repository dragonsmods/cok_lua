ActivityEventObj = ActivityEventObj or {}
ActivityEventObjForLua = ActivityEventObjForLua or {}

------------------------------------------------------------------------------
------------------------------------------------------------------------------
------------------------------------------------------------------------------

function ActivityEventObj:isServerValid(  )
	-- MyPrint("ActivityEventObj:isServerValid")
	return true
end

function ActivityEventObj:loadResource(  )
	CCLoadSprite:call("doResourceByCommonIndex", 500, true)
	CCLoadSprite:call("doResourceByCommonIndex", 506, true)
    CCLoadSprite:call("loadDynamicResourceByName", "activity_ad")
    CCLoadSprite:call("loadDynamicResourceByName", "activity_ad_2")
    CCLoadSprite:call("loadDynamicResourceByName", "activity_res")
    local id = self:getProperty("id")
    
    local dypath = cc.FileUtils:getInstance():getWritablePath()

    local md5 = self:getProperty("md5")
    local path1 = dypath .. "lua/" .. id .. "/resources/activity_" .. id .."_new.plist"
    if md5 ~= "" 
    	and LuaController:call("checkValidActivity", id, md5)
    	and cc.FileUtils:getInstance():isFileExist(path1)
    	then
    	cc.SpriteFrameCache:getInstance():addSpriteFrames(path1)
    end

    local resname = self:getDyResName()
    local path2 = dypath .. "dresource/" .. resname .. ".plist"
    if DynamicResourceController2:call("checkDynamicResource", resname)
    	and cc.FileUtils:getInstance():isFileExist(path2)
    	then
    	cc.SpriteFrameCache:getInstance():addSpriteFrames(path2)
    end

    local path3 = dypath .. "lua/resources/activity_" .. id .. ".plist"
    if LuaController:call("isLuaFilesValid") 
    	and cc.FileUtils:getInstance():isFileExist(path3)
    	then
    	cc.SpriteFrameCache:getInstance():addSpriteFrames(path3)
    end

    local path4 = dypath .. "lua/resources/" .. id .. "_pic.plist"
    if LuaController:call("isLuaFilesValid") 
    	and cc.FileUtils:getInstance():isFileExist(path4)
    	then
    	cc.SpriteFrameCache:getInstance():addSpriteFrames(path4)
    end
end

function ActivityEventObj:getAdFrame(  )
	-- MyPrint("ActivityEventObj:getAdFrame")
	self:loadResource()
	local ret = CCLoadSprite:call("getSF", self:getProperty("Advertise_pic") .. ".png")

	local type_ = tonumber(self:getProperty("type"))
	if type_ == 3 then -- 黑骑士
		local actId = HeiqishiNewSkinController:call("getInstance"):call("getactId")
		if actId ~= "" then
			local picstr = actId .. "_ad1.png"
			ret = CCLoadSprite:call("getSF", picstr)
		end
	end

	if nil == ret then
		ret = CCLoadSprite:call("getSF", self:getProperty("id") .. "_ad1_new.png")
	end
	if nil == ret then
		ret = CCLoadSprite:call("getSF", self:getProperty("id") .. "_pic.png")
	end
	if nil == ret then
		ret = CCLoadSprite:call("getSF", "activity_ad_beiyong.png")
	end
	-- MyPrint("ret ", ret)
	return ret
end

function ActivityEventObj:getIconFrame(  )
	-- MyPrint("ActivityEventObj:getIconFrame")
	self:loadResource()
	local ret = CCLoadSprite:call("getSF", "activity_".. self:getProperty("id") .. "_list_cell_head_new.png")

	local type_ = tonumber(self:getProperty("type"))
	if type_ == 3 then -- 黑骑士
		local actId = HeiqishiNewSkinController:call("getInstance"):call("getactId")
		if actId ~= "" then
			local picstr = actId .. "_icon.png"
			ret = CCLoadSprite:call("getSF", picstr)
		end
	end

	if ret == nil then
		local picstr = CCCommonUtilsForLua:call("getPropById", self:getProperty("id"), "icon") .. ".png"
		ret = CCLoadSprite:call("getSF", picstr)
	end
	if nil == ret then
		ret = CCLoadSprite:call("getSF", "Ativity_iconLogo_" .. tostring(self:getProperty("type")) .. ".png")
	end
	if nil == ret then
		ret = CCLoadSprite:call("getSF", "Ativity_iconLogo_" .. tostring(self:getProperty("id")) .. ".png")
	end
	if nil == ret then
		ret = CCLoadSprite:call("getSF", "Ativity_iconLogo_1.png")
	end
	-- MyPrint("ret", ret)
	return ret
end

function ActivityEventObj:getDyResName(  )
	return self:getProperty("id") .. "_face"
end

function ActivityEventObj:loadActivityRes()
	local id = self:getProperty("id")
    local dypath = cc.FileUtils:getInstance():getWritablePath()
    local path = dypath .. "lua/" .. id .. "/resources/activity_" .. id .."_new.plist"
    if cc.FileUtils:getInstance():isFileExist(path) then
    	cc.SpriteFrameCache:getInstance():addSpriteFrames(path)
    end
end

------------------------------------------------------------------------------
------------------------------------------------------------------------------
------------------------------------------------------------------------------



------------------------------------------------------------------------------
------------------------------------------------------------------------------
------------------------------------------------------------------------------

-- lua obj 基类

-- 返回ActivityStage 和 该阶段剩余时间
-- 子类要实现这个函数！！！！！！！！
ActivityEventObjForLua.getCurActivityStageAndLeftTime = nil

-- 获取显示在活动中心的时间内容
-- 子类要实现这个函数！！！！！！！！
ActivityEventObjForLua.getGameTickStr = nil

-- 可重载 进入活动中心时调用
function ActivityEventObjForLua:requestActivityDetail(  )
	-- MyPrint("ActivityEventObjForLua:requestActivityDetail")
	return
end

-- 可重载
function ActivityEventObjForLua:parse( params )
	-- MyPrint("ActivityEventObjForLua:parse")
	self:call("parse", params)
end

-- 可重载
function ActivityEventObjForLua:isRelatedSwitchOpen(  )
	-- MyPrint("ActivityEventObjForLua:isRelatedSwitchOpen true")
	return true
end

-- 不要重载
function ActivityEventObjForLua:init(params)
	--MyPrint("ActivityEventObjForLua:init")
	if nil == params then
		return false
	end

	self:parse(params)

	if CCCommonUtilsForLua:call("getPropById", self:getProperty("id"), "id") == "" then
		return false
	end

	if self:call("isCountryValid") == false then
		-- MyPrint("ActivityEventObjForLua isCountryValid false")
		return false
	end

	if self:call("isServerValid") == false then
		-- MyPrint("ActivityEventObjForLua isServerValid false")
		return false
	end

	if self:isAnalyticIDOk() == false then
		-- MyPrint("ActivityEventObjForLua isAnalyticIDOk false")
		return false
	end

	if self:isRelatedSwitchOpen() == false then
		-- MyPrint("isRelatedSwitchOpen false")
		return false
	end

	return true
end

-- 不要重载
function ActivityEventObjForLua:isAnalyticIDOk(  )
	local plats = CCCommonUtilsForLua:call("getPropById", self:getProperty("id"), "pf");
    if plats == "" then
        return true
    end

    local myAna = GlobalData:getProperty("analyticID")
    if myAna == "" then
    	return true
    end

    plats = string.split(plats, ";")
    for i=1,#plats do
    	if myAna == plats[i] then
    		return true
    	end
    end

    return false
end

-- 不要重载
function ActivityEventObjForLua:getNormalCurActivityStageAndLeftTime(  )
	local nowTime = GlobalData:call("getWorldTime")
    local startTime = self:getProperty("startTime")
    local endTime = self:getProperty("endTime")

    if startTime == 0 and endTime == 0 then
    	return ActivityStage.ActivityStage_Running, -1
	end
    
    if nowTime < startTime then
        return ActivityStage.ActivityStage_Comming, startTime - nowTime
    end
    
    if nowTime >= startTime and nowTime < endTime then
        return ActivityStage.ActivityStage_Running, endTime - nowTime
    end
    
    return ActivityStage.ActivityStage_Preparing, -1
end

-- // 105805={0}后结束
-- // 105804={0}后开始
-- // 105800=活动准备中
-- // 105830=活动正在进行中
-- 不要重载
function ActivityEventObjForLua:getNormalGameTickStr(  )
	local stage, left = self:getCurActivityStageAndLeftTime()
	if nil == stage or nil == left then
		return ""
	end

	if stage == ActivityStage.ActivityStage_Preparing then
		return _lang("105800")
	end

	if stage == ActivityStage.ActivityStage_Running then
		if left < 0 then
			return _lang("105830")
		else
			return _lang_1("105805", format_time(left))
		end
	end

	return _lang_1("105804", format_time(left))
end

------------------------------------------------------------------------------
------------------------测试 范例--------------------------------------------
------------------------------------------------------------------------------


testobj = class("testobj", function (	)
	return ActivityEventObjForLua:call("create")
end)

function testobj.create( params )
	-- MyPrint("testobj.create")
	local ret = testobj.new()
	if ret:init(params) == false then
		ret = nil
	end
	return ret
end

function testobj:getCurActivityStageAndLeftTime(  )
	-- MyPrint("testobj:getCurActivityStageAndLeftTime")
	return self:getNormalCurActivityStageAndLeftTime()
end

function testobj:getGameTickStr( )
	-- MyPrint("testobj:getGameTickStr")
	return self:getNormalGameTickStr()
end



------------------------------------------------------------------------------
------------------------------------------------------------------------------
------------------------------------------------------------------------------