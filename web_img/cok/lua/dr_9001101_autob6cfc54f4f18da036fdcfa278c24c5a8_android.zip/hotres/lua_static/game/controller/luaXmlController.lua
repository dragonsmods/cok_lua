local luaXmlController = class("luaXmlController")

local _instance = nil
function luaXmlController.getInstance()
    if _instance == nil then
        _instance = luaXmlController.new()
    end
    return _instance
end

function luaXmlController:ctor()
    -- dump("luaXmlController:updateLuaPath ctor is: ")
    self.xmlIndexTbl = {}
    self.xmlIndexId = nil
    self:updateLuaPath()
end

function luaXmlController:updateLuaPath()
    self:clearXMLData()
    local useLocal = LocalController:call("getLocalXmlSign")
    local beGreen = GlobalDataCtr.checkIsGreenServer()
    if beGreen then
        if useLocal then
            self.xmlPath = "localGreen.luaxmlGreen."
        else
            self.xmlPath = "luaxmlGreen."
        end
    else
        if useLocal then
            self.xmlPath = "local.luaxml."
        else
            self.xmlPath = "luaxml."
        end
    end
    -- dump(self.xmlPath, "luaXmlController:updateLuaPath self.xmlPath is: ")
end

function luaXmlController:clearXMLData()
    local oldPath  = self.xmlPath
    if oldPath then
        for key, data in pairs(self.xmlIndexTbl) do
            local path = oldPath .. key
            package.preload[path] = nil
            package.loaded[path] = nil
        end
        local path = oldPath.."luaxml_index"
        package.preload[path] = nil
        package.loaded[path] = nil
    end
    self.xmlIndexTbl = {}
    self.xmlIndexId = nil
end

function luaXmlController:getGroupByKey(groupKey)
    if self.xmlIndexTbl[groupKey] then
        return self.xmlIndexTbl[groupKey]
    end

    if string.find(groupKey, "luaxml_") == nil then
        local dict = LocalController:call("shared"):call("DBXMLManager"):call("getGroupByKey", groupKey) --ccdict*
        local groupDict = dictToLuaTable(dict)

        self.xmlIndexTbl[groupKey] = groupDict

        return groupDict
    end

    local groupDict
    local function requireXml()
        groupDict = require(self.xmlPath..groupKey)
    end

    local status = xpcall(requireXml, nil)
    if status then
        -- self.xmlIndexTbl[groupKey] = groupDict
        return groupDict
    else
        return {}
    end
end

function luaXmlController:getIndexTbl()
    if self.xmlIndexId == nil then
        self.xmlIndexId = require(self.xmlPath.."luaxml_index")
    end
    return self.xmlIndexId
end

function luaXmlController:getPropById(propId, propParam)
    local idIndex = self:getIndexTbl()
    if idIndex[propId] then
        return self:getPropByIdGroup(idIndex[propId], propId, propParam)
    end
    
    return ""
end

function luaXmlController:getPropByIdGroup(group,propId, propParam)
    local groupTbl = self:getGroupByKey(group)
    local tbl = {}
    if groupTbl[propId] then
        tbl = groupTbl[propId]
    end
    return tbl[propParam] or ""
end

function luaXmlController:getPropDictByIdGroup(group,propId)
    local groupTbl = self:getGroupByKey(group)
    if groupTbl and groupTbl[propId] then
        return groupTbl[propId]
    end

    return {}
end


return luaXmlController