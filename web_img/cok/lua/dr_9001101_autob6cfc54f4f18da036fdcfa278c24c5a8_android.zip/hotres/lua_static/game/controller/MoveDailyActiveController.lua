local MoveDailyActiveController = class("MoveDailyActiveController")


local _instance = nil
function MoveDailyActiveController.getInstance()
    if _instance == nil then
        _instance = MoveDailyActiveController.new()
        guiCommonGlobal.controllerAutoPurge(_instance)
    end
    return _instance
end

function MoveDailyActiveController:ctor()
    self:reset()
end

function MoveDailyActiveController:getMoveFlag(  )
    if self.m_moveFlag then
        return self.m_moveFlag
    end

    self.m_moveFlag = (CCCommonUtilsForLua:isFunOpenByKey("move_daily_active") and CCCommonUtilsForLua:isFunOpenByKey("new_daily_active_switch")) and self:isPassGuide()
    return self.m_moveFlag
end

function MoveDailyActiveController:getSwitchOrder(  )
    if self:getMoveFlag() then
        local low_level = FunBuildController:call("getMainCityLv") < 15
        return low_level and {"chapter_task","daily_task"} or {"daily_task","chapter_task"}
    end
end

function MoveDailyActiveController:accessCurPageIdx( tIdx )
    if tIdx then
        self.m_curentIdx = tIdx
    else
        return self.m_curentIdx
    end
end

function MoveDailyActiveController:isTaskPageVisible(  )
    if self:getMoveFlag() then
        local so = self:getSwitchOrder()
        if self.m_curentIdx then
            return so[self.m_curentIdx] == 'chapter_task'
        end
    end
    return true
end

function MoveDailyActiveController:isPassGuide(  )
    if FunBuildController:call("getMainCityLv") >= 15 then
        return true
    end
    
    local guideKeys = self.m_guidKeys
    if not guideKeys then
        guideKeys = {"AC_reward","AC_normal","AC_stage","AC_back"}
        self.m_guidKeys = guideKeys
    end
    if self.m_guideStageChange then
        self.m_checkFlag = nil
    end

    if self.m_checkFlag == nil then
        local flag = true
        for _,v in ipairs(guideKeys) do
            flag = flag and utils.accessLocal(v,'0') == '1'
            if not flag then
                break
            end
        end
        self.m_checkFlag = flag
    end

    return self.m_checkFlag
end

function MoveDailyActiveController:passOneGuid( key )
    utils.accessLocal(key,'1')
    self.m_guideStageChange = true
end

function MoveDailyActiveController:reset(  )
    self.m_moveFlag = nil
    self.m_curentIdx = nil
end


function MoveDailyActiveController:purge()
    self:reset()
end




return MoveDailyActiveController