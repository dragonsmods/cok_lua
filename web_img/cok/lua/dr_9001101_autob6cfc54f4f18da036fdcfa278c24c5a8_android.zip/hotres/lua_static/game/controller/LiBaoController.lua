local  GOLDEXCHANGE_ICON_LIST_CHANGE = "GoldExchangeIcon.Change"
MSG_OLD_EXCHANGE_INIT = "msg.oldExchagne.init"


function LiBaoController.getInstance()
	return LiBaoController:call("getInstance")
end

function LiBaoController:getGoldExchangeItemByIdCpp( itemId )
	return self:call("getGoldExchangeItemById",itemId)
end

function LiBaoController:addNewPopupValue( data )
	if not data then 
		return
	end
	if not self.newPopupValuesTbl  then 
		self.newPopupValuesTbl = {}
	end
	data.recvTime = GlobalData:call("getTimeStamp")
	local key = tonumber(data.exchangeId)
	self.newPopupValuesTbl[key] = data
	-- dump(self.newPopupValuesTbl[key],"LiBaoController:addNewPopupValue after add+++")
end

function LiBaoController:getNewPopupValue( data )
	if not data then 
		return -911911
	end
	if self.newPopupValuesTbl and sizen(self.newPopupValuesTbl) > 0 then
		local key = tonumber(data.id)
		local newData = self.newPopupValuesTbl[key]
		if newData then 
			return tonumber(data.popup) + tonumber(newData.val)
		end 
	end
	return tonumber(data.popup)
end

function LiBaoController:removeTimeoutNewPopupValue( )
	if not self.newPopupValuesTbl or sizen(self.newPopupValuesTbl) == 0 then 
		return
	end
	local currentTime = GlobalData:call("getTimeStamp")
	local tmpTbl = {}
	for k,v in pairs(self.newPopupValuesTbl) do 
		local dif = (currentTime - v.recvTime) 
		if dif < tonumber(v.time) then 
			tmpTbl[k] = v
		end 
	end
	self.newPopupValuesTbl = tmpTbl
	-- dump(tmpTbl,"LiBaoController:removeTimeoutNewPopupValue after remove+++")
end

function LiBaoController:onPushLiBaoPopValue( dict )
	if not CCCommonUtilsForLua:isFunOpenByKey("pop_change") then 
		return 
	end
	local data = dictToLuaTable(dict)
	-- dump(data, "LiBaoController:onPushLiBaoPopValue+++")
	if not data then 
		return
	end
	self:addNewPopupValue(data)
end

function LiBaoController:purge()
	self.goldExchangeList = nil
	self.showTypeList = nil
	self.m_dataTbl = nil
	self.m_popItemId = ""
	self.goldExchangeListInit = false
	self.account_switch = nil
	self.firstPaySign = false

	self.functionOnKeys = {}
	self.sortGroupList = {}
	self.m_iconConfig = nil
	self.m_hadEmit = nil
	self.m_isInGreenServer = nil
end

g_viewsNeedDelAfterPay = g_viewsNeedDelAfterPay or {}
function LiBaoController:markViewNeedDel( view )
	for k,v in pairs(g_viewsNeedDelAfterPay) do 
		if v == view then
			return 
		end
	end
	g_viewsNeedDelAfterPay[#g_viewsNeedDelAfterPay+1] = view
	-- dump({view,g_viewsNeedDelAfterPay},"LiBaoController mark one view+++",10) 
end

function LiBaoController:unmarkViewNeedDel( view )
	-- dump({view,g_viewsNeedDelAfterPay}, "LiBaoController:unmarkViewNeedDel+++")
	for k,v in pairs(g_viewsNeedDelAfterPay) do 
		if v == view then 
			 table.remove(g_viewsNeedDelAfterPay,k)
			 return
		end
	end
end

function LiBaoController:doRemoveViewNeedDel()
	-- dump(g_viewsNeedDelAfterPay,"LiBaoController:doRemoveViewNeedDel+++")
	local size = #g_viewsNeedDelAfterPay
	for indx=1, size do
		PopupViewController:call("removeLastPopupView")
	end
	g_viewsNeedDelAfterPay = {}
	return size 
end

function LiBaoController:setIsNeedRemoveMarkView(bNeed)
	if not CCCommonUtilsForLua:isFunOpenByKey("doNotGo2MainAfterPay") then
		bNeed = false
	end
	self.isNeedRemoveMarkView = bNeed
	g_viewsNeedDelAfterPay = {}
	-- dump(self.isNeedRemoveMarkView,"LiBaoController:setNeedRemoveMarkView+++")
end

function LiBaoController:getIsNeedRemoveMarkView()
	if self.isNeedRemoveMarkView == nil then 
		self.isNeedRemoveMarkView = false
	end
	-- dump(self.isNeedRemoveMarkView,"LiBaoController:getIsNeedRemoveMarkView+++")
	return self.isNeedRemoveMarkView
end

function LiBaoController:showLiBaoView(newKey, dict)
	if newKey == "showExchangePopup" then
		if self:getHasInitdata() and self:hasItemByType("3") then
			local path = "game.LiBao.LibaoCommonPopupView"
			package.loaded[path] = nil
			local view = require(path):create()
			PopupViewController:addPopupView(view)
		end
	elseif newKey == "showGoldBuyPanel" then
		--全球赛点击无效
		if (require("game.dragonWorldCup.DragonWorldCupManager").isDragonGlobalServer()) then return end
		if CCCommonUtilsForLua:isFunOpenByKey("libao_tab_group_show") then
			local view = Drequire("game.LiBao.LibaoTabGroupView").create()
			PopupViewController:addPopupInView(view)
		elseif CCCommonUtilsForLua:isFunOpenByKey("libao_falls_show") then
			local view = Drequire("game.LiBao.LibaoFallsView").create()
			PopupViewController:addPopupInView(view)
        else
			local view = Drequire("game.LiBao.LuaGoldExchangeView_NEW"):create()
			PopupViewController:addPopupInView(view)
		end
	elseif newKey == "setFirstPaySign" then
		local bool = dict:getCString() == "1" and true or false
		self.firstPaySign = bool
	elseif newKey == "onRefreshGroupExchangeData" then
		-- 按组更新礼包数据通知
		self:onRefreshGroupExchangeData(dict)
	elseif newKey == "checkHasGoldItemByShowType" then
		return self:checkHasGoldItemByDict(dict)
	end
end

function LiBaoController:getCurLiBaoMap(dict)
	local goldExchangeList = self:getGoldExchangeList()
	self.goldExchangeList = goldExchangeList
	local curTime = getWorldTime()
	local m_data = dict:objectForKey("data")
	local m_type = dict:objectForKey("type"):getValue()

	self.beFill = dict:objectForKey("beFill"):getValue()
	-- dump(" m_data is: "..tostring(m_data))
	return self:getServerSortMap(m_data, m_type)
end

function LiBaoController:printTbl(tbl, tips)
	-- dump("printTbl printTbl printTbl printTbl printTbl")
	-- for key, id in pairs(tbl) do
	-- 	local goldExchangeList = self.goldExchangeList
	-- 	local item = goldExchangeList[id]
	-- 	if item then
	-- 		local text = "id["..id.."] popup:"..item.popup.." group_type:"..tostring(item.group_type).." group_rate:"..tostring(item.group_rate).." rate:"..tostring(item.rate).." name:"..tostring(getLang(item.name).." type: "..tostring(item.type).." show_type is: "..tostring(item.show_type))
	-- 		MyPrint(tips .." printTbl info +++ "..text)
	-- 	end
	-- end
end

function LiBaoController:setBestSaleLiBao(tbl, m_data)
	local goldExchangeList = self.goldExchangeList
	for key, id in pairs(tbl) do
		-- dump(goldExchangeList[id], "index key is: "..key)
		m_data:addObject(CCString:create(id))
	end
	self:call("setBestSaleLiBao", m_data)
	m_data:removeAllObjects()
	-- local best = 0
	-- local index = 0
	-- for key, id in pairs(tbl) do
	-- 	local item = LuaLiBaoController.goldExchangeList[id]
	-- 	if item.m_bestSeller > best then
	-- 		best = item.m_bestSeller
	-- 		index = key
	-- 	end
	-- end

	-- if index > 0 then
	-- 	local item = LuaLiBaoController.goldExchangeList[tbl[index]]
	-- 	item.m_isBestSeller = "1"
	-- end
end

function LiBaoController:LiBaoCCArraySort(tbl)
	table.sort(tbl, function(a, b) 
			return self.goldExchangeList[a].popup > self.goldExchangeList[b].popup
		end)
end

function LiBaoController:getGoldExchangeArray()
	local m_GoldExchangeArray = LiBaoController:call("getGoldExchangeArray")
	-- dump("LiBaoSamePopReorder m_GoldExchangeArray is:  "..tostring(m_GoldExchangeArray))
	if not m_GoldExchangeArray then
		m_GoldExchangeArray = CCArray:create()
		self:call("setGoldExchangeArray", m_GoldExchangeArray)
	end

	return m_GoldExchangeArray
end

function LiBaoController:getGoldExchangeList()
	if self.goldExchangeListInit then
		return self.goldExchangeList
	else
		return {}
	end
end

function LiBaoController:getPopItemId()
	local itemId = self:call("getPopItemId")
	return itemId
end
function LiBaoController:setPopItemId(id)
	self:call("setPopItemId", tostring(id))
end

local LocalGoldExchangeKey = "LocalGoldExchangeKey"
local LocalPopItemCountKey = "LocalPopItemCountKey"
local LocalAllExchangeListKey = "LocalAllExchangeListKey"

function LiBaoController:getLocalExchangeList()
	local heroName = GlobalDataCtr.getPlayerName()
	local str = cc.UserDefault:getInstance():getStringForKey(LocalAllExchangeListKey..heroName, "")
	local tbl = {}
	if str ~= "" then
		tbl = string.split(str, ",")
	end
	-- dump(tbl, " LiBaoController:getLocalExchangeList tbl is: ")
	return tbl
end

function LiBaoController:setLocalExchangeList()
	local heroName = GlobalDataCtr.getPlayerName()
	local txt = getWorldTime()
	local res = {txt}
	for id, item in pairs(self.goldExchangeList) do
		-- txt = txt..","..id
		table.insert(res,id)
	end
	txt = table.concat(res,',')
	-- dump(" LiBaoController:setLocalExchangeList txt is: "..txt)
	cc.UserDefault:getInstance():setStringForKey(LocalAllExchangeListKey..heroName, txt)
end

function LiBaoController:getLocalGoldExchangeTbl()
	local heroName = GlobalDataCtr.getPlayerName()
	local str = cc.UserDefault:getInstance():getStringForKey(LocalGoldExchangeKey..heroName, "")
	local result = {}
	if str ~= "" then
		local tmp = {}
		tmp = string.split(str, ",")

		local time = tonumber(tmp[1])
		if self:checkTimeOffline(time) then
			self:setPopItemId(tmp[2])
			for i = 3, #tmp do
				result[#result+1] = tmp[i]
			end
		end
	end
	-- dump(result, "getLocalGoldExchangeTbl result is: 1111")
	return result
end

function LiBaoController:setLocalGoldExchangeTbl(goldTbl)
	local curTime = getWorldTime()
	-- 存储gold格式，第一个为当前时间，其后为id列表,本地存储加上服务器号等比较好
	local str = ""..curTime..","..self:getPopItemId()
	for key, id  in pairs(goldTbl) do
		str = str..","..id
	end
	-- dump(" LiBaoController:setLocalGoldExchangeTbl() ~~~~~~~~~~~~222222 "..str)

	local heroName = GlobalDataCtr.getPlayerName()
	cc.UserDefault:getInstance():setStringForKey(LocalGoldExchangeKey..heroName, str)
end

function LiBaoController:getGoldExchangeItemById(itemId)
	return self.goldExchangeList and self.goldExchangeList[itemId]
end

-- 只有获取切换礼包的地方使用了这个函数，后面找时间修改下
function LiBaoController:getGoldExchangeItemIdByShowType(show_type)
	show_type = tostring(show_type)
	local goldExchangeList = self:getGoldExchangeList()
	for key, item in pairs(goldExchangeList) do
		if not item.bought and item.show_type == show_type then
			return key, item
		end
	end

	return ""
end

function LiBaoController:insertNewLibao(dict)
	local sortExchangeList = arrayToLuaTable(dict)
	self.sortExchangeList = {}
	for i = 1, #sortExchangeList do
		self.sortExchangeList[#self.sortExchangeList + 1] = sortExchangeList[i].id
	end

	self.timeZone = GlobalDataCtr.getTimeZone()*60*60
	self.goldExchangeListInit = true
	-- dump("LiBaoController:insertNewLibao i1111111111111111111")
	self.goldExchangeList = {}
	for key, item in pairs(sortExchangeList) do
		self:itemDefaultValue(item)
		self:_insertOneLibao(item)
	end
	self:emitLibaoReady()
end

function LiBaoController:updateSaveGoldExchangeData(newLibaoTbl)
	local m_GoldExchangeArray = self:getGoldExchangeArray()
	local m_GoldExchangeTbl = arrayToLuaTable(m_GoldExchangeArray)
	self.goldExchangeList = self:getGoldExchangeList()
	-- dump(m_GoldExchangeTbl, "updateSaveGoldExchangeData start is: ")
	if table_is_empty(m_GoldExchangeTbl) then
		-- 如果为空表，则读取本地数据，判断时长
		m_GoldExchangeTbl = self:getLocalGoldExchangeTbl()
	end
	if table_is_empty(m_GoldExchangeTbl) then
		return
	end
	-- dump(m_GoldExchangeTbl, "updateSaveGoldExchangeData start is: 2222222")

	local tmpGoldTbl = {}
	for key, itemId in pairs(m_GoldExchangeTbl) do
		tmpGoldTbl[itemId] = true
	end
	-- dump(tmpGoldTbl, "updateSaveGoldExchangeData start is: ")
	for key, item in pairs(newLibaoTbl) do
		if self.goldExchangeList[item.id] then
			if (not item.group_type) or (item.group_type == "") then
				if not tmpGoldTbl[item.id] then  	-- 无组的才添加,有组的等下一次刷新
			-- if true and not tmpGoldTbl[item.id] then
					m_GoldExchangeTbl[#m_GoldExchangeTbl + 1] = item.id
				end
			end
		end
	end

	local num = #m_GoldExchangeTbl
	for i = num, 1, -1 do
		if not self.goldExchangeList[m_GoldExchangeTbl[i]] then
			table.remove(m_GoldExchangeTbl, i)
		end
	end

	-- dump(m_GoldExchangeTbl, "m_GoldExchangeTbl now is: ")
	self:LiBaoCCArraySort(m_GoldExchangeTbl)

	-- dump(m_GoldExchangeTbl, "m_GoldExchangeTbl cur is: ")
	m_GoldExchangeArray:removeAllObjects()
	for key, id in pairs(m_GoldExchangeTbl) do
		m_GoldExchangeArray:addObject(CCString:create(id))
	end

	-- 保存goldExchange数据
	self:setLocalGoldExchangeTbl(m_GoldExchangeTbl)
end

function LiBaoController:getPopupItemCountTbl()
	local heroName = GlobalDataCtr.getPlayerName()
	local str = cc.UserDefault:getInstance():getStringForKey(LocalPopItemCountKey..heroName, "")
	local tmp = {}
	if str ~= "" then
		tmp = string.split(str, ",")
		-- dump(tmp, "getPopupItemCountTbl str is: ")
		local time = tonumber(tmp[1])
		table.remove(tmp, 1)
		local curTime = getWorldTime()
		local popupItemCountTbl = {}
		local offtime = (tonumber(CCCommonUtilsForLua:getPropById("79008", "k1")) or 60) * 60
		-- dump("curTime: "..curTime.." saveTime: "..time.." offtime:"..offtime)
		if curTime < time + offtime then
			-- 小于一小时的判断是否一个时间段内
			local nums = math.ceil(time / offtime)
			if curTime > nums * offtime then
				-- 一小时内，读取本地数据
				tmp = {}
			end
		end
	end
	-- dump(tmp,"cur tmp is: ")
	return tmp
end

function LiBaoController:countPopupItem(dict)

	local popupItemCountTbl = self:getPopupItemCountTbl()
	local itemId = dict.itemId
	
	popupItemCountTbl[#popupItemCountTbl + 1] = itemId

	-- save字符串
	local str = tostring(getWorldTime())
	for key, itemId in pairs(popupItemCountTbl) do
		str = str ..","..itemId
	end
	-- dump(popupItemCountTbl, "countPopupItem ~~~~~")
	local heroName = GlobalDataCtr.getPlayerName()
	cc.UserDefault:getInstance():setStringForKey(LocalPopItemCountKey..heroName, str)
end

-- 本处获取的是列表，而非单个物品
function LiBaoController:getGoldExchangeFromListByType(itemType)
	itemType = tostring(itemType or 1)
	self.goldExchangeList = self:getGoldExchangeList()
	local newTbl = {}
	local tmpTbl = {}
	for key, item in pairs(self.goldExchangeList) do
		if item.type == itemType and item.popup ~= 0 then
			tmpTbl[#tmpTbl+1] = item
		end
	end

	if itemType == "1" then
		local curTime = getWorldTime()
		for key, item in pairs(tmpTbl) do
			if not item.bought and item.popup_image ~= "" and item.popup_image ~= "hide" then
				if item["end"] > curTime then
					newTbl[#newTbl+1] = item
				end
			end
		end
	elseif itemType == "3" then
		local curTime = getWorldTime()
		for key, item in pairs(tmpTbl) do
			if not item.bought and item.popup_image ~= "close" then
				if item["end"] > curTime then
					newTbl[#newTbl+1] = item
				end
			end
		end
	elseif itemType == "5" then
		-- 月卡逻辑，尚未处理
		newTbl = tmpTbl
	else
		newTbl = tmpTbl
	end

	return newTbl
end

function LiBaoController:getExchangeItemByType(itemType)
	itemType = tostring(itemType or 1)
	self.goldExchangeList = self:getGoldExchangeList()
	local tmpTbl = {}
	for key, item in pairs(self.goldExchangeList) do
		if item.type == itemType and item.popup ~= 0 then
			tmpTbl[#tmpTbl+1] = item
		end
	end
	-- dump(tmpTbl, "LiBaoController:getExchangeItemByType["..tostring(itemType))
	return tmpTbl
end

function LiBaoController:checkTimeOffline(time)
	if time then
		time = tonumber(time)
	end
	if time and time > 0 then
		local curTime = getWorldTime()
		local offtime = (tonumber(CCCommonUtilsForLua:getPropById("79008", "k1")) or 60) * 60
		-- dump("curTime: "..curTime.." saveTime: "..time.." offtime:"..offtime)
		if curTime < time + offtime then
			-- 小于一小时的判断是否一个时间段内
			local nums = math.ceil(time / offtime)
			if curTime < nums * offtime then
				-- 一小时内，读取本地数据
				return true
			end
		end
		return false
	else
		return false
	end
end

function LiBaoController:initLibaoData(dict)
	local newLibaoTbl = arrayToLuaTable(dict)
	-- dump(newLibaoTbl, "LiBaoController:initLibaoData the tbl is: ")
	local diffTbl={}
	local tmp = self:getLocalExchangeList()
	-- self.goldExchangeList = {}
	-- table.remove(tmp, 2)
	-- table.remove(tmp, 2)
	if self:checkTimeOffline(tmp[1]) then
		-- 统一时间段内，判读时间逻辑
		-- self.goldExchangeList = self:getGoldExchangeList()
		local oldLibaoTbl = {}
		for i = 2, #tmp do
			oldLibaoTbl[tmp[i]] = true
		end
		-- 差异文件
		for key, item in pairs(newLibaoTbl) do
			if not oldLibaoTbl[item.id] then
				diffTbl[item.id] = item
			end
		end
		-- dump(diffTbl, "差异文件 ~~~~~~~~~~~")
		self:updateSaveGoldExchangeData(diffTbl)
	end

	-- if not table_is_empty(diffTbl) then
	if true then
		self.goldExchangeList = self:getGoldExchangeList()
		self:setLocalExchangeList()
	end
end
------------------------------------------------ 新服务器排序礼包分割线 ------------------------------------------------
function LiBaoController:getServerSortMap(m_data, m_type)
	-- 服务器下发排序表为空，则不读取这个数据
	if self:getFunctionOn("loading_show_type") then
		return self:getServerSortMapByShowType(m_data, m_type)
	end

	if table_is_empty(self.sortExchangeList or {}) then
		return
	end

	local m_dataTbl
	if m_data then
		m_dataTbl = arrayToLuaTable(m_data)
		-- 先清理m_data，使用lua表进行排序，然后重新整理赋值给m_data
		m_data:removeAllObjects()
	else
		m_dataTbl = {}
	end

	if m_type > 0 then
		for i = 1, #self.sortExchangeList do
			local item = self.goldExchangeList[self.sortExchangeList[i]]
			if item and item.type == "3" 
				and not item.bought
				and item.popup_image ~= "close"
				then
				-- if item.show_type == tostring(m_type) then
				if true then
					m_dataTbl[#m_dataTbl+1] = item.id
				end
			end
		end
	else
		if CCCommonUtilsForLua:isFunOpenByKey("show_type_in_shop") then
			for i = 1, #self.sortExchangeList do
				local item = self.goldExchangeList[self.sortExchangeList[i]]
				if item and item.type == "3" 
					and not item.bought
					and item.popup_image ~= "close"
					then
					m_dataTbl[#m_dataTbl+1] = item.id
				end
			end
		else
			for i = 1, #self.sortExchangeList do
				local item = self.goldExchangeList[self.sortExchangeList[i]]
				if item 
					and item.show_type == ""
					and item.type == "3" 
					and not item.bought
					and item.popup_image ~= "close"
					then
					m_dataTbl[#m_dataTbl+1] = item.id
				end
			end
		end
	end
	
	self.m_popItemId = self:getPopItemId()
	local maxCount = tonumber(CCCommonUtilsForLua:getPropById("79001", "k1"));
	local m_popItemId = ""
	if m_type > 0 then
		local num = #m_dataTbl
		local tmpRemoveTbl = {}
		local this_type = tostring(m_type)
		for i = num, 1, -1 do
			local item = self.goldExchangeList[m_dataTbl[i]]
			if item.show_type ~= this_type then
				table.remove(m_dataTbl, i)
				-- 存储排除的数据，用于数量不足时的补齐
				tmpRemoveTbl[#tmpRemoveTbl + 1] = item
			end
		end

		if self.beFill and #m_dataTbl < maxCount then
			-- 使用type为3的进行添加
			if this_type ~= "2" and this_type ~= "3" then
				for i = #tmpRemoveTbl, 1, -1 do
					m_dataTbl[#m_dataTbl + 1] = tmpRemoveTbl[i].id
				end
			end
		end
	else
		-- 数据回写逻辑
		self:showItemCountSort(m_dataTbl)
		for key, id in pairs(m_dataTbl) do
			local item = self.goldExchangeList[id]
			if item and item.show_type == "" then
				m_popItemId = id
				self:setPopItemId(m_popItemId)
				break
			end
		end
	end
	-- self:printTbl(m_dataTbl, "server sort in the end ~~~~~")

	-- 判断最大数量
	while maxCount < #m_dataTbl do
		table.remove(m_dataTbl, #m_dataTbl)
	end

	self.m_dataTbl = m_dataTbl
	if m_data then
		-- 最后回写m_data数据
		for key, id in pairs(m_dataTbl) do
			-- dump(goldExchangeList[id], "index key is: "..key)
			m_data:addObject(CCString:create(id))
		end
	end

	if m_type == 0 and self.m_popItemId ~= "" and self.m_popItemId ~= m_popItemId then
		-- 弹出礼包id存在，并且礼包id不同，则变化icon
		CCSafeNotificationCenter:postNotification(GOLDEXCHANGE_ICON_LIST_CHANGE)
	end

	return self.m_dataTbl
end

function LiBaoController:showItemCountSort(m_dataTbl)
	-- 增加次数的判断的后移逻辑
	local maxCount = tonumber(CCCommonUtilsForLua:getPropById("79001", "k2"))
	if not maxCount then
		maxCount = 5
		MyPrint("Lua Error not has 79001 k2")
	end
	local countTbl = self:getPopupItemCountTbl()
	local countItemTbl = {}
	for key, itemId in pairs(countTbl) do
		if not countItemTbl[itemId] then
			countItemTbl[itemId] = 0
		end
		countItemTbl[itemId] = countItemTbl[itemId] + 1
	end
	local firstId = m_dataTbl[1]
	if countItemTbl[firstId] and countItemTbl[firstId] >= maxCount then
		local index = tonumber(CCCommonUtilsForLua:getPropById("79001", "k1"))
		if index > #m_dataTbl then
			index = #m_dataTbl
		end
		table.remove(m_dataTbl, 1)
		-- 数据后移至 配置数量 位
		table.insert(m_dataTbl, index, firstId)

		-- countItemTbl[firstId] = nil
		-- local str = tostring(getWorldTime())
		-- -- 回写数据
		-- for itemId, num in pairs(countItemTbl) do
		-- 	-- save字符串
		-- 	for i = 1, num do
		-- 		str = str ..","..itemId
		-- 	end
		-- end
		-- dump(popupItemCountTbl, "countPopupItem ~~~~~")
		-- local heroName = GlobalDataCtr.getPlayerName()
		-- cc.UserDefault:getInstance():setStringForKey(LocalPopItemCountKey..heroName, str)

	end
end

------------------------------------------------礼包功能分割线 ------------------------------------------------
function LiBaoController:hasItemByType(item_type)
	item_type = tostring(item_type)
	local tbl = {}
	local goldExchangeList = self:getGoldExchangeList()
	for key, item in pairs(goldExchangeList) do
		if not item.bought and item.type == item_type then
			if item.type == "3" then
				if item.popup_image ~= "close" then
					return true, item
				end
			else
				return true, item
			end
		end
	end

	return false
end

-- 取所有show_type的礼包数据
function LiBaoController:getExchangeListByShowType(show_type)
	if tostring(show_type) == "0" then
		show_type = ""
	end
	show_type = tostring(show_type or "")
	local tbl = {}
	local goldExchangeList = self:getGoldExchangeList()
	for key, item in pairs(goldExchangeList) do
		if not item.bought and item.show_type == show_type and item.popup_image ~= "close" then
			tbl[#tbl+1] = item
		end
	end

	return tbl
end

-- GoldExchangeItem::toString()
function LiBaoController:getItemStringById(itemId)
	local item = nil
	local str = nil
	if self.goldExchangeList and self.goldExchangeList[itemId] then
		item = self.goldExchangeList[itemId]
	else
		self.goldExchangeList = self:getGoldExchangeList()
		item = self.goldExchangeList[itemId]
	end

	if item then
		str = item.id ..","..item.type..","..item.gold_doller..","..item.dollar..","..item.name_doller..","..
			item.gift..","..item.item..","..item.percent..","..item.oldprice..","..item.name..","..
			item.product_id..","..item.start..","..item["end"]..","..item.time..","..(item.bought and 1 or 0)..","..
			item.popup..","..item.price..","..(item.isPayCallBack and 1 or 0)..","..item.popup_image

		if str == "123" then
			str = str..item.popup_image + ","
		end
		local analyticId = GlobalDataCtr.getAnalyticID()
		if analyticId == "market_global"
			or analyticId == "AppStore"
			or analyticId == "tstore"
			or analyticId == "nstore"
			or analyticId == "amazon"
			then
			str = str ..item.equipment..","..(item.send_mail and 1 or 0)..","
		else
			str = str ..item.equipment..",0,"
		end

		str = str .."bindGuide" -- 22

		str = str ..","..item.m_slogan..","..item.m_isBestSeller..","..item.only_once -- 23-26
		local addgold="0";
	    local arrId ={"9000","9001","9002","9003","9004","9009"};
	    for index, key in pairs(arrId) do
	    	if self.goldExchangeList[key] then
	    		if self.goldExchangeList[key].product_id == item.product_id then
	    			addgold = item.gold_doller
	    			break
	    		end
	    	end
	    end
	    str = str..","..addgold --27
	    local tmp1 = ""
	    local tmp2 = ""
	    if item.m_stamp ~= "" then
		    local tbl = string.split(item.m_stamp, "|")
		    -- dump(tbl, " ~~~~~~ m_stamp is: ")
		    tmp1 = tbl[1] and tbl[1] or ""
		    tmp2 = tbl[2] and tbl[2] or ""
		end
	    
	end

	return str
end

function LiBaoController:itemDefaultValue(item)
	if item.sales and tonumber(item.sales) == 1 then
		item.buyMore = true
	else
		item.buyMore = false
	end
	item.popup_image = item.popup_image or "1"
	item.price = item.price or 0
	item.name = item.name or ""
	item.oldprice = item.price

	if item.time and item.type == "3" then
		item.time = tonumber(item.time) or 0
	else
		item.time = 0
	end
	item.count = item.count or 0

	item.exDataMap = {}
	if item.popup then
		item.exDataMap[10101] = item.popup
	else
		item.popup = 0
	end

	if item.bought then
		if item.bought == "1" then
			item.bought = true
		else
			item.bought = false
		end
	else
		-- item.bought = item.bought or false
		item.bought = false
	end

	-- 无用代码注释掉
	-- if item.start then
	-- 	item.start = math.floor(item.start/1000)
	-- 	if item.start > 0 then
	-- 		item.start = self.timeZone + item.start
	-- 	end
	-- end
	if item["end"] then
		item["end"] = (item["end"]/1000)     -- 取消math.floor，减少效率损失
		if item["end"] > 0 then
			item["end"] = item["end"] + self.timeZone
		end
	else
		item["end"] = 0
	end
	item.group = item.group or 0
	item.md5 = item.md5 or ""
	item.equipment = item.equipment or ""
	-- local analyticId = GlobalDataCtr.getAnalyticID()
	-- if item.send_mail and item.send_mail ~= "" 
	-- 	and (analyticId == "market_global" or analyticId == "AppStore" or analyticId == "tstore" or analyticId == "nstore" or analyticId == "amazon")
	-- 	then
	-- 	item.send_mail = true
	-- else
	-- 	item.send_mail = false
	-- end

	item.isPayCallBack = false
	item.m_slogan = item.slogan or ""
	item.slogan = nil

	item.m_bestSeller = item.spend or 0
	item.spend = nil

	item.m_sellCount = item.num or 0
	item.num = nil

	item.m_speedGiftType = item.speedgift or -1
	item.speedgift = nil

	item.m_sortorder = tonumber(item.sort_order) or 0
	item.sort_order = nil

	item.m_info = item.info or ""
	item.info = nil

	item.gift_show = item.gift_show or ""
	item.only_once = item.only_once or "1"

	item.m_stamp = item.stamp or ""
	item.stamp = nil

	item.show_type = item.show_type or ""
	item.group_type = item.group_type or ""
	item.group_rate = item.group_rate or 0
	item.rate = item.rate or ""
	item.refresh = item.refresh or ""

	for i = 1, 5 do
		item["para"..i] = item["para"..i] or ""
	end

	-- local text = getLang(item.m_slogan)
	-- if text ~= "" then
	-- 	item.m_lang_des = text
	-- else
	-- 	local goldNum = tonumber(item.gold_doller)
 --    	local goodsPrice = 0
 --    	if item.item then
	--     	local itemTmpList = string.split(item.item, "|")
	--     	for key, str in pairs(itemTmpList) do
	--     		local tbl = string.split(str, ";")
	--     		local itemId = tbl[1]
	--     		local num = tonumber(tbl[2])
	--     		if itemId and num then
	-- 	    		local price = tonumber(CCCommonUtilsForLua:getPropById(itemId, "price")) or 0
	-- 	    		goodsPrice = goodsPrice + price*num
	--     		end
	--     	end
	--     end

 --    	if goldNum > 0 or goodsPrice > 0 then
 --    		item.m_lang_des = getLang("9000032", goldNum, goodsPrice)
 --    	end
	-- end
end

function LiBaoController:refreshLibaoItemData(dict)
	-- dump(dict, "refreshLibaoItemData dict is: ")
	self.timeZone = GlobalDataCtr.getTimeZone()*60*60
	self.goldExchangeListInit = true
	local tbl = arrayToLuaTable(dict)
	self.goldExchangeList = {}
	for key, item in pairs(tbl) do
		self:itemDefaultValue(item)
		self:_insertOneLibao(item)
	end
	-- dump(self.goldExchangeList, "refreshLibaoItemData self.goldExchangeList is: ")
end

function LiBaoController:updateLibaoItemData(dict, isDel)
	-- dump(dict, "refreshLibaoItemData dict is: ")
	self.timeZone = GlobalDataCtr.getTimeZone()*60*60
	if self.goldExchangeListInit then
		if not isDel then
			-- 更新数据
			local item = dict
			self:itemDefaultValue(item)
			self.goldExchangeList[item.id] = item
		else
			-- 删除数据
			if self.goldExchangeList[dict.itemId] then
				self.goldExchangeList[dict.itemId] = nil
			end
		end
	end
end

function LiBaoController:showBuySuccessBuyDiamondView( buy_resp )
	local view = Drequire("game.LiBao.RechargeFeedBack.RechargeFeedBackLuatblView").create(buy_resp)
    PopupViewController:addPopupView(view)
end

function LiBaoController:buyLibaoWithDiamond( libaoData, itemCount, touchPos)
	repeat
		if table.isNilOrEmpty( libaoData ) then
			break
		end

		if string.isNilOrEmpty( libaoData.diamondPay ) or string.isNilOrEmpty( libaoData.diamondPayCost ) then
			break
		end

		local cost_num = tonumber(libaoData.diamondPayCost)
		if not cost_num then
			break
		end

		local enoughFlag = cost_num <= (PlayerInfoController:getCrystalGold() or 0)
		if enoughFlag then
			self:getModifyV1MgrInst():setReadyToBuy(libaoData.id,libaoData)
			utils.requestServer( "diamondbuyexchange.buy", {{"exchangeId",CCString:create(tostring(libaoData.id))}}, nil, function ( tbl )
				if not table.isNilOrEmpty( tbl ) then
					tbl.gold_doller = libaoData.gold_doller
				end

				if not table.isNilOrEmpty( tbl.reward ) then
					local rwdArr = luaToArray(tbl.reward)
					RewardController:call("retReward", rwdArr)
					CCSafeNotificationCenter:call("postNotification", MSG_REFREASH_TOOL_DATA)
				end

				self:showBuySuccessBuyDiamondView(tbl)

				self:getModifyV1MgrInst():onPaymentBack()
			end )
		else
			CCCommonUtilsForLua:call("flyHint", "", "", getLang("9200709"))

			self:tryCleanEntry()
	        self.m_entryId = cc.Director:getInstance():getScheduler():scheduleScriptFunc(function(dt) 
	            self:tryCleanEntry()
	            PopupViewController:call("removeAllPopupView")
	            
	            local view = Drequire("game.CommonPopup.ItemGetMethodView"):create("500003")
				PopupViewController:call("addPopupView", view)
	        end, 1, false)
		end

		return true
	until true

	return false
end

function LiBaoController:tryCleanEntry()
    if self.m_entryId then
        cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.m_entryId)
        self.m_entryId = nil 
    end
end

function LiBaoController:callPayment(itemId, touchPos)
	self.buyLibaoCount = nil
	local itemData = self.goldExchangeList[itemId]

	if not self:checkCanPayWithBind(itemData) then
		return
	end

	
	if self:buyLibaoWithDiamond(itemData,nil,touchPos) then
		return
	end

	self:getModifyV1MgrInst():setReadyToBuy(itemId,itemData)

	local itemData = self.goldExchangeList[itemId]
	local options = nil
	if itemData then
		local cur,max = self:getModifyV1MgrInst():getLiBaoBuyTimes(itemData),
					self:getLiBaoMaxCount(itemData)
		
		if max < 0 or cur < max then
			local ti = self:getGoldExchangeItemByIdCpp(itemData.id)
            if ti then
                ti:setProperty("bought", false)
            end
		end
		if itemData.options then
			local LibaoCommonFunc = require("game.LiBao.LibaoCommonFunc")
	        local selectIndex = LibaoCommonFunc.getGroupIndexById(itemData.id)
		    LuaController:call("callPayment", itemId, selectIndex-1)
		    options = selectIndex - 1
	    else
			-- 因lua和服务器索引不同，所以-1
		    LuaController:call("callPayment", itemId)
	    end
	else
		-- dump(" not has ["..itemId.."] item in goldExchangeList")
		LuaController:call("callPayment", itemId)
	end
    

    if CCCommonUtilsForLua:isFunOpenByKey("buy_gift_stay") then
        CCSafeNotificationCenter:postNotification("gold_callPayment_notify")
    else
        PopupViewController:call("getInstance"):call("removeAllPopupView")
    end
end

function LiBaoController:getModifyV1MgrInst(  )
	return require("game.LiBao.ModifyLibaoMgrV1").getInstance()
end

function LiBaoController:getLiBaoMaxCountById(exchangeId)
	local itemData = self:getGoldExchangeItemById(exchangeId)
	if not table.isNilOrEmpty( itemData ) then
		return self:getLiBaoMaxCount(itemData)
	end
end

function LiBaoController:getLiBaoMaxCount(itemData)
	-- dump(itemData,"LiBaoController:getLiBaoMaxCount+++",10)
	if self:getModifyV1MgrInst():isOpen() then
		return tonumber(itemData.buyLimit or "-1")
	end
	local maxCount = -999 
	if itemData.maxQuantityLimit and itemData.maxQuantityLimit ~= "" then
		maxCount = tonumber(itemData.maxQuantityLimit)
	end
	return maxCount
end

function LiBaoController:addCurLiBaoCount(itemData)
	-- dump("LiBaoController:addCurLiBaoCount+++")
	local curCount = self:getCurLiBaoCount(itemData)
	local maxCount = self:getLiBaoMaxCount(itemData)
    if maxCount == -1 then --无穷大
        curCount = curCount + 1
    elseif maxCount > 0 and curCount < maxCount then 
    	curCount = curCount + 1
    end
	local libaoId = tonumber(itemData.id)
    self.curLiBaoCountTbl[libaoId] = curCount
	-- dump(self.curLiBaoCountTbl, "curLiBaoCountTbl+++")
    return curCount
end

function LiBaoController:subCurLiBaoCount(itemData)
	local curCount = self:getCurLiBaoCount(itemData)
    if curCount > 1 then 
        curCount = curCount - 1
    end
	local libaoId = tonumber(itemData.id)
    self.curLiBaoCountTbl[libaoId] = curCount
    return curCount
end

function LiBaoController:getBuyLiBaoCount()
	return self.buyLibaoCount
end

function LiBaoController:setBuyLiBaoCount(count)
	self.buyLibaoCount = count
end

--[[
	注:此方法是获取or修改当前礼包可购次数的接口
]]
function LiBaoController:accessLiBaoCount(itemData,val)
	if val then
		if not string.isNilOrEmpty(itemData.nowBuyTimes) and tonumber(itemData.nowBuyTimes) then
			itemData.nowBuyTimes = tostring(tonumber(itemData.nowBuyTimes) + val)
		end
	else
		return not string.isNilOrEmpty(itemData.nowBuyTimes) and tonumber(itemData.nowBuyTimes) or 0 
	end
end

--[[
	注:此方法是获取老界面上有加减按钮的 "选择" 礼包数量的接口
]]
function LiBaoController:getCurLiBaoCount(itemData)
	-- dump(itemData, "LiBaoController:getCurLiBaoCount+++")
	if not self.curLiBaoCountTbl then 
		self.curLiBaoCountTbl = {}
	end
	local libaoId = tonumber(itemData.id)
	local curCount = self.curLiBaoCountTbl[libaoId]
	if not curCount then 
		curCount = 1
	end
	-- dump(self.curLiBaoCountTbl, "curLiBaoCountTbl+++")
	local maxCount = self:getLiBaoMaxCount(itemData)

	if maxCount ~= -1 and curCount > maxCount then 
		curCount = maxCount
	end
	self.curLiBaoCountTbl[libaoId] = curCount
	return curCount
end

function LiBaoController:isCanBuyMoreThan1(itemData)
	-- dump(itemData, "LiBaoController:isCanBuyMoreThan1+++",10)
	-- dump("LiBaoController:isCanBuyMoreThan1+++")
	local funOpen = CCCommonUtilsForLua:isFunOpenByKey("buy_more_libao")
	local isCan = false 
	local maxCount = self:getLiBaoMaxCount(itemData)
	if maxCount > 0 or maxCount == -1 then
 		isCan = true
 	end
	-- dump(isCan, "isCanBuyMoreThan1 isCan+++")
	-- dump(funOpen, "isCanBuyMoreThan1 funOpen+++")
	return funOpen and isCan
end

function LiBaoController:callPaymentEx(itemId, itemCount, touchPos)
	self.buyLibaoCount = nil 
	local itemData = self.goldExchangeList[itemId]

	if not self:checkCanPayWithBind(itemData) then
		return
	end


	if self:buyLibaoWithDiamond(itemData,itemCount, touchPos) then
		return
	end

	self:getModifyV1MgrInst():setReadyToBuy(itemId,itemData)

	local options = nil
	self.buyLibaoCount = itemCount 
	if itemData then
		if itemData.options then
			local LibaoCommonFunc = require("game.LiBao.LibaoCommonFunc")
	        local selectIndex = LibaoCommonFunc.getGroupIndexById(itemData.id)
		    LuaController:call("callPaymentEx", itemId, itemCount, selectIndex-1)
		    options = selectIndex - 1
	    else
			-- 因lua和服务器索引不同，所以-1
		    LuaController:call("callPaymentEx", itemId, itemCount)
	    end
	else
		-- dump(" not has ["..itemId.."] item in goldExchangeList")
		LuaController:call("callPaymentEx", itemId, itemCount)
	end
    
    
    if CCCommonUtilsForLua:isFunOpenByKey("buy_gift_stay") then
        CCSafeNotificationCenter:postNotification("gold_callPayment_notify")
    else
        PopupViewController:call("getInstance"):call("removeAllPopupView")
    end
end

function LiBaoController:checkCanPayWithBind(itemData)
	if CCCommonUtilsForLua:isFunOpenByKey("anti_addiction") then
		return DataController.AntiAddictionController:checkPayState(itemData.dollar, itemData.product_id)
	end
	if self.account_switch == nil then
		self.account_switch = CCCommonUtilsForLua:isFunOpenByKey("account_switch")
	end
	if self.account_switch then
		local analyticId = GlobalDataCtr.getAnalyticID()
		if analyticId == "cn1" then
			if not GlobalData:call("checkHasBindWeibo") then
				local dict1 = CCDictionary:create()
				dict1:setObject(CCString:create("SetAccountNextView"), "name")
				dict1:setObject(CCString:create("3"), "type")
		 		LuaController:call("openPopViewInLua", dict1)
				return false
			end
		end
	end

	return true
end

------------------------------------------------ lua内部获取排序礼包分割线 Start ------------------------------------------------
function LiBaoController:getCurLiBaoMapInLua(show_type, beFilled)
	beFilled = beFilled or false
	if not self.goldExchangeListInit then
		return {}
	end
	self.beFill = beFilled
	local tbl = self:getServerSortMap(nil, tonumber(show_type) or 0)

	local newTbl = {}
	for _, id in pairs(tbl) do
		newTbl[#newTbl+1] = self.goldExchangeList[id]
	end
	return newTbl
end

function LiBaoController:onNewRefreshExchangeData(dict)
	self.timeZone = GlobalDataCtr.getTimeZone()*60*60
	local data = dictToLuaTable(dict)
	-- dump(data)
	self.goldExchangeListInit = true
	if not self.goldExchangeList then
		self.goldExchangeList = {}
	end
	if data.deletes then
		local tbl = string.split(data.deletes, ",")
		for key, id in pairs(tbl) do
			self.goldExchangeList[id] = nil
		end
	end
	if data.updates then
		for key, item in pairs(data.updates) do
			self:itemDefaultValue(item)
			self:_insertOneLibao(item)
		end
	end
	if data.orderIds then
		self.sortExchangeList = string.split(data.orderIds, ",")
	end
	self:emitLibaoReady()
end

function LiBaoController:_isInGreenServer(  )
	local isInGreenServer = self.m_isInGreenServer
	if not isInGreenServer then
	    isInGreenServer = require('game.controller.WhichServerMgr').getInstance():isInServer('GreenServer')
	    self.m_isInGreenServer = isInGreenServer
	end
	return isInGreenServer
end

function LiBaoController:_insertOneLibao( item )
	local is_green_server = self:_isInGreenServer()
	local is_green_libao = item.oldServer == 'onlyOld'
	local is_both_libao = item.oldServer == 'both'
	if is_both_libao or ( not ( utils.xor(is_green_server , is_green_libao) )) then
		self.goldExchangeList[item.id] = item
	end
end

function LiBaoController:getHasInitdata()
	return self.goldExchangeListInit
end

function LiBaoController:getTabShowTypeBySort()
	if table_is_empty(self.sortExchangeList or {}) then
		return {}
	end
	local tabList = self.m_tabShowTypeBySort
	if not table.isNilOrEmpty(tabList) then
		return tabList
	end
	local maxCount = tonumber(CCCommonUtilsForLua:getPropById("79001", "k1"));
	
	tabList = {}
	self.m_tabShowTypeBySort = tabList
	if CCCommonUtilsForLua:isFunOpenByKey("package_more_page") then
		-- 新类型，读取para10
		for _, id in pairs(self.sortExchangeList) do
			local item = self.goldExchangeList[id]
			local typeStr
			if item.para10 and item.para10 ~= "" then
				typeStr = item.para10
			else
				typeStr = item.para4
			end
			if not string.isNilOrEmpty( typeStr ) then
				local typeList = string.split(typeStr, ",")
				for _, typeIdx in pairs(typeList) do
					local typeIndex = tonumber(typeIdx)
				    if typeIndex then
				        local tmp = tabList[typeIndex] or {}
				        if #tmp < maxCount then
							-- tmp[#tmp + 1] = item
							self:_insertLibaoToTabList(item,tmp)
					        tabList[typeIndex] = tmp
					    end
				    end
				end
			end
		end
	else
		for _, id in pairs(self.sortExchangeList) do
			local item = self.goldExchangeList[id]
			local typeIndex = item and tonumber(item.para4)
		    if typeIndex then
		        local tmp = tabList[typeIndex] or {}
		        if #tmp < maxCount then
					-- tmp[#tmp + 1] = item
					self:_insertLibaoToTabList(item,tmp)
			        tabList[typeIndex] = tmp
			    end
		    end
		end
	end

	return tabList
end

function LiBaoController:tabContainsLibaoId( libaoId )
	if not libaoId then
		return false
	end
	local tabList = self:getTabShowTypeBySort()
	if table.isNilOrEmpty(tabList) then
		return false
	end

	for k,v in pairs(tabList) do
		if table.find(v,function(cur)
			return cur.id == libaoId
		end) then
			return true
		end
	end
	return false
end

function LiBaoController:canBuyLibao( itemData )
	if table.isNilOrEmpty(itemData) then
		return false
	end

	local ModifyLibaoMgrInst = require("game.LiBao.ModifyLibaoMgrV1").getInstance()
	local cur,max = ModifyLibaoMgrInst:getLiBaoBuyTimes(itemData),self:getLiBaoMaxCount(itemData)
	return max == -1 or (cur and cur < max)
end

function LiBaoController:_insertLibaoToTabList( item, tabList )
	local sg_list = self:getLibaoSingleList()
	repeat
		-- 没有配置礼包链
		if table.isNilOrEmpty(sg_list) then
			break
		end

		local libao_id = item.id
		local libao_sg_list = sg_list[libao_id]

		-- 礼包链没有此id
		if table.isNilOrEmpty(libao_sg_list) then
			break
		end

		local ModifyLibaoMgrInst = require("game.LiBao.ModifyLibaoMgrV1").getInstance()
		for k,v in ipairs(libao_sg_list) do
			if table.contains(v,libao_id) then
				break
			end

			local buy_over_any = false
			for k1,v1 in ipairs(v) do
				local itemData = self:getGoldExchangeItemById(v1)
				if itemData then
					local cur,max = ModifyLibaoMgrInst:getLiBaoBuyTimes(itemData),
							LiBaoController.getInstance():getLiBaoMaxCount(itemData)
							
					local noLimit = max == -1
					-- 是不限购或者还没买完
					if noLimit or (cur < max) then
					else
						buy_over_any = true
						break
					end
				else
					buy_over_any = true
					break
				end
			end
			if not buy_over_any then
				return
			end
		end

	until true

	table.insert(tabList,item)
end

function LiBaoController:getNextLibaoList( libao_id )
	if string.isNilOrEmpty(libao_id) then
		return
	end
	local singleList = self:getLibaoSingleList()
	local sg = singleList and singleList[libao_id]
	if not sg then
		return
	end

	local t_len = #sg
	for i,v in ipairs(sg) do
		if i < t_len and table.contains(v,libao_id) then
			return sg[i+1]
		end
	end
end

function LiBaoController:getLibaoSingleList(  )
	local singleList = self.m_singleList
	if not singleList then
		singleList = {}
		local r = {
			["45006601"] = {id="45006601", libao_ids="765467|765468;765469;765470;765471;765472;765473"}
		}
		-- CCCommonUtilsForLua:getGroupByKey("libao_sg_list")
		if not table.isNilOrEmpty(r) then
			for k,v in pairs(r) do
				local ids = string.splitNSep(v.libao_ids,"|;")
				
				assert(not table.isNilOrEmpty(ids),"invalid ids in libao_sg_list")
				for k1,v1 in ipairs(ids) do
					for k2,v2 in ipairs(v1) do
						assert(not singleList[v2],"id duplicate in libao_sg_list")
						singleList[v2] = ids
					end
				end
			end
		end
		self.m_singleList = singleList
	end
	return singleList
end

function LiBaoController:getLiBaoViewByIds(libaoIds) --hanxiao1
	if table_is_empty(self.sortExchangeList or {}) or libaoIds == nil then
		return
	end

	local maxCount = tonumber(CCCommonUtilsForLua:getPropById("79001", "k1"));
	local tabList = {}
	for k,v in pairs(libaoIds or {}) do
		local item = self.goldExchangeList[v]
		tabList[#tabList+1] = item
	end
	
	local path = "game.LiBao.LibaoCommonPopupView"
	package.loaded[path] = nil
	local view = require(path):create(tabList)
	PopupViewController:addPopupView(view)
	
end
------------------------------------------------ lua内部获取排序礼包分割线 End ------------------------------------------------
function LiBaoController:onRefreshGroupExchangeData(param)
	self.timeZone = GlobalDataCtr.getTimeZone()*60*60
	local data = dictToLuaTable(param)
	local showType = data.showType
	-- 可用的showType列表
	if self.showTypeList == nil then
		self.showTypeList = {}
	end
	if data.showTypeList then
		for i, key in pairs(data.showTypeList) do
			if self.showTypeList[key] == nil then
				local typeInfo = {beDown = false}
				self.showTypeList[key] = typeInfo
			end
		end
	end

	local beRequireOther = false
	if self.goldExchangeListInit ~= true then
		beRequireOther = true
	end
	self.goldExchangeListInit = true
	if not self["goldExchangeList"] then
		self.goldExchangeList = {}
	end
	if data.exchange then
		-- 蛋疼的老机制
		if self.showTypeList[showType] == nil then
			self.showTypeList[showType] = {}
		else
			for i, key in pairs(self.showTypeList[showType].orderList or {}) do
				self.goldExchangeList[key] = nil
			end
		end
		local orderList = {}
		for key, item in pairs(data.exchange) do
			self:itemDefaultValue(item)
			self:_insertOneLibao(item)
			orderList[#orderList + 1] = item.id
		end

		self.showTypeList[showType].orderList = orderList
		self.showTypeList[showType].beDown = true
		if showType == "0" then
			self.sortExchangeList = orderList
		end
	else
		-- 憋屈的新机制，72上开了半年，外网始终没开
		if data.deletes and data.deletes ~= "" then
			local tbl = string.split(data.deletes, ",")
			for key, id in pairs(tbl) do
				self.goldExchangeList[id] = nil
			end
		end
		if data.updates then
			for key, item in pairs(data.updates) do
				self:itemDefaultValue(item)
				self:_insertOneLibao(item)
			end
		end
		if data.orderIds then
			if data.orderIds == "" then
				self.showTypeList[showType] = nil
			else
				local orderList = string.split(data.orderIds, ",")
				-- dump(orderList, " orderList is: ")
				-- 分组排序逻辑使用
				if showType == "0" then
					self.sortExchangeList = orderList
				end
				if self.showTypeList[showType] == nil then
					self.showTypeList[showType] = {}
				end
				self.showTypeList[showType].orderList = orderList
				self.showTypeList[showType].beDown = true
			end
		end
	end

	if showType == "0" then
		CCSafeNotificationCenter:postNotification(GOLDEXCHANGE_LIST_CHANGE)
	else
		local showKey = CCString:create(showType)
		CCSafeNotificationCenter:postNotification(GOLDEXCHANGE_GROUP_LIST_CHANGE, showKey)
	end

	if beRequireOther then
		-- 此处应请求响应的优先级较高的那些showType
		for i, key in pairs(self.initShowTypeList or {}) do
			if not self.showTypeList[key] 
				or not self.showTypeList[key].beDown 
				then
				-- 没有的数据或者未下载的数据，开始下载
				self:getExchangeDataRefersh(key)
			end
		end
	end
end

function LiBaoController:getFunctionOn(key)
	if UiCompoentControoller.checkHasInitData() then
		if self.functionOnKeys == nil then
			self.functionOnKeys = {}
		end
		if self.functionOnKeys[key] == nil then
			self.functionOnKeys[key] = CCCommonUtilsForLua:isFunOpenByKey(key)
		end
		return self.functionOnKeys[key]
	else
		return CCCommonUtilsForLua:isFunOpenByKey(key)
	end
end

function LiBaoController:getExchangeDataRefersh(showType)
	if self:getFunctionOn("loading_show_type") then
		LiBaoController.getInstance():call("getGroupExchangeData", tonumber(showType) or 0)
	else
		LiBaoController.getInstance():call("getExchangeData")
	end
end

function LiBaoController:checkHasGoldItemByShowType(show_type)
	-- dump("LiBaoController:checkHasGoldItemByShowType is: "..tostring(show_type))
	local showType = "0"
	if show_type then
		showType = tostring(show_type)
	end
	local result = false
	if self:getFunctionOn("loading_show_type") then
		if showType == "0" then
			result = true
		else
			if not self.showTypeList[showType] then
				-- 不在服务器发送列表中，直接返回空
				result = false
			else
				result = true 
			end
		end
	else
		local tbl = self:getExchangeListByShowType(show_type)
		if #tbl > 0 then
			result = true
		end
	end

	-- dump("LiBaoController:checkHasGoldItemByShowType result is: "..tostring(result))

	return result
end

-- 判断是否有showType类型的礼包
function LiBaoController:checkHasGoldItemByDict(dict)
	
	local showType = "0"
	local tmp = dict:objectForKey("showType")
	if tmp then
		showType = tmp:getCString()
	end
	local result = self:checkHasGoldItemByShowType(showType)
	if dict then
		dict:setObject(CCBool:create(result), "result")
	end
	return result
end

function LiBaoController:initConfigData(dict)
	local showType = dict:objectForKey("loading_show_type")
	-- dump(showType, " showType is: ")
	self.initShowTypeList = {}
	if showType then
		local str = showType:getCString()
		local tbl = string.split(str, ";")
		for i, str in pairs(tbl) do
			local tmp = string.split(str, "-")
			if #tmp == 1 then
				self.initShowTypeList[#self.initShowTypeList + 1] = tostring(tmp[1])
			else
				local startNum = tonumber(tmp[1])
				local endNum = tonumber(tmp[2])
				for i = startNum, endNum do
					self.initShowTypeList[#self.initShowTypeList + 1] = tostring(i)
				end
			end
		end
	end
	-- dump(self.initShowTypeList, " self.initShowTypeList is: ")
end

function LiBaoController:getServerSortMapByShowType(m_data, m_showType)
	-- dump("LiBaoController :getServerSortMapByShowType(m_data, m_showType"..tostring(m_showType))
	-- 现默认的m_data 为空表，因代码调用均为空表
	if table_is_empty(self.sortExchangeList or {}) then
		-- dump(" LiBaoController:getServerSortMapByShowType 11111111111111")
		return {}
	end
	local sortList = nil
	-- 可用的showType列表
	if self.showTypeList == nil then
		self.showTypeList = {}
	end
	local keyType = tostring(m_showType)
	if keyType == "0" then
		-- 先直接取sortExchangeList
		sortList = self.sortExchangeList
	else
		if not self.showTypeList[keyType] then
			-- 不在服务器发送列表中，直接返回空
			return {}
		elseif self.showTypeList[keyType].beDown == false then
			-- 在下载列表中，但是还未申请，
			self:getExchangeDataRefersh(keyType)
			return {}
		else
			sortList = self.showTypeList[keyType].orderList
		end
	end
	local m_dataTbl = {}
	for i = 1, #sortList do
		local item = self.goldExchangeList[sortList[i]]
		if item 
			and item.type == "3" 
			and not item.bought
			and item.popup_image ~= "close"
			then
			m_dataTbl[#m_dataTbl+1] = item.id
		end
	end
	self.m_popItemId = self:getPopItemId()
	if self.maxCount == nil then
		self.maxCount = tonumber(CCCommonUtilsForLua:getPropById("79001", "k1"))
	end
	local maxCount = self.maxCount
	local m_popItemId = ""
	if keyType == "0" then
		-- 数据回写逻辑
		self:showItemCountSort(m_dataTbl)
		for key, id in pairs(m_dataTbl) do
			local item = self.goldExchangeList[id]
			if item and item.show_type == "" then
				m_popItemId = id
				self:setPopItemId(m_popItemId)
				break
			end
		end
	end

	-- 判断最大数量
	while maxCount < #m_dataTbl do
		table.remove(m_dataTbl, #m_dataTbl)
	end

	self.m_dataTbl = m_dataTbl
	if m_data then
		-- 最后回写m_data数据
		for key, id in pairs(m_dataTbl) do
			m_data:addObject(CCString:create(id))
		end
	end
	-- dump(m_dataTbl, " LiBaoController:getServerSortMapByShowType 666666666",1)
	if m_showType == 0 and self.m_popItemId ~= "" and self.m_popItemId ~= m_popItemId then
		-- 弹出礼包id存在，并且礼包id不同，则变化icon
		CCSafeNotificationCenter:postNotification(GOLDEXCHANGE_ICON_LIST_CHANGE)
	end
	-- dump(m_dataTbl, "self.m_dataTbl is:", 1)
	return self.m_dataTbl
end

function LiBaoController:dumpInfomation()
    -- Dprint("LiBaoController:dumpInfomation() begin")
    dump(self.goldExchangeList)
    -- Dprint("LiBaoController:dumpInfomation() end")
end

function LiBaoController:makeExchangeItem( itemData )
	local need_keys = self.m_need_keys
	if not need_keys then
		need_keys = {
			"id",
			"type",
			"gold_doller",
			"dollar",
			"name_doller",
			"gift",
			"item",
			"percent",
			"oldprice",
			"product_id",
		}
		self.m_need_keys = need_keys
	end

	local newData = {}
	for _,v in ipairs(need_keys) do
		newData[v] = itemData[v]
	end
	local dict = luaTableToDict(newData)
	local goldExchangeItem = GoldExchangeItem:call("create1", dict)
	return goldExchangeItem
end

function LiBaoController:getSortExchangeList(  )
	return self.sortExchangeList
end

function LiBaoController:getLiBaoIconConfig()
	if self.m_iconConfig == nil then
		self.m_iconConfig = CCCommonUtilsForLua:getGroupByKey("libao_icon_config")
	end

	return self.m_iconConfig
end

function LiBaoController:getLibaoReadyEvent(  )
	local libaoReadyEv = self.m_libaoReadyEv
	if not libaoReadyEv then
	    libaoReadyEv = utils.getEventClass(  ):create()
	    self.m_libaoReadyEv = libaoReadyEv
	end
	return libaoReadyEv
end

function LiBaoController:getLibaoPayedOkViewEvent(  )
	local libaoOkViewEv = self.m_libaoOkViewEv
	if not libaoOkViewEv then
	    libaoOkViewEv = utils.getEventClass(  ):create()
	    self.m_libaoOkViewEv = libaoOkViewEv
	end
	return libaoOkViewEv
end

function LiBaoController:emitLibaoReady(  )
	self.m_tabShowTypeBySort = nil
	if not self.m_hadEmit then
		local all_list = LiBaoController.getInstance():getGoldExchangeList()
		if not table.isNilOrEmpty( all_list ) then
			local all_keys = table.keys(all_list)
			if not table.isNilOrEmpty( all_keys ) then
				self.m_hadEmit = true
				self:getLibaoReadyEvent():emit()
			end
		end
	end
end

function LiBaoController:_tranItems( libao_info,itemKey )
	local res = {}
	if table.isNilOrEmpty(libao_info) then
		return res
	end
	local tv = libao_info[itemKey]
	if string.isNilOrEmpty(tv) then
		return res
	end

	local type_str = itemKey == "item" and RewardTypeConfig.R_GOODS or RewardTypeConfig.R_EQUIP
	type_str = tostring(type_str)
	local tv_arr = string.splitNSep(tv,"|;")
	
	for _,v in ipairs(tv_arr) do
		local t = {
			type = type_str,
			value = {
				id = v[1],
				num = v[2]
			}
		}
		table.insert(res,t)
	end
	return res
end

function LiBaoController:getRewardArryByLibaoItems( libao_info )
	libao_info = type(libao_info) == "string" and self:getGoldExchangeItemById(libao_info) or libao_info
	local res = {}
	if table.isNilOrEmpty(libao_info) then
		return res
	end
	
	table.append(res,self:_tranItems(libao_info,"item"))
	table.append(res,self:_tranItems(libao_info,"equipment"))
	return res
end

-- common cell factory
function LiBaoController:_makeNewCell(params,libaoId)
	return Drequire("game.LiBao.LuaGoldExchangeCommonCell").new(params, libaoId)
end

function LiBaoController:getCellFromFactory(params,libaoId,init_reserve_num)
	self.m_cellFactory = self.m_cellFactory or {}
	local showType = params.showType or 0
	
	local cellNodePool = self.m_cellFactory[showType]
	if not cellNodePool then
		cellNodePool = utils.getExtendClass("nodePool",true):create()
		self.m_cellFactory[showType] = cellNodePool
	end
	if init_reserve_num and cellNodePool:isEmpty() then
		local init_cells = {}
		for i=1,init_reserve_num do
			local tCell = cellNodePool:getFromPool(utils.handler2(self,self._makeNewCell,params,libaoId))
			tCell._facetoryShowType = showType
			table.insert(init_cells, tCell)
		end
		for _, v in ipairs(init_cells) do
			cellNodePool:_releaseToPool(v)
		end
	end
	local tCell = cellNodePool:getFromPool(utils.handler2(self,self._makeNewCell,params,libaoId))
	tCell._facetoryShowType = showType
	return tCell
end

function LiBaoController:releaseCellToFactory(tCell)
	local showType = tCell._facetoryShowType
	if not showType then
		return
	end
	local cellNodePool = self.m_cellFactory[showType]
	if not cellNodePool then
		return
	end
	cellNodePool:_releaseToPool(tCell)
end

function LiBaoController:destoryFactory()
	for k,v in pairs(self.m_cellFactory or {}) do
		v:purgeAll()
	end
	self.m_cellFactory = {}
end