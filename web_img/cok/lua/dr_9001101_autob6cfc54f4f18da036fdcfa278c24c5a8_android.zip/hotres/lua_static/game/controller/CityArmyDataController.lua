--[[ 
    获取城内士兵信息
    2019.9.23   Awen
 ]]

local CityArmyDataController = class("CityArmyDataController")
local _instance = _instance or nil

function CityArmyDataController.getInstance()
    if not _instance then 
        _instance = CityArmyDataController.new() 
    end
    return _instance
end

-- 处理C++调用
function CityArmyDataController:fireEventRef( key, dict )
	Dprint('CityArmyDataController:fireEvenntRef key='..key)
	if key == "getPathAndPoints" then
        self:getPathAndPoints(dict)
    elseif key == "getPathPedlar" then
        self:getPathPedlar(dict)
    elseif key == "getPathBoat" then
        self:getPathBoat(dict)
	end
end

-- 获取城内士兵到集结旗路线及集结方阵
function CityArmyDataController:getPathAndPoints(dict)
    local _civType = dict:valueForKey("type"):intValue()

    if _civType == 4 then   --阿拉伯文明
        local _path = {
            {pos = "1", points = {440,970, 540,920, 320,900, 220,790}, zorder = {900}},
            {pos = "8", points = {49,805, 61,649, 80,491}, zorder = {900}},
            {pos = "10", points = {747,707, 540,610, 230,745, 61,649, 80,491}, zorder = {900}},
            {pos = "13", points = {1140,1476, 1212,1398, 1254,1421, 1386,1356, 1328,1301, 1469,1133, 1546,1089, 540,610, 230,745, 61,649, 80, 491}, zorder = {900}},
            {pos = "9", points = {230,745, 61,649, 80,491}, zorder = {900}},
            {pos = "11", points = {804,730, 540,610, 230,745, 61,649, 80,491}, zorder = {900}},
            {pos = "52", points = {698,1002, 847,833, 924,789, 540,610, 230,745, 61,649, 80, 491}, zorder = {500}},
            {pos = "7", points = {408,1115, 477,1037, 430,1014, 558,950, 698,1002, 847,833, 924,789, 540,610, 230,745, 61,649, 80, 491}, zorder = {900}},
            {pos = "53", points = {1084,863, 540,610, 230,745, 61,649, 80, 491}, zorder = {500}},
            {pos = "14", points = {1321,1307, 1469,1133, 1546,1089, 540,610, 230,745, 61,649, 80, 491}, zorder = {500}},
            {pos = "13", points = {1140,1476, 1212,1398, 1254,1421, 1386,1356, 1328,1301, 1469,1133, 1546,1089, 540,610, 230,745, 61,649, 80, 491}, zorder = {500}},
            {pos = "56", points = {1679,1154, 540,610, 230,745, 61,649, 80,491}, zorder = {500}},
            {pos = "15", points = {1713,1173, 540,610, 230,745, 61,649, 80,491}, zorder = {500}},
            {pos = "6", points = {1780,1296, 1875,1248, 540,610, 230,745, 61,649, 80,491}, zorder = {500}},
            {pos = "16", points = {1555,1407, 1875,1248, 540,610, 230,745, 61,649, 80,491}, zorder = {500}},
            {pos = "12", points = {1286,1548, 1875,1248, 540,610, 230,745, 61,649, 80,491}, zorder = {500}},
        }
        dict:setObject(luaToArray(_path), "path")

        local _square = {-305,570,   -219,528,    -133,485,    -47,443,    39,400,     125,358,     218,309,
                        -411,516,    -325,474,    -239,431,    -153,389,   -67,346,    19,304,      110,262,    206,212,
                        -517,462,    -431,422,    -345,377,    -259,335,   -173,292,   -87,250,     -12,210,    76,167,     167,123,    
                        -599,398,    -521,363,    -441,323,    -358,279,   -278,240,   -205,200,    -101,146,
                        -549,305,   
                    }
        dict:setObject(luaToArray(_square), "square")
    end
end

-- 获取小商贩路线
function CityArmyDataController:getPathPedlar(dict)
    local _civType = dict:valueForKey("type"):intValue()

    -- 商贩方向：   -45:左上   45:左下  -90:上  90:下   0:左
    if _civType == 4 then   --阿拉伯文明
        local _path = {
            {direction = "0", x = "3551", y = "411"},
            {direction = "0", x = "3280", y = "452"},
            {direction = "0", x = "3035", y = "559"},
            {direction = "45", x = "2390", y = "369"},
            {direction = "0", x = "1987", y = "454"},
            {direction = "-45", x = "1940", y = "479"},
        }
        dict:setObject(luaToArray(_path), "path")
    end
end

-- 获取小船路线
function CityArmyDataController:getPathBoat(dict)
    local _civType = dict:valueForKey("type"):intValue()

    local _path = nil
    -- 小船方向：   0:左  1:左下    2:右上  3:右
    if _civType == RACE_TYPE_WEI_JING then      --维京文明
        _path = {
            {direction = "0", x = "3170", y = "1330"},
            {direction = "0", x = "2957", y = "1375"},
            {direction = "0", x = "2789", y = "1373"},
            {direction = "0", x = "2656", y = "1405"},
            {direction = "0", x = "2656", y = "1405"},
            {direction = "1", x = "2754", y = "1141"},
            {direction = "1", x = "2754", y = "1141"},
            {direction = "1", x = "2789", y = "1373"},
            {direction = "0", x = "2957", y = "1375"},
            {direction = "0", x = "3170", y = "1330"},
            {direction = "0", x = "3700", y = "1470"},
        }
    elseif _civType == RACE_TYPE_DA_HE then     --大和文明
        _path = {
            {direction = "0", x = "3236", y = "1606"},
            {direction = "1", x = "3229", y = "1492"},
            {direction = "0", x = "3704", y = "1666"},
        }
    elseif _civType == RACE_TYPE_HUA_XIA then   --华夏文明
        _path = {
            {direction = "0", x = "3400", y = "1570"},
            {direction = "1", x = "3315", y = "1612"},
            {direction = "1", x = "2678", y = "1805"},
            {direction = "1", x = "2678", y = "1805"},
            {direction = "1", x = "3315", y = "1612"},
            {direction = "0", x = "3400", y = "1570"},
            {direction = "0", x = "3704", y = "1666"},
        }
    elseif _civType == RACE_TYPE_ARAB then      --阿拉伯文明
        _path = {
            {direction = "3", x = "3700", y = "1720"},
            {direction = "0", x = "2848", y = "1695"},
            {direction = "0", x = "2461", y = "1753"},
            {direction = "1", x = "2333", y = "1533"},
            {direction = "1", x = "2562", y = "1310"},
            {direction = "1", x = "2294", y = "893"},
            {direction = "1", x = "2294", y = "893"},
            {direction = "1", x = "2562", y = "1310"},
            {direction = "1", x = "2333", y = "1533"},
            {direction = "0", x = "2461", y = "1753"},
            {direction = "0", x = "2848", y = "1695"},
            {direction = "3", x = "3700", y = "1720"},
        }
    else    --龙裔文明
        _path = {
            {direction = "0", x = "3185", y = "1524"},
            {direction = "1", x = "3081", y = "1461"},
            {direction = "1", x = "2711", y = "1437"},
            {direction = "1", x = "2495", y = "1180"},
            {direction = "1", x = "2495", y = "1180"},
            {direction = "2", x = "2711", y = "1437"},
            {direction = "1", x = "3081", y = "1461"},
            {direction = "1", x = "3185", y = "1524"},
            {direction = "3", x = "3700", y = "1470"},
        }
    end
    if _path then
        dict:setObject(luaToArray(_path), "path")
    end
end


return CityArmyDataController