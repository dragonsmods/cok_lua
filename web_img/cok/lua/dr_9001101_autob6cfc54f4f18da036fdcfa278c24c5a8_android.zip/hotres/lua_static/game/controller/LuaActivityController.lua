LuaActivityController = class("LuaActivityController")
ActivityEventObj = ActivityEventObj or {}

-- 王力宏音乐的时间长度
WANGLIHONG_MUSIC_TIME_SPAN = 35

local _instance = nil 

function LuaActivityController:ctor(  )
	self.wanglihongdata = nil
	self.lastwanglihongrefreshtime = 0
	self.lastlistenwanglihongtime = 0

	-- 一种活动的进度
	self.actValue = 0
	self.actMaxValue = 0
	self.actProType = 0  -- 1 雪怪世界boss  2 npc boss

	-- 蛋的上次刷新时间 
	self.lastReqEggDataTime = 0

	self.quality_list = {}
	self.receive_list = {}
	self.free_num = 0
	self.free_time = 0
	self.need_gold = 0
	self.m_eggInfos = nil

	-- 活动的各种值
	self.m_actKeyValues = {}
	-- 活动相关的各种时间数据
	self.m_actKeyTimes = {}
	-- 某个refreshType 1 分钟 2 小时 3 天 4 周 5 月 6 年
	self.m_actRefreshTypes = {}
	-- 刷新周期数
	self.m_actRefreshInterval = {}

	local function onEnterFrame( dt )
		self:onEnterFrame(dt)
	end

	self.schedulerID = cc.Director:getInstance():getScheduler():scheduleScriptFunc(onEnterFrame, 1, false)
end

function LuaActivityController:dtor(  )
	if nil ~= self.schedulerID then
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.schedulerID)
	end
end

function LuaActivityController.getInstance(  )
	if nil == _instance then
		_instance = LuaActivityController.new()
	end
	return _instance
end

function LuaActivityController.purge(  )
	if nil ~= _instance then
		_instance:dtor()
	end
	_instance = nil
end

function LuaActivityController:onEnterFrame( dt )
	-- MyPrint("LuaActivityController:onEnterFrame")
	local nowtime = LuaController:call("getTimeStamp")
	local pass = nowtime - self.lastlistenwanglihongtime 
	-- MyPrint("onEnterFrame: pass", pass)
	if pass >= WANGLIHONG_MUSIC_TIME_SPAN and pass < WANGLIHONG_MUSIC_TIME_SPAN + 2 then
		self.lastlistenwanglihongtime = 0 
		if ImperialScene:call("getInstance") ~= nil then
			MyPrint("play ImperialScene music")
			SoundController:call("sharedSound"):call("stopAllMusic")
			SoundController:call("sharedSound"):call("playBGMusic", "m_city_new")
		elseif WorldMapView:call("instance") ~= nil then
			MyPrint("play world music")
			SoundController:call("sharedSound"):call("stopAllMusic")
			SoundController:call("sharedSound"):call("playBGMusic", "m_field_new")
		end
	end
end

function LuaActivityController:parseWangLihongInfo( dict )
	if nil == dict then
		MyPrint("parseWangLihongInfo error!!!! dict == nil")
		return
	end
	MyPrint("parseWangLihongInfo")
	self.lastwanglihongrefreshtime = LuaController:call("getTimeStamp")

	self.wanglihongdata = self.wanglihongdata or {}
	local data = self.wanglihongdata
	data.listened_times_today = dict:valueForKey("listen"):intValue()
	data.listen_total_times_today = dict:valueForKey("listen_total_times"):intValue()
	data.shared_times_today = dict:valueForKey("share"):intValue()
	data.share_total_times_today = dict:valueForKey("share_total_times"):intValue()
	
	dump(data, data)
	dump(self.wanglihongdata, "self.wanglihongdata")
end

function LuaActivityController:startGetWangLihongData(  )
	MyPrint("startGetWangLihongData")
	require "game.command.WangLihongCmd"
	local cmd = WangLihongCmd.new()
	cmd:send()
end

function LuaActivityController:onGetWangLihongData( dict )
	if nil == dict then
		return
	end

	self:parseWangLihongInfo(dict:objectForKey("info"))

	CCSafeNotificationCenter:call("postNotification", "wanglihong_data_init")
end

function LuaActivityController:startShitingWangLihong(  )
	MyPrint("startShitingWangLihong")
	require "game.command.WangLihongCmd"
	local cmd = WangLihongListenCmd.new()
	cmd:send()

	-- 标记
	self.lastlistenwanglihongtime = LuaController:call("getTimeStamp")
end

function LuaActivityController:onShitingWangLihong( dict )
	if nil == dict then
		return
	end

	self:parseWangLihongInfo(dict:objectForKey("info"))

	-- 试听有可能有奖励
	local arr = dict:objectForKey("rewards")
	if nil ~= arr then
		PortActController:call("flyReward", arr, true)
		local rwdInfo = RewardController:call("retReward", arr)
		MyPrint("rwdInfo", rwdInfo)
		CCCommonUtilsForLua:call("flyHint", "", "", rwdInfo)
	end

	
end

function LuaActivityController:startFenxiangWangLihong(  )
	MyPrint("startFenxiangWangLihong")
	require "game.command.WangLihongCmd"
	local cmd = WangLihongShareCmd.new()
	cmd:send()
end

function LuaActivityController:onFenxiangWangLihong( dict )
	if nil == dict then
		return
	end

	self:parseWangLihongInfo(dict:objectForKey("info"))

	-- 分享有可能有奖励 但是可能不走这个
	local arr = dict:objectForKey("rewards")
	if nil ~= arr then
		PortActController:call("flyReward", arr, true)
		local rwdInfo = RewardController:call("retReward", arr)
		MyPrint("rwdInfo", rwdInfo)
		CCCommonUtilsForLua:call("flyHint", "", "", rwdInfo)
	end

end

function LuaActivityController:onMonsterKillCntChange( dict )
	MyPrint("onMonsterKillCntChange")
	if nil == dict then
		return
	end

	self.actValue = dict:valueForKey("value"):intValue()
	self.actMaxValue = dict:valueForKey("max_value"):intValue()
	self.actProType = dict:valueForKey("type"):intValue()
	MyPrint("actValue, actMaxValue", self.actValue, self.actMaxValue)
	CCSafeNotificationCenter:call("postNotification", "msg_act_value_pro_change")
end

function LuaActivityController:retEggsData( dict )
	-- retObj.putSFSArray("quality_list",retObjArr);
	-- retObj.putSFSArray("receive_list",retObjArrRec);
	-- retObj.putLong("free_time",lValue); 倒计时刷新时间戳
	-- retObj.putLong("free_num",value); 剩余的免费刷新次数
	-- retObj.putInt("need_gold",this.need_gold); 用金币刷新需要的金币数量

	if nil == dict then
		return
	end
	self.quality_list = arrayToLuaTable(dict:objectForKey("quality_list"))
	self.receive_list = arrayToLuaTable(dict:objectForKey("receive_list"))
	self.free_num = dict:valueForKey("free_num"):intValue()
	self.free_time = tonumber(dict:valueForKey("free_time"):getCString()) / 1000
	self.need_gold = dict:valueForKey("need_gold"):intValue()
	self.lastReqEggDataTime = GlobalData:call("getTimeStamp")
	CCSafeNotificationCenter:call("postNotification", "msg_egg_data_back")
end

function LuaActivityController:getEggInfoById( id )
	local infos = self:getEggInfos()
	return infos[tostring(id)]
end

function LuaActivityController:getEggInfos(  )
	if nil == self.m_eggInfos then
		local xmlmanager = LocalController:call("DBXMLManager")
	    local dict = xmlmanager:call("getGroupByKey", "lucky_egg")
		self.m_eggInfos = dictToLuaTable(dict)
		dump(self.m_eggInfos, "self.m_eggInfos")
	end
	return self.m_eggInfos
end

function LuaActivityController:requestServerActValue( key )
	MyPrint("LuaActivityController:requestServerActValue ", key)
	if nil == key then
		return
	end

	require("game.command.GetActivityValueCommand")
	local cmd = GetActivityValueCommand.create(key)
	cmd:send()
end

function LuaActivityController:onGetServerActValue( params )
	MyPrint("LuaActivityController:onGetServerActValue", params)
	dump(params, "params")
	if nil == params then
		return
	end

	local keys = params["keys"]
	local values = params["values"]
	local times = params["refreshTimes"]
	local refreshType = params["refreshType"]
	local refreshInterval = params["refreshInterval"]
	if nil ~= values then
		local t = string.split(values, ";")
		for i,v in ipairs(t) do
			local vv = string.split(v, "=")
			if #vv == 2 then
				self.m_actKeyValues[ vv[1] ] = vv[2]
			end
		end
	end
	if nil ~= times then
		local t = string.split(times, ";")
		for i,v in ipairs(t) do
			local vv = string.split(v, "=")
			if #vv == 2 then
				self.m_actKeyTimes[ vv[1] ] = vv[2]
			end
		end
	end
	if nil ~= refreshType then
		local t = string.split(refreshType, ";")
		for i,v in ipairs(t) do
			local vv = string.split(v, "=")
			if #vv == 2 then
				self.m_actRefreshTypes[ vv[1] ] = vv[2]
			end
		end
	end
	if nil ~= refreshInterval then
		local t = string.split(refreshInterval, ";")
		for i,v in ipairs(t) do
			local vv = string.split(v, "=")
			if #vv == 2 then
				self.m_actRefreshInterval[ vv[1] ] = vv[2]
			end
		end
	end
	
	dump(self.m_actKeyValues, "self.m_actKeyValues")
	dump(self.m_actKeyTimes, "self.m_actKeyTimes")
	dump(self.m_actRefreshTypes, "self.m_actRefreshTypes")
	dump(self.m_actRefreshInterval, "self.m_actRefreshInterval")
	CCSafeNotificationCenter:call("postNotification", "msg_act_key_value_back", CCString:create(tostring(keys)))
end

function LuaActivityController:getValueByKey( key )
	MyPrint("LuaActivityController:getValueByKey ", key)
	if nil == key then
		return nil
	end

	return self.m_actKeyValues[key]
end

function LuaActivityController:getTimeByKey( key )
	MyPrint("LuaActivityController:getTimeByKey ", key)
	if nil == key then
		return nil
	end
	return self.m_actKeyTimes[key]
end

function LuaActivityController:getRefreshTypeByKey( key )
	MyPrint("LuaActivityController:getRefreshTypeByKey ", key)
	if nil == key then
		return nil
	end
	return self.m_actRefreshTypes[key]
end

function LuaActivityController:getRefreshIntervalByKey( key )
	MyPrint("LuaActivityController:getRefreshIntervalByKey ", key)
	if nil == key then
		return nil
	end
	return self.m_actRefreshInterval[key]
end

function LuaActivityController:getRealRefreshIntervalByKey( key )
	MyPrint("LuaActivityController:getRealRefreshIntervalByKey ", key)
	if nil == key then
		return nil
	end

	local interval = self.m_actRefreshInterval[key]
	if nil == interval or "" == interval then
		return nil
	end
	-- // 刷新方式 1 分钟 2 小时 3 天 4 周 5 月 6 年

	interval = math.tonumber(interval)
	local refreshType = self:getRefreshTypeByKey(key)
	if refreshType == "1" then
		return 60 * interval
	end
	if refreshType == "2" then
		return 60 * 60 * interval
	end
	if refreshType == "3" then
		return 24 * 60 * 60 * interval
	end
	if refreshType == "4" then
		return 7 * 24 * 60 * 60 * interval
	end
	if refreshType == "5" then
		return 30 * 24 * 60 * 60 * interval
	end
	if refreshType == "6" then
		return 365 * 24 * 60 * 60 * interval
	end

	return nil
end
