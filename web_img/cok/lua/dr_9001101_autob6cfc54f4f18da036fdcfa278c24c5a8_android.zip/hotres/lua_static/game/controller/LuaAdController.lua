--[[ 
    广告控制类
    2019.6.10   Awen
 ]]

 local LuaAdController = class("LuaAdController")

 AD_TYPE = {
    HERO_DRAW_NORMAL = 1        --普通英雄招募
    ,HERO_DRAW_SENIOR = 2       --高级英雄招募
    ,MAGIC_DRAW_NORMAL = 3      --普通魔法抽卡
    ,MAGIC_DRAW_SENIOR = 4      --高级魔法抽卡
    ,CIVI_CRYSTAL = 5           --文明结晶
    ,MAIN_CITY_LD = 6           --主页
    ,GENERAL_HP = 7             --领主体力
    ,ACE_SHOOTER = 8            --王牌射手
    ,DUOBAO_DRAW_DIAMOND = 9    --装扮夺宝钻石抽奖
    ,DUOBAO_DRAW_GOLD = 10      --装扮夺宝金币抽奖
    ,FESTIVAL_DRAW = 11         --节日转盘
    ,GOLDBOX_DRAW = 12          --黄金宝箱
    ,NAFU_DRAW = 13             --聚宝纳福
    ,RANDOMBUY_FRESH = 14       --随选商城刷新
    ,MAGICGAMBLE_LOTTERY = 15   --占星魔法屋
    ,ALLIANCE_SUPPLIES = 16     --联盟物资
    ,HERO_53580 = 17            --英雄帝国之盾
    ,HERO_53582 = 18            --英雄猛虎武士
    ,KNIGHT_QUESTION = 19       --骑士大厅答题
    ,CARGO_BOX = 20             --码头宝箱
    ,NEW_PLAYER_1 = 21          --新手看广告获得增益
    ,NEW_PLAYER_2 = 22          --新手看广告获得增益
    ,NEW_PLAYER_3 = 23          --新手看广告获得增益
    ,DIG_GEM = 24               --挖掘宝石
 }

--[[  
##队列加速暂时搁置
--广告队列加速
local CheckQueueType = 
{
    TYPE_BUILDING = 0,--建筑0
    TYPE_FORCE = 1,--步兵
    TYPE_HOSPITAL = 3, --医院
    TYPE_SCIENCE = 6, --科技
    TYPE_RIDE_SOLDIER = 8, --骑8
    TYPE_BOW_SOLDIER = 9,  --弓9
    TYPE_CAR_SOLDIER =10,  --车10
}
--队列加速映射广告类型
local QueueType2AdType = {
    [CheckQueueType.TYPE_BUILDING] = AD_TYPE.BUILDING, --建筑加速
    [CheckQueueType.TYPE_FORCE] = AD_TYPE.SOLDIER_FORCE,--步兵
    [CheckQueueType.TYPE_RIDE_SOLDIER] = AD_TYPE.SOLDIER_RIDE,--骑兵
    [CheckQueueType.TYPE_BOW_SOLDIER] = AD_TYPE.SOLDIER_BOW,--弓兵
    [CheckQueueType.TYPE_CAR_SOLDIER] = AD_TYPE.SOLDIER_CAR,
    [CheckQueueType.TYPE_HOSPITAL] = AD_TYPE.HOSPITAL,--医院
    [CheckQueueType.TYPE_SCIENCE] = AD_TYPE.SCIENCE, --科研
} ]]

 --处理回调
 local CALL_BACK = {
     [AD_TYPE.HERO_DRAW_NORMAL] =  function(params)
        if isFunOpenByKey("general_draw_new") then  -- 英雄多卡池招募
            require("game.hero.recruit.HeroRecruitController").getInstance():reqVideoRecruit(AD_TYPE.HERO_DRAW_NORMAL)
        else
            HeroLuckDrawController:reqLuckDrawByAd(AD_TYPE.HERO_DRAW_NORMAL)
        end
    end
    ,[AD_TYPE.HERO_DRAW_SENIOR] = function(params)
        if isFunOpenByKey("general_draw_new") then  -- 英雄多卡池招募
            require("game.hero.recruit.HeroRecruitController").getInstance():reqVideoRecruit(AD_TYPE.HERO_DRAW_SENIOR)
        else
            HeroLuckDrawController:reqLuckDrawByAd(AD_TYPE.HERO_DRAW_SENIOR)
        end
    end
     ,[AD_TYPE.MAGIC_DRAW_NORMAL] =  function(params)
        MagicLuckDrawController:reqLuckDrawByAd(AD_TYPE.MAGIC_DRAW_NORMAL)
     end
     ,[AD_TYPE.MAGIC_DRAW_SENIOR] = function(params)
        MagicLuckDrawController:reqLuckDrawByAd(AD_TYPE.MAGIC_DRAW_SENIOR)
     end
     ,[AD_TYPE.CIVI_CRYSTAL] = function(params)
        require("game.command.LuaAdCommand"):reqADGoods(AD_TYPE.CIVI_CRYSTAL)
     end
     ,[AD_TYPE.MAIN_CITY_LD] = function(params)
        require("game.command.LuaAdCommand"):reqADGoods(AD_TYPE.MAIN_CITY_LD)
     end
     ,[AD_TYPE.GENERAL_HP] = function(params)
        require("game.command.LuaAdCommand"):reqADGoods(AD_TYPE.GENERAL_HP)
     end
     ,[AD_TYPE.ACE_SHOOTER] = function(params)
        require("game.command.LuaAdCommand"):reqADGoods(AD_TYPE.ACE_SHOOTER)
     end
     ,[AD_TYPE.KNIGHT_QUESTION] = function(params)
        require("game.knightActivity.answerActivity.KnightQAController"):getInstance():reqPanelBaseDataByAd(AD_TYPE.KNIGHT_QUESTION)
     end
     ,[AD_TYPE.CARGO_BOX] = function(params)
        PortActController:call("getInstance"):call("startTimeRwd", AD_TYPE.CARGO_BOX)
     end
     ,[AD_TYPE.DIG_GEM] = function (params)
        require("game.equipment.gem.EquipmentGemController").getInstance():reqAd(AD_TYPE.DIG_GEM)
     end
 }
 ---------------------------------------------------- 
 --[[ 
     获取广告基础数据
  ]]
local AdDataCmd = class("AdDataCmd", LuaCommandBase)
function AdDataCmd.req(types)
    Dprint("AdDataCmd.create", types)
    local ret = AdDataCmd.new()
    ret:initWithName("video.info")
    ret:putParam("videoStr", CCString:create(types))
    ret:send()
end

function AdDataCmd:handleReceive(dict)
    local flag, params = self:parseMsg(dict)
    Dprint("AdDataCmd:handleReceive | parse flag=", flag)
    if (type(flag) == "boolean") then
        return flag
    end
    
    -- dump(flag, "AdDataCmd:handleReceive -->")
    LuaAdController.getInstance():refreshData(flag)
    return true
end
 
 
 ---------------------------------------------------- 
local _instance = nil
function LuaAdController.getInstance()
    if _instance == nil then
        _instance = LuaAdController.new()
    end
    return _instance
end

-- 接收CPP调用
function LuaAdController:fireEventRef(newKey, dict)
    Dprint("LuaAdController:fireEventRef", newKey)
    if newKey == "init" then
        self:initAd()
    elseif newKey == "callback" then
        local _type = dict:valueForKey('type'):intValue()
        self:callback(_type)
    elseif newKey == "checkState" then
        self:checkShowState(dict)
    elseif newKey == "playVideo" then
        self:checkAndPlay(dict)
    elseif newKey == "playBGMusicAfterCallback" then
        local _type = 0
        if dict ~= "" then
            _type = dict:valueForKey('type'):intValue()
        end
        self:playBGMusicAfterCallback(_type)
    elseif newKey == "finishPreload" then
        self:adsFinishPreload(dict)
    end
end
 
-- 是否开启
function LuaAdController:isOpen()
    return self.v_isInitAd and CCCommonUtilsForLua:isFunOpenByKey("google_video")
end

-- 初始化广告
function LuaAdController:initAd( type )
    Dprint('LuaAdController:initAd')
    if CCCommonUtilsForLua:isFunOpenByKey("google_video") then

        if not CCCommonUtilsForLua:isFunOpenByKey("google_ad_separate") and type then
            return
        end

        local _analyticID = GlobalData:call("shared"):getProperty("analyticID")
        local _config = CCCommonUtilsForLua:call("getPropByIdGroup","data_config","google_ad_sdk2","k1")
        if _config then
            self.v_isInitAd = false
            self.v_showReward = 0
            for k,v in ipairs(string.split(_config, ';') or {}) do
                if _analyticID == v then
                    self.v_isInitAd = true
                    break
                end
            end

            if self.v_isInitAd and not self:isAdLoaded(type) and not self:isShowCokVideo() then
                if CCCommonUtilsForLua:isFunOpenByKey("google_ad_separate") then
                    local _uid = nil
                    if type then
                        _uid = self:initAdUnitId(type)
                    else
                        _uid = self:initAdUnitId(AD_TYPE.MAIN_CITY_LD)
                    end
                    AdVideoController:call("getInstance"):call("initConfigGoogleMobileAdsWithUnitId", _uid)
                    local logParams = self:getLogExtParams(type, {tag='initWithUnitId',adId=_uid})
                    LogController:postEventLog("LuaAdController", logParams)
                else
                    local _aid, _uid = nil, nil
                    if isIOS() then
                        _aid = CCCommonUtilsForLua:call("getPropByIdGroup","data_config","google_ad_sdk2","k7")
                    else
                        _aid = CCCommonUtilsForLua:call("getPropByIdGroup","data_config","google_ad_sdk2","k8")
                    end
                    --默认播放普通英雄招募广告
                    _uid = self:initAdUnitId(AD_TYPE.HERO_DRAW_NORMAL)
                    AdVideoController:call("getInstance"):call("initAd", _aid, _uid)
                end
            end
            Dprint('LuaAdController:initAd = ', _analyticID, self.v_isInitAd)
            if not type then self:getData({AD_TYPE.MAIN_CITY_LD}) end
        end
        -- self:getAllADTypeData()
    end
end

function LuaAdController:initAdUnitId( type )
    local uids = nil
    if isIOS() then
        local id_List = CCCommonUtilsForLua:call("getPropByIdGroup","data_config","google_ad_sdk2","k3")
        self.unitIdList = string.split(id_List, "|")
    else
        local id_List = CCCommonUtilsForLua:call("getPropByIdGroup","data_config","google_ad_sdk2","k4")
        self.unitIdList = string.split(id_List, "|")
    end
    --dump(self.unitIdList,"LuaAdController:initAdUnitId")
    return self.unitIdList and self.unitIdList[type] or nil
end

function LuaAdController:adsFinishPreload(dict)
    if not self.isAdsFinishPreload then self.isAdsFinishPreload = {} end
    local unitId = dict:valueForKey("unitId"):getCString()
    local type = dict:valueForKey("type"):intValue()
    for k,v in ipairs(self.unitIdList) do
        if v == unitId then
            self.isAdsFinishPreload[k] = true
        end
    end
    local logParams = self:getLogExtParams(type, {tag='finishPreloadWithUnitId',adId=unitId})
    LogController:postEventLog("LuaAdController", logParams)
    CCSafeNotificationCenter:postNotification("LuaAdController:adsFinishPreload")
end

function LuaAdController:isAdLoaded(type)
    --dump(self.isAdsFinishPreload,"LuaAdController:isAdLoaded")
    return type and self.isAdsFinishPreload and self.isAdsFinishPreload[type] or false
end

-- 获取数据
function LuaAdController:getData( typeList )
    Dprint('LuaAdController:getData', self:isOpen())
    if self:isOpen() and typeList then
        local _types = ''
        for k,v in ipairs(typeList) do 
            _types = _types .. v
            if k < #typeList then
                _types = _types .. ';'
            end
        end
        self.v_showReward = 0

        AdDataCmd.req(_types)
    end
end

-- 设置数据
function LuaAdController:refreshData( data )
    if data then
        local _playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
        local _playerUid = _playerInfo:getProperty("uid")
        self.v_nextAd = cc.UserDefault:getInstance():getIntegerForKey(tostring(_playerUid).."AdVideo_nextAd", 0)
        self.v_data = self.v_data or {}
        self.v_data.videoCok = atoi(data.isNeedVideoCOK)
        for _,v in pairs(data.arr or {}) do
            self.v_data[tonumber(v.type)] = {
                cur = tonumber(v.hasWatchTimes) or 0,
                max = tonumber(v.maxTimes) or 0,
                open = tonumber(v.videoOpen) or 0,
                rewardId = v.rewardId or nil,       --奖励id
                rewardList = v.rewardList or nil,   --奖励id列表
                multiTimesAndNums = v.rewardTimes or nil,   --表示观看视频第几次翻倍翻倍多少 格式： 5;2|7;3|10;4 (分号前面表示第几次翻倍,后面是翻的倍数)
                showReward = v.showReward or '0',       --看完获取奖励是否展示
                previewReward = v.previewReward or '0',       --是否预览奖励
            }
        end

        -- dump(self.v_data, 'LuaAdController:refreshData')
        CCSafeNotificationCenter:postNotification("LuaAdController:refreshData")
    end
end

function LuaAdController:setData( data )
    -- dump(data, 'LuaAdController:setData')
    if data then
        if data.videoHasWatch then
            self.v_data[tonumber(data.type)].cur = tonumber(data.videoHasWatch) or 0
            self.v_showReward = 1

            local logParams = self:getLogExtParams(tonumber(data.type), {tag='reward'})
            LogController:postEventLog("LuaAdController", logParams)
        end
        if data.videoMaxTimes then
            self.v_data[tonumber(data.type)].max = tonumber(data.videoMaxTimes) or 0
        end
    end
end

-- 是否能播放视频
function LuaAdController:isCanPlay(type)
    local _isCan = false
    if self:isShowCokVideo() then
        _isCan = true 
    elseif CCCommonUtilsForLua:isFunOpenByKey("google_ad_separate") then
        if type and self:isAdLoaded(type) then
            _isCan = true    
            --_isCan = AdVideoController:call("getInstance"):call("isCanPlayGoogleAdsWithUnitId", self.unitIdList[type])        
        end
    else
        _isCan = AdVideoController:call("getInstance"):call("isCanPlay")
    end
    local logParams = self:getLogExtParams(type, {tag='isShow',isCan=_isCan})
    LogController:postEventLog("LuaAdController", logParams)
    return _isCan
end

function LuaAdController:getDataByTypes( type1, type2 )
    type1 = tonumber(type1) or 0
    type2 = tonumber(type2) or 0
    local _data1, _data2 = nil, nil
    if self:isOpen() and self.v_data then
        if self.v_data[type1] then
            _data1 = self.v_data[type1]
        end
        if self.v_data[type2] then
            _data2 = self.v_data[type2]
        end
    end
    return _data1, _data2
end

-- 获取当前奖励id
function LuaAdController:getCurRewardId(data)
    if data then
        local _rewardList = string.split(data.rewardList or data.rewardId, ";")
        local _cur = (tonumber(data.cur) or 0) + 1
        if _cur <= #_rewardList then
            return _rewardList[_cur]
        else
            return _rewardList[1]
        end
    end
end

-- 获取倍率数据
function LuaAdController:getMultiData(cur, multiTimesAndNums)
    local _curTime = (tonumber(cur) or 0) + 1
    if multiTimesAndNums then
        local _timesAndNums = string.split(multiTimesAndNums, "|")
        local _times = {}
        local _nums = {}
        for i,v in ipairs(_timesAndNums or {}) do
            local _tn = string.split(v, ";")
            _times[i] = _tn[1]
            _nums[i] = _tn[2]
        end

        local _curMulti, _nextMulti = nil
        for i,v in ipairs(_times or {}) do
            local _t = atoi(v)
            if _curTime == _t then   --当次多倍奖励
                _curMulti = i
                break
            elseif _curTime < _t then
                _nextMulti = i
                break
            end
        end

        if _curMulti and _curMulti <= #_nums then
            return _nums[_curMulti]
        elseif _nextMulti and _nextMulti <= #_nums then
            return nil, atoi(_times[_nextMulti]) - _curTime, _nums[_nextMulti]
        end
    end
end

-- 下次可播放视频的时间戳
function LuaAdController:getNextAdStamp()
    return self.v_nextAd or 0
end

-- 播放视频广告
function LuaAdController:playVideo( type )
    if self:isOpen() then
        local _isPlayCokVideo = false
        if self.v_data and self.v_data.videoCok > 0 or self:isShowCokVideo() then
            local _videoUrls = {}
            for _,v in pairs(CCCommonUtilsForLua:getGroupByKey("cok_video") or {}) do
                table.insert(_videoUrls, v.address)
            end
            if #_videoUrls > 0 then
                local _videoIndex = math.random(1, #_videoUrls)
                local _url = _videoUrls[_videoIndex]
                Dprint('LuaAdController:playVideo', _videoIndex, _url)
                if _url then
                    AdVideoController:call("getInstance"):call("playInsideRewardVideo", type, _url)
                    _isPlayCokVideo = true
                end
            end
        end

        if _isPlayCokVideo == false then
            if CCCommonUtilsForLua:isFunOpenByKey("google_ad_separate") then
                AdVideoController:call("getInstance"):call("playGoogleAdvertiseWithUnitId", type, self.unitIdList[type])
            else
                AdVideoController:call("getInstance"):call("playAd", type)
            end
        end

        SoundController:call("sharedSound"):call("stopAllMusic")

        self.v_showReward = 0
        -- 计算CD
        local _cd = tonumber(CCCommonUtilsForLua:call("getPropByIdGroup","data_config","google_ad_sdk2","k6")) or 60
        self.v_nextAd = _cd + getTimeStamp()
        local _playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
        local _playerUid = _playerInfo:getProperty("uid")
        cc.UserDefault:getInstance():setIntegerForKey(tostring(_playerUid).."AdVideo_nextAd", self.v_nextAd);
        Dprint("LuaAdController:playVideo next", self.v_nextAd)
        local logParams = self:getLogExtParams(type, {tag='play'})
        LogController:postEventLog("LuaAdController", logParams)
    end
end

-- 视频播放完成回调
function LuaAdController:callback( type )
    local scheduler = cc.Director:getInstance():getScheduler()
    if self.m_entryId then  
        scheduler:unscheduleScriptEntry(self.m_entryId)              
        self.m_entryId = nil
    end
    Dprint("LuaAdController:callback", type)
    local function callBack()
        if CALL_BACK[type] then
            CALL_BACK[type]()
        elseif self.typeViewMgr[tonumber(type)] then
            self.typeViewMgr[tonumber(type)]()
        end
        scheduler:unscheduleScriptEntry(self.m_entryId)
        self.m_entryId = nil
    end
    self.m_entryId = scheduler:scheduleScriptFunc(function() callBack() end, 0.5, false)
    local logParams = self:getLogExtParams(type, {tag='callback'})
    LogController:postEventLog("LuaAdController", logParams)
end
 
--获取当前所有类型的广告状态
function LuaAdController:getAllADTypeData()
    local params = {}
    for k,v in pairs(AD_TYPE) do
        table.insert(params,v)
    end
    self:getData(params)
end

-- --检查是否满足广告首弹前提(取消)
-- function LuaAdController:checkPopUpCondiction()     
--     for _,checkType in pairs(CheckQueueType) do
--         local qid = QueueController:call("getMinTimeQidByType", checkType)
--         local allQueuesInfo = GlobalData:call("shared"):getProperty("allQueuesInfo")
--         local qInfo = allQueuesInfo[qid]     
--         if qid ~= QID_MAX and qInfo ~= nil then

--             break
--         end 
--     end
-- end

--根据type检查是否满足广告展示状态
function LuaAdController:checkShowState(dict)
    local res = false
    local type = dict:valueForKey("type"):intValue()
    if not self:isCanPlay( type ) then return res end
    local data = self:getDataByTypes(type)
    if data.open == 1 and data.cur < data.max then
        dict:setObject(CCInteger:create(1),"state")
        dict:setObject(CCInteger:create(data.cur),"curTime")
        dict:setObject(CCInteger:create(data.max),"maxTime")        
        res = true
    end
    return res
end
--提供给c的播放视频调用
function LuaAdController:checkAndPlay(dict)
    local type = dict:valueForKey("type"):intValue()
    if self:checkShowState(type) then
        self:playVideo(type)
        local cdTime = self:getNextAdStamp()
        dict:setObject(CCString:create(tostring(cdTime)),"nextAdStamp")        
    end
end

--广告回调后开启背景声音
function LuaAdController:playBGMusicAfterCallback(_type)
    if ImperialScene:call("getInstance") ~= nil then
        MyPrint("play ImperialScene music")
        SoundController:call("sharedSound"):call("stopAllMusic")
        SoundController:call("sharedSound"):call("playBGMusic", "m_city_new")
    elseif WorldMapView:call("instance") ~= nil then
        MyPrint("play world music")
        SoundController:call("sharedSound"):call("stopAllMusic")
        SoundController:call("sharedSound"):call("playBGMusic", "m_field_new")
    end
    local logParams = self:getLogExtParams(_type, {tag='callbackResult0'})
    LogController:postEventLog("LuaAdController", logParams)
end

--初始化页面控制类
function LuaAdController:initTypViewMgr( type,callback )
    self.typeViewMgr = self.typeViewMgr or {}
    if type and callback then
        self.typeViewMgr[tonumber(type)] = callback
    end
end

function LuaAdController:isShowCokVideo()
    if isIOS() then
        return CCCommonUtilsForLua:isFunOpenByKey("cok_video_ios")
    else
        return CCCommonUtilsForLua:isFunOpenByKey("cok_video")
    end
end

function LuaAdController:getLogExtParams(type, params)
    local logType = type or AD_TYPE.MAIN_CITY_LD
    local extParams = {
        type = logType,
        adId = self:initAdUnitId(logType),
        uid = GlobalDataCtr.getUuid(),
        time = getWorldTime(),
        analyticID = GlobalDataCtr.getAnalyticID(),
        regCountry = GlobalDataCtr.getRegCountry(),
    }

    if not table.isNilOrEmpty(params) then
        table.merge(extParams, params)
    end

    return extParams
end

return LuaAdController
