----------------------------
-- 逐步替换C++的GlobalData控制类接口
-- 目前已有的是:
-- GlobalDataCtr.getAnalyticID()       取渠道名
-- GlobalDataCtr.getUuid()             取uuid
-- GlobalDataCtr.getRegCountry()       取注册地
-- GlobalDataCtr.getTimeZone()         取时区
-- GlobalDataCtr.getTimeStamp()        取系统时间
-- GlobalDataCtr.getWorldTime()        取带时区的时间
-- GlobalDataCtr.changeTime(time)      转换为时区时间
-- GlobalDataCtr.getTomorrowTime()     取明日0点时间
----------------------------

GlobalDataCtr = {}
GlobalDataCtr.tomorrow_time = 0
GlobalDataCtr.worldTime = 0
GlobalDataCtr.localTime = 0
GlobalDataCtr.timeZone = 0

-------------------- 数据初始化和更新部分 Start --------------------
function GlobalDataCtr.setTomorrowTime(time)
    GlobalDataCtr.tomorrow_time = time
    -- 因时间问题没有弹出时间限制，所以在此添加一个
    DataController.AntiAddictionController:checkState()
end

function GlobalDataCtr.updateWorldTime(dict)
    local tbl = dictToLuaTable(dict)
    GlobalDataCtr.worldTime = tbl.worldTime
    GlobalDataCtr.localTime = os.time()
end
function GlobalDataCtr.setWorldTime(dict)
    local tbl = dictToLuaTable(dict)
    GlobalDataCtr.worldTime = tbl.worldTime
    GlobalDataCtr.timeZone = tbl.timeZone
    GlobalDataCtr.localTime = os.time()
end

local funcitonMap = {
    ["updateWorldTime"] = GlobalDataCtr.updateWorldTime,
    ["setWorldTime"] = GlobalDataCtr.setWorldTime,
}
function GlobalDataCtr.updateFireEvent(key, dict)
    if funcitonMap[key] then
        funcitonMap[key](dict)
    end
end
-------------------- 数据初始化和更新部分 Ended --------------------

function GlobalDataCtr.getMonthCardInfoList()
    local t = GlobalData:call("shared")
    local list = t:toTable("monthCardInfoList")
    return list["monthCardInfoList"]
end

function GlobalDataCtr.getPlayerName()
    local playerInfo = GlobalData:comFunc("getPlayerInfo",0)
    local name =  playerInfo:getProperty("name")
    return name
end

function GlobalDataCtr.getPlayerGold()
    local num = 0
    local playerInfo = GlobalData:call("getPlayerInfo")
    if playerInfo ~= nil then
        num = playerInfo:getProperty("gold")
    end

    return num
end

function GlobalDataCtr.setPlayerGold(nowGold, isAbsolute)
    local playerInfo = GlobalData:call("getPlayerInfo")
    if isAbsolute == nil then
        isAbsolute = true
    end
    if playerInfo ~= nil then
        if not isAbsolute then
            nowGold = GlobalDataCtr.getPlayerGold()+ tonumber(nowGold)
        end

        playerInfo:setProperty("gold", nowGold)
        CCSafeNotificationCenter:postNotification("city_resources_update")
    end
end

function GlobalDataCtr.getAnalyticID()
    if GlobalDataCtr.analyticID == nil then
        local t = GlobalData:call("shared")
        GlobalDataCtr.analyticID = t:getProperty("analyticID")
    end
    return GlobalDataCtr.analyticID
end

function GlobalDataCtr.getUuid()
    return PlayerInfoController:getUid()
end

function GlobalDataCtr.getRegCountry()
    return PlayerInfoController:getRegCountry()
end

function GlobalDataCtr.getTimeZone()
    return GlobalDataCtr.timeZone
end

function GlobalDataCtr.getTimeStamp()
    return GlobalDataCtr.worldTime + (os.time() - GlobalDataCtr.localTime)
end

function GlobalDataCtr.getWorldTime()
    return GlobalDataCtr.worldTime + (os.time() - GlobalDataCtr.localTime) + GlobalDataCtr.timeZone * 3600
end

function GlobalDataCtr.changeTime(time)
    if time < 0 then
        return 0
    end
    return time + GlobalDataCtr.timeZone * 3600
end

function GlobalDataCtr.getTomorrowTime()
    local tomorrow_time = GlobalDataCtr.tomorrow_time
    local curTime = GlobalDataCtr.getTimeStamp()

    if tomorrow_time > 0 then
        if curTime > tomorrow_time then
            tomorrow_time = tomorrow_time + 86400
        end
    else
        tomorrow_time = curTime - (curTime % 86400) + 86400
    end

    return tomorrow_time
end


function GlobalDataCtr.getCurServerId()
    local id = tonumber(GlobalData:call("getPlayerInfo"):getProperty("currentServerId"))
    return id
end

-- 获取vip等级
function GlobalDataCtr.getPlayerVipLevel()
    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
    local SVIPLevel = playerInfo:getProperty("SVIPLevel")
    local vipPoints = playerInfo:getProperty("vipPoints")
    
    local vipLevel = VipUtil:call("getVipLevel", vipPoints) + SVIPLevel
    return vipLevel
end

-- 获取vip结束时间
function GlobalDataCtr.getPlayerVipEndTime()
    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
    local vipEndTime = playerInfo:getProperty("vipEndTime")

    return vipEndTime
end

-- 更新资源数据
-- "resource" = {
--     "chip"         = "10000"
--     "diamond"      = "62"
--     "diamondstone" = "0"
--     "dragonFood"   = "0"
--     "dragonGold"   = "0"
--     "food"         = "1134777"
--     "food_bind"    = "60"
--     "granite"      = "0"
--     "iron"         = "2934395"
--     "iron_bind"    = "169828"
--     "limestone"    = "0"
--     "marble"       = "0"
--     "sandstone"    = "0"
--     "silver"       = "589849"
--     "stone"        = "41457"
--     "stone_bind"   = "361242"
--     "wood"         = "46095031"
--     "wood_bind"    = "1159149"
-- }
local resKey = {
    ["food"] = "lFood",
    ["wood"] = "lWood",
    ["stone"] = "lStone",
    ["iron"] = "lIron",
}
function GlobalDataCtr.updateResourceInfo(resouorce)
    if not resouorce or table_is_empty(resouorce) then
        return
    end
    local resourceInfo = GlobalData:call("shared"):getProperty("resourceInfo")
    for key, value in pairs(resKey) do
        if resouorce[key] then
            resourceInfo:setProperty(value, tonumber(resouorce[key]))
        end

        if resouorce[key.."_bind"] then
            resourceInfo:setProperty(value.."_bind", tonumber(resouorce[key.."_bind"]))
        end
    end
    CCSafeNotificationCenter:call("postNotification", MSG_CITY_RESOURCES_UPDATE)
end

function GlobalDataCtr.getMainCityLevel()
    local mainCityLv = FunBuildController:call("getMainCityLv")
    if mainCityLv == 30 then
        mainCityLv = mainCityLv + FunBuildController:call("getMainCityHonorLv")
    end
    return mainCityLv
end

--@description:判断当前是否为怀旧服 
--@param : nil
--@return: bool
function GlobalDataCtr.checkIsGreenServer()
    if nil == GlobalDataCtr.isGreenServer then
        GlobalDataCtr.isGreenServer = GlobalDataCtr.getGreenServerCache()
    end
    return GlobalDataCtr.isGreenServer
end

function GlobalDataCtr.getGreenServerCache(  )
    return CCUserDefault:sharedUserDefault():getBoolForKey(SHARED_USERDEFAULT_IS_GREEN_SERVER, false)
end

--@description:维护怀旧服本地记录值 
--@param : bool
--@return: nil
function GlobalDataCtr.setGreenServerCache(isGreenServer)
    if nil == isGreenServer then
        isGreenServer = false
    end
    if GlobalDataCtr.getGreenServerCache() ~= isGreenServer then
        CCUserDefault:sharedUserDefault():setBoolForKey(SHARED_USERDEFAULT_IS_GREEN_SERVER, isGreenServer)
        CCUserDefault:sharedUserDefault():flush()
    end
    GlobalDataCtr.isGreenServer = isGreenServer
end

--@description: 玩家账号是否已绑定第三方平台
--@param : nil
--@return: bool
function GlobalDataCtr.isAccountBind()
    local res = false
	local FB_USERID = "facebookUserID"
	local FB_USERNAME =	"FaceBook_Name"
	local GP_USERID = "googlePlayID"
	local GP_USERNAME = "googlePlayName"

	local m_facebookUid = CCUserDefault:sharedUserDefault():getStringForKey(FB_USERID, "")
	local m_facebookName = CCUserDefault:sharedUserDefault():getStringForKey(FB_USERNAME,"")
	local m_googleplayId = CCUserDefault:sharedUserDefault():getStringForKey(GP_USERID,"")
	local m_googleplayName = CCUserDefault:sharedUserDefault():getStringForKey(GP_USERNAME,"")

	local isBind = false
	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	local platFormBindInfo = playerInfo:toTable("m_platFormBindInfo")
	platFormBindInfo = platFormBindInfo["m_platFormBindInfo"]

	local bindId = ""
	local bindPf = ""
	for k,v in pairs(platFormBindInfo or {}) do
		bindPf = v:getProperty("bindPf")
		bindId = v:getProperty("bindId")
		if bindId ~= "" and bindPf ~= "" then
			isBind = true
			break
		end
	end
	
	if m_facebookUid == "" and m_facebookName == "" and m_googleplayId == "" and m_googleplayName == "" and not isBind then
		res = false
	else
		res = true
	end
	return res
end

function GlobalDataCtr.purge(  )
    GlobalDataCtr.isGreenServer = nil
end