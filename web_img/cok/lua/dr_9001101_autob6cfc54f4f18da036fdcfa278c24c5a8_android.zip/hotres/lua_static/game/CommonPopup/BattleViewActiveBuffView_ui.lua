----------------------------
-- Author: Elex
-- Date: 2019-12-04 Wednesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local BattleViewActiveBuffView_ui = class("BattleViewActiveBuffView_ui")

--#ui propertys


--#function
function BattleViewActiveBuffView_ui:create(owner, viewType, paramTable)
	local ret = BattleViewActiveBuffView_ui.new()
	CustomUtility:LoadUi("MarchActiveBuffView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function BattleViewActiveBuffView_ui:initLang()
end

function BattleViewActiveBuffView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function BattleViewActiveBuffView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function BattleViewActiveBuffView_ui:onCloseButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onCloseButtonClick", pSender, event)
end

function BattleViewActiveBuffView_ui:initTableView()
	TableViewSmoker:createView(self, "m_tableView", "game.CommonPopup.BattleViewActiveBuffCell", 1, 7, "MarchActiveBuffCell")
end

function BattleViewActiveBuffView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return BattleViewActiveBuffView_ui

