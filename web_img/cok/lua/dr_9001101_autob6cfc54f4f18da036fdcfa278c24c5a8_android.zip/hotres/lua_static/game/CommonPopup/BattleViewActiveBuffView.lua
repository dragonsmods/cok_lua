--[[
    2019-11-13
    出征增益信息界面
    BattleViewActiveBuffView 
]]

Drequire("game.CommonPopup.NewActiveSkillHelper")

local BattleViewActiveBuffView = class("BattleViewActiveBuffView", PopupBaseView)

BattleViewActiveBuffView.__index = BattleViewActiveBuffView

function BattleViewActiveBuffView:ctor()
end
   
function BattleViewActiveBuffView:create(params)
    local view = BattleViewActiveBuffView.new()
    Drequire("game.CommonPopup.BattleViewActiveBuffView_ui"):create(view, 0)
    if view:initView(params) then
        return view 
    end
end

function BattleViewActiveBuffView:onEnter()
    UIComponent:call("showPopupView", 0)
    self.ui.m_titleLabel:setString(getLang("10200031")) -- 10200031=当前生效的增益/技能
    registerScriptObserver(self, self.updateTableView      , MessageType.MSG_BATTLE_ACTIVE_BUFF_TABLEVIEW)

    NewKingBiographySkillListCommand.new():send() -- 获取领主技能数据
end

function BattleViewActiveBuffView:initView()
    if CCCommonUtilsForLua:isIosAndroidPad() then
       self:setScale(2)
    end
    self:updateTableView()
    return true
end

function BattleViewActiveBuffView:updateTableView()
    local params = require("game.controller.BattleViewActiveBuffController").getInstance():getBuffInfo()
    local dataTable = {}
    local data_index = 1

    --[[
        "itemArray" = {
            1 = {
                "endTime" = "1574957068814"
                "itemId"  = "200414"
            }
        }
    ]]
    local itemArray = params["itemArray"] or {}
    if itemArray then
        for index, value in ipairs(itemArray) do
            local toolInfo = ToolController:call("getToolInfoByIdForLua", tonumber(value.itemId))
            if toolInfo then
                dataTable[data_index] = {index = data_index, type = "ToolInfo", info = toolInfo, data = value}
                data_index = data_index + 1
            end
        end
    end

    --[[
        "lordSkillArray" = {
            1 = {
                -- "onceUse" -- 没有endTime时，才会存在onceUse
                "endTime" = "1574917346058"
                "skillId" = "xxx"
            }
        }
    ]]
    local lordSkillArray = params["lordSkillArray"] or {}
    if lordSkillArray then
        for index, value in ipairs(lordSkillArray) do
            local generalInfo = GlobalData:call("getSelfGeneralInfo")
            if generalInfo then
                dataTable[data_index] = {index = data_index, type = "GeneralInfo", info = generalInfo, data = value}
                data_index = data_index + 1
            end
        end
    end

    --[[
        "skillArray" = {
            1 = {
                -- "onceUse" -- 没有endTime时，才会存在onceUse
                "endTime" = "1574917346058"
                "skillId" = "xxx"
            }
        }
    ]]
    local skillArray = params["skillArray"] or {}
    if skillArray then
        for index, value in ipairs(skillArray) do
            local skillInfo = HeroManager.getActiveSkillInfoById(value.skillId)
            if skillInfo ~= nil  then
                dataTable[data_index] = {index = data_index, type = "SkillInfo", info = skillInfo, data = value}
                data_index = data_index + 1
            end
        end
    end

    --[[
        "dragonArray" = {
            1 = {
                -- "onceUse" -- 没有endTime时，才会存在onceUse
                "endTime" = "1574917346058"
                "skillId" = "xxx"
            }
        }
    ]]
    local dragonArray = params["dragonArray"] or {}
    if dragonArray then
        for index, value in ipairs(dragonArray) do
            local dragonSkillInfo = DragonActiveSkillManager.getInstance():getDataById(value.skillId)
            if nil ~= dragonSkillInfo then
                dataTable[data_index] = {index = data_index, type = "DragonSkillInfo", info = dragonSkillInfo, data = value}
                data_index = data_index + 1
            end
        end
    end

    -- dump(dataTable, "setTableViewDataSource data")
    self.ui:setTableViewDataSource("m_tableView", dataTable)
end

--tableview
function BattleViewActiveBuffView:cellSizeForTable(tab, idx)
    return 540, 125
end

function BattleViewActiveBuffView:tableCellTouched(tab, cell)
    -- 触摸

end


function BattleViewActiveBuffView:onExit()
    unregisterScriptObserver(self, MessageType.MSG_BATTLE_ACTIVE_BUFF_TABLEVIEW)
end

function BattleViewActiveBuffView:onCleanup()

end


function BattleViewActiveBuffView:closeSelf()
	PopupViewController:call("removePopupView", self)
end

function BattleViewActiveBuffView:onCloseButtonClick()
    self:closeSelf()
end

return BattleViewActiveBuffView