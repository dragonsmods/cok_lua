
ShareLayer = class("ShareLayer", function()
        return cc.Layer:create() 
    end
)
ShareLayer.__index = ShareLayer

local IconWidth = 210
local IconHeight = 56
local imageScale = 0.25

function ShareLayer:create(params)
    local view = ShareLayer.new()
    if view:initView(params) == false then
        return nil
    end
    return view
end

function ShareLayer:initView(params)
    dump(params,"ShareLayer:initView+++")
    self.shareCtlInstance = require("game.controller.ShareController").getInstance()
    local function onNodeEvent(event)
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(onNodeEvent)

    function onTouch(eventType, x, y)  
        if eventType == "began" then  
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)  
        else  
            return self:onTouchEnded(x, y)  
        end
    end
    self:registerScriptTouchHandler(onTouch)
    self:setTouchEnabled(true)
    self:setSwallowsTouches(true)

	local size = cc.Director:getInstance():getIFWinSize()
	self:setContentSize(size)
    self:setAnchorPoint(cc.p(0, 0))
    self:setPosition(cc.p(0,0))
    self:setVisible(true)  

    self.imagePath = params.imgFilePath
    self.delImgAfterShare = (params.isFromAndroid == nil) and true or false

    if (not self.imagePath) or (self.imagePath == "") or (not cc.FileUtils:getInstance():isFileExist(self.imagePath)) then
        dump(self.imagePath, "error, share file1 not exist+++")
        return false 
    end
    self:onScreenshotIsTaken()
    return true 
end

function ShareLayer:onEnter()
        
end

function ShareLayer:onExit()

end

function ShareLayer:onTouchEnded(x,y)
end

function ShareLayer:onTouchBegan(x,y)
    self.isShareingImg = false
    local isNeedCheckTouch = self.m_shareNode and self.m_shareNode:isVisible()
    self:showShareNode(false)   
    if isNeedCheckTouch then  
        if ( touchInside(self.m_shareNode, x, y) )
            or ( self.picSprite and touchInside(self.picSprite, x, y) )
            or ( self.btnBg and touchInside(self.btnBg, x, y) )
            or ( self.btnLabel and touchInside(self.btnLabel, x, y) ) then
            self.isShareingImg = true
            self:gotoShareView()
            return true
        end
    end
    self:removeImageFile()
    return false
end

function ShareLayer:onTouchMoved(x,y)
end

function ShareLayer:gotoShareView()
    local tbl = {["shareType"]=3, ["shareLink"]=self.imagePath, ["delImgAfterShare"]=self.delImgAfterShare , ["addErWeiMa"]="1,2,3", ["addLogoPic"]="1,2,3,4,5", ["shareTag"]="ScreenShot"}
    local view = Drequire("game.CommonPopup.CommonShareView"):createEx(tbl)
    if view and view:hasAnyShareChannel() then
		PopupViewController:addPopupView(view)
	end
end

function ShareLayer:addPic()
    dump(self.imagePath,"ShareLayer:addPic+++")
    if not self.imagePath then 
        return
    end
    local sprite = cc.Scale9Sprite:create(self.imagePath)
    MyPrint("sprite, shareNode:", sprite, self.m_shareNode)
    MyPrint("file existed:", cc.FileUtils:getInstance():isFileExist(self.imagePath))
    if sprite and self.m_shareNode then
        local width =  sprite:getContentSize().width * imageScale + 10
        local height =  sprite:getContentSize().height * imageScale + 10
        local layer = cc.LayerColor:create(cc.c4b(255, 255, 255, 230), width, height)
        layer:setPosition(cc.p(-5, -5))
        self.m_shareNode:addChild(layer)
        sprite:setAnchorPoint(cc.p(0,0))
        sprite:setPosition(cc.p(0, 0))
        sprite:setScale(imageScale)
        self.picSprite = sprite
        self.m_shareNode:addChild(sprite)
    end
end

function ShareLayer:hideShareNode()
    if self.entryId then
        self:getScheduler():unscheduleScriptEntry(self.entryId)
        self.entryId = nil
    end
    if self.m_shareNode then 
        self.m_shareNode:setVisible(false)
    end
    self:removeImageFile()
end

function ShareLayer:startTimer()
    if self.entryId then
        self:getScheduler():unscheduleScriptEntry(self.entryId)
    end
    self.entryId = self:getScheduler():scheduleScriptFunc(function(dt)  self:hideShareNode(dt) end, 5, false)
end

function ShareLayer:onScreenshotIsTaken(ref)
    self:showShareNode(true)
    self:startTimer()
    local btnTxt = ""
    if self.shareCtlInstance:isCanGetReward() then 
        btnTxt = getLang("4100024") --4100024=分享&奖励
    else
        btnTxt = getLang("4100023") --4100023=分享
    end
    if self.btnLabel then
        self.btnLabel:setString(btnTxt)
    end
end

function ShareLayer:removeImageFile()
    if not self.isShareingImg and self.delImgAfterShare and self.imagePath and cc.FileUtils:getInstance():isFileExist(self.imagePath) then 
        MyPrint("remove ios share image file+++",self.imagePath)
        os.remove(self.imagePath)
    end
end   

function ShareLayer:showShareNode(bShow)
    if bShow then 
        self:createShareNode()
        self.m_shareNode:setVisible(true)
    else
        if self.m_shareNode then
            self.m_shareNode:setVisible(false)
        end
    end
end

--创建分享按钮
function ShareLayer:createShareNode()
    dump("ShareLayer:createShareNode+++")
    if self.m_shareNode then
        self.m_shareNode:removeFromParent()
        self.m_shareNode = nil
        self.picSprite = nil
        self.btnBg = nil 
        self.btnLabel = nil
    end
    
    self.m_shareNode = cc.Node:create()
    self.m_shareNode:setContentSize(cc.size(IconWidth, IconHeight))
    self:addChild(self.m_shareNode)
    self.m_shareNode:setAnchorPoint(cc.p(0, 0))

    self:addPic()
    local width = self.picSprite:getContentSize().width*imageScale
    local bg = CCLoadSprite:call("createScale9Sprite", "technology_11.png")
    if bg then
        bg:setAnchorPoint(cc.p(0.5, 0))
        bg:setPreferredSize(cc.size(width, IconHeight))
        bg:setPositionX(width*0.5)
        self.btnBg = bg 
        self.m_shareNode:addChild(bg)
    end
    local label = cc.Label:createWithSystemFont("", "Helvetica", 18, cc.size(0.0,0))
    if label then
        label:setAnchorPoint(cc.p(0.5, .5))
        label:setPositionX(width*0.5)
        label:setPositionY(IconHeight*0.5)
        -- label:setColor(cc.c3b(153, 102, 51))
        self.btnLabel = label
        self.m_shareNode:addChild(label)
    end

	local size = cc.Director:getInstance():getIFWinSize()
    self.m_shareNode:setPositionY(size.height*0.3)
    self.m_shareNode:setPositionX(10)  
end

return ShareLayer
