----------------------------
-- Author: Elex
-- Date: 2021-01-15 Friday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CargoRewardDialog_ui = class("CargoRewardDialog_ui")

--#ui propertys


--#function
function CargoRewardDialog_ui:create(owner, viewType, paramTable)
	local ret = CargoRewardDialog_ui.new()
	CustomUtility:DoRes(11, true)
	CustomUtility:LoadUi("CargoRewardDialog.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CargoRewardDialog_ui:initLang()
	LabelSmoker:setText(self.m_labelBtnAd, "167549")
	ButtonSmoker:setText(self.m_btnOk, "105036")
end

function CargoRewardDialog_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CargoRewardDialog_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CargoRewardDialog_ui:onClickBtnOk(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnOk", pSender, event)
end

function CargoRewardDialog_ui:onClickBtnAd(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnAd", pSender, event)
end

return CargoRewardDialog_ui

