
require("game.command.TriggerActivityCmd")
ActivityRwdShowCell = class("ActivityRwdShowCell", function()
    return cc.Node:create()
end)
ActivityView = class("ActivityView", function  (  )
    return PopupBaseView:call("create")
end)

function ActivityView:ctor( id )
    self.m_id = id
end

function ActivityView:create( id )
    local ret = ActivityView.new(id)
    if ret:initView() == false then
        ret = nil
    end
    return ret
end

function ActivityView:getObj(  )
    return ActivityController:call("getActObj", self.m_id)
end

function ActivityView:initView()

    if self:init(true, 0) == false then
        return false    
    end
    self:setHDPanelFlag(true)

    local obj = self:getObj()
    if nil == obj then
        return false
    end

    self.m_cutDownTipLabel = nullptr
    self.m_cutDownLabel = nullptr
    

    local objType = obj:getProperty("type")
    local objExchange = obj:getProperty("exchange")
    local objId = obj:getProperty("id")
    if (objType ~= 6 and objType ~= 28 and objType ~= 27 and objType ~= 30) then
        return false
    end

    CCLoadSprite:call("doResourceByCommonIndex", 500, true)
    CCLoadSprite:call("doResourceByCommonIndex", 505, true)
    CCLoadSprite:call("doResourceByCommonIndex", 502, true)
    CCLoadSprite:call("doResourceByCommonIndex", 506, true)

    local size = cc.Director:getInstance():getIFWinSize()
    self:setContentSize(cc.size(640, 852))

    local isPad = CCCommonUtilsForLua:call("isIosAndroidPad")
    MyPrint("isPad ;;;; ", isPad)

    if isPad then
        self:setContentSize(cc.size(1536, 2048))
    end

    local proxy = cc.CCBProxy:create()
    local ccbiUrl = "ActivityView"
    local node = CCBReaderLoad(ccbiUrl, proxy, self)
    if nil == node then
        return false
    end

    self:addChild(node)

    if isPad then
        self.m_bottomNode:setPositionY(self.m_bottomNode:getPositionY() - (size.height - 2048))
        self.m_listNode:setPositionY(self.m_listNode:getPositionY() - (size.height - 2048))
        self.m_listNode:setContentSize(cc.size(self.m_listNode:getContentSize().width, self.m_listNode:getContentSize().height + size.height - 2048))
    else
        self.m_bottomNode:setPositionY(self.m_bottomNode:getPositionY() - (size.height - 852))
        self.m_listNode:setPositionY(self.m_listNode:getPositionY() - (size.height - 852))
        self.m_listNode:setContentSize(cc.size(self.m_listNode:getContentSize().width, self.m_listNode:getContentSize().height + size.height - 852))
    end

    CCCommonUtilsForLua:call("setButtonTitle", self.m_rwdBtn, getLang("133076"))
    local bvisible = false
    if (objType == 6) then
        if (objExchange == "1" or objExchange== "2" or objExchange == "10") then
            bvisible = true
        elseif objExchange == "11" then
            if CCCommonUtilsForLua:call("getLanguage") == "zh_TW" then
                bvisible = true
                CCCommonUtilsForLua:call("setButtonTitle", self.m_rwdBtn, getLang("151234"))
            end
        elseif objExchange == "12" then
            bvisible = true
            CCCommonUtilsForLua:call("setButtonTitle", self.m_rwdBtn, getLang("150932"))
            self.m_rwdBtn:setEnabled(false)
            local cmd = CallFriendsCmd.new(50)
            cmd:send()
        end
    end

    if bvisible then
        self.m_bottomNode:setVisible(true)
    else 
        self.m_bottomNode:setVisible(false)
        if isPad then
            self.m_listNode:setPositionY(self.m_listNode:getPositionY() - 178)
            self.m_listNode:setContentSize(cc.size(self.m_listNode:getContentSize().width, self.m_listNode:getContentSize().height + 178))
        else
            self.m_listNode:setPositionY(self.m_listNode:getPositionY() - 92)
            self.m_listNode:setContentSize(cc.size(self.m_listNode:getContentSize().width, self.m_listNode:getContentSize().height + 92))
        end
    end

    MyPrint("self.m_progressN", self.m_progressN)
    self.m_progressN:setVisible(false)
    MyPrint("self.m_titleLabel", self.m_titleLabel)
    self.m_titleLabel:setString(getLang("150215"))
    
    
    -- // 正文
    self:initScrollView()
    self:onEnterFrame(0)
    
    local node2 = nil
    if (objType == 6 and obj:getProperty("md5") ~= "") then
        if LuaController:call("getInstance"):call("checkValidActivity", obj:getProperty("id"), obj:getProperty("md5")) then
            node2 = LuaController:call("getInstance"):call("createActivityAdCellByActMain", obj)
        end
    elseif objType == 28 or objType == 27 or objType == 30 then
        local picPath = obj:getProperty("Advertise_pic") .. ".png"
        local cf = cc.SpriteFrameCache:getInstance():getSpriteFrame(picPath)
        if cf ~= nil then
            node2 = cc.Node:create()
            local ts = CCLoadSprite:call("createSprite", obj:getProperty("Advertise_pic") .. ".png")
            ts:setAnchorPoint(cc.p(0, 0))
            node2:addChild(ts)
        end
    else
    end

    if node2 and node2:getChildrenCount() > 0 then
        self.m_picNode:addChild(node2)
    else
        local nameTTF = cc.Label:create()
        nameTTF:setString(obj:getProperty("name"))
        local infoTTF = cc.Label:create()
        infoTTF:setString(obj:getProperty("desc"))
        local bgImg = CCLoadSprite:call("createSprite", "activity_ad_beiyong.png")
        
        nameTTF:setPosition(cc.p(16,245))
        nameTTF:setAnchorPoint(cc.p(0, 1))
        nameTTF:setSystemFontSize(36)
        nameTTF:setColor(cc.c3b(255,219,117))
        nameTTF:setHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
        nameTTF:setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_TOP)
        nameTTF:setDimensions(0, 0)
        
        infoTTF:setPosition(cc.p(16,201))
        infoTTF:setAnchorPoint(cc.p(0, 1))
        infoTTF:setColor(cc.c3b(0, 249, 0))
        infoTTF:setHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
        infoTTF:setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_TOP)
        infoTTF:setDimensions(300, 0)
        
        
        bgImg:setAnchorPoint(cc.p(0, 0))
        bgImg:setPosition(cc.p(0, 0))
        node2 = cc.Node:create()
        node2:addChild(bgImg)
        node2:addChild(nameTTF)
        node2:addChild(infoTTF)
        self.m_picNode:addChild(node2)
    end
    
    if isPad then
        local w = (1536.0 - 1156.0) / 2.0
        local h = 645
        node2:setContentSize(cc.size(0, 0))
        node2:setScaleX(1156.0 / 640.0)
        node2:setScaleY(645.0 / 357.0)
        local layer1 = CCModelLayerColor:call("create")
        layer1 = tolua.cast(layer1, "cc.LayerColor")
        layer1:setAnchorPoint(cc.p(0, 0))
        layer1:setContentSize(cc.size(w, h))
        layer1:setPosition(cc.p(-w, 0))
        layer1:setOpacity(255)
        layer1:setColor(cc.BLACK)
        self.m_picNode:addChild(layer1)
        
        layer1 = CCModelLayerColor:call("create")
        layer1 = tolua.cast(layer1, "cc.LayerColor")
        layer1:setAnchorPoint(cc.p(0, 0))
        layer1:setPosition(cc.p(1156, 0))
        layer1:setContentSize(cc.size(w, h))
        layer1:setOpacity(255)
        layer1:setColor(cc.BLACK)
        self.m_picNode:addChild(layer1)
    end
    
    if (objType == 6) then
        if (objExchange == "2") then
            ActivityController:call("checkAndGetExc2Data", objId)
        elseif (objExchange == "1") then
            ActivityController:call("checkAndGetExc1Data", objId)
        else
        end
    end
	
	local function onEnterFrame(dt)
        MyPrint("onEnterFrame")
		self:onEnterFrame(dt)
	end

    local function onNodeEvent( event )
        if event == "enter" then
            local obj = self:getObj()
            if nil ~= obj then
                self:call("setTitleName", obj:getProperty("name"))
            end
            
            MyPrint("aaaaaa")
            self.entry = tonumber(self:getScheduler():scheduleScriptFunc(onEnterFrame, 1.0, false))
            --activityCB
            local function onActivityDataCB( ref )
                MyPrint("onActivityDataCB")
                if ref == nil then
                    return
                end
                dump(ref,"cjy onActivityDataCB")
                self:parseActivityInfo(ref)
            end
            local t = tolua.cast(self, "cc.Node")
            local handler = t:registerHandler(onActivityDataCB)
            CCSafeNotificationCenter:registerScriptObserver(self, handler, "activity_callback")
        elseif event == "exit" then
            self:getScheduler():unscheduleScriptEntry(self.entry)
            CCSafeNotificationCenter:unregisterScriptObserver(self, "activity_callback")
        end
    end
    self:registerScriptHandler(onNodeEvent)

    return true
end

function ActivityView:parseActivityInfo(ref )
    if not ref then
        MyPrint("ref is nil")
        return
    end
    local tbl = dictToLuaTable(ref)   
    dump(tbl,"ActivityView parseInfo tbl")
    if tbl.state then
        self.m_facebookState = tbl.state
        MyPrint("self.m_facebookState",self.m_facebookState)
    end
    if tbl.endTime then
        self.m_facebookEndTime = math.ceil(tonumber(tbl.endTime) / 1000)
        MyPrint("self.m_facebookEndTime",self.m_facebookEndTime)
    end
end

function ActivityView:scrollViewDidScroll(view)
    local mindy = view:minContainerOffset().y 
    local maxdy = view:maxContainerOffset().y 
    local dy = view:getContentOffset().y
    if (dy < mindy) then
        view:setContentOffset(cc.p(0, mindy))
    end
    if (dy > maxdy) then
        view:setContentOffset(cc.p(0, maxdy))
    end
end

function ActivityView:initScrollView()
    local node = cc.Node:create()
    local label = nil
    local spr = nil
    local height = 0
    local obj = self:getObj()
    if nil == obj then
        return
    end
    local objType = obj:getProperty("type")
    local showDialogs = obj:getProperty("showDialogs")
    local rewardIds = obj:getProperty("rewardIds")
    local isPad = CCCommonUtilsForLua:call("isIosAndroidPad")

    if objType == 6 or objType == 27 then
        if (#rewardIds> 0) then
            if (#showDialogs > 0) then
                height = height - 20
                if isPad then
                    height = height - 20
                end
            end
            
            for i,v in ipairs(showDialogs) do
                local tVec = string.split(v, ";")
                local showStr = ""
                if #tVec == 1 then
                    showStr = getLang(tVec[1])
                elseif #tVec == 2 then
                    showStr = getLang(tVec[1], CCCommonUtilsForLua:call("getNameById", tVec[2]))
                elseif #tVec == 3 then
                    showStr = getLang(tVec[1], CCCommonUtilsForLua:call("getNameById", tVec[2]), CCCommonUtilsForLua:call("getNameById", tVec[3]))
                elseif #tVec == 4 then
                    showStr = getLang(tVec[1], CCCommonUtilsForLua:call("getNameById", tVec[2]), CCCommonUtilsForLua:call("getNameById", tVec[3]), CCCommonUtilsForLua:call("getNameById", tVec[4]))
                else
                end

                label = cc.Label:create()
                label:setString(showStr)
                label:setSystemFontSize(20)
                if isPad then
                    label:setSystemFontSize(40)
                end
                label:setColor(cc.BLACK)
                label:setAnchorPoint(cc.p(0.5, 1))
                label:setDimensions(580, 0)
                if isPad then
                    label:setDimensions(1300, 0)
                end
                label:setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
                label:setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_TOP)
                label:setPosition(cc.p(0, height))
                node:addChild(label)
                height = height - label:getContentSize().height * label:getScaleY()
            end
            height = height - 5
            if isPad then
                height = height - 5
            end
            -- //有几率获得
            label = cc.Label:create()
            label:setString(getLang("150217"))
            label:setSystemFontSize(18)
            if isPad then
                label:setSystemFontSize(36)
            end
            label:setAnchorPoint(cc.p(0.5, 1))
            label:setPosition(cc.p(0, height))
            label:setColor(cc.c3b(139, 29, 20))
            label:setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
            label:setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_TOP)
            node:addChild(label)
            height = height - label:getContentSize().height * label:getScaleY()
            
            -- //展示奖励
            local cnt = #rewardIds
            local hang = math.ceil(cnt / 6.0)
            for i=1,hang do
                if i < hang then
                    for j=1,6 do
                        local cell = ActivityRwdShowCell:create(rewardIds[j - 1 + (i - 1) * 6 + 1])
                        cell:setPositionX(- 80 * 6 / 2 + 80 / 2 + (j - 1) * 80)
                        cell:setPositionY(height - 40)
                        if isPad then
                            cell:setPositionX(- 160 * 6 / 2 + 160 / 2 + (j - 1) * 160)
                            cell:setPositionY(height - 80)
                        end
                        node:addChild(cell)
                    end
                    height = height - 80
                    if isPad then
                        height = height - 80
                    end
                else
                    local leftCnt = cnt - (i - 1) * 6
                    for j=1,leftCnt do
                        local cell = ActivityRwdShowCell:create(rewardIds[(i - 1) * 6 + j - 1 + 1])
                        cell:setPositionX(- (80 * leftCnt) / 2 + 80 / 2 + (j - 1) * 80)
                        cell:setPositionY(height - 40)
                        if isPad then
                            cell:setPositionX(- 160 * leftCnt / 2 + 160 / 2 + (j - 1) * 160)
                            cell:setPositionY(height - 80)
                        end
                        node:addChild(cell)
                    end
                    height = height - 80
                    if isPad then
                        height = height - 80
                    end
                end
            end

            -- //空
            height = height - 10
            if isPad then
                height = height - 10
            end

            -- //横线
            spr = CCLoadSprite:call("createSprite", "Items_tips3_lottery.png")
            spr:setAnchorPoint(cc.p(0.5, 0.5))
            spr:setPosition(cc.p(0, height))
            node:addChild(spr)
            if isPad then
                spr:setScale(2)
            end

            -- //空
            height = height - 10
            if isPad then
                height = height - 10
            end

            -- //剧情简介
            label = cc.Label:create()
            label:setString(getLang("150216"))
            label:setAnchorPoint(cc.p(0.5, 1))
            label:setColor(cc.BLACK)
            label:setSystemFontSize(20)
            if isPad then
                label:setSystemFontSize(40)
            end
            label:setPosition(cc.p(0, height))
            label:setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
            label:setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_TOP)
            node:addChild(label)
            height = height - label:getContentSize().height * label:getScaleY()
            
            -- //空
            height = height - 10
            if isPad then
                height = height - 10
            end
        end

        -- //正文
        local mStory
        if obj:getProperty("id") == "57091" then
            local luckyDay = CLuckdayController:call("getInstance")
            local left_time = CCCommonUtilsForLua:call("getPropById", "99027", "k7")
            local curTime = luckyDay:getProperty("m_getEffectTimes") 
            local totalTimes = luckyDay:getProperty("m_totalTimes") 
            local curAction = ""
            if (luckyDay:getProperty("m_iLuckyId") > 0) then
                local action = tonumber(CCCommonUtilsForLua:call("getPropById", tostring(luckyDay:getProperty("m_iLuckyId")), "action"))
                if (action > 0) then
                    -- curAction = getLang(tostring(9400538 + action))
                    curAction = getLang(CCCommonUtilsForLua:call("getPropById", tostring(luckyDay:getProperty("m_iLuckyId")), "typename"))
                end
            end
            
            local effectLeftTime = tostring(totalTimes- curTime)
            mStory = _lang_4("9400543", tostring(totalTimes), left_time, curAction, effectLeftTime)
        else
            mStory = getLang(obj:getProperty("story"))
        end

        mStory = mStory .. "\n\n\n"
        label = cc.Label:create()
        label:setString(mStory)
        label:setSystemFontSize(20)
        if isPad then
            label:setSystemFontSize(40)
        end
        label:setDimensions(580, 0)
        if isPad then
            label:setDimensions(1300, 0)
        end
        label:setAnchorPoint(cc.p(0.5, 1))
        label:setColor(cc.c3b(85, 62, 31))
        label:setPosition(cc.p(0, height))
        label:setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
        label:setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_TOP)
        node:addChild(label)
        height = height - label:getContentSize().height * label:getScaleY()
    elseif objType == 28 then
        -- //倒计时tip
        -- // 153037
        label = cc.Label:create()
        label:setString("r")
        label:setAnchorPoint(cc.p(0.5, 1))
        label:setSystemFontSize(22)
        if isPad then
            label:setSystemFontSize(44)
        end
        label:setDimensions(580, 0)
        if isPad then
            label:setDimensions(1300, 0)
        end
        label:setColor(cc.c3b(85, 62, 31))
        label:setPosition(cc.p(0, height))
        label:setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
        label:setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_TOP)
        self.m_cutDownTipLabel = label
        node:addChild(label)
        height = height - label:getContentSize().height * label:getScaleY()
        
        -- // 倒计时的时间
        label = cc.Label:create()
        label:setString("00:00:00")
        label:setAnchorPoint(cc.p(0.5, 1))
        label:setSystemFontSize(22)
        if isPad then
            label:setSystemFontSize(44)
        end
        label:setDimensions(580, 0)
        if isPad then
            label:setDimensions(1300, 0)
        end
        label:setColor(cc.c3b(19, 127, 7)) -- 绿色字体
        label:setPosition(cc.p(0, height))
        label:setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
        label:setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_TOP)
        self.m_cutDownLabel = label
        node:addChild(label)
        height = height - label:getContentSize().height * label:getScaleY()
        
        -- //空
        height = height - 5
        if isPad then
            height = height - 5
        end
        
        -- //横线
        spr = CCLoadSprite:call("createSprite", "Quest_bg_1.png")
        spr:setAnchorPoint(cc.p(1, 0.5))
        spr:setPosition(cc.p(0, height))
        node:addChild(spr)
        if isPad then
            spr:setScale(2)
        end
        spr = CCLoadSprite:call("createSprite", "Quest_bg_1.png")
        spr:setAnchorPoint(cc.p(0, 0.5))
        spr:setFlippedX(true)
        spr:setPosition(cc.p(0, height))
        node:addChild(spr)
        if isPad then
            spr:setScale(2)
        end
        
        -- //空
        height = height - 10
        if isPad then
            height = height - 10
        end
        
        -- // 小正文
        -- // 153038 有三个参数 资源田最小等级 最大等级 刷新间隔
        local para1 = "1"
        local para2 = tostring(ActivityController:call("getHighestLv"))
        local para3 = tostring(ActivityController:call("getFreshInterval"))
        label = cc.Label:create()
        label:setString(getLang("153038", para1, para2, para3))
        label:setAnchorPoint(cc.p(0.5, 1))
        label:setSystemFontSize(20)
        if isPad then
            label:setSystemFontSize(40)
        end
        label:setDimensions(580, 0)
        if isPad then
            label:setDimensions(1300, 0)
        end
        label:setColor(cc.c3b(85, 62, 31))
        label:setPosition(cc.p(0, height))
        label:setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
        label:setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_TOP)
        node:addChild(label)
        height = height - label:getContentSize().height * label:getScaleY()

        
        -- //空
        height = height - 10
        if isPad then
            height = height - 10
        end
        
        local nowtime = LuaController:call("getWorldTime")
        -- // 只有活动进行中 才显示当前的剩余数量
        -- // 显示各等级的资源田剩余的数量
        -- // 153039=等级{0}特殊资源田还剩余{1}个。
        if (nowtime >= obj:getProperty("startTime")  and nowtime < obj:getProperty("endTime")) then
            local highestlv = ActivityController:call("getHighestLv")
            for i=1,highestlv do
                label = cc.Label:create()
                label:setString(getLang("153039", tostring(i), tostring(ActivityController:call("getLeftCntByResLv", i))))
                label:setAnchorPoint(cc.p(0.5, 1))
                label:setSystemFontSize(20)
                if isPad then
                    label:setSystemFontSize(40)
                end
                label:setDimensions(580, 0)
                if isPad then
                    label:setDimensions(1300, 0)
                end
                label:setColor(cc.c3b(85, 62, 31))
                label:setPosition(cc.p(0, height))
                label:setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
                label:setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_TOP)
                node:addChild(label)
                height = height - label:getContentSize().height * label:getScaleY()
            end
            
            -- //空
            height = height - 20
            if isPad then
                height = height - 20
            end
        end
    end
    local view = cc.ScrollView:create()
    view:setViewSize(self.m_listNode:getContentSize())
    if (math.abs(height) < self.m_listNode:getContentSize().height) then
        node:setPositionY(self.m_listNode:getContentSize().height / 2.0 + math.abs(height) / 2.0)
        height = -self.m_listNode:getContentSize().height
    else 
        node:setPositionY(math.abs(height))
    end
    view:setContentSize(cc.size(self.m_listNode:getContentSize().width, math.abs(height)))
    view:addChild(node)
    node:setPositionX(view:getContentSize().width / 2)
    view:setContentOffset(cc.p(0, self.m_listNode:getContentSize().height - view:getContentSize().height))
    view:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
    view:setDelegate()
    local function scrollViewDidScroll(  )
        self:scrollViewDidScroll(view)
    end
    view:registerScriptHandler(scrollViewDidScroll, cc.SCROLLVIEW_SCRIPT_SCROLL)
    self.m_listNode:addChild(view)
end

function ActivityView:onEnterFrame(dt)
    MyPrint("ActivityView:onEnterFrame")
    local obj = self:getObj()
    if nil == obj then
        return 
    end

    if obj:getProperty("exchange") == "12" and obj:getProperty("type") == 6 and self.m_facebookEndTime then
        local now = LuaController:call("getTimeStamp")
        local updateTimeFormate = self.m_facebookEndTime - now
        updateTimeFormate = math.max(updateTimeFormate,0)
        if updateTimeFormate > 0 then --未到时间
            self.m_rwdBtn:setEnabled(false)
            CCCommonUtilsForLua:call("setButtonTitle", self.m_rwdBtn, getLang("150932").."\n"..format_time(updateTimeFormate))
        else
            self.m_rwdBtn:setEnabled(true)
            CCCommonUtilsForLua:call("setButtonTitle", self.m_rwdBtn, getLang("150932"))
        end
    end
    if obj:getProperty("type") == 28 then
        if (self.m_cutDownTipLabel == nil or self.m_cutDownLabel == nil) then
            return
        end
        local nowTime = LuaController:call("getWorldTime")
        local maxRound = ActivityController:call("getMaxRound")
        local curRound = ActivityController:call("getCurRound")
        local curRdEndTime  = ActivityController:call("getCurRdEndTime")
        local actStartTime = obj:getProperty("startTime") 
        local actEndTime = obj:getProperty("endTime")
        local roundLastTime = ActivityController:call("getFreshInterval") * 60 * 60
        MyPrint("nowTime", nowTime)
        MyPrint("maxRound", maxRound)
        MyPrint("curRound", curRound)
        MyPrint("curRdEndTime", curRdEndTime)
        MyPrint("actStartTime", actStartTime)
        MyPrint("actEndTime", actEndTime)
        MyPrint("roundLastTime", roundLastTime)
        MyPrint("ActivityView:onEnterFrame1")
        if (nowTime < actStartTime) then
            -- // 活动还未开始
            -- // 150283    距离活动开始时间：{0}
            self.m_cutDownTipLabel:setString(getLang("150283", ""))
            self.m_cutDownLabel:setString(format_time(actStartTime - nowTime))
            return
        end
        MyPrint("ActivityView:onEnterFrame2")
        if (nowTime > actEndTime) then
            -- // 105800=活动准备中
            self.m_cutDownTipLabel:setString(getLang("105800"))
            self.m_cutDownLabel:setString("")
            return
        end
        MyPrint("ActivityView:onEnterFrame3")
        if (curRound == maxRound) then
            -- // 显示活动何时结束
            -- // 150284    距离活动结束时间：{0}
            self.m_cutDownTipLabel:setString(getLang("150284", ""))
            self.m_cutDownLabel:setString(format_time(actEndTime - nowTime))
            return
        end
        MyPrint("ActivityView:onEnterFrame4")
        if (nowTime <= curRdEndTime) then
            -- // 153037    距离下一次寸土必争活动的特殊资源田刷新还有
            self.m_cutDownTipLabel:setString(getLang("153037"))
            self.m_cutDownLabel:setString(format_time(curRdEndTime - nowTime))
            return
        end
        MyPrint("ActivityView:onEnterFrame5")
        if (nowTime > curRdEndTime) then
            if (roundLastTime == 0) then
                return
            end
            local passed = nowTime - curRdEndTime
            local passedRds = math.ceil(passed * 1.0 / roundLastTime)
            if (curRound + passedRds >= maxRound) then
                -- //此时显示距离活动结束的倒计时
                -- // 显示活动何时结束
                -- // 150284    距离活动结束时间：{0}
                self.m_cutDownTipLabel:setString(getLang("150284", ""))
                self.m_cutDownLabel:setString(format_time(actEndTime - nowTime))
            else 
                -- // 显示距离下轮活动的开启时间
                -- // 153037    距离下一次寸土必争活动的特殊资源田刷新还有
                self.m_cutDownTipLabel:setString(getLang("153037"))
                self.m_cutDownLabel:setString(format_time(passedRds * roundLastTime + curRdEndTime - nowTime))
            end
        end
        MyPrint("ActivityView:onEnterFrame6")
        return
    end
end

function ActivityView:onClickRwdBtn()
    local obj = self:getObj()
    if nil == obj then
        return
    end
    local objExchange = obj:getProperty("exchange")
    if (objExchange== "2") then
        local view = ActivityExcNewView:call("create", obj)
        PopupViewController:call("addPopupView", view)
    elseif (objExchange == "1") then
        local view = ActivityExcView:call("create", obj)
        PopupViewController:call("addPopupInView", view)
    elseif (objExchange == "10") then
        local view = ActivityVoteView:call("create")
        PopupViewController:call("addPopupInView", view)
    elseif (objExchange == "11") then

        -- E100091=领主大人，资源下载中，请稍后尝试操作。
        if DynamicResourceController2:call("checkDynamicResource", "activity_res") == false then
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("E100091"))
            return false
        end

        require "game.CommonPopup.WangLihongShareView"
		local view = WangLihongShareView:create()
        PopupViewController:call("addPopupView", view)
    elseif (objExchange == "12") then
        if CCCommonUtilsForLua:call("fbIsLogin") == false then
            MyPrint("not login !!!!!")
            CCCommonUtilsForLua:call("fbLogin")
            return
        end
        local link = ""
        if isAndroid() then
            link = "https://fb.me/789279541113368?from_feed=android_king"
        else
            link = "https://fb.me/789290781112244?from_feed=ios_king"
        end
        local str = getLang("151647")
        local pictureUrl = "http://cdn1.cok.eleximg.com/cok/mail/WEB/huigui.jpg"
        local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
        if playerInfo and playerInfo:call("getRegCountry") == "KR" then
            str = getLang("151648")
            pictureUrl = "http://cdn1.cok.eleximg.com/cok/mail/WEB/huigui_kr.jpg"
        elseif playerInfo and playerInfo:call("getRegCountry") == "MO" then
            str = getLang("151645")
        end
        CCCommonUtilsForLua:call("fbPublishFeedDialog", "Clash Of Kings", "Clash Of Kings", str, link, pictureUrl)
        TriggerEventUtils.triggerShare("recall")
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("105552"))

        local cmd = CallFriendsCmd.new(50)
        cmd:send()

        self.m_rwdBtn:setEnabled(false)
    end
end

function ActivityView:CMDCallbackForLua( ... )
    -- body
end


------------------

function ActivityRwdShowCell:create( itemId )
    local ret = ActivityRwdShowCell.new()
    if ret:initCell(itemId) == false then
        ret = nil
    end
    return ret
end


function ActivityRwdShowCell:initCell(itemId)
    local bg = CCLoadSprite:call("createSprite", "icon_kuang.png")
    CCCommonUtilsForLua:call("setSpriteMaxSize", bg, 75, false)
    self:addChild(bg)
    CCCommonUtilsForLua:call("createGoodsIcon", tonumber(itemId), self, cc.size(68, 68))
    if CCCommonUtilsForLua:call("isIosAndroidPad") == true then
        self:setScale(2.0)
    end
    return true
end
