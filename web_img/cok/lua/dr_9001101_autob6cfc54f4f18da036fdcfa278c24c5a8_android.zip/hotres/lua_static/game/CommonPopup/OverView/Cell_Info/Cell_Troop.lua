--行军队列
local Cell_Troop = class("Cell_Troop",Drequire("game.CommonPopup.OverView.Cell_Info.Cell_QueueFile"))

function Cell_Troop:create(Id)
    local ret = Cell_Troop.new(Id)
    if ret:initBaseById(Id) then
        return ret
    end
end

function Cell_Troop:getCureQueueInfo()
    if not self:checkIsVisible() then
        return
    end
    -- 行军总计
	local maxMarchNum = WorldController:call("getInstance"):call("getMaxMarchCount")
	--当前空闲行军
	local nowMarchNum = maxMarchNum - WorldController:call("getInstance"):call("getCurrentMarchCount")
    local curTime = WorldController:call("getInstance"):call("getTime")
    
    local tempTbl = {}
    for qid,info in pairs( self.allQueuesInfos or {} ) do
        if info:getProperty("finishTime") >= curTime + 1000 and info:call("isWorldMarch") then
            if not WorldController:call("getInstance"):call("MarchIsHeiqishi",info:getProperty('uuid')) then
                --插入出征信息
                tempTbl[#tempTbl + 1] = self:getSubTypeCellTbl(qid)	
            end
        end
    end
    --插入空闲行军
    for i=1,nowMarchNum do
        tempTbl[#tempTbl + 1] = self:getSubTypeCellTbl(QID_MAX)
    end

    self.CellTbl.cellMeta=tempTbl
    return self.CellTbl

end

function Cell_Troop:getSubTypeCellTbl(qid)
    local res = {}
	local _state = self.Queue_ST_Init
	local _finishTime = -1
	local _totalTime = -1
	local _label = ""
	local _type = -1
    local _id = ""
    local _name = ""
    local _icon = ""
    local _visible = ""
    local _startTime = -1
    local _marchIcon = ""

    local qInfo = self.allQueuesInfos[qid]
    if qInfo then
        local type = qInfo:getProperty("type")
        local marchIcon = CCCommonUtilsForLua:call("getQueueIconByType",type)
        _marchIcon = marchIcon
    end
    local disTime = getWorldTime() - getTimeStamp()
    if qid ~= QID_MAX then
        _state,_finishTime,_totalTime = self:getQueueState(qInfo)
        if _finishTime > 0 then
            _finishTime = _finishTime/1000            
            _startTime = qInfo:getProperty("startTime")/1000
            _totalTime = _finishTime - _startTime
            _finishTime = _finishTime + disTime            
        end
	else
		_state = self.Queue_ST_IDLE
		_finishTime = 0		
	end

	if _state == self.Queue_ST_IDLE then
        _label = "169606" --空闲中				
    elseif _state == self.Queue_ST_WORK then
        if _finishTime == -1 then
            _label = "169607" --169607=驻扎中
        else
            _label = "169608" --169608=出征中
        end
    elseif _state == self.Queue_ST_LOCK then
        _label = "2000442" --2000442=未解锁
    end
    _id = "30711009" --这几个行军队列都用这一个id

    if  _label ~= "" then
        _name,_icon,_visible = self:getNameIconVisibleBySubId(_id)        
		res = {id = _id, state = _state, param1 = _finishTime, param2 = _totalTime,label = _label,name = _name,icon = _icon,order = _order,marchIcon=_marchIcon,cell = self}
    end
    if _visible == "1" then
        return res
    end
end

function Cell_Troop:OnClickJump(_id,_state)
    if _id == "30711009" then
        self:jumpByTypeAndTarget(2)
    end
end

return Cell_Troop