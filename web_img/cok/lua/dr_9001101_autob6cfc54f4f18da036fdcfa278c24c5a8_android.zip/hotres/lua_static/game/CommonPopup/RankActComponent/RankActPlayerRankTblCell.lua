--玩家排行TableViewCell
 local RankActPlayerRankTblCell = class("RankActPlayerRankTblCell",
	function() 
		return cc.Layer:create()
	end
)

function RankActPlayerRankTblCell:create(idx)
	local view = RankActPlayerRankTblCell.new()
	Drequire("game.CommonPopup.RankActComponent.RankActPlayerRankTblCell_ui"):create(view, 0)
	return view
end

function RankActPlayerRankTblCell:refreshCell(info, idx)	
	self.m_info = info
	self.ui.m_rankNode:setVisible(false)
	self.ui.m_moreNode:setVisible(false)
	if self.m_info.dataType == 0 then
		self.ui.m_rankNode:setVisible(true)

		if not self.m_info.showSearch then
			self.ui.m_rankLabel:setPositionY(0)
			self.ui.m_searchBtn:setVisible(false)
		end

		self.ui.m_rankLabel:setString(info.rank)
		self.ui.m_numLabel:setString(CC_CMDITOAL(info.val))

		-- 玩家是否隐藏名字
		if info.hideKing == "1" then
			self.ui.m_pNameLabel:setString(getLang("140473")) -- 140473=领主ID已隐藏
		else
			local str = info.name
			if info.allianceShortName and info.allianceShortName ~= "" then
				str = "(" .. info.allianceShortName .. ") " .. str
			end
			self.ui.m_pNameLabel:setString(str)
		end

		local str = nil

		if info.hideKing == "1" then

		else
			str = getLang("138027") .. ": " -- 138027=王国
			if info.serverId and info.serverId ~= "" then
				str = str .. info.serverId
			end

			local allianceName = ""
			if info.allianceName and info.allianceName ~= "" then
				allianceName = info.allianceName
			elseif info.allianceShortName and info.allianceShortName ~= "" then
				allianceName = info.allianceShortName
			end
			if allianceName ~= "" then
				str = str .. "\n" .. getLang("102161") .. ": " .. allianceName -- 102161=联盟
			end
		end

		if str then
			self.ui.m_sNumLabel:setString(str)
		end

		self.ui.m_headNode:removeAllChildren()

		local pic = info.pic
		if not pic or pic == "0" then
			pic = "g044.png"
		else
			pic = pic .. ".png"
		end

		local head = CCLoadSprite:call("createSprite", pic)
		head:setScale(0.5)
		self.ui.m_headNode:addChild(head)
		local picVer = tonumber(info.picVer)
		local uid = info.uid
		local m_headImgNode = HFHeadImgNode:call("create")
		if CCCommonUtilsForLua:call("isUseCustomPic", picVer) then
			if (CCCommonUtilsForLua:isIosAndroidPad()) then
				m_headImgNode:call("initHeadImgUrl2", self.ui.m_headNode, CCCommonUtilsForLua:call("getCustomPicUrl", uid, picVer), 1.0, 68*2.4, true)
			else
				m_headImgNode:call("initHeadImgUrl2", self.ui.m_headNode, CCCommonUtilsForLua:call("getCustomPicUrl", uid, picVer), 1.0, 68, true)
			end
		end	
	else
		self.ui.m_moreNode:setVisible(true)
		if self.m_info.dataType == 1 then
			self.ui.m_moreTxt:setString(getLang("221126"))
		else -- if self.m_info.dataType == 2 then
			self.ui.m_moreTxt:setString(getLang("221127"))
		end
	end

end

function RankActPlayerRankTblCell:onClickSearchBtn(pSender, event)
	if self.m_info.showSearch and self.m_info.searchCallback then
		self.m_info.searchCallback(tonumber(self.m_info.rank) or 1)
	end
end

function RankActPlayerRankTblCell:onClickPicBtn(pSender, event)
	if self.m_info.uid then
		local dict = CCDictionary:create()
		dict:setObject(CCString:create("GeneralsPopupView"), "name")
		dict:setObject(CCString:create(self.m_info.uid), "uid")
		LuaController:call("openPopViewInLua", dict)
	end
end

function RankActPlayerRankTblCell:onRewardButtonClick(pSender, event)
	if self.m_info.callback and self.m_info.rank then
		self.m_info.callback(tonumber(self.m_info.rank) or 1)
	end
end

function RankActPlayerRankTblCell:onMoreButtonClick(pSender, event)
	if self.m_info.getMoreRank then
		self.m_info.getMoreRank()
	end
end

return RankActPlayerRankTblCell