local ChangeServerConditions = class("ChangeServerConditions",
	function()
        return PopupBaseView:create()
    end
    )

ChangeServerConditions.__index = ChangeServerConditions

local ChangeServerController = require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance()

--创建一个条件判断"switch-case"
--开关server_transfer_testmode 用于测试服测试，无视任何条件
local switch = {
    [1] = function (param)--未处于跨服状态  1
        local res = false
        local crossServerId = GlobalData:call("getPlayerInfo"):getProperty("crossFightSrcServerId")
        if crossServerId >= 0 then res = true end
        --crossFightSrcServerId;表示玩家是从哪个服跨服过来的。 -1 表示没有跨服， >=0表示现在处于跨服状态
        return res
    end,
    [2] = function (param)--未处于迁移冷却状态状态  2
        local res = ChangeServerConditions.cdCondition
        return res
    end,
    [3] = function (param)--无出征队列处于城外  3
        local res = false
        local cnt = WorldController:call("getCurrentMarchCount")--当前出征队列数量
        if cnt > 0 then res = true end
        return res
    end,
    --8,9数据也走服务器
    -- [8] = function (param)--远古战场未处于开启状态  8
    --     local res = ActivityController.getInstance():isActivityOpen("57007")
    --     return res
    -- end,
    -- [9] = function (param)--边境矿脉未处于采集/争夺状态  9
    --     local res = ActivityController.getInstance():isActivityOpen("57131")
    --     return res
    -- end,
    [10] = function (param)--霸主争夺战未处于开启状态  10
        local res = false
        local startTime = ActivityController:call("getInstance"):getProperty("despotBattleOpt")
        local curTime = getTimeStamp()
        local endTime = ActivityController:call("getInstance"):getProperty("despotBattleEt")
        if curTime > startTime and curTime < endTime then
            res = true
        end
        return res
    end,
    [11] = function (param)--未处于联盟中  11       
        local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
        local res = playerInfo:call("isInAlliance")
        return res
    end,
    [12] = function (param)--非王国国王  12
        local res = false
        local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
        local officer = 1
        if playerInfo and playerInfo:getProperty("officer") ~= "" then
            officer = tonumber(playerInfo:getProperty("officer")) --KINGDOM_KING_ID:216000
            if officer == 216000 then
                res = true
            end
        end
        return res
    end,
    [13] = function (param)--没有未治疗的伤兵  13
        local res = false
        local totalDead = ArmyController:call("getTotalDead")
        local queueNum = QueueController:call("getQueueNumByType", QueueType.TYPE_HOSPITAL)
        if totalDead > 0 or queueNum > 0 then
            res = true
        end
        return res
    end,
    [15] = function (param)--文明堡垒未收起  15
        local res = false
        local state = CivFortressController:getCivFortressStatus() --0:未放置
        if state ~= 0 then
            res = true
        end
        return res
    end,
    [16] = function (param) --没有未领取奖励的邮件  16
        local res = false
        local mailState = MailController:call("checkHaveAnyReward") --true:表示通过    
        -- dump(mailState,"hxq checkHaveAnyReward res is")
        if not mailState then
            res = true
        end
        return res
    end,
    [17] = function (param)--英雄没有被抓捕  17
        local res = false
        local HeroCapturedNum = HeroManager.HeroCapturedNum
        -- dump(HeroCapturedNum,"hxq HeroCapturedNum is")
        if HeroCapturedNum > 0 then res = true end
        return res
    end,
    [18] = function (param)--未抓捕其他领主英雄  18
        local res = false
        local prisonInfo = HeroManager.getPrisonerInfo()
        -- dump(prisonInfo, "HeroListView:checkCanOpen")
        if not table_is_empty(prisonInfo) then
            res = true
        end
        return res
    end,
}
---------------------ChangeServerConditions start------------------------ 
function ChangeServerConditions:create( param)
	local view  = ChangeServerConditions.new()
	Drequire("game.CommonPopup.ChangeServer.ChangeServerConditions_ui"):create(view, 0)
    if view:initView(param) then
        return view
    else
    	return nil
    end

end

function ChangeServerConditions:initView(param)
    local touchLayer = cc.Layer:create()
    self:addChild(touchLayer)

        local function touchHandle( eventType, x, y )
        MyPrint("touchHandle", eventType, x, y)
        if eventType == "began" then
            return self:onTouchBegan(x, y)
        elseif eventType == "moved" then
            
        else
            self:onTouchEnded(x, y)
        end
    end
    touchLayer:registerScriptTouchHandler(touchHandle)
    touchLayer:setTouchEnabled(true)
    touchLayer:setSwallowsTouches(false)

    self.ui.m_conditionTitle:setString(getLang("153594"))
    self.ui.m_ListTitle:setString(getLang("153595"))
    self.ui.needLabel:setString(getLang("153596"))
    self.ui.m_btnGetMoreLabel:setString(getLang("153597"))--获取更多
    self.ui.btn_label:setString(getLang("153598"))
    self.ui.btn_clearLabel:setString(getLang("301177"))--清理邮件
    self.isConditionsPass = true
    local itemDataId = 211094
    self.ui.m_iconNode:removeAllChildren(true)
    CCCommonUtilsForLua:createGoodsIcon(itemDataId, self.ui.m_iconNode, CCSize(50, 50))

    self.targetServerName = param.targetServerName
    self.tool_cost = param.cost
    self.serverId = param.serverId

    local itemInfo = ToolController:call("getToolInfoByIdForLua", itemDataId)
    self.ItemName = itemInfo:call("getName")
    self.ui.toolName:setString(self.ItemName)
    self.curItemNum = itemInfo:comFunc("getCNT", 0):getValue()
    self.m_itemUuid = itemInfo:comFunc("getUuid", 0):getCString()

    --联盟招贤榜已经提前扣除道具
    if self.tool_cost then
        self.ui.tool_num:setString(self.curItemNum.."/"..self.tool_cost)--self.data.cost

        if self.curItemNum < self.tool_cost then
            self.isConditionsPass = false
            self.ui.tool_num:setColor(cc.c3b(255, 20, 20))
        else
            self.ui.tool_num:setColor(cc.c3b(255, 241, 36))
        end
    else
        self.ui.m_itemNode:setVisible(false)
    end

    self.cdCondition = param.cdCondition

    self.tableData = {}
    self.ui.btn_2:setEnabled(false)

    --条件确认
    if param.confirm then
        self.ui.btn_2:setVisible(false)
        self.ui.btn_label:setVisible(false)
        self.ui.btn_clearLabel:setPositionY(60)
        self.ui.btn_clearMail:setPositionY(60)
    end

	return true
end

function ChangeServerConditions:initData()
    self.tableData = {}
    local tableTempData = {}
    local XMLData = CCCommonUtilsForLua:getGroupByKey("transfer_conditions")
    -- dump(XMLData,"hxq XMLData is")

    for k,v in pairs(XMLData or {}) do
        tableTempData[#tableTempData+1] = v
    end


    local function SortByOrder(a,b)
        local a_order = tonumber(a.order)
        local b_order = tonumber(b.order)
        return a_order < b_order
    end

    for k,v in pairs(tableTempData) do
        local typeValue = tonumber(v.type)
        if nil == v.param then           
            v.state = not self:checkCondition(typeValue)

        else
            local tempParam = string.split(v.param, "|")
            v.state = not self:checkCondition(typeValue,tempParam)
        end
        if v.state == false then
            self.isConditionsPass = false
        end
        self.tableData[#self.tableData+1] = v
    end
    table.sort(self.tableData, SortByOrder )
    -- dump(self.tableData,"hxq self.tableData is")
end


--[[
服务器读取的条件满足：
最强王国活动未处于进行状态  4
巨龙战役：常规赛未处于比赛阶段  5
巨龙战役：季后赛未处于比赛阶段  6
CoK世界杯未处于比赛阶段  7
远古战场未处于开启状态  8
边境矿脉未处于采集/争夺状态  9
开服时间过短  14
未参与拍卖行竞拍  19
背包内无高价值物品 20 皮肤附魔大于70级此条件限制不生效
未处于秘境宝藏活动中  21
未处于超值夺宝活动中  22
阵法拍卖行 23
--]]
function ChangeServerConditions:checkCondition(type,param) --param:特殊道具ids
    local res = false --默认通过
    local condition = switch[type]
    if nil ~= condition then
        res = condition(param)
    else--数据从服务器获取
        -- dump(type,"hxq get data erroe")
        self.isConditionsPass = false
    end

    return res
end

function ChangeServerConditions:onTouchBegan(x, y)
    if touchInside(self.ui.m_touchLayer, x, y) == true then
        self.touch = true
    else
        self.touch = false
    end 
    return true
end

function ChangeServerConditions:onTouchMoved(x, y)
    -- body
end

function ChangeServerConditions:onTouchEnded(x, y)
    if touchInside(self.ui.m_touchLayer, x, y) == false and not self.touch then
        self:closeView()
    end     
end

function ChangeServerConditions:refreshView(data)
    if nil == data then
        return
    end
    local ServerData = data.conditionList
    for k,v in pairs(ServerData or {}) do
        local typeValue = tonumber(v.type)
        local state = tonumber(v.state) --1:满足条件
        switch[typeValue] = function (param)
            local res = false
            if state == 0 then
                res = true
            end
            return res
        end
    end

    self:initData()
    if self.tool_cost then
        self.ui:setTableViewDataSource("m_tableView",self.tableData)
    else
        self.ui:setTableViewDataSource("m_tableViewNoItem",self.tableData)
    end
    self.ui.btn_2:setEnabled(self.isConditionsPass)
    if CCCommonUtilsForLua:isFunOpenByKey('server_transfer_testmode') then
        self.ui.btn_2:setEnabled(true)
    end
end



function ChangeServerConditions:onEnter()
    local function callBack(data)
        self:refreshView(data)
    end
    ChangeServerController:getServerConditionState(self.serverId, callBack)
end

function ChangeServerConditions:onExit()
    
end

function ChangeServerConditions:onClickGet()
    local itemDataId = 211094
    local ItemGetMethodView = Drequire("game.CommonPopup.ItemGetMethodView")
    local view = ItemGetMethodView:create(itemDataId)
    PopupViewController:addPopupView(view)
end

function ChangeServerConditions:onClickBack()
    self:closeView()
end

function ChangeServerConditions:onClickClearMail( )
    local function getServerResponse(data)
        local res = tonumber(data.result) or 0
        if res == 1 then
            CCCommonUtilsForLua:call("flyHint","","",getLang("301181"))
        else
            CCCommonUtilsForLua:call("flyHint","","",getLang("301182"))
        end
        self.ui.btn_clearMail:setEnabled(true)
    end
    local function confirmClearMails( )     
        self.ui.btn_clearMail:setEnabled(false)
        ChangeServerController:clearMails(getServerResponse)
    end
    local function confirmFirstTime ()
        local dia =YesNoDialog:show(getLang("301179"), confirmClearMails)
        dia:call("showCancelButton")
    end
    YesNoDialog:show(getLang("301178"), confirmFirstTime)
end

function ChangeServerConditions:onClickSure()
    if self.tool_cost and self.curItemNum < self.tool_cost then
        self:onClickGet()
        return
    end
    --hxq 再次确认
    local function confirmFunc()
        local function changeServer() self:startChangeServer() end
        local function faqTip() FaqHelper:call("showSingleFAQ", "45281") end
        local noTxt = getLang("153571")

        local view = WarningView:call("create", getLang("105261"), getLang("153570"), cc.CallFunc:create(changeServer), "", cc.CallFunc:create(faqTip), getLang("153571"))
        view:call("exchangeBtnPos")
        PopupViewController:addPopupView(view)
    end
    
    if self.tool_cost then
        YesNoDialog:show(getLang("153569", tostring(self.tool_cost), self.ItemName, self.targetServerName), confirmFunc)
    else
        confirmFunc()
    end
end

function ChangeServerConditions:startChangeServer()
    -- 开始转服
    local function callBack (data)
        dump(data, " onConfirmClick2 ~~~~~******************")
        --self.m_confirmBtn2:setEnabled(true)
        if nil ~= data.errorCode and data.errorCode ~= "" then
            -- dump(self.name.. " create errorCode...")
            local param = ""
            if data.errorCode == "E100316" then
                param = getLang(CCCommonUtilsForLua:call("getPropByIdGroup", "goods", data.itemId, "name"))
            elseif data.errorCode == "153581" then
                param = CC_CMDITOA(data.mailNum)
            end
            LuaController:flyHint("", "", getLang(data.errorCode, param))
            PopupViewController:call("removeLastPopupView")
            return
        end

        local serverInfo = data.serverInfo
        local ip = serverInfo.ip
        local zone = serverInfo.zone
        local port = serverInfo.port
        local gameUid = serverInfo.uid
        
        local infoDict = CCDictionary:create()
        infoDict:setObject(CCString:create(ip), tostring("ip"))
        infoDict:setObject(CCString:create(zone), tostring("zone"))
        infoDict:setObject(CCInteger:create(port), tostring("port"))

        local dict = CCDictionary:create()
        dict:setObject(infoDict, tostring("serverInfo"))
        dict:setObject(CCBool:create(false), tostring("showBG"))
        ActivityController:call("changeServerByInfo", dict)
        --PopupViewController:comFunc("removeAllPopupView",0)
    end
    ChangeServerController:transfer(tonumber(self.serverId), self.m_itemUuid, callBack)

    -- 173362=尊敬的领主，跳转服务器需要一段时间，期间不要退出游戏，请耐心等待！
    local dialog = YesNoDialog:show(getLang("173362"))
    dialog:call("setEnforceShow", true)

    self.ui.btn_2:setEnabled(false)
    self:closeView()
end

function ChangeServerConditions:closeView()
    self:call("closeSelf")
end


return ChangeServerConditions