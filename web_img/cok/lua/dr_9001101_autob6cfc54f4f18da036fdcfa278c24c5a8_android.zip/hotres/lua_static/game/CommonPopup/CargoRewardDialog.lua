--[[ 
    码头宝箱
 ]]
local CargoRewardDialog = class("CargoRewardDialog", function() return PopupBaseView:create() end )
CargoRewardDialog.__index = CargoRewardDialog
local LuaAdController = require("game.controller.LuaAdController").getInstance()

function CargoRewardDialog:create()
    CCLoadSprite:call("loadDynamicResourceByName", "Cargo_face")
    local view = CargoRewardDialog.new()
    Drequire("game.CommonPopup.CargoRewardDialog_ui"):create(view)
    if view:initView() then
        return view
    end
end

function CargoRewardDialog:initView()
    if GuideController:call("isInTutorial") then
        return false
    end
    CCLoadSprite:call("doResourceByCommonIndex", 11, true)
    CCLoadSprite:call("loadDynamicResourceByName", "goods")
    registerTouchHandler(self)
    
    local rewardInfo = PortActController:call("getInstance"):getProperty("m_rewardInfo")
    if string.isNilOrEmpty(rewardInfo) then
        return false
    end

    local rewardList = string.splitNSep(rewardInfo, "|")
    if table.isNilOrEmpty(rewardList) then
        return false
    end

    local rewardData = string.splitNSep(rewardList[1], ",")
    if #rewardData < 3 then
        return false
    end
    if rewardData[1] ~= "goods" then
        return false
    end

    local toolId = rewardData[2]
    local tInfo = ToolController:call("getToolInfoByIdForLua", atoi(toolId))
    if tInfo == nil then
        return false
    end
    local color = atoi(CCCommonUtilsForLua:call("getPropByIdGroup","goods",toolId, "color"))
    local bgName = CCCommonUtilsForLua:call("getToolBgByColor", color)
    local bgSpr = CCLoadSprite:createSprite(bgName)
    CCCommonUtilsForLua:call('setSpriteMaxSize', bgSpr, 75, true)
    self.ui.m_nodeItem:addChild(bgSpr)

    local itemName = CCCommonUtilsForLua:call("getIcon", toolId)
    local itemSpr = CCLoadSprite:createSprite(itemName)
    CCCommonUtilsForLua:call('setSpriteMaxSize', itemSpr, 75, true)
    self.ui.m_nodeItem:addChild(itemSpr)

    local tName = CCCommonUtilsForLua:call("getNameById", toolId)
    self.ui.m_labelName:setString(string.format("%s x%s", tName, rewardData[3]))

    local des = tInfo:getProperty("des")
    self.ui.m_labelDes:setString(getLang(des))

    self.adType = AD_TYPE.CARGO_BOX
    LuaAdController:getData({self.adType})

    self:updateView()
    return true
end

function CargoRewardDialog:updateView()
    self.ui.m_btnOk:setPositionX(0)
    self.ui.m_nodeAd:setVisible(false)
    local targetTime = PortActController:call("getInstance"):getProperty("m_nextRewardTime")
    local now = getTimeStamp()
    if targetTime > now then
        self.ui.m_btnOk:setEnabled(false)
        CCCommonUtilsForLua:call("setButtonTitle", self.ui.m_btnOk, CC_SECTOA(targetTime - now))
    else
        self.ui.m_btnOk:setEnabled(true)
        CCCommonUtilsForLua:call("setButtonTitle", self.ui.m_btnOk, getLang("105036"))    --105036=领取奖励
    end
    
    local _adData, _ = LuaAdController:getDataByTypes(self.adType)
    if _adData and _adData.open > 0 and _adData.cur < _adData.max then
        if _adData.flag or LuaAdController:isCanPlay(self.adType) then
            _adData.flag = true
            local _offset = LuaAdController:getNextAdStamp() - now
            if _offset > 0 then
                self.ui.m_labelAdProcess:setString(format_time(_offset))
                self.ui.m_btnAd:setEnabled(false)
                self.ui.m_adShadow:setVisible(true)
            else
                self.ui.m_labelAdProcess:setString(getLang("682815", _adData.max - _adData.cur, _adData.max))   --682815=今日：{0}/{1}
                local isEnabled = self.ui.m_btnOk:isEnabled()
                self.ui.m_btnAd:setEnabled(isEnabled)
                self.ui.m_adShadow:setVisible(not isEnabled)
            end
            
            self.ui.m_btnOk:setPositionX(-1 * self.ui.m_nodeAd:getPositionX())
            local _curMulti, _, _ = LuaAdController:getMultiData(_adData.cur, _adData.multiTimesAndNums)
            self.ui.m_labelAdRate:setString(string.format("x%s", _curMulti))
            self.ui.m_nodeAd:setVisible(true)
        end
    end
end

function CargoRewardDialog:onEnter()
    self:closeSchedule()
    self.schedule = self:getScheduler():scheduleScriptFunc(function(dt) self:updateView() end, 1, false)
    registerScriptObserver(self, self.closeDialog, "msg.new.time.rwd.end")
    registerScriptObserver(self, self.updateView, "LuaAdController:refreshData")
end

function CargoRewardDialog:onExit()
    self:closeSchedule()
    self:closeWaitInterface()
    unregisterScriptObserver(self, "msg.new.time.rwd.end")
    unregisterScriptObserver(self, "LuaAdController:refreshData")
end

function CargoRewardDialog:closeSchedule()
    if self.schedule then
        self:getScheduler():unscheduleScriptEntry(self.schedule)
    end
end

function CargoRewardDialog:closeWaitInterface()
    if self.waitInterface then
        self.waitInterface:call("remove")
        self.waitInterface = nil
    end
end

function CargoRewardDialog:closeDialog()
    self:call("closeSelf")
end

function CargoRewardDialog:onClickBtnOk()
    self:closeWaitInterface()

    self.waitInterface = GameController:call("showWaitInterface1", self.ui.m_btnOk)
    AllianceManager:call("getInstance"):call("showRecAlliance")
    PortActController:call("getInstance"):call("startTimeRwd")
end

function CargoRewardDialog:onClickBtnAd()
    self:closeDialog()
    AllianceManager:call("getInstance"):call("showRecAlliance")
    LuaAdController:playVideo(self.adType)
end

function CargoRewardDialog:onTouchBegan(x, y)
    if touchInside(self.ui.m_bg, x, y) == false then
        self.touchX = x
        self.touchY = y
        return true
    end
    return false
end

function CargoRewardDialog:onTouchMoved(x, y)
end

function CargoRewardDialog:onTouchEnded(x, y)
    if touchInside(self.ui.m_bg, x, y) == false and touchInside(self.ui.m_bg, self.touchX, self.touchY) == false then 
        self:closeDialog()
    end
end

return CargoRewardDialog