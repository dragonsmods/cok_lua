local ApplySelectView = class("ApplySelectView", PopupBaseView)

function ApplySelectView:create(data1, data2, default1)
    local view = ApplySelectView.new(data1, data2, default1)
    Drequire("game.CommonPopup.ChangeServer.ApplySelectView_ui"):create(view, 0)
    view:initView()
    return view
end

function ApplySelectView:ctor(data1, data2, default1)
    self.sourceData = {}
    self.sourceData1 = data1
    self.sourceData2 = data2
    self.title1Show = true
    self.title2Show = false

    if default1 then
        self.text1 = getLang(default1)
        self.id1 = default1
    end
end

function ApplySelectView:initView()
    self:setHDPanelFlag(true)

    if CCCommonUtilsForLua:isIosAndroidPad() then
        self.ui.nodeccb:setScale(2.0)
    end

    registerTouchHandler(self)
    self:setTouchEnabled(true)

    self.ui.m_titleLabel:setString(getLang("173246"))
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_confirmBtn, getLang("confirm"))

    local size = self.ui.m_listNode:getContentSize()

    if self.sourceData1 == nil then
        self.ui.m_titleNode1:setVisible(false)
        self.ui.m_listNode:setVisible(false)
    end

    if self.sourceData2 == nil then
        self.ui.m_titleNode2:setVisible(false)
        self.ui.m_listNode:setPosition(-276, -288)
        self.ui.m_listNode:setContentSize(cc.size(size.width, size.height + 60))
    end
    
    local delegate = {}
    delegate.gridAtIndex = function(tab, idx) return self:gridAtIndex(tab, idx) end
    delegate.numberOfCellsInTableView = function(tab) return self:numberOfCellsInTableView(tab) end
    delegate.numberOfGridsInCell = function(tab) return self:numberOfGridsInCell(tab) end
    delegate.gridSizeForTable = function(tab, idx) return self:gridSizeForTable(tab, idx) end

    size = self.ui.m_listNode:getContentSize()
    self.m_tabView = require("game.utility.TableViewMultiCol").new(size)
    self.m_tabView:setDelegate(delegate)
    self.m_tabView:setDirection(kCCScrollViewDirectionVertical)
    self.m_tabView:setVerticalFillOrder(kCCTableViewFillTopDown)

    self.ui.m_listNode:addChild(self.m_tabView)
end

function ApplySelectView:onEnter()
    local function beSelected(text) return self.text1 == text or self.text2 == text end

    if self.sourceData1 then
        for k, v in ipairs(self.sourceData1) do
            v.view = self.ui.m_listNode
            v.selectCb = beSelected
        end
    end

    if self.sourceData2 then
        for k, v in ipairs(self.sourceData2) do
            v.view = self.ui.m_listNode
            v.selectCb = beSelected
        end
    end

    self:updateView()
    self:refreshTitle()

    local function callback1(param) self:select(param) end
	local handler1 = self:registerHandler(callback1)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "changerServer.select")
end

function ApplySelectView:onExit()
    CCSafeNotificationCenter:unregisterScriptObserver(self, "changerServer.select")
end

function ApplySelectView:select(param)
    if param then
        local text = param:valueForKey("text"):getCString()
        local id = param:valueForKey("id"):getCString()
        if self.title1Show then 
            self.text1 = text 
            self.id1 = id 
        end
        if self.title2Show then 
            self.text2 = text 
            self.id2 = id 
        end
        CCSafeNotificationCenter:postNotification("changerServer.option")
        self:refreshTitle()
    end
end

function ApplySelectView:refreshTitle()
    local info = ""
    if self.sourceData2 then
        info = "<s 18><c dededeff>" .. getLang("173237") .. "   <c 939393ff> " .. getLang("173269")
    else
        info = "<s 18><c dededeff>" .. getLang("173209") .. "   <c 939393ff> " .. getLang("173270")
    end

    if self.text1 and self.sourceData2 then 
        info = "<s 18><c dededeff>" .. getLang("173237") .. "   <c ecdcaaff> " .. self.text1 
    elseif self.text1 and self.sourceData2 == nil then
        info = "<s 18><c dededeff>" .. getLang("173209") .. "   <c ecdcaaff> " .. self.text1 
    end

	local richText = IFHyperlinkText:call("create", info, cc.size(360.00, 0))
    richText:setAnchorPoint(ccp(0, 0.5))
    richText:ignoreAnchorPointForPosition(false)
    self.ui.m_finalNode1:removeAllChildren()
    self.ui.m_finalNode1:addChild(richText)

    
    local info = "<s 18><c dededeff>" .. getLang("173209") .. "   <c 939393ff> " .. getLang("173270")
    if self.text2 then info = "<s 18><c dededeff>" .. getLang("173209") .. "   <c ecdcaaff> " .. self.text2 end

	local richText = IFHyperlinkText:call("create", info, cc.size(360.00, 0))
    richText:setAnchorPoint(ccp(0, 0.5))
    richText:ignoreAnchorPointForPosition(false)
    self.ui.m_finalNode2:removeAllChildren()
    self.ui.m_finalNode2:addChild(richText)
end

function ApplySelectView:gridAtIndex(tab, idx)
    local luaIdx = idx + 1
    if luaIdx > #self.sourceData then return end
    local cell = tab:dequeueGrid()
    if not cell then cell = Drequire("game.CommonPopup.ChangeServer.ApplySelectCell"):create() end
    cell:refreshCell(self.sourceData[luaIdx])
	return cell
end

function ApplySelectView:numberOfCellsInTableView(tab)
    return math.ceil(#self.sourceData / 3)
end

function ApplySelectView:numberOfGridsInCell(tab)
    return 3
end

function ApplySelectView:gridSizeForTable(tab, idx)
    return 184, 68
end

function ApplySelectView:onTouchBegan(x, y)
    if not isTouchInside(self.ui.m_bg, x, y) then
        self.startPoint = ccp(x, y)
        return true
    end

    if self.ui.m_bg1:isVisible(true) and isTouchInside(self.ui.m_bg1, x, y) then
        self.startPoint = ccp(x, y)
        return true
    end

    if self.ui.m_bg2:isVisible(true) and isTouchInside(self.ui.m_bg2, x, y) then
        self.startPoint = ccp(x, y)
        return true
    end
end

function ApplySelectView:onTouchEnded(x, y)
    local distance = ccpDistance(self.startPoint, ccp(x, y))
    if distance > 10 then return end

    if not isTouchInside(self.ui.m_bg, x, y) then self:call("closeSelf") end
    
    local updateView = false
    if self.ui.m_bg1:isVisible(true) and isTouchInside(self.ui.m_bg1, x, y) then
        self.title1Show = not self.title1Show
        if self.title1Show then self.title2Show = false end
        updateView = true
    end

    if self.ui.m_bg2:isVisible(true) and isTouchInside(self.ui.m_bg2, x, y) then
        self.title2Show = not self.title2Show
        if self.title2Show then self.title1Show = false end
        updateView = true
    end

    if updateView then self:updateView() end
end

function ApplySelectView:updateView()
    if self.title1Show then
        self.ui.m_titleNode2:setPosition(-276, -288)
        self.ui.m_listNode:setVisible(true)
        if self.ui.m_titleNode2:isVisible() then
            self.ui.m_listNode:setPosition(-276, -228)
        else
            self.ui.m_listNode:setPosition(-276, -288)
        end
        self.ui.m_arrowSp1:setRotation(90)
        self.ui.m_arrowSp2:setRotation(0)
        self.sourceData = self.sourceData1
    elseif self.title2Show then
        self.ui.m_titleNode2:setPosition(-276, 138)
        self.ui.m_listNode:setVisible(true)
        self.ui.m_listNode:setPosition(-276, -288)
        self.ui.m_arrowSp1:setRotation(0)
        self.ui.m_arrowSp2:setRotation(90)
        self.sourceData = self.sourceData2
    else
        self.ui.m_titleNode2:setPosition(-276, 138)
        self.ui.m_listNode:setVisible(false)
        self.ui.m_listNode:setPosition(-276, -288)
        self.ui.m_arrowSp1:setRotation(0)
        self.ui.m_arrowSp2:setRotation(0)
        self.sourceData = {}
    end
    self.m_tabView:reloadData()
end

function ApplySelectView:onClickBtnConfirm()
    local passer = CCDictionary:create()
    if self.sourceData2 then
        passer:setObject(CCString:create(tostring(self.id1)), "serverId")
        passer:setObject(CCString:create(tostring(self.id2)), "lan")
    else
        passer:setObject(CCString:create(tostring(self.id1)), "lan")
    end
    CCSafeNotificationCenter:postNotification("changerServer.filter", passer)
    self:call("closeSelf")
end

return ApplySelectView