----------------------------
-- Author: Elex
-- Date: 2017-09-13 19:55:32
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local UseItemSelectView_ui = class("UseItemSelectView_ui")

--#ui propertys


--#function
function UseItemSelectView_ui:create(owner, viewType)
	local ret = UseItemSelectView_ui.new()
	CustomUtility:LoadUi("UseItemSelectView.ccbi", ret, owner, true, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function UseItemSelectView_ui:initLang()
end

function UseItemSelectView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function UseItemSelectView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function UseItemSelectView_ui:onUseClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onUseClick", pSender, event)
end

function UseItemSelectView_ui:onSubClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onSubClick", pSender, event)
end

function UseItemSelectView_ui:onAddClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onAddClick", pSender, event)
end

return UseItemSelectView_ui

