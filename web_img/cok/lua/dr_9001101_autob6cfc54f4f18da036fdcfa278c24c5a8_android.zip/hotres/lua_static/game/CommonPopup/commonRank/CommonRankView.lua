--[[ 
------------------------------通用排行榜界面------------------------------
配置:
排名奖励配置actType2XML
栏目标题配置: columnTile
标题配置:actId2Title
cell配置
headRankNode配置

@params:
	type:排行榜活动类型，不同活动排行榜拥有不同的type类型，与后端约定好 比如:typeTest
	viewType:1:本服玩家排行  2:全服玩家排行
	viewSize:界面尺寸大小
	pageSize:页面请求cell数量的限制，默认100个
	self_id: 个人排名传uid,其他的再定
]]
-- update at 19.07.24
-- use CommonRankConfig

local CommonRankView =
	class(
	"CommonRankView",
	function()
		return cc.Layer:create()
	end
)

CommonRankView.__index = CommonRankView

local CommonRankGroupTitleView =
	class(
	"CommonRankGroupTitleView",
	function()
		return cc.Layer:create()
	end
)

CommonRankGroupTitleView.__index = CommonRankGroupTitleView

local CommonRankPopupView =
	class(
	"CommonRankPopupView",
	function()
		return PopupBaseView:create()
	end
)

CommonRankPopupView.__index = CommonRankPopupView

local cellHeight = 92

-- type,m_viewType,viewSize,pageSize,self_id
function CommonRankView:create(params)
	local config = Drequire("game.CommonPopup.commonRank.CommonRankConfig"):createWithParams(params)
	local view = CommonRankView.new(config)
	Drequire("game.CommonPopup.commonRank.CommonRankView_ui"):create(view, 0, params.viewSize)
	if view:initView() then
		return view
	end
end

function CommonRankView:createWithConfigId(configId, rankName, viewSize)
	local config = Drequire("game.CommonPopup.commonRank.CommonRankConfig"):create(configId, rankName)

	local view = CommonRankView.new(config)
	Drequire("game.CommonPopup.commonRank.CommonRankView_ui"):create(view, 0, viewSize)
	if view:initView() then
		return view
	end
end

--非通用排行榜寄生 😂
function CommonRankView:createWithMgr(configId, rankName, params)
	local config = Drequire("game.CommonPopup.commonRank.CommonRankConfig"):createWithMgr(configId, rankName, params.rankMgr)
	local view = CommonRankView.new(config)
	Drequire("game.CommonPopup.commonRank.CommonRankView_ui"):create(view, 0, params.viewSize)
	if view:initView() then
		return view
	end
end

function CommonRankView:createWithTwoGroup(configLocal, configGlobal, viewSize)
	return CommonRankGroupTitleView:create(configLocal, configGlobal, viewSize)
end

function CommonRankView:addCommonRankPopupView(title, rankCreator)
	local view = CommonRankPopupView:create(title, rankCreator)
	if view then
		PopupViewController:addPopupInView(view)
	end
end

function CommonRankView:ctor(config)
	self.config = config
	self.rankCellNode = self.config:getRankCellNode()
end

function CommonRankView:initView()
	CCLoadSprite:call("loadDynamicResourceByName", "AllServerRank_face")
	CCLoadSprite:call("loadDynamicResourceByName", "HeadIcon")
	local function TouchEvent(eventType, x, y)
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
			return self:onTouchMoved(x, y)
		else
			return self:onTouchEnded(x, y)
		end
	end
	self.ui.m_touchLayer:setTouchEnabled(true)
	self.ui.m_touchLayer:registerScriptTouchHandler(TouchEvent)
	self.ui.m_touchLayer:setSwallowsTouches(true)
	self.m_pageIndex = 0

	local rankMgr = self.config.rankMgr or "game.CommonPopup.commonRank.CommonRankController"
	self.ctl = Drequire(rankMgr).new()

	self.m_endAt = nil
	self:updateUI()

	local scoreDialogId = self.config:getScoreDescDialog()
	if scoreDialogId and scoreDialogId ~= "" then
		self.ui.m_scoreDescLabel:setVisible(true)
		self.ui.m_scoreDescLabel:setString(getLang(tostring(scoreDialogId)))

		local viewSize = self:getContentSize()
		viewSize.height = viewSize.height - 70
		self.ui.m_contentNode:setContentSize(viewSize)
		viewSize.width = viewSize.width - 64
		viewSize.height = viewSize.height - 10
		self.ui.m_listNode:setContentSize(viewSize)
		self.ui.m_listBG:setContentSize(viewSize)
	else
		self.ui.m_scoreDescLabel:setVisible(false)
	end

	self.m_curMaxRank = 0 -- 当前最大的排名
	self.m_isSearching = false -- 是否在查找排名
	self.m_searchingRank = 0 -- 要查找的排名
	self:initTableView()
	self:reqData()
	return true
end

--请求界面信息
function CommonRankView:reqData()
	local params = self.config:getReqParams(self.m_pageIndex)
	self.ctl:reqData(params)
end

function CommonRankView:onEnter()
	-- CCSafeNotificationCenter:call("postNotification", "msg.CommonRankView.close")
	self:onEnterFrame(0)
	if self.entry then
		self:getScheduler():unscheduleScriptEntry(self.entry)
	end
	self.entry =
		tonumber(
		self:getScheduler():scheduleScriptFunc(
			function(dt)
				self:onEnterFrame(dt)
			end,
			1,
			false
		)
	)

	registerScriptObserver(self, self.getPlayerRankData, "msg.CommonRankView.getLocalPlayerRank")
	registerScriptObserver(self, self.rankDataFail, "CommonRankView.rankDataFail")
	registerScriptObserver(self, self.refreshAnonymousView, "CommonRankView.anonymous_state.changed")
	local function onGetRewardDetailBack(ref)
		local rewardId = ""
		if ref then
			rewardId = ref:getCString()
		end
		if self.m_requestingRewardIdTab and #self.m_requestingRewardIdTab > 0 then
			for i = 1, #self.m_requestingRewardIdTab do
				if rewardId == self.m_requestingRewardIdTab[i] then
					table.remove(self.m_requestingRewardIdTab, i)
					break
				end
			end
			if #self.m_requestingRewardIdTab == 0 then
				GameController:call("removeWaitInterface")
				self:getRewardDataAndOpenView()
			end
		end
	end
	local handler = self:registerHandler(onGetRewardDetailBack)
	CCSafeNotificationCenter:registerScriptObserver(self, handler, "MSG_GET_REWARD_DETAIL_BACK")
	registerScriptObserver(self, self.closeSelf, "msg.CommonRankView.close")

	self.ui.m_anonymousNode:setVisible(false)
end

function CommonRankView:onExit()
	self:getScheduler():unscheduleScriptEntry(self.entry)
	unregisterScriptObserver(self, "msg.CommonRankView.getLocalPlayerRank")
	unregisterScriptObserver(self, "CommonRankView.rankDataFail")
	unregisterScriptObserver(self, "msg.CommonRankView.close")
	unregisterScriptObserver(self, "CommonRankView.anonymous_state.changed")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "MSG_GET_REWARD_DETAIL_BACK")
end

function CommonRankView:closeSelf()
	self:removeFromParent()
end

function CommonRankView:createTop3CellData(tbl)
	local top3Data = {
		type = 4,
		parent = self,
		data = {
			rankList = tbl,
			luaFile = self.rankCellNode.luaTop3Path -- actType2RankNode[self.m_type],
		},
		config = self.config
	}
	return top3Data
end

function CommonRankView:createTitleCellData()
	local titleInfo = string.split(self.config:getColumnTitle() or "108101;182091;102139", ";")
	local dialogId1 = titleInfo[1] or "108101" -- 108101=领主
	local dialogId2 = titleInfo[2] or "182091" -- 182091=本期积分
	local dialogId3 = titleInfo[3] or "102139" -- 102139=奖励
	local dialogTips = self.config:getRefreshDialog()

	local titleCellData = {
		type = 3,
		parent = self,
		data = {
			name = getLang(dialogId1),
			power = getLang(dialogId2),
			server = getLang(dialogId3),
			tips = getLang(dialogTips)
		},
		config = self.config
	}
	return titleCellData
end

function CommonRankView:getPlayerRankData()
	local tbl = self.ctl:getRankDataByGroup(self.config:getRankGroupType())
	local endTime = tbl.endTime or tbl.end_time
	if endTime then --有下发时间时按服务器下发时间
		self.m_endAt = tonumber(endTime)
	else -- 没有下发时各自处理
		self:setPhaseLabel()
	end
	self:updateUI()
	self.anonymous_state = tonumber(tbl.anonymous_state) or 0
	self:refreshAnonymousView()

	local list = {}
	local rankPage = {}
	if tbl.rank then
		rankPage = tbl.rank
	elseif tbl.pagerank then
		rankPage = tbl.pagerank
	elseif self.m_pageIndex == 0 then
		LuaController:flyHint("", "", getLang("138130")) -- 138130=暂无记录
	end

	self.m_curMaxRank = self.m_curMaxRank or 1
	if rankPage and #rankPage > 0 then
		table.sort(
			rankPage,
			function(a, b)
				return tonumber(a.rank or 0) < tonumber(b.rank or 0)
			end
		)
		local _rank = tonumber(rankPage[#rankPage].rank)
		if _rank > self.m_curMaxRank then
			self.m_curMaxRank = _rank
		end
	end
	if tbl.selfrank then
		self.myRank = tonumber(tbl.selfrank.rank)
	end

	if self.m_pageIndex == 0 then
		-- 初始化界面
		local top3List = {rankPage[1], rankPage[2], rankPage[3]}
		local top3Data = self:createTop3CellData(top3List)
		table.insert(list, top3Data)

		local titleCellData = self:createTitleCellData()
		table.insert(list, titleCellData)

		-- 计算我的排名
		
		if tbl.selfrank and next(tbl.selfrank) then
			local myRankNum = tonumber(tbl.selfrank.rank or 0)
			if (myRankNum < 0 or myRankNum > 3) and tbl.selfrank.score then
				local myCellData = {
					type = 1,
					parent = self,
					data = tbl.selfrank,
					config = self.config
				}
				myCellData.callback = function(x)
					self:onRewardButtonClick(tonumber(x))
				end
				myCellData.dataType = 0 -- 排名数据
				myCellData.showSearch = true
				myCellData.searchCallback = function(x)
					self:searchRankInfo(tonumber(x))
				end
				myCellData.parent = self
				myCellData.isSelf = true
				table.insert(list, myCellData)
			end
		end
	end

	self.m_rankMap = self.m_rankMap or {}

	local flag = 1
	if #self.m_rankMap >= 1 then
		table.remove(self.m_rankMap, #self.m_rankMap)
		flag = 0
	end

	if #rankPage > 0 then
		-- 为 cell 添加查看奖品的回调
		local start = 1
		if self.m_pageIndex == 0 then
			start = 4
		end
		for i = start, #rankPage do
			local cellData = {
				type = 1,
				parent = self,
				data = rankPage[i],
				config = self.config
			}
			cellData.callback = function(x)
				self:onRewardButtonClick(tonumber(x))
			end
			cellData.dataType = 0 -- 排名数据
			table.insert(list, cellData)
		end
	end

	self.totalPageNum = tonumber(tbl.pagenum or self.totalPageNum) or 0
	if self.m_pageIndex + 1 < self.totalPageNum then
		local cellData = {
			type = 2,
			data = {
				dataType = 1,
				getMoreRank = function()
					self:reqData()
				end
			}, -- 获取更多
			config = self.config
		}

		table.insert(list, cellData)
	else
		-- self.m_rankMap[#self.m_rankMap + 1] = {dataType = 2} -- 没有更多数据
		if self.m_isSearching then
			self.m_searchingRank = self.m_curMaxRank
		end
		local cellData = {
			type = 2,
			data = {
				dataType = 2
			},
			config = self.config
		}
		table.insert(list, cellData)
	end

	for _, v in ipairs(list) do
		table.insert(self.m_rankMap, v)
	end
	self.cellDataList = self.m_rankMap

	local offset = self.ui.m_listTableView:getContentOffset()
	self.ui:setTableViewDataSource("m_listTableView", self.m_rankMap)
	-- offset.y = offset.y - cellHeight * (#rankPage - 2 + flag)
	-- self.ui.m_listTableView:setContentOffset(offset)

	-- 增加页数
	self.m_pageIndex = self.m_pageIndex + 1

	-- self.m_curMaxRank = #self.m_rankMap + 3 - 1
	if self.m_isSearching then
		if self.m_searchingRank <= self.m_curMaxRank then
			GameController:call("getInstance"):call("removeWaitInterface")
			self.m_isSearching = false
			self:jumpToSearchingRank(self.m_searchingRank)
		else
			self:reqData()
		end
	else
		GameController:call("getInstance"):call("removeWaitInterface")
	end
end

function CommonRankView:rankDataFail(params)
	if self.m_isSearching then
		self.m_isSearching = false
		self:jumpToSearchingRank(self.m_curMaxRank)
	end
end

function CommonRankView:onEnterFrame(dt)
	self:updateUI()
end

function CommonRankView:updateUI()
	if self.m_endAt and self.m_endAt > 0 then
		local leftTime = tonumber(self.m_endAt) / 1000 - getTimeStamp() -- LuaController:call("getWorldTime")
		if leftTime > 0 then
			self.ui.m_timeLabel:setString(getLang("182043", CC_SECTOA(leftTime))) --182043={0}后发放奖励
		else
			self.ui.m_timeLabel:setString(getLang(self.config:getRankEndDialog() or "176075"))
		end
	else
		self.ui.m_timeLabel:setString("")
	end
end

-- 招募之神的排行奖励每期变化
function CommonRankView:getPhaseRewardId()
	local rewardId
	if self.config:getRankName() == "general" then
		local HeroRecruitRankCtl = require("game.hero.NewUI_v2.HeroRecruitRankController").getInstance()
		if self.config:getRankGroupType() == "local" then -- 本服
			rewardId = HeroRecruitRankCtl.pic_id_2
		else
			rewardId = HeroRecruitRankCtl.pic_id_1
		end
	end
	return rewardId
end

function CommonRankView:setPhaseLabel()
	self.ui.m_phaseLabel:setVisible(true)
	local configId = ""
	local xmlName = self.config:getRewardTbl()
	configId = self:getPhaseRewardId()

	local info = self.config:getPhraseInfo()
	if info then
		self.ui.m_phaseLabel:setString(info)
	else
		if self.config:getRankName() == "general" then
			local start_time = CCCommonUtilsForLua:call("getPropByIdGroup", xmlName, configId, "start_time")
			local end_time = CCCommonUtilsForLua:call("getPropByIdGroup", xmlName, configId, "end_time")
			end_time = end_time .. "-00-00-00"
			local target = CCCommonUtilsForLua:call("UTCDataToTimeStamp", end_time)
			local end_time_new = CCCommonUtilsForLua:call("timeStampToYMD", target - 86400)
			self.ui.m_phaseLabel:setString(start_time .. "--" .. end_time_new)
		else
			self.ui.m_phaseLabel:setString("")
		end
	end
end

function CommonRankView:onTouchBegan(x, y)
	if self:isVisible(true) and isTouchInside(self.ui.m_touchLayer, x, y) then
		return true
	end
end

function CommonRankView:onTouchMoved(x, y)
end

function CommonRankView:onTouchEnded(x, y)
	-- body
end

function CommonRankView:hasReward()
	if string.isNilOrEmpty(self.config:getRewardTbl()) == false or string.isNilOrEmpty(self.config:getRewardId()) == false then
		return true
	end
	return false
end

function CommonRankView:onRewardButtonClick(idx)
	if self:hasReward() then
		-- 打点需求
		local rankName = self.config:getRankName() or ""
		local groupName = self.config:getRankGroupType() or ""

		self.m_idx = idx
		if self.config:getRewardTbl() == "ladder_rank" and self.config:getRewardId() == "-1" then
			-- 皇家竞技场
			self:getLadderRankRewardData(self.config:getRewardTbl(), TournamentControllerInst)
		elseif self.config:getRewardTbl() == "peak_ladder_rank" then
			-- 巅峰竞技场
			self:getLadderRankRewardData(self.config:getRewardTbl(), PinnacleControllerInst)
		else
			self:getRewardDataWithCheck()
		end
	end
end

-- 解析奖励
function CommonRankView:parseRewardId()
	if not self.m_rewardIdTab then
		self.m_rewardIdTab = {}
		local xmlName = self.config:getRewardTbl()
		local equipRewardId = self.config:getRewardId()

		if self.config:getRankName() == "general" then
			local rewardId = self:getPhaseRewardId()
			if rewardId then
				equipRewardId = rewardId
			end
		end

		local reward = CCCommonUtilsForLua:call("getPropByIdGroup", xmlName, equipRewardId, "reward")
		local rwdTab = string.split(reward, "|")
		for i = 1, #rwdTab do
			local rwdItem = string.split(rwdTab[i], ";")
			if #rwdItem >= 2 then
				local rwdIdx = string.split(rwdItem[1], "-")
				if #rwdIdx >= 2 then
					self.m_rewardIdTab[i] = {left = tonumber(rwdIdx[1]), right = tonumber(rwdIdx[2]), rewardId = rwdItem[2]}
				elseif #rwdIdx >= 1 then
					self.m_rewardIdTab[i] = {left = tonumber(rwdIdx[1]), right = tonumber(rwdIdx[1]), rewardId = rwdItem[2]}
				end
			end
		end
	end
end

-- 检查奖励数据
function CommonRankView:checkRewardData()
	self:parseRewardId()

	self.m_requestingRewardIdTab = {}
	for i = 1, #self.m_rewardIdTab do
		local rwd = GlobalData:call("getCachedRewardData", self.m_rewardIdTab[i].rewardId)
		local rwdData = arrayToLuaTable(rwd)
		if #rwdData == 0 then
			self.m_requestingRewardIdTab[#self.m_requestingRewardIdTab + 1] = self.m_rewardIdTab[i].rewardId
		end
	end
end

-- 获取奖励数据（没有时向服务器请求）
function CommonRankView:getRewardDataWithCheck()
	self:checkRewardData()

	if #self.m_requestingRewardIdTab == 0 then
		self:getRewardDataAndOpenView()
	else
		GameController:call("getInstance"):call("showWaitInterface")
		for i = 1, #self.m_requestingRewardIdTab do
			GlobalData:call("requestRewardData", self.m_requestingRewardIdTab[i])
		end
	end
end

-- 获取奖励数据并打开奖励界面
function CommonRankView:getRewardDataAndOpenView()
	local myRank = self.myRank or 0
	local idx = self.m_idx or 1
	local found = false
	local index = 0
	local rewardTab = {}
	if myRank > 0 then
		for i = 1, #(self.m_rewardIdTab or {}) do
			local left = self.m_rewardIdTab[i].left
			local right = self.m_rewardIdTab[i].right
			if left <= myRank and myRank <= right then
				if idx == myRank then
					found = true
					index = #rewardTab
				end

				local titleStr = getLang("221120") .. " (" .. getLang("170008") .. ": " .. myRank .. ")"
				rewardTab[#rewardTab + 1] = {type = 1000, label = titleStr}
				local rwd = GlobalData:call("getCachedRewardData", self.m_rewardIdTab[i].rewardId)
				local rwdData = arrayToLuaTable(rwd)
				for _, v in pairs(rwdData) do
					rewardTab[#rewardTab + 1] = v
				end
				break
			end
		end
	end
	for i = 1, #(self.m_rewardIdTab or {}) do
		local left = self.m_rewardIdTab[i].left
		local right = self.m_rewardIdTab[i].right
		if not found then
			if left <= idx and idx <= right then
				found = true
				index = #rewardTab
			end
		end

		local titleStr = ""
		if left ~= right then
			titleStr = getLang("221119", tostring(left), tostring(right))
		else
			titleStr = getLang("221121", tostring(left))
		end
		rewardTab[#rewardTab + 1] = {type = 1000, label = titleStr}
		local rwd = GlobalData:call("getCachedRewardData", self.m_rewardIdTab[i].rewardId)
		local rwdData = arrayToLuaTable(rwd)
		for _, v in pairs(rwdData) do
			rewardTab[#rewardTab + 1] = v
		end
	end

	local titleName = getLang(self.config:getRewardTitle())
	local tipsDes = getLang(self.config:getRewardTips() or "221122")
	self:showRewardView(rewardTab, index, titleName, tipsDes)
end

function CommonRankView:showRewardView(rewardTab, index, titleName, tipsDes)
	local view = Drequire("game.equipment.EquipRank.EquipmentRewardView"):create(rewardTab, index, titleName, tipsDes)
	PopupViewController:call("addPopupView", view)
end

function CommonRankView:onSearchButtonClick(pSender, event)
	local callback = function (index)
		self:searchRankInfo(tonumber(index))
	end
	local view = Drequire("game.CommonPopup.CommonInputView"):create(getLang("221129"), callback)
	PopupViewController:call("addPopupView", view)
end

function CommonRankView:searchRankInfo(idx)
	local maxRank = 5000
	local _data = self.ctl:getRankDataByGroup(self.config:getRankGroupType())

	if _data then
		if self.config:getRankGroupType() == "local" then
			maxRank = tonumber(_data.maxLocalRank) or 5000
		else
			maxRank = tonumber(_data.maxGlobalRank) or 5000
		end
	end
	if idx <= 3 then
		idx = 3 + 1
	elseif idx > maxRank then
		idx = maxRank
	end
	if idx <= self.m_curMaxRank then
		self:jumpToSearchingRank(idx)
	else
		self.m_isSearching = true
		self.m_searchingRank = idx
		self:reqData()
	end
end

function CommonRankView:jumpToSearchingRank(idx)
	local minOffsetY = self.ui.m_listNode:getContentSize().height - self.ui.m_listTableView:getContentSize().height
	local maxOffsetY = self.ui.m_listNode:getContentSize().height
	local offsetY = minOffsetY + (idx - 3 - 1) * cellHeight
	if offsetY < minOffsetY then
		offsetY = minOffsetY
	elseif offsetY > maxOffsetY then
		offsetY = maxOffsetY
	end
	offsetY = offsetY + 420
	self.ui.m_listTableView:setContentOffset(cc.p(0, offsetY))
end

-- 招募之神的历届排名begin
function CommonRankView:setPhaseButtonVisible(isVisible, iconPic, curPhase)
	self.ui.m_phaseNode:setVisible(isVisible)
	if iconPic ~= nil and isVisible then
		local picFrame = CCLoadSprite:call("getSF", iconPic) or CCLoadSprite:call("getSF", "Icon_Activities.png")
		if picFrame then
			self.ui.m_sprHistoryRank:setSpriteFrame(picFrame)
		end
	end

	if curPhase ~= nil and isVisible then
		self.m_curPhase = tonumber(curPhase)
	end
end

function CommonRankView:onPhaseButtonClick()
	if self.m_curPhase and self.m_curPhase <= 1 then
		CCCommonUtilsForLua:call("flyHint", "", "", _lang("138130"))
		return
	end
	local view = Drequire("game.rank.PlayerRankListView"):create(13)
	PopupViewController:addPopupInView(view)
end
-- 招募之神的历届排名end

function CommonRankView:getLadderRankRewardData(xmlGroup, control)
	local xmlData = CCCommonUtilsForLua:getGroupByKey(xmlGroup)
	local myRank = self.myRank or 0
	local idx = self.m_idx or 1
	local rewardTab = {}
	local rankData = {}
	local rankBegin = 1
	local rankEnd = idx + 5
	if idx == 1 then
		rankEnd = 10
	end
	if idx - 5 > 0 then
		rankBegin = idx - 5
	end

	for i = rankBegin, rankEnd do
		for k, v in pairs(xmlData) do
			if tonumber(v.ranking) then
				if tonumber(v.ranking) == i then
					local data = {
						ranking = i,
						type = v.type,
						value = v.value
					}
					rankData[#rankData + 1] = data
				end
			else
				local rankItem = string.split(v.ranking, ";")
				local left = tonumber(rankItem[1])
				local right = tonumber(rankItem[2])
				if i >= left and i <= right then
					local data = {
						ranking = i,
						type = v.type,
						value = v.value
					}
					rankData[#rankData + 1] = data
				end
			end
		end
	end

	local index = 0
	local rewardTab = {}
	if myRank > 0 then
		for i = 1, #(rankData or {}) do
			local ranking = rankData[i].ranking
			if myRank == ranking then
				-- index = #rewardTab
				local titleStr = getLang("221120") .. " (" .. getLang("170008") .. ": " .. myRank .. ")"
				rewardTab[#rewardTab + 1] = {type = 1000, label = titleStr}
				local rewardData = {type = -1000, value = {}}
				rewardData["value"]["num"] = control:applyRankingMethod(rankData[i])
				-- if rankData[i].type == "1" then -- 公式计算
				-- 	-- 公式：1/（名次)^0.3 *10000+500
				-- 	rewardData["value"]["num"] = math.floor(10000 / math.pow(tonumber(rankData[i].ranking), 0.3) + 500)
				-- else
				-- 	rewardData["value"]["num"] = tonumber(rankData[i].value)
				-- end
				rewardTab[#rewardTab + 1] = rewardData
				break
			end
		end
	end
	for i = 1, #(rankData or {}) do
		local ranking = rankData[i].ranking
		if ranking == idx then
			index = #rewardTab
		end

		local titleStr = getLang("221121", tostring(ranking))
		rewardTab[#rewardTab + 1] = {type = 1000, label = titleStr}
		local rewardData = {type = -1000, value = {}}
		rewardData["value"]["num"] = control:applyRankingMethod(rankData[i])
		-- if rankData[i].type == "1" then -- 公式计算
		-- 	-- 公式：1/（名次)^0.3 *10000+500
		-- 	rewardData["value"]["num"] = math.floor(10000 / math.pow(tonumber(rankData[i].ranking), 0.3) + 500)
		-- else
		-- 	rewardData["value"]["num"] = tonumber(rankData[i].value)
		-- end
		rewardTab[#rewardTab + 1] = rewardData
	end
	local titleName = getLang("350245")
	local tipsDes = getLang(self.config:getRewardTips() or "221122")
	self:showRewardView(rewardTab, index, titleName, tipsDes)
end

function CommonRankView:allianceRankToOldInfo(rankInfo)
	local ret = {
		abbr = rankInfo.abbr,
		alliancename = rankInfo.allianceName,
		fightpower = rankInfo.power,
		icon = rankInfo.icon,
		learderName = rankInfo.leaderName,
		learderUid = rankInfo.leaderUid,
		serverId = rankInfo.serverId,
		uid = rankInfo.uid,
		curMember = rankInfo.curMember,
		maxMember = rankInfo.maxMember,
		powerRestriction = rankInfo.powerRestriction,
		castleRestriction = rankInfo.castleRestriction,
		recruit = rankInfo.recruit,
		language = rankInfo.language
	}
	return ret
end

function CommonRankView:openAllianceViewByRankInfo(info)
	local oldInfo = self:allianceRankToOldInfo(info)
	local alliance = AllianceInfo:call("create") --AllianceInfo*
	alliance:call("updateAllianceInfo", luaToDict(oldInfo))

	local dict = CCDictionary:create()
	dict:setObject(CCString:create("CheckAllianceInfoView"), "name")
	dict:setObject(alliance, "AllianceInfo")
	LuaController:call("openPopViewInLua", dict)
end

function CommonRankView:openKingdomViewByRankInfo(info)
	-- TODO:
end

function CommonRankView:cellSizeForTable(tv, idx)
	if not self.cellDataList then
		return 0, 0
	end
	local data = self.cellDataList[idx + 1]
	if data then
		if data.type == 1 then
			return 574, 92
		elseif data.type == 2 then
			return 574, 92
		elseif data.type == 3 then
			return 576, 80
		else
			return 576, 420
		end
	else
		return 0, 0
	end
end

function CommonRankView:initTableView()
	local listSize = self.ui.m_listNode:getContentSize()
	self.ui.m_listTableView:setContentSize(listSize)
	Drequire("Editor.TableViewSmoker"):createView(
		self.ui,
		"m_listTableView",
		-- actType2CellFile[self.m_type].path,
		self.rankCellNode.luaPath,
		1,
		10,
		-- actType2CellFile[self.m_type].fileName
		self.rankCellNode.ccbiName
	)

	self.cellDataList = {
		self:createTop3CellData(),
		self:createTitleCellData()
	}
	self.ui:setTableViewDataSource("m_listTableView", self.cellDataList)
end

function CommonRankView:refreshAnonymousView()
	if self.config:getAnonymousOpen() and self.config:getHasAnonymousPermission() then
		self.ui.m_anonymousNode:setVisible(true)
		if not self.anonymous_state or self.anonymous_state == 0 then
			self.ui.m_anonymousOpenLabel:setString(getLang("9800056"))
		else
			self.ui.m_anonymousOpenLabel:setString(getLang("9800055"))
		end
	else
		self.ui.m_anonymousNode:setVisible(false)
	end
end

function CommonRankView:onAnonymousClick()
	if self.config and self.config:getAnonymousOpen() and self.config:getRankName() then
		local newState = (self.anonymous_state == 0) and 1 or 0
		self.ctl:doReqSetAnonymousState(
			self.config:getRankName(),
			self.config:getRankSelfId(),
			newState,
			function(tbl)
				self.anonymous_state = newState
				CCSafeNotificationCenter:call("postNotification", "CommonRankView.anonymous_state.changed")
			end
		)
	end
end

function CommonRankView:hideSearchNode()
	self.ui.m_serchNode:setVisible(false)
end
-------------------------------

function CommonRankGroupTitleView:create(configLocal, configGlobal, viewSize)
	local view = CommonRankGroupTitleView.new(configLocal, configGlobal)
	Drequire("game.CommonPopup.commonRank.CommonRankGroupTitleView_ui"):create(view, 0, viewSize)
	if view:initView() then
		return view
	end
end

function CommonRankGroupTitleView:ctor(configLocal, configGlobal)
	self.configLocal = configLocal
	self.configGlobal = configGlobal
end

function CommonRankGroupTitleView:initView()
	self:initTitle()
	self:onClickBtnGlobal()
	return true
end

function CommonRankGroupTitleView:initTitle()
	if self.configLocal.title then
		self.ui.m_localLabel:setString(getLang(self.configLocal.title))
	end
	if self.configGlobal.title then
		self.ui.m_globalLabel:setString(getLang(self.configGlobal.title))
	end
end

function CommonRankGroupTitleView:onClickBtnGlobal()
	self:addARank(self.configGlobal)
	self.ui.m_btnGlobal:setEnabled(false)
	self.ui.m_btnLocal:setEnabled(true)
end

function CommonRankGroupTitleView:onClickBtnLocal()
	self:addARank(self.configLocal)
	self.ui.m_btnGlobal:setEnabled(true)
	self.ui.m_btnLocal:setEnabled(false)
end

function CommonRankGroupTitleView:addARank(config)
	local viewSize = self.ui.m_rankNode:getContentSize()

	local view = CommonRankView:createWithConfigId(config.id, config.name, viewSize)
	if view then
		if self.aRankView then
			self.ui.m_rankNode:removeChild(self.aRankView)
		end
		self.ui.m_rankNode:addChild(view)
		self.aRankView = view
	end
end

-------------

function CommonRankPopupView:create(title, rankCreator)
	local view = CommonRankPopupView.new()
	Drequire("game.CommonPopup.commonRank.CommonRankPopupView_ui"):create(view, 1)

	if view:initView(title, rankCreator) == false then
		return nil
	end
	return view
end

function CommonRankPopupView:initView(title, rankCreator)
	if title then
		self.ui.m_labelTitle:setString(getLang(title))
	end

	if rankCreator then
		local contentSize = self.ui.m_rankNode:getContentSize()
		local view = rankCreator(contentSize)
		self.ui.m_rankNode:addChild(view)
	end

	return true
end

return CommonRankView
