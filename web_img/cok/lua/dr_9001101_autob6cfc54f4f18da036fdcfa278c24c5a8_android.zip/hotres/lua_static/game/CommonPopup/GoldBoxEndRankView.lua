GoldBoxEndRankView = class("GoldBoxEndRankView", function()
        return PopupBaseView:create()
    end
)
GoldBoxEndRankView.__index = GoldBoxEndRankView

local GoldBoxRankCellSize = CCSize(610, 145)
local GoldBoxRankCellHDSize = CCSize(1476, 290)
local cellButtonNumPosY = 22
local myActivityId = ""
local infoListPosY = 0
local TOP_HEIGHT_HD = 154
local infoListContentDeltaHeight = 60
local infoListContentSizeHeight = 0
---------------------------排行 Start ---------------------------
GoldBoxRankEndCmd = class("GoldBoxRankEndCmd", LuaCommandBase)
function GoldBoxRankEndCmd.create()
    local ret = GoldBoxRankEndCmd.new()
    ret:initWithName("goldwheel.rank")
    return ret
end

function GoldBoxRankEndCmd:handleReceive(dict)
    local flag, params = self:parseMsg(dict)
    Dprint("BalanceInputCmd:handleReceive | parse flag=", flag)
    if (type(flag) == "boolean") then
        return flag
    end
    CCSafeNotificationCenter:postNotification("goldbox_get_EndWheelRank",params)
    return true
end
--------------------------- 排行 End ---------------------------

---------------------------隐藏姓名 Start ---------------------------
GoldBoxRankEndHideCmd = class("GoldBoxRankEndHideCmd", LuaCommandBase)
function GoldBoxRankEndHideCmd.create()
    local ret = GoldBoxRankEndHideCmd.new()
    ret:initWithName("goldwheel.update")
    return ret
end

function GoldBoxRankEndHideCmd:handleReceive(dict)
    local flag, params = self:parseMsg(dict)
    Dprint("BalanceInputCmd:handleReceive | parse flag=", flag)
    if (type(flag) == "boolean") then
        return flag
    end
    CCSafeNotificationCenter:postNotification("goldbox_get_EndWheelRank",params)
    return true
end

--------------------------- 排行 End ---------------------------

------------------------------------------ GoldBoxEndRankView Start --------------------------------------------

function GoldBoxEndRankView:create()
    local view = GoldBoxEndRankView.new()
    Drequire("game.CommonPopup.GoldBoxEndRankView_ui"):create(view, 0)
    if view:initView() == false then
        return nil
    end
    return view
end

function GoldBoxEndRankView:initView()
    CCLoadSprite:call("doResourceByCommonIndex", 7, true)
    CCLoadSprite:call("doResourceByCommonIndex", 205, true)

    self.m_nowRankIndex = 1
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_rankBtn1, getLang("140476"))--黄金宝箱
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_rankBtn2, getLang("140477"))--本服
    self.ui.m_rankTitle:setString(getLang("170902"))
    self.ui.m_textTitle1:setString(getLang("140351"))
    self.ui.m_textTitle2:setString(getLang("150302"))
    local rewardSendTime = 0
    --读取前台表 
    local xmlData = CCCommonUtilsForLua:getGroupByKey("golden_roulette")
    for k,v in pairs(xmlData) do
        if v.rewardSendTime and v.rewardSendTime ~= "" then
        rewardSendTime = tonumber(v.rewardSendTime)
        end
    end
    self.ui.m_tipsLabel:setString(getLang("140494",rewardSendTime / 60))--cjytest   rewardSendTime
    self:setTitleName(getLang("150289"))
    self.ui.node_hideNameBtn:setVisible(false)
    self.ui.m_rankTitleTime:setString(getLang("140485"))
    self.ui.m_timeLeftTextTime:setPositionX(self.ui.m_rankTitleTime:getPositionX() + self.ui.m_rankTitleTime:getContentSize().width + 10)
    self.ui.m_timeLeftText:setPositionX(self.ui.m_rankTitle:getPositionX() + self.ui.m_rankTitle:getContentSize().width + 10)
    self.m_deltTime = 0
    return true
end

function GoldBoxEndRankView:onEnter()
    local cmd = GoldBoxRankEndCmd:create()
    cmd:send()
    local function onRefresh( ref )
        local tbl = dictToLuaTable(ref)
        self.rankDataList = tbl
        self:onRefresh(tbl,true)
    end 
    local t = tolua.cast(self, "cc.Node")
    local handler = t:registerHandler(onRefresh)
    CCSafeNotificationCenter:registerScriptObserver(self, handler, "goldbox_get_EndWheelRank")
    -- 倒计时
    self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:update(dt) end, 1, false)

end

function GoldBoxEndRankView:onExit()
    CCSafeNotificationCenter:unregisterScriptObserver(self, "goldbox_get_EndWheelRank")      
    if self.m_entryId ~= nil then
        self:getScheduler():unscheduleScriptEntry(self.m_entryId)
        self.m_entryId = nil
    end
end

function GoldBoxEndRankView:onRefresh( tbl,isFirstIn)
    if not tbl.rankLocal or not tbl.rankGlobal or not tbl.local_ref or not tbl.global_ref then
        MyPrint("data is wrong")
        return 
    end
    self.m_time2 = tbl.local_ref
    self.m_time3 = tbl.global_ref    

    -- print("GoldBoxEndRankView:onRefresh hey!! " , tbl.hide)
    -- dump(tbl , "cjy GoldBoxEndRankView:onRefresh hey!! ")
    if tbl.hide == "1" then
        self.ui.txt_hideName:setString(getLang("140495"))--显示
    else
        self.ui.txt_hideName:setString(getLang("140478"))--隐藏
    end
    local data = {}
    if self.m_nowRankIndex == 1 then
        if #tbl.rankLocal <= 0 then
            self.ui.m_timeLeftText:setString("")
            self.ui.m_rankTitle:setString(getLang("E100176"))
        else
            if tbl.myLrank == "-1" then
                self.ui.m_timeLeftText:setString("999+")
            else
                local heroUid = tostring(GlobalData:call("shared"):getProperty("playerInfo"):getProperty("uid"))
                for k,v in pairs(tbl.rankLocal) do
                    if heroUid == tostring(v.uid) then -- 是自己
                        v.hideKing = tbl.hide
                        break
                    end 
                end
                if tbl.myLrank ~= "-1" then
                    self.ui.m_timeLeftText:setString(tbl.myLrank)
                else
                    self.ui.m_timeLeftText:setString("999+")
                end
            end
            self.ui.m_rankTitle:setString(getLang("170902"))
            for i = 1, #tbl.rankLocal, 1 do
                data[i] = tbl.rankLocal[i]
            end
        end
        self.ui.m_rankBtn1:setEnabled(false)
        self.ui.m_rankBtn2:setEnabled(true)
    elseif self.m_nowRankIndex == 2 then
        if #tbl.rankGlobal <= 0 then
            self.ui.m_timeLeftText:setString("")
            self.ui.m_rankTitle:setString(getLang("E100176"))
        else
            if tbl.myGRank == "-1" then
                self.ui.m_timeLeftText:setString("999+")
            else
                local heroUid = tostring(GlobalData:call("shared"):getProperty("playerInfo"):getProperty("uid"))
                for k,v in pairs(tbl.rankGlobal) do
                    if heroUid == tostring(v.uid) then -- 是自己
                        v.hideKing = tbl.hide
                        break
                    end 
                end
                self.ui.m_timeLeftText:setString(tbl.myGRank)
            end
            for i = 1, #tbl.rankGlobal, 1 do
                data[i] = tbl.rankGlobal[i]
            end
            if tbl.myGRank ~= "-1" then
                self.ui.m_timeLeftText:setString(tbl.myGRank)
            else
                self.ui.m_timeLeftText:setString("999+")
            end
        end
        self.ui.m_rankBtn1:setEnabled(true)
        self.ui.m_rankBtn2:setEnabled(false)
    end

    Dprint("GoldBoxEndRankView:onRefresh set table!! before self.ui=", self.ui, ", dataLen=", #data)
    self.ui:setTableViewDataSource("m_infoList", data)
    Dprint("GoldBoxEndRankView:onRefresh set table!! after self.ui=", self.ui)
end

function GoldBoxEndRankView:onClickRankBtn1(  )    
    self.m_nowRankIndex = 1
    if self.m_time1 ~= nil then
        self.m_deltTime = tonumber(self.m_time1) - tonumber(LuaController:call("getTimeStamp"))
        self:update(nil)
    end
    self:onRefresh(self.rankDataList,false)
end
function GoldBoxEndRankView:onClickRankBtn2(  )
    self.m_nowRankIndex = 2
    if self.m_time2 ~= nil then
        self.m_deltTime = tonumber(self.m_time2) - tonumber(LuaController:call("getTimeStamp"))
        self:update(nil)
    end
    self:onRefresh(self.rankDataList,false)
end

function GoldBoxEndRankView:onclickHide(  )
    -- print("cjy onclickHide")
    local cmd = GoldBoxRankEndHideCmd:create()
    cmd:send()
end

function GoldBoxEndRankView:update( dt )
    self.m_deltTime = self.m_deltTime - 1
    if self.m_deltTime < 0 then
        self.m_deltTime = 0
    end
    self.ui.m_timeLeftTextTime:setString(format_time(self.m_deltTime))
end
return GoldBoxEndRankView





