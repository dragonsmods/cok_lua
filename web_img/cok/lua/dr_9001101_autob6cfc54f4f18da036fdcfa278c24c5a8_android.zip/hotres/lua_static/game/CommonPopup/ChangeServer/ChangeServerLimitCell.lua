local ChangeServerLimitCell = class("ChangeServerLimitCell", cc.Layer)

function ChangeServerLimitCell:ctor(data)
	-- Drequire("game.CommonPopup.ChangeServer.ChangeServerLimitCell_ui"):create(self, 0)
    
    local bg = CCLoadSprite:call("createScale9Sprite", "BG_tanchukuang02.png")
    bg:setPreferredSize(cc.size(100, 68))
    bg:setAnchorPoint(ccp(0, 0))
    self:addChild(bg)

    local icon = CCLoadSprite:call("createSprite", "icon_chengzhen.png")
    icon:setScale(0.5)
    icon:setPosition(20, 45)
    self:addChild(icon)

    self.m_text1 = cc.Label:createWithSystemFont("", "Helvetica", 16, cc.size(0.0,0))
    self.m_text2 = cc.Label:createWithSystemFont("", "Helvetica", 16, cc.size(0.0,0))

    self.m_text1:setAnchorPoint(ccp(0, 0.5))
    self.m_text1:setPosition(43, 44)
    self.m_text2:setPosition(50, 15)

    self:addChild(self.m_text1)
    self:addChild(self.m_text2)

    self:setData(data)
end

function ChangeServerLimitCell:setData(data)
    self.m_text1:setString("#" .. data.kingid)
    self.m_text2:setString(data.maxnum)
end

return ChangeServerLimitCell