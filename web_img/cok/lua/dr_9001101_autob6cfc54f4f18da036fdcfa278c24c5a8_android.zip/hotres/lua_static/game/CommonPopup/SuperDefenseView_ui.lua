----------------------------
-- Author: Elex
-- Date: 2021-03-02 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local SuperDefenseView_ui = class("SuperDefenseView_ui")

--#ui propertys


--#function
function SuperDefenseView_ui:create(owner, viewType, paramTable)
	local ret = SuperDefenseView_ui.new()
	CustomUtility:LoadUi("SuperDefenseView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function SuperDefenseView_ui:initLang()
	LabelSmoker:setText(self.m_titleTxt, "163000")
	LabelSmoker:setText(self.m_pLabelTTF20, "113069")
	ButtonSmoker:setText(self.m_moreBtn, "105086")
	ButtonSmoker:setText(self.m_moreBtn1, "105086")
end

function SuperDefenseView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function SuperDefenseView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function SuperDefenseView_ui:onClickMore(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickMore", pSender, event)
end

function SuperDefenseView_ui:onClickMore1(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickMore1", pSender, event)
end

function SuperDefenseView_ui:onClickOpen(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickOpen", pSender, event)
end

return SuperDefenseView_ui

