----------------------------
-- Author: Elex
-- Date: 2021-01-13 Wednesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CommonPopView_ui = class("CommonPopView_ui")

--#ui propertys


--#function
function CommonPopView_ui:create(owner, viewType, paramTable)
	local ret = CommonPopView_ui.new()
	CustomUtility:LoadUi("CommonPopView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CommonPopView_ui:initLang()
end

function CommonPopView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CommonPopView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CommonPopView_ui:onUpdateOneClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onUpdateOneClick", pSender, event)
end

function CommonPopView_ui:onUpdateMaxClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onUpdateMaxClick", pSender, event)
end

return CommonPopView_ui

