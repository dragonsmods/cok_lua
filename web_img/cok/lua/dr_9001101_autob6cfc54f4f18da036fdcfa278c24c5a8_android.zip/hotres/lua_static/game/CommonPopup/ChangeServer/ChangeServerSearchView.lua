local ChangeServerSearchView = class("ChangeServerSearchView", PopupBaseView)

function ChangeServerSearchView:create()
    local view = ChangeServerSearchView.new()
    Drequire("game.CommonPopup.ChangeServer.ChangeServerSearchView_ui"):create(view, 1)
    view:initView()
    return view
end

function ChangeServerSearchView:ctor()
    self.kingdom = 0
end

function ChangeServerSearchView:initView()
    self:setHDPanelFlag(true)

    if CCCommonUtilsForLua:isIosAndroidPad() then
        self.ui.nodeccb:setScale(2.0)
    end

    registerTouchHandler(self)
    self:setTouchEnabled(true)

    self.ui.m_mainTitle:setString(getLang("173246"))
    self.ui.m_kingdom:setString(getLang("108755")) 
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_confirmBtn, getLang("confirm"))
    self.m_kingdomEdit = self:createEditBox(self.ui.m_kingdomNode, "01_24.png", 4)
    self.m_kingdomEdit:setPlaceHolder(getLang("132013"))
end

function ChangeServerSearchView:createEditBox(baseNode, pic, maxLength)
    local editSize = baseNode:getContentSize()
    local editpic = CCLoadSprite:call("createScale9Sprite", pic)
    local editBox = CCEditBox:create(editSize,editpic)
    editBox:setInputMode(cc.EDITBOX_INPUT_MODE_NUMERIC)
    editBox:setFontColor(cc.c3b(96, 93, 91))
    editBox:setPlaceholderFontColor(cc.c3b(96, 93, 91))
    editBox:setMaxLength(maxLength)
    editBox:setReturnType(cc.KEYBOARD_RETURNTYPE_DONE)
    editBox:setPosition(ccp(editSize.width/2, editSize.height/2))
    baseNode:addChild(editBox)

    local function editCB (strEventName,pSender)
        dump("editCB pSender is: " ..tostring(pSender))
        if tostring(pSender) == "began" then
            --光标进入，选中全部内容
            -- print("self.m_editOpen = true")
            self.m_editOpen = true
        elseif tostring(pSender) == "ended" then
            -- 当编辑框失去焦点并且键盘消失的时候被调用
        elseif tostring(pSender) == "return" then
            -- 当用户点击编辑框的键盘以外的区域，或者键盘的Return按钮被点击时所调用
            self:editBoxReturn(editBox)

        elseif tostring(pSender) == "changed" then
            -- 输入内容改变时调用
            -- self:editBoxTextChanged(self.m_editBox:getText())     
        end
    end
    editBox:registerScriptEditBoxHandler(editCB) --输入框的事件，主要有光标移进去，光标移出来，以及输入内容改变等

    return editBox
end

function ChangeServerSearchView:editBoxReturn(editBox)
    self.kingdom = atoi(editBox:getText())
    editBox:setText(tostring(self.kingdom))
end

function ChangeServerSearchView:onTouchBegan(x, y)
    if not isTouchInside(self.ui.m_bg, x, y) then
        self.touchPoint = ccp(x, y)
        return true
    end
end

function ChangeServerSearchView:onTouchEnded(x, y)
    if ccpDistance(self.touchPoint, ccp(x, y)) > 10 then return end
    self:call("closeSelf")
end

function ChangeServerSearchView:onConfirmBtnClick()
    CCSafeNotificationCenter:postNotification("ChangeServerView:search", CCString:create(tostring(self.kingdom)))
    self:call("closeSelf")
end

return ChangeServerSearchView