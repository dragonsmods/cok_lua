--[[
	新技能面板
]]

local NewActiveSkillView = class("NewActiveSkillView", function()
	return PopupBaseView:call("create")
end)

require("game.CommonPopup.NewActiveSkillHelper")
require("game.controller.NewActiveSkillController")

local PAGE_COLLECT = "collect"	--收藏
local PAGE_GENERAL = "general"	--领主
local PAGE_DRAGON = "dragon"	--龙
local PAGE_HERO = "hero"		--英雄
local PAGE_BUFF = "buff"		--增益

local Alliance_CiviSkill_Type = 1	--文明星盘技能类型

local CELL_WIDTH = 182		-- 单元格宽
local CELL_HEIGHT = 184		-- 单元格高
local itemCellH1 = 120

local SKILL_TAB_BTN_COUNT = 5 -- 技能组标签页数量
local ArtilleryBuffType = 9999

function NewActiveSkillView:ctor()
	self.page = cc.UserDefault:getInstance():getStringForKey("NewActiveSkillView_page", PAGE_GENERAL)

	self.generalEnabledId = 0
	local generalInfo = GlobalData:call("getSelfGeneralInfo")
	if generalInfo ~= nil then
		self.generalEnabledId = generalInfo:getProperty("curMapIdx")
	end
	self.generalSeletedId = self.generalEnabledId
	self.heroSeletedId = cc.UserDefault:getInstance():getIntegerForKey("NewActiveSkillView_page_hero", 1)
	self.m_skillItemId = ""
	self.extraStatus = {}
end

function NewActiveSkillView.create(param)
	local ret = NewActiveSkillView.new()
	if ret:initSelf(param) then
		return ret
	end
	return nil
end

function NewActiveSkillView:initSelf(param)
	if param then
		if param.entrance == 1 then --参数是1，表示从出征界面打开，需要根据filter_by_match_show判断是否显示该项目
			self.filter_by_match_show = 1 
		end
		if param.open_page then
			self.m_open_page = param.open_page
			self.page = self.m_open_page
		end
	end

	self:init(true, 0)
	self:setHDPanelFlag(true)

	CCLoadSprite:call("doResourceByCommonIndex", 3, true)
	CCLoadSprite:call("doResourceByCommonIndex", 5, true)
	CCLoadSprite:call("doResourceByCommonIndex", 105, true)
	CCLoadSprite:call("doResourceByCommonIndex", 500, true)
	CCLoadSprite:call("loadDynamicResourceByName", "dragonCave")
	CCLoadSprite:call("loadDynamicResourceByName", "dragonCave1")
	CCLoadSprite:call("loadDynamicResourceByName", "newHero")
	CCLoadSprite:call("loadDynamicResourceByName", "newHero_head")
	CCLoadSprite:call("loadDynamicResourceByName", "science")
	CCLoadSprite:call("loadDynamicResourceByName", "Common_209_face")
	CCLoadSprite:call("loadDynamicResourceByName", "ActiveSkill_face")

	local proxy = cc.CCBProxy:create()
	local ccbiUrl = "ActiveSkill_v3_View"

	local node = CCBReaderLoad(ccbiUrl, proxy, self)
	self:addChild(node)
	local winsize = node:getContentSize()
	self:setContentSize(winsize)
	
	self:initUI()

	local function onNodeEvent(event)
		if event == "enter" then
			self:onEnter()
		elseif event == "exit" then
			self:onExit()
		end
	end
	self:registerScriptHandler(onNodeEvent)

	self.touchLayer = cc.Layer:create()
	self:addChild(self.touchLayer)
	local function touchHandle(eventType, x, y)
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "ended" then
			self:onTouchEnded(x, y)
		end
	end
	self.touchLayer:registerScriptTouchHandler(touchHandle)
	self.touchLayer:setTouchEnabled(true)
	self.touchLayer:setSwallowsTouches(false)
	
	-- 技能收藏获取数据
	self.v_reqCount = 0
	self.scheduleReqCollection = self:getScheduler():scheduleScriptFunc(function()
			if self.v_reqCount < 5 then
				NewActiveSkillController.reqCollectionData()
				self.v_reqCount = self.v_reqCount + 1
			else
				if self.scheduleReqCollection then
					self:getScheduler():unscheduleScriptEntry(self.scheduleReqCollection)
				end
			end
		end, 1, false)

	if self.filter_by_match_show == 1 then
		self.page = self.m_open_page or PAGE_BUFF
	end
	self:updateUI()
	self:updateRedDotNum()
	
	if GuideController:call("getCurGuideID") == '3919800' then
		GuideController:call("next")
	end
	return true
end

-- 初始化界面
function NewActiveSkillView:initUI()
	self.m_titleLabel:setString(getLang("10200000")) --10200000=快捷使用

	self.m_tabLabel0:setString(getLang("180210"))	--180210=收藏
	self.m_tabLabel1:setString(getLang("169856"))	--169856=领主
	self.m_tabLabel2:setString(getLang("169858"))	--169858=龙
	self.m_tabLabel3:setString(getLang("169857"))	--169857=英雄
	self.m_tabLabel4:setString(getLang("104953"))	--104953=增益
	
	self.m_labelCollectTitle:setString(getLang("180210"))	--180210=收藏
	self.m_labelCollectTips:setString(getLang("180221"))	--180221=您还没有收藏技能，您可以在其他页签点击技能图标进行收藏。
	CCCommonUtilsForLua:setButtonTitle(self.m_btnOneKey, getLang("180217"))		--180217=一键使用

	self.m_labelTips:setString(getLang("161046"))	--161046=你暂时还没有龙，完成引导将会获得黑龙。
	
	CCCommonUtilsForLua:setButtonTitle(self.m_htabButton1, getLang("128000"))	--128000=战斗
	CCCommonUtilsForLua:setButtonTitle(self.m_htabButton2, getLang("128001"))	--128001=发展
	CCCommonUtilsForLua:setButtonTitle(self.m_htabButton3, getLang("128002"))	--128002=辅助
	
	-- 收藏
	self.m_nodeDes:setVisible(false)

    self.m_menuRootArr = {
        self.m_menuRoot0,
        self.m_menuRoot1,
        self.m_menuRoot2,
        self.m_menuRoot3,
        self.m_menuRoot4,
    }

    for _, value in ipairs(self.m_menuRootArr) do
        value:setUseTouchScale(true)
    end
end

-- 更新界面
function NewActiveSkillView:updateUI()
	self.m_iconSelect0:setVisible(self.page == PAGE_COLLECT)
	self.m_nodeCollect:setVisible(self.page == PAGE_COLLECT)

	self.m_iconSelect1:setVisible(self.page == PAGE_GENERAL)
	self.m_lordNode:setVisible(self.page == PAGE_GENERAL)

	self.m_iconSelect2:setVisible(self.page == PAGE_DRAGON)
	self.m_listNode2:setVisible(self.page == PAGE_DRAGON)

	self.m_iconSelect3:setVisible(self.page == PAGE_HERO)
	self.m_heroNode:setVisible(self.page == PAGE_HERO)

	self.m_iconSelect4:setVisible(self.page == PAGE_BUFF)
	self.m_listNode4:setVisible(self.page == PAGE_BUFF)

	if self.page == PAGE_GENERAL then	--领主
		self:initGeneralData()
		local _offset = 0
		local _size = self.m_listNode1:getContentSize()
		if self.generalSeletedId == self.generalEnabledId then
			_offset = self.m_nodeLordBottom:getContentSize().height
			_size = cc.size( _size.width, _size.height + _offset)
			self.m_nodeLordBottom:setVisible(false)
		else
			self.m_nodeLordBottom:setVisible(true)
		end
		self.m_generalTableView:setPositionY(-_offset)
		self.m_generalTableView:setContentSize(_size)
		self.m_generalTableView:reloadData()			
		self.m_generalTableView:setContentOffset(cc.p(0, self.m_listNode1:getContentSize().height + _offset - self.m_generalTableView:getContentSize().height))

		-- 改成新的标签按钮
		for i = 1, SKILL_TAB_BTN_COUNT do
			self.m_btn_tab_arr[i]:setEnabled(self.generalSeletedId ~= i-1)
			self.m_spr_clicked_arr[i]:setVisible(self.generalSeletedId == i-1)
		end

		self.m_redDotNode1:setVisible(false)
	elseif self.page == PAGE_DRAGON then	-- 龙
		self:initDragonData()
		if #self.dragonDataGroup > 0 and #self.dragonDataGroup[1] > 0 then
			self.m_labelTips:setVisible(false)
			self.m_dragonTableView:reloadData()
			self.m_dragonTableView:setContentOffset(cc.p(0, self.m_listNode2:getContentSize().height - self.m_dragonTableView:getContentSize().height))
		else
			self.m_labelTips:setVisible(true)
		end

		self.m_redDotNode2:setVisible(false)
	elseif self.page == PAGE_HERO then		-- 英雄
		self:initHeroData()
		self.m_heroTableView:reloadData()
		self.m_heroTableView:setContentOffset(cc.p(0, self.m_listNode3:getContentSize().height - self.m_heroTableView:getContentSize().height))
	
		self.m_htabButton1:setEnabled(self.heroSeletedId ~= 1)
		self.m_htabButton2:setEnabled(self.heroSeletedId ~= 2)
		self.m_htabButton3:setEnabled(self.heroSeletedId ~= 3)

		self.m_redDotNode3:setVisible(false)
	elseif self.page == PAGE_COLLECT then	-- 收藏
		self:initDragonData()
		self:initCollectData()
		local _count = self:updateCollectRate(  )
		self.m_collectTableView:reloadData()
		self.m_collectTableView:setContentOffset(cc.p(0, self.m_listNode0:getContentSize().height - self.m_collectTableView:getContentSize().height))
		if _count > 0 then
			self.m_labelCollectTips:setVisible(false)
			self.m_btnOneKey:setEnabled(true)
		else
			self.m_labelCollectTips:setVisible(true)
			self.m_btnOneKey:setEnabled(false)
		end
	elseif self.page == PAGE_BUFF then 		-- 增益
		self:initBuffData()
		if #self.buffDataGroup > 0 and #self.buffDataGroup[1] > 0 then
			self.m_labelTips4:setVisible(false)
			self.m_buffTableView:reloadData()
			self.m_buffTableView:setContentOffset(cc.p(0, self.m_listNode4:getContentSize().height - self.m_buffTableView:getContentSize().height))
		else
			self.m_labelTips4:setVisible(true)
		end
	end
end

--更新红点
function NewActiveSkillView:updateRedDotNum()
	local generalRedDot = require("game.CommonPopup.NewActiveSkillHelper"):getSkillCountByType(0)
	local dragonRedDot = require("game.CommonPopup.NewActiveSkillHelper"):getSkillCountByType(1)
	local heroRedDot = require("game.CommonPopup.NewActiveSkillHelper"):getSkillCountByType(2)

	self.m_redDotNode1:setVisible(generalRedDot > 0)
	self.m_redDotNode2:setVisible(dragonRedDot > 0)
	self.m_redDotNode3:setVisible(heroRedDot > 0)

	self.m_redDotText1:setString(tostring(generalRedDot))
	self.m_redDotText2:setString(tostring(dragonRedDot))
	self.m_redDotText3:setString(tostring(heroRedDot))
end

--清理数据
function NewActiveSkillView:clearHelpSkill()
	if self.page == PAGE_GENERAL then
		require("game.CommonPopup.NewActiveSkillHelper"):clearSkillByType(0)
	elseif self.page == PAGE_DRAGON then
		require("game.CommonPopup.NewActiveSkillHelper"):clearSkillByType(1)
	elseif self.page == PAGE_HERO then
		require("game.CommonPopup.NewActiveSkillHelper"):clearSkillByType(2)
	end
end

-- 消息回调更新界面
function NewActiveSkillView:updateUICallback()
	if self.scheduleReqCollection then
		self:getScheduler():unscheduleScriptEntry(self.scheduleReqCollection)
	end
		
	self:updateUI()
end

-- 更新收藏比率
function NewActiveSkillView:updateCollectRate(  )
	if self.page == PAGE_COLLECT then
		local _count, _maxCount = NewActiveSkillController:getCount()
		self.m_labelCollectRate:setString(getLang("176193", _count, _maxCount))	--176193={0}/{1}
		return _count
	end
	return 0
end

function NewActiveSkillView:updateKingBiographySkill(dict)
	local tbl = dictToLuaTable(dict)
	if tbl and tbl.skills then
		local skills = tbl.skills
		local generalInfo = GlobalData:call("getSelfGeneralInfo")
		if skills and #skills > 0 then
			for k, v in pairs(skills) do
				v.id = generalInfo:call("getAbilityBySkillId", v.skillId, self.generalSeletedId)
				v[v.skillId] = v.level
			end

			local list = luaToArray(skills)
			-- 列王传技能，五个技能页都要更新
			for i = 0, 4 do
				generalInfo:call("setAbilityByIdx", list, i)
			end
			GeneralManager:call("updateSkillData",list)
			-- 刷新界面
			self:updateUI()
		end
	end
end

function NewActiveSkillView:pushPop()
	self:retain()
    PopupViewController:call("removePopupView", self)
    PopupViewController:call("pushPop", self, true)
    self:release()
end

function NewActiveSkillView:updateExtra(param)
	if param:objectForKey("extraStatus") then
		self.extraStatus = {}
		
		local extraStatus = arrayToLuaTable(param:objectForKey("extraStatus"))
		for _, status in ipairs(extraStatus) do
			self.extraStatus[status.id] = atoi(status.effect)
		end
	end
end

function NewActiveSkillView:reqStatusItem()
	self.onlyRefreshExtra = true

	local buff_cmd = require("game.command.ShowStatusItemCmd").create(nil)
	buff_cmd:send()
end

function NewActiveSkillView:onEnter()
	-- General begin
	local function onGetChangeBack( dict )
		if nil == dict then
			return
		end

		local generalInfo = GlobalData:call("getSelfGeneralInfo")
		if nil == generalInfo then
			return
		end

		if dict:objectForKey("gold") then
			GlobalData:call("shared"):call("getPlayerInfo"):setProperty("gold", dict:valueForKey("gold"):intValue())
			CCSafeNotificationCenter:call("postNotification", "city_resources_update")
			local dictTable = dictToLuaTable(dict)
			local infoDic = dictTable["infoDic"]
			if infoDic ~= nil and infoDic["page"] ~= nil then
				local page = tonumber(infoDic["page"])
				if page ~= nil then
					generalInfo:setProperty("curMapIdx", page-1)
				end
			end

			GeneralManager:call("resetGeneralSkillEffectValue")
			GeneralManager:call("resetSkillCDMap")

			--updateUI
			CCSafeNotificationCenter:call("postNotification", "GeneralSkillSwitch_back_2", dict)
		end

		self.generalEnabledId = generalInfo:getProperty("curMapIdx")
		if self.page == PAGE_GENERAL then
			self:updateUI()
		end
	end
	local handler1 = self:registerHandler(onGetChangeBack)
	CCSafeNotificationCenter:call("registerScriptObserver", self, handler1, "GeneralSkillSwitch_back")

	local function onGetMsgUseSkillCmdSuccess( ref )
		self:successCallBack(ref)
	end
	local handler1 = self:registerHandler(onGetMsgUseSkillCmdSuccess)
	CCSafeNotificationCenter:call("registerScriptObserver", self, handler1, "msg_useskillcmd_success")

	local function onGetMsgUseSkillCmdFail( ref )
		self:failCallBack(ref)
	end
	local handler1 = self:registerHandler(onGetMsgUseSkillCmdFail)
	CCSafeNotificationCenter:call("registerScriptObserver",self, handler1, "msg_useskillcmd_fail")

	local function onGetCancelCmdBack( ref )
		self:onRetCancelSkill(ref)
	end
	local handler1 = self:registerHandler(onGetCancelCmdBack)
	CCSafeNotificationCenter:call("registerScriptObserver",self, handler1, "msg_cancelskillcmd_back")

	-- General end

	-- Dragon begin
	local function onDragonSkillData()
		if self.page == PAGE_DRAGON then
			self:updateUI()
		end
	end

	local handler2 = self:registerHandler(onDragonSkillData)
	CCSafeNotificationCenter:call("registerScriptObserver", self, handler2, "msg_dragonactiveskill_data_back")

	-- Dragon end

	-- 增益
	local function onUpdateBuffInfo(param)
		self:updateExtra(param)
		
		if self.page == PAGE_BUFF and not self.onlyRefreshExtra then
			self:updateUI()
		end
	end
	local buff_handler = self:registerHandler(onUpdateBuffInfo)
	CCSafeNotificationCenter:registerScriptObserver(self, buff_handler, "status.item.refresh")

	local buff_cmd = require("game.command.ShowStatusItemCmd").create(nil)
	buff_cmd:send()

	local function callback1(pObj) self:pushPop(pObj) end
	local handler3 = self:registerHandler(callback1)
	CCSafeNotificationCenter:registerScriptObserver(self, handler3, "MSG_NEW_SKILL_PUSHPOP")

	registerScriptObserver(self, self.reqStatusItem, MessageType.MSG_SEND_BATTLE_VIEW_BUFF_CMD)
	registerScriptObserver(self, self.onCloseButtonClick, 'ActiveSkillView.onCloseClick')
	registerScriptObserver(self, self.updateUICallback, 'ActiveSkillView.updateUICallback')
	registerScriptObserver(self, self.updateCollectRate, 'ActiveSkillView.updateCollectRate')
	registerScriptObserver(self, self.updateKingBiographySkill, 'ActiveSkillView.updateKingBiographySkill')
	registerScriptObserver(self, self.updateRedDotNum, "msg.skill.dot")
	NewKingBiographySkillListCommand.new():send()
end

function NewActiveSkillView:onExit()
	self:clearHelpSkill()

	cc.UserDefault:getInstance():setStringForKey("NewActiveSkillView_page", self.page)
	cc.UserDefault:getInstance():setIntegerForKey("NewActiveSkillView_page_hero", self.heroSeletedId)

	for i, v in ipairs(self.dragonDataGroupState or {}) do
		cc.UserDefault:getInstance():setIntegerForKey("NewActiveSkillView_page_dragon_" .. v.id, v.state)
	end

	-- 增益存储
	for i, v in ipairs(self.buffDataGroupState or {}) do
		cc.UserDefault:getInstance():setIntegerForKey("NewActiveSkillView_page_buff_" .. v.id, v.state)
	end

	if self.scheduleReqCollection then
		self:getScheduler():unscheduleScriptEntry(self.scheduleReqCollection)
	end
	unregisterScriptObserver(self, MessageType.MSG_SEND_BATTLE_VIEW_BUFF_CMD)
	unregisterScriptObserver(self, 'ActiveSkillView.onCloseClick')
	unregisterScriptObserver(self, 'ActiveSkillView.updateUICallback')
	unregisterScriptObserver(self, 'ActiveSkillView.updateCollectRate')
	unregisterScriptObserver(self, 'ActiveSkillView.updateKingBiographySkill')
	unregisterScriptObserver(self, "msg.skill.dot")
	CCSafeNotificationCenter:call("unregisterScriptObserver", self, "MSG_NEW_SKILL_PUSHPOP")
	CCSafeNotificationCenter:call("unregisterScriptObserver", self, "GeneralSkillSwitch_back")
	CCSafeNotificationCenter:call("unregisterScriptObserver", self, "msg_useskillcmd_success")
	CCSafeNotificationCenter:call("unregisterScriptObserver", self, "msg_useskillcmd_fail")
	CCSafeNotificationCenter:call("unregisterScriptObserver", self, "msg_cancelskillcmd_back")
	CCSafeNotificationCenter:call("unregisterScriptObserver", self, "msg_dragonactiveskill_data_back")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "status.item.refresh")
end

function NewActiveSkillView:onTouchBegan(x, y)
	if self.m_nodeDes:isVisible() then
		if (not isTouchInside(self.m_desBg, x, y)) then
			self.selectedId = nil
			self.m_nodeDes:setVisible(false)
		end
		-- 点击收藏/取消收藏
		if isTouchInside(self.m_btnCollect, x, y) then
			if self.v_cellId then
				self.selectedId = nil
				self.m_nodeDes:setVisible(false)
				NewActiveSkillController:reqChangeCollectState(self.page, self.v_cellId)
			end
			return false
		end
	end

	self.startTouchPt = cc.p(x, y)

    local page = self.page
    if isTouchInside(self.m_touchNode1, self.startTouchPt.x, self.startTouchPt.y) and isTouchInside(self.m_touchNode1, x, y) then
        self.m_menuRootArr[2]:setTouchScaled(true)
    elseif isTouchInside(self.m_touchNode2, self.startTouchPt.x, self.startTouchPt.y) and isTouchInside(self.m_touchNode2, x, y) then
        self.m_menuRootArr[3]:setTouchScaled(true)
    elseif isTouchInside(self.m_touchNode3, self.startTouchPt.x, self.startTouchPt.y) and isTouchInside(self.m_touchNode3, x, y) then
        self.m_menuRootArr[4]:setTouchScaled(true)
    elseif isTouchInside(self.m_touchNode0, self.startTouchPt.x, self.startTouchPt.y) and isTouchInside(self.m_touchNode0, x, y) then
        self.m_menuRootArr[1]:setTouchScaled(true)
    elseif isTouchInside(self.m_touchNode4, self.startTouchPt.x, self.startTouchPt.y) and isTouchInside(self.m_touchNode4, x, y) then
        self.m_menuRootArr[5]:setTouchScaled(true) -- 增益
    end

	return true
end

function NewActiveSkillView:onTouchEnded(x, y)
	if not isTouchInside(self.m_bg, self.startTouchPt.x, self.startTouchPt.y) then
		self:onCloseButtonClick()
		return
	end

    for _, value in ipairs(self.m_menuRootArr) do
        value:setTouchScaled(false)
    end

	local page = self.page
	if isTouchInside(self.m_touchNode1, self.startTouchPt.x, self.startTouchPt.y) and isTouchInside(self.m_touchNode1, x, y) then
		page = PAGE_GENERAL
	elseif isTouchInside(self.m_touchNode2, self.startTouchPt.x, self.startTouchPt.y) and isTouchInside(self.m_touchNode2, x, y) then
		page = PAGE_DRAGON
	elseif isTouchInside(self.m_touchNode3, self.startTouchPt.x, self.startTouchPt.y) and isTouchInside(self.m_touchNode3, x, y) then
		page = PAGE_HERO
	elseif isTouchInside(self.m_touchNode0, self.startTouchPt.x, self.startTouchPt.y) and isTouchInside(self.m_touchNode0, x, y) then
		page = PAGE_COLLECT
	elseif isTouchInside(self.m_touchNode4, self.startTouchPt.x, self.startTouchPt.y) and isTouchInside(self.m_touchNode4, x, y) then
		page = PAGE_BUFF -- 增益
	end
	if self.page ~= page and FunOpenController:isUnlock(string.format("book_%s", page), true) then
		self:clearHelpSkill()
		self.page = page
		self:updateUI()
	end
end

function NewActiveSkillView:onTouchGrid(cell)
	if cell == nil then
		return
	end
	self.v_cellId = cell.id
	if self.selectedId ~= self.v_cellId then
		self.selectedId = self.v_cellId
	end

	if self.m_nodeDes:isVisible() == false then
		self.m_nodeDes:setVisible(true)

		local _title = ""
		local _desc = ""

		local _page = nil
		if self.page == PAGE_COLLECT then
			if cell.v_type == 0 then		--0是领主技能
				_page = PAGE_GENERAL
			elseif cell.v_type == 1 then	--1是龙技能
				_page = PAGE_DRAGON
			elseif cell.v_type == 2 then	--2是英雄技能
				_page = PAGE_HERO
			end
		end

		if self.page == PAGE_GENERAL or _page == PAGE_GENERAL then
			_title = getLang(CCCommonUtilsForLua:call("getPropById", self.v_cellId, "name"))
			local _dialog = CCCommonUtilsForLua:call("getPropById", self.v_cellId, "description")
			local _base = CCCommonUtilsForLua:call("getPropById", self.v_cellId, "base")
			local _type = math.tonumber(CCCommonUtilsForLua:call("getPropById", self.v_cellId, "type"))
			local _cdinfo = GeneralManager:call("getSkillCDInfoById", self.v_cellId)

			if _cdinfo then
				local skillType = _cdinfo:getProperty("type")
				if skillType == Alliance_CiviSkill_Type then
					local civiBase = require("game.allianceTerritory.civiMiracle.CiviMiracleManager").getSkillCiviBase(self.selectedId)
					if civiBase then _base = civiBase end
				end
			end
			if _type == 12 or _type == 13 or _type == 15 then
				_desc = getLang(_dialog, _base)
			elseif _type == 14 then
				local ta = string.split(_base, "|")
				if #ta == 2 then
					_desc = getLang(_dialog, ta[1], ta[2])
				end
			else
				local GeneralManagerIns = require("game.general.GeneralManagerIns").getInstance()
				local dis_value = GeneralManagerIns:getSkillDisvalueById(self.v_cellId)
				if dis_value then
					local descPercent = CCCommonUtilsForLua:call("getPropById",  self.v_cellId, "desc_num_percent")
					if descPercent == "1" then
						dis_value = dis_value.."%"
					end
					_desc = getLang(_dialog, dis_value)
				else
					_desc = getLang(_dialog)
				end
			end
		elseif self.page == PAGE_DRAGON or _page == PAGE_DRAGON then
			if DragonActiveSkillManagerNew.getInstance():isNewSkillType(self.v_cellId) then
				_title = getLang(CCCommonUtilsForLua:call("getPropByIdGroup","dragon_skill",self.v_cellId,"name"))
				_desc = DragonActiveSkillManagerNew.getInstance():getDescInBook(self.v_cellId)
			else
				local data = DragonActiveSkillManager.getInstance():getDataById(self.v_cellId)
				if nil == data then
					return
				end
				_title = data:getName()
				_desc = data:getDescriptionByLevel(data:getLevel())
			end
		elseif self.page == PAGE_HERO or _page == PAGE_HERO then
			local info = HeroManager.getActiveSkillInfoById(self.v_cellId)
			if nil == info then
				return
			end
			_title = info:getName()
			_desc = info:getDesStr()
		end

		if NewActiveSkillController:isCollected(self.v_cellId) then
			self.m_labelCollect:setString(getLang('180212'))	--180212=取消收藏
		else
			self.m_labelCollect:setString(getLang('180211'))	--180211=添加收藏
		end
		-- 设置标题
		self.m_labelDesTitle:setString(_title)
		if self.m_txtDes then
			self.m_txtDes:setString(_desc)
		else
			self.m_listViewDes = cc.ScrollView:create()
			self.m_listViewDes:setViewSize(self.m_nodeListDes:getContentSize())
			self.m_listViewDes:ignoreAnchorPointForPosition(true)
			self.m_listViewDes:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
			self.m_listViewDes:setClippingToBounds(true)
			self.m_listViewDes:setBounceable(true)
			self.m_nodeListDes:addChild(self.m_listViewDes)

			self.m_txtDes = cc.Label:createWithSystemFont(_desc, "Helvetica", 16, cc.size(self.m_nodeListDes:getContentSize().width - 4,0))
			self.m_txtDes:setColor(cc.c3b(184, 172, 132))
			self.m_txtDes:setPositionX(3)
			self.m_listViewDes:addChild(self.m_txtDes)
		end
		self.m_listViewDes:setContentSize(self.m_txtDes:getContentSize())
		self.m_listViewDes:setContentOffset(cc.p(0, self.m_nodeListDes:getContentSize().height - self.m_txtDes:getContentSize().height))

		local posx = 0
		local posy = 0
		local th = self.m_desBg:getContentSize().height
		local wp = cell.m_iconNode:convertToWorldSpace(cc.p(0, 0))

		local _nodeList = self.m_listNode1
		if self.page == PAGE_DRAGON then
			_nodeList = self.m_listNode2
		elseif self.page == PAGE_HERO then
			_nodeList = self.m_listNode3
		elseif self.page == PAGE_COLLECT then
			_nodeList = self.m_listNode0
		end
		local pos = _nodeList:convertToNodeSpace(wp)
		if pos.x > _nodeList:getContentSize().width * 0.5 + 20 then
			posx = 410
		elseif pos.x < _nodeList:getContentSize().width * 0.5 - 20 then
			posx = 135
		else 
			posx = _nodeList:getContentSize().width * 0.5
		end
		posy = pos.y + th * 0.5 + 60
		if self.page == PAGE_GENERAL then
			posy = posy + th - 20
		elseif self.page == PAGE_COLLECT then
			posy = posy + th - 40
		end
		self.m_nodeDes:setPosition(cc.p(posx, posy))
	end
end

-- 点击关闭按钮
function NewActiveSkillView:onCloseButtonClick()
	self:call("closeSelf")
end

-- 点击一键使用
function NewActiveSkillView:onClickBtnOneKey( )
	if self.page == PAGE_COLLECT then
		NewActiveSkillController:reqOneKeyUse()
	end
end

function NewActiveSkillView:successCallBack( ref )
	if nil == ref then
		return
	end

	local id = ref:valueForKey("cacheSkillId"):getCString()
	if id ~= self.selectedId then
		return
	end
	local skillType = atoi(CCCommonUtilsForLua:call("getPropById", self.selectedId, "type"))
	local tip = ""
	if skillType == 10 then
		PopupViewController:call("removeAllPopupView")
		SceneController:call("gotoScene", 11)
		return
	elseif skillType == 11 then
		-- 118002=获得了救援效果，当你的部队下一次在城堡外发生战斗时优先产生伤兵。
		CCCommonUtilsForLua:call("flyText", getLang("118002"))
	elseif skillType == 21 then
		-- 150812=技能已激活，下次攻击敌方城堡的队伍将会与对方决斗。被攻击方援助无效，双方损失的兵将直接死亡。
		CCCommonUtilsForLua:call("flyText", getLang("150812"))
	elseif skillType == 12 then
		local para1 = CCCommonUtilsForLua:call("getPropById", self.selectedId, "para1")
		local param1 = atoi(para1)
		local outPutSec = param1 * 60 * 60
		local harvestInfo = string.format("%s|2350|70", tostring(outPutSec))
		GlobalData:call("shared"):setProperty("m_harvestInfo", harvestInfo)

		local currentSceneId = SceneController:call("getCurrentSceneId")
		if currentSceneId ~= SCENE_ID_MAIN then
			local world = WorldMapView:call("instance")
			if world then
				world:call("leaveWorld")
			else 
				SceneController:call("gotoScene", SCENE_ID_MAIN)
			end
		else
			CCSafeNotificationCenter:call("postNotification", "msg_change_scence_and_show_harvest")
		end

		tip = getLang("118001")
	elseif skillType == 13 then
	elseif skillType == 14 then
		CCCommonUtilsForLua:call("flyText", getLang("118003"))
	elseif skillType == 15 then
		local fortInfo = ""
		if ref:objectForKey("trap") then
			local trap = ref:objectForKey("trap")
			if trap and trap:objectForKey("id") and trap:objectForKey("free") then
				local str = trap:valueForKey("free"):getCString()
				if str ~= "" then
					fortInfo = trap:valueForKey("id"):getCString() .. "|" .. trap:valueForKey("free"):getCString()
				end
			end
		end
		GlobalData:call("shared"):setProperty("m_skillFortInfo", fortInfo)
		local currentSceneId = SceneController:call("getCurrentSceneId")
		if currentSceneId ~= SCENE_ID_MAIN then
			local world = WorldMapView:call("instance")
			if world then
				world:call("leaveWorld")
			else
				SceneController:call("gotoScene", SCENE_ID_MAIN)
			end
		else
			CCSafeNotificationCenter:call("postNotification", "msg_show_fort_skill_effect")
		end

		if ref:objectForKey("trap") then
			local trap = ref:objectForKey("trap")
			if trap and trap:objectForKey("id") and trap:objectForKey("free") then
				local str = trap:valueForKey("free"):getCString()
				if str ~= "" then
					local getCount = trap:valueForKey("free"):intValue()
					local addPower = 0
					local fortInfo = GlobalData:call("getArmyInfoById", trap:valueForKey("id"):getCString())
					if fortInfo then
						addPower = getCount * fortInfo:getProperty("power")
						addPower = math.max(addPower, 0)
						GlobalData:call("getPlayerInfo"):setProperty("fortPower", GlobalData:call("getPlayerInfo"):getProperty("fortPower") + addPower)
					end
					GlobalData:call("getPlayerInfo"):setProperty("addPower", addPower)
					CCSafeNotificationCenter:call("postNotification", "msg_collect_soldier_add_power")
				end
			end
		end
	elseif skillType == 18 or skillType == 19 then
		ToolController:call("retUseTool", ref)
	elseif skillType == 20 then
		if ref:objectForKey("itemEffectObj") then
			local effectObj = ref:objectForKey("itemEffectObj")
			if effectObj and effectObj:objectForKey("stamina") then
				CCSafeNotificationCenter:call("postNotification", "msg_stamine_add_eff")
				WorldController:call("getInstance"):setProperty("currentStamine", effectObj:valueForKey("stamina"):intValue())
				WorldController:call("getInstance"):setProperty("lastStamineTime", effectObj:valueForKey("lastStaminaTime"):doubleValue())
				CCSafeNotificationCenter:call("postNotification", "msg_currentStamine")
			end
		end
	elseif skillType == 23 then
		if ref and ref:objectForKey("reward") then
			local arr = ref:objectForKey("reward")
			if nil ~= arr then
				PortActController:call("flyReward", arr, true)
				local rwdInfo = RewardController:call("retReward", arr)
				CCCommonUtilsForLua:call("flyHint", "", "", rwdInfo)
			end
		end
		if ref:objectForKey("stamina") then
			CCSafeNotificationCenter:call("postNotification", "msg_stamine_add_eff")
			local dicTemp = ref:objectForKey("stamina")
			WorldController:call("getInstance"):setProperty("currentStamine", dicTemp:valueForKey("stamina"):intValue())
			WorldController:call("getInstance"):setProperty("lastStamineTime", dicTemp:valueForKey("lastStaminaTime"):doubleValue())
			CCSafeNotificationCenter:call("postNotification", "msg_currentStamine")
		end
	elseif skillType == 27 then --更新其他技能CD时间
		--领主技能CD更新 
		if ref:objectForKey("userSkArr") then
			local list = ref:objectForKey("userSkArr")
			GeneralManager:call("updateSkillData",list)
		end

		--英雄技能CD更新	
		if ref:objectForKey("newGenSkArr") then
			local list = ref:objectForKey("newGenSkArr")
			local data = arrayToLuaTable(list)
			local refreshTbl = {}
			for _,v in pairs(data or {}) do
				local heroId = v.ownerId
				if nil == refreshTbl[heroId] then
					refreshTbl[heroId] = {}
				end				
				local skillInfo = {skillId = v.skillId, endTime = v.endTime, state = v.state, actTime = v.actTime}
				table.insert( refreshTbl[heroId], skillInfo )				
			end
			for k,v in pairs(refreshTbl) do
				HeroManager.refreshSkillInfo(k, {skillInfo=v})
			end
		end
	elseif skillType == 28 then --年兽次数增加
		if ref:objectForKey("remainAttackTime") then
			local time = ref:valueForKey("remainAttackTime"):intValue()
			local lordInfo = GlobalData:call("shared"):getProperty("lordInfo")
			if lordInfo then
				lordInfo:setProperty("remainAttackTime",time)
			end
		end
	end

	if string.isNilOrEmpty(tip) == false then
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("118001"))	--118001=技能使用成功
	end

	if skillType ~= 11 and skillType ~= 14 and skillType ~= 21 and skillType ~= 27 then
		PopupViewController:call("removeAllPopupView")
	else
		self:updateUI()
	end
end

function NewActiveSkillView:onRetCancelSkill( ref )
	if nil == ref then
		return
	end
	local skillId = ref:getCString()
	if skillId ~= self.selectedId then
		return
	end
	self:updateUI()
end

function NewActiveSkillView:failCallBack( ref )
	if nil == ref then
		return
	end
	local id = ref:valueForKey("cacheSkillId"):getCString()
	if id ~= self.selectedId then
		return
	end
	self:updateUI()
end

-- ---------------------------------------------------------------------------------------
-- Collect begin
function NewActiveSkillView:initCollectData(  )
	if self._initCollectData == nil then
		self._initCollectData = true
		self.m_collectTableView = Drequire("game.utility.TableViewMultiCol").new(self.m_listNode0:getContentSize())
		self.m_collectTableView:setDirection(kCCScrollViewDirectionVertical)
		self.m_collectTableView:setVerticalFillOrder(kCCTableViewFillTopDown)
		self.m_listNode0:addChild(self.m_collectTableView)
		local _collectDelegate = {}
		_collectDelegate.numberOfCellsInTableView = function(table) return self:collectNumberOfCellsInTableView(table) end
		_collectDelegate.numberOfGridsInCell = function(table) return self:collectNumberOfGridsInCell(table) end
		_collectDelegate.gridAtIndex = function(table, idx) return self:collectGridAtIndex(table, idx) end
		_collectDelegate.gridSizeForTable = function(table, idx) return self:collectGridSizeForTable(table, idx) end
		self.m_collectTableView:setDelegate(_collectDelegate)
	end

	self.v_collectData = {}
	local _dragonSkillCount = 0
	if self.dragonDataGroup then
		_dragonSkillCount = #self.dragonDataGroup
	end
	for k,v in pairs(NewActiveSkillController:getData() or {}) do
		if v.state == 1 then
			if v.type ~= 2 or _dragonSkillCount > 0 then
				table.insert(self.v_collectData, v)
			end
		end
    end

	table.sort( self.v_collectData, function (a, b)
		local _nowWorldTime = GlobalData:call("getWorldTime")

		local _isActiveA = false
		local _isInCD_A = false
		if a.type == 0 then--0是领主技能
			local _generalInfo = GlobalData:call("getSelfGeneralInfo")
			if _generalInfo then
				_isActiveA = _generalInfo:call("checkHaveStudy", a.id, self.generalEnabledId)
				if _isActiveA then
					local _cdinfo = GeneralManager:call("getSkillCDInfoById", a.id)
					
					local _gapTime = 0
					local _effectTime = 0
					if _cdinfo and _cdinfo:getProperty("endTime") ~= 0 then
						_gapTime = _cdinfo:getProperty("endTime") - _nowWorldTime
						if _cdinfo:getProperty("effectEndTime") ~= 0 then
							_effectTime = _cdinfo:getProperty("effectEndTime") - _nowWorldTime
						end
					end
					_isInCD_A = _gapTime > 0 or _effectTime > 0
				end
			end
		elseif a.type == 1 then--1是龙技能
			local _data = DragonActiveSkillManager.getInstance():getDataById(a.id)
			if _data then
				_isActiveA = _data:getIsUnLocked()
				if _isActiveA then
					_isInCD_A = _data:isActive() or _data:isInCD()
				end
			end
		elseif a.type == 2 then--1是英雄技能
			local _info = HeroManager.getActiveSkillInfoById(a.id)
			if _info then
				_isActiveA = _info:isObtain()
				if _isActiveA then
					_isInCD_A = _info:isActive() or _info:isInCD()
				end
			end
		end

		local _isActiveB = false
		local _isInCD_B = false
		if b.type == 0 then	--0是领主技能
			local _generalInfo = GlobalData:call("getSelfGeneralInfo")
			if _generalInfo then
				_isActiveB = _generalInfo:call("checkHaveStudy", b.id, self.generalEnabledId)
				if _isActiveB then
					local _cdinfo = GeneralManager:call("getSkillCDInfoById", b.id)
					
					local _gapTime = 0
					local _effectTime = 0
					if _cdinfo and _cdinfo:getProperty("endTime") ~= 0 then
						_gapTime = _cdinfo:getProperty("endTime") - _nowWorldTime
						if _cdinfo:getProperty("effectEndTime") ~= 0 then
							_effectTime = _cdinfo:getProperty("effectEndTime") - _nowWorldTime
						end
					end
					_isInCD_B = _gapTime > 0 or _effectTime > 0
				end
			end
		elseif b.type == 1 then--1是龙技能
			local _data = DragonActiveSkillManager.getInstance():getDataById(b.id)
			if _data then
				_isActiveB = _data:getIsUnLocked()
				if _isActiveB then
					_isInCD_B = _data:isActive() or _data:isInCD()
				end
			end
		elseif b.type == 2 then--2是英雄技能
			local _info = HeroManager.getActiveSkillInfoById(b.id)
			if _info then
				_isActiveB = _info:isObtain()
				if _isActiveB then
					_isInCD_B = _info:isActive() or _info:isInCD()
				end
			end
		end

		if _isActiveA and _isActiveB then
			if _isInCD_A == _isInCD_B then
				if a.type < b.type then
					return true
				end
			elseif (not _isInCD_A) and (_isInCD_B) then
				return true
			end
			
		elseif _isActiveA and (not _isActiveB) then
			return true
		end

        return false
    end)
end

function NewActiveSkillView:collectNumberOfCellsInTableView(table)
	return math.ceil(#self.v_collectData / 3)
end

function NewActiveSkillView:collectNumberOfGridsInCell(table)
	return 3
end

function NewActiveSkillView:collectGridAtIndex(table, idx)
	idx = idx + 1
	if (idx > #self.v_collectData) then
		return nil
	end

	local grid = table:dequeueGrid()
	local _item = self.v_collectData[idx]

	if grid then
		grid:setData(_item)
	else
		grid = Drequire("game.CommonPopup.NewActiveSkillCollectGrid").new(_item,self)
	end

	return grid
end

function NewActiveSkillView:collectGridSizeForTable(table, idx)
	return CELL_WIDTH, CELL_HEIGHT
end

-- ---------------------------------------------------------------------------------------
-- General begin
function NewActiveSkillView:initGeneralData()
	if self._initGeneralData then
		return
	end
	self._initGeneralData = true

	local _size = self.m_listNode1:getContentSize()
	self.m_generalTableView = Drequire("game.utility.TableViewMultiCol").new(_size)
	self.m_generalTableView:setDirection(kCCScrollViewDirectionVertical)
	self.m_generalTableView:setVerticalFillOrder(kCCTableViewFillTopDown)
	self.m_listNode1:addChild(self.m_generalTableView)
	local generalDelegate = {}
	generalDelegate.numberOfCellsInTableView = function(table) return self:generalNumberOfCellsInTableView(table) end
	generalDelegate.numberOfGridsInCell = function(table) return self:generalNumberOfGridsInCell(table) end
	generalDelegate.gridAtIndex = function(table, idx) return self:generalGridAtIndex(table, idx) end
	generalDelegate.gridSizeForTable = function(table, idx) return self:generalGridSizeForTable(table, idx) end
	self.m_generalTableView:setDelegate(generalDelegate)
	if self.generalSeletedId == self.generalEnabledId then
		_size = cc.size( _size.width + self.m_nodeLordBottom:getContentSize().width, _size.height + self.m_nodeLordBottom:getContentSize().height)
		self.m_generalTableView:setContentSize(_size)
		self.m_generalTableView:setPositionY(-self.m_nodeLordBottom:getContentSize().height)
		self.m_nodeLordBottom:setVisible(false)
	else
		self.m_nodeLordBottom:setVisible(true)
	end
	self.m_labelLordDes:setString(getLang("175228"))	--175228=该技能组尚未激活，激活后才可以使用
	CCCommonUtilsForLua:setButtonTitle(self.m_btnLordActive, getLang("190054"))		--190054=激活

	-- 初始化解锁检测条件
	self:initCastleCondition()
	self:initVipCondition()
	self:initSvipCondition()
	self:initNewSkillChangeBtn()

	self.generalData = {}
	local data = CCCommonUtilsForLua:getGroupByKey("sk")
	for k, v in pairs(data) do
		if atoi(v.type) >= 10 then
			self.generalData[#self.generalData + 1] = k
		end
	end

	table.sort(self.generalData, function(k1, k2)
		return data[k1].activeskill_index < data[k2].activeskill_index
	end)

	local generalInfo = GlobalData:call("getSelfGeneralInfo")
	if generalInfo ~= nil then
		local obtainTable = {}
		for i, v in ipairs(self.generalData) do
			obtainTable[v] = generalInfo:call("checkHaveStudy", v, self.generalSeletedId)
		end
		table.sort(self.generalData, function(id1, id2)
			return obtainTable[id1] == true and obtainTable[id2] == false
		end)
	end
end

function NewActiveSkillView:generalNumberOfCellsInTableView(table)
	return math.ceil(#self.generalData / 3)
end

function NewActiveSkillView:generalNumberOfGridsInCell(table)
	return 3
end

function NewActiveSkillView:generalGridAtIndex(table, idx)
	idx = idx + 1
	if (idx > #self.generalData) then
		return nil
	end

	local grid = table:dequeueGrid()
	local id = self.generalData[idx]

	if grid then
		grid:setData(id)
	else
		grid = Drequire("game.CommonPopup.NewActiveSkillGeneralGrid").new(id,self)
	end

	return grid
end

function NewActiveSkillView:generalGridSizeForTable(table, idx)
	return CELL_WIDTH, CELL_HEIGHT
end

-- 2019-10-30 统一处理技能组页签切换 btn_index 范围与self.selectMapIdx一致（0-4），分别对应技能组1-5
function NewActiveSkillView:onSkillChangeImpl(btn_index)
    if self:checkCastleCondition(btn_index, true) and self:checkVipCondition(btn_index, true) and self:checkSvipCondition(btn_index, true) then
		if self.generalSeletedId ~= btn_index then
			self.generalSeletedId = btn_index
			self:initGeneralData()
			self.selectedId = ""
			if #self.generalData > 0 then
				self.selectedId =  self.generalData[1]
			end
			self:updateUI()
		end
    end
end

function NewActiveSkillView:onSkillGroupChange1()
    -- 检测城堡、vip、svip条件
    self:onSkillChangeImpl(0)
end

function NewActiveSkillView:onSkillGroupChange2()
    -- 检测城堡、vip、svip条件
    self:onSkillChangeImpl(1)
end

function NewActiveSkillView:onSkillGroupChange3()
	self:onSkillChangeImpl(2)
end

function NewActiveSkillView:onSkillGroupChange4()
	self:onSkillChangeImpl(3)
end

function NewActiveSkillView:onSkillGroupChange5()
	self:onSkillChangeImpl(4)
end


-- 【领主】点击激活
function NewActiveSkillView:onClickBtnLordActive()
	Dprint("NewActiveSkillView:onClickBtnLordActive", self.generalSeletedId, self.generalEnabledId)
	if self.generalSeletedId ~= self.generalEnabledId then
		if GeneralManager:call("getInstance"):call("checkSkillActivating", "603100") == true then
			CCCommonUtilsForLua:call("flyHint", "", "", getLang("167018"))	--167018=您已经激活了决斗技能，无法切换天赋，请您先取消决斗技能
			return
		end

		local canActive = self:checkCastleCondition(self.generalSeletedId, true) and self:checkVipCondition(self.generalSeletedId, true) and self:checkSvipCondition(self.generalSeletedId, true)
		if not canActive then
			return
		end
		
		local idx = self.generalSeletedId -- 选中项id
		local mapSG = GlobalData:call("shared"):getProperty("generals") --map<string,GeneralInfo>
		local info = table.firstvalue(mapSG)--GeneralInfo
		local curMapIdx = info:getProperty("curMapIdx")
		local changeToNo=true
	
		local tempSuperMap = info:getProperty("generalSkillMaps")
		local firstV = tempSuperMap[idx]
		if firstV ~= nil then
			for k, v in pairs(firstV) do
				for p, q in pairs(v) do
					if q and q:getProperty("level") > 0 then
						changeToNo = false
						break
					end
				end
				if changeToNo == false then
					break
				end
			end
		end
		if (changeToNo) then
			YesNoDialog:call("showYesDialog",_lang("137655"))
		else
			local function confirm()
				local generalInfo = GlobalData:call("getSelfGeneralInfo")
				if nil == generalInfo then
					return
				end
				local cmd = myRequire("game.command.GeneralSkillSwitchCommand"):create(generalInfo:getProperty("uuid"), idx)
				cmd:send()
			end

			YesNoDialog:call("show", _lang_1("660913", CC_ITOA(idx+1)) , cc.CallFunc:create(confirm)) -- 660913=是否切换至技能组{0}
		end
	end
end
-- General end
-- ---------------------------------------------------------------------------------------
-- Dragon begin

function NewActiveSkillView:initDragonData()
	if self._initDragonData == nil then
		self._initDragonData = true

		self.m_dragonTableView = cc.TableView:create(self.m_listNode2:getContentSize())
		self.m_dragonTableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
		self.m_dragonTableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
		self.m_dragonTableView:setDelegate()
		self.m_dragonTableView:registerScriptHandler(function(table, idx) return self:dragonCellSizeForTable(table, idx) end, cc.TABLECELL_SIZE_FOR_INDEX)
		self.m_dragonTableView:registerScriptHandler(function(table, idx) return self:dragonTableCellAtIndex(table, idx) end, cc.TABLECELL_SIZE_AT_INDEX)
		self.m_dragonTableView:registerScriptHandler(function(table) return self:dragonNumberOfCellsInTableView(table) end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
		self.m_listNode2:addChild(self.m_dragonTableView)
	end

	self.dragonData = {}
	self.dragonDataGroup = {}
	self.dragonDataGroupState = {}

	local dragonSkillIds = DragonActiveSkillManager.getInstance():getOwnDragonActiveSkillIds()
	if CCCommonUtilsForLua:call("isFunOpenByKey", "dragon_talentskill") then
		for i, v in ipairs(dragonSkillIds) do
			self.dragonData[#self.dragonData + 1] = v
		end
	end

	local obtainTable = {}
	for i, v in ipairs(self.dragonData) do
		obtainTable[v] = false
 		local data = DragonActiveSkillManager.getInstance():getDataById(v)
		if data ~= nil then
			obtainTable[v] = data:getIsUnLocked()
		end
	end
	table.sort(self.dragonData, function(id1, id2)
		if obtainTable[id1] == obtainTable[id2] then
			return atoi(id1) < atoi(id2)
		end
		return obtainTable[id1] == true and obtainTable[id2] == false
	end)

	local dragonDataGroup = {}
	for i, v in ipairs(self.dragonData) do
		local baseId = ""
		local skillInfo = DragonActiveSkillManager.getInstance():getDataById(v)
		if nil ~= skillInfo then
			local dragonInfo = skillInfo:getDragonInfo()
			if nil ~= dragonInfo then
				baseId = dragonInfo:call("getBaseId")
			end
		end
		if nil == dragonDataGroup[baseId] then
			dragonDataGroup[baseId] = {}
		end
		table.insert(dragonDataGroup[baseId], v)
	end
	for k, v in pairs(dragonDataGroup) do
		self.dragonDataGroup[#self.dragonDataGroup + 1] = v
		local state = cc.UserDefault:getInstance():getIntegerForKey("NewActiveSkillView_page_dragon_" .. k, 1)
		self.dragonDataGroupState[#self.dragonDataGroupState + 1] = { id = k, state = state }
	end
end

function NewActiveSkillView:dragonCellSizeForTable(table, idx)
	idx = idx + 1
	if (idx > #self.dragonDataGroup) then
		return 0, 0
	end
	if self.dragonDataGroupState[idx].state == 1 then
		return 546, 90 + CELL_HEIGHT * math.ceil(#self.dragonDataGroup[idx] / 3)
	else
		return 546, 90
	end
end

function NewActiveSkillView:dragonTableCellAtIndex(table, idx)
	idx = idx + 1
	if (idx > #self.dragonDataGroup) then
		return nil
	end

	local cell = table:dequeueCell()
	local tid = self.dragonDataGroup[idx]
	if cell then
		cell:setData(idx, tid)
	else
		cell = Drequire("game.CommonPopup.NewActiveSkillDragonCell").new(idx, tid, self)
	end

	return cell
end

function NewActiveSkillView:dragonNumberOfCellsInTableView(table)
	return #self.dragonDataGroup
end

function NewActiveSkillView:buffTableCellTouched(tab, cell)
	if (cell) then
		local node = cell:getChildByTag(666)
		if (node and node.touchEnable) then
			if (node.m_type == 0 or node.m_type == ArtilleryBuffType or node.m_showIndepend == 1) then 
				return 
			end
			if self.buffDataGroupState[node.m_idx].state == 1 then
				self.buffDataGroupState[node.m_idx].state = 0
			else
				self.buffDataGroupState[node.m_idx].state = 1
			end
			local offset = self.m_buffTableView:getContentOffset()
			self.m_buffTableView:reloadData()
			local totalHeight = 0
			for i = #self.buffDataGroup, 1, -1 do
				if i > node.m_idx then
					local w, h = self:buffCellSizeForTable(self.m_buffTableView, i - 1)
					totalHeight = totalHeight + h
				end
			end

			local w, h = self:buffCellSizeForTable(self.m_buffTableView, node.m_idx - 1)
			local curHeight = h
			local minOffset = 0 - totalHeight
			local defaultOffset = self.m_listNode4:getContentSize().height - self.m_buffTableView:getContentSize().height
			if minOffset < defaultOffset then
				minOffset = defaultOffset
			end
			local maxOffset = self.m_listNode4:getContentSize().height - totalHeight - curHeight
			if offset.y < minOffset then
				offset.y = minOffset
			end
			if offset.y > maxOffset then
				offset.y = maxOffset
			end
			self.m_buffTableView:setContentOffset(offset)
		end
	end
end

function NewActiveSkillView:buffCellSizeForTable(table, idx)
	local real_idx = idx + 1
	if (real_idx > #self.buffDataGroup) then
		return 0, 0
	end
	if self.buffDataGroupState[real_idx].state == 1 then
		local count = #(self.buffDataSubitemList[self.buffDataGroup[real_idx]] or {})
		return 546, 155 + count * itemCellH1
	else
		return 546, 155
	end
end


function NewActiveSkillView:buffTableCellAtIndex(table, idx)
	local real_idx = idx + 1
	if (real_idx > #self.buffDataGroup) then
		return nil
	end

	local cell = table:dequeueCell()
	if (cell) then
		local node = cell:getChildByTag(666)
		node:setData(real_idx, self.buffDataGroup[real_idx], self)
	else
		local node = Drequire("game.CommonPopup.NewActiveSkillViewBuffCell"):create(real_idx, self.buffDataGroup[real_idx], self)
		if node then
			node:setTag(666)
			cell = cc.TableViewCell:create()
			cell:addChild(node)
		end
	end
	return cell
end

function NewActiveSkillView:buffNumberOfCellsInTableView(table)
	return #self.buffDataGroup
end


function NewActiveSkillView:onTouchCell(idx)
	if self.page == PAGE_DRAGON then
		if self.dragonDataGroupState[idx].state == 1 then
			self.dragonDataGroupState[idx].state = 0
		else
			self.dragonDataGroupState[idx].state = 1
		end

		local offset = self.m_dragonTableView:getContentOffset()
		self.m_dragonTableView:reloadData()
		local totalHeight = 0
		for i = #self.dragonDataGroup, 1, -1 do
			if i > idx then
				local w, h = self:dragonCellSizeForTable(self.m_dragonTableView, i - 1)
				totalHeight = totalHeight + h
			end
		end
		local w, h = self:dragonCellSizeForTable(self.m_dragonTableView, idx - 1)
		local curHeight = h
		local minOffset = 0 - totalHeight
		local defaultOffset = self.m_listNode2:getContentSize().height - self.m_dragonTableView:getContentSize().height
		if minOffset < defaultOffset then
			minOffset = defaultOffset
		end
		local maxOffset = self.m_listNode2:getContentSize().height - totalHeight - curHeight
		if offset.y < minOffset then
			offset.y = minOffset
		end
		if offset.y > maxOffset then
			offset.y = maxOffset
		end
		self.m_dragonTableView:setContentOffset(offset)
	end
end

function NewActiveSkillView:onGetDragonSkillUseCmdBack( ref )
	if nil == ref then
		return
	end
	local skillId = ref:getCString()
	if skillId ~= self.selectedId then
		return
	end
	self:updateUI()
end
-- Dragon end
-- ---------------------------------------------------------------------------------------
-- Hero begin

function NewActiveSkillView:initHeroData()
	if self._initHeroData then
		return
	end
	self._initHeroData = true

	self.m_heroTableView = Drequire("game.utility.TableViewMultiCol").new(self.m_listNode3:getContentSize())
	self.m_heroTableView:setDirection(kCCScrollViewDirectionVertical)
	self.m_heroTableView:setVerticalFillOrder(kCCTableViewFillTopDown)
	self.m_listNode3:addChild(self.m_heroTableView)
	local heroDelegate = {}
	heroDelegate.numberOfCellsInTableView = function(table) return self:heroNumberOfCellsInTableView(table) end
	heroDelegate.numberOfGridsInCell = function(table) return self:heroNumberOfGridsInCell(table) end
	heroDelegate.gridAtIndex = function(table, idx) return self:heroGridAtIndex(table, idx) end
	heroDelegate.gridSizeForTable = function(table, idx) return self:heroGridSizeForTable(table, idx) end
	self.m_heroTableView:setDelegate(heroDelegate)

	self.heroData = {}
	self.heroData1 = {}
	self.heroData2 = {}
	self.heroData3 = {}

	local heroData = HeroManager.getAllActiveSkillIds()
	local obtainTable = {}
	local heroIdTable = {}
	for _, v in ipairs(heroData) do
		obtainTable[v] = false
		heroIdTable[v] = 0
		local info = HeroManager.getActiveSkillInfoById(v)
		if info then
			obtainTable[v] = info:isObtain()
			local heroInfo = info:getHeroInfo()
			if heroInfo then
				heroIdTable[v] = heroInfo.id
			end
		end
	end

	table.sort(heroData, function(id1, id2)
		if obtainTable[id1] == obtainTable[id2] then
			return heroIdTable[id1] < heroIdTable[id2]
		else
			return obtainTable[id1] == true and obtainTable[id2] == false
		end
	end)

	for _, v in ipairs(heroData) do
		local subtype = 0
		local info = HeroManager.getActiveSkillInfoById(v)
		if info ~= nil then
			local heroInfo = info:getHeroInfo()
			if heroInfo ~= nil then
				subtype = atoi(heroInfo.subtype)
			end
		end
		if subtype == 1 then
			self.heroData1[#self.heroData1 + 1] = v
		elseif subtype == 2 then
			self.heroData2[#self.heroData2 + 1] = v
		elseif subtype == 3 then
			self.heroData3[#self.heroData3 + 1] = v
		else
			self.heroData1[#self.heroData1 + 1] = v
			self.heroData2[#self.heroData2 + 1] = v
			self.heroData3[#self.heroData3 + 1] = v
		end
	end

	-- self.heroData = self.heroData1
	if self.heroSeletedId == 1 then
		self.heroData = self.heroData1
	elseif self.heroSeletedId == 2 then
		self.heroData = self.heroData2
	elseif self.heroSeletedId == 3 then
		self.heroData = self.heroData3
	end
end

function NewActiveSkillView:heroNumberOfCellsInTableView(table)
	return math.ceil(#self.heroData / 3)
end

function NewActiveSkillView:heroNumberOfGridsInCell(table)
	return 3
end

function NewActiveSkillView:heroGridAtIndex(table, idx)
	idx = idx + 1
	if (idx > #self.heroData) then
		return nil
	end

	local grid = table:dequeueGrid()
	local id = self.heroData[idx]

	if grid then
		grid:setData(id)
	else
		grid = Drequire("game.CommonPopup.NewActiveSkillHeroGrid").new(id, self)
	end

	return grid
end

function NewActiveSkillView:heroGridSizeForTable(table, idx)
	return CELL_WIDTH, CELL_HEIGHT
end

function NewActiveSkillView:onHTabButton1Click()
	if self.heroSeletedId ~= 1 then
		self.heroSeletedId = 1
		self.heroData = self.heroData1
		self.selectedId = ""
		if #self.heroData > 0 then
			self.selectedId =  self.heroData[1]
		end
		self:updateUI()
	end
end

function NewActiveSkillView:onHTabButton2Click()
	if self.heroSeletedId ~= 2 then
		self.heroSeletedId = 2
		self.heroData = self.heroData2
		self.selectedId = ""
		if #self.heroData > 0 then
			self.selectedId =  self.heroData[1]
		end
		self:updateUI()
	end
end

function NewActiveSkillView:onHTabButton3Click()
	if self.heroSeletedId ~= 3 then
		self.heroSeletedId = 3
		self.heroData = self.heroData3
		self.selectedId = ""
		if #self.heroData > 0 then
			self.selectedId =  self.heroData[1]
		end
		self:updateUI()
	end
end

-- 初始化城堡等级条件
function NewActiveSkillView:initCastleCondition() -- 城堡等级条件
	local castle_str = CCCommonUtilsForLua:call("getPropByIdGroup", "payuicontrol", "99006", "k4")
    self.m_castle_condition_arr = {}
    if castle_str then
        local castle_arr = string.split(castle_str, "|")
        for i, v in ipairs(castle_arr) do
            self.m_castle_condition_arr[i] = atoi(v)
        end
    end
end

--[[
    ---------------- checkCastleCondition 判断城堡等级条件 ----------------
    - 参数                  必须(*)/可选(?)   注释     
    - selIndex                  *           选择序号对应self.selectMapIdx， 0-4之间
    - needShowDialog            ?           是否弹出提示框
]]
function NewActiveSkillView:checkCastleCondition(selIndex, needShowDialog)
    if self.m_castle_condition_arr and #self.m_castle_condition_arr >= selIndex+1 then
        local checkLevel = self.m_castle_condition_arr[selIndex+1] 
        local mainCityLv = FunBuildController:call("getMainCityLv") + FunBuildController:call("getMainCityHonorLv")
        if checkLevel ~= nil and (mainCityLv >= checkLevel or checkLevel <= 0) then
            return true
        else
            if needShowDialog then
                YesNoDialog:call("show", _lang_1("101603", tostring(checkLevel)), nil) -- 101603=城堡等级达到{0}解锁该功能
                return false
            end
        end
    end
    return false
end


-- 初始化vip等级条件
function NewActiveSkillView:initVipCondition()
	local vip_str = CCCommonUtilsForLua:call("getPropByIdGroup", "payuicontrol", "99006", "k5")
    self.m_vip_condition_arr = {}
    if vip_str then
        local vip_arr = string.split(vip_str, "|")
        for i, v in ipairs(vip_arr) do
            self.m_vip_condition_arr[i] = atoi(v)
        end
    end
end

--[[
    ---------------- checkVipCondition 判断vip等级条件 ----------------
    - 参数                  必须(*)/可选(?)   注释     
    - selIndex                  *           选择序号对应self.selectMapIdx， 0-4之间
    - needShowDialog            ?           是否弹出提示框
]]
function NewActiveSkillView:checkVipCondition(selIndex, needShowDialog)
    if self.m_vip_condition_arr and #self.m_vip_condition_arr >= selIndex+1 then
        local checkLevel = self.m_vip_condition_arr[selIndex+1] 
        local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
        -- local SVIPLevel = playerInfo:getProperty("SVIPLevel")
        local vipPoints = playerInfo:getProperty("vipPoints")
        local vipLevel = VipUtil:call("getVipLevel", vipPoints)
        if checkLevel ~= nil and (vipLevel >= checkLevel or checkLevel <= 0) then
            return true
        else
            if needShowDialog then
                YesNoDialog:call("show", _lang_1("103001", tostring(checkLevel)), nil) --//103001=VIP{0}
                return false
            end
        end
    end
    return false
end


-- 初始化svip等级条件
function NewActiveSkillView:initSvipCondition()
    local svip_str = CCCommonUtilsForLua:call("getPropByIdGroup", "payuicontrol", "99006", "k6")
    self.m_svip_condition_arr = {}
    if svip_str then
        local svip_arr = string.split(svip_str, "|")
        for i, v in ipairs(svip_arr) do
            self.m_svip_condition_arr[i] = atoi(v)
        end
    end
end

--[[
    ---------------- checkSvipCondition 判断svip等级条件 ----------------
    - 参数                  必须(*)/可选(?)   注释     
    - selIndex                  *           选择序号对应self.selectMapIdx， 0-4之间
    - needShowDialog            ?           是否弹出提示框
]]
function NewActiveSkillView:checkSvipCondition(selIndex, needShowDialog)
    if self.m_svip_condition_arr and #self.m_svip_condition_arr >= selIndex+1 then
        local checkLevel = self.m_svip_condition_arr[selIndex+1]
        local svipLevel = GlobalData:call("shared"):getProperty("playerInfo"):getProperty("SVIPLevel")
        if checkLevel ~= nil and (svipLevel >= checkLevel or checkLevel <= 0) then
            return true
        else
            if needShowDialog then
                YesNoDialog:call("show", _lang_1("137657", tostring(checkLevel)), nil) --//137657=尊敬的领主大人，您需要达到SVIP{0}才能使用该功能。
                return false
            end
        end
    end
    return false
end


-- 新版技能组按钮
function NewActiveSkillView:initNewSkillChangeBtn()
    self.m_btn_tab_arr = {}
    self.m_spr_lock_arr = {}
    self.m_spr_clicked_arr = {}
    self.m_title_arr = {}
    for i = 1, SKILL_TAB_BTN_COUNT do
        self.m_btn_tab_arr[i] = self["m_btn_tab_"..i]
        self.m_spr_lock_arr[i] = self["m_spr_lock_"..i]
        self.m_spr_clicked_arr[i] = self["m_spr_clicked_"..i]
        self.m_title_arr[i] = self["m_title_"..i]

        -- 判定是否达到解锁条件
        local checkIndex = i - 1
        local canUnlock = self:checkCastleCondition(checkIndex, false) and self:checkVipCondition(checkIndex, false) and self:checkSvipCondition(checkIndex, false)
		self.m_spr_lock_arr[i]:setVisible(not canUnlock)

        -- 技能组名
        self.m_title_arr[i]:setString(getLang("660911")..i) -- 660911 技能组
    end
end

-- 增益
function NewActiveSkillView:initBuffData()
	if self._initBuffData then
		return
	end
	self._initBuffData = true

	self.m_buffTableView = cc.TableView:create(self.m_listNode4:getContentSize())
	self.m_buffTableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
	self.m_buffTableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
	self.m_buffTableView:setDelegate()
	self.m_buffTableView:registerScriptHandler(function(tab, cell) self:buffTableCellTouched(tab, cell) end, cc.TABLECELL_TOUCHED)
	self.m_buffTableView:registerScriptHandler(function(table, idx) return self:buffCellSizeForTable(table, idx) end, cc.TABLECELL_SIZE_FOR_INDEX)
	self.m_buffTableView:registerScriptHandler(function(table, idx) return self:buffTableCellAtIndex(table, idx) end, cc.TABLECELL_SIZE_AT_INDEX)
	self.m_buffTableView:registerScriptHandler(function(table) return self:buffNumberOfCellsInTableView(table) end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
	self.m_listNode4:addChild(self.m_buffTableView)

	ToolController:call("getInstance"):setProperty("m_typeItems", {})
	
	self.buffDataGroup = {}
	self.buffDataGroupState = {}
	self.buffDataSubitemList = {}
	local serverType = GlobalData:call("shared"):getProperty("serverType")
	local forbidden_frozen = CCCommonUtilsForLua:isFunOpenByKey("forbidden_frozen")
	local statusItems = FunBuildController:call("getCityItemStatus")
	for index, buffId in ipairs(statusItems) do
		-- 战场不支持冰冻弹
		if buffId == "108870" then
			if forbidden_frozen == true and serverType ~= ServerType.SERVER_NORMAL then
			else
				table.insert(self.buffDataGroup, buffId)
			end
		else
			table.insert(self.buffDataGroup, buffId)
		end
	end

	if self.filter_by_match_show == 1 then --需要过滤，根据march_show判断是否显示该项目
		local tmpStatusIdItems = {}
		for i,v in ipairs(self.buffDataGroup) do
			local march_show = CCCommonUtilsForLua:getPropById(v, "march_show")
			if march_show == "1" then
				tmpStatusIdItems[#tmpStatusIdItems + 1] = v
			end
		end
		self.buffDataGroup = tmpStatusIdItems
	end

	for k, v in pairs(self.buffDataGroup) do
		local state = cc.UserDefault:getInstance():getIntegerForKey("NewActiveSkillView_page_buff_" .. k, 1)
		self.buffDataGroupState[#self.buffDataGroupState + 1] = { id = k, state = state }
		-- 初始化子项目列表
		self.buffDataSubitemList[v] = self:getSubitemsList(k)
	end
end

function NewActiveSkillView:getSubitemsList(idx)
	local item_list = {}
	self.m_params = nil
	local statusFlag = self.buffDataGroupState[idx].state
	local statusId = self.buffDataGroup[idx]
	local type = atoi(CCCommonUtilsForLua:call("getPropById", statusId, "type"))
	
	local useNewProtect = false
	local itemType = nil
	if type == 1 then
		local ctManager = require("game.crossThrone.CrossThroneManager")
		useNewProtect, itemType = ctManager:useCrossThroneProtect()
	else
		useNewProtect = false
	end
	
	local num, count, index = 0, 0, 0

	if (statusFlag == false) then
		local Items = ToolController:call("getInstance"):getProperty("m_durationItems")
		if (Items[type]) then
			num = 1
			count = 1
			local itemId = 0
			local dataList = ToolController:call("getInstance"):getProperty("m_allTools")
			for i = 1, #dataList do
				local tmpToolId = dataList[i]
				local info = ToolController:call("getToolInfoByIdForLua", tmpToolId)
				if (info:getProperty("type") == type) then
					itemId = info:getProperty("itemId")
					break
				end
			end

			table.insert(item_list, {["itemId"] = itemId, ["objId"] = "", ["qid"] = 0})
		end

		-- 不知道是否能复用refreshData，故而得改俩份
	elseif self.m_params ~= nil and self.m_params.statusTbl then
		-- 暂时不支持皮肤
		count = #self.m_params.statusTbl
		for i, statusId in pairs(self.m_params.statusTbl) do
			local continue = false
			local itemId = tonumber(CCCommonUtilsForLua:call("getPropByIdGroup", "status", statusId, "itemId")) or 0
			local toolInfo = ToolController:call("getToolInfoByIdForLua", itemId)
			local price = toolInfo:getProperty("price")
			local cnt = toolInfo:call("getCNT")
			local _type = toolInfo:getProperty("type")
			local _type2 = toolInfo:getProperty("type2")

			if (price <= 0 and cnt <= 0) then             
				if (useNewProtect and _type == itemType) then
					continue = false
				elseif (not (_type == 4 and (_type2 == 17 or _type2 == 18))) then
					count = count - 1
					continue = true
				end
				
			end
			if (continue == false) then
				table.insert(item_list, {["itemId"] = itemId, ["objId"] = "", ["qid"] = 0})
			end

			if (continue == false) then index = index + 1 end
		end
	else
		local typeItems = ToolController:call("getInstance"):getProperty("m_typeItems")

		local array = typeItems[type]
		if (array and array:count() > 0) then
			num = array:count()
			count = num
			for i = 0, num - 1 do
				local continue = false
				local dictInfo = array:objectAtIndex(i)
				if (dictInfo:objectForKey("customskin")) then
					table.insert(item_list, {["itemId"] = 0, ["objId"] = "customskin", ["qid"] = 0})
				else
					local itemId = dictInfo:valueForKey("id"):intValue()
					--// 如果price=0的时候，只有你身上有这种道具的时候才显示。
					--// =4 表示是作用相关道具，=17 表示是龙韵石。龙韵石不受上述price=0的影响。
					local toolInfo = ToolController:call("getToolInfoByIdForLua", itemId)
					local price = toolInfo:getProperty("price")
					local cnt = toolInfo:call("getCNT")
					local _type = toolInfo:getProperty("type")
					local _type2 = toolInfo:getProperty("type2")

					--跨服王战不显示普通加速
					if (useNewProtect and _type == 4) then
						count = count - 1
						continue = true
					end

					if (price <= 0 and cnt <= 0) then             
						if (useNewProtect and _type == itemType) then
							continue = false
						elseif (not (_type == 4 and (_type2 == 17 or _type2 == 18))) then
							count = count - 1
							continue = true
						end
						
					end
					if (continue == false) then
						table.insert(item_list, {["itemId"] = itemId, ["objId"] = "", ["qid"] = 0})
					end
				end

				if (continue == false) then index = index + 1 end
			end
		end
	end
	return item_list
end

return NewActiveSkillView