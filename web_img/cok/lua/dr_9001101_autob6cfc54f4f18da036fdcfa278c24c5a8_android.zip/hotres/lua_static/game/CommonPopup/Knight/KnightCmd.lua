KnightStorageInfoCmd = class("KnightStorageInfoCmd", LuaCommandBase)
KnightStorageModifyCmd = class("KnightStorageModifyCmd", LuaCommandBase)

function KnightStorageInfoCmd:create(callBack )
	-- body
    local ret = KnightStorageInfoCmd.new()
    ret:initWithName("activeShortCut.info")

	ret._callBack = callBack

    self.isError = false

    return ret
end

function KnightStorageInfoCmd:handleReceive( dict )
    local tbl, params = self:parseMsg(dict,true)
    if self._callBack and not self.isError then
        self._callBack(tbl)
    end

	return true
end

function KnightStorageInfoCmd:errorCallBack( tbl )
    -- body
    self.isError = true
    if self._callBack then
        self._callBack(false)
    end
end

----    KnightStorageModifyCmd -------------

function KnightStorageModifyCmd:create( str, callBack )
    -- body
    local ret = KnightStorageModifyCmd.new()
    ret:initWithName("activeShortCut.modify")

    ret:putParam("knightShortCut", CCString:create(str))
    ret._callBack = callBack

    self.isError = false

    return ret
end

function KnightStorageModifyCmd:handleReceive( dict )
    local tbl, params = self:parseMsg(dict,true)
    if self._callBack and not self.isError then
        self._callBack(true)
    end

    return true
end

function KnightStorageModifyCmd:errorCallBack( tbl )
    -- body
    self.isError = true
    if self._callBack then
        self._callBack(false)
    end
end
