

local AuctionHouseView = class("AuctionHouseView", 
	function()
    return PopupBaseView:create()
	end
	)
AuctionHouseView.__index =  AuctionHouseView

function AuctionHouseView:create()
 local view = AuctionHouseView.new()
    Drequire("game.CommonPopup.AuctionHouse.AuctionHouseView_ui"):create(view, 4)
    if view:initView() then
        return view
    end
    return false
end

function AuctionHouseView:initView()
	-- dump("AuctionHouseView:initView+++")
    self.timeCount = 0
    self:setTitleName(getLang("9440888"))
    self.ui.m_pLabelBackMoney:setString(getLang("9440931"))
    self.ui.m_pLabelBackMoneyCount:setString("0")
    self.ui.m_pNodeIcon:removeAllChildren()
    self.ui.m_pLabelNotice:setVisible(false)
    self.ui.m_pLabelNotice:setString(getLang("9441233"))
    self.ui.m_pNodeSupItem:setVisible(false)
    self.ui.m_pNodetable4:setVisible(false)
    
    -- 设置半透明层位置
    self:call("setModelLayerPosition", self.ui.m_baseNode:getPosition())

    CCLoadSprite:call("loadDynamicResourceByName", "uicompoent_face")
    local iconName = "AuctionHouseBg.png"
    local spr = nil
    local icon = CCLoadSprite:call("getSF", iconName)
    if icon ~= nil then 
        spr = CCLoadSprite:call("createSprite",iconName)
    else
        -- dump("error:auction house bg icon is not found+++ "..iconName)
        spr = CCLoadSprite:call("createSprite","banner.png")
    end
    self.ui.m_pNodeIcon:addChild(spr)

    self.isAuction4FunOpen = CCCommonUtilsForLua:isFunOpenByKey("auction_4")
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnGet, getLang("9440881"))
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnPersonalRecord, getLang("9440885"))
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnAcutionRecord, getLang("9440884"))
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnAcutionHonor, getLang("137401")) -- 137401=成就

    CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnTab1, getLang("139509")) -- 139509=资源
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnTab2, getLang("151435")) -- 151435=加速
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnTab3, getLang("176017")) -- 176017=增益
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnTab4, getLang("176018")) -- 176018=其他
    
    function onTouch(eventType, x, y)  
        if eventType == "began" then  
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)  
        else  
            return self:onTouchEnded(x, y)  
        end
    end
    self:setTouchEnabled(true)
    self:registerScriptTouchHandler(onTouch)

    
    if CCCommonUtilsForLua:isFunOpenByKey("auction_3") then
        self.ui.m_pNodeTabBtn:setVisible(true)
        self.ui.m_pNodetable1:setVisible(true)
        self.ui.m_pNodetable:setVisible(false)

        self.ui.m_btnAcutionHonor:setVisible(true)
        self.ui.m_btnAcutionRecord:setPositionX(320)
        self.ui.m_btnPersonalRecord:setPositionX(515)

        self:setTag(AuctionType.RES)

        self.ui.m_pNodetable1:setVisible(not self.isAuction4FunOpen)
        self.ui.m_pNodeSupItem:setVisible(self.isAuction4FunOpen)
        self.ui.m_pNodetable4:setVisible(self.isAuction4FunOpen)
        if self.isAuction4FunOpen then 
            local y = self.ui.m_pNodetable4:getPositionY() + 35
            self.ui.m_pNodeTabBtn:setPositionY(y)
        end
    else
        self.ui.m_pNodeTabBtn:setVisible(false)
        self.ui.m_pNodetable1:setVisible(false)
        self.ui.m_pNodetable:setVisible(true)

        self.ui.m_btnAcutionHonor:setVisible(false)
    end

    local ano = AuctionHouseController:getAnonmous()
    if ano and ano ~= 0 then 
        CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnAnomous, getLang("9440887"))
    else
        CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnAnomous, getLang("9440886"))
    end
    self:updateGlobalAucCell()
    return true
end

function AuctionHouseView:onEnter()
    -- dump("AuctionHouseView:onEnter+++") 
    UIComponent:call("showPopupView", 4)
    registerScriptObserver(self, self.onGetAuctionViewDataBack, AuctionGetViewDataBack)
    registerScriptObserver(self, self.onAuctionGivePriceDataBack, AuctionGivePriceDataBack)
    registerScriptObserver(self, self.onAuctionAddPriceDataBack, AuctionAddPriceDataBack)
    registerScriptObserver(self, self.onAuctionWithdrawDataBack, AuctionWithdrawDataBack)
    registerScriptObserver(self, self.onAuctionListViewDataChanged, AuctionListViewDataChanged)
    registerScriptObserver(self, self.onAuctionAckGrivePriceNow, AuctionAckGrivePriceNow)

    if self.isAuction4FunOpen then
        registerScriptObserver(self, self.onGlobalAuctionDataIsChanged, GlobalAuctionDataIsChangedMsg)
        self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:update(dt) end, 1, false)
        self:update(0)
    end
end

function AuctionHouseView:onExit()
    unregisterScriptObserver(self, AuctionGetViewDataBack)
    unregisterScriptObserver(self, AuctionGivePriceDataBack)
    unregisterScriptObserver(self, AuctionAddPriceDataBack)
    unregisterScriptObserver(self, AuctionWithdrawDataBack)
    unregisterScriptObserver(self, AuctionListViewDataChanged)
    unregisterScriptObserver(self, AuctionAckGrivePriceNow)
    if self.isAuction4FunOpen then 
        unregisterScriptObserver(self, GlobalAuctionDataIsChangedMsg)
        self:getScheduler():unscheduleScriptEntry(self.m_entryId)
    end
    CCSafeNotificationCenter:postNotification(AuctionViewOnExit)
end

function AuctionHouseView:onTouchBegan(x, y)
    return true
end

function AuctionHouseView:onTouchMoved(x, y)
end

function AuctionHouseView:onTouchEnded(x, y)
end

function AuctionHouseView:onGlobalAuctionDataIsChanged()
    dump("AuctionHouseView:onGlobalAuctionDataIsChanged+++")
    self:updateGlobalAucCell()
end

function AuctionHouseView:update(dt)
    if not AuctionHouseController.globalAucInfo then 
        return
    end
    local curTime = GlobalData:call("getTimeStamp")
    local endTime = AuctionHouseController.globalAucInfo.endTime/1000
    if endTime - curTime >= 0 then 
        local time = format_time( endTime - curTime)
        self.ui.m_pLabelTime:setString(time)
    else
        if self.timeCount and self.timeCount >= 60*3 then
            self.timeCount = 0
        else
            if self.timeCount == 0 then
                dump("time is 00,pull data151+++")
                AuctionHouseController:pullAuctionHouseViewData(false)
            end
            self.timeCount = self.timeCount+1
        end
    end
end

function AuctionHouseView:updateGlobalAucCell()
    if not self.isAuction4FunOpen then 
        return
    end
    local isInActivity = AuctionHouseController:isInActivity()
    self.ui.m_pSpriteGlobalTimer:setVisible(isInActivity)
    self.ui.m_btnTakePrice:setVisible(isInActivity)
    self.ui.m_pLabelPrice:setVisible(isInActivity)
    self.ui.m_pLabelRaisePrice:setVisible(isInActivity)
    self.ui.m_pSpriteGlobalCurPrice:setVisible(isInActivity)
    self.ui.m_pSpriteGlobalAddPrice:setVisible(isInActivity)
    
    self.ui.m_labelGlobalAuc:setString(getLang("176363"))   --176363=全服竞拍
    self.ui.m_pLabelPrice:setString(getLang("176265"))      --176265=当前价格
    self.ui.m_pLabelRaisePrice:setString(getLang("9440883"))
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnTakePrice, getLang("176264"))   --176264=竞价
    if not AuctionHouseController.globalAucInfo then 
        return
    end
    
    local info = AuctionHouseController.globalAucInfo
    self.ui.m_pNodeItemIcon:removeAllChildren()
    --reward, iconNode, width, nameLabel, numLabel, nameWithNum, beTouch, touchParentNode)
    local spr = LibaoCommonFunc.createRewardItemInfo(
        {type="7", value={id=tostring(info.itemId),num=tostring(info.num)} },
         self.ui.m_pNodeItemIcon, 100, nil, nil, true, true, nil)

    self.ui.m_pLabelPriceNum:setString(info.price)
    self.ui.m_pLabelRaisePriceNum:setString(info.add)
    self.ui.m_labelNum:setString(CC_CMDITOA(info.num))
    local name = CCCommonUtilsForLua:getPropById(tostring(info.itemId), "name")
    self.ui.m_pLabelItemName:setString(getLang(name))
    if info.selfAuctioned == "0" then 
        self.ui.m_btnTakePrice:setEnabled(true)
    else
        self.ui.m_btnTakePrice:setEnabled(false)
    end
    self:updateGoldInAcutionHouse()
end

--全服竞价
function AuctionHouseView:onGivePriceClicked()
    -- dump(AuctionHouseController,"AuctionHouseView:onGivePriceClicked+++",10)
    AuctionHouseController.curAuctionCellInfo = nil
    AuctionHouseController.curGlobalAuctionCellInfo = nil
    local info = AuctionHouseController.globalAucInfo
    if not info then 
        dump("auc error199+++")
        return
    end
    if self:isAuctionTimeOver() then 
        LuaController:flyHint("", "", getLang("9440925")) 
        return
    end
    local goldInAuction = tonumber(AuctionHouseController:getGoldCountInAuction())  
    local totalGold = goldInAuction + GlobalDataCtr.getPlayerGold()
    local minNum = tonumber(info.add) + tonumber(info.price)
    local maxNum = totalGold
    if maxNum < minNum then 
        LuaController:flyHint("", "", getLang("104912")) --104912=领主大人，您的金币不足，赶快去购买一些吧！
        return
    end

    -- 176263=请输入您的竞拍加价！  
    -- 176264=竞价
    AuctionHouseController.curGlobalAuctionCellInfo = info 
    local NewToolNumSelectView = Drequire("game.CommonPopup.NewToolNumSelectView")
    local view = NewToolNumSelectView:create(nil, minNum, maxNum, nil, 5, "176263" , "176264" , nil , AuctionAckGrivePriceNow , nil)
    local name = CCCommonUtilsForLua:getPropById(tostring(info.itemId), "name")
    view.auctionGoodsName = getLang(name)
    PopupViewController:addPopupView(view)
end

function AuctionHouseView:isAuctionTimeOver(  )
    local curTime = GlobalData:call("getTimeStamp")
    local endTime = AuctionHouseController.globalAucInfo.endTime/1000
    if endTime - curTime >= 0 then 
        return false
    end
    return true
end

function AuctionHouseView:updateView()
    local goldInAuction = AuctionHouseController:getGoldCountInAuction()
    self.ui.m_pLabelBackMoneyCount:setString(goldInAuction)
    --self.ui:setTableViewDataSource("m_pTableView", AuctionHouseController:getAuctionHouseViewData())
    self:refreshTableView()
    self:updateGlobalAucCell()

    local enableBtn = AuctionHouseController:isInActivity()
    self.ui.m_btnAnomous:setEnabled(enableBtn)
    self.ui.m_btnAcutionRecord:setEnabled(enableBtn)
    self.ui.m_btnPersonalRecord:setEnabled(enableBtn)
    self.ui.m_pLabelNotice:setVisible(not enableBtn)
    self.ui.m_pNodeTabBtn:setVisible(enableBtn)
    self.ui.m_btnGet:setEnabled(goldInAuction~="0") 
end

function AuctionHouseView:onGlobalAuctionAckGrivePriceNow( dict )
    if not dict then 
        return
    end
    local tbl = dictToLuaTable(dict)
    -- dump(tbl,"tbl2+++")
    -- dump(AuctionHouseController.curAuctionCellInfo,"cell info2+++")
    local myPrice = tbl.num --我的出价
    local uuid = AuctionHouseController.curGlobalAuctionCellInfo.uuid
    local price = tonumber(AuctionHouseController.curGlobalAuctionCellInfo.price) --当前价格
    local ano = AuctionHouseController:getAnonmous()
    AuctionHouseController:globalAuction(uuid, price, myPrice, ano)
    AuctionHouseController.curGlobalAuctionCellInfo = nil
end

function AuctionHouseView:onAuctionAckGrivePriceNow( dict )
    -- dump("AuctionHouseView:onAuctionAckGrivePriceNow+++")
    if self.isAuction4FunOpen and AuctionHouseController.curGlobalAuctionCellInfo then 
        self:onGlobalAuctionAckGrivePriceNow(dict)
        return
    end

    if not dict or not AuctionHouseController.curAuctionCellInfo then 
        return
    end
    local tbl = dictToLuaTable(dict)
    -- dump(tbl,"tbl+++")
    -- dump(AuctionHouseController.curAuctionCellInfo,"cell info+++")
    local myPrice = tbl.num --我的出价
    local uuid = AuctionHouseController.curAuctionCellInfo.uuid
    local price = tonumber(AuctionHouseController.curAuctionCellInfo.price) --当前价格
    local ano = AuctionHouseController:getAnonmous()
    AuctionHouseController:addPrice(uuid, price, myPrice-price, ano)
    AuctionHouseController.curAuctionCellInfo = nil
end

function AuctionHouseView:refreshTableView()

    if CCCommonUtilsForLua:isFunOpenByKey("auction_3") then
        local data = AuctionHouseController:getAuctionHouseViewData()
        local showData = {}
        for i, v in pairs(data) do
            if tonumber(v.auctionType) == self.m_tag then
                table.insert(showData, v)
            end
        end
        if self.isAuction4FunOpen then 
            self.ui:setTableViewDataSource("m_pTableView4", showData)
        else
            self.ui:setTableViewDataSource("m_pTableViewNew", showData)
        end
    else
        self.ui:setTableViewDataSource("m_pTableView", AuctionHouseController:getAuctionHouseViewData())
    end
end

function AuctionHouseView:onAuctionListViewDataChanged( )
    -- dump("AuctionHouseView:onAuctionListViewDataChanged+++")
    self:refreshTableView()
end

function AuctionHouseView:onGetAuctionViewDataBack( )
    -- dump("AuctionHouseView:onGetAuctionViewDataBack+++")
    self:updateView()
end

function AuctionHouseView:onAuctionGivePriceDataBack()
    -- dump("AuctionHouseView:onAuctionGivePriceDataBack+++")
    self:updateView()
end

function AuctionHouseView:onAuctionAddPriceDataBack(  )
    -- dump(allAuctionAddPriceCmdBackData, "AuctionHouseView:onAuctionAddPriceDataBack+++")
    self:updateView()
end

function AuctionHouseView:setTag(idx)
    self.m_tag = idx

    self.ui.m_btnTab1:setEnabled(idx ~= 1)
    self.ui.m_btnTab2:setEnabled(idx ~= 2)
    self.ui.m_btnTab3:setEnabled(idx ~= 3)
    self.ui.m_btnTab4:setEnabled(idx ~= 4)
end

function AuctionHouseView:onTabClick1(pSender, event)
    self:setTag(AuctionType.RES)
    self:refreshTableView()
end

function AuctionHouseView:onTabClick2(pSender, event)
    self:setTag(AuctionType.SPEED_UP)
    self:refreshTableView()
end

function AuctionHouseView:onTabClick3(pSender, event)
    self:setTag(AuctionType.GAIN)
    self:refreshTableView()
end

function AuctionHouseView:onTabClick4(pSender, event)
    self:setTag(AuctionType.OTHER)
    self:refreshTableView()
end

function AuctionHouseView:onAcutionHonorClicked(pSender, event)
    Drequire ("game.role.WallOfHonor")
    local openType = 0
    local view = WallOfHonor:create(openType)
    PopupViewController:call("addPopupInView", view)
end

function AuctionHouseView:updateGoldInAcutionHouse(  )
    local goldInAuction = AuctionHouseController:getGoldCountInAuction()
    if not goldInAuction then 
        return 
    end
    self.ui.m_pLabelBackMoneyCount:setString(goldInAuction)
    self.ui.m_btnGet:setEnabled(goldInAuction~="0")
end

function AuctionHouseView:onAuctionWithdrawDataBack(  )
    -- dump(allAuctionAddPriceCmdBackData, "AuctionHouseView:onAuctionWithdrawDataBack+++")
    self:updateGoldInAcutionHouse()
end

function AuctionHouseView:onHelpButtonClick()
    LuaController:call("showFAQ","45284")
end

function AuctionHouseView:onSupHelpButtonClick()
    dump("AuctionHouseView:onSupHelpButtonClick+++")
    -- 176364=全服竞拍说明\n1.全服竞拍道具均为稀有道具，通过竞拍最后出价最高的玩家获得；\n2.全服竞拍活动期间，如果 在竞拍时间快结束时还有玩家竞拍，竞拍时间则往后顺延30分钟，最高顺延到活动第二天结束前40分钟，第二天结束前40分 钟内将不可再次竞价；最后一次出价且最高出价的玩家获得；\n3.全服竞拍的竞价可能存在一定时间的延迟刷新，延迟期间 ，最高最先出价的玩家获得竞价拍卖资格；\n4.全服竞拍道具竞拍成功之后将会开启全服系统公告；\n5.竞拍不成功的金币 将在每次刷新之后退还到竞拍退款里，请注意查收；\n6.竞拍成功消耗的金币将计入累消活动消耗，竞拍不成功不计入。
    local params = {}
    params.title = getLang("102271")
    params.info = getLang("176364") 
    local view = Drequire("game.DressIntroduction.CommonInfoViewNew"):create(params)
    PopupViewController:addPopupView(view)
end

--拍卖行交易纪录
function AuctionHouseView:onAcutionRecordClicked()
	local view = Drequire("game.CommonPopup.AuctionHouse.AuctionHouseRecordView"):create(Auction_House_Record_All)
    PopupViewController:addPopupView(view)
end

--个人交易纪录
function AuctionHouseView:onPersonalRecordClicked()
	local view = Drequire("game.CommonPopup.AuctionHouse.AuctionHouseRecordView"):create(Auction_House_Record_Personal)
    PopupViewController:addPopupView(view)
end

--领取
function AuctionHouseView:onBtnGetMoneyBackClicked()
	-- local view = Drequire("game.CommonPopup.AuctionHouse.AuctionHouseInputAckView"):create(Auction_House_Ack_GetMoneyBack)
	-- PopupViewController:addPopupView(view)
    local goldInAuc = AuctionHouseController:getGoldCountInAuction()
    if goldInAuc==nil or goldInAuc == "" or tonumber(goldInAuc) == nil or tonumber(goldInAuc) <= 0 then 
        LuaController:flyHint("", "", getLang("E000000"))
        return
    end
    -- dump(goldInAuc,"send auction cmd+++")
    local nNumInput = tonumber(goldInAuc)
    AuctionHouseController:getMoneyBack(nNumInput)
end

--匿名拍卖
function AuctionHouseView:onBtnAnymousAuctionClicked()
    if AuctionHouseController:getAnonmous() == 0 then
        AuctionHouseController:setAnonmous(1)
        CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnAnomous, getLang("9440887"));
    else
        AuctionHouseController:setAnonmous(0)
        CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnAnomous, getLang("9440886"));
    end
end


return AuctionHouseView



