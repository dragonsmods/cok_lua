----------------------------
-- Author: Elex
-- Date: 2019-06-19 Wednesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local RankActMethodCell_ui = class("RankActMethodCell_ui")

--#ui propertys


--#function
function RankActMethodCell_ui:create(owner, viewType, paramTable)
	local ret = RankActMethodCell_ui.new()
	CustomUtility:LoadUi("RankActMethodCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function RankActMethodCell_ui:initLang()
	LabelSmoker:setText(self.m_titleLabel, "182108")
	LabelSmoker:setText(self.m_methodName1, "182121")
	LabelSmoker:setText(self.m_btnLabel1, "182125")
	LabelSmoker:setText(self.m_methodName2, "182122")
	LabelSmoker:setText(self.m_btnLabel2, "182126")
	LabelSmoker:setText(self.m_methodName3, "182123")
	LabelSmoker:setText(self.m_btnLabel3, "310009")
	LabelSmoker:setText(self.m_methodName4, "182124")
	LabelSmoker:setText(self.m_btnLabel4, "134104")
end

function RankActMethodCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function RankActMethodCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function RankActMethodCell_ui:onClickMethod1(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickMethod1", pSender, event)
end

function RankActMethodCell_ui:onClickBtnDes1(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnDes1", pSender, event)
end

function RankActMethodCell_ui:onClickMethod2(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickMethod2", pSender, event)
end

function RankActMethodCell_ui:onClickBtnDes2(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnDes2", pSender, event)
end

function RankActMethodCell_ui:onClickMethod3(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickMethod3", pSender, event)
end

function RankActMethodCell_ui:onClickBtnDes3(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnDes3", pSender, event)
end

function RankActMethodCell_ui:onClickMethod4(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickMethod4", pSender, event)
end

function RankActMethodCell_ui:onClickBtnDes4(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnDes4", pSender, event)
end

return RankActMethodCell_ui

