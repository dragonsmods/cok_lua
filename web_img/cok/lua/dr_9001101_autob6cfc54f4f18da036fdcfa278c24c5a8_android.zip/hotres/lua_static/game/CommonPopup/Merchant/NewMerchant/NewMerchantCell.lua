
-------------------------------------------- NewMerchantCell Start --------------------------------------------
local NewMerchantCell = class("NewMerchantCell", function()
    return cc.Layer:create()
end)
ccb["NewMerchantCell"] = ccb["NewMerchantCell"] or {}

NewMerchantCell.m_labelCellHeight = 40
NewMerchantCell.m_bgHeight = 130
local dis = 10
local Music_Sfx_click_button = "ui_confirm"
function NewMerchantCell:create(idx)
    local ret = NewMerchantCell.new()
    Drequire("game.CommonPopup.Merchant.NewMerchant.NewMerchantCell_ui"):create(ret)
    local function onTouch(eventType, x, y)  
        if eventType == "began" then  
            return ret:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return ret:onTouchMoved(x, y)  
        else  
            return ret:onTouchEnded(x, y)  
        end
    end
    ret:setTouchEnabled(true)
    ret:registerScriptTouchHandler(onTouch)
    ret:setSwallowsTouches(false)

    self.m_nowItemId = ""
    self.m_nowItemNum = 0
    self.m_goldItemTbl = {}
    self.m_goldIcon = ""
    self.m_singlePrice = 0
    self.m_priceType = 5

    local par1 = ParticleController:call("createParticle", "TravelBusiness")
    par1:setContentSize(cc.size(1000, 1000))
    ret.ui.m_rewardNode:addChild(par1)

    self.am = ccb["NewMerchantCell"]["mAnimationManager"]
    return ret
end

function NewMerchantCell:animationCallback()
    dump("NewMerchantCell:animationCallback+++")
    if not self.isAnimationOver then 
        return 
    end
    dump("NewMerchantCell:animationCallback2+++")
    self:scheculeAnimationCallback(false)
    self.am:runAnimationsForSequenceNamed("0")
    if self.m_info.color and tonumber(self.m_info.color) >= 3 then
        self.ui.m_superNode:setVisible(true)
        self.ui.m_rewardNode:setVisible(true)
        self.ui.m_topLightSpr:setColor(cc.c3b(138,62,251)) --紫色
        self.ui.m_topLightSpr1:setColor(cc.c3b(138,62,251))
        self.ui.m_bottomLightSpr:setColor(cc.c3b(138,62,251))
        self.ui.m_bottomLightSpr1:setColor(cc.c3b(138,62,251))
        if self.m_goldItemTbl and #self.m_goldItemTbl == 2 then
            if tonumber(self.m_goldItemTbl[1]) == self.m_nowItemId and tonumber(self.m_goldItemTbl[2]) == self.m_nowItemNum then
                self.ui.m_topLightSpr:setColor(cc.c3b(251, 183, 40)) -- 橙色
                self.ui.m_topLightSpr1:setColor(cc.c3b(251, 183, 40))
                self.ui.m_bottomLightSpr:setColor(cc.c3b(251, 183, 40))
                self.ui.m_bottomLightSpr1:setColor(cc.c3b(251, 183, 40))
            end
        end
    else
        self.ui.m_rewardNode:setVisible(false)
        self.ui.m_superNode:setVisible(false)
    end
end

function NewMerchantCell:scheculeAnimationCallback(bStart)
    if bStart then
        if self.m_entryId then 
            self:getScheduler():unscheduleScriptEntry(self.m_entryId)
            self.m_entryId = nil
        end
        self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:animationCallback() end, 1, false)
    else
        if self.m_entryId then 
            self:getScheduler():unscheduleScriptEntry(self.m_entryId)
        end
        self.m_entryId = nil
    end
end
  
function NewMerchantCell:playAnimation()
    self.isAnimationOver = false
    local onPlayEnd = function ()
        self.isAnimationOver = true
        -- self:animationCallback()
    end
    -- local callfunc = cc.CallFunc:create(onPlayEnd) --这里为何不使用callfunc呢。
    self.am:setAnimationCompletedCallback(onPlayEnd)
    self.am:runAnimationsForSequenceNamed("1")
    self:scheculeAnimationCallback(true)
end

function NewMerchantCell:refreshCell(info , idx)
    self.m_index = idx
    self.ui.m_picNode1:removeAllChildren()
    self.ui.m_bestItemIconNode:removeAllChildren()
    self.ui.m_lblSuper:setString(getLang("104933"))
    self.ui.m_rewardNode:setVisible(false)
    self.ui.m_superNode:setVisible(false)
    self.m_info = info
    if self.m_info.canPlay and tonumber(self.m_info.canPlay) == 1 then
        self.m_info.canPlay = 0
        self:playAnimation()
    else
        if self.m_info.color and tonumber(self.m_info.color) >= 3 then
            self.ui.m_superNode:setVisible(true)
            self.ui.m_rewardNode:setVisible(true)
            self.ui.m_topLightSpr:setColor(cc.c3b(138,62,251)) --紫色
            self.ui.m_topLightSpr1:setColor(cc.c3b(138,62,251))
            self.ui.m_bottomLightSpr:setColor(cc.c3b(138,62,251))
            self.ui.m_bottomLightSpr1:setColor(cc.c3b(138,62,251))
            if self.m_goldItemTbl and #self.m_goldItemTbl == 2 then
                if tonumber(self.m_goldItemTbl[1]) == self.m_nowItemId and tonumber(self.m_goldItemTbl[2]) == self.m_nowItemNum then
                    self.ui.m_topLightSpr:setColor(cc.c3b(251, 183, 40)) -- 橙色
                    self.ui.m_topLightSpr1:setColor(cc.c3b(251, 183, 40))
                    self.ui.m_bottomLightSpr:setColor(cc.c3b(251, 183, 40))
                    self.ui.m_bottomLightSpr1:setColor(cc.c3b(251, 183, 40))
                end
            end
        else
            self.ui.m_rewardNode:setVisible(false)
            self.ui.m_superNode:setVisible(false)
        end
    end
    if self.m_info.itemId and self.m_info.itemNum and self.m_info.color then 
        local bestItemId = self.m_info.itemId
        self.m_nowItemId = bestItemId
        self.m_nowItemNum = tonumber(self.m_info.itemNum)

        if tonumber(bestItemId) <= WorldResourceType.WorldResource_Max and tonumber(bestItemId) >= WorldResourceType.Wood then
            local iconName = CCCommonUtilsForLua:call("getResourceIconByType", tonumber(bestItemId))
            local pic = CCLoadSprite:call("createSprite", iconName)
            if (pic ~= nil) then
                local sptName = CCCommonUtilsForLua:call("getToolBgByColor", 0) -- 0 == WHITE
                local iconBg = CCLoadSprite:call("createSprite", sptName)
                CCCommonUtilsForLua:call("setSpriteMaxSize", iconBg, 95, true)
                self.ui.m_picNode1:addChild(iconBg)
                CCCommonUtilsForLua:call("setSpriteMaxSize", pic, 80, true)
                self.ui.m_picNode1:addChild(pic)
            end
            local name = CCCommonUtilsForLua:call("getResourceNameByType", tonumber(bestItemId)) 
            self.ui.m_bestName:setString(name .. "  x"..CC_CMDITOA(self.m_info.itemNum))
            self.ui.m_desName:setString(getLang(name))
        else
            local spr = CCCommonUtilsForLua:call("createGoodsIcon", tonumber(bestItemId), self.ui.m_picNode1, CCSize(90, 90))
            local name = CCCommonUtilsForLua:getPropById(bestItemId, "name")
            self.ui.m_bestName:setString(getLang(name) .. "  x"..CC_CMDITOA(self.m_info.itemNum))
            self.ui.m_desName:setString(getLang(name))
            local desc = CCCommonUtilsForLua:getPropById(bestItemId, "description")
            self.ui.m_desLabel:setString(getLang(desc))
        end
                    
    end
    if self.m_info.priceType then
        if tonumber(self.m_info.priceType) <= WorldResourceType.WorldResource_Max and tonumber(self.m_info.priceType) >= WorldResourceType.Wood then
            self.m_priceType = tonumber(self.m_info.priceType)
            local priceTypeIcon = CCCommonUtilsForLua:call("getResourceIconByType", tonumber(self.m_info.priceType))
            self.m_goldIcon = priceTypeIcon
            local priceTypeSpr = CCLoadSprite:createSprite(priceTypeIcon)
            self.ui.m_bestItemIconNode:addChild(priceTypeSpr)
            CCCommonUtilsForLua:call("setSpriteMaxSize", priceTypeSpr, 40, true)
        else
            self.m_priceType = tonumber(self.m_info.priceType)
            local iconStr = CCCommonUtilsForLua:call("getIcon", tostring(self.m_info.priceType))
            self.m_goldIcon = iconStr
            local pic = CCLoadSprite:call("createSprite", iconStr)
            if (pic ~= nil) then
                CCCommonUtilsForLua:call("setSpriteMaxSize", pic, 40, true)
                self.ui.m_bestItemIconNode:addChild(pic)
            end
        end
    end
    if self.m_info.price then
        self.ui.m_bestNowPrice:setString(CC_ITOA_K(tonumber(self.m_info.price)))
        self.m_singlePrice = tonumber(self.m_info.price)
    end
    if self.m_info.price_hot and tonumber(self.m_info.price_hot) > 0 then
        self.ui.m_NodeBestOriginPrice:setVisible(true)
        self.ui.m_bestNowPrice:setPositionY(11)
        self.ui.m_bestOriginPrice:setString(CC_ITOA_K(tonumber(self.m_info.price_hot)))
    else
        self.ui.m_bestNowPrice:setPositionY(0)
        self.ui.m_NodeBestOriginPrice:setVisible(false)
    end
    if self.m_info.bestItem then
        local goldItemTbl = string.split(self.m_info.bestItem , ";")
        if goldItemTbl and #goldItemTbl == 2 then
            self.m_goldItemTbl = goldItemTbl
        end
    end
    
end


function NewMerchantCell:onEnter()
    
end

function NewMerchantCell:onExit()
    self:scheculeAnimationCallback(false)
end

function NewMerchantCell:onTouchBegan(x, y)
    self.m_startTouchPt = cc.p(x, y)
    if isTouchInside(self.ui.spr_best, x, y) and tonumber(self.m_nowItemId) > WorldResourceType.WorldResource_Max  then
        self.ui.m_desNode:setVisible(true)
        return true
    end
end

function NewMerchantCell:onTouchMoved(x, y)
    if (cc.pGetDistance(self.m_startTouchPt, cc.p(x, y)) > dis) then
        self.ui.m_desNode:setVisible(false)
        return
    end
end
function NewMerchantCell:onTouchEnded(x, y)
    self.ui.m_desNode:setVisible(false)
end

function NewMerchantCell:onRefreshClick(  )
    SoundController:call("sharedSound"):call("playEffects", Music_Sfx_click_button)
    local StoreBuyConfirmDialogForLua = Drequire("game.CommonPopup.StoreBuyConfirmDialogForLua")
    local params = {}
    params.itemId = self.m_nowItemId
    params.maxNum = tonumber(self.m_nowItemNum)
    params.messagePosted = "NewMerchantCell_Buy_CB"
    params.singlePoint = self.m_singlePrice
    params.moneyIcon = self.m_goldIcon
    params.id = ""
    params.isShowSelect = 0
    params.isNeedStore = 0
    params.index = self.m_index
    params.priceType = self.m_priceType
    local view = StoreBuyConfirmDialogForLua:create(params)
    PopupViewController:addPopupView(view)
end
-------------------------------------------- NewMerchantCell End --------------------------------------------

return NewMerchantCell