local ChangeServerApplyView = class("ChangeServerApplyView", PopupBaseView)

function ChangeServerApplyView:create(page)
    local view = ChangeServerApplyView.new(page)
    Drequire("game.CommonPopup.ChangeServer.ChangeServerApplyView_ui"):create(view, 0)
    view:initView()
    return view
end

function ChangeServerApplyView:ctor(page)
    self.page = page or 1
end

function ChangeServerApplyView:initView()
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_alliBtn, getLang("173224"))
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_rcBtn, getLang("173225"))
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_allyBtn, getLang("173313"))

    CCLoadSprite:call("doResourceByCommonIndex", 519, true)
    self.ui.m_titleTxt:setString(getLang("173221"))

    if self.page == 1 then
        self:onClickBtnAlli()
    else
        self:onClickBtnRc()
    end
end

function ChangeServerApplyView:onEnter()
    UIComponent:call("showPopupView", 1)
end

function ChangeServerApplyView:onExit()

end

function ChangeServerApplyView:onClickBtnAlli()
    if require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance():showTransferDirectly() then 
        self:onClickBtnRc()
        return
    end

    self.ui.m_alliBtn:setEnabled(false)
    self.ui.m_rcBtn:setEnabled(true)
    self.ui.m_allyBtn:setEnabled(true)
    
    local function addApplyRecord(alliance) 
        if self.rcNode then self.rcNode:addApplyRecord(alliance) end
    end

    if not self.alliNode then
        self.alliNode = Drequire("game.CommonPopup.ChangeServer.AllianceRecruitNode"):create(addApplyRecord)
        self.ui.m_listNode:addChild(self.alliNode)
    end

    self.alliNode:setVisible(true)
    if self.rcNode then self.rcNode:setVisible(false) end
    if self.allyNode then self.allyNode:setVisible(false) end
end

function ChangeServerApplyView:onClickBtnRc()
    if not self.rcNode then
        self.rcNode = Drequire("game.CommonPopup.ChangeServer.ApplyRecordNode"):create()
        self.ui.m_listNode:addChild(self.rcNode)
    end

    self.ui.m_alliBtn:setEnabled(true)
    self.ui.m_rcBtn:setEnabled(false)
    self.ui.m_allyBtn:setEnabled(true)

    self.rcNode:setVisible(true)
    if self.alliNode then self.alliNode:setVisible(false) end
    if self.allyNode then self.allyNode:setVisible(false) end
end

function ChangeServerApplyView:onClickBtnAlly()
    if require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance():showTransferDirectly() then 
        self:onClickBtnRc()
        return
    end

    local function addApplyRecord(alliance) 
        if self.rcNode then self.rcNode:addApplyRecord(alliance) end
    end

    if not self.allyNode then
        self.allyNode = Drequire("game.CommonPopup.ChangeServer.AllyApplyNode"):create(addApplyRecord)
        self.ui.m_listNode:addChild(self.allyNode)
    end

    self.ui.m_alliBtn:setEnabled(true)
    self.ui.m_rcBtn:setEnabled(true)
    self.ui.m_allyBtn:setEnabled(false)

    self.allyNode:setVisible(true)
    if self.alliNode then self.alliNode:setVisible(false) end
    if self.rcNode then self.rcNode:setVisible(false) end
end

function ChangeServerApplyView:onClickBtnTip()
    FaqHelper:call("showSingleFAQ", "45281")
end

return ChangeServerApplyView