local CommonInputView = class("CommonInputView", function()
	return PopupBaseView:create()
end)

function CommonInputView:create(desc, callback)
	local view = CommonInputView.new()
	Drequire("game.CommonPopup.CommonInputView_ui"):create(view, 0)
	if view:initView(desc, callback) then
		return view
	end
end

function CommonInputView:initView(desc, callback)
	self.m_desc = desc
	self.m_callback = callback

	self.ui.m_descLabel:setString(desc)
	self.ui.m_confirmButton:setEnabled(false)

	local editSize = self.ui.m_inputNode:getContentSize()
	local editpic = CCLoadSprite:call("createScale9Sprite", "UI_Alliance_TextBox.png")
	editpic:setContentSize(editSize)
	editpic:setInsetBottom(1)
	editpic:setInsetTop(1)
	editpic:setInsetRight(1)
	editpic:setInsetLeft(1)
	-- 输入框
	self.m_editBox = CCEditBox:create(editSize, editpic) -- 输入框尺寸，背景图片
	self.m_editBox:setPosition(cc.p(editSize.width / 2, editSize.height / 2))
	self.m_editBox:setAnchorPoint(cc.p(0.5, 0.5))
	self.m_editBox:setFontColor(cc.c3b(0, 0, 0))
	self.ui.m_inputNode:addChild(self.m_editBox)
	self.m_editBox:setReturnType(cc.KEYBOARD_RETURNTYPE_DONE) -- 输入键盘返回类型，done，send，go等
	self.m_editBox:setInputMode(cc.EDITBOX_INPUT_MODE_NUMERIC) -- 输入模型，如整数类型，URL，电话号码等，会检测是否符合
	self.m_editBox:setMaxLength(8)
	local function editCB1(strEventName,pSender)
		if tostring(pSender) == "began" then
			-- 光标进入，选中全部内容
		elseif tostring(pSender) == "ended" then
			-- 当编辑框失去焦点并且键盘消失的时候被调用
		elseif tostring(pSender) == "return" then
			-- 当用户点击编辑框的键盘以外的区域，或者键盘的Return按钮被点击时所调用
		elseif tostring(pSender) == "changed" then
			-- 输入内容改变时调用
			self:editBoxTextChanged(self.m_editBox:getText())
		end
	end
	self.m_editBox:registerScriptEditBoxHandler(editCB1)
	return true
end

function CommonInputView:editBoxTextChanged(text)
	local temp = ""
	for s in string.gmatch(text, "%d") do
		temp = temp .. s
	end
	self.m_editBox:setText(temp)
	self.ui.m_confirmButton:setEnabled(temp ~= "")
end

function CommonInputView:onCloseButtonClick(pSender, event)
	self:call("closeSelf")
end

function CommonInputView:onConfirmButtonClick(pSender, event)
	local inputNum = tonumber(self.m_editBox:getText())
	if inputNum then
		if self.m_callback then
			self.m_callback(inputNum)
		end
		self:call("closeSelf")
	else
		CCCommonUtilsForLua:call("flyHint", "", "", self.m_desc)
	end
end

return CommonInputView