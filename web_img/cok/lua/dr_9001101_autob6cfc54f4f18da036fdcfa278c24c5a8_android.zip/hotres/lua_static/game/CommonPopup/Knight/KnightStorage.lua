

local KnightStorage = class("KnightStorage",
	function()
		-- body
		return cc.LayerColor:create()
	end
)

function KnightStorage:create(itemId)
	local view = KnightStorage.new()
	if (view:initView(itemId)) then 
		return view 
	end
end

function KnightStorage:initView( knightId )

	local proxy = cc.CCBProxy:create()
	local ccbUri = "KnightStorage_lua.ccbi"
	local node = CCBReaderLoad(ccbUri, proxy, self)

	self:addChild(node)

	self.m_storages = { 
		{bg=self.m_pBg1, pic=self.m_pPic1, text = self.m_pLabel1, txt_needNum = self.txt_needNum1, pic_KnightNum = self.pic_KnightNum1},
		{bg=self.m_pBg2, pic=self.m_pPic2, text = self.m_pLabel2, txt_needNum = self.txt_needNum2, pic_KnightNum = self.pic_KnightNum2},
		{bg=self.m_pBg3, pic=self.m_pPic3, text = self.m_pLabel3, txt_needNum = self.txt_needNum3, pic_KnightNum = self.pic_KnightNum3},
		{bg=self.m_pBg4, pic=self.m_pPic4, text = self.m_pLabel4, txt_needNum = self.txt_needNum4, pic_KnightNum = self.pic_KnightNum4},
		{bg=self.m_pBg5, pic=self.m_pPic5, text = self.m_pLabel5, txt_needNum = self.txt_needNum5, pic_KnightNum = self.pic_KnightNum5},
	}

	self:initRegFuns()
	self:onRefresh()    

	local flag = CCUserDefault:sharedUserDefault():getBoolForKey("KnightStorageMainNodeVisible", true)
	self:setStorageShow(flag)

	return true
end

function KnightStorage:onRefresh()
	-- body
	local storageInfo = KnightController.getInstance().m_storage

	self.m_haveNum = 0
	for i,v in ipairs(storageInfo) do
		local picNode = self.m_storages[i].pic
		picNode:removeAllChildren()
		picNode.icon = nil

		local pText = self.m_storages[i].text
		pText:setString("")

		local txt_needNum = self.m_storages[i].txt_needNum
		txt_needNum:setString("")

		local pic_KnightNum = self.m_storages[i].pic_KnightNum
		pic_KnightNum:setVisible(false)

		picNode.KnightId = nil
		self.m_storages[i].isLock = v.isLock
		
		if v.isLock then 
			local strIcon = "img_lock.png"
			local sprIcon = CCLoadSprite:call("createSprite", strIcon)
			picNode:addChild(sprIcon)
			picNode.icon = sprIcon

		elseif v.knightId then
			local kInfo = KnightTitleController:call("getInstance"):call("getKnightInfoById", tonumber(v.knightId))
			if not kInfo then return end

			local infoName = kInfo:call("getName") 
			pText:setString(getLang(infoName))

			local bedgeIdVec = kInfo:getProperty("mateVec")
			local size = #bedgeIdVec
			if size > 0 then 
				local strBedgeid = tostring(bedgeIdVec[size])
				local iconShowStr = CCCommonUtilsForLua:call("getPropById", strBedgeid, "icon")
				iconShowStr = iconShowStr .. "_a.png"

				local iconShow = CCLoadSprite:call("createSprite", iconShowStr, CCLoadSpriteType_GOODS)
				CCCommonUtilsForLua:setSpriteMaxSize(iconShow, 90, true)
				picNode:addChild(iconShow)
				picNode.KnightId = v.knightId

				picNode.icon = iconShow

				-- 龙韵石数量
				local needNum,haveNum = QuickEquipmentController.getInstance():calculateBedgeNum(bedgeIdVec)
				self.m_haveNum = haveNum
				txt_needNum:setString(CC_ITOA_K(needNum))
				pic_KnightNum:setVisible(true)
				if needNum > haveNum then
					txt_needNum:setColor(cc.c3b(255, 0, 0))
				else
					txt_needNum:setColor(cc.c3b(184, 172, 132))
				end
			end
		else
			local strIcon = "ICON_jiahao.png"
			local sprIcon = CCLoadSprite:call("createSprite", strIcon)
			picNode:addChild(sprIcon)
			picNode.icon = sprIcon
		end
	end
	self.txt_needNum0:setString(CC_ITOA_K(self.m_haveNum))
end

function KnightStorage:initRegFuns()
	-- body

	local function onNodeEvent(event)
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(onNodeEvent)

    local function onRefresh()
		-- body
		self:onRefresh()
	end

	local handler = self:registerHandler(onRefresh)
	local key = KnightController.getInstance().m_Knight_Change_NotifyKey
    CCSafeNotificationCenter:registerScriptObserver(self, handler, key)
    self:onRefresh()
end

function KnightStorage:onTouchBegan( x, y )
	-- body

	if self:isStorageShow() then
		for i,v in ipairs(self.m_storages) do
			if isTouchInside(v.bg,x,y) then
				return true
			end
		end
	end

	if isTouchInside(self.m_pTouch,x,y) then
		return true
	end

	return false
end

function KnightStorage:onTouchEnded( x, y )

	if self:isStorageShow() then
		for i,v in ipairs(self.m_storages) do
			if isTouchInside(v.bg,x,y) then

				if v.isLock then
					local btnText = getLang("160580") -- 前往解锁
					local dia = YesNoDialog:show(btnText)
					-- dia:call("setYesButtonTitle", btnText)
					break
				end

				if v.pic.KnightId then
					local key = KnightController.getInstance().m_Knight_Click_NotifyKey
					CCSafeNotificationCenter:postNotification(key, CCString:create(tostring(v.pic.KnightId)))
					break
				else
					-- 去添加龙语
					local btnText = getLang("160597") -- 前往解锁
					local dia = YesNoDialog:show(btnText)
					-- dia:call("setYesButtonTitle", btnText)
					break
				end

				return true
			end
		end
	end

	if isTouchInside(self.m_pTouch,x,y) then
		self:onBtnShow()
		return true
	end

	return false
end

function KnightStorage:onEnter( )
	-- body
end

function KnightStorage:onExit( )
	-- body
	local key = KnightController.getInstance().m_Knight_Change_NotifyKey
    CCSafeNotificationCenter:unregisterScriptObserver(self,key)
end

function KnightStorage:isStorageShow()
	local isVisible = self:isVisible()
	if isVisible then 
		local isMainNodeVisible = self.m_pMain:isVisible()
		return isMainNodeVisible
	end
	return false
end 

function KnightStorage:setStorageShow(isShow)
	local isVisible = self.m_pMain:isVisible()
	if isVisible ~= isShow then 
		self.m_pMain:setVisible(isShow)

		CCUserDefault:sharedUserDefault():setBoolForKey("KnightStorageMainNodeVisible", isShow)
		local key = KnightController.getInstance().m_Knight_VisibleChange_NotifyKey
		CCSafeNotificationCenter:postNotification(key)
	end

	if isShow then 
		self.m_pSpriteArrow:setRotation(-90)
	else
		self.m_pSpriteArrow:setRotation(90)
	end

	for i,v in ipairs(self.m_storages) do
		v.bg:setOpacity(255)
		v.text:setOpacity(255)
		if v.pic.icon then 
			v.pic.icon:setOpacity(255)
		end
	end
end 

function KnightStorage:onBtnShow()
	-- body
	local isVisible = self.m_pMain:isVisible()
	if isVisible then 

		local fun1 = cc.CallFunc:create(function()
				self:setStorageShow(false)
			end)

		local fadeOut = cc.FadeOut:create(0.4)
		local seq = cc.Sequence:create(fadeOut, fun1)
		self.m_pMain:runAction(seq)

		for i,v in ipairs(self.m_storages) do
			
			v.bg:stopAllActions()
			v.bg:runAction(fadeOut:clone())
			v.text:stopAllActions()
			v.text:runAction(fadeOut:clone())
			if v.pic.icon then 
				v.pic.icon:stopAllActions()
				v.pic.icon:runAction(fadeOut:clone())
			end
		end
		self.m_pSpriteArrow:setRotation(90)
	else
		self:setStorageShow(true)
		self.m_pSpriteArrow:setRotation(-90)

		for i,v in ipairs(self.m_storages) do
			v.bg:setOpacity(255)
			v.text:setOpacity(255)
			if v.pic.icon then 
				v.pic.icon:setOpacity(255)
			end
		end
	end

end



return KnightStorage