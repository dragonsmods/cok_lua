----------------------------
-- Author: Elex
-- Date: 2018-12-03 Monday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CommonInputView_ui = class("CommonInputView_ui")

--#ui propertys


--#function
function CommonInputView_ui:create(owner, viewType, paramTable)
	local ret = CommonInputView_ui.new()
	CustomUtility:LoadUi("CommonInputView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CommonInputView_ui:initLang()
	LabelSmoker:setText(self.m_descLabel, "4512060")
	ButtonSmoker:setText(self.m_confirmButton, "9400630")
end

function CommonInputView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CommonInputView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CommonInputView_ui:onCloseButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onCloseButtonClick", pSender, event)
end

function CommonInputView_ui:onConfirmButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onConfirmButtonClick", pSender, event)
end

return CommonInputView_ui

