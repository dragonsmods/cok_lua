

SelectLuaView = class("SelectLuaView", function (  )
	return PopupBaseView:call("create")
end)

function SelectLuaView.create( maxNum, callBack, tipStr )
	local ret = SelectLuaView.new(maxNum, callBack, tipStr)
	if ret:initView() == false then
		ret = nil
	end
	return ret
end

function SelectLuaView:ctor( maxNum, callBack, tipStr )
	self.maxNum = tonumber(maxNum)
	self.callBack = callBack
	self.tipStr = tipStr
end

function SelectLuaView:initView(  )
	self:init(true, 0)
	self:setHDPanelFlag(true)

	if self.maxNum < 1 then
		return false
	end

	local isPad = CCCommonUtilsForLua:call("isIosAndroidPad")
	local winsize = cc.Director:getInstance():getIFWinSize()
	self:setContentSize(winsize)

	CCLoadSprite:call("doResourceByCommonIndex", 1, true)

	local proxy = cc.CCBProxy:create()
    local ccbiUrl = "SelectLuaView"
	local node = CCBReaderLoad(ccbiUrl, proxy, self)
    if nil == node then
        return false
    end

    self:addChild(node)

    if nil ~= self.tipStr then
    	self.m_infoLabel:setString(self.tipStr)
    end
    self.m_numMaxText:setString("/" .. CC_CMDITOA(self.maxNum))
    if isPad then
    	self.m_infoNode:setScale(2)
    end

    local function onNodeEvent( event )
		if event == "enter" then
			self:onEnter()
	    elseif event == "exit" then
			self:onExit()
	    end
	end
	self:registerScriptHandler(onNodeEvent)


	self.startTouchPt = cc.p(0, 0)
	local layer = cc.Layer:create()
	node:addChild(layer)
	local function touchHandle( eventType, x, y )
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		else
			self:onTouchEnded(x, y)
		end
	end
	layer:registerScriptTouchHandler(touchHandle)
	layer:setTouchEnabled(true)
	layer:setSwallowsTouches(false)

	--文本框
	local img = CCLoadSprite:call("createScale9Sprite", "frame_text2.png")  
	img:setAnchorPoint(0.5, 0.5)
	self.m_editBox = cc.EditBox:create(self.m_editNode:getContentSize(), img)  --输入框尺寸，背景图片
	self.m_editBox:setPosition(self.m_editNode:getContentSize().width / 2,self.m_editNode:getContentSize().height / 2)
	self.m_editBox:setAnchorPoint(cc.p(0.5,0.5))
	self.m_editBox:setFontSize(22)
	if isPad then
		self.m_editBox:setFontSize(44)
	end
	self.m_editBox:setFontColor(cc.c3b(255,255,255))
	self.m_editBox:setReturnType(cc.KEYBOARD_RETURNTYPE_DONE ) --输入键盘返回类型，done，send，go等
	self.m_editBox:setInputMode(cc.EDITBOX_INPUT_MODE_NUMERIC) --输入模型，如整数类型，URL，电话号码等，会检测是否符合
	-- self.m_editBox:setText("0")
	self.m_editBox:setText("1")


	local function editCB (strEventName,pSender)
		if tostring(pSender) == "ended" or tostring(pSender) == "return" then
			self:boxReturn()
		end
	end
	self.m_editBox:registerScriptEditBoxHandler(editCB) --输入框的事件，主要有光标移进去，光标移出来，以及输入内容改变等
	self.m_editNode:addChild(self.m_editBox)
	-- self.m_editBox:setHACenter() --输入的内容锚点为中心

	--滑动条
	-- local thunmImg = CCLoadSprite:call("createSprite", "huadongtiao1.png")
	-- local progImg = CCLoadSprite:call("createSprite", "huadongtiao2.png") 
	-- local bgImg =  CCLoadSprite:call("createScale9Sprite", "huadongtiao3.png") 
	-- local barSize = self.m_barNode:getContentSize()
	-- bgImg:setInsetBottom(5)
 --    bgImg:setInsetLeft(5)
 --    bgImg:setInsetRight(5)
 --    bgImg:setInsetTop(5)
 --    bgImg:setAnchorPoint(cc.p(0.5,0.5))
 --    bgImg:setContentSize(cc.size(barSize.width,18))
 --    bgImg:setPreferredSize(cc.size(barSize.width, 18))
 --    bgImg:setPosition(cc.p(barSize.width*0.5,barSize.height*0.5+9))

	-- self.m_controlSlider = CCSliderBar:call("createSlider", bgImg,progImg,thunmImg)
	-- self.m_controlSlider:setAnchorPoint(cc.p(0.5,0.5))
	-- self.m_controlSlider:setPosition(cc.p(barSize.width / 2,barSize.height / 2))
	-- self.m_controlSlider:setEnabled( true )
	-- self.m_controlSlider:setMinimumValue( 1 )
	-- self.m_controlSlider:setMaximumValue( tonumber(self.maxNum) )

	--滑动条
	local thunmImg = CCLoadSprite:createSprite("huadongtiao1.png")
	local progImg = CCLoadSprite:createSprite( "huadongtiao2.png") 
	local bgImg =  CCLoadSprite:createSprite( "huadongtiao3.png") 
	bgImg:setContentSize(self.m_barNode:getContentSize())
	bgImg:setVisible(false)

	self.m_controlSlider = cc.ControlSlider:create(bgImg,progImg,thunmImg)
	self.m_controlSlider:setAnchorPoint(CCPoint(0.5,0.5))
	self.m_controlSlider:setPosition(CCPoint(self.m_barNode:getContentSize().width / 2,self.m_barNode:getContentSize().height / 2))
	self.m_controlSlider:setEnabled( true )
	self.m_controlSlider:setMinimumValue( 1 )
	self.m_controlSlider:setMaximumValue( tonumber(self.maxNum) )
	self.m_invalidSlider = false
  	local function valueChanged(pSender)
	    if nil == pSender then
	        return
	    end           
	    if self.m_invalidSlider == true then
	    	self.m_invalidSlider = false
	    	return
	    end
	    local pControl = pSender
	    local changedInt = math.floor(pControl:getValue() + 0.5)
	    self.m_editBox:setText(tostring(changedInt))
	    self.m_invalidSlider = true
	    self.m_controlSlider:setValue(changedInt)
	end
	self.m_controlSlider:registerControlEventHandler(valueChanged, cc.CONTROL_EVENTTYPE_VALUE_CHANGED) 
	self.m_barNode:addChild(self.m_controlSlider)
	self.m_invalidSlider = true
	self.m_controlSlider:setValue(1)

	CCCommonUtilsForLua:call("setButtonTitle", self.m_useBtn, getLang("confirm"))
end

function SelectLuaView:onEnter(  )
	-- body
end

function SelectLuaView:onExit(  )
	-- body
end

function SelectLuaView:onUseClick(  )
	if nil ~= self.callBack then
		self.callBack(self.m_controlSlider:getValue())
	end
	self:call("closeSelf")
end

function SelectLuaView:boxReturn(  )
	local num = tonumber(self.m_editBox:getText())
	num = math.max(math.min(num, self.maxNum), 1)
	self.m_controlSlider:setValue(num)
end

function SelectLuaView:onTouchBegan( x, y )
	MyPrint("SelectLuaView:onTouchBegan")
	self.startTouchPt = cc.p(x, y)

	if isTouchInside(self.m_subArea, x, y) == true then
		return true
	end

	if isTouchInside(self.m_addArea, x, y) == true then
		MyPrint("adddddd")
		return true
	end

	if isTouchInside(self.m_touchNode, x, y) == false then
		MyPrint("subbbbbbb")
		return true
	end

	return false
end

function SelectLuaView:onTouchEnded( x, y )
	local dis = 10
	if CCCommonUtilsForLua:call("isIosAndroidPad") == true then
		dis = 20
	end

	if cc.pGetDistance(cc.p(x, y), self.startTouchPt) > dis then
		return
	end

	if isTouchInside(self.m_addArea, x, y) == true then
		local num = self.m_controlSlider:getValue()
		if num < self.maxNum then
			self.m_invalidSlider = true
			local tnum = math.floor(num + 1 + 0.5)
			self.m_controlSlider:setValue(tnum)
			self.m_editBox:setText(tostring(tnum))
		end
	end

	if isTouchInside(self.m_subArea, x, y) == true then
		local num = self.m_controlSlider:getValue()
		if num > 1 then
			self.m_invalidSlider = true
			local tnum = math.floor(num - 1 + 0.5)
			self.m_controlSlider:setValue(tnum)
			self.m_editBox:setText(tostring(tnum))
		end
	end

	if isTouchInside(self.m_touchNode, x, y) == false then
		self:call("closeSelf")
	end
end

