-- @author: mm
-- @time: 2016.11.11

local conns = {"raw", "tencent", "lx", "hk", ""}
local conn_names = {"直连", "腾讯", "蓝汛", "香港", "自动"}
local NET_FIXED_LINK = "NET_FIXED_LINK" --全局define
local SCENE_ID_LOADING = 0 --全局define
local MSG_NET_CONNECT_RETRY = "net_connect_retry" --全局define
local IS_USE_NEW_NET = 1
local heyprint = function(...)
    -- print(...)
end

local SelectNetCell = class("SelectNetCell",
    function()
        return cc.LayerColor:create() 
    end
)
SelectNetCell.__index = SelectNetCell

function SelectNetCell:create(id)
    local view = SelectNetCell.new()
    if view:initView(id) == true then
        return view
    end
    return nil
end

function SelectNetCell:initView(id)
    self.m_idx = id
    if self:init() == false then
        return false
    end

    -- local dict = CCDictionary:create()
    -- dict:setObject(CCString:create("btn_green3.png"),"1")
    local btnImg = CCLoadSprite:call("createScale9Sprite", "btn_green3.png")
    if btnImg == nil then
        return false
    end
    local btn = CCControlButton:create(btnImg)

    local function onTouch(eventType, x, y)  
        if eventType == "began" then
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)  
        else  
            return self:onTouchEnded(x, y)  
        end
    end

    self:registerScriptTouchHandler(onTouch)
    self:setTouchEnabled(true)
    self:setContentSize(cc.size(160, 70))
    self:setSwallowsTouches(true)

    btn:setPreferredSize(cc.size(160, 70))
    btn:setEnabled(false)
    CCCommonUtilsForLua:call("setButtonTitle", btn, conn_names[self.m_idx])

    self:addChild(btn)
    self.my_btn = btn

    if (cc.UserDefault:getInstance():getStringForKey(NET_FIXED_LINK, "") == conns[self.m_idx]) then
        CCCommonUtilsForLua:call("setButtonSprite", btn, "btn_Orange.png")
    end

    return true
end

function SelectNetCell:onTouchBegan(x, y)
    heyprint("SelectNetCell:onTouchBegan")
    self.m_startY = y
    if touchInside(self.my_btn, x, y) then
        heyprint("SNV inside!")
        return true
    end
    return false
end

function SelectNetCell:onTouchMoved(x, y)

end

function SelectNetCell:onTouchEnded(x, y)
    heyprint("SelectNetCell:onTouchEnded")
    if touchInside(self.my_btn, x, y) and math.abs(y - self.m_startY) < 30 then
        self:onClickBtn()
    end
    self.m_startY = y
end

function SelectNetCell:onClickBtn()
    local function callback()
        self:resetFixConn()
    end

    local ynd = YesNoDialog:show("确定选择该线路吗？", callback)

    ynd:call("showCancelButton")
    -- 以下获取国际文本有c2lua未映射的问题，等待修改。
    -- 原来有统一封装的getLang函数，V5。
    ynd:call("setYesButtonTitle", getLang("confirm"))
    ynd:call("setNoButtonTitle", getLang("cancel_btn_label"))
end

function SelectNetCell:resetFixConn()
    heyprint("SelectNetCell:resetFixConn idx=" , self.m_idx)
    cc.UserDefault:getInstance():setStringForKey(NET_FIXED_LINK, conns[self.m_idx])
    -- 重新连接；如果是在登陆界面的话，那么就登陆重试，否则在游戏中重连并重新读取数据。
    if (SceneController:call("getCurrentSceneId") <= SCENE_ID_LOADING ) then
        CCSafeNotificationCenter:call("postNotification", MSG_NET_CONNECT_RETRY)
    else 
        GameController:call("ResetData");
    end
end


-- SelectNetView = SelectNetView or {}
-- ccb["SelectNetView"] = SelectNetView

local SelectNetView = class("SelectNetView",
    function()
        return PopupBaseView:create()
    end
)
SelectNetView.__index = SelectNetView
SelectNetView.USE_NEW_NET = IS_USE_NEW_NET

function SelectNetView:create(table)
    local view = SelectNetView.new()
    if view:initView() == false then
        return nil
    end
    -- PopupViewController:call("addPopupInView", view)
    return view
end

function SelectNetView:initView()
    --PopupBaseView::init();
    local dict = CCDictionary:create()
    dict:setObject(CCBool:create(true),"1")
    if self:init(true, 0) == false then
        heyprint("SelectNetView init error")
        return false
    end

    --setIsHDPanel(true);
    self:setHDPanelFlag(true)

    --auto ccb = CCBLoadFile("SelectNetView", this, this);
    local proxy = cc.CCBProxy:create()
    local ccbiURL = "SelectNetView_Lua.ccbi"
    local nodeccb = CCBReaderLoad(ccbiURL, proxy, self)
    if nodeccb == nil then
        heyprint("SelectNetView loadccb error")
        return false
    else
        heyprint("SelectNetView loadccb done")
    end

    self:addChild(nodeccb)

    -- this->setContentSize(ccb->getContentSize());
    -- auto size = CCDirector::sharedDirector()->getWinSize();
    -- int add = size.height - ccb->getContentSize().height;
    self:setContentSize(nodeccb:getContentSize())
    local screenSize = cc.Director:getInstance():getIFWinSize()
    local add = screenSize.height - nodeccb:getContentSize().height

    self.m_bgNode:setPositionY(self.m_bgNode:getPositionY() - add)

    local frame = CCLoadSprite:call("loadResource", "technology_09.png")
    local tBatchNode = CCSpriteBatchNode:createWithTexture(frame:getTexture())

    local height = 0
    while (height < screenSize.height)
    do
        local spr = CCLoadSprite:call("createSprite", "technology_09.png")
        spr:setAnchorPoint(cc.p(0.5, 0))
        spr:setPositionX(0)
        spr:setPositionY(height)
        tBatchNode:addChild(spr)
        height = height + spr:getContentSize().height
    end
    self.m_bgNode:addChild(tBatchNode)

    self.m_conns = {}
    
    local realIndex = 1
    for i = 1, #conns, 1 do
        if ( string.len(conns[i]) == 0 or NetControllerEx:call("has_conn", conns[i]) ) then 
            self.m_conns[realIndex] = i
            realIndex = realIndex + 1
        end
    end

    heyprint("m_conns table=", self.m_conns)

    for i = 1, #self.m_conns, 1 do
        local cell = SelectNetCell:create(self.m_conns[i])
        cell:setPositionY(-150 * (i - 1))
        self.m_mainNode:addChild(cell)
    end
    
    return true
end

return SelectNetView
