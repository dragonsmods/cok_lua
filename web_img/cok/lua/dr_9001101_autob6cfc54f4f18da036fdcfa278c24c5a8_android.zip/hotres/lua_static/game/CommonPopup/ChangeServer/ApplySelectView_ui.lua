----------------------------
-- Author: Elex
-- Date: 2019-01-29 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local ApplySelectView_ui = class("ApplySelectView_ui")

--#ui propertys


--#function
function ApplySelectView_ui:create(owner, viewType, paramTable)
	local ret = ApplySelectView_ui.new()
	CustomUtility:LoadUi("ApplySelectView.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function ApplySelectView_ui:initLang()
end

function ApplySelectView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function ApplySelectView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function ApplySelectView_ui:onClickBtnConfirm(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnConfirm", pSender, event)
end

return ApplySelectView_ui

