
Auction_House_Record_Personal = 1   --个人记录
Auction_House_Record_All = 2        --所有记录
Auction_House_Ack_GetMoneyBack=1    --领取
Auction_House_Ack_GivePrice=2       --出价
AuctionRemoveAckView="auction_remove_ack_view"
AuctionAckGrivePriceNow="ack_grive_price_now"
AuctionListViewDataChanged="auction_list_view_data_changed"
AuctionPriceReplace="auction_price_replace" -- 通知：自己的出价被超越了
AuctionViewOnExit="auction_view_on_exit" -- 通知：退出了界面
LibaoCommonFunc = Drequire("game.LiBao.LibaoCommonFunc")

---------------------------------------获取拍卖行物品------------------------------------------
AuctionGetViewDataBack = "auction_view_data_back" -- 通知：我从服务器拉到了界面数据
local GetAuctionViewDataCmd = class("GetAuctionViewDataCmd", LuaCommandBase)
function GetAuctionViewDataCmd.create(bNeedCreateView)
    local ret = GetAuctionViewDataCmd.new()
    ret:initWithName("auction.getView")
    ret.bNeedCreateView = bNeedCreateView
    return ret
end

function GetAuctionViewDataCmd:handleReceive(dict)
    dump("GetAuctionViewDataCmd:handle data+++")
    local tbl = self:parseMsg(dict)
    if type(tbl) == "boolean" then
        return tbl
    end
    dump(tbl, "GetAuctionViewDataCmd:handleReceive+++ ", 10)
    AuctionHouseController:processAuctionViewData(tbl, self.bNeedCreateView)
    return true
end
-------------------------------------------------------------------------------


---------------------------------------获取交易纪录------------------------------------------
AuctionGetRecordDataBack = "auction_get_record_back"
local GetAuctionRecordCmd = class("GetAuctionRecordCmd", LuaCommandBase)
function GetAuctionRecordCmd.create(cmdName)
    -- dump(cmdName, "GetAuctionRecordCmd+++")
    local ret = GetAuctionRecordCmd.new()
    ret:initWithName(cmdName)
    return ret
end

function GetAuctionRecordCmd:handleReceive(dict)
    -- dump("GetAuctionRecordCmd:handle data+++")
    local tbl = self:parseMsg(dict)
    if type(tbl) == "boolean" then
        return tbl
    end
    -- dump(tbl, "GetAuctionRecordCmd:handleReceive+++ ", 10)
    AuctionHouseController:processAuctionRecordData(tbl)
    return true
end
-------------------------------------------------------------------------------


--------------------------------------出价-------------------------------------------
AuctionGivePriceDataBack="auction_give_price_data_back" 
local AuctionGivePriceCmd = class("AuctionGivePriceCmd", LuaCommandBase)
function AuctionGivePriceCmd.create(id, oldprice, myprice, anonmous)
	-- dump("AuctionGivePriceCmd.create id:"..id..", price:"..oldprice..", myprice:"..myprice..", anonmous:"..anonmous)
    local ret = AuctionGivePriceCmd.new()
    ret:initWithName("auction.auction")
    ret:putParam("uuid", CCString:create(id))
    ret:putParam("clientPrice", CCInteger:create(oldprice))
    ret:putParam("price", CCInteger:create(myprice))
    ret:putParam("anon", CCInteger:create(anonmous))
    return ret
end

function AuctionGivePriceCmd:handleReceive(dict)
    -- dump("AuctionGivePriceCmd:handleReceive+++")
 	local tbl = self:parseMsg(dict)
    if type(tbl) == "boolean" then
    	-- dump("boolean+++")
        return tbl
    end
    -- dump(tbl, "AuctionGivePriceCmd data+++")
    return true
end
-------------------------------------------------------------------------------


---------------------------------------加价------------------------------------
AuctionAddPriceDataBack = "auction_add_price_back"
local AuctionAddPriceCmd = class("AuctionAddPriceCmd", LuaCommandBase)
function AuctionAddPriceCmd.create(goodsId,price,myPirce,anonmous)
    -- dump("add price cmd:"..goodsId..","..price..","..anonmous)
    local ret = AuctionAddPriceCmd.new()
    ret:initWithName("auction.addPrice")
    ret:putParam("uuid", CCString:create(goodsId))
    ret:putParam("price", CCInteger:create(price))
    ret:putParam("anon", CCInteger:create(anonmous))
    ret:putParam("addPrice", CCInteger:create(myPirce))
    return ret
end

function AuctionAddPriceCmd:handleReceive(dict)
    -- dump("AuctionAddPriceCmd:handle data+++")
    local tbl = self:parseMsg(dict)
    if type(tbl) == "boolean" then
        return tbl
    end
    return true
end
-------------------------------------------------------------------------------


---------------------------------------一口价------------------------------------
AuctionDecisionDataBack = "auction_Decision_back"
local AuctionDecisionCmd = class("AuctionDecisionCmd", LuaCommandBase)
function AuctionDecisionCmd.create(goodsId,anonmous)
    -- dump("decision price cmd:"..goodsId..","..anonmous)
    local ret = AuctionDecisionCmd.new()
    ret:initWithName("auction.decision")
    ret:putParam("uuid", CCString:create(goodsId))
    ret:putParam("anon", CCInteger:create(anonmous))
    return ret
end

function AuctionDecisionCmd:handleReceive(dict)
    -- dump("AuctionDecisionCmd:handle data+++")
    local tbl = self:parseMsg(dict)
    if type(tbl) == "boolean" then
        return tbl
    end
    return true
end
-------------------------------------------------------------------------------



---------------------------------------领取------------------------------------------
AuctionWithdrawDataBack = "auction_get_money_back_key"
local AuctionWithdrawBackCmd = class("AuctionWithdrawBackCmd", LuaCommandBase)
function AuctionWithdrawBackCmd.create(goldNum)
    local ret = AuctionWithdrawBackCmd.new()
    ret:initWithName("auction.withdraw")
    ret:putParam("gold", CCInteger:create(goldNum))
    return ret
end

function AuctionWithdrawBackCmd:handleReceive(dict)
    -- dump("AuctionWithdrawBackCmd:handle data+++")
    local tbl = self:parseMsg(dict)
    if type(tbl) == "boolean" then
        return tbl
    end
    -- dump(tbl, "AuctionWithdrawBackCmd:handleReceive+++ ", 10)
    AuctionHouseController:processWithdrawData(tbl)
    return true
end


---------------------------------------全服拍卖-竞价------------------------------------------
GlobalAuctionDataIsChangedMsg = "Global_Auction_Data_Is_Changed_Msg"
GlobalAuctionGivePriceDataBack = "global_auction_give_price_back_key"
local GlobalAuctionGivePriceCmd = class("GlobalAuctionGivePriceCmd", LuaCommandBase)
function GlobalAuctionGivePriceCmd.create(id, oldprice, myprice, anonmous)
    local ret = GlobalAuctionGivePriceCmd.new()
    ret:initWithName("auction.auctionGlobal")
    ret:putParam("uuid", CCString:create(id))
    ret:putParam("clientPrice", CCInteger:create(oldprice))
    ret:putParam("price", CCInteger:create(myprice))
    ret:putParam("anon", CCInteger:create(anonmous))
    return ret
end

function GlobalAuctionGivePriceCmd:handleReceive(dict)
    dump("GlobalAuctionGivePriceCmd:handle data+++")
    local tbl = self:parseMsg(dict)
    if type(tbl) == "boolean" then
        return tbl
    end
    -- dump(tbl, "GlobalAuctionGivePriceCmd:handleReceive+++ ", 10)
    return true
end
-------------------------------------------------------------------------------



AuctionHouseController = class("AuctionHouseController")

local _instance = nil
function AuctionHouseController.getInstance()
    if _instance == nil then
        _instance = AuctionHouseController.new();
    end
    return _instance;
end

function AuctionHouseController:ctor()
    -- dump("AuctionHouseController:ctor+++")
    self.globalAucInfo = nil
end

function  AuctionHouseController:setAnonmous( anonmous )
    -- dump(anonmous,"AuctionHouseController:setAnonmous+++")
    self.isAnonmousAuction=anonmous
    cc.UserDefault:getInstance():setStringForKey("AuctionHouseIsAnomouse", tostring(anonmous))
end

function  AuctionHouseController:getAnonmous()
    local isAno = cc.UserDefault:getInstance():getStringForKey("AuctionHouseIsAnomouse","")
    -- dump(isAno, "AuctionHouseController:getAnonmous1+++")
    if isAno and isAno ~= "" then 
        self.isAnonmousAuction = tonumber(isAno)
    else
        self:setAnonmous(0)
    end
    return self.isAnonmousAuction
end

function AuctionHouseController:processGlobalAcutionData(data)
    self.globalAucInfo = nil
    if data and data.globalList and #data.globalList > 0 then
        self.globalAucInfo = data.globalList[1]
    end
    if data and data.gold then 
        self.goldInAuctionHouse = data.gold
    end
    -- dump(AuctionHouseController, "AuctionHouseController:processGlobalAcutionData", 10)
end

function AuctionHouseController:processAddPriceData(data)
    dump("AuctionHouseController:processAddPriceData+++")
    if not data then 
        return
    end
    if data.code ~= "1" then 
        -- dump(data.code, "error code+++:")
        LuaController:flyHint("", "", getLang(data.code)) 
        return 
    end
    self.allAuctionAddPriceBackData = data
    self.auctionHouseViewData = data.list
    self.goldInAuctionHouse = data.gold
    CCSafeNotificationCenter:postNotification(AuctionAddPriceDataBack)
end

function AuctionHouseController:processGlobalAuctionDataChanged(data)
    dump(data, "AuctionHouseController:processGlobalAuctionDataChanged+++")
    if not data then 
        dump("data error239+++")
        return 
    end
    if data.code ~= "1" then 
        dump(data.code, "error code+++:")
        local info = getLang(data.code)
        LuaController:flyHint("", "", getLang(data.code))
        return 
    end
    self:processGlobalAcutionData(data)
    CCSafeNotificationCenter:postNotification(GlobalAuctionDataIsChangedMsg)
end

function AuctionHouseController:processGlobalAuctionPriceReplaced(data)
    self:processGlobalAcutionData(data)
    CCSafeNotificationCenter:postNotification(GlobalAuctionDataIsChangedMsg)
    CCSafeNotificationCenter:postNotification(AuctionPriceReplace)
end

function AuctionHouseController:processGivePriceData(data)
    -- dump(data, "AuctionHouseController:processGivePriceData+++")
    if not data then 
        -- dump("data error+++")
        return 
    end
    if data.code ~= "1" then 
        -- dump(data.code, "error code+++:")
        local info = getLang(data.code)
        LuaController:flyHint("", "", getLang(data.code))
        return 
    end
    self.allAuctionGrivePriceBackData = data
    self.auctionHouseViewData = data.list
    self.goldInAuctionHouse = data.gold
    CCSafeNotificationCenter:postNotification(AuctionGivePriceDataBack)
end

function AuctionHouseController:processAuctionViewData(data,bNeedCreateView)
    if not data then 
        return
    end

    local function createAcutionHouseView( )
        if bNeedCreateView == false then
            return
        end
        -- dump(bNeedCreateView, "create auction house view+++")
        local view = Drequire("game.CommonPopup.AuctionHouse.AuctionHouseView"):create()
        PopupViewController:addPopupInView(view)
    end

    local inActivity = data.inActivity
    -- dump(inActivity,"inActivity+++")
    if inActivity and inActivity == "1" then
        local cross = GlobalData:call("getPlayerInfo"):getProperty("crossFightSrcServerId")
        -- dump(cross,"cross+++")
        if cross and cross == - 1 then
            createAcutionHouseView()
        else
            -- if cross then dump(cross,"cross+++") end
            LuaController:flyHint("", "", getLang("9440926"))   --跨服状态
            return 
        end
    else
        -- if inActivity then dump(inActivity,"inActivity+++") end
        if CCCommonUtilsForLua:isFunOpenByKey("pertukaran_barang") then
            createAcutionHouseView()
        else
            LuaController:flyHint("", "", getLang("9441073"))   --活动没开启
        end
    end

    self.inActivity = inActivity
    self.allAutionRecordData = data
    self.auctionHouseViewData = data.list
    self.goldInAuctionHouse = data.gold
    self:processGlobalAcutionData(data)
    CCSafeNotificationCenter:postNotification(AuctionGetViewDataBack)
end

function AuctionHouseController:processAuctionRecordData(data)
    if not data then 
        return
    end
    self.auctionRecordData = data
    CCSafeNotificationCenter:postNotification(AuctionGetRecordDataBack)
end

function AuctionHouseController:processWithdrawData(data)
    -- dump("AuctionHouseController:processWithdrawData")
    if not data then 
        return
    end
    self.auctionWithdrawData = data
    self.goldInAuctionHouse = data.gold
    CCSafeNotificationCenter:postNotification(AuctionWithdrawDataBack)
end

function AuctionHouseController:processMyPriceIsReplacedData(data)
    -- dump("AuctionHouseController:processMyPriceIsReplacedData")
    if not data then 
        return
    end
    self.auctionMyPriceIsReplacedData = data
    self.goldInAuctionHouse = data.gold
    self.auctionHouseViewData = data.list
    CCSafeNotificationCenter:postNotification(AuctionGetViewDataBack)
    CCSafeNotificationCenter:postNotification("show_auc_price_exceed_msg_right_now")
    CCSafeNotificationCenter:postNotification(AuctionPriceReplace)
end

function AuctionHouseController:processListViewDataChanged( data )
    self.auctionHouseViewData = data.list
    CCSafeNotificationCenter:postNotification(AuctionListViewDataChanged)
end

function AuctionHouseController:isInActivity(  )
    if self.inActivity == "0" then 
        return false
    end
    return true
end

function AuctionHouseController:getAuctionRecordData(  )
    return  self.auctionRecordData.historyList
end

function AuctionHouseController:getGoldCountInAuction(  )
    return  self.goldInAuctionHouse
end

function AuctionHouseController:getAuctionHouseViewData(  )
    local function sortfunction(left,right)
        return tonumber(left.selfAuctioned) > tonumber(right.selfAuctioned)
    end
    table.sort( self.auctionHouseViewData, sortfunction )
    return self.auctionHouseViewData
end

function AuctionHouseController:getReqRecordType( )
   return self.reqRecordType
end

function AuctionHouseController:getCurrentItemPrice( goodsId )
    if self.auctionHouseViewData ~= nil and #(self.auctionHouseViewData) > 0 then 
        for k,v in pairs(self.auctionHouseViewData) do 
            if v.uuid == goodsId then 
                return v.price
            end
        end
    end
    return ""
end

function AuctionHouseController:pullAuctionRecordData( recordType )
    self.reqRecordType = recordType
    if recordType == Auction_House_Record_Personal then 
        -- dump("get user history+++")  
        local cmd = GetAuctionRecordCmd.create("auction.getUserHistory")
        cmd:send()
    else  
        -- dump("get all history+++")
        local cmd = GetAuctionRecordCmd.create("auction.getHistory")
        cmd:send()
    end
end

function AuctionHouseController:pullAuctionHouseViewData( bCreateView )
    dump("AuctionHouseController:pullAuctionHouseViewData+++")
    local cmd = GetAuctionViewDataCmd.create(bCreateView)
    cmd:send()
end

function AuctionHouseController:addPrice(goodsId, price, myPirce, anonmous)
    local cmd = AuctionAddPriceCmd.create(goodsId, price, myPirce, anonmous)
    cmd:send()
end

function AuctionHouseController:globalAuction(goodsId, price, myPirce, anonmous)
    local cmd = GlobalAuctionGivePriceCmd.create(goodsId, price, myPirce, anonmous)
    cmd:send()
end

function AuctionHouseController:getMoneyBack( goldNum )
    local cmd = AuctionWithdrawBackCmd.create(goldNum)
    cmd:send()
end

function AuctionHouseController:givePrice( goodsId, oldPrice, myPrice, isAnonmousAuction )
    local cmd = AuctionGivePriceCmd.create(goodsId, tonumber(oldPrice), tonumber(myPrice), isAnonmousAuction)
    cmd:send()
end

function AuctionHouseController:decisionPrice( goodsId,isAnonmousAuction )
    local cmd = AuctionDecisionCmd.create(goodsId, isAnonmousAuction)
    cmd:send()
end

return AuctionHouseController

