local ComposeMaterialView = class("ComposeMaterialView", function (  )
	return PopupBaseView:call("create")
end)
local ComposeMaterialCell = class("ComposeMaterialCell", function (  )
	return cc.Node:create()
end)
ccb = ccb or {}

ccb["ComposeMaterialView"] = ccb["ComposeMaterialView"] or {}
function ComposeMaterialView.create( ids )
	local ret = ComposeMaterialView.new()
	if ret:initSelf(ids) ~= true then
		ret = nil
	end
	return ret
end

function ComposeMaterialView:initSelf( ids )
	
	MyPrint("ComposeMaterialView:initSelf")



	self:init(true, 0)
	self:setHDPanelFlag(true)

	if nil == ids or "" == ids then
		return false
	end

	self.ids = string.split(ids, ";")

	if nil == self.ids then
		return false
	end

	self:setContentSize(cc.Director:getInstance():getIFWinSize())

	local proxy = cc.CCBProxy:create()
    local ccbiUrl = "ComposeMaterialView"
	local node = CCBReaderLoad(ccbiUrl, proxy, self)
    if nil == node then
        return false
    end
    self:addChild(node)

    if CCCommonUtilsForLua:call("isIosAndroidPad") then
    	self.m_mainNode:setScale(2)
    end

	self.curIdx = 1 

	self.startTouchPt = cc.p(0, 0)
	self.touchLayer = cc.Layer:create()
    local function touchHandle( eventType, x, y )
        if eventType == "began" then
            return self:onTouchBegan(x, y)
        elseif eventType == "moved" then
        else
            self:onTouchEnded(x, y)
        end
    end
    self.touchLayer:registerScriptTouchHandler(touchHandle)
    self.touchLayer:setTouchEnabled(true)
    self.touchLayer:setSwallowsTouches(false)
    self:addChild(self.touchLayer)

	registerNodeEventHandler(self)

	self.animationManager = ccb["ComposeMaterialView"]["mAnimationManager"]

	-- 119028=合成
	CCCommonUtilsForLua:call("setButtonTitle", self.m_btn, getLang("119028"))

	-- 137552=道具合成
	self.m_titleText:setString(getLang("137552"))	

	self.m_parNode:setVisible(false)
	return true
end

function ComposeMaterialView:onTouchBegan( x, y )
	self.startTouchPt = cc.p(0, 0)
	if isTouchInside(self.m_bg, x, y) == false then
		return true
	end
	return false
end

function ComposeMaterialView:onTouchEnded( x, y )
	if isTouchInside(self.m_bg, x, y) then
		return 
	end

	self:call("closeSelf")
end

function ComposeMaterialView:onEnter(  )
	self:refreshView()

	local function onGetComposeEnd( ref )
		MyPrint("onGetComposeEnd")

		local function refresh(  )
			self:refreshNum()
			self.m_parNode:setVisible(true)
			self.animationManager:runAnimationsForSequenceNamed("Default Timeline")
		end
        performWithDelay(self,refresh,1)
	end
	local handler2 = self:registerHandler(onGetComposeEnd)
	CCSafeNotificationCenter:registerScriptObserver(self, handler2, "notify_item_compose_end")
end

function ComposeMaterialView:onExit(  )
	CCSafeNotificationCenter:unregisterScriptObserver(self, "notify_item_compose_end")
	-- body
end

function ComposeMaterialView:refreshNum(  )
	MyPrint("ComposeMaterialView:refreshNum")
	self.m_sprIconBG1:setVisible(false)
	self.m_numLabel:setString("")
	local id = self.ids[self.curIdx]
	local target = CCCommonUtilsForLua:call("getPropById", id, "target")
	MyPrint("target", target)
	local targets = string.split(target, "|")
	if #targets == 1 then
		self.m_sprIconBG1:setVisible(true)
		targets = targets[1]
		targets = string.split(targets, ";")
		if #targets == 2 then
			local tinfo = ToolController:call("getToolInfoByIdForLua", tonumber(targets[1]))
			if nil ~= tinfo then
				self.m_numLabel:setString(CC_CMDITOA(tinfo:call("getCNT")))
				self.m_sprIconBG1:setVisible(true)
			end
		end
	else
		self.m_sprIconBG1:setVisible(false)
		self.m_numLabel:setString("")
	end
end

function ComposeMaterialView:refreshView(  )
	MyPrint("ComposeMaterialView:refreshView")
	self.m_scrollNode:removeAllChildren()
	self.m_iconNode:removeAllChildren()
	local id = self.ids[self.curIdx]
	if self.curIdx <= 1 then
		self.m_leftBtn:setVisible(false)
	else 
		self.m_leftBtn:setVisible(true)
	end
	if self.curIdx >= #self.ids then
		self.m_rightBtn:setVisible(false)
	else
		self.m_rightBtn:setVisible(true)
	end
	local targets = self:getCurTargets()
	local tips_icon = CCCommonUtilsForLua:call("getPropById", id, "tips_icon")
	if #targets > 1 then
		local spr = CCLoadSprite:call("createSprite", tips_icon .. ".png", 2)
		self.m_iconNode:addChild(spr)
		local title = CCCommonUtilsForLua:call("getPropById", id, "tips_title")
		if title == "" then
			title = "151263"
		end
		self.m_target:setString(getLang(title))
		self.m_targetdes:setString(getLang(CCCommonUtilsForLua:call("getPropById", id, "tips_desc")))
	elseif #targets == 1 then
		local tid = targets[1]
		local spr = CCLoadSprite:call("createSprite", CCCommonUtilsForLua:call("getPropById", tostring(tid), "icon") .. ".png", 2)
		self.m_iconNode:addChild(spr)
		self.m_target:setString(getLang(CCCommonUtilsForLua:call("getPropById", tostring(tid), "name")))
		self.m_targetdes:setString(getLang(CCCommonUtilsForLua:call("getPropById", tostring(tid), "description")))
	end
	
	local materials = self:getCurMaterialAndNum()
	if #materials > 4 then
		return
	end
	local cnt = #materials
	local w = 530 / cnt
	for i=1,cnt do
		local v = materials[i]
		if #v == 2 then
			local cell = ComposeMaterialCell.new(v[1], v[2])
			cell:setPositionY(0)
			cell:setPositionX(-530 * 0.5 + (i - 1) * w + 0.5 * w)
			self.m_scrollNode:addChild(cell)
		end
	end
	self:refreshNum()
end

function ComposeMaterialView:onLeftBtnClick(  )
	self.curIdx = self.curIdx - 1
	self.curIdx = math.max(1, self.curIdx)
	self:refreshView()
end

function ComposeMaterialView:onRightBtnClick(  )
	self.curIdx = self.curIdx + 1
	self.curIdx = math.min(self.curIdx, #self.ids)
	self:refreshView()
end



function ComposeMaterialView:onClickBtn(  )

	local id = self.ids[self.curIdx]
	local materials = self:getCurMaterialAndNum()
	local canCrtNum = -1
	for i=1,#materials do
		local tinfo = ToolController:call("getToolInfoByIdForLua", materials[i][1])
		if nil == tinfo then
			return
		end
		local now = tinfo:call("getCNT")
		local need = materials[i][2]
		local crtNum = math.floor(now / need)
		if canCrtNum == -1 then
			canCrtNum = crtNum
		else
			if canCrtNum > crtNum then
				canCrtNum = crtNum
			end
		end
	end

	-- 137554=领主大人，您的合成材料不足，无法完成合成！
	if canCrtNum <= 0 then
		CCCommonUtilsForLua:call("flyText", getLang("137554"))
		return
	end

	local callBack = function ( num )
		local cmd = myRequire("game.command.ComposeLuaCommand").create(id, num)
		cmd:send()
	end

	local str = ""
	local targets = self:getCurTargets()
	if #targets == 1 then
		local toolid = targets[1]
		local name = getLang(CCCommonUtilsForLua:call("getPropById", tostring(toolid), "name"))
		-- 150214=领主大人，您要合成{0}吗？
		str = getLang("150214", name)
	else
		local name = CCCommonUtilsForLua:call("getPropById", id, "tips_title")
		if name == "" then
			name = "151263"
		end
		name = getLang(name)
		-- 152270    您确定要合成{0}吗？\n\n合成后您将会获得随机奖励
		str = getLang("152270", name)
	end

	myRequire("game.CommonPopup.SelectLuaView")
	local view = SelectLuaView.create(canCrtNum, callBack, str)
	PopupViewController:call("addPopupView", view)
end

function ComposeMaterialView:getCurMaterialAndNum(  )
	local id = self.ids[self.curIdx]
	local materials = CCCommonUtilsForLua:call("getPropById", id, "material")
	materials = string.split(materials, "|")
	local ret = {}
	for i=1,#materials do
		local t = string.split(materials[i], ";")
		if #t == 2 then
			t[1] = tonumber(t[1])
			t[2] = tonumber(t[2])
			ret[#ret + 1] = t
		end
	end
	return ret
end

function ComposeMaterialView:getCurTargets(  )
	MyPrint("ComposeMaterialView:getCurTargets")
	local id = self.ids[self.curIdx]
	local target = CCCommonUtilsForLua:call("getPropById", id, "target")
	if "" == target then
		return {}
	end
	target = string.split(target, "|")
	local ret = {}
	for i,v in ipairs(target) do
		v = string.split(v, ";")
		if #v == 2 then
			ret[#ret + 1] = tonumber(v[1])
		end
	end
	dump(ret, "ret")
	return ret
end


ccb["ComposeMaterialCell"] = ccb["ComposeMaterialCell"] or {}

function ComposeMaterialCell:ctor( id, num )

	local proxy = cc.CCBProxy:create()
    local ccbiUrl = "ComposeMaterialCell"
	local node = CCBReaderLoad(ccbiUrl, proxy, self)
    if nil == node then
        return false
    end
    self:addChild(node)

	id = tonumber(id)
	num = tonumber(num)
	self.id = id
	self.num = num
	self:refreshSelf()
	registerNodeEventHandler(self)
	self.animationManager = ccb["ComposeMaterialCell"]["mAnimationManager"]
	self.m_parNode:setVisible(false)

end

function ComposeMaterialCell:refreshSelf(  )
	local id = self.id
	local num = self.num
	local tinfo = ToolController:call("getToolInfoByIdForLua", id)
	if nil == tinfo then
		return
	end
	local sprName = CCCommonUtilsForLua:call("getPropById", tostring(id), "icon")
	local spr = CCLoadSprite:call("createSprite", sprName .. ".png", 2)
	self.m_iconNode:addChild(spr)

	local now = tinfo:call("getCNT")
	if now >= num then
		self.m_label:setColor(cc.WHITE)
	else
		self.m_label:setColor(cc.RED)
	end
	self.m_label:setString(CC_CMDITOA(now) .. "/" .. CC_CMDITOA(num))
end

function ComposeMaterialCell:onEnter(  )
	local function onGetComposeEnd( ref )
		MyPrint("onGetComposeEnd")
		self:refreshSelf()
		self:showPar()
	end
	local handler2 = self:registerHandler(onGetComposeEnd)
	CCSafeNotificationCenter:registerScriptObserver(self, handler2, "notify_item_compose_end")

end

function ComposeMaterialCell:onExit(  )
	CCSafeNotificationCenter:unregisterScriptObserver(self, "notify_item_compose_end")
end

function ComposeMaterialCell:showPar(  )
	self.m_parNode:setVisible(true)

	self.animationManager:runAnimationsForSequenceNamed("Default Timeline")
end

return ComposeMaterialView
