local cellSW = 100
local KNIGHT_BEDGE_CLICK = "knight.bedge.click"
local KNIGHT_PUT_MSG = "knight.put.msg"

local KnightTitileView = class("KnightTitileView",
	function()
		return PopupBaseView:create() 
	end
)
KnightTitileView.__index = KnightTitileView

function KnightTitileView:create(knightId)
	local view = KnightTitileView.new()
	if (view:initView(knightId)) then return view end
end

function KnightTitileView:initView( knightId )
	
	if (self:init(true, 0)) then
		Dprint("@@ ----- initView",knightId)
		self:setIsHDPanel(true)

		CCLoadSprite:call("doResourceByCommonIndex", 7, true)
		CCLoadSprite:call("doResourceByCommonIndex", 100, true)
		CCLoadSprite:call("doResourceByCommonIndex", 11, true)

		self.m_idx = -1
		self.m_knightId = knightId
		self.m_putPtVec = {}
		self.m_bedgeIdVec = {}
		self.m_bedgeHaveVec = {}
		self.m_showSprdVec = {}
		self.m_clickSprdVec = {}
        self.m_curActivateType = -1 --1=普通，2=上古，3=契约

		local proxy = cc.CCBProxy:create()
		local ccbUri = "KnightTitileView_lua.ccbi"
		local node = CCBReaderLoad(ccbUri, proxy, self)

		local function onNodeEvent(event)
			if event == "enter" then
				self:onEnter()
			elseif event == "exit" then
				self:onExit()
			elseif event == "cleanup" then
				self:onCleanup()
 			end
		end
		node:registerScriptHandler(onNodeEvent)
		self:addChild(node)

		local nodeSize = node:getContentSize()
		self:setContentSize(nodeSize)

		local winSize = cc.Director:sharedDirector():getIFWinSize()
		CCCommonUtilsForLua:call("makeBatchBG", self.m_bgNode, winSize, ccp(0.5, 1), 1)

		local extH = self:getExtendHeight()
		self.m_bottomNode:setPositionY(self.m_bottomNode:getPositionY() - extH)

		local listSize = self.m_infoList:getContentSize()
		self.m_infoList:setContentSize(cc.size(listSize.width, listSize.height + extH))

		self.m_scrollView = cc.ScrollView:create()
        self.m_scrollView:setViewSize(self.m_infoList:getContentSize())
        self.m_scrollView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
        self.m_infoList:addChild(self.m_scrollView)

        -- local knightInfos = KnightTitleController:call("getInstance"):getProperty("KnightTitleInfoMap")
        -- local knightInfo = knightInfos[self.m_knightId]
        Dprint("@@ ----- initView  1")
        local knightInfo = KnightTitleController:call("getInstance"):call("getKnightInfoById", knightId)
        if not knightInfo then return false end
		
		Dprint("@@ ----- initView  2")
        local _type = knightInfo:call("getType")
        if (_type == 3) then
        	-- 160514=需要激活过任意一条{0}阶龙语才可激活本龙语
        	local num = knightInfo:call("getPreClassify")
        	self.m_noticeLabel:setString(getLang("160514", tostring(num)))
        end

        local titleLength = self.m_kTitleLabel:getContentSize().width * self.m_kTitleLabel:getScaleX()
       	if (_type == 2 or _type == 3) then
       		if (_type == 2) then
       			self.m_kTitle2Label:setString(getLang("160330"))  -- 上古
       		else
       			self.m_kTitle2Label:setString(getLang("160520"))  -- 契约
       		end

       		local length = self.m_kTitle2Label:getContentSize().width * self.m_kTitle2Label:getScaleX()
       		local offX = 150
       		self.m_kTitle2Label:setColor(cc.c3b(235, 146, 0))
       		if (CCCommonUtilsForLua:call("isFlip")) then
       			self.m_kTitle2Label:setAnchorPoint(ccp(1, 0.5))
       			self.m_kTitleLabel:setPositionX(self.m_kTitleLabel:getPositionX() + (offX + length) / 2)
       			local lbX = self.m_kTitleLabel:getPositionX() - titleLength / 2 - offX
       			self.m_kTitle2Label:setPosition(ccp(lbX, self.m_kTitleLabel:getPositionY()))
       		else
       			self.m_kTitleLabel:setPositionX(self.m_kTitleLabel:getPositionX() - (offX + length) / 2)
       			local lbX = self.m_kTitleLabel:getPositionX() + titleLength / 2 + offX
       			self.m_kTitle2Label:setPosition(ccp(lbX, self.m_kTitleLabel:getPositionY()))
       		end
       	end

       	local mateVec = knightInfo:getProperty("mateVec")
       	local size = #mateVec
       	if (size == 2) then
       		self.m_putPtVec[#self.m_putPtVec + 1] = ccp(-cellSW * 0.5, 0)
       		self.m_putPtVec[#self.m_putPtVec + 1] = ccp(cellSW * 0.5, 0)
       	elseif (size == 3) then
       		self.m_putPtVec[#self.m_putPtVec + 1] = ccp(-cellSW, 30)
       		self.m_putPtVec[#self.m_putPtVec + 1] = ccp(0, 0)
       		self.m_putPtVec[#self.m_putPtVec + 1] = ccp(cellSW, 30)
       	elseif (size == 4) then
       		self.m_putPtVec[#self.m_putPtVec + 1] = ccp(-cellSW * 1.5, 30)
       		self.m_putPtVec[#self.m_putPtVec + 1] = ccp(-cellSW * 0.5, 0)
       		self.m_putPtVec[#self.m_putPtVec + 1] = ccp(cellSW * 0.5, 0)
       		self.m_putPtVec[#self.m_putPtVec + 1] = ccp(cellSW * 1.5, 30)
       	elseif (size == 5) then
       		self.m_putPtVec[#self.m_putPtVec + 1] = ccp(-cellSW * 2, 60)
       		self.m_putPtVec[#self.m_putPtVec + 1] = ccp(-cellSW, 30)
       		self.m_putPtVec[#self.m_putPtVec + 1] = ccp(0, 0)
       		self.m_putPtVec[#self.m_putPtVec + 1] = ccp(cellSW, 30)
       		self.m_putPtVec[#self.m_putPtVec + 1] = ccp(cellSW * 2, 60)
       	elseif (size == 6) then
       		self.m_putPtVec[#self.m_putPtVec + 1] = ccp(-cellSW * 2.5, 60)
       		self.m_putPtVec[#self.m_putPtVec + 1] = ccp(-cellSW * 1.5, 30)
       		self.m_putPtVec[#self.m_putPtVec + 1] = ccp(-cellSW * 0.5, 0)
       		self.m_putPtVec[#self.m_putPtVec + 1] = ccp(cellSW * 0.5, 0)
       		self.m_putPtVec[#self.m_putPtVec + 1] = ccp(cellSW * 1.5, 30)
       		self.m_putPtVec[#self.m_putPtVec + 1] = ccp(cellSW * 2.5, 60)
       	end

       	CCCommonUtilsForLua:setButtonTitle(self.m_putBtn, getLang("160299"))

       	-- local knightTitleId = KnightTitleController:call("getInstance"):getProperty("m_curKnightTitleId")
       	local knightTitleId = KnightTitleController:call("getInstance"):call("getCurrentOnId")

       	local name = knightInfo:call("getName")
        self.m_kTitleLabel:setString(getLang(name))

       	if (self.m_knightId == knightTitleId) then
       		CCCommonUtilsForLua:setButtonTitle(self.m_putBtn, getLang("160326"))
       		CCCommonUtilsForLua:call("setButtonSprite", self.m_putBtn, "mail_red_btn.png")

       		self.m_kTitleLabel:setString(getLang(name) ..": ".. getLang("169629"))
       	end

       	self.m_waitInterface = nil
       	self.m_guideKey = ""
       	self.m_YNdialog = nil

       	if (_type == 2 and GuideController:call("checkSubGuide", "3320100")) then
       		GuideController:call("triggerSubGuide", "3320100")
       	end

       	local touchLayer = cc.Layer:create()
		self:addChild(touchLayer)

		local function touchHandle( eventType, x, y )
			print("touchHandle", eventType, x, y)
			if eventType == "began" then
				return self:onTouchBegan(x, y)
			elseif eventType == "moved" then
			
			else
				self:onTouchEnded(x, y)
			end
		end
		touchLayer:registerScriptTouchHandler(touchHandle)
		touchLayer:setTouchEnabled(true)
		touchLayer:setSwallowsTouches(false)

		self:initKnightStorage()

		return true
	end
	return false
end

function KnightTitileView:initKnightStorage()
	-- body
	self.storageView = Drequire("game.CommonPopup.Knight.KnightStorage"):create()
	self.m_pNodeStorage:addChild(self.storageView )
	if CCCommonUtilsForLua:isFunOpenByKey("dragon_words_activate_memory") then 
		self.storageView:setVisible(true)
		self:call("showCloseBtn", true)
	else
		self.storageView:setVisible(false)
		self:call("showCloseBtn", false)
	end
end

function KnightTitileView:scheduleUpdate()
	local function updatefunc(dt) self:onEnterFrame(dt) end 
	self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(updatefunc, 1.0, false)
end

function KnightTitileView:unscheduleUpdate()
	if self.entry then
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
		self.entry = nil
	end
end

function KnightTitileView:onEnterFrame(dt)
	local kInfo = KnightTitleController:call("getInstance"):call("getKnightInfoById", self.m_knightId)
	if (not kInfo) then return end

	local _type = kInfo:call("getType")
	if (_type == 3) then
		if (self.m_timeLabel1 and self.m_timeLabel2) then
			local endTime = kInfo:call("getEndTime")
			local now = GlobalData:call("getTimeStamp")
			local left = endTime - now
			if (left > 0) then
				--160515 契约时间:{0}
				self.m_timeLabel1:setString(getLang("160515", ""))
				self.m_timeLabel2:setString(format_time(left))
			else
				--160521 生效时长:{0}
				local periodTime = kInfo:call("getPeriodTime")
				self.m_timeLabel1:setString(getLang("160521", ""))
				self.m_timeLabel2:setString(format_time(periodTime))
			end

			local w1 = self.m_timeLabel1:getContentSize().width * self.m_timeLabel1:getScale()
			local w2 = self.m_timeLabel2:getContentSize().width * self.m_timeLabel2:getScale()
			local w = self.m_infoList:getContentSize().width
			self.m_timeLabel1:setPositionX(w * 0.5 - (w1 + w2) * 0.5)
			self.m_timeLabel2:setPositionX(w * 0.5 - (w1 + w2) * 0.5 + w1)
		end
	end
end

function KnightTitileView:onEnter()
	-- body
	local function callback1(pObj) self:setBedgeData(pObj) end
	local function callback2(pObj) self:retData(pObj) end
	local handler1 = self:registerHandler(callback1)
	local handler2 = self:registerHandler(callback2)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, KNIGHT_BEDGE_CLICK)
	CCSafeNotificationCenter:registerScriptObserver(self, handler2, KNIGHT_PUT_MSG)

	self.m_idx = -1
	self:onUpdatePutNode()
	self:onShowMsg()
	self:setTitleName(getLang("160297"))
	self.m_bEndPost = true
	self.m_bEndPlay = true

	self:scheduleUpdate()
	self:onEnterFrame(0)

	local function onRefresh(ref)
		-- body
		local ref = tolua.cast(ref, "CCString")
		if ref then 
			local strId = ref:getCString()
			Dprint("@@ onRefresh KnightTitileView ", strId)

			PopupViewController:call("removeLastPopupView")
			local titleView = Drequire("game.CommonPopup.Knight.KnightTitileView"):create(tonumber(strId))
			PopupViewController:addPopupInView(titleView)
		end
	end

	local handler = self:registerHandler(onRefresh)
	local key = KnightController.getInstance().m_Knight_Click_NotifyKey
    CCSafeNotificationCenter:registerScriptObserver(self, handler, key)
    self.storageView:onRefresh()

    local function onStorageVisibleChange(ref)
    	if self.storageView:isStorageShow() then 
			self.m_showNode:setVisible(false)
		else
			self.m_showNode:setVisible(true)
		end
    end
    local handler2= self:registerHandler(onStorageVisibleChange)
    key = KnightController.getInstance().m_Knight_VisibleChange_NotifyKey
    CCSafeNotificationCenter:registerScriptObserver(self, handler2, key)
end

function KnightTitileView:onExit()
	if (self.m_waitInterface) then
		self.m_waitInterface:call("remove")
		self.m_waitInterface = nil
	end

	self:unscheduleUpdate()
	CCSafeNotificationCenter:unregisterScriptObserver(self, KNIGHT_BEDGE_CLICK)
	CCSafeNotificationCenter:unregisterScriptObserver(self, KNIGHT_PUT_MSG)

	local key = KnightController.getInstance().m_Knight_Click_NotifyKey
	CCSafeNotificationCenter:unregisterScriptObserver(self, key) 

	key = KnightController.getInstance().m_Knight_VisibleChange_NotifyKey
    CCSafeNotificationCenter:unregisterScriptObserver(self, key)
	self:call("showCloseBtn", false)
end

function KnightTitileView:onCleanup()
	-- body
	self = nil
end

function KnightTitileView:retData( pObj )
	self.m_bEndPost = true
	self:onEndChange()
end

function KnightTitileView:onEndChange()
	if ( (not self.m_bEndPost) or (not self.m_bEndPlay) ) then return end
	if (self.m_waitInterface) then
		self.m_waitInterface:call("remove")
		self.m_waitInterface = nil
	end

	local knightInfo = KnightTitleController:call("getInstance"):call("getKnightInfoById", self.m_knightId)
	local curknightTitleId = KnightTitleController:call("getInstance"):call("getCurrentOnId")

	local name = knightInfo:call("getName")
	if curknightTitleId == self.m_knightId then 
        self.m_kTitleLabel:setString(getLang(name) ..": ".. getLang("169629"))
	else
        self.m_kTitleLabel:setString(getLang(name))
	end
	self:onUpdatePutNode()
	self:resetBtns()
end

function KnightTitileView:getGuideNode(key)
	if (key == "KnightT_G1") then
		if ((#self.m_clickSprdVec > 0) and (#self.m_bedgeHaveVec > 0) and (#self.m_clickSprdVec == #self.m_bedgeHaveVec)) then
			if (self.m_bedgeHaveVec[#self.m_bedgeHaveVec] == 0) then
				self.m_guideKey = key
				if (CCCommonUtilsForLua:isIosAndroidPad()) then
					local node = cc.Node:create()
					local size = self.m_clickSprdVec[#self.m_clickSprdVec]:getContentSize()
					node:setContentSize(cc.size(size.width * 2, size.height * 2))
					self.m_clickSprdVec[#self.m_clickSprdVec]:addChild(node)
					return node
				else
					return self.m_clickSprdVec[#self.m_clickSprdVec]
				end
			else
				GuideController:call("setGuide", "3311900")
			end
		end
	elseif (key == "KnightT_G3") then

		self.m_guideKey = key

		if CCCommonUtilsForLua:isFunOpenByKey("dragon_words_activate_memory") then
			return self.m_pBtnQuickPut
		else
			return self.m_putBtn
		end

	else
		return nil
	end
end

function KnightTitileView:onTouchBegan(x, y)
	self.m_touchPoint = ccp(x, y)

	if self.storageView:isVisible() and self.storageView:onTouchBegan(x,y) then
		return true
	end

	return true
end

function KnightTitileView:onTouchEnded(x, y)

	if self.storageView:isVisible() and self.storageView:onTouchEnded(x,y) then
		return true
	end

	if (math.abs(y - self.m_touchPoint.y) >= 20) then return end

	local info = KnightTitleController:call("getInstance"):call("getKnightInfoById", self.m_knightId)
	if not info then return end

	self.m_idx = -1
	for i = 1, #self.m_bedgeIdVec do
		if (self.m_bedgeHaveVec[i] == 1 or self.m_bedgeHaveVec[i] == 2) then
			if (isTouchInside(self.m_clickSprdVec[i], x, y)) then
				self.m_idx = i

				local tool = ToolController:call("getToolInfoByIdForLua", self.m_bedgeIdVec[i])
				local cnt = tool:call("getCNT")
				local name = tool:call("getName")
				if (self.m_bedgeHaveVec[i] == 1) then
					-- local uKid = KnightTitleController:call("getInstance"):getProperty("m_curKnightTitleId")
					-- local uKInfos = KnightTitleController:call("getInstance"):getProperty("KnightTitleInfoMap")
					-- local uKInfo = uKInfos[uKid]
					if not CCCommonUtilsForLua:isFunOpenByKey("dragon_words_new_combine") then
						local uKInfo = KnightTitleController:call("getInstance"):call("getCurrentOnInfo")
						if uKInfo then
							local uname = uKInfo:call("getName")
							local msg = getLang("160301", name, getLang(uname))
							local function callback() self:onGotoOtherKnight() end
							local callfunc = cc.CallFunc:create(callback)
							local dialog = YesNoDialog:call("show", msg, callfunc)
							dialog:call("setYesButtonTitle", getLang("160380"))
							dialog:call("setYesButtonSprite", "mail_red_btn.png")
						end
					end
				elseif info:call("getType") ~= 1 then
					local p1 = getLang("160300", name)
					if info:call("getType") == 3 then
						local useBedge = KnightTitleController:call("getInstance"):call("GetUseBedgeById", self.m_bedgeIdVec[i])
						p1 = getLang("160517", name, name, tostring(math.max(0, cnt - useBedge)))
					end
					local function callback() self:onOkBtn() end
					local callfunc = cc.CallFunc:create(callback)
					YesNoDialog:call("show", p1, callfunc)
				end
				break
			end
		elseif (self.m_bedgeHaveVec[i] == 0) then --跳转到背包
			if (isTouchInside(self.m_clickSprdVec[i], x, y)) then
				if self.m_type == 1 and CCCommonUtilsForLua:isFunOpenByKey("dragon_words_new_combine") then
					if self.m_knightId ~= KnightTitleController:call("getInstance"):call("getCurrentOnId") then
						self:onBtnQuickPut()
					end
				else
					local function callback() self:onGotoShop() end
					local callfunc = cc.CallFunc:create(callback)
					local dialog = YesNoDialog:call("show", getLang("160325", name), callfunc)
					dialog:call("setYesButtonTitle", getLang("160327"))
					if (self.m_guideKey == "KnightT_G1") then
						CCSafeNotificationCenter:postNotification(GUIDE_INDEX_CHANGE, CCString:create(self.m_guideKey))
					end
				end
				break
			end
		else

		end
	end
end

function KnightTitileView:onGotoShop()
	Dprint("self.m_knightId ", self.m_knightId)
	KnightController.getInstance():setMateVec(self.m_bedgeIdVec, self.m_knightId)
	local view = require("game.CommonPopup.Knight.BedgeComposeView"):create(1)
	PopupViewController:addPopupInView(view)
	CCSafeNotificationCenter:postNotification(GUIDE_INDEX_CHANGE, CCString:create("YesNo_OK"))
end

function KnightTitileView:onGotoOtherKnight()
	--local tmpKid = KnightTitleController:call("getInstance"):getProperty("m_curKnightTitleId")
	local tmpKid = KnightTitleController:call("getInstance"):call("getCurrentOnId")
	if (tmpKid > 0) then
		local view = KnightTitileView:create(tmpKid)
		PopupViewController:addPopupInView(view)
	end
end

function KnightTitileView:onOkBtn()
	self.m_bedgeHaveVec[self.m_idx] = 3
	CCCommonUtilsForLua:setSpriteGray(self.m_showSprdVec[self.m_idx], false)

	self.m_clickSprdVec[self.m_idx]:stopAllActions()
	self.m_clickSprdVec[self.m_idx]:setOpacity(255)

	local scaleTo1 = cc.ScaleTo:create(0, 2)
	local moveBy1 = cc.MoveBy:create(0, ccp(0, 100))
	local spawn1 = cc.Spawn:create(scaleTo1, moveBy1)

	local scaleTo2 = cc.ScaleTo:create(0.3, 1)
	local moveBy2 = cc.MoveBy:create(0.3, ccp(0, -100))
	local easeBackIn = cc.EaseBackIn:create(moveBy2)
	local spawn2 = cc.Spawn:create(scaleTo2, easeBackIn)
	local function callback() self:addPutParticle() end
	local funcall = cc.CallFunc:create(callback)
	local seq = cc.Sequence:create(spawn1, spawn2, funcall)

	self.m_clickSprdVec[self.m_idx]:getParent():runAction(seq)
	self.m_putNum = self.m_putNum + 1

	--if (self.m_putNum == #self.m_bedgeIdVec) then
	--	self.m_putBtn:setEnabled(true)
	--else
	--	self.m_putBtn:setEnabled(false)
	--end

	self:resetBtns()
end

function KnightTitileView:addPutParticle()
	local count = 3
	local tmpStart = "DragLanPlace_"
	for i = 0, count do
		local resName = string.format("%s%d", tmpStart, i)
		local particle = ParticleController:call("createParticle", resName)
		particle:setPosition(self.m_clickSprdVec[self.m_idx]:getPosition())
		self.m_clickSprdVec[self.m_idx]:getParent():addChild(particle)
	end
end

function KnightTitileView:onBtnStorage()
	-- body
	-- Dprint("@@ onBtnStorage")
	local ret = false
	if KnightController.getInstance():isKnightInStorage(self.m_knightId) then 
		ret = KnightController.getInstance():removeKnight(self.m_knightId)
	else
		ret = KnightController.getInstance():addKnight(self.m_knightId)
		if ret then 
			self:PlayStorageAnimation(ret)
		end
	end

	self.storageView:setStorageShow(true)

	if ret then 
		self:resetBtnStorageText()
	end 
end


function KnightTitileView:PlayStorageAnimation( index )
	-- body
	Dprint("@@ PlayStorageAnimation", index)
	local pNode = self.storageView.m_storages[index]
	if not pNode then 
		return 
	end 

	self.m_flyNode:removeAllChildren()
	for i = 1, #self.m_clickSprdVec do

		local pt1 = ccp(pNode.bg:getPosition())
		local worldpt1 = pNode.bg:getParent():convertToWorldSpace(pt1)
		local endPt = self.m_flyNode:convertToNodeSpace(worldpt1)

		-- local pt1 = ccp(self.m_showSprdVec[i]:getPosition())
		-- local worldpt1 = self.m_showNode:convertToWorldSpace(pt1)
		-- local endPt = self.m_flyNode:convertToNodeSpace(worldpt1)

		local pt2 = ccp(self.m_clickSprdVec[i]:getPosition())
		local worldpt2 = self.m_clickSprdVec[i]:getParent():convertToWorldSpace(pt2)
		local startPt = self.m_flyNode:convertToNodeSpace(worldpt2)

		local strBedgeid = tostring(self.m_bedgeIdVec[i])
		local iconShowStr = CCCommonUtilsForLua:call("getPropById", strBedgeid, "icon")
		iconShowStr = iconShowStr .. "_a.png"
		local playIcon = CCLoadSprite:call("createSprite", iconShowStr, CCLoadSpriteType_GOODS)
		playIcon:setPosition(startPt)
		CCCommonUtilsForLua:setSpriteMaxSize(playIcon, 90, true)
		playIcon:setScale(1.0)
		self.m_flyNode:addChild(playIcon)

		local particle = ParticleController:call("createParticle", "DragLanAct_tails")
		playIcon:addChild(particle)

		local scaleTo1 = cc.ScaleTo:create(0.5, 1.5)
		local moveTo1 = cc.MoveTo:create(0.5, ccp(endPt.x, endPt.y + 100))
		local easeExponentialIn = cc.EaseExponentialOut:create(moveTo1)
		local spawn = cc.Spawn:create(scaleTo1, easeExponentialIn)

		local delayT1 = cc.DelayTime:create(0.2)
		local moveTo2 = cc.MoveTo:create(0.2, endPt)
		local easeBackIn = cc.EaseBackIn:create(moveTo2)

		local fadeOut = cc.FadeOut:create(0.2)

		local function callback1()
			local key = KnightController.getInstance().m_Knight_Change_NotifyKey
			CCSafeNotificationCenter:postNotification(key)
		end 
		local fun1 = cc.CallFunc:create(callback1)

		local seq = cc.Sequence:create(spawn, easeBackIn, fun1,fadeOut)
		playIcon:runAction(seq)
	end
end

function KnightTitileView:onBtnQuickPut()

	if (self.m_guideKey == "KnightT_G3") then
		CCSafeNotificationCenter:postNotification(GUIDE_INDEX_CHANGE, CCString:create(self.m_guideKey))
	end
	-- body
	local knightTitleId = KnightTitleController:call("getInstance"):call("getCurrentOnId")	
	if (knightTitleId == self.m_knightId) then

		-- 取消激活
		LogController:call("postEventLog", "Knight_cancel")
		-- MyPrint("breakpoint -1")
		KnightTitleController:call("getInstance"):call("startPutOnKnightTitle", -1)

		for i = 1, #self.m_showSprdVec do
			self.m_showSprdVec[i]:runAction(cc.FadeOut:create(0.5))

			local count = 2
			local tmpStart = "DragLanCancel_"
			for j = 0, count do
				local resName = string.format("%s%d", tmpStart, j)
				local particle = ParticleController:call("createParticle", resName)
				particle:setPosition(self.m_showSprdVec[i]:getPosition())
				self.m_showSprdVec[i]:getParent():addChild(particle)
			end
		end

        --AdjustII:TakeOffKnight
        local param = {knightId = knightTitleId}
        sendAdjustStatistic("TakeOffKnight", param)

		local function callback() self:onEndFuc() end
		local node = cc.Node:create()
		self:addChild(node)
		performWithDelay(node, callback, 1.5)
	else
		if self.m_type == 1 and self.m_haveNum < self.m_needNum then

			-- 前往获取龙韵石
			local itemId = 209861
            local ItemGetMethodView = Drequire("game.CommonPopup.ItemGetMethodView")
	        local view = ItemGetMethodView:create(itemId)
			PopupViewController:call("addPopupView", view)

			if (self.m_waitInterface) then
				self.m_waitInterface:call("remove")
				self.m_waitInterface = nil
			end

			local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
    		local uid = playerInfo:getProperty("uid")

			-- Dprint("@@ time",getWorldTime(), "uid:",uid)

		else

			-- 激活 or 一键激活
			local kInfo = KnightTitleController:call("getInstance"):call("getKnightInfoById", self.m_knightId)
			if not kInfo then return end

			local _type = kInfo:call("getType")
			local unlock = kInfo:call("getBeUnlocked")

			if kInfo:call("isRankConditionOkToUnlock") == false then
				local function fun()
					local kkInfo = KnightTitleController:call("getInstance"):call("getKnightInfoById", self.m_knightId)
					if not kkInfo then return end
					PopupViewController:call("removeAllPopupView")
					local view = Drequire("game.CommonPopup.Knight.KnightListView"):create()
					if view then
						PopupViewController:call("addPopupInView", view)
						view:showRank(kkInfo:call("getPreClassify"))
					end
				end
				
				local func = cc.CallFunc:create(fun)
				local dialog = YesNoDialog:call("show", getLang("160514", tostring(kInfo:call("getPreClassify"))), func)
				if dialog then
					dialog:call("setYesButtonTitle", getLang("160519"))
				end

				if (self.m_waitInterface) then
					self.m_waitInterface:call("remove")
					self.m_waitInterface = nil
				end

				return
			end

			local endTime = kInfo:call("getEndTime")
			local now = GlobalData:call("getTimeStamp")
			local function callback() self:onOkPutOn() end
			local callfunc = cc.CallFunc:create(callback)
			if (_type == 2 and unlock == false) then
	            self.m_curActivateType = 2
				YesNoDialog:call("show", getLang("160374"), callfunc) -- 首次激活上古龙语将会消耗相应的龙韵石各一枚，再次激活时不再消耗。确定激活吗？
			elseif (_type == 3 and (endTime <= now)) then
	            self.m_curActivateType = 3
				YesNoDialog:call("show", getLang("160516"), callfunc)  -- 每次激活契约龙语将会消耗相应的龙韵石各一枚，确定激活吗？
			else
	            self.m_curActivateType = 1
				self:onOkPutOn()
			end
		end
	end
end

function KnightTitileView:resetBtnStorageText()
	if KnightController.getInstance():isKnightInStorage(self.m_knightId) then 
		CCCommonUtilsForLua:setButtonTitle(self.m_pBtnStorage, getLang("160578")) -- 取消记忆
		CCCommonUtilsForLua:call("setButtonSprite", self.m_pBtnStorage, "mail_red_btn.png")
	else
		CCCommonUtilsForLua:setButtonTitle(self.m_pBtnStorage, getLang("160577")) -- 记忆
		CCCommonUtilsForLua:call("setButtonSprite", self.m_pBtnStorage, "btn_green3.png")
	end
end



function KnightTitileView:onClickPutBtn()
	if (self.m_guideKey == "KnightT_G3") then
		CCSafeNotificationCenter:postNotification(GUIDE_INDEX_CHANGE, CCString:create(self.m_guideKey))
	end
	
	self.m_waitInterface = GameController:call("showWaitInterface1", self.m_putBtn)
	self.m_bEndPost = false
	self.m_bEndPlay = false


	local knightTitleId = KnightTitleController:call("getInstance"):call("getCurrentOnId")	
	if (knightTitleId == self.m_knightId) then

		-- 取消激活
		LogController:call("postEventLog", "Knight_cancel")
		-- MyPrint("breakpoint -1")
		KnightTitleController:call("getInstance"):call("startPutOnKnightTitle", -1)

		for i = 1, #self.m_showSprdVec do
			self.m_showSprdVec[i]:runAction(cc.FadeOut:create(0.5))

			local count = 2
			local tmpStart = "DragLanCancel_"
			for j = 0, count do
				local resName = string.format("%s%d", tmpStart, j)
				local particle = ParticleController:call("createParticle", resName)
				particle:setPosition(self.m_showSprdVec[i]:getPosition())
				self.m_showSprdVec[i]:getParent():addChild(particle)
			end
		end

        --AdjustII:TakeOffKnight
        local param = {knightId = knightTitleId}
        sendAdjustStatistic("TakeOffKnight", param)

		local function callback() self:onEndFuc() end
		local node = cc.Node:create()
		self:addChild(node)
		performWithDelay(node, callback, 1.5)
	else
		-- local kInfos = KnightTitleController:call("getInstance"):getProperty("KnightTitleInfoMap")
		-- local kInfo = kInfos[self.m_knightId]

		-- 激活
		local kInfo = KnightTitleController:call("getInstance"):call("getKnightInfoById", self.m_knightId)
		if not kInfo then return end

		local _type = kInfo:call("getType")
		local unlock = kInfo:call("getBeUnlocked")

		if kInfo:call("isRankConditionOkToUnlock") == false then
			local function fun()
				local kkInfo = KnightTitleController:call("getInstance"):call("getKnightInfoById", self.m_knightId)
				if not kkInfo then return end
				PopupViewController:call("removeAllPopupView")
				local view = Drequire("game.CommonPopup.Knight.KnightListView"):create()
				if view then
					PopupViewController:call("addPopupInView", view)
					view:showRank(kkInfo:call("getPreClassify"))
				end
			end
			
			local func = cc.CallFunc:create(fun)
			local dialog = YesNoDialog:call("show", getLang("160514", tostring(kInfo:call("getPreClassify"))), func)
			if dialog then
				dialog:call("setYesButtonTitle", getLang("160519"))
			end

			if (self.m_waitInterface) then
				self.m_waitInterface:call("remove")
				self.m_waitInterface = nil
			end

			return
		end

		local endTime = kInfo:call("getEndTime")
		local now = GlobalData:call("getTimeStamp")
		local function callback() self:onOkPutOn() end
		local callfunc = cc.CallFunc:create(callback)
		if (_type == 2 and unlock == false) then
            self.m_curActivateType = 2
			YesNoDialog:call("show", getLang("160374"), callfunc)
		elseif (_type == 3 and (endTime <= now)) then
            self.m_curActivateType = 3
			YesNoDialog:call("show", getLang("160516"), callfunc)
		else
            self.m_curActivateType = 1
			self:onOkPutOn()
		end
	end

	
end

function KnightTitileView:onOkPutOn()
	LogController:call("postEventLog", "Knight_activation")
	KnightTitleController:call("getInstance"):call("startPutOnKnightTitle", self.m_knightId)

    if 1 == self.m_curActivateType then
        --AdjustII:PutOnKnight
        local param = {knightId = self.m_knightId}
        sendAdjustStatistic("PutOnKnight", param)
    else --上古与契约
        --AdjustII:ActivateKnightFirst
        local param = {knightId = self.m_knightId}
        sendAdjustStatistic("ActivateKnightFirst", param)
    end
    self.m_curActivateType = 1 --归为默认值

	self:onPlayUse()
end

function KnightTitileView:onHelpBtnClick()
	FaqHelper:call("showSingleFAQ", "45224")
end

function KnightTitileView:onUpdatePutNode()
	-- local kInfos = KnightTitleController:call("getInstance"):getProperty("KnightTitleInfoMap")
	-- local kInfo = kInfos[self.m_knightId]

	local kInfo = KnightTitleController:call("getInstance"):call("getKnightInfoById", self.m_knightId)
	if not kInfo then return end

	self.m_bedgeIdVec = kInfo:getProperty("mateVec")
	self.m_bedgeHaveVec = {}
	self.m_showSprdVec = {}
	self.m_clickSprdVec = {}
	self.m_putNode:removeAllChildren()
	self.m_showNode:removeAllChildren()
	self.m_putNum = 0

	local cellW = 100
	local size = #self.m_bedgeIdVec
	if (size == 4) then
		cellW = 100
	elseif (size < 4) then
		cellW = 110
	end

	local _type = kInfo:call("getType")
	self.m_type = _type
	local unlock = kInfo:call("getBeUnlocked")
	local now = GlobalData:call("getTimeStamp")
	local halfNum = math.floor(size / 2)
	if (size % 2 == 0) then
		halfNum = halfNum - 0.5
	end

	for i = 1, size do
		local info = ToolController:call("getToolInfoByIdForLua", self.m_bedgeIdVec[i])
		local strBedgeid = tostring(self.m_bedgeIdVec[i])
		local iconShowStr = CCCommonUtilsForLua:call("getPropById", strBedgeid, "icon")
		iconShowStr = iconShowStr .. "_a.png"
		local iconStr = CCCommonUtilsForLua:call("getIcon", strBedgeid)
		if (_type == 2 or _type == 3) then
			iconStr = CCCommonUtilsForLua:call("getPropById", strBedgeid, "icon")
			iconStr = iconStr .. "_b.png"
		end
		Dprint("@@ PNG:",iconStr, iconShowStr)

		local iconPut = CCLoadSprite:call("createSprite", iconStr, CCLoadSpriteType_GOODS)
		local iconShow = CCLoadSprite:call("createSprite", iconShowStr, CCLoadSpriteType_GOODS)

		CCCommonUtilsForLua:setSpriteMaxSize(iconShow, 90, true)
		if (_type == 2 or _type == 3) then
			CCCommonUtilsForLua:setSpriteMaxSize(iconPut, 80, true)
		else
			CCCommonUtilsForLua:setSpriteMaxSize(iconPut, 90, true)
		end

		local node = cc.Node:create()
		node:addChild(iconPut)
		node:setPosition((i - halfNum - 1) * cellW, 0)
		node:setTag(self.m_bedgeIdVec[i])

		local para4 = info:getProperty("para4")
		local label = CCLabelIF:call("create8", getLang(para4), 24, cc.size(0, 0), 1, 1)
		label:call("setColor", cc.c3b(235, 146, 0))

		tolua.cast(label, "cc.Node"):setPosition(node:getPositionX(), node:getPositionY() - 60)
		self.m_putNode:addChild(tolua.cast(label, "cc.Node"))
		
		iconShow:setPosition(self.m_putPtVec[i])

		self.m_putNode:addChild(node)
		self.m_showNode:addChild(iconShow)

		if self.storageView:isStorageShow() then 
			self.m_showNode:setVisible(false)
		else
			self.m_showNode:setVisible(true)
		end

		self.m_showSprdVec[#self.m_showSprdVec + 1] = iconShow
		self.m_clickSprdVec[#self.m_clickSprdVec + 1] = iconPut

		local bedgeCnt = info:call("getCNT")
		if CCCommonUtilsForLua:isFunOpenByKey("dragon_words_new_combine") then
			-- 3代表正常显示
			-- 2代表点击确认
			-- 1代表已经有别人使用
			if (unlock and _type == 2) then
				self.m_bedgeHaveVec[#self.m_bedgeHaveVec + 1] = 3
			else
				if (bedgeCnt <= 0) then
					self.m_bedgeHaveVec[#self.m_bedgeHaveVec + 1] = 0
				else
					self.m_bedgeHaveVec[#self.m_bedgeHaveVec + 1] = 2
				end
			end
		else
			if (_type == 2) then
				if (unlock) then
					self.m_bedgeHaveVec[#self.m_bedgeHaveVec + 1] = 3
				else
					if (bedgeCnt > 1) then
						self.m_bedgeHaveVec[#self.m_bedgeHaveVec + 1] = 2
					elseif (bedgeCnt <= 0) then
						self.m_bedgeHaveVec[#self.m_bedgeHaveVec + 1] = 0
					else
						local ret = KnightTitleController:call("getInstance"):call("GetUseBedgeById", self.m_bedgeIdVec[i])
						if (ret == 1) then
							self.m_bedgeHaveVec[#self.m_bedgeHaveVec + 1] = 1
						else
							self.m_bedgeHaveVec[#self.m_bedgeHaveVec + 1] = 2
						end
					end
				end
			elseif (_type == 3) then
				local endTime = kInfo:call("getEndTime")
				if endTime > now then
					self.m_bedgeHaveVec[#self.m_bedgeHaveVec + 1] = 3
				else
					if (bedgeCnt > 1) then
						self.m_bedgeHaveVec[#self.m_bedgeHaveVec + 1] = 2
					elseif (bedgeCnt <= 0) then
						self.m_bedgeHaveVec[#self.m_bedgeHaveVec + 1] = 0
					else
						local ret = KnightTitleController:call("getInstance"):call("GetUseBedgeById", self.m_bedgeIdVec[i])
						if (ret == 1) then
							self.m_bedgeHaveVec[#self.m_bedgeHaveVec + 1] = 1
						else
							self.m_bedgeHaveVec[#self.m_bedgeHaveVec + 1] = 2
						end
					end
				end
			else
				if (bedgeCnt > 0) then
					self.m_bedgeHaveVec[#self.m_bedgeHaveVec + 1] = 3
				else
					self.m_bedgeHaveVec[#self.m_bedgeHaveVec + 1] = 0
				end
			end
		end
	end
	if CCCommonUtilsForLua:isFunOpenByKey("dragon_words_new_combine") then
		for i = 1, #self.m_bedgeHaveVec do
			self.m_showSprdVec[i]:setVisible(false)
			local knightTitleId = KnightTitleController:call("getInstance"):call("getCurrentOnId")
			if (self.m_knightId == knightTitleId) then
				self.m_showSprdVec[i]:setVisible(true)
			end

			if (self.m_bedgeHaveVec[i] == 0) then
				local info = ToolController:call("getToolInfoByIdForLua", self.m_bedgeIdVec[i])
				CCCommonUtilsForLua:setSpriteGray(self.m_clickSprdVec[i], true)
			elseif (self.m_bedgeHaveVec[i] == 2 and _type == 2) then
				local fadeIn = cc.FadeIn:create(0.5)
				local fadeOut = cc.FadeOut:create(0.5)
				local seq = cc.Sequence:create(fadeIn, fadeOut)
				local forever = cc.RepeatForever:create(seq)
				self.m_clickSprdVec[i]:runAction(forever)
			elseif (self.m_bedgeHaveVec[i] == 3) then
				self.m_putNum = self.m_putNum + 1
			end
		end
	else
		for i = 1, #self.m_bedgeHaveVec do
			self.m_showSprdVec[i]:setVisible(false)

			local knightTitleId = KnightTitleController:call("getInstance"):call("getCurrentOnId")
			if (self.m_knightId == knightTitleId) then
				self.m_showSprdVec[i]:setVisible(true)
			end

			if (self.m_bedgeHaveVec[i] == 0) then
				local info = ToolController:call("getToolInfoByIdForLua", self.m_bedgeIdVec[i])
				if (_type == 2) then
					CCCommonUtilsForLua:setSpriteGray(self.m_clickSprdVec[i], true)
				else
					local id = info:getProperty("itemId")
					local bg = "dgs_1_5.png"
					if (id == 209866 or id == 209867 or id == 209868 or id == 209869 or id == 209870) then
						bg = "dgs_6_10.png"
					elseif (id == 209871 or id == 209872 or id == 209873 or id == 209874 or id == 209875) then
						bg = "dgs_11_15.png"
					elseif (id == 209876 or id == 209877 or id == 209878 or id == 209879 or id == 209880) then
						bg = "dgs_16_20.png"
					end

					local frame = CCLoadSprite:call("loadResource", bg)
					self.m_clickSprdVec[i]:setSpriteFrame(frame)
					CCCommonUtilsForLua:setSpriteMaxSize(self.m_clickSprdVec[i], 90, true)

					local addicon = CCLoadSprite:call("createSprite", "icon_hospital.png")
					addicon:setPosition(self.m_clickSprdVec[i]:getPosition())
					self.m_clickSprdVec[i]:getParent():addChild(addicon)
				end
			elseif (self.m_bedgeHaveVec[i] == 1 or self.m_bedgeHaveVec[i] == 2) then
				local fadeIn = cc.FadeIn:create(0.5)
				local fadeOut = cc.FadeOut:create(0.5)
				local seq = cc.Sequence:create(fadeIn, fadeOut)
				local forever = cc.RepeatForever:create(seq)
				self.m_clickSprdVec[i]:runAction(forever)
			elseif (self.m_bedgeHaveVec[i] == 3) then
				self.m_putNum = self.m_putNum + 1
			end
		end
	end
	self:resetBtns()
end

function KnightTitileView:resetBtns()
	-- body

	local kInfo = KnightTitleController:call("getInstance"):call("getKnightInfoById", self.m_knightId)
	if not kInfo then return end
	self.m_type = kInfo:call("getType")
	local unlock = kInfo:call("getBeUnlocked")


	if CCCommonUtilsForLua:isFunOpenByKey("dragon_words_activate_memory") then 
		self.m_putBtn:setVisible(false)
		self.m_pBtnStorage:setVisible(true)
		self.m_pBtnQuickPut:setVisible(true)
	else
		self.m_putBtn:setVisible(true)
		self.m_pBtnStorage:setVisible(false)
		self.m_pBtnQuickPut:setVisible(false)
	end

	self.m_putBtn:setEnabled(true)
	self.m_pBtnStorage:setEnabled(true)
	self.m_pBtnQuickPut:setEnabled(true)

	

	self:resetBtnStorageText()

	local knightTitleId = KnightTitleController:call("getInstance"):call("getCurrentOnId")
	if (self.m_knightId == knightTitleId) then
		CCCommonUtilsForLua:setButtonTitle(self.m_putBtn, getLang("160326")) -- 取消激活
		CCCommonUtilsForLua:call("setButtonSprite", self.m_putBtn, "mail_red_btn.png")

		CCCommonUtilsForLua:setButtonTitle(self.m_pBtnQuickPut, getLang("160326")) -- 取消激活
		CCCommonUtilsForLua:call("setButtonSprite", self.m_pBtnQuickPut, "mail_red_btn.png")
	else
		CCCommonUtilsForLua:setButtonTitle(self.m_putBtn, getLang("160299")) -- 激活
		CCCommonUtilsForLua:call("setButtonSprite", self.m_putBtn, "btn_green3.png")

		CCCommonUtilsForLua:setButtonTitle(self.m_pBtnQuickPut, getLang("160299"))
		CCCommonUtilsForLua:call("setButtonSprite", self.m_pBtnQuickPut, "btn_green3.png")
	end

	self.node_knightNumAll:setVisible(false)
	if self.m_type == 1 and CCCommonUtilsForLua:isFunOpenByKey("dragon_words_activate_memory") then

		Dprint("@@ knightid:",self.m_knightId)
		local needNum,haveNum = self:calculateBedgeNum()
		self.m_needNum = needNum
		self.m_haveNum = haveNum
		self.m_putBtn:setEnabled(true)
		self.m_pBtnQuickPut:setEnabled(true)

		if self.m_knightId ~= knightTitleId then
			if haveNum >= needNum then
				CCCommonUtilsForLua:setButtonTitle(self.m_pBtnQuickPut, getLang("160573")) -- 一键激活
			else
				CCCommonUtilsForLua:setButtonTitle(self.m_pBtnQuickPut, getLang("160574") .. "\n" .. getLang("160575", CC_ITOA_K(needNum - haveNum)))
			end
		end

	else

		Dprint("@@ self.m_putNum",self.m_putNum, #self.m_bedgeIdVec)

		if (self.m_type == 2 and unlock == true) or (self.m_putNum == #self.m_bedgeIdVec) then
			self.m_putBtn:setEnabled(true)
			self.m_pBtnQuickPut:setEnabled(true)
		else
			self.m_putBtn:setEnabled(false)
			self.m_pBtnQuickPut:setEnabled(false)

			CCCommonUtilsForLua:call("setButtonSprite", self.m_putBtn, "Btn_grey.png")
			CCCommonUtilsForLua:call("setButtonSprite", self.m_pBtnQuickPut, "Btn_grey.png")
		end

		if self.m_type == 2 and unlock == false and  CCCommonUtilsForLua:isFunOpenByKey("dragon_words_activate_memory") then
			local needNum,haveNum = self:calculateBedgeNum()
			self.m_needNum = needNum
			self.m_haveNum = haveNum

			self.node_knightNumAll:setVisible(true)
			self.txt_needNum0:setString(CC_ITOA_K(self.m_needNum))
			self.txt_needNum0:setColor(cc.c3b(184, 172, 132))

			if self.m_knightId ~= knightTitleId then
				if haveNum < needNum then
					CCCommonUtilsForLua:setButtonTitle(self.m_pBtnQuickPut, getLang("160575", CC_ITOA_K(needNum - haveNum)))
					self.txt_needNum0:setColor(cc.c3b(255, 0, 0))
				end
			end
		end

	end
end

function KnightTitileView:onShowMsg()
	local fontSize = 22
	local sc = 1.0
	if (CCCommonUtilsForLua:isIosAndroidPad()) then
		fontSize = 44
		sc = 2.4
	end

	-- local kInfos = KnightTitleController:call("getInstance"):getProperty("KnightTitleInfoMap")
	-- local kInfo = kInfos[self.m_knightId]
	local kInfo = KnightTitleController:call("getInstance"):call("getKnightInfoById", self.m_knightId)
	if not kInfo then return end

	--显示属性
	local curY = 0
	local maxW1 = 0
	local maxW2 = 0
	local dimWidth = 350 * sc

	local disLabelNode = cc.Node:create()
	local disValueNode = cc.Node:create()

	local textAlignment1 = 0
	local textAlignment2 = 2
	local anchorX1 = 0
	local anchorX2 = 1

	if (CCCommonUtilsForLua:call("isFlip")) then
		textAlignment1 = 2
		textAlignment2 = 0
		anchorX1 = 1
		anchorX2 = 0
	end

	local showDias = kInfo:getProperty("showDias")
	--dump(showDias, "showDias")
	local values = kInfo:getProperty("values")
	--dump(values, "values")
	local listSize = self.m_infoList:getContentSize()

	-- curY = curY - 3 * sc --间隔

	local classify = kInfo:call("getClassify")
	local rankName = KnightTitleController:call("getRankName", classify)
	local titleLabel = CCLabelIF:call("create8", getLang(rankName), fontSize, cc.size(500 * sc, 0), 1, 2)
	titleLabel:call("setAnchorPoint", ccp(0.5, 0))
	titleLabel:call("setColor", cc.c3b(181, 23, 32))

	for i = 1, 30 do
		if (showDias[i] and values[i]) then
			local diaLabel = CCLabelIF:call("create8", getLang(showDias[i]), fontSize, cc.size(0, 0), textAlignment1, 0)
			diaLabel:call("setAnchorPoint", ccp(anchorX1, 1))
			diaLabel:call("setColor", cc.c3b(197, 152, 15))

			local labelH = diaLabel:call("getContentSize").height * diaLabel:call("getOriginScaleY")
			local labelW1 = diaLabel:call("getContentSize").width * diaLabel:call("getOriginScaleX")
			if (labelW1 > dimWidth) then
				diaLabel:call("setDimensions", cc.size(dimWidth, 0))
				labelH = diaLabel:call("getContentSize").height * diaLabel:call("getOriginScaleY")
				labelW1 = diaLabel:call("getContentSize").width * diaLabel:call("getOriginScaleX")
			end

			tolua.cast(diaLabel, "cc.Node"):setPosition(0, curY)
			disLabelNode:addChild(tolua.cast(diaLabel, "cc.Node"))

			labelH = labelH + 10
			maxW1 = math.max(maxW1, labelW1)

			local valueInfo = ""
			local pf = kInfo:call("getEffFormatByOrd", i)
			local pm = kInfo:call("getEffPMByOrd", i)
			if (pf == "") then
				valueInfo = valueInfo .. pm .. tostring(values[i]) .. pf .. "\n"
			else
				valueInfo = valueInfo .. pm .. string.format("%.2f", values[i]) .. pf .. "\n"
			end

			local valLabel = CCLabelIF:call("create8", valueInfo, fontSize, cc.size(0, 0), textAlignment2, 0)
			valLabel:call("setAnchorPoint", ccp(anchorX2, 1))
			valLabel:call("setColor", cc.c3b(65, 183, 40))
			
			local labelW2 = valLabel:call("getContentSize").width * valLabel:call("getOriginScaleX")
			maxW2 = math.max(maxW2, labelW2)

			tolua.cast(valLabel, "cc.Node"):setPosition(0, curY)
			disValueNode:addChild(tolua.cast(valLabel, "cc.Node"))

			curY = curY - labelH
		else
			break
		end
	end

	local funShowDias = kInfo:getProperty("funShowDias")
	--dump(funShowDias, "funShowDias")
	local funValues = kInfo:getProperty("funValues")
	--dump(funValues, "funValues")
	for i = 1, 7 do
		if (funShowDias[i] and funValues[i]) then
			local diaLabel = CCLabelIF:call("create8", getLang(funShowDias[i]), fontSize, cc.size(0, 0), textAlignment1, 0)
			tolua.cast(diaLabel, "cc.Node"):setPosition(0, curY)
			diaLabel:call("setAnchorPoint", ccp(anchorX1, 1))
			diaLabel:call("setColor", cc.c3b(197, 152, 15))
			disLabelNode:addChild(tolua.cast(diaLabel, "cc.Node"))

			local labelH = diaLabel:call("getContentSize").height * diaLabel:call("getOriginScaleY")
			local labelW1 = diaLabel:call("getContentSize").width * diaLabel:call("getOriginScaleX")
			if (labelW1 > dimWidth) then
				diaLabel:call("setDimensions", cc.size(dimWidth, 0))
				labelH = diaLabel:call("getContentSize").height * diaLabel:call("getOriginScaleY")
				labelW1 = diaLabel:call("getContentSize").width * diaLabel:call("getOriginScaleX")
			end
			maxW1 = math.max(maxW1, labelW1)

			local valueInfo = ""
			local pf = kInfo:call("getFunFormatByOrd", i)
			local pm = kInfo:call("getFunPMByOrd", i)
			if (#funValues > 0) then
				if (pf == "") then
					valueInfo = valueInfo .. pm .. tostring(funValues[i]) .. pf .. "\n"
				else
					valueInfo = valueInfo .. pm .. string.format("%.2f", funValues[i]) .. pf .. "\n"
				end
			end

			local valLabel = CCLabelIF:call("create8", valueInfo, fontSize, cc.size(0, 0), textAlignment2, 0)
			valLabel:call("setAnchorPoint", ccp(anchorX2, 1))
			valLabel:call("setColor", cc.c3b(65, 183, 40))
			tolua.cast(valLabel, "cc.Node"):setPosition(0, curY)
			disValueNode:addChild(tolua.cast(valLabel, "cc.Node"))

			local labelW2 = valLabel:call("getContentSize").width * valLabel:call("getOriginScaleX")
			maxW2 = math.max(maxW2, labelW2)

			curY = curY - labelH
		else
			break
		end
	end

	--curY = curY - 30 * sc --间隔
	curY = curY - 3 * sc --间隔
	local bianH = 50 * sc
	local des = kInfo:call("getDes")
	local desLabel = CCLabelIF:call("create8", getLang(des), fontSize, cc.size(500 * sc, 0), 1, 2)
	desLabel:call("setAnchorPoint", ccp(0.5, 0))
	desLabel:call("setColor", cc.c3b(197, 152, 15))

	curY = curY - desLabel:call("getContentSize").height * desLabel:call("getOriginScaleY")
	local desW = desLabel:call("getContentSize").width * desLabel:call("getOriginScaleX")

	local extH = 0
	local _type = kInfo:call("getType")
	if (_type == 2) then
		local des2Label = CCLabelIF:call("create8", getLang("160489"), fontSize, cc.size(500 * sc, 0), 1, 2)
		des2Label:call("setAnchorPoint", ccp(0.5, 0))
		des2Label:call("setColor", cc.c3b(255, 0, 0))

		extH = des2Label:call("getContentSize").height * des2Label:call("getOriginScaleY")
		curY = curY - extH

		local des2W = des2Label:call("getContentSize").width * des2Label:call("getOriginScaleX")

		tolua.cast(des2Label, "cc.Node"):setSkewX(10)
		tolua.cast(des2Label, "cc.Node"):setPosition(listSize.width / 2 - des2W / 2, bianH)
		self.m_scrollView:addChild(tolua.cast(des2Label, "cc.Node"))
	end

	if (_type == 3) then
		local des2Label = CCLabelIF:call("create8", getLang("160513"), fontSize, cc.size(500 * sc, 0), 1, 2)
		des2Label:call("setAnchorPoint", ccp(0.5, 0))
		des2Label:call("setColor", cc.c3b(255, 0, 0))

		local des2W = des2Label:call("getContentSize").width * des2Label:call("getOriginScaleX")
		local des2H = des2Label:call("getContentSize").height * des2Label:call("getOriginScaleY")
		extH = extH + des2H

		tolua.cast(des2Label, "cc.Node"):setSkewX(10)
		tolua.cast(des2Label, "cc.Node"):setPositionX(self.m_infoList:getContentSize().width / 2 - des2W / 2)
		self.m_scrollView:addChild(tolua.cast(des2Label, "cc.Node"))

		extH = extH + 10 * sc

		self.m_timeLabel1 = cc.LabelTTF:create()
		self.m_timeLabel1:setString("a")
		self.m_timeLabel1:setColor(cc.c3b(197, 152, 15))
		self.m_timeLabel1:setAnchorPoint(ccp(0, 0))
		self.m_timeLabel1:setFontSize(fontSize)

		self.m_timeLabel2 = cc.LabelTTF:create()
		self.m_timeLabel2:setString("a")
		self.m_timeLabel2:setColor(cc.c3b(65, 183, 40))
		self.m_timeLabel2:setAnchorPoint(ccp(0, 0))
		self.m_timeLabel2:setFontSize(fontSize)

		local timeLabelH = self.m_timeLabel1:getContentSize().height * self.m_timeLabel1:getScaleY()
		extH = extH + timeLabelH
		curY = curY - extH
		self.m_scrollView:addChild(self.m_timeLabel1)
		self.m_scrollView:addChild(self.m_timeLabel2)

		tolua.cast(des2Label, "cc.Node"):setPositionY(bianH + extH - des2H)
		self.m_timeLabel1:setPositionY(bianH)
		self.m_timeLabel2:setPositionY(bianH)
	end

	local titleW = titleLabel:call("getContentSize").width * titleLabel:call("getOriginScaleX")
	tolua.cast(titleLabel, "cc.Node"):setPosition(listSize.width / 2 - titleW / 2, 40 * sc - curY + bianH )

	tolua.cast(desLabel, "cc.Node"):setSkewX(10)
	tolua.cast(desLabel, "cc.Node"):setPosition(listSize.width / 2 - desW / 2, bianH + extH + 10)


	local sumW = maxW1 + maxW2
	local sumH = 40 * sc - curY + bianH * 2
	local extW = (listSize.width - sumW) / 3
	if (CCCommonUtilsForLua:call("isFlip")) then
		disValueNode:setPosition(extW, sumH - bianH)
		disLabelNode:setPosition(listSize.width - extW, sumH - bianH)
	else
		disLabelNode:setPosition(extW, sumH - bianH)
		disValueNode:setPosition(listSize.width - extW, sumH - bianH)
	end

	self.m_scrollView:addChild(titleLabel)
	self.m_scrollView:addChild(disLabelNode)
	self.m_scrollView:addChild(disValueNode)
	self.m_scrollView:addChild(tolua.cast(desLabel, "cc.Node"))
	self.m_scrollView:setContentSize(cc.size(listSize.width, sumH))
	self.m_scrollView:setContentOffset(ccp(0, listSize.height - sumH))
end

function KnightTitileView:setBedgeData(pObj)
	local paramCCStr = tolua.cast(pObj, "CCString")
	if (paramCCStr) then
		local bedgeId = paramCCStr:getCString()
		local view = require("game.CommonPopup.Knight.BedgeInfoPop"):create(atoi(bedgeId))
		PopupViewController:addPopupView(view)
	end
end

function KnightTitileView:onPlayUse()
	self.m_flyNode:removeAllChildren()
	for i = 1, #self.m_clickSprdVec do
		local pt1 = ccp(self.m_showSprdVec[i]:getPosition())
		local worldpt1 = self.m_showNode:convertToWorldSpace(pt1)
		local endPt = self.m_flyNode:convertToNodeSpace(worldpt1)

		local pt2 = ccp(self.m_clickSprdVec[i]:getPosition())
		local worldpt2 = self.m_clickSprdVec[i]:getParent():convertToWorldSpace(pt2)
		local startPt = self.m_flyNode:convertToNodeSpace(worldpt2)

		local strBedgeid = tostring(self.m_bedgeIdVec[i])
		local iconShowStr = CCCommonUtilsForLua:call("getPropById", strBedgeid, "icon")
		iconShowStr = iconShowStr .. "_a.png"
		local playIcon = CCLoadSprite:call("createSprite", iconShowStr, CCLoadSpriteType_GOODS)
		playIcon:setPosition(startPt)
		CCCommonUtilsForLua:setSpriteMaxSize(playIcon, 90, true)
		playIcon:setScale(1.0)
		self.m_flyNode:addChild(playIcon)

		local particle = ParticleController:call("createParticle", "DragLanAct_tails")
		playIcon:addChild(particle)

		local scaleTo1 = cc.ScaleTo:create(0.5, 1.5)
		local moveTo1 = cc.MoveTo:create(0.5, ccp(endPt.x, endPt.y + 100))
		local easeExponentialIn = cc.EaseExponentialOut:create(moveTo1)
		local spawn = cc.Spawn:create(scaleTo1, easeExponentialIn)

		local delayT1 = cc.DelayTime:create(0.5)
		local moveTo2 = cc.MoveTo:create(0.2, endPt)
		local easeBackIn = cc.EaseBackIn:create(moveTo2)

		local fadeOut = cc.FadeOut:create(0.3)

		local function callback1() self:addCancelParticle(i) end
		local function callback2() self:palyShowIcon(i) end
		local fun1 = cc.CallFunc:create(callback1)
		local fun2 = cc.CallFunc:create(callback2)

		local seq = cc.Sequence:create(spawn, delayT1, easeBackIn, func1, fadeOut, fun2)
		playIcon:runAction(seq)
	end

	local function callback() self:onEndFuc() end
	local node = cc.Node:create()
	self:addChild(node)
	performWithDelay(node, callback, 1.5)
end

function KnightTitileView:addCancelParticle(idx)
	if (idx > 0 and #self.m_showSprdVec >= idx) then
		local count = 2
		for i = 0, count do
			local particle = ParticleController:call("createParticle", "DragLanAct_" .. i)
			particle:setPosition(self.m_showSprdVec[idx]:getPosition())
			self.m_showSprdVec[idx]:getParent():addChild(particle)
		end
	end
end

function KnightTitileView:palyShowIcon(idx)
	if (idx > 0 and #self.m_showSprdVec >= idx) then
		self.m_showSprdVec[idx]:setOpacity(0)
		self.m_showSprdVec[idx]:setVisible(true)
		self.m_showSprdVec[idx]:runAction(cc.FadeIn:create(0.4))
	end
end

function KnightTitileView:onEndFuc(dt)
	self.m_bEndPlay = true
	self:onEndChange()
end

-- 计算激活需要的龙韵石数量 和 可分解龙韵石的数量
function KnightTitileView:calculateBedgeNum()
	local size = #self.m_bedgeIdVec
	local needNum = 0
	local haveNum = 0

	for i = 1, size do
		local info = ToolController:call("getToolInfoByIdForLua", self.m_bedgeIdVec[i])
		local cnt = 1
		local level = (tonumber(info:getProperty("para5")) or 0) - 1 -- 等级文本
		-- Dprint("@@ needNum :",self.m_bedgeIdVec[i],level, math.pow(2,level))

		if level > 0 then
			needNum = needNum + math.pow(2,level) * cnt  -- 换算成1级龙韵石的数量
		else
			needNum = needNum + cnt
		end
	end

	local resLists = ToolController:call("getInstance"):getProperty("m_typeTools")
	local tmpVec = resLists[19]

	for i,v in ipairs(tmpVec) do
		local info = ToolController:call("getToolInfoByIdForLua", v)
		local cnt = info:call("getCNT")
		local level = (tonumber(info:getProperty("para5")) or 0) - 1 -- 等级文本
		-- Dprint("@@ have :",i,v,cnt,level, math.pow(2,level))

		if level > 0 then
			haveNum = haveNum + math.pow(2,level) * cnt  -- 换算成1级龙韵石的数量
		else
			haveNum = haveNum + cnt
		end
	end

	-- Dprint("@@. need@have. ",needNum, haveNum)
	return needNum,haveNum
end	

return KnightTitileView