	NewPlayerSignInRewardView = class("NewPlayerSignInRewardView", function()
        return PopupBaseView:create()
    end
)
NewPlayerSignInRewardView.__index = NewPlayerSignInRewardView

local ms_path = "game.CommonPopup.Merchant.MerchantShining"
local MerchantShining = Drequire(ms_path)

local NewPlayerSignInReward_Cell_Height = 90
local NewPlayerSignInReward_Cell_Width = 600
local special = {2,4,7}
------------------------------------------ NewPlayerSignInRewardCell Start --------------------------------------------
local NewPlayerSignInRewardCell = class("NewPlayerSignInRewardCell", function()
    return cc.Layer:create()
end)

function NewPlayerSignInRewardCell:create(tbl)
    local ret = NewPlayerSignInRewardCell.new()
    if ret:init(tbl) == false then
    	return nil
    end
    return ret
end

function NewPlayerSignInRewardCell:init(tbl)
  --初始化界面
    MyPrint("NewPlayerSignInRewardCell init start")
	local proxy = cc.CCBProxy:create()
	local ccbiURL = ""
	ccbiURL = "ccbi/NewPlayerSignInRewardCell.ccbi"
	local m_bIsPad = CCCommonUtilsForLua:isIosAndroidPad()
  	self.m_bIsPad = m_bIsPad
    self.m_baseScale = 1.0
  	if self.m_bIsPad then
  		ccbiURL = "hdccbi/NewPlayerSignInRewardCell.ccbi"
        self.m_baseScale = 2.4
  	end
  	local nodeccb = CCBReaderLoad(ccbiURL,proxy, self)
	if nodeccb == nil then
		MyPrint("NewPlayerSignInRewardCell loadccb error")
		return false
	end

	self:setContentSize(nodeccb:getContentSize())
	self:addChild(nodeccb)

    self.m_tbl = tbl
    dump(self.m_tbl, "NewPlayerSignInRewardCell:init")
	self:setData()

	return true
end

function NewPlayerSignInRewardCell:setData()
  	MyPrint("NewPlayerSignInRewardCell setData start")
    if self.m_tbl == nil then
        return
    end

    local valueTable = self.m_tbl.value
    if valueTable == nil then
        return
    end

    if self.m_tbl.type == nil or valueTable.id == nil or valueTable.num == nil then
        return
    end

    local itemId = tonumber(valueTable.id)
    local itemType = tonumber(self.m_tbl.type)
    local rewardNum = tonumber(valueTable.num)
    local shiningFlag = false

    local itemName = RewardController:call("getNameByType", itemType, itemId, true)
    local itemNum = " +"..tostring(rewardNum)
    self.m_nameLabel:setString(itemName)
    self.m_numLabel:setString(itemNum)
    self.m_picNode:removeAllChildren()
    if itemType == RewardTypeConfig.R_GOODS then
        local toolInfo = ToolController:call("getToolInfoByIdForLua", itemId)
        if toolInfo ~= nil then
            local pic = CCCommonUtilsForLua:call("getIcon", tostring(itemId))
            local picBg = CCCommonUtilsForLua:call("getToolKuangByColor", toolInfo:getProperty("color"))
            local spr = CCLoadSprite:call("createSprite", pic, CCLoadSpriteType.CCLoadSpriteType_GOODS)
            local sf = CCLoadSprite:call("getSF", picBg)
            if sf then
                self.m_bg:setSpriteFrame(sf)
            end
            CCCommonUtilsForLua:call("setSpriteMaxSize", spr, 70, true)
            self.m_picNode:addChild(spr)
            if toolInfo:getProperty("color") == 5 or toolInfo:getProperty("color") == 4 then
                shiningFlag = true
            end
        end
    elseif itemType == RewardTypeConfig.R_EQUIP then
        local pic = CCCommonUtilsForLua:call("getPropById", tostring(itemId), "icon")..".png"
        local color = CCCommonUtilsForLua:call("getPropById", tostring(itemId), "color")
        local picBg = CCCommonUtilsForLua:call("getToolKuangByColor", tonumber(color))
        local spr = CCLoadSprite:call("createSprite", pic, CCLoadSpriteType.CCLoadSpriteType_EQUIP)
        local sf = CCLoadSprite:call("getSF", picBg)
        if sf then
            self.m_bg:setSpriteFrame(sf)
        end
        CCCommonUtilsForLua:call("setSpriteMaxSize", spr, 70, true)
        self.m_picNode:addChild(spr)
        if color == "5" or color == "4" then
            shiningFlag = true
        end
    else
        if itemType == RewardTypeConfig.R_YINBI then
            itemType = WorldResourceType.YinBi
        end

        local pic = CCCommonUtilsForLua:call("getResourceIconByType", itemType)
        local spr = CCLoadSprite:call("createSprite", pic, CCLoadSpriteType.CCLoadSpriteType_RESOURCE)
        CCCommonUtilsForLua:call("setSpriteMaxSize", spr, 70, true)
        self.m_picNode:addChild(spr)
    end

    if shiningFlag then
        local shiningNode = MerchantShining:create(cc.c3b(251, 183, 40), CCSize(NewPlayerSignInReward_Cell_Width + 10, NewPlayerSignInReward_Cell_Height + 28))
        self:addChild(shiningNode)
        shiningNode:setShineAlpha(255)
        shiningNode:showEff2(true, -1)
        if self.m_bIsPad then
            shiningNode:setScale(2.4)
        end
        shiningNode:setPosition(cc.p(NewPlayerSignInReward_Cell_Width * self.m_baseScale / 2, NewPlayerSignInReward_Cell_Height * self.m_baseScale / 2 + 1))
    end        
end
------------------------------------------ NewPlayerSignInRewardCell End --------------------------------------------

------------------------------------------ NewPlayerSignInRewardView Start --------------------------------------------

function NewPlayerSignInRewardView:create()
	local view = NewPlayerSignInRewardView.new()
	if view:initView() == false then
		return nil
	end
  	return view
end

function NewPlayerSignInRewardView:initView()
	if self:init(true, 0) == false then
		MyPrint("NewPlayerSignInRewardView init error")
    	return false
	end

    CCLoadSprite:call("doResourceByCommonIndex", 11, true)
    CCLoadSprite:call("doResourceByCommonIndex", 7, true)
	self:setHDPanelFlag(true)
	local m_bIsPad = CCCommonUtilsForLua:isIosAndroidPad()
	local proxy = cc.CCBProxy:create()
	local ccbiURL = ""
  	self.m_baseScale = 1.0
	ccbiURL = "ccbi/NewPlayerSignInRewardView.ccbi"
  	self.m_bIsPad = m_bIsPad
  	if self.m_bIsPad then
  		ccbiURL = "hdccbi/NewPlayerSignInRewardView.ccbi"
      	self.m_baseScale = 2.4
  	end
  	local nodeccb = CCBReaderLoad(ccbiURL,proxy, self)
	if nodeccb == nil then
		MyPrint("NewPlayerSignInRewardView loadccb error")
		return false
	end

	self:setContentSize(nodeccb:getContentSize())
    self:addChild(nodeccb)

    local screenSize = cc.Director:getInstance():getIFWinSize()
    local count = math.ceil(screenSize.height/120) + 1
    for i = 1, count do
        local pic = CCLoadSprite:createSprite("bg0.png")
        pic:setAnchorPoint(cc.p(0, 0))
        pic:setScale(self.m_baseScale * 2)
        pic:setPosition(cc.p(0, (i - 1) * 120))
        self.m_bgNode:addChild(pic)
    end

    self:call("setTitleName", getLang("106035"))
    CCCommonUtilsForLua:call("setButtonTitle", self.m_rwdBtn, getLang("111052"))
	local addHeight = self:call("getExtendHeight")
    self.m_bgNode:setPositionY(self.m_bgNode:getPositionY() - addHeight)
    self.m_bgSprite:setPositionY(self.m_bgSprite:getPositionY() - addHeight)
    MyPrint("NewPlayerSignInRewardView:initView addHeight is "..tostring(addHeight))
    if screenSize.height > 1000 * self.m_baseScale then
        addHeight = addHeight - 136 * self.m_baseScale
        MyPrint("NewPlayerSignInRewardView:initView addHeight is "..tostring(addHeight))
    end
    self.m_downNode:setPositionY(self.m_downNode:getPositionY() - addHeight)
    self.m_infoList:setPositionY(self.m_infoList:getPositionY() - addHeight)
    self.m_infoList:setContentSize(CCSize(self.m_infoList:getContentSize().width, self.m_infoList:getContentSize().height + addHeight))
    self.m_listBg:setContentSize(CCSize(self.m_listBg:getContentSize().width, self.m_listBg:getContentSize().height + addHeight))
    self.m_listBg:setPositionY(self.m_listBg:getPositionY() - addHeight)

	local scrollView = cc.ScrollView:create()
  	if scrollView ~= nil then
      	scrollView:setViewSize(self.m_infoList:getContentSize())
      	scrollView:setPosition(cc.p(0,0))
      	scrollView:setScale(1.0)
      	scrollView:ignoreAnchorPointForPosition(true)
      	scrollView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
      	self.m_infoList:addChild(scrollView);
 	end
  	self.scrollView = scrollView
  	self.scrollView:setTouchEnabled(true)

	self.ccbNode = nodeccb
	local function onNodeEvent(event)
		if event == "enter" then
			self:onEnter()
		elseif event == "exit" then
			self:onExit()
		end
	end
  	self.ccbNode:registerScriptHandler(onNodeEvent)

	function onTouch(eventType, x, y)  
      	if eventType == "began" then  
      	    return self:onTouchBegan(x, y)  
      	elseif eventType == "moved" then  
        	return self:onTouchMoved(x, y)  
      	else  
        	return self:onTouchEnded(x, y)  
      	end
  	end
	local touchif = tolua.cast(self,"cc.CCIFTouchNode")
	if touchif ~= nil then
      	local dic1 = CCDictionary:create()
      	dic1:setObject(CCBool:create(true),"1")
      	MyPrint("NewPlayerSignInRewardView:registerScriptTouchHandler")
      	touchif:registerScriptTouchHandler(onTouch)
      	touchif:comFunc("setTouchEnabled", dic1)
  	end

    self:bindNode()
    self:refreshView()
  	return true
end

function NewPlayerSignInRewardView:bindNode()
    self.m_rdNodeTbl = {}
    self.m_rdNodeTbl[1] = self.m_rd1Node
    self.m_rdNodeTbl[2] = self.m_rd2Node
    self.m_rdNodeTbl[3] = self.m_rd3Node
    self.m_rdNodeTbl[4] = self.m_rd4Node
    self.m_rdNodeTbl[5] = self.m_rd5Node
    self.m_rdNodeTbl[6] = self.m_rd6Node
    self.m_rdNodeTbl[7] = self.m_rd7Node

    self.m_rdOpenTbl = {}
    self.m_rdOpenTbl[1] = self.m_rd1Open
    self.m_rdOpenTbl[2] = self.m_rd2Open
    self.m_rdOpenTbl[3] = self.m_rd3Open
    self.m_rdOpenTbl[4] = self.m_rd4Open
    self.m_rdOpenTbl[5] = self.m_rd5Open
    self.m_rdOpenTbl[6] = self.m_rd6Open
    self.m_rdOpenTbl[7] = self.m_rd7Open

    self.m_rdCloseTbl = {}
    self.m_rdCloseTbl[1] = self.m_rd1Close
    self.m_rdCloseTbl[2] = self.m_rd2Close
    self.m_rdCloseTbl[3] = self.m_rd3Close
    self.m_rdCloseTbl[4] = self.m_rd4Close
    self.m_rdCloseTbl[5] = self.m_rd5Close
    self.m_rdCloseTbl[6] = self.m_rd6Close
    self.m_rdCloseTbl[7] = self.m_rd7Close

    self.m_rd1Label:setString(getLang("106036", "1"))
    self.m_rd2Label:setString(getLang("106036", "2"))
    self.m_rd3Label:setString(getLang("106036", "3"))
    self.m_rd4Label:setString(getLang("106036", "4"))
    self.m_rd5Label:setString(getLang("106036", "5"))
    self.m_rd6Label:setString(getLang("106036", "6"))
    self.m_rd7Label:setString(getLang("106036", "7"))

    for i=1,#special do
        if special[i] <= #self.m_rdNodeTbl then
            local node = cc.Node:create()
            node:setScale(0.6)
            for i=0,2 do
                local particle = ParticleController:call("createParticle", "5DayPackage_"..tostring(i))
                node:addChild(particle)
            end
            self.m_rdNodeTbl[special[i]]:addChild(node)
            node:setTag(999)
            node:setPosition(self.m_rdNodeTbl[special[i]]:getContentSize().width / 2, self.m_rdNodeTbl[special[i]]:getContentSize().height / 2)
        end
    end
end

function NewPlayerSignInRewardView:refreshView()
    self.m_get = PortActController:call("getNewHaveGetReward") -- 今天是否领奖 1为领过
    self.m_day = PortActController:call("getNewLoginDay") -- 第几天
    self.m_today = self.m_day + 1
    if self.m_get == 1 then
        self.m_today = self.m_day
    end
    self.m_viewDay = self.m_today
    MyPrint("NewPlayerSignInRewardView:refreshView self.m_day is "..tostring(self.m_day))
    MyPrint("NewPlayerSignInRewardView:refreshView self.m_today is "..tostring(self.m_today))
    MyPrint("NewPlayerSignInRewardView:refreshView self.m_get is "..tostring(self.m_get))

    local pic = ""
    if self.m_today == 1 or self.m_today == 3 or self.m_today == 6 then
        self.m_tipTxt2:setString(getLang("151655"))
        pic = "newplayer_resourceBg.png"
    elseif self.m_today == 2 or self.m_today == 4 or self.m_today == 7 then
        self.m_tipTxt2:setString(getLang("151656"))
        pic = "newplayer_goodsBg.png"
    elseif self.m_today == 5 then
        self.m_tipTxt2:setString(getLang("151657"))
        pic = "newplayer_equipBg.png"
    end
    local sf = CCLoadSprite:call("getSF",pic)
    if sf ~= nil then
        self.m_bgPic:setSpriteFrame(sf)
    end

    for i=1,7 do
        if i == self.m_today then
            self.m_rdOpenTbl[i]:setScale(0.75)
        else
            self.m_rdOpenTbl[i]:setScale(0.6)
        end
        local grayFlag = i < self.m_today or (i == self.m_today and self.m_get == 1)
        self.m_rdOpenTbl[i]:setVisible(i <= self.m_today)
        CCCommonUtilsForLua:call("setSpriteGray", self.m_rdOpenTbl[i], grayFlag)
        self.m_rdCloseTbl[i]:setVisible(i > self.m_today)
    end
    
    self:refreshReward()
end

function NewPlayerSignInRewardView:initNewPlayerSignInReward()
    self.m_reward = {}
    local rewardArr = PortActController:call("getNewRewardArray", self.m_viewDay)
    MyPrint("NewPlayerSignInRewardView:initNewPlayerSignInReward rewardArr is ", rewardArr)
    if rewardArr ~= nil then
        rewardArr = tolua.cast(rewardArr, "CCArray")
        if rewardArr ~= nil then
            local data = arrayToLuaTable(rewardArr)
            dump(data, "NewPlayerSignInRewardView:initNewPlayerSignInReward")
            if data ~= nil then
                self.m_reward = data
            end
        end
    end
end

function NewPlayerSignInRewardView:refreshReward()
    self:initNewPlayerSignInReward()
    if self.scrollView ~= nil then
        self.scrollView:getContainer():removeAllChildren()
        local cH = self.m_infoList:getContentSize().height
        local height = 0
        local mainNode = cc.Node:create();
        for i=1,#self.m_reward do
            local cell = NewPlayerSignInRewardCell:create(self.m_reward[i])
            mainNode:addChild(cell)
            height = height + NewPlayerSignInReward_Cell_Height * self.m_baseScale
            cell:setPosition(cc.p(0, 0 - height))
        end

        self.scrollView:addChild(mainNode);
        mainNode:setPosition(cc.p(0, height))
        self.scrollView:setContentSize(CCSize(self.m_infoList:getContentSize().width,height))
        self.scrollView:setContentOffset(CCPoint(0, cH - height))
    end
    local canReward = self.m_get == 0 and self.m_viewDay == self.m_today
    self.m_rwdBtn:setEnabled(canReward)
    if self.m_viewDay < self.m_today then
        CCCommonUtilsForLua:call("setButtonTitle", self.m_rwdBtn, getLang("180015"))
    elseif self.m_viewDay == self.m_today and self.m_get == 1 then
        CCCommonUtilsForLua:call("setButtonTitle", self.m_rwdBtn, getLang("180015"))
    else
        CCCommonUtilsForLua:call("setButtonTitle", self.m_rwdBtn, getLang("111052"))
    end
    for i=1,#special do
        if special[i] <= #self.m_rdNodeTbl then
            if self.m_today > special[i] then
                if self.m_rdNodeTbl[special[i]]:getChildByTag(999) then
                    self.m_rdNodeTbl[special[i]]:getChildByTag(999):removeFromParent()
                end
            elseif self.m_today == special[i] and self.m_get == 1 then
                if self.m_rdNodeTbl[special[i]]:getChildByTag(999) then
                    self.m_rdNodeTbl[special[i]]:getChildByTag(999):removeFromParent()
                end
            end
        end
    end

    if self.m_viewDay <= 7 then
        self.m_select:setPositionX(self.m_rdNodeTbl[self.m_viewDay]:getPositionX())
    end
    for i=1,7 do
        if i == self.m_viewDay then
            self.m_rdCloseTbl[i]:setScale(1)
            if i == 7 then
                self.m_rdCloseTbl[i]:setScale(0.74)
            end
        else
            self.m_rdCloseTbl[i]:setScale(0.84)
            if i == 7 then
                self.m_rdCloseTbl[i]:setScale(0.66)
            end
        end
    end
end

function NewPlayerSignInRewardView:onEnter()
	MyPrint("NewPlayerSignInRewardView:onEnter")
	local function onRefresh( ref )
		self:refreshView()
	end
	local t = tolua.cast(self, "cc.Node")
	local handler = t:registerHandler(onRefresh)
	CCSafeNotificationCenter:registerScriptObserver(self, handler, "msg.new.player.rd")
	MyPrint("NewPlayerSignInRewardView:onEnter registerScriptObserver")
end

function NewPlayerSignInRewardView:onExit()
	CCSafeNotificationCenter:unregisterScriptObserver(self, "msg.new.player.rd")
    local scene = ImperialScene:call("getInstance")
    if scene then
        MyPrint("scene", scene)
        scene:call("onMoveToSpeBuildAndPlay", 9990013, 1.5)
    end
end

function NewPlayerSignInRewardView:onTouchBegan(x, y)
  	for i=1,7 do
        if touchInside(self.m_rdNodeTbl[i], x, y) then
            return true
        end
    end
end

function NewPlayerSignInRewardView:onTouchMoved(x, y)
end

function NewPlayerSignInRewardView:onTouchEnded(x, y)
  	for i=1,7 do
        if touchInside(self.m_rdNodeTbl[i], x, y) then
            self.m_viewDay = i
            self:refreshReward()
            break
        end
    end
end

function NewPlayerSignInRewardView:onClickTipBtn()
    local tips = getLang("106039").."\n"..getLang("106040").."\n"..getLang("106041").."\n"..getLang("106042").."\n"..getLang("106043")
    if GlobalData:call("isXiaoMiPlatForm") then
        tips = getLang("106039").."\n"..getLang("106040").."\n"..getLang("106041").."\n"..getLang("106042")
    end
    local view = TipsView:call("create", tips, cc.TEXT_ALIGNMENT_LEFT)
    PopupViewController:call("addPopupView", view)
end

function NewPlayerSignInRewardView:onClickRwdBtn()
    PortActController:call("startGetNewPlayerRD")
end

function NewPlayerSignInRewardView:getGuideNode(key)
    if key == "LUA_NEWRD_get" and self.m_rwdBtn then
        local function callBack()
            self:onClickRwdBtn()
            CCSafeNotificationCenter:call("postNotification", "guide_index_change", CCString:create("LUA_NEWRD_get"))
        end
        GuideController:call("setCallback", cc.CallFunc:create(callBack))
        return self.m_rwdBtn
    elseif key == "LUA_NEWRD_next" and self.m_rd2Node then
        local function callBack()
            self.m_viewDay = 2
            self:refreshReward()
            CCSafeNotificationCenter:call("postNotification", "guide_index_change", CCString:create("LUA_NEWRD_next"))
        end
        GuideController:call("setCallback", cc.CallFunc:create(callBack))
        return self.m_rd2Node
    end
end

return NewPlayerSignInRewardView







