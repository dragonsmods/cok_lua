local btnIcon = {"icon_facebook.png","icon_Twitter.png","icon_youtube.png","icon_vk_general.png","fans_ko_icon.png","icon_google.png"}
local btnLang = {"101265","101266","101267","101297","","101268"}
local btnURL = {"https://www.facebook.com/871470146215610","https://twitter.com/ClashOfKingsCOK","http://www.youtube.com/user/ClashofKingsGame","http://vk.com/clashofking","http://cafe.naver.com/clashofkings","https://plus.google.com/communities/102750039774058615160"}
local m_bIsPad = false
local curLang = ""
local curAnalyticID = ""
local m_datas = nil

SocialPopUpLuaView = SocialPopUpLuaView or {}
ccb["SocialPopUpLuaView"] = SocialPopUpLuaView

local SocialPopUpView = class("SocialPopUpView",
    function()
        return PopupBaseView:comFunc("create",0)
    end
)
SocialPopUpView.__index = SocialPopUpView

function SocialPopUpView:create()
  local view = SocialPopUpView.new()
  if view:initView() == false then
    return false
  end
  local dict = CCDictionary:create()
  dict:setObject(view,"1")
  PopupViewController:comFunc("addPopupInView",dict)
  return true
end

function SocialPopUpView:initView()
  local dict = CCDictionary:create()
  dict:setObject(CCBool:create(true),"1")
  if self:comFunc("init",dict):getValue() == false then
    -- print("SocialPopUpView init error")
    return false
  end
  
  m_bIsPad = CCCommonUtilsForLua:comFunc("isIosAndroidPad",0):getValue()
  curLang = LocalController:comFunc("getLanguageFileName",0):getCString()
  curAnalyticID = GlobalData:comFunc("shared",0):getProperty("analyticID")
  
  self.isClose = true
  dict:setObject(CCBool:create(true),"1")
  self:comFunc("setHDPanelFlag",dict)
  local  proxy = cc.CCBProxy:create()
  local ccbiURL = ""
  if m_bIsPad == false then
    ccbiURL = "ccbi/SocialView.ccbi"
  else
    ccbiURL = "hdccbi/SocialView.ccbi"
  end
  
  local nodeccb = CCBReaderLoad(ccbiURL,proxy,SocialPopUpLuaView)
  if nodeccb == nil then
     -- print("SocialPopUpView loadccb error")
    return false
  end
  if nil ~= SocialPopUpLuaView["m_background"] then
    self.m_background = tolua.cast(SocialPopUpLuaView["m_background"],"ccui.Scale9Sprite")
  end
  if nil == self.m_background then
    -- print("SocialPopUpLuaView m_background error")
    return false
  end
  if nil ~= SocialPopUpLuaView["m_infoList"] then
    self.m_infoList = tolua.cast(SocialPopUpLuaView["m_infoList"],"cc.Node")
  end
  if nil == self.m_infoList then
    -- print("SocialPopUpLuaView m_listContainer error")
    return false
  end
  
  local curSize = nodeccb:getContentSize()
  self:setContentSize(curSize)

  local preHg = self.m_background:getContentSize().height
  dict:setObject(self.m_background,"1")
  self:comFunc("changeBGHeight",dict)
  local dh = self.m_background:getContentSize().height-preHg
  self.m_infoList:setPositionY(self.m_infoList:getPositionY()-dh)
  curSize = self.m_infoList:getContentSize()
  self.m_infoList:setContentSize(cc.size(curSize.width, curSize.height+dh))
  
  
  self.m_datas = CCArray:create()
  if curLang == "ko" then
    for index =1,5 do
      self.m_datas:addObject(CCInteger:create(index))
    end
  elseif curAnalyticID=="tstore" or curAnalyticID == "amazon" or curAnalyticID == "AppStore"then
    for index =1,4 do
      self.m_datas:addObject(CCInteger:create(index))
    end
  else
    for index =1,6 do
      if index ~= 5 then 
        self.m_datas:addObject(CCInteger:create(index))
      end
    end
  end
  m_datas = self.m_datas
  
  self:addChild(nodeccb)
  
  self.ccbNode = nodeccb
  local function onNodeEvent(event)
    if event == "enter" then
      self:onEnter()
    elseif event == "exit" then
      self:onExit()
    end
  end
  self.ccbNode:registerScriptHandler(onNodeEvent)
  
  curSize = self.m_infoList:getContentSize()  
  self.m_tableView = cc.TableView:create(curSize)
  self.m_infoList:addChild(self.m_tableView)
  self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
  self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
  self.m_tableView:setAnchorPoint(cc.p(0,0))
  self.m_tableView:setDelegate()
  self.m_tableView:registerScriptHandler(SocialPopUpView.scrollViewDidScroll,cc.SCROLLVIEW_SCRIPT_SCROLL)
  self.m_tableView:registerScriptHandler(SocialPopUpView.tableCellTouched,cc.TABLECELL_TOUCHED)
  self.m_tableView:registerScriptHandler(SocialPopUpView.cellSizeForTable,cc.TABLECELL_SIZE_FOR_INDEX)
  self.m_tableView:registerScriptHandler(SocialPopUpView.tableCellAtIndex,cc.TABLECELL_SIZE_AT_INDEX)
  self.m_tableView:registerScriptHandler(SocialPopUpView.numberOfCellsInTableView,cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
  self.m_tableView:reloadData()  
  -- 老代码，滑动老报错。为了省事，干脆禁止滑动了，反正一屏可以显示下
  self.m_tableView:setTouchEnabled(false)

end

function SocialPopUpView:onEnter()
  local dict = CCDictionary:create()
  dict:setObject(CCString:create("101264"),"1")
  local strTitle = LuaController:comFunc("getLang",dict)
  dict:setObject(strTitle,"1")
  self:comFunc("setTitleName",dict)
end

function SocialPopUpView:onExit()
  --local dict = CCDictionary:create()
  --local bIsQuitGame = GameController:comFunc("IsQuitGame",0):getValue()
  -- local bIsQuitGame = GameController:call("IsQuitGame")
  local bIsQuitGame = IsQuitGame()
--  print (bIsQuitGame)
  if bIsQuitGame == false then
    print ("isfalse!!!!")
    -- dict:setObject(CCString:create("msg_popup_remove"),"1")
    -- dict:setObject(CCString:create("3"),"2")    -- copy TypeDefinition.h PVT_alliance value
    CCSafeNotificationCenter:call("postNotification", "msg_popup_remove", CCString:create("3"))
  end
  m_datas = nil
end

function SocialPopUpView.scrollViewDidScroll(view)

end

function SocialPopUpView.tableCellTouched(tab,cell)
    
end

function SocialPopUpView.cellSizeForTable(tab,idx)

  if m_bIsPad then
    return 1536,220
  end
  return 640, 110
end

function SocialPopUpView.tableCellAtIndex(tab, idx)
  if idx >= m_datas:count() then
    -- print("SocialBtnCell tableCellAtIndex nil")
    return nil
  end
  local showIdx = m_datas:objectAtIndex(idx)
  if showIdx == nil then
    return nil
  end
  local cell = tab:dequeueCell()
  local node = nil
  if cell == nil then
    node = SocialBtnCell:create(showIdx:getValue())
    if node ~= nil then
      node:setTag(100)
      cell = cc.TableViewCell:new()
      cell:addChild(node)
    end
  else
    node = cell:getChildByTag(100)
    if node ~= nil then
      node:setData(showIdx:getValue())
    end
  end

  return cell
end

function SocialPopUpView.numberOfCellsInTableView(tab)
  return m_datas:count()
end

-- SocialBtnLuaCell  = SocialBtnLuaCell or {}
-- ccb["SocialBtnLuaCell"] = SocialBtnLuaCell

SocialBtnCell = class("SocialBtnCell",
    function()
        return cc.Layer:create() 
    end
)
SocialBtnCell.__index = SocialBtnCell

function SocialBtnCell:create(Id)
  local view = SocialBtnCell.new()
  if view:initView(Id) == true then
    return view
  end
  return nil
end

function SocialBtnCell:initView(Id)
  self.m_Id = Id
  local dict = CCDictionary:create()
  if self:init() == false then
    -- print("SocialBtnCell init error")
    return false
  end
  local  proxy = cc.CCBProxy:create()
  
  -- SocialBtnLuaCell.onGoBtnClick = function()
  --   self:onGoBtnClick()
  -- end
  
  local ccbiURL = ""
  
  local m_bIsFlip =  CCCommonUtilsForLua:comFunc("isFlip",0):getValue()
  if m_bIsFlip then
    if m_bIsPad == false then
      ccbiURL = "flipccbi"
    else
      ccbiURL = "hdflipccbi"
    end
  else
    if m_bIsPad == false then
      ccbiURL = "ccbi"
    else
      ccbiURL = "hdccbi"
    end
  end
  ccbiURL = ccbiURL .. "/SocialBtnCell.ccbi"
  
  local nodeccb = CCBReaderLoad(ccbiURL,proxy,self)
  if nodeccb == nil then
    -- print("SocialBtnCell ccbload error")
    return false
  end
  
  -- if nil ~= SocialBtnLuaCell["m_descTxt"] then
  --   self.m_descTxt = tolua.cast(SocialBtnLuaCell["m_descTxt"],"cc.Label")
  -- end
  -- if nil == self.m_descTxt then
  --    print("SocialBtnLuaCell m_descTxt error")
  --   return false
  -- end
  
  -- if nil ~= SocialBtnLuaCell["m_icon"] then
  --   self.m_icon = tolua.cast(SocialBtnLuaCell["m_icon"],"cc.Node")
  -- end
  -- if nil == self.m_icon then
  --   print("SocialBtnLuaCell m_icon error")
  --   return false
  -- end
  
  -- if nil ~= SocialBtnLuaCell["m_goBtn"] then
  --   self.m_goBtn = tolua.cast(SocialBtnLuaCell["m_goBtn"],"cc.ControlButton")
  -- end
  -- if nil == self.m_goBtn then
  --   print("SocialBtnLuaCell m_goBtn error")
  --   return false
  -- end
    
  local curSize = nodeccb:getContentSize()
  self:setContentSize(curSize)
  
  local strName = ""
  if curAnalyticID == "cn1" or GlobalData:comFunc("isXiaoMiPlatForm",0):getValue() == true then
    strName = "赞"
  else
    dict:setObject(CCString:create("101270"),"1")
    strName = LuaController:comFunc("getLang",dict):getCString()
  end
  dict:setObject(self.m_goBtn,"1")
  dict:setObject(CCString:create(strName),"2")
  CCCommonUtilsForLua:comFunc("setButtonTitle",dict)
  self:addChild(nodeccb)
  
  self:setData(self.m_Id)
  return true
end

function SocialBtnCell:onGoBtnClick()
  local dict = CCDictionary:create()
  local url = btnURL[self.m_Id]
  if self.m_Id == 2 and curLang  == "ja" then
    url = "https://twitter.com/clashofkingsJP"
  end
  --dict:setObject(CCString:create(url),"1")
  --GameController:comFunc("goTurntoUrl",dict)
  GameController:call("goTurntoUrl", url)
end

function SocialBtnCell:setData(Id)
  local dict = CCDictionary:create()
  self.m_Id = Id
  self.m_icon:removeAllChildren(true)
  local strTitle = ""
  if self.m_Id == 5 and curLang == "ko" then
    strTitle = "한국 유저 팬까페에 가입하세요！"  
  else
    dict:setObject(CCString:create(btnLang[self.m_Id]),"1")
    strTitle = LuaController:comFunc("getLang",dict):getCString()
  end
  self.m_descTxt:setString(strTitle)
  
  local strIcon = btnIcon[self.m_Id]
  if self.m_Id == 4 and curLang == "ru" then
    strIcon = "icon_vk_ru.png"
  end
  dict:setObject(CCString:create(strIcon),"1")
  local logo = CCLoadSprite:comFunc("createSprite",dict)
  dict:setObject(logo,"1")
  dict:setObject(CCInteger:create(60),"2")
  CCCommonUtilsForLua:comFunc("setSpriteMaxSize",dict)
  self.m_icon:addChild(logo)
end

return SocialPopUpView