KnightController = class("KnightController")

Drequire("game.CommonPopup.Knight.KnightCmd")

local _instance = nil



function KnightController.getInstance()
    if _instance == nil then
        _instance = KnightController.new();
        _instance:init()
    end
    return _instance;
end

function KnightController.purge()
	_instance = nil
end

function KnightController:init()
	-- body
	self.m_storage = {}
	self.m_Knight_Change_NotifyKey = "Knight_Change_StorageRefresh"
	self.m_Knight_Click_NotifyKey = "Knight_Click_StorageRefresh"
	self.m_Knight_VisibleChange_NotifyKey = "Knight_VisibleChange_NotifyKey"
	self.m_mateVec = {}
	self.m_knightId = ""
	local storageNum = 5
	for i=1,storageNum do
		table.insert(self.m_storage, { knightId = nil, isLock = false})
	end

	local cmd = KnightStorageInfoCmd:create( function(tbl)
		-- body
		self:loadData(tbl)
	end)
	cmd:sendAndRelease()


	self.m_unlockSize = 0

	local knightInstance = KnightTitleController:call("getInstance")
	local tmpStr = knightInstance:getProperty("DrogenStorageInfo")
	-- local tmpStr = "3;4"
	if not tmpStr then
		tmpStr = "5;5"
	end 
	local config = string.split(tmpStr, ";")

	for i,v in ipairs(self.m_storage) do

		if i <= tonumber(config[1]) then 
			v.isLock = false
			self.m_unlockSize = self.m_unlockSize + 1
		else
			v.isLock = true
		end
	end
end

function KnightController:loadData(tbl)
	if not tbl then 
		return
	end

	-- Dprint("@@ KnightController:loadData", tbl.knightShortCut)

	if not tbl.knightShortCut and tbl.knightShortCut == "" then 
		return 
	end

	local arr = string.split(tbl.knightShortCut, "|")
	if not arr then 
		return
	end

	for i,v in ipairs(arr) do
		local arr2 = string.split(v,";")
		if arr2[1] and arr2[2] then 
			self.m_storage[ tonumber(arr2[1])].knightId = arr2[2]
		end
	end

	CCSafeNotificationCenter:postNotification(self.m_Knight_Change_NotifyKey)
end

function KnightController:saveData()

	local strParam = ""	
	for i,v in ipairs(self.m_storage) do
		if v.knightId then
			if strParam == "" then
				strParam =  strParam .. i .. ";" .. v.knightId
			else
				strParam =  strParam .. "|" .. i .. ";" .. v.knightId
			end

		end
	end

	 --Dprint("@@ KnightController:saveData", strParam)
	if strParam ~= "" then 
		local cmd = KnightStorageModifyCmd:create(strParam, function(ret)
			-- body
			-- Dprint("@@ KnightStorageModifyCmd", ret)
		end)
		cmd:sendAndRelease()
	end
end

function KnightController:addKnight(nKnightId)
	Dprint("@@ addKnight")
	if not self:isKnightInStorage(nKnightId) then

		local bFind = false
		local index = 0
		for i,v in ipairs(self.m_storage) do
			if v.knightId == nil and not v.isLock then
				v.knightId = nKnightId
				bFind = true
				index = i
				break 
			end
		end

		if not bFind then 
			self.m_storage[self.m_unlockSize].knightId = nKnightId
			index = self.m_unlockSize
		end
		Dprint("@@ addKnight", nKnightId)
		
		return index
	end
	return false
end

function KnightController:removeKnight(nKnightId)
	-- body
	Dprint("@@ removeKnight", nKnightId)
	for i,v in ipairs(self.m_storage) do
		if tonumber(v.knightId) == tonumber(nKnightId) and not v.isLock then
			v.knightId = nil
			CCSafeNotificationCenter:postNotification(self.m_Knight_Change_NotifyKey)
			return i
		end
	end
	return false
end


function KnightController:isKnightInStorage(nKnightId)
	-- body
	for i,v in ipairs(self.m_storage) do
		if tonumber(v.knightId) == tonumber(nKnightId) and not v.isLock then
			Dprint("@@ isKnightInStorage" , true)
			return true
		end
	end
	Dprint("@@ isKnightInStorage" , false)
	return false
end


function KnightController:setMateVec(mateVec, knightId)
	self.m_mateVec = mateVec
	self.m_knightId = knightId
end

function KnightController:getMateVec()
	return self.m_mateVec or {}
end

function KnightController:getMateId()
	return self.m_knightId or ""
end

return KnightController