-------------------------------------------- NewMerchantBigCell Start --------------------------------------------
local NewMerchantBigCell = class("NewMerchantBigCell", function()
    return cc.Layer:create()
end)

NewMerchantBigCell.m_labelCellHeight = 40
NewMerchantBigCell.m_bgHeight = 130

MerchantGoodsType = 
{
    Resource = 1, -- 1、资源
    Accelerate = 2, -- 2、加速
    Increase = 3, -- 3、增益
    Other = 4, -- 4、其他
}

function NewMerchantBigCell:create(idx)
    local ret = NewMerchantBigCell.new()
    Drequire("game.CommonPopup.Merchant.NewMerchant.NewMerchantBigCell_ui"):create(ret)
    return ret
end

function NewMerchantBigCell:refreshCell(info , idx)
    self.m_index = idx
    self.m_merchantType = self.m_index + 1
    self.m_info = info
    if self.m_info then
        self.ui:setTableViewDataSource("m_infoList", self.m_info)
    end
    if self.m_merchantType == MerchantGoodsType.Resource then
        self.ui.m_lblSuper:setString(getLang("176015"))
    elseif self.m_merchantType == MerchantGoodsType.Accelerate then
        self.ui.m_lblSuper:setString(getLang("176016"))
    elseif self.m_merchantType == MerchantGoodsType.Increase then
        self.ui.m_lblSuper:setString(getLang("176017"))
    elseif self.m_merchantType == MerchantGoodsType.Other then
        self.ui.m_lblSuper:setString(getLang("176018"))
    end
    self.ui.m_infoList:setTouchEnabled(false)
end

function NewMerchantBigCell:onEnter()

end

function NewMerchantBigCell:onExit()
end

-------------------------------------------- NewMerchantBigCell End --------------------------------------------

return NewMerchantBigCell