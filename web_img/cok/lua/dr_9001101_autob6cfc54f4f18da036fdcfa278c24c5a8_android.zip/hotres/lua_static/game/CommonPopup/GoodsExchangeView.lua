--[[
    GoodsExchangeView
    道具转换界面
]]

--[[
    stuffget.info    道具合成路径
    参数
        goodsId         String      物品id
    返回
        rule(array)     合成规则，一个道具可能有多个合成规则。数组里都是SFSObj
            uuid        String      唯一id
            goodsId     String      传来物品id
            count       int         合成传来的物品一组多少个
            exchange    obj         key是物品id，value是物品数量    
            resetType   int         1-每日重置 2-每周重置 3-每月重置 4-每年重置 5-不重置
            limit       int         上限，不重置而且是-1就表示无限制
            nowCount    int         现在已经换了几次
]]
local GetGoodsExchangeInfoCommand = class("GetGoodsExchangeInfoCommand", LuaCommandBase)

function GetGoodsExchangeInfoCommand.create(goodsId)
    local cmd = GetGoodsExchangeInfoCommand.new()
    cmd:initWithName("stuffget.info")
    cmd:putParam("goodsId", CCString:create(goodsId))
    return cmd
end

function GetGoodsExchangeInfoCommand:handleReceive( dict )
    local params = self:parseMsg(dict)
    if type(params) == "boolean" then
        return params
    end

    CCSafeNotificationCenter:postNotification("GoodsExchangeView:refreshView", dict:objectForKey("params"))
    return true
end


--[[
    stuffget.convert    道具合成
    参数
        uuid
        times           int         批量合成次数
    返回
        result          bool        结果 0-失败 1-成功
        rule(array)     新的页面
            uuid        String      唯一id
            goodsId     String      传来物品id
            count       int         合成传来的物品一组多少个
            exchange    obj         key是物品id，value是物品数量    
            resetType   int         1-每日重置 2-每周重置 3-每月重置 4-每年重置 5-不重置
            limit       int         上限，不重置而且是-1就表示无限制
            nowCount    int         现在已经换了几次
]]

local GoodsExchangeCommand = class("GoodsExchangeCommand", LuaCommandBase)

function GoodsExchangeCommand.create(convertUuid, times)
    local cmd = GoodsExchangeCommand.new()
    cmd:initWithName("stuffget.convert")
    cmd:putParam("uuid", CCString:create(convertUuid))
    cmd:putParam("times", CCInteger:create(times))
    return cmd
end

function GoodsExchangeCommand:handleReceive( dict )
    local params = self:parseMsg(dict)
    if type(params) == "boolean" then
        return params
    end

    CCSafeNotificationCenter:postNotification("GoodsExchangeView:refreshView", dict:objectForKey("params"))
    return true
end




--*****************************************************************************
--*********************          GoodsExchangeView         *********************
--*****************************************************************************

local GoodsExchangeView = class("GoodsExchangeView", PopupBaseView)

function GoodsExchangeView:create(goodsId)
    local view = GoodsExchangeView.new()
    Drequire("game.CommonPopup.GoodsExchangeView_ui"):create(view)
    if view:initView(goodsId) then
        return view
    end

    return nil
end

function GoodsExchangeView:initView(goodsId)
    self.m_goodsId = goodsId
    self.m_convertRule = {}

    local toolInfo = ToolController:call("getToolInfoForLua", tonumber(self.m_goodsId))
    if nil == toolInfo then
        return false
    end

    self.ui.m_nameLabel:setString(toolInfo:call("getName"))
    self.ui.m_countLabel:setString(getLang("164055", toolInfo:call("getCNT")))
    CCCommonUtilsForLua:call("createGoodsIcon", tonumber(self.m_goodsId), self.ui.m_rewardNode, CCSizeMake(95, 95))
    self:getExchangeInfo()
    self:initInputBox()
    self:initSliderBar()
    self.m_inputBox:setText("1")
    return true
end

function GoodsExchangeView:getExchangeInfo()
    local cmd = GetGoodsExchangeInfoCommand.create(self.m_goodsId)
    cmd:send()
end

-- 初始化滑动条
function GoodsExchangeView:initSliderBar()
    local sliderW = 260
    local sliderBg = CCLoadSprite:call("createScale9Sprite", "prestige_jindutiao_bg2.png")
    sliderBg:setInsetBottom(5)
    sliderBg:setInsetLeft(5)
    sliderBg:setInsetRight(5)
    sliderBg:setInsetTop(5)
    sliderBg:setAnchorPoint(ccp(0.5,0.5))
    sliderBg:setPosition(ccp(sliderW/2, 25))
    sliderBg:setContentSize(CCSize(sliderW,18))

    local proSp = CCLoadSprite:call("createSprite","pro_soldier_jindutiao2.png")
    local thuSp = CCLoadSprite:call("createSprite","huadongtiao1.png")

    self.m_slider = CCSliderBar:call("createSlider",sliderBg, proSp, thuSp)
    self.m_slider:setMinimumValue(0.0)
    self.m_slider:setMaximumValue(1.0)
    self.m_slider:call("setProgressScaleX", sliderW/proSp:getContentSize().width)
    self.m_slider:call("setLimitMoveValueEx", 20)
    self.ui.m_nodeSlider:addChild(self.m_slider)
    local function valueChanged(pSender)
        self:callbackSlider()
    end
    self.m_slider:addHandleOfControlEvent(valueChanged, CCControlEventValueChanged)
end

-- 滑动条回调
function GoodsExchangeView:callbackSlider()
    if self.m_invalideSlider then
        self.m_invalideSlider = false
        return
    end

    local limitCount = self:getLimitCount()
    local percent = self.m_slider:getValue()
    -- 改成 四舍五入，以减少 百分比 和 绝对值 转换过程中的精度损失
    local count = math.floor(percent * limitCount + 0.5)
    if (count <= 0 and limitCount <= 0) then
        count =  1
        self.m_invalideSlider = true
        self.m_slider:setValue(1)
    elseif (count < 1 and limitCount > 0) then
        self.m_invalideSlider = true
        local value = 1.0 / limitCount
        self.m_slider:setValue(value)
        count = 1
    end
    self:refreshCount(count)
end

-- 刷新
function GoodsExchangeView:refreshCount(count)
    self.m_inputBox:setText(count)

    local rule = self.m_convertRule[self.m_selIndex+1]
    if rule then
        self.ui.m_numLabel:setString(count * rule.count)
        local dict = CCDictionary:create()
        dict:setObject(CCString:create(rule.uuid), "uuid")
        dict:setObject(CCInteger:create(count), "count")
        CCSafeNotificationCenter:postNotification("GoodsExchangeCell:refreshCount", dict)
    end
end

-- 初始化输入框
function GoodsExchangeView:initInputBox()
    local inputSize = self.ui.m_nodeInput:getContentSize();
    local inputPic = CCLoadSprite:call("createScale9Sprite", "num_text_bg.png")
    inputPic:setContentSize(inputSize)
    inputPic:setInsetBottom(1)
    inputPic:setInsetTop(1)
    inputPic:setInsetRight(1)
    inputPic:setInsetLeft(1)
    self.m_inputBox = CCEditBox:create(inputSize,inputPic)
    self.m_inputBox:setInputMode(cc.EDITBOX_INPUT_MODE_NUMERIC)
    self.m_inputBox:setMaxLength(18)
    self.m_inputBox:setReturnType(cc.KEYBOARD_RETURNTYPE_DONE)
    self.m_inputBox:setPosition(ccp(inputSize.width/2, inputSize.height/2))
    self.m_inputBox:setFontColor(cc.c3b(255, 255, 255))
    self.ui.m_nodeInput:addChild(self.m_inputBox)
    
    local function editCB (strEventName, pSender)  
        self:callbackEditBox()
    end
    self.m_inputBox:registerScriptEditBoxHandler(editCB) 
end

function GoodsExchangeView:callbackEditBox()
    local value = tonumber(self.m_inputBox:getText()) or 1
    self.m_inputBox:setText(value)
    if self.m_selIndex then
        local limitCount = self:getLimitCount()
        if limitCount > 0 then
            local percent = value / limitCount
            self.m_slider:setValue(percent)
        end
    end
end

function GoodsExchangeView:getLimitCount()
    local rule = self.m_convertRule[self.m_selIndex+1]
    if rule and rule.nowCount < rule.limit then
        local minCount = rule.limit - rule.nowCount
        for key, value in pairs(rule.exchange or {}) do
            local cost = atoi(value)
            if cost > 0 then
                local tinfo = ToolController:call("getToolInfoForLua", tonumber(key))
                if nil == tinfo then
                    return 0
                end
    
                minCount = math.min(minCount, tinfo:call("getCNT")/cost)
            end
        end

        return minCount
    else
        return 0
    end
end

function GoodsExchangeView:refreshView(paramDict)
    local params = dictToLuaTable(paramDict)

    self.m_convertRule = params.rule
    for _, rule in ipairs(self.m_convertRule) do
        rule.resetType = atoi(rule.resetType)
        rule.limit     = atoi(rule.limit)
        rule.nowCount  = atoi(rule.nowCount)
        rule.exchangeArr = {}
        for key, value in pairs(rule.exchange or {}) do
            table.insert(rule.exchangeArr, {
                itemId = key,
                num = atoi(value)
            })
        end
    end
    self.m_selIndex = 0
    if not self.m_tableCircle then
        self:initTableView()
    end
    self.m_tableCircle:reloadData()
    self:callbackEditBox()
end

function GoodsExchangeView:updateCount()
    local toolInfo = ToolController:call("getToolInfoForLua", tonumber(self.m_goodsId))
    if nil == toolInfo then
        return false
    end

    self.ui.m_countLabel:setString(getLang("164055", toolInfo:call("getCNT")))
end

function GoodsExchangeView:onEnter()
    registerScriptObserver(self, self.refreshView, "GoodsExchangeView:refreshView")
    registerScriptObserver(self, self.updateCount, MSG_REFREASH_TOOL_DATA)
end

function GoodsExchangeView:onExit()
    unregisterScriptObserver(self, "GoodsExchangeView:refreshView")
    unregisterScriptObserver(self, MSG_REFREASH_TOOL_DATA)
end

function GoodsExchangeView:initTableView()
    local listViewSize = self.ui.m_tableRoot:getContentSize()

    local function createFunc(index)
        local retView = Drequire("game.CommonPopup.GoodsExchangeCell"):create({
                    viewSize = listViewSize, 
                    itemData = self.m_convertRule[index+1],
                    index = index
                }, self)
        return retView
    end

    local function refreshFunc(cell, index)
        cell:refreshCell({
                itemData = self.m_convertRule[index+1],
                index = index
            })
    end

    local function cellMoveEvent(cell, index)
        self.m_selIndex = index

        self.ui.m_okButton:setEnabled(false)
        if self.m_selIndex then
            local rule = self.m_convertRule[self.m_selIndex+1]
            if rule then
                self.ui.m_okButton:setEnabled(rule.nowCount < rule.limit)
                self.ui.m_numLabel:setString(rule.count)
                self.m_slider:setValue(0)
                self:callbackSlider()
            end
        end
    end

    local function cellTouchedEvent(cell, index)
        return
    end

    self.m_tableCircle = Drequire("game.utility.TableViewCircle").new({
        size        = listViewSize,
        direction   = kCCScrollViewDirectionHorizontal,
        createFunc  = createFunc,
        refreshFunc = refreshFunc,
        cellMoveEvent = cellMoveEvent,
        cellTouchedEvent = cellTouchedEvent,
        cellNum     = #self.m_convertRule,
        cellSize    = listViewSize,
    })

    self.ui.m_tableRoot:addChild(self.m_tableCircle)
    self.m_selIndex = 0
end

function GoodsExchangeView:onOKButtonClick()
    if self.m_selIndex then
        local rule = self.m_convertRule[self.m_selIndex+1]
        if rule then
            for key, value in pairs(rule.exchange or {}) do
                local toolInfo = ToolController:call("getToolInfoForLua", tonumber(key))
                if toolInfo and toolInfo:call("getCNT") < atoi(value) then
                    CCCommonUtilsForLua:call("flyHint", "", "", getLang("E100165")) -- E100165=道具数量不足
                    return
                end
            end

            local times = atoi(self.m_inputBox:getText())
            local cmd = GoodsExchangeCommand.create(rule.uuid, times)
            cmd:send()
        end
    end
end

function GoodsExchangeView:onCloseButtonClick()
    PopupViewController:call("removePopupView", self)
end

return GoodsExchangeView