local CommonSetTipView = class("CommonSetTipView", PopupBaseView)

function CommonSetTipView:create(params)
    local view = CommonSetTipView.new(params)
    Drequire("game.CommonPopup.CommonSetTipView_ui"):create(view, 1)
    if view:initView() then return view end
end

function CommonSetTipView:ctor(params)
    self.params = params
end

function CommonSetTipView:initView()
    self:setHDPanelFlag(true)
    if CCCommonUtilsForLua:call("isIosAndroidPad") then
        self.ui.nodeccb:setScale(2)
    end

    local title = self.params.title
    local btnTitle = self.params.btnTitle or getLang("confirm")
    local desc = self.params.desc
    local gold = self.params.gold

    if title then
        self.ui.m_mainTitle:setString(title)
    end

    if desc then
        self.ui.m_tipTitle:setString(desc)
    end

    if btnTitle then
        CCCommonUtilsForLua:setButtonTitle(self.ui.m_confirmBtn, btnTitle)
    end

    if gold then
        self.ui.m_confirmBtn:setLabelAnchorPoint(ccp(0.5, 0.2))
        self.ui.m_costNode:setVisible(true)
        self.ui.m_costText:setString(CC_CMDITOA(atoi(gold)))

        local size = self.ui.m_costText:getContentSize()
        self.ui.m_costCoinSp:setPositionX(- size.width / 2 - 18)
    end

    registerTouchHandler(self)

    return true
end

function CommonSetTipView:onTouchBegan(x, y)
    if not isTouchInside(self.ui.m_bg, x, y) then
        self.touchPoint = ccp(x, y)
        return true
    end
end

function CommonSetTipView:onTouchEnded(x, y)
    if ccpDistance(self.touchPoint, ccp(x, y)) > 10 then return end
    self:call("closeSelf")
end

function CommonSetTipView:onClickSet()
    local setKey = self.params.setKey
    if not setKey then return end
    
    local showTip = cc.UserDefault:getInstance():getBoolForKey(setKey, true)
    showTip = not showTip
    if showTip then
        self.ui.m_selectSp:setVisible(false)
    else
        self.ui.m_selectSp:setVisible(true)
    end
    cc.UserDefault:getInstance():setBoolForKey(setKey, showTip)
    cc.UserDefault:getInstance():flush()
end

function CommonSetTipView:onClickConfirm()
    local callback = self.params.callback
    if callback then callback() end
    self:call("closeSelf")
end

return CommonSetTipView