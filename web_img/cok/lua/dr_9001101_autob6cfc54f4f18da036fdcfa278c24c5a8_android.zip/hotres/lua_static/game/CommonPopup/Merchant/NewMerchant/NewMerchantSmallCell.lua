local Music_Sfx_click_button = "ui_confirm"
local LibaoCommonFunc = Drequire("game.LiBao.LibaoCommonFunc")
-------------------------------------------- NewMerchantSmallCell Start --------------------------------------------
ccb["NewMerchantSmallCell"] = ccb["NewMerchantSmallCell"] or {}
local NewMerchantSmallCell = class("NewMerchantSmallCell", function()
    return cc.Layer:create()
end)

function NewMerchantSmallCell:create(idx)
    local ret = NewMerchantSmallCell.new()
    Drequire("game.CommonPopup.Merchant.NewMerchant.NewMerchantSmallCell_ui"):create(ret)
    local function onTouch(eventType, x, y)  
        if eventType == "began" then  
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)  
        else  
            return self:onTouchEnded(x, y)  
        end
    end
    ret:registerScriptTouchHandler(onTouch)
    ret:setTouchEnabled(true)
    ret:setSwallowsTouches(true)

    ret.am = ccb["NewMerchantSmallCell"]["mAnimationManager"]
    ret.m_hotPrice = 0
    ret.m_price = 0
    return ret
end

function NewMerchantSmallCell:addBlingParticle(parentNode)
    if not CCCommonUtilsForLua:isFunOpenByKey("merchant_bling_items") then 
        return 
    end
    -- dump(self.m_info,"addBlingParticle+++")
    for j=0,2 do
        local particle = ParticleController:call("createParticle", "LordSuitY_"..tostring(j))
        particle:setScale(1.2)
        particle:setContentSize(cc.size(99999,99999))
        parentNode:addChild(particle, -1)
    end
end

function NewMerchantSmallCell:isEquipment( itemId )
   local name = CCCommonUtilsForLua:call("getPropByIdGroup", "equipment", itemId, "name")
   if name and name ~= "" then 
        return true
   end
   return false
end

function NewMerchantSmallCell:refreshCell(info , idx)
    self.m_hotPrice = 0
    self.m_price = 0
    self.m_info = info
    if not self.m_info then
        return
    end
    self.ui.m_nodeParticle:removeAllChildren()
	self.m_index = tonumber(self.m_info.index)
    if self.m_info and self.m_info.itemId and self.m_info.itemNum then 
        local bestItemId = self.m_info.itemId
        self.m_nowItemId = bestItemId
        self.m_nowItemNum = tonumber(self.m_info.itemNum)
        self.ui.m_picNode1:removeAllChildren()
        self.ui.m_bestItemIconNode:removeAllChildren()
        if self.m_info.goods_flash and self.m_info.goods_flash == "1" and self.ui.m_nodeParticle then
            self:addBlingParticle(self.ui.m_nodeParticle)
        end

        if tonumber(bestItemId) <= WorldResourceType.WorldResource_Max and tonumber(bestItemId) >= WorldResourceType.Wood then
            local iconName = CCCommonUtilsForLua:call("getResourceIconByType", tonumber(bestItemId))
            local pic = CCLoadSprite:call("createSprite", iconName)
            if (pic ~= nil) then
                local sptName = CCCommonUtilsForLua:call("getToolBgByColor", 0) -- 0 == WHITE
                local iconBg = CCLoadSprite:call("createSprite", sptName)
                CCCommonUtilsForLua:call("setSpriteMaxSize", iconBg, 90, true)
                self.ui.m_picNode1:addChild(iconBg)
                CCCommonUtilsForLua:call("setSpriteMaxSize", pic, 80, true)
                self.ui.m_picNode1:addChild(pic)
            end
            self.ui.m_bestName:setString(CC_ITOA_K(tonumber(self.m_info.itemNum)))
        else
            -- local spr = CCCommonUtilsForLua:call("createGoodsIcon", tonumber(bestItemId), self.ui.m_picNode1, CCSize(90, 90))
            -- local name = CCCommonUtilsForLua:getPropById(bestItemId, "name")
            -- self.ui.m_bestName:setString(CC_CMDITOA(self.m_info.itemNum))
            local iconType = 0
            if self:isEquipment(bestItemId) then  
                iconType = 1
            end
            -- 显示图标（带tip）
            local itemData = {
                type = iconType,
                itemId = self.m_info.itemId,
                num = self.m_info.itemNum
            }
            local canTipsTouch = true
            if tonumber(self.m_info.itemId) <= WorldResourceType.WorldResource_Max and tonumber(self.m_info.itemId) >= WorldResourceType.Wood then
                canTipsTouch = false
            end
            LibaoCommonFunc.createDataItemTouchNode({
                itemData = itemData,
                iconNode = self.ui.m_picNode1,
                iconSize = 90,
                numLabel = self.ui.m_bestName,
                beTouch = canTipsTouch,  -- 默认可以触摸
                touchParentNode = self.m_info.touchRect,
            })
        end
    end
    if self.m_info.priceType then
        if tonumber(self.m_info.priceType) <= WorldResourceType.WorldResource_Max and tonumber(self.m_info.priceType) >= WorldResourceType.Wood then
            self.m_priceType = tonumber(self.m_info.priceType)
            local priceTypeIcon = CCCommonUtilsForLua:call("getResourceIconByType", tonumber(self.m_info.priceType))
            self.m_goldIcon = priceTypeIcon
            local priceTypeSpr = CCLoadSprite:createSprite(priceTypeIcon)
            self.ui.m_bestItemIconNode:addChild(priceTypeSpr)
            CCCommonUtilsForLua:call("setSpriteMaxSize", priceTypeSpr, 40, true)
        else
            self.m_priceType = tonumber(self.m_info.priceType)
            local iconStr = CCCommonUtilsForLua:call("getIcon", tostring(self.m_info.priceType))
            self.m_goldIcon = iconStr
            local pic = CCLoadSprite:call("createSprite", iconStr)
            if (pic ~= nil) then
                CCCommonUtilsForLua:call("setSpriteMaxSize", pic, 40, true)
                self.ui.m_bestItemIconNode:addChild(pic)
            end
        end
    end
    if self.m_info.price then
        self.ui.m_bestNowPrice:setString(CC_ITOA_K(tonumber(self.m_info.price)))
        self.m_singlePrice = tonumber(self.m_info.price)
        self.m_price = tonumber(self.m_info.price)
    end
    if self.m_info.price_hot and tonumber(self.m_info.price_hot) > 0 then
        self.ui.m_NodeBestOriginPrice:setVisible(true)
        self.ui.m_bestNowPrice:setPositionY(51)
        self.ui.m_bestOriginPrice:setString(CC_ITOA_K(tonumber(self.m_info.price_hot)))
        self.m_hotPrice = tonumber(self.m_info.price_hot)
    else
        self.ui.m_bestNowPrice:setPositionY(44)
        self.ui.m_NodeBestOriginPrice:setVisible(false)
    end
    if self.m_info.bestItem then
        local goldItemTbl = string.split(self.m_info.bestItem , ";")
        if goldItemTbl and #goldItemTbl == 2 then
            self.m_goldItemTbl = goldItemTbl
        end
    end
    self.ui.node_salePar:removeAllChildren()
    self.ui.m_newNode1:setVisible(false)
    if self.m_hotPrice > 0 and self.m_price > 0 then
        local deltaPrice = math.floor(math.min(100, math.max(0, (self.m_hotPrice - self.m_price) / self.m_hotPrice * 100)))
        if deltaPrice >= 50 then
            self.ui.m_salePercent:setString("-".. deltaPrice .. "%")
            self.ui.m_salePercent:setColor(cc.c3b(255, 234, 94))
            local par1 = ParticleController:call("createParticle", "QueueGlow_1")
            self.ui.node_salePar:addChild(par1)
            par1:setPosition(cc.p(0, 0))
            self.ui.m_newNode1:setVisible(true)
            par1:setContentSize(cc.size(1000, 1000))
        elseif deltaPrice >= 10 then 
            self.ui.m_salePercent:setString("-" .. deltaPrice .. "%")
            self.ui.m_salePercent:setColor(cc.c3b(233, 219, 254))
            local par1 = ParticleController:call("createParticle", "QueueGlow_1")
            self.ui.node_salePar:addChild(par1)
            par1:setPosition(cc.p(0, 0))
            self.ui.m_newNode1:setVisible(true)
            par1:setContentSize(cc.size(1000, 1000))
        end
    end
    if self.m_info.canPlay and tonumber(self.m_info.canPlay) == 1 then
        self.m_info.canPlay = 0
        self:playAnimation()
    else
        self:animationCallback()
    end
end

function NewMerchantSmallCell:playAnimation()
    local onPlayEnd = function ()
        self:animationCallback()
    end
    -- local callfunc = cc.CallFunc:create(onPlayEnd) --这里为何不使用callfunc呢。
    self.am:setAnimationCompletedCallback(onPlayEnd)
    self.am:runAnimationsForSequenceNamed("1")
end

function NewMerchantSmallCell:animationCallback()
    self.am:runAnimationsForSequenceNamed("0")
end

function NewMerchantSmallCell:onEnter()
end

function NewMerchantSmallCell:onExit()
end

function NewMerchantSmallCell:onTouchBegan(x, y)
    -- return true
end

function NewMerchantSmallCell:onTouchMoved(x, y)
end
function NewMerchantSmallCell:onTouchEnded(x, y)
end

function NewMerchantSmallCell:onRefreshClick(  )

    local wp = self.ui.m_bestItemIconNode:convertToWorldSpace(cc.p(0, 0))
    local rect = self.m_info.touchRect:getBoundingBox()
    if CCCommonUtilsForLua:call("isIosAndroidPad") then
        rect.width = rect.width * 2.4
        rect.height = rect.height * 2.4
    end
    if rect and cc.rectContainsPoint(rect, wp) then 
        SoundController:call("sharedSound"):call("playEffects", Music_Sfx_click_button)
        local StoreBuyConfirmDialogForLua = Drequire("game.CommonPopup.StoreBuyConfirmDialogForLua")
        local params = {}
        params.itemId = self.m_nowItemId
        params.maxNum = tonumber(self.m_nowItemNum)
        params.messagePosted = "NewMerchantSmallCell_Buy_CB"
        params.singlePoint = self.m_singlePrice
        params.moneyIcon = self.m_goldIcon
        params.id = ""
        params.isShowSelect = 0
        params.isNeedStore = 0
        params.index = self.m_index
        params.priceType = self.m_priceType
        local view = StoreBuyConfirmDialogForLua:create(params)
        PopupViewController:addPopupView(view)
    end
end
-------------------------------------------- NewMerchantSmallCell End --------------------------------------------

return NewMerchantSmallCell