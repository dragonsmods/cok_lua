local RecruitDetailView = class("RecruitDetailView", PopupBaseView)

--偏向
local prefer = {
    ["173200"] = 1,
    ["173201"] = 2,
}
--活跃度
local active = {
    ["173228"] = 1,
    ["173229"] = 2,
    ["173230"] = 3,
}
--口号
local announce = {
    ["173211"] = 1,
    ["173212"] = 2,
    ["173213"] = 3,
}
--特征
local feature = {
    ["173216"] = 1,
    ["173217"] = 2,
    ["173218"] = 3,
    ["173219"] = 4,
}

local defaultCityLevel = 16
local defaultPower = 1000000
local cityLimit = 36

function RecruitDetailView:create(preview)
    local view = RecruitDetailView.new(preview)
    Drequire("game.CommonPopup.ChangeServer.RecruitDetailView_ui"):create(view, 1)
    view:initView()
    return view
end

function RecruitDetailView:ctor(preview)
    self.preview = preview
    self.ctrl = require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance()

    self.prefer = "173201"
    local recruitMax = self.ctrl:getRecruitLimit()
    self.recruitMax = recruitMax < 5 and recruitMax or 5
    self.recruit = self.recruitMax
    self.announce = "173213"
    self.feature = "173216;173217"
    self.requireIndex = 1
    self.kill = 0
    self.description = ""

    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	local allianceInfo = playerInfo:getProperty("allianceInfo")
    self.lan = allianceInfo:getProperty("language")
    self.city = allianceInfo:getProperty("castleRestriction")
    self.city = self.city > 0 and self.city or defaultCityLevel
    self.power = allianceInfo:getProperty("powerRestriction")
    self.power = self.power > 0 and self.power or defaultPower
    self.active = "173228"
end

function RecruitDetailView:initView()
    local viewSize = self.ui.m_listNode:getContentSize()
    if self.preview then 
        self.ui.m_listNode:setPositionY(160)
        self.ui.m_pdNode:setPositionY(0)
        viewSize.height = viewSize.height + 100 
    end
    self.scrollView = CCScrollView:create(viewSize)
    self.scrollView:setDirection(kCCScrollViewDirectionVertical)
    self.ui.m_listNode:addChild(self.scrollView)

    local contentSize = self.ui.m_detailNode:getContentSize()
    self.ui.m_detailNode:removeFromParent()
    self.ui.m_detailNode:setVisible(true)
    self.scrollView:addChild(self.ui.m_detailNode)
    self.scrollView:setContentOffset(ccp(0, viewSize.height - contentSize.height))
    self.scrollView:setContentSize(contentSize)

    self.descEdit = self:createMultiLineEditBox(self.ui.m_descNode, getLang("173268"))

    local function editCB (strEventName, pSender)
        if tostring(pSender) == "began" then
            --光标进入，选中全部内容
            -- print("self.m_editOpen = true")
            self.m_editOpen = true
        elseif tostring(pSender) == "ended" then
            -- 当编辑框失去焦点并且键盘消失的时候被调用
        elseif tostring(pSender) == "return" then
            -- 当用户点击编辑框的键盘以外的区域，或者键盘的Return按钮被点击时所调用
            self.recruit = atoi(self.recruitEdit:getText())
            if self.recruit > self.recruitMax then self.recruit = self.recruitMax end
            if self.recruit <= 0 then self.recruit = 1 end --至少招募一个
            self.recruitEdit:setText(tostring(self.recruit))
        elseif tostring(pSender) == "changed" then
            -- 输入内容改变时调用
            -- self.recruitNum = atoi(self.recruitEdit:getText())     
        end
    end
    self.recruitEdit = self:createEditBox(self.ui.m_numNode, getLang("173264"), editCB)
    self.recruitEdit:setText(tostring(self.recruit))
    
    local function editCB (strEventName, pSender)
        if tostring(pSender) == "began" then
            --光标进入，选中全部内容
            -- print("self.m_editOpen = true")
            self.m_editOpen = true
        elseif tostring(pSender) == "ended" then
            -- 当编辑框失去焦点并且键盘消失的时候被调用
        elseif tostring(pSender) == "return" then
            -- 当用户点击编辑框的键盘以外的区域，或者键盘的Return按钮被点击时所调用
            self.city = atoi(self.cityEdit:getText())  
            if self.city > cityLimit then self.city = cityLimit end
            self.cityEdit:setText(tostring(self.city))
        elseif tostring(pSender) == "changed" then
            -- 输入内容改变时调用
            -- self.city = atoi(self.cityEdit:getText())     
        end
    end

    self.cityEdit = self:createEditBox(self.ui.m_cityNode, getLang("173264"), editCB)
    if self.city > 0 then self.cityEdit:setText(tostring(self.city)) end

    local function editCB (strEventName, pSender)
        if tostring(pSender) == "began" then
            --光标进入，选中全部内容
            -- print("self.m_editOpen = true")
            self.m_editOpen = true
        elseif tostring(pSender) == "ended" then
            -- 当编辑框失去焦点并且键盘消失的时候被调用
        elseif tostring(pSender) == "return" then
            -- 当用户点击编辑框的键盘以外的区域，或者键盘的Return按钮被点击时所调用
            self.power = atoi(self.powerEdit:getText())
            self.powerEdit:setText(self.powerEdit:getText())
        elseif tostring(pSender) == "changed" then
            -- 输入内容改变时调用
            -- self.power = atoi(self.powerEdit:getText())   
        end
    end

    self.powerEdit = self:createEditBox(self.ui.m_powerNode, getLang("173265"), editCB)
    if self.power > 0 then self.powerEdit:setText(tostring(self.power)) end
    
    local function editCB (strEventName, pSender)
        if tostring(pSender) == "began" then
            --光标进入，选中全部内容
            -- print("self.m_editOpen = true")
            self.m_editOpen = true
        elseif tostring(pSender) == "ended" then
            -- 当编辑框失去焦点并且键盘消失的时候被调用
        elseif tostring(pSender) == "return" then
            -- 当用户点击编辑框的键盘以外的区域，或者键盘的Return按钮被点击时所调用
            self.kill = atoi(self.killEdit:getText())
            self.killEdit:setText(self.killEdit:getText())
        elseif tostring(pSender) == "changed" then
            -- 输入内容改变时调用
            -- self.kill = atoi(self.killEdit:getText())    
        end
    end
    self.killEdit = self:createEditBox(self.ui.m_killNode, getLang("173266"), editCB)

    CCCommonUtilsForLua:setButtonTitle(self.ui.m_recruitBtn, getLang("173236"))

    self.ui.m_titleTxt:setString(getLang("173222"))
    self.ui.m_prefreTxt:setString(getLang("173202"))
    self.ui.m_prefre1Txt:setString(getLang("173200"))
    self.ui.m_prefre2Txt:setString(getLang("173201"))
    self.ui.m_recruitTxt:setString(getLang("173203"))
    self.ui.m_recruitMaxTxt:setString("max:" .. self.recruitMax)
    self.ui.m_cityTxt:setString(getLang("173204"))
    self.ui.m_requireTxt:setString(getLang("173205"))
    self.ui.m_lanTxt:setString(getLang("173209"))
    self.ui.m_directionTxt:setString(getLang("173210"))
    self.ui.m_featureTxt:setString(getLang("173214"))
    self.ui.m_descriptionTxt:setString(getLang("173220"))
    self.ui.m_dir1Txt:setString(getLang("173211"))
    self.ui.m_dir2Txt:setString(getLang("173212"))
    self.ui.m_dir3Txt:setString(getLang("173213"))
    self.ui.m_feature1Txt:setString(getLang("173216"))
    self.ui.m_feature2Txt:setString(getLang("173217"))
    self.ui.m_feature3Txt:setString(getLang("173218"))
    self.ui.m_feature4Txt:setString(getLang("173219"))
    self.ui.m_currentLanTxt:setString(getLang(self.lan))
    self.ui.m_powerTxt:setString(getLang("173206"))
    self.ui.m_activeTxt:setString(getLang("173207"))
    self.ui.m_finalActiveTxt:setString(getLang("173228"))
    self.ui.m_killTxt:setString(getLang("173208"))

    for k, v in pairs(active) do
        if self.ui["m_active" .. v .. "Txt"] then
            self.ui["m_active" .. v .. "Txt"]:setString(getLang(k))
        end
    end
    self.ui.m_activeSelectNode:setVisible(false)

    self:updateAnnounce()
    self:updateFeature()
    self:updatePrefer()

    if self.preview then
        self.ui.m_btnNode:setVisible(false)
        self.ui.m_recruitMaxTxt:setVisible(false)
        self.ui.m_titleTxt:setString(getLang("173318"))
        self.killEdit:setTouchEnabled(false)
        self.powerEdit:setTouchEnabled(false)
        self.cityEdit:setTouchEnabled(false)
        self.recruitEdit:setTouchEnabled(false)
        self.descEdit:setTouchEnabled(false)
        self:setTouchEnabled(false)
        self.ctrl:getPreview()
    else
        registerTouchHandler(self)
        self:setTouchEnabled(true)
    end
end

function RecruitDetailView:updateLan(param)
    if param then
        self.lan = param:valueForKey("lan"):getCString()
        self.ui.m_currentLanTxt:setString(getLang(self.lan))
    end
end

function RecruitDetailView:updateAnnounce()
    local first = announce[self.announce]
    for index = 1, 3 do
        if index == first then
            self.ui["m_dir" .. index .. "Txt"]:setColor(cc.c3b(236, 220, 170))
            self.ui["m_dirSp" .. index]:setVisible(true)
        else
            self.ui["m_dir" .. index .. "Txt"]:setColor(cc.c3b(147, 147, 147))
            self.ui["m_dirSp" .. index]:setVisible(false)
        end
    end
end

function RecruitDetailView:updateFeature()
    local tbl = splitString(self.feature, ";")
    if #tbl > 2 then 
        table.remove(tbl, 1)
        self.feature = table.concat(tbl, ";")
    end

    local first = feature[tbl[1]]
    local second = feature[tbl[2]]
    for index = 1, 4 do
        if index == first or index == second then
            self.ui["m_feature" .. index .. "Txt"]:setColor(cc.c3b(236, 220, 170))
            self.ui["m_feature" .. index .. "Sp"]:setVisible(true)
        else
            self.ui["m_feature" .. index .. "Txt"]:setColor(cc.c3b(147, 147, 147))
            self.ui["m_feature" .. index .. "Sp"]:setVisible(false)
        end
    end
end

function RecruitDetailView:updatePrefer()
    local first = prefer[self.prefer]
    for index = 1, 2 do
        if index == first then
            self.ui["m_prefre" .. index .. "Txt"]:setColor(cc.c3b(236, 220, 170))
            self.ui["m_pSelect" .. index .. "Sp"]:setVisible(true)
        else
            self.ui["m_prefre" .. index .. "Txt"]:setColor(cc.c3b(147, 147, 147))
            self.ui["m_pSelect" .. index .. "Sp"]:setVisible(false)
        end
    end
end

-- function RecruitDetailView:editBoxReturn()
--     self.description = self.descEdit:call("getText")
--     self.descEdit:call("closeIME")
-- end

function RecruitDetailView:updateView(ref)
    local data = dictToLuaTable(ref)
    if data then
        self.prefer = data.prefer
        self.recruit = data.rMax
        self.city = data.city
        self.power = data.power
        self.active = data.active
        self.kill = data.kill
        self.lan = data.lan
        self.announce = data.announce
        self.feature = data.feature
        self.description = data.description

        self.ui.m_currentLanTxt:setString(getLang(self.lan))
        
        self:updateAnnounce()
        self:updateFeature()
        self:updatePrefer()

        self.cityEdit:setText(self.city)
        self.recruitEdit:setText(self.recruit)
        self.descEdit:call("setText", self.description or "")
        
        for index = 1, 3 do self.ui["m_requireSp" .. index]:setVisible(false) end

        if self.power then
            self.ui.m_requireSp1:setVisible(true)
            self.powerEdit:setText(tostring(self.power))
        elseif self.active then
            self.ui.m_requireSp2:setVisible(true)
            self.ui.m_finalActiveTxt:setString(getLang(self.active))
        elseif self.kill then
            self.ui.m_requireSp3:setVisible(true)
            self.killEdit:setText(tostring(self.kill))
        end
    end
end

function RecruitDetailView:onEnter()
    UIComponent:call("showPopupView", 1)

    local function callback1(param) self:updateLan(param) end
	local handler1 = self:registerHandler(callback1)
    CCSafeNotificationCenter:registerScriptObserver(self, handler1, "changerServer.filter")

    local function callback2(param) self:call("closeSelf") end
	local handler2 = self:registerHandler(callback2)
    CCSafeNotificationCenter:registerScriptObserver(self, handler2, "RecruitDetailView:close")

    local function callback3(pObj) self:updateView(pObj) end
	local handler3 = self:registerHandler(callback3)
	CCSafeNotificationCenter:registerScriptObserver(self, handler3, "RecruitDetailView:updateView")
end

function RecruitDetailView:onExit()
    CCSafeNotificationCenter:unregisterScriptObserver(self, "changerServer.filter") 
    CCSafeNotificationCenter:unregisterScriptObserver(self, "RecruitDetailView:close") 
    CCSafeNotificationCenter:unregisterScriptObserver(self, "RecruitDetailView:updateView") 
end

function RecruitDetailView:createEditBox(node, placeHolder, editCB)
    local size = node:getContentSize()
    local sprite9 = CCLoadSprite:call("createScale9Sprite", "blankFrame.png")
    local editBox = CCEditBox:create(size, sprite9)
    editBox:setAnchorPoint(ccp(0, 0))
    editBox:setFontSize(14)
    editBox:setPlaceHolder(placeHolder)
    editBox:setMaxLength(18)
    editBox:setFontColor(cc.c3b(255, 255, 255))
    editBox:setInputMode(cc.EDITBOX_INPUT_MODE_NUMERIC)
    editBox:setPosition(ccp(0, 0))
    node:addChild(editBox)
    editBox:registerScriptEditBoxHandler(editCB) --输入框的事件，主要有光标移进去，光标移出来，以及输入内容改变等
    return editBox
end

function RecruitDetailView:createMultiLineEditBox(node, placeHolder)
    local size = node:getContentSize()
    local editBox = InputFieldMultiLine:call("create", size, "blankFrame.png", 18)
    editBox:call("setAddH", 0)
    editBox:call("setMaxChars", 80)
    editBox:call("setLineNumber", 3)
    editBox:call("setFontColor", cc.c3b(147, 147, 147))	
    editBox:call("setSwallowsTouches", true)
    editBox:call("setMoveFlag", true)
    editBox:call("setcalCharLen", true)
    --editBox:call("setOnlySingleLine", true)
    editBox:call("setPlaceHolder", placeHolder)
    editBox:setPosition(ccp(0, 0))
    editBox:setAnchorPoint(ccp(0, 0))
    node:addChild(editBox)

    return editBox
end

function RecruitDetailView:onClickRecruit()
    if self.ctrl:canPublishRecruit() == false then
        --173295=功能冷却中，请冷却完毕后再来
        -- CCCommonUtilsForLua:call("flyHint", "", "", getLang("173295"))
        local now = GlobalData:call("getTimeStamp")
        local remain = self.ctrl.publishTime - now
        YesNoDialog:call("showTimeWithDes", getLang("173295"), getLang("108659"), remain)
        return
    end

    self.m_waitInterface = GameController:call("showWaitInterface1", self.m_recruitBtn)
    self.description = self.descEdit:call("getText")

    local paras = {
        ["prefer"] = self.prefer,
        ["recruit"] = self.recruit,
        ["city"] = self.city,
        ["lan"] = self.lan,
        ["announce"] = self.announce,
        ["feature"] = self.feature,
        ["description"] = self.description,
    }

    if self.requireIndex == 1 then
        paras.power = self.power
    elseif self.requireIndex == 2 then
        paras.active = self.active
    else
        paras.kill = self.kill
    end
    dump(paras, "onClickRecruit")
    self.ctrl:recruit(paras)
end

function RecruitDetailView:onTouchBegan(x, y)
    self.touchPoint = ccp(x, y)

    if isTouchInside(self.ui.m_pSelect1Bg, x, y) then
        return true
    elseif isTouchInside(self.ui.m_pSelect2Bg, x, y) then
        return true
    elseif isTouchInside(self.ui.m_dirBg1, x, y) then
        return true
    elseif isTouchInside(self.ui.m_dirBg2, x, y) then
        return true
    elseif isTouchInside(self.ui.m_dirBg3, x, y) then
        return true
    elseif isTouchInside(self.ui.m_feature1Bg, x, y) then
        return true
    elseif isTouchInside(self.ui.m_feature2Bg, x, y) then
        return true
    elseif isTouchInside(self.ui.m_feature3Bg, x, y) then
        return true
    elseif isTouchInside(self.ui.m_feature4Bg, x, y) then
        return true
    elseif isTouchInside(self.ui.m_activeBg, x, y) then
        return true
    elseif isTouchInside(self.ui.m_lanBg, x, y) then
        return true
    elseif isTouchInside(self.ui.m_requireBg1, x, y) then
        return true
    elseif isTouchInside(self.ui.m_requireBg2, x, y) then
        return true
    elseif isTouchInside(self.ui.m_requireBg3, x, y) then
        return true
    end
end

function RecruitDetailView:onTouchEnded(x, y)
    local distance = ccpDistance(self.touchPoint, ccp(x, y))
    if distance > 10 then return end

    if isTouchInside(self.ui.m_pSelect1Bg, x, y) then
        self.prefer = "173200"
        self:updatePrefer()
    elseif isTouchInside(self.ui.m_pSelect2Bg, x, y) then
        self.prefer = "173201"
        self:updatePrefer()
    elseif isTouchInside(self.ui.m_dirBg1, x, y) then
        self.announce = "173211"
        self:updateAnnounce()
    elseif isTouchInside(self.ui.m_dirBg2, x, y) then
        self.announce = "173212"
        self:updateAnnounce()
    elseif isTouchInside(self.ui.m_dirBg3, x, y) then
        self.announce = "173213"
        self:updateAnnounce()
    elseif isTouchInside(self.ui.m_feature1Bg, x, y) then
        if self.ui.m_feature1Sp:isVisible() == false then
            self.feature = self.feature .. ";173216"
            self:updateFeature()
        end
    elseif isTouchInside(self.ui.m_feature2Bg, x, y) then
        if self.ui.m_feature2Sp:isVisible() == false then
            self.feature = self.feature .. ";173217"
            self:updateFeature()
        end
    elseif isTouchInside(self.ui.m_feature3Bg, x, y) then
        if self.ui.m_feature3Sp:isVisible() == false then
            self.feature = self.feature .. ";173218"
            self:updateFeature()
        end
    elseif isTouchInside(self.ui.m_feature4Bg, x, y) then
        if self.ui.m_feature4Sp:isVisible() == false then
            self.feature = self.feature .. ";173219"
            self:updateFeature()
        end
    elseif isTouchInside(self.ui.m_activeBg, x, y) and self.requireIndex == 2 then
        self.ui.m_activeSelectNode:setVisible(true)
    elseif isTouchInside(self.ui.m_lanBg, x, y) then
        local sourceData = {}
        local xmlData = CCCommonUtilsForLua:getGroupByKey("language")
        for k, v in ipairs4ScatteredT(xmlData) do
            if v.mark then
                table.insert(sourceData, {text = getLang(v.lang_id), id = v.lang_id})
            end
        end
        local view = Drequire("game.CommonPopup.ChangeServer.ApplySelectView"):create(sourceData, nil, self.lan)
        PopupViewController:addPopupView(view)
    elseif isTouchInside(self.ui.m_requireBg1, x, y) then
        self.ui.m_requireSp1:setVisible(true)
        self.ui.m_requireSp2:setVisible(false)
        self.ui.m_requireSp3:setVisible(false)
        self.powerEdit:setEnabled(true)
        self.killEdit:setEnabled(false)
        self.requireIndex = 1
    elseif isTouchInside(self.ui.m_requireBg2, x, y) then
        self.ui.m_requireSp1:setVisible(false)
        self.ui.m_requireSp2:setVisible(true)
        self.ui.m_requireSp3:setVisible(false)
        self.powerEdit:setEnabled(false)
        self.killEdit:setEnabled(false)
        self.requireIndex = 2
    elseif isTouchInside(self.ui.m_requireBg3, x, y) then
        self.ui.m_requireSp1:setVisible(false)
        self.ui.m_requireSp2:setVisible(false)
        self.ui.m_requireSp3:setVisible(true)
        self.powerEdit:setEnabled(false)
        self.killEdit:setEnabled(true)
        self.requireIndex = 3
    end
end

function RecruitDetailView:onClickBtnTip()
    FaqHelper:call("showSingleFAQ", "45281")
end

function RecruitDetailView:onBtnActive1Click()
    self.active = "173228"
    self.ui.m_finalActiveTxt:setString(getLang(self.active))
    self.ui.m_activeSelectNode:setVisible(false)
end

function RecruitDetailView:onBtnActive2Click()
    self.active = "173229"
    self.ui.m_finalActiveTxt:setString(getLang(self.active))
    self.ui.m_activeSelectNode:setVisible(false)
end

function RecruitDetailView:onBtnActive3Click()
    self.active = "173230"
    self.ui.m_finalActiveTxt:setString(getLang(self.active))
    self.ui.m_activeSelectNode:setVisible(false)
end

return RecruitDetailView