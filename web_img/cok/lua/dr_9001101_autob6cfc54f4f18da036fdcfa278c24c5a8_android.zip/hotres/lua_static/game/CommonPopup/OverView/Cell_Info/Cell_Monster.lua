--年兽
local Cell_Monster = class("Cell_Monster",Drequire("game.CommonPopup.OverView.Cell_Info.Cell_MainFile"))
local FUN_BUILD_SMITHY = 407000 --战争大厅
function Cell_Monster:create(Id)
    local ret = Cell_Monster.new(Id)
    if ret:initBaseById(Id) then
        return ret
    end
end
function Cell_Monster:getCellDataTbl()
    if not self:checkIsVisible() then
        return
    end
    local _id = '30711020'
    local _finishTime = PortActController:call("getInstance"):getProperty("m_nextRewardTime")
    local _state = -1
    local _label = ""
    local _name = ""
    local _icon = ""
    local _visible = ""
    local _cancelJump = false
    local buildId = FunBuildController:call("getMaxLvBuildByType", FUN_BUILD_SMITHY)
    
    --每日攻击首领怪次数
    local remainAttackTime = CCCommonUtilsForLua:call("getBossMonsterAttackTimes")
    if buildId > 0 then
        if remainAttackTime > 0 then
            _state = self.Queue_ST_WORK
            _finishTime = remainAttackTime
            _label = self:getDialogByIdIndex(_id,1)
        else
            _cancelJump = true
            _state = self.Queue_ST_IDLE
            _finishTime = remainAttackTime
            _label = self:getDialogByIdIndex(_id,3)
        end
    else
        _state = self.Queue_ST_LOCK
        _finishTime = -1
		_label = "2000442"
    end
    _name,_icon,_visible = self:getNameIconVisibleBySubId(_id)
    local cellOne = {id = _id, name = _name,icon = _icon, state = _state,param1 = _finishTime, label = _label, cancelJump = _cancelJump, cell = self}
    if _visible == "1" then
        self.CellTbl.cellMeta={cellOne}
    end

    return self.CellTbl
end

function Cell_Monster:OnClickJump(_id,_state)
    if _id == "30711020" then
        if _state ~= self.Queue_ST_LOCK then
            self:jumpByTypeAndTarget(2)
        else
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("115127"))
        end
    end
end

return Cell_Monster