--造兵
local Cell_Soldier = class("Cell_Soldier",Drequire("game.CommonPopup.OverView.Cell_Info.Cell_QueueFile"))

local TYPE_FORCE = 1 --步兵
local TYPE_RIDE_SOLDIER = 8 --骑兵
local TYPE_BOW_SOLDIER = 9 --弓兵
local TYPE_CAR_SOLDIER = 10 --车兵
local FUN_BUILD_BARRACK1 = 423000	--兵营
local FUN_BUILD_BARRACK2 = 424000	--马厩
local FUN_BUILD_BARRACK3 = 425000	--靶场
local FUN_BUILD_BARRACK4 = 426000	--战车
function Cell_Soldier:create(Id)
    local ret = Cell_Soldier.new(Id)
    if ret:initBaseById(Id) then
        return ret
    end
end

function Cell_Soldier:getCureQueueInfo()
    if not self:checkIsVisible() then
        return
    end
    local tempTbl = {}
    -- 士兵训练
	-- 步兵
	
    local qid = QueueController:call("getMinTimeQidByType", TYPE_FORCE)
    tempTbl[#tempTbl+1] = self:getSubTypeCellTbl(qid,TYPE_FORCE)

    -- 骑兵
    local qid = QueueController:call("getMinTimeQidByType", TYPE_RIDE_SOLDIER)
    tempTbl[#tempTbl+1] = self:getSubTypeCellTbl(qid,TYPE_RIDE_SOLDIER)

    -- 弓兵
    local qid = QueueController:call("getMinTimeQidByType", TYPE_BOW_SOLDIER)
    tempTbl[#tempTbl+1] = self:getSubTypeCellTbl(qid,TYPE_BOW_SOLDIER)

	-- 车兵
	local qid = QueueController:call("getMinTimeQidByType", TYPE_CAR_SOLDIER)
    tempTbl[#tempTbl+1] = self:getSubTypeCellTbl(qid,TYPE_CAR_SOLDIER)

    self.CellTbl.cellMeta=tempTbl
    return self.CellTbl
end

function Cell_Soldier:getSubTypeCellTbl(qid,type)
    local TYPE_BUILDING = 0 --建筑
    local res = {}
	local _state = self.Queue_ST_Init
	local _finishTime = -1
	local _totalTime = -1
	local _label = ""
	local _type = type
    local _id = ""
    local _name = ""
    local _icon = ""
    local _visible = ""

    local qInfo = self.allQueuesInfos[qid]

    if qid ~= QID_MAX then
        _state,_finishTime,_totalTime = self:getQueueState(qInfo)
	else
		_state = self.Queue_ST_IDLE
		_finishTime = 0
		
	end
      
    if _state == self.Queue_ST_IDLE then
        _label = "169606" --空闲中
    elseif _state == self.Queue_ST_WORK then
        _label = "2000430" --部队训练中
    elseif _state == self.Queue_ST_LOCK then
        _label = "2000442" --未解锁			
    end
    if _type == TYPE_FORCE then
        _id = "30711003"
    elseif _type == TYPE_RIDE_SOLDIER then
        _id = "30711004"
    elseif _type == TYPE_BOW_SOLDIER then
        _id = "30711005"
    elseif _type == TYPE_CAR_SOLDIER then
        _id = "30711006"
    end

    --未解锁
    if not self:checkIsUnLock(type) then
        _state = self.Queue_ST_LOCK
        _finishTime = -1
        _label = "2000442"
    end

    _name,_icon,_visible = self:getNameIconVisibleBySubId(_id)        
    res = {id = _id, state = _state, param1 = _finishTime, param2 = _totalTime,label = _label,name = _name,icon = _icon,order = _order,cell = self}
     
    if _visible == "1" then
        return res
    end
end

function Cell_Soldier:OnClickJump(_id,_state)
    if _id == "30711003" then
        self:jumpByTypeAndTarget(1,FUN_BUILD_BARRACK1)
    elseif _id == "30711004" then
        self:jumpByTypeAndTarget(1,FUN_BUILD_BARRACK2)
    elseif _id == "30711005" then
        self:jumpByTypeAndTarget(1,FUN_BUILD_BARRACK3)
    elseif _id == "30711006" then
        self:jumpByTypeAndTarget(1,FUN_BUILD_BARRACK4)
    end

end

return Cell_Soldier