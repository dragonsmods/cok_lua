----------------------------
-- Author: Elex
-- Date: 2019-03-05 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local RewardTblView_ui = class("RewardTblView_ui")

--#ui propertys


--#function
function RewardTblView_ui:create(owner, viewType, paramTable)
	local ret = RewardTblView_ui.new()
	CustomUtility:LoadUi("RewardTblView.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function RewardTblView_ui:initLang()
end

function RewardTblView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function RewardTblView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function RewardTblView_ui:initTableView()
	TableViewSmoker:createView(self, "m_listTableView", "game.CommonPopup.RewardTblCell", 0, 6, "RewardTblCell")
end

function RewardTblView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return RewardTblView_ui

