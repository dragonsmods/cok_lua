--@author: mm
--@date: 2016-11-14

--pre dec
-- local print = print
-- local math = math
local loprint = function(...)
    -- print(...)
end

local ToolMerchantRefreshCommand = class("ToolMerchantRefreshCommand", LuaCommandBase)

local TOOL_MERCHANT_REFRESH_COMMAND = "hot.item.refresh"
local MSG_CITY_RESOURCES_UPDATE = "city_resources_update"

function ToolMerchantRefreshCommand.create(callback)
    local ret = ToolMerchantRefreshCommand.new()
    ret:initWithName(TOOL_MERCHANT_REFRESH_COMMAND)
    ret.cmdCallback = callback
    loprint("ToolMerchantRefreshCommand | create")
    --ret.callback=func
    return ret
end

function ToolMerchantRefreshCommand:handleReceive( dict )
    loprint("ToolMerchantRefreshCommand: handleReceive")

    local cmdname = dict:valueForKey("cmd"):getCString()
    if cmdname ~= TOOL_MERCHANT_REFRESH_COMMAND then
        return false
    end
    
    local params = dict:objectForKey("params")
    if nil == params then
        return true
    end

    local exist = params:objectForKey("errorCode")
    loprint("ToolMerchantRefreshCommand: exist=", exist)
    if (exist) then
        return true
    end

    ToolController:call("retMerchantItems", params)
    loprint("ToolMerchantRefreshCommand: params=", params)

    if (params:objectForKey("remainGold")) then
        local gold = params:valueForKey("remainGold"):doubleValue()
        local gd = GlobalData:call("shared")
        local playerInfo = gd:call("getPlayerInfo") --it's a table?
        playerInfo:setProperty("gold", gold)
        CCSafeNotificationCenter:postNotification(MSG_CITY_RESOURCES_UPDATE)
    end

    loprint("ToolMerchantRefreshCommand: p3, cmdCb =", self.cmdCallback)
    self.cmdCallback(params)
    self.cmdCallBack = nil

    return true --mm: c里面这是false，不知有没有问题。

    -- if params:objectForKey("errorCode") ~= nil then
    --     local errorCode = params:valueForKey("errorCode"):getCString()
    --     print("ToolMerchantRefreshCommand:handleReceive ... errorCode .. " .. errorCode)
    --     return true
    -- end
    -- return true
end

return ToolMerchantRefreshCommand

