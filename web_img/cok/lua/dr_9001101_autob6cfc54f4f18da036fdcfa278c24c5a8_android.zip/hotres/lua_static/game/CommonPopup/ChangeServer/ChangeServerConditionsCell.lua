local ChangeServerConditionsCell = class("ChangeServerConditionsCell", 
    function ()
       return cc.TableViewCell:create()
    end)

ChangeServerConditionsCell.__index = ChangeServerConditionsCell
function ChangeServerConditionsCell:create()
    local node = ChangeServerConditionsCell.new()
    Drequire("game.CommonPopup.ChangeServer.ChangeServerConditionsCell_ui"):create(node, 0)
    return node
end

function ChangeServerConditionsCell:refreshCell(info, idx)
    -- dump(idx,"hxq idx is")
    -- dump(info,"hxq info is")
    if nil == info.name or nil == info.state then return end
    self.ui.m_conditionLabel:setString(getLang(info.name))
    if info.state then
        self.ui.m_conditionLabel:setColor(cc.c3b(184,172,132))
        self.ui.m_yesSpr:setVisible(true)
        self.ui.m_noSpr:setVisible(false)
        self.ui.m_CellBG:setVisible(false)
    else
        self.ui.m_conditionLabel:setColor(cc.c3b(147,147,147))
        self.ui.m_noSpr:setVisible(true)
        self.ui.m_yesSpr:setVisible(false)
        self.ui.m_CellBG:setVisible(true)
    end
end

return ChangeServerConditionsCell