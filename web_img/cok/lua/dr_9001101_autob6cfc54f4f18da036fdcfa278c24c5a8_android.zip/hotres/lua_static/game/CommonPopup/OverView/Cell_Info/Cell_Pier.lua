--码头
local Cell_Pier = class("Cell_Pier",Drequire("game.CommonPopup.OverView.Cell_Info.Cell_MainFile"))
local SPE_BUILD_CARGO  = 9990011
function Cell_Pier:create(Id)
    local ret = Cell_Pier.new(Id)
    if ret:initBaseById(Id) then
        return ret
    end
end
function Cell_Pier:getCellDataTbl()
    if not self:checkIsVisible() then
        return
    end
    local now = getTimeStamp()
    local _id = '30711015'
    local _finishTime = PortActController:call("getInstance"):getProperty("m_nextRewardTime")
    local _targetTime = 5*60
    local _state = -1
    local _label = ""
    local _name = ""
    local _icon = ""
    local _visible = ""
    local curWorldTime = getWorldTime()
	local disTime = curWorldTime - now
    if _finishTime <= now then
        --装卸货物完成
        _state = self.Queue_ST_WORK
        _label = self:getDialogByIdIndex(_id,1)--"2000420"
    elseif _finishTime > now then
        --装卸货物中
        _finishTime = _finishTime + disTime
        _label = self:getDialogByIdIndex(_id,2)--"2000432"
        _state = self.Queue_ST_WORK
    end
    _name,_icon,_visible = self:getNameIconVisibleBySubId(_id)
    local cellOne = { id = _id, name = _name,icon = _icon, state = _state,label = _label, param1 = _finishTime, param2 = _targetTime,cell = self}
    if _visible == "1" then
        self.CellTbl.cellMeta={cellOne}
    end
    return self.CellTbl

end

function Cell_Pier:OnClickJump(_id,_state)
    if _id == "30711015" then
        local dict = CCDictionary:create()
        dict:setObject(CCString:create("TimeRwdShowView"), "name")
        LuaController:call("openPopViewInLua", dict)
    end
end

return Cell_Pier