--玩家排行TableViewCell
local CommonRankPlayerTblCell = class("CommonRankPlayerTblCell", cc.Layer)

function CommonRankPlayerTblCell:create(idx)
    local view = CommonRankPlayerTblCell.new()
    Drequire("game.CommonPopup.commonRank.CommonRankPlayerTblCell_ui"):create(view, 0)
    return view
end

function CommonRankPlayerTblCell:refreshViewByType(info, type)
    if type == 1 then
        local rankStr = "0"
        if info.data.rank and info.data.rank ~= "" then
            rankStr = info.data.rank
        end
        local showSearch = info.showSearch
        if (tonumber(rankStr) or 0) <= 0 then
            rankStr = getLang("150290")
            if info.maxShowNum then
                rankStr = info.maxShowNum .. '+'
            end
            showSearch = false
        end
        if not showSearch then
            self.ui.m_rankLabel:setPositionY(0)
            self.ui.m_searchBtn:setVisible(false)
        else
            self.ui.m_rankLabel:setPositionY(20)
            self.ui.m_searchBtn:setVisible(true)
        end
        self.ui.m_rankLabel:setString(rankStr)
        self:refreshScore(info)

        -- 玩家是否隐藏名字
        -- if not info.isSelf and (info.hideKing == "1" or info.data.anonymous_state == 1 or not info.data.u_info) then
        if self:isHideKing() then
            self.ui.m_pNameLabel:setString(getLang("140473")) -- 140473=领主ID已隐藏
        else
            local str = info.data.u_info.name
            if info.data.u_info.abbr and info.data.u_info.abbr ~= "" then
                str = "(" .. info.data.u_info.abbr .. ") " .. str
            end
            self.ui.m_pNameLabel:setString(str)
        end

        local str = nil

        -- if info.hideKing == "1" or info.data.anonymous_state == 1 then
        if self:isHideKing() then
            str = ""
        else
            local sid = nil
            if info.data.sid and info.data.sid ~= "" then
                sid = info.data.sid
            elseif info.data.u_info.sid and info.data.u_info.sid ~= "" then
                sid = info.data.u_info.sid
            end

            if sid then
                local serverId = resetGreenServerId(sid)
                str = string.format("%s: %d", getLang("138027"), serverId)  -- 138027=王国
            else
                str = string.format("%s:", getLang("138027"))               -- 138027=王国
            end
        end
        if str then
            self.ui.m_sNumLabel:setString(str)
        end

        self.ui.m_headNode:removeAllChildren()
        local pic = info.data.u_info and info.data.u_info.pic
        if not pic or pic == "0" or self:isHideKing() then
            pic = "g044.png"
        else
            pic = pic .. ".png"
        end
        local head = CCLoadSprite:call("createSprite", pic)
        head:setScale(0.5)
        self.ui.m_headNode:addChild(head)
        if not self:isHideKing() then
            local picVer = tonumber(info.data.u_info and info.data.u_info.picVer or 0)
            local uid = info.data.uid
            local picfraId = info.data.u_info and info.data.u_info.picfraId
            picfraId = picfraId or ""
            
            local headIcon = CCCommonUtilsForLua:call("makeUserHeadIcon", uid, pic, picfraId, picVer, 68)
            self.ui.m_kuangNode:removeAllChildren()
            self.ui.m_kuangNode:addChild(headIcon)
        end
        self.ui.m_nodeBox:setVisible(self.parent:hasReward())
    elseif type == 2 then
        if info.data.dataType == 1 then
            self.ui.m_moreTxt:setString(getLang("221126"))
        else -- if self.m_info.dataType == 2 then
            self.ui.m_moreTxt:setString(getLang("221127"))
        end
    elseif type == 3 then
        self.ui.m_tNameLabel:setString(info.data.name)
        self.ui.m_tPowerLabel:setString(info.data.power)
        self.ui.m_tServerLabel:setString(info.data.server)
        self.ui.m_tipsLabel:setString(info.data.tips)
    elseif type == 4 then
        local tbl = info.data.rankList
        for idx = 1, 3 do
            local oneInfo = tbl and tbl[idx]
            if oneInfo then
                oneInfo.config = info.config
            end
            self.ui["m_rankNode" .. idx]:removeAllChildren()
            local rankNode = Drequire(info.data.luaFile):create(idx, oneInfo, self.parent)
            self.ui["m_rankNode" .. idx]:addChild(rankNode)
        end
    end
end

function CommonRankPlayerTblCell:refreshScore(info)
    local _score = atoi(info.data.score)
    self.ui.m_numLabel:setString(CC_CMDITOAL(_score))
end

function CommonRankPlayerTblCell:refreshCell(info, idx)
    if nil == info or type(info) ~= "table" then
        return
    end
    self.m_info = info
    self.parent = info.parent
    local type = info.type or 1

    local cells = {
        self.ui.m_rankCellRoot,
        self.ui.m_moreRoot,
        self.ui.m_rankTitleRoot,
        self.ui.m_top3RankRoot
    }
    for _, v in ipairs(cells) do
        v:setVisible(false)
    end
    cells[type]:setVisible(true)
    local size = cells[type]:getContentSize()
    self:setContentSize(size)
    self.cellSize = size
    self:refreshViewByType(info, type)
    if info.checkPageDataUpdate then
        info.checkPageDataUpdate(idx)
    end
end

function CommonRankPlayerTblCell:cellSizeForTable(tv, idx)
    if not self.cellSize then
        return self:getContentSize()
    else
        return self.cellSize
    end
end

function CommonRankPlayerTblCell:onClickSearchBtn(pSender, event)
    if self.m_info.showSearch and self.m_info.searchCallback then
        self.m_info.searchCallback(tonumber(self.m_info.data.rank) or 1)
    end
end

function CommonRankPlayerTblCell:onClickPicBtn(pSender, event)
    -- if self.m_info.hideKing == "1" or self.m_info.data.anonymous_state == 1 then
    if self:isHideKing() then
        return
    end

    if self.m_info.config and self.m_info.config.rankName then
        if self.m_info.config.rankName == "BeautyValueRank" and self.m_info.data then
            require("game.flower.FlowerController").getInstance():openSendView(self.m_info.data)
            return 
        end
    end

    local uid = self.m_info.data.uid
    if uid == nil then
        uid = self.m_info.data.u_info.uid
    end
    if uid then
        local dict = CCDictionary:create()
        dict:setObject(CCString:create("GeneralsPopupView"), "name")
        dict:setObject(CCString:create(uid), "uid")
        LuaController:call("openPopViewInLua", dict)
    end
    
    if self.m_info.config and self.m_info.config.rankName then
        if self.m_info.config.rankName == "KnightValueRank" then
            require("game.flower.FlowerController").getInstance():showKnightTip()
        end
    end
end

function CommonRankPlayerTblCell:onRewardButtonClick(pSender, event)
    -- if self.m_info.callback and self.m_info.data.rank then
    --     self.m_info.callback(tonumber(self.m_info.data.rank) or 1)
    -- end
    self.parent:onRewardButtonClick(tonumber(self.m_info.data.rank) or 1)
end

function CommonRankPlayerTblCell:onMoreButtonClick(pSender, event)
    if self.m_info.data.getMoreRank then
        self.m_info.data.getMoreRank()
    end
end

function CommonRankPlayerTblCell:onRewardButton1Click()
    self.parent:onRewardButtonClick(1)
end

function CommonRankPlayerTblCell:onRewardButton2Click()
    self.parent:onRewardButtonClick(2)
end

function CommonRankPlayerTblCell:onRewardButton3Click()
    self.parent:onRewardButtonClick(3)
end

function CommonRankPlayerTblCell:isHideKing()
    local info = self.m_info
    if not info or not info.data or not info.data.u_info then
        return true
    end
    if not info.config or not info.config.getAnonymousOpen or not info.config:getAnonymousOpen() then
        return false
    end
    if not info.isSelf and ( info.data.isShowName == "0" 
    or info.hideKing == "1" 
    or info.data.anonymous_state == "1" ) then
        -- if self.m_info and not self.isSelfFixed and (self.m_info.hideKing == "1" or self.m_info.data.anonymous_state == 1) then
        return true
    end
    return false
end

return CommonRankPlayerTblCell
