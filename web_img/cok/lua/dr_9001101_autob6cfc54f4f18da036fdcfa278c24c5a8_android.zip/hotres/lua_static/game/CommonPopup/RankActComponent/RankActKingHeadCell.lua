--排行第一玩家信息
local RankActKingHeadCell = class("RankActKingHeadCell",
function ()
    return cc.Layer:create()
end)

RankActKingHeadCell.__index = RankActKingHeadCell

function RankActKingHeadCell:ctor()
    self.ctl = require("game.CommonPopup.RankActComponent.RankActDataController").getInstance()
end

function RankActKingHeadCell:create(viewSize, info, customFrameMode)
    local view = RankActKingHeadCell.new()
    Drequire("game.CommonPopup.RankActComponent.RankActKingHeadCell_ui"):create(view,0,viewSize)
    if view:initView(info) then
        return view
    end
end

function RankActKingHeadCell:initView(info)             
    self:refreshView(info)
    return true
end

function RankActKingHeadCell:refreshView(info)
    self.info = info or self.ctl:getDataBykey("kingHeadData")
    -- dump(self.info,"hxq self.info in headCell is ")
    if self.info and type(self.info) == "table" then
        self.ui.m_closingLabel:setVisible(false)
        self.ui.m_lbNone:setVisible(fasle)
        self.ui.m_headNode:setVisible(true)

        self.ui.m_headNode:removeAllChildren()
        self.ui.m_playerName:setString(self.info.playerName)
        self.ui.m_allianceName:setString(self.info.allianceName)
        if self.info.tipLabel then
            self.ui.m_tipsNode:setVisible(true)
            self.ui.m_tipLabel:setString(self.info.tipLabel)
        else
            self.ui.m_tipsNode:setVisible(false)
        end
        local info_pic      = self.info.head_pic
        local info_picVer   = tonumber(self.info.head_picVer)
        local info_uid      = self.info.playerUid
        local info_picfraId = self.info.picfraId
        if customFrameMode then
            info_uid = nil
        end
        local headIcon = CCCommonUtilsForLua:call("makeUserHeadIcon", info_uid, info_pic, info_picfraId, info_picVer, 95)        
        self.ui.m_headNode:addChild(headIcon)        
        self:addHeadParticle()

      
    else
        self.ui.m_closingLabel:setVisible(true)
        self.ui.m_headNode:setVisible(false)
        local state = self.info
       
        if state == 2 then
            self.ui.m_closingLabel:setString(getLang("168108"))
        elseif state == 3 then
            self.ui.m_closingLabel:setString(getLang("176075"))
        else
            self.ui.m_closingLabel:setVisible(false)
            self.ui.m_lbNone:setVisible(true)
            self.ui.m_lbNone:setString(getLang("140257"))
        end
    end
end
--添加特殊战士的奖励
function RankActKingHeadCell:addSpecialItem(data)
      --奖励特效
      if data and data.itemId then
       
        self.ui.m_nodeItem:removeAllChildren()
        local itemdata = {}
        itemdata.type = 0
        itemdata.itemId = data.itemId          

        LibaoCommonFunc.createItemInfoShow(itemdata, self.ui.m_nodeItem, 84, nil, nil, nil, true) 
        local frame = CCLoadSprite:call("getSF", "BG_tubiaokuang01.png")
        if frame then
            self.ui.m_nodeItem:getChildByTag(GOODS_BG_TAG):setSpriteFrame(frame)
            self.ui.m_nodeItem:getChildByTag(GOODS_BG_TAG):setScale(1)
            self.ui.m_nodeItem:getChildByTag(GOODS_BG_TAG):setPositionY(10)
        end
        
        for i = 0, 2 do
            local particle = ParticleController:call("createParticle", "England_"..i)
            if particle then
                self.ui.m_nodeItem:addChild(particle)
            end
        end

    end
end
function RankActKingHeadCell:onClickBtnAvatar()
	local view = Drequire("game.activity.BattlePassNew.BattlePassAvatarPreView"):create()
	PopupViewController:addPopupView(view)
end
function RankActKingHeadCell:addHeadParticle()
    if self.refreshParticle then
        return
    end
    self.ui.m_headParNode:removeAllChildren()
    self.ui.m_nodeHead:removeAllChildren()
    self.ui.m_headParNode:setScale(0.88)
    local parTbl = {
        {"dawangguan_1.plist",0,40},
        {"dawangguan_2.plist",0,25},
        {"dawangguan_3.plist",0,10},
        {"dawangguan_4.plist",-45,15},
        {"dawangguan_5.plist",-43,15},
        {"dawangguan_6.plist",0,-10},
        {"dawangguan_7.plist",45,15},
        {"dawangguan_8.plist",43,15},
    }
    local rootPath = CCFileUtils:sharedFileUtils():getWritablePath() .. "dresource/"
    for k, v in pairs(parTbl) do       
		local plistPath = rootPath .. "skinparticle/" .. v[1]
		local particle = ParticleController:call("createParticleForLua", plistPath)
		if particle then
			particle:setPosition(v[2], v[3])
			self.ui.m_headParNode:addChild(particle)
		end
    end 
    self.refreshParticle = true

    if self.info.item and  self.info.item.isEffect then
        local params = {}
       
        params.tblParticles ={"DragonCristal_4_0.plist","DragonCristal_4_1.plist","DragonCristal_4_2.plist"}
        params.tblPositions = {cc.p(0,-30),cc.p(0,-30),cc.p(0,-30)}
        params.isCreateNewParNode = true
        params.scale = 1

        self.ui.m_nodeHead:addChild(createParticlesNode(params))

       
    end  
end

function RankActKingHeadCell:onClickHead()    
    local uid = ( self.info and type(self.info) == "table")and self.info.playerUid or ""
    if uid ~= "" then
        local dict = CCDictionary:create()
		dict:setObject(CCString:create("GeneralsPopupView"), "name")
		dict:setObject(CCString:create(uid), "uid")
		LuaController:call("openPopViewInLua", dict)
    end
end

function RankActKingHeadCell:onEnter()
    registerScriptObserver(self,self.refreshView,"msg.RankActKingHeadCell.refreshView")
end

function RankActKingHeadCell:onExit()
    unregisterScriptObserver(self,"msg.RankActKingHeadCell.refreshView")
end
return RankActKingHeadCell