local ChangeServerApplyCell = class("ChangeServerApplyCell", cc.TableViewCell)

local default_ccb = "game.CommonPopup.ChangeServer.ChangeServerApplyCell_ui"

function ChangeServerApplyCell:create(idx, ccb_ui)
    return ChangeServerApplyCell.new(ccb_ui)
end

function ChangeServerApplyCell:ctor(ccb_ui)
    ccb_ui = ccb_ui or default_ccb
    Drequire(ccb_ui):create(self, 0)
end

function ChangeServerApplyCell:refreshCell(info, idx)
    self.info = info

    if type(self.info) == "number" then return end

    local name = info.abbr .. "(" .. info.name .. ")"
    self.ui.m_allianceNameTxt:setString(name)
    self.ui.m_serverTxt:setString(info.serverId)
    self.ui.m_numTxt:setString("(" .. info.rCur .. "/" .. info.rMax .. ")")
    self.ui.m_lanTxt:setString(getLang(info.lan))

    local flag = AllianceFlagPar:call("create", info.icon .. ".png")
    flag:setScale(0.6)
    self.ui.m_flagNode:removeAllChildren()
    self.ui.m_flagNode:addChild(flag)
    self.ui.m_allianceDescTxt:setString(getLang("110175") .. ":" .. getLang(info.announce))

    local rankName = require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance():getRankName(info.rank)
    self.ui.m_rankTxt:setString(rankName)

    local state = atoi(info.state)
    if state == 1 then
        self.ui.m_stateTxt:setString(getLang("173232"))
        self.ui.m_stateTxt:setColor(cc.c3b(255, 35, 35))
    elseif state == 2 then
        self.ui.m_stateTxt:setString(getLang("173233"))
        self.ui.m_stateTxt:setColor(cc.c3b(132, 233, 170))
    elseif state == 3 then
        self.ui.m_stateTxt:setString(getLang("173234"))
        self.ui.m_stateTxt:setColor(cc.c3b(255, 35, 35))
    end

    self.ui.m_preferTxt:setString(getLang(info.prefer))
    if info.power then
        self.ui.m_requireTxt:setString(getLang("173275", CC_ITOA_K(atoi(info.power))))
    elseif info.kill then
        self.ui.m_requireTxt:setString(getLang("173276", CC_ITOA_K(atoi(info.kill))))
    elseif info.active then
        self.ui.m_requireTxt:setString(getLang("173277", getLang(info.active)))
    end
    self.ui.m_cityTxt:setString(getLang("173274", self.info.city))

    local color = require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance():getHotColor(info.serverState or 3)
    local redDot = CCLoadSprite:createSprite("mail_unread_Icon.png")
    redDot:setScale(0.5)
    self.ui.m_hotNode:removeAllChildren()
    self.ui.m_hotNode:addChild(redDot)

    self:showOther()
end

function ChangeServerApplyCell:showOther()
    dump("override me if necessary")
end

function ChangeServerApplyCell:getDetail()
    return self.info
end

return ChangeServerApplyCell