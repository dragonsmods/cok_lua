GoldBoxTipsView = class("GoldBoxTipsView", function()
        return PopupBaseView:create()
    end
)
GoldBoxTipsView.__index = GoldBoxTipsView

local Cell_Width = 540
local Cell_Height = 100
local cellAllHeight = 0
local deltaCellHeight = 10
------------------------------------------ GoldBoxBigCell Start --------------------------------------------
local GoldBoxBigCell = class("GoldBoxBigCell", function()
    return cc.Layer:create()
end)

function GoldBoxBigCell:create(datas,tblExtTip)
    -- dump(tblExtTip, "GoldBoxBigCell:create+++")
    local ret = GoldBoxBigCell.new()
    if ret:init(datas,tblExtTip) == false then
        return nil
    end
    return ret
end

function GoldBoxBigCell:init(datas,tblExtTip)
    --初始化界面
    --MyPrint("cjy data1",data1,data2,data3)
    for i=1, #datas do
        if i == 1 then
            self:addCellTitle(getLang("140461"))
        elseif i == 2 then
            self:addCellTitle(getLang("140462"))
        elseif i == 3 then
            self:addCellTitle(getLang("140479"))
        elseif i == 4 then 
            self:addCellTitle(getLang("176146"))
        elseif i == 5 then 
            self:addCellTitle(getLang("176399"))--176399=活动结束后,全服排名31~50的玩家,将获得:
        end
        local data = nil
        
        data = datas[i]

        local bgSpr = CCLoadSprite:call("createScale9Sprite","bg_grey.png");
        -- bgSpr:setContentSize(cc.size(550,109))
        bgSpr:setAnchorPoint(cc.p(0,1))
        bgSpr:setPosition(cc.p(0, 0 - cellAllHeight + deltaCellHeight*0.5))
        self:addChild(bgSpr)

        local dataList = string.split(data,"|")
        for i,v in ipairs(dataList) do--"104037,3"
            local num = string.split(v,";")[2]
            local id = string.split(v,";")[1]
            if id and num then
                self:addcellContent(id,num)
            end
        end
        bgSpr:setContentSize(cc.size(550, Cell_Height * #dataList + deltaCellHeight))
        

        cellAllHeight = cellAllHeight + deltaCellHeight
    end
    -- cellAllHeight = cellAllHeight + deltaCellHeight * 6
    self:addExtTip(tblExtTip)
    self:addContentEnd(getLang("140502" , ActivityController.getInstance():getProperty("goldBoxScoreQingtong") , ActivityController.getInstance():getProperty("goldBoxScoreBaiyin") , ActivityController.getInstance():getProperty("goldBoxScoreHuangjin")))
    self:setContentSize(CCSizeMake(Cell_Width, cellAllHeight))

    return true
end

function GoldBoxBigCell:addContentEnd(title )
    local label1 = cc.Label:createWithSystemFont(title, "Helvetica", 18, cc.size(Cell_Width,0))
    label1:setColor(cc.c3b(50, 30, 2))
    label1:setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    label1:setAnchorPoint(cc.p(0.5, 0.5))
    label1:setPositionX(555 / 2)
    label1:setPositionY(-cellAllHeight - label1:getContentSize().height / 2)
    self:addChild(label1)
    cellAllHeight = cellAllHeight + label1:getContentSize().height + deltaCellHeight
end
function GoldBoxBigCell:addcellContent( id,num )
    local cellNode = cc.Node:create()
    -- local bgSpr = CCLoadSprite:call("createScale9Sprite","bg_grey.png");
    -- bgSpr:setContentSize(cc.size(550,109))
    -- bgSpr:setAnchorPoint(cc.p(0,0.5))
    -- cellNode:addChild(bgSpr)
    local iconBg = CCLoadSprite:call("createSprite","icon_kuang.png")
    iconBg:setPositionX(10)
    iconBg:setScale(0.8)
    iconBg:setAnchorPoint(cc.p(0,0.5))
    cellNode:addChild(iconBg)
    local iconNode = cc.Node:create()
    CCCommonUtilsForLua:call("createGoodsIcon", tonumber(id), iconNode, CCSizeMake(70, 70))
    iconNode:setPosition(cc.p(iconBg:getContentSize().width * 0.8 / 2 + 10,0))
    cellNode:addChild(iconNode)
    self:addChild(cellNode)
    local label1 = cc.Label:createWithSystemFont("x"..tostring(num), "Helvetica", 18, cc.size(0,0))
    label1:setAnchorPoint(cc.p(1,0.5))
    label1:setColor(cc.c3b(84, 50, 3))
    label1:setPositionX(530)
    cellNode:addChild(label1)
    cellNode:setPositionY(-cellAllHeight - Cell_Height / 2 )
    local itemName = CCCommonUtilsForLua:call("getNameById", tostring(id))
    local label2 = cc.Label:createWithSystemFont(itemName, "Helvetica", 18, cc.size(380,0))
    label2:setAnchorPoint(cc.p(0,0.5))
    label2:setColor(cc.c3b(84, 50, 3))
    label2:setPositionX(120)
    cellNode:addChild(label2)
    cellNode:setPositionY(-cellAllHeight - Cell_Height / 2 )

    -- cellAllHeight = cellAllHeight +  Cell_Height + deltaCellHeight
    cellAllHeight = cellAllHeight +  Cell_Height

end
function GoldBoxBigCell:addCellTitle(title)
    local label1 = cc.Label:createWithSystemFont(title, "Helvetica", 18, cc.size(Cell_Width,0))
    label1:setColor(cc.c3b(84, 50, 3))
    label1:setAnchorPoint(cc.p(0, 0.5))
    label1:setPositionX(20)
    label1:setPositionY(-cellAllHeight - label1:getContentSize().height / 2)
    self:addChild(label1)
    cellAllHeight = cellAllHeight + label1:getContentSize().height + deltaCellHeight
end

function GoldBoxBigCell:addExtTip( tblExtTip )
    if tblExtTip and #tblExtTip > 0 then
        for k, tip in pairs(tblExtTip) do 
            local label1 = cc.Label:createWithSystemFont(tip, "Helvetica", 18, cc.size(Cell_Width,0))
            label1:setColor(cc.c3b(84, 50, 3))
            label1:setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
            label1:setAnchorPoint(cc.p(0.5, 0.5))
            label1:setPositionX(555 / 2)
            label1:setPositionY(-cellAllHeight - label1:getContentSize().height / 2)
            self:addChild(label1)
            cellAllHeight = cellAllHeight + label1:getContentSize().height + deltaCellHeight
        end
    end
end

------------------------------------------ GoldBoxBigCell End --------------------------------------------


GoldBoxTipsViewGaiLvCell = class("GoldBoxTipsViewGaiLvCell",
    function()
        return cc.Layer:create()
    end
)
GoldBoxTipsViewGaiLvCell.__index = GoldBoxTipsViewGaiLvCell

function GoldBoxTipsViewGaiLvCell:create(data)
    local view = GoldBoxTipsViewGaiLvCell.new(data)
    if view:initView(data) then
        return view
    end
    return nil
end

function GoldBoxTipsViewGaiLvCell:initView(data)
    -- dump(data,"GoldBoxTipsViewGaiLvCell:initView+++")
    local ccbiUrl = "GoldBoxTipsViewGaiLvCell"
    local proxy = cc.CCBProxy:create()
    local bg = CCBReaderLoad(ccbiUrl, proxy, self)
    self:addChild(bg)
    self:setContentSize(bg:getContentSize())
    self:setData(data)
    return true
end

function GoldBoxTipsViewGaiLvCell:setData(data)
    if data.qbh and (data.firstQingTong or data.firstBaiYin or data.firstHuangJin) then
        self.m_labelQingTong:setString(data.qbh)
    else
        self.m_labelQingTong:setString("")
    end
    if data.goodsName then
        self.m_labelWuPin:setString(data.goodsName)
    else
        self.m_labelWuPin:setString("")
    end
    if data.gailv then
        self.m_labelGaiLv:setString( tostring(string.format("%.4f",data.gailv).."%") )
    else
        self.m_labelGaiLv:setString("")
    end
end


------------------------------------------ GoldBoxTipsView Start --------------------------------------------

function GoldBoxTipsView:create(tipMsgInHelpView)
    local view = GoldBoxTipsView.new()
    if view:initView(tipMsgInHelpView) == false then
        return nil
    end
    return view
end

local btn_index_reward = 1
local btn_index_gaiLv = 2
function GoldBoxTipsView:initView(tipMsgInHelpView)
    if self:init(true, 0) == false then
        --MyPrint("GoldBoxTipsView init error")
        return false
    end
    --MyPrint("GoldBoxTipsView init")
    self:setHDPanelFlag(true)
    self.m_tableViewGaiLv = nil
    local  proxy = cc.CCBProxy:create()
    local ccbiURL = ""
    ccbiURL = "ccbi/GoldBoxTipsView.ccbi"

    local nodeccb = CCBReaderLoad(ccbiURL,proxy, self)
    if nodeccb == nil then
        --MyPrint("GoldBoxTipsView loadccb error")
        return false
    end

    self.m_bIsPad = CCCommonUtilsForLua:isIosAndroidPad()
    if self.m_bIsPad then
        nodeccb:setScale(2.0)
    else
        nodeccb:setScale(1.0)
    end
    self:setContentSize(cc.Director:getInstance():getIFWinSize())
    self:addChild(nodeccb)

    self.ccbNode = nodeccb
    local function onNodeEvent(event)
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end
    self.ccbNode:registerScriptHandler(onNodeEvent)

    function onTouch(eventType, x, y)  
        if eventType == "began" then  
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)  
        else  
            return self:onTouchEnded(x, y)  
        end
    end
    local touchif = tolua.cast(self,"cc.CCIFTouchNode")
    if touchif ~= nil then
        local dic1 = CCDictionary:create()
        dic1:setObject(CCBool:create(true),"1")
        touchif:comFunc("setTouchEnabled", dic1)

        --MyPrint("GoldBoxTipsView:registerScriptTouchHandler")
        touchif:registerScriptTouchHandler(onTouch)
    end
    self.m_titleLabel:setString(getLang("140475"))
    --读取前台表
    local xmlData = CCCommonUtilsForLua:getGroupByKey("golden_roulette")
    -- dump(xmlData, "golden_roulette+++")
    self.m_rewardType1 = nil
    self.m_rewardType2 = nil
    self.m_rewardType3 = nil
    self.m_rewardType4 = nil
    self.m_datas = {}
    for k,v in pairs(xmlData) do
        if tonumber(v.index) == 1 then
            -- self.m_rewardType1 = v.rewardtype1
            -- self.m_rewardType2 = v.rewardtype2
            -- self.m_rewardType3 = v.rewardtype3
            -- self.m_rewardType4 = v.rewardtype4
            self.m_datas[1] = v.rewardtype1
            self.m_datas[2] = v.rewardtype2
            self.m_datas[3] = v.rewardtype3
            self.m_datas[4] = v.rewardtype4
            if CCCommonUtilsForLua:isFunOpenByKey("golden_roulette_31_50") then
                self.m_datas[5] = v.rewardtype5 --代表全服31-50
            end
            break
        end

    end
    --UI
    local scrollView = cc.ScrollView:create()
    if scrollView ~= nil  and self.m_datas ~= {} then
        scrollView:setViewSize(self.m_infoList:getContentSize())
        scrollView:setPosition(cc.p(0,0))
        scrollView:setScale(1.0)
        scrollView:ignoreAnchorPointForPosition(true)
        scrollView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)

        local cH = self.m_infoList:getContentSize().height
        local height = 0
        local mainNode = cc.Node:create();
        local cell = GoldBoxBigCell:create(self.m_datas, tipMsgInHelpView)
        if cell then
            mainNode:addChild(cell)
            height = height + cellAllHeight
            cell:setPosition(cc.p(0, 0))
        end
        scrollView:addChild(mainNode);
        mainNode:setPosition(cc.p(0, height))
        scrollView:setContentSize(CCSize(Cell_Width,height))
        scrollView:setContentOffset(CCPoint(0, cH - height))
        self.scrollView = scrollView
        self.m_infoList:addChild(scrollView);
    end

    -- 102139=奖励
    -- 176311=概率
    CCCommonUtilsForLua:setButtonTitle(self.m_rewardBtn, getLang("102139")) 
    CCCommonUtilsForLua:setButtonTitle(self.m_gaiLvBtn, getLang("176311")) 
    self:highLightBtn(btn_index_reward)
    return true
end

function GoldBoxTipsView:onGaiLvBtnClick( )
    self:changeContentByBtnIndex(btn_index_gaiLv)
end

function GoldBoxTipsView:onRewardBtnClick( )
    self:changeContentByBtnIndex(btn_index_reward)
end

function GoldBoxTipsView:cellSizeForTable(tab, idx)
    return 500,60
end

function GoldBoxTipsView:tableCellAtIndex(tab, idx)
    -- Dprint('GoldBoxTipsView:tableCellAtIndex', idx)
    if (idx >= self:numberOfCellsInTableView()) then 
        return 
    end

    local dict = self.tblDataGaiLv[idx+1]
    if not dict then
        return
    end
    local cell = tab:dequeueCell()
    if (cell) then
        local node = cell:getChildByTag(666)
        if node then node:setData(dict) end
    else
        local node = GoldBoxTipsViewGaiLvCell:create(dict)
        node:setTag(666)
        cell = cc.TableViewCell:create()
        cell:addChild(node)
    end
    return cell
end

function GoldBoxTipsView:numberOfCellsInTableView(tab)
    return #(self.tblDataGaiLv)
end

-- 140454=青铜
-- 140455=白银
-- 140456=黄金
function GoldBoxTipsView:initGaiLvTableView()
    local xmlDataRule = CCCommonUtilsForLua:getGroupByKey("golden_roulette")
    -- dump(xmlDataRule, "golden_roulette is+++: ")
    self.tblDataGaiLv={}
    local qingtong = getLang("140454")
    local baiyin = getLang("140455")
    local huangjin = getLang("140456")
    local tmpTblQingTong = {}
    local tmpTblBaiYin = {}
    local tmpTblHuangJin = {}
    local firstQingTong,firstBaiYin,firstHuangJin = true,true,true
    for key, data in pairs(xmlDataRule) do
        local tblGaiLvs = string.split(data.rate,";")
        -- dump({data.rate,data.item},"rata,items+++")
        local totalRate = 0
        for k, v in pairs(tblGaiLvs) do
            totalRate = totalRate + tonumber(v)
        end
        if totalRate == 0 then 
            return
        end
        local items = data.item
        local tblItems = string.split(items,";")
        if tblItems and #tblItems > 0 then
            for k, itemId in pairs(tblItems) do
                local cellData = {}
                if key == "89600" then --青
                    cellData.firstQingTong = false
                    if firstQingTong then
                        firstQingTong = false
                        cellData.firstQingTong = true
                    end
                    cellData.qbh = qingtong
                elseif key == "89601" then  --白
                    cellData.firstBaiYin = false
                    if firstBaiYin then
                        firstBaiYin = false
                        cellData.firstBaiYin = true
                    end
                    cellData.qbh = baiyin
                elseif key == "89602" then --黄
                    cellData.firstHuangJin = false
                    if firstHuangJin then
                        firstHuangJin = false
                        cellData.firstHuangJin = true
                    end
                    cellData.qbh = huangjin
                end
                local nameIdx = CCCommonUtilsForLua:getPropById(itemId, "name")
                cellData.goodsName = getLang(nameIdx)
                local curRate = tblGaiLvs[k]
                if curRate then
                    local gailv = string.format("%.4f",tonumber(curRate)/totalRate*100)
                    cellData.gailv = tonumber(gailv)
                end

                if cellData.qbh == qingtong then 
                    tmpTblQingTong[#tmpTblQingTong+1] = cellData
                elseif cellData.qbh == baiyin then 
                    tmpTblBaiYin[#tmpTblBaiYin+1] = cellData
                elseif cellData.qbh == huangjin then
                    tmpTblHuangJin[#tmpTblHuangJin+1] = cellData
                end
            end
        end
    end

    local function addData( tmpTblData )
        for k,v in pairs(tmpTblData) do
            self.tblDataGaiLv[#self.tblDataGaiLv+1] = v
        end
    end 
    local function checkGaiLv(tmpTblData)
        local maxGaiLv = 0
        local maxGaiLvKey = 0
        local totalGaiLv = 0
        for k,v in pairs(tmpTblData) do
            if v and v.gailv then 
                totalGaiLv = totalGaiLv + v.gailv
                if v.gailv > maxGaiLv then 
                    maxGaiLv = v.gailv
                    maxGaiLvKey = k
                end
            end
        end
        if maxGaiLv > 0 and maxGaiLv < 100 and tmpTblData[maxGaiLvKey] then
            local totalOkGaiLv = totalGaiLv - maxGaiLv
            tmpTblData[maxGaiLvKey].gailv = tonumber(string.format("%.4f",100-totalOkGaiLv))
            -- dump({totalGaiLv,maxGaiLv,totalOkGaiLv,100-totalOkGaiLv},"totalGaiLv,maxGaiLv,totalOkGaiLv,100-totalOkGaiLv+++")
        end
    end 
    checkGaiLv(tmpTblQingTong)
    addData(tmpTblQingTong)
    checkGaiLv(tmpTblBaiYin)
    addData(tmpTblBaiYin)
    checkGaiLv(tmpTblHuangJin)
    addData(tmpTblHuangJin)
    -- dump(self.tblDataGaiLv,"self.tblDataGaiLv+++")

    local listSize = self.m_infoList:getContentSize()
    self.m_tableViewGaiLv = cc.TableView:create(listSize)
    self.m_tableViewGaiLv:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
    self.m_tableViewGaiLv:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
    self.m_tableViewGaiLv:setDelegate()
    self.m_tableViewGaiLv:registerScriptHandler(function(tab, idx) return self:cellSizeForTable(tab, idx) end, cc.TABLECELL_SIZE_FOR_INDEX)
    self.m_tableViewGaiLv:registerScriptHandler(function(tab, idx) return self:tableCellAtIndex(tab, idx) end, cc.TABLECELL_SIZE_AT_INDEX)
    self.m_tableViewGaiLv:registerScriptHandler(function(tab) return self:numberOfCellsInTableView(tab) end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
    self.m_infoList:addChild(self.m_tableViewGaiLv)
    self.m_tableViewGaiLv:setVisible(false)
    self.m_tableViewGaiLv:reloadData()
end

function GoldBoxTipsView:changeContentByBtnIndex( btnIndex )
    if btnIndex == btn_index_gaiLv and not self.m_tableViewGaiLv then
        self:initGaiLvTableView()
    end
    self:highLightBtn(btnIndex)
    if btnIndex == btn_index_gaiLv then 
        self.scrollView:setVisible(false)
        if self.m_tableViewGaiLv then
            self.m_tableViewGaiLv:setVisible(true)
        end
    elseif btnIndex == btn_index_reward then
        self.scrollView:setVisible(true)
        if self.m_tableViewGaiLv then
            self.m_tableViewGaiLv:setVisible(false)
        end
    end
end

function GoldBoxTipsView:highLightBtn( btnIndex )
    if btnIndex == btn_index_gaiLv then 
        self.m_rewardBtn:setEnabled(true)
        self.m_gaiLvBtn:setEnabled(false)
    elseif btnIndex == btn_index_reward then
        self.m_rewardBtn:setEnabled(false)
        self.m_gaiLvBtn:setEnabled(true)
    end
end

function GoldBoxTipsView:onEnter()

end

function GoldBoxTipsView:onExit()
end

function GoldBoxTipsView:onTouchBegan(x, y)
    return true
end

function GoldBoxTipsView:onTouchMoved(x, y)
end

function GoldBoxTipsView:onTouchEnded(x, y)
    if touchInside(self.m_touchNode, x, y) == false then
        --MyPrint("GoldBoxTipsView:onTouchEnded not touchInside m_touchNode")
        self:call("closeSelf")
    end
end

return GoldBoxTipsView







