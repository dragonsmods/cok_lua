
-----------------------------获取基金数据---------------------------------------
MonthFundDataBackMsg = "MonthFund_data_back_msg"
local MonthFundDataCmd = class("MonthFundDataCmd", LuaCommandBase)
function MonthFundDataCmd.create()
    local ret = MonthFundDataCmd.new()
    ret:initWithName("monthfund.info")
    return ret
end

function MonthFundDataCmd:handleReceive(dict)
    local tbl = self:parseMsg(dict)
    if type(tbl) == "boolean" then
        return tbl
    end
    if self.callbackFun then 
    	self.callbackFun(tbl)
    end
    return true
end


------------------------------获取基金奖励信息--------------------------------------
MonthFundAllRewardBackMsg = "MonthFundAllReward_back_msg"
local MonthFundAllRewardCmd = class("MonthFundAllRewardCmd", LuaCommandBase)
function MonthFundAllRewardCmd.create()
    local ret = MonthFundAllRewardCmd.new()
    ret:initWithName("monthfund.rewardinfo")
    return ret
end

function MonthFundAllRewardCmd:handleReceive(dict)
    local tbl = self:parseMsg(dict)
    if type(tbl) == "boolean" then
        return tbl
    end
                                       

    if self.callbackFun then 
        self.callbackFun(tbl)
    end
    return true
end


------------------------------领奖--------------------------------------
MonthFundGetRewardBackMsg = "MonthFundGetReward_back_msg"
local MonthFundGetRewardCmd = class("MonthFundGetRewardCmd", LuaCommandBase)
function MonthFundGetRewardCmd.create(fundid)
    local ret = MonthFundGetRewardCmd.new()
    ret:initWithName("monthfund.reward")
    ret:putParam("fundId", CCString:create(fundid))
    return ret
end

function MonthFundGetRewardCmd:handleReceive(dict)
    local tbl = self:parseMsg(dict)
    if type(tbl) == "boolean" then
        return tbl
    end
    if self.callbackFun then 
        self.callbackFun(tbl)
    end
    return true
end
------------------------------------------------------------------------------
local superClass = require("game.controller.KpiActMgr")
local MonthFundController = class("MonthFundController",superClass)

local _instance = nil
function MonthFundController.getInstance()
    if _instance == nil then
        _instance = MonthFundController.new()
        guiCommonGlobal.controllerAutoPurge(_instance)
    end
    return _instance
end

function MonthFundController:reset(  )
    superClass.reset(self)
   
end



function MonthFundController:ctor()
    superClass.ctor(self,"57268","","month_fund")
    self.giftBoxDesc= string.split(CCCommonUtilsForLua:call("getPropByIdGroup", "activity_panel", self.m_actId, "para1"),",")
  
    self.isMonthFundOpen = false --是否可进入整合界面
    self.monthFundRedPtCount = 0
    self.dollar19 = ""
    self.dollar49 = ""
    self.dollar99 = ""
    self.dollar9 = ""
    self.fund19Rewards = {}
    self.fund49Rewards = {}
    self.fund99Rewards = {}
    self.fund9Rewards = {}
end

function MonthFundController:updateActStatus( )
    self.isActivityOpen = false
    local act = ActivityController:call("getActObj", self.m_actId)
    if act then
        if act:getProperty("endTime") then
            local endTime = tonumber(act:getProperty("endTime"))
            -- MyPrint('integrateMonthFundController:checkOpen endTime', endTime)
            if endTime > 0 and getWorldTime() > endTime then
                return false
            end
        end
        if act:getProperty("startTime") then
            local startTime = tonumber(act:getProperty("startTime"))
            -- MyPrint('integrateMonthFundController:checkOpen startTime', startTime)
            if startTime > 0 and getWorldTime() < startTime then
                return false
            end
        end
        self.isActivityOpen = true
    end
    return self.isActivityOpen
end

--基金被激活
function MonthFundController:onPushMonthFund(dict)
    self.isMonthFundOpen = true
    if self.monthFundRedPtCount < 1 then 
        self.monthFundRedPtCount = 1
    end
end

function MonthFundController:initConfigData(dict)
    if not dict then 
        return 
    end
    local params = dict:objectForKey("monthFund")
    if params then
        local data = dictToLuaTable(params)
        if data then 
            local available = tonumber(data.available)
            local canReward = tonumber(data.canReward)
            self.isMonthFundOpen = available > 0
            self.monthFundRedPtCount = canReward
        end
    end
end

function MonthFundController:isHasRewardNotRecvd(tblFundDays, today)
    if not tblFundDays or not today then 
        return false
    end
    local has = false
    for k,v in pairs(tblFundDays) do 
        if v and v.order == today and v.receive == "0" then
            has = true
            break
        end
    end
    return has
end

function MonthFundController:pullMonthFundData( )
	local function callbackFunK( tbl )
		self:processMonthFundData(tbl)
	end 
	local cmd = MonthFundDataCmd.create()
	cmd.callbackFun = callbackFunK
    cmd:send()
end

   -- "cardNum"    = "1"
   -- "fund" = {
   --     1 = {
   --         "available"   = "0". --是否激活
   --         "days" = *MAX NESTING*
   --         "gold"        = "gold_3"
   --         "id"          = "9022501"
   --         "needCardNum" = "2"
   --         "page"        = "1"
   --     }
   --     2 = {
   --         "available"   = "0"
   --         "days" = *MAX NESTING*
   --         "gold"        = "gold_4"
   --         "id"          = "9022502"
   --         "needCardNum" = "3"
   --         "page"        = "2"
   --     }

    -- "days" = {
    --             1 = {
    --                 "hot"   = "0"
    --                 "id"    = "200065"
    --                 "num"   = "1"
    --                 "order" = "1"
    --             }
function MonthFundController:processMonthFundData( tbl )
    if not tbl or not tbl.fund or not tbl.fund[1] or not tbl.fund[2] or (self:isNew99Open() and not tbl.fund[3]) then 
        return 
    end
    self:sortLibao(tbl.fund)
    local function processDays( tblDays )
        -- dump(tblDays,"tblDays+++")
        if not tblDays or #tblDays == 0 then 
            return {}
        end
        local tblRet = {}
        local cellData = {}
        for k,v in pairs(tblDays) do
            v.cellType = 1 --基金展示
            cellData[#cellData+1] = v
            if #cellData == 5 then 
                tblRet[#tblRet+1] = cellData
                cellData = {}
            end
        end
        if #cellData > 0 then 
            tblRet[#tblRet+1] = cellData
        end
        return tblRet
    end

    self.curTotalMonthCards = tonumber(tbl.cardNum)
    self.fund19 = tbl.fund[2]
    self.isActived19 = (self.fund19.available ~= "0")
    self.needCardNum19 = tonumber(self.fund19.needCardNum)
    self.fund19Rewards = processDays(self.fund19.days)
    self.dollar19 = LuaController:call("getDollarString", "", self.fund19.gold)

    self.fund49 = tbl.fund[3]
    self.isActived49 = (self.fund49.available ~= "0")
    self.needCardNum49 = tonumber(self.fund49.needCardNum)
    self.fund49Rewards = processDays(self.fund49.days)
    self.dollar49 = LuaController:call("getDollarString", "", self.fund49.gold)

    if self:isNew99Open() and tbl.fund[4] then
        self.fund99 = tbl.fund[4]
        self.isActived99 = (self.fund99.available ~= "0")
        self.needCardNum99 = tonumber(self.fund99.needCardNum)
        self.fund99Rewards = processDays(self.fund99.days)
        self.dollar99 = LuaController:call("getDollarString", "", self.fund99.gold)
    end

    self.fund9 = tbl.fund[1]
    self.isActived9 = (self.fund9.available ~= "0")
    self.needCardNum9 = tonumber(self.fund9.needCardNum)
    self.fund9Rewards = processDays(self.fund9.days,self.nowDay9)
    self.dollar9 = LuaController:call("getDollarString", "", self.fund9.gold)
    if tbl.progressBoxInfo then
       self:parseLibaoBox(tbl.progressBoxInfo)
       
    end
    self:postRedCount()
    CCSafeNotificationCenter:postNotification(MonthFundDataBackMsg)
end
function MonthFundController:parseLibaoBox(progressBoxInfo)
       --宝箱信息
       self.progressBoxInfo = {}
       if  table.isNilOrEmpty(progressBoxInfo) then
          return 
       end
       for i,v in ipairs(progressBoxInfo) do
            local info = 
            {state = tonumber(v.status),--0 未完成 1 完成但未领取 2 已领取|
            rewardId = v.reward,
            title =  self.giftBoxDesc[i] or "",
            target = tonumber(v.target),
            index = tonumber(v.index),
            num = tonumber(v.num),--当前完成数
            reqRewardFunc = function()
                             self:reqGetGiftReward(tonumber(v.index))
                            end
            }

            if i > 1 then
                info.bottom = i == 2 and 0 or tonumber(progressBoxInfo[i-1].target)
            end
            table.insert(self.progressBoxInfo,info)
        end
end

function MonthFundController:pullAllMonthFunRewardData( )
    local function callbackFun( tbl )
        self:processAllMonthFundRewardData(tbl)
    end 

    if isCrossServerNow() == false then
        local cmd = MonthFundAllRewardCmd.create()
        cmd.callbackFun = callbackFun
        cmd:send()
    end
end

function MonthFundController:updateCanGetRewardsTodayStatus( )
    self.fund19_rCanGetRewardsToday = false
    if self.isActived19_r and self.nowDay19_r and self.fund19_r.days and self.fund19_r.days[self.nowDay19_r] then 
        self.fund19_rCanGetRewardsToday = (self.fund19_r.days[self.nowDay19_r].receive == "0")
    end
    self.fund49_rCanGetRewardsToday = false
    if self.isActived49_r and self.nowDay49_r and self.fund49_r.days and self.fund49_r.days[self.nowDay49_r] then 
        self.fund49_rCanGetRewardsToday = (self.fund49_r.days[self.nowDay49_r].receive == "0")
    end
    if self:isNew99Open() and self.fund99_r then
        self.fund99_rCanGetRewardsToday = false
        if self.isActived99_r and self.nowDay99_r and self.fund99_r.days and self.fund99_r.days[self.nowDay99_r] then 
            self.fund99_rCanGetRewardsToday = (self.fund99_r.days[self.nowDay99_r].receive == "0")
        end
    end
    self.fund9_rCanGetRewardsToday = false
    if self.isActived9_r and self.nowDay9_r and self.fund9_r.days and self.fund9_r.days[self.nowDay9_r] then 
        self.fund9_rCanGetRewardsToday = (self.fund9_r.days[self.nowDay9_r].receive == "0")
    end
end

function MonthFundController:updateMonthFundRedPtCount( )
    self.monthFundRedPtCount = 0
    if self.fund19_rCanGetRewardsToday then 
        self.monthFundRedPtCount = self.monthFundRedPtCount + 1
    end
    if self.fund49_rCanGetRewardsToday then 
        self.monthFundRedPtCount = self.monthFundRedPtCount + 1
    end
    if self:isNew99Open() then
        if self.fund99_rCanGetRewardsToday then 
            self.monthFundRedPtCount = self.monthFundRedPtCount + 1
        end
    end
    if self.fund9_rCanGetRewardsToday then 
        self.monthFundRedPtCount = self.monthFundRedPtCount + 1
    end
    
end

function MonthFundController:processAllMonthFundRewardData( tbl )
    if not tbl or not tbl.fund or not tbl.fund[1] or not tbl.fund[2] or (self:isNew99Open() and not tbl.fund[3]) then 
        return 
    end
    self:sortLibao(tbl.fund)
    
    local function processDays( tblDays,nowDay )
        -- dump(tblDays,"tblDays+++")
        if not tblDays or #tblDays == 0 then 
            return {}
        end
        local tblRet = {}
        local cellData = {}
        for k,v in pairs(tblDays) do
            v.cellType = 2 --领取基金奖励
            if tonumber(v.order) < nowDay then 
                v.passed = true
            else
                v.passed = false
            end

            cellData[#cellData+1] = v
            if #cellData == 5 then 
                tblRet[#tblRet+1] = cellData
                cellData = {}
            end
        end
        if #cellData > 0 then 
            tblRet[#tblRet+1] = cellData
        end
        -- dump(tblRet,"tblRet+++")
        return tblRet
    end

    self.fund19_r = tbl.fund[2]
    self.nowDay19_r = tonumber(self.fund19_r.nowDay) 
    self.isActived19_r = (self.fund19_r.available ~= "0")
    self.fund19Rewards_r = processDays(self.fund19_r.days,self.nowDay19_r)
    self.dollar19_r = LuaController:call("getDollarString", "", self.fund19_r.gold)
    
    self.fund49_r = tbl.fund[3]
    self.nowDay49_r = tonumber(self.fund49_r.nowDay)
    self.isActived49_r = (self.fund49_r.available ~= "0")
    self.fund49Rewards_r = processDays(self.fund49_r.days,self.nowDay49_r)
    self.dollar49_r = LuaController:call("getDollarString", "", self.fund49_r.gold)
    
    if self:isNew99Open() and tbl.fund[4] then
        self.fund99_r = tbl.fund[4]
        self.nowDay99_r = tonumber(self.fund99_r.nowDay)
        self.isActived99_r = (self.fund99_r.available ~= "0")
        self.fund99Rewards_r = processDays(self.fund99_r.days,self.nowDay99_r)
        self.dollar99_r = LuaController:call("getDollarString", "", self.fund99_r.gold)
    end

    self.fund9_r = tbl.fund[1]
    self.nowDay9_r = tonumber(self.fund9_r.nowDay)
    self.isActived9_r = (self.fund9_r.available ~= "0")
    self.fund9Rewards_r = processDays(self.fund9_r.days,self.nowDay9_r)
    self.dollar9_r = LuaController:call("getDollarString", "", self.fund9_r.gold)
    
    self:updateCanGetRewardsTodayStatus()
    self:updateMonthFundRedPtCount()
    
    self.isMonthFundOpen = self.isActived19_r or self.isActived49_r or self.isActived99_r or self.isActived9_r
    if not CCCommonUtilsForLua:isFunOpenByKey("month_fund") then
        self.isMonthFundOpen = false
    end    

    if tbl.progressBoxInfo then
        self:parseLibaoBox(tbl.progressBoxInfo)
    end
    CCSafeNotificationCenter:postNotification(MonthFundAllRewardBackMsg)
end

function MonthFundController:getMonthFunRewardData( fundid )
    local function callbackFun( tbl )
        self:onGetMonthFundRewardData(tbl)
    end 
    local cmd = MonthFundGetRewardCmd.create(fundid)
    cmd.callbackFun = callbackFun
    cmd:send()
end

-- "goods" = {
--     1 = {
--         "id"  = "200065"
--         "num" = "1"
--     }
-- }
-- "rewardDay" = {
--     1 = {
--         "day"    = "1"
--         "fundId" = "9022502"
--     }
-- }
function MonthFundController:onGetMonthFundRewardData( tbl )
    if not tbl or not tbl.goods then
        return 
    end
    local arr = {}
    for k, v in pairs(tbl.goods) do
        local obj = {}
        obj.itemId = v.id
        obj.rewardAdd = v.num
        arr[k] =  obj
    end
    self.rewardsGot = luaTableToArray(arr) --展示的奖励

    local rewardDay = tbl.rewardDay
    if rewardDay and #rewardDay > 0 then
        for k,v in pairs(rewardDay) do 
            if self.fund19_r and self.fund19_r.id and self.fund19_r.id == v.fundId then
                self.fund19_r.days[tonumber(v.day)].receive = "1"
            elseif self.fund49_r and self.fund49_r.id and self.fund49_r.id == v.fundId then
                self.fund49_r.days[tonumber(v.day)].receive = "1"
            elseif self:isNew99Open() and self.fund99_r and self.fund99_r.id and self.fund99_r.id == v.fundId then
                self.fund99_r.days[tonumber(v.day)].receive = "1"
            elseif self.fund9_r and self.fund9_r.id and self.fund9_r.id == v.fundId then
                self.fund9_r.days[tonumber(v.day)].receive = "1"
            end
        end
    end
    self:updateCanGetRewardsTodayStatus()
    self:updateMonthFundRedPtCount()
    CCSafeNotificationCenter:postNotification(MonthFundGetRewardBackMsg)
end

function MonthFundController:isNew99Open()
    if CCCommonUtilsForLua:isFunOpenByKey("month_fund_progress_box") then
        return true
    end
end
----------------------------------

function MonthFundController:getRedDotCount(  )
    if not self:isNew99Open() then
        return 0 
    end
      if not  self:updateActStatus() then
         return 0
      end
      if not self.progressBoxInfo then
        
         return 0
      end
      
      --可领取礼包数量
      local count = 0
      for i, v in ipairs(self.progressBoxInfo) do
          if v.state == 1 then
            count = count + 1
          end
      end
      return count
end
function MonthFundController:postRedCount()
    if not self:isNew99Open() then
        return
    end
  
    local ctlType = self:getActControlType()
    local count = self:getRedDotCount()
    if count > 0 then
        require("game.RedDotMgr.KpiActRedDotMgr").getInstance(ctlType):addDot(self.m_actId,true)
    else
        require("game.RedDotMgr.KpiActRedDotMgr").getInstance(ctlType):removeDot(self.m_actId)
    end
end

function MonthFundController:reqGetGiftReward(index)
   
    utils.requestServer('monthfund.getProgressRward', {{"index",CCInteger:create(index)}}, nil, function ( tbl )
         if not table.isNilOrEmpty(tbl.rewardArray) then
            createTableFlyReward(tbl.rewardArray)
         end
         if  self.progressBoxInfo[index +1] then
            self.progressBoxInfo[index + 1].state = 2
         end
         CCSafeNotificationCenter:postNotification(MonthFundDataBackMsg)
         self:postRedCount()
    end )
end
function MonthFundController:sortLibao(tbl)
    table.sort(tbl,function(a,b)
        if a.page and b.page then
            return tonumber(a.page) <  tonumber(b.page) 
        end
    end)
    return true
end
return MonthFundController


