--modify by yanwei
local FestalActMakexxxCtl = require("game.FestivalActivities.FestivalActivitiesMakexxxController").getInstance()
local deltaPosY = 20
local originPosY = 35
------------------------------------------ ItemGetMethodCell Start --------------------------------------------
local ItemGetMethodCell = class("ItemGetMethodCell", function()
    return cc.Node:create()
end)

local ItemTypeInfo = nil

-- sourceType 跳转来源，1: 龙语界面跳转，
function ItemGetMethodCell:create(data, param, fromView, sourceType, parent_view)
    local ret = ItemGetMethodCell.new()
    if ret:init(data, param, fromView, sourceType, parent_view) == false then
        return nil
    end
    return ret
end

function ItemGetMethodCell:init(data, param, fromView, sourceType, parent_view)
    --初始化界面
    local proxy = cc.CCBProxy:create()
    local ccbiURL = ""
    ccbiURL = "ccbi/ItemGetMethodCell.ccbi"
    local nodeccb = CCBReaderLoad(ccbiURL, proxy, self)
    if nodeccb == nil then
        MyPrint("ItemGetMethodCell loadccb error")
        return false
    end
    
    self:setContentSize(nodeccb:getContentSize())
    self:addChild(nodeccb)
    registerNodeEventHandler(self)
    
    self.m_data = data
    self.m_itemId = data.id
    self.m_param = param
    self.m_fromView = fromView
    self.m_sourceType = sourceType
    self.parent_view = parent_view
    local pic = CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", self.m_itemId, "icon") .. ".png"
    self._spr = CCLoadSprite:call("createSprite", pic)
    local getType = tonumber(CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", self.m_itemId, "type"))
    
    local desc = CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", self.m_itemId, "desc")
    local t = string.split(desc, ";")
    local param0 = t[1]
    local param1 = t[2]
    local param2 = t[3]
    local param3 = t[4]
    self.m_titleTxt:setString(getLang(param0, param1, param2, param3))
    CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("164952"))
    
    --init diff
    local itemTypeInfo = ItemTypeInfo[getType]
    if itemTypeInfo and itemTypeInfo.init then
        itemTypeInfo.init(self)
    end
    
    CCCommonUtilsForLua:call("setSpriteMaxSize", self._spr, 80, true)
    self.m_picNode:removeAllChildren()
    self.m_picNode:addChild(self._spr)
    
    self:addHelpTime()
    
    if data.use_when_get then
        self:onClickGet()
    end
    return true
end

----------------initCell-----------------------
function ItemGetMethodCell:initDefault(...)
    -- body
    local itemId = CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", self.m_itemId, "para1")
    local toolInfo = ToolController:call("getToolInfoForLua", tonumber(itemId))
    if toolInfo == nil then
        self.m_titleTxt:setString("")
        MyPrint("HeroUseItemView getToolInfo fail with itemId "..tostring(self.m_itemId))
    else
        local count = toolInfo:call("getCNT")
        local desc = CCCommonUtilsForLua:call("getPropById", tostring(itemId), "name")--50体力
        self.m_titleTxt:setString(getLang(desc) .. "    x" .. count)
        CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("169631"))
        if count <= 0 then
            self.m_getBtn:setEnabled(false)
            self:removeBtnPar(self.m_getBtn)
        else
            self.m_getBtn:setEnabled(true)
            self:addBtnPar(self.m_getBtn)
        end
    end
end

function ItemGetMethodCell:initActivityView(...)
    -- body
    local actId = CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", self.m_itemId, "para1")
    local obj = ActivityController:call("getActObj", actId)
    if nil ~= obj then
        local fra = obj:getIconFrame()
        if fra then
            self._spr = cc.Sprite:createWithSpriteFrame(fra)
        end
    else
        local dypath = cc.FileUtils:getInstance():getWritablePath()
        local path1 = table.concat({dypath, "lua/", actId, "/resources/activity_", actId, "_new.plist"})
        if cc.FileUtils:getInstance():isFileExist(path1) then
            cc.SpriteFrameCache:getInstance():addSpriteFrames(path1)
        end
        local pic = CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", self.m_itemId, "icon") .. ".png"
        self._spr = CCLoadSprite:call("createSprite", pic)
    end

    if obj then
        CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("164952")) -- 164952=前往
        self.m_getBtn:setEnabled(true)
    else
        CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("101465")) -- 101465=未开启
        self.m_getBtn:setEnabled(false)
    end
end

function ItemGetMethodCell:initJumpToRepay(...)
    -- body
    require("game.LiBao.Repay.RepayController")
    if RepayController.getInstance():isBegin() then
        CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("164952")) -- 164952=前往
        self.m_getBtn:setEnabled(true)
    else
        CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("101465")) -- 101465=未开启
        self.m_getBtn:setEnabled(false)
    end
end

function ItemGetMethodCell:initHeroRecruitActivity(...)
    -- body
    local heroName = CCCommonUtilsForLua:getPropById(self.m_param, "title")
    self.m_titleTxt:setString(getLang(param0, param1, param2, param3) .. ":" .. getLang(heroName))
    self.txt_timeDesc:setString(getLang("103073"))-- 103073=敬请期待
    -- endTime
    self.m_countEndTime = 0
    local xmlData = CCCommonUtilsForLua:getGroupByKey("general_draw")
    if xmlData then
        local endTime = 0
        for k, v in pairs(xmlData) do
            if v.activity_type and v.activity_type == "1" and tonumber(v.item_id) == tonumber(self.m_param) then
                endTime = tonumber(v.end_time)
                break
            end
        end
        if endTime > 0 then -- 倒计时
            self.m_countEndTime = endTime / 1000
        end
    end
    self:addCountDownUpdater(true)
end

function ItemGetMethodCell:initAllianceBoss(...)
    -- body
    if CCCommonUtilsForLua:isFunOpenByKey("allianceboss_open") then
        CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("164952")) -- 164952=前往
        self.m_getBtn:setEnabled(true)
    else
        CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("101465")) -- 101465=未开启
        self.m_getBtn:setEnabled(false)
    end
end

function ItemGetMethodCell:initTournamentAddNum(...)
    -- body
    CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("102137"))
    local isEnable = TournamentControllerInst:hasEnoughAddItem(1)
    self.m_getBtn:setEnabled(isEnable)
end

function ItemGetMethodCell:initNationalWarResource(...)
    -- body
    self.m_picNode:setScale(0.5)
    if CCCommonUtilsForLua:isFunOpenByKey("ek_war_main") then
        CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("164952")) -- 164952=前往
        self.m_getBtn:setEnabled(true)
    else
        CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("101465")) -- 101465=未开启
        self.m_getBtn:setEnabled(false)
    end
end

function ItemGetMethodCell:initMateCreate(...)
    -- body
    CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("164952")) -- 164952=前往
    self.m_getBtn:setEnabled(true)
end
---------------------initCell end-----------------------

function ItemGetMethodCell:addBtnPar(btn)
    local tmpStart = "ShowFire_"
    local tmpStart1 = "ShowFireUp_"
    local s9 = CCLoadSprite:call("createScale9Sprite", "sel_general.png")

    local size = btn:getPreferredSize()
    s9:setPreferredSize(CCSize(30 + size.width, 30 + size.height))
    s9:setPosition(CCSize(size.width / 2, size.height / 2))
    s9:setAnchorPoint(ccp(0.05, 0.15))
    s9:setTag(8000)
    btn:addChild(s9)
    for i = 1, 5 do
        local particle = ParticleController:call("createParticle", tmpStart .. i, CCPointZero, size.width * 0.3)
        particle:setPosition(ccp(size.width / 2, -3))
        particle:setPosVar(ccp(size.width / 2, 0))
        particle:setTag(8000 + i * 10 + 1)
        btn:addChild(particle)
        
        local particle1 = ParticleController:call("createParticle", tmpStart .. i, CCPointZero, size.width * 0.3)
        particle1:setPosition(ccp(size.width / 2, size.height - 3))
        particle1:setPosVar(ccp(size.width / 2, 0))
        particle1:setTag(8000 + i * 10 + 2)
        btn:addChild(particle1)
        
        local particle2 = ParticleController:call("createParticle", tmpStart1 .. i, CCPointZero, size.height * 0.3)
        particle2:setPosition(ccp(0, size.height / 2))
        particle2:setPosVar(ccp(0, size.height / 2))
        particle2:setTag(8000 + i * 10 + 3)
        btn:addChild(particle2)
        
        local particle3 = ParticleController:call("createParticle", tmpStart1 .. i, CCPointZero, size.height * 0.3)
        particle3:setPosition(ccp(size.width, size.height / 2))
        particle3:setPosVar(ccp(0, size.height / 2))
        particle3:setTag(8000 + i * 10 + 4)
        btn:addChild(particle3)
    end
end

function ItemGetMethodCell:removeBtnPar(btn)
    local nodeBg = btn:getChildByTag(8000)
    if nodeBg then
        btn:removeChild(nodeBg, true)
    end
    
    for i = 1, 5 do
        for j = 1, 4 do
            local node = btn:getChildByTag(8000 + i * 10 + j)
            if node then
                btn:removeChild(node, true)
            end
        end
    end
end

function ItemGetMethodCell:updateHelpTime(dt)
    if self:isHelpItem() then
        if self:isCanReqHelp() then
            self:addHelpTimeUpdater(false)
            self.nodeHelpTime:setVisible(false)
            CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("4249715"))
        else
            if not self.nodeHelpTime:isVisible() then
                self.nodeHelpTime:setVisible(true)
                CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, "")
            end
            local lastReqHelpTime = cc.UserDefault:getInstance():getIntegerForKey(gtblTimeoutKey.makeXXXReqHelp, 0)
            local worldTime = getWorldTime()
            local difTime = worldTime - lastReqHelpTime
            self.m_timeLabel:setString(format_time(FestalActMakexxxCtl.minReqHelpIntervalTime - difTime))
        end
    end
end

function ItemGetMethodCell:addCountDownUpdater(flag)
    Dprint("addCountDownUpdater ", flag, self.m_countEndTime)
    if self.m_entryCountDownId then
        self:getScheduler():unscheduleScriptEntry(self.m_entryCountDownId)
        self.m_entryCountDownId = nil
    end
    if not flag then
        self.m_countEndTime = 0
    end
    local difTime = self.m_countEndTime - getTimeStamp()
    if difTime > 0 then -- 倒计时
        self.node_updateCountDown:setVisible(true)
        self.m_titleTxt:setPositionY(self.m_titleTxt:getPositionY() + deltaPosY)
        self.m_entryCountDownId = self:getScheduler():scheduleScriptFunc(function(dt) self:updateCountDown(dt) end, 1.0, false)
    end
    self:updateCountDown(0)
end

function ItemGetMethodCell:updateCountDown(dt)
    local difTime = self.m_countEndTime - getTimeStamp()
    Dprint("updateCountDown difTime", difTime, format_time(difTime))
    if difTime > 0 then -- 倒计时
        self.txt_timeCountDown:setString(format_time(difTime))
    else
        self.txt_timeDesc:setVisible(true)
        self.m_getBtn:setVisible(false)
        self.node_updateCountDown:setVisible(false)
        self.m_titleTxt:setPositionY(originPosY)
    end
end

function ItemGetMethodCell:isCanReqHelp()
    return getTimeoutForKey(gtblTimeoutKey.makeXXXReqHelp, FestalActMakexxxCtl.minReqHelpIntervalTime)
end

function ItemGetMethodCell:onEnter()
    if self:isHelpItem() then
        if self:isCanReqHelp() then
            self:addHelpTimeUpdater(false)
            CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("4249715"))
        else
            CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, "")
            self:addHelpTimeUpdater(true)
        end
    end
end

function ItemGetMethodCell:onExit()
    self:addHelpTimeUpdater(false)
    self:addCountDownUpdater(false)
end

function ItemGetMethodCell:addHelpTimeUpdater(bAdd)
    if self.m_entryId then
        self:getScheduler():unscheduleScriptEntry(self.m_entryId)
        self.m_entryId = nil
    end
    if bAdd then
        self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:updateHelpTime(dt) end, 1.0, false)
        self:updateHelpTime()
    end
end

function ItemGetMethodCell:addHelpTime()
    if self:isHelpItem() then
        if self.nodeHelpTime then
            self.nodeHelpTime:removeAllChildren()
        else
            self.nodeHelpTime = cc.Node:create()
            self.m_getBtn:addChild(self.nodeHelpTime)
            local size = self.m_getBtn:getContentSize()
            self.nodeHelpTime:setPosition(size.width / 2, size.height / 2)
        end
        local label = cc.Label:createWithSystemFont(itmeName, "Helvetica", 22, cc.size(0.0, 0))
        self.nodeHelpTime:addChild(label)
        self.m_timeLabel = label
    end
end

--活动中的“求助”
function ItemGetMethodCell:isHelpItem()
    local info = ItemTypeInfo[self.m_data.type]
    return info and info[self.m_data.type].isHelpItem and (self.m_data.para1 == "208")
end

function ItemGetMethodCell:onClickGet()
    local flag = PopupViewController:call("isLastLevel4PopupView")
    self:onClickGetExtra()
    -- 当前弹出框为半屏幕弹出框
    -- 最后打开的弹出框为全屏弹出框
    if flag and (not PopupViewController:call("isLastLevel4PopupView")) then
        -- 移除所有半屏弹出框
        PopupViewController:call("removeLevel4PopupView")
    end
end

--main: 0, 1
--sub: 1,2,3,4,5
function ItemGetMethodCell:openBagViewEx(main, sub)
    MyPrint(main, sub, self.m_itemId, "main,sub+++")
    main = main or 0
    sub = sub or 5
    LuaController:call("openBagView", main)
    local para1 = CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", self.m_itemId, "para1")
    dump(para1, "para1+++")
    if para1 and para1 ~= "" then
        sub = para1
    end
    MyPrint(self.m_data.itemIdWanted, para1, "itemIdWanted+++")
    local dict = CCDictionary:create()
    dict:setObject(CCString:create(tostring(main)), 'main')
    dict:setObject(CCString:create(tostring(sub)), 'sub')
    dict:setObject(CCString:create(self.m_data.itemIdWanted), 'highLightItem')
    CCSafeNotificationCenter:postNotification("MSG_CHANGE_BAG_VIEW", dict)
end

function ItemGetMethodCell:onClickGetExtra()
    MyPrint("ItemGetMethodCell:onClickGet ", self.m_itemId)
    local getType = tonumber(CCCommonUtilsForLua:call("getPropById", self.m_itemId, "type"))
    --执行跳转逻辑
    local itemTpeInfo = ItemTypeInfo[getType]
    if itemTpeInfo then
        itemTpeInfo.call(self)
    end
    --打点
    if self.m_sourceType and tostring(self.m_sourceType) ~= "" then
        local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
        local uid = playerInfo:getProperty("uid")
        
    end
    
end

function ItemGetMethodCell:popViewByName(popViewName, beCloseSelf)
    -- body
    if popViewName ~= "" then
        if beCloseSelf then
            self.parent_view:closeSelf()
        else
            if self.m_fromView == "DragonInfo_New" then
                PopupViewController:call("removeLastPopupView")
            else
                PopupViewController:call("removeAllPopupView")
            end
        end
        local dict = CCDictionary:create()
        dict:setObject(CCString:create(popViewName), "name")
        LuaController:call("openPopViewInLua", dict)
    end
end

-------------------------跳转函数--------------------------------

function ItemGetMethodCell:onDefault(...)
    -- body
    local itemId = tonumber(CCCommonUtilsForLua:call("getPropById", tostring(self.m_itemId), "para1"))
    if itemId == 200380 or itemId == 213739 then
        local dict = CCDictionary:create()
        dict:setObject(CCString:create("ToolNumSelectView"), "name")
        dict:setObject(CCString:create(tostring(itemId)), "itemId")
        dict:setObject(CCString:create(tostring(0)), "opFrom")
        dict:setObject(CCString:create(""), "targetId")
        LuaController:call("openPopViewInLua", dict)
    else
        ToolController:call("useTool", itemId, 1, true, false)
    end
    return true
end

function ItemGetMethodCell:onGoldExchange(...)
    -- body
    local popViewName = "GoldExchangeView_NEW";
    self:popViewByName(popViewName, false);
    return true
end

function ItemGetMethodCell:onDragonTower(...)
    -- body
    local buildId = FunBuildController:call("getMaxLvBuildByType", 432000)
    if buildId == 0 then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("169042"))
        return false
    end
    
    PopupViewController:call("removeAllPopupView")
    FunBuildController:call("moveToBuildByBuildType", 432000)
    return true
end

function ItemGetMethodCell:onActivity(...)
    -- body
    PopupViewController:call("removeAllPopupView")
    ActivityController:call("openActivityView")
    return true
end

function ItemGetMethodCell:onMerchant(...)
    -- body
    local mainCityLv = FunBuildController:call("getMainCityLv")
    if mainCityLv < 6 then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("169042"))
        return false
    end
    local popViewName = "MerchantView"
    self:popViewByName(popViewName, false);
    return true
end

function ItemGetMethodCell:onStore(...)
    -- body
    self.parent_view:closeSelf()
    -- PopupViewController:call("removeAllPopupView")
    -- LuaController:call("openBagView", 1)
    self:openBagViewEx(1, nil)
    return false
end

function ItemGetMethodCell:onDragonExplore(...)
    -- body
    if CCCommonUtilsForLua:isFunOpenByKey("dragon_lua") then
        PopupViewController:call("removeAllPopupView")
        local dragonInfo = DragonController:call("getActiveDragonInfo")
        if dragonInfo == nil then
            return false
        end
        if CCCommonUtilsForLua:isFunOpenByKey("dragon_new_ui_switch") then
            local view = Drequire("game.NewDragon.NewDragon_V2.DragonListNewView"):create()
            PopupViewController:call("addPopupInView", view)
            if nil ~= view then
                view:openDragonViewByUuid(dragonInfo:call("getUuid"), dragonInfo:call("getBaseId"))
            end
        else
            local DragonCave_New = Drequire("game.NewDragon.DragonCave_New")
            local view = DragonCave_New:create({uuid = dragonInfo:call("getUuid")})
            PopupViewController:call("addPopupInView", view)
        end
        return false
    else
        local popViewName = "DragonIntimacyView"
        self:popViewByName(popViewName, false);
    end
    return true
end

function ItemGetMethodCell:onHeroBuyFragment(...)
    -- body
    MyPrint("self.m_param ", self.m_param)
    -- 参数有两种类型
    -- 1.纯数值 heroId
    -- 2.表结构 {heroId, needNum}
    local param1 = nil
    local param2 = nil
    if type(self.m_param) == "table" then
        param1 = self.m_param.heroId
        param2 = self.m_param.needNum
    else
        param1 = self.m_param
    end
    PopupViewController:call("removeLastPopupView")
    package.loaded["game.hero.HeroBuyFragmentView"] = nil
    local HeroBuyFragmentView = require("game.hero.HeroBuyFragmentView")
    local useItemView = HeroBuyFragmentView:create(param1, param2)
    PopupViewController:addPopupInView(useItemView)
    
    return true
end

function ItemGetMethodCell:onJumpToBuild(...)
    -- body
    local data = self.m_data
    PopupViewController:call("removeAllPopupView")
    local speBuild = false
    if data.para2 == "1" then
        speBuild = true
    end
    FunBuildController:call("moveToBuildByBuildType", tonumber(data.para1), speBuild)
    
    return true
end

function ItemGetMethodCell:onOpenDailyActivity(...)
    -- body
    PopupViewController:call("removeAllPopupView")
    if CCCommonUtilsForLua:isFunOpenByKey("new_daily_active_switch") then
        local view = Drequire("game.NewDailyActive.NewDailyActiveFrameView"):create()
        PopupViewController:addPopupInView(view)
    else
        local view = Drequire("game.Tavern.DailyActiveView"):create()
        PopupViewController:addPopupInView(view)
    end
    return true
end

function ItemGetMethodCell:onJumpToWorld(...)
    -- body
    local itemId = self.itemId
    
    local function findBuild()
        local buildType = CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", tostring(itemId), "para1")
        if buildType and buildType ~= "" then
            local level = CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", tostring(itemId), "para2")
            if not level or level == "" then
                local key = "FindResTile_";
                key = key..CC_ITOA(buildType);
                level = cc.UserDefault:getInstance():getIntegerForKey(key, 1);
            end
            local cmd = Drequire("game.command.IFFindResTileCmd").create(tonumber(buildType), tonumber(level or 1))
            cmd:send()
        end
    end
    
    PopupViewController:call("removeAllPopupView")
    -- 世界
    if SceneController:call("getCurrentSceneId") ~= 11 then
        require("game.CommonPopup.CommonEventController"):once("msgSceneChangeFinish", function ()
            if SceneController:call("getCurrentSceneId") == 11 then
                findBuild()
            end
        end)
        SceneController:call("gotoScene", 11)
    else
        findBuild()
    end
    return true
end

function ItemGetMethodCell:onOpenHeroTowerHomeView(...)
    -- body
    if CCCommonUtilsForLua.isHeroChallengeOpen() then
        local popViewName = "HeroTowerHomeView"
        self:popViewByName(popViewName, false);
    else
        -- 169042=该功能暂未开启，敬请期待
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("169042"))
    end
    return true
end

function ItemGetMethodCell:onDragonBag(...)
    -- body
    if CCCommonUtilsForLua:call("isFunOpenByKey", "dragon_friendship") then
        PopupViewController:call("removeLastPopupView")
        local popViewName = "DragonBagView"
        self:popViewByName(popViewName, false);
    else
        -- 169042=该功能暂未开启，敬请期待
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("169042"))
    end
    return true
end

function ItemGetMethodCell:onAllianceTreasure(...)
    -- body
    if CCCommonUtilsForLua:call("isKuaFu") then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("102531"))
        return false
    end
    
    local mycitylv = FunBuildController:call("getMainCityLv")
    local limit = AllianceDailyController:call("getInstance"):getProperty("conditionPublishLevel")
    if limit and mycitylv < limit then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("134068", tostring(limit)))
        return
    end
    local beCloseSelf = true
    local popViewName = "AllianceDailyPublishView"
    self:popViewByName(popViewName, beCloseSelf);
    return true
end

function ItemGetMethodCell:onAllianceQuest(...)
    -- body
    local beCloseSelf = true
    local popViewName = "AllianceQuestView"
    self:popViewByName(popViewName, beCloseSelf);
    return true
end

function ItemGetMethodCell:onStoreBagView(...)
    -- body
    -- PopupViewController:call("removeAllPopupView")
    local beCloseSelf = true
    -- LuaController:call("openBagView", 0)
    self:openBagViewEx(0, nil)
    return true
end

function ItemGetMethodCell:onActivityView(...)
    -- body
    local actId = CCCommonUtilsForLua:call("getPropById", tostring(self.m_itemId), "para1")
    local obj = ActivityController:call("getActObj", actId)
    if nil == obj then
        -- 176074=活动暂未开启
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("176074"))
    else
        local beCloseSelf = true
        -- PopupViewController:call("removeAllPopupView")
        -- ActivityController:call("shouActUIById", actId)
        ActivityController.getInstance():shouActUIById(actId)
    end
    return true
end

function ItemGetMethodCell:onAllianceShop(...)
    -- body
    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
    local hasAlliance = playerInfo:call("isInAlliance")
    if hasAlliance then
        local beCloseSelf = true;
        local popViewName = "AllianceShopView"
        self:popViewByName(popViewName, beCloseSelf);
    else
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("132360"))
    end
    return true
end

function ItemGetMethodCell:onKingdomLiBao(...)
    -- body
    PopupViewController:call("removeAllPopupView")
    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
    local serverId = playerInfo:getProperty("selfServerId")
    local dict = CCDictionary:create()
    dict:setObject(CCString:create("KingsGiftView"), "name")
    dict:setObject(CCString:create(tostring(serverId)), "serverId")
    LuaController:call("openPopViewInLua", dict)
    return false
end

function ItemGetMethodCell:onHeroGetRolate(...)
    -- body
    if CCCommonUtilsForLua:isFunOpenByKey("hero_roulette") then
        PopupViewController:call("removeAllPopupView")
        local prlvPath = "game.hero.NewUI.HeroGetRotateView"
        local view = Drequire(prlvPath)
        PopupViewController:call("addPopupInView", view:create("89699", "hero_type"))
    end
    return true
end

function ItemGetMethodCell:onCivPrestage(...)
    -- body
    PopupViewController:call("removeAllPopupView")
    local CivilizationDonateView = Drequire("game.civilization.prestige.CivilizationDonateView")
    local view = CivilizationDonateView:create()
    PopupViewController:addPopupInView(view, true)
    return false
end

function ItemGetMethodCell:onCivShop(...)
    -- body
    PopupViewController:call("removeAllPopupView")
    local view = myRequire("game.civilization.prestige.CivilizationShopView").create()
    PopupViewController:addPopupInView(view)
    return false
end

function ItemGetMethodCell:onHeroRecruit(...)
    -- body
    -- PopupViewController:call("removeAllPopupView")
    self.parent_view:closeSelf()
    CCCommonUtilsForLua.jumpToTarget( 7, "25" )
    return false
end

function ItemGetMethodCell:onShuiJingBox(...)
    -- body
    -- dump("hanxiao12345 in open ShuiJingBox")
    
    local dict = CCDictionary:create()
    dict:setObject(CCString:create(USE_TOOL_SHUIJING), "type")
    dict:setObject(CCString:create("138523"), "title")
    CCSafeNotificationCenter:call("postNotification", "ItemGetMethodView_closeself")
    local view = Drequire("game.CommonPopup.UseToolView"):create(USE_TOOL_SHUIJING, dict, "138523")
    PopupViewController:addPopupInView(view)
    return false
end

-- 跳转暗水晶宝箱使用界面
function ItemGetMethodCell:onAnShuiJingBox(...)
    local dict = CCDictionary:create()
    dict:setObject(CCString:create(USE_TOOL_ANSHUIJING), "type")
    dict:setObject(CCString:create("138523"), "title")
    CCSafeNotificationCenter:call("postNotification", "ItemGetMethodView_closeself")
    local view = Drequire("game.CommonPopup.UseToolView"):create(USE_TOOL_ANSHUIJING, dict, "138523")
    PopupViewController:addPopupInView(view)
    return false
end

function ItemGetMethodCell:onItemExchange(...)
    -- body
    local lua_path = "game.store.BagExchangeView"
    package.loaded[lua_path] = nil
    require(lua_path)
    local itemId = CCCommonUtilsForLua:call("getPropById", self.m_itemId, "para1")
    MyPrint("go to more for itemid = ", itemId, "and self = ", self.parent_view)
    local view = BagExchangeView:create(itemId)
    if view == nil then
        MyPrint("BagExchangeView is nil ")
    end
    PopupViewController:addPopupInView(view)
    PopupViewController:call("removePopupView", self.parent_view)
    PopupViewController:call("removePopupView", self.m_fromView)
    return false
end

function ItemGetMethodCell:onTreasureShop(...)
    -- body
    if CCCommonUtilsForLua:isFunOpenByKey("treasure_fam_on_1") then
        CCSafeNotificationCenter:call("postNotification", "ItemGetMethodView_closeself")
        TreasureFamManager:getTreasureFamInfo()
        local view = Drequire("game.TreasureFam.TreasureFamShopView"):create()
        PopupViewController:addPopupInView(view)
    else
        LuaController:flyHint("", "", getLang("E100008"))
    end
    return false
end

function ItemGetMethodCell:onAuctionHouse(...)
    -- body
    if not CCCommonUtilsForLua:isFunOpenByKey("auction") then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("169042")) --活动未开启
        return false
    end
    local cross = GlobalData:call("getPlayerInfo"):getProperty("crossFightSrcServerId")
    if cross and cross ~= -1 then
        if cross then dump(cross, "cross+++") end
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("9440926")) --跨服状态,不能开启拍卖行
        return false
    end
    --先获取数据，活动不开启，inActivity=0
    CCSafeNotificationCenter:call("postNotification", "ItemGetMethodView_closeself")
    AuctionHouseController:pullAuctionHouseViewData()
    return false
end

function ItemGetMethodCell:onMagicDrawView(...)
    -- body
    CCSafeNotificationCenter:call("postNotification", "ItemGetMethodView_closeself")
    if CCCommonUtilsForLua:isFunOpenByKey("magic_skill") then
        local poolIndex = atoi(CCCommonUtilsForLua:call("getPropById", tostring(self.m_itemId), "para1"))
        local cardIndex = atoi(CCCommonUtilsForLua:call("getPropById", tostring(self.m_itemId), "para2"))
        local view = Drequire("game.magic.LuckDraw.MagicLuckDrawView"):create(cardIndex, poolIndex)
        PopupViewController:call("addPopupInView", view)
    end
    return false
end

function ItemGetMethodCell:onMakexxxReqHelp(...)
    -- body
    if self:isHelpItem() then
        if self:isCanReqHelp() then
            self:addHelpTimeUpdater(false)
            setTimeoutForKey(gtblTimeoutKey.makeXXXReqHelp, false)
            self.parent_view:closeSelf()
            CCSafeNotificationCenter:call("postNotification", MSG_MAKE_XXX_REQ_HELP)
            LuaController:flyHint("", "", getLang("4249724")) -- 4249724=求助成功，在联盟聊天中查看
        else
            LuaController:flyHint("", "", getLang("4249726"))
        end
    end
    return true
end

function ItemGetMethodCell:onJumpToWorldResource(...)
    -- body
    PopupViewController:call("removeAllPopupView")
    if self.m_param == nil then
        self.m_param = {}
    end
    local cmd = Drequire("game.command.IFFindResTileCmd").create(self.m_param.buildType or 9, self.m_param.level or 1)
    cmd:send()
    return false
end

function ItemGetMethodCell:onJumpToForge(...)
    -- body
    local vipView = Drequire("game.equipment.NewEquip.NewEquipMainView"):create()
    PopupViewController:addPopupInView(vipView)
    return true
end

function ItemGetMethodCell:onCrystalRoulette(...)
    -- body
    local view = Drequire("game.hero.NewUI.HeroGetRotateView"):create("89698", "crystal_type")
    PopupViewController:call("addPopupInView", view)
    self.parent_view:closeSelf()
    return true
end

function ItemGetMethodCell:onJumpToRepay(...)
    -- body
    require("game.LiBao.Repay.RepayController")
    if RepayController.getInstance():isBegin() then
        RepayController.getInstance():fireEvent("RepayViewCreate")
        self.parent_view:closeSelf()
    end
    return true
end

function ItemGetMethodCell:onHeroRecruitActivity(...)
    -- body
    -- PopupViewController:call("removeAllPopupView")
    self.parent_view:closeSelf()
    local view = Drequire("game.hero.LuckDraw.HeroLuckDrawView").create()
    PopupViewController:addPopupInView(view)
    return false
end

function ItemGetMethodCell:onAllianceBoss(...)
    -- body
    PopupViewController:call("addPopupInView", myRequire("game.allianceBoss.AllianceBossView").create())
    self.parent_view:closeSelf()
    return true
end

function ItemGetMethodCell:onAvatarStoreFragment(...)
    -- body
    PopupViewController:call("removeAllPopupView")
    local AvatarViewEx = Drequire("game.avatar.AvatarViewEx")
    local view = AvatarViewEx.create(AvatarType_MysteryPiece)
    PopupViewController:call("addPopupInView", view)
    self.parent_view:closeSelf()
    return true
end

function ItemGetMethodCell:onAvatarStoreDiamond(...)
    -- body
    PopupViewController:call("removeAllPopupView")
    local AvatarViewEx = Drequire("game.avatar.AvatarViewEx")
    local view = AvatarViewEx.create(AvatarType_Diamond)
    PopupViewController:call("addPopupInView", view)
    self.parent_view:closeSelf()
    return true
end

function ItemGetMethodCell:onTournamentAddNum(...)
    -- body
    TournamentControllerInst:requestAddFightNum()
    return true
end

function ItemGetMethodCell:onNationalWarResource(...)
    -- body
    PopupViewController:call("removeAllPopupView")
    local view = Drequire("game.NationalWar.NationalWarMainView"):create()
    PopupViewController:call("addPopupInView", view)
    self.parent_view:closeSelf()
    return true
end

function ItemGetMethodCell:onMateCreate(...)
    -- body
    local info = ToolController:call("getToolInfoByIdForLua", tonumber(self.m_data.itemIdWanted))
    local color = atoi(info:getProperty("color"))
    local realItemId = 0
    if color > 0 then -- 0 = WHITE
        realItemId = self.m_data.itemIdWanted - 1
    else
        realItemId = self.m_data.itemIdWanted
    end
    
    local dict = CCDictionary:create()
    dict:setObject(CCString:create("MateCreateView"), "name")
    dict:setObject(CCString:create(tostring(realItemId)), "itemId")
    dict:setObject(CCString:create("0"), "type")
    dict:setObject(CCString:create("0"), "count")
    dict:setObject(CCString:create("0"), "nextCount")
    LuaController:call("openPopViewInLua", dict)
    return true
end

function ItemGetMethodCell:onKingBiographyRoulette(...)
    -- body
    require("game.activity.KingBiography.KingBiographyController").createKingBiographyRotate()
    return true
end

function ItemGetMethodCell:onKingBiographyView(...)
    -- body
    require("game.activity.KingBiography.KingBiographyController").createKingBiographyView()
    return true
end

function ItemGetMethodCell:onFestivalMainView(...)
    local festivalId = CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", self.m_itemId, "para1")
    local actId = CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", self.m_itemId, "para2")
    local festivalCtl = require("game.FestivalActivities.FestivalActivitiesController").getInstance()
    if festivalCtl:isFestivalActivityOpenById(festivalId,actId) then
        PopupViewController:call("removeAllPopupView")        
        require("game.FestivalActivities.FestivalActivitiesHelper").openFestivalView(festivalId, actId)
    else
        LuaController:flyHint("", "", getLang("10200044"))
    end
    return true
end

function ItemGetMethodCell:onDarkCivView( ... )
    -- 跳转到名城列表
    local view = Drequire("game.darkCivilization.DarkCivListView"):create(0)
    PopupViewController:call("addPopupView", view)
    self.parent_view:closeSelf()
end

function ItemGetMethodCell:onFTBagView( ... )
    -- 跳转阵法仓库
    PopupViewController:call("removeAllPopupView")
    FormationTrainCtr:getInstance():jumpView('bag')

end

function ItemGetMethodCell:onTheHeavensView( ... )
    -- 跳转天空之境
    PopupViewController:call("removeAllPopupView")
    local view = Drequire("game.TheHeavens.TheHeavensMainView"):create()
    PopupViewController:addPopupInView(view)

end

function ItemGetMethodCell:onTreasureMapActView()
    if CCCommonUtilsForLua:isFunOpenByKey("night_market") then
        if isCrossServerNow() then
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("137705"))
            return
        end

        CCLoadSprite:call("loadDynamicResourceByName", "TreasureMap_face")
        local view = Drequire("game.FestivalActivities.TreasureMap.TreasureMapActView"):create()
        if view then
            PopupViewController:addPopupInView(view)
        end
    end
end

function ItemGetMethodCell:onSoldierRankView()
    if CCCommonUtilsForLua:isFunOpenByKey("soldier_theme_rank") then
        CCLoadSprite:call("loadDynamicResourceByName", "armament_face")
        local view = Drequire("game.soldier.soldierRank.SoldierRankView"):create()
        if view then
            PopupViewController:addPopupInView(view)
        end
    end
end

function ItemGetMethodCell:onAllStore()
    local view = Drequire("game.shop.AllStoreView"):create()
    if view then 
        local para1 = CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", self.m_itemId, "para1")
        view:setCurrentPage(tostring(para1))
        PopupViewController:addPopupInView(view)
    end
end

function ItemGetMethodCell:onFTAuction()
    -- 阵法拍卖行
    PopupViewController:call("removeAllPopupView")
    local para1 = tonumber(self.m_data.para1) or 1 
    local view = Drequire('game.formationTrain.auction.FTAuctionView'):create()
    PopupViewController:addPopupInView(view)
    gNotifierCenter:trigger(Events.FTAuctionJumpAuctionAll, para1)
end

function ItemGetMethodCell:onFTView()
    -- 阵法页面
    PopupViewController:call("removeAllPopupView")
    local para1 = self.m_data.para1 or 'main'
    FormationTrainCtr:getInstance():jumpView(para1)
end

function ItemGetMethodCell:onDigView()
    -- 宝石挖掘
    PopupViewController:call("removeAllPopupView")
    CCCommonUtilsForLua.jumpToTarget(7, '65')
end

function ItemGetMethodCell:onAlliance(...)
    self.parent_view:closeSelf()
    local dict = CCDictionary:create()
    dict:setObject(CCString:create("AllianceInfoView"), "name")
    dict:setObject(CCString:create("true"), "bRef")
    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
    local allianceInfo = playerInfo:getProperty("allianceInfo")	
    dict:setObject(allianceInfo,"info")
    LuaController:call("openPopViewInLua", dict) 
    return true
end

function ItemGetMethodCell:onAllianceDonate(...)
    -- 联盟捐献
    local beCloseSelf = true
    local popViewName = "AllianceScienceView"
    self:popViewByName(popViewName, beCloseSelf);
    return true
end

function ItemGetMethodCell:onGoodsExchange(...)
    local view = Drequire("game.CommonPopup.GoodsExchangeView"):create(self.m_data.itemIdWanted)
    PopupViewController:call("addPopupView", view)
    return true
end


--初始化方法和跳转方法的配置
--[[
tpe:cell类型
call:跳转方法
init:不同类型的cell初始化
]]
ItemTypeInfo = {
    [0] = {tpe = 0, call = ItemGetMethodCell.onDefault, init = ItemGetMethodCell.initDefault}, --默认没取到时的处理
    [1] = {tpe = 1, call = ItemGetMethodCell.onGoldExchange}, --礼包
    [2] = {tpe = 2, call = ItemGetMethodCell.onDragonTower}, --龙塔
    [3] = {tpe = 3, call = ItemGetMethodCell.onActivity}, --活动中心
    [4] = {tpe = 4, call = ItemGetMethodCell.onMerchant}, --旅行商人
    [5] = {tpe = 5, call = ItemGetMethodCell.onStore}, --商城
    [6] = {tpe = 6, call = ItemGetMethodCell.onDragonExplore}, --龙游历
    [7] = {tpe = 7, call = ItemGetMethodCell.onHeroBuyFragment}, -- 英雄碎片购买
    [8] = {tpe = 8, call = ItemGetMethodCell.onJumpToBuild}, -- 跳转建筑物
    [9] = {tpe = 9, call = ItemGetMethodCell.onOpenDailyActivity}, -- 打开日常任务界面
    [10] = {tpe = 10, call = ItemGetMethodCell.onJumpToWorld}, -- 跳转世界
    [11] = {tpe = 11, call = ItemGetMethodCell.onOpenHeroTowerHomeView}, -- 龙试炼界面
    [12] = {tpe = 12, call = ItemGetMethodCell.onDragonBag}, -- 龙背包
    [13] = {tpe = 13, call = ItemGetMethodCell.onAllianceTreasure}, -- 联盟宝藏
    [14] = {tpe = 14, call = ItemGetMethodCell.onAllianceQuest}, -- 联盟任务
    [15] = {tpe = 15, call = ItemGetMethodCell.onStoreBagView}, -- 背包
    [16] = {tpe = 16, call = ItemGetMethodCell.onActivityView, init = ItemGetMethodCell.initActivityView}, -- 打开活动界面
    [17] = {tpe = 17, call = ItemGetMethodCell.onAllianceShop},
    [18] = {tpe = 18, call = ItemGetMethodCell.onKingdomLiBao}, --国王礼包
    [19] = {tpe = 19, call = ItemGetMethodCell.onHeroGetRolate, beHeroRoulette = true}, -- 英雄转盘
    [20] = {tpe = 20, call = ItemGetMethodCell.onCivPrestage}, -- 文明声望
    [21] = {tpe = 21, call = ItemGetMethodCell.onCivShop},
    [22] = {tpe = 22, call = ItemGetMethodCell.onHeroRecruit}, --英雄招募
    [23] = {tpe = 23, call = ItemGetMethodCell.onShuiJingBox}, --水晶宝箱
    [24] = {tpe = 24, call = ItemGetMethodCell.onItemExchange}, -- 道具兑换
    [25] = {tpe = 25, call = ItemGetMethodCell.onTreasureShop}, --秘境商店
    [26] = {tpe = 26, call = ItemGetMethodCell.onAuctionHouse}, --拍卖行
    [27] = {tpe = 27, call = ItemGetMethodCell.onMagicDrawView}, --魔法屋
    [28] = {tpe = 28, call = ItemGetMethodCell.onMakexxxReqHelp, isHelpItem = true}, --活动中的制作xxx“求助”
    [29] = {tpe = 29, call = ItemGetMethodCell.onJumpToWorldResource}, -- 查找世界资源点 走IFFindResTileCmd消息，默认为查找世界上奇迹资源，其余为自带参数
    [30] = {tpe = 30, call = ItemGetMethodCell.onJumpToForge}, -- 装备锻造
    [31] = {tpe = 31, call = ItemGetMethodCell.onCrystalRoulette}, -- 水晶转盘
    [32] = {tpe = 32, call = ItemGetMethodCell.onJumpToRepay, init = ItemGetMethodCell.initJumpToRepay}, -- 累计充值
    [33] = {tpe = 33, call = ItemGetMethodCell.onHeroRecruitActivity, init = ItemGetMethodCell.initHeroRecruitActivity}, --英雄招募活动（限时招募）
    [34] = {tpe = 34, call = ItemGetMethodCell.onAllianceBoss, init = ItemGetMethodCell.initAllianceBoss}, --联盟Boss
    [35] = {tpe = 35, call = ItemGetMethodCell.onAvatarStoreFragment}, --【Awen】装扮商城碎片页签
    [36] = {tpe = 36, call = ItemGetMethodCell.onAvatarStoreDiamond}, --【Awen】装扮商城钻石页签
    [37] = {tpe = 37, call = ItemGetMethodCell.onTournamentAddNum, init = ItemGetMethodCell.initTournamentAddNum}, --【tw】竞技场增加次数道具
    [38] = {tpe = 38, call = ItemGetMethodCell.onNationalWarResource, init = ItemGetMethodCell.initNationalWarResource}, -- 神秘海域矿产道具，黑白金石
    [39] = {tpe = 39, call = ItemGetMethodCell.onMateCreate, init = ItemGetMethodCell.initMateCreate}, -- 材料合成界面 -- 2019-10-16 hyp
    [40] = {tpe = 40, call = ItemGetMethodCell.onKingBiographyRoulette}, -- 列王传转盘
    [41] = {tpe = 41, call = ItemGetMethodCell.onKingBiographyView}, -- 列王传界面
    [42] = {tye = 42, call = ItemGetMethodCell.onFestivalMainView}, --节日主题活动跳转
    [43] = {tpe = 43, call = ItemGetMethodCell.onDarkCivView}, --名城列表跳转
    [44] = {tpe = 44, call = ItemGetMethodCell.onFTBagView}, --阵法仓库
    [45] = {tpe = 45, call = ItemGetMethodCell.onTheHeavensView}, --天空之境
    [46] = {tpe = 46, call = ItemGetMethodCell.onAllStore}, --通用代币商店,
    [47] = {tpe = 47, call = ItemGetMethodCell.onSoldierRankView}, -- 士兵排行榜
    [48] = {tpe = 48, call = ItemGetMethodCell.onTreasureMapActView}, -- 夜市
    [49] = {tpe = 49, call = ItemGetMethodCell.onAnShuiJingBox}, -- 暗水晶宝箱
    [50] = {tpe = 50, call = ItemGetMethodCell.onFTAuction}, -- 阵法拍卖行
    [51] = {tpe = 51, call = ItemGetMethodCell.onFTView}, -- 阵法界面
    [52] = {tpe = 52, call = ItemGetMethodCell.onDigView}, -- 宝石挖掘
    [53] = {tpe = 53, call = ItemGetMethodCell.onAlliance}, -- 联盟
    [54] = {tpe = 54, call = ItemGetMethodCell.onAllianceDonate}, -- 联盟捐献
    [55] = {tpe = 55, call = ItemGetMethodCell.onGoodsExchange}, -- 道具转化
}

return ItemGetMethodCell
------------------------------------------ ItemGetMethodCell End --------------------------------------------
