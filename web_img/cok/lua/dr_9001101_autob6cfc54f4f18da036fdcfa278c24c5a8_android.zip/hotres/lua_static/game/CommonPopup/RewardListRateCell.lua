-------------------------------------------- NewbeeCastlePopupCell Start --------------------------------------------
local RewardListRateCell = class("RewardListRateCell", function()
    return cc.Layer:create()
end)

local LibaoCommonFunc = Drequire("game.LiBao.LibaoCommonFunc")

function RewardListRateCell:create(idx)
    local ret = RewardListRateCell.new()
    Drequire("game.CommonPopup.RewardListRateCell_ui"):create(ret)
    return ret
end

function RewardListRateCell:refreshCell(data , idx)
    -- dump(data, "RewardListRateCell:refreshCell")
    LibaoCommonFunc.createRewardItemTouchNode({
            reward = data,
            iconNode = CCNode:create(),
            iconSize = 60,
            nameLabel = self.ui.m_nameLabel,
        })

    local rate = (atoi(data.value.rate) / atoi(data.sumRate)) * 100
    self.ui.m_rateLabel:setString(string.format("%.4f%%", rate))
end

function RewardListRateCell:onEnter()
end

function RewardListRateCell:onExit()

end

-------------------------------------------- RewardListRateCell End --------------------------------------------

return RewardListRateCell