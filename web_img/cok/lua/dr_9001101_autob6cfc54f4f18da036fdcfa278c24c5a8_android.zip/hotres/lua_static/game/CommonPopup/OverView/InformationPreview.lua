local InformationPreview = class("InformationPreview", 
    function()
        return cc.Layer:create()            
    end
)
InformationPreview.__index = InformationPreview
PreviewController = Drequire("game.CommonPopup.OverView.PreviewController")
local cellHeight = 50
local maxCellNum = 9

function InformationPreview:ctor()
	self.infoData = {}
	self.ctl = PreviewController.getInstance()
	self.ctl:initInfo()	
end

function InformationPreview:create(dict)	
	local view = InformationPreview.new()
	Drequire("game.CommonPopup.OverView.InformationPreview_ui"):create(view,0)
	if view:initView(dict) then
		return view
	end
end

function InformationPreview:initView(dict)
	if FunOpenController:isUnlock("fun_preview", true) == false then
		return false
	end
	CCLoadSprite:call("loadDynamicResourceByName", "overview_icons_face")
	self.parentNode = dict:objectForKey("Node") or nil
	self.UISpr = self.parentNode:getChildByTag(1) or nil
	if self.UISpr then
		self.UISpr:setVisible(false)
	end
	self.touchlayer = cc.Layer:create()
	function touchHandle(eventType, x, y)
        if eventType == "began" then  
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)
        else  
            return self:onTouchEnded(x, y)  
        end
	end

    self.ui.m_sprCloseRoot:setUseTouchScale(true)
	self.ui.m_touchNode:addChild(self.touchlayer)
	self.touchlayer:registerScriptTouchHandler(touchHandle)
    self.touchlayer:setTouchEnabled(true)
	self.touchlayer:setSwallowsTouches(true)
	self.ui.m_title:setString(getLang("2000440"))
	
	--position
	local size = self.ui.m_rootNode:getContentSize()
	self:setPosition(ccp(size.width * -1,size.height* -0.5))

	--tableViewData
	self.showType = 0
	self:setShowViewData()
	self.ui.m_saveSetBtn:setEnabled(false)
	return true
end

--type:1 进场  2:退场
function InformationPreview:onEnterAction(type)
	local contentSize = self.ui.m_rootNode:getContentSize()
	local _delay = cc.DelayTime:create(0.2)
	local _move = cc.MoveTo:create(0.2,ccp(-3,contentSize.height* -0.5))	
	local _moveOut = cc.MoveTo:create(0.2,ccp(contentSize.width * -1,contentSize.height* -0.5))
	local callfun = cc.CallFunc:create(function()
		if self.UISpr then
			self.UISpr:setVisible(true)
		end
		self:removeFromParent()
	end)
	if type == 1 then
		local _seq = cc.Sequence:create(_delay,_move)
		self:runAction(_seq)
	elseif type == 2 then
		local _seq = cc.Sequence:create(_delay,_moveOut,callfun)
		self:runAction(_seq)
	end
end

function InformationPreview:onEnter( )
	self:onEnterAction(1)
	registerScriptObserver(self,self.goBackShowView,"InformationPreview:refreshView")
	--数据打点
	local now = getTimeStamp()
	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
    local myUid = playerInfo:getProperty("uid")
end

function InformationPreview:onExit()
	self:saveShowTblOffset()
	unregisterScriptObserver(self,"InformationPreview:refreshView")
end

function InformationPreview:onTouchBegan(x, y)
	self.onClickType = 1	
	if not isTouchInside(self.ui.m_touchNode,x,y) or isTouchInside(self.ui.m_sprClose,x,y) then
		self.onClickType = 0
        self.ui.m_sprCloseRoot:setTouchScaled(true)
	end

	if self.ui.m_resetSpr:isVisible(true) and isTouchInside(self.ui.m_resetSpr,x,y) then
		self:onClickResetBtn()
		return true
	end

	if self.ui.m_backSpr:isVisible(true) and isTouchInside(self.ui.m_backSpr,x,y) then
		self:goBackShowView()
		return true
	end

	-- dump("hxq .....onTouchBegan ")
	--move
	return true
end

function InformationPreview:onTouchMoved(x, y)
end

function InformationPreview:onTouchEnded(x, y)
	if not isTouchInside(self.ui.m_touchNode,x,y) and self.onClickType == 0 then
		self:onClickClose()		
	end
	if isTouchInside(self.ui.m_sprClose,x,y) and self.onClickType == 0 then
        self.ui.m_sprCloseRoot:setTouchScaled(false)
		self:onClickClose()
	end
end

--关闭界面
function InformationPreview:onClickClose()
	self:onEnterAction(2)
end

--刷新界面信息
function InformationPreview:refreshView()
	self.ctl:initInfo()
	self:setShowViewData()
end

--设置
function InformationPreview:onClickResetBtn()
	self:saveShowTblOffset()
	self.ui.m_infoTableView:setVisible(false)
	self.ui.m_switchTblView:setVisible(true)
	self.ui.m_saveSetBtn:setVisible(true)	
	self.ui.m_resetBtn:setVisible(true)
	self.ui.m_backSpr:setVisible(true)
	self.ui.m_resetSpr:setVisible(false)
	self.showType = 1	
	--为了实现勾选以后的排序要求，这里维护两个子列表，当不显示变为显示时插到表1尾部，当显示变为不显示插到表2头部
	--tableView总显示列表
	self.selectTblData = {}
	--表1:显示，打对号
	self.visibleTblData = {}
	--表2:不显示，不打对号
	self.notVisibleTblData = {}

	local function sortByOrder(a,b)
		if a.local_order == b.local_order then
			return tonumber(a.order) < tonumber(b.order)
		else
			return a.local_order < b.local_order
		end
	end

	local tempTbl = self.ctl.previewSelectData or {}--保存前数据
	for k,v in pairs(tempTbl) do
		v.parent = self
		if v.visible then
			table.insert(self.visibleTblData,v)
		else
			table.insert(self.notVisibleTblData,v)
		end
	end

	table.sort(self.visibleTblData, sortByOrder)
	table.sort(self.notVisibleTblData, sortByOrder)
	self:setSelectViewDate()
end

--设置列表
function InformationPreview:setSelectViewDate()
	self.selectTblData = {}
	for k ,v in pairs(self.visibleTblData or {}) do
		table.insert( self.selectTblData,v)
	end
	for k ,v in pairs(self.notVisibleTblData or {}) do
		table.insert( self.selectTblData,v)
	end
	--设置列表
	dump(self.selectTblData,"hxq selectTblData is ")
	self.ui:setTableViewDataSource("m_switchTblView",self.selectTblData)
	if self.selectOffset then
		self.ui.m_switchTblView:setContentOffset(self.selectOffset)
	end
end

--详细信息列表
function InformationPreview:setShowViewData()
	--详细信息列表
	self.showType = 0
	local function sortByOrder(a,b)
		if a.local_order == b.local_order then
			return a.order < b.order
		else
			return a.local_order < b.local_order
		end
	end	
	local tbl = self.ctl.previewInfoData or {}
	self.tableData={}
	for key,value in pairs(tbl) do
		value.parent = self
		table.insert(self.tableData,value)
	end
	table.sort(self.tableData,sortByOrder)
	self.ui:setTableViewDataSource("m_infoTableView",self.tableData)
	
	local last_offset = self:getShowTblOffset()
	if last_offset then
		self.ui.m_infoTableView:setContentOffset(last_offset)
	end
end

function InformationPreview:cellSizeForTable(table, index)
	if self.showType == 0 then
		--默认初始大小，9个子类别	
		if not self.cellSizeTbl then
			self.cellSizeTbl = {}
		end
		local cellInfo = self.tableData[index+1]
		local cellNum = #cellInfo.cellMeta or 1
		if cellNum > maxCellNum then cellNum = maxCellNum end
		local width = 464
		local height = 515 - (maxCellNum - cellNum) * 50
		self.cellSizeTbl[index+1] = height
		return width,height
	else
		return 464,80
	end
end

function InformationPreview:onClickSelectCellSpr(key, visible)
	self.ctl.previewSelectData[key].visible = visible --该表
	--存下当前偏移量
	self.selectOffset = self.ui.m_switchTblView:getContentOffset()

	--visible是选择后的状态
	if visible then
		for k,v in pairs(self.notVisibleTblData or {}) do
			if v.key == key then
				v.visible = visible
				table.remove( self.notVisibleTblData,k)
				table.insert( self.visibleTblData,v)
			end
		end
	else
		for k,v in pairs(self.visibleTblData or {}) do
			if v.key == key then
				v.visible = visible
				table.remove( self.visibleTblData,k)
				table.insert( self.notVisibleTblData,1,v)
			end
		end
		
	end
	self:setSelectViewDate()
	for k,v in pairs(self.selectTblData) do
		self.ctl.previewSelectData[v.key].local_order = k
	end
end

function InformationPreview:goBackShowView()
	self.ui.m_infoTableView:setVisible(true)
	self.ui.m_switchTblView:setVisible(false)
	self.ui.m_saveSetBtn:setVisible(false)
	self.ui.m_resetBtn:setVisible(false)	
	self.ui.m_backSpr:setVisible(false)
	self.ui.m_resetSpr:setVisible(true)
	self:setShowViewData()
end

function InformationPreview:onClickSaveSet( )
	self.ui.m_saveSetBtn:setEnabled(false)
	--编辑生效后清空偏移量记录
	cc.UserDefault:getInstance():setStringForKey("InformationPreviewOffset", "")
	cc.UserDefault:getInstance():flush()
	--保存生效
	self.ctl:saveCellShowSwitch()	
end

function InformationPreview:onClickReset( )
	cc.UserDefault:getInstance():setStringForKey("InformationPreviewOffset", "")
	self.ctl:resetLocalProps()
end

--保存当前列表偏移量
function InformationPreview:saveShowTblOffset()
	local offset = self.ui.m_infoTableView:getContentOffset()
	if offset then
		local pos_y = offset.y
		cc.UserDefault:getInstance():setStringForKey("InformationPreviewOffset", tostring(pos_y))
		cc.UserDefault:getInstance():flush()
	end	
end

--读取上次列表偏移量
function InformationPreview:getShowTblOffset()
	local pos_y = cc.UserDefault:getInstance():getStringForKey("InformationPreviewOffset","")
	if pos_y ~= "" then
		return ccp(0,tonumber(pos_y))
	end
end

return InformationPreview