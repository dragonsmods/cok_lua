----------------------------
-- Author: Elex
-- Date: 2019-07-10 Wednesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local RewardShowAndGetNewCell_ui = class("RewardShowAndGetNewCell_ui")

--#ui propertys


--#function
function RewardShowAndGetNewCell_ui:create(owner, viewType, paramTable)
	local ret = RewardShowAndGetNewCell_ui.new()
	CustomUtility:LoadUi("RewardShowAndGetNewCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function RewardShowAndGetNewCell_ui:initLang()
end

function RewardShowAndGetNewCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function RewardShowAndGetNewCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return RewardShowAndGetNewCell_ui

