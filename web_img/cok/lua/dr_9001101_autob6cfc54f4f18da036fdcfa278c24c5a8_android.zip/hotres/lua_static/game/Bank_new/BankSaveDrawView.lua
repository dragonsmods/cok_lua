local BankSaveDrawView = class("BankSaveDrawView", 
	function() 
		return PopupBaseView:create() 
	end
)
function BankSaveDrawView:create(data,index,type)
	MyPrint("-------call BankSaveDrawView:create -----",index,"type =",type)
	local view = BankSaveDrawView.new()
	require("game.Bank_new.BankSaveDrawView_ui"):create(view,1)
	if type == nil and view:initView(data,index) == false then 
		view = nil    
    elseif type == 2 and  view:initView2(data,index,type) == false then
        view = nil 
	end
	return view
end

function BankSaveDrawView:initView(data,index)
    self:setIsHDPanel(true)
    dump(data,"BankSaveDrawView:initView")
	self.m_data   = data
	self.m_index  = index
	self.m_max    = data.max
	self.m_min    = data.min
	self.m_hireNum= data.min
    self.m_endTime = data.time

	self.ui.m_titleLabel:setString(_lang("180118"))
	local str_rata = string.format("%s%%",tostring(self.m_data.rate))
	self.ui.m_earningsLabel:setString(_lang("149308"))
    self.ui.m_rateNum1Label:setString(str_rata)

    local extra_rata = string.format("%s%%",tostring(data.extraRate))
    self.ui.m_extra1Label:setString(_lang("149307"))
    self.ui.m_rateNum2Label:setString(extra_rata) --额外利率
    self.total_rate = tonumber(data.extraRate) + tonumber(data.rate)
    self.m_time = data.time--投资时间
    local str_time = format_time(self.m_time)
    self.ui.m_deadlineLabel:setString(_lang("149309"))
    self.ui.m_deadNumLabel:setString(str_time)
    --限制
    self.ui.m_leastLabel:setString(_lang("149310"))
    self.ui.m_leastNumLabel:setString(CC_CMDITOA(data.min))

    self.ui.m_okButton:setTitleForState(_lang("149313"), cc.CONTROL_STATE_NORMAL)
    self.ui.m_desLabel:setString(_lang("149312"))

    local m_sliderBg = CCLoadSprite:call("createScale9Sprite","huadongtiao3.png");
    m_sliderBg:setInsetBottom(5)
    m_sliderBg:setInsetLeft(5)
    m_sliderBg:setInsetRight(5)
    m_sliderBg:setInsetTop(5)
    m_sliderBg:setAnchorPoint(ccp(0.5,0.5))
    m_sliderBg:setPosition(ccp(304/2, 25))
    m_sliderBg:setContentSize(cc.size(280,18))
	local bgSp = CCLoadSprite:call("createSprite","huadongtiao3.png")
    local proSp = CCLoadSprite:call("createSprite","UI_jindutiao.png")
    local thuSp = CCLoadSprite:call("createSprite","huadongtiao1.png")
    bgSp:setScaleY(0.8)
	self.m_goldSlider = CCSliderBar:call("createSlider",m_sliderBg, proSp, thuSp)
    self.m_goldSlider:setMinimumValue(self.m_min/self.m_max)
    self.m_goldSlider:setMaximumValue(1.0)
    self.m_goldSlider:call("setProgressScaleX",280/proSp:getContentSize().width)
    self.m_goldSlider:setTag(1)
    self.m_goldSlider:call("setLimitMoveValueEx",25)
    -- self.m_trainSlider:setTouchPriority(Touch_Popup);
    
    local function valueChanged(pSender)
        self:sliderCallBack(pSender)
    end
    self.m_goldSlider:addHandleOfControlEvent(valueChanged, CCControlEventValueChanged)
    self.ui.m_sliderContainer:addChild(self.m_goldSlider, 1);

    -- 输入框
    local editSize = self.ui.m_pEditNode:getContentSize()
    local editpic = CCLoadSprite:call("createScale9Sprite", "frame_3.png")
    editpic:setContentSize(editSize)
    editpic:setInsetBottom(1)
    editpic:setInsetTop(1)
    editpic:setInsetRight(1)
    editpic:setInsetLeft(1)
    self.m_editBox = CCEditBox:create(editSize, editpic)
    self.m_editBox:setInputMode(cc.EDITBOX_INPUT_MODE_NUMERIC)
    self.m_editBox:setText(self.m_hireNum)
    self.m_editBox:setMaxLength(12)
    self.m_editBox:setReturnType(cc.KEYBOARD_RETURNTYPE_DONE)
    self.m_editBox:setPosition(ccp(editSize.width / 2, editSize.height / 2))
    self.ui.m_pEditNode:addChild(self.m_editBox)

    -- 输入框回调
    local function editCB(strEventName, pSender)
        if tostring(pSender) == "began" then
            -- 光标进入，选中全部内容
        elseif tostring(pSender) == "ended" then
            -- 当编辑框失去焦点并且键盘消失的时候被调用
        elseif tostring(pSender) == "return" then
            -- 当用户点击编辑框的键盘以外的区域，或者键盘的Return按钮被点击时所调用
            self:editBoxReturn()
        elseif tostring(pSender) == "changed" then
            -- 输入内容改变时调用
        end
    end
    self.m_editBox:registerScriptEditBoxHandler(editCB) -- 输入框的事件，主要有光标移进去，光标移出来，以及输入内容改变等

    self.ui.m_sp_p_2:setVisible(false)
    self.ui.m_spr_dp_2:setVisible(false)
    self.ui.m_line_2:setVisible(false)
    MyPrint("BankSaveDrawView:initView over")
	return true
end	

function BankSaveDrawView:initView2(data,index,type)
    self:setIsHDPanel(true)
    dump(data,"BankSaveDrawView data")
    self.m_type = type
    self.m_data = data
    self.m_endTime = data.endTime/1000
    local str_rata = string.format("%s%%",tostring(self.m_data.rate))
    local extra_rata = string.format("%s%%",tostring(data.extraRate))
    self.ui.m_earningsLabel:setString(_lang("149325"))
    self.ui.m_extra1Label:setString(_lang("149308"))
    self.ui.m_rateNum2Label:setString(str_rata)
    self.ui.m_extra2Label:setString(_lang("149307"))
    self.ui.m_timeLabel:setString(_lang("149323"))
    self.ui.m_yetLabel:setString(_lang("149324"))
    self.ui.m_desLabel:setString(_lang("149312"))
    self.ui.m_okButton:setTitleForState(_lang("149314"), cc.CONTROL_STATE_NORMAL)
    self.ui.m_line_2:setVisible(false)
    self.ui.m_extraNum3Label:setString(extra_rata)
    self.ui.m_yetIcon:setVisible(true)
    self.ui.m_icon_1:setVisible(false)
    self.ui.m_editBoxNode:setVisible(false)
    self.ui.m_yetNumLabel:setString(CC_CMDITOA(data.num))
    self.total_rate = tonumber(data.extraRate) + tonumber(data.rate)
    local total  = math.modf((self.total_rate/100 + 1) * self.m_data.num)
    self.ui.m_rateNum1Label:setString(CC_CMDITOA(total))
    local now_time = getTimeStamp() 
    -- local curTime = getTimeStamp() 
    self.d_time  = (self.m_endTime - now_time )
    if self.d_time < 0 then 
        self.d_time = 0 
    end
    local str_left_time = format_time(self.d_time)
    local str_begin_time = format_time(tonumber(data.time) - tonumber(self.d_time))

    self.ui.m_timeNumLabel:setString(str_left_time)
    MyPrint("BankSaveDrawView now_time ",now_time,"end time ",self.m_endTime ,"and d_time ",self.d_time)
    if self.m_endTime < now_time then 
        self.ui.m_okButton:setTitleForState(_lang("168533"), cc.CONTROL_STATE_NORMAL)
    end

    local function updatefunc(dt)
        self:update(dt)
    end 
    self.m_entryId = cc.Director:getInstance():getScheduler():scheduleScriptFunc(updatefunc, 1, false)
    self.ui.m_sp_p_2:setVisible(false)
    self.ui.m_spr_dp_2:setVisible(false)
    return true
end

function BankSaveDrawView:update(t)
    self.d_time  = self.d_time - t
    if self.d_time < 0 then 
        self.d_time = 0
        if self.m_entryId then
            cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.m_entryId)
            self.m_entryId = nil
        end
        self.ui.m_okButton:setTitleForState(_lang("168533"), cc.CONTROL_STATE_NORMAL)
    end
    local str_left_time = format_time(self.d_time)
    self.ui.m_timeNumLabel:setString(str_left_time)
end

function BankSaveDrawView:onExit( )
    if self.m_entryId then
        cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.m_entryId)
        self.m_entryId = nil
    end
end

function BankSaveDrawView:editBoxReturn()
    local numStr = self.m_editBox:getText()
    local num = tonumber(numStr) or self.m_hireNum
    local min = tonumber(self.m_min)
    local max = tonumber(self.m_max)
    if num < min then
        num = min
    elseif num > max then
        num = max
    end
    self.m_hireNum = num

    -- 更新界面
    self.m_editBox:setText(self.m_hireNum)
    if max <= 0 then
        self.m_goldSlider:setTouchEnabled(false)
        self.m_goldSlider:setValue(0.0)
    else
        self.m_goldSlider:setTouchEnabled(true)
        self.m_goldSlider:setValue(1.0 * num / max)
    end
end


function BankSaveDrawView:sliderCallBack( pSender )
	self.m_hireNum = math.floor(self.m_goldSlider:getValue() * self.m_max + 0.5);
    if tonumber(self.m_hireNum)  < tonumber(self.m_min) then 
        self.m_hireNum  = self.m_min
    end
    self:refreshNum();
    MyPrint("BankSaveDrawView:sliderCallBack",self.m_hireNum)
end

function BankSaveDrawView:refreshNum()
    self.m_editBox:setText(self.m_hireNum)
end

function BankSaveDrawView:onOkButtonClick(pSender, event)
    -- if ElexSdkUtil:call("getIsWatched") then
    --     CCCommonUtilsForLua:call("flyHint", "", "", getLang("149454"))
    --     return
    -- end

    if self.m_type == nil then 
	   self:showYesNo()
    elseif self.m_type == 2 then --领取奖励
        MyPrint("BankSaveDrawView  onOkButtonClick")

        if self.d_time > 0 then
            local view = require("game.Bank_new.BankStopView"):create(self.m_data)
            PopupViewController:call("addPopupView", view)
            PopupViewController:call("removePopupView",self)
        else
            local cmd = BankDrawMoneyCmd:create(self.m_data.key)
            cmd:send()
            CCSafeNotificationCenter:postNotification("MSG_RELOAD_BANK_BAG",CCString:create(self.m_data.key))
            PopupViewController:call("removePopupView",self)
        end
    end
end

function BankSaveDrawView:showYesNo( )
    local function confirmFunc()
        -- 判断存款数目是否达到上限
        local curDepositNum = #BankController:getInstance().m_deposit_list
        local maxDepositNum = 0
        local imperialInfo = GlobalData:call("shared"):getProperty("imperialInfo")
        for k, v in pairs (imperialInfo) do
            if math.floor(k / 1000) == FUN_BUILD_BANK then
                maxDepositNum = maxDepositNum + v:getProperty("para3")
            end
        end
        if curDepositNum >= maxDepositNum then
            CCCommonUtilsForLua:call("flyText", _lang_1("149479", CC_ITOA(maxDepositNum))) -- -- 149479=当前购买的理财产品已达上限数量{0}个，无法继续购买。
            return
        end

        local  cmd = BankProductsBuyCmd:create(self.m_data.type ,self.m_hireNum)
        cmd:send()
        local key = self.m_data.key
        MyPrint("postNotification the key ",key)
        -- CCSafeNotificationCenter:postNotification("MSG_RELOAD_BANK_BAG",CCString:create(key))
         PopupViewController:call("removePopupView",self)
    end

    local now_time =  getTimeStamp()
    local finish_time  = (self.m_endTime  + now_time )
    -- local str_left_time = format_time(d_time)
    local str_left_time = CCCommonUtilsForLua:call("timeStampToDHM",finish_time)

    local total  =  (self.total_rate/100 + 1) * self.m_hireNum
    -- MyPrint("showYesNo str_left_time",str_left_time,"total ",total,"self.m_hireNum",self.m_hireNum,"time "，self.m_endTime,"now_time",now_time)
    local name = _lang(CCCommonUtilsForLua:getPropById(self.m_data.type,"name"))
    local text = _lang_4("149327",CC_CMDITOA(self.m_hireNum),name,str_left_time,CC_CMDITOA(total))
    YesNoDialog:show(text, confirmFunc)
end

function BankSaveDrawView:onClickCloseBtn()
	 PopupViewController:call("removePopupView",self)
end

return BankSaveDrawView
