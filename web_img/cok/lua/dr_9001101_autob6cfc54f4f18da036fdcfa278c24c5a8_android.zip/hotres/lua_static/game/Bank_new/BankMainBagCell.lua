local BankMainBagCell = class("BankMainBagCell", 
	function() 
		return cc.TableViewCell:create()
	end
)

function BankMainBagCell:create(data,index)
	MyPrint("-------call BankRecordCell:create -----")
	local view = BankMainBagCell.new()
	require("game.Bank_new.BankMainBagCell_ui"):create(view,1)
	if view:initView(data,index) == false then 
		view = nil 
	end

	return view
end

function BankMainBagCell:initView(data,index)
	dump(data,"initView data")
	self.m_data = data
	self.m_index = index
	self.m_endTime = data.endTime/1000
	self.base_id = self.m_data.type
	self.m_key = data.key
	self.ui.m_nameBagLabel:setString(_lang( CCCommonUtilsForLua:getPropById(self.base_id,"name")))
	self.ui.m_desBagButton:setTitleForState(_lang("149306"), cc.CONTROL_STATE_NORMAL)

	local planed_gold =math.modf(((tonumber(data.extraRate)+tonumber(data.rate))/100+ 1)* self.m_data.num)
	self.ui.m_planLabel:setString(_lang("149317"))
	self.ui.m_goldLabel:setString(_lang("149318"))
	self.ui.m_timeLabel:setString(_lang("149319"))
	self.ui.m_limitLabel:setString(_lang("149320"))
	self.ui.m_planNumLabel:setString(CC_CMDITOA(planed_gold))
	self.ui.m_goldNumLabel:setString(CC_CMDITOA(self.m_data.num))
	self.ui.m_desOkButton:setVisible(false)
	self.ui.m_desBagButton:setVisible(true)
	local now_time =  getTimeStamp()
    self.d_time  = (self.m_endTime - now_time )
    local str_end_time = CCCommonUtilsForLua:call("timeStampToDHM",self.m_endTime)
	self.ui.m_timeEnd:setString(str_end_time)
	local began_data =CCCommonUtilsForLua:call("timeStampToDHM",self.m_endTime - data.time)
	self.ui.m_timeStart:setString(began_data)
	MyPrint("self.d_time ",self.d_time,"endtime ",self.m_endTime," now_time ",now_time)
	if self.m_endTime <= now_time then --已经到时间可以领取
		self.ui.m_desOkButton:setTitleForState(_lang("149321"), cc.CONTROL_STATE_NORMAL)
		self.ui.m_desOkButton:setVisible(true)
		self.ui.m_desBagButton:setVisible(false)
	end
	return true
end	

function BankMainBagCell:update(t)
    self.d_time  = self.d_time - t
    local str_left_time = format_time(self.d_time)
    self.ui.m_timeEnd:setString(str_left_time)
end


function BankMainBagCell:onDesBagButtonClick(pSender, event) 
	-- local  cmd = require("game.Bank_new.BankProductsBuyCmd"):create()
	local view  = Drequire("game.Bank_new.BankSaveDrawView"):create(self.m_data,self.m_index,2)
	PopupViewController:call("addPopupView", view)
	MyPrint("BankMainBagCell:onDesBagButtonClick")
end

function BankMainBagCell:onDesOkButtonClick(pSender, event)
	-- if ElexSdkUtil:call("getIsWatched") then
 --        CCCommonUtilsForLua:call("flyHint", "", "", getLang("149454"))
 --        return
 --    end

	local cmd = BankDrawMoneyCmd:create(self.m_key)
    cmd:send()
end
return BankMainBagCell
