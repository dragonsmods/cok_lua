
local BankStopView = class("BankStopView", 
	function() 
		return PopupBaseView:create() 
	end
)

function BankStopView:create(data,index)
	MyPrint("-------call BankStopView:create here-----")
	local view = BankStopView.new()
	require("game.Bank_new.BankStopView_ui"):create(view,1)
	if view:initView(data,index) == false then 
		view = nil 
	end

	return view
end

function BankStopView:initView(data,index)
	dump(data,"BankStopView:initView")
	self.m_data = data 
	self.ui.m_detailLabel:setString(_lang("149455"))
	self.ui.m_titleLabel:setString(_lang("149314"))
	self.ui.m_goldLabel:setString(_lang("149456"))
	self.ui.m_goldNumLabel:setString(CC_CMDITOA(data.num))
	self.ui.m_askLabel:setString(_lang("149453"))
	self.ui.m_okButton:setTitleForState(_lang("149322"), cc.CONTROL_STATE_NORMAL)
	self:initTouch()
	return true
end	

function BankStopView:onOkButtonClick(pSender)
	MyPrint("MSG_RELOAD_BANK_BAG key = ",self.m_data.key)
	local cmd = BankDrawMoneyCmd:create(self.m_data.key)
    cmd:send()
 	CCSafeNotificationCenter:postNotification("MSG_RELOAD_BANK_BAG",CCString:create(self.m_data.key))
    PopupViewController:call("removePopupView",self)
end

function BankStopView:initTouch( ... )
	local function touchHandle( eventType, x, y )
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		else
			self:onTouchEnded(x, y)
		end
	end
	local touchLayer = cc.Layer:create()
	self:addChild(touchLayer)
	touchLayer:registerScriptTouchHandler(touchHandle)
	touchLayer:setTouchEnabled(true)
end

function BankStopView:onTouchBegan(x, y)
	if touchInside(self.ui.m_okButton, x, y) then
		return false
	end
	return true
end

function BankStopView:onTouchEnded(x, y)
	PopupViewController:call("removePopupView",self)
end

return BankStopView
