local BankRecordCell = class("BankRecordCell", 
	function() 
		return cc.TableViewCell:create()
	end
)

function BankRecordCell:create(data,index)
	MyPrint("-------call BankRecordCell:create -----")
	local view = BankRecordCell.new()
	require("game.Bank_new.BankRecordCell_ui"):create(view,1)
	if view:initView(data,index) == false then 
		view = nil 
	end

	return view
end

function BankRecordCell:initView(data,index)
	if data == nil then
		return false 
	end 
	self.m_data = data
	self.m_index = index

	dump(data, " BankRecordCell data ")
	local name = string.format("(%s)",_lang( CCCommonUtilsForLua:getPropById(self.m_data.type,"name")))
	self.ui.m_nameLabel:setString(name)
	self.ui.m_savedrawNum:setString(CC_CMDITOA(data.num))
	local str_data = CCCommonUtilsForLua:call("timeStampToDHM",data.withDrawTime/1000)
	self.ui.m_savedrawDate:setString(str_data)
	-- local total = tonumber(data.num) * (1 + tonumber(data.rate) /100 )* (1 + tonumber(data.extraRate)/100)
	-- self.ui.m_savedrawTotal:setString(CC_CMDITOA(total))
	self.ui.m_savedrawTotal:setVisible(false)
	local str = _lang("149218")
	if self.m_data.operate == "1" then 
		str = _lang("149217")
	end 
	self.ui.m_saveDrawAction:setString(str)
	
	local now_time = getWorldTime()
	MyPrint("now time ",now_time)
	return true
end	

function BankRecordCell:onGetStoreButtonClick(pSender, event) 
	-- local  cmd = require("game.Bank_new.BankProductsBuyCmd"):create()
	local view  = Drequire("game.Bank_new.BankSaveDrawView"):create(self.m_data)
	PopupViewController:call("addPopupInView", view)
end
return BankRecordCell
