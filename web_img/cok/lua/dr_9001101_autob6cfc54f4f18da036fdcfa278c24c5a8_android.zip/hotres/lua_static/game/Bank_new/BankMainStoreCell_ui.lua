----------------------------
-- Author: Elex
-- Date: 2018-12-28 Friday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local BankMainStoreCell_ui = class("BankMainStoreCell_ui")

--#ui propertys


--#function
function BankMainStoreCell_ui:create(owner, viewType, paramTable)
	local ret = BankMainStoreCell_ui.new()
	CustomUtility:DoRes(7, true)
	CustomUtility:LoadUi("BankMainStoreCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function BankMainStoreCell_ui:initLang()
end

function BankMainStoreCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function BankMainStoreCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function BankMainStoreCell_ui:onDesStoreButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onDesStoreButtonClick", pSender, event)
end

function BankMainStoreCell_ui:onGetStoreButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onGetStoreButtonClick", pSender, event)
end

return BankMainStoreCell_ui

