--[[
    活动npc列表Cell
]]

local LibaoCommonFunc = require("game.LiBao.LibaoCommonFunc")

local ActivityNpcListCell = class("ActivityNpcListCell", function()
    return cc.Layer:create()
end)

local DailyActivityManager = require("game.dailyActivity.DailyActivityManager")
function ActivityNpcListCell:create(idx)
    local ret = ActivityNpcListCell.new()
    Drequire("game.ActivityNpc.ActivityNpcListCell_ui"):create(ret)
    local function onTouch(eventType, x, y)  
        if eventType == "began" then  
            return ret:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return ret:onTouchMoved(x, y)  
        else  
            return ret:onTouchEnded(x, y)  
        end
    end
    ret:setTouchEnabled(true)
    ret:registerScriptTouchHandler(onTouch)
    ret:setSwallowsTouches(false)
   
    return ret
end

function ActivityNpcListCell:refreshCell(info , idx)
    self.m_id = info.activityId
    self.m_tableView = info.tableView

    local obj = ActivityController:call("getInstance"):call("getActObj", self.m_id)
    if (not obj) then
        return
    end
    self.ui.m_nameLabel:setString(obj:getProperty("name"))
    self.ui.m_iconNode:removeAllChildren()

    if LocalController:call("getLanguageFileName") == "ar" then--阿拉伯语
        local size = self.ui.m_nameLabel:getContentSize()
        if size.width > 300 then
            self.ui.m_nameLabel:setScale(300 / size.width)
        end
    end
    local sf = obj:getIconFrame()
    local iconSpr = nil
    if (sf) then
        iconSpr = cc.Sprite:createWithSpriteFrame(sf)
        self.ui.m_iconNode:addChild(iconSpr)
    else
        iconSpr = CCLoadSprite:createSprite("Ativity_iconLogo_1.png")
        self.ui.m_iconNode:addChild(iconSpr)
    end
    CCCommonUtilsForLua:call("setSpriteMaxSize", iconSpr, 94, true)
    if (obj:call("getmerge")) then
        for i=0,2 do
            local particle = ParticleController:call("createParticle", string.format("LimitActive_%d", i))
            self.ui.m_iconNode:addChild(particle)
            particle:setContentSize(cc.size(9999, 9999))
        end
    end
    self.ui.m_getLabel:setString(getLang("101303"))
    self.ui.m_getLabel:setVisible(true)
    -- <ItemSpec id="57000" type="1" name="105842" desc="105809" desc_info="105846" story="137519" Advertise_pic="57000_ad1" conquest="1" battle_type="1" level="1" item="200715;200392;200450"/>
    --reward icon
    self.ui.m_iconListNode:removeAllChildren()
    self.ui.m_iconListNode:setPositionX(self.ui.m_getLabel:getPositionX() + self.ui.m_getLabel:getContentSize().width)
    if self.iconlist_size == nil then 
        self.iconlist_size = self.ui.m_iconListNode:getContentSize()
    else
        self.ui.m_iconListNode:setContentSize( self.iconlist_size)
    end
   
    local rewardIds = obj:getProperty("rewardIds")
    local iconSize = 54
    if #rewardIds > 0 then
        for i=1,3 do
            if rewardIds[i] then

                local itemData = {
                type = 0,
                itemId = rewardIds[i],
                num = 1
                }
                local icon_node = CCNode:create()
                -- icon_node:setContentSize(CCSize(iconSize, iconSize))
                LibaoCommonFunc.createItemInfoShow(itemData, icon_node, iconSize,nil,nil,nil,true,self.ui.m_iconListNode)
                local rwardStr = CCCommonUtilsForLua:call("getIcon", tostring(rewardIds[i]))
                local ricon = CCLoadSprite:call("createSprite", rwardStr, CCLoadSpriteType.CCLoadSpriteType_GOODS)
                CCCommonUtilsForLua:call("setSpriteMaxSize", ricon, iconSize, true)
                -- self.ui.m_iconListNode:addChild(ricon)
                self.ui.m_iconListNode:addChild(icon_node)
                ricon:setAnchorPoint(cc.p(0,0))
                ricon:setPositionX(iconSize * (i - 1) )
                if LocalController:call("getLanguageFileName") == "ar" then--阿拉伯语
                     icon_node:setPosition(cc.p(iconSize * (i - 1) + iconSize/2 + 20,iconSize/2))
                else
                    icon_node:setPosition(cc.p(iconSize * (i - 1) + iconSize/2 ,iconSize/2))
                end
                -- icon_node:setAnchorPoint(cc.p(0.5,0.5))
            end
        end
    else
        self.ui.m_iconListNode:setContentSize(CCSize(0,0))
        self.ui.m_getLabel:setVisible(false)
    end

    --奖励星级
    self.ui.m_starLabel:setString(getLang("138573"))
    self.ui.m_starListNode:removeAllChildren()
    self.ui.m_starListNode:setPositionX(self.ui.m_starLabel:getPositionX() + self.ui.m_starLabel:getContentSize().width)
    local starNum = CCCommonUtilsForLua:getPropById(self.m_id, "reward_star")
    if "" ~= starNum then
        local stars = atoi(starNum)
        if stars > 0 then
            for index = 1, stars do
                local star = CCLoadSprite:createSprite("ICON_xingxing01.png")
                local particle1 = ParticleController:call("createParticle", "UIGlowLoop_1")
                local particle2 = ParticleController:call("createParticle", "UIGlowLoop_2")
                star:setPosition(index * 50, 15)
                particle1:setPosition(index * 50, 15)
                particle2:setPosition(index * 50, 15)
                self.ui.m_starListNode:addChild(star)
                self.ui.m_starListNode:addChild(particle1)
                self.ui.m_starListNode:addChild(particle2)
            end
            self.ui.m_starListNode:setScale(0.8)
        end
    else
        self.ui.m_starLabel:setVisible(false)
    end

    --level
    local challengeLevel = obj:getProperty("level")
    if challengeLevel == 1 then
        self.ui.m_levelTripleSprite:setVisible(false)
        self.ui.m_levelDoubleSprite:setVisible(false)
        self.ui.m_levelOneSprite:setVisible(true)
    elseif challengeLevel == 2 then
        self.ui.m_levelTripleSprite:setVisible(false)
        self.ui.m_levelDoubleSprite:setVisible(true)
        self.ui.m_levelOneSprite:setVisible(false)
    elseif challengeLevel == 3 then
        self.ui.m_levelTripleSprite:setVisible(true)
        self.ui.m_levelDoubleSprite:setVisible(false)
        self.ui.m_levelOneSprite:setVisible(false)
    else
        self.ui.m_levelTripleSprite:setVisible(false)
        self.ui.m_levelDoubleSprite:setVisible(false)
        self.ui.m_levelOneSprite:setVisible(false)
    end
    --battleType
    local battleType = obj:getProperty("battleType")
    if battleType == 1 then
        self.ui.m_peopleOneSprite:setVisible(true)
        self.ui.m_peopleDoubleSprite:setVisible(false)
    elseif battleType == 2 then
        self.ui.m_peopleOneSprite:setVisible(false)
        self.ui.m_peopleDoubleSprite:setVisible(true)
    else
        self.ui.m_peopleOneSprite:setVisible(false)
        self.ui.m_peopleDoubleSprite:setVisible(false)
    end
    --recommend
    local recommend = obj:getProperty("recommend") -- 1;30
    self.ui.m_recNode:setVisible(false)
    if recommend == 0 then
        self.ui.m_recNode:setVisible(false)
    elseif recommend == 1 then
        self.ui.m_recNode:setVisible(true)
        self.ui.m_recLabel:setString(getLang("115837"))
    end
   
    self:update(0)
    self.ui.m_superNode:setVisible(false)
end

function ActivityNpcListCell:updateSpecialActivity(actId)
    local isSpeAct, endTime = DailyActivityManager.getSpecialActivityEndtime(actId)
    if isSpeAct then 
        if endTime > 0 then
            self.ui.m_timeOverLabel:setColor(cc.c3b(93,207,0))
            self.ui.m_timeOverLabel:setString( getLang("105805",CC_SECTOA(endTime)) )
            self.ui.m_timeOverLabel:setVisible(true)
        else
            self.ui.m_timeOverLabel:setVisible(false)
        end
        return true  --活动进行了特殊处理
    end
    return false
end

function ActivityNpcListCell:update(dt)
    local isSpecialAct = self:updateSpecialActivity(self.m_id)
    if isSpecialAct then
        return
    end
    local obj = ActivityController:call("getInstance"):call("getActObj", self.m_id)
    if (not obj) then
        return
    end
    self.ui.m_timeOverLabel:setString(obj:call("getGameTickStr"))
    local stageObj = obj:call("getCurActivityStageAndLeftTime")
    local case_cond = stageObj.curStage
    if (case_cond == ActivityStage.ActivityStage_Running) then
        self.ui.m_timeOverLabel:setColor(cc.c3b(93,207,0))
    elseif (case_cond == ActivityStage.ActivityStage_Comming) then
        self.ui.m_timeOverLabel:setColor(cc.c3b(255,150,0))
    elseif (case_cond == ActivityStage.ActivityStage_Preparing) then
        self.ui.m_timeOverLabel:setColor(cc.c3b(155,150,146))
    else
        self.ui.m_timeOverLabel:setColor(cc.c3b(93,207,0))
    end
end

function ActivityNpcListCell:onEnter()
    self.ui.m_touchlayer:setTouchEnabled(true)
    self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:update(dt) end, 1, false)
    self:update(0)
end

function ActivityNpcListCell:onExit()
    self.ui.m_touchlayer:setTouchEnabled(false)
    self:getScheduler():unscheduleScriptEntry(self.m_entryId)
end


function ActivityNpcListCell:onTouchBegan(x, y)
    self.m_startTouchPt = cc.p(x, y)
    if not self:isVisible(true) or not isTouchInside(self.ui.m_touchlayer, x, y)
        or isTouchInside(self.ui.m_iconListNode,x,y) or (not isTouchInside(self.m_tableView, x, y)) then
        return false
    end
    if (self.ui.m_touchlayer and isTouchInside(self.ui.m_touchlayer, x, y)) then
        self:setScale(0.98)
        return true
    end
    return false
end

function ActivityNpcListCell:onTouchMoved(x, y)
    
end
function ActivityNpcListCell:onTouchEnded(x, y)
    self:setScale(1)
    local dis = 10
    if (cc.pGetDistance(self.m_startTouchPt, cc.p(x, y)) > dis) then
        return
    end
    PopupViewController:call("removeAllPopupView")
    -- 打开界面
    ActivityController.getInstance():shouActUIById(self.m_id)
end

return ActivityNpcListCell