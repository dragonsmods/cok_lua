--[[
    活动npc列表界面
]]

local ActivityNpcListView = class("ActivityNpcListView", PopupBaseView)
ActivityNpcListView.__index = ActivityNpcListView

local DailyActivityManager = require("game.dailyActivity.DailyActivityManager")
local controller = require("game.ActivityNpc.ActivityNpcController").getInstance()

function ActivityNpcListView:ctor()
end

function ActivityNpcListView:create(act_type)
    local view = ActivityNpcListView.new()
    Drequire("game.ActivityNpc.ActivityNpcListView_ui"):create(view)
    if view:initView(act_type) == false then
        return nil
    end
    return view
end

function ActivityNpcListView:initView(act_type)
    self.ui.m_titleLabel:setString(getLang("667600")) -- 667600=NPC活动
    self.ui.m_introLabel:setString(getLang("667601")) -- 667601=百姓在城内举办了一些活动，领主大人可以前往参加！
    CCLoadSprite:call("doResourceByCommonIndex", 500, true)
    CCLoadSprite:call("doResourceByCommonIndex", 502, true)
    CCLoadSprite:call("doResourceByCommonIndex", 506, true)
    CCLoadSprite:call("loadDynamicResourceByName", "activity_res")

    if CCCommonUtilsForLua:isIosAndroidPad() then
        self:setScale(2)
    end

    self.m_act_type = act_type

    self.ui.m_listTableView:setScale(0.85)
    self.ui.m_listTableView:setPosition(cc.p(-320, -440))
    self:initActivityView()
    self.ui:setTableViewDataSource("m_listTableView", self.m_allActivityTbl)

    return true
end

function ActivityNpcListView:initActivityView()
    -- 数据
    self.m_data = controller:getOpeningActivityIdByType(self.m_act_type)
    -- dump(self.m_data, "----------- self.m_data")
    if (not self.m_data) then
        return false
    end
    if #self.m_data == 0 then
        return
    end
    self.m_nowActivityTbl = {} -- 当前活动
    self.m_nextActivityTbl = {} -- 即将开始

    -- 主城等级和荣耀等级
    local v_mainCityLv = FunBuildController:call("getMainCityLv") + FunBuildController:call("getMainCityHonorLv")
    for k,value in pairs(self.m_data) do
        local v = tostring(value)
        local obj = ActivityController:call("getInstance"):call("getActObj", v)
        if obj then
            local v_isAdd = true
            local actId = obj:getProperty('id')
            if actId then
                local v_lvShow = CCCommonUtilsForLua:getPropByIdGroup('activity_panel', actId , "lv_show")
                local v_lvShowInt = tonumber(v_lvShow) or 0
                -- 当主城等级大于等于配置表里的lv_show时，才添加活动
                v_isAdd = tonumber(v_mainCityLv) >= v_lvShowInt

                -- if not isFunOpenByKey('general_draw_show') then
                --     local is_general_draw = CCCommonUtilsForLua:getPropByIdGroup('activity_panel', actId , "is_general_draw")
                --     if is_general_draw == '1' then
                --         v_isAdd = false
                --     end
                -- end
            end
            if v_isAdd then
                local isSpeAct = DailyActivityManager.isSpecialActivity(v)
                local stageObj = obj:call("getCurActivityStageAndLeftTime")
                local case_cond = stageObj.curStage
                if (not isSpeAct) then
                    if (case_cond == ActivityStage.ActivityStage_Running) then
                        table.insert(self.m_nowActivityTbl , v)
                    else
                        table.insert(self.m_nextActivityTbl , v)
                    end
                end
            end
        end
    end

    DailyActivityManager.addSpecialActivities(self.m_nowActivityTbl)

    --推荐排序
    function sortByRecommend(a,b)
        if a ~= b then
            local objA = ActivityController:call("getInstance"):call("getActObj", a)
            local objB = ActivityController:call("getInstance"):call("getActObj", b)
            if objA and objB then
                local recommendA = objA:getProperty("recommend")
                local recommendB = objB:getProperty("recommend")
                local endTimeA = objA:getProperty("endTime")
                local endTimeB = objB:getProperty("endTime")
                if (recommendA == 1 and recommendB == 1 ) or (recommendA == 0 and recommendB == 0 ) then
                    return endTimeA < endTimeB
                elseif recommendA == 1 and recommendB == 0 then
                    return true
                elseif recommendA == 0 and recommendB == 1 then
                    return false
                end
            end
        end
        return false
    end
    table.sort(self.m_nowActivityTbl,sortByRecommend)

    --正在进行和即将开启放在一起
    self.m_allActivityTbl = {}
    for k, v in ipairs(self.m_nowActivityTbl) do
        local data = {activityId = v, tableView = self.ui.m_listTableView}
        table.insert(self.m_allActivityTbl, data)
    end

    for k, v in ipairs(self.m_nextActivityTbl) do
        local data = {activityId = v, tableView = self.ui.m_listTableView}
        table.insert(self.m_allActivityTbl, data)
    end

    -- 获取活动的详细信息 请求后台
    ActivityController:call("getInstance"):call("getActivityDetailInfo")
    self.m_startTouchPt = cc.p(0,0)
end

function ActivityNpcListView:onGetDragonPlayoffDataCallBack(ref)
    local info = ref
    if (not info or info:objectForKey("errorCode")) then
        return
    end
    local dic = CCDictionary:create()
    local state = info:valueForKey("state"):intValue()
    local turns = info:valueForKey("turns"):intValue()
    if (state<2 or state>6) then 
        dic:setObject(CCString:create("DragonPlayoffView"), "name")
    else
        if (turns<4) then 
            dic:setObject(CCString:create("DragonPlayoffAgainstView"), "name")
        else
            dic:setObject(CCString:create("DragonPlayoffKnockView"), "name")
        end
    end
    LuaController:call("openPopViewInLua", dic)
end

function ActivityNpcListView:onEnter()
    registerScriptObserver(self, self.onGetDragonPlayoffDataCallBack, "MSG_DRAGON_PLAYOFF_TURNS_COMMAND_BACK")

    local function callback1(param) self:refreshView(param) end
    local handler1 = self:registerHandler(callback1)
    CCSafeNotificationCenter:call("registerScriptObserver", self, handler1, "MSG_DRAGON_PLAYOFF_TURNS_COMMAND_BACK")
end

function ActivityNpcListView:onExit()
    CCSafeNotificationCenter:unregisterScriptObserver(self, "MSG_DRAGON_PLAYOFF_TURNS_COMMAND_BACK")
    CCSafeNotificationCenter:call("unregisterScriptObserver", self, "MSG_DRAGON_PLAYOFF_TURNS_COMMAND_BACK")
    --add by shp
    require("game.dailyActivity.DailyActivityManager").unsignActivitys()
end

function ActivityNpcListView:checkOpen()
    if CCCommonUtilsForLua:isFunOpenByKey("WorldCup_entrance") then
        self:getDataById("57451")

        local _obj57451 = ActivityController:call("getActObj", "57451")
        if _obj57451 then
            _obj57451:requestActivityDetail()
        end
    end
end

function ActivityNpcListView:getDataById( actId )
    local config = CCCommonUtilsForLua:getGroupByKey("cross_battlefield_UI")
    local configData = nil
    for _, data in pairs(config) do
        if data.activity_id == actId then
            configData = data
        end
    end

    local obj = ActivityController:call("getActObj", actId)
    local nowtime = tonumber(GlobalData:call("getWorldTime"))
    local endTime=0;
    local state=-1;
    local tbl= {}
    if nil ~= obj then
        local stageObj = obj:call("getCurActivityStageAndLeftTime")
        local case_cond = 99
        if stageObj and stageObj.curStage then
            case_cond = stageObj.curStage
        end

        local sT = tonumber(obj:getProperty("startTime"))
        local eT = tonumber(obj:getProperty("endTime"))
        if nowtime >= sT  and nowtime < eT then
            endTime=eT
        elseif nowtime < sT then
            endTime=sT
        else
            endTime=0
        end

        tbl.actId = actId
        tbl.state = case_cond
        tbl.endTime = endTime
        tbl.configData = configData
        table.insert(self.centerDataArr, tbl)
    end
end

function ActivityNpcListView:getDataByIdNew( configData )
    local actId = configData.activity_id
    local obj = ActivityController:call("getActObj", actId)
    local nowtime = tonumber(GlobalData:call("getWorldTime"))
    local endTime=0;
    local state=-1;
    local tbl= {}
    if nil ~= obj then
        local stageObj = obj:call("getCurActivityStageAndLeftTime")
        local case_cond = 99
        if stageObj and stageObj.curStage then
            case_cond = stageObj.curStage
        end

        local sT = tonumber(obj:getProperty("startTime"))
        local eT = tonumber(obj:getProperty("endTime"))
        if nowtime >= sT  and nowtime < eT then
            endTime=eT
        elseif nowtime < sT then
            endTime=sT
        else
            endTime=0
        end

        tbl.actId = actId
        tbl.state = case_cond
        tbl.endTime = endTime
        tbl.configData = configData
        -- tbl.permanent = ("1" == configData.permanent)
        table.insert(self.centerDataArr, tbl)

        if obj.requestActivityDetail then
            obj:requestActivityDetail()
        else
            obj:call("requestActivityDetail")
        end
    end

end

function ActivityNpcListView:refreshView( params )
    local tbl = dictToLuaTable(params)
    -- dump(tbl, "ActivityNpcListView:refreshView tbl~~~")

    if tbl.state and tbl.turns then
        local state=tonumber(tbl.state) or 0
        local turns=tonumber(tbl.turns) or 0
        if state<2 or state>6 then
            local dict = CCDictionary:create()
            dict:setObject(CCString:create("DragonPlayoffView"), "name")
            LuaController:call("openPopViewInLua", dict)
        else
            if turns<4 then
                local dict = CCDictionary:create()
                dict:setObject(CCString:create("DragonPlayoffAgainstView"), "name")
                LuaController:call("openPopViewInLua", dict)
            else
                local dict = CCDictionary:create()
                dict:setObject(CCString:create("DragonPlayoffKnockView"), "name")
                LuaController:call("openPopViewInLua", dict)
            end
        end
    end
end

function ActivityNpcListView:onCloseButtonClick()
    PopupViewController:call("removePopupView", self)
end

return ActivityNpcListView

