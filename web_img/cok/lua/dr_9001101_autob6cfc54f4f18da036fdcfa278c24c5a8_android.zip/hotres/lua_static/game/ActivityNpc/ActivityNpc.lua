--[[
    活动npc城内动画
]]

local BUBBLE_TAG = 1000

local ActivityNpc = class("ActivityNpc",
    function()
        return cc.Layer:create()
    end
)
ActivityNpc.__index = ActivityNpc

local ActivityNpcCtrlIns = require("game.ActivityNpc.ActivityNpcController").getInstance()

function ActivityNpc.create(type)
    local view = ActivityNpc.new()
    if view:initView(type)then
        return view
    end
    return nil
end

function ActivityNpc:initView(type)
    self.m_act_type = type
    self.m_opening_act = ActivityNpcCtrlIns:getOpeningActivityMapByType(self.m_act_type)
    self.m_index = 1
    self.touchnodeAngel = cc.Node:create()
    self.touchnodeAngel:setAnchorPoint(0.5, 0.5)
    self.touchnodeAngel:setContentSize(160, 160)
    self:addChild(self.touchnodeAngel)

    self.m_nodeRoot = cc.Node:create()
    self:addChild(self.m_nodeRoot)

    local function onNodeEvent(event)
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(onNodeEvent)

    self.startTouchPt = cc.p(0, 0)
    local function touchHandle(eventType, x, y)
        if eventType == "began" then
            return self:onTouchBegan(x, y)
        elseif eventType == "moved" then
        else
            self:onTouchEnded(x, y)
        end
    end
    self:registerScriptTouchHandler(touchHandle)
    self:setTouchEnabled(true)
    self:setSwallowsTouches(false)

    self:setLocalZOrder(2000)
    self:updateUI()
    self:setAnchorPoint(0, 0)
    self:setContentSize(cc.size(0, 0))

    return true
end

function ActivityNpc:onEnter()
    registerScriptObserver(self, self.updateUI, 'msg.activity.init')
    self:resetScheduler()
end

function ActivityNpc:onExit()
    unregisterScriptObserver(self, "msg.activity.init")
    self:removeScheduler()
end

function ActivityNpc:updateUI()
    if self.m_opening_act and #self.m_opening_act > 0 then
        self:setVisible(true)
        self.m_nodeRoot:removeAllChildren()

        local _npcData = ActivityNpcCtrlIns:getNpcData(self.m_act_type)
        CCLoadSprite:call("loadDynamicResourceByName", _npcData.dynamicRes)
        -- Dprint("ActivityNpc:updateUI ", _npcData.x, _npcData.y, _npcData.scale, _npcData.dynamicRes)
        --骨骼动画
        local utils = cc.FileUtils:getInstance()
        local wpath = utils:getWritablePath()
        local dpath = wpath .. "dresource/"
        if DynamicResourceController2:call("checkDynamicResource", _npcData.dynamicRes) == true then
            local json = dpath .. _npcData.json
            local atlas = dpath .. _npcData.atlas
            if utils:isFileExist(json) and utils:isFileExist(atlas) then
                local animationObj = IFSkeletonAnimation:call("create", json, atlas)
                if nil ~= animationObj then
                    animationObj:setToSetupPose()
                    animationObj:setAnimation(0, _npcData.action_name, true)
                    animationObj:setScaleX(-_npcData.scale)
                    self.m_nodeRoot:addChild(animationObj)
                end
            end

            -- 头顶气泡
            self:onEnterFrame()
        end

        -- 默认图
        if self.m_nodeRoot:getChildrenCount() == 0 then
            local _icon = CCLoadSprite:createSprite("icon_equip.png")
            if _icon then
                _icon:setPosition(cc.p(0, 0))
                self.m_nodeRoot:addChild(_icon)
            end
        end

        self:setPosition(cc.p( _npcData.x, _npcData.y))
    else
        self:setVisible(false)
    end
end

function ActivityNpc:resetScheduler()
    self:removeScheduler()
    self:onEnterFrame()
    self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(function() self:onEnterFrame() end, 5, false)
end

function ActivityNpc:removeScheduler()
    if self.entry then
        cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
        self.entry = nil
    end
end

function ActivityNpc:onEnterFrame()
    self.m_bubbleBg = nil
    self.m_nodeRoot:removeChildByTag(BUBBLE_TAG)

    if self.m_index > #self.m_opening_act then
        self.m_index = 1
    end

    self.m_act_data = self.m_opening_act[self.m_index]
    if self.m_act_data and self.m_act_data.controller.createBubble then
        local node, bubbleCheckImg = self.m_act_data.controller:createBubble()
        if node then
            node:setTag(BUBBLE_TAG)
            self.m_nodeRoot:addChild(node)
            self.m_bubbleBg = bubbleCheckImg -- 用于头像响应点击的节点
        end
    end

    self.m_index = self.m_index + 1
end


function ActivityNpc:onTouchBegan(x, y)
    if SceneController:call("isHFViewPortModel") then
        return false
    end

    self.m_touchType = 0
    self.startTouchPt = cc.p(x, y)
    if self.m_nodeRoot and self.m_nodeRoot:isVisible() and self.touchnodeAngel then
        if isTouchInside(self.touchnodeAngel, x ,y) then
            self.m_touchType = 1
            return true
        end
        if isTouchInside(self.m_bubbleBg, x ,y) then
            -- self.m_bubbleBg:stopAllActions()
            -- -- self.m_bubbleBg:setVisible(false)
            self.m_touchType = 2
            return true
        end
    end

    return false
end

function ActivityNpc:onTouchEnded(x, y)
    -- 判断点击或者拖动，如果是拖动，则不打开界面
    if cc.pGetDistance(self.startTouchPt, cc.p(x, y)) <= 10 then
        if self.m_opening_act and #self.m_opening_act > 0 then
            if #self.m_opening_act == 1 then
                local act_data = self.m_opening_act[1]
                if act_data and act_data.controller and act_data.controller:isOpen() then
                    act_data.controller:fireEventRef("openUI")
                else
                    CCCommonUtilsForLua:call("flyHint", "", "", getLang("146313"))    --146313=功能暂未开放，敬请期待！
                end
            else
                -- 打开界面
                if self.m_touchType == 2 and self.m_act_data then
                    if self.m_act_data and self.m_act_data.controller and self.m_act_data.controller:isOpen() then
                        self.m_act_data.controller:fireEventRef("openUI")
                    else
                        CCCommonUtilsForLua:call("flyHint", "", "", getLang("146313"))    --146313=功能暂未开放，敬请期待！
                    end
                else
                    ActivityNpcCtrlIns:openActivityNpcView(self.m_act_type)
                end
            end
        else
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("146313"))    --146313=功能暂未开放，敬请期待！
        end
    end
end

return ActivityNpc





