--[[
    活动npc控制类
]]

ActivityNpcController = class("ActivityNpcController")

local __instance = nil
function ActivityNpcController.getInstance(  )
    if nil == __instance then
        __instance = ActivityNpcController.new()
    end
    return __instance
end

function ActivityNpcController:ctor(  )
    self.m_activity_npc_data = {
        {
            type = 1,
            -- time_event_npc = "20600005",
            dynamicRes = "Npc_Angel_face",
            json = "Npc_Angel_face.json",
            atlas = "sk_Npc_Angel_face.atlas",
            action_name = "dj",
            posArr = {"813,1337", "960,1220", "560,1736", "620,1500", "1005,1170"},
            activity_map = {
                -- {
                --     act_id = 57451,
                --     controller = require("game.QueenWorldCup.QueenWorldCupController").getInstance()
                -- },
                {
                    act_id = 57153,
                    controller = require("game.ActivityNpc.GoldBoxNpcController").getInstance(),
                },
            }
        },
        {
            type = 2,
            time_event_npc = "20600001",
            dynamicRes = "TrainingTroop_face",
            json = "trainingTroop.json",
            atlas = "sk_TrainingTroopSpine_face.atlas",
            action_name = "animation",
            posArr = {"350,950", "900,1550", "200,1550", "600,1750", "1904, 574"},
            activity_map = {
                {
                    act_id = 57340, -- 军团集结
                    controller = require('game.Training.troops.TrainingTroopsController').getInstance(),
                },
                {
                    act_id = 57359, -- 文明堡垒限时
                    controller = require('game.civilization.CivilizationTimeLimited.CivilizationTimeLimitedController').getInstance(),
                },
                {
                    act_id = 57370, -- 消耗士兵排行榜活动
                    controller = COSDataController.getInstance(),
                },
                {
                    act_id = 57405, -- Alliance Kill Monster Activity
                    controller = require("game.ActivityNpc.QuickKillMonsterNpcController").getInstance(),
                },
                {
                    act_id = 5740501, -- Alliance Kill Monster Activity
                    controller = require("game.ActivityNpc.QuickKillMonsterNpcController").getInstance(),
                },
                -- {
                --     act_id = 57473, -- 商旅活动
                --     controller = require("game.commercialDarts.CommercialController").getInstance()
                -- },
            }
        }
    }
end

function ActivityNpcController:createAllActivityNpc(touchLayer)
    local type_base = 10000000
    for key, value in pairs(self.m_activity_npc_data) do
        if touchLayer:getChildByTag(type_base+value.type) then
            touchLayer:removeChildByTag(type_base+value.type)
        end
        local _npc = require("game.ActivityNpc.ActivityNpcController").getInstance():createNpcByType(value.type)
        if _npc then
            touchLayer:addChild(_npc)
            _npc:setTag(type_base+value.type)
        end
    end
end

-- 已开启活动
function ActivityNpcController:getOpeningActivityMapByType(type)
    if self.m_activity_npc_data[type] then
        local npc_arr = {}
        local data_map = self.m_activity_npc_data[type].activity_map or {}
        for key, value in ipairs(data_map) do
            if value.controller and value.controller:isOpen() then
                table.insert(npc_arr, value)
            end
        end
        return npc_arr
    end
end

function ActivityNpcController:getOpeningActivityIdByType(type)
    if self.m_activity_npc_data[type] then
        local npc_arr = {}
        local data_map = self.m_activity_npc_data[type].activity_map or {}
        for key, value in ipairs(data_map) do
            if value.controller and value.controller:isOpen() then
                table.insert(npc_arr, value.act_id)
            end
        end
        return npc_arr
    end
end

function ActivityNpcController:getActivityDataByType(type)
    return self.m_activity_npc_data[type]
end

function ActivityNpcController:getActivityById(type, act_id)
    if self.m_activity_npc_data[type] then
        local data_map = self.m_activity_npc_data[type].activity_map or {}
        for key, value in ipairs(data_map) do
            if value.act_id == act_id and  value.controller and value.controller:isOpen() then
                return value
            end
        end
    end
end

-- 创建NPC
function ActivityNpcController:createNpcByType(type)
    return Drequire("game.ActivityNpc.ActivityNpc").create(type)
end

-- 获取npc的坐标和缩放倍数
function ActivityNpcController:getNpcData(type)
    local data = self:getActivityDataByType(type)
    if data then    
        local _x = -100
        local _y = -100

        local _raceType = CCCommonUtilsForLua:call("RACETYPE")
        local _pos = nil
        if data.time_event_npc then
            if _raceType == RACE_TYPE_LONG_YI then
                _pos = CCCommonUtilsForLua:call("getPropByIdGroup", "time_event_npc", data.time_event_npc, "npc_position_longyi") 
            elseif _raceType == RACE_TYPE_WEI_JING then
                _pos = CCCommonUtilsForLua:call("getPropByIdGroup", "time_event_npc", data.time_event_npc, "npc_position_weijing") 
            elseif _raceType == RACE_TYPE_DA_HE then
                _pos = CCCommonUtilsForLua:call("getPropByIdGroup", "time_event_npc", data.time_event_npc, "npc_position_dahe") 
            elseif _raceType == RACE_TYPE_HUA_XIA then
                _pos = CCCommonUtilsForLua:call("getPropByIdGroup", "time_event_npc", data.time_event_npc, "npc_position_huaxia") 
            elseif _raceType == RACE_TYPE_ARAB then
                _pos = CCCommonUtilsForLua:call("getPropByIdGroup", "time_event_npc", data.time_event_npc, "npc_position_arab") 
            end
        end

        local posArr = data.posArr
        if _pos == "" then
            _pos = posArr[_raceType + 1]
        end

        if _pos then
            local _xy = string.split(_pos, ",")
            _x = tonumber(_xy[1]) or 0
            _y = tonumber(_xy[2]) or 0
        end

        local _xmlScale = CCCommonUtilsForLua:call("getPropByIdGroup", "time_event_npc", data.time_event_npc, "scale")
        local _scale = tonumber(_xmlScale) or 1

        local _xmlDynamicRes = CCCommonUtilsForLua:call("getPropByIdGroup", "time_event_npc", data.time_event_npc, "dynamicRes")
        local _dynamicRes = data.dynamicRes
        return {x = _x, y = _y, scale = _scale, xmlDynamicRes = _xmlDynamicRes, dynamicRes = _dynamicRes, json = data.json, atlas = data.atlas, action_name = data.action_name}
    end
end

function ActivityNpcController:openActivityNpcView(type)
    local view = Drequire("game.ActivityNpc.ActivityNpcListView"):create(type)
    PopupViewController:call("addPopupView", view)
end

return ActivityNpcController