--[[
    黄金宝箱活动npc控制类
]]

GoldBoxNpcController = class("GoldBoxNpcController")

local __instance = nil
function GoldBoxNpcController.getInstance(  )
    if nil == __instance then
        __instance = GoldBoxNpcController.new()
    end
    return __instance
end

function GoldBoxNpcController:ctor()
    self:refreshData()
end

function GoldBoxNpcController:isOpen()
    local canCreate = false
    local now = LuaController:call("getWorldTime")
    local goldBoxEndTime = tonumber(ActivityController:call("getInstance"):getProperty("goldBoxEndTime"))
    local rewardSendTime = 0
    local xmlData = CCCommonUtilsForLua:getGroupByKey("golden_roulette")
    for k,v in pairs(xmlData) do
        if v.rewardSendTime and v.rewardSendTime ~= "" then
            rewardSendTime = tonumber(v.rewardSendTime)
            break
        end
    end

    if rewardSendTime and goldBoxEndTime and (now < goldBoxEndTime + rewardSendTime * 60) then
        canCreate = true
    end

    if (require("game.dragonWorldCup.DragonWorldCupManager").isDragonGlobalServer()) then
        canCreate = false
    end

    return canCreate
end

function GoldBoxNpcController:fireEventRef()
    if self:checkCanOpenActivity() then
        if isCrossServerNow() then
            LuaController:flyHint("", "", getLang("164891"))   --跨服状态,不能开启
            return
        end
        local lua_path = "game.CommonPopup.GoldBoxView"
        package.loaded[lua_path] = nil
        local view = require(lua_path):create("57153")
        PopupViewController:addPopupInView(view)
    elseif self:checkIsInEndRankTime() then 
        local lua_path = "game.CommonPopup.GoldBoxEndRankView"
        package.loaded[lua_path] = nil
        local view = require(lua_path):create()
        PopupViewController:addPopupInView(view)
    else
        LuaController:flyHint("","",getLang("105801"))
    end
end

function GoldBoxNpcController:refreshData()
    self.m_id = "57153"
    self.m_endTime = 0
    local now = LuaController:call("getWorldTime")
    local obj = ActivityController:call("getInstance"):call("getActObj", self.m_id)
    if obj and obj:getProperty("endTime") then
        self.m_endTime = tonumber(obj:getProperty("endTime"))
    end
    if self.m_endTime == 0 then
        ActivityController:call("getInstance"):call("getActivityDetailInfo")
    end

    --结束持续时间
    self.m_rewardSendTime = 0
    local xmlData = CCCommonUtilsForLua:getGroupByKey("golden_roulette")
    for k,v in pairs(xmlData) do
        if v.rewardSendTime and v.rewardSendTime ~= "" then
            self.m_rewardSendTime = tonumber(v.rewardSendTime)
            break
        end
    end
    --宝箱结束时间
    self.m_goldBoxEndTime = ActivityController:call("getInstance"):getProperty("goldBoxEndTime")
end

function GoldBoxNpcController:checkCanOpenActivity()
    self:refreshData()
    local canOpen = false
      if self.m_endTime > 0 then
          local now = LuaController:call("getWorldTime")
          if now < self.m_endTime then
            canOpen = true
          end
    else
        local now = LuaController:call("getWorldTime")
        local obj = ActivityController:call("getInstance"):call("getActObj", self.m_id)
        if obj and obj:getProperty("endTime") then
            self.m_endTime = tonumber(obj:getProperty("endTime"))
        end
    end

      return canOpen
end

function GoldBoxNpcController:createBubble()
    local nodeBtn = cc.Node:create()

    local btn = CCLoadSprite:call("createSprite", "but_03.png")
    btn:setAnchorPoint(cc.p(0.5, 0))
    btn:setPositionY(125)
    nodeBtn:addChild(btn)
    btn:setScale(1.5)

    local iconName = "daily_shortmen.png"
    local iconSpr = CCLoadSprite:createSprite(iconName)
    if iconSpr then
        iconSpr:setPositionY(180)
        iconSpr:setAnchorPoint(0.5,0)
        nodeBtn:addChild(iconSpr)
        iconSpr:setScale(0.8)
    end

    nodeBtn:setScale(0.7)
    return nodeBtn, btn
end

return GoldBoxNpcController