--部队旗帜
local BuildFlagBtn = class("BuildFlagBtn", Drequire("game.buildingBtns.SpeBuildingBtn"))

function BuildFlagBtn:create(param)
    local btn = BuildFlagBtn.new(param)
    btn:initBtn()    
    return btn
end

function BuildFlagBtn:initBtn() 
    self.param:setObject(CCString:create(getLang("108557")), "title")  
    --部队详情
    local callback1 = function()
        self:hideSelf()
        local view = Drequire("game.soldier.NewTroopsView"):create(0)
	    PopupViewController:addPopupInView(view)
    end
    self:addBtn("btn_Lord_information.png","169015",callback1)

    
    if isFunOpenByKey('formation_train') and FunOpenController:isShow("fun_formation") then
        --新阵法
        local ctrl = FormationTrainCtr:getInstance()
        if ctrl:checkFTLevelOpen() then
            if DynamicResourceController2:call("checkDynamicResource", "FormationTrain_face") == false then
                DynamicResourceController2:call("bringFront", "FormationTrain_face")
                -- E100091=领主大人，资源下载中，请稍后尝试操作。
                -- CCCommonUtilsForLua:call("flyHint", "", "", getLang("E100091"))
                -- return false
            end
            CCLoadSprite:call("loadDynamicResourceByName", "FormationTrain_face")
            local isLoadDone = ctrl:getBagModel():isLoadDone()--数据是否加载完成
            if not isLoadDone then
                --重新请求数据
                ctrl:getCmdManager():reqFormationTrainBag()
            end
            if isFunOpenByKey('new_formation_train') then
                --阵法
                self:addBtn("ft_btn_main.png","9700201",function (  )
                    self:hideSelf()
                    if not isLoadDone then
                        CCCommonUtilsForLua:call("flyHint", "", "", getLang("E100091"))
                        return
                    end
                    ctrl:jumpView('main')
                end)
            else
                --阵法总览（阵法背包）
                local callback2 = function()
                    self:hideSelf()
                    if not isLoadDone then
                        CCCommonUtilsForLua:call("flyHint", "", "", getLang("E100091"))
                        return
                    end
                    ctrl:jumpView('bag')
                end
                self:addBtn("ft_btn_bag.png","9711880",callback2)--9711880=阵法总览

                --阵法
                self:addBtn("ft_btn_main.png","9700201",function (  )
                    self:hideSelf()
                    if not isLoadDone then
                        CCCommonUtilsForLua:call("flyHint", "", "", getLang("E100091"))
                        return
                    end
                    ctrl:jumpView('main')
                end)

                --阵法演练（抽卡）
                self:addBtn("ft_btn_luck.png","9711904",function (  )--9711904=阵法演练
                    self:hideSelf()
                    if not isLoadDone then
                        CCCommonUtilsForLua:call("flyHint", "", "", getLang("E100091"))
                        return
                    end
                    ctrl:jumpView('luck')
                end)
            end
           
        end
    else
        if CCCommonUtilsForLua:isFunOpenByKey("aormation") then
            local callback2 = function()
                self:hideSelf()
                local view = Drequire("game.TacticalDeploy.TacticalDepMainView"):create()
                PopupViewController:addPopupInView(view)
            end
            self:addBtn("icon_battle_book.png","9700201",callback2)
        end
    end

    --士兵排行榜
    if isFunOpenByKey("soldier_theme_rank") and FunOpenController:isShow("fun_soldierRank") then
        CCLoadSprite:call("loadDynamicResourceByName", "armament_face")
        self:addBtn("shibingpaihangbang.png","9711475",function()
            self:hideSelf()
            local view = Drequire("game.soldier.soldierRank.SoldierRankView"):create()
            if view then
                PopupViewController:addPopupInView(view)
            end
        end)
    end
    --适配按钮位置
    self:adapt()
end

return BuildFlagBtn