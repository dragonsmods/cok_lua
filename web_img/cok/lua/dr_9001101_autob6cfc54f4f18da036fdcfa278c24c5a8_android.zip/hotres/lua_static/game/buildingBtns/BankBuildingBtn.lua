--银行
local BankBuildingBtn = class("BankBuildingBtn", Drequire("game.buildingBtns.BuildingAddBtn"))

function BankBuildingBtn:create(param)
    local btn = BankBuildingBtn.new(param)
    btn:initBtn()    
    return btn
end

function BankBuildingBtn:initBtn()
    self.buildKey = "438000"

    if isFunOpenByKey("functionopen") and FunOpenController:isShow("fun_investment") then
        self:addBtn({
            icon = "icon_investment.png",
            text = "149328", -- 149328=投资
            callback = function()
                BankController:getInstance():openBankView()
            end,
        })
    end

    if isFunOpenByKey("bank_finance_open") and FunOpenController:isShow("fun_selectedFinance") then        
        local callback4 = function()
            local buildKey = self.buildKey
            self:hideSelf()
            local view = Drequire("game.Bank_new.BankFinanceView"):create()
            PopupViewController:call("addPopupView", view)
        end
        self:addBtn({
            icon = "item676.png",
            text = "660922", -- 660922=精选理财
            callback = callback4,
        })
    end
end

return BankBuildingBtn
