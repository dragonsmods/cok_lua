local BuildingAddBtn = class("BuildingAddBtn", cc.Node)

local BuildingAddBtnTag = 686868
local BuildingAddBtnIcon = "bnt_02.png"

local fadeInTime = 0.27
local fadeOutTime = 0.16

-- 需要setTouchScaled(true)的类型
local UseScaleType = {
    [cc.CONTROL_EVENTTYPE_TOUCH_DOWN]  = 1,
--    [cc.CONTROL_EVENTTYPE_DRAG_INSIDE] = 2,
--    [cc.CONTROL_EVENTTYPE_DRAG_ENTER]  = 8,
}

local AllButtonEvent = {
    cc.CONTROL_EVENTTYPE_TOUCH_DOWN,
    cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE,
    cc.CONTROL_EVENTTYPE_TOUCH_UP_OUTSIDE,
    cc.CONTROL_EVENTTYPE_TOUCH_CANCEL,
}

-- 功能建筑按钮基类
-- 在C的按钮之后，继续追加按钮(偷懒的开发模式)
-- 任何问题联系***!!!

function BuildingAddBtn:ctor(param)
    self.param = param
    self.btnNum = 0
    self.manager = require("game.buildingBtns.BuildingBtnManager").getInstance()
    self:initBase()
end

-- 所有按钮都存储在btnList里面，然后全部返回给C里面，用于设置位置，
function BuildingAddBtn:initBase()
    self:setTag(BuildingAddBtnTag)
    self.btnList = {}
    self.btnKeyList = {}
    -- 暂时不考虑
    local effectStr = self.param:valueForKey("effectStr")
    if effectStr and effectStr.getCString then
        self.effectStr = effectStr:getCString()
    end
    -- self.effectIndex = self.effectIndex - 2

    registerNodeEventHandler(self)
end

-- icon, text,callback 前三个参数同BuildingBtn:addBtn,方便后期互转，最后一个tbl包含btnKey字符串，用于查找
function BuildingAddBtn:addBtn(param)
    local icon = param.icon
    local text = param.text
    local callback = param.callback
    if icon and text and callback then
        self.btnKey = param.btnKey or ""
        local btn = CCControlButton:create(CCLoadSprite:call("createScale9Sprite", BuildingAddBtnIcon))
        btn:setPreferredSize(cc.size(100, 100))
        btn:setScale(0.8)
        self:addBtnEvent(btn, callback)
        btn:setTag(666)
        btn:setTouchPriority(4) 

        local bg = CCLoadSprite:createSprite(BuildingAddBtnIcon)
        local icon = CCLoadSprite:createSprite(icon)
        icon:setTag(99)
        CCCommonUtilsForLua:call('setSpriteMaxSize', icon, 90, false)
        local txt = CCLabelIF:call("create1", getLang(text))
        txt:call("setColor", cc.c3b(254, 253, 212))
        txt:call("setFontSize", 20)
        txt:call("setAnchorPoint",ccp(0.5, 1))
        txt:call("setDimensions", cc.size(105, 75))
        txt:call("setHorizontalAlignment", cc.TEXT_ALIGNMENT_CENTER)
        txt:setPosition(cc.p(0, -35))

        local baseNode = cc.Node:create()
        baseNode:addChild(btn)
        baseNode:addChild(bg)
        baseNode:addChild(icon)
        baseNode:addChild(txt)
        if param.redpoint then
            local _sprRedPoint = CCLoadSprite:createSprite("unlock_tipPt.png")
            if _sprRedPoint then
                _sprRedPoint:setPosition(btn:getContentSize().width / 2 - 15, btn:getContentSize().height / 2 - 15)
                baseNode:addChild(_sprRedPoint)
            end
        end
        baseNode:setUseTouchScale(true)
        self:addChild(baseNode)
        self.btnList[#self.btnList + 1] = baseNode
        if self.btnKey then
            self.btnKeyList[self.btnKey] = baseNode
        end

        if self.btnKey ~= "" and self.btnKey == self.effectStr then
            self:addBtnEffect(baseNode)
        end
    end
    return 
end

function BuildingAddBtn:addBtnEvent(btn, callback)
    local function realCallback(pSender, event)
        pSender:getParent():setTouchScaled(UseScaleType[event] ~= nil)

        if event ~= cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE then
            return
        end

        callback(pSender, event)
    end
    
    for _, eventType in ipairs(AllButtonEvent) do
        btn:addHandleOfControlEvent(realCallback, eventType)
    end
end

function BuildingAddBtn:addBtnEffect(baseNode)
    if baseNode then
        local sp1 = CCLoadSprite:createSprite("build_btn_effect.png")
        local sp2 = CCLoadSprite:createSprite("build_btn_effect.png")
        sp1:setScale(1.8)
        sp1:setColor(cc.c3b(255, 169, 0))
        sp2:setScale(1.8)
        sp2:setColor(cc.c3b(255, 214, 0))
        sp2:setOpacity(180)

        local function runAction(sp)
            local fadeOut = cc.FadeOut:create(0.75)
            local fadeIn = cc.FadeIn:create(0.75)
            local seq = cc.Sequence:create(fadeOut, fadeIn)
            local forever = cc.RepeatForever:create(seq)
            sp:stopAllActions()
            sp:runAction(forever)
        end

        runAction(sp1)
        runAction(sp2)

        local effect = ParticleController:call("createParticle", "buildButton")
        baseNode:addChild(sp1)
        baseNode:addChild(sp2)
        baseNode:addChild(effect)
    end
end

function BuildingAddBtn:getBtnNum()
    return 0
end

function BuildingAddBtn:getBtnList()
    return self.btnList
end

function BuildingAddBtn:hideSelf()
    self:setVisible(false)
    self.manager:clearShowBtn()

    local imscene = ImperialScene:call("getInstance")
	if imscene then
		imscene:call("hideBuildBtnView")
    end
end

function BuildingAddBtn:showAni(param)
    local intObj = tolua.cast(param, "CCInteger")
	if param and intObj then
		local aniType = intObj:getValue()
        for i, btn in pairs(self.btnList) do
            self:playAni(btn, aniType)
        end

        if aniType == 1 then
            self.manager:clearShowBtn()
        end
    end
end

function BuildingAddBtn:playAni(node, aniType)
    if aniType == 0 then
        local fadeIn = cc.ScaleTo:create(fadeInTime, 1)
        local moveBy = cc.MoveBy:create(fadeInTime, ccp(0, -100))
        local spawn = cc.Spawn:create(fadeIn, moveBy)
        node:stopAllActions()
        node:setScale(0)
        node:runAction(spawn)
        node:setPositionY(node:getPositionY() + 100)
    else
        local fadeOut = cc.ScaleTo:create(fadeOutTime, 0)
        node:stopAllActions()
        node:setScale(1)
        node:runAction(fadeOut)
    end
end

-- function BuildingAddBtn:adjust4work(param)
--     local cbtnNum = param:valueForKey("num"):getCString()
--     if param and cbtnNum then
--         self:adapt4CBtnNum(tonumber(cbtnNum),param)
--     end
-- end

function BuildingAddBtn:onEnter()
    local function callback(param) self:showAni(param) end
    local handler = self:registerHandler(callback)
    CCSafeNotificationCenter:registerScriptObserver(self, handler, "msg_stop_questani")
    
    --建筑正在升级或者建筑功能队列正在工作
    -- local function callback2(param) self:adjust4work(param) end
    -- local handler2 = self:registerHandler(callback2)
    -- CCSafeNotificationCenter:registerScriptObserver(self, handler2, "msg_build_working")
    self:onEnter2()
end

function BuildingAddBtn:onExit()
    CCSafeNotificationCenter:unregisterScriptObserver(self, "msg_stop_questani")
    -- CCSafeNotificationCenter:unregisterScriptObserver(self, "msg_build_working")
    self:onExit2()
end

function BuildingAddBtn:getBtn(index)
    if self["btnNode" .. index] then
        return self["btnNode" .. index]:getChildByTag(666)
    end
end

function BuildingAddBtn:getGuideNodeByKey(key)
    if key then
        return self.btnKeyList[key]
    end
end

function BuildingAddBtn:onEnter2()
    dump("override me if necessary")
end

function BuildingAddBtn:onExit2()
    dump("override me if necessary")
end

--添加扩建按钮
function BuildingAddBtn:addExtensionBtn()
    local buildKey = self.param:valueForKey("buildKey"):intValue()
    if FunOpenController:isShow("fun_expand") and DataController.ExtensionDataController:checkBuildExtensionIsOpen(buildKey) then
        local openExtension = function()
            self:hideSelf()
            if FunOpenController:isUnlock("fun_expand", true) then
                DataController.ExtensionDataController:openMainView(buildKey)
                LogController:sendUserBehaviorEvent("building", 2, tostring(math.floor(buildKey / 1000)), "expand")
            end
        end
        self:addBtn({
            icon = "icon_buildExtension.png",
            text = "194000",
            callback = openExtension,
            btnKey = "buildExtension",
        })
    end
end

-- 添加自定义按钮
function BuildingAddBtn:addCustomBtn( conditionFunc,dynRes,iconName,defaultIcon,text,btnKey,clickFunc )
    if conditionFunc() then
        CCLoadSprite:call("loadDynamicResourceByName", dynRes)
        local _,def = utils.getSafeSprite( iconName, defaultIcon )
        iconName = def and defaultIcon or iconName
        self:addBtn({
            icon = iconName,
            text = text,
            callback = function (  )
                self:hideSelf()
                if clickFunc then
                    clickFunc()
                end
            end,
            btnKey = btnKey,
        })
    end
end

return BuildingAddBtn