local BuildingBtn = class("BuildingBtn", cc.Node)

local BuildingBtnTag = 686868
local BuildingBtnLimit = 4
local BuildingBtnIcon = "bnt_02.png"

local fadeInTime = 0.27
local fadeOutTime = 0.16

--按钮位置调整
local btnPosForNum = {
    [1] = {ccp(0,-16)},
    [2] = {ccp(-55,-6),ccp(55,-6)},
    [3] = {ccp(-107,6),ccp(0,-16),ccp(107,6)},
    [4] = {ccp(-156,40),ccp(-55,-6),ccp(55,-6),ccp(156,40)},
    [5] = {ccp(-200, 60),ccp(-107, 6),ccp(0,-16),ccp(107, 6),ccp(200, 60)},
    [6] = {ccp(-230, 95),ccp(-150, 35),ccp(-55, -6),ccp(55, -6),ccp(150, 35),ccp(230, 95)},
    [7] = {ccp(0,130),ccp(-150, 35),ccp(-55, -6),ccp(55, -6),ccp(150, 35),ccp(230, 95),ccp(-230,95)},
}

-- 需要setTouchScaled(true)的类型
local UseScaleType = {
    [cc.CONTROL_EVENTTYPE_TOUCH_DOWN]  = 1,
--    [cc.CONTROL_EVENTTYPE_DRAG_INSIDE] = 2,
--    [cc.CONTROL_EVENTTYPE_DRAG_ENTER]  = 8,
}

local AllButtonEvent = {
    cc.CONTROL_EVENTTYPE_TOUCH_DOWN,
    cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE,
    cc.CONTROL_EVENTTYPE_TOUCH_UP_OUTSIDE,
    cc.CONTROL_EVENTTYPE_TOUCH_CANCEL,
}

-- 功能建筑按钮基类
-- 排除详情和升级按钮,只添加功能按钮就行

-- btnNode1比较特效,一般为功能按钮,和建筑等级有关或者自身带队列
-- 例如四个兵营的训练按钮或者医院的治疗按钮
-- 当建筑正在升级或者工作的时候 此按钮会自己隐藏

-- 按钮添加请参考HospitalBtn.lua
-- 任何问题联系suhongping@elex-tech.com

function BuildingBtn:ctor(param)
    self.param = param
    self.btnNum = 0
    self.manager = require("game.buildingBtns.BuildingBtnManager").getInstance()
    self:initBase()
end

function BuildingBtn:initBase()
    self:setTag(BuildingBtnTag)
    self.btnNode1 = cc.Node:create()
    self.btnNode2 = cc.Node:create()
    self.btnNode3 = cc.Node:create()
    self.btnNode4 = cc.Node:create()

    self.btnNode1:setUseTouchScale(true)
    self.btnNode2:setUseTouchScale(true)
    self.btnNode3:setUseTouchScale(true)
    self.btnNode4:setUseTouchScale(true)

    self:addChild(self.btnNode1)
    self:addChild(self.btnNode2)
    self:addChild(self.btnNode3)
    self:addChild(self.btnNode4)

    self.effectIndex = self.param:valueForKey("effectIndex"):intValue()
    self.effectIndex = self.effectIndex - 2

    registerNodeEventHandler(self)
end

function BuildingBtn:addBtn(icon, text, callback, redpoint)
    local _index = -1
    if icon and text and callback then
        if self.btnNum < BuildingBtnLimit then
            self.btnNum = self.btnNum + 1

            local btn = CCControlButton:create(CCLoadSprite:call("createScale9Sprite", BuildingBtnIcon))
            btn:setPreferredSize(cc.size(100, 100))
            btn:setScale(0.8)
            self:addBtnEvent(btn, callback)
            btn:setTag(666)
            btn:setTouchPriority(4) 

            local bg = CCLoadSprite:createSprite(BuildingBtnIcon)
            local icon = CCLoadSprite:createSprite(icon)
            icon:setTag(99)
            CCCommonUtilsForLua:call('setSpriteMaxSize', icon, 96, false)
            local txt = CCLabelIF:call("create1", getLang(text))
            txt:call("setColor", cc.c3b(254, 253, 212))
            txt:call("setFontSize", 20)
            txt:call("setAnchorPoint",ccp(0.5, 1))
            txt:call("setDimensions", cc.size(105, 75))
            txt:call("setHorizontalAlignment", cc.TEXT_ALIGNMENT_CENTER)
            txt:setPosition(cc.p(0, -35))
            if self["btnNode" .. self.btnNum] then
                self["btnNode" .. self.btnNum]:addChild(btn)
                self["btnNode" .. self.btnNum]:addChild(bg)
                self["btnNode" .. self.btnNum]:addChild(icon)
                self["btnNode" .. self.btnNum]:addChild(txt)
                if redpoint then
                    local _sprRedPoint = CCLoadSprite:createSprite("unlock_tipPt.png")
                    if _sprRedPoint then
                        _sprRedPoint:setPosition(btn:getContentSize().width / 2 - 15, btn:getContentSize().height / 2 - 15)
                        self["btnNode" .. self.btnNum]:addChild(_sprRedPoint)
                    end
                end
                _index = self.btnNum
            end

            if self.btnNum == self.effectIndex then
                self:addBtnEffect(self.effectIndex)
            end
        end
    end
    return _index
end

function BuildingBtn:addBtnEvent(btn, callback)
    local function realCallback(pSender, event)
        pSender:getParent():setTouchScaled(UseScaleType[event] ~= nil)

        if event ~= cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE then
            return
        end

        callback(pSender, event)
    end
    
    for _, eventType in ipairs(AllButtonEvent) do
        btn:addHandleOfControlEvent(realCallback, eventType)
    end
end

function BuildingBtn:addBtnEffect(index)
    if self["btnNode" .. index] then
        local sp1 = CCLoadSprite:createSprite("build_btn_effect.png")
        local sp2 = CCLoadSprite:createSprite("build_btn_effect.png")
        sp1:setScale(1.8)
        sp1:setColor(cc.c3b(255, 169, 0))
        sp2:setScale(1.8)
        sp2:setColor(cc.c3b(255, 214, 0))
        sp2:setOpacity(180)

        local function runAction(sp)
            local fadeOut = cc.FadeOut:create(0.75)
            local fadeIn = cc.FadeIn:create(0.75)
            local seq = cc.Sequence:create(fadeOut, fadeIn)
            local forever = cc.RepeatForever:create(seq)
            sp:stopAllActions()
            sp:runAction(forever)
        end

        runAction(sp1)
        runAction(sp2)

        local effect = ParticleController:call("createParticle", "buildButton")
        self["btnNode" .. index]:addChild(sp1)
        self["btnNode" .. index]:addChild(sp2)
        self["btnNode" .. index]:addChild(effect)
    end
end

function BuildingBtn:getBtnNum()
    self.btnNum = 0
    for i = 1, 4 do
        if self["btnNode" .. i] and self["btnNode" .. i]:isVisible() and self["btnNode" .. i]:getChildrenCount() > 0 then
            self.btnNum = self.btnNum + 1
        end
    end
    return self.btnNum
end

function BuildingBtn:adapt()
    if self.btnNum == 1 then
        self.btnNode1:setPosition(107, 6)
    elseif self.btnNum == 2 then
        self.btnNode1:setPosition(52, -10)
        self.btnNode2:setPosition(156, 30)
    elseif self.btnNum == 3 then
        self.btnNode1:setPosition(0, -16) 
        self.btnNode2:setPosition(107, 6) 
        self.btnNode3:setPosition(200, 60)
    elseif self.btnNum == 4 then
        self.btnNode1:setPosition(-52, -10)
        self.btnNode2:setPosition(52, -10)
        self.btnNode3:setPosition(156, 30)
        self.btnNode4:setPosition(240, 110)
    end
end

function BuildingBtn:adapt4CBtnNum(num,param)
    --功能按钮隐藏 建筑正在升级或者工作
    local isShow = self.manager:getBtn1State(self.buildKey)
    self.btnNode1:setVisible(isShow)
    --按钮调整
    local c_node1 = param:objectForKey("Node1")
    local c_node2 = param:objectForKey("Node2")
    local add = isShow and 0 or -1

    local totalBtnNum = num + self.btnNum + add
    
    local posTbl = btnPosForNum[totalBtnNum]
    if c_node1 and c_node2 then
        c_node1:setPosition(posTbl[2])
        c_node2:setPosition(posTbl[1])
    end
    if num == 3 then
        local c_node3 = param:objectForKey("Node3")
        c_node3:setPosition(posTbl[3])
    end
    for i=1,self.btnNum do
        self["btnNode"..i]:setPosition(posTbl[i+num+add])
    end

end

function BuildingBtn:hideSelf()
    self:setVisible(false)
    self.manager:clearShowBtn()

    local imscene = ImperialScene:call("getInstance")
	if imscene then
		imscene:call("hideBuildBtnView")
    end
end

function BuildingBtn:showAni(param)
    local intObj = tolua.cast(param, "CCInteger")
	if param and intObj then
		local aniType = intObj:getValue()
        for index = 1, self.btnNum do
            self:playAni(self["btnNode" .. index], aniType)
        end

        if aniType == 1 then
            self.manager:clearShowBtn()
        end
    end
end

function BuildingBtn:playAni(node, aniType)
    if aniType == 0 then
        local fadeIn = cc.ScaleTo:create(fadeInTime, 1)
        local moveBy = cc.MoveBy:create(fadeInTime, ccp(0, -100))
        local spawn = cc.Spawn:create(fadeIn, moveBy)
        node:stopAllActions()
        node:setScale(0)
        node:runAction(spawn)
        node:setPositionY(node:getPositionY() + 100)
    else
        local fadeOut = cc.ScaleTo:create(fadeOutTime, 0)
        node:stopAllActions()
        node:setScale(1)
        node:runAction(fadeOut)
    end
end

function BuildingBtn:adjust4work(param)
    local cbtnNum = param:valueForKey("num"):getCString()
    if param and cbtnNum then
        self:adapt4CBtnNum(tonumber(cbtnNum),param)
    end
end

function BuildingBtn:onEnter()
    local function callback(param) self:showAni(param) end
    local handler = self:registerHandler(callback)
    CCSafeNotificationCenter:registerScriptObserver(self, handler, "msg_stop_questani")
    
    --建筑正在升级或者建筑功能队列正在工作
    local function callback2(param) self:adjust4work(param) end
    local handler2 = self:registerHandler(callback2)
    CCSafeNotificationCenter:registerScriptObserver(self, handler2, "msg_build_working")
    self:onEnter2()
end

function BuildingBtn:onExit()
    CCSafeNotificationCenter:unregisterScriptObserver(self, "msg_stop_questani")
    CCSafeNotificationCenter:unregisterScriptObserver(self, "msg_build_working")
    self:onExit2()
end

function BuildingBtn:addExtensionBtn()
    --扩建
    if DataController.ExtensionDataController:checkBuildExtensionIsOpen(self.buildKey) then
        local openExtension = function()
            self:hideSelf()
            DataController.ExtensionDataController:openMainView(self.buildKey)            
        end
        self:addBtn("icon_buildExtension.png","194000",openExtension)
    end
end

function BuildingBtn:getBtn(index)
    if self["btnNode" .. index] then
        return self["btnNode" .. index]:getChildByTag(666)
    end
end

function BuildingBtn:getGuideNodeByKey(key)
    dump("override me if necessary")
end

function BuildingBtn:onEnter2()
    dump("override me if necessary")
end

function BuildingBtn:onExit2()
    dump("override me if necessary")
end

return BuildingBtn