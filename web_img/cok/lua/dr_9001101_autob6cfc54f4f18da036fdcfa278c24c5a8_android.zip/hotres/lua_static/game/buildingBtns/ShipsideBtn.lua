-- @Author:fenghaibin 
-- @Date: 2020-06-01
-- @Description: 码头按钮

local ShipsideBtn = class("ShipsideBtn", Drequire("game.buildingBtns.SpeBuildingBtn"))

function ShipsideBtn:create(param)
    local btn = ShipsideBtn.new(param)
    btn:initBtn()    
    return btn
end

function ShipsideBtn:initBtn()
    -- 增加7日签到开关
    if CCCommonUtilsForLua:isFunOpenByKey("sign_7") then
        local openSevenDaySign = function()
            self:hideSelf()
            local dict = CCDictionary:create() 
            dict:setObject(CCString:create("PortActView"), "name")
            LuaController:call("openPopViewInLua", dict)
        end 
        self:addBtn("qiandao_icon.png", "133187", openSevenDaySign)
    end

    -- 超值好礼
    local k_verson = CCCommonUtilsForLua:getPropById("99022", "k1")
    local k_server = CCCommonUtilsForLua:getPropById("99022", "k1")
    -- 与c程序保持一直，屏蔽掉老功能
    if false and CCCommonUtilsForLua:call("checkVersion", k_verson) 
        and CCCommonUtilsForLua:call("checkServer", k_server) then
        local openSevenDayPayView = function()
            self:hideSelf()
            if not CCCommonUtilsForLua:isFunOpenByKey("luck_draw") then
                local lua_path = "game.LiBao.SevenDayPayView"
                package.loaded[lua_path] = nil
                local view = require(lua_path):create()
                PopupViewController:addPopupInView(view)
            else
                CActivityPopupUIManager:call("popupSevenDayPayView")
            end
        end 
        self:addBtn("7dayIcon.png", "9000029", openSevenDayPayView)    -- 9000029=超值好礼
    end

    -- 超值月度好礼
    local openMonthCardView = function()
        self:hideSelf()
        if CCCommonUtilsForLua:isFunOpenByKey("month_card") then
            CCCommonUtilsForLua.jumpToTarget(gtblGoType.integrateMainView_MonthCard)
        else
            local view = MonthCardView:call("create")
            PopupViewController:addPopupInView(view)
        end
    end 
    self:addBtn("monthcard_icon.png", "101283", openMonthCardView)

    -- 每月签到
    if FunOpenController:isShow("integrateSignIn") then
        if require('game.WelfareIntegrate.signIn.integrateSignInController'):checkOpen() then
            local openSignIn = function()
                self:hideSelf()
                CCCommonUtilsForLua.jumpToTarget( 7, "28" )
            end 
            self:addBtn("monthlyqiandao_icon.png", "9200259", openSignIn)    -- 9200259=每月签到
        end
    end

    -- 订阅
    if FunOpenController:isShow("fun_subscribe") then
        local ctl = require("game.LiBao.NewSubscribe.NewSubscribeMgr").getInstance()
        if ctl:isSubscribeOpen() then
            local openSubscribe = function()
                self:hideSelf()
                ctl:OpenView()
            end 
            local redConut = ctl:getRedDotCount()
            self:addBtn("subscribeIcon.png", "9400581", openSubscribe, redConut>0)    -- 9400581=订阅
        end
    end

    -- 永夜城
    if NightCityController:getInstance():isOpen() then
        self:addBtn("monthlyqiandao_icon.png", "52226936", function ()
            -- SceneController:call("gotoScene", SCENE_ID_NIGHTCITY)
            NightCityController:getInstance():gotoScene()
        end)
    end
    --漫游东大路 （开门）
    local EastRoadCtl = require("game.EastRoad.EastRoadCtl"):getInstance()
    if EastRoadCtl:isOpen() then
        local callBack = function ()
            self:hideSelf()
            EastRoadCtl:showPopView()
        end
        self:addBtn("EastRoad_icon.png", "52045259", callBack)
        self.guideIndex = self.btnNum
    end

    --适配按钮位置
    self:adapt()
end

function ShipsideBtn:getGuideNodeByKey(key)
    if key == "LUA_btn_EastRoad" and self.guideIndex then
        return self:getBtn(self.guideIndex)
    end
end

return ShipsideBtn