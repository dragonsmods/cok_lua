--英雄殿堂(不包含升级与详情按钮)
local HeroBuildingBtn = class("HeroBuildingBtn", Drequire("game.buildingBtns.BuildingAddBtn"))

function HeroBuildingBtn:create(param)
    local btn = HeroBuildingBtn.new(param)
    btn:initBtn()    
    return btn
end

function HeroBuildingBtn:initBtn()
    self.buildKey = "433000"
    --【Awen】首次引导只显示：信息、升级、英雄、招募
    local _isFirstGuide = false
    if GuideController:call("isInTutorial") then
        local _playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
        local _playerUid = _playerInfo:getProperty("uid")
        local _key = _playerUid .. "HeroBtnFirstGuide"
        if cc.UserDefault:getInstance():getBoolForKey(_key, false)==false then
            _isFirstGuide = true
            cc.UserDefault:getInstance():setBoolForKey(_key, true)
            cc.UserDefault:getInstance():flush()
        end
    end

    if isFunOpenByKey("functionopen") then
        -- 英雄试炼
        if FunOpenController:isShow("fun_heroTrials") then
            self:addBtn({
                icon = "icon_heroTower.png",
                text = "164836",    --164836=英雄试炼
                callback = function ()
                    self:hideSelf()
                    if FunOpenController:isUnlock("fun_heroTrials", true) then
                        local crossFightSrcServerId = GlobalData:call("getPlayerInfo"):getProperty("crossFightSrcServerId")
                        local selfServerId = GlobalData:call("getPlayerInfo"):getProperty("selfServerId")
                        local serverType = GlobalData:call("shared"):getProperty("serverType")

                        if (crossFightSrcServerId > 0 and crossFightSrcServerId ~= selfServerId) 
                        or serverType == ServerType.SERVER_BATTLE_FIELD 
                        or serverType == ServerType.SERVER_DRAGON_BATTLE 
                        or serverType == ServerType.SERVER_DRAGON_BATTLE_GLOBAL 
                        then
                            LuaController:flyHint("", "", getLang("137705"))  --137705=您当前处于跨服状态，无法使用该功能。
                        else
                            local dict = CCDictionary:create()
                            dict:setObject(CCString:create("HeroTowerHomeView"), "name")
                            LuaController:call("openPopViewInLua", dict)
                        end
                    end
                    LogController:sendUserBehaviorEvent("building", 2, self.buildKey, "heroTrials")
                end
            })
        end

        -- 英雄殿堂
        if FunOpenController:isShow("fun_hero") then
            local dict = CCDictionary:create()
            local HeroManager = require("game.hero.HeroManager")
            HeroManager.postIsHeroUnlockInList(dict)
            local heroRP = dict:valueForKey("unlock"):intValue()
            if heroRP == 0 and isFunOpenByKey("hero_avatar_chuzheng") then
                if require("game.hero.HeroSkinManager").getInstance():isShowHint() then
                    heroRP = 1
                end
            end
            self:addBtn({
                icon = "heroIcon.png",
                text = "169603",    --169603=英雄
                redpoint = heroRP > 0,
                callback = function ()
                    self:hideSelf()

                    if DynamicResourceController2:call("checkDynamicResource", "newHero") and 
                    not CCCommonUtilsForLua:call("isTmpZipFileExist", "newHero") then
                        local view = Drequire("game.hero.NewUI_v2.HeroListView"):create(1)
                        PopupViewController:call("addPopupInView", view)
                    else
                        LuaController:flyHint("", "", getLang("169633"))--169633=该功能正在下载中，请稍候
                    end
                    LogController:sendUserBehaviorEvent("building", 2, self.buildKey, "hero")
                end
            })
        end
    end
    
    -- 英雄招募
    if FunOpenController:isShow("fun_heroRecruitment") then
        local _icon = "icon_generalDraw.png"
        local _redpoint = false
        local _addType = 0
        if isFunOpenByKey("general_draw_new") then  -- 英雄多卡池招募
            _addType = 1
            local actIcon, actRP = require("game.hero.recruit.HeroRecruitController").getInstance():getTipConfig()
            if actIcon then
                _icon = actIcon
            end
            _redpoint = actRP > 0
        elseif isFunOpenByKey("general_draw") then
            _addType = 2
            local _dict = CCDictionary:create()
            HeroLuckDrawController:fireCommonEvent("hasFree", _dict)
            if _dict:objectForKey("actIcon") then
                _icon = _dict:valueForKey("actIcon"):getCString()
            end
            _redpoint = _dict:valueForKey("heroLuck"):intValue() == 1
        end

        if _addType > 0 then
            self:addBtn({
                icon = _icon,
                text = "169950",    --169950=英雄招募
                redpoint = _redpoint,
                callback = function ()
                    self:hideSelf()
                    CCCommonUtilsForLua.jumpToTarget( 7, "25" )
                    LogController:sendUserBehaviorEvent("building", 2, self.buildKey, "heroRecruitment")
                end
            })
        end
    end

    -- 招募之神
    if _isFirstGuide == false and CCCommonUtilsForLua:isFunOpenByKey("general_rank") and FunOpenController:isShow("fun_godRecruit") then        
        local callback4 = function()
            self:hideSelf()

            local view = Drequire("game.hero.NewUI_v2.HeroRecruitRankView"):create()
            PopupViewController:addPopupInView(view)
            LogController:sendUserBehaviorEvent("building", 2, self.buildKey, "recruitmentGod")
        end
        self:addBtn({
            icon = "tile_pop_icon9.png",
            text = "660001",    --660001=招募之神
            callback = callback4,
        })
        
    end
    --骑士之剑
    local sokControl = require('game.swordOfKnight.SwordOfKnightController').getInstance()
    if sokControl:checkIsOpenByType() then
        CCLoadSprite:call("loadDynamicResourceByName", "SwordOfKnight_face")
        self:addBtn({
            icon = "icon_knight_sword.png",
            text = "52015001",  --52015001=骑士之剑
            callback = function (  )
                sokControl:openMainView()
            end,
        })
    end
    --英雄信物
    local badgeControl = require('game.hero.badge.HeroBadgeController'):getInstance()
    if badgeControl:isOpenBadge() then
        badgeControl:checkBadgeData()
        CCLoadSprite:call("loadDynamicResourceByName", "hero_badge_face")
        CCLoadSprite:call("loadDynamicResourceByName", "hero_badge2_face")
        self:addBtn({
            icon = "hushenfu_entrance_icon.png",
            text = "671746",--671746=护身符
            callback = function (  )
                self:hideSelf()
                local view = Drequire('game.hero.badge.HeroBadgeBagView'):create()
                PopupViewController:addPopupInView(view)
            end,
        })
    end
end

return HeroBuildingBtn
