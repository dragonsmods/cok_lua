--城墙按钮
local CityWallBtn = class("MainCityFunBtn", Drequire("game.buildingBtns.BuildingAddBtn"))
function CityWallBtn:create(param)
    local btn = CityWallBtn.new(param)
    btn:initBtn()    
    return btn
end

function CityWallBtn:initBtn()
    self.buildKey = self.param:valueForKey("buildKey"):intValue()
    self:addExtensionBtn()
end

return CityWallBtn