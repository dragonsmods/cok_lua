--许愿池
local SacrificeBtn = class("SacrificeBtn", Drequire("game.buildingBtns.BuildingAddBtn"))
function SacrificeBtn:create(param)
    local btn = SacrificeBtn.new(param)
    btn:initBtn()    
    return btn
end

function SacrificeBtn:initBtn()
    self.buildKey = self.param:valueForKey("buildKey"):intValue()
    if isFunOpenByKey("functionopen") then
        --许愿池
        if FunOpenController:isShow("fun_wish") then
            local openSacrifice = function()
                self:hideSelf()
        
                local SacrificePopUpView = Drequire("game.sacrifice.SacrificePopUpView")
                local view = SacrificePopUpView:create()
                if view then
                    PopupViewController:addPopupInView(view)
                end
                LogController:sendUserBehaviorEvent("building", 2, tostring(math.floor(self.buildKey / 1000)), "wish")
            end
            self:addBtn({icon = "icon_sacrifice.png",text = "102328",callback = openSacrifice})    --102328=许愿
        end
    
        --精铁转盘
        if FunOpenController:isShow("fun_fineIronRoulette") and CCCommonUtilsForLua:isFunOpenByKey("hero_roulette") then
            local openRoulette = function()
                self:hideSelf()
                local view = Drequire("game.hero.NewUI.HeroGetRotateView"):create("89699","hero_type")
                if view then
                    PopupViewController:call("addPopupInView", view)
                end
                LogController:sendUserBehaviorEvent("building", 2, tostring(math.floor(self.buildKey / 1000)), "ironRoulette")
            end
            self:addBtn({icon = "icon_roulette_s.png",text = "169845",callback = openRoulette})--169845=精铁转盘
        end
    end

    --祝福大厅
    if CCCommonUtilsForLua:isFunOpenByKey("fortune") 
        and GlobalData:call("getPlayerInfo"):call("isInAlliance")
        and isCrossServerNow() == false then
        local openFortune = function()
            self:hideSelf()

            local view = Drequire("game.Fortune.FortuneMainView"):create()
            if view then
                PopupViewController:addPopupInView(view)
            end
        end
        self:addBtn("alliancePray.png","5602023",openFortune)
    end

    --扩建
    self:addExtensionBtn()

    --天空之境
    if CCCommonUtilsForLua:isFunOpenByKey("sky_on") 
    and CCCommonUtilsForLua:isFunOpenByKey("sky_door_nolimit") and not isCrossServerNow()
    and FunOpenController:isShow("fun_keyLand") then
        self:addCustomBtn(function ()
            return true
        end, "TheHeavens_face",'TH_entrance_icon.png','icon_buildExtension.png','52027120','heavenEntry',function (  )  --52027120=天空之境
            self:hideSelf()

            local view = Drequire("game.TheHeavens.TheHeavensMainView"):create()
            PopupViewController:addPopupInView(view)
            LogController:sendUserBehaviorEvent("building", 2, tostring(math.floor(self.buildKey / 1000)), "skyLand")
        end)
    end
end

return SacrificeBtn