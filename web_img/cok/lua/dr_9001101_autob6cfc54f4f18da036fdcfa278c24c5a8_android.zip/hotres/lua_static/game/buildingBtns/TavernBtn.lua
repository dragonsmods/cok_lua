--酒馆按钮
local TavernBtn = class("TavernBtn", Drequire("game.buildingBtns.SpeBuildingBtn"))

function TavernBtn:create(param)
    local btn = TavernBtn.new(param)
    btn:initBtn()    
    return btn
end

function TavernBtn:initBtn()
    -- if 1 then return end
    --龙晶
    local isOpenLongJing = false
    local sw = GlobalData:call("shared"):getProperty("dragonglass_control")
    if sw == "" or sw == "0" then
        isOpenLongJing = false
    elseif sw == "1" then
        isOpenLongJing = true
    else
        isOpenLongJing = CCCommonUtilsForLua:call("checkVersion", sw)
    end

    if FunBuildController:call("getMainCityLv") < 15 then
        isOpenLongJing = false
    end

    if FunOpenController:isShowAndDef("fun_dragonGlass", isOpenLongJing) then
        local callback = function()
            self:hideSelf()
            
            SoundController:call("playEffects", Music_Sfx_click_button)

            local colorPage = 1
            local uuid = EquipmentController:call("FindOnEquipBySite", 6)
            local tinfo = EquipmentController:call("getMyEquipInfoByUuid", uuid)
            if tinfo then
                colorPage = tinfo:call("getColor")
            end

            local view = Drequire("game.longjing.EquipLongjingView"):create(colorPage)
            PopupViewController:addPopupInView(view)
        end
        self:addBtn("icon_longJingShop.png", "111652", callback)
        self.guideIndex = self.btnNum
    end

    --试炼场
    if ActivityController:call("getInstance"):getProperty("m_isTrialOpen") == 1 
        and GlobalData:call("shared"):getProperty("serverType") ~= ServerType.SERVER_DRAGON_BATTLE_GLOBAL
        and FunOpenController:isShow("fun_trials") then
        local callback = function()
            self:hideSelf()
            
            if FunOpenController:isUnlock("fun_trials", true) then
                local dict = CCDictionary:create()
                dict:setObject(CCString:create("Training1View"), "name")
                LuaController:call("openPopViewInLua", dict)
            end
        end

        if ActivityController:call("getInstance"):getProperty("v2Open") then
            self:addBtn("training_enter.png", "52045028", callback) --52045028=试炼排位赛
        else
            self:addBtn("training_enter.png", "137525", callback)   --137525=试炼场
        end
    end

    --幸运转盘
    if GlobalData:call("shared"):getProperty("serverType") ~= ServerType.SERVER_DRAGON_BATTLE_GLOBAL
        and LotteryController:call("isLotteryOn", 1) and LotteryController:call("getOpenFlag2") == 1
        and GlobalData:call("shared"):getProperty("analyticID") ~= "common" and FunBuildController:call("getMainCityLv") >= 5 
        and FunOpenController:isShow("fun_luckyWheel") then
        local callback = function()
            self:hideSelf()

            if FunOpenController:isUnlock("fun_luckyWheel", true) then
                if LotteryController:call("isLotteryOn") then
                    local lotteryInfo = LotteryController:call("shared"):getProperty("lotteryInfo")
                    local lotteryType = lotteryInfo:getProperty("type")
                    local name = (lotteryType == 2 and "LotteryAct2View" or "LotteryActView")
                    local dict = CCDictionary:create() 
                    dict:setObject(CCString:create(name), "name")
                    LuaController:call("openPopViewInLua", dict)
                else
                    --111153=尊敬的领主，由于当地法律规定，转盘暂时关闭。
                    CCCommonUtilsForLua:call("flyHint", "", "", getLang("111153"))
                end
            end
        end
        self:addBtn("icon_roulette_s.png", "111100", callback)  --111100=幸运轮盘
    end

    --水晶转盘
    if CCCommonUtilsForLua:isFunOpenByKey("dragonglass_charge") and FunOpenController:isShow("fun_crystalRoulette") then
        local icon = "icon_roulette_s.png"
        local cf = CCLoadSprite:call("getSF", "icon_roulette_crystal.png")
        if cf then icon = "icon_roulette_crystal.png" end
        
        local callback = function()
            self:hideSelf()

            if FunOpenController:isUnlock("fun_crystalRoulette", true) then
                local view = Drequire("game.hero.NewUI.HeroGetRotateView"):create("89698","crystal_type")
                PopupViewController:call("addPopupInView", view)
            end
        end
        self:addBtn(icon, "169892", callback)  --169892=水晶转盘
    end

    --成长手册
    if CCCommonUtilsForLua:isFunOpenByKey("power_info") and
        GlobalData:call("shared"):getProperty("serverType") ~= ServerType.SERVER_DRAGON_BATTLE_GLOBAL
        and FunOpenController:isShow("fun_powerGuide") then
        local callback = function()
            self:hideSelf()

            if FunOpenController:isUnlock("fun_powerGuide", true) then
                local view = require("game.manual.ManualMainView"):create()
                PopupViewController:addPopupInView(view)
            end 
        end 
        self:addBtn("manual_icon.png", "161000", callback)  --161000=成长指引
    end

    --日常奖励
    if GlobalData:call("shared"):getProperty("serverType") ~= ServerType.SERVER_DRAGON_BATTLE_GLOBAL 
        and FunOpenController:isShowAndDef("fun_dailyRewards", FunBuildController:call("getMainCityLv") > 3) then
        
        local callback = function()
            self:hideSelf()

            if FunOpenController:isUnlock("fun_dailyRewards", true) then
                if CCCommonUtilsForLua:isFunOpenByKey("new_daily_active_switch") then
                    local view = Drequire("game.NewDailyActive.NewDailyActiveFrameView"):create()
                    PopupViewController:addPopupInView(view)
                else
                    local view = Drequire("game.Tavern.DailyActiveView"):create()
                    PopupViewController:addPopupInView(view)
                end
            end 
        end 
        self:addBtn("dailyActive_icon.png", "133190", callback)  --133190=日常奖励
        
        if DailyActiveController:call("getDailyActiveOpenFlag") == 1 and DailyActiveController:call("canGetReward") then
            self:addBtnEffect()
        end
    end

    if CCCommonUtilsForLua:isFunOpenByKey("study_plan") then 
        -- 学习答题
        CCLoadSprite:call("loadDynamicResourceByName", "GameKnowledge_face")
        local icon = "GK_study_entrance_icon.png"
        local defaultIcon = "icon_buildExtension.png"
        local _,def = utils.getSafeSprite( "GK_study_entrance_icon.png", "icon_buildExtension.png" )
        icon = def and defaultIcon or icon
        local callback = function()
            self:hideSelf()

            local view = Drequire("game.knowledge.GameKnowledgeEnterView"):create()
            PopupViewController:call("addPopupInView", view)
        end
        self:addBtn(icon, "52034884", callback)     
    end
    
    --适配按钮位置
    self:adapt()
end

function TavernBtn:addBtnEffect()
    if self["btnNode" .. self.btnNum] then
        local particleNode = cc.Node:create()
        self["btnNode" .. self.btnNum]:addChild(particleNode)

        local tmpStart = "QueueGlow_"
        for index = 1, 2 do
            local particle = ParticleController:call("createParticle", string.format("%s%d", tmpStart, index))
            particle:setPositionType(1)
            particleNode:addChild(particle)
        end
    end
end

function TavernBtn:getGuideNodeByKey(key)
    if key == "longjing" and self.guideIndex then
        return self:getBtn(self.guideIndex)
    end
end

return TavernBtn