--仓库
local CellarBuildingBtn = class("CellarBuildingBtn", Drequire("game.buildingBtns.BuildingAddBtn"))

function CellarBuildingBtn:create(param)
    local btn = CellarBuildingBtn.new(param)
    btn:initBtn()    
    return btn
end

function CellarBuildingBtn:initBtn()
    self.buildKey = self.param:valueForKey("buildKey"):intValue()
    local goldenTouchIns = require('game.activity.GoldenTouch.GoldenTouchMgr').getInstance()
    if goldenTouchIns:isActivityOpen() then
        self:addCustomBtn(function (  )
            return goldenTouchIns:isActivityOpen()
        end,nil,'icon_GoldenTouch.png','icon_buildExtension.png','52145667','GoldenTouchEntry',function (  )
            goldenTouchIns:showView()
        end)
    end
end

return CellarBuildingBtn