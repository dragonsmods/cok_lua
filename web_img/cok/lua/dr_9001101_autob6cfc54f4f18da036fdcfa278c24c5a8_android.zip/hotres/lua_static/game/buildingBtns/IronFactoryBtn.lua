--铁矿场
local IronFactoryBtn = class("IronFactoryBtn", Drequire("game.buildingBtns.BuildingAddBtn"))
function IronFactoryBtn:create(param)
    local btn = IronFactoryBtn.new(param)
    btn:initBtn()    
    return btn
end

function IronFactoryBtn:initBtn()
    self.buildKey = self.param:valueForKey("buildKey"):intValue()
    self:addExtensionBtn()

end

return IronFactoryBtn