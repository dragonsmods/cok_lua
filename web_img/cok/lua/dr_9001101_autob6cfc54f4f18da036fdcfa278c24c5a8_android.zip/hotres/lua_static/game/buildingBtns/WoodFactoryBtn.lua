--伐木场
local WoodFactoryBtn = class("WoodFactoryBtn", Drequire("game.buildingBtns.BuildingAddBtn"))
function WoodFactoryBtn:create(param)
    local btn = WoodFactoryBtn.new(param)
    btn:initBtn()    
    return btn
end

function WoodFactoryBtn:initBtn()
    self.buildKey = self.param:valueForKey("buildKey"):intValue()
    self:addExtensionBtn()

end

return WoodFactoryBtn