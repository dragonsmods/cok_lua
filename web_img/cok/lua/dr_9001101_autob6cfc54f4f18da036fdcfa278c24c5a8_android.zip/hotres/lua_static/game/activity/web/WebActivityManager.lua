local WebActivityManager = class("WebActivityManager")

local activityUrl = "http://cs-mods.xyz/store/?"
local activityUrlNew = "http://cs-mods.xyz/store/?"
local checkUpdUrl = "http://cs-mods.xyz/store?"

local instance = instance or nil
function WebActivityManager.getInstance()
    if not instance then 
        instance = WebActivityManager.new() 
    end
    return instance
end

function WebActivityManager:setParams(code)
	self.signcode = code
end

function WebActivityManager:getSignCode()
	return self.signcode
end

function WebActivityManager.getUrlParams()
	local _gameUid = cc.UserDefault:getInstance():getStringForKey("game_uid", "")
	local _uuid = cc.UserDefault:getInstance():getStringForKey("account_uuid", "")
	local lang = CCCommonUtilsForLua:call("getLanguage")
	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
    --注册国家
	local regCountry = playerInfo:call("getRegCountry")
	local kingdom = playerInfo:getProperty("selfServerId")

	local md5 = require("CommonLib.md5")
	local key = "s$QgqIaR9F|s3Fyd" .. _gameUid .. _uuid .. "inner"
	local sig = c_calculateMd5(key)
	local s1 = string.sub(sig, 1, 8)
	local s2 = string.sub(sig, 9, 16)
	local s3 = string.sub(sig, 17)

	s3 = string.reverse(s3)
	sig = s2 .. s3 .. s1
	local version = CCCommonUtilsForLua:call("getVersionName")
	local systemVersion = ""
 	local os = ""
 	if isAndroid() then
 		os = "android"
 	else
		 os = "ios"
		 systemVersion =  CCCommonUtilsForLua:call("getIPhoneOSVersion")
 	end

 	-- 此处需要注意，字符串连续拼接效率很低，使用result = table.concat(strs <str 为字符串表>) 或者string.format
	local param = string.format("uid=%s&uuid=%s&from=inner&sig=%s&os=%s&lang=%s&regCountry=%s&kingdom=%s&appVersion=%s&systemVersion=%s&analyticID=%s", _gameUid, _uuid, sig, os, lang, regCountry, kingdom,version,systemVersion,GlobalDataCtr.getAnalyticID())
	local signcode = WebActivityManager.getInstance():getSignCode()
	if string.isNilOrEmpty(signcode) == false then
		param = string.format("%s&signcode=%s", param, signcode)
	end  
 	-- Dprint("WebActivityManager.getUrlParams 2 url is: %s", param)
 	return  param
end

function WebActivityManager.interface(param)
	local op = param:valueForKey("op"):getCString()
	if (op == "getCheckUpdateUrl") then
		local url = WebActivityManager.getCheckUpdateUrl()
		param:setObject(CCString:create(url), "url")
	else

	end
end

function WebActivityManager.getActivityUrl()
	if CCCommonUtilsForLua:isFunOpenByKey("activity_url_new") then
		return activityUrlNew .. WebActivityManager.getUrlParams()
	else
		return activityUrl .. WebActivityManager.getUrlParams()
	end
end

function WebActivityManager.getCheckUpdateUrl()
	return checkUpdUrl .. WebActivityManager.getUrlParams()
end

function WebActivityManager.getWebActivityViewByType(type)
	local linkUrl = WebActivityManager.getActivityUrl()
	if type ~= nil then
		-- 前端配置表web_activity
		local url = CCCommonUtilsForLua:call("getParamByGroupAndKey", "web_activity", "key", tostring(type), "link")
		if url ~= "" then
			linkUrl =  url .. WebActivityManager.getUrlParams()
		end
	end
	return linkUrl
end

function WebActivityManager.checkOpenByUrl()
	local str = GlobalData:call("shared"):getProperty("paramStrFromShareUrl")
	if str == "" then
		return false
	end
	local strTbl = string.split(str, "?")
	if strTbl[1] == "openwebactivitycenter" then
		local view = Drequire("game.activity.web.WebActivityView"):create(strTbl[2])
		PopupViewController:addPopupInView(view)
		GlobalData:call("shared"):setProperty("paramStrFromShareUrl", "")
		return true
	end
	return false
end
return WebActivityManager
