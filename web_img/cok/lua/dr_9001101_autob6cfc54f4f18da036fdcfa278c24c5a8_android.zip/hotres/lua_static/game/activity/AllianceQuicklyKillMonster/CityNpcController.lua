local CityNpcController = class("CityNpcController")

local NpcDefaultDataInfo = class("NpcDefaultDataInfo")

function NpcDefaultDataInfo:ctor(actId)
    self.actId = tostring(actId)
    self:init()
end

function NpcDefaultDataInfo:init()
    self.ctl = COSDataController.getInstance()
end

function NpcDefaultDataInfo:getActId()
    return self.actId
end

function NpcDefaultDataInfo:isOpen()
    return self.ctl:isOpen(true)
end

function NpcDefaultDataInfo:getNpcData()
    return self.ctl:getNpcData()
end

function NpcDefaultDataInfo:getSpineJson()
    return "trainingTroop.json"
end

function NpcDefaultDataInfo:getSpineAtlas()
    return "sk_TrainingTroopSpine_face.atlas"
end

function NpcDefaultDataInfo:getLeaderInfo()
    return self.ctl.LeaderInfo
end

function NpcDefaultDataInfo:onEventClick()
    self.ctl:fireEventRef("openUIInCity")
end

function NpcDefaultDataInfo:getNpcTitle()
    return "182171"
end
function NpcDefaultDataInfo:getRes()
    return nil
end
----------------------------------------------

local AlliQuicklyKillMonsterNpcDataInfo = class("AlliQuicklyKillMonsterNpcDataInfo", NpcDefaultDataInfo)

function AlliQuicklyKillMonsterNpcDataInfo:ctor(actId)
    self.super.ctor(self, actId)
end

function AlliQuicklyKillMonsterNpcDataInfo:init()
    
end

function AlliQuicklyKillMonsterNpcDataInfo:isOpen()
    -- local _actId = '57370'
    if not CCCommonUtilsForLua:isFunOpenByKey("time_event_monster_hunter") then
        return false
    end
    local obj = ActivityController:call("getActObj", self:getActId())
    if obj then
        local startTime = obj:getProperty("startTime")
        local endTime = obj:getProperty("endTime")
        local nowtime = getWorldTime()
        if nowtime >= tonumber(startTime) and nowtime < tonumber(endTime) then
            return true 
        end
    end
	return false
end

function AlliQuicklyKillMonsterNpcDataInfo:getNpcData()
    local npcId = "20600004"
    local _x = -100
	local _y = -100

	local _raceType = CCCommonUtilsForLua:call("RACETYPE")
	local _pos = nil
	if _raceType == RACE_TYPE_LONG_YI then
		_pos = CCCommonUtilsForLua:call("getPropByIdGroup", "time_event_npc", npcId, "npc_position_longyi")
	elseif _raceType == RACE_TYPE_WEI_JING then
		_pos = CCCommonUtilsForLua:call("getPropByIdGroup", "time_event_npc", npcId, "npc_position_weijing")
	elseif _raceType == RACE_TYPE_DA_HE then
		_pos = CCCommonUtilsForLua:call("getPropByIdGroup", "time_event_npc", npcId, "npc_position_dahe")
	elseif _raceType == RACE_TYPE_HUA_XIA then
		_pos = CCCommonUtilsForLua:call("getPropByIdGroup", "time_event_npc", npcId, "npc_position_huaxia")
    elseif _raceType == RACE_TYPE_ARAB then
		_pos = CCCommonUtilsForLua:call("getPropByIdGroup", "time_event_npc", npcId, "npc_position_arab") 
	end

	if _pos then
		local _xy = string.split(_pos, ",")
		_x = tonumber(_xy[1]) or 0
		_y = tonumber(_xy[2]) or 0
    end
    -- self.NpcPosition = ccp(_x,_y)

	local _xmlScale = CCCommonUtilsForLua:call("getPropByIdGroup", "time_event_npc", npcId, "scale")
	local _scale = tonumber(_xmlScale) or 1

	local _xmlDynamicRes = CCCommonUtilsForLua:call("getPropByIdGroup", "time_event_npc", npcId, "dynamicRes")
	local _dynamicRes = _xmlDynamicRes or "COSAct_face"
	return {x = _x, y = _y, scale = _scale, dynamicRes = _dynamicRes}
end

function AlliQuicklyKillMonsterNpcDataInfo:getSpineJson()
    return "trainingTroop.json"
end

function AlliQuicklyKillMonsterNpcDataInfo:getSpineAtlas()
    return "sk_TrainingTroopSpine_face.atlas"
end

function AlliQuicklyKillMonsterNpcDataInfo:getLeaderInfo()
    return self.leaderInfo
end

function AlliQuicklyKillMonsterNpcDataInfo:onEventClick()
    if self:isOpen() then
        local view = Drequire("game.activity.AllianceQuicklyKillMonster.AllianceQuicklyKillMonsterView"):create()
        if view then
		   PopupViewController:addPopupInView(view)
        end
    end
end

function AlliQuicklyKillMonsterNpcDataInfo:setLeaderInfo(info)
    self.leaderInfo = info
end

function AlliQuicklyKillMonsterNpcDataInfo:getNpcTitle()
    return "987661520"
end
function AlliQuicklyKillMonsterNpcDataInfo:getRes()
    CCLoadSprite:call("loadDynamicResourceByName", "face_alli_kill_monster")
    local res = {}
    res.headBg = "kuang_bg.png"
    res.wangguan = "icon_wangguan.png"

    
    return res
end

----------------------------------------------

function CityNpcController.getInstance()
    if not _CityNpcController_instance then
        _CityNpcController_instance = CityNpcController.new()
    end
    return _CityNpcController_instance
end

function CityNpcController:ctor()

end

function CityNpcController:getNpcInfo(actId)
    if not actId then
        return
    end
    actId = tostring(actId)
    if not self.actInfoMap then
        self.actInfoMap = {}
    end
    if not self.actInfoMap[actId] then
        self.actInfoMap[actId] = self:createNpcDataInfo(actId)
    end
    return self.actInfoMap[actId]
end

function CityNpcController:createNpcDataInfo(actId)
    if tonumber(actId) == 57405 then
        return AlliQuicklyKillMonsterNpcDataInfo.new(actId)
    end
    return NpcDefaultDataInfo.new(actId)
end

function CityNpcController:createCityNpcView(actId)
    Dprint("CityNpcController:createCityNpcView:"..actId)
    return Drequire("game.activity.CallOfSoldiresAct.COSRankActNpc").create(actId)
end

return CityNpcController