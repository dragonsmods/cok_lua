----------------------------
-- Author: Elex
-- Date: 2020-01-16 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CsmodItemStoreCell_ui = class("CsmodItemStoreCell_ui")

--#ui propertys


--#function
function CsmodItemStoreCell_ui:create(owner, viewType, paramTable)
	local ret = CsmodItemStoreCell_ui.new()
	CustomUtility:DoRes(305, true)
	CustomUtility:DoRes(8, true)
	CustomUtility:LoadUi("CsmodItemStoreCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CsmodItemStoreCell_ui:initLang()
end

function CsmodItemStoreCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CsmodItemStoreCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CsmodItemStoreCell_ui:onBuyButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBuyButtonClick", pSender, event)
end

return CsmodItemStoreCell_ui

