local WebActivityView = class("WebActivityView", function()
        return PopupBaseView:create()
    end
)
------------------------------------------ WebActivityView Start --------------------------------------------

function WebActivityView:create(urlParam, openType)
    if openType == "ScoreMall" then
    end

    local view = WebActivityView.new()
    if view:initView(urlParam, openType) == false then
        return nil
    end
    return view
end

function WebActivityView:initView(urlParam, openType)
    if self:init(true, 5) == false then
        MyPrint("WebActivityView init error")
        return false
    end

    self:setHDPanelFlag(true)
    local m_bIsPad = CCCommonUtilsForLua:isIosAndroidPad()
    
    local webNode = cc.Node:create()
    self:addChild(webNode)

    local function onNodeEvent(event)
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end
    webNode:registerScriptHandler(onNodeEvent)

    local winSize = getWinSize()
    self:setContentSize(winSize)
    local x, y = 0, 0
    local listSize = CCSizeMake(0, 0)
    if m_bIsPad then
    	y = winSize.height -- - 90 * 2
    	listSize.width = 1536
    	listSize.height = y
    else
    	y = winSize.height -- - 80
    	listSize.width = 640
    	listSize.height = y
 	end 

 	webNode:setAnchorPoint(ccp(0, 1))
 	webNode:setPosition(x, y)
 	Dprint("listSize", listSize.width, listSize.height)
    webNode:setContentSize(cc.size(listSize.width, listSize.height))

    CCCommonUtilsForLua:call("makeBatchBG", webNode, winSize, ccp(0, 1), 1)

    local loadingIcon = CCLoadSprite:call("createSprite", "loading_1.png")
    loadingIcon:setAnchorPoint(ccp(0.5, 0.5))
    loadingIcon:setPosition(ccp(listSize.width / 2, -listSize.height / 2))

    local rotateAction = cc.RotateTo:create(0.5, 720)
    local rotateForever = cc.RepeatForever:create(rotateAction)
    loadingIcon:runAction(rotateForever)
    webNode:addChild(loadingIcon)
       
    local url = require("game.activity.web.WebActivityManager").getInstance().getWebActivityViewByType(openType)
    -- dump(openType, "WebActivityView init openType")
    -- dump(url, "WebActivityView init url")

    if urlParam and urlParam ~= "" then
        url = url.."&".. urlParam
    end
    -- 这里不能打日志的，防止uid泄漏
    -- Dprint("url:".. url)
    self.WebViewInstance = CCWebView:call("create",  ccp(0, 0), cc.Director:getInstance():getIFWinSize(), webNode)
	self.WebViewInstance:call("loadUrl",  url)

    return true
end


function WebActivityView:onEnter()    
    self:setTitleName(getLang("168620"))
    --邮件小红点
    local weekDay = CCCommonUtilsForLua:call("getWeekDay", getWorldTime())
    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
    local myUid = playerInfo:getProperty("uid")
    local key = "WEB_ACT_"..myUid
    local last_day = cc.UserDefault:getInstance():getIntegerForKey(key, -1)
    if(last_day ~= weekDay) then
        cc.UserDefault:getInstance():setIntegerForKey(key, weekDay)
        cc.UserDefault:getInstance():flush()
        CCSafeNotificationCenter:postNotification("mailListChange")
    end
    registerScriptObserver(self,self.closeView,"WebActivityView.close")
end

function WebActivityView:onExit()
    if self.WebViewInstance then
	   self.WebViewInstance:call("setVisible", false)
    end
    unregisterScriptObserver(self,"WebActivityView.close")
end

function WebActivityView:closeView()
    PopupViewController:call("goBackPopupView")
end

return WebActivityView