

---------------------------领奖 Start ---------------------------
ConsumeActivityGetCmd = class("ConsumeActivityGetCmd", LuaCommandBase)
function ConsumeActivityGetCmd.create(getLv)
    local ret = ConsumeActivityGetCmd.new()--getLv int 要领取的档位
    ret:initWithName("continuedcost.reward")
    ret:putParam("getLv", CCInteger:create(getLv))
    return ret
end

function ConsumeActivityGetCmd:handleReceive(dict)
    local flag, params = self:parseMsg(dict)
    Dprint("BalanceInputCmd:handleReceive | parse flag=", flag)
    if (type(flag) == "boolean") then
        return flag
    end
    CCSafeNotificationCenter:postNotification("consumeActivity_get_info",params)
    return true
end
--------------------------- 领奖 End ---------------------------

-------------------------------------------- ConsumeActivityRewardCell Start --------------------------------------------
local ConsumeActivityRewardCell = class("ConsumeActivityRewardCell", function()
    return cc.Layer:create()
end)

ConsumeActivityRewardCell.m_labelCellHeight = 40
ConsumeActivityRewardCell.m_bgHeight = 130

function ConsumeActivityRewardCell:create(idx)
    local ret = ConsumeActivityRewardCell.new()
    Drequire("game.activity.consumePoint.ConsumeActivityRewardCell_ui"):create(ret)
    local function onTouch(eventType, x, y)  
        if eventType == "began" then  
            return ret:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return ret:onTouchMoved(x, y)  
        else  
            return ret:onTouchEnded(x, y)  
        end
    end
    ret.ui.m_touchlayer:setTouchEnabled(true)
    ret.ui.m_touchlayer:registerScriptTouchHandler(onTouch)
    ret.ui.m_touchlayer:setSwallowsTouches(false)

    return ret
end

function ConsumeActivityRewardCell:refreshCell(info , idx)
    self.m_idx = tonumber(info.level)
    self.touchFunc = info.touchFunc
    self.parent = info.parent
    -- 修改为自动领奖
    if tonumber(info.costPoint) < tonumber(info.rewardMax) then -- 未完成115306
        self.ui.m_buyTxt:setString(getLang("115306"))
    else
        self.ui.m_buyTxt:setString(getLang("140556"))
    end
    
    self.ui.m_baseNode:removeAllChildren()
    self.m_cellPosY = 0
	self.ui.m_btnTxt:setString(getLang("140553" ,info.level, info.rewardMax))
    self.reward = info.costReward.reward
    self.cellNode = {}
	for k,v in pairs(info.costReward.reward) do
        if tonumber(v.type) == 5 then
            self:addLabel(v.type , nil , v.value, k)
        elseif tonumber(v.type) == 7 then
            self:addLabel(v.type , v.value.id, v.value.num, k)    
        end
    end
    --偏移修正
    local fixNum = #info.costReward.reward - 2
    if fixNum < 0 then
        fixNum = 0
    end

    self.ui.nodeccb:setPositionY(self.m_labelCellHeight * fixNum)
    -- local scaleY = (self.ui.m_sprBG:getContentSize().height + self.m_labelCellHeight * fixNum) / self.ui.m_sprBG:getContentSize().height
    self.ui.m_sprBG:setContentSize(cc.size(500,self.m_labelCellHeight * fixNum + self.m_bgHeight))
end

function ConsumeActivityRewardCell:onEnter()
end

function ConsumeActivityRewardCell:onExit()
end

function ConsumeActivityRewardCell:addLabel( itemType, id ,num, k)
    local halfHeight = self.m_labelCellHeight*0.5
    local cellNode = cc.Node:create()
    cellNode:setAnchorPoint(cc.p(0, 0.5))
    cellNode:setContentSize(cc.size(500, self.m_labelCellHeight))

    self.ui.m_baseNode:addChild(cellNode)
    local iconBg = CCLoadSprite:call("createSprite","icon_kuang.png")
    iconBg:setPosition(cc.p(10, halfHeight))
    iconBg:setScale(0.35)
    cellNode:addChild(iconBg)
    local iconNode = cc.Node:create()
    if tonumber(itemType) == 7 then
        CCCommonUtilsForLua:call("createGoodsIcon", tonumber(id), iconNode, CCSizeMake(30, 30))
        iconNode:setPosition(iconBg:getPosition())
        cellNode:addChild(iconNode)
    elseif tonumber(itemType) == 5 then
        local goldSpr = CCLoadSprite:call("createSprite", "ui_gold.png")
        goldSpr:setScale(0.8)
        goldSpr:setPosition(cc.p(10, halfHeight+5))
        cellNode:addChild(goldSpr)
    end

    local itemName = CCCommonUtilsForLua:call("getNameById", tostring(id))
    if tonumber(itemType) == 5 then
        itemName = getLang("151412")
    end
    local label2 = cc.Label:createWithSystemFont(itemName, "Helvetica", 18, cc.size(0,0))
    label2:setAnchorPoint(cc.p(0,0.5))
    label2:setPosition(cc.p(50, halfHeight))
    cellNode:addChild(label2)

    local label1 = cc.Label:createWithSystemFont("x"..tostring(num), "Helvetica", 18, cc.size(0,0))
    label1:setAnchorPoint(cc.p(0,0.5))
    label1:setPosition(cc.p(label2:getPositionX() + label2:getContentSize().width + 20, halfHeight))
    cellNode:addChild(label1)

    cellNode:setPositionY(-self.m_cellPosY )
    self.m_cellPosY = self.m_cellPosY + self.m_labelCellHeight
    self.cellNode[k] = cellNode
end

function ConsumeActivityRewardCell:onTouchBegan(x, y)
    -- dump(self.reward, "ConsumeActivityRewardCell onTouchBegan")
    self.touchItem = nil
    if touchInside(self.parent, x, y) then
        for k, reward in pairs(self.reward) do
            local baseNode = self.cellNode[k]
            if reward and tonumber(reward.type) == RewardTypeConfig.R_GOODS then
                if touchInside(baseNode, x, y) then
                    self.touch_x = x
                    self.touch_y = y
                    self.touchItem = reward
                    local newPos = self:convertToNodeSpace(cc.p(x, y))
                    self.touchFunc(true, self.touchItem, x, y)
                    return true
                end
            end
        end
    end
    return false
end

function ConsumeActivityRewardCell:onTouchMoved(x, y)
    -- dump("ConsumeActivityRewardCell onTouchBegan")
    if self.touchItem then
        if cc.pGetDistance(cc.p(self.touch_x, self.touch_y), cc.p(x,y)) > 20 then
            self.touchFunc(false)
            self.touchItem = false
        end
    end
end
function ConsumeActivityRewardCell:onTouchEnded(x, y)
    -- dump("ConsumeActivityRewardCell onTouchBegan")
    if self.touchItem then
        self.touchFunc(false)
        self.touchItem = false
    end
end
-------------------------------------------- ConsumeActivityRewardCell End --------------------------------------------

return ConsumeActivityRewardCell