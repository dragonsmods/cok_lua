----------------------------
-- Author: Elex
-- Date: 2017-10-16 Monday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CsmodItemStoreView_ui = class("CsmodItemStoreView_ui")

--#ui propertys


--#function
function CsmodItemStoreView_ui:create(owner, viewType)
	local ret = CsmodItemStoreView_ui.new()
	CustomUtility:LoadUi("CsmodItemStoreView.ccbi", ret, owner, true, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then		owner:initTableViewByOwner()
	else		ret:initTableView()	end	return ret
end

function CsmodItemStoreView_ui:initLang()
end

function CsmodItemStoreView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CsmodItemStoreView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CsmodItemStoreView_ui:onDefaultButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onDefaultButtonClick", pSender, event)
end

function CsmodItemStoreView_ui:onLuxuryButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onLuxuryButtonClick", pSender, event)
end

function CsmodItemStoreView_ui:onClickRecord(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickRecord", pSender, event)
end

function CsmodItemStoreView_ui:initTableView()
	TableViewSmoker:createView(self, "m_listTableView_Default", "game.activity.CsmodItemStore.CsmodItemStoreCell", 1, 10, "CsmodItemStoreCell")
	TableViewSmoker:createView(self, "m_listTableView_Luxury", "game.activity.CsmodItemStore.CsmodItemStoreCell", 1, 10, "CsmodItemStoreCell")
end

function CsmodItemStoreView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return CsmodItemStoreView_ui

