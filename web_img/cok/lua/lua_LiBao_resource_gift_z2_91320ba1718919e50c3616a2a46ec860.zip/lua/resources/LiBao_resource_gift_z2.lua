cfg_table = {
	["layerX"] = -13,
	["layerY"] = -40,
	["layerScale"] = 1,
	["particle"] = {
		["parName"] = {
			[1] = "Rose_3",
			[2] = "VIPGlow_3",
			[3] = "",
			[4] = "",
		},
		["parPosX"] = 50,
		["parPosY"] = 50,
		["parScale"] = 0.9
	}
}