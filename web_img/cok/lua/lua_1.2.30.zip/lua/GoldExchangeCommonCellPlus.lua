LiBaoCommonCell  = LiBaoCommonCell or {}
ccb["LiBaoCommonCell"] = LiBaoCommonCell

GoldExchangeCommonCell = class("GoldExchangeCommonCell",
	function()
        return cc.Layer:create() 
	end
)
GoldExchangeCommonCell.__index = GoldExchangeCommonCell
function GoldExchangeCommonCell:create(path,params)
	local node = GoldExchangeCommonCell.new()
	node:init(path,params)
	return node
end
function GoldExchangeCommonCell:init(path,params)
    local dic1 = CCDictionary:create()
    self.rootPath = path
    self.data = params
    local  proxy = cc.CCBProxy:create()
    local ccbiUrl = self.rootPath .. "/ccbi/LiBaoCommonCell.ccbi"
	local  node  = CCBReaderLoad(ccbiUrl,proxy,LiBaoCommonCell)
    if(nil == node) then
        return
    end

    self:setContentSize(CCSize(566, 75))

   	print "(COK2_Cell)GoldExchangeCommonCell:init"
    local  layer = tolua.cast(node,"cc.Layer")
    if nil ~= LiBaoCommonCell["m_nameLabel"] then
        self.m_nameLabel = tolua.cast(LiBaoCommonCell["m_nameLabel"],"cc.Label")
        if nil ~= self.m_nameLabel then
            self.m_nameLabel:setString("")
        end
    end

    --print "1"
    if nil ~= LiBaoCommonCell["m_numLabel"] then
        self.m_numLabel = tolua.cast(LiBaoCommonCell["m_numLabel"],"cc.Label")
        if nil ~= self.m_numLabel then
            local numStr = string.format(self.data[2])
            self.m_numLabel:setString(numStr)
        end
    end
    
    --print "2"
    if nil ~= LiBaoCommonCell["m_iconNode"] then
    	self.m_iconNode = tolua.cast(LiBaoCommonCell["m_iconNode"],"cc.LayerColor")
        if nil ~= self.m_iconNode then
            -- LuaController:addItemIcon(self.m_iconNode,self.data[1],self.m_nameLabel)
            dic1:setObject(self.m_iconNode, "1")
            dic1:setObject(CCString:create(tostring(self.data[1])), "2")
            dic1:setObject(self.m_nameLabel, "3")
            LuaController:comFunc("addItemIcon", dic1)

            tdic1 = CCDictionary:create()
            tdic1:setObject(CCString:create(tostring(self.data[1])), "1")
            tdic1:setObject(CCString:create(tostring("vanishTime")), "2")
            local vanishTime = CCCommonUtilsForLua:comFunc("getPropById", tdic1):getCString()
            -- vanishTime=6001
            if vanishTime~=nil and vanishTime~="" and tonumber(vanishTime)>0 then
                local tdic1 = CCDictionary:create()
                tdic1:setObject(CCString:create(tostring(self.data[1])), "1")
                tdic1:setObject(CCString:create(tostring("name")), "2")
                local nameDialog = CCCommonUtilsForLua:comFunc("getPropById", tdic1):getCString()
                tdic1 = CCDictionary:create()
                tdic1:setObject(CCString:create(tostring(nameDialog)), "1")
                local nameStr = LuaController:comFunc("getLang", tdic1):getCString()

                print("nameStr:"..nameStr..",vanishTime:"..vanishTime)
                local hour =tonumber(string.format("%.1f", tonumber(vanishTime)/60))
                local day =tonumber(string.format("%d", tonumber(hour)/24))
                local dayhour = tonumber(hour)%24
                print("hour:"..hour..";day:"..day..",dayhour:"..dayhour)
                local addstr = ""
                if day>0 then
                    if dayhour>0 then
                        --101506=（限时{0}天{1}小时）
                        tdic1 = CCDictionary:create()
                        tdic1:setObject(CCString:create("101506"), "1")
                        tdic1:setObject(CCString:create(tostring(day)), "2")
                        tdic1:setObject(CCString:create(tostring(dayhour)), "3")
                        addstr = LuaController:comFunc("getLang2", tdic1):getCString()
                        print("addstr:"..addstr)
                    else
                        --101504=（限时{0}天）
                        tdic1 = CCDictionary:create()
                        tdic1:setObject(CCString:create("101504"), "1")
                        tdic1:setObject(CCString:create(tostring(day)), "2")
                        addstr = LuaController:comFunc("getLang1", tdic1):getCString()
                        print("addstr:"..addstr)
                    end
                else
                    --101505=（限时{0}小时）
                    tdic1 = CCDictionary:create()
                    tdic1:setObject(CCString:create("101505"), "1")
                    tdic1:setObject(CCString:create(tostring(hour)), "2")
                    addstr = LuaController:comFunc("getLang1", tdic1):getCString()
                    print("addstr:"..addstr)
                end
                nameStr=nameStr..addstr
                self.m_nameLabel:setString(nameStr)
            end

            self.m_iconNode:setPositionX(self.m_iconNode:getPositionX())
            self.m_iconNode:setPositionY(self.m_iconNode:getPositionY())
            self.m_iconNode:setScale(0.95)
        end
    end
    self:addChild(node)
    -- local chechV = tostring(CCCommonUtilsForLua:getPropById("99020","k1"))
    -- if CCCommonUtilsForLua:checkVersion(chechV) == true then
    --     if CCCommonUtilsForLua:isFlip() then
    --         self:setFlip()
    --     end
    -- end
    dic1:setObject(CCString:create(tostring("99020")), "1")
    dic1:setObject(CCString:create(tostring("k1")), "2")
    local chechV = CCCommonUtilsForLua:comFunc("getPropById", dic1):getCString()
    -- if CCCommonUtilsForLua:checkVersion(chechV) == true then
    dic1:setObject(CCString:create(tostring(chechV)), "1")
    if CCCommonUtilsForLua:comFunc("checkVersion", dic1):getValue() == true then
        -- if CCCommonUtilsForLua:isFlip() then
        if CCCommonUtilsForLua:comFunc("isFlip", 0):getValue() == true then
            self:setFlip()
        end
    end
end

function GoldExchangeCommonCell:setFlip()
    if self.m_nameLabel ~= nil then
        self.m_nameLabel:setScaleX(-1)
    end
    if self.m_numLabel ~= nil then
        self.m_numLabel:setScaleX(-1)
    end
end