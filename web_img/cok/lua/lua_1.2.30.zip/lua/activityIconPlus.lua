
activityIconPlus = class("activityIconPlus",
	function()
        return cc.Layer:create() 
	end
)
activityIconPlus.__index = activityIconPlus
function activityIconPlus:create(parent,path,params)
    --print "activityIconPlus:create(parent,path,params)"
	local node = activityIconPlus.new()
	node:initWithCommon(parent,path,params)
	return node
end
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function activityIconPlus:initWithCommon(parent,path,params)
    print("activityIconPlus:initWithCommon-path:"..path..",params:"..params)
    local dic1 = CCDictionary:create()
    local strPath = string.format(path)
    self.rootPath = strPath
    self.parentNode = parent
    self.actname = params

    self.mainNode = cc.Node:create()
    self:addChild(self.mainNode)
    -- self:initParticale()
    --print "-----409----"
    self:initCommonSkeleton()
    --print "-----410----"
    if nil ~= self.parentNode then
    --print "-----411----"
        self.parentNode:addChild(self)
    end
    --print "-----412----"
    local function eventHandler( eventType )
        if eventType == "enter" then
            --print " activityIconPlus enter"
        elseif eventType == "exit" then
            --print "activityIconPlus exit"
        elseif eventType == "cleanup" then
            --print "activityIconPlus cleanup"
            self:unregisterScriptHandler()
        end
    end
    self:registerScriptHandler(eventHandler)
end
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function activityIconPlus:initCommonSkeleton()
    print "activityIconPlus:initCommonSkeleton"
    local dic1 = CCDictionary:create()
    if nil==self.mainNode then
        return
    end
    local targetPlatform = cc.Application:getInstance():getTargetPlatform()
    if (3 == targetPlatform) then
        targetPlatform = "android/"
    else
        targetPlatform = "ios/"
    end

    local layerScale = 1
    local layerX = 0
    local layerY = 0
    local altas = ""
    local json = ""
    local aniName = "animation"

    local popImg = tostring(self.actname)
    if tostring(self.actname)=="default" then
        popImg = "Activity_Default"--"LiBao_resource_gift"
    -- elseif tostring(self.actname)=="57077" then
    --     popImg = "LiBao_EuropeanCup"
    end
    print("popImg:"..popImg)
    -- local bFile = LuaController:checkSkeletonFile(targetPlatform .."sk_"..popImg.."_icon")
    dic1:setObject(CCString:create(tostring(targetPlatform .."sk_"..popImg.."_icon")), "1")
    local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
    if bFile == false then
        popImg = "Activity_Default"
        dic1 = CCDictionary:create()
        dic1:setObject(CCString:create(tostring(targetPlatform .."sk_"..popImg.."_icon")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
    end
    altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_"..popImg.."_icon.atlas"
    json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_"..popImg.."_icon.json"

    if popImg == "Activity_Default" then
        layerX = -5
    elseif popImg == "LiBao_crystal_gift" then
        aniName = "rukou"
        layerX = -12
        layerY = -40
        layerScale = 0.9
    elseif popImg == "9012508" then
        -- aniName = "rukou"
        layerY = 60
    end

    self.mainNode:removeAllChildren(true)

    dic1 = CCDictionary:create()
    dic1:setObject(self.mainNode, "1")
    dic1:setObject(CCString:create(tostring(json)), "2")
    dic1:setObject(CCString:create(tostring(altas)), "3")
    dic1:setObject(CCString:create(tostring(aniName)), "4")
    dic1:setObject(CCFloat:create(1), "5")
    LuaController:comFunc("addSkeletonAnimation", dic1)
    self.mainNode:setScale(layerScale)
    self.mainNode:setPosition(cc.p(layerX,layerY))
    print "333"
end
