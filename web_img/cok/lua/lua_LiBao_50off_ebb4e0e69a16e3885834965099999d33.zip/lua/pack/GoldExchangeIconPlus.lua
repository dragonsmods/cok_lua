GoldExchangeLuaIcon  = GoldExchangeLuaIcon or {}
ccb["GoldExchangeLuaIcon"] = GoldExchangeLuaIcon

GoldExchangeIcon = class("GoldExchangeIcon",
	function()
        return cc.Layer:create() 
	end
)
GoldExchangeIcon.__index = GoldExchangeIcon
function GoldExchangeIcon:create(parent,path,params)
    --print "GoldExchangeIcon:create(parent,path,params)"
	local node = GoldExchangeIcon.new()
	node:init(parent,path,params)
	return node
end
function GoldExchangeIcon:init(parent,path,params)
    local testStr = "aaa.bbb.ccc"
    testStr = testStr .. "ddd"
    print "testbegan"
    local pteststr = CCString:create(tostring(testStr))
    print "testend"

    local dic1 = CCDictionary:create()
    self:setData(params)
    local popImg = string.format(self.data[19])
    print("(COK2-Icon)popImg___:" .. popImg)
    local firstIdx = string.find(popImg,"_",1)
    if (firstIdx ~= nil) then
        local firstStr = string.sub(popImg,1,firstIdx-1)
        print("(COK2-Icon)firstStr:" .. firstStr)
        if firstStr=="LiBao" then
            self.openType = 1
            print("(COK2-Icon)firstStr==LiBao" )
            -- local node = GoldExchangeIcon.new()
            self:initWithCommon(parent,path,params)
            -- return node
            return
        end
    end

	local strPath = string.format(path)
    self.rootPath = strPath
    self.parentNode = parent
    -- self:setData(params)

    loadLuaResource(self.rootPath .. "/resources/".. self.data[19] .."icon.plist")

    local ccbiUrl = strPath .. "/" .. self:getCCBI()
    ----print(ccbiUrl)
    local proxy = cc.CCBProxy:create()
    --print "GoldExchangeIcon:init(parent,path,params)"
   	local ccbnode = CCBReaderLoad(ccbiUrl,proxy,GoldExchangeLuaIcon)
    if ccbnode ~= nil then
        --print "-----401----"
        local layer = tolua.cast(ccbnode,"cc.Layer")
        --print "-----402----"

        if nil ~= GoldExchangeLuaIcon["m_timeLabel"] then
        --print "-----403----"

            self.m_timeLabel = tolua.cast(GoldExchangeLuaIcon["m_timeLabel"],"cc.Label")
            --self.m_timeLabel = nil
        end
        --print "-----404----"

        if nil ~= GoldExchangeLuaIcon["m_ani1"] then
        --print "-----405----"

            self.m_ani1Layer = tolua.cast(GoldExchangeLuaIcon["m_ani1"],"cc.LayerColor")
        end
        --print "-----406----"

        if nil ~= GoldExchangeLuaIcon["m_ani2"] then
        --print "-----407----"

            self.m_ani2Layer = tolua.cast(GoldExchangeLuaIcon["m_ani2"],"cc.LayerColor")
        end
        --print "-----408----"

        self:initParticale()
        --print "-----409----"

        self:initSkeleton()
        --print "-----410----"

        if nil ~= self.parentNode then
        --print "-----411----"

            -- self.parentNode:addChild(ccbnode)
            self.parentNode:addChild(self)
            self:addChild(ccbnode)
        end
        --print "-----412----"

        if self.data[19] == "normal_gift" then
        --print "-----413----"

            if nil ~= self.data[10] then
                local keyStr = string.format(self.data[10])
                -- local titleStr = string.format(LuaController:getLang(keyStr))
                dic1:setObject(CCString:create(tostring(keyStr)), "1")
                local titleStr  = LuaController:comFunc("getLang", dic1):getCString()
                self.m_timeLabel:setString(titleStr)
            end
        else
        --print "-----414----"
        local function scheduleBack(  )
            -- print "_____GoldExchangeIcon:scheduleBack"
            if self.data ~= nil then
            if nil ~= self.m_timeLabel then
            -- local curTime = LuaController:getWorldTime()
            local curTime = tonumber(LuaController:comFunc("getWorldTime", 0):getValue())
            local expTime = tonumber(self.data[14])
            local endTime = tonumber(self.data[13])
            local lastTime = endTime - curTime
            -- print "1"
            if expTime>0 then
                -- print "2"
                local count =(endTime- curTime)/(expTime*3600)
                count = math.floor(count)
                lastTime=endTime-count*(expTime*3600)-curTime
            else
                -- print "3"
                lastTime = endTime - curTime
            end
            -- local timeStr = string.format(LuaController:getSECLang(lastTime))
            -- print "4"
            local dic2 = CCDictionary:create()
            -- print "5"
            dic2:setObject(CCInteger:create(tonumber(lastTime)), "1")
            -- print "6"
            local timeStr = LuaController:comFunc("getSECLang", dic2):getCString()
            -- print "7"
            self.m_timeLabel:setString(timeStr)
            local isShow = 1
            -- print "8"
            if ((endTime - curTime) <= 0) then
            -- print "9"
                isShow = 0
            end
            -- print "10"
            if (string.format(self.data[15]) == "1") then
                -- print "11"
                isShow = 0
            end
            -- print "12"
            if isShow == 0 then
                -- print "13"
                self.m_timeLabel:setString("")
                self:removeAllEvent()
                if nil ~= self.parentNode then
                    -- print "14"
                    self.parentNode:setVisible(false)
                end
            else
                -- print "15"
                if nil ~= self.parentNode then
                    -- print "16"
                    self.parentNode:setVisible(true)
                end
            end
            end
            end
        end

         local function eventHandler( eventType )
            if eventType == "enter" then
                -- print " GoldExchangeIcon enter"
                scheduleBack()
                self.m_entryId = tonumber(ccbnode:getScheduler():scheduleScriptFunc(scheduleBack, 1, false))
            elseif eventType == "exit" then
                -- print "GoldExchangeIcon exit"
                if nil ~= self.m_entryId then
                    ccbnode:getScheduler():unscheduleScriptEntry(self.m_entryId)
                end
            elseif eventType == "cleanup" then
                -- print "GoldExchangeIcon cleanup"
                ccbnode:unregisterScriptHandler()
            end
        end
        ccbnode:registerScriptHandler(eventHandler)
        end
    end
end
function GoldExchangeIcon:setData(params)
        --print "GoldExchangeIcon:setData(params)"

	local paramsStr = string.format(params)
    ----print("params:" .. paramsStr)
    self.data = {}
    local index = 1
    local startI = 1
    local fIndex = string.find(paramsStr,",",startI)
    local tmpValue = "" 
    while (true) do
        tmpValue = string.sub(paramsStr,startI,fIndex-1)
        ----print("params" .. string.format(index) .. ":" .. tmpValue)
        self.data[index] = tmpValue
        index = index + 1
        startI = fIndex + 1
        fIndex = string.find(paramsStr,",",startI)
        if (fIndex == nil) then
            tmpValue = string.sub(paramsStr,startI,string.len(paramsStr))
            ----print("params" .. string.format(index) .. ":" .. tmpValue)
            self.data[index] = tmpValue
            break
        end
    end
end
function GoldExchangeIcon:removeAllEvent()
    releaseLuaResource(self.rootPath .. "/resources/".. self.data[19] .."icon")
    if self.m_timeLabel ~= nil then
        self.m_timeLabel:stopAllActions()
    end
end
--[[function GoldExchangeIcon:scheduleBack()
    --print "_____GoldExchangeIcon:scheduleBack"
    if self.data ~= nil then
    	if nil ~= self.m_timeLabel then
            local curTime = LuaController:getWorldTime()
            local expTime = tonumber(self.data[14])
            local endTime = tonumber(self.data[13])
            local lastTime = endTime - curTime
            if expTime>0 then
                local count =(endTime- curTime)/(expTime*3600)
                count = math.floor(count)
                lastTime=endTime-count*(expTime*3600)-curTime
            else
                lastTime = endTime - curTime
            end
            local timeStr = string.format(LuaController:getSECLang(lastTime))
            self.m_timeLabel:setString(timeStr)
            local isShow = 1
            if ((endTime - curTime) <= 0) then
                isShow = 0
            end
            if (string.format(self.data[15]) == "1") then
                isShow = 0
            end
            if isShow == 0 then
                self.m_timeLabel:setString("")
                self:removeAllEvent()
                if nil ~= self.parentNode then
                    self.parentNode:setVisible(false)
                end
            else
                if nil ~= self.parentNode then
                    self.parentNode:setVisible(true)
                end
            end
        end
    end
end]]

function GoldExchangeIcon:getCCBI()
    local actName = string.format(self.data[19])
    return "ccbi/GoldExchange"..actName.."LuaIcon.ccbi"
end
function GoldExchangeIcon:initSkeleton()
    --print "1"
    local dic1 = CCDictionary:create()
    if nil==self.m_ani1Layer then
        return
    end
    --print "2"
    local skeletonPath = nil
    --print "3"
    local targetPlatform = cc.Application:getInstance():getTargetPlatform()
    --print "4"
    --if (kTargetAndroid == targetPlatform) then
    if (3 == targetPlatform) then
        -- android
    --print "5"
        targetPlatform = "android/"
    else
    --print "6"
        targetPlatform = "ios/"
    end

    local layerScale = 1
    local layerX = 0
    local layerY = 0
    local altas = ""
    local json = ""
    local aniName = "animation"

    --print "7"
    if self.data[19] == "resource_gift" then
    --print "8"
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "normal_giftditu-zylb")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "normal_giftditu-zylb")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        ----print("build_alliance_initSkeleton")
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."normal_giftditu-zylb.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."normal_giftditu-zylb.json"

        layerScale = 0.9
        --layerX = 0
        layerY = -50
    elseif self.data[19] == "oneyear" then
    --print "9"
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "icon_oneyears")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "icon_oneyears")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end

        altas = self.rootPath .. "/skeleton/"..targetPlatform .."icon_oneyears.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."icon_oneyears.json"

        layerX = -10
        layerY = -55
    elseif self.data[19] == "cn_fight" then
    --print "10"
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_cn_fight")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_cn_fight")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end

        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_cn_fight.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_cn_fight.json"

        layerX = -10
        layerY = -55
    elseif self.data[19] == "jp_fight" then
    --print "11"
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_jp_fight")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_jp_fight")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end

        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_jp_fight.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_jp_fight.json"

        layerX = -10
        layerY = -55
    elseif self.data[19] == "qixi" then
    --print "12"
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_qixi")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_qixi")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end

        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_qixi.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_qixi.json"

        layerX = -10
        layerY = -55
    elseif self.data[19] == "peace_gift" then
    --print "13"
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_peace_gift")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_peace_gift")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_peace_gift.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_peace_gift.json"
        --aniName = "animation"
        --layerScale = 1
        layerX = -10
        layerY = -55
    elseif self.data[19] == "zhongqiu_gift" then
    --print "14"
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_zhongqiu_gift")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_zhongqiu_gift")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_zhongqiu_gift.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_zhongqiu_gift.json"
        --aniName = "animation"
        layerScale = 0.5
        layerX = -10
        layerY = -55
    elseif self.data[19] == "de_fight" then
    --print "15"
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_de_fight")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_de_fight")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_de_fight.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_de_fight.json"
        --aniName = "animation"
        layerScale = 0.8
        layerX = -10
        layerY = -55
    elseif self.data[19] == "guoqing_gift" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_guoqing_gift")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_guoqing_gift")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_guoqing_gift.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_guoqing_gift.json"
        --aniName = "animation"
        layerScale = 0.8
        layerX = -10
        layerY = -35
    elseif self.data[19] == "TW_gift" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_TW_gift")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_TW_gift")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_TW_gift.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_TW_gift.json"
        --aniName = "animation"
        layerScale = 0.9
        layerX = 0
        layerY = -30
    elseif self.data[19] == "TW_gift1" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_TW_gift1")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_TW_gift1")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_TW_gift1.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_TW_gift1.json"
        --aniName = "animation"
        layerScale = 0.9
        layerX = 0
        layerY = -30
    elseif self.data[19] == "europe_gift" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_europe_gift")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_europe_gift")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_europe_gift.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_europe_gift.json"
        aniName = "rukou"
        layerScale = 0.8
        layerX = -10
        layerY = -40
    elseif self.data[19] == "thousand" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_thousand")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_thousand")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_thousand.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_thousand.json"
        aniName = "animation"
        layerScale = 1
        layerX = -10
        layerY = -30
    elseif self.data[19] == "google_park" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_google_park")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_google_park")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_google_park.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_google_park.json"
        aniName = "entrancePark"
        layerScale = 1
        layerX = -10
        layerY = -55
    elseif self.data[19] == "Double_the_Joy" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_Double_the_Joy")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_Double_the_Joy")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_Double_the_Joy.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_Double_the_Joy.json"
        aniName = "animation"
        layerScale = 1
        layerX = -5
        layerY = -40
    elseif self.data[19] == "Thanksgiving_Gift" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_Thanksgiving_Gift")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_Thanksgiving_Gift")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_Thanksgiving_Gift.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_Thanksgiving_Gift.json"
        aniName = "animation"
        layerScale = 1
        layerX = 4
        layerY = -43
    elseif self.data[19] == "Christmas_gift" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_Christmas_gift")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_Christmas_gift")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_Christmas_gift.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_Christmas_gift.json"
        aniName = "animation"
        layerScale = 1
        layerX = -60
        layerY = -33
    elseif self.data[19] == "March_Acceleration" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_March_Acceleration")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_March_Acceleration")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_March_Acceleration.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_March_Acceleration.json"
        aniName = "animation"
        layerScale = 1
        layerX = -25
        layerY = -33
    elseif self.data[19] == "Christmas_gift_jp" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_Christmas_gift_jp")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_Christmas_gift_jp")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_Christmas_gift_jp.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_Christmas_gift_jp.json"
        aniName = "animation"
        layerScale = 1
        layerX = -25
        layerY = -33
    elseif self.data[19] == "new_year" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_new_year")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_new_year")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_new_year.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_new_year.json"
        aniName = "animation"
        layerScale = 1
        layerX = -15
        layerY = -33
    elseif self.data[19] == "last_sale" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_last_sale")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_last_sale")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_last_sale.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_last_sale.json"
        aniName = "animation"
        layerScale = 1
        layerX = -10
        layerY = -33
    elseif self.data[19] == "last_sale_s2" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_last_sale_s2")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_last_sale_s2")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_last_sale_s2.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_last_sale_s2.json"
        aniName = "animation"
        layerScale = 1
        layerX = -10
        layerY = -33
    elseif self.data[19] == "goods_SpringFestival" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_goods_SpringFestival")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_goods_SpringFestival")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_goods_SpringFestival.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_goods_SpringFestival.json"
        aniName = "animation"
        layerScale = 1
        layerX = -10
        layerY = -33
    elseif self.data[19] == "Spring_Festival" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_Spring_Festival")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_Spring_Festival")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_Spring_Festival.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_Spring_Festival.json"
        aniName = "animation"
        layerScale = 1
        layerX = -10
        layerY = -33
    elseif self.data[19] == "chinese_newyeargoogle" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_chinese_newyeargoogle")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_chinese_newyeargoogle")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_chinese_newyeargoogle.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_chinese_newyeargoogle.json"
        aniName = "animation"
        layerScale = 1
        layerX = -10
        layerY = -33
    elseif self.data[19] == "dragon" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_dragon")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_dragon")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_dragon.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_dragon.json"
        aniName = "animation"
        layerScale = 1
        layerX = -10
        layerY = -33
    elseif self.data[19] == "Valentines_Day" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_Valentines_Day")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_Valentines_Day")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_Valentines_Day.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_Valentines_Day.json"
        aniName = "animation"
        layerScale = 1
        layerX = -10
        layerY = -33
    elseif self.data[19] == "kroea_ad" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_kroea_ad")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_kroea_ad")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_kroea_ad.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_kroea_ad.json"
        aniName = "animation"
        layerScale = 1
        layerX = -12
        layerY = -40
    elseif self.data[19] == "WomensDay" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_WomensDay")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_WomensDay")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_WomensDay.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_WomensDay.json"
        aniName = "animation"
        layerScale = 1
        layerX = -12
        layerY = -40
    elseif self.data[19] == "AprilFoolsDay" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_AprilFoolsDay")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_AprilFoolsDay")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_AprilFoolsDay.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_AprilFoolsDay.json"
        aniName = "animation"
        layerScale = 1
        layerX = -12
        layerY = -40
    elseif self.data[19] == "Easter_formal" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_Easter_formal")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_Easter_formal")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_Easter_formal.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_Easter_formal.json"
        aniName = "animation"
        layerScale = 1
        layerX = -12
        layerY = -40
    elseif self.data[19] == "Easter_informal" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_Easter_informal")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_Easter_informal")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_Easter_informal.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_Easter_informal.json"
        aniName = "animation"
        layerScale = 1
        layerX = -12
        layerY = -40
    elseif self.data[19] == "the_iran" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_the_iran")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_the_iran")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_the_iran.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_the_iran.json"
        aniName = "animation"
        layerScale = 1
        layerX = -12
        layerY = -40
    elseif self.data[19] == "DragonCastle" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_DragonCastle")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_DragonCastle")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_DragonCastle.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_DragonCastle.json"
        aniName = "animation"
        layerScale = 1
        layerX = -12
        layerY = -40
    elseif self.data[19] == "JP_yinghua" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_JP_yinghua")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_JP_yinghua")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_JP_yinghua.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_JP_yinghua.json"
        aniName = "animation"
        layerScale = 1
        layerX = -12
        layerY = -40
    elseif self.data[19] == "PoShuiJie" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_PoShuiJie")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_PoShuiJie")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_PoShuiJie.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_PoShuiJie.json"
        aniName = "animation"
        layerScale = 1
        layerX = -12
        layerY = -40
    elseif self.data[19] == "CastleSkin" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_CastleSkin")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_CastleSkin")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_CastleSkin.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_CastleSkin.json"
        aniName = "animation"
        layerScale = 1
        layerX = -12
        layerY = -40
    elseif self.data[19] == "LiYuQi" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_LiYuQi")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_LiYuQi")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_LiYuQi.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_LiYuQi.json"
        aniName = "liyuqi"
        layerScale = 1
        layerX = -12
        layerY = -40
    elseif self.data[19] == "crystal_gift_s" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_crystal_gift_s")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_crystal_gift_s")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_crystal_gift_s.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_crystal_gift_s.json"
        aniName = "rukou"
        layerScale = 1
        layerX = -12
        layerY = -40
    elseif self.data[19] == "LaoDongJie" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_LaoDongJie")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_LaoDongJie")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_LaoDongJie.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_LaoDongJie.json"
        aniName = "animation"
        layerScale = 1
        layerX = -12
        layerY = -40
    elseif self.data[19] == "TW_Libao" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_TW_Libao")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_TW_Libao")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_TW_Libao.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_TW_Libao.json"
        aniName = "animation2"
        layerScale = 1
        layerX = -12
        layerY = -40
    elseif self.data[19] == "MothersDay" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_MothersDay")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_MothersDay")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_MothersDay.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_MothersDay.json"
        aniName = "animation"
        layerScale = 1
        layerX = -12
        layerY = -40
    elseif self.data[19] == "RU_Libao" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_RU_Libao")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_RU_Libao")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_RU_Libao.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_RU_Libao.json"
        aniName = "animation"
        layerScale = 1
        layerX = -12
        layerY = -40
    elseif self.data[19] == "DragonStone" then
        -- local bFile = LuaController:checkSkeletonFile(targetPlatform .. "sk_DragonStone")
        dic1:setObject(CCString:create(tostring(targetPlatform .. "sk_DragonStone")), "1")
        local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
        if bFile == false then
            return
        end
        altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_DragonStone.atlas"
        json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_DragonStone.json"
        aniName = "animation"
        layerScale = 1
        layerX = -25
        layerY = -45
    end

    if json == "" then
        return
    end
    if altas == "" then
        return
    end

    self.m_ani1Layer:removeAllChildren(true)
    dic1:setObject(self.m_ani1Layer, "1")
    dic1:setObject(CCString:create(tostring(json)), "2")
    dic1:setObject(CCString:create(tostring(altas)), "3")
    dic1:setObject(CCString:create(tostring(aniName)), "4")
    if self.data[19] == "kroea_ad" then
        -- LuaController:addSkeletonAnimation(self.m_ani1Layer,json,altas,aniName,0.8)
        dic1:setObject(CCFloat:create(0.8), "5")
    else
        -- LuaController:addSkeletonAnimation(self.m_ani1Layer,json,altas,aniName,1)
        dic1:setObject(CCFloat:create(1), "5")
    end
    LuaController:comFunc("addSkeletonAnimation", dic1)
    self.m_ani1Layer:setScale(layerScale)
    self.m_ani1Layer:setPosition(CCPoint(layerX,layerY))
end
function GoldExchangeIcon:initParticale()
    print "GoldExchangeIcon:initParticale"
    local dic1 = CCDictionary:create()
    if self.data[19] == "wargift" or self.data[19] == "LiBao_wargift" then
        if nil ~= self.m_ani1Layer then
            print "111"
            local size = self.m_ani1Layer:getContentSize()
            -- local particles1 = LuaController:createParticleForLua(self.rootPath .. "/particles/ActivitiesWar_1")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/ActivitiesWar_1")), "1")
            local particles1 = LuaController:comFunc("createParticleForLua", dic1)
            if nil ~= particles1 then
                self.m_ani1Layer:addChild(particles1)
                particles1:setPosition(cc.p(size.width*0.5,size.height*0.2))
            end
            -- local particles2 = LuaController:createParticleForLua(self.rootPath .. "/particles/ActivitiesWar_2")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/ActivitiesWar_2")), "1")
            local particles2 = LuaController:comFunc("createParticleForLua", dic1)
            if nil ~= particles2 then
                self.m_ani1Layer:addChild(particles2)
                particles2:setPosition(cc.p(size.width*0.5,size.height*0.2))
            end
            -- local particles3 = LuaController:createParticleForLua(self.rootPath .. "/particles/ActivitiesWar_3")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/ActivitiesWar_3")), "1")
            local particles3 = LuaController:comFunc("createParticleForLua", dic1)
            if nil ~=particles3 then
                self.m_ani1Layer:addChild(particles3)
                particles3:setPosition(cc.p(size.width*0.5,size.height*0.2))
            end
            if nil ~= self.m_ani2Layer then
                -- local particles4 = LuaController:createParticleForLua(self.rootPath .. "/particles/ActivitiesWar_4")
                dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/ActivitiesWar_4")), "1")
                local particles4 = LuaController:comFunc("createParticleForLua", dic1)
                if nil ~= particles4 then
                    self.m_ani2Layer:addChild(particles4)
                    particles4:setPosition(cc.p(size.width*0.6,size.height*0.37))
                end
                -- local particles5 = LuaController:createParticleForLua(self.rootPath .. "/particles/ActivitiesWar_5")
                dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/ActivitiesWar_5")), "1")
                local particles5 = LuaController:comFunc("createParticleForLua", dic1)
                if nil ~= particles5 then
                    self.m_ani2Layer:addChild(particles5)
                    particles5:setPosition(cc.p(size.width*0.4,size.height*0.37))
                end
                -- local particles6 = LuaController:createParticleForLua(self.rootPath .. "/particles/ActivitiesWar_6")
                dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/ActivitiesWar_6")), "1")
                local particles6 = LuaController:comFunc("createParticleForLua", dic1)
                if nil ~= particles6 then
                    self.m_ani2Layer:addChild(particles6)
                    particles6:setPosition(cc.p(size.width*0.5,size.height*0.5))
                end
            end
        end
    elseif self.data[19] == "kingdom" or self.data[19] == "LiBao_kingdom" then
        if nil ~= self.m_ani2Layer then
            local size = self.m_ani2Layer:getContentSize()
            -- local particlesa= LuaController:createParticleForLua(self.rootPath .. "/particles/KingdomIcon_1")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/KingdomIcon_1")), "1")
            local particlesa = LuaController:comFunc("createParticleForLua", dic1)
            if nil ~= particlesa then
                self.m_ani2Layer:addChild(particlesa)
                particlesa:setPosition(cc.p(size.width*0.5,size.height*0.5))
            end
            -- local particlesb = LuaController:createParticleForLua(self.rootPath .. "/particles/KingdomIcon_2")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/KingdomIcon_2")), "1")
            local particlesb = LuaController:comFunc("createParticleForLua", dic1)
            if nil ~= particlesb then
                self.m_ani2Layer:addChild(particlesb)
                particlesb:setPosition(cc.p(size.width*0.5,size.height*0.5))
            end  
            -- local particlesc = LuaController:createParticleForLua(self.rootPath .. "/particles/KingdomIcon_3")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/KingdomIcon_3")), "1")
            local particlesc = LuaController:comFunc("createParticleForLua", dic1)
            if nil ~= particlesc then
                self.m_ani2Layer:addChild(particlesc)
                particlesc:setPosition(cc.p(size.width*0.5,size.height*0.5))
            end
        end
    elseif self.data[19] == "build_kingdom" or self.data[19] == "LiBao_build_kingdom" then
        if nil ~= self.m_ani2Layer then
            local size = self.m_ani2Layer:getContentSize()
            -- local particlesa= LuaController:createParticleForLua(self.rootPath .. "/particles/KingdomIcon_1")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/KingdomIcon_1")), "1")
            local particlesa = LuaController:comFunc("createParticleForLua", dic1)
            if nil ~= particlesa then
                self.m_ani2Layer:addChild(particlesa)
                particlesa:setPosition(cc.p(size.width*0.5,size.height*0.5))
            end
            -- local particlesb = LuaController:createParticleForLua(self.rootPath .. "/particles/KingdomIcon_2")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/KingdomIcon_2")), "1")
            local particlesb = LuaController:comFunc("createParticleForLua", dic1)
            if nil ~= particlesb then
                self.m_ani2Layer:addChild(particlesb)
                particlesb:setPosition(cc.p(size.width*0.5,size.height*0.5))
            end  
            -- local particlesc = LuaController:createParticleForLua(self.rootPath .. "/particles/KingdomIcon_3")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/KingdomIcon_3")), "1")
            local particlesc = LuaController:comFunc("createParticleForLua", dic1)
            if nil ~= particlesc then
                self.m_ani2Layer:addChild(particlesc)
                particlesc:setPosition(cc.p(size.width*0.5,size.height*0.5))
            end
        end
    elseif self.data[19] == "alliance" then
        if nil ~= self.m_ani1Layer then
            local size = self.m_ani1Layer:getContentSize()
            -- local particlesa= LuaController:createParticleForLua(self.rootPath .. "/particles/ActivitiesAlliance_1")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/ActivitiesAlliance_1")), "1")
            local particlesa = LuaController:comFunc("createParticleForLua", dic1)
            if nil ~= particlesa then
                self.m_ani1Layer:addChild(particlesa)
                particlesa:setPosition(cc.p(size.width*0.5,size.height*0.5))
            end
            if nil ~= self.m_ani2Layer then
                -- local particlesb = LuaController:createParticleForLua(self.rootPath .. "/particles/ActivitiesAlliance_2")
                dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/ActivitiesAlliance_2")), "1")
                local particlesb = LuaController:comFunc("createParticleForLua", dic1)

                if nil ~= particlesb then
                    self.m_ani2Layer:addChild(particlesb)
                    particlesb:setPosition(cc.p(size.width*0.38,size.height*0.65))
                end
                -- local particlesc = LuaController:createParticleForLua(self.rootPath .. "/particles/ActivitiesAlliance_3")
                dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/ActivitiesAlliance_3")), "1")
                local particlesc = LuaController:comFunc("createParticleForLua", dic1)

                if nil ~= particlesc then
                    self.m_ani2Layer:addChild(particlesc)
                    particlesc:setPosition(cc.p(size.width*0.62,size.height*0.65))
                end
            end
        end
    elseif self.data[19] == "alliance1" or self.data[19] == "LiBao_alliance1" then
        if nil ~= self.m_ani1Layer then
            local size = self.m_ani1Layer:getContentSize()
            -- local particlesa= LuaController:createParticleForLua(self.rootPath .. "/particles/ActivitiesAlliance_1")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/ActivitiesAlliance_1")), "1")
            local particlesa = LuaController:comFunc("createParticleForLua", dic1)
            if nil ~= particlesa then
                self.m_ani1Layer:addChild(particlesa)
                particlesa:setPosition(cc.p(size.width*0.5,size.height*0.5))
            end
            if nil ~= self.m_ani2Layer then
                -- local particlesb = LuaController:createParticleForLua(self.rootPath .. "/particles/ActivitiesAlliance_2")
                dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/ActivitiesAlliance_2")), "1")
                local particlesb = LuaController:comFunc("createParticleForLua", dic1)

                if nil ~= particlesb then
                    self.m_ani2Layer:addChild(particlesb)
                    particlesb:setPosition(cc.p(size.width*0.38,size.height*0.65))
                end
                -- local particlesc = LuaController:createParticleForLua(self.rootPath .. "/particles/ActivitiesAlliance_3")
                dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/ActivitiesAlliance_3")), "1")
                local particlesc = LuaController:comFunc("createParticleForLua", dic1)

                if nil ~= particlesc then
                    self.m_ani2Layer:addChild(particlesc)
                    particlesc:setPosition(cc.p(size.width*0.62,size.height*0.65))
                end
            end
        end
    elseif self.data[19] == "king" or self.data[19] == "LiBao_king" then
        if nil ~= self.m_ani2Layer then
            local size = self.m_ani2Layer:getContentSize()
            -- local particlesa= LuaController:createParticleForLua(self.rootPath .. "/particles/Rose_3")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/Rose_3")), "1")
            local particlesa = LuaController:comFunc("createParticleForLua", dic1)

            if nil ~= particlesa then
                self.m_ani2Layer:addChild(particlesa)
                particlesa:setPosition(cc.p(size.width*0.5,size.height*0.5))
            end
            -- local particlesb = LuaController:createParticleForLua(self.rootPath .. "/particles/VIPGlow_3")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/VIPGlow_3")), "1")
            local particlesb = LuaController:comFunc("createParticleForLua", dic1)
            if nil ~= particlesb then
                self.m_ani2Layer:addChild(particlesb)
                particlesb:setPosition(cc.p(size.width*0.5,size.height*0.5))
            end
        end
    elseif self.data[19] == "war_resource" or self.data[19] == "LiBao_war_resource" then
        if nil ~= self.m_ani2Layer then
            local size = self.m_ani2Layer:getContentSize()
            -- local particlesa= LuaController:createParticleForLua(self.rootPath .. "/particles/Rose_3")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/Rose_3")), "1")
            local particlesa = LuaController:comFunc("createParticleForLua", dic1)
            if nil ~= particlesa then
                self.m_ani2Layer:addChild(particlesa)
                particlesa:setPosition(cc.p(size.width*0.5,size.height*0.5))
            end
            -- local particlesb = LuaController:createParticleForLua(self.rootPath .. "/particles/VIPGlow_3")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/VIPGlow_3")), "1")
            local particlesb = LuaController:comFunc("createParticleForLua", dic1)
            if nil ~= particlesb then
                self.m_ani2Layer:addChild(particlesb)
                particlesb:setPosition(cc.p(size.width*0.5,size.height*0.5))
            end
        end
    elseif self.data[19] == "spring" or self.data[19] == "LiBao_spring" then
        if nil ~= self.m_ani1Layer then
            local size = self.m_ani1Layer:getContentSize()
            -- local particlesa= LuaController:createParticleForLua(self.rootPath .. "/particles/Rose_3")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/Rose_3")), "1")
            local particlesa = LuaController:comFunc("createParticleForLua", dic1)
            if nil ~= particlesa then
                self.m_ani1Layer:addChild(particlesa)
                particlesa:setPosition(cc.p(size.width*0.5,size.height*0.5))
            end
        end
    elseif self.data[19] == "build_alliance" or self.data[19] == "LiBao_build_alliance" then
        if nil ~= self.m_ani2Layer then
            print "111"
            print (self.rootPath)
            local size = self.m_ani2Layer:getContentSize()
            -- local particlesb = LuaController:createParticleForLua(self.rootPath .. "/particles/KingdomIcon_2")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/KingdomIcon_2")), "1")
            local particlesb = LuaController:comFunc("createParticleForLua", dic1)
            if nil ~= particlesb then
                self.m_ani2Layer:addChild(particlesb)
                particlesb:setPosition(cc.p(size.width*0.5,size.height*0.5))
            end  
            -- local particlesc = LuaController:createParticleForLua(self.rootPath .. "/particles/KingdomIcon_3")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/KingdomIcon_3")), "1")
            local particlesc = LuaController:comFunc("createParticleForLua", dic1)

            if nil ~= particlesc then
                self.m_ani2Layer:addChild(particlesc)
                particlesc:setPosition(cc.p(size.width*0.5,size.height*0.5))
            end
            print "222"
        end
    elseif self.data[19] == "equip_build" or self.data[19] == "LiBao_equip_build" then
        if nil ~= self.m_ani2Layer then
            local size = self.m_ani2Layer:getContentSize()
            -- local particlesa= LuaController:createParticleForLua(self.rootPath .. "/particles/ActivitiesEquipBuild_1")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/ActivitiesEquipBuild_1")), "1")
            local particlesa = LuaController:comFunc("createParticleForLua", dic1)

            if nil ~= particlesa then
                self.m_ani2Layer:addChild(particlesa)
                particlesa:setPosition(cc.p(size.width*0.5,0))
            end
            -- local particlesb= LuaController:createParticleForLua(self.rootPath .. "/particles/ActivitiesEquipBuild_2")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/ActivitiesEquipBuild_2")), "1")
            local particlesb = LuaController:comFunc("createParticleForLua", dic1)

            if nil ~= particlesb then
                self.m_ani2Layer:addChild(particlesb)
                particlesb:setPosition(cc.p(size.width*0.5,0))
            end
            -- local particlesc= LuaController:createParticleForLua(self.rootPath .. "/particles/ActivitiesEquipBuild_3")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/ActivitiesEquipBuild_3")), "1")
            local particlesc = LuaController:comFunc("createParticleForLua", dic1)
            if nil ~= particlesc then
                self.m_ani2Layer:addChild(particlesc)
                particlesc:setPosition(cc.p(size.width*0.5,0))
            end
        end
    elseif self.data[19] == "trap_build" or self.data[19] == "LiBao_trap_build" then
        if nil ~= self.m_ani2Layer then
            local size = self.m_ani2Layer:getContentSize()
            -- local particlesa= LuaController:createParticleForLua(self.rootPath .. "/particles/ActivitiesEquipBuild_1")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/ActivitiesEquipBuild_1")), "1")
            local particlesa = LuaController:comFunc("createParticleForLua", dic1)

            if nil ~= particlesa then
                self.m_ani2Layer:addChild(particlesa)
                particlesa:setPosition(cc.p(size.width*0.5,size.height*0.5))
            end
            -- local particlesb= LuaController:createParticleForLua(self.rootPath .. "/particles/ActivitiesEquipBuild_2")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/ActivitiesEquipBuild_2")), "1")
            local particlesb = LuaController:comFunc("createParticleForLua", dic1)

            if nil ~= particlesb then
                self.m_ani2Layer:addChild(particlesb)
                particlesb:setPosition(cc.p(size.width*0.5,size.height*0.5))
            end
            -- local particlesc= LuaController:createParticleForLua(self.rootPath .. "/particles/ActivitiesEquipBuild_3")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/ActivitiesEquipBuild_3")), "1")
            local particlesc = LuaController:comFunc("createParticleForLua", dic1)

            if nil ~= particlesc then
                self.m_ani2Layer:addChild(particlesc)
                particlesc:setPosition(cc.p(size.width*0.5,size.height*0.5))
            end
        end
    elseif self.data[19] == "kingdom_war" or self.data[19] == "LiBao_kingdom_war" then
        if nil ~= self.m_ani2Layer then
            local size = self.m_ani2Layer:getContentSize()
            -- local particlesa= LuaController:createParticleForLua(self.rootPath .. "/particles/ActivitiesEquipBuild_1")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/ActivitiesEquipBuild_1")), "1")
            local particlesa = LuaController:comFunc("createParticleForLua", dic1)

            if nil ~= particlesa then
                self.m_ani2Layer:addChild(particlesa)
                particlesa:setPosition(cc.p(size.width*0.5,0))
            end
            -- local particlesb= LuaController:createParticleForLua(self.rootPath .. "/particles/ActivitiesEquipBuild_2")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/ActivitiesEquipBuild_2")), "1")
            local particlesb = LuaController:comFunc("createParticleForLua", dic1)

            if nil ~= particlesb then
                self.m_ani2Layer:addChild(particlesb)
                particlesb:setPosition(cc.p(size.width*0.5,0))
            end
            -- local particlesc= LuaController:createParticleForLua(self.rootPath .. "/particles/ActivitiesEquipBuild_3")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/ActivitiesEquipBuild_3")), "1")
            local particlesc = LuaController:comFunc("createParticleForLua", dic1)
            if nil ~= particlesc then
                self.m_ani2Layer:addChild(particlesc)
                particlesc:setPosition(cc.p(size.width*0.5,0))
            end
        end
    elseif self.data[19] == "ru_gift" then
        if nil ~= self.m_ani2Layer then
            local size = self.m_ani2Layer:getContentSize()
            -- local particlesa= LuaController:createParticleForLua(self.rootPath .. "/particles/KingdomIcon_1")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/KingdomIcon_1")), "1")
            local particlesa = LuaController:comFunc("createParticleForLua", dic1)

            if nil ~= particlesa then
                self.m_ani2Layer:addChild(particlesa)
                particlesa:setPosition(cc.p(size.width*0.5,size.height*0.5))
            end
            -- local particlesb = LuaController:createParticleForLua(self.rootPath .. "/particles/KingdomIcon_2")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/KingdomIcon_2")), "1")
            local particlesb = LuaController:comFunc("createParticleForLua", dic1)

            if nil ~= particlesb then
                self.m_ani2Layer:addChild(particlesb)
                particlesb:setPosition(cc.p(size.width*0.5,size.height*0.5))
            end  
            -- local particlesc = LuaController:createParticleForLua(self.rootPath .. "/particles/KingdomIcon_3")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/KingdomIcon_3")), "1")
            local particlesc = LuaController:comFunc("createParticleForLua", dic1)

            if nil ~= particlesc then
                self.m_ani2Layer:addChild(particlesc)
                particlesc:setPosition(cc.p(size.width*0.5,size.height*0.5))
            end
        end
    elseif self.data[19] == "first" or self.data[19] == "LiBao_first" then
        if nil ~= self.m_ani2Layer then
            local size = self.m_ani2Layer:getContentSize()
            -- local particlesa= LuaController:createParticleForLua(self.rootPath .. "/particles/KingdomIcon_1")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/KingdomIcon_1")), "1")
            local particlesa = LuaController:comFunc("createParticleForLua", dic1)

            if nil ~= particlesa then
                self.m_ani2Layer:addChild(particlesa)
                particlesa:setPosition(cc.p(size.width*0.5,0))
            end
            -- local particlesb = LuaController:createParticleForLua(self.rootPath .. "/particles/KingdomIcon_2")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/KingdomIcon_2")), "1")
            local particlesb = LuaController:comFunc("createParticleForLua", dic1)

            if nil ~= particlesb then
                self.m_ani2Layer:addChild(particlesb)
                particlesb:setPosition(cc.p(size.width*0.5,size.height*0.5))
            end  
            -- local particlesc = LuaController:createParticleForLua(self.rootPath .. "/particles/KingdomIcon_3")
            dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/KingdomIcon_3")), "1")
            local particlesc = LuaController:comFunc("createParticleForLua", dic1)

            if nil ~= particlesc then
                self.m_ani2Layer:addChild(particlesc)
                particlesc:setPosition(cc.p(size.width*0.5,size.height*0.5))
            end
        end
    elseif self.data[19] == "Double_the_Joy" then
        if nil ~= self.m_ani2Layer then
            local size = self.m_ani2Layer:getContentSize()
            for i=1,4 do
                -- local particle1= LuaController:createParticleForLua(self.rootPath .. "/particles/UiFire_"..string.format(i))
                dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/UiFire_" .. tostring(i))), "1")
                local particle1 = LuaController:comFunc("createParticleForLua", dic1)

                if nil ~= particle1 then
                    self.m_ani2Layer:addChild(particle1)
                    particle1:setPosition(CCPoint(size.width*0.23,size.height*0.4))
                end
            end
        end
    elseif self.data[19] == "EN_Libao" then
        if nil ~= self.m_ani2Layer then
            local size = self.m_ani2Layer:getContentSize()
            for i=1,3 do
                local idx = i-1
                -- local particle1= LuaController:createParticleForLua(self.rootPath .. "/particles/England_"..string.format(idx))
                dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/England_" .. tostring(idx))), "1")
                local particle1 = LuaController:comFunc("createParticleForLua", dic1)
                if nil ~= particle1 then
                    particle1:setScale(2.5)
                    self.m_ani2Layer:addChild(particle1)
                    -- particle1:setPosition(CCPoint(size.width*0.23,size.height*0.4))
                end
            end
        end
    elseif self.data[19] == "DE_Libao" then
        if nil ~= self.m_ani2Layer then
            local size = self.m_ani2Layer:getContentSize()
            -- for i=1,3 do
                -- local idx = i-1
                -- local particle1= LuaController:createParticleForLua(self.rootPath .. "/particles/Germany")
                dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/Germany")), "1")
                local particle1 = LuaController:comFunc("createParticleForLua", dic1)
                if nil ~= particle1 then
                    particle1:setScale(2.5)
                    self.m_ani2Layer:addChild(particle1)
                    particle1:setPosition(CCPoint(-60,0))
                end
            -- end
        end
    elseif self.data[19] == "US_Libao" or self.data[19] == "LiBao_US_Libao" then
        if nil ~= self.m_ani2Layer then
            local size = self.m_ani2Layer:getContentSize()
            for i=1,2 do
                local idx = i-1
                -- local particle1= LuaController:createParticleForLua(self.rootPath .. "/particles/American_"..string.format(idx))
                dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/American_" .. tostring(idx))), "1")
                local particle1 = LuaController:comFunc("createParticleForLua", dic1)
                if nil ~= particle1 then
                    particle1:setScale(2.5)
                    self.m_ani2Layer:addChild(particle1)
                    particle1:setPosition(CCPoint(10,40))
                end
            end
        end
    elseif self.data[19] == "LiBao_JuLong" then
        if nil ~= self.m_ani2Layer then
            local size = self.m_ani2Layer:getContentSize()
            for i=1,2 do
                local idx = i-1
                dic1:setObject(CCString:create(tostring(self.rootPath .. "/particles/DragonGift_" .. tostring(idx))), "1")
                local particle1 = LuaController:comFunc("createParticleForLua", dic1)
                if nil ~= particle1 then
                    -- particle1:setScale(2.5)
                    self.m_ani2Layer:addChild(particle1)
                    particle1:setPosition(CCPoint(50,50))
                end
            end
        end
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function GoldExchangeIcon:initWithCommon(parent,path,params)
    local dic1 = CCDictionary:create()
    local strPath = string.format(path)
    self.rootPath = strPath
    self.parentNode = parent
    -- self:setData(params)

    -- local popImg = string.format(self.data[19])
    -- local firstIdx = string.find(popImg,"_",1)
    -- local secondStr = string.sub(popImg,firstIdx+1,string.len(popImg))
    -- print("(COK2-Icon)secondStr:"..secondStr);
    -- loadLuaResource(self.rootPath .. "/resources/LiBao_"..secondStr..".plist")
    -- print("(COK2-Icon)path:"..self.rootPath .. "/resources/LiBao_"..secondStr..".plist")
    -- loadLuaResource(self.rootPath .. "/resources/".. self.data[19] .."icon.plist")
    local ccbiUrl = ""
    local popImg = string.format(self.data[19])
    local ccb_file = strPath .. "/ccbi/"..popImg.."Icon.ccbi"
    print(ccb_file)
    if cc.FileUtils:getInstance():isFileExist(ccb_file) then
        ccbiUrl = ccb_file
        loadLuaResource(self.rootPath .. "/resources/"..popImg..".plist")
    else
        ccbiUrl = strPath .. "/ccbi/LiBaoCommonIcon.ccbi"--self:getCCBI()
    end

    print(ccbiUrl)
    local proxy = cc.CCBProxy:create()
    -- print "GoldExchangeIcon:init(parent,path,params)"
    local ccbnode = CCBReaderLoad(ccbiUrl,proxy,GoldExchangeLuaIcon)
    if ccbnode ~= nil then
        -- print "-----401----"
        local layer = tolua.cast(ccbnode,"cc.Layer")
        --print "-----402----"

        if nil ~= GoldExchangeLuaIcon["m_timeLabel"] then
        --print "-----403----"

            self.m_timeLabel = tolua.cast(GoldExchangeLuaIcon["m_timeLabel"],"cc.Label")
            --self.m_timeLabel = nil
        end
        --print "-----404----"

        if nil ~= GoldExchangeLuaIcon["m_ani1"] then
        --print "-----405----"

            self.m_ani1Layer = tolua.cast(GoldExchangeLuaIcon["m_ani1"],"cc.LayerColor")
        end
        --print "-----406----"

        if nil ~= GoldExchangeLuaIcon["m_ani2"] then
        --print "-----407----"

            self.m_ani2Layer = tolua.cast(GoldExchangeLuaIcon["m_ani2"],"cc.LayerColor")
        end
        --print "-----408----"

        self:initParticale()
        --print "-----409----"

        self:initCommonSkeleton()
        --print "-----410----"

        if nil ~= self.parentNode then
        --print "-----411----"

            -- self.parentNode:addChild(ccbnode)
            self.parentNode:addChild(self)
            self:addChild(ccbnode)
        end
        --print "-----412----"

        if self.data[19] == "normal_gift" then
        --print "-----413----"

            if nil ~= self.data[10] then
                local keyStr = string.format(self.data[10])
                -- local titleStr = string.format(LuaController:getLang(keyStr))
                dic1:setObject(CCString:create(tostring(keyStr)), "1")
                local titleStr = LuaController:comFunc("getLang", dic1):getCString()
                self.m_timeLabel:setString(titleStr)
            end
        else
            -- print "-----414----"
            local function scheduleBack(  )
                -- print "_____GoldExchangeIcon:scheduleBack"
                local dic2 = CCDictionary:create()
                if self.data ~= nil then
                    if nil ~= self.m_timeLabel then
                        -- local curTime = LuaController:getWorldTime()
                        local curTime = LuaController:comFunc("getWorldTime", 0):getValue()
                        local expTime = tonumber(self.data[14])
                        local endTime = tonumber(self.data[13])
                        local lastTime = endTime - curTime
                        if expTime>0 then
                            local count =(endTime- curTime)/(expTime*3600)
                            count = math.floor(count)
                            lastTime=endTime-count*(expTime*3600)-curTime
                        else
                            lastTime = endTime - curTime
                        end
                        -- local timeStr = string.format(LuaController:getSECLang(lastTime))
                        dic2:setObject(CCInteger:create(tonumber(lastTime)), "1")
                        local timeStr = LuaController:comFunc("getSECLang", dic2):getCString()
                        self.m_timeLabel:setString(timeStr)
                        local isShow = 1
                        if ((endTime - curTime) <= 0) then
                            isShow = 0
                        end
                        if (string.format(self.data[15]) == "1") then
                            isShow = 0
                        end
                        if isShow == 0 then
                            self.m_timeLabel:setString("")
                            releaseLuaResource(self.rootPath .. "/resources/".. self.data[19])
                            self:removeAllEvent()
                            if nil ~= self.parentNode then
                                self.parentNode:setVisible(false)
                            end
                        else
                            if nil ~= self.parentNode then
                                self.parentNode:setVisible(true)
                            end
                        end
                    end
                end
            end

            local function eventHandler( eventType )
                if eventType == "enter" then
                    --print " GoldExchangeIcon enter"
                    scheduleBack()
                    self.m_entryId = tonumber(ccbnode:getScheduler():scheduleScriptFunc(scheduleBack, 1, false))
                elseif eventType == "exit" then
                    --print "GoldExchangeIcon exit"
                    if nil ~= self.m_entryId then
                        ccbnode:getScheduler():unscheduleScriptEntry(self.m_entryId)
                    end
                elseif eventType == "cleanup" then
                    --print "GoldExchangeIcon cleanup"
                    ccbnode:unregisterScriptHandler()
                end
            end
            ccbnode:registerScriptHandler(eventHandler)
        end
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function GoldExchangeIcon:initCommonSkeleton()
    print "GoldExchangeIcon:initCommonSkeleton"
    local dic1 = CCDictionary:create()
    if nil==self.m_ani1Layer then
        return
    end
    local targetPlatform = cc.Application:getInstance():getTargetPlatform()
    if (3 == targetPlatform) then
        targetPlatform = "android/"
    else
        targetPlatform = "ios/"
    end

    local layerScale = 1
    local layerX = 0
    local layerY = 0
    local altas = ""
    local json = ""
    local aniName = "animation"

    local popImg = string.format(self.data[19])

    -- local bFile = LuaController:checkSkeletonFile(targetPlatform .."sk_"..popImg.."_icon")
    dic1:setObject(CCString:create(tostring(targetPlatform .."sk_"..popImg.."_icon")), "1")
    local bFile = LuaController:comFunc("checkSkeletonFile", dic1):getValue()
    if bFile == false then
        return
    end
    altas = self.rootPath .. "/skeleton/"..targetPlatform .."sk_"..popImg.."_icon.atlas"
    json = self.rootPath .. "/skeleton/"..targetPlatform .."sk_"..popImg.."_icon.json"
    aniName = "animation"
    layerScale = 1
    -- layerX = -60
    -- layerY = -33
    layerX = -13
    layerY = -33

    if json == "" then
        return
    end
    if altas == "" then
        return
    end

    if self.data[19] == "LiBao_crystal_gift" then
        aniName = "rukou"
        layerX = -12
        layerY = -40
    elseif self.data[19] == "LiBao_resource_gift" then
        layerScale = 0.9
        layerX = 0
        layerY = -40
    elseif self.data[19] == "LiBao_DragonCastle" then
        layerX = -12
        layerY = -40
    elseif self.data[19] == "LiBao_build_alliance" then
        layerScale = 0.9
        layerX = -10
        layerY = -50
    elseif self.data[19] == "LiBao_peace_gift" then
        layerX = -10
        layerY = -55
    elseif self.data[19] == "LiBao_ChildrensDay" then
        layerX = -10
        layerY = -55
    elseif self.data[19] == "LiBao_DragonStone" then
        layerX = -30
        layerY = -50
    elseif self.data[19] == "LiBao_RU_Libao" then
        layerX = 0
        layerY = -50
    elseif self.data[19] == "LiBao_HK_Libao" then
        layerX = -10
        layerY = -33
    elseif self.data[19] == "LiBao_JP_Libao" then
        layerX = -13
        layerY = -33
    elseif self.data[19] == "LiBao_Google" then
        layerX = -13
        layerY = -33
    elseif self.data[19] == "LiBao_DuanWuJie" then
        layerX = -13
        layerY = -33
    elseif self.data[19] == "LiBao_FathersDay" then
        layerScale = 0.8
        layerX = -13
        layerY = -33
    elseif self.data[19] == "LiBao_year2" then
        layerScale = 0.8
        layerX = -13
        layerY = -33
    elseif self.data[19] == "LiBao_EuropeanCup" then
        layerScale = 0.8
        layerX = -13
        layerY = -33
    elseif self.data[19] == "LiBao_year2PiFu" then
        layerScale = 0.8
        layerX = -13
        layerY = -33
    elseif self.data[19] == "LiBao_JuLong" then
        layerScale = 0.8
        layerX = -13
        layerY = -33
    elseif self.data[19] == "LiBao_Technology" then
        layerScale = 0.8
        layerX = -13
        layerY = -33
    end

    self.m_ani1Layer:removeAllChildren(true)
    dic1:setObject(self.m_ani1Layer, "1")
    dic1:setObject(CCString:create(tostring(json)), "2")
    dic1:setObject(CCString:create(tostring(altas)), "3")
    dic1:setObject(CCString:create(tostring(aniName)), "4")
    dic1:setObject(CCFloat:create(1), "5")
    LuaController:comFunc("addSkeletonAnimation", dic1)
    -- LuaController:addSkeletonAnimation(self.m_ani1Layer,json,altas,aniName,1)
    dic1:setObject(self.m_ani1Layer, "1")
    dic1:setObject(CCString:create(tostring(json)), "2")
    dic1:setObject(CCString:create(tostring(altas)), "3")
    dic1:setObject(CCString:create(tostring(aniName)), "4")
    dic1:setObject(CCFloat:create(1), "5")
    LuaController:comFunc("addSkeletonAnimation", dic1)
    self.m_ani1Layer:setScale(layerScale)
    self.m_ani1Layer:setPosition(cc.p(layerX,layerY))
    print "333"
end
