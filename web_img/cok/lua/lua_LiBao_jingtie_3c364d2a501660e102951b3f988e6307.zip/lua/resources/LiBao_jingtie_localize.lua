local localize={
	["CN"]=1, 
	["JA"]=2, 
}
return localize
