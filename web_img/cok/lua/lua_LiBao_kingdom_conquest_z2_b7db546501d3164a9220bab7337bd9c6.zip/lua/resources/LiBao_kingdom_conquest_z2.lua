cfg_table = {
	["layerX"] = -17,
	["layerY"] = -3,
	["layerScale"] = 1,
}