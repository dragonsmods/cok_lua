cfg_table = {
	-- ["localize"]={["CN"]=1,["TW"]=2},
	["iconOrder"] = 2,  -- 是否显示图片  值大小为显示顺序，大的最后显示
	["particleOrder"] = 3,  -- 是否显示粒子,particle 值大小为显示顺序，大的最后显示
	-- ["spineOrder"] = 1,   -- 是否显示spine, 与spineHide不共存 值大小为显示顺序，大的最后显示
	-- ["spineHide"] = true,  -- 为兼容旧版本的特殊处理，如果该礼包有旧的spine动画，且不打算显示spine动画，则必须配置这个参数，如果没有旧的spine动画，则无需配置
	["particle"] = {		-- 粒子特效显示逻辑，与particleOrder共存，particleOrder存在，则particle必须存在
		["parName"] = {   -- 粒子特效名称
			[1] = "3year_star1",
			[2] = "3year_star2",
			[3] = "",
			[4] = "",
		},
		["parPos"] = 0,  -- 粒子特效原点， 0:在图片下方，1:在图片中间，2:在图片中间，默认为1
	},
}