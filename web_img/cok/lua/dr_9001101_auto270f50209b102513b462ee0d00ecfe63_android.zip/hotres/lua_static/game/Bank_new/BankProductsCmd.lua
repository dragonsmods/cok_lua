
local MSG_REFRESH_BANK_LIST = "MSG_REFRESH_BANK_LIST"
local MSG_REFRESH_RECORD_LIST = "MSG_REFRESH_RECORD_LIST"
local MSG_BANG_BUY_HISTORY = "MSG_BANG_BUY_HISTORY"
local MSG_BANG_BUY = "MSG_BANG_BUY"
BankProductsCmd = class("BankProductsCmd", LuaCommandBase)
function BankProductsCmd:create()
    local ret = BankProductsCmd.new()
    ret:initWithName("bank.enter")
    return ret
end

function BankProductsCmd:handleReceive(dict)
    -- if (dict:valueForKey("cmd"):getCString() ~= EGG_SMASHING_INFO) then
    --     return false
    -- end
    if (dict:valueForKey("cmd"):getCString() ~= "bank.enter") then
        return false
    end
    local tbl = dictToLuaTable(dict)
    local params = dict:objectForKey("params")
    if params:objectForKey("errorCode") ~= nil then
        local pStr = params:valueForKey("errorCode"):getCString()
        MyPrint("BankProductsBuyCmd:handleReceive errorCode",pStr)
        -- if CCCommonUtilsForLua:call("isAllowShowHandleRecieveErrorDialog",pStr) then
            CCCommonUtilsForLua:call("flyText",_lang(pStr))
        -- end
    end 
    dump(tbl,"BankProductsCmd:handleReceive")   
    BankController:getInstance():praseData(dict)
    CCSafeNotificationCenter:postNotification(MSG_REFRESH_BANK_LIST,dict)
    return true
end

--------------------------------------------------------------------------

BankProductsBuyCmd  = class("BankProductsBuyCmd", LuaCommandBase)

function BankProductsBuyCmd:create(type,sum)
    local ret = BankProductsBuyCmd.new()
    ret:initWithName("bank.store")
    ret:putParam("type",CCInteger:create(type))
    ret:putParam("num",CCInteger:create(sum))
    return ret
end

function BankProductsBuyCmd:handleReceive(dict)
    -- if (dict:valueForKey("cmd"):getCString() ~= EGG_SMASHING_INFO) then
    --     return false
    -- end
    if (dict:valueForKey("cmd"):getCString() ~= "bank.store") then
        return false
    end
    local tbl = dictToLuaTable(dict)
    dump(tbl,"BankProductsBuyCmd:handleReceive")  

    local params = dict:objectForKey("params")
    if params:objectForKey("errorCode") ~= nil then
        local pStr = params:valueForKey("errorCode"):getCString()
        MyPrint("BankProductsBuyCmd:handleReceive errorCode",pStr)
        -- if CCCommonUtilsForLua:call("isAllowShowHandleRecieveErrorDialog",pStr) then
            CCCommonUtilsForLua:call("flyText",_lang(pStr))
    else
        -- CCCommonUtilsForLua:call("flyHint", "", "", getLang("149232"))
        LuaController:flyHint("", "", getLang("149232"))
    end 
    
    local gold = tbl.params.gold
    if gold ~= nil then 
        GlobalDataCtr.setPlayerGold(gold)
        UIComponent:call("updateGold",tonumber(gold))
    end
   
    BankController:getInstance():setDeposit(nil)
    CCSafeNotificationCenter:postNotification(MSG_BANG_BUY)
    return true
end

--------------------------------------------------------------------------

BankBuyHistory = class("BankBuyHistory", LuaCommandBase)

function BankBuyHistory:create(  )
    local ret = BankBuyHistory.new()
    ret:initWithName("bank.history")
    return ret
end

function BankBuyHistory:handleReceive(dict)
    if (dict:valueForKey("cmd"):getCString() ~= "bank.history") then
        return false
    end

    local tbl = dictToLuaTable(dict)
    dump(tbl,"BankBuyHistory:handleReceive")  

    BankController:getInstance():setRecordList(tbl.params.records)
    CCSafeNotificationCenter:postNotification(MSG_BANG_BUY_HISTORY)
end

--------------------------------------------------------------------------

BankGetDeposit = class("BankGetDeposit", LuaCommandBase)

function BankGetDeposit:create(  )
    local ret = BankGetDeposit.new()
    ret:initWithName("bank.getDeposit")
    return ret
end

function BankGetDeposit:handleReceive(dict)
 
    if (dict:valueForKey("cmd"):getCString() ~= "bank.getDeposit") then
        return false
    end

    local tbl = dictToLuaTable(dict)
    dump(tbl,"BankGetDeposit:handleReceive2")  
    local params = dict:objectForKey("params")
    if params:objectForKey("errorCode") ~= nil then
        local pStr = params:valueForKey("errorCode"):getCString()
        MyPrint("BankGetDeposit:handleReceive errorCode",pStr)
        -- if CCCommonUtilsForLua:call("isAllowShowHandleRecieveErrorDialog",pStr) then
            CCCommonUtilsForLua:call("flyText",_lang(pStr))
        -- end
    end 

    BankController:getInstance():setDeposit(tbl.params.deposit)
    CCSafeNotificationCenter:postNotification(MSG_REFRESH_BANK_LIST,dict)
end
------------------------------------------------------------------------

BankDrawMoneyCmd = class("BankDrawMoneyCmd", LuaCommandBase)

function BankDrawMoneyCmd:create(key)
    local ret = BankDrawMoneyCmd.new()
    MyPrint(" BankDrawMoneyCmd:create key",key)
    ret:initWithName("bank.withDraw")
    ret:putParam("key",CCString:create(key))
    ret.drawkey = key --MM:记录key，最后若取款成功再处理界面。
    return ret
end

function BankDrawMoneyCmd:handleReceive(dict)
    if (dict:valueForKey("cmd"):getCString() ~= "bank.withDraw") then
        return false
    end
    local tbl = dictToLuaTable(dict)
    dump(tbl,"BankDrawMoneyCmd:handleReceive2")  

    local params = dict:objectForKey("params")
    if params:objectForKey("errorCode") ~= nil then
        local pStr = params:valueForKey("errorCode"):getCString()
            CCCommonUtilsForLua:call("flyText",_lang(pStr))
        return true
    else
        LuaController:flyHint("", "", getLang("149233"))
    end 
    local gold = tbl.params.gold
    if gold ~= nil then 
        GlobalDataCtr.setPlayerGold(gold)
        UIComponent:call("updateGold",tonumber(gold))
    end 
    GameController:call("getInstance"):call("removeWaitInterface")
    local flag, paramstmp = self:parseMsg(dict)
    --MM: 领取成功，处理界面。
    if type(self.drawkey) == "string" then
        CCSafeNotificationCenter:postNotification("MSG_RELOAD_BANK_BAG",CCString:create(self.drawkey))
    end
    Dprint("BalanceInputCmd:handleReceive | parse flag=", flag)
    if (type(flag) == "boolean") then
        return flag
    end
end

