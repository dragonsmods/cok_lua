BankController = class("BankController")

function checkBankTips()
	return BankController.getInstance():haveCanGet()
end

local _instance = nil

function BankController.getInstance()
    if _instance == nil then
        _instance = BankController.new();
    end
    return _instance;
end

function BankController:initDeposit(dict)
	if dict and dict:objectForKey("deposit") then
		local deposit = dict:objectForKey("deposit")
		deposit = tolua.cast(deposit, "CCArray")
		deposit = arrayToLuaTable(deposit)
		if deposit then
			self:setDeposit(deposit)
		end
	end
end

function BankController:ctor()
	self.m_product_list = {}
	self.m_deposit_list = nil
	self.m_save_list = {}
	self.m_geted_list = {}
	self.m_record_list = {}
end

function BankController:openBankView(type)	
	local view = Drequire("game.Bank_new.BankView"):create()
	PopupViewController:call("addPopupView", view)
	if nil ~= type and type == 1 then
		view:onBagButtonClick()
	end
end

function BankController:praseData( dic )
	local dict_lua = dictToLuaTable(dic)
	self.m_product_list = dict_lua.params.product
	self:setDeposit(dict_lua.params.deposit)
	-- dump(self.m_product_list,"self.m_product_list")
end

function BankController:setRecordList( record_list )
	if record_list then 
		self.m_record_list = record_list
		-- dump(self.m_record_list,"setRecordList")
		for k,v in pairs(record_list) do 
			if tonumber(v.operate) == 2 then --2 取
				local index = #self.m_geted_list
				if not v.withDrawTime or tonumber(v.withDrawTime) < tonumber(v.startTime) then
					v.withDrawTime = v.startTime + v.time * 1000 -- 如果结束时间不对，则纠正
				end

				table.insert(self.m_geted_list,index,v)
			elseif tonumber(v.operate) == 1 then --1存
				local index = #self.m_save_list
				table.insert(self.m_save_list,index,v)

				if not v.withDrawTime or tonumber(v.withDrawTime) < tonumber(v.startTime) then
					v.withDrawTime = v.startTime -- 存的结束时间为开始时间
				end
			end
	 	end

	 	table.sort(self.m_record_list, function ( a,b )
	 		-- body
	 		return tonumber(a.withDrawTime) > tonumber(b.withDrawTime)
	 	end)
	 	-- dump(self.m_record_list,"setRecordList")
	 end
end

function BankController:removeDepositByKey( key)
    for k,v in pairs(self.m_deposit_list or {}) do 
  		if v.key == key then 
 			 table.remove(self.m_deposit_list, k)  
  		end
    end
	-- 更新主城银行建筑弹出气泡
	if not self:haveCanGet() then
		local scene = ImperialScene:call("getInstance")
		if scene then
			scene:call("setNeedRefreshBankIconTips", 0)
		end
	end
end

function BankController:haveCanGet()
	local now_time =  getTimeStamp()
    for k,v in pairs(self.m_deposit_list or {}) do 
    	local endTime = v.endTime/1000
  		if endTime < now_time then 
 			 return true
  		end
    end
    return false
end

function BankController:getRecordList()
	return self.m_record_list
end

function BankController:refreshDeposit(  )
	if self.m_deposit_list == nil then 
		local cmd = BankGetDeposit:create()
		cmd:send()
		return true
	end
	return false
end

function BankController:setDeposit(deposit)
	self.m_deposit_list = deposit
	if self.m_deposit_list == nil or #self.m_deposit_list < 1 then 
		return 
	end
	table.sort(self.m_deposit_list,sortData)
end

function  sortData( cell_a,cell_b)
    local sa = tonumber(cell_a.endTime)
    local sb = tonumber(cell_b.endTime)
    return sa > sb 
end

return BankController
