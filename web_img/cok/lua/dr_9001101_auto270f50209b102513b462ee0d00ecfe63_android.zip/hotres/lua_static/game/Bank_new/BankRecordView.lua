
local BankRecordView = class("BankRecordView", 
	function() 
		return PopupBaseView:create() 
	end
)

function BankRecordView:create(data,index)
	MyPrint("-------call BankRecordView:create -----")
	local view = BankRecordView.new()
	require("game.Bank_new.BankRecordView_ui"):create(view,1)
	if view:initBaseView(data,index) == false then 
	 	view = nil 
	end

	return view
end

function BankRecordView:initBaseView( ... )
	self.ui.m_labelTitle:setString(_lang("149300"))
	self.ui.m_desTitle:setString(_lang("149301"))
	return true
end

function BankRecordView:initView()
	local delegate = {}
	delegate.gridAtIndex = function(tab, idx) return self:gridAtIndex(tab, idx) end
    delegate.numberOfCellsInTableView = function(tab) return self:numberOfCellsInTableView(tab) end
    delegate.numberOfGridsInCell = function(tab) return self:numberOfGridsInCell(tab) end
    delegate.gridSizeForTable = function(tab, idx) return self:gridSizeForTable(tab, idx) end

    local list_size = self.ui.m_listNode:getContentSize()
   	self.m_tabView= require("game.utility.TableViewMultiCol").new(list_size)
    self.m_tabView:setDelegate(delegate)
	self.m_tabView:setDirection(kCCScrollViewDirectionVertical)
	self.m_tabView:setVerticalFillOrder(kCCTableViewFillTopDown)
	self.ui.m_listNode:addChild(self.m_tabView)
	self.m_tabView:reloadData()
	self:initTouch()
	return true
end	

function BankRecordView:initTouch( ... )
	-- 触控系列
    local function onTouch(eventType, x, y)  
        if eventType == "began" then
            return self:onTouchBegan(x, y)
        elseif eventType == "moved" then
        else
            return self:onTouchEnded(x, y)
        end
    end
    self:setTouchEnabled(true)
    self:registerScriptTouchHandler(onTouch)
    -- self:setSwallowsTouches(true)
end

function BankRecordView:onTouchBegan(x, y)

	if not isTouchInside(self.ui.m_listNode, x, y) then
        self.canClose = true
    else
    	self.canClose = false
    end
    return true
end

function BankRecordView:onTouchEnded(x,y)

	if not isTouchInside(self.ui.m_listNode, x, y) and self.canClose then
        PopupViewController:call("removePopupView", self)
    end
    return true
end

function BankRecordView:gridAtIndex(tab, idx)
	local list = BankController:getInstance():getRecordList()
	local data = list[idx + 1]
	local cell = Drequire("game.Bank_new.BankRecordCell"):create(data,idx)
	return cell 
end

function BankRecordView:getCellByIndex(idx)

end

function BankRecordView:numberOfCellsInTableView(tab)
	return #BankController:getInstance().m_record_list
end

function BankRecordView:numberOfGridsInCell(tab)
	return 1
end

function BankRecordView:gridSizeForTable(tab, idx)
	return 530,100
end

function BankRecordView:onEnter()
	local cmd = BankBuyHistory:create()
	cmd:send()
	local function onRecordListCBack( ref )
        self:onRefreshRecordList(ref)
    end
	local handler = self:registerHandler(onRecordListCBack)
    CCSafeNotificationCenter:registerScriptObserver(self, handler, "MSG_BANG_BUY_HISTORY")
end

function BankRecordView:onRefreshRecordList(ref)
	MyPrint("onRefreshRecordList")
	self:initView()
end

function BankRecordView:onExit()
	CCSafeNotificationCenter:unregisterScriptObserver(self, "MSG_BANG_BUY_HISTORY")
end

function BankRecordView:onGetStoreButtonClick(pSender, event) 
	-- local  cmd = require("game.Bank_new.BankProductsBuyCmd"):create()
	local view  = Drequire("game.Bank_new.BankSaveDrawView"):create(self.m_data,0,2)
	PopupViewController:call("addPopupInView", view)
end

function BankRecordView:onIncomeClick( pSender, event )
	self.m_tabIndex = 1
end

function BankRecordView:onSaveDrawClick()
	self.m_tabIndex = 2
end

return BankRecordView
