----------------------------
-- Author: Elex
-- Date: 2017-07-19 11:28:12
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local BankStopView_ui = class("BankStopView_ui")

--#ui propertys


--#function
function BankStopView_ui:create(owner, viewType)
	local ret = BankStopView_ui.new()
	CustomUtility:LoadUi("BankStopView.ccbi", ret, owner, true, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function BankStopView_ui:initLang()
end

function BankStopView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function BankStopView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function BankStopView_ui:onOkButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onOkButtonClick", pSender, event)
end

return BankStopView_ui

