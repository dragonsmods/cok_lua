local TroopInfoView = class("TroopInfoView", PopupBaseView)

TroopInfoViewController = TroopInfoViewController or {}
ccb["TroopInfoViewController"] = TroopInfoViewController

local TOTAL_BUTTON_NUM = 5
local ICON_TAG = 10
local BUTTON_TAG = 20
local ICON_DEL_TAG = 30

function TroopInfoView:create(uuid)
    local view = TroopInfoView.new(uuid)
    Drequire("game.commercialDarts.TroopInfoView_ui"):create(view, 1)
    if view:initView() then return view end
end

function TroopInfoView:ctor(uuid)
    self.uuid = uuid
    self.btnCnt = 0
    self.saveMarchId = ""
    self.dataCtrl = require("game.commercialDarts.CommercialController").getInstance()
end

function TroopInfoView:initView()
    self:setHDPanelFlag(true)

    if CCCommonUtilsForLua:isIosAndroidPad() then
		self.ui.nodeccb:setScale(2)
    end
    
    registerTouchHandler(self)
    self:call("setModelLayerOpacity", 0)

    self.aniManager = ccb["TroopInfoViewController"]["mAnimationManager"]

    local marchInfo = self.dataCtrl:getMarchInfo(self.uuid)
    if not marchInfo then return false end

    local name = marchInfo.ownerInfo.name
    if marchInfo.ownerInfo.abbr ~= "" then
        name = "(" .. marchInfo.ownerInfo.abbr .. ")" .. name
    end
    self.ui.m_nameAndAlliance:setString(name)

    if marchInfo:isDarts() then
        self.ui.m_tilePoint:setString(getLang("41576052"))
    elseif marchInfo:isBack() then
        self.ui.m_tilePoint:setString(getLang("108572"))
    else
        self.ui.m_tilePoint:setString(getLang("108562"))
    end

    self:refreshView()

    return true
end

function TroopInfoView:setButtonCount(count)
    self.btnCnt = count

    local index = 1
    while index <= TOTAL_BUTTON_NUM do
        local btnNode = self.ui["m_btnNode" .. index]
        if btnNode then
            btnNode:removeChildByTag(ICON_TAG)
            btnNode:removeChildByTag(BUTTON_TAG)
            btnNode:removeChildByTag(ICON_DEL_TAG)
            index = index + 1
        end
    end

    for index = 1, TOTAL_BUTTON_NUM do
        local btn = CCControlButton:create(CCLoadSprite:call("createScale9Sprite", "blankFrame.png"))
        btn:setTag(BUTTON_TAG)
        -- btn:addHandleOfControlEvent(callback, cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE)
        btn:setTouchPriority(3) 

        local node = self.ui["m_node" .. index]
        node:setVisible(false)

        local btnNode = self.ui["m_btnNode" .. index]
        if btnNode then
            btnNode:addChild(btn)
        end
    end
end

function TroopInfoView:setButtonName(index, name)
    if self.ui["m_nameText" .. index] then
        self.ui["m_nameText" .. index]:setString(name)
    end
end

function TroopInfoView:setButtonCallback(index, callback)
    local btnNode = self.ui["m_btnNode" .. index]
    if btnNode then
        local btn = btnNode:getChildByTag(BUTTON_TAG)
        if btn then
            btn:addHandleOfControlEvent(callback, cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE)
        end
    end
end

function TroopInfoView:setButtonIcon(index, iconName)
    local node = self.ui["m_node" .. index]
    local btnNode = self.ui["m_btnNode" .. index]
    local btn = btnNode:getChildByTag(BUTTON_TAG)
    node:setVisible(true)
    CCCommonUtilsForLua:call("setButtonSprite", btn, "bnt_02.png")

    local sprite = CCLoadSprite:call("createScale9Sprite", "bnt_02.png")
    btn:setPreferredSize(cc.size(100, 100))
    sprite:setColor(cc.c3b(166, 166, 166))
    btn:setBackgroundSpriteForState(sprite, CCControlStateDisabled)

    local icon = CCLoadSprite:createSprite(iconName)
    icon:setTag(ICON_TAG)
    btnNode:addChild(icon)
end

function TroopInfoView:refreshView()
    local function setCallBack(name, index, func, icon)
        local function callback() func(self) end
        self:setButtonName(index, name)
        self:setButtonCallback(index, callback)
        self:setButtonIcon(index, icon)
    end

    local marchInfo = self.dataCtrl:getMarchInfo(self.uuid)
    local playerInfo = GlobalData:call("getPlayerInfo")
    local mineUid = playerInfo:getProperty("uid")
    local selfAllianceId = playerInfo:call("getAllianceId")
    --刷新一下ownerType
    marchInfo:setOwnerType(mineUid, selfAllianceId)
    --自己
    if marchInfo.ownerType == PlayerType.PlayerSelf then    
        --镖车
        if marchInfo:isDarts() then
            if marchInfo:haveEscortArmy() then
                self:setButtonCount(4)
                setCallBack(getLang("41576037"), 1, self.troop, "tile_pop_icon5.png")
                setCallBack(getLang("41576040"), 3, self.assist, "tile_pop_icon9.png")
                setCallBack(getLang("108556"), 4, self.recall, "tile_pop_icon6.png")
                setCallBack(getLang("41576003"), 2, self.information, "icon_camel.png")
            else
                self:setButtonCount(3)
                setCallBack(getLang("41576037"), 2, self.troop, "tile_pop_icon5.png")
                setCallBack(getLang("41576040"), 3, self.assist, "tile_pop_icon9.png")
                setCallBack(getLang("41576003"), 1, self.information, "icon_camel.png")
            end
        --接镖也不能召回
        elseif marchInfo:isBack() or marchInfo:isReceive() then
            self:setButtonCount(2)
            setCallBack(getLang("41576037"), 1, self.troop, "tile_pop_icon5.png")
            setCallBack(getLang("104903"), 3, self.accelerate, "tile_pop_icon15.png")
        else
            self:setButtonCount(3)
            setCallBack(getLang("41576037"), 2, self.troop, "tile_pop_icon5.png")
            setCallBack(getLang("104903"), 3, self.accelerate, "tile_pop_icon15.png")
            setCallBack(getLang("108556"), 1, self.recall, "tile_pop_icon6.png")
        end
    elseif marchInfo.ownerType == PlayerType.PlayerAlliance then
        if marchInfo:isDarts() then
            self:setButtonCount(1)
            setCallBack(getLang("41576037"), 1, self.troop, "tile_pop_icon5.png")
            -- setCallBack(getLang("41576040"), 3, self.assist, "tile_pop_icon9.png")
        else
            self:setButtonCount(0)
        end
    else
        --镖车
        if marchInfo:isDarts() then
            self:setButtonCount(3)
            setCallBack(getLang("41576037"), 2, self.troop, "tile_pop_icon5.png")
            setCallBack(getLang("41576039"), 3, self.attack, "tile_pop_icon4.png")
            setCallBack(getLang("41576038"), 1, self.scout, "tile_pop_icon3.png")
        else
            self:setButtonCount(0)
        end
    end
end

function TroopInfoView:update(dt)
    local marchInfo = self.dataCtrl:getMarchInfo(self.uuid)
    if not marchInfo then 
        self:closeThis() 
        return
    end

    if marchInfo.ownerType == PlayerType.PlayerSelf  then
        local pointStr = getLang("108740", tostring(math.floor(marchInfo.endPoint.x)), tostring(math.floor(marchInfo.endPoint.y)))
        self.ui.m_pointLabel:setString(pointStr)
    else
        local now = WorldController:call("getTime")
        local remainTime = marchInfo.endTime - now
        if remainTime <= 0 then 
            self:closeThis()
            return
        end
        self.ui.m_pointLabel:setString(format_time_q(remainTime / 1000))
    end
end

function TroopInfoView:onEnter()
    if self.saveMarchId and self.saveMarchId ~= "" then
        self.dataCtrl.followMarchId = self.saveMarchId
    end
    self:update()
    self:playShowAni()
    local function update(dt) self:update(dt) end 
	self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(update, 1, false)
end

function TroopInfoView:onExit()
    self.saveMarchId = self.dataCtrl.followMarchId
    self.dataCtrl.followMarchId = ""
    cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
end

function TroopInfoView:playShowAni()
    local aniName = "FadeIn"
    if self.btnCnt == 3 or self.btnCnt == 5 then
        aniName = "FadeIn5"
    elseif self.btnCnt == 4 then
        aniName = "FadeIn4"
    elseif self.btnCnt == 2 then
        aniName = "FadeIn2"
    end

    self.aniManager:runAnimationsForSequenceNamed(aniName)
end

function TroopInfoView:information()
    self:closeThis()
    self.dataCtrl:showPopView()
end

function TroopInfoView:pushPop()
    local marchInfo = self.dataCtrl:getMarchInfo(self.uuid)
    if not marchInfo then 
        self:closeThis()
        return
    end

    if marchInfo:isDarts() and marchInfo.ownerType ~= PlayerType.PlayerSelf then
        self:retain()
        PopupViewController:call("removePopupView", self, false)
        PopupViewController:call("pushPop", self, true)
        self:release()
    else
        self:closeThis()
    end
end

function TroopInfoView:troop()
    local marchInfo = self.dataCtrl:getMarchInfo(self.uuid)
    if not marchInfo then 
        self:closeThis() 
        return
    end
    
    self:pushPop()

    local uuid = marchInfo:isDarts() and marchInfo.escortUuid or marchInfo.uuid
    local rewardT = {}
    if marchInfo.rewardId and marchInfo.rewardId ~= "" then
        table.insert(rewardT, marchInfo.rewardId)
    end
    if marchInfo.luckyReward then
        table.insert(rewardT, marchInfo.luckyReward)
    end

    local camelUuid = marchInfo:isDarts() and marchInfo.uuid or ""
    local view = Drequire("game.commercialDarts.CommercialDetailView"):create(marchInfo.ownerInfo, camelUuid, uuid, rewardT, marchInfo.baseRate)
    PopupViewController:addPopupView(view)
end

function TroopInfoView:attack()
    local marchInfo = self.dataCtrl:getMarchInfo(self.uuid)
    if not marchInfo then 
        self:closeThis() 
        return
    end

    self:pushPop()
    
    -- local dict = CCDictionary:create()
    -- dict:setObject(CCString:create("OpenBattleViewForCommercial"), "name")
    -- dict:setObject(CCString:create("-168"), "type")
    -- dict:setObject(CCString:create(marchInfo.uuid), "id")
    -- dict:setObject(CCString:create("COMMERCIAL_ATTACK"), "key")
    -- LuaController:call("openPopViewInLua", dict) 
    local view = Drequire("game.CommonPopup.BattleView"):createViewForCommercial(-168, marchInfo.uuid, "COMMERCIAL_ATTACK")
    PopupViewController:addPopupInView(view)
    self.dataCtrl:getMarchTime(marchInfo.uuid)
end

function TroopInfoView:assist()
    local marchInfo = self.dataCtrl:getMarchInfo(self.uuid)
    if not marchInfo then 
        self:closeThis()
        return
    end

    self:closeThis()
    --发镖车uuid 因为可能没有护卫队伍
    local uuid = marchInfo.uuid
    local view = Drequire("game.commercialDarts.CommercialAssistView"):create(uuid, marchInfo.ownerInfo.uid)
    PopupViewController:addPopupView(view)
end

function TroopInfoView:accelerate()
    local marchInfo = self.dataCtrl:getMarchInfo(self.uuid)
    if not marchInfo then 
        self:closeThis() 
        return
    end

    self:pushPop()

    local startTime = GlobalData:call("changeTime", marchInfo.startTime / 1000)
    local endTime = GlobalData:call("changeTime", marchInfo.endTime / 1000)

    local dict = CCDictionary:create()
    dict:setObject(CCString:create("UseCDToolView"), "name")
    dict:setObject(CCString:create(marchInfo.uuid), "uuid")
    dict:setObject(CCString:create("-3"), "qid")
    dict:setObject(CCString:create("1"), "timeFlag")
    dict:setObject(CCString:create(tostring(startTime)), "startTime")
    dict:setObject(CCString:create(tostring(endTime)), "endTime")
    LuaController:call("openPopViewInLua", dict) 
end

function TroopInfoView:recall()
    local marchInfo = self.dataCtrl:getMarchInfo(self.uuid)
    if not marchInfo then 
        self:closeThis() 
        return
    end
    
    self:pushPop()
    local function confirm()
        local marchUuid = marchInfo:isDarts() and marchInfo.escortUuid or marchInfo.uuid
        local dict = CCDictionary:create()
        dict:setObject(CCString:create(marchUuid), "uuid")
        local view = Drequire("game.CommonPopup.UseToolView"):create(USE_TOOL_COMMERCIAL_CANCEL, dict)
        PopupViewController:addPopupInView(view)
    end

    if marchInfo:isDarts() then
        YesNoDialog:show(getLang("41576180"), confirm)
    else
        confirm()
    end
end

function TroopInfoView:scout()
    if not GlobalData:call("getPlayerInfo"):call("isInAlliance") then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("133032"))
        self:closeThis()
        return
    end

    local marchInfo = self.dataCtrl:getMarchInfo(self.uuid)
    if not marchInfo then 
        self:closeThis() 
        return
    end

    self.dataCtrl:scout(nil, marchInfo.uuid, marchInfo.ownerInfo.name)
end

function TroopInfoView:onTouchBegan(x, y)
    if isTouchInside(self.m_btn1, x, y) 
        or isTouchInside(self.m_btn2, x, y) 
        or isTouchInside(self.m_btn3, x, y) then
        return false
    end

    return true
end

function TroopInfoView:onTouchEnded(x, y)
    local currentSceneId = SceneController:call("getCurrentSceneId")
    if currentSceneId ~= SCENE_ID_WORLD then return end
    if isTouchInside(self.ui.m_infoBG, x, y) then
        local marchInfo = self.dataCtrl:getMarchInfo(self.uuid)
        if marchInfo then
            self.dataCtrl.followMarchId = ""
            WorldMapView:call("gotoTilePoint", ccp(marchInfo.endPoint.x, marchInfo.endPoint.y))
        end
    end
    self:closeThis()
end

function TroopInfoView:closeThis()
    if self.isClosing then return end
    self.isClosing = true

    local function compelte()
        local currentSceneId = SceneController:call("getCurrentSceneId")
        if currentSceneId == SCENE_ID_WORLD then 
            local world = WorldMapView:call("instance")
            world:call("removeTouchEffect")
        end
        self:call("closeSelf")
    end
    self.aniManager:setAnimationCompletedCallback(compelte)

    local aniName = "FadeOut"
    if self.btnCnt == 3 or self.btnCnt == 5 then
        aniName = "FadeOut5"
    elseif self.btnCnt == 2 then
        aniName = "FadeOut2"
    elseif self.btnCnt == 4 then
        aniName = "FadeOut4"
    end
    
    self.aniManager:runAnimationsForSequenceNamed(aniName)
end

return TroopInfoView
