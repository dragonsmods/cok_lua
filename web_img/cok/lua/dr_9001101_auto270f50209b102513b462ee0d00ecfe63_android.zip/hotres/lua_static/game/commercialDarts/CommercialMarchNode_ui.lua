----------------------------
-- Author: Elex
-- Date: 2020-03-26 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CommercialMarchNode_ui = class("CommercialMarchNode_ui")

--#ui propertys


--#function
function CommercialMarchNode_ui:create(owner, viewType, paramTable)
	local ret = CommercialMarchNode_ui.new()
	CustomUtility:DoRes(8, true)
	CustomUtility:DoRes(0, true)
	CustomUtility:LoadUi("CommercialMarchNode.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function CommercialMarchNode_ui:initLang()
	LabelSmoker:setText(self.m_text2, "41576056")
	LabelSmoker:setText(self.m_text3, "41576057")
	LabelSmoker:setText(self.m_text6, "41576019")
	LabelSmoker:setText(self.m_text7, "41576022")
	LabelSmoker:setText(self.m_text8, "138108")
	LabelSmoker:setText(self.m_pLabelTTF92, "103672")
	ButtonSmoker:setText(self.m_maydayBtn, "41576017")
	ButtonSmoker:setText(self.m_prayBtn, "41576018")
	ButtonSmoker:setText(self.m_jumpBtn, "106228")
	ButtonSmoker:setText(self.m_refreshBtn, "41576020")
	ButtonSmoker:setText(self.m_continueBtn, "41576167")
end

function CommercialMarchNode_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CommercialMarchNode_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CommercialMarchNode_ui:onClickMayday(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickMayday", pSender, event)
end

function CommercialMarchNode_ui:onClickPray(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickPray", pSender, event)
end

function CommercialMarchNode_ui:onClickJump(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickJump", pSender, event)
end

function CommercialMarchNode_ui:onClickInfo(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickInfo", pSender, event)
end

function CommercialMarchNode_ui:onClickRefresh(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickRefresh", pSender, event)
end

function CommercialMarchNode_ui:onClickContinue(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickContinue", pSender, event)
end

function CommercialMarchNode_ui:initTableView()
	TableViewSmoker:createView(self, "m_listView", "game.commercialDarts.CommercialItemCell", 1, 4, "CommercialItemCell")
end

function CommercialMarchNode_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return CommercialMarchNode_ui

