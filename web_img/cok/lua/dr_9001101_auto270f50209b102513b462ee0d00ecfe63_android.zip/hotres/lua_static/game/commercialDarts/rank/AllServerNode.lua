local AllServerNode = class("AllServerNode", cc.Layer)

function AllServerNode:create(size)
    local node = AllServerNode.new()
    Drequire("game.commercialDarts.rank.AllServerNode_ui"):create(node, 0, size)
    if node:initNode() then return node end
end

function AllServerNode:ctor()

end

function AllServerNode:initNode()
    --适配
	CCCommonUtilsForLua:call("adaptIphoneX", self.ui.m_nodeBottom, NODEPOS_X.BOTTOM)
    CCCommonUtilsForLua:call("adaptIphoneX", self.ui.m_listNode, NODEPOS_X.CENTER)
    
    self.size = self.ui.m_listNode:getContentSize()
    self:onClickPlayer()
    return true
end

function AllServerNode:onClickServer()
    self.ui.m_serverBtn:setEnabled(false)
    self.ui.m_allianceBtn:setEnabled(true)
    self.ui.m_playerBtn:setEnabled(true)

    CCLoadSprite:call("doResourceByCommonIndex", 208, true)

    local config = {
        name = "escort_server",
        id = "35366014",
    }

    local rankView = Drequire("game.CommonPopup.commonRank.CommonRankView"):createWithConfigId(
                config.id, config.name, self.size
            )
 
    self.ui.m_listNode:removeAllChildren() 
    self.ui.m_listNode:addChild(rankView)
end

function AllServerNode:onClickAlliance()
    self.ui.m_serverBtn:setEnabled(true)
    self.ui.m_allianceBtn:setEnabled(false)
    self.ui.m_playerBtn:setEnabled(true)

    local config = {
        name = "escort_alliance",
        id = "35366013",
    }

    local rankView = Drequire("game.CommonPopup.commonRank.CommonRankView"):createWithConfigId(
                config.id, config.name, self.size
            )
 
    self.ui.m_listNode:removeAllChildren() 
    self.ui.m_listNode:addChild(rankView)
end

function AllServerNode:onClickPlayer()
    self.ui.m_serverBtn:setEnabled(true)
    self.ui.m_allianceBtn:setEnabled(true)
    self.ui.m_playerBtn:setEnabled(false)

    local config = {
        name = "escort_user",
        id = "35366012",
    }


    local rankView = Drequire("game.CommonPopup.commonRank.CommonRankView"):createWithConfigId(
                config.id, config.name, self.size
            )
 
    self.ui.m_listNode:removeAllChildren() 
    self.ui.m_listNode:addChild(rankView)
end

return AllServerNode