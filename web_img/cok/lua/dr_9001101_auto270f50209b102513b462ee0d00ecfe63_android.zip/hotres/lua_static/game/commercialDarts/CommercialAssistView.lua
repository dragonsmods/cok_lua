local CommercialAssistView = class("CommercialAssistView", PopupBaseView)

function CommercialAssistView:create(uuid, ownerId)
    local view = CommercialAssistView.new(uuid, ownerId)
    Drequire("game.commercialDarts.CommercialAssistView_ui"):create(view, 1)
    if view:initView() then return view end
end

function CommercialAssistView:ctor(uuid, ownerId)
    self.uuid = uuid
    self.ownerId = ownerId
    self.reinforce = 0
end

function CommercialAssistView:initView()
    self:setHDPanelFlag(true)

    if CCCommonUtilsForLua:isIosAndroidPad() then
		self.ui.nodeccb:setScale(2)
    end
    
    self.ui.m_cancelBtn:setEnabled(true)
    self.ui.m_sendBtn:setEnabled(false)
    registerTouchHandler(self)

    self.ctrl = require("game.commercialDarts.CommercialController").getInstance()
    self.ctrl:reinforce(self.uuid)
    return true
end

function CommercialAssistView:refreshView(param)
    local data = dictToLuaTable(param)

    if data.cur and data.max then
        local cur = CC_CMDITOA(atoi(data.cur))
        local max = CC_CMDITOA(atoi(data.max))
        self.ui.m_numTxt:setString(cur .. "/" .. max)

        local playerInfo = GlobalData:call("getPlayerInfo")
        local mineUid = playerInfo:getProperty("uid")
        if self.ownerId == mineUid and atoi(data.cur) < atoi(data.max) then
            self.reinforce = atoi(data.max) - atoi(data.cur)
            self.ui.m_sendBtn:setEnabled(true)
        end
    end
end

function CommercialAssistView:onEnter()
    registerScriptObserver(self, self.refreshView,"COMMERCIAL_ASSISTVIEW")
end

function CommercialAssistView:onExit()
    unregisterScriptObserver(self, "COMMERCIAL_ASSISTVIEW")
end

function CommercialAssistView:onCancelClick()
    self:call("closeSelf")
end

function CommercialAssistView:onSendClick()
    self:call("closeSelf")

    -- local dict = CCDictionary:create()
    -- dict:setObject(CCString:create("OpenBattleViewForCommercial"), "name")
    -- dict:setObject(CCString:create("-168"), "type")
    -- dict:setObject(CCString:create(self.uuid), "id")
    -- dict:setObject(CCString:create("COMMERCIAL_ASSIST"), "key")
    -- dict:setObject(CCString:create(tostring(self.reinforce)), "maxForceNum")
    -- LuaController:call("openPopViewInLua", dict) 
    local view = Drequire("game.CommonPopup.BattleView"):createViewForCommercial(-168, self.uuid, "COMMERCIAL_ASSIST", self.reinforce)
    PopupViewController:addPopupInView(view)

    self.ctrl:getMarchTime(self.uuid)
end

function CommercialAssistView:onTouchBegan(x, y)
    if not isTouchInside(self.ui.m_bg, x, y) then 
        self.touchPoint = ccp(x, y)
        return true
    end

    return false
end

function CommercialAssistView:onTouchEnded(x, y)
    if ccpDistance(self.touchPoint, ccp(x, y)) > 10 then return end
    self:call("closeSelf")
end

return CommercialAssistView