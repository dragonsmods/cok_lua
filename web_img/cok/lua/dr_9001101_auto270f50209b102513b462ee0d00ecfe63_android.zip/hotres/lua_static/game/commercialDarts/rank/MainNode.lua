local MainNode = class("MainNode", cc.Layer)

function MainNode:create(size)
    local node = MainNode.new()
    Drequire("game.commercialDarts.rank.MainNode_ui"):create(node, 0, size)
    if node:initNode() then return node end
end

function MainNode:ctor()
    self.rewardTabs = {}
    self.rewardIdTab = {}
    self.xmlName = "ranking_reward"
    self.ctrl = require("game.commercialDarts.CommercialController").getInstance()
end

function MainNode:initNode()
    self.ctrl:getRank()
    self:refreshHead()
    CCCommonUtilsForLua:call("adaptIphoneX", self.ui.m_nodeBottom, NODEPOS_X.BOTTOM)
    return true
end

function MainNode:refreshHead()
    --头像设置
    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")

	local info_pic      = playerInfo:getProperty("pic")
	local info_picVer   = playerInfo:getProperty("picVer")
	local info_uid      = playerInfo:getProperty("uid")
    local info_picfraId = playerInfo:getProperty("picfraId")
    
    local headIcon = CCCommonUtilsForLua:call("makeUserHeadIcon", info_uid, info_pic, info_picfraId, info_picVer, 88)
    self.ui.m_iconNode:removeAllChildren()
    self.ui.m_iconNode:addChild(headIcon)
end

function MainNode:refreshNode(params)
    local tbl = dictToLuaTable(params)
    
    self.maxPro = tonumber(tbl.total_score)
    self.curPro = tonumber(tbl.score)
    
    self.tblProData = {}
	for k, v in pairs(tbl.box_information) do
        table.insert(self.tblProData, 
            {
                reward = v.rewardId, 
                state = v.status, 
                target = v.score, 
                rewardIndex = v.id,
                curPro = self.curPro,
                maxPro = self.maxPro
            })
	end

	local function sortfunc(a,b)
		return tonumber(a.target) < tonumber(b.target) 
	end

	if self.tblProData and #(self.tblProData) > 0 then
		table.sort(self.tblProData, sortfunc)
		local len = #(self.tblProData)
		for i = 1, len do --插入bottom数据
			self.tblProData[i].getRewardFunc = function()
				self.ctrl:getReward(self.tblProData[i].rewardIndex)
			end
			if i == 1 then
				self.tblProData[1].bottom = "0"
			else
				self.tblProData[i].bottom = self.tblProData[i - 1].target
			end
		end
    end
    
    self.ui.m_rewardNode:removeAllChildren()
	if self.tblProData and #self.tblProData > 0 then
		local view = Drequire("game.CommonPopup.CommonProgressView").create(self.tblProData, 600)
		if view then
			self.ui.m_rewardNode:addChild(view)
		end
    end
    
    self.endTime = atoi(tbl.endTime) / 1000

    self.localRank = atoi(tbl.localRankNum)
    self.globalRank = atoi(tbl.globalRankNum)
    
    self.ui.m_pText2:setString(getLang("41576281", CC_CMDITOA(tbl.localRankNum)))
    self.ui.m_pText3:setString(getLang("41576282", CC_CMDITOA(tbl.globalRankNum)))
    self.ui.m_pText4:setString(getLang("41576284", CC_CMDITOA(tbl.now_score)))

    if self.localRank == 0 or self.localRank == -1 then
        self.ui.m_pText2:setString(getLang("41576281", getLang("41576283")))
    end

    if self.globalRank == 0 or self.globalRank == -1 then
        self.ui.m_pText3:setString(getLang("41576282", getLang("41576283")))
    end

    local rSolts = splitString(tbl.receive, ";")
    if #rSolts == 5 then
        for index, num in ipairs(rSolts) do
            self.ui["m_prop1Text" .. index]:setString(CC_CMDITOA(num))
        end
    end

    local eSolts = splitString(tbl.reach, ";")
    if #eSolts == 5 then
        for index, num in ipairs(eSolts) do
            self.ui["m_prop2Text" .. index]:setString(CC_CMDITOA(num))
        end
    end

    local aSolts = splitString(tbl.attack, ";")
    if #aSolts == 5 then
        for index, num in ipairs(aSolts) do
            self.ui["m_prop3Text" .. index]:setString(CC_CMDITOA(num))
        end
    end

    self:onEnterFrame(0)
end

function MainNode:onEnterFrame(dt)
    if not self.endTime then return end

    local now = getTimeStamp()
    local reamin = self.endTime - now
    if reamin > 0 then
        self.ui.m_pText1:setString(getLang("41576279", format_time(reamin)))
    else
        self.ui.m_pText1:setString(getLang("41576280"))
    end
end

function MainNode:onEnter()
    local function update(dt) self:onEnterFrame(dt) end
    self.entry = self:getScheduler():scheduleScriptFunc(update, 1, false)
    registerScriptObserver(self, self.refreshNode,"COMMERCIAL_RANK")
	registerScriptObserver(self, self.getRewardDataAndOpenView, "MSG_GET_MULTY_REWARD_DETAIL_BACK")
end 

function MainNode:onExit()
    self:getScheduler():unscheduleScriptEntry(self.entry)
    unregisterScriptObserver(self, "COMMERCIAL_RANK")
    unregisterScriptObserver(self, "MSG_GET_MULTY_REWARD_DETAIL_BACK")
end

function MainNode:onClickLocal()
    if self.localRank then
        self.xmlRwdId = "35380015"
        self.rank = self.localRank
        self.rank = self.rank > 0 and self.rank or 0 

        self:showRank()
    end
end

function MainNode:onClickGlobal()
    if self.globalRank then
        self.xmlRwdId = "35380012"
        self.rank = self.globalRank
        self.rank = self.rank > 0 and self.rank or 0 

        self:showRank()
    end
end

-- 获取奖励数据并打开奖励界面
function MainNode:getRewardDataAndOpenView()
    if not self.rank then return end

	local found = false
	local index = 1
    local rewardTab = {}
    
	if self.rank > 0 then
		for i = 1, #(self.rewardIdTab or {}) do
			local left = self.rewardIdTab[i].left
			local right = self.rewardIdTab[i].right
			if left <= self.rank and self.rank <= right then
				found = true
				index = #rewardTab

                local titleStr = string.join("", getLang("221120"), " (", getLang("170008"), ": ", self.rank, ")")
				rewardTab[#rewardTab + 1] = {type = 1000, label = titleStr}
                
                local rwd = GlobalData:call("getCachedRewardData", self.rewardIdTab[i].rewardId)
				local rwdData = arrayToLuaTable(rwd)
				for _, v in pairs(rwdData) do
                    table.insert(rewardTab, v)
				end
				break
			end
		end
	end
	for i = 1, #(self.rewardIdTab or {}) do
		local left = self.rewardIdTab[i].left
		local right = self.rewardIdTab[i].right

		local titleStr = ""
		if left ~= right then
			titleStr = getLang("221119", tostring(left), tostring(right))
		else
			titleStr = getLang("221121", tostring(left))
		end
		rewardTab[#rewardTab + 1] = {type = 1000, label = titleStr}
        
        local rwd = GlobalData:call("getCachedRewardData", self.rewardIdTab[i].rewardId)
		local rwdData = arrayToLuaTable(rwd)
		for _, v in pairs(rwdData) do
			rewardTab[#rewardTab + 1] = v
		end
    end
    
	if not found then index = #rewardTab end

	local view = Drequire("game.equipment.EquipRank.EquipmentRewardView"):create(rewardTab, index, getLang("42600014"), getLang("221122"))
	PopupViewController:call("addPopupView", view)
end

-- 解析奖励
function MainNode:parseRewardId()
	if not self.rewardTabs[self.xmlRwdId] then
		self.rewardTabs[self.xmlRwdId] = {}
		
		local reward = CCCommonUtilsForLua:call("getPropByIdGroup", self.xmlName, self.xmlRwdId, "reward")
		local rwdTab = string.split(reward, "|")
		for i = 1, #rwdTab do
			local rwdItem = string.split(rwdTab[i], ";")
			if #rwdItem >= 2 then
				local rwdIdx = string.split(rwdItem[1], "-")
				if #rwdIdx >= 2 then
					self.rewardTabs[self.xmlRwdId][i] = {left = tonumber(rwdIdx[1]), right = tonumber(rwdIdx[2]), rewardId = rwdItem[2]}
				elseif #rwdIdx >= 1 then
					self.rewardTabs[self.xmlRwdId][i] = {left = tonumber(rwdIdx[1]), right = tonumber(rwdIdx[1]), rewardId = rwdItem[2]}
				end
			end
		end
    end
    self.rewardIdTab = self.rewardTabs[self.xmlRwdId]
end

-- 检查奖励数据
function MainNode:checkRewardData()
	self:parseRewardId()

    self.reqRwd = {}
    
	for i = 1, #self.rewardIdTab do
		local rwd = GlobalData:call("getCachedRewardData", self.rewardIdTab[i].rewardId)
		local rwdData = arrayToLuaTable(rwd)
		if #rwdData == 0 then
			table.insert(self.reqRwd, self.rewardIdTab[i].rewardId)
		end
	end
end	

-- 获取奖励数据（没有时向服务器请求）
function MainNode:showRank()
	self:checkRewardData()

	if #self.reqRwd == 0 then
		self:getRewardDataAndOpenView()
	else
		GlobalData:call("requestMultiRewardData", self.reqRwd)
	end
end

function MainNode:onClickGo()
    self.ctrl:showPopView()
end

return MainNode