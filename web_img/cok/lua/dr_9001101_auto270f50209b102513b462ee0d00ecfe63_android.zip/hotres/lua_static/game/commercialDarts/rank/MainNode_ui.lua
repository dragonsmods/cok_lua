----------------------------
-- Author: Elex
-- Date: 2020-04-03 Friday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local MainNode_ui = class("MainNode_ui")

--#ui propertys


--#function
function MainNode_ui:create(owner, viewType, paramTable)
	local ret = MainNode_ui.new()
	CustomUtility:DoRes(0, true)
	CustomUtility:LoadUi("CommercialMainNode.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function MainNode_ui:initLang()
	LabelSmoker:setText(self.m_pText5, "41576285")
	LabelSmoker:setText(self.m_pText6, "41576286")
	LabelSmoker:setText(self.m_pLabelTTF63, "41576287")
	LabelSmoker:setText(self.m_pLabelTTF59, "41576288")
	LabelSmoker:setText(self.m_pLabelTTF60, "41576289")
	LabelSmoker:setText(self.m_pLabelTTF61, "41576290")
	LabelSmoker:setText(self.m_pLabelTTF62, "41576296")
	LabelSmoker:setText(self.m_pLabelTTF64, "41576291")
	LabelSmoker:setText(self.m_pLabelTTF65, "41576291")
	LabelSmoker:setText(self.m_pLabelTTF66, "41576291")
	LabelSmoker:setText(self.m_pLabelTTF67, "41576292")
	LabelSmoker:setText(self.m_pLabelTTF68, "41576292")
	LabelSmoker:setText(self.m_pLabelTTF69, "41576292")
	LabelSmoker:setText(self.m_pLabelTTF70, "41576293")
	LabelSmoker:setText(self.m_pLabelTTF71, "41576293")
	LabelSmoker:setText(self.m_pLabelTTF72, "41576293")
	LabelSmoker:setText(self.m_pLabelTTF73, "41576294")
	LabelSmoker:setText(self.m_pLabelTTF74, "41576294")
	LabelSmoker:setText(self.m_pLabelTTF75, "41576294")
	LabelSmoker:setText(self.m_pLabelTTF76, "41576295")
	LabelSmoker:setText(self.m_pLabelTTF77, "41576295")
	LabelSmoker:setText(self.m_pLabelTTF78, "41576295")
	ButtonSmoker:setText(self.m_goBtn, "106228")
end

function MainNode_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function MainNode_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function MainNode_ui:onClickGo(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickGo", pSender, event)
end

function MainNode_ui:onClickLocal(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickLocal", pSender, event)
end

function MainNode_ui:onClickGlobal(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickGlobal", pSender, event)
end

return MainNode_ui

