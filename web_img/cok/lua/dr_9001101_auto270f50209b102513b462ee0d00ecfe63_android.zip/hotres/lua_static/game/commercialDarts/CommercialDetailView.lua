local CommercialDetailView = class("CommercialDetailView", PopupBaseView)

function CommercialDetailView:create(ownerInfo, camelUuid, uuid, rewardT, baseRate)
    local view = CommercialDetailView.new(ownerInfo, camelUuid, uuid, rewardT, baseRate)
    Drequire("game.commercialDarts.CommercialDetailView_ui"):create(view, 1)
    if view:initView() then return view end
end

function CommercialDetailView:ctor(ownerInfo, camelUuid, uuid, rewardT, baseRate)
    self.ownerInfo = ownerInfo
    self.camelUuid = camelUuid
    self.uuid = uuid
    self.rewardT = rewardT
    self.baseRate = baseRate
    self.armyCells = {}
    self.totalTroops = 0
    self.escortHeroSwitch = CCCommonUtilsForLua:isFunOpenByKey("big_escort")
    self.ctrl = require("game.commercialDarts.CommercialController").getInstance()
end

function CommercialDetailView:initView()
    self:setHDPanelFlag(true)

    if CCCommonUtilsForLua:isIosAndroidPad() then
		self.ui.nodeccb:setScale(2)
    end
    
    self.ui.m_allLabel:setString(getLang("114333"))

    if self.uuid == "" then
        self.ui.m_allNumLabel:setString("0")
    else
        self.ctrl:viewTroop(self.uuid)
    end

    if self.escortHeroSwitch and self.camelUuid ~= "" then 
        self.ctrl:reqEnemySpeed(self.camelUuid) 
    end

    local ownerName = self.ownerInfo.name
    if self.ownerInfo.abbr and self.ownerInfo.abbr ~= "" then
        ownerName = string.join("", "(", self.ownerInfo.abbr, ") ", ownerName)
    end
    self.ui.m_ownerText:setString(ownerName)

    local size = self.ui.m_ownerText:getContentSize()
    local x = self.ui.m_ownerText:getPositionX()
    self.ui.m_allLabel:setPositionX(size.width + x + 58)

    if self.rewardT and #self.rewardT > 0 then
        self:onRewardGetback()
    else
        self.ui.m_rewardNode:setVisible(false)
        self.ui.m_attackDescLable:setVisible(false)
        self.ui.m_listNode:setVisible(false)
        self.ui.m_troopNode:setPositionY(260)
        self.ui.m_aListNode:setPositionY(-50)
        self.ui.m_aListNode:setContentSize(cc.size(576, 560))
    end

    local size = self.ui.m_allLabel:getContentSize()
    local x = self.ui.m_allLabel:getPositionX()
    self.ui.m_allNumLabel:setPositionX(size.width + x + 8)

    CCLoadSprite:call("doResourceByCommonIndex", 204, true)
    registerTouchHandler(self)

    return true
end

function CommercialDetailView:onRewardGetback()
    local rwdData = {}
    for index, rewardId in ipairs(self.rewardT) do
        local rwd = GlobalData:call("getCachedRewardData", rewardId)
        local rData = arrayToLuaTable(rwd)
        for _, urwd in ipairs(rData) do
            if index == 1 then
                urwd.value.num = math.floor(atoi(urwd.value.num) * self.baseRate / 100)
            else
                urwd.value.spe = 1
            end
            table.insert(rwdData, urwd)
        end
    end 

    local Width = -38
    if #rwdData > 0 then
        self.ui.m_listNode:removeAllChildren()
        for i, v in ipairs(rwdData) do
            local cell = Drequire("game.CivFortress.Barrack.CampIconCell"):create()
            cell:setData(v)
            cell:setScale(0.8)

            local size = cell:getContentSize()
            local x = Width
            Width = Width + 80
            local y = 0

            cell:setPosition(cc.p(x,y))
            self.ui.m_listNode:addChild(cell)

            if v.value and v.value.spe == 1 then
                self:addLuckParticle(cell.ui.m_iconNode)
            end

            if i == 8 then -- 最多显示8个
                break
            end
        end

        self.ui.m_tagLabel:setString(getLang("41576014"))
    else
        GlobalData:call("requestMultiRewardData", self.rewardT)
    end
end

function CommercialDetailView:addLuckParticle(node)
    if node then
        node:removeChildByTag(666)

        local parNode = cc.Node:create()
        parNode:setScale(1)
        parNode:setTag(666)
        node:addChild(parNode)

        for index = 0, 1 do
            local particle = ParticleController:call("createParticle", string.format("bag_%d", index))
            if particle then
                particle:setContentSize(cc.size(9999, 9999))
                parNode:addChild(particle)
            end
        end
    end
end

function CommercialDetailView:refreshView(params)
    local data = dictToLuaTable(params)
    self.totalTroops = atoi(data.totalTroops)
    self.ui.m_allNumLabel:setString(CC_CMDITOA(self.totalTroops))
    
    self.totalH = 0
    local listWeight = self.ui.m_aListNode:getContentSize().width

    self.scrollView = CCScrollView:create(self.ui.m_aListNode:getContentSize())
    self.scrollView:setDirection(kCCScrollViewDirectionVertical)
    self.scrollView:setPosition(cc.p(0,0))
    self.ui.m_aListNode:addChild(self.scrollView)

    if data.soldiers then
        local height = 0
        local count = #data.soldiers
        for index = count, 1, -1 do
            local v = data.soldiers[index]
            local cell = Drequire("game.CivFortress.Barrack.CampDetailArmyCell"):create()
            self.scrollView:addChild(cell)

            height = cell:getContentSize().height
            local x = 0
            if index % 2 == 0 then
                x = cell:getContentSize().width
            end
            local y =  math.floor((index - 1) / 2)
            y = y * height

            cell:setPosition(cc.p(x,y))
            cell:setData(v.armyId .. ";" .. v.count)
            cell:setStar(v.star)
            cell:setMult(data.mult)

            table.insert(self.armyCells, cell)
        end
        self.totalH = self.totalH + (math.floor(count / 2) + count % 2) * height
    end

    if self.escortHeroSwitch and data.mult then
        self.ui.m_fakeNode:setVisible(true)
        self.ui.m_fakeNode:setPosition(0, self.totalH)
        self.ui.m_fakeNode:retain()
        self.ui.m_fakeNode:removeFromParent()
        self.scrollView:addChild(self.ui.m_fakeNode)
        self.ui.m_fakeNode:release()

        local mutlStr = string.format("%0.2f", atoi(data.mult))
        self.ui.m_fakeText:setString(getLang("5504318", mutlStr))
        self.ui.m_refreshBtn:setVisible(atoi(data.leftMaskTimes) > 0)
        self.totalH = self.totalH + 50

        self:refreshTotal(data.mult)
    end

    if self.escortHeroSwitch and self.camelUuid ~= "" then
        self.ui.m_speedNode:setVisible(true)
        self.ui.m_speedNode:setPosition(0, self.totalH)
        self.ui.m_speedNode:retain()
        self.ui.m_speedNode:removeFromParent()
        self.scrollView:addChild(self.ui.m_speedNode)
        self.ui.m_speedNode:release()
        self.totalH = self.totalH + 50
    end

    -- title
    local titleBar = Drequire("game.CivFortress.Barrack.CampDetailTitleCell"):create()
    titleBar:setTitle(getLang("108585"))
    self.scrollView:addChild(titleBar)
    titleBar:setPosition(cc.p(0,self.totalH))
    self.totalH = self.totalH + titleBar:getContentSize().height

    local width = 0
    local height = 0
    if data.newGeneral then
        -- hero
        local hero = Drequire("game.CivFortress.Barrack.CampDetailHeroCell"):create()
        self.scrollView:addChild(hero)
        width = hero:getContentSize().width
        height = hero:getContentSize().height
        hero:setPosition(cc.p(11, self.totalH))
        self.totalH = self.totalH + hero:getContentSize().height
        hero:setData(data.newGeneral.generalId, data.newGeneral.level)
    end

    if data.petDragon then
        local dragon = Drequire("game.CivFortress.Barrack.CampDetailDragonCell"):create()
        self.scrollView:addChild(dragon)
        local width1 = dragon:getContentSize().width
        dragon:setPosition(cc.p(11 + width , self.totalH - height))
        if height == 0 then
            self.totalH = self.totalH + dragon:getContentSize().height
        end
        dragon:setData(data.petDragon.itemId)
    end

    self.scrollView:setContentSize(cc.size(self.ui.m_aListNode:getContentSize().width,self.totalH));
    self.scrollView:setContentOffset(ccp(0, self.ui.m_aListNode:getContentSize().height - self.totalH));
end

function CommercialDetailView:refreshTotal(mult)
    local now = math.floor(atoi(mult) * self.totalTroops)
    if now ~= self.totalTroops then
        local params = {}
        params.lbl = self.ui.m_allNumLabel
        params.showType = 1
        params.value = tostring(now)
        params.isEnough = true
        params.fontSize = 20
        setLabelReduceX(params)
    else
        local params = {}
        params.lbl = self.ui.m_allNumLabel
        params.showType = 0
        setLabelReduceX(params)
    end
end

function CommercialDetailView:refreshMult(param)
    local data = dictToLuaTable(param)

    local mutlStr = string.format("%0.2f", atoi(data.mult))
    self.ui.m_fakeText:setString(getLang("5504318", mutlStr))
    self.ui.m_refreshBtn:setVisible(atoi(data.leftMaskTimes) > 0)
    self.ui.m_refreshBtn:setEnabled(true)
    self:refreshTotal(data.mult)
    for _, cell in ipairs(self.armyCells) do
        cell:setMult(data.mult)
    end
end

function CommercialDetailView:onEnterFrame()

end

function CommercialDetailView:refreshSpeed(param)
    if param then
        self.ui.m_helpBtn:setEnabled(true)

        local data = dictToLuaTable(param)
        -- dump(data, "refreshSpeed")
        self.ui.m_speedText:setString(getLang("5504334", data.decrEnemySpeedRate))
    end
end

function CommercialDetailView:onEnter()
    registerScriptObserver(self, self.refreshView, "COMMERCIAL_TROOPVIEW")
    registerScriptObserver(self, self.onRewardGetback, "MSG_GET_REWARD_DETAIL_BACK")
    registerScriptObserver(self, self.refreshMult, "COMMERCIAL_REFRESH_MULT")
    registerScriptObserver(self, self.refreshSpeed, "msg.escort.speed")
end

function CommercialDetailView:onExit()
    unregisterScriptObserver(self, "COMMERCIAL_TROOPVIEW")
    unregisterScriptObserver(self, "MSG_GET_REWARD_DETAIL_BACK")
    unregisterScriptObserver(self, "COMMERCIAL_REFRESH_MULT")
    unregisterScriptObserver(self, "msg.escort.speed")
end

function CommercialDetailView:onTouchBegan(x, y)
    if not isTouchInside(self.ui.m_touchNode, x, y) then
        self.touchPoint = ccp(x, y)
        return true
    end
    return false
end

function CommercialDetailView:onTouchEnded(x, y)
    if ccpDistance(self.touchPoint, ccp(x, y)) > 10 then return end

    self:call("closeSelf")
end

function CommercialDetailView:onClickRefresh()
    self.ui.m_refreshBtn:setEnabled(false)
    self.ctrl:refreshMult(self.uuid)
end

function CommercialDetailView:onClickHelp()
    --5504333=无法助力非盟友的商旅
    local playerInfo = GlobalData:call("getPlayerInfo")
    local mineUid = playerInfo:getProperty("uid")
    local selfAllianceId = playerInfo:call("getAllianceId")

    if selfAllianceId ~= self.ownerInfo.allianceId and selfAllianceId ~= "" then
        LuaController:flyHint("", "", getLang("5504333"))
        return 
    end

    local heroId = CCCommonUtilsForLua:call("getPropByIdGroup", "data_config", "bodyguard_hero", "k1")
    local skillId = CCCommonUtilsForLua:call("getPropByIdGroup", "data_config", "bodyguard_hero", "k2")
    
    --5504337=对不起，您没有“镖师威慑”技能
    if not HeroManager.isHeroObtainSkill(heroId, skillId) then
        LuaController:flyHint("", "", getLang("5504337"))
        return 
    end

    --5504338=对不起，“镖师威慑”技能处于冷却状态
    if HeroManager.isSkillInCd(heroId, skillId) then
        LuaController:flyHint("", "", getLang("5504337"))
        return 
    end
       
    HeroManager.escortThreaten(heroId, skillId, self.ownerInfo.uid)
    self.ui.m_helpBtn:setEnabled(false) 
end

return CommercialDetailView