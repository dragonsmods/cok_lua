local CommercialItemCell = class("CommercialItemCell", cc.TableViewCell)

function CommercialItemCell:create()
    local cell = CommercialItemCell.new()
    Drequire("game.commercialDarts.CommercialItemCell_ui"):create(cell, 0)
    return cell
end

function CommercialItemCell:refreshCell(info, idx)
    if info then self.itemId = info end

    local itemId = atoi(self.itemId)
    local tInfo = ToolController:call("getToolInfoForLua", itemId)
    if tInfo then
        local cnt = tInfo:call("getCNT")
        self.ui.m_useBtn:setEnabled(cnt > 0)
        self.ui.m_numLabel:setString(CC_CMDITOA(cnt))
    else
        self.ui.m_useBtn:setEnabled(false)
        self.ui.m_numLabel:setString("0")
    end

    LibaoCommonFunc.createDataItemTouchNode(
        {
            itemData = {
                            type = 0,
                            itemId = itemId,
                        },
            iconNode = self.ui.m_iconNode,
            iconSize = 88,
            beTouch = true,
        }
    )

    self.ui.m_useBtn:setSwallowsTouches(false)
end

function CommercialItemCell:itemChange()
    self:refreshCell()
end

function CommercialItemCell:onEnter()
    registerScriptObserver(self, self.itemChange, MSG_REFREASH_TOOL_DATA)
end

function CommercialItemCell:onExit()
    unregisterScriptObserver(self, MSG_REFREASH_TOOL_DATA)
end

function CommercialItemCell:onUseBtnClick()
    if self.itemId then
        local itemId = atoi(self.itemId)
        ToolController:call("useTool", itemId, 1, true, false)
    end
end

return CommercialItemCell