CamelTile = class("CamelTile", function()
    return NewBaseTileLuaInfo:call("create")
end
)

function CamelTile:create( index )
    local tile = CamelTile.new(index)
    if tile:initView(index) then
        return tile
    end
end

function CamelTile:ctor(index)
    self.cityIndex = index
    self.ctrl = require("game.commercialDarts.CommercialController").getInstance()
end

function CamelTile:initView( index )
    self:call("setCityIndex", index)
    if self:call("initTile", true) == false then return false  end

    local cityInfo = self:call("getCityInfo")
    if nil == cityInfo then return false end

    self.cityInfo = cityInfo
    self.luaMap = cityInfo:call("getLuaMap")
    --dump(self.luaMap)

    self.data = self.ctrl:getMarchInfo(self.luaMap.caravanUuid)
    if self.data == nil then return false end

    registerNodeEventHandler(self)
    self:call("addToParent")
    self:refreshView()

    return true
end

function CamelTile:onEnterFrame(dt)
    local now = WorldController:call("getTime")
    local name = self.data.ownerInfo.name
    local abbr = self.data.ownerInfo.abbr
    local occupier = self.data.obtainInfo
    local showDialog = ""
    local prefix = ""
    local startTime = atoi(self.data.obtainStartTime)
    local endTime = atoi(self.data.obtainEndTime)
    local leftTime = endTime - now

    if occupier then 
        name = occupier.name
        abbr = occupier.abbr 
        showDialog = "9200939"
        
        local totoalTime = atoi(self.data.obtainNeedTime)
        local percent = leftTime / totoalTime
        percent = math.min(percent, 1)
        percent = math.max(percent, 0)
        prefix = string.format("%d%%", math.ceil(percent * 100))
    else
        showDialog = "41576054"
        prefix = format_time(leftTime / 1000)
    end
    
    if abbr and abbr ~= "" then
        name = string.join("", "(", abbr, ") ", name)
    end

    if leftTime > 0 then
        local tip = getLang(showDialog, name, prefix)
        self:call("setAllianceString", tip)
    else
        self:closeTile()
    end
end

function CamelTile:onEnter()
    local function update(dt) self:onEnterFrame(dt) end 
	self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(update, 1, false)
    registerScriptObserver(self, self.refreshView, "COMMERCIAL_DETAIL")
end

function CamelTile:onExit()
    cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
    unregisterScriptObserver(self, "COMMERCIAL_DETAIL")
end

function CamelTile:refreshView(params)
    local function setCallBack(name, index, func, state)
        local function callback() func(self) end
        self:call("setButtonName", index, name)
        self:call("setButtonState", index, state)
        self:call("setButtonCallback", index, cc.CallFunc:create(callback))
    end

    local playerInfo = GlobalData:call("getPlayerInfo")
    local mineUid = playerInfo:getProperty("uid")
    local selfAllianceId = playerInfo:call("getAllianceId")

    local occupier = self.data.obtainInfo
    local ownerInfo = self.data.ownerInfo

    local uid = ownerInfo.uid
    local allianceId = ownerInfo.allianceId
    
    if occupier then
        uid = occupier.uid
        allianceId = occupier.allianceId
    end
    
    if uid == mineUid then
        if self.data:haveEscortArmy() then   
            self:call("setButtonCount", 3)
            setCallBack(getLang("41576037"), 1, self.troop, TileButtonState.ButtonViewTroop)
            setCallBack(getLang("41576040"), 2, self.assist, TileButtonState.ButtonSupport)
            setCallBack(getLang("108556"), 3, self.recall, TileButtonState.ButtonRecall)
        else
            self:call("setButtonCount", 1)
            setCallBack(getLang("41576040"), 1, self.assist, TileButtonState.ButtonSupport)
        end
    else
        --盟友
        if allianceId ~= "" and allianceId == selfAllianceId then
            if self.data:haveEscortArmy() then
                self:call("setButtonCount", 1)
                setCallBack(getLang("41576037"), 1, self.troop, TileButtonState.ButtonViewTroop)
            else
                self:call("setButtonCount", 0)
            end
        --其他人
        else
            if self.data:haveEscortArmy() then
                self:call("setButtonCount", 3)
                setCallBack(getLang("41576038"), 1, self.scout, TileButtonState.ButtonScout)
                setCallBack(getLang("41576037"), 2, self.troop, TileButtonState.ButtonViewTroop)
                setCallBack(getLang("41576039"), 3, self.attack, TileButtonState.ButtonMarch)
            else
                self:call("setButtonCount", 2)
                setCallBack(getLang("41576038"), 2, self.scout, TileButtonState.ButtonScout)
                setCallBack(getLang("41576039"), 3, self.attack, TileButtonState.ButtonMarch)
            end
        end
    end
end

function CamelTile:troop()
    local marchUuid = self.data.escortUuid

    local rewardT = {}
    table.insert(rewardT, self.data.rewardId)
    if self.data.luckyReward then
        table.insert(rewardT, self.data.luckyReward)
    end

    local ownerInfo = self.data.ownerInfo
    local name = ownerInfo.name
    local abbr = ownerInfo.abbr 
    local occupier = self.data.obtainInfo
    if occupier then
        name = occupier.name
        abbr = occupier.abbr
    end

    if abbr and abbr ~= "" then
        name = string.join("", "(", abbr, ") ", name)
    end

    local view = Drequire("game.commercialDarts.CommercialDetailView"):create(ownerInfo, self.data.uuid, marchUuid, rewardT, self.data.baseRate)
    PopupViewController:addPopupView(view)

    self:closeTile()
end

function CamelTile:assist()
    local uuid = self.data.uuid
    local ownerId = self.data.ownerInfo.uid
    if self.data.obtainInfo then
        ownerId = self.data.obtainInfo.uid
    end
    local view = Drequire("game.commercialDarts.CommercialAssistView"):create(uuid, ownerId)
    PopupViewController:addPopupView(view)

    self:closeTile()
end

function CamelTile:attack()
    local uuid = self.data.uuid
    
    -- local dict = CCDictionary:create()
    -- dict:setObject(CCString:create("OpenBattleViewForCommercial"), "name")
    -- dict:setObject(CCString:create("-168"), "type")
    -- dict:setObject(CCString:create(uuid), "id")
    -- dict:setObject(CCString:create("COMMERCIAL_ATTACK"), "key")
    -- LuaController:call("openPopViewInLua", dict) 

    local view = Drequire("game.CommonPopup.BattleView"):createViewForCommercial(-168, uuid, "COMMERCIAL_ATTACK")
    PopupViewController:addPopupInView(view)
    self.ctrl:getMarchTime(uuid)

    self:closeTile()
end

function CamelTile:recall()
    local marchUuid = self.data.escortUuid

    local dict = CCDictionary:create()
    dict:setObject(CCString:create(marchUuid), "uuid")
    local view = Drequire("game.CommonPopup.UseToolView"):create(USE_TOOL_COMMERCIAL_CANCEL, dict)
    PopupViewController:addPopupInView(view) 

    self:closeTile()
end

function CamelTile:scout()
    self.ctrl:scout(nil, self.data.uuid, self.data.ownerInfo.name)
    self:closeTile()
end

function CamelTile:closeTile()
    self = tolua.cast(self, "NewBaseTileLuaInfo")
    
    self:call("closeThis")
end
