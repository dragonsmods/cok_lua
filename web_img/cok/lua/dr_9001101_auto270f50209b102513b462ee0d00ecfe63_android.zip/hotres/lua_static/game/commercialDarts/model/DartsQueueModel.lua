local DartsQueueModel = class("DartsQueueModel", Drequire("game.commercialDarts.model.BaseQueueModel"))

--美术给的资源未按白绿篮紫橙金排序
local CamelColorMap =  
{
    ["1"] = 1,
    ["2"] = 4,
    ["3"] = 3,
    ["4"] = 5,
    ["5"] = 0,
    ["6"] = 2,
}

function DartsQueueModel:parse(data)
    if data.uuid then
        self.uuid = data.uuid
    end

    --地图用
    if self.marchTag == 0 then
        self.marchTag = WorldController:call("getMarchTag")
    end

    --队列用
    if self.marchQid == 0 then
        self.marchQid = QueueController:call("getQID", QueueType.TYPE_MARCH) + self.marchTag
    end

    if data.startPoint then
        self.startPoint.x = atoi(data.startPoint.x)
        self.startPoint.y = atoi(data.startPoint.y)
    end

    if data.endPoint then
        self.endPoint.x = atoi(data.endPoint.x)
        self.endPoint.y = atoi(data.endPoint.y)
    end

    if data.marchUuid then
        self.escortUuid = data.marchUuid
    else
        self.escortUuid = ""
    end

    if data.startTime then self.startTime = atoi(data.startTime) end
    if data.endTime then self.endTime = atoi(data.endTime) end
    if data.allianceId then self.allianceId = data.allianceId end
    
    if data.configId then 
        if self.configId ~= "" and self.configId ~= data.configId then
            self.recreate = true
        end
        self.configId = data.configId 
    end

    if data.rewardId then self.rewardId = data.rewardId end
    if data.luckyReward then self.luckyReward = data.luckyReward end
    if data.state then self.state = atoi(data.state) end
    if data.obtainStartTime then self.obtainStartTime = atoi(data.obtainStartTime) end
    if data.obtainEndTime then self.obtainEndTime = atoi(data.obtainEndTime) end
    if data.obtainNeedTime then self.obtainNeedTime = atoi(data.obtainNeedTime) end
    if data.ownerInfo then self.ownerInfo = data.ownerInfo end
  
    if data.obtainInfo then
        self.obtainInfo = data.obtainInfo
        self:clearMarch()
    else
        self.obtainInfo = nil
    end

    self.tmpPos = {}
    if data.tmpPointId then
        self.tmpPointId = atoi(data.tmpPointId)
        self.startPointMap = nil
        self.endPointMap = nil
    else
        self.tmpPointId = 0
    end

    if data.totalTime then self.totalTime = atoi(data.totalTime) end
    if data.baseRate then self.baseRate = atoi(data.baseRate) end
    if data.attSkin then self.attSkin = atoi(data.attSkin) end
    if data.marchSkin then self.marchSkin = atoi(data.marchSkin) end
end

function DartsQueueModel:createMarchNode()
    local directionStr = ""
    local flipX = false

    local direction = self:getDirection()
    if direction == 0 then
        directionStr = "W"
    elseif direction == 1 then
        directionStr = "SW"
        flipX = true
    elseif direction == 2 then
        directionStr = "S"
    elseif direction == 3 then
        directionStr = "SW"
    elseif direction == 4 then
        directionStr = "W"
        flipX = true
    elseif direction == 5 then
        directionStr = "NW"
    elseif direction == 6 then
        directionStr = "N"
    elseif direction == 7 then
        directionStr = "NW"
        flipX =  true
    end

    local rootPath = CCFileUtils:sharedFileUtils():getWritablePath() .. "dresource/"

    local camelType = CCCommonUtilsForLua:call("getPropByIdGroup", "bodyguard_level", self.configId, "type")
    local goodsColor = CCCommonUtilsForLua:call("getPropByIdGroup", "bodyguard_level", self.configId, "color")
    local marchColor = CamelColorMap[goodsColor] or 1
    local skin_file = rootPath .. string.format("sk_commercial_camel%d.atlas", atoi(camelType))
    local skin_json = rootPath .. string.format("sk_commercial_camel%d.json", atoi(camelType))
    local aniName = string.format("walk_%d", direction)
    local skin = string.format("goods_%d", direction)
    local slot = string.format("goods_%s_%d_000_", directionStr, marchColor)
    if flipX then slot = slot .. "2" end
    local attachment = string.format("goods_%s_%d_000_", directionStr, marchColor)
    local marchNode = IFAvatarMarchSkNode:call("createWithJsonAndAtlas", skin_json, skin_file, aniName, skin, slot, attachment)
    if marchNode then
        local haloSlot = "guanghuan_"
        local haloIndex = tostring(direction + 1)
        if haloIndex == "1" then haloIndex = "" end
        haloSlot = haloSlot .. haloIndex
        local haloAttachment = string.format("guanghuan_%d", direction)
        local animationObj = marchNode:call("getAnimationObj")
        if self.ownerType == PlayerType.PlayerSelf then
            animationObj:setAttachment(haloSlot, haloAttachment)
        end
        WorldMapView:call("addAvatarMarchNodeToBatch", marchNode)
    else
        --骆驼队列
        marchNode = IFAvatarMarchSkNode:call("createForLua", 12000986, 0, direction)
        if marchNode then
            WorldMapView:call("addAvatarMarchNodeToBatch", marchNode)
        else
            marchNode = cc.Node:create()
            WorldMapView:call("getMapMarchNode"):addChild(marchNode)
        end
    end
    marchNode:setTag(self.marchTag)
    return marchNode

end

function DartsQueueModel:getLocation()
    if self.tmpPointId > 0 then
        if self.tmpPos.x and self.tmpPos.y then
            return self.tmpPos.x, self.tmpPos.y
        else
            local point = WorldController:call("getPointByIndex", self.tmpPointId)
            local mapPos = WorldController:call("getViewPointByTilePoint", point)
            self.tmpPos.x = mapPos.x
            self.tmpPos.y = mapPos.y
            return mapPos.x, mapPos.y
        end
    else
        if self.posX and self.posY then
            return self.posX, self.posY
        end
    end
end

function DartsQueueModel:update(now, dt, followMarchId)
    local addFlag = false

    if self.tmpPointId > 0 then return addFlag end

    if not self.startPointMap and not self.endPointMap then
        self.startPointMap = WorldController:call("getViewPointByTilePoint", ccp(self.startPoint.x, self.startPoint.y))
        self.endPointMap = WorldController:call("getViewPointByTilePoint", ccp(self.endPoint.x, self.endPoint.y))
    end

    local t = 1 - (self.endTime - now) / self.totalTime
    if self.endTime < now then t = 1 end
   
    if self.recreate then
        self:clearMarch()
        self.recreate = false
    end

    local marchNode = WorldMapView:call("getMarchNodeByTag", self.marchTag)
    if not marchNode then
        marchNode = self:createMarchNode()
        addFlag = true
    end

    local xMove = (self.endPointMap.x - self.startPointMap.x) * t
    local yMove = (self.endPointMap.y - self.startPointMap.y) * t
    local posX = self.startPointMap.x + xMove
    local posY = self.startPointMap.y + yMove
    marchNode:setPosition(posX, posY)

    self.posX = posX
    self.posY = posY

    if self.uuid == followMarchId then self:jumpToTarget(marchNode) end

    return addFlag
end

function DartsQueueModel:clearMarch()
    local world = WorldMapView:call("instance")
    if not world then return end
    
    local marchNode = world:call("getMapMarchNode")
    if marchNode then
        marchNode:removeChildByTag(self.marchTag)
    end

    world:call("eraseAvatarMarchNode", self.marchTag)
end

function DartsQueueModel:isRestState()
    return self.state == DartsState.Rest
end

function DartsQueueModel:isTransferState()
    return self.state == DartsState.Transfer
end

function DartsQueueModel:isOccupyState()
    return self.state == DartsState.Attack
end

function DartsQueueModel:isRepairState()
    return self.state == DartsState.Repair
end

return DartsQueueModel