local superClass = require("game.CommonPopup.UiCompoentIcon")
local CommercialSpeIcon = class("CommercialSpeIcon",superClass)

function CommercialSpeIcon.create(iconSize, contentSize)
    local view = CommercialSpeIcon.new(iconSize)
    if view:initView(iconSize, contentSize) then
        return view
    end
end

-- function CommercialSpeIcon:ctor()
-- 	self.showCounter = 0
-- 	self.showSeconds = 10
-- 	self.showDialog = false
-- end

function CommercialSpeIcon:initView(iconSize, contentSize)
	self.showCounter = 0
	self.showSeconds = 10
	self.showDialog = false

	self.m_iconSize = iconSize
	self:setContentSize(iconSize)
	self:setVisible(false)

	self.t_name = cc.LabelTTF:create("", "Helvetica", 18)
    self.t_name:setPosition(ccp(iconSize.width / 2,  2))
    self.t_name:setAnchorPoint(ccp(0.5, 0) )
	self:addChild(self.t_name, 2)
    utils.attachBgToLabel(self.t_name)
	registerNodeEventHandler(self)

	self:refreshUI()
	return true
end

function CommercialSpeIcon:onEnterFrame(dt)
	self.showCounter = self.showCounter + dt
	local now = getTimeStamp()
	local endTime = self:getMgrIns():getSpeEndTime()
	local remain = endTime - now
	if remain > 0 then
		if self.showCounter > self.showSeconds then
			local function change()
				self.showDialog = not self.showDialog
				self.showCounter = 0
				self:onEnterFrame(0)
			end
			local flip = cc.ScaleTo:create(0.3, 0, 1)
			local callFunc = cc.CallFunc:create(change)
			local flipR = cc.ScaleTo:create(0.3, 1, 1)
			local seq = cc.Sequence:create(flip, flipR, callFunc)
			self.t_name:stopAllActions()
			self.t_name:runAction(seq)
		end

		if self.showDialog then
			--41576230=奖励UP
			self.t_name:setString(getLang("41576230"))
		else
			self.t_name:setString(format_time(remain))
		end
	else
		self:getMgrIns():tryDestroyIcon()
	end
end

function CommercialSpeIcon:onEnter()
	self:onEnterFrame(0)
	local function update(dt) self:onEnterFrame(dt) end
	self.entry = self:getScheduler():scheduleScriptFunc(update, 1, false)
end

function CommercialSpeIcon:onExit()
	self:getScheduler():unscheduleScriptEntry(self.entry)
end

function CommercialSpeIcon:getMgrIns(  )
	local mgrIns = self.m_mgrIns
	if not mgrIns then
	    mgrIns = require("game.commercialDarts.CommercialController").getInstance()
	    self.m_mgrIns = mgrIns
	end
	return mgrIns
end

function CommercialSpeIcon:refreshUI()
    local bg = CCLoadSprite:createSprite("popup_list_btn_bg.png")
	bg:setPosition(ccp(self.m_iconSize.width * 0.5, self.m_iconSize.height * 0.5))
    self:addChild(bg)

    local icon = CCLoadSprite:createSprite("icon_camel.png")
    icon:setPosition(ccp(self.m_iconSize.width * 0.5, self.m_iconSize.height * 0.5))
    self:addChild(icon)
    self:setVisible(true)
end

function CommercialSpeIcon:touchEvent()
	self:getMgrIns():showPopView()
end

function CommercialSpeIcon:onSceneChanged(sceneId)
	if sceneId == SCENE_ID_WORLD then
		self:setVisible(false)
	else
		self:setVisible(true)
	end
end

function CommercialSpeIcon:onCleanup(  )

end

return CommercialSpeIcon