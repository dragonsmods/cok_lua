local CommercialController = class("CommercialController")

local CELL_HEIGHT = 59

--c++ 每帧20个队列形象和行军线保护
--lua 暂时每帧10个看看压力
local MarchAddPerFrame = 10

local _CommercialInstance = nil

function CommercialController.getInstance()
    if not _CommercialInstance then
        _CommercialInstance = CommercialController.new()
    end

    return _CommercialInstance
end

function CommercialController:ctor()
    --行军信息
    self.marchInfos = {}
    --移除队列数据
    self.removeUuids = {}
    --移除队列UI
    self.removeQids = {}
    --跟踪队列ID
    self.followMarchId = ""
    --将要打开的队列详情
    self.willShowMarchId = ""
    --功能开关
    self.funSwitch = false
    --功能开启等级
    self.openLevel = 16
    --国运信息
    self.speAct = nil
    --国运开始时间
    self.speStartTime = 0
    --国运结束时间
    self.speEndTime = 0
    --国运路线
    self.path = 0
    --国运驿站信息
    self.station = {}
    --监听消息
    registerScriptObserver(self, self.createQueueUI, "BASEQUEUE_UI")
    registerScriptObserver(self, self.receive, "COMMERCIAL_RECEIVE")
    registerScriptObserver(self, self.attack, "COMMERCIAL_ATTACK")
    registerScriptObserver(self, self.assist, "COMMERCIAL_ASSIST")
    registerScriptObserver(self, self.accelerate, "COMMERCIAL_ACCELERATE")
    registerScriptObserver(self, self.removeOthers, "COMMERCIAL_PURGE")
    registerScriptObserver(self, self.clearAllMarch, "COMMERCIAL_CLEAR")
    registerScriptObserver(self, self.clickMap, "COMMERCIAL_CLICKMAP")
    registerScriptObserver(self, self.miniMap, "COMMERCIAL_MINIMAP")
    registerScriptObserver(self, self.addCamelRoad, "COMMERCIAL_ROAD")
    registerScriptObserver(self, self.unlockMorale, "COMMERCIAL_MORALE")
    ---启动帧定时器
    self:schedule()
end

--------地图场景--------
function CommercialController:initQueue(data)
    if data.caravan then
        for _, data in ipairs(data.caravan) do
            self:addEscortQueue(data)
        end
    end

    if data.marches then
        self:addAttackQueue(data)
    end

    if data.speAct then
        self.speAct = data.speAct
    end

    if data.path then
        self.path = atoi(data.path)
    end

    if data.station then
        self.station = data.station
    end

    self:checkSpeIcon()
    self:checkGuide()
end

function CommercialController:update(dt)
    if not self.funSwitch then return end
    
    local initWorld = WorldController:call("getInstance"):getProperty("initWorld")
    local selfServer = GlobalData:call("getPlayerInfo"):call("isInSelfServer")
    local now = WorldController:call("getTime")
    local addNum = 0
    
    for uuid, model in pairs(self.marchInfos) do
        if initWorld and selfServer and addNum < MarchAddPerFrame and model:update(now, dt, self.followMarchId) then
            addNum = addNum + 1
        end

        if initWorld and self.willShowMarchId == model.uuid then
            self:showTroopInfo(model.uuid)
            self.willShowMarchId = ""
        end

        local rmUuid, rmQid = model:checkOverTime(dt)
        if rmUuid then
            table.insert(self.removeUuids, rmUuid) 
        end

        if rmQid then 
            table.insert(self.removeQids, rmQid)
        end
    end

    for _, uuid in ipairs(self.removeUuids) do
        self.marchInfos[uuid] = nil
    end
    self.removeUuids = {}
    if #self.removeQids > 0 then
        --移除UI队列
        CCSafeNotificationCenter:postNotification(MSG_QUEUE_REMOVE)
    end
end

function CommercialController:addEscortQueue(data)
    local playerInfo = GlobalData:call("getPlayerInfo")
    local mineUid = playerInfo:getProperty("uid")
    local selfAllianceId = playerInfo:call("getAllianceId")

    local marchInfo = self.marchInfos[data.uuid]
    if not marchInfo then
        marchInfo = require("game.commercialDarts.model.DartsQueueModel").new()
    end
    marchInfo:parse(data)
    --标记镖车
    marchInfo:setDarts()
    local rmQid = marchInfo:setOwnerType(mineUid, selfAllianceId)
    self.marchInfos[marchInfo.uuid] = marchInfo
    --同步时间
    -- local now = WorldController:call("getTime")
    -- local dTime = math.abs(now - marchInfo.startTime)
    -- if dTime > 1000 and dTime < 10000 then
    --     WorldController:call("resetTime", marchInfo.startTime)
    -- end
    if marchInfo.ownerType == PlayerType.PlayerSelf then
        CCSafeNotificationCenter:postNotification(MSG_QUEUE_ADD)
    end
    
    if rmQid then
        table.insert(self.removeQids, rmQid)
        CCSafeNotificationCenter:postNotification(MSG_QUEUE_REMOVE)
    end
end

function CommercialController:addAttackQueue(data)
    if data and data.marches then
        local playerInfo = GlobalData:call("getPlayerInfo")
        local mineUid = playerInfo:getProperty("uid")
        local selfAllianceId = playerInfo:call("getAllianceId")

        local notify = false

        local function getDartsLocation(uuid)
            if self.marchInfos[uuid] and self.marchInfos[uuid].getLocation then
                return self.marchInfos[uuid]:getLocation()
            end
        end

        for _, oneData in ipairs(data.marches) do
            local marchInfo = self.marchInfos[oneData.uuid]

            if marchInfo and marchInfo.marchType ~= atoi(oneData.marchType) then
                marchInfo:clearMarch()
                if marchInfo.ownerType == PlayerType.PlayerSelf then
                    table.insert(self.removeQids, marchInfo.marchQid)
                end
                
                self.marchInfos[oneData.uuid] = nil
                marchInfo = nil
            end

            if not marchInfo then
                --接镖和返回直线队列
                if atoi(oneData.marchType) == 3 
                    or atoi(oneData.marchType) == 5 then
                    marchInfo = require("game.commercialDarts.model.NormalQueueModel").new()
                --攻击队列队列 贝塞尔曲线
                elseif atoi(oneData.marchType) == 2 then  
                    marchInfo = require("game.commercialDarts.model.BezierQueueModel").new()
                    marchInfo:setDartsCb(getDartsLocation)
                end
            end

            if marchInfo then
                marchInfo:parse(oneData)
                marchInfo:setOwnerType(mineUid, selfAllianceId)
                self.marchInfos[oneData.uuid] = marchInfo

                if marchInfo.ownerType == PlayerType.PlayerSelf then
                    notify = true
                end
            end
        end

        if notify then
            CCSafeNotificationCenter:postNotification(MSG_QUEUE_ADD)
        end
    end
end

function CommercialController:schedule()
    local function update(dt) self:update(dt) end 
	self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(update, 0, false)
end

function CommercialController:unSchedule()
    cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
end

function CommercialController:getMarchInfo(uuid)
    return self.marchInfos[uuid]
end

local function sortByTag(m1, m2)
    if m1 and m2 then
        return m1.marchTag < m2.marchTag
    else
        return false
    end
end

--队列显示在主UI
function CommercialController:createQueueUI(recipient)
    if recipient then
        local queueNode = recipient:objectForKey("node")

        for _, marchQid in ipairs(self.removeQids) do
            queueNode:removeChildByTag(marchQid)
        end

        if #self.removeQids > 0 then self.removeQids = {} end

        local queueCount = 0
        local tmpY = 0
        local isExpansion = recipient:objectForKey("isExpansion"):getValue()
        local showMarch = {}
        for uuid, marchInfo in pairs(self.marchInfos) do
            if marchInfo.ownerType == PlayerType.PlayerSelf then
                table.insert(showMarch, marchInfo)
            end
        end
        
        --预防UI队列上下跳动
        table.sort(showMarch, sortByTag)

        for _, marchInfo in ipairs(showMarch) do
            local cell = queueNode:getChildByTag(marchInfo.marchQid)
            if not cell then
                cell = require("game.commercialDarts.CommercialQueueCell"):create(marchInfo.uuid)
                queueNode:addChild(cell)
            end
            cell:setPositionY(tmpY)
            cell:setTag(marchInfo.marchQid)
            tmpY = tmpY - CELL_HEIGHT
            queueCount = queueCount + 1
            if isExpansion and queueCount > 2 then
                cell:setVisible(false)
            else
                cell:setVisible(true)
            end
        end
        
        recipient:setObject(CCString:create(tostring(queueCount)), "queueCount")
    end
end

function CommercialController:showTroopInfo(uuid)
    local marchInfo = self.marchInfos[uuid]
    if marchInfo then
        local view = Drequire("game.commercialDarts.TroopInfoView"):create(uuid)
        PopupViewController:addPopupView(view)
    end
end

function CommercialController:receive(dict)
    local data = dictToLuaTable(dict)

    local cmdData = {}
    cmdData.type = atoi(CCCommonUtilsForLua:call("getPropByIdGroup", "bodyguard_level",  data.id, "type"))
    cmdData.petDragonUid = data.petDragonUid
    cmdData.generalId = data.generalId
    cmdData.soldiers = data.soldiers
    cmdData.aormationId = data.aormationId

    if sizen(data.soldiers) == 0 then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("105112"))
        return 
    end
    self:preSubSoilders(data.soldiers)

    local mineUid = PlayerInfoController:getUid()
    local setKey = string.join("", "CommercialStop", mineUid)
    local stop = cc.UserDefault:getInstance():getBoolForKey(setKey, true)
    cmdData.unStop = not stop
    

    require("game.commercialDarts.CommercialCommands"):receive(cmdData)
end

function CommercialController:attack(dict)
    local data = dictToLuaTable(dict)

    local cmdData = {}
    cmdData.uuid = data.id
    cmdData.petDragonUid = data.petDragonUid
    cmdData.generalId = data.generalId
    cmdData.soldiers = data.soldiers
    cmdData.aormationId = data.aormationId

    if sizen(data.soldiers) == 0 then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("105112"))
        return 
    end
    self:preSubSoilders(data.soldiers)

    require("game.commercialDarts.CommercialCommands"):attack(cmdData)
end

function CommercialController:assist(dict)
    local data = dictToLuaTable(dict)

    local cmdData = {}
    cmdData.uuid = data.id
    cmdData.petDragonUid = data.petDragonUid
    cmdData.generalId = data.generalId
    cmdData.soldiers = data.soldiers
    cmdData.aormationId = data.aormationId
    
    if sizen(data.soldiers) == 0 then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("105112"))
        return 
    end

    self:preSubSoilders(data.soldiers)

    require("game.commercialDarts.CommercialCommands"):assist(cmdData)
end

function CommercialController:accelerate(param)
    local data = dictToLuaTable(param)
    if data.uuid and data.itemId then
        local uuid = data.uuid
        local itemId = atoi(data.itemId)
        require("game.commercialDarts.CommercialCommands"):accelerate(uuid, itemId)
    end
end

function CommercialController:recall(uuid, itemId)
    require("game.commercialDarts.CommercialCommands"):recall(uuid, itemId)
end

function CommercialController:reinforce(uuid)
    require("game.commercialDarts.CommercialCommands"):reinforce(uuid)
end

function CommercialController:viewTroop(uuid)
    require("game.commercialDarts.CommercialCommands"):viewTroop(uuid)
end

function CommercialController:refreshMult(uuid)
    require("game.commercialDarts.CommercialCommands"):refreshMult(uuid)
end

function CommercialController:reqEnemySpeed(uuid)
    require("game.commercialDarts.CommercialCommands"):reqEnemySpeed(uuid)
end

function CommercialController:pointDetail(uuid)
    require("game.commercialDarts.CommercialCommands"):pointDetail(uuid)
end

function CommercialController:syncQueueData()
    self.funSwitch = CCCommonUtilsForLua:isFunOpenByKey("bodyguard")
    self.openLevel = CCCommonUtilsForLua:call("getPropByIdGroup","data_config","commercial","k1")
    self.openLevel = tonumber(self.openLevel) or 16

    if self.funSwitch then
        if CCCommonUtilsForLua:call("isKuaFuWangZhan") or isCrossServerNow() == false then
            require("game.commercialDarts.CommercialCommands"):syncQueue()
        end
    end
end

--删除不是自己类型的行军信息
function CommercialController:removeOthers()
    self.followMarchId = ""

    local removeT = {}
    for uuid, marchInfo in pairs(self.marchInfos) do
        if marchInfo.ownerType ~= PlayerType.PlayerSelf then
            table.insert(removeT, uuid)
        end
    end

    for _, uuid in ipairs(removeT) do
        if self.marchInfos[uuid] then
            self.marchInfos[uuid]:clearMarch()
            self.marchInfos[uuid] = nil
        end
    end
end

--移除所有队列
function CommercialController:clearAllMarch()
    for uuid, marchInfo in pairs(self.marchInfos) do
        if marchInfo.ownerType == PlayerType.PlayerSelf then
            table.insert(self.removeQids, marchInfo.marchQid)
        end
    end
    self.marchInfos = {}
    self:syncQueueData()
end

--地图点击判断是否点到队列
function CommercialController:clickMap(param)
    local p = dictToLuaTable(param)
    local pt = ccp(atoi(p.x), atoi(p.y))

    local findUuid = ""
    for uuid, model in pairs(self.marchInfos) do
        if model:isClickOnSelf(pt) then
            self:showTroopInfo(uuid)
            self.followMarchId = uuid
            findUuid = uuid
            break
        end
    end    

    if findUuid ~= "" then
        param:setObject(CCString:create(uuid), "uuid")
    end
end

function CommercialController:preSubSoilders(soldiers)
    for armyId, armyNum in pairs(soldiers) do
        local armyInfo = GlobalData:call("getArmyInfoById", armyId)
        if armyInfo then
            local free = armyInfo:getProperty("free")
            local march = armyInfo:getProperty("march")
            free = free - atoi(armyNum)
            free = free > 0 and free or 0
            march = march + atoi(armyNum)
            march = march > 0 and march or 0
            armyInfo:setProperty("free", free)
            armyInfo:setProperty("march", march)
        end
    end
end

function CommercialController:revertSoilders(soldiers)
    for armyId, armyNum in pairs(soldiers) do
        local armyInfo = GlobalData:call("getArmyInfoById", armyId)
        if armyInfo then
            local free = armyInfo:getProperty("free")
            local march = armyInfo:getProperty("march")
            free = free + atoi(armyNum)
            free = free > 0 and free or 0
            march = march - atoi(armyNum)
            march = march > 0 and march or 0
            armyInfo:setProperty("free", free)
            armyInfo:setProperty("march", march)
        end
    end
end

function CommercialController:marchBackSync(data)
    if data.soldiers then
        for _, armyData in ipairs(data.soldiers) do
            local armyInfo = GlobalData:call("getArmyInfoById", armyData.id)
            if armyInfo then
                armyInfo:setProperty("free", atoi(armyData.free))
                if armyData.march then
                    armyInfo:setProperty("march", atoi(armyData.march))
                end
            end
        end
        CCSafeNotificationCenter:postNotification(ARMY_NUM_CHANGE)
        CCSafeNotificationCenter:postNotification(MSG_TROOPS_CHANGE)
    end
end

function CommercialController:requestMyTroop()
    local removeT = {}
    for uuid, marchInfo in pairs(self.marchInfos) do
        if marchInfo.ownerType == PlayerType.PlayerSelf then
            local marchUuid = marchInfo:isDarts() and marchInfo.escortUuid or marchInfo.uuid
            if marchUuid ~= "" then
                self:viewTroop(marchUuid)
            end
        end
    end
end


local RomanNum = 
{
    "137054",
    "137055",
    "137056",
    "137057",
}
--------UI场景--------
function CommercialController:getPath(src)
    local path = {}
    local count = #RomanNum
    if RomanNum[src] then
        while #path < count do
            table.insert(path, getLang(RomanNum[src]))
            src = src + 1
            if src > count then src = 1 end
        end
    end

    return table.concat(path, "-")
end


function CommercialController:reqMineData()
    require("game.commercialDarts.CommercialCommands"):reqMineData()
end

function CommercialController:reqOtherData()
    require("game.commercialDarts.CommercialCommands"):reqOtherData()
end

function CommercialController:jumpCamel(uuid)
    PopupViewController:call("removeAllPopupView")
    require("game.commercialDarts.CommercialCommands"):jumpCamel(uuid)
end

function CommercialController:prayCamel(uuid)
    require("game.commercialDarts.CommercialCommands"):prayCamel(uuid)
end

function CommercialController:refreshCamel(configId)
    require("game.commercialDarts.CommercialCommands"):refreshCamel(configId)
end

function CommercialController:continueCamel(uuid)
    require("game.commercialDarts.CommercialCommands"):continueCamel(uuid)
end

function CommercialController:getMarchTime(uuid)
    require("game.commercialDarts.CommercialCommands"):getMarchTime(uuid)
end

function CommercialController:scout(index, uuid, name)
    require("game.commercialDarts.CommercialCommands"):scout(index, uuid, name)
end

function CommercialController:saveRefresh()
    require("game.commercialDarts.CommercialCommands"):saveRefresh()
end

function CommercialController:miniMap()
    if self.funSwitch then
        require("game.commercialDarts.CommercialCommands"):miniMap()
    end
end

function CommercialController:isActivityOpen()
    local actObj = ActivityController:call("getActObj", "57473")
    if actObj then
        local startTime = actObj:getProperty("startTime")
        local endTime = actObj:getProperty("endTime")
        local worldTime = getWorldTime()
        if startTime < worldTime and worldTime < endTime then
            return true
        end
    end

    return false
end
--地图镖车线路
function CommercialController:addCamelRoad()
    if self.funSwitch == false then return end
    if self:isActivityOpen() == false then return end

    local world = WorldMapView:call("instance")
    if nil == world then return end

    local camelRoadNode = world:call("getCamelRoadNode")
    if camelRoadNode then
        camelRoadNode:removeAllChildren()

        local path = self.path
        local count = #self.station
        local points = {}
        while #points < count do
            if self.station[path] then
                table.insert(points, self.station[path].point)
            end

            path = path + 1
            if path > count then path = 1 end
        end

        local roadCount = #points - 1
        for index = 1,roadCount do
            local sp = atoi(points[index])
            local dp = atoi(points[index + 1])
            local sPoint = WorldController:call("getPointByIndex", sp)
            local dPoint = WorldController:call("getPointByIndex", dp)
            local src = WorldController:call("getViewPointByTilePoint", sPoint)
            local dst = WorldController:call("getViewPointByTilePoint", dPoint)

            local road = CCLineBatchedSprite:call("createForLua", "camel64.png", src, dst, 64, 70)
            road:setColor(cc.c3b(255, 127, 0))
            camelRoadNode:addChild(road)
        end
    end
end

function CommercialController:getStationPoint(which)
    if self.station[which] then
        return atoi(self.station[which].point)
    end
end

--解锁士气提示
function CommercialController:unlockMorale(param)
    if param then
        local data = dictToLuaTable(param)
        if data.source == "1" then
            CCLoadSprite:call("loadDynamicResourceByName", "commercial_face")
            CCCommonUtilsForLua:call("flyHint", "icon_morale.png", getLang("41576140"), getLang("41576141"))
        end
    end
end

function CommercialController:notifyChatShare(uuid, shareKey, dialogId, data)
    local playerInfo = GlobalData:call("getPlayerInfo")
    if not playerInfo:call("isInAlliance") then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("106204"))
        return
    end

    local uid = playerInfo:getProperty("uid")
    local lastShareTime = cc.UserDefault:getInstance():getIntegerForKey(shareKey .. uid, 0)
    
    local cdTime = 0
    local overTimeTip = "41576176"
    local bubbleImageName = ""
    local title = ""
    if shareKey == "CommercialChatPray" then
        overTimeTip = "41576176"
        title = "41576238"
        bubbleImageName = "ecgnc_background_chat_bubble_business_travel_blessing"
        cdTime = atoi(CCCommonUtilsForLua:call("getPropByIdGroup","data_config","commercial","k2"))
    elseif shareKey == "CommercialChatHelp" then
        overTimeTip = "41576177"
        title = "41576239"
        bubbleImageName = "ecgnc_background_chat_bubble_business_travel_attacked"
        cdTime = atoi(CCCommonUtilsForLua:call("getPropByIdGroup","data_config","commercial","k3"))
    end
    
    local now = getTimeStamp()
    if lastShareTime > 0 and now - lastShareTime < cdTime then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang(overTimeTip))
        return
    end
    
    local mineUid = playerInfo:getProperty("uid")
    local myAllianceId = playerInfo:call("getAllianceId")
    
    local param = 
    {
        key = shareKey,
        uid = mineUid,
        uuid = uuid,
    }
    --回调参数
    local json = require("CommonLib.dkjson")
    local paramStr = json.encode(param)

    local tData = {
        channelType = 1,
        channelId = myAllianceId,
        content = dialogId,
        post = 41,
        extra = 
        {
            sourceType = 1,
            isShowHorn = 0,
            isSelfCanClick = 1,
            recordClickStatu = 0,
            bubbleImageName = bubbleImageName,
            -- clickedBubbleImageName = clickedBubbleImageName,
            titleInfo = 
            {
                content = title,
                contentType = "2",
            },
            contentInfo = 
            {
                contentType = 2,
                textColor = "#b5602d",
                -- clickedTextColor = "#949494",
                clickInfo =
                {
                    jumpType = 1,
                    param = paramStr,
                },
                replaceWords = 
                {
                    {
                        content = data,
                        contentType = 1,
                    }
                }
            }
        }
    }

    local duration = 5 * 60
    if shareKey == "CommercialChatHelp" then
        tData["extra"]["endTimeInfo"] = {
            endTime = getTimeStamp() + duration,      --到期时间
            textColor = "#cacaca",  --时间的显示颜色
        }
    end

    require("game.controller.ChatSharedController").onSharedChatDialogV2019(tData)

    if shareKey == "CommercialChatPray" then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("41576123"))
    elseif shareKey == "CommercialChatHelp" then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("41576124"))
    end

    cc.UserDefault:getInstance():setIntegerForKey(shareKey .. uid, now)
    CCUserDefault:sharedUserDefault():flush()
end

--老版聊天消息回调
function CommercialController:touchShareMsg(shareKey, param)
    if shareKey and param then
        local solts = string.split(param, ";")
        local uid = solts[1]
        local uuid = solts[2]
        if uid and uuid then
            local playerInfo = GlobalData:call("getPlayerInfo")
            local mineUid = playerInfo:getProperty("uid")
            if isCrossServerNow() then
                CCCommonUtilsForLua:call("flyHint", "", "", getLang("610002"))
            else
                if shareKey == "CommercialChatPray" then
                    if mineUid ~= uid then
                        self:prayCamel(uuid)
                    else
                        CCCommonUtilsForLua:call("flyHint", "", "", getLang("41576236"))
                    end
                elseif shareKey == "CommercialChatHelp" then
                    self:jumpCamel(uuid)
                end
            end
        end
    end
end

--2019新版聊天消息回调
function CommercialController:handleClickMessage(pData)
    local shareKey = pData.key
    local uid = pData.uid
    local uuid = pData.uuid 
    if shareKey and uid and uuid then
        local playerInfo = GlobalData:call("getPlayerInfo")
        local mineUid = playerInfo:getProperty("uid")
        local playerInfo = GlobalData:call("getPlayerInfo")
        local mineUid = playerInfo:getProperty("uid")
        if isCrossServerNow() then
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("610002"))
        else
            if shareKey == "CommercialChatPray" then
                if mineUid ~= uid then
                    self:prayCamel(uuid)
                else
                    CCCommonUtilsForLua:call("flyHint", "", "", getLang("41576236"))
                end
            elseif shareKey == "CommercialChatHelp" then
                self:jumpCamel(uuid)
            end
        end
    end
end

function CommercialController:getIconConfig()
    return { iconName = "game.commercialDarts.CommercialSpeIcon", iconType = 2, order = 0, alone = 1 }
end

function CommercialController:getSpeEndTime()
    return atoi(self.speEndTime)
end

function CommercialController:checkSpeIcon()
    local now = getTimeStamp()

    self.speStartTime = 0
    self.speEndTime = 0

    if self.speAct then
        local startTime1 = atoi(self.speAct.startTime1) / 1000
        local endTime1 = atoi(self.speAct.endTime1) / 1000
        local startTime2 = atoi(self.speAct.startTime2) / 1000
        local endTime2 = atoi(self.speAct.endTime2) / 1000
        if now < startTime1
            or (startTime1 <= now and now < (endTime1 - 2)) then
            self.speStartTime = startTime1
            self.speEndTime = endTime1
        elseif now < startTime2
            or (startTime2 <= now and now < (endTime2 - 2)) then
            self.speStartTime = startTime2
            self.speEndTime = endTime2
        end
    end

    if self.speStartTime == 0 or self.speEndTime == 0 then return end
    local function notify()
        UiCompoentControoller.getIconEvent():emit({icon_cfg = self:getIconConfig(), eventType = "create"})
    end
    if self.speStartTime <= now and now < self.speEndTime then
        notify()
    elseif now < self.speStartTime then
        DataController.TimeEventController:addTimeListener({
            key = "commercialIconTime",
            time = self.speStartTime,
            _callBack = notify,
        })
    else
        self:tryDestroyIcon()
    end
end

function CommercialController:tryDestroyIcon()
    UiCompoentControoller.getIconEvent():emit({icon_cfg = self:getIconConfig(), eventType = "destroy"})
    self:checkSpeIcon()
end

----引导----
function CommercialController:showPopView(page)
    local cityLevel = FunBuildController:call("getMainCityLv")
    if FunOpenController:isShowAndDef("fun_caravanEvent", FunBuildController:call("getMainCityLv") < self.openLevel) then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("41576120"))--41576120=城堡等级不足16级，无法参与传奇商旅活动
        return
    end

    if DynamicResourceController2:call("checkDynamicResource", "commercial_face") == false then
        DynamicResourceController2:call("bringFront", "commercial_face")
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("E100091"))--E100091=领主大人，资源下载中，请稍后尝试操作。
        return
    end

    page = page or 1
    local cView = Drequire("game.commercialDarts.CommercialView"):create(page)
    PopupViewController:addPopupInView(cView)
end

function CommercialController:showRankView()
    local rView = Drequire("game.commercialDarts.rank.CommercialRankView"):create()
    PopupViewController:addPopupInView(rView)
end

function CommercialController:canCloseAllView()
    local curView = PopupViewController:call("getCurrentPopupView")
    if curView and curView.__cname then
        if curView.__cname == "TroopInfoView" then
            return true
        end
    end

    if PopupViewController:call("getCurrViewCount") > 0 then 
        return false 
    end 

    return true
end

function CommercialController:checkGuideLockRes()
    if GuideController:call("isInTutorial") then return false end
    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	local isLocked = playerInfo:getProperty("AccountLocked")
    if isLocked == 1 then return false end
    if DynamicResourceController2:call("checkDynamicResource", "commercial_face") == false then return false end
    return self:canCloseAllView()
end

--入口引导
function CommercialController:checkGuide()
    local function start()
        self:startGuide()
    end
    DataController.TimeEventController:addTimeListener({
        key = "commercialStartGuide",
        time = getTimeStamp() + 3,
        _callBack = start,
    })
end

function CommercialController:startGuide()
    if self:checkGuideLockRes() == false then return end
    if isCrossServerNow() then return end
    if FunBuildController:call("getMainCityLv") < self.openLevel then return end
    if self:isActivityOpen() == false then return end
    if not FunBuildController:call("IsHaveRecordeByKey", "commercial_start") then 
        if SceneController:call("getCurrentSceneId") ~= SCENE_ID_MAIN then 
            SceneController:call("gotoScene", SCENE_ID_MAIN)
        end

        PopupViewController:call("removeAllPopupView")
        GuideController:call("setGuide", "41726001")
    end
end

--提示继续押镖
function CommercialController:noticeContinue()
    if self:checkGuideLockRes() == false then return end

    PopupViewController:call("removeAllPopupView")

    if not FunBuildController:call("IsHaveRecordeByKey", "commercial_refresh") then
        self:showPopView(1)
        GuideController:call("setGuide", "41726008")
    else
        require("game.CommonPopup.LuaNpcTalkView")
        local view = LuaNpcTalkView.create({getLang("41576050")})
        if view == nil then
            return
        end
        local callback = function( ) self:showPopView() end
        view:setButtonCallBack(callback)
        view:setButtonTitle(getLang("9400546"))
        PopupViewController:addPopupView(view)
    end
end

function CommercialController:startEscort(data)
    if data.configId then
        local tip = CCCommonUtilsForLua:call("getPropByIdGroup", "bodyguard_level",  data.configId, "tip")
        local bonus = CCCommonUtilsForLua:call("getPropByIdGroup", "bodyguard_level",  data.configId, "extra_bonus")
        CCCommonUtilsForLua:call("flyHint", "", "", getLang(tip, tostring(atoi(bonus) * 100)))
    end

    if self:checkGuideLockRes() == false then return end
    if not FunBuildController:call("IsHaveRecordeByKey", "commercial_startEscort") then
        PopupViewController:call("removeAllPopupView")

        self:showPopView(1)
        GuideController:call("setGuide", "41726006")
        FunBuildController:call("SendRecordeToServer", "commercial_startEscort")
    end
end

function CommercialController:jumpGuide()
    if self:checkGuideLockRes() == false then return end
    if not FunBuildController:call("IsHaveRecordeByKey", "commercial_jump") then
        GuideController:call("setGuide", "41726010")
        FunBuildController:call("SendRecordeToServer", "commercial_jump")
    end
end

--商业之神
function CommercialController:getRank()
    require("game.commercialDarts.CommercialCommands"):getRank()
end

function CommercialController:getReward(rwdIdx)
    require("game.commercialDarts.CommercialCommands"):getReward(rwdIdx)
end

function CommercialController:getRankIcon()
    return { iconName = "game.commercialDarts.rank.CommercialRankIcon", iconType = 6, order = 2 }
end

function CommercialController:checkRankIcon()
    if self:checkGuideLockRes() == false then return false end
    if CCCommonUtilsForLua:isFunOpenByKey("bodyguard_rank") == false then return false end

    local actObj = ActivityController:call("getActObj", "57528") 
    if actObj then
        local now = getWorldTime()
        local startTime = actObj:getProperty("startTime")
        local endTime = actObj:getProperty("endTime")
        if startTime < now and now < endTime then
            self:tryCreateRankIcon()
        end
    end
end

function CommercialController:tryCreateRankIcon()
    UiCompoentControoller.getIconEvent():emit({icon_cfg = self:getRankIcon(), eventType = "create"})
end

function CommercialController:tryDestroyRankIcon()
    UiCompoentControoller.getIconEvent():emit({icon_cfg = self:getRankIcon(), eventType = "destroy"})
end

--押镖英雄相关
function CommercialController:noticeEnemyEscort(data)
    local uid = GlobalData:call("getPlayerInfo"):getProperty("uid")
    local now = getTimeStamp()
    local cd = CCUserDefault:sharedUserDefault():getIntegerForKey("CommercialEnemyTip" .. uid, 0)
    
    if now < cd then return end

    local tipView = Drequire("game.commercialDarts.CommercialEnemyTipView").new(data)
    if PopupViewController:call("getCurrViewCount") > 0 then
        PopupViewController:call("pushPop", tipView, true)
    else
        PopupViewController:addPopupView(tipView)
    end
end

function CommercialController:purge()
    self:unSchedule()
    self.marchInfos = {}
    unregisterScriptObserver(self, "BASEQUEUE_UI")
    unregisterScriptObserver(self, "COMMERCIAL_RECEIVE")
    unregisterScriptObserver(self, "COMMERCIAL_ATTACK")
    unregisterScriptObserver(self, "COMMERCIAL_ASSIST")
    unregisterScriptObserver(self, "COMMERCIAL_ACCELERATE")
    unregisterScriptObserver(self, "COMMERCIAL_PURGE")
    unregisterScriptObserver(self, "COMMERCIAL_CLEAR")
    unregisterScriptObserver(self, "COMMERCIAL_CLICKMAP")
    unregisterScriptObserver(self, "COMMERCIAL_MINIMAP")
    unregisterScriptObserver(self, "COMMERCIAL_ROAD")
    unregisterScriptObserver(self, "COMMERCIAL_MORALE")
    _CommercialInstance = nil
end

return CommercialController