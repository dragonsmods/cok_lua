local CamelAddUnders = class("CamelAddUnders", cc.Layer)

local playAniThreshold = 6000 --毫秒
local perHp2Seconds = 5 --5秒扣血

function CamelAddUnders:ctor(cityInfo, luaMap)
    self.cityInfo = cityInfo
    self.luaMap = luaMap
    self.hide = true

    local function finish()
        CCLoadSprite:call("loadDynamicResourceByName", "commercial_face")	
		local frame = cc.SpriteFrameCache:getInstance():getSpriteFrame("camel_occupy.png")
        if frame then
            local occupySp = cc.Sprite:createWithSpriteFrame(frame)
            occupySp:setPositionY(30)
            self:addChild(occupySp)
        else
            local json = "Spine/World/rm.json"
            local atlas = "World/World_3.atlas"
            self.animationObj = IFSkeletonAnimation:call("create", json, atlas)
            if self.animationObj then 
                self.animationObj:setToSetupPose()
                self.animationObj:setAnimation(0, "dj", true)
                self:addChild(self.animationObj)
            end
        end
        
        local protectTime = CCCommonUtilsForLua:call("getPropByIdGroup","data_config","commercial","k4")
        perHp2Seconds = tonumber(protectTime) or perHp2Seconds

        self.hide = false
    end

    local json = "lianmengzhanzheng.json"
    local atlas = "sk_lianmengzhanzheng.atlas"
    local animationName = "animation"
    local rootPath = CCFileUtils:sharedFileUtils():getWritablePath() .. "dresource/"
    local jsonFile = rootPath .. json
    local atlasFile = rootPath .. atlas

    --判断是否播放攻击动画
    local now = WorldController:call("getTime")
    local playAni = math.abs(now - atoi(luaMap.startTime)) < playAniThreshold
    if playAni and cc.FileUtils:getInstance():isFileExist(jsonFile) and cc.FileUtils:getInstance():isFileExist(atlasFile) then
        local animationObj = IFSkeletonAnimation:call("create", jsonFile, atlasFile)
        if animationObj then
            animationObj:setToSetupPose()
            animationObj:setAnimation(0, animationName, false)
            animationObj:setPosition(0, 38)
            self:addChild(animationObj)

            local function eventCb(event)
                animationObj:removeFromParent()
                finish()
            end
            animationObj:registerSpineEventHandler(eventCb, spEventType.SP_ANIMATION_COMPLETE)
        else
            finish()
        end
    else
        finish()
    end

    self.ctrl = require("game.commercialDarts.CommercialController").getInstance()
    local data = self.ctrl:getMarchInfo(self.luaMap.caravanUuid)
    self.ownerName = data.ownerInfo.name
    if data.ownerInfo.abbr and data.ownerInfo.abbr  ~= "" then
        self.ownerName = string.join("", "(", data.ownerInfo.abbr, ") ", self.ownerName)
    end

    self:createHp()
    
    registerNodeEventHandler(self)
end

function CamelAddUnders:createHp()
    self.hpNode = cc.Node:create()
    self.hpNode:setScale(0.8)
    self.hpNode:setVisible(false)
    
    local hpbg = CCLoadSprite:createSprite("hp_bg_icon.png")
    self.hpNode:addChild(hpbg)

    self.hp = CCLoadSprite:createSprite("hp_icon.png")
    self.hp:setAnchorPoint(ccp(0, 0.5))
    self.hp:setPositionX(-114)
    self.hpNode:addChild(self.hp)

    self.hpLabel = cc.Label:createWithSystemFont("", "Helvetica", 18, cc.size(0.0,0))
    self.hpNode:addChild(self.hpLabel)

    local labelBatch = WorldMapView:call("getUnBatchLabelNode")
    if labelBatch then
        labelBatch:addChild(self.hpNode)
        local pos = self.cityInfo:call("GetPositionInMap") 
        self.hpNode:setPosition(pos.x, pos.y - 18)
    end

    self.dtTime = perHp2Seconds
end

function CamelAddUnders:onEnterFrame(dt)
    if not self.hpNode then return end
    if self.hide then return end
    
    local data = self.ctrl:getMarchInfo(self.luaMap.caravanUuid)
    if data and data.obtainInfo then
        self.hpNode:setVisible(true)
        self.dtTime = self.dtTime + dt
        if self.dtTime >= perHp2Seconds then
            local now = WorldController:call("getTime")
            local startTime = atoi(data.obtainStartTime)
            local endTime = atoi(data.obtainEndTime)
            local totoalTime = atoi(data.obtainNeedTime)
            local remainTime = endTime - now
            remainTime = math.max(remainTime, 0)
            local percent = remainTime / totoalTime
            percent = math.min(percent, 1)
            percent = math.max(percent, 0)
            self.hpLabel:setString(string.format("%d%%", math.ceil(percent * 100)))
            self.hp:setScaleX(percent)
            self.dtTime = 0
        end
    else
        self.hpNode:setVisible(false)
    end
end

function CamelAddUnders:onEnter()
    self:onEnterFrame(0)
    local function update(dt) self:onEnterFrame(dt) end
    self.entry = self:getScheduler():scheduleScriptFunc(update, 1, false)
end

function CamelAddUnders:onExit()
    self:getScheduler():unscheduleScriptEntry(self.entry)
end

function addCamelAddUnders( index )
	local world = WorldMapView:call("instance")
    if nil == world then
        return nil
    end
    local cityInfo = WorldController:call("getCityInfoByIndex", index)
    if nil == cityInfo then
        return nil
    end
    if cityInfo:getProperty("luaType") ~= WorldCityType.commercial_camel then
        return nil
    end
    local luaMap = cityInfo:call("getLuaMap")
    --dump(luaMap, "CamelAddUnders")
    local pos = cityInfo:call("GetPositionInMap")
    local ret = CCArray:create()
    local under = CamelAddUnders.new(cityInfo, luaMap)
    under:setTag(index)
    under:setPosition(cc.p(pos.x, pos.y))
    ret:addObject(under)
    ret:addObject(under.hpNode)
    world:call("getCityBatchNode"):addChild(under, index)

    -- 添加文本
    local labelBatch = WorldMapView:call("getUnBatchLabelNode")
    if labelBatch then
        local nameBgPic = "name_bg.png"
        local nameBg = CCLoadSprite:call("createSprite", nameBgPic)
        nameBg:setPosition(pos.x, pos.y - 50)
        nameBg:setScaleX(1)
        labelBatch:addChild(nameBg)
        ret:addObject(nameBg)

        local nameStr = getLang("41576041", under.ownerName)
        local nameLabel = cc.Label:createWithSystemFont(nameStr, "Helvetica", 18, cc.size(0.0,0))
        nameLabel:setColor(cc.c3b(242, 237, 222))
        nameLabel:setAnchorPoint(cc.p(0.5, 0.5))
        labelBatch:addChild(nameLabel, index)
        nameLabel:setPosition(pos.x, pos.y - 50)
        ret:addObject(nameLabel)
    end

    return ret
end

return CamelAddUnders