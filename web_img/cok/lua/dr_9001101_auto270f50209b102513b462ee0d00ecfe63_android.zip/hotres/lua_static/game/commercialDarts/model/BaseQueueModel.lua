local BaseQueueModel = class("BaseQueueModel")

local winSize = cc.Director:getInstance():getWinSize()
local halfWinSize = cc.size(winSize.width / 2, winSize.height / 2)

local AngleConst = 180 / math.pi
--动画方向误差角度
local AniAngle = 22.5

local BaseQueueType = 
{
    --护卫
    Escort = 1,
    --攻击
    Attack = 2,
    --接镖
    Receive = 3,
    --侦查
    Scout = 4,
    --返回
    Back = 5,
    --镖车
    Darts = 168,
}

function BaseQueueModel:ctor()
    --开始时间
    self.startTime = 0
    --达到时间
    self.endTime = 0
    --起点(贝塞尔控制点p0)
    self.startPoint = {}
    --控制点(贝塞尔控制点p1)
    self.caravanPoint = {} 
    --终点(贝塞尔控制点p2)
    self.endPoint = {}
    -- 队列uuid
    self.uuid = ""
    -- 拥有者uid
    self.ownerId = ""
    -- 行军tag(地图用)
    self.marchTag = 0
    -- 队列Id(队列用)
    self.marchQid = 0
    -- 队列所属者
    self.onwerInfo = {}
    -- 队列占领者
    self.obtainInfo = nil
    -- 队列状态
    self.marchType = 0
    -- 护卫队伍uuid
    self.escortUuid = ""
    -- 镖车配置id
    self.configId = ""
    -- 镖车奖励id
    self.rewardId = ""
    -- 镖车状态
    self.state = 0
    -- 队列持有类型
    self.ownerType = PlayerType.PlayerNone
    -- 特殊状态开始时间
    self.obtainStartTime = 0
    -- 特殊状态结束时间
    self.obtainEndTime = 0
    -- 特殊状态关联的点
    self.tmpPointId = 0
    -- 攻击目标镖车uuid
    self.targetUuid = ""
    -- 攻击城堡皮肤
    self.attSkin = 0
    -- 行军皮肤
    self.marchSkin = 0
    -- 行军方阵相关
    self.marchArmy = {}
    -- 英雄
    self.marchDragon = {}
    -- 龙
    self.marchHero = {}
end

--override me
function BaseQueueModel:parse(data)
    
end

--override me
function BaseQueueModel:update(now, dt, followMarchId)
    
end

function BaseQueueModel:setDarts()
    self.marchType = BaseQueueType.Darts
end

function BaseQueueModel:setOwnerType(mineUid, selfAllianceId)
    if self.ownerInfo.uid == mineUid then
        self.ownerType = PlayerType.PlayerSelf
        self:notifyCDView()
    --抢了别人的镖车 嘿嘿
    elseif self.obtainInfo and self.obtainInfo.uid == mineUid then
        self.ownerType = PlayerType.PlayerSelf
        self:notifyCDView()
    elseif selfAllianceId ~= "" and self.ownerInfo.allianceId == selfAllianceId then
        self.ownerType = PlayerType.PlayerAlliance
    else
        local beforeOwnerType = self.ownerType
        self.ownerType = PlayerType.PlayerOther
        if beforeOwnerType == PlayerType.PlayerSelf then return self.marchQid end
    end
end

function BaseQueueModel:createMarchNode()
    -- local marchNode = CCLoadSprite:call("createSprite", "")
    -- marchNode:setTextureRect(cc.rect(0, 0, 0, 0))
    -- local direction = -45
    -- local tmpName = string.format("ZC_shadow_%d_0.png", direction)
    -- local body = CCLoadSprite:call("createSprite", tmpName)
    -- local cloth = CCLoadSprite:call("createSprite", tmpName)
    -- local shadow = CCLoadSprite:call("createSprite", tmpName)

    -- local function createFrameAni(format, direction, frameCount)
    --     local frameTable = {}
    --     for index = 0, frameCount - 1 do
    --         local frameName = string.format(format, direction, index)
    --         table.insert(frameTable, CCLoadSprite:loadResource(frameName))
    --     end
    --     local delay = 1.0 / frameCount
    --     local frameAnimation = cc.Animation:createWithSpriteFrames(frameTable, delay)
	-- 	local frameAnimate = cc.Animate:create(frameAnimation)
    --     local frameRepeat = cc.RepeatForever:create(frameAnimate)
    --     return frameRepeat
    -- end

    -- local bodyAni = createFrameAni("JY_body_%d_%d.png", direction, 8)
    -- local clothAni = createFrameAni("JY_yifu_%d_%d.png", direction, 8)
    -- body:runAction(bodyAni)
    -- cloth:runAction(clothAni)
    -- marchNode:addChild(body)
    -- marchNode:addChild(cloth)
    -- marchNode:addChild(shadow, -1)
    -- marchNode:setTag(self.marchTag)

    -- local marchNode = WorldMapView:call("getMapMarchNode")
    -- if marchNode then
    --     marchNode:addChild(marchNode)
    -- end
    local marchNode
    if self.marchSkin > 0 or self.attSkin > 0 then
        local direction = self:getDirection()
        marchNode = IFAvatarMarchSkNode:call("createForLua", self.marchSkin, self.attSkin, direction)
        WorldMapView:call("addAvatarMarchNodeToBatch", marchNode)
    end

    if not marchNode then
        local info = 
        {
            uuid = self.uuid,
            sp = tostring(WorldController:call("getIndexByPoint", ccp(math.floor(self.startPoint.x), math.floor(self.startPoint.y)))),
            dp = tostring(WorldController:call("getIndexByPoint", ccp(math.floor(self.endPoint.x), math.floor(self.endPoint.y)))),
            st = tostring(self.startTime),
            et = tostring(self.endTime),
            marchTag = tostring(self.marchTag),
            army = self.marchArmy,
            dragonList = self.marchDragon,
            generalList = self.marchHero,
        }

        marchNode = WorldMapView:call("createMarchArmyByFakeInfo", luaToDict(info))
    end
    marchNode:setTag(self.marchTag)
    return marchNode
end

local function getAngleByPos(p1,p2)
    local x = p2.x - p1.x
    local y = p2.y - p1.y
    return math.atan2(y, x) * AngleConst
end

function BaseQueueModel:getDirection()
    local angle = getAngleByPos(self.endPointMap, self.startPointMap)
    angle = angle + 360
    angle = angle % 360

    local direction = 0
    if (angle >= 360 - AniAngle and angle <= 360)
        or (angle >= 0 and angle <= AniAngle) then
        direction = 0
    elseif angle > AniAngle and angle <= 90 - AniAngle then
        direction = 1
    elseif angle > 90 - AniAngle and angle <= 90 + AniAngle then
        direction = 2
    elseif angle > 90 + AniAngle and angle <= 180 - AniAngle then
        direction = 3
    elseif angle > 180 - AniAngle and angle <= 180 + AniAngle then
        direction = 4
    elseif angle > 180 + AniAngle and angle <= 270 - AniAngle then
        direction = 5
    elseif angle > 270 - AniAngle and angle <= 270 + AniAngle then
        direction = 6
    elseif angle > 270 + AniAngle and angle <= 360 - AniAngle then
        direction = 7
    end

    return direction
end

function BaseQueueModel:createMarchLine()
    local distance = ccpDistance(self.startPointMap, self.endPointMap)
    local totalTime = (self.endTime - self.startTime) / 1000
    local speed = distance / totalTime

    local src = self.startPointMap
    local dst = self.endPointMap

    local marchLine = CCLineBatchedSprite:call("createForLua", "foot64.png", src, dst, 40, speed)
    if self.ownerType == PlayerType.PlayerOther then
        marchLine:setColor(cc.c3b(255, 255, 255))
    else
        marchLine:setColor(cc.c3b(0, 255, 0))
    end
    marchLine:setTag(self.marchTag)
    WorldMapView:call("addMarchLine", marchLine)

    return marchLine
end

function BaseQueueModel:checkOverTime(dt)
    local now = WorldController:call("getTime")
    local endTime = self.endTime
    if self.obtainInfo then
        endTime = self.obtainEndTime
    end
    if endTime < now then
        self:clearMarch()

        if self.ownerType == PlayerType.PlayerSelf then
            if self:isBack() then
                CCCommonUtilsForLua:call("flyHint", "march_icon.png", getLang("136002"), getLang("136003", self.ownerInfo.name), 2, 0, true)
            end
            return self.uuid, self.marchQid
        end

        return self.uuid
    end
end

function BaseQueueModel:notifyCDView()
    local notifier = CCDictionary:create()
    notifier:setObject(CCString:create(self.uuid), "uuid")
    notifier:setObject(CCString:create(tostring(self.endTime)), "endTime")
    CCSafeNotificationCenter:postNotification("COMMERCIAL_UPDATETIME", notifier)
end

function BaseQueueModel:jumpToTarget(marchNode)
    local x, y = marchNode:getPosition()
    local mapNode = WorldController:call("getMapNode")
    if mapNode then
        local scaleX = mapNode:getScaleX()
        local scaleY = mapNode:getScaleY()
        local finalX = halfWinSize.width - x * scaleX
        local finalY = halfWinSize.height - y * scaleY
        WorldController:call("setMapPos", ccp(finalX, finalY))
    end
end

function BaseQueueModel:getMarchNodePos()
    local marchNode = WorldMapView:call("getMarchNodeByTag", self.marchTag)
    if marchNode then
        return marchNode:getPosition()
    end
end

--是否正在返回
function BaseQueueModel:isBack()
    return self.marchType == BaseQueueType.Back
end

--是否是镖车
function BaseQueueModel:isDarts()
    return self.marchType == BaseQueueType.Darts
end

--是否是接镖
function BaseQueueModel:isReceive()
    return self.marchType == BaseQueueType.Receive
end

--镖车是否有护卫
function BaseQueueModel:haveEscortArmy()
    return self.escortUuid ~= ""
end

function BaseQueueModel:isClickOnSelf(pt)
    local marchNode = WorldMapView:call("getMarchNodeByTag", self.marchTag)
    if marchNode and marchNode:getParent() then
        local x, y = marchNode:getPosition()
        local size = cc.size(120, 120)
        local np = ccp(x - 60, y - 60)
        local p2 = marchNode:getParent():convertToWorldSpace(np)
        local bBox = cc.rect(p2.x, p2.y, size.width, size.height)
        if cc.rectContainsPoint(bBox, pt) then
            return true
        end
    end
end

function BaseQueueModel:clearMarch()
    local world = WorldMapView:call("instance")
    if not world then return end
    
    local drawRoadNode = world:call("getDrawRoadNode")
    if drawRoadNode then
        drawRoadNode:removeChildByTag(self.marchTag)
    end

    local marchNode = world:call("getMapMarchNode")
    if marchNode then
        marchNode:removeChildByTag(self.marchTag)
    end

    world:call("eraseAvatarMarchNode", self.marchTag)

    local marchInfo = WorldController:call("getWorldMarchInfoByUuid", self.uuid)
    if marchInfo then
        marchInfo:setProperty("stateType", MarchStateType.StateReturn)
        marchInfo:setProperty("endStamp", 0)
    end

    world:call("removeMarchArmy", self.marchTag)
end

return BaseQueueModel