local MineServerNode = class("MineServerNode", cc.Node)

function MineServerNode:create(size)
    local node = MineServerNode.new(size)
    if node:initNode() then return node end
end

function MineServerNode:ctor(size)
    self.size = size
end

function MineServerNode:initNode()
    local config = {
        name = "escort_user",
        id = "35366015",
    }

    local rankView = Drequire("game.CommonPopup.commonRank.CommonRankView"):createWithConfigId(
                config.id, config.name, self.size
            )
 
    self:removeAllChildren() 
    self:addChild(rankView)
    self:setContentSize(self.size)

    return true
end

return MineServerNode