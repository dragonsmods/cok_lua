local StationAddUnders = class("StationAddUnders", cc.Layer)

function StationAddUnders:ctor(cityInfo,luaMap )
    CCLoadSprite:call("loadDynamicResourceByName", "commercial_face")	
    local frame = cc.SpriteFrameCache:getInstance():getSpriteFrame("camel_station_tile.png")
    if frame then
        local icon = cc.Sprite:createWithSpriteFrame(frame)
        icon:setPositionY(150)
        self:addChild(icon)
    else
        local icon = CCLoadSprite:call("createSprite", "1800.png")
        icon:setPositionY(100)
        self:addChild(icon)
    end
end

function addStationAddUnders( index )
	local world = WorldMapView:call("instance")
    if nil == world then
        return nil
    end
    local cityInfo = WorldController:call("getCityInfoByIndex", index)
    if nil == cityInfo then
        return nil
    end
    if cityInfo:getProperty("luaType") ~= WorldCityType.station then
        return nil
    end
    local luaMap = cityInfo:call("getLuaMap")
    -- dump(luaMap, "addStationAddUnders")
    local pos = cityInfo:call("GetPositionInMap")
    local ret = CCArray:create()
    local under = StationAddUnders.new(cityInfo,luaMap )
    under:setTag(index)
    under:setPosition(cc.p(pos.x, pos.y))
    ret:addObject(under)
    world:call("getCityBatchNode"):addChild(under, index)

    -- 添加文本
    local labelBatch = WorldMapView:call("getUnBatchLabelNode")
    if labelBatch then
        local nameBgPic = "name_bg.png"
        local nameBg = CCLoadSprite:call("createSprite", nameBgPic)
        nameBg:setPosition(cc.p(0, -50))
        nameBg:setScaleX(1.2)
        under:addChild(nameBg)

        local index = atoi(luaMap.index)
        local name = getLang(StationName[index])
        -- local nameStr = getLang("650179", luaMap.htname)
        local nameLabel = cc.Label:createWithSystemFont(name, "Helvetica", 18, cc.size(0.0,0))
        nameLabel:setColor(cc.c3b(242, 237, 222))
        nameLabel:setAnchorPoint(cc.p(0.5, 0.5))
        labelBatch:addChild(nameLabel, index)
        nameLabel:setPosition(pos.x, pos.y - 50)
        ret:addObject(nameLabel)
    end

    return ret
end

return StationAddUnders