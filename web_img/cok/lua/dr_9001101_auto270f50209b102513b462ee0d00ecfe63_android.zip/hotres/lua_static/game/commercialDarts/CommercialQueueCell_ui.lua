----------------------------
-- Author: Elex
-- Date: 2019-12-17 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CommercialQueueCell_ui = class("CommercialQueueCell_ui")

--#ui propertys


--#function
function CommercialQueueCell_ui:create(owner, viewType, paramTable)
	local ret = CommercialQueueCell_ui.new()
	CustomUtility:DoRes(6, true)
	CustomUtility:LoadUi("CommercialQueueCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CommercialQueueCell_ui:initLang()
end

function CommercialQueueCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CommercialQueueCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CommercialQueueCell_ui:onCDClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onCDClick", pSender, event)
end

return CommercialQueueCell_ui

