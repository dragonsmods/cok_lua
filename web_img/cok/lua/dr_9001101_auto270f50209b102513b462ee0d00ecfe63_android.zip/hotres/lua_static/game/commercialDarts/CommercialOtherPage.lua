local CommercialOtherPage = class("CommercialOtherPage", cc.Layer)

local FilterType = 
{
    --全部
    All = 1,
    --仇人
    Enemy = 2,
    --盟友
    Ally = 3,
    --等级I
    Type1 = 4,
    --等级II
    Type2 = 5,
    --等级III
    Type3 = 6,
    --等级IV
    Type4 = 7,
    -- --等级V
    -- Type5 = 8,
}

local FilterDialog =
{
    --全部
    "41576027",
    --仇人
    "41576028",
    --盟友
    "681387",
    --行脚商人
    "41576009",
    --一般商旅
    "41576010",
    --普通商旅
    "41576011",
    --高级商旅
    "41576012",
    -- --豪商巨贾
    -- "41576013",
}

--品质优先(等级 > 颜色)
local function sortByQuality(c1, c2)
    if c1 and c2 then
        local _type1 = CCCommonUtilsForLua:call("getPropByIdGroup", "bodyguard_level", c1.configId, "type")
        local _type2 = CCCommonUtilsForLua:call("getPropByIdGroup", "bodyguard_level", c2.configId, "type")
        if _type1 == _type2 then
            local color1 = CCCommonUtilsForLua:call("getPropByIdGroup", "bodyguard_level", c1.configId, "color")
            local color2 = CCCommonUtilsForLua:call("getPropByIdGroup", "bodyguard_level", c2.configId, "color")
            return color2 < color1
        else
            return _type1 < _type2
        end
    else
        return false
    end
end

--仇人优先(仇人 > 盟友 > 品质)
local function sortByRelation(c1, c2)
    local playerInfo = GlobalData:call("getPlayerInfo")
    local selfAllianceId = playerInfo:call("getAllianceId")

    if c1 and c2 then
        local isEnemy1 = c1.enemy
        local isEnemy2 = c1.enemy
        if isEnemy1 == isEnemy2 then
            local isAlly1 = (selfAllianceId ~= "" and selfAllianceId == c1.allianceId) and 1 or 0
            local isAlly2 = (selfAllianceId ~= "" and selfAllianceId == c2.allianceId) and 1 or 0 
            if isAlly1 == isAlly2 then
                return sortByQuality(c1, c2)
            else
                return isAlly2 < isAlly1
            end
        else
            return isEnemy2 < isEnemy1
        end
    else
        return false
    end
end

function CommercialOtherPage:create(parentSize)
    local page = CommercialOtherPage.new()
    Drequire("game.commercialDarts.CommercialOtherPage_ui"):create(page, 0, parentSize)
    if page:initPage() then return page end
end

function CommercialOtherPage:ctor()
    self.filter = FilterType.All
    self.showData = {}
    self.ctrl = require("game.commercialDarts.CommercialController").getInstance()
end

function CommercialOtherPage:initPage()
    registerTouchHandler(self)
    self:setSwallowsTouches(false)

    local filterDialog = FilterDialog[self.filter]
    self.ui.m_checkText:setString(getLang(filterDialog))

    for index, dialog in ipairs(FilterDialog) do
        if self.ui["m_boxText" .. index] then
            self.ui["m_boxText" .. index]:setString(getLang(dialog))
        end
    end

    self.ctrl:reqOtherData()

    return true
end

function CommercialOtherPage:refreshPage(dict)
    local data = dictToLuaTable(dict)
    
    self.othersData = data.others or {}
    self.path = data.path
    self.scout = data.scout
    self:refreshText()
    self:refreshList()
    self:checkGuide()
end 

function CommercialOtherPage:refreshText()
    local path = self.ctrl:getPath(atoi(self.path))
    self.ui.m_text2:setString(getLang("41576024") .. path)

    local scout = splitString(self.scout, ";")
    local scoutStr = table.concat(scout, ",")
    if not scoutStr then scoutStr = "" end
    if scoutStr == "nil" then scoutStr = "" end
    self.ui.m_text3:setString(getLang("41576025") .. scoutStr)
end

function CommercialOtherPage:refreshList()
    self.ui.m_checkBoxNode:setVisible(false)

    local filterDialog = FilterDialog[self.filter]
    self.ui.m_checkText:setString(getLang(filterDialog))
    self.ui.m_checkText:setVisible(true)
    self.ui.m_checkSp:setVisible(true)
    
    self:generateData()
    self.ui:setTableViewDataSource("m_listView", self.showData or {})
end

function CommercialOtherPage:generateData()
    if self.filter == FilterType.All then
        self.showData = clone(self.othersData)
        table.sort(self.showData, sortByRelation)
    elseif self.filter == FilterType.Enemy then
        self.showData = self:getEnemyData()
        table.sort(self.showData, sortByQuality)
    elseif self.filter == FilterType.Ally then
        self.showData = self:getAllyData()
        table.sort(self.showData, sortByQuality)
    elseif self.filter == FilterType.Type1 then
        self.showData = self:getLvData(1)
        table.sort(self.showData, sortByQuality)
    elseif self.filter == FilterType.Type2 then
        self.showData = self:getLvData(2)
        table.sort(self.showData, sortByQuality)
    elseif self.filter == FilterType.Type3 then
        self.showData = self:getLvData(3)
        table.sort(self.showData, sortByQuality)
    elseif self.filter == FilterType.Type4 then
        self.showData = self:getLvData(4)
        table.sort(self.showData, sortByQuality)
    elseif self.filter == FilterType.Type5 then
        self.showData = self:getLvData(5)
        table.sort(self.showData, sortByQuality)
    else
        self.showData = clone(self.othersData)
        table.sort(self.showData, sortByRelation)
    end
end

function CommercialOtherPage:getEnemyData()
    local showData = {}
    for _, data in ipairs(self.othersData) do
        if data.enemy == "1" then
            table.insert(showData, data)
        end
    end

    return showData
end

function CommercialOtherPage:getAllyData()
    local showData = {}

    local playerInfo = GlobalData:call("getPlayerInfo")
    local selfAllianceId = playerInfo:call("getAllianceId")

    for _, data in ipairs(self.othersData) do
        if selfAllianceId ~= "" and selfAllianceId == data.allianceId then
            table.insert(showData, data)
        end
    end

    return showData
end

function CommercialOtherPage:getLvData(speType)
    local showData = {}
    for _, data in ipairs(self.othersData) do
        local _type = CCCommonUtilsForLua:call("getPropByIdGroup", "bodyguard_level", data.configId, "type")
        if atoi(_type) == atoi(speType) then
            table.insert(showData, data)
        end
    end

    return showData
end

function CommercialOtherPage:onEnterFrame(dt)
    local actObj = ActivityController:call("getActObj", "57473")
    if actObj then
        local tickStr = actObj:call("getGameTickStr")
        self.ui.m_text1:setString(tickStr)
    else
        self.ui.m_text1:setVisible(false)
    end
end

function CommercialOtherPage:onEnter()
    self:onEnterFrame(0)
    local function update(dt) self:onEnterFrame(dt) end
    self.entry = self:getScheduler():scheduleScriptFunc(update, 1, false)
    registerScriptObserver(self, self.refreshPage, "COMMERCIAL_OTHER_PAGE")
end

function CommercialOtherPage:onExit()
    self:getScheduler():unscheduleScriptEntry(self.entry)
    unregisterScriptObserver(self, "COMMERCIAL_OTHER_PAGE")
end

function CommercialOtherPage:onTouchBegan(x, y)

    return true
end

function CommercialOtherPage:onTouchEnded(x, y)
    self.ui.m_checkText:setVisible(true)
    self.ui.m_checkSp:setVisible(true)
    self.ui.m_checkBoxNode:setVisible(false)
end

function CommercialOtherPage:onClickInfo()
    local view = Drequire("game.FestivalActivities.FestivalActivitiesExplainView"):create(getLang("41576058"))
    PopupViewController:call("addPopupView", view)
end

function CommercialOtherPage:onClickCheckBox()
    self.ui.m_checkText:setVisible(false)
    self.ui.m_checkSp:setVisible(false)
    self.ui.m_checkBoxNode:setVisible(true)
end

function CommercialOtherPage:onClickFilter1()
    self.filter = FilterType.All
    self:refreshList()
end

function CommercialOtherPage:onClickFilter2()
    self.filter = FilterType.Enemy
    self:refreshList()
end

function CommercialOtherPage:onClickFilter3()
    self.filter = FilterType.Ally
    self:refreshList()
end

function CommercialOtherPage:onClickFilter4()
    self.filter = FilterType.Type1
    self:refreshList()
end

function CommercialOtherPage:onClickFilter5()
    self.filter = FilterType.Type2
    self:refreshList()
end

function CommercialOtherPage:onClickFilter6()
    self.filter = FilterType.Type3
    self:refreshList()
end

function CommercialOtherPage:onClickFilter7()
    self.filter = FilterType.Type4
    self:refreshList()
end

function CommercialOtherPage:getGuideNode(key)
    if key == "commercial_jump" then
        local cell = self.ui.m_listView:cellAtIndex(0)
        if cell then
            return cell:getGuideNode()
        end
    end
end

function CommercialOtherPage:checkGuide()
    if #self.showData > 0 then self.ctrl:jumpGuide() end
end

function CommercialOtherPage:onClickRefresh()
    self.ctrl:reqOtherData()

    local cdTime = 5
    self.ui.m_refreshBtn:setEnabled(false)
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_refreshBtn, tostring(cdTime))

    local delay = cc.DelayTime:create(1)
    local function reset()
        cdTime = cdTime - 1
        if cdTime == 0 then
            self.ui.m_refreshBtn:setEnabled(true)
            self.ui.m_refreshBtn:stopAllActions()
            CCCommonUtilsForLua:setButtonTitle(self.ui.m_refreshBtn, getLang("41576215"))
        else
            self.ui.m_refreshBtn:setEnabled(false)
            CCCommonUtilsForLua:setButtonTitle(self.ui.m_refreshBtn, tostring(cdTime))
        end
    end
    local callFunc = cc.CallFunc:create(reset)
    local seq = cc.Sequence:create(delay, callFunc)
    local forever = cc.RepeatForever:create(seq)
    self.ui.m_refreshBtn:runAction(forever)
end

return CommercialOtherPage