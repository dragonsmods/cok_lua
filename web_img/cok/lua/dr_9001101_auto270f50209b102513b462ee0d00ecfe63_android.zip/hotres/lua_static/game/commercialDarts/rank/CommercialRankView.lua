local CommercialRankView = class("CommercialRankView", PopupBaseView)

function CommercialRankView:create()
    local view = CommercialRankView.new()
    Drequire("game.commercialDarts.rank.CommercialRankView_ui"):create(view, 1)
    if view:initView() then return view end
end

function CommercialRankView:initView()
    self:onClickPage1()
    return true
end

function CommercialRankView:onEnter()
    
end

function CommercialRankView:onExit()

end

function CommercialRankView:onClickPage1()
    self.ui.m_pageBtn1:setEnabled(false)
    self.ui.m_pageBtn2:setEnabled(true)
    self.ui.m_pageBtn3:setEnabled(true)

    if not self.mainNode then
        local size = self.ui.m_listNode:getContentSize()
        self.mainNode = Drequire("game.commercialDarts.rank.MainNode"):create(size)
        self.ui.m_listNode:addChild(self.mainNode)
    end

    if self.mainNode then self.mainNode:setVisible(true) end
    if self.allServerNode then self.allServerNode:setVisible(false) end
    if self.mineServerNode then self.mineServerNode:setVisible(false) end
end

function CommercialRankView:onClickPage2()
    self.ui.m_pageBtn1:setEnabled(true)
    self.ui.m_pageBtn2:setEnabled(false)
    self.ui.m_pageBtn3:setEnabled(true)

    if self.allServerNode then
        self.allServerNode:removeFromParent()
    end

    local size = self.ui.m_listNode:getContentSize()
    self.allServerNode = Drequire("game.commercialDarts.rank.AllServerNode"):create(size)
    self.ui.m_listNode:addChild(self.allServerNode)

    if self.mainNode then self.mainNode:setVisible(false) end
    if self.allServerNode then self.allServerNode:setVisible(true) end
    if self.mineServerNode then self.mineServerNode:setVisible(false) end
end

function CommercialRankView:onClickPage3()
    self.ui.m_pageBtn1:setEnabled(true)
    self.ui.m_pageBtn2:setEnabled(true)
    self.ui.m_pageBtn3:setEnabled(false)

    if self.mineServerNode then
        self.mineServerNode:removeFromParent()
    end
    local size = self.ui.m_listNode:getContentSize()
    self.mineServerNode = Drequire("game.commercialDarts.rank.MineServerNode"):create(size)
    self.ui.m_listNode:addChild(self.mineServerNode)

    if self.mainNode then self.mainNode:setVisible(false) end
    if self.allServerNode then self.allServerNode:setVisible(false) end
    if self.mineServerNode then self.mineServerNode:setVisible(true) end
end

function CommercialRankView:onClickTip()
    local view = Drequire("game.FestivalActivities.FestivalActivitiesExplainView"):create(getLang("41576297"))
    PopupViewController:addPopupView(view)
end

return CommercialRankView