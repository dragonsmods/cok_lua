local CommercialEnemyTipView = class("CommercialEnemyTipView", PopupBaseView)

function CommercialEnemyTipView:ctor(data)
    self.name = data.escortName
    self.uuid = data.uuid

    self.ctrl = require("game.commercialDarts.CommercialController").getInstance()
    Drequire("game.commercialDarts.CommercialEnemyTipView_ui"):create(self, 1)
    self:initView()
end

function CommercialEnemyTipView:initView()
    registerTouchHandler(self)
    self.ui.m_contentText:setString(getLang("5504316", self.name))
end

function CommercialEnemyTipView:onTouchBegan(x, y)
    if not isTouchInside(self.ui.m_bg, x, y) then
        self.touchPoint = ccp(x, y)
        return true
    end
end

function CommercialEnemyTipView:onTouchEnded(x, y)
    if ccpDistance(self.touchPoint, ccp(x, y)) > 10 then return end
    self:call("closeSelf")
end

function CommercialEnemyTipView:onClickSet()
    local isVisible = self.ui.m_selectSp:isVisible()
    local nowVisible = not visible
    self.ui.m_selectSp:setVisible(nowVisible)

    local uid = GlobalData:call("getPlayerInfo"):getProperty("uid")
    if nowVisible then
        local tomorrowTime = GlobalDataCtr.getTomorrowTime()
        CCUserDefault:sharedUserDefault():setIntegerForKey("CommercialEnemyTip" .. uid, tomorrowTime)
        CCUserDefault:sharedUserDefault():flush()
    else
        CCUserDefault:sharedUserDefault():setIntegerForKey("CommercialEnemyTip" .. uid, 0)
        CCUserDefault:sharedUserDefault():flush()
    end
end

function CommercialEnemyTipView:onClickBtn()
    self.ctrl:jumpCamel(self.uuid)
end

return CommercialEnemyTipView