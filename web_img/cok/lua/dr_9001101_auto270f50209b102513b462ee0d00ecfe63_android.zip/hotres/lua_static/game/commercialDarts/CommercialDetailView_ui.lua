----------------------------
-- Author: Elex
-- Date: 2020-11-11 Wednesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CommercialDetailView_ui = class("CommercialDetailView_ui")

--#ui propertys


--#function
function CommercialDetailView_ui:create(owner, viewType, paramTable)
	local ret = CommercialDetailView_ui.new()
	CustomUtility:LoadUi("CommercialDetailView.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CommercialDetailView_ui:initLang()
	LabelSmoker:setText(self.m_titleLabel, "41576037")
	LabelSmoker:setText(self.m_recoverTimeLabel, "650257")
	ButtonSmoker:setText(self.m_helpBtn, "5504336")
end

function CommercialDetailView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CommercialDetailView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CommercialDetailView_ui:onClickRefresh(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickRefresh", pSender, event)
end

function CommercialDetailView_ui:onClickHelp(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickHelp", pSender, event)
end

return CommercialDetailView_ui

