local CommercialOtherCell = class("CommercialOtherCell", cc.TableViewCell)

function CommercialOtherCell:create()
    local cell = CommercialOtherCell.new()
    Drequire("game.commercialDarts.CommercialOtherCell_ui"):create(cell, 0)
    return cell
end

function CommercialOtherCell:refreshCell(info, idx)
    self.info = info

    local headIcon = CCCommonUtilsForLua:call("makeUserHeadIcon", info.uid, info.pic, "", atoi(info.picVer), 80)
    self.ui.m_iconNode:removeAllChildren()
    self.ui.m_iconNode:addChild(headIcon)

    local name = info.name
    --敌人
    if info.enemy == "1" then
        name = info.name .. " (" .. getLang("41576028") .. ")"
    end
    --盟友
    local playerInfo = GlobalData:call("getPlayerInfo")
    local uid = playerInfo:getProperty("uid")
    local selfAllianceId = playerInfo:call("getAllianceId")
    if selfAllianceId ~= "" and selfAllianceId == info.allianceId then
        name = info.name .. " (" .. getLang("681387") .. ")"
    end
    --自己
    if uid == info.uid then
        name = info.name .. "(" .. getLang("150945") .. ")"
    end
    self.ui.m_text1:setString(name)

    if info.abbr ~= "" then
        self.ui.m_text2:setString(getLang("108596", info.abbr))
    else
        self.ui.m_text2:setString("")
    end
    
    local location = string.format("x%s y%s", info.point.x, info.point.y)
    self.ui.m_text4:setString(location)
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_goBtn, getLang("650158"))

    local desc = CCCommonUtilsForLua:call("getPropByIdGroup", "bodyguard_level", info.configId, "desc")
    local icon = CCCommonUtilsForLua:call("getPropByIdGroup", "bodyguard_level", info.configId, "icon")
    self.ui.m_text3:setString(getLang(desc))

    local sf = CCLoadSprite:call("loadResource", icon .. ".png")
    self.ui.m_flagSp:setSpriteFrame(sf)

    local color = CCCommonUtilsForLua:call("getPropByIdGroup", "bodyguard_level", info.configId, "color")
    local path = string.format("cmr_color_%d.png", atoi(color))
    local sf = CCLoadSprite:call("loadResource", path)
    self.ui.m_flagSp:setSpriteFrame(sf)

    local star = CCCommonUtilsForLua:call("getPropByIdGroup", "bodyguard_level", info.configId, "star")
    local starNode = getStarNode(atoi(star), SCROLLVIEW_DIR_VERTICAL)
    starNode:setAnchorPoint(ccp(0, 0))
    starNode:setScale(0.3)
    self.ui.m_starNode:removeAllChildren()
    self.ui.m_starNode:addChild(starNode)

    if info.hp then
        local hp = atoi(info.hp)
        self.ui.m_hpBar:setScaleX(hp)
        self.ui.m_hpTxt:setString(string.format("%d%%", math.floor(hp * 100)))
    else
        self.ui.m_hpBar:setScaleX(1)
        self.ui.m_hpTxt:setString(getLang("9200405"))
    end
end

function CommercialOtherCell:onClickGo()
    require("game.commercialDarts.CommercialController").getInstance():jumpCamel(self.info.uuid)
end

function CommercialOtherCell:getGuideNode()
    return self.ui.m_goBtn
end

return CommercialOtherCell