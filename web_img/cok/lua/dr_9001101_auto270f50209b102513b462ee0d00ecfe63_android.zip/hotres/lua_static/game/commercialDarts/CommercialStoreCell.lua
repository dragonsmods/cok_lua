-- @Author: yanwei
-- @Date:   2019-12-05 15:41:09
-- @Last Modified by:   yanwei
-- @Last Modified time: 2019-12-05 15:57:11
local CommercialStoreCell = class("CommercialStoreCell", Drequire("game.shop.ShopMallCell"))

function CommercialStoreCell:create()
    return CommercialStoreCell.new(nil, "CommercialStore_BuyConfirm")
end

return CommercialStoreCell