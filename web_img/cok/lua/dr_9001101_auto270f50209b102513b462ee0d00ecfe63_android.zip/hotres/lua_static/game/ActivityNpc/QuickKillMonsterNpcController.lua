--[[
    快速杀怪活动npc控制类
]]

local ALLIANCE_QUICKLY_KILLMONSTER_ACTIVITY = 57405

QuickKillMonsterNpcController = class("QuickKillMonsterNpcController")

local __instance = nil
function QuickKillMonsterNpcController.getInstance(  )
    if nil == __instance then
        __instance = QuickKillMonsterNpcController.new()
    end
    return __instance
end

function QuickKillMonsterNpcController:ctor()
    self.m_info = CityNpcController.getInstance():getNpcInfo(ALLIANCE_QUICKLY_KILLMONSTER_ACTIVITY)
end

function QuickKillMonsterNpcController:isOpen()
    return self.m_info:isOpen()
end

function QuickKillMonsterNpcController:fireEventRef()
    self.m_info:onEventClick()
end

function QuickKillMonsterNpcController:createBubble()
    -- 头顶气泡
    local actId = ALLIANCE_QUICKLY_KILLMONSTER_ACTIVITY
    local ctl = CityNpcController.getInstance():getNpcInfo(actId)

    local headbg = ctl:getRes() and ctl:getRes().headBg or "BG_zhuangbeikuang_bai.png"
    local leaderHeadNode = cc.Node:create()
    leaderHeadNode:setPosition(ccp(0,150))
    local leaderInfo = ctl:getLeaderInfo()

    local headNode = cc.Node:create()
    local headBG = CCLoadSprite:createSprite(headbg)
    local headBG2 = CCLoadSprite:createSprite("BG_zhuangbeiwaikuang.png")

    headNode:addChild(headBG)
    headNode:addChild(headBG2)
    local headIconSize = 95
    local pos = cc.p(0,0)
    if ctl:getRes() and ctl:getRes().wangguan then
        local wangguan = CCLoadSprite:createSprite(ctl:getRes().wangguan)
        wangguan:setScale(0.4)

        headNode:addChild(wangguan)
        wangguan:setPosition(cc.p(0,78))
        headBG:setScale(0.8)
        headBG2:setScale(0.8)
        headIconSize = 76                    
        headNode:setPosition(cc.p(0,-12))
    end

    if leaderInfo and leaderInfo.uid then
        local info_pic      = leaderInfo.pic
        local info_picVer   = tonumber(leaderInfo.picVer)
        local info_uid      = leaderInfo.uid
        local info_picfraId = leaderInfo.picfraId

        local headIcon = CCCommonUtilsForLua:call("makeUserHeadIcon", info_uid, info_pic, info_picfraId, info_picVer, headIconSize)
        headNode:addChild(headIcon)
    end

    local BG_LU = CCLoadSprite:createSprite("BG_yingxiongdengji.png")
    local BG_RU = CCLoadSprite:createSprite("BG_yingxiongdengji.png")
    BG_LU:setAnchorPoint(ccp(1,0.5))
    BG_LU:setFlipX(true)
    BG_RU:setAnchorPoint(ccp(0,0.5))
    BG_LU:setPositionY(-35)
    BG_RU:setPositionY(-35)
    headNode:addChild(BG_LU)
    headNode:addChild(BG_RU)
    headNode:setScale(0.85)
    if leaderInfo and leaderInfo.name then
        local label0 = CCLabelIF:call("create1", leaderInfo.name)
        label0:call("setFontSize", 20)
        label0:call("setColor",cc.c3b(236,220,170))
        label0:setPositionY(-35)
        headNode:addChild(label0)
    end


    local BG_L = CCLoadSprite:createSprite("BG_yingxiongdengji.png")
    local BG_R = CCLoadSprite:createSprite("BG_yingxiongdengji.png")                
    BG_L:setAnchorPoint(ccp(1,0.5))
    BG_L:setFlipX(true)
    BG_L:setScaleX(1.5)
    BG_R:setScaleX(1.5)
    BG_R:setAnchorPoint(ccp(0,0.5))
    BG_L:setPositionY(-150)
    BG_R:setPositionY(-150)

    local actDialog = ctl:getNpcTitle() or "182171"
    local label = CCLabelIF:call("create1", getLang(actDialog))
    label:call("setFontSize", 20)
    label:call("setColor",cc.c3b(236,220,170))
    label:setPositionY(-150)
    leaderHeadNode:addChild(BG_L)
    leaderHeadNode:addChild(BG_R)
    leaderHeadNode:addChild(headNode)
    leaderHeadNode:addChild(label)

    return leaderHeadNode, headBG2
end

return QuickKillMonsterNpcController