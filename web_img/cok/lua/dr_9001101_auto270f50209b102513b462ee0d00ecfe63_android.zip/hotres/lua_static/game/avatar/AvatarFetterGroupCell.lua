--[[ 
    皮肤羁绊内元素-单元格
    2019.4.28   Awen
 ]]
local AvatarFetterGroupCell = class("AvatarFetterGroupCell", function() return cc.Layer:create() end)
local CELL_COUNT = 3

function AvatarFetterGroupCell:create()
    local cell = AvatarFetterGroupCell.new()
    Drequire("game.avatar.AvatarFetterGroupCell_ui"):create(cell, 0)
    cell:initView()
    return cell
end

function AvatarFetterGroupCell:initView()
    registerTouchHandler(self)
    self:setTouchEnabled(true)
    self:setSwallowsTouches(false)
    for i = 1, CELL_COUNT do
        local node = self.ui['m_nodeItem'..i]
        if node then
            node:setUseTouchScale(true)
        end
    end
end

function AvatarFetterGroupCell:refreshCell(data, idx)
    self.v_data = data
    self.v_index = idx
    for i=1,CELL_COUNT do
        if data[i] then
            self.ui['m_nodeItem'..i]:setVisible(true)
            self.ui['m_nodeActive'..i]:setVisible(false)

            local tInfo= ToolController:call("getToolInfoByIdForLua", tonumber(data[i].itemId))
            
            -- 名称
            if data[i].name then
                self.ui['m_labelName'..i]:setString(getLang(data[i].name))
            else
                self.ui['m_labelName'..i]:setString(tInfo:call("getName"))
            end
            -- 图标
            local _icon = nil
            self.ui['m_nodeIcon'..i]:removeAllChildren()
            if data[i].icon then
                _icon = CCLoadSprite:createSprite('fetter12_' .. data[i].icon..'.png')
            else
                _icon = CCLoadSprite:createSprite(tInfo:getProperty("icon")..'.png')
            end
            if _icon then
                self.ui['m_nodeIcon'..i]:addChild(_icon)
            end

            -- 未获取置灰
            CCCommonUtilsForLua:setSpriteGray(_icon, (not AvatarController:getInstance():isAlreadyHaveAndOpen(tonumber(data[i].itemId))))
        else
            self.ui['m_nodeItem'..i]:setVisible(false)
        end
    end
end

function AvatarFetterGroupCell:refreshState(data)
    Dprint("AvatarFetterGroupCell:refreshState")
    if data then
        local _itemId = tolua.cast(data,"CCString"):getCString()
        if _itemId then
            for i=1,CELL_COUNT do
                if self.v_data[i] then
                    if self.v_data[i].itemId == _itemId then
                        self.ui['m_nodeActive'..i]:setVisible(true)
    
                        self.v_data[i].view:refresh(_itemId)
                    else
                        self.ui['m_nodeActive'..i]:setVisible(false)
                    end
                end
            end
        end
    end
end

function AvatarFetterGroupCell:onEnter(  )
	registerScriptObserver(self, self.refreshState, "AvatarFetterGroupCell:refreshState")
end

function AvatarFetterGroupCell:onExit(  )
    unregisterScriptObserver(self, "AvatarFetterGroupCell:refreshState")
end

function AvatarFetterGroupCell:onTouchBegan( x, y )
    for i=1,CELL_COUNT do
        local node = self.ui['m_nodeItem'..i]
        if self.v_data[i] and isTouchInsideVis(self.ui['m_nodeItem'..i], x, y) then
            self.touchPoint = ccp(x, y)
            node:setTouchScaled(true)
            return true
        end
    end
    return false
end

function AvatarFetterGroupCell:onTouchEnded( x, y )
    if ccpDistance(self.touchPoint, ccp(x, y)) > 10 then return end

    for i=1,CELL_COUNT do
        local node = self.ui['m_nodeItem'..i]
        node:setTouchScaled(false)
        if self.v_data[i] and isTouchInsideVis(self.ui['m_nodeItem'..i], x, y) then
	        CCSafeNotificationCenter:call("postNotification", "AvatarFetterGroupCell:refreshState", CCString:create(self.v_data[i].itemId))
	        CCSafeNotificationCenter:call("postNotification", "MSG_TMP_SKIN_CHANGE", CCString:create(self.v_data[i].itemId))
            break
        end
    end
end

return AvatarFetterGroupCell