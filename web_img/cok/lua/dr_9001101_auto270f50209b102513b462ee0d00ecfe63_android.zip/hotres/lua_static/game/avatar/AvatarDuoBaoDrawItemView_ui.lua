----------------------------
-- Author: Elex
-- Date: 2019-05-31 Friday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local AvatarDuoBaoDrawItemView_ui = class("AvatarDuoBaoDrawItemView_ui")

--#ui propertys


--#function
function AvatarDuoBaoDrawItemView_ui:create(owner, viewType, paramTable)
	local ret = AvatarDuoBaoDrawItemView_ui.new()
	CustomUtility:LoadUi("AvatarDuoBaoDrawItemView.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function AvatarDuoBaoDrawItemView_ui:initLang()
	LabelSmoker:setText(self.m_pLabelTTF41, "150360")
end

function AvatarDuoBaoDrawItemView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function AvatarDuoBaoDrawItemView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return AvatarDuoBaoDrawItemView_ui

