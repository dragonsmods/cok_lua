--[[	
	装备夺宝抽奖
	2019.5.13	Xu
]]
local AvatarDuoBaoDrawResultView =
	class(
	"AvatarDuoBaoDrawResultView",
	function()
		return PopupBaseView:create()
	end
)
AvatarDuoBaoDrawResultView.__index = AvatarDuoBaoDrawResultView

--------------------------------------------------------------------------------------
function AvatarDuoBaoDrawResultView.create(parent)
	local view = AvatarDuoBaoDrawResultView.new()
	Drequire("game.avatar.AvatarDuoBaoDrawResultView_ui"):create(view, 1)

	view.view = parent
	view.ctl = parent.ctl
	view.viewType = parent.viewType
	view.resultData = data

	if view:initView() == false then
		return nil
	end
	return view
end

function AvatarDuoBaoDrawResultView:initView()
	Dprint("AvatarDuoBaoDrawResultView:initView")

	self.ui.m_buyOneSpriteLabel:setString(getLang("176824", "1"))
	self.ui.m_buyTenSpriteLabel:setString(getLang("176824", "10"))
	self.ui.m_openOneLabel:setString(getLang("176825", "1"))
	self.ui.m_openTenLabel:setString(getLang("176825", "10"))

	self:registerTouchFuncs()
	CCLoadSprite:call("loadDynamicResourceByName", "AvatarDuoBao_face")

	return true
end

function AvatarDuoBaoDrawResultView:onEnter()
	XEvtTimer:on("AvatarDuoBaoDrawResultView:setResult", function (data)
		self:setResult(data)
	end)
	self:setFreeDrawCountdown(true)
	self:refreshView()

end

function AvatarDuoBaoDrawResultView:onExit()
	XEvtTimer:off("AvatarDuoBaoDrawResultView:setResult")
	self:setFreeDrawCountdown(false)
end

function AvatarDuoBaoDrawResultView:setResult(result)
	if result then
		self.resultData = result
		self:refreshView()

		-- 
		-- createTableFlyReward(result.lotteryReward)
		-- local _cArray = luaToArray(result.lotteryReward)

		-- PortActController:call("flyReward", _cArray, true)
		-- RewardController:call("retReward", _cArray)
		createGCMRewardByRewardAdd(result.lotteryReward, true)
		-- dump(result.lotteryReward, "AvatarDuoBaoDrawResultView:result.lotteryReward")
		local arr = {}
		local type = "7"
		for k, v in ipairs(result.itemArray) do
			local one = {
				type = type,
				value = v
			}
			table.insert(arr, one)
		end
		createGCMRewardByRewardAdd(arr, true)
		-- dump(arr, "AvatarDuoBaoDrawResultView:result.itemArray")
	end
end

function AvatarDuoBaoDrawResultView:refreshView()
	self:refreshMainItemView()
	self:refreshItemsView()
	self:refreshFreeDrawCountdownView()
	self:refreshDrawMoneyTypeView()
	self:refreshHasAni()
end

function AvatarDuoBaoDrawResultView:refreshMainItemView()
	if not (self.resultData and self.resultData.lotteryReward and self.resultData.lotteryReward[1]) then
		return 
	end
	local data = self.resultData.lotteryReward[1].value
	
	local itemData = {
        type = 0,
        itemId = data.itemId,
        num = data.rewardAdd or data.addCount
    }
    local icon_node = CCNode:create()
    local iconSize = 80
    local LibaoCommonFunc = Drequire("game.LiBao.LibaoCommonFunc")
	LibaoCommonFunc.createItemInfoShow(itemData, icon_node, iconSize, nil, nil, nil, true)
	icon_node:setTag(1)
    self.ui.m_iconNode:addChild(icon_node)

    local nameStr = getLang(CCCommonUtilsForLua:call("getPropById", itemData.itemId, "name"))
    nameStr = nameStr.." X"..itemData.num
	self.ui.m_pItemLabel:setString(nameStr)

	-- local MagicLuckDrawRewardCell = Drequire("game.magic.LuckDraw.MagicLuckDrawRewardCell")
	-- local cell = MagicLuckDrawRewardCell.create(true, itemData.itemId, itemData.num)
	-- cell:setScale(0.8)
	-- self.ui.m_iconNode:addChild(cell)
	-- cell:showAnim(1)

	-- local scaleTo1 = cc.ScaleTo:create(0.2, 8)
	-- local scaleTo2 = cc.ScaleTo:create(0.1, 8, 7.5)
	-- local scaleTo3 = cc.ScaleTo:create(0.1, 8, 8)

	-- local function callback()  end
	-- local call = cc.CallFunc:create(callback)
	-- local sequence = cc.Sequence:create(scaleTo1, scaleTo2, scaleTo3, call)
	-- self.ui.m_iconNode:runAction(sequence)
	self:showAnim_1()
end

function AvatarDuoBaoDrawResultView:refreshItemsView()
	if not (self.resultData and self.resultData.itemArray) then
		return 
	end
	local type = 10
	local datas = {}
	for k, v in pairs(self.resultData.itemArray or {}) do
		datas[k] = {}
		for k2, v2 in pairs(v) do
			datas[k][k2] = v2
		end
		datas[k].lighting = self.ctl:getIsRewardLighting(self.viewType, v.index)
	end
	if #datas == 1 then
		type = 1
	end
	for i = 1, 10 do
		local node = self.ui["m_itemNode"..i]
		if type == 1 then
			if i == 3 then
				node:setVisible(true)
				self:refreshOneItemView(node, datas[1])
			else
				node:setVisible(false)
			end
		elseif type == 10 then
			if datas[i] then
				node:setVisible(true)
				self:refreshOneItemView(node, datas[i])
			else
				node:setVisible(false)
			end
		end
	end
end

function AvatarDuoBaoDrawResultView:refreshOneItemView(node, data)
	node:removeAllChildren()
	local itemNode = Drequire("game.avatar.AvatarDuoBaoDrawResultItemView"):create()
	itemNode:refreshCell(data)
	node:addChild(itemNode)
end

function AvatarDuoBaoDrawResultView:setFreeDrawCountdown(active) -- 设置活动时间倒计时定时器
	if self.freeDrawCountdownTimer then
		self:getScheduler():unscheduleScriptEntry(self.freeDrawCountdownTimer)
		self.freeDrawCountdownTimer = nil
	end
	if active then
		self.freeDrawCountdownTimer =
			self:getScheduler():scheduleScriptFunc(
			function(dt)
				self:refreshFreeDrawCountdownView()
			end,
			1.0,
			false
		)
	end
end

function AvatarDuoBaoDrawResultView:refreshFreeDrawCountdownView()
	
	local nextFreeAt = self.ctl:getNextFreeBuyOneAt(self.viewType)
	local now = getTimeStamp()
	if now >= nextFreeAt then
		self.ui.m_buyOneFreeLabel:setVisible(true)
		self.ui.m_costOneIconSpr:setVisible(false)
		self.ui.m_buyOneCostLabel:setVisible(false)

		self.ui.m_freeTimerLabel:setVisible(false)
	else
		self.ui.m_buyOneFreeLabel:setVisible(false)
		self.ui.m_costOneIconSpr:setVisible(true)
		self.ui.m_buyOneCostLabel:setVisible(true)

		self.ui.m_freeTimerLabel:setVisible(true)

		self.ui.m_freeTimerLabel:setString(format_time(nextFreeAt - now))
	end
end

function AvatarDuoBaoDrawResultView:refreshDrawMoneyTypeView()
	local price = self.ctl:getLuckyDrawPrice(self.viewType)
	if not price then
		self.ui.m_buyBtnNode:setVisible(false)
		return
	else
		self.ui.m_buyBtnNode:setVisible(true)
	end
	
	local spf, size = self:getMoneyIconByType(price.priceType)
	self.ui.m_costOneIconSpr:setSpriteFrame(spf)
	CCCommonUtilsForLua:call("setSpriteMaxSize", self.ui.m_costOneIconSpr, size, true)
	spf, size = self:getMoneyIconByType(price.priceType)
	self.ui.m_costTenIconSpr:setSpriteFrame(spf)
	CCCommonUtilsForLua:call("setSpriteMaxSize", self.ui.m_costTenIconSpr, size, true)
	self.ui.m_buyOneCostLabel:setString(tostring(price.priceOne))
	self.ui.m_buyTenCostLabel:setString(tostring(price.priceTen))

end

function AvatarDuoBaoDrawResultView:refreshHasAni()
	self.ui.m_selectSpr:setVisible(not self.ctl:getHasAni())
	XEvtTimer:post("AvatarDuoBaoDrawView:refresh", {
		action = "refreshHasAni"
	})
end

function AvatarDuoBaoDrawResultView:getMoneyIconByType(type)
	if self.ctl:isTicketOpen() then
		local viewType = self.viewType
		if self.m_moneyIconMap and self.m_moneyIconMap[viewType] then
			return self.m_moneyIconMap[viewType],45
		end

		local currId = self:getCurrId(viewType)
		if currId then
			local icon = CCCommonUtilsForLua:call("getIcon", tostring(currId))
			if not string.isNilOrEmpty(icon) then
				local spf = CCLoadSprite:call("loadResource", icon)
				if spf then
					self.m_moneyIconMap = self.m_moneyIconMap or {}
					self.m_moneyIconMap[viewType] = spf

					self.m_beUseItemAsCurrency = true
					return spf, 45
				end
			end
		end

		if self.m_beUseItemAsCurrency then
			return
		end
	end

	if type == _DRAW_TYPE_GOLD then
		local spf = CCLoadSprite:call("loadResource", "ui_gold.png")
		return spf, 45
	elseif type == _DRAW_TYPE_DIAMOND then
		local spf = CCLoadSprite:call("loadResource", "diamond.png")
		return spf, 45
	end
end

function AvatarDuoBaoDrawResultView:_getGamebleData( type,key )
	type = type or self.viewType
	local infoData = self.ctl:getDrawInfoData(type)
	if infoData and infoData.gambleData and 
		(infoData.gambleData.currType == '3' and not string.isNilOrEmpty(infoData.gambleData[key])) then
		return infoData.gambleData[key]
	end

	return nil
end

function AvatarDuoBaoDrawResultView:getCurrId( type )
	return self:_getGamebleData(type,"currId")
end

function AvatarDuoBaoDrawResultView:onClickBuyOneBtn()
	-- self.view:onClickBuyOneBtn()
	self:exitToParent()
	XEvtTimer:post("AvatarDuoBaoDrawView:doADraw", {
		times = 1
	})
end
function AvatarDuoBaoDrawResultView:onClickBuyTenBtn()
	-- self.view:onClickBuyTenBtn()
	self:exitToParent()
	XEvtTimer:post("AvatarDuoBaoDrawView:doADraw", {
		times = 10
	})
end

function AvatarDuoBaoDrawResultView:onSwitchHasAniBtnClick()
	self.ctl:setHasAni(not self.ctl:getHasAni())
	self:refreshHasAni()
end

function AvatarDuoBaoDrawResultView:onTouchBegan(x, y)
    self.touchToRemove = nil
    if not touchInside(self.ui.m_dialog_root, x, y) then
        self.touchToRemove = 1
    end
    return true
end

function AvatarDuoBaoDrawResultView:onTouchMoved(x, y)

end

function AvatarDuoBaoDrawResultView:onTouchEnded(x, y)
    if self.touchToRemove == 1 and touchInside(self.ui.m_dialog_root, x, y)==false then
		-- 
		self:exitToParent()
    end
end
function AvatarDuoBaoDrawResultView:exitToParent()
	-- self.view:removeChild(self)
	PopupViewController:call("removeLastPopupView")
end

function AvatarDuoBaoDrawResultView:showAnim_1()
    -- 图标
    if self.ui.m_iconNode then
        self.ui.m_iconNode:setVisible(true)
        local icon = self.ui.m_iconNode:getChildByTag(1)
        if icon then
            icon:setScale(3.5)
            icon:setOpacity(80)

            local action1_0 = cc.FadeTo:create(0.5, 255)
            local action1_1 = cc.ScaleTo:create(0.5, 0.9)
            local action1_2 = cc.EaseSineIn:create(action1_1)
            local spawn1 = cc.Spawn:create(action1_0, action1_2)

            local action2_0 = cc.ScaleTo:create(0.2, 1.2)
            local action2_1 = cc.EaseSineIn:create(action2_0)
            local spawn2 = cc.Spawn:create(action2_1)

            local action3_0 = cc.ScaleTo:create(0.1, 1)
            local spawn3 = cc.Spawn:create(action3_0)

            local function callback()  end
            local call = cc.CallFunc:create(callback)

            local sequence = cc.Sequence:create(spawn1, spawn2, call, spawn3)
            icon:runAction(sequence)
        end
    end  

    -- 数字
    if self.ui.m_num then
        local delay = cc.DelayTime:create(0.5)
        local show = cc.Show:create()
        local fadeto = cc.FadeTo:create(0, 102)
        local fadein = cc.FadeIn:create(0.5)
        self.ui.m_num:runAction(cc.Sequence:create(delay, show, fadeto, fadein))
    end

    -- 名字
    if self.ui.m_pItemLabel then
        local delay = cc.DelayTime:create(0.5)
        local show = cc.Show:create()
        local fadeto = cc.FadeTo:create(0, 102)
        local fadein = cc.FadeIn:create(0.5)
        self.ui.m_pItemLabel:runAction(cc.Sequence:create(delay, show, fadeto, fadein))
    end
end


return AvatarDuoBaoDrawResultView
