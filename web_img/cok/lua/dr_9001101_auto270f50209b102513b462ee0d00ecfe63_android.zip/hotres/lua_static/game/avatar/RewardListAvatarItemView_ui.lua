----------------------------
-- Author: Elex
-- Date: 2018-04-17 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local RewardListAvatarItemView_ui = class("RewardListAvatarItemView_ui")

--#ui propertys


--#function
function RewardListAvatarItemView_ui:create(owner, viewType, paramTable)
	local ret = RewardListAvatarItemView_ui.new()
	CustomUtility:LoadUi("RewardListAvatarItemView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function RewardListAvatarItemView_ui:initLang()
end

function RewardListAvatarItemView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function RewardListAvatarItemView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function RewardListAvatarItemView_ui:onUseBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onUseBtnClick", pSender, event)
end

function RewardListAvatarItemView_ui:onBuyBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBuyBtnClick", pSender, event)
end

function RewardListAvatarItemView_ui:onCancelBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onCancelBtnClick", pSender, event)
end

function RewardListAvatarItemView_ui:onInfoBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onInfoBtnClick", pSender, event)
end

function RewardListAvatarItemView_ui:initTableView()
	TableViewSmoker:createView(self, "m_pTableView1", "game.activity.NewbeeCastle.NewbeeCastlePopupCell", 1, 5, "NewbeeCastlePopupCell")
end

function RewardListAvatarItemView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return RewardListAvatarItemView_ui

