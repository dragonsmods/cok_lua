----------------------------
-- Author: Elex
-- Date: 2019-04-26 Friday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local AvatarFetterView_ui = class("AvatarFetterView_ui")

--#ui propertys


--#function
function AvatarFetterView_ui:create(owner, viewType, paramTable)
	local ret = AvatarFetterView_ui.new()
	CustomUtility:DoRes(8, true)
	CustomUtility:LoadUi("AvatarFetterView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function AvatarFetterView_ui:initLang()
	LabelSmoker:setText(self.m_labelTitle, "350203")
	LabelSmoker:setText(self.m_titleTxt, "350202")
end

function AvatarFetterView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function AvatarFetterView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function AvatarFetterView_ui:onClickBtnFaq(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnFaq", pSender, event)
end

function AvatarFetterView_ui:initTableView()
	TableViewSmoker:createView(self, "m_tableView", "game.avatar.AvatarFetterCell", 1, 3, "AvatarFetterCell")
	TableViewSmoker:createView(self, "m_tableViewBuff", "game.avatar.AvatarFetterBuffCell", 1, 3, "AvatarFetterBuffCell")
end

function AvatarFetterView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return AvatarFetterView_ui

