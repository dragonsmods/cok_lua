--[[	
	装备夺宝抽奖
	2019.5.13	Xu
]]
local AvatarDuoBaoDrawMallView = class( "AvatarDuoBaoDrawMallView", function() return PopupBaseView:create() end )
AvatarDuoBaoDrawMallView.__index = AvatarFettersView

local ITEM_IDS = {215528, 215529}	-- 神眷水晶	暗泽水晶
--------------------------------------------------------------------------------------
function AvatarDuoBaoDrawMallView.create()
	local view = AvatarDuoBaoDrawMallView.new()
	Drequire("game.avatar.AvatarDuoBaoDrawMallView_ui"):create(view, 1)

	if view:initView() == false then
		return nil
	end
	return view
end

function AvatarDuoBaoDrawMallView:initView()
	self.ui.m_switchBtn1:setHighlighted(true)
	require("game.avatar.AvatarDuoBaoDrawController"):requestMallData(function (data)
		if data.goodsArray then
			self.m_goodsArray = data.goodsArray
			self:onSwitch1Click()
		end
	end)
	return true
end

function AvatarDuoBaoDrawMallView:getItemData( itemId )
	local _tableData = {}
	local _tableRow = {}
	if self.m_goodsArray then
		for i,v in ipairs(self.m_goodsArray) do
			if v.currId == tostring(itemId) then
				if #_tableRow >= 2 then
					table.insert(_tableData, _tableRow)
					_tableRow = {}
				end
				table.insert(_tableRow, v)
			end
		end
		if #_tableRow > 0 then
			table.insert(_tableData, _tableRow)
		end
	end
	return _tableData
end

function AvatarDuoBaoDrawMallView:onSwitch1Click()
	self.ui.m_switchBtn1:setHighlighted(true)
	self.ui.m_switchBtn2:setHighlighted(false)
	local _tableData = self:getItemData(ITEM_IDS[1])
	self.ui:setTableViewDataSource("m_tableView", _tableData)
end

function AvatarDuoBaoDrawMallView:onSwitch2Click()
	self.ui.m_switchBtn1:setHighlighted(false)
	self.ui.m_switchBtn2:setHighlighted(true)
	local _tableData = self:getItemData(ITEM_IDS[2])
	self.ui:setTableViewDataSource("m_tableView", _tableData)
end

function AvatarDuoBaoDrawMallView:onEnter()
	self:refreshView()
	registerScriptObserver(self, self.refreshView, "AvatarDuoBaoDrawMallView:refreshView")
end

function AvatarDuoBaoDrawMallView:onExit()
	unregisterScriptObserver(self, "AvatarDuoBaoDrawMallView:refreshView")	
end

function AvatarDuoBaoDrawMallView:refreshView()
	for i,v in ipairs(ITEM_IDS) do
		local _tInfo= ToolController:call("getToolInfoByIdForLua", v)
		if _tInfo then
			-- 图标
			if self.ui['m_nodeItem'..i]:getChildrenCount() == 0 then
				local _iconSpr = CCLoadSprite:createSprite(_tInfo:getProperty("icon")..".png")
				if _iconSpr then
					self.ui['m_nodeItem'..i]:addChild(_iconSpr)
				end
				CCCommonUtilsForLua:call("setSpriteMaxSize", _iconSpr, 44, true)
			end

			-- 名称和数量
			self.ui['m_labelItem'..i]:setString(_tInfo:call("getName")..': x'.._tInfo:call("getCNT"))
		end
	end
end

-- 点击关闭
function AvatarDuoBaoDrawMallView:onClickBtnClose()
	self:closeSelf()
end

return AvatarDuoBaoDrawMallView