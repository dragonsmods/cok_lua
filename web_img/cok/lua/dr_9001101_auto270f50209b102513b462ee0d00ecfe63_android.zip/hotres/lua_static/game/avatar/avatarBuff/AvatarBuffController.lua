local AvatarBuffController = class("AvatarBuffController")

function AvatarBuffController:ctor()
	self:init()
end

function AvatarBuffController:init()
	if self.avatarXmlData == nil then
		self.avatarXmlData = {}
		--建立缓存以goodsId为key，省去一次查找
		local dress_attribute = CCCommonUtilsForLua:getGroupByKey("dress_effect") --buf表
		for k,v in pairs(dress_attribute) do
			if v.goodsid then
				local keyTbl = string.split(v.goodsid,";")
				for _,key in pairs(keyTbl or {}) do
					self.avatarXmlData[key] = {status_id = v.status_id, effect_id = v.effect_id, dialog_id = v.dialog_id}
				end
			end
	    end 
	end
end

--[[ 
    <ItemSpec id="19900000" status_id="12001216" goodsid = "215731;215738" effect_id="1011;0.5|1031;0.5" dialog_id="171054|171055"/>
 ]]
 --根据goodsId获取皮肤属性
function AvatarBuffController:getBufListById(goodsId)	
    local res = {}
	local data = self.avatarXmlData[tostring(goodsId)]
	if not data then 
		return res
	end
    
    local dialogs = string.split(data.dialog_id,"|")    
    local effectNums = string.split(data.effect_id,"|")
    local buffSize = #dialogs
    for i=1,buffSize do
        local effInfo = string.split(effectNums[i],";") or {}
        res[#res+1] = {
            dialogId = dialogs[i] or "",            
            effValue = tonumber(effInfo[2]) or 0,
            effNum = tonumber(effInfo[1]) or 0
        }
    end
    return res
end

return AvatarBuffController
