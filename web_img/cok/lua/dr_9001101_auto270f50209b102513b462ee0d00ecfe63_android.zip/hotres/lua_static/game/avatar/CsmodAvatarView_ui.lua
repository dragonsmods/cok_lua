----------------------------
-- Author: Elex
-- Date: 2021-04-25 Sunday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CsmodAvatarView_ui = class("CsmodAvatarView_ui")

--#ui propertys


--#function
function CsmodAvatarView_ui:create(owner, viewType, paramTable)
	local ret = CsmodAvatarView_ui.new()
	CustomUtility:DoRes(0, true)
	CustomUtility:LoadUi("AvatarViewNewEx.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CsmodAvatarView_ui:initLang()
	LabelSmoker:setText(self.m_labelFetters, "350201")
	LabelSmoker:setText(self.m_pLabelTTF15, "350170")
	LabelSmoker:setText(self.m_pLabelTTF15, "132206")
	ButtonSmoker:setText(self.m_btnDress, "350168")
	ButtonSmoker:setText(self.m_btnShop, "350169")
end

function CsmodAvatarView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CsmodAvatarView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CsmodAvatarView_ui:onClickBtnIndex(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnIndex", pSender, event)
end

function CsmodAvatarView_ui:onClickBtnTab(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnTab", pSender, event)
end

function CsmodAvatarView_ui:onClickBtnTab(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnTab", pSender, event)
end

function CsmodAvatarView_ui:onClickBtnUseAll(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnUseAll", pSender, event)
end

function CsmodAvatarView_ui:onClickGotoScale(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickGotoScale", pSender, event)
end

return CsmodAvatarView_ui

