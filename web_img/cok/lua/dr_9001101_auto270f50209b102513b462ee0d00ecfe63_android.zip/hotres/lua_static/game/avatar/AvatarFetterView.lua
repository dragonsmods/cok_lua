--[[
	皮肤羁绊主界面
	2019.4.25	Awen
]]
local AvatarFetterView = class("AvatarFetterView", function()
    return PopupBaseView:create()
end)
AvatarFetterView.__index = AvatarFettersView

--------------------------------------------------------------------------------------
function AvatarFetterView.create(  )
	local view = AvatarFetterView.new()
	Drequire("game.avatar.AvatarFetterView_ui"):create(view, 1)

	if view:initView() == false then
		return nil
	end
  	return view
end

function AvatarFetterView:initView()
	Dprint("AvatarFetterView:initView")
	CCLoadSprite:call("loadDynamicResourceByName", "SkinFetter_face")
	require("game.avatar.AvatarController")

	-- registerNodeEventHandler(self)
	-- 皮肤羁绊列表
	local _xmlData = {}
	for _,v in pairs(CCCommonUtilsForLua:getGroupByKey("skin_fetters") or {}) do
		table.insert(_xmlData, v)
	end
	table.sort(_xmlData, function(a, b)
		local _aIndex = tonumber(a.index) or 0
		local _bIndex = tonumber(b.index) or 0
		return _aIndex < _bIndex
	end)
	dump(_xmlData, "AvatarFetterView:initView _xmlData")

	local _dataGroup = {}
	local _dataBuff = {}
	local _dataRow = {}
	for _,v in pairs(_xmlData) do
		local _xmlItem = { id = v.id, name = v.name, icon = v.icon }
		-- 进度
		local _itemList = string.split(v.item, '|')
		local _ownCount = 0
		for i,v in ipairs(_itemList) do
			if AvatarController:getInstance():isAlreadyHaveAndOpen(tonumber(v)) then
				_ownCount = _ownCount + 1
			end
		end
		_xmlItem.process = _ownCount .. '/' .. (#_itemList)

		-- Buff
		local _effectList = string.split(v.effect_dialog, '|')
		local _effectValue = string.split(v.value, '|')
		local _effectCondition = string.split(v.number, '|')
		local _effectAbs = string.split(v.abs, '|')
		for i=1, #_effectList do
			local _index = _effectList[i]
			_dataBuff[_index] = _dataBuff[_index] or {cur = 0, max = 0, abs = _effectAbs[i]}

			-- 最大值
			local _value = tonumber(_effectValue[i]) or 0
			_dataBuff[_index].max = _dataBuff[_index].max + _value

			-- 当前值
			local _condition = tonumber(_effectCondition[i]) or 0
			if _ownCount >= _condition then
				_dataBuff[_index].cur = _dataBuff[_index].cur + _value
			end
		end

		table.insert(_dataRow, _xmlItem)
		if #_dataRow == 2 then
			table.insert(_dataGroup, _dataRow)
			_dataRow = {}
		end
	end
	if #_dataRow > 0 then
		table.insert(_dataGroup, _dataRow)
	end
	dump(_dataGroup, "AvatarFetterView:initView")
	self.ui:setTableViewDataSource('m_tableView', _dataGroup)


	-- 总属性
	local _dataBuff2 = {}
	for k,v in pairs(_dataBuff) do
		if v.abs == '0' then
			table.insert(_dataBuff2, {labelAll = getLang(k, v.cur..'%')..' (max:'..v.max..'%)'})
		else
			table.insert(_dataBuff2, {labelAll = getLang(k, v.cur)..' (max:'..v.max..')'})
		end
	end

	-- dump(_dataBuff, "AvatarFetterView:initView")
	self.ui:setTableViewDataSource('m_tableViewBuff', _dataBuff2)

	self.v_data = _xmlData

	XEvtTimer:on("AvatarFetterView:openAGroup", function(tbl)
		if tbl and tbl.id and self.openAGroup then
			self:openAGroup(tbl.id)
		end
	end)
	XEvtTimer:on("AvatarFetterView:changeGroupLastOrNext", function(tbl)
		if tbl and tbl.lastOrNext and tbl.id then
			self:changeGroupLastOrNext(tbl.id, tbl.lastOrNext)
		end
	end)
	return true
end

function AvatarFetterView:onCleanup()
	XEvtTimer:off("AvatarFetterView:openAGroup")
	XEvtTimer:off("AvatarFetterView:changeGroupLastOrNext")
end

-- 打开FAQ
function AvatarFetterView:onClickBtnFaq(  )
	local params = {}
    params.title = getLang("350201") --350201=鉴赏
    params.info = getLang("350207")
    local view = Drequire("game.DressIntroduction.CommonInfoViewNew"):create(params)
    PopupViewController:addPopupView(view)
end

function AvatarFetterView:openAGroup(id)
    local view = Drequire("game.avatar.AvatarFetterGroupView").create(id)
	PopupViewController:addPopupInView(view)
end
function AvatarFetterView:changeGroupLastOrNext(groupId, lastOrNext)
	if #self.v_data < 2 then
		return
	end
	local index = nil
	for k, v in ipairs(self.v_data) do
		if v.id == groupId then
			index = k
			break
		end
	end
	if not index then
		return
	end
	if lastOrNext < 0 then
		index = (index + #self.v_data - 2) % (#self.v_data) + 1
	else
		index = index % (#self.v_data) + 1
	end
	self:openAGroup(self.v_data[index].id)
end


return AvatarFetterView