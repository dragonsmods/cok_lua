local function isHasValueInTable( v, t )
	for i,vv in ipairs(t) do
		if vv == v then
			return true
		end
	end
	return false
end

AvatarController = AvatarController or {}

MSG_AVATAR_INIT = "MSG_AVATAR_INIT"

---------------------------------------------
AvatarViewWardrobeShowInfo = class("AvatarViewWardrobeShowInfo")

function AvatarViewWardrobeShowInfo:ctor(  )
	self.isInBag = false
	self.itemId = 0
	self.endTime = 0
	self.isActive = false
	self.mark = 0
end

function AvatarViewWardrobeShowInfo:toDic(  )
	local dic = CCDictionary:create()
	dic:setObject(CCString:create(tostring(self.itemId)), "itemId")
	if self.isInBag then
		dic:setObject(CCString:create("1"), "isInBag")
	else
		dic:setObject(CCString:create("0"), "isInBag")
	end
	dic:setObject(CCString:create(tostring(self.endTime)), "endTime")
	dic:setObject(CCString:create("0"), "mark")
	return dic
end

function AvatarViewWardrobeShowInfo:isYongjiuStatus(  )
	return self.endTime == -1 or self.endTime > 1900000000
end

------------------------------------------------------

function hasUnSeenAvatar()
	local unSeen = AvatarController:getInstance():getUnSeenItemInStore()
	return unSeen and true or false
end

_gAvatarController = nil

function AvatarController:getInstance(  )
	if not _gAvatarController then
		_gAvatarController = AvatarController:call("getInstance")
		_gAvatarController:refreshSellItemsInStore()
		_gAvatarController:downloadFetterSkin()
		self.initCnt = 1
	end
	return _gAvatarController
end

function AvatarController.purge ()
	_gAvatarController = nil
end

--【Awen】下载羁绊皮肤 
function AvatarController:downloadFetterSkin()
	for _,v in pairs(CCCommonUtilsForLua:getGroupByKey("skin_fetters") or {}) do
		for i,vv in ipairs(string.split(v.item, '|') or {}) do
			local _ainfo = AvatarController:call("getAvatarInfoByGoodsId", tonumber(vv))
			if _ainfo and _ainfo:call("isResOk") == false then 
				local _statusId = _ainfo:call("getStatusId")
				AvatarController:call("downloadAvatarById", _statusId)
			end
		end
	end
end

function AvatarController:hasSeenItemInStore (itemId)
    local saveKey = "avatar_shop_seen_" .. itemId
    local seen = cc.UserDefault:getInstance():getIntegerForKey(saveKey, 0)
    -- MyPrint('AvatarController:hasSeenItemInStore', itemId, seen)
    return 1 == seen
end

--[[
	Return: nil 没有未查看的商品（不显示红点提示），{} 全部未查看（新号，页签显示提示，商品不显示）， {...} 页签、商品都显示提示
]]
function AvatarController:getUnSeenItemInStore (avatarType)
	avatarType = avatarType or AvatarType_Diamond
	if self.sellItemsInStore == nil then
		self:refreshSellItemsInStore()
		if self.sellItemsInStore == nil then
			return nil
		end
	end
	local itemIds = self.sellItemsInStore[avatarType]
	if not itemIds or 0 == #itemIds then
		self:refreshSellItemsInStore()
		local itemIds = self.sellItemsInStore[avatarType]
		if not itemIds or 0 == #itemIds then
			return nil
		end
	end
	local unSeen = {}
	for k, itemId in pairs(itemIds) do
	    if not self:hasSeenItemInStore(itemId) then
	    	unSeen[#unSeen + 1] = itemId
	    end
	end
	if 0 == #unSeen then
		return nil
	end
	if #unSeen >= #itemIds then
		return {}
	end
	return unSeen
end

function AvatarController:markAsSeenByType (avatarType)
	avatarType = avatarType or AvatarType_Diamond
	local itemIds = self.sellItemsInStore[avatarType]
	if not itemIds then
		return
	end
	for k, itemId in pairs(itemIds) do
		self:markAsSeen(itemId)
	end
end

function AvatarController:markAsSeen (itemId, val)
	val = val or 1
    local saveKey = "avatar_shop_seen_" .. itemId
    -- MyPrint('AvatarController:markAsSeen', saveKey)
    cc.UserDefault:getInstance():setIntegerForKey(saveKey, val)
    cc.UserDefault:getInstance():flush()
end

function AvatarController:markAsOpposite (itemId)
    local saveKey = "avatar_shop_seen_" .. itemId
    local cur = cc.UserDefault:getInstance():getIntegerForKey(saveKey, 0)
    cc.UserDefault:getInstance():setIntegerForKey(saveKey, 1 - cur)
    cc.UserDefault:getInstance():flush()
end

function AvatarController:fireCommonEvent(newKey, dict)
    if newKey == "createMarchAvatarNode" then
    	local data = dictToLuaTable(dict)
    	local baseNode = Drequire("game.avatar.AvatarMarchNode").new(data)
    	if baseNode then
    		dict:setObject(baseNode, "marchNode")
    	end
	elseif newKey == "updateMarchAvatarState" then
		local baseNode = dict:objectForKey("marchNode")
		local marchType = tonumber(dict:objectForKey("marchType"):getValue()) or 1
		-- dump(marchType, " marchType is: ")
		if baseNode and baseNode.setMarchState then
			baseNode:setMarchState(marchType)
		end
    end
end

function AvatarController:getAvatar3DTextureName(fileName)
	local tail = ".pvr"
	if isAndroid() then
		tail = ".pkm"
	end
	local path = CCFileUtils:sharedFileUtils():getWritablePath().."dresource/"..fileName..tail
	return path
end

function AvatarController:getAvatar3DTextureName2(fileName)
	local tail = ".pvr"
	if isAndroid() then
		tail = "_alpha.pkm"
	end
	local path = CCFileUtils:sharedFileUtils():getWritablePath().."dresource/"..fileName..tail
	return path
end

-- 取avatar配置
function AvatarController:getAvatarConfigData(configName)
	if not self.m_configListData then
		self.m_configListData = {}
	end
	self.m_configListData[configName] = nil
	if self.m_configListData[configName] == nil then
		local configFilePath = CCFileUtils:sharedFileUtils():getWritablePath().."dresource/skinparticle/"..configName..".config"
		local configDataFile = io.open(configFilePath, "r")
		local config = {}
		if configDataFile then
			local configLineContent = configDataFile:read()
			while(configLineContent) do
				local tbl = string.split(configLineContent, "=")
				config[tbl[1]] = tbl[2]
				configLineContent = configDataFile:read()
			end
		    io.close(configDataFile)
		end
		-- dump(config, " getConfig["..configName.."] is: ")

		if table_is_empty(config) then
			return false
		end
		self.m_configListData[configName] = config
	end
	return self.m_configListData[configName]
end

function AvatarController:createNodeByAvatarConfig(configName, xOffset, yOffset, loop)
	local config = self:getAvatarConfigData(configName)
	if loop ~= false then
		loop = true
	end
	-- parcnt=2
	-- par1=icedragon_0,150,50,1,0
	-- par2=icedragon_1,100,60,1,0
	-- skeletoncnt=1
	-- skeleton1=face_iceDragon_wai,sk_face_iceDragon_wai,dj,130,60,1
	-- isMonster=1
	-- hideNative=1
    if not config then 
        return 
    end
    local resPath = cc.FileUtils:getInstance():getWritablePath().."dresource/"

    xOffset = xOffset or 0
    yOffset = yOffset or 0

    local retNode
    local mainPos = {0, 0}
    -- local cfgName = string.lower(self.m_configName)
    local skeletoncnt = tonumber(config["skeletoncnt"]) or 0
    for i =1, skeletoncnt do
        local info = config["skeleton"..i]
        if info then
            local tbl = string.split(info, ",")
            if #tbl > 3 then
                mainPos[1] = (tonumber(tbl[4]) or 0) + xOffset
                mainPos[2] = (tonumber(tbl[5]) or 0) + yOffset
                local skin_file = resPath .. tbl[2].. ".atlas" 
                local skin_json = resPath .. "skinparticle/"..tbl[1]..".json"
                local animationObj = IFSkeletonAnimation:call("create", skin_json, skin_file)
                if animationObj then
                    -- dump("success to create animation+++")
                    -- animationObj:setToSetupPose()
                    animationObj:setAnimation(0, tbl[3], loop)
                    animationObj:setContentSize(cc.size(9999, 9999))
                    animationObj:setPosition(cc.p(mainPos[1],mainPos[2]))
                    if not retNode then
                    	retNode = cc.Node:create()
                    end
					retNode:addChild(animationObj)
					animationObj:setTag(i)
					if i == 1 then
						retNode.animationObj = animationObj
					end
                end
            end
        end
    end

    local parcnt = tonumber(config["parcnt"]) or 0
    for i = 1, parcnt do
        local info = config["par"..i]
        if info then
            local tbl = string.split(info, ",")
            -- 字段内容与其余皮肤保持一致
            -- ：粒子名称,坐标X,Y,是否在上面,是否在本地
            -- 是否在上面 暂时不需要
            local parPath = ""
            local particle = nil
            if tbl[5] == "1" then       -- "1"在本地
                particle = ParticleController:call("createParticle", tbl[1])
            else
                local path = resPath.. "skinparticle/" .. tbl[1]
                particle = ParticleController:call("createParticleForLua", path)
            end
            if particle then
                particle:setPosition(cc.p(mainPos[1] + tbl[2], mainPos[2] + tbl[3]))
                particle:setContentSize(cc.size(9999, 9999))
                if not retNode then
                	retNode = cc.Node:create()
                end
                retNode:addChild(particle)
            end
        end
    end
    return retNode
end

function AvatarController:isStoreInitialized ()
	local ret = self.sellItemsInStore and not table_is_empty(self.sellItemsInStore) and self.sellItemsInStore[AvatarType_Diamond]
	-- MyPrint('AvatarController:isStoreInitialized ' .. (ret and 'true' or 'false'), self.initCnt)
	self.initCnt = self.initCnt + 1
	return ret
end

function AvatarController:dumpAvatarListForLua( fun )
	local handler = luaRegisterHandler(fun)
	self:call("dumpAvatarListForLua", handler)
end

function AvatarController:dumpWardrobeForLua( fun )
	local handler = luaRegisterHandler(fun)
	self:call("dumpWardrobeForLua", handler)
end

function AvatarController:refreshSellItemsInStoreIfEmpty ()
	-- MyPrint('AvatarController:refreshSellItemsInStoreIfEmpty')
	if self:isStoreInitialized() then
		return
	end
	self.sellItemsInStore = self:getAllATypeAndSellItemsInStore()
end

function AvatarController:refreshSellItemsInStore ()
	self.sellItemsInStore = self:getAllATypeAndSellItemsInStore()
end

-- AvatarType_None = 0
-- AvatarType_Diamond = 98 --//钻石购买的
-- AvatarType_MysteryPiece = 99 -- //神秘礼盒碎片购买的
-- AvatarType_Castle = 100 --//城堡皮肤 包括内城和外城
-- AvatarType_March = 101 --// 行军皮肤
-- AvatarType_Ground = 102  --// 主城地表皮肤
-- AvatarType_ChatBg = 103 --// 聊天气泡
-- AvatarType_Nameplate = 104 --// 铭牌
-- AvatarType_CastleBubble = 105 --// 城堡上冒气泡
-- AvatarType_Protect = 106 --// 保护罩
-- AvatarType_HEHEHE = 107 -- 被莫名其妙占着了
-- AvatarType_CastleEffect = 108 --// 城堡上冒特效  和 105很像
-- AvatarType_Wings = 109  --// 翅膀
-- AvatarType_Civ = 110  --// 文明
-- AvatarType_CivFort = 114  --// 文明堡垒皮肤
-- AvatarType_Item = 199
-- AvatarType_HeadFrame = 115 -- // 头像框
-- AvatarType_MAX = 201
function AvatarController:advanceMake(  )
	self.avatarShopConfig = {}
    local tempTable = dictToLuaTable(LocalController:call("DBXMLManager"):call("getGroupByKey", "shop_new_avatar"))
    for k,v in pairs(tempTable) do
        self.avatarShopConfig[tonumber(v.item_id)]=v
    end

	self.avatarShopData = {}
	local function invoke( info )
		-- 取消资源未下载完成的限制
		-- if 
		-- 	info:call("isResOk") == false 
		-- 	and 
		-- 	AvatarType_Civ ~= info:call("getAvatarType") 
		-- 	and AvatarType_Item ~= info:call("getAvatarType") 
		-- 	and AvatarType_Ground ~= info:call("getAvatarType") 
		-- 	then 
		-- 	-- MyPrint('info:call("getAvatarType") == false', info:call("getItemId"))
		-- 	return true
		-- end
		local itemId = info:call("getItemId")
		if nil == self.avatarShopConfig[itemId] then
			-- MyPrint('nil == sellItemInfo', itemId)
			return true
		end

		local atype = info:call("getAvatarType")
		if 8 == tonumber(self.avatarShopConfig[itemId].value1_type) then -- 钻石购买
			-- MyPrint('AvatarType_Diamond statusId', info:call("getStatusId"))
			atype = AvatarType_Diamond
		elseif 11 == tonumber(self.avatarShopConfig[itemId].value1_type) then -- 神秘礼盒碎片购买
			atype = AvatarType_MysteryPiece
		end
		if AvatarType_Item == atype or atype == AvatarType_ActivityEffect then -- 不出现相应tab
			-- MyPrint('Not isValidToSell--不出现相应tab')
			return true
		end
		self.avatarShopData[atype] = self.avatarShopData[atype] or {}
		local t = self.avatarShopData[atype]
		t[#t + 1] = itemId
		return true
	end
	self:dumpAvatarListForLua(invoke)
end

function AvatarController:getAllATypeAndSellItemsInStore(  )
	-- MyPrint("AvatarController:getAllATypeAndSellItemsInStore")
	self.storeActivityIdxTab = {}
	local ret = {}

	if self.avatarShopData == nil then
		--【Awen】skin_mall开启后商城数据从后端获取 
		if not CCCommonUtilsForLua:isFunOpenByKey("skin_mall") then
			self:advanceMake()
		end
	end

	if self.avatarShopData == nil then
		return nil
	end
	for k,v in pairs(self.avatarShopData) do
		ret[k] = {}
		for i=1,#v do
			ret[k][i] = v[i]
		end
	end

	self.m_inSellType = self.m_inSellType or {}
	
	-- 穿着的皮肤 
	if not CCCommonUtilsForLua:isFunOpenByKey("skin_mall") then
		for i=AvatarType_Castle,AvatarType_MAX - 1 do
			if i ~= AvatarType_ActivityEffect then 
				local ainfo = self:call("getActiveAvatarInfoByType", i)
				if ainfo 
					-- 取消资源未下载完成的限制
					-- and (AvatarType_Civ == ainfo:call("getAvatarType") 
					-- 	or AvatarType_Ground == ainfo:call("getAvatarType") 
					-- 	-- or ainfo:call("isResOk")
					-- 	) 
					and ainfo:call("isHiddenInWardrobe") == false then
					ret[i] = ret[i] or {}
					if isHasValueInTable(ainfo:call("getItemId"), ret[i]) == false then
						ret[i][#(ret[i]) + 1] = ainfo:call("getItemId")
						self.storeActivityIdxTab[i] = ainfo:call("getItemId")
					end
				end
			end
		end
	end
	-- dump(ret, "ret_2")

	for k,v in pairs(ret) do
		table.sort(v, function (id1, id2)
			local shopInfo1 = self.avatarShopConfig[id1]
			local shopInfo2 = self.avatarShopConfig[id2]
			if shopInfo1 and shopInfo2 
				and shopInfo1.display ~= ""
				and shopInfo2.display ~= ""
				then
				return tonumber(shopInfo1.display) > tonumber(shopInfo2.display)
			end
			return id1 < id2
		end )
	end

	-- dump(ret, "ret355++++++")
	return ret

end

-- 获取衣柜里的所有avatar类型 包括背包里的还未使用的道具 包括正在穿着的皮肤
function AvatarController:getAllATypeAndItemsInWardrobe(  )
	-- MyPrint("AvatarController:getAllATypeAndItemsInWardrobe")
	local ret = {}
	local active = {}
	self.wardrobeActivityIdxTab = {}
	-- 正在穿着的
	for i = AvatarType_Castle, AvatarType_MAX -1 do
		if i ~= AvatarType_ActivityEffect then  
			local ainfo = self:call("getActiveAvatarInfoByType", i)
			if ainfo 
				-- 取消资源未下载完成的限制
				-- and (
				-- 	AvatarType_Civ == ainfo:call("getAvatarType") 
				-- 	or AvatarType_HeadFrame == ainfo:call("getAvatarType") 
				-- 	or AvatarType_Ground == ainfo:call("getAvatarType") 
				-- 	or ainfo:call("isResOk")
				-- 	) 
				and ainfo:call("isHiddenInWardrobe") == false 
				then
				ret[i] = ret[i] or {}
				local oneInfo = AvatarViewWardrobeShowInfo.new()
				oneInfo.isInBag = false
				oneInfo.itemId = ainfo:call("getItemId")
				oneInfo.statusId = ainfo:call("getStatusId")
				oneInfo.endTime = GlobalData:call("getEndTimeByStatus", oneInfo.statusId)
				if self.v_skinMark then
					oneInfo.mark = tonumber(self.v_skinMark[oneInfo.statusId]) or 0
				end
				local tt = ret[i]
				tt[#tt + 1] = oneInfo
				active[oneInfo.itemId] = true
				self.wardrobeActivityIdxTab[i] = ainfo:call("getItemId")
			end
		end
	end
	-- dump(ret, "ret_1")

	-- 背包里的
	local function invoke( info )
		-- 取消资源未下载完成的限制
		-- if 
		-- 	-- info:call("isResOk") == false 
		-- 	-- and 
		-- 	AvatarType_Civ ~= info:call("getAvatarType") then
		-- 	return true
		-- end

		local itemId = info:call("getItemId")
		local tinfo = ToolController:call("getToolInfoForLua", itemId)
		if nil == tinfo then
			return true
		end
		if tinfo:call("getCNT") == 0 then
			return true
		end
		if info:call("isHiddenInWardrobe") == true then
			return true
		end

		local atype = info:call("getAvatarType")
		if atype == AvatarType_ActivityEffect then 
			return true
		end
		ret[atype] = ret[atype] or {}
		local oneInfo = AvatarViewWardrobeShowInfo.new()
		oneInfo.isInBag = true
		oneInfo.itemId = info:call("getItemId")
		oneInfo.endTime = 0
		if self.v_skinMark then
			oneInfo.mark = tonumber(self.v_skinMark[info:call("getStatusId")]) or 0
		end
		local tt = ret[atype]
		tt[#tt + 1] = oneInfo
		return true
	end

	self:dumpAvatarListForLua(invoke)
	-- dump(ret, "ret_2")

	-- 衣柜里的
	local now = GlobalData:call("getWorldTime")
	local function invokeWardrobe( winfo )
		local endTime = winfo:getProperty("endTime")
		if endTime > now or endTime == -1 then
			local ainfo = self:call("getAvatarInfoByStatusId", winfo:getProperty("status"))
			if ainfo then
				local atype = ainfo:call("getAvatarType")
				if atype == AvatarType_ActivityEffect then 
					return true
				end
				ret[atype] = ret[atype] or {}
				local oneInfo = AvatarViewWardrobeShowInfo.new()
				oneInfo.isInBag = false
				oneInfo.itemId = ainfo:call("getItemId")
				oneInfo.statusId = ainfo:call("getStatusId")
				oneInfo.endTime = endTime
				oneInfo.tempTakeOff = true
				if self.v_skinMark then
					oneInfo.mark = tonumber(self.v_skinMark[oneInfo.statusId]) or 0
				end
				local tt = ret[atype]
				tt[#tt + 1] = oneInfo
			end
		end
		return true
	end
	self:dumpWardrobeForLua(invokeWardrobe)
	-- dump(ret, "ret_3")

	-- 默认
	for k,v in pairs(ret) do
		local oneInfo = AvatarViewWardrobeShowInfo.new()
		oneInfo.isInBag = false
		oneInfo.itemId = k
		oneInfo.endTime = -1
		local tt = ret[k]
		tt[#tt + 1] = oneInfo
	end
	self.m_inSellType = self.m_inSellType or {}
	-- dump(self.m_inSellType, "self.m_inSellType")
	for i=AvatarType_Castle,AvatarType_MAX - 1 do
		if nil ~= self.m_inSellType[i] then
			ret[i] = ret[i] or {}
		end
	end
	-- dump(ret, "ret_4")

	-- 排序
	local function sortRule( info1, info2 )
		if info1.itemId < 200 and info2.itemId > 200 then
			return true
		elseif info1.itemId > 200 and info2.itemId < 200 then
			return false
		else
			if active[info1.itemId] == true and active[info2.itemId] ~= true then
				return true
			elseif active[info1.itemId] ~= true and active[info2.itemId] == true then
				return false
			else
				if info1.isInBag == false and info2.isInBag == true then
					return true
				elseif info1.isInBag == true and info2.isInBag == false then
					return false
				elseif info1.isInBag == false and info2.isInBag == false then
					if info1:isYongjiuStatus() and info2:isYongjiuStatus() == false then
						return true
					elseif info1:isYongjiuStatus() == false and info2:isYongjiuStatus() then
						return false
					else
						return info1.itemId > info2.itemId
					end
				else
					return info1.itemId > info2.itemId
				end
			end
		end
	end
	for k,v in pairs(ret) do
		table.sort( v, sortRule )
	end
	-- dump(ret, "ret1+++++++")
	ret = self:filterCivFortDataWardrobe(ret)

	-- 全部
	if CCCommonUtilsForLua:isFunOpenByKey("skin_mall") then
		local _allData = {}
		for k,v in pairs(ret) do
			for _,vv in pairs(v) do
				vv.tag = k
				table.insert(_allData, vv)
			end
		end
		ret[AvatarType_None] = _allData
	end
	return ret
end

function AvatarController:filterCivFortDataWardrobe(data)
	if CCCommonUtilsForLua:isFunOpenByKey("fortress_avatar") then
		return data
	end
	local tblRet = {}
	for k,v in pairs(data) do 
		if k ~= AvatarType_CivFort then
			tblRet[k] = v
		end
	end
	-- dump(tblRet, "ret2+++++++")
	return tblRet
end

-- 只用于宝箱物品
function AvatarController:buyItem (itemId, messagePosted)
	MyPrint('AvatarController:buyItem', itemId)
	local sellItemInfo = self.avatarShopConfig[itemId]
	if nil == sellItemInfo then
		return
	end
	self.sellitemid = sellItemInfo.id
	local value1 = tonumber(sellItemInfo.value1) --sellItemInfo:getProperty("m_value1")
	local value1_type = tonumber(sellItemInfo.value1_type)

	-- if money insufficient
	if value1_type == 8 then
		if value1 > PlayerInfoController:getCrystalGold() then
			local view = Drequire("game.CommonPopup.ItemGetMethodView"):create("500003")
			PopupViewController:call("addPopupView", view)
			return
		end
	else
		if value1 > GlobalData:call("getPlayerInfo"):getProperty("gold") then
			YesNoDialog:call("gotoPayTips")
			return
		end
	end	

	local StoreBuyConfirmDialogForLua = Drequire("game.CommonPopup.StoreBuyConfirmDialogForLua")
    local params = {}
    params.itemId = tostring(itemId)
    params.maxNum = math.floor(PlayerInfoController:getCrystalGold() / value1)
    params.messagePosted = messagePosted
    params.singlePoint = value1 -- single price
    params.hasNum = PlayerInfoController:getCrystalGold()
    params.moneyIcon = 'diamond.png'
    params.id = ""
    params.isShowSelect = 1
    params.isNeedStore = 1
    local view = StoreBuyConfirmDialogForLua:create(params)
    PopupViewController:addPopupView(view)
end

function AvatarController:getSellPrice( itemId )
	-- local sellitemid = ToolController:call("getAvatarSellMapIdByItemId", itemId)
	-- local sellItemInfo = ToolController:call("getSellItemInfoBySellId", sellitemid)
	local sellItemInfo = self.avatarShopConfig[itemId]
	if nil == sellItemInfo then
		return 999999
	end
	-- local price = sellItemInfo:getProperty("m_value1")
	local price = tonumber(sellItemInfo.value1)
	return price
end

-- 衣柜 背包 身上 是否有该皮肤
function AvatarController:isAlreadyHave( itemId )
	-- MyPrint("AvatarController:isAlreadyHave ", itemId)
	if itemId < 200 then
		return false
	end
	local ainfo = self:call("getAvatarInfoByGoodsId", itemId)
	if nil == ainfo then
		return false
	end
	if self:call("getActiveItemByType", ainfo:call("getAvatarType")) == itemId then
		MyPrint("active is itemId")
		return true
	end
	if self:isAlreadyHaveInWardrobeData(itemId) then
		return true
	end
	local tinfo = ToolController:call("getToolInfoForLua", itemId)
	if tinfo and tinfo:call("getCNT") > 0 then
		MyPrint("itemId tinfo:getCNT ", tinfo:call("getCNT"))
		return true
	end
	-- MyPrint("not have .... ", itemId)
	return false
end

-- 衣柜 身上 是否有该皮肤
function AvatarController:isAlreadyHaveAndOpen( itemId )
	-- MyPrint("AvatarController:isAlreadyHave ", itemId)
	if itemId < 200 then
		return false
	end
	local ainfo = self:call("getAvatarInfoByGoodsId", itemId)
	if nil == ainfo then
		return false
	end
	if self:call("getActiveItemByType", ainfo:call("getAvatarType")) == itemId then
		MyPrint("active is itemId")
		return true
	end
	if self:isAlreadyHaveInWardrobeData(itemId) then
		return true
	end
	-- MyPrint("not open .... ", itemId)
	return false
end

function AvatarController:isAlreadyHaveInWardrobeData( itemId )
	-- MyPrint("AvatarController:isAlreadyHaveInWardrobeData ", itemId)
	local ret = false
	local ainfo = self:call("getAvatarInfoByGoodsId", itemId)
	if nil == ainfo then
		return false
	end
	local now = GlobalData:call("getWorldTime")
	local function invokeWardrobe( winfo )
		if winfo:getProperty("status") ~= ainfo:call("getStatusId") then
			return true
		end
		local endTime = winfo:getProperty("endTime")
		if endTime > now or endTime == -1 then
			ret = true
			return false
		end
		return true
	end
	self:dumpWardrobeForLua(invokeWardrobe)
	-- MyPrint("ret ", ret)
	return ret
end

-- face_kula  xxx_out  xxx_chuzheng  xxx_gongji xxx_1_10
-- march_pukeren_face
-- Nameplate_chrismas_face
function AvatarController:getStatusIdByCfgName( name )
	if not self.xmlDataRule then 
		-- dump(getTimeStamp(), "downloadAvatar+++ begin")
		local xmlDataRule = CCCommonUtilsForLua:getGroupByKey("status")
		self.xmlDataRule = {}
		for k,v in pairs(xmlDataRule) do 
			if v.effectart and v.id and not self.xmlDataRule[v.effectart] then 
				self.xmlDataRule[v.effectart] = tonumber(v.id)
			end
		end
		-- dump(getTimeStamp(), "downloadAvatar+++ end")
	end
	if self.xmlDataRule[name] ~= nil then
		-- dump(name,"AvatarFaceShowView:delayAvatar+++ find in cache")
		return self.xmlDataRule[name]
	else
		--【Awen】优化查找
		local _configItems = string.split(name, '_')
		if #_configItems > 2 then
			for i=1,#_configItems - 2 do
				local _configNew = ''
				local _length = #_configItems - i
				for ii=1,_length do
					_configNew = _configNew .. _configItems[ii]
					if ii < _length then
						_configNew = _configNew .. '_'
					end
				end
				-- dump(_configNew," 1AvatarFaceShowView:delayAvatar+++ find in cache 2")
				if self.xmlDataRule[_configNew] then
					-- dump(_configNew," 1AvatarFaceShowView:delayAvatar+++ find in cache 3")
					return self.xmlDataRule[_configNew]
				end
			end
		end
	end
	for k,v in pairs(self.xmlDataRule) do 
		local from = string.find(name, k) --皮肤
		if from == 1 then
			self.xmlDataRule[name] = v
			return v
		end
	end
	return 0
end

--===============================================================
local MALLID = 15
--[[ 获取商城数据 ]]
local AvatarMallDataCmd = class("AvatarMallDataCmd", LuaCommandBase)
function AvatarMallDataCmd.req(mallId)
    -- Dprint("AvatarController: AvatarMallDataCmd.req", mallId)
	local ret = AvatarMallDataCmd.new()
	ret:initWithName("mall.data")
	ret:putParam("mallId", CCString:create(tostring(mallId)))
	ret:send()
end

function AvatarMallDataCmd:handleReceive(dict)
    local flag, params = self:parseMsg(dict)
    -- Dprint("AvatarController: AvatarMallDataCmd:handleReceive | parse flag=", flag)
    if (type(flag) == "boolean") then
        return flag
	end

	AvatarController:getInstance():ackStoreData(flag)
	return true
end

function AvatarController:reqStoreData()
	AvatarMallDataCmd.req(MALLID)
end

-- 注: 若策划需要换第四个切页的商品 改这个AvatarType_ForthTag对应的货币的id就行
function AvatarController:getCurrIdMap(  )
	local currIdMap = self.m_currId2AvatarType
	if not currIdMap then
		currIdMap = {
			['36001711'] = AvatarType_ForthTag,
			['215206'] = AvatarType_MysteryPiece,
		}
		self.m_currId2AvatarType = currIdMap
	end
	return currIdMap
end

function AvatarController:currIdToAvatarType( currId )
	if not currId then
		return
	end
	local currIdMap = self:getCurrIdMap()
	return currIdMap[currId]
end

function AvatarController:avatarTypeToCurrId( tType )
	if not tType then
		return
	end

	local currIdMap = self:getCurrIdMap()
	for k,v in pairs(currIdMap) do
		if v == tType then
			return k
		end
	end
end

function AvatarController:ackStoreData(data)
	self.avatarShopConfig = {}
	for i,v in ipairs(data.goodsArray) do
		local _itemId = tonumber(v.itemId)
		local _ainfo = self:call("getAvatarInfoByGoodsId", _itemId)
		if _ainfo then
			-- 对应新老类型
			local _priceType = tonumber(v.currType) or 0
			if v.currType == '2' then		--// 钻石
				_priceType = 8
			elseif v.currType == '3' then	--// 道具兑换
				_priceType = 11
			end
			self.avatarShopConfig[_itemId] = {
				item_id = _itemId, 
				value1_type = _priceType, 
				value1 = v.price, 
				times = v.canBuyTimes,
				display = CCCommonUtilsForLua:call("getPropByIdGroup","skin_mall",v.targetId,"index"),
				id = v.targetId,
				currId = v.currId,
			}
		end
	end

	self.avatarShopData = {}
	for k,v in pairs(self.avatarShopConfig) do
		local atype = AvatarType_Coin
		local aa_type = self:currIdToAvatarType(v.currId)
		if aa_type then
			atype = aa_type
		else
			if 8 == v.value1_type then -- 钻石购买
				atype = AvatarType_Diamond
			elseif 11 == v.value1_type then -- 神秘礼盒碎片购买
				atype = AvatarType_MysteryPiece
			end
		end
		self.avatarShopData[atype] = self.avatarShopData[atype] or {}
		table.insert(self.avatarShopData[atype], v.item_id)
	end

    CCSafeNotificationCenter:postNotification("MSG_AVATAR_INIT")
end

function AvatarController:_hasAvatarTypeInStoreTag( tType )
	return not not (self.avatarShopData and self.avatarShopData[tType])
end

function AvatarController:has_AvatarType_ForthTag(  )
	return self:_hasAvatarTypeInStoreTag(AvatarType_ForthTag)
end

-- 当用道具购买商品时 要确定是哪种道具 默认为 215206(神秘碎片)
function AvatarController:getItemCurrId( sellItemInfo )
	return sellItemInfo and sellItemInfo.currId or "215206"
end

function AvatarController:getItemDefaultCurrId(  )
	local tstr = self:avatarTypeToCurrId(AvatarType_MysteryPiece)
	return tonumber(tstr) or 215206 --神秘碎片
end

----------------------------------
--[[ 购买物品 ]]
local AvatarMallBuyCmd = class("AvatarMallBuyCmd", LuaCommandBase)
function AvatarMallBuyCmd.req(mallId, itemId, count)
    -- Dprint("AvatarController: AvatarMallBuyCmd.req", mallId, itemId, count)
	local ret = AvatarMallBuyCmd.new()
	ret:initWithName("mall.buy")
	ret:putParam("mallId", CCString:create(tostring(mallId)))
	ret:putParam("targetId", CCString:create(tostring(itemId)))
	ret:putParam("num", CCInteger:create(count))
	ret:send()
end

function AvatarMallBuyCmd:handleReceive(dict)
    local flag, params = self:parseMsg(dict)
    -- Dprint("AvatarController: AvatarMallBuyCmd:handleReceive | parse flag=", flag)
    if (type(flag) == "boolean") then
        return flag
	end
	DressIntroductionController:pullDressIntrData()
	-- 购买物品后的金币、道具变化都通过其他推送来处理
	return true
end

function AvatarController:reqBuyItem(itemId, count)
	AvatarMallBuyCmd.req(MALLID, itemId, count)
end

----------------------------------
--[[ 皮肤数据 ]]
local AvatarSkinDataCmd = class("AvatarSkinDataCmd", LuaCommandBase)
function AvatarSkinDataCmd.req()
	-- Dprint("AvatarController: AvatarSkinDataCmd.req")
	local ret = AvatarSkinDataCmd.new()
	ret:initWithName("skin.avatar_data")
	ret:send()
end

function AvatarSkinDataCmd:handleReceive(dict)
    local flag, params = self:parseMsg(dict)
    -- Dprint("AvatarController: AvatarSkinDataCmd:handleReceive | parse flag=", flag)
    if (type(flag) == "boolean") then
        return flag
    end
	
	AvatarController:getInstance():ackSkinData(flag)
	return true
end

function AvatarController:reqSkinData()
	AvatarSkinDataCmd.req()
end

function AvatarController:ackSkinData(data)
	self.v_skinMark = {}
	for k,v in pairs(data.markAvatarIds or {}) do
		self.v_skinMark[tonumber(v)] = 1
	end
end

----------------------------------
--[[ 一键使用 ]]
local AvatarSkinBatchCmd = class("AvatarSkinBatchCmd", LuaCommandBase)
function AvatarSkinBatchCmd.req(itemIds)
    -- Dprint("AvatarController: AvatarSkinBatchCmd.req", itemIds)
	local ret = AvatarSkinBatchCmd.new()
	ret:initWithName("avatar.batch_activate")
	ret:putParam("avatarIds", CCString:create(tostring(itemIds)))
	ret:send()
end

function AvatarSkinBatchCmd:handleReceive(dict)
    local flag, params = self:parseMsg(dict)
    -- Dprint("AvatarController: AvatarSkinBatchCmd:handleReceive | parse flag=", flag)
    if (type(flag) == "boolean") then
        return flag
	end
	-- dump(flag, "AvatarController: AvatarSkinBatchCmd:handleReceive")
	
	AvatarController:getInstance():ackBatchActive(params)
	return true
end

function AvatarController:reqBatchActive(itemIds)
	AvatarSkinBatchCmd.req(itemIds)
end

function AvatarController:ackBatchActive(data)
	-- Dprint("AvatarController:ackBatchActive")
	if data:objectForKey("statusObj") then
		local _allKeys = data:objectForKey("statusObj"):allKeys()
		_allKeys = arrayToLuaTable(_allKeys)
		for i,v in ipairs(_allKeys) do
			AvatarController:call("handleActiveAvatar", data:objectForKey("statusObj"):objectForKey(v))
		end
	end
	if data.enchant_skills then
		DressIntroductionController:processFuMoSkills(data.enchant_skills)
	end
end

----------------------------------
--[[ 设置偏好 ]]
local AvatarSkinLikeCmd = class("AvatarSkinLikeCmd", LuaCommandBase)
function AvatarSkinLikeCmd.req(statusIds, isMark)
	-- Dprint("AvatarController: AvatarSkinLikeCmd.req", statusIds, isMark)
	local ret = AvatarSkinLikeCmd.new()
	ret:initWithName("skin.mark")
	ret:putParam("avatarIds", CCString:create(statusIds))
	ret:putParam("mark", CCBool:create(isMark))
	ret:send()
end

function AvatarSkinLikeCmd:handleReceive(dict)
    local flag, params = self:parseMsg(dict)
    -- Dprint("AvatarController: AvatarSkinLikeCmd:handleReceive | parse flag=", flag)
    if (type(flag) == "boolean") then
        return flag
    end
	
	AvatarController:getInstance():ackLike(flag)
	return true
end

function AvatarController:reqLike(statusIds, isMark)
	AvatarSkinLikeCmd.req(statusIds, isMark)
end

function AvatarController:ackLike(data)

	local _statusIds = string.split(data.infoDic.avatarIds, ';')
	for i,v in ipairs(_statusIds) do
		self.v_skinMark[tonumber(v)] = data.infoDic.mark and 1 or 0
	end

    CCSafeNotificationCenter:postNotification("MSG_AVATAR_ACTIVE_WARDROBE_STATUS_BACK")
end

function AvatarController:tryStoreStatus( tbl,use_when_get )
	local aw = self:getAllATypeAndItemsInWardrobe()
	local all_status = {}
	for k,v in pairs(aw) do
		table.append(all_status,table.findAll(v,function ( cur )
			return not cur.isInBag
		end))
	end
	
	local expirationTime = GlobalDataCtr.changeTime((tonumber(tbl.expirationTime) or 0 )/1000)
	local statusId = tonumber(tbl.avatar)
	local activeOne = table.find(all_status,function ( cur )
		return cur.statusId and cur.statusId == statusId
	end)

	repeat
		-- 激活时正穿在身上
		if activeOne and not activeOne.tempTakeOff then
			local statusMap = GlobalData:call("shared"):getProperty("statusMap")
			statusMap[statusId] = expirationTime
			GlobalData:call("shared"):setProperty("statusMap",statusMap)
			statusMap = GlobalData:call("shared"):getProperty("statusMap")

			return
		end

		-- 激活时没穿在身上,但放在衣柜里
		if activeOne and activeOne.tempTakeOff then
			AvatarController:call("removeWardrobeStatus", statusId)
			break
		end

		-- 激活时没有该光环(背包里的道具也算该情况)
	until true

	AvatarController:call("storeStatus", statusId, expirationTime)

	local itemId = activeOne and activeOne.itemId
	if activeOne then
		itemId = activeOne.itemId
	else
		itemId = CCCommonUtilsForLua:call("getPropByIdGroup","status",tostring(statusId),"itemId")
	end

	if not string.isNilOrEmpty( itemId ) then
		self:getStoreStatusEvent():emit(tonumber(itemId))
	end
end

function AvatarController:getStoreStatusEvent(  )
	local storStatus = self.m_storStatus
	if not storStatus then
	    storStatus = utils.getEventClass(  ):create()
	    self.m_storStatus = storStatus
	end
	return storStatus
end

function AvatarController:findNot_Coin_Diamon_Mestery( storeTag )
	local r = {AvatarType_Coin,AvatarType_Diamond,AvatarType_MysteryPiece}
	for _,v in ipairs(storeTag) do
		if not table.contains(r,v) then
			return v
		end
	end
end

function AvatarController:getStatusInfoByItemId( itemId, key )
	local itemId2StatusId = self.m_itemId2StatusId
    if not itemId2StatusId then
        itemId2StatusId = {}
        local status_data = CCCommonUtilsForLua:getGroupByKey("status")
        for k,v in pairs(status_data) do
            if v.itemId then
                itemId2StatusId[v.itemId] = k
            end
        end
        self.m_itemId2StatusId = itemId2StatusId
    end

    local sid = itemId2StatusId[itemId]
    if sid then
        key = key or "id"
        return CCCommonUtilsForLua:call("getPropByIdGroup", "status", sid, key), sid
    end
end

function AvatarController:getPermanentSkinByItemId( itemId, type2 )
	if not type2 then
		return false
	end
	local aw = AvatarController:getInstance():getAllATypeAndItemsInWardrobe()
	local data_tab = aw[tonumber(type2)]
	if not data_tab then
		return false
	end
	local find_info = table.find(data_tab,function ( cur )
		return (cur.itemId == itemId) and (not cur.isInBag)
	end)
	return not not find_info
end

function AvatarController:_ensurePernameIdx( skin_idx )
	-- (永久.可赠送) 9441839
	return skin_idx == "9441839" and "9401055" or skin_idx
end

function AvatarController:hasPermanentSkin( itemId )
	local status_data = CCCommonUtilsForLua:getGroupByKey("goods")
	local cur_data = status_data[tostring(itemId)]

	if cur_data and cur_data.type2 then
		local skin_str = cur_data.skin
		local skin_idx = self:_ensurePernameIdx(string.split(skin_str,"|")[2])
		local delta = tonumber(skin_idx) - 9401050
		local per_item_id = tonumber(itemId) + 5 - delta
		local flag = self:getPermanentSkinByItemId(per_item_id,cur_data.type2)
		if flag then
			local per_data = status_data[tostring(per_item_id)]
			return flag,per_data
		end
	end
	return false
end

function AvatarController:isPermanentSkin( itemId,status_data )
	status_data = status_data or CCCommonUtilsForLua:getGroupByKey("goods")
	local cur_data = status_data[tostring(itemId)]

	if cur_data then
		local skin_str = cur_data.skin
		if string.isNilOrEmpty( skin_str ) then
			return false
		end
		local skin_str_arr = string.split(skin_str,"|")
		if #skin_str_arr < 2 then
			return false
		end
		local skin_idx = self:_ensurePernameIdx(skin_str_arr[2])
		local delta = tonumber(skin_idx) - 9401050
		local per_item_id = tonumber(itemId) + 5 - delta
		return tonumber(itemId) == per_item_id
	end
	return false
end

function AvatarController:findPermanentStatusId(statusId)
	local goodsId = CCCommonUtilsForLua:call("getPropByIdGroup","status",tostring(statusId),"itemId")
	if string.isNilOrEmpty(goodsId) then
		return statusId
	end
	local tbl = CCCommonUtilsForLua:getPropDictByIdGroup("goods",goodsId)
	if table.isNilOrEmpty(tbl) then
		return statusId
	end
	local skin_idx = self:_ensurePernameIdx(string.split(tbl.name,"|")[3])
    local delta = tonumber(skin_idx) - 9401050
    local per_goods_id = tonumber(goodsId) + 5 - delta
    local new_statusId = CCCommonUtilsForLua:call("getPropByIdGroup","goods",tostring(per_goods_id),"para1")
    return new_statusId
end

-- 通过itemId 找到头像框配置
function AvatarController:findHeadFrameInfoByItemId( itemId )
	if not itemId then
		return
	end
	
	local status_id = self:getStatusInfoByItemId( itemId, 'id' )
	if string.isNilOrEmpty(status_id) then
		return
	end

	local tbl = CCCommonUtilsForLua:getPropDictByIdGroup("status",status_id)

	local frameID = tbl.frameID
	if not frameID then
		return
	end

	local tbl_frame = CCCommonUtilsForLua:getPropDictByIdGroup("lord_image_frame",frameID)
	if not tbl_frame then
		return
	end

	return tbl_frame
end

--皮肤类道具使用放到这里特殊处理下
function AvatarController:checkUseTool( itemId )
	local toolInfo = ToolController:call("getToolInfoForLua", itemId)
	if not toolInfo then
        return
    end
	local itemName = toolInfo:call("getName")
	local avatarType = toolInfo:getProperty("type2")
	local ainfo = AvatarController:getInstance():call("getAvatarInfoByGoodsId", itemId)
	if ainfo then
		-- 二次确认下type
		avatarType = ainfo:call("getAvatarType")
	end
	local skinScaleMgrIns = require('game.skinScale.SkinScaleMgr').getInstance()
	if avatarType and skinScaleMgrIns:checkIsSkinScaleType(avatarType) 
	and skinScaleMgrIns:checkIsAllMatchStatus() then
		local function func()
			-- skinScaleMgrIns:tryShowConfirmView(itemId)
			ToolController:call("useTool", itemId, 1, true)
		end
		YesNoDialog:call("show", getLang("52132231", itemName), cc.CallFunc:create(func))
	else
		local function callback()
			ToolController:call("useTool", itemId, 1, true)
		end
		YesNoDialog:call("show", getLang("104955", itemName), cc.CallFunc:create(callback))
	end
end