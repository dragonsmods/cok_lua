--[[	
	装备夺宝抽奖Item
	2019.5.13	Xu
]]
local AvatarDuoBaoDrawMallCell = class( "AvatarDuoBaoDrawMallCell", function() return cc.Layer:create() end )

function AvatarDuoBaoDrawMallCell:create()
    local cell = AvatarDuoBaoDrawMallCell.new()
    Drequire("game.avatar.AvatarDuoBaoDrawMallCell_ui"):create(cell, 0)
    cell:initView()
    return cell
end

function AvatarDuoBaoDrawMallCell:initView()
    registerTouchHandler(self)
    self:setTouchEnabled(true)
    self:setSwallowsTouches(false)
    self.v_dressName = {}
    for _,v in pairs(CCCommonUtilsForLua:getGroupByKey("dress_introduction") or {}) do
        self.v_dressName[v.goods_id] = v.dialog_id
    end
end

function AvatarDuoBaoDrawMallCell:refreshCell(data, idx)
    self.v_data = data
    for i=1,2 do
        local _item = data[i]
        if _item then
            self.ui['m_nodeItem'..i]:setVisible(true)
            local _tInfo= ToolController:call("getToolInfoByIdForLua", tonumber(_item.itemId))

            local nameStr
            -- if self.v_dressName[_item.itemId] then
            --     nameStr = getLang(self.v_dressName[_item.itemId])
            -- else
            --     nameStr = _tInfo:call("getName")
            -- end
            nameStr = "1"
            -- 商品名称
            self.ui['m_labelTitle'..i]:setString(nameStr) --(_tInfo:call("getName"))
            -- 商品图标
            -- local _iconSpr = CCLoadSprite:createSprite(_tInfo:getProperty("icon")..".png")
            self.ui['m_nodeIcon'..i]:removeAllChildren()
            -- if _iconSpr then
            --     self.ui['m_nodeIcon'..i]:addChild(_iconSpr)
            -- end
            local itemData = {
                type = 0,
                itemId = _item.itemId,
                num = 1
            }
            local icon_node = CCNode:create()
            local iconSize = 160
            local LibaoCommonFunc = Drequire("game.LiBao.LibaoCommonFunc")
            LibaoCommonFunc.createItemInfoShow(itemData, icon_node, iconSize, nil, nil, nil, true)
            self.ui['m_nodeIcon'..i]:addChild(icon_node)
            icon_node:getChildByTag(GOODS_BG_TAG):setVisible(false)

            -- 价格
            self.ui['m_labelPrice'..i]:setString(_item.price)
            -- 货币
            local _cInfo= ToolController:call("getToolInfoByIdForLua", tonumber(_item.currId))
            local _iconCurrSpr = CCLoadSprite:createSprite(_cInfo:getProperty("icon")..".png")
            self.ui['m_nodeCurr'..i]:removeAllChildren()
            if _iconCurrSpr then
                CCCommonUtilsForLua:call('setSpriteMaxSize',_iconCurrSpr, 40, false)
                self.ui['m_nodeCurr'..i]:addChild(_iconCurrSpr)
            end
        else
            self.ui['m_nodeItem'..i]:setVisible(false)
        end
    end
end

function AvatarDuoBaoDrawMallCell:onClickItem1()
        local view = myRequire("game.avatar.AvatarDuoBaoDrawMallBuyView").create(self.v_data[1])
        PopupViewController:call("addPopupView", view) 
end

function AvatarDuoBaoDrawMallCell:onClickItem2()
        local view = myRequire("game.avatar.AvatarDuoBaoDrawMallBuyView").create(self.v_data[2])
        PopupViewController:call("addPopupView", view) 
end
-- function AvatarDuoBaoDrawMallCell:onTouchBegan(x, y)
--     for i=1,2 do
--         if self.ui['m_nodeItem'..i]:isVisible() then
--             if isTouchInsideVis(self.ui['m_itemBuy'..i], x, y) then
--                 return true
--             end
--         end
--     end
--     return false
-- end

-- function AvatarDuoBaoDrawMallCell:onTouchEnded(x, y)
--     for i=1,2 do
--         if isTouchInsideVis(self.ui['m_itemBuy'..i], x, y) then
--             local view = myRequire("game.avatar.AvatarDuoBaoDrawMallBuyView").create(self.v_data[i])
--             PopupViewController:call("addPopupView", view) 
--         end
--     end
-- end

return AvatarDuoBaoDrawMallCell
