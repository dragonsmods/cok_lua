--[[	
	装备夺宝抽奖
	2019.5.13	Xu
]]

local CMD_DUOBAO_DRAW_VIEW = 'gamble.data'
local CMD_DUOBAO_DO_DRAW = 'gamble.lottery'
local CMD_DUOBAO_BOX_REWARD = 'gamble.box_reward'
local CMD_DUOBAO_MALL_VIEW = 'mall.data'
local CMD_DUOBAO_BUY_ITEM = 'mall.buy'

--server 请求数据命令
local AvatarDuoBaoDrawViewCmd = class("AvatarDuoBaoDrawViewCmd", LuaCommandBase)
function AvatarDuoBaoDrawViewCmd:ctor (ctl, params, cb)
	self.super.ctor(self, CMD_DUOBAO_DRAW_VIEW)
	self.ctl = ctl
	self.cb = cb
	self:putParam("gambleType", CCInteger:create(params.gambleType))
	MyPrint("AvatarDuoBaoDrawViewCmd new")
end

function AvatarDuoBaoDrawViewCmd:handleReceive (dict)
	local tbl = self:parseMsg(dict)
	if type(tbl) == "boolean" then
		return tbl
	end
	if self.cb then
		self.cb(tbl)
	end
	return true
end

--server 请求数据命令
local AvatarDuoBaoDoDrawCmd = class("AvatarDuoBaoDoDrawCmd", LuaCommandBase)
function AvatarDuoBaoDoDrawCmd:ctor (ctl, params, cb)
	self.super.ctor(self, CMD_DUOBAO_DO_DRAW)
	self.ctl = ctl
	self.cb = cb
	self:putParam("gambleType", CCInteger:create(params.gambleType))
	self:putParam("num", CCInteger:create(params.num))
	self:putParam("useFree", CCBool:create(params.useFree))
	if params.videoType then
		self:putParam("videoType", CCInteger:create(params.videoType))
	end
	MyPrint("AvatarDuoBaoDoDrawCmd new")
end

function AvatarDuoBaoDoDrawCmd:handleReceive (dict)
	local tbl = self:parseMsg(dict)
	if type(tbl) == "boolean" then
		return tbl
	end
	if self.cb then
		self.cb(tbl)
	end
	return true
end

--server 请求数据命令
local AvatarDuoBaoBoxRewardCmd = class("AvatarDuoBaoBoxRewardCmd", LuaCommandBase)
function AvatarDuoBaoBoxRewardCmd:ctor (ctl, params, cb)
	self.super.ctor(self, CMD_DUOBAO_BOX_REWARD)
	self.ctl = ctl
	self.cb = cb
	self:putParam("gambleType", CCInteger:create(params.gambleType))
	self:putParam("targetIndex", CCInteger:create(params.targetIndex))
	MyPrint("AvatarDuoBaoBoxRewardCmd new")
end

function AvatarDuoBaoBoxRewardCmd:handleReceive (dict)
	
	local tbl = self:parseMsg(dict)
	if type(tbl) == "boolean" then
		return tbl
	end
	if self.cb then
		self.cb(tbl)
	end
	return true
end

--server 请求数据命令
local AvatarDuoBaoMallViewCmd = class("AvatarDuoBaoMallViewCmd", LuaCommandBase)
function AvatarDuoBaoMallViewCmd:ctor (ctl, params, cb)
	self.super.ctor(self, CMD_DUOBAO_MALL_VIEW)
	self.ctl = ctl
	self.cb = cb
	self:putParam("mallId", CCString:create("100"))
	MyPrint("AvatarDuoBaoMallViewCmd new")
end

function AvatarDuoBaoMallViewCmd:handleReceive (dict)
	
	local tbl = self:parseMsg(dict)
	if type(tbl) == "boolean" then
		return tbl
	end
	if self.cb then
		self.cb(tbl)
	end
	return true
end

-------------------

local AvatarDuoBaoBuyItemCmd = class("AvatarDuoBaoBuyItemCmd", LuaCommandBase)

function AvatarDuoBaoBuyItemCmd:ctor (ctl, params, cb)
	self.ctl = ctl
	self.cb = cb
	self.super.ctor(self, CMD_DUOBAO_BUY_ITEM)
	self:putParam("mallId", CCString:create("100"))
	self:putParam("targetId", CCString:create(params.targetId))
	self:putParam("num", CCInteger:create(params.num))
	MyPrint("AvatarDuoBaoBuyItemCmd new")
end

function AvatarDuoBaoBuyItemCmd:handleReceive (dict)
	
	local tbl = self:parseMsg(dict)
	if type(tbl) == "boolean" then
		return tbl
	end
	if self.cb then
		self.cb(tbl)
	end
	return true
end

local function createCmd (type, ctl, params, cb)
	if type == 'info' then
		return AvatarDuoBaoDrawViewCmd.new(ctl, params, cb)
	elseif type == 'draw' then
		return AvatarDuoBaoDoDrawCmd.new(ctl, params, cb)
	elseif type == 'box' then
		return AvatarDuoBaoBoxRewardCmd.new(ctl, params, cb)
	elseif type == 'mall' then
		return AvatarDuoBaoMallViewCmd.new(ctl, params, cb)
	elseif type == 'buy' then
		return AvatarDuoBaoBuyItemCmd.new(ctl, params, cb)
	else
		MyPrint("createCmd Error: not cmdType", type)
	end
end
return {
	create = createCmd
}

