--[[	
	装备夺宝确认购买对话框
	2019.5.16	Awen	
]]
local AvatarDuoBaoDrawMallBuyView = class( "AvatarDuoBaoDrawMallBuyView", function() return PopupBaseView:create() end )
AvatarDuoBaoDrawMallBuyView.__index = AvatarFettersView

--------------------------------------------------------------------------------------
function AvatarDuoBaoDrawMallBuyView.create(data)
	local view = AvatarDuoBaoDrawMallBuyView.new()
	Drequire("game.avatar.AvatarDuoBaoDrawMallBuyView_ui"):create(view, 1)

	if view:initView(data) == false then
		return nil
	end
	return view
end

function AvatarDuoBaoDrawMallBuyView:initView(data)
	Dprint("AvatarDuoBaoDrawMallBuyView:initView")
	self.v_data = data
	-- 176828=您确实使用{0}个{1}兑换{2}吗？
	local _tInfo= ToolController:call("getToolInfoByIdForLua", tonumber(data.itemId))
	local _cInfo= ToolController:call("getToolInfoByIdForLua", tonumber(data.currId))
	self.ui.m_labelText:setString(getLang("176828", data.price, _cInfo:call("getName"), _tInfo:call("getName")))

	return true
end

-- 点击确定
function AvatarDuoBaoDrawMallBuyView:onClickBtnOK()
	self:closeSelf()
	require("game.avatar.AvatarDuoBaoDrawController"):requestBuyMallItem(self.v_data.targetId, 1, function (data)
		CCSafeNotificationCenter:postNotification('AvatarDuoBaoDrawMallView:refreshView')
		-- dump(data, "AvatarDuoBaoDrawMallBuyView:onClickBtnOK2")
		local tbl = {
			{
				type = "7",
				value = {
					itemId = self.v_data.itemId,
					rewardAdd = "1"
				}
			}
		}
		local _cArray = luaToArray(tbl)

		PortActController:call("flyReward", _cArray, true)
	end)
end

-- 点击取消
function AvatarDuoBaoDrawMallBuyView:onClickBtnCancel()
	self:closeSelf()
end

return AvatarDuoBaoDrawMallBuyView