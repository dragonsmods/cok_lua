AvatarMarchNode = class("AvatarMarchNode", function (  )
	return cc.Node:create()
end)
require("game.avatar.AvatarController")
-- isLuaAvatar=1    是否luaavatar
-- isArmyAvatar=1   是否为部队整体形象替换Avatar
-- isSoldierAvatar=1  是否为出征部队形象替换，保留了英雄和龙
-- animCnt=3
-- model3Dtexture=m_threeDragon     3D图片资源名
-- model3DName=c3b/dragon           3D资源名
-- model3DRotation=70,90,0        3D形象旋转
-- model3DScale=20
-- model3DAttackName=gongji         3D攻击动画名     这个不填，强制为gongji/feixing
-- model3DMoveName=feixing          3D移动动画名     这个不填，强制为gongji/feixing
-- model3DMoveParCnt=0              3D移动粒子
-- model3DMovePar1=TX_001,DragonFire_y,0,1          挂载点名字/粒子名/是否本地粒子/缩放
-- model3DAttackParCnt=1            3D攻击粒子
-- model3DAttackPar1=TX_001,DragonFire_y,0,1        挂载点名字/粒子名/是否本地粒子/缩放
-- AttackParCnt=2
-- AttackPar1=icedragon_0,150,50,1,0    
-- AttackPar2=icedragon_1,100,60,1,0
function AvatarMarchNode:ctor(data)
	-- dump(data, "1111111 AvatarMarchNode ctor config is: ")
	local config = data.configName
	local rotation = tonumber(data.rotation) or 0
	-- configName = "face_March_threeDragon"
	self.rootPath = CCFileUtils:sharedFileUtils():getWritablePath().."dresource/"
	local configData = AvatarController:getInstance():getAvatarConfigData(config)
	self.configData = configData
	-- dump(self.configData, "AvatarMarchNode:ctor configData is: ")

	local model3Dtexture = configData.model3Dtexture
    if configData.model3Dtexture == nil or configData.model3DName == nil then
        return
    end 

	local textureName = AvatarController:getInstance():getAvatar3DTextureName(model3Dtexture)
	local model = IFSprite3D:call("create", self.rootPath..configData.model3DName, textureName, "feixing")
	model:call("setTexture", textureName)
    model:call("useOrthographicProjecion", true)
    model:call("autoTabDefaultAction", true)
    model:setScale(tonumber(configData.model3DScale) or 1)

    local rotationTbl = string.split((configData.model3DRotation or "0,0,0"), ",")
    for i = 1, 3 do
        rotationTbl[i] = tonumber(rotationTbl[i]) or 0
    end

    -- rotationTbl = {40, 90, 0}
    self.rotationVec = cc.vec3(rotationTbl[1], rotation+rotationTbl[2], rotationTbl[3])
    -- dump(self.rotationVec, " self.rotationVec is: ")

    model:call("setRotation3D", self.rotationVec)

    self.rotation = rotation+90

    self.m_particleList = {}
    self.m_parNode = cc.Node:create()
    self:addChild(self.m_parNode)

    self.m_parBoneNode = cc.Node:create()
    self:addChild(self.m_parBoneNode)

    self.m_model = model
    self:addChild(model)
    self.convertTbl = {}

    -- self:setMarchState(data.marchType)
    self:setMarchState(1)
    registerNodeEventHandler(self)

    --     local node = cc.Node:create()
    --     node:setContentSize(40, 40)
    --     self:addChild(node)
    --     node:setAnchorPoint(cc.p(0, 0))
    --     addTestLayerColor(node, 100)


    -- local pos = self.m_model:call("GetBonePositon", boneName)
    -- dump(pos, "create AvatarMarchNode pos is: ")
    return self
end

function AvatarMarchNode:setMarchState(marchType)
    self.marchType = marchType
    self.m_particleList = {}
    self.m_parNode:removeAllChildren()
    self.m_parBoneNode:removeAllChildren()
	if marchType ~= 2 then
    	self.m_model:call("setAction", "feixing",true)
    else
    	self.m_model:call("setAction", "gongji",true)
    end
    -- 未完成的功能逻辑，暂停
    -- self:addParbyType(marchType)
end

function AvatarMarchNode:addParbyType(marchType)
    local key = "Move"
    if marchType == 2 then
        key = "Attack"
    end

    local parCnt = tonumber(self.configData[key.."ParCnt"]) or 0
    for i = 1, parCnt do
        local info = self.configData[key.."Par"..i]
        if info then
            local tbl = string.split(info, ",")
            -- 字段内容与其余皮肤保持一致
            -- ：粒子名称,坐标X,Y,是否在上面,是否在本地
            -- 是否在上面 暂时不需要
            local parPath = ""
            local particle = nil
            if tbl[5] == "1" then       -- "1"在本地
                particle = ParticleController:call("createParticle", tbl[1])
            else
                local path =self.rootPath.. "skinparticle/" .. tbl[1]
                particle = ParticleController:call("createParticleForLua", path)
            end
            if particle then
                particle:setPosition(cc.p(mainPos[1] + tbl[2], mainPos[2] + tbl[3]))
                particle:setContentSize(cc.size(9999, 9999))
                self.m_parNode:addChild(particle)
            end
        end
    end

    local parBoneCnt = tonumber(self.configData["model3D"..key.."ParCnt"]) or 0
    for i = 1, parBoneCnt do
        local info = self.configData["model3D"..key.."Par"..i]
        -- dump(info, "info is: ")
        local tbl = string.split(self.configData["model3D"..key.."Par"..i] or "", ",")
        -- dump(tbl, "tbl is: ")
        if #tbl == 4 then
            if tbl[3] == "1" then       -- "1"在本地
                particle = ParticleController:call("createParticle", tbl[2])
            else
                local path =self.rootPath.. "skinparticle/" .. tbl[2]
                particle = ParticleController:call("createParticleForLua", path)
            end
            -- dump(particle, "particle is: ")
            if particle then
                particle:setScale(tonumber(tbl[4]) or 1)
                self.m_particleList[#self.m_particleList + 1] = particle
                particle.boneName = tbl[1]
                self.m_parBoneNode:addChild(particle)
                particle:setAngle(self.rotationVec.y - 60)
            end
        end
    end
    if false then
        -- local par1 = ParticleController:call("createParticle", "Rose_3")
        -- self.m_parBoneNode:addChild(par1)
        -- self.m_particleList[#self.m_particleList + 1] = par1
        -- par1.boneName = "TX_001"
        -- local par2 = ParticleController:call("createParticle", "VIPGlow_3")
        -- self.m_parBoneNode:addChild(par2)
        -- par2.boneName = "TX_001"
        -- self.m_particleList[#self.m_particleList + 1] = par2

        local node = cc.Node:create()
        node:setContentSize(40, 40)
        self.m_parBoneNode:addChild(node)
        self.m_particleList[#self.m_particleList + 1] = node
        node.boneName = "TX_001"
        node:setAnchorPoint(cc.p(0, 0))
        addTestLayerColor(node, 255)
    end
    self:update(0)
end

function AvatarMarchNode:onEnter()
    self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:update(dt) end, 0.02, false)
end

function AvatarMarchNode:onExit()
    self:getScheduler():unscheduleScriptEntry(self.m_entryId)
    -- self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:update(dt) end, 0.02, false)
end

-- 3D坐标转为2D
function AvatarMarchNode:initConvert()
    self.convertTbl = {}
end
function AvatarMarchNode:convertV3ToV2(boneName)
    if not self.convertTbl[boneName] then
        local scale = self.m_model:getScale()
        local pos = self.m_model:call("GetBonePositon", boneName)
        dump(pos, " pos is: ")
        local x, y = 0, 0
        local angleX = math.deg(math.atan((0-pos.z)/pos.x))
        if pos.x < 0 and angleX > 0 then
            angleX = angleX + 180
        elseif pos.x < 0 and pos.z < 0 then
            angleX = angleX + 90
        end
        local dis = math.sqrt(math.pow(pos.x, 2) + math.pow(pos.z, 2))
        local newAngleX = (self.rotationVec.y + angleX)
        x = dis * math.cos(math.rad(newAngleX))

        local angleY = math.deg(math.atan((pos.z)/pos.y))
        dump("start angleY["..angleY.."] is: ")
        -- 下面不完善，但是没有详细数据，需要有挂点后再调整
        -- if pos.y < 0 and angleY > 0 then
        --     angleY = angleY + 180
        -- elseif pos.y < 0 and pos.z < 0 then
        --     angleY = angleY + 90
        -- end
        local dis = math.sqrt(math.pow(pos.y, 2) + math.pow(pos.z, 2))
        local newAngleY = (self.rotationVec.x + angleY)
        y = dis * math.cos(math.rad(newAngleY))
        -- dump(y, " newAngleY["..newAngleY.."] is: ")
        -- y = (y) * math.cos(math.rad(self.rotationVec.x))
        -- dump(y, " now is: ")
        -- y = 0 - math.abs(y) * math.cos(math.rad(self.rotationVec.y))

        self.convertTbl[boneName] = {x = x*scale, y=y*scale}
        -- dump(self.convertTbl[boneName], " self.convertTbl[boneName] is: ")
    end

    return self.convertTbl[boneName]
end

function AvatarMarchNode:update(dt)
    if #self.m_particleList > 0 then
        local scale = self.m_model:getScale()
        self:initConvert()
        for i, par in pairs(self.m_particleList) do
            local pos = self:convertV3ToV2(par.boneName)
            par:setPosition(cc.p(pos.x, pos.y))
        end
        self:initConvert()
    end

end

return AvatarMarchNode

