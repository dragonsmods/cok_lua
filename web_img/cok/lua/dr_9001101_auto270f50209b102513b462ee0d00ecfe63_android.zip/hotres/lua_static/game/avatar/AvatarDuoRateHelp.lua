-- @Author: tangwen
-- @Desc:   装扮夺宝概率界面
-- @Note:   None

local superClass = Drequire("game.activity.GoldBasin.BasinRateView")
local AvatarDuoRateHelp = class("AvatarDuoRateHelp",superClass)

function AvatarDuoRateHelp:ctor( data,mgrIns )
    self.m_mgrIns = mgrIns
    superClass.ctor(self,data)
end

function AvatarDuoRateHelp:initView(data)
    superClass.initView(self,data)

    local shorts = {}
    local keys = table.keys(data)
    if #keys == 1 then
        table.insert(shorts,3 - keys[1])
    end

    if not table.isNilOrEmpty(shorts) then
        utils.requestServer("gamble.data",{{"gambleType",CCInteger:create(shorts[1])}},nil,function ( tbl )
            local type = tonumber(tbl.infoDic.gambleType)
            table.sort(tbl.goodsArray,function ( f,s )
                return (tonumber(f.index) or 0) < (tonumber(s.index) or 0)
            end)
            self.m_mgrIns.drawInfoData[type] = tbl
            local tbl_key = type == _DRAW_TYPE_DIAMOND and "m_contentTable" or "m_contentTable1"
            self.ui:setTableViewDataSource(tbl_key, self:_parseData(tbl))
        end)
    end
end

function AvatarDuoRateHelp:_parseData( data )
    local res = {}
	if not table.isNilOrEmpty(data.goodsArray) then
		local total = 0
		for i,v in ipairs(data.goodsArray) do
			total = total + tonumber(v.power)
		end

		for i,v in ipairs(data.goodsArray) do
			local i_name = utils.getItemNameByItemId(v.goodsId)
			if i_name then
				table.insert(res,{i_name,string.format("%.4f%%",tonumber(v.power) / total * 100),v.goodsNum})
			end
		end
	end
	return res
end

function AvatarDuoRateHelp:prepareData( data )
    local key = _DRAW_TYPE_DIAMOND
    return data[key] and self:_parseData(data[key]) or {}
end

function AvatarDuoRateHelp:prepareDataNumber( data )
    local key = _DRAW_TYPE_GOLD
    return data[key] and self:_parseData(data[key]) or {}
end

function AvatarDuoRateHelp:getSwitchNames(  )
	return {getLang("176821"),getLang("176822")}
end

return AvatarDuoRateHelp