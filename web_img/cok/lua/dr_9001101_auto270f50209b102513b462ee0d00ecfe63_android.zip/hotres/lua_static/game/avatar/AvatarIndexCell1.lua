--[[ 
    装扮商城索引1-单元格
    2019.4.19   Awen
 ]]
 local AvatarIndexCell1 = class("AvatarIndexCell1", function() return cc.Layer:create() end)

function AvatarIndexCell1:create()
    local cell = AvatarIndexCell1.new()
    Drequire("game.avatar.AvatarIndexCell1_ui"):create(cell, 0)
    cell:initView()
    return cell
end

function AvatarIndexCell1:initView()
    registerTouchHandler(self)
    self:setTouchEnabled(true)
end

function AvatarIndexCell1:refreshCell(data, idx)
    self.v_data = data
    self.v_index = idx

    if data.name == '0' then
        self.ui.m_label:setString(data.type)
    else
        self.ui.m_label:setString(getLang(data.name))
    end

    if data.state == 0 then
        CCCommonUtilsForLua:setSpriteGray(self.ui.m_flag, true)
        self.ui.m_flag:setVisible(true) 
    else
        CCCommonUtilsForLua:setSpriteGray(self.ui.m_flag, false)
        self.ui.m_flag:setVisible(data.state > 1) 
    end
end

function AvatarIndexCell1:onTouchBegan( x, y )
    if self.v_data.state > 0 and isTouchInsideVis(self.ui.m_bg, x, y) then
        self.v_touchPoint = ccp(x, y)
        return true
    end
    return false
end

function AvatarIndexCell1:onTouchEnded( x, y )
    Dprint("AvatarIndexCell1:onTouchEnded", x, y, self.v_index)
    local _distance = ccpDistance(self.v_touchPoint, ccp(x,y))
    if _distance < 10 and isTouchInsideVis(self.ui.m_bg, x, y) then
        self.ui.m_flag:setVisible(not self.ui.m_flag:isVisible())
        self.v_data.parent.v_data[self.v_index + 1].state = self.ui.m_flag:isVisible() and 2 or 1
        self.v_data.parent:checkSelectAll(true)
    end
end

return AvatarIndexCell1