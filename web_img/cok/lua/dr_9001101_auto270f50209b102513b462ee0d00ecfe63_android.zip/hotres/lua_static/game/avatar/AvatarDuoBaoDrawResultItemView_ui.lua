----------------------------
-- Author: Elex
-- Date: 2019-05-27 Monday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local AvatarDuoBaoDrawResultItemView_ui = class("AvatarDuoBaoDrawResultItemView_ui")

--#ui propertys


--#function
function AvatarDuoBaoDrawResultItemView_ui:create(owner, viewType, paramTable)
	local ret = AvatarDuoBaoDrawResultItemView_ui.new()
	CustomUtility:LoadUi("AvatarDuoBaoDrawResultItemView.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function AvatarDuoBaoDrawResultItemView_ui:initLang()
end

function AvatarDuoBaoDrawResultItemView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function AvatarDuoBaoDrawResultItemView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return AvatarDuoBaoDrawResultItemView_ui

