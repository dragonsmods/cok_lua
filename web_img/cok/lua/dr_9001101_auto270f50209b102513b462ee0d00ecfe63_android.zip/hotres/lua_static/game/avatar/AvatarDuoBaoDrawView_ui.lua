----------------------------
-- Author: Elex
-- Date: 2020-03-24 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local AvatarDuoBaoDrawView_ui = class("AvatarDuoBaoDrawView_ui")

--#ui propertys


--#function
function AvatarDuoBaoDrawView_ui:create(owner, viewType, paramTable)
	local ret = AvatarDuoBaoDrawView_ui.new()
	CustomUtility:DoRes(0, true)
	CustomUtility:DoRes(500, true)
	CustomUtility:DoRes(8, true)
	CustomUtility:DoRes(0, true)
	CustomUtility:LoadUi("AvatarDuoBaoDrawView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function AvatarDuoBaoDrawView_ui:initLang()
	LabelSmoker:setText(self.m_pLabelTTF54, "176823")
	LabelSmoker:setText(self.m_buyOneSpriteLabel, "176824")
	LabelSmoker:setText(self.m_buyOneFreeLabel, "111124")
	LabelSmoker:setText(self.m_openOneLabel, "176825")
	LabelSmoker:setText(self.m_buyTenSpriteLabel, "176824")
	LabelSmoker:setText(self.m_openTenLabel, "176825")
	LabelSmoker:setText(self.m_pLabelTTF21, "176826")
	LabelSmoker:setText(self.txt_check, "176871")
	LabelSmoker:setText(self.m_labelTitle, "176815")
	ButtonSmoker:setText(self.m_diamondBtn, "176821")
	ButtonSmoker:setText(self.m_goldBtn, "176822")
	ButtonSmoker:setText(self.m_glodRankBtn, "9800017")
	ButtonSmoker:setText(self.m_diamondRankBtn, "9800016")
end

function AvatarDuoBaoDrawView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function AvatarDuoBaoDrawView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function AvatarDuoBaoDrawView_ui:onDiamondTabBtn(pSender, event)
	ButtonSmoker:forwardFunction(self, "onDiamondTabBtn", pSender, event)
end

function AvatarDuoBaoDrawView_ui:onGoldTabBtn(pSender, event)
	ButtonSmoker:forwardFunction(self, "onGoldTabBtn", pSender, event)
end

function AvatarDuoBaoDrawView_ui:onGoldRankBtn(pSender, event)
	ButtonSmoker:forwardFunction(self, "onGoldRankBtn", pSender, event)
end

function AvatarDuoBaoDrawView_ui:onDiamondRankBtn(pSender, event)
	ButtonSmoker:forwardFunction(self, "onDiamondRankBtn", pSender, event)
end

function AvatarDuoBaoDrawView_ui:onRateHelp(pSender, event)
	ButtonSmoker:forwardFunction(self, "onRateHelp", pSender, event)
end

function AvatarDuoBaoDrawView_ui:onClickCheckkBox(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickCheckkBox", pSender, event)
end

function AvatarDuoBaoDrawView_ui:onCrystalShopBtn(pSender, event)
	ButtonSmoker:forwardFunction(self, "onCrystalShopBtn", pSender, event)
end

function AvatarDuoBaoDrawView_ui:onClickBuyOneBtn(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBuyOneBtn", pSender, event)
end

function AvatarDuoBaoDrawView_ui:onClickBuyTenBtn(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBuyTenBtn", pSender, event)
end

function AvatarDuoBaoDrawView_ui:onSwitchHasAniBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onSwitchHasAniBtnClick", pSender, event)
end

function AvatarDuoBaoDrawView_ui:onClickBtnAd(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnAd", pSender, event)
end

function AvatarDuoBaoDrawView_ui:onClickBtnFaq(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnFaq", pSender, event)
end

return AvatarDuoBaoDrawView_ui

