----------------------------
-- Author: Elex
-- Date: 2019-04-19 Friday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local AvatarIndexCell1_ui = class("AvatarIndexCell1_ui")

--#ui propertys


--#function
function AvatarIndexCell1_ui:create(owner, viewType, paramTable)
	local ret = AvatarIndexCell1_ui.new()
	CustomUtility:LoadUi("AvatarIndexCell1.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function AvatarIndexCell1_ui:initLang()
end

function AvatarIndexCell1_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function AvatarIndexCell1_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return AvatarIndexCell1_ui

