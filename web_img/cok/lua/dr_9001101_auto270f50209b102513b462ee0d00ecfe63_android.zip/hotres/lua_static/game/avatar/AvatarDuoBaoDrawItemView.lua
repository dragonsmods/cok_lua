--[[	
	装备夺宝抽奖Item
	2019.5.13	Xu
]]
local AvatarDuoBaoDrawItemView =
    class(
    "AvatarDuoBaoDrawItemView",
    function()
        return cc.Layer:create()
    end
)

function AvatarDuoBaoDrawItemView:create()
    local cell = AvatarDuoBaoDrawItemView.new()
    Drequire("game.avatar.AvatarDuoBaoDrawItemView_ui"):create(cell, 0)
    cell:initView()
    return cell
end

function AvatarDuoBaoDrawItemView:initView()
    registerTouchHandler(self)
    self:setTouchEnabled(true)
    self:setSwallowsTouches(false)
    self.ui.m_hasGotSign:setVisible(false)
    self.ui.m_nodeLight:setVisible(false)
    self.ui.m_countLabel:setVisible(false)
    self:setCountLabel(0)
end

function AvatarDuoBaoDrawItemView:refreshCell(data)

    -- local kuangSpf = CCLoadSprite:call('loadResource', 'kuang' .. data.quality .. '.png')

    -- self.ui.m_iconBgSpr:setSpriteFrame(kuangSpf) -- Item的品质框
    -- self.ui.m_iconSpr:setSpriteFrame() -- Item icon

    local itemData = {
        type = 0,
        itemId = data.goodsId,
        num = tonumber(data.goodsNum)
    }
    local icon_node = CCNode:create()
    local iconSize = 92
    local LibaoCommonFunc = Drequire("game.LiBao.LibaoCommonFunc")
    LibaoCommonFunc.createItemInfoShow(itemData, icon_node, iconSize, nil, nil, nil, true)
    
    -- local bg = icon_node:getChildByTag(GOODS_BG_TAG)
    -- if bg then
    --     local color = CCCommonUtilsForLua:call("getPropById", tostring(itemData.itemId), "color")
    --     local bgPath = getItemBgByColor(atoi(color))
    --     bg:setSpriteFrame(CCLoadSprite:call("loadResource", bgPath))
    -- end

    self.ui.m_iconNode:removeAllChildren()
    self.ui.m_iconNode:addChild(icon_node)


    if tonumber(data.special or 0) == 1 then
        self.ui.m_xiyouNode:setVisible(true)
    else
        self.ui.m_xiyouNode:setVisible(false)
    end

    -- local nameStr = getLang(CCCommonUtilsForLua:call("getPropById", data.goodsId, "name"))
    -- nameStr = nameStr.." x"..data.goodsNum
    local nameStr = ""..data.goodsNum
    self.ui.m_pItemLabel:setString(nameStr)
end

function AvatarDuoBaoDrawItemView:doLighting(is)
    self.ui.m_nodeLight:setVisible(is)
end

function AvatarDuoBaoDrawItemView:doSelected(is)
    self.ui.m_hasGotSign:setVisible(is)
end
function AvatarDuoBaoDrawItemView:setCountLabel(count)
    self.m_count = count
    if count <= 1 then
        self.ui.m_countLabel:setVisible(false)
    else
        self.ui.m_countLabel:setVisible(true)
        self.ui.m_countLabel:setString("X"..count)
    end
end

return AvatarDuoBaoDrawItemView
