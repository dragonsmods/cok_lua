----------------------------
-- Author: Elex
-- Date: 2019-05-16 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local AvatarDuoBaoDrawMallBuyView_ui = class("AvatarDuoBaoDrawMallBuyView_ui")

--#ui propertys


--#function
function AvatarDuoBaoDrawMallBuyView_ui:create(owner, viewType, paramTable)
	local ret = AvatarDuoBaoDrawMallBuyView_ui.new()
	CustomUtility:LoadUi("AvatarDuoBaoDrawMallBuyView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function AvatarDuoBaoDrawMallBuyView_ui:initLang()
	ButtonSmoker:setText(self.m_btnCancel, "108532")
	ButtonSmoker:setText(self.m_btnOK, "350184")
end

function AvatarDuoBaoDrawMallBuyView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function AvatarDuoBaoDrawMallBuyView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function AvatarDuoBaoDrawMallBuyView_ui:onClickBtnCancel(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnCancel", pSender, event)
end

function AvatarDuoBaoDrawMallBuyView_ui:onClickBtnOK(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnOK", pSender, event)
end

return AvatarDuoBaoDrawMallBuyView_ui

