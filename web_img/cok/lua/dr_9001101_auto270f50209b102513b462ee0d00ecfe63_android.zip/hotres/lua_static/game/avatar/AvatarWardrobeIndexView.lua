--[[
	装扮索引界面
	2019.4.17	Awen
]]

local AvatarWardrobeIndexView = class("AvatarWardrobeIndexView", function() return PopupBaseView:create() end)
AvatarWardrobeIndexView.__index = AvatarWardrobeIndexView

local ST_NO = 0		--没有该类型
local ST_HIDE = 1	--隐藏该类型
local ST_SHOW = 2	--显示该类型
------------------------------------------ AvatarWardrobeIndexView --------------------------------------------
function AvatarWardrobeIndexView.create( parent,pos )
	local view = AvatarWardrobeIndexView.new()
	Drequire("game.avatar.AvatarWardrobeIndexView_ui"):create(view, 0)

	if view:initView(parent,pos) == false then
		return nil
	end
  	return view
end

function AvatarWardrobeIndexView:initView(parent,pos)
	Dprint("AvatarWardrobeIndexView:initView")
	self.v_parent = parent
	pos = tostring(pos)
	local function touchHandle(eventType, x, y)
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		else
			self:onTouchEnded(x, y)
		end
	end
	self:registerScriptTouchHandler(touchHandle)
	self:call("setTouchEnabled", true)
	self:call("setSwallowsTouches", true)
	self:call("setNeedCheckUpperAllAtOneceListenner", true)

	local _xmlData = CCCommonUtilsForLua:getGroupByKey("avatar_index")
	self.v_data = {}
	for k,v in pairs(_xmlData) do
		if v.pos == pos then
			v.parent = self
			v.type = tonumber(v.type) or 0
			v.state = ST_NO
			table.insert(self.v_data, v)
		end
	end

	table.sort(self.v_data, function(a, b)
		local _ida = tonumber(a.id) or 0
		local _idb = tonumber(b.id) or 0
		return _ida < _idb
	end)

	-- 隐藏所有已有类型
	for i,v in ipairs(self.v_parent.v_wardrobeAllTags or {}) do
		for ii,vv in ipairs(self.v_data) do
			if v == vv.type then
				vv.state = ST_HIDE
				break
			end
		end
	end

	-- 显示所有激活类型
	for i,v in ipairs(self.v_parent.m_wardrobeTags) do
		for ii,vv in ipairs(self.v_data) do
			if v == vv.type then
				vv.state = ST_SHOW
				break
			end
		end
	end	

	self:checkSelectAll()
	self.ui:setTableViewDataSource("m_tableView", self.v_data)

	dump(self.v_data, "AvatarWardrobeIndexView:initView")
	return true
end

-- 检查是否全选
function AvatarWardrobeIndexView:checkSelectAll(isModify)
	self.v_isModify = isModify
	local _isAll = true
	for i,v in ipairs(self.v_data) do
		if v.state == ST_HIDE then
			_isAll = false
			break
		end
	end
	self.ui.m_flagAll:setVisible(_isAll)	
end

-- 点击关闭
function AvatarWardrobeIndexView:onClickBtnClose( )
	self:closeSelf()
end

-- 点击确定
function AvatarWardrobeIndexView:onClickBtnOK()
	if self.v_isModify then
		self.v_parent.m_wardrobeTags = {AvatarType_None}
		for i,v in ipairs(self.v_data) do
			if v.state == ST_SHOW then
				table.insert(self.v_parent.m_wardrobeTags, v.type)
			end
		end

		self.v_parent.m_activeWardrobeTag = self.v_parent.m_wardrobeTags[1]
		if CCCommonUtilsForLua:isFunOpenByKey("dress_index") then
			local json = require("CommonLib.dkjson")			
		   local localStr = json.encode(self.v_parent.m_wardrobeTags)

		    cc.UserDefault:getInstance():setStringForKey("AvatarViewEx_wardrobeTags", tostring(localStr))

		end
		
		CCSafeNotificationCenter:postNotification("AvatarViewEx:refreshView")
	end

	self:onClickBtnClose()
end

function AvatarWardrobeIndexView:onEnter( )
	-- registerScriptObserver(self, self.setIsAnim, "AvatarWardrobeIndexView.setIsAnim")
end

function AvatarWardrobeIndexView:onExit( )
    -- unregisterScriptObserver(self, "AvatarWardrobeIndexView.setIsAnim")
end

function AvatarWardrobeIndexView:onTouchBegan( x, y )
	Dprint("AvatarWardrobeIndexView:onTouchBegan")
	self.v_touchX = x
	self.v_touchY = y
	return true
end

function AvatarWardrobeIndexView:onTouchEnded( x, y )
	Dprint("AvatarWardrobeIndexView:onTouchEnded")
	if (not isTouchInsideVis(self.ui.m_bg, x, y)) and (not isTouchInsideVis(self.ui.m_bg, self.v_touchX, self.v_touchY)) then
		self:onClickBtnClose()
		return
	end
	
	self.v_isModify = true
	if isTouchInsideVis(self.ui.m_bgAll, x, y) then
		self.ui.m_flagAll:setVisible(not self.ui.m_flagAll:isVisible())
		local _flag = self.ui.m_flagAll:isVisible()
		for i,v in ipairs(self.v_data) do
			if v.state > ST_NO then
				v.state = _flag and ST_SHOW or ST_HIDE
			end
		end
		self.ui.m_tableView:reloadData()
	end
end

return AvatarWardrobeIndexView
