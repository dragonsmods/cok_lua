----------------------------
-- Author: Elex
-- Date: 2019-04-19 Friday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local AvatarWardrobeIndexView_ui = class("AvatarWardrobeIndexView_ui")

--#ui propertys


--#function
function AvatarWardrobeIndexView_ui:create(owner, viewType, paramTable)
	local ret = AvatarWardrobeIndexView_ui.new()
	CustomUtility:DoRes(0, true)
	CustomUtility:LoadUi("AvatarWardrobeIndexView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function AvatarWardrobeIndexView_ui:initLang()
	LabelSmoker:setText(self.m_titleLabel, "350174")
	LabelSmoker:setText(self.m_pLabelTTF34, "350183")
	ButtonSmoker:setText(self.m_confirmBtn, "350184")
end

function AvatarWardrobeIndexView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function AvatarWardrobeIndexView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function AvatarWardrobeIndexView_ui:onClickBtnClose(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnClose", pSender, event)
end

function AvatarWardrobeIndexView_ui:onClickBtnOK(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnOK", pSender, event)
end

function AvatarWardrobeIndexView_ui:initTableView()
	TableViewSmoker:createView(self, "m_tableView", "game.avatar.AvatarIndexCell1", 1, 5, "AvatarIndexCell1")
end

function AvatarWardrobeIndexView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return AvatarWardrobeIndexView_ui

