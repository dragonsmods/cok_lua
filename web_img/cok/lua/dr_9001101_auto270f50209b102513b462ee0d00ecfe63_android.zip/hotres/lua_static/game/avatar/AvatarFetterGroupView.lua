--[[
	皮肤羁绊组界面
	2019.4.25	Awen
]]
local AvatarFetterGroupView = class("AvatarFetterGroupView", function()
    return PopupBaseView:create()
end)
AvatarFetterGroupView.__index = AvatarFettersView

--------------------------------------------------------------------------------------
function AvatarFetterGroupView.create(groupId)
	local view = AvatarFetterGroupView.new()
	Drequire("game.avatar.AvatarFetterGroupView_ui"):create(view, 0)

	if view:initView(groupId) == false then
		return nil
	end
  	return view
end

function AvatarFetterGroupView:initView(groupId)
	Dprint("AvatarFetterGroupView:initView", groupId)

    registerTouchHandler(self)
    self:setTouchEnabled(true)
	-- self:setSwallowsTouches(false)

	self.v_groupId = groupId
	-- 城堡展示
	local _clipNode = CCClipNode:call("create", self.ui.m_nodeWorld:getContentSize().width, self.ui.m_nodeWorld:getContentSize().height)
    _clipNode = tolua.cast(_clipNode, "cc.Node")
    self.ui.m_nodeWorld:addChild(_clipNode, -3000)
	local arr = CCArray:create()
	for i,v in pairs(AvatarController:getInstance().wardrobeActivityIdxTab or {}) do
		arr:addObject(CCInteger:create(tonumber(v)))
	end

	local world = VirtualWorld:call("createForLua", arr)
	if world then
		world:call("showLensStretching", 0.8, 0)
		world:setPositionY(-460)
		_clipNode:addChild(world)
		-- if CCCommonUtilsForLua:call("checkBeIphoneX") then
		-- 	world:setPosition(ccp(0, 200))
		-- end
	end


	-- 装扮图鉴名称
	self.v_dressName = {}
	for _,v in pairs(CCCommonUtilsForLua:getGroupByKey("dress_introduction") or {}) do
		self.v_dressName[v.goods_id] = v.dialog_id
	end

	local _xmlData = CCCommonUtilsForLua:getPropDictByIdGroup("skin_fetters", groupId)
	dump(_xmlData, "AvatarFetterGroupView:initView")
	
	-- 设置标题
	self:setTitleName(getLang(_xmlData.name))

	self.ui.m_nodeGet:setVisible(false)
	-- 
	local _itemList = string.split(_xmlData.item, '|')
	local _iconList = string.split(_xmlData.item_icon, '|')
	local _dataItem = {}
	local _tempItem = {}
	local _ownCount = 0
	for k,v in pairs(_itemList) do
		Dprint("AvatarFetterGroupView:initView", (#_tempItem), v)
		if v and v ~= '' then
			if AvatarController:getInstance():isAlreadyHaveAndOpen(tonumber(v)) then
				_ownCount = _ownCount + 1
			end
			if _xmlData.item_icon and _iconList and _iconList[k] then
				table.insert(_tempItem, {view = self, itemId = v, name = self.v_dressName[v], icon = _iconList[k]})
			else
				table.insert(_tempItem, {view = self, itemId = v, name = self.v_dressName[v]})
			end
		end
		if #_tempItem >= 3 then
			table.insert(_dataItem, _tempItem)
			_tempItem = {}
		end
	end
	if #_tempItem > 0 then
		table.insert(_dataItem, _tempItem)
	end
	-- dump(_dataItem, "AvatarFetterGroupView:initView")
	self.ui:setTableViewDataSource('m_tableView', _dataItem)

	-- Buff
	local _effectList = string.split(_xmlData.effect_dialog, '|')
	local _effectValue = string.split(_xmlData.value, '|')
	local _effectCondition = string.split(_xmlData.number, '|')
	local _effectAbs = string.split(_xmlData.abs, '|')

	local _dataBuff = {}
	for i,v in ipairs(_effectList or {}) do
		local _condition = tonumber(_effectCondition[i]) or 0
		local _abs = tonumber(_effectAbs[i]) or 0

		local _color = nil
		if _ownCount < _condition then
			_color = cc.c3b(147, 147, 147)	--如果未达到条件置灰
		end

		-- 350230=收藏{0}个装扮：
		if _abs == 1 then
			table.insert(_dataBuff, {label = getLang("350230", _condition), content = getLang(v, _effectValue[i]), color = _color})
		else
			table.insert(_dataBuff, {label = getLang("350230", _condition), content = getLang(v, _effectValue[i]..'%'), color = _color})
		end
	end
	-- dump(_dataBuff, "AvatarFetterGroupView:initView")
	self.ui:setTableViewDataSource('m_tableViewBuff', _dataBuff)

	XEvtTimer:delayTimer(0.2, function ()
		CCSafeNotificationCenter:call("postNotification", "AvatarFetterGroupCell:refreshState", CCString:create(_itemList[1]))
	    CCSafeNotificationCenter:call("postNotification", "MSG_TMP_SKIN_CHANGE", CCString:create(_itemList[1]))
	end)
	return true
end

function AvatarFetterGroupView:refresh( itemId )
	Dprint('AvatarFetterGroupView:refresh', itemId)
	if itemId then
		if self.v_dressName[itemId] then
			self.ui.m_labelGroupName:setString(getLang(self.v_dressName[itemId]))
		else
			local tInfo= ToolController:call("getToolInfoByIdForLua", tonumber(itemId))
			if tInfo then
				Dprint('AvatarFetterGroupView:refresh', itemId, tInfo:call("getName"))
				self.ui.m_labelGroupName:setString(tInfo:call("getName"))
			end
		end

		self.ui.m_nodeGet:setVisible(not AvatarController:getInstance():isAlreadyHave(tonumber(itemId)))
	end
end

function AvatarFetterGroupView:onEnter()
	self:call("showCloseBtn", true)

end

function AvatarFetterGroupView:onExit()
	self:call("showCloseBtn", false)
end

-- 点击获取
function AvatarFetterGroupView:onClickBtnGet()
	Dprint("AvatarFetterGroupView:onClickBtnGet", self.v_groupId)
	local view = Drequire("game.CommonPopup.ItemGetMethodView"):create(self.v_groupId)
	PopupViewController:call("addPopupView", view)
end

function AvatarFetterGroupView:onTouchBegan( x, y )
	self.touchPoint = ccp(x, y)
	return true
end

function AvatarFetterGroupView:onTouchEnded( x, y )
    if ccpDistance(self.touchPoint, ccp(x, y)) < 40 then return end
	local dir = self:getDirFromTo(self.touchPoint, ccp(x, y))
	if dir == 1 then
		self:changeRightGroup()
	elseif dir == 3 then
		self:changeLeftGroup()
	end
	self.touchPoint = nil
	return true
end

function AvatarFetterGroupView:changeLeftGroup()
	PopupViewController:call("removeLastPopupView")
	XEvtTimer:post("AvatarFetterView:changeGroupLastOrNext", {
		id = self.v_groupId,
		lastOrNext = -1
	})
end
function AvatarFetterGroupView:changeRightGroup()
	PopupViewController:call("removeLastPopupView")
	XEvtTimer:post("AvatarFetterView:changeGroupLastOrNext", {
		id = self.v_groupId,
		lastOrNext = 1
	})
end

function AvatarFetterGroupView:getDirFromTo(from, to) -- left, up, right, down 顺时针
	local fromOrigin = ccp(to.x - from.x, to.y - from.y)
	if math.abs(fromOrigin.x) > math.abs(fromOrigin.y) then
		if fromOrigin.x < 0 then
			return 1
		else
			return 3
		end
	else
		if fromOrigin.y < 0 then
			return 4
		else
			return 2
		end
	end
end

return AvatarFetterGroupView