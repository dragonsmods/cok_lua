----------------------------
-- Author: Elex
-- Date: 2020-01-09 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local AvatarFetterGroupView_ui = class("AvatarFetterGroupView_ui")

--#ui propertys


--#function
function AvatarFetterGroupView_ui:create(owner, viewType, paramTable)
	local ret = AvatarFetterGroupView_ui.new()
	CustomUtility:LoadUi("AvatarFetterGroupView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function AvatarFetterGroupView_ui:initLang()
	LabelSmoker:setText(self.m_pLabelTTF57, "164950")
	LabelSmoker:setText(self.m_labelTitle, "350203")
end

function AvatarFetterGroupView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function AvatarFetterGroupView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function AvatarFetterGroupView_ui:onClickBtnGet(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnGet", pSender, event)
end

function AvatarFetterGroupView_ui:initTableView()
	TableViewSmoker:createView(self, "m_tableView", "game.avatar.AvatarFetterGroupCell", 1, 2, "AvatarFetterGroupCell")
	TableViewSmoker:createView(self, "m_tableViewBuff", "game.avatar.AvatarFetterBuffCell", 1, 3, "AvatarFetterBuffCell")
end

function AvatarFetterGroupView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return AvatarFetterGroupView_ui

