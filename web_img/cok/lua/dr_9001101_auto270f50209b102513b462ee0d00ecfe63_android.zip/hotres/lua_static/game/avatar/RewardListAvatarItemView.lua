local RewardListAvatarItemView = class("RewardListAvatarItemView",
    function()
        return PopupBaseView:create()
    end
)
RewardListAvatarItemView.__index = RewardListAvatarItemView

function RewardListAvatarItemView:create(itemId, param)
    local view = RewardListAvatarItemView.new()
    Drequire("game.avatar.RewardListAvatarItemView_ui"):create(view, 0)
    if view:initView(itemId, param) then
        return view
    end
end

function RewardListAvatarItemView:initTableViewByOwner()
    local TableViewSmoker = Drequire("Editor.TableViewSmoker")
    TableViewSmoker:createView(self.ui, "m_pTableView1", "commonView.RewardListShowCell", 1, 5, "NewbeeCastlePopupCell")
end

function RewardListAvatarItemView:initView(itemId, param)
    self.m_itemId = itemId
    self.m_rewardId = param.rewardId
    self.m_titleName = param.titleName
    self.m_reward = param.reward or {}
    --local reward = param.reward or {}
    dump(" RewardListAvatarItemView:initView ")
    self._callBack = param.callBack
    local btnName = param.btnName or getLang("101274")
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnOk, btnName)

    self:registerTouchFuncs()
    local titleName = param.titleName or getLang("105114")
    self.ui.m_titleLabel:setString(titleName)
    local data = {}
    for i, info in pairs(self.m_reward) do
        data[i] = {}
        data[i].reward = info
        data[i].touchParentNode = self.ui.m_tableNode
    end
    self.ui:setTableViewDataSource("m_pTableView1", data)

    CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnUse, _lang('162022'))
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnBuy, _lang('102148'))
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnCancel, _lang('108532'))

    self:refreshBtn()


    if CCCommonUtilsForLua:isFunOpenByKey("box_show_rate") then
        if self.m_reward[1] and self.m_reward[1].value and self.m_reward[1].value.rate then
            self.ui.m_infoBtn:setVisible(true)
        else
            self.ui.m_infoBtn:setVisible(false)
        end
    else
        self.ui.m_infoBtn:setVisible(false)
    end

    return true
end

function RewardListAvatarItemView:refreshBtn()
    local hasItem = AvatarController.getInstance():isAlreadyHave(self.m_itemId)
    -- local hasItem = false -- 始终设置为购买
    self.ui.m_btnUse:setVisible(hasItem)
    self.ui.m_btnBuy:setVisible(not hasItem)
    self.ui.m_btnCancel:setVisible(not hasItem)
end

function RewardListAvatarItemView:refreshData()
    local rwd = GlobalData:call("getCachedRewardData", self.m_rewardId)
    local rwdData = arrayToLuaTable(rwd)
    self:initView(self.m_itemId, {rewardId = self.m_rewardId, reward = rwdData, btnName = getLang("101274"), titleName = self.m_titleName})
end

function RewardListAvatarItemView:onEnter()
    -- 获取数据
    registerScriptObserver(self, self.refreshData, MSG_GET_REWARD_DETAIL_BACK)
    registerScriptObserver(self, self.onConfirmBuy, "RewardListAvatarItemView.confirmBuyItem")
    
    MyPrint('RewardListAvatarItemView:onEnter')
end

function RewardListAvatarItemView:onExit()
    unregisterScriptObserver(self, MSG_GET_REWARD_DETAIL_BACK)
    unregisterScriptObserver(self, "RewardListAvatarItemView.confirmBuyItem")
end

function RewardListAvatarItemView:onTouchBegan(x, y)
    self.touchType = nil
    if not touchInside(self.ui.m_sprBG, x, y) then
        self.touchType = 1
    end
    return true
end

function RewardListAvatarItemView:onTouchMoved(x, y)

end

function RewardListAvatarItemView:onTouchEnded(x, y)
    if self.touchType == 1 and touchInside(self.ui.m_sprBG, x, y)==false then
        PopupViewController:call("removeLastPopupView")
    end
end

function RewardListAvatarItemView:onUseBtnClick()
    PopupViewController:call("removeLastPopupView")
    local dict = CCDictionary:create()
    dict:setObject(CCString:create("ToolNumSelectView"), "name")
    dict:setObject(CCString:create(tostring(self.m_itemId)), "itemId")
    dict:setObject(CCString:create(tostring(0)), "opFrom")
    dict:setObject(CCString:create(""), "targetId")
    LuaController:call("openPopViewInLua", dict)
end

function RewardListAvatarItemView:onBuyBtnClick()
    -- PopupViewController:call("removeLastPopupView") -- 不能移除，用它监听事件
    AvatarController.getInstance():buyItem(self.m_itemId, "RewardListAvatarItemView.confirmBuyItem")
end

function RewardListAvatarItemView:onInfoBtnClick()
    if #self.m_reward > 0 then
        local view = Drequire("game.CommonPopup.RewardListRateView"):create(self.m_reward)
        PopupViewController:addPopupView(view)
    end
end

function RewardListAvatarItemView:onConfirmBuy (ref)
    MyPrint('RewardListAvatarItemView buy item', self.m_itemId)
    local sellitemid = ToolController:call("getAvatarSellMapIdByItemId", self.m_itemId)
    MyPrint('RewardListAvatarItemView buy item', sellitemid)
    local sellItemInfo = ToolController:call("getSellItemInfoBySellId", sellitemid)
    if nil == sellItemInfo then
        return
    end
    local value1 = sellItemInfo:getProperty("m_value1")
    local tbl = dictToLuaTable(ref)

    local function callback() self:refreshBtn() end
    local callfunc = cc.CallFunc:create(callback)

    ToolController:call("shopBuyTool", sellitemid, tbl.count, tbl.count * value1, callfunc)
end

function RewardListAvatarItemView:onCancelBtnClick()

    PopupViewController:call("removeLastPopupView")
end

return RewardListAvatarItemView



