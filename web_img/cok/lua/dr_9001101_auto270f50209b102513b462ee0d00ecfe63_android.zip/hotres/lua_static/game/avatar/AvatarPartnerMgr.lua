-- @Author: tangwen
-- @Date:   2019-07-03 17:08:03
-- @Last Modified by:   tangwen
-- @Last Modified time: 2019-08-16 18:04:53

local AvatarPartnerMgr = class("AvatarPartnerMgr")

local _instance = nil
function AvatarPartnerMgr.getInstance()
    if _instance == nil then
        _instance = AvatarPartnerMgr.new()
        guiCommonGlobal.controllerAutoPurge(_instance)
    end
    return _instance
end

function AvatarPartnerMgr:ctor()
    self.m_hideWhenCompMap = {}
    self.m_partnerMap = {}
    self.m_partner2initMap = {}

    require("game.controller.SceneMgr").getInstance():getSceneChangeEvent():add(self.onSceneChange,self)
end

function AvatarPartnerMgr:onSceneChange(sceneId)
    if sceneId == SCENE_ID_MAIN then
        self.m_hideWhenCompMap = {}
        self.m_partnerMap = {}
        self.m_partner2initMap = {}
    end
end

function AvatarPartnerMgr:purge(  )
    _instance = nil
end

function AvatarPartnerMgr:__setPartnerShow(isShow,sk_node)
    local jsonName = sk_node:getJsonName()

    local decide_show = isShow

    -- 默认_out 是城堡 Wings是翅膀 这两个在显示组合动画的时候隐藏掉 所以组合的动画名称不要带这两个字段
    if string.find(jsonName,"_out") or string.find(jsonName,"Wings") then
        decide_show = not decide_show
    end

    local node = tolua.cast(sk_node,"cc.Node")
    utils.ensureNodeState( node, 2, function ( n )
        n:setVisible(decide_show)
    end)
end

local PartnerSkin = class("PartnerSkin")

function PartnerSkin:ctor(partnerArray,posConfig)
    self.m_partnerArray = partnerArray
    self.m_posConfig = posConfig
    self.m_start_sk = 2
end

function PartnerSkin:_setPartnerShow(isShow,sk_node_tbl,index)
    local exist_node = nil
    if index == 2 then
        local t_len = #sk_node_tbl
        exist_node = t_len > 1 and tolua.cast(sk_node_tbl[t_len],"cc.Node") or nil
    end
    for idx,v in ipairs(sk_node_tbl) do
        if index == 2 then
            local jsonName = v:getJsonName()

            local tn = tolua.cast(v,"cc.Node")
            local paroot = tn:getParent():getParent()

            if not paroot and exist_node then
                paroot = exist_node:getParent():getParent()
                paroot:addChild(tn:getParent(),20)
            end
            
            AvatarPartnerMgr.getInstance():__setPartnerShow(isShow,v,index)
            if isShow then
                self:customAnimation(v,tn)
            end
        else
            AvatarPartnerMgr.getInstance():__setPartnerShow(isShow,v,index)
        end
    end
end

function PartnerSkin:adjustPosition(tbl)
    local start_sk = self.m_start_sk
    local p1 = cc.p(tolua.cast( tbl[start_sk + 1][1],"cc.Node"):getPosition())
    local p2 = cc.p(tolua.cast( tbl[start_sk + 3][1],"cc.Node"):getPosition())
    local p1_on_p2_left = p1.x < p2.x

    -- 组合皮肤不一定放在第一位，遍历一下
    local n1_isconfig_left = table.find(tbl[start_sk + 1], function (cur)
        local jsonStr = cur:getJsonName()
        return string.find(jsonStr, self.m_posConfig.left) ~= nil
    end)
    local n1_isconfig_right = not n1_isconfig_left
    local need_flipX = (n1_isconfig_left and not p1_on_p2_left) or (n1_isconfig_right and p1_on_p2_left)
    
    for _,v in ipairs(tbl[start_sk + 2]) do
        local n = tolua.cast(v,"cc.Node")
        n:setPosition(cc.p( (p1.x+p2.x)/2, (p1.y+p2.y)/2 ))
        if need_flipX then
            n:setScaleX(-1)
        end
    end
end

function PartnerSkin:setPartnerShow(isShow)
    local tbl = self.m_partnerArray
    local start_sk = self.m_start_sk
    self:_setPartnerShow(isShow,tbl[start_sk + 1],1)
    self:_setPartnerShow(isShow,tbl[start_sk + 3],3)
    self:_setPartnerShow(isShow,tbl[start_sk + 2],2)

    if isShow then
        self:adjustPosition(tbl)
    end
end

function PartnerSkin:customAnimation(skNode,justNode)
    skNode:setToSetupPose()
    skNode:setAnimation("animation",0)
end

-- 吕布貂蝉 组合皮肤
local LvBuDiaoChan = class("LvBuDiaoChan",PartnerSkin)

function LvBuDiaoChan:customAnimation(skNode,justNode)
    skNode:setToSetupPose()
    justNode:runAction(utils.getDelayAction(0.1,function()
        skNode:setToSetupPose()
        skNode:setAnimation("xiuxian",1)
        justNode:runAction(utils.getDelayAction(6.3,function()
            skNode:setAnimation("idle",0)
        end))
    end))
end

-- 2021 枪手舞女
local QiangshouWunv = class("QiangshouWunv",PartnerSkin)
function QiangshouWunv:customAnimation(skNode,justNode)
    justNode:runAction(utils.getDelayAction(0.1,function()
        skNode:setToSetupPose()
        skNode:setAnimation("guochang",1)
        justNode:runAction(utils.getDelayAction(5.3,function()
            skNode:setAnimation("idle",0)
        end))
    end))
end

function AvatarPartnerMgr:getPartnerClass( comp_json_name )
    if string.find(comp_json_name,"Lover2020_3") then
        return LvBuDiaoChan,{left="Lover2020_1",right="Lover2020_2"}
    elseif string.find(comp_json_name,"Lover2021_3_gaoji") then
        return QiangshouWunv,{left="Lover2021_1_gaoji",right="Lover2021_2_gaoji"}
    elseif string.find(comp_json_name,"Lover2021_3_diji") then
        return QiangshouWunv,{left="Lover2021_1_diji",right="Lover2021_2_diji"}
    end

    return PartnerSkin
end

function AvatarPartnerMgr:cleanPartner(tbl)
    self:showPartner(tbl,false)
end

function AvatarPartnerMgr:showPartner(tbl,isShow)
    local start_sk = 2
    local r = {tbl[start_sk + 1],tbl[start_sk + 2],tbl[start_sk + 3]}
    for idx,v in ipairs(r) do
        for _,v1 in ipairs(v) do
            self:__setPartnerShow(isShow,v1)
            if idx == 2 then
                local node = tolua.cast(v1,"cc.Node")
                tolua.cast(v1,"cc.Node"):removeFromParent(true)
            end
        end
    end
end

function AvatarPartnerMgr:descripNode( tn )
    local tp = cc.p(tolua.cast(tn,"cc.Node"):getPosition())
    return {tp.x,tp.y,tn:getJsonName(),tn}
end

function AvatarPartnerMgr:findInitSKByDescriptor( descriptor )
    if table.isNilOrEmpty(self.m_hideWhenCompMap) then
        return
    end

    for key,v in pairs(self.m_hideWhenCompMap) do
        local v1 = v[table.keys(v)[1]]
        if descriptor[1] == v1[1] and descriptor[2] == v1[2] then
            return key
        end
    end
end

function AvatarPartnerMgr:updatePartner2initMap( nodes, keytbl )
    for _,v in ipairs(nodes) do
        local sk_desc = self:descripNode(v)
        local sk_key = self:findInitSKByDescriptor(sk_desc)
        if sk_key then
            self.m_partner2initMap[keytbl] = self.m_partner2initMap[keytbl] or {}
            if not table.contains(self.m_partner2initMap[keytbl],sk_key) then
                table.insert(self.m_partner2initMap[keytbl],sk_key)
            end
        end
    end
end

function AvatarPartnerMgr:isAreadyInComp( init_key )
    if not init_key then
        return false
    end
    for k,v in pairs(self.m_partner2initMap or {}) do
        if table.contains(v,init_key) then
            return true
        end
    end
    return false
end

function AvatarPartnerMgr:handleSKNode( newKey, data )
    if newKey == "initSkNode" then
        local tbl = arrayToLuaTable(data)
        if tbl[1] and type(tbl[1]) == "number" then
            local init_key = tbl[1]
            local sk_node = tbl[2]
            self.m_hideWhenCompMap[init_key] = self.m_hideWhenCompMap[init_key] or {} 
            
            local t = self.m_hideWhenCompMap[init_key]
            local desc = self:descripNode(sk_node)
            t[desc[3]] = t[desc[3]] or {}
            table.merge(t[desc[3]],desc)

            if self:isAreadyInComp(init_key) then
                utils.ensureNodeState( tolua.cast(sk_node,"cc.Node"), 2, function ( n )
                    n:setVisible(false)
                end)
            end
        end
    elseif newKey == "compSkNode" then
        local tbl = arrayToLuaTable(data)
        if table.isNilOrEmpty(tbl[3]) or table.isNilOrEmpty(tbl[4]) or table.isNilOrEmpty(tbl[5]) then
            return
        end

        for k,v in pairs(self.m_partnerMap) do
            if v and (table.contains(k,tbl[1]) or table.contains(k,tbl[2])) then
                -- clean old
                local old_tbl = v[4]
                for _,oldv in ipairs(old_tbl) do
                    tolua.cast(oldv,"cc.Node"):removeFromParent(true)
                end

                -- repace new
                v[4] = tbl[4]
                return
            end
        end

        local sk1_arr = {}
        local keytbl = {tbl[1],tbl[2]}
        if table.isNilOrEmpty(self.m_partnerMap) then
            self.m_partnerMap[keytbl] = tbl
        else
            for k,v in pairs(self.m_partnerMap) do
                if not table.contains(keytbl,k[1]) and not table.contains(keytbl,k[2]) then
                    self.m_partnerMap[keytbl] = tbl
                end
            end
        end

        self:updatePartner2initMap({tbl[3][1],tbl[5][1]},keytbl)
        
        local partnerClass,posConfig = self:getPartnerClass(tbl[4][1]:getJsonName())
        partnerClass:create(tbl,posConfig):setPartnerShow(true)

        local names = {}
        for _,n in ipairs(tbl[3]) do
            table.insert(names,n:getJsonName())
        end

    elseif newKey == "dismissComp" then
        local cityName = data:getCString()
        if cityName then
            for k,v in pairs(self.m_partnerMap) do
                if v and table.contains(k,cityName) then
                    self:cleanPartner(v)
                    self.m_partnerMap[k] = nil
                    self.m_partner2initMap[k] = nil
                    break
                end
            end
        end
    end
end

return AvatarPartnerMgr