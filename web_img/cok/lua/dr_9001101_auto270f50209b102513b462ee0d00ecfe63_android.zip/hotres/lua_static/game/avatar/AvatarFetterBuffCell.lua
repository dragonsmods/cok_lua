--[[ 
    皮肤羁绊属性-单元格
    2019.4.25   Awen
 ]]
local AvatarFetterBuffCell = class("AvatarFetterBuffCell", function() return cc.Layer:create() end)

function AvatarFetterBuffCell:create()
    local cell = AvatarFetterBuffCell.new()
    Drequire("game.avatar.AvatarFetterBuffCell_ui"):create(cell, 0)
    return cell
end

function AvatarFetterBuffCell:refreshCell(data, idx)
    if data.labelAll then
        self.ui.m_labelAll:setString(data.labelAll)
    end
    if data.label then
        self.ui.m_label:setString(data.label)
    end
    if data.content then
        self.ui.m_content:setString(data.content)
    end

    if data.color then
        self.ui.m_labelAll:setColor(data.color)
        self.ui.m_label:setColor(data.color)
        self.ui.m_content:setColor(data.color)
    end
end

return AvatarFetterBuffCell