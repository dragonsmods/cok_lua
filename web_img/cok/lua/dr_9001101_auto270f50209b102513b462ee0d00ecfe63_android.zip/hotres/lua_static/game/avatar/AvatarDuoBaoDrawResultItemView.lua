--[[	
	装备夺宝抽奖Item
	2019.5.13	Xu
]]
local AvatarDuoBaoDrawResultItemView =
    class(
    "AvatarDuoBaoDrawResultItemView",
    function()
        return cc.Layer:create()
    end
)

function AvatarDuoBaoDrawResultItemView:create()
    local cell = AvatarDuoBaoDrawResultItemView.new()
    Drequire("game.avatar.AvatarDuoBaoDrawResultItemView_ui"):create(cell, 0)
    cell:initView()
    return cell
end

function AvatarDuoBaoDrawResultItemView:initView()
    registerTouchHandler(self)
    self:setTouchEnabled(true)
    self:setSwallowsTouches(false)
end

function AvatarDuoBaoDrawResultItemView:refreshCell(data)
    local itemData = {
        type = 0,
        itemId = data.goodsId or data.itemId,
        num = tonumber(data.rewardAdd or data.addCount),
    }
    local icon_node = CCNode:create()
    local iconSize = 80
    local LibaoCommonFunc = Drequire("game.LiBao.LibaoCommonFunc")
    LibaoCommonFunc.createItemInfoShow(itemData, icon_node, iconSize, nil, nil, nil, true)
    self.ui.m_iconNode:addChild(icon_node)

    -- local nameStr = getLang(CCCommonUtilsForLua:call("getPropById", itemData.itemId, "name"))
    -- nameStr = nameStr.." x"..itemData.num
    local nameStr = ""..itemData.num
    self.ui.m_pItemLabel:setString(nameStr)
    self:addParticle(data.lighting)
end

function AvatarDuoBaoDrawResultItemView:addParticle(lighting)
    self.ui.m_parNode:removeAllChildren()
    if lighting then 
        for j=0, 2 do
            if j ~= 1 then
                local particle = ParticleController:call("createParticle", "LordSuitY_"..tostring(j))
                particle:setScale(1.4)
                particle:setPosition(cc.p(50, 50))
                self.ui.m_parNode:addChild(particle, -1)
            end
        end
    end
    self.ui.m_parNode:setVisible(lighting)
end

return AvatarDuoBaoDrawResultItemView
