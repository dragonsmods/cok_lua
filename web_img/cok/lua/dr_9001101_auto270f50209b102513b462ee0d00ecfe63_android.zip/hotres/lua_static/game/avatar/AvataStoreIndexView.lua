--[[
	装扮商城索引界面
	2019.4.17	Awen
]]

local AvataStoreIndexView = class("AvataStoreIndexView", function() return PopupBaseView:create() end)
AvataStoreIndexView.__index = AvataStoreIndexView

local ST_NO = 0		--没有该类型
local ST_HIDE = 1	--隐藏该类型
local ST_SHOW = 2	--显示该类型
------------------------------------------ AvataStoreIndexView --------------------------------------------
function AvataStoreIndexView.create( parent,pos )
	local view = AvataStoreIndexView.new()
	Drequire("game.avatar.AvataStoreIndexView_ui"):create(view, 0)

	if view:initView(parent,pos) == false then
		return nil
	end
  	return view
end

function AvataStoreIndexView:initView(parent,pos)
	Dprint("AvataStoreIndexView:initView")
	self.v_parent = parent
	self.v_pos = tostring(pos)

	local function touchHandle(eventType, x, y)
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		else
			self:onTouchEnded(x, y)
		end
	end
	self:registerScriptTouchHandler(touchHandle)
	self:call("setTouchEnabled", true)
	self:call("setSwallowsTouches", true)
	self:call("setNeedCheckUpperAllAtOneceListenner", true)

	local _xmlData = CCCommonUtilsForLua:getGroupByKey("avatar_index")
	self.v_data = {}
	for k,v in pairs(_xmlData) do
		if v.pos == self.v_pos then
			v.parent = self
			v.state = ST_NO
			table.insert(self.v_data, v)
		end
	end

	table.sort(self.v_data, function(a, b)
		local _ida = tonumber(a.id) or 0
		local _idb = tonumber(b.id) or 0
		return _ida < _idb
	end)

	local _isNoOwned = false
	local _isOwned = false
	self.v_stNoOwned = ST_NO
	self.v_stOwned = ST_NO

	if self.v_pos == '2' then	-- 装扮商店
		local _index = self.v_parent.m_activeStoreTag
		for k,v in pairs(self.v_parent.v_storeAllData[_index] or {}) do
			local _info = AvatarController:call("getAvatarInfoByGoodsId", v)
			if _info then
				local _type = _info:call("getAvatarType")
				for ii,vv in ipairs(self.v_data) do
					if vv.type == tostring(_type) then
						vv.state = ST_HIDE
						break
					end
				end
	
				if _isNoOwned == false or _isOwned == false then
					if AvatarController:getInstance():isAlreadyHave(v) then
						_isOwned = true
						self.v_stOwned = ST_HIDE
					else
						_isNoOwned = true
						self.v_stNoOwned = ST_HIDE
					end				
				end
			end
		end
	
		_isNoOwned = false
		_isOwned = false
		for k,v in pairs(self.v_parent.m_storeData[_index] or {}) do
			local _info = AvatarController:call("getAvatarInfoByGoodsId", v)
			if _info then
				local _type = _info:call("getAvatarType")
				for ii,vv in ipairs(self.v_data) do
					if vv.type == tostring(_type) then
						vv.state = ST_SHOW
						break
					end
				end
				if _isNoOwned == false or _isOwned == false then
					if AvatarController:getInstance():isAlreadyHave(v) then
						_isOwned = true
						self.v_stOwned = ST_SHOW
					else
						_isNoOwned = true
						self.v_stNoOwned = ST_SHOW
					end
				end
			end
		end

	elseif self.v_pos == '3' then	-- 图鉴
		-- dump(DressIntroductionController.dressTblData[0], "aaa")
		for _,v in ipairs(DressIntroductionController.dressTblData[0] or {}) do
			for _,vv in ipairs(self.v_data) do
				if v.type == vv.type then
					vv.state = ST_HIDE
					break
				end
			end

			if _isNoOwned == false or _isOwned == false then
				if v.can_dress or v.already_dress then
					_isOwned = true
					self.v_stOwned = ST_HIDE
				else
					_isNoOwned = true
					self.v_stNoOwned = ST_HIDE
				end				
			end
		end
	
		_isNoOwned = false
		_isOwned = false
		for _,v in ipairs(self.v_parent.v_tag0Data or {}) do
			for _,vv in ipairs(v) do
				for _,vvv in ipairs(self.v_data) do
					if vv.type == vvv.type then
						vvv.state = ST_SHOW
						break
					end
				end

				if _isNoOwned == false or _isOwned == false then
					if vv.can_dress or vv.already_dress then
						_isOwned = true
						self.v_stOwned = ST_SHOW
					else
						_isNoOwned = true
						self.v_stNoOwned = ST_SHOW
					end				
				end
			end
		end
	end

	dump(self.v_data, "AvataStoreIndexView:initView")
	self.ui:setTableViewDataSource("m_tableView", self.v_data)

	if self.v_stNoOwned == ST_NO then
		CCCommonUtilsForLua:setSpriteGray(self.ui.m_flagNoOwned, true)
	else
		self.ui.m_flagNoOwned:setVisible(self.v_stNoOwned > ST_HIDE)
	end
	if self.v_stOwned == ST_NO then
		CCCommonUtilsForLua:setSpriteGray(self.ui.m_flagOwned, true)
	else
		self.ui.m_flagOwned:setVisible(self.v_stOwned > ST_HIDE )
	end

	self:checkSelectAll(false)
	Dprint("AvataStoreIndexView:initView", self.v_isModify, self.v_stNoOwned, self.v_stOwned)

	return true
end  

-- 检查是否全选
function AvataStoreIndexView:checkSelectAll(isModify)
	self.v_isModify = isModify
	local _isAll = true

	if self.v_stNoOwned == ST_HIDE or self.v_stOwned == ST_HIDE then
		_isAll = false
	else
		for i,v in ipairs(self.v_data) do
			if v.state == ST_HIDE then
				_isAll = false
				break		
			end
		end
	end

	self.ui.m_flagAll:setVisible(_isAll)	
end

-- 点击关闭
function AvataStoreIndexView:onClickBtnClose()
	self:closeSelf()
end

-- 点击确定
function AvataStoreIndexView:onClickBtnOK()
	Dprint("AvataStoreIndexView:onClickBtnOK", self.v_isModify, self.v_stNoOwned, self.v_stOwned)

	-- 刷新数据
	if self.v_isModify then
		if self.v_pos == '2' then	-- 装扮商店
			local _index = self.v_parent.m_activeStoreTag
			self.v_parent.m_storeData[_index] = {}
			if self.ui.m_flagAll:isVisible() then
				self.v_parent.m_storeData[_index] = clone(self.v_parent.v_storeAllData[_index])
			else
				local _isNoOwned = self.v_stNoOwned ~= ST_HIDE
				local _isOwned = self.v_stOwned ~= ST_HIDE
				Dprint("AvataStoreIndexView:onClickBtnOK 1", _isNoOwned, _isOwned)

				if _isNoOwned or _isOwned then
					for k,v in pairs(self.v_parent.v_storeAllData[_index] or {}) do
						local _info = AvatarController:call("getAvatarInfoByGoodsId", v)
						if _info then
							local _type = _info:call("getAvatarType")
							for ii,vv in ipairs(self.v_data) do
								Dprint("AvataStoreIndexView:onClickBtnOK", _type, vv.type, vv.state)
								if vv.type == tostring(_type) and vv.state ~= ST_HIDE then
									if _isNoOwned and _isOwned then
										table.insert(self.v_parent.m_storeData[_index], v)
									else
										if AvatarController:getInstance():isAlreadyHave(v) then
											if _isOwned then
												table.insert(self.v_parent.m_storeData[_index], v)
											end
										else
											if _isNoOwned then
												table.insert(self.v_parent.m_storeData[_index], v)
											end
										end
									end
									break
								end
							end
						end
					end
				end
			end

			--存储选择展示的图鉴数据到本地--------
			if CCCommonUtilsForLua:isFunOpenByKey("dress_index") then
				local json = require("CommonLib.dkjson")			
			    local localStr = json.encode(self.v_parent.m_storeData)	           
			    cc.UserDefault:getInstance():setStringForKey("AvatarViewEx_storeData", tostring(localStr))
			end			

			CCSafeNotificationCenter:postNotification("AvatarViewEx:refreshView")
		
		elseif self.v_pos == '3' then	-- 图鉴
			self.v_parent.v_tag0Data = {}
			if self.ui.m_flagAll:isVisible() then
				self.v_parent.v_tag0Data = DressIntroductionController:getDressTblData(0)
			else
				local _isNoOwned = self.v_stNoOwned ~= ST_HIDE
				local _isOwned = self.v_stOwned ~= ST_HIDE
				Dprint("AvataStoreIndexView:onClickBtnOK 1", _isNoOwned, _isOwned)
				table.sort(self.v_data, function(a, b)
					local _ida = tonumber(a.type) or 0
					local _idb = tonumber(b.type) or 0
					return _ida < _idb
				end)
				if _isNoOwned or _isOwned then
					local _rowData = {}
					for _,v in ipairs(DressIntroductionController.dressTblData[0] or {}) do
						-- Dprint("AvataStoreIndexView:onClickBtnOK", v.id, v.type)
						local _type = tonumber(v.type) or 0
						if _type > 0 and _type <= #self.v_data then
							local _filterData = self.v_data[_type]
							if _filterData.state ~= ST_HIDE then
								if _isNoOwned and _isOwned then
									table.insert(_rowData, v)
								else
									if v.can_dress or v.already_dress then
										if _isOwned then
											table.insert(_rowData, v)
										end
									else
										if _isNoOwned then
											table.insert(_rowData, v)
										end
									end
								end
								if #_rowData == 4 then
									table.insert(self.v_parent.v_tag0Data, _rowData)
									_rowData = {}
								end
							end
						end
					end
					if #_rowData > 0 then
						table.insert(self.v_parent.v_tag0Data, _rowData)
					end
				end
			end
			for k,v in pairs(self.v_parent.v_tag0Data) do
				for _, vv in pairs(v) do
					if vv.isTouchInside then
						vv.isTouchInside = false
					end
				end
			end
            self.v_parent.touchItemInfo = nil
			self.v_parent:initDressIntrTableView(0)
		end
	end

	self:onClickBtnClose()
end

function AvataStoreIndexView:onEnter(  )
	-- registerScriptObserver(self, self.setIsAnim, "AvataStoreIndexView.setIsAnim")
end

function AvataStoreIndexView:onExit(  )
    -- unregisterScriptObserver(self, "AvataStoreIndexView.setIsAnim")
end

function AvataStoreIndexView:onTouchBegan( x, y )
	Dprint("AvataStoreIndexView:onTouchBegan")
	self.v_touchX = x
	self.v_touchY = y
	return true
end

function AvataStoreIndexView:onTouchEnded( x, y )
	Dprint("AvataStoreIndexView:onTouchEnded")
	if (not isTouchInsideVis(self.ui.m_bg, x, y)) and (not isTouchInsideVis(self.ui.m_bg, self.v_touchX, self.v_touchY)) then
		self:onClickBtnClose()
		return
	end

	if isTouchInsideVis(self.ui.m_bgAll, x, y) then
		self.v_isModify = true
		self.ui.m_flagAll:setVisible(not self.ui.m_flagAll:isVisible())

		local _flag = self.ui.m_flagAll:isVisible()
		if self.v_stNoOwned > ST_NO then
			self.ui.m_flagNoOwned:setVisible(_flag)
			self.v_stNoOwned = _flag and ST_SHOW or ST_HIDE
		end
		if self.v_stOwned > ST_NO then
			self.ui.m_flagOwned:setVisible(_flag)
			self.v_stOwned = _flag and ST_SHOW or ST_HIDE
		end
		for i,v in ipairs(self.v_data) do
			if v.state > ST_NO then
				v.state = _flag and ST_SHOW or ST_HIDE
			end
		end
		self.ui.m_tableView:reloadData()

	elseif self.v_stNoOwned > ST_NO and isTouchInsideVis(self.ui.m_bgNoOwned, x, y) then
		self.ui.m_flagNoOwned:setVisible(not self.ui.m_flagNoOwned:isVisible())
		self.v_stNoOwned = self.ui.m_flagNoOwned:isVisible() and ST_SHOW or ST_HIDE
		self:checkSelectAll(true)

	elseif self.v_stOwned > ST_NO and isTouchInsideVis(self.ui.m_bgOwned, x, y) then
		self.ui.m_flagOwned:setVisible(not self.ui.m_flagOwned:isVisible())
		self.v_stOwned = self.ui.m_flagOwned:isVisible() and ST_SHOW or ST_HIDE
		self:checkSelectAll(true)
	end
end

return AvataStoreIndexView