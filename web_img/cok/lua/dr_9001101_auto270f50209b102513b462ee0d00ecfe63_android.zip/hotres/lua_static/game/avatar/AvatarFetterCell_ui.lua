----------------------------
-- Author: Elex
-- Date: 2019-04-26 Friday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local AvatarFetterCell_ui = class("AvatarFetterCell_ui")

--#ui propertys


--#function
function AvatarFetterCell_ui:create(owner, viewType, paramTable)
	local ret = AvatarFetterCell_ui.new()
	CustomUtility:DoRes(0, true)
	CustomUtility:LoadUi("AvatarFetterCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function AvatarFetterCell_ui:initLang()
end

function AvatarFetterCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function AvatarFetterCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return AvatarFetterCell_ui

