----------------------------
-- Author: Elex
-- Date: 2019-04-19 Friday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local AvataStoreIndexView_ui = class("AvataStoreIndexView_ui")

--#ui propertys


--#function
function AvataStoreIndexView_ui:create(owner, viewType, paramTable)
	local ret = AvataStoreIndexView_ui.new()
	CustomUtility:DoRes(0, true)
	CustomUtility:LoadUi("AvatarStoreIndexView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function AvataStoreIndexView_ui:initLang()
	LabelSmoker:setText(self.m_titleLabel, "350174")
	LabelSmoker:setText(self.m_pLabelTTF34, "350183")
	LabelSmoker:setText(self.m_pLabelTTF10, "350185")
	LabelSmoker:setText(self.m_pLabelTTF11, "350186")
	ButtonSmoker:setText(self.m_btnOK, "350184")
end

function AvataStoreIndexView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function AvataStoreIndexView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function AvataStoreIndexView_ui:onClickBtnClose(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnClose", pSender, event)
end

function AvataStoreIndexView_ui:onClickBtnOK(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnOK", pSender, event)
end

function AvataStoreIndexView_ui:initTableView()
	TableViewSmoker:createView(self, "m_tableView", "game.avatar.AvatarIndexCell2", 1, 4, "AvatarIndexCell2")
end

function AvataStoreIndexView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return AvataStoreIndexView_ui

