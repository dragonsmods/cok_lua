----------------------------
-- Author: Elex
-- Date: 2019-05-27 Monday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local AvatarDuoBaoDrawMallCell_ui = class("AvatarDuoBaoDrawMallCell_ui")

--#ui propertys


--#function
function AvatarDuoBaoDrawMallCell_ui:create(owner, viewType, paramTable)
	local ret = AvatarDuoBaoDrawMallCell_ui.new()
	CustomUtility:DoRes(0, true)
	CustomUtility:LoadUi("AvatarDuoBaoDrawMallCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function AvatarDuoBaoDrawMallCell_ui:initLang()
end

function AvatarDuoBaoDrawMallCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function AvatarDuoBaoDrawMallCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function AvatarDuoBaoDrawMallCell_ui:onClickItem1(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickItem1", pSender, event)
end

function AvatarDuoBaoDrawMallCell_ui:onClickItem2(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickItem2", pSender, event)
end

return AvatarDuoBaoDrawMallCell_ui

