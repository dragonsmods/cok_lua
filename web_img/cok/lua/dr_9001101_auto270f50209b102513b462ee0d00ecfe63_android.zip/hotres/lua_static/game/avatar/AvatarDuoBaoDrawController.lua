--[[	
	装备夺宝抽奖
	2019.5.13	Xu
]]

local AvatarDuoBaoDrawController = class("AvatarDuoBaoDrawController")
AvatarDuoBaoDrawController.__index = AvatarDuoBaoDrawController

-- _cache_AvatarDuoBaoDrawController_config = _cache_AvatarDuoBaoDrawController_config or {}

local ccud = cc.UserDefault:getInstance()
local UDDuoBaoHasNoAniKey = "AvatarDuoBaoHasNoAni"

_DRAW_TYPE_GOLD = 1
_DRAW_TYPE_DIAMOND = 2

function AvatarDuoBaoDrawController:ctor()
    self:loadConfig()
end

function AvatarDuoBaoDrawController:loadConfig()
    self:loadHasAni()
    self.GoodsConfig = {}
    self.GoodsIndexMap = {}
    local tbl = CCCommonUtilsForLua:getGroupByKey("gamble_goods")
	for _,v in pairs(tbl or {}) do
        -- self.GoodsConfig[tonumber(v.gamble_type)] = v
        if not self.GoodsConfig[tonumber(v.gamble_type)] then
            self.GoodsConfig[tonumber(v.gamble_type)] = {}
        end
        table.insert(self.GoodsConfig[tonumber(v.gamble_type)], v)

        if not self.GoodsIndexMap[tonumber(v.gamble_type)] then
            self.GoodsIndexMap[tonumber(v.gamble_type)] = {}
        end
        self.GoodsIndexMap[tonumber(v.gamble_type)][tonumber(v.index)] = v
	end
end
--     _cache_AvatarDuoBaoDrawController_config = {}

--     _cache_AvatarDuoBaoDrawController_config.drawTypeInfoMap = {}
--     local _xmlData = {}
-- 	for _,v in pairs(CCCommonUtilsForLua:getGroupByKey("gamble_data") or {}) do
--         table.insert(_xmlData, v)
--         _cache_AvatarDuoBaoDrawController_config.drawTypeInfoMap[tonumber(v.gamble_type)] = v
-- 	end

--     _xmlData = {}
-- 	for _,v in pairs(CCCommonUtilsForLua:getGroupByKey("gamble_goods") or {}) do
-- 		table.insert(_xmlData, v)
-- 	end
-- 	table.sort(_xmlData, function(a, b)
-- 		local _aIndex = tonumber(a.index) or 0
-- 		local _bIndex = tonumber(b.index) or 0
-- 		return _aIndex < _bIndex
--     end)
    
--     _cache_AvatarDuoBaoDrawController_config.drawItemsMap = {
--         [_DRAW_TYPE_GOLD] = {},
--         [_DRAW_TYPE_DIAMOND] = {}
--     }
--     for _, v in ipairs(_xmlData) do
--         table.insert(_cache_AvatarDuoBaoDrawController_config.drawItemsMap[tonumber(v.gamble_type)], v)
--     end
    
-- end

function AvatarDuoBaoDrawController:requestDrawData(type)
    Drequire("game.avatar.AvatarDuoBaoDrawCmd").create("info", self, {
        gambleType = tonumber(type)
    }, function(result)
        self:onReceiveDrawData(result)
    end):send()
end

function AvatarDuoBaoDrawController:requestDoDraw(type, num, useFree, callback)
    Drequire("game.avatar.AvatarDuoBaoDrawCmd").create("draw", self, {
        gambleType = tonumber(type),
        num = tonumber(num),
        useFree = (useFree and true or false)
    }, function(result)
        if result.goodsArray then
            self:onParseDrawGoodsArray(type, result.goodsArray)
        end
        callback(result)
    end):send()
end

function AvatarDuoBaoDrawController:reqLuckDrawByAd( adType, callback )
    local type = 0
    if adType == AD_TYPE.DUOBAO_DRAW_DIAMOND then
        type = _DRAW_TYPE_DIAMOND
    elseif adType == AD_TYPE.DUOBAO_DRAW_GOLD then
        type = _DRAW_TYPE_GOLD
    end

    if type > 0 then
        Drequire("game.avatar.AvatarDuoBaoDrawCmd").create("draw", self, {
            gambleType = tonumber(type),
            num = 1,
            useFree = false,
            videoType = adType
        }, function(result)
            require("game.controller.LuaAdController").getInstance():setData(result)
            if result.goodsArray then
                self:onParseDrawGoodsArray(type, result.goodsArray)
            end
            callback(result)
        end):send()
    end
end

function AvatarDuoBaoDrawController:requestBoxReward(type, index, callback)
    Drequire("game.avatar.AvatarDuoBaoDrawCmd").create("box", self, {
        gambleType = tonumber(type),
        targetIndex = index
    }, callback):send()
end

-- 请求商城数据
function AvatarDuoBaoDrawController:requestMallData(callback)
    Drequire("game.avatar.AvatarDuoBaoDrawCmd").create("mall", self, nil, callback):send()
end

function AvatarDuoBaoDrawController:requestBuyMallItem(productId, num, callback)
    Drequire("game.avatar.AvatarDuoBaoDrawCmd").create("buy", self, {
        targetId = tostring(productId),
        num = num
    }, callback):send()
end

function AvatarDuoBaoDrawController:onReceiveDrawData(result)
    local type = tonumber(result.infoDic.gambleType)

    -- if result.goodsArray then
    --     table.sort(result.goodsArray, function(a, b)
    --         local _aIndex = tonumber(a.index) or 0
    --         local _bIndex = tonumber(b.index) or 0
    --         return _aIndex < _bIndex
    --     end)
    -- end

    if not self.drawInfoData then
        self.drawInfoData = {}
    end
    self.drawInfoData[type] = result
    self:onParseDrawGoodsArray(type, result.goodsArray)

    self.activeEndAt = (result.endTime or 0) / 1000
    self:setNextFreeBuyOneAt(type)
    self:viewStateChanged()
end

function AvatarDuoBaoDrawController:onParseDrawGoodsArray(type, goods)
    if self.drawInfoData[type] then
        table.sort(goods, function(a, b)
            local _aIndex = tonumber(a.index) or 0
            local _bIndex = tonumber(b.index) or 0
            return _aIndex < _bIndex
        end)
        self.drawInfoData[type].goodsArray = goods
    end
end

function AvatarDuoBaoDrawController:getActivityTimeUpAt()
    return self.activeEndAt or 0
end

function AvatarDuoBaoDrawController:getDrawItems(type)
    -- return _cache_AvatarDuoBaoDrawController_config[tonumber(type)]
    return self.drawInfoData and self.drawInfoData[type] and self.drawInfoData[type].goodsArray or {}
end

function AvatarDuoBaoDrawController:getLuckyNum(type)
    if self.drawInfoData and self.drawInfoData[type] then
        return tonumber(self.drawInfoData[type].luckyNum or 0)
    else
        return 0
    end
end

function AvatarDuoBaoDrawController:getMaxLuckyNum(type)
    if self.drawInfoData and self.drawInfoData[type] and self.drawInfoData[type].gambleData then
        return tonumber(self.drawInfoData[type].gambleData.luckyLimit or 0)
    else
        return 0
    end
end

-- function AvatarDuoBaoDrawController:getLastFreeTime(type)
--     local num = tonumber(self.drawInfoData and self.drawInfoData[type] and self.drawInfoData[type].lastFreeTime or 0)
--     num = num / 1000
--     return num
-- end

-- function AvatarDuoBaoDrawController:getFreeTimeInterval(type)
--     local num = tonumber(self.drawInfoData and self.drawInfoData[type] and self.drawInfoData[type].gambleData and self.drawInfoData[type].gambleData.freeCD or 0)
--     num = num * 60 * 60
--     return num
-- end
function AvatarDuoBaoDrawController:getNextFreeBuyOneAt(type)
     return self.nextFreeDrawAt and self.nextFreeDrawAt[type] or 0
end
function AvatarDuoBaoDrawController:setNextFreeBuyOneAt(type, last)
    local intervalHours = 24
    if self.drawInfoData and self.drawInfoData[type] and self.drawInfoData[type].gambleData then
        intervalHours = self.drawInfoData[type].gambleData.freeCD
    end
    local interval = intervalHours * 60 * 60

    if not last then
        if self.drawInfoData and self.drawInfoData[type] then
            last = self.drawInfoData[type].lastFreeTime / 1000 or 0
        else
            last = 0
        end
    end
    if not self.nextFreeDrawAt then
        self.nextFreeDrawAt = {}
    end
    self.nextFreeDrawAt[type] = last + interval
end
function AvatarDuoBaoDrawController:hasFreeBuyChance(type)
    local next = self:getNextFreeBuyOneAt(type)
    local now = getTimeStamp()
    return now >= next
end

function AvatarDuoBaoDrawController:getLuckyDrawPrice(type)
    if self.drawInfoData and self.drawInfoData[type] and self.drawInfoData[type].gambleData then
        return {
            priceOne = tonumber(self.drawInfoData[type].gambleData.price or 0),
            priceTen = tonumber(self.drawInfoData[type].gambleData.price or 0) * 10,
            priceType = tonumber(self.drawInfoData[type].gambleData.currType or 1),
            priceItemId = self.drawInfoData[type].gambleData.currId
        }
    end
end

function AvatarDuoBaoDrawController:getProgressData(type)
    if self.drawInfoData and self.drawInfoData[type] then
        local maxProcess = tonumber(self.drawInfoData[type].gambleData.maxProcess)
        local processBoxLimit = self.drawInfoData[type].gambleData.processBoxLimit -- "1;200|2;500|3;1000"-- _cache_AvatarDuoBaoDrawController_config.drawTypeInfoMap[type].processBoxLimit
        local processBoxReward = self.drawInfoData[type].gambleData.processBoxReward

        local nowProgress = tonumber(self.drawInfoData[type].process)
        local processBoxStr = self.drawInfoData[type].processBoxStr
        
        local progressInfo = {}
        local arr = string.split(processBoxLimit,"|")
        local rewards = {}
        for k, v in ipairs(arr) do
            local arr2 = string.split(v,";")
            local score = tonumber(arr2[2])
            rewards[tonumber(arr2[1])] = {
                score = score
            }
            if score <= nowProgress then
                rewards[tonumber(arr2[1])].fin = true
            end
        end
        arr = string.split(processBoxReward,"|")
        for _, v in ipairs(arr) do
            local arr2 = string.split(v,";")
            rewards[tonumber(arr2[1])].reward = tonumber(arr2[2])
        end

        if processBoxStr and processBoxStr ~= "" then
            arr = string.split(processBoxStr,";")
            for _, v in pairs(arr) do
                rewards[tonumber(v)].gained = true
            end
        end
        local data = {}
        for k, v in ipairs(rewards) do
            local one = {
                reward=tostring(v.reward), 
                -- state= and "1" or "2", 
                target=v.score, 
                curPro=nowProgress, 
                maxPro=maxProcess
            }
            if v.fin then
                if v.gained then
                    one.state = "1"
                else
                    one.state = "2"
                end
            else
                one.state = "0"
            end
            
            table.insert(data, one)
        end
        
        local function sortfunc(a,b)
            return tonumber(a.target) < tonumber(b.target) 
        end
        if data and #(data) > 0 then
            table.sort(data, sortfunc)
            local len = #(data)
            for i = 1, len do --插入bottom数据
                data[i].getRewardFunc = function()
                    self:requestBoxReward(type, i, function (result)
                        if result and result.rewardArray then
                            if not self.drawInfoData[type].processBoxStr or self.drawInfoData[type].processBoxStr == "" then
                                self.drawInfoData[type].processBoxStr = tostring(i)
                            else
                                self.drawInfoData[type].processBoxStr = self.drawInfoData[type].processBoxStr .. ";" .. tostring(i)
                            end
                            createTableFlyReward(result.rewardArray)
                        end
                    end)
                end
                if i == 1 then
                    data[1].bottom = "0"
                else
                    data[i].bottom = data[i - 1].target
                end
            end
        end
        return data

    end
end

function AvatarDuoBaoDrawController:getDrawInfoData( viewType )
    if viewType then
        return self.drawInfoData and self.drawInfoData[viewType]
    end
    return self.drawInfoData
end

function AvatarDuoBaoDrawController:viewStateChanged()
    XEvtTimer:post("AvatarDuoBaoDrawView:refresh", {
        action = "refresh"
    })
end

function AvatarDuoBaoDrawController:updateLuckyNum(type, luckyNum, process)
    if self.drawInfoData and self.drawInfoData[type] then
        self.drawInfoData[type].luckyNum = tonumber(luckyNum)
        if process then
            self.drawInfoData[type].process = tonumber(process)
        end
        -- CCSafeNotificationCenter:postNotification('AvatarDuoBaoDrawView:refreshLuckNum')
        XEvtTimer:post("AvatarDuoBaoDrawView:refresh", {
            action = "refreshLuckyNum"
        })
    end
end

function AvatarDuoBaoDrawController:gainItemsAsReward(itemArr, hasAni)
    
    -- createTableFlyReward(arr)

	-- local _cArray = luaToArray(arr)

    -- if hasAni or hasAni == nil then
    --     PortActController:call("flyReward", _cArray, true)
    -- end
    -- if hasReward or hasReward == nil then
    --     RewardController:call("retReward", _cArray)
    -- end
    -- gainItemsAsReward(arr, not hasAni)
end

-- function AvatarDuoBaoDrawController:getDrawResultItemByIndex(type, index)
--     if self.drawInfoData and self.drawInfoData[type] and self.drawInfoData[type].goodsArray and #self.drawInfoData[type].goodsArray > 0 then
--         for k, v in pairs(self.drawInfoData[type].goodsArray) do
--             if tostring(v.index) == tostring(index) then
--                 return v
--             end
--         end
--     end
-- end

function AvatarDuoBaoDrawController:loadHasAni()
    self.notAni = ccud:getIntegerForKey(UDDuoBaoHasNoAniKey, 0)
end
function AvatarDuoBaoDrawController:getHasAni()
    return self.notAni ~= 1
end

function AvatarDuoBaoDrawController:setHasAni(has)
    if has then
        self.notAni = 0
    else
        self.notAni = 1
    end
    ccud:setIntegerForKey(UDDuoBaoHasNoAniKey, self.notAni)
end

function AvatarDuoBaoDrawController:getIsRewardLighting(type, index)
    if self.GoodsIndexMap and self.GoodsIndexMap[tonumber(type)] and self.GoodsIndexMap[tonumber(type)][tonumber(index)] then
        return tonumber(self.GoodsIndexMap[tonumber(type)][tonumber(index)].lighten or 0) == 1
    end
    return false
end

function AvatarDuoBaoDrawController:isRankOpen()
    -- return isFunOpenByKey("gamble_mall_rank")
    return (isFunOpenByKey("gamble_mall_local_rank") or isFunOpenByKey("gamble_mall_global_rank"))
end

function AvatarDuoBaoDrawController:isTicketOpen(  )
    local shopMallCtrl = require("game.shop.ShopMallController")
    return shopMallCtrl.isTicketOpen()
end

function AvatarDuoBaoDrawController:getActId(  )
    return "57393"
end

return AvatarDuoBaoDrawController

