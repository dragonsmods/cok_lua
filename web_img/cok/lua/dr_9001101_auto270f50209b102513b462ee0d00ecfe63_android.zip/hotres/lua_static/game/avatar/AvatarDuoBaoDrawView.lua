--[[	
	装备夺宝抽奖
	2019.5.13	Xu
]]
local AvatarDuoBaoDrawView =
	class(
	"AvatarDuoBaoDrawView",
	function()
		return PopupBaseView:create()
	end
)
AvatarDuoBaoDrawView.__index = AvatarDuoBaoDrawView
local LuaAdController = require("game.controller.LuaAdController").getInstance()
--------------------------------------------------------------------------------------
function AvatarDuoBaoDrawView:create()
	local view = AvatarDuoBaoDrawView.new()
	CCLoadSprite:call("loadDynamicResourceByName", "AvatarDuoBao_face")
	CCLoadSprite:call("loadDynamicResourceByName", "SkinFetter_face")
	Drequire("game.avatar.AvatarDuoBaoDrawView_ui"):create(view, 1)
	view.ctl = Drequire("game.avatar.AvatarDuoBaoDrawController").new()

	if view:initView() == false then
		return nil
	end
	return view
end

function AvatarDuoBaoDrawView:initView()
	Dprint("AvatarDuoBaoDrawView:initView")
	self:changeViewType(_DRAW_TYPE_DIAMOND)

    self.ui.m_labelTitle:setString(getLang("176815"))
	self.ui.m_buyOneSpriteLabel:setString(getLang("176924"))
	self.ui.m_buyTenSpriteLabel:setString(getLang("176925"))
	self.ui.m_openOneLabel:setString(getLang("176825", "1"))
	self.ui.m_openTenLabel:setString(getLang("176825", "10"))
	self.ui.m_luckyNumLabel:setString(getLang("176819", "0"))

	self:initLuckyStateView()
	self:checkRankOpen()
	self:requestServerTicketId()
	self.m_duoBaoKey = "duobaov1"
	self.m_nowCheckState = not(utils.accessLocal(self.m_duoBaoKey,nil,'0') == '1')
	self:onClickCheckkBox()

    -- 视频广告
	self.ui.m_nodeAd:setVisible(false)
	self:initAd(_DRAW_TYPE_GOLD)
	self:initAd(_DRAW_TYPE_DIAMOND)
	self:refresh()

	utils.attachBackFrom(self,"57393")

	return true
end

function AvatarDuoBaoDrawView:initAd( viewType )
	local adType
	if viewType == _DRAW_TYPE_DIAMOND then
		adType = AD_TYPE.DUOBAO_DRAW_DIAMOND
	else
		adType = AD_TYPE.DUOBAO_DRAW_GOLD
	end

	local function callback()
		self:doADraw(1,true)
	end

	LuaAdController:initAd(adType)
	LuaAdController:getData({adType})
	LuaAdController:initTypViewMgr(adType, callback)
end

function AvatarDuoBaoDrawView:refresh(  )
	if self.viewType == _DRAW_TYPE_DIAMOND then
		self.adType = AD_TYPE.DUOBAO_DRAW_DIAMOND
	else
		self.adType = AD_TYPE.DUOBAO_DRAW_GOLD
	end
    -- cclog("AvatarDuoBaoDrawView:refresh")
    -- 刷新广告
	local _isCanPlay = LuaAdController:isCanPlay(self.adType)
	if _isCanPlay then
		if self.m_adSchedule then
			self:getScheduler():unscheduleScriptEntry(self.m_adSchedule)
		end
		self:updateAd()
		self.m_adSchedule = self:getScheduler():scheduleScriptFunc(function(dt) self:updateAd() end, 1, false)
	end
end

-- 更新广告倒计时
function AvatarDuoBaoDrawView:updateAd()
	local _offset = LuaAdController:getNextAdStamp() - getTimeStamp()
    local adInfo = LuaAdController:getDataByTypes(self.adType)
    -- utils.dump( adInfo, "updateAd~~~~~~~~~" )
	if adInfo and adInfo.open > 0 and adInfo.cur < adInfo.max then
		self.ui.m_nodeAd:setVisible(true)
		if self.drawAniPlaying then
			self.ui.m_btnAd:setEnabled(false)
		else
			self.ui.m_btnAd:setEnabled(_offset <= 0)
		end
		if _offset > 0 then
			self.ui.m_labelAd:setString(format_time(_offset))
		else
			self.ui.m_labelAd:setString(string.format('%d/%d', adInfo.max - adInfo.cur, adInfo.max))
		end
	else
		self.ui.m_nodeAd:setVisible(false)
	end

	if self.ui.m_nodeAd:isVisible() == false then
		if self.m_adSchedule then
			self:getScheduler():unscheduleScriptEntry(self.m_adSchedule)
		end
	end
end

--播放视频广告
function AvatarDuoBaoDrawView:onClickBtnAd()
	LuaAdController:playVideo(self.adType)
	-- LuaAdController:callback( self.adType )
end

function AvatarDuoBaoDrawView:onEnter()

	local shopMallCtrl = require("game.shop.ShopMallController")
	shopMallCtrl.getAfterBuyTicketEvent():add(self.refreshMoneyLabel,self)

	self:initItemsView()

	self:refreshView()
	self:setActivityTimeUpCountdown(true)
	self:setFreeDrawCountdown(true)

	-- local function onRefresh(ref)
	-- 	self:refreshView()
	-- end
	-- local t = tolua.cast(self, "cc.Node")
	-- local handler = t:registerHandler(onRefresh)
	-- CCSafeNotificationCenter:registerScriptObserver(self, handler, "AvatarDuoBaoDrawView:refresh")
	XEvtTimer:on("AvatarDuoBaoDrawView:refresh", function(data)
		if data.action == "refresh" then
			self:refreshView()
		elseif data.action == "refreshHasAni" then
			self:refreshHasAni()
		elseif data.action == "refreshLuckyNum" then
			self:refreshLuckyStateView()
			self:refreshMoneyView()
		elseif data.action == "refreshDrawItemList" then
			self:refreshItemsView()
		end
	end)

	-- function onRefreshLuckNum(ref)
	-- 	self:refreshLuckyStateView()
	-- 	self:refreshMoneyView()
	-- end
	-- CCSafeNotificationCenter:registerScriptObserver(self, t:registerHandler(onRefreshLuckNum), "AvatarDuoBaoDrawView:refreshLuckNum")

	XEvtTimer:on("AvatarDuoBaoDrawView:doADraw", function(data)
		-- dump(data,"AvatarDuoBaoDrawView:doADraw")
		if data.times == 10 then
			self:onClickBuyTenBtn()
		else
			self:onClickBuyOneBtn()
		end
	end)

	registerScriptObserver(self, self.refresh, 'msg.getAdReward.refresh')
    registerScriptObserver(self, self.refresh, "LuaAdController:adsFinishPreload")
end

function AvatarDuoBaoDrawView:onExit()
	-- CCSafeNotificationCenter:unregisterScriptObserver(self, "AvatarDuoBaoDrawView:refresh")
	XEvtTimer:off("AvatarDuoBaoDrawView:refresh")
	-- CCSafeNotificationCenter:unregisterScriptObserver(self, "AvatarDuoBaoDrawView:refreshLuckNum")
	XEvtTimer:off("AvatarDuoBaoDrawView:doADraw")
	self:setActivityTimeUpCountdown(false)
	self:setFreeDrawCountdown(false)
	if self.schAni then
		self:getScheduler():unscheduleScriptEntry(self.schAni)
		self.schAni = nil
	end


	local shopMallCtrl = require("game.shop.ShopMallController")
	shopMallCtrl.getAfterBuyTicketEvent():remove(self.refreshMoneyLabel,self)

	unregisterScriptObserver(self, 'msg.getAdReward.refresh')
    unregisterScriptObserver(self, "LuaAdController:adsFinishPreload")
	if self.m_adSchedule then
		self:getScheduler():unscheduleScriptEntry(self.m_adSchedule)
    end
end

function AvatarDuoBaoDrawView:setActivityTimeUpCountdown(active) -- 设置活动时间倒计时定时器
	if self.activityCountdownTimer then
		self:getScheduler():unscheduleScriptEntry(self.activityCountdownTimer)
		self.activityCountdownTimer = nil
	end
	if active then
		self.activityCountdownTimer =
			self:getScheduler():scheduleScriptFunc(
			function(dt)
				self:refreshActivityCountdownView()
			end,
			1.0,
			false
		)
	end
end
function AvatarDuoBaoDrawView:setFreeDrawCountdown(active) -- 设置活动时间倒计时定时器
	if self.freeDrawCountdownTimer then
		self:getScheduler():unscheduleScriptEntry(self.freeDrawCountdownTimer)
		self.freeDrawCountdownTimer = nil
	end
	if active then
		self.freeDrawCountdownTimer =
			self:getScheduler():scheduleScriptFunc(
			function(dt)
				self:refreshFreeDrawCountdownView()
			end,
			1.0,
			false
		)
	end
end

function AvatarDuoBaoDrawView:refreshView()
	self:refreshActivityCountdownView()
	self:refreshLuckyStateView()
	self:refreshItemsView()
	self:resetItemsSelState()
	-- self:refreshProgressView()
	self:refreshMoneyView()

	self:refreshFreeDrawCountdownView()
	self:refreshDrawProgressView()
	self:refreshHasAni()

end

function AvatarDuoBaoDrawView:refreshMoneyViewOld() -- 刷新玩家资源
	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")

	-- 钻石或金币或水晶数量
	local spf, size = self:getMoneyIconByType(self.viewType)
	if self.viewType == _DRAW_TYPE_GOLD then
		self.ui.m_moneyIconSpr:setSpriteFrame(spf)
		self.ui.m_moneyNumLabel:setString(CC_CMDITOA(playerInfo:getProperty("gold")))
	else
		-- local spf = CCLoadSprite:call("loadResource", "diamond.png")
		self.ui.m_moneyIconSpr:setSpriteFrame(spf)
		self.ui.m_moneyNumLabel:setString(CC_CMDITOA(PlayerInfoController:getCrystalGold()))
	end
	CCCommonUtilsForLua:call("setSpriteMaxSize", self.ui.m_moneyIconSpr, size, true)
end

function AvatarDuoBaoDrawView:requestServerTicketId(  )
	if self.ctl:isTicketOpen() then
		local ShopMallController = require("game.shop.ShopMallController")
		ShopMallController.showBuyTicketView(2,function ( tbl )
			if tbl and tbl.goodsArray then
				local p_arr = string.splitNSep(tbl.goodsArray[1].numPrice,"|;")
				self.m_baseDiamondPrice = p_arr and p_arr[1] and tonumber(p_arr[1][2]) or 1
			end
		end)
	end
end

function AvatarDuoBaoDrawView:getExChangeDiamondPrice(  )
	return self.m_baseDiamondPrice or 1
end

function AvatarDuoBaoDrawView:refreshMoneyView() -- 刷新玩家资源
	if not self.ctl:isTicketOpen() then
		self:refreshMoneyViewOld()
		return
	end
	-- local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")

	-- 钻石或金币或水晶数量
	local spf, size = self:getMoneyIconByType(self.viewType)
	if self.viewType == _DRAW_TYPE_GOLD then
		self.ui.m_moneyIconSpr:setSpriteFrame(spf)
		-- self.ui.m_moneyNumLabel:setString(CC_CMDITOA(playerInfo:getProperty("gold")))
	else
		-- local spf = CCLoadSprite:call("loadResource", "diamond.png")
		self.ui.m_moneyIconSpr:setSpriteFrame(spf)
		-- self.ui.m_moneyNumLabel:setString(CC_CMDITOA(PlayerInfoController:getCrystalGold()))
	end

	self:refreshMoneyLabel()
	CCCommonUtilsForLua:call("setSpriteMaxSize", self.ui.m_moneyIconSpr, size, true)
end

function AvatarDuoBaoDrawView:refreshMoneyLabel(  )
	self.ui.m_moneyNumLabel:setString("")

	local currId = self:getCurrId()
	if currId then
		local _,info = utils.getItemNameByItemId(currId)
		self.ui.m_moneyNumLabel:setString(CC_CMDITOA(info and info:call("getCNT") or 0))
		return
	end

	if self.m_beUseItemAsCurrency then
		return
	end

	if self.viewType == _DRAW_TYPE_GOLD then
		self.ui.m_moneyNumLabel:setString(CC_CMDITOA(GlobalDataCtr.getPlayerGold()))
	else
		self.ui.m_moneyNumLabel:setString(CC_CMDITOA(PlayerInfoController:getCrystalGold()))
	end
end

function AvatarDuoBaoDrawView:refreshActivityCountdownView() -- 刷新活动倒计时
	local now = getTimeStamp()
	local timeUpAt = self.ctl:getActivityTimeUpAt()
	local difTime = timeUpAt - now
	if difTime < 0 then
		-- self.ui.m_activityTimerIconSpr:setVisible(false)
		-- self.ui.m_timeup_label:setVisible(false)

		self.ui.m_timeup_label:setString(format_time(0))
	else
		-- self.ui.m_activityTimerIconSpr:setVisible(true)
		-- self.ui.m_timeup_label:setVisible(true)
		self.ui.m_timeup_label:setString(format_time(difTime))
	end
end

function AvatarDuoBaoDrawView:initLuckyStateView()
	CCCommonUtilsForLua:call("setSpriteGray", self.ui.m_luckyProgressFrameSpr, true)
end

function AvatarDuoBaoDrawView:refreshLuckyStateView() -- 刷新界面中间描述
	tolua.cast(self.ui.m_luckyProgressBar, "cc.ProgressTimer")

	local spfBg, spfLight, barSpr
	if self.viewType == _DRAW_TYPE_DIAMOND then
		spfBg = CCLoadSprite:call("loadResource", "adb_dragon_bg_purple.png")
		spfLight = CCLoadSprite:call("loadResource", "adb_progress_light_purple.png")
		barSpr = CCLoadSprite:call("createSprite", "adb_progress_fill_purple.png")
	else
		spfBg = CCLoadSprite:call("loadResource", "adb_dragon_bg_yellow.png")
		spfLight = CCLoadSprite:call("loadResource", "adb_progress_light_yellow.png")
		barSpr = CCLoadSprite:call("createSprite", "adb_progress_fill_yellow.png")
	end
	self.ui.m_center_dragon_bg:setSpriteFrame(spfBg)
	self.ui.m_progressLightSpr:setSpriteFrame(spfLight)

	self.ui.m_luckyProgressBar:setSprite(barSpr)

	local luckyNum = self.ctl:getLuckyNum(self.viewType) or 0
	local total = self.ctl:getMaxLuckyNum(self.viewType) or 1
	self.ui.m_luckyNumLabel:setString(getLang("176819", tostring(luckyNum)))

	local progress = 0
	if not total or total <= 0 then
		progress = 0
	else
		progress = luckyNum / total * 100
		if progress > 100 then
			progress = 100
		end
	end

	self.ui.m_progressLightSpr:setVisible(false)
	-- 为了达到美术效果，进度条下面20%左右被遮挡，所以跳过，进度条上方10%无法加特效，所以跳过
	if progress == 0 then
		CCCommonUtilsForLua:call("setSpriteGray", self.ui.m_center_dragon_bg, true)
	elseif progress >= 100 then
		CCCommonUtilsForLua:call("setSpriteGray", self.ui.m_center_dragon_bg, false)
	else
		CCCommonUtilsForLua:call("setSpriteGray", self.ui.m_center_dragon_bg, false)
		progress = 30 + progress * 0.6

		local barHeight = 150
		self.ui.m_progressLightSpr:setVisible(true)
		self.ui.m_progressLightSpr:setPositionY(barHeight * progress / 100)
	end

	self.ui.m_luckyProgressBar:setPercentage(progress)

	self.ui.m_progressRoot:removeAllChildren()
	local data = self.ctl:getProgressData(self.viewType)
	local view = Drequire("game.CommonPopup.CommonProgressView").create(data, 600)
	if view then
		self.ui.m_progressRoot:addChild(view)
	end
end

function AvatarDuoBaoDrawView:initItemsView()
	-- local shortOneWidth = math.min(rect.width, rect.height)

	local TotalItemCountH = 4
	local TotalItemCountV = 5
	local itemWidth = 100
	local itemHeight = 100

	local dialSize = self.ui.m_dialNode:getContentSize()
	local itemsNodeSize = self.ui.m_itemsRoot:getContentSize()
	local centerSize = self.ui.m_centerProgressNode:getContentSize()
	local bottomSize = self.ui.m_bottomNode:getContentSize()

	-- if centerSize.height > 0.5 * shortOneWidth then
	-- 	self.ui.m_centerProgressNode:setScale(shortOneWidth / centerSize.height * 0.4)
	-- 	bScaleToFixScreen = true
	-- end
	local bScaleToFixScreen = false

	if itemsNodeSize.height < itemHeight * 3.5 + centerSize.height then
		bScaleToFixScreen = true
	end

	if bScaleToFixScreen then
		local newHeight = itemHeight * 4 + centerSize.height
		self.ui.m_dialNode:setContentSize(dialSize.width, newHeight)
		self.ui.m_itemsRoot:setContentSize(itemsNodeSize.width, newHeight)
		self.ui.m_bottomNode:setContentSize(bottomSize.width, bottomSize.height + newHeight - dialSize.height)
		self.ui.m_bottomNode:setScale(bottomSize.height / (bottomSize.height + newHeight - dialSize.height))
		itemsNodeSize.width = dialSize.width
		itemsNodeSize.height = newHeight
		self.ui.m_centerProgressNode:setPositionY(newHeight / 2)
	end

	local width = itemsNodeSize.width
	local height = itemsNodeSize.height


	-- local itemWidth = shortOneWidth / 7
	-- local itemHeight = Math.min(rect.width, rect.height) / 6.4
	-- local itemHeight = itemWidth

	local edgeH = itemWidth * 0.2
	local edgeV = itemHeight * 0.3

	local disH = (width - TotalItemCountH * itemWidth - 2 * edgeH) / (TotalItemCountH - 1)
	disH = math.min(disH, 50)
	edgeH = (width - TotalItemCountH * itemWidth - disH * (TotalItemCountH - 1)) / 2
	local disV = (height - TotalItemCountV * itemHeight - 2 * edgeV) / (TotalItemCountV - 1)

	local x
	local y = edgeV + 0.5 * itemHeight
	self.itemPosArray = {}
	for i = 1, TotalItemCountV do
		x = edgeH + 0.5 * itemWidth
		for j = 1, TotalItemCountH do
			if i == 1 or i == TotalItemCountV or j == 1 or j == TotalItemCountH then
				
				local order = 0
				if i == TotalItemCountV and j == 1 then
					order = 1
				elseif i == TotalItemCountV then
					order = j
				elseif j == TotalItemCountH then
					order = TotalItemCountH + TotalItemCountV - i
				elseif i == 1 then
					order = TotalItemCountH + TotalItemCountV + TotalItemCountH - j - 1
				elseif j == 1 then
					order = TotalItemCountH + TotalItemCountV + TotalItemCountH + i - 3
				end
				table.insert(self.itemPosArray, {
					x = x,
					y = y,
					line = i,
					row = j,
					order = order
				})
			end
			x = x + disH + itemWidth
		end
		y = y + disV + itemHeight
	end
	table.sort(self.itemPosArray, function (a, b)
		return a.order < b.order
	end)

	-- local scaleVal = nil
	self.itemNodeArray = {}
	self.ui.m_itemsRoot:removeAllChildren()
	for k, v in ipairs(self.itemPosArray) do
		local itemNode = Drequire("game.avatar.AvatarDuoBaoDrawItemView"):create()
		self.ui.m_itemsRoot:addChild(itemNode)
		itemNode:setPositionX(v.x)
        itemNode:setPositionY(v.y)
		itemNode:setAnchorPoint(0.5,0.5)
		-- if bScaleToFixScreen then
		-- 	if not scaleVal then
		-- 		local boxSize = itemNode.ui.m_root:getBoundingBox()
		-- 		scaleVal = itemWidth / boxSize.width
		-- 	end
		-- 	if scaleVal ~= 1 then
		-- 		itemNode.ui.m_root:setScale(scaleVal)
		-- 	end
		-- end

		self.itemNodeArray[k] = itemNode
	end
end
function AvatarDuoBaoDrawView:refreshItemsView() -- 刷新周围一圈奖品
	local itemsData = self.ctl:getDrawItems(self.viewType)
	if not itemsData or #itemsData == 0 then
		return
	end

	for k, v in pairs(itemsData) do
		local node = self.itemNodeArray[tonumber(v.index)]
		node:refreshCell(v)
	end
	self:resetItemsSelState()
end
function AvatarDuoBaoDrawView:resetItemsSelState()
	if self.schAni then
		self:getScheduler():unscheduleScriptEntry(self.schAni)
		self.schAni = nil
	end
	for k, v in pairs(self.itemNodeArray or {}) do
		v:doLighting(false)
		v:doSelected(false)
		v:setCountLabel(0)
	end
end

function AvatarDuoBaoDrawView:refreshDrawProgressView()
	local price = self.ctl:getLuckyDrawPrice(self.viewType)
	if not price then
		self.ui.m_nodeBuyRoot:setVisible(false)
		return
	else
		self.ui.m_nodeBuyRoot:setVisible(true)
	end
	
	local spf, size = self:getMoneyIconByType(price.priceType)
	-- local spf = self:getMoneyIconByType(price.priceType)
	self.ui.m_costOneIconSpr:setSpriteFrame(spf)
	CCCommonUtilsForLua:call("setSpriteMaxSize", self.ui.m_costOneIconSpr, size, true)
	spf,size = self:getMoneyIconByType(price.priceType)
	self.ui.m_costTenIconSpr:setSpriteFrame(spf)
	CCCommonUtilsForLua:call("setSpriteMaxSize", self.ui.m_costTenIconSpr, size, true)

	self.ui.m_buyOneCostLabel:setString(tostring(price.priceOne))
	self.ui.m_buyTenCostLabel:setString(tostring(price.priceTen))

end

function AvatarDuoBaoDrawView:refreshFreeDrawCountdownView()
	local nextFreeAt = self.ctl:getNextFreeBuyOneAt(self.viewType)
	local now = getTimeStamp()
	if now >= nextFreeAt then
		self.ui.m_buyOneFreeLabel:setVisible(true)
		self.ui.m_costOneIconSpr:setVisible(false)
		self.ui.m_buyOneCostLabel:setVisible(false)

		self.ui.m_freeTimerLabel:setVisible(false)
	else
		self.ui.m_buyOneFreeLabel:setVisible(false)
		self.ui.m_costOneIconSpr:setVisible(true)
		self.ui.m_buyOneCostLabel:setVisible(true)

		self.ui.m_freeTimerLabel:setVisible(true)

		self.ui.m_freeTimerLabel:setString(format_time(nextFreeAt - now))
	end
end

function AvatarDuoBaoDrawView:refreshHasAni()
	self.ui.m_selectSpr:setVisible(not self.ctl:getHasAni())
end

-- 打开帮助
function AvatarDuoBaoDrawView:onClickBtnFaq()
	local params = {}
    params.title = getLang("102271") --102271=详情
    params.info = getLang("176831", self.ctl:getMaxLuckyNum(self.viewType) or 1)
    local view = Drequire("game.DressIntroduction.CommonInfoViewNew"):create(params)
    PopupViewController:addPopupView(view)
end

function AvatarDuoBaoDrawView:onClickCheckkBox(pSender, event)

	local prev_state = self.m_nowCheckState
	local next_state = not prev_state
	self.m_nowCheckState = next_state
	-- cclog("onClickCheckkBox,,, %s",self.m_nowCheckState)
	utils.accessLocal(self.m_duoBaoKey,next_state and '1' or '0')
	self.ui.m_checkBox:setVisible(next_state)
	require("game.flyHint.PushNoticeMgr").getInstance():setNoticeState("176926",not next_state)
	if not self.m_setShareLab then
		self.m_setShareLab = true
		self.ui.m_shareLab:setString(getLang("176940"))
	end
end

function AvatarDuoBaoDrawView:onSwitchHasAniBtnClick()
	self.ctl:setHasAni(not self.ctl:getHasAni())
	self:refreshHasAni()
end

function AvatarDuoBaoDrawView:onDiamondTabBtn()
	if self.drawAniPlaying or not self.ctl then
		return 
	end
	self:changeViewType(_DRAW_TYPE_DIAMOND)
	
end

function AvatarDuoBaoDrawView:onDiamondRankBtn()
	self:changeToRankView(1)
end

function AvatarDuoBaoDrawView:onGoldRankBtn()
	self:changeToRankView(2)
end

function AvatarDuoBaoDrawView:onGoldTabBtn()
	if self.drawAniPlaying or not self.ctl then
		return 
	end
	self:changeViewType(_DRAW_TYPE_GOLD)
end

-- 打开商城
function AvatarDuoBaoDrawView:onCrystalShopBtn()
	local view = myRequire("game.avatar.AvatarDuoBaoDrawMallView").create(self, result)
	PopupViewController:call("addPopupView", view)
end

function AvatarDuoBaoDrawView:onClickBuyOneBtn()
	self:doADraw(1)
end

function AvatarDuoBaoDrawView:onClickBuyTenBtn()
	self:doADraw(10)
end

function AvatarDuoBaoDrawView:doADraw(times,isAdDraw)
	local hasAni = self.ctl:getHasAni()
	if not self.ctl or hasAni and self.drawAniPlaying then
		return 
	end
	local useFree = (times == 1 and self.ctl:hasFreeBuyChance(self.viewType) or false)
	if not isAdDraw and not useFree and not self:checkMoneyEnoughToDraw(times)  then
		return 
	end
	local drawResult = nil -- math.random( 1, 14 )
	local toShowResultData = nil

	self.drawAniPlaying = true
	if hasAni then
		self:startAniOfDraw(self.itemNodeArray, function ()
			return drawResult
		end, function (err)
			self.drawAniPlaying = false
			if not err then
				if toShowResultData then
					self:toDrawResultView(toShowResultData)
				end
			end
		end)
	else
		self:toDrawResultView()
		self.drawAniPlaying = false
	end
	if not isAdDraw then
		self.ctl:requestDoDraw(self.viewType, times, useFree, function (result, err)
			if err then
				drawResult = -1
			else
				if useFree then
					local now = getTimeStamp()
					self.ctl:setNextFreeBuyOneAt(self.viewType, now)
				end
				self.ctl:updateLuckyNum(self.viewType, result.luckyNum, result.newProcess)
				if hasAni then
					local itemsData = self.ctl:getDrawItems(self.viewType)
					drawResult = {}
					for k1, v1 in ipairs(result.itemArray) do
						for k2, v2 in pairs(itemsData or {}) do
							if tostring(v2.index) == tostring(v1.index) then
								table.insert(drawResult, k2)
							end
						end
					end
					toShowResultData = result
				else
					XEvtTimer:post("AvatarDuoBaoDrawResultView:setResult", result)
				end
			end
		end)
	else
		self.ctl:reqLuckDrawByAd(self.adType, function (result)
			self.ctl:updateLuckyNum(self.viewType, result.luckyNum, result.newProcess)
			if hasAni then
				local itemsData = self.ctl:getDrawItems(self.viewType)
				drawResult = {}
				for k1, v1 in ipairs(result.itemArray) do
					for k2, v2 in pairs(itemsData or {}) do
						if tostring(v2.index) == tostring(v1.index) then
							table.insert(drawResult, k2)
						end
					end
				end
				toShowResultData = result
			else
				XEvtTimer:post("AvatarDuoBaoDrawResultView:setResult", result)
			end
		end)
	end
end

function AvatarDuoBaoDrawView:changeViewType(type)
	-- self.ui.m_bottomNode:setVisible(true)
	-- self.ui.m_rankNode:setVisible(false)
	self:setVisibleRankView(false)
	if self.viewType ~= type then
		self.viewType = type
		self:refresh()
		self:refreshView()
		XEvtTimer:delayTimer(0.1, function()
			self.ctl:requestDrawData(type)
		end)
	end
	local idx = 1
	if self.viewType == _DRAW_TYPE_GOLD then
		idx = 2
	end
	self:refreshBtnHighlight(idx)
end

function AvatarDuoBaoDrawView:changeToRankView(type)
	if not self.ctl:isRankOpen() then
		return 
	end
	-- self.ui.m_bottomNode:setVisible(false)
	-- self.ui.m_rankNode:setVisible(true)
	self:setVisibleRankView(true)

	self:createRankView(type)

	local idx = 4
	if type == 1 then
		idx = 3
	end
	self:refreshBtnHighlight(idx)
end

function AvatarDuoBaoDrawView:refreshBtnHighlight(idx)
	local arr = {
		self.ui.m_diamondBtn,
		self.ui.m_goldBtn,
		self.ui.m_diamondRankBtn,
		self.ui.m_glodRankBtn
	}

	local spfArr = {
		"BTN_yeqian01.png",
		"BTN_yeqian02.png"
	}
	local titleColorArr = {
		cc.c3b(236, 220, 170),
		cc.c3b(147, 147, 147)
	}
	for i = 1, #arr do
		local useIdx
		if i == idx then
			useIdx = 1
			arr[i]:setEnabled(false)
		else
			useIdx = 2
			arr[i]:setEnabled(true)
		end
		CCCommonUtilsForLua:call("setButtonSprite", arr[i], spfArr[useIdx])
		CCCommonUtilsForLua:call('setButtonTitleColor', arr[i], titleColorArr[useIdx])
	end
end

function AvatarDuoBaoDrawView:createRankView(type)
	local configLocal, configGlobal
	if type == 1 then
		configLocal = {
			name = "gamble_gem",
			id = "35366005"
		}
		configGlobal = {
			name = "gamble_gem",
			id = "35366006"
		}
	else
		configLocal = {
			name = "gamble_gold",
			id = "35366003"
		}
		configGlobal = {
			name = "gamble_gold",
			id = "35366004"
		}
	end

	local viewSize = self.ui.m_rankNode:getContentSize()
	local rankView 
    if CCCommonUtilsForLua:isFunOpenByKey("gamble_mall_local_rank") and 
        CCCommonUtilsForLua:isFunOpenByKey("gamble_mall_global_rank") then
        rankView = Drequire("game.CommonPopup.commonRank.CommonRankView"):createWithTwoGroup(
            configLocal, configGlobal, viewSize
        )
    else
        if CCCommonUtilsForLua:isFunOpenByKey("gamble_mall_local_rank") then
            rankView = Drequire("game.CommonPopup.commonRank.CommonRankView"):createWithConfigId(
                configLocal.id, configLocal.name, viewSize
            )
        else
            rankView = Drequire("game.CommonPopup.commonRank.CommonRankView"):createWithConfigId(
                configGlobal.id, configGlobal.name, viewSize
            )
        end
    end
    if rankView then
        if self.rankView then
            self.ui.m_rankNode:removeChild(self.rankView)
        end
        self.rankView = rankView
        self.ui.m_rankNode:addChild(self.rankView)
    end
end

function AvatarDuoBaoDrawView:_getGamebleData( type,key )
	type = type or self.viewType
	local infoData = self.ctl:isTicketOpen() and self.ctl:getDrawInfoData(type)
	if infoData and infoData.gambleData and 
		(infoData.gambleData.currType == '3' and not string.isNilOrEmpty(infoData.gambleData[key])) then
		return infoData.gambleData[key]
	end

	return nil
end

function AvatarDuoBaoDrawView:getCurrId( type )
	return self:_getGamebleData(type,"currId")
end

function AvatarDuoBaoDrawView:getGamble_type( type )
	return self:_getGamebleData(type,"gamble_type")
end

function AvatarDuoBaoDrawView:getMoneyIconByType(type)
	if self.ctl:isTicketOpen() then
		local viewType = self.viewType
		-- if self.m_moneyIconMap and self.m_moneyIconMap[viewType] then
		-- 	return self.m_moneyIconMap[viewType],80
		-- end

		local currId = self:getCurrId(viewType)
		if currId then
			local icon = CCCommonUtilsForLua:call("getIcon", tostring(currId))
			if not string.isNilOrEmpty(icon) then
				local spf = utils.getSafeSpriteFrame(icon,"wenhao.png")
				if spf then
					self.m_moneyIconMap = self.m_moneyIconMap or {}
					self.m_moneyIconMap[viewType] = spf

					-- self.m_beUseItemAsCurrency = true
					return spf, 80
				end
			end
		end

		-- if self.m_beUseItemAsCurrency then
		-- 	return
		-- end
	end

	if type == _DRAW_TYPE_GOLD then
		local spf = CCLoadSprite:call("loadResource", "ui_gold.png")
		return spf, 80
	elseif type == _DRAW_TYPE_DIAMOND then
		local spf = CCLoadSprite:call("loadResource", "diamond.png")
		return spf, 80
	end
end

function AvatarDuoBaoDrawView:tellIdLotteryType( id )
	if id == "36000861" then --砖石夺宝
		return 2
	elseif id == "36000860" then --金币
		return 1
	end
	return nil
end

function AvatarDuoBaoDrawView:checkMoneyEnoughToDraw(times)
	local price = self.ctl:getLuckyDrawPrice(self.viewType)
	if not price then
		return false 
	end

	local costMoney = 0

	if times == 1 then
		costMoney = price.priceOne
	elseif times == 10 then
		costMoney = price.priceTen
	end

	local shopMallCtrl = require("game.shop.ShopMallController")
	local hasMoney = 0

	local currId = self:getCurrId()
	if currId then
		local lotteryType = self:tellIdLotteryType(currId)
		-- cclog("checkMoneyEnoughToDraw %s %s",currId,lotteryType)
		if lotteryType and tonumber(lotteryType) then
			-- cclog("checkMoneyEnoughToDraw %s",lotteryType)
			local _,info = utils.getItemNameByItemId(currId)
			hasMoney = info and info:call("getCNT") or 0
			if costMoney > hasMoney then
				if lotteryType == 2 then
					local myDiamond = PlayerInfoController:getCrystalGold()
					if myDiamond < self:getExChangeDiamondPrice() then
						local view = Drequire("game.CommonPopup.ItemGetMethodView"):create("500003")
						PopupViewController:call("addPopupView", view)
					else
						shopMallCtrl.showBuyTicketView(tonumber(lotteryType))
					end
				else
					shopMallCtrl.showBuyTicketView(tonumber(lotteryType))
				end
				return false
			else
				return true
			end
		end
	end

	if self.viewType ==_DRAW_TYPE_GOLD then
		local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
		hasMoney = tonumber(playerInfo:getProperty("gold") or 0)

		if costMoney > hasMoney then
			YesNoDialog:call('gotoPayTips')
            return false
		end
	elseif self.viewType == _DRAW_TYPE_DIAMOND then
		hasMoney = tonumber(PlayerInfoController:getCrystalGold() or 0)

		if costMoney > hasMoney then
			local function confirmFunc()
				local view = Drequire("game.CommonPopup.ItemGetMethodView"):create("500003")
				PopupViewController:call("addPopupView", view)
			end
			local dialog = YesNoDialog:call("show", getLang("9200709"), cc.CallFunc:create(confirmFunc))
			dialog:call("setYesButtonTitle", getLang("106228")) --106228=前往
			
			return false
		end
	end
	return true
end

function AvatarDuoBaoDrawView:toDrawResultView(result)

	local view = Drequire("game.avatar.AvatarDuoBaoDrawResultView").create(self)
	PopupViewController:call("addPopupView", view)
	-- view:setResult(result)
	if result then
		XEvtTimer:post("AvatarDuoBaoDrawResultView:setResult", result)
	end

	XEvtTimer:post("AvatarDuoBaoDrawView:refresh", {
		action = "refreshDrawItemList"
	})
	return view
end

function AvatarDuoBaoDrawView:startAniOfDraw(nodes, thatHasResult, finishCB)
	local state = 0

	local interval = 0
	local frame = 0
	local order = 0

	local tick = 0.05
	local timeout = math.floor( 1 / tick )

	local maxWait = math.floor( 3 / tick )

	local intervalSpeed = 0.5
	local result = nil

	local rotating = true

	local endingWaitFor = 5
	
	local openArrayIndex = 1
	function getIndexByOrder(_order)
		local index = (_order - 1) % #(nodes) + 1
		return index
	end
	function getNodeByOrder(_order)
		local index = getIndexByOrder(_order)
		return nodes[index]
	end
	function openOne(index)
		if index < 1 then
			return 
		end
		local node = getNodeByOrder(index)
		node:doLighting(true)
	end
	function closeOne(index)
		if index < 1 then
			return 
		end
		local node = getNodeByOrder(index)
		node:doLighting(false)
	end
	function selectOne(index)
		if index < 1 then
			return 
		end
		local node = getNodeByOrder(index)
		node:doSelected(true)

		local count = node.m_count
		if not count then
			count = 1
		else
			count = count + 1
		end
		node:setCountLabel(count)
	end
	function unselectOne(index)
		if index < 1 then
			return 
		end
		local node = getNodeByOrder(index)
		node:doSelected(false)
		node:setCountLabel(0)
	end
	function changeState(_new_state)
		local oldState = stare
		state = _new_state
		if state == -1 then
			if self.schAni then
				self:getScheduler():unscheduleScriptEntry(self.schAni)
				self.schAni = nil
			end
			closeOne(order)
			finishCB("timeout")
		elseif state == 1 then
			interval = 3
			frame = 0
			order = 0
		elseif state == 2 then
			interval = 1
		elseif state == 7 then
			interval = 2
			openArrayIndex = 1
			rotating = false
		elseif state == 10 then
			rotating = false
			interval = 1
		elseif state == 20 then
			rotating = false
			self:getScheduler():unscheduleScriptEntry(self.schAni)
			self.schAni = nil
			finishCB()
		end
	end
	function changeNextOrder()
		if rotating then
			closeOne(order)
			order = order + 1
			openOne(order)
		end
	end

	for k = 1, #nodes do
		closeOne(k)
		unselectOne(k)
	end
	self.schAni = self:getScheduler():scheduleScriptFunc(
		function(dt)
			if interval < 1 or frame % math.floor( interval ) == 0 then
				changeNextOrder()
				if state == 1 then
					if interval > 1 then
						interval = interval - intervalSpeed
					else
						changeState(2)
					end
				elseif state == 2 then
					maxWait = maxWait - 1
					if timeout > 0 then
						timeout = timeout - 1
					else
						result = thatHasResult()
						if result then
							if type(result) == "table" then
								if #result > 0 then
									changeState(5)
								else
									changeState(-1)
								end
							else
								changeState(-1)
							end
						elseif maxWait <= 0 then
							changeState(-1)
						end
					end
				elseif state == 5 then
					if getIndexByOrder(order + 9) == result[1] then
						changeState(6)
					end
				elseif state == 6 then
					if getIndexByOrder(order) == result[1] then
						changeState(7)
					else
						interval = interval + intervalSpeed
					end
				elseif state == 7 then
					if openArrayIndex <= #result then
						openOne(result[openArrayIndex])
						selectOne(result[openArrayIndex])
						openArrayIndex = openArrayIndex + 1
					else
						changeState(10)
					end
				elseif state == 10 then
					if endingWaitFor > 0 then
						endingWaitFor = endingWaitFor - 1
					else
						changeState(20)
					end
				end
			end
			frame = frame + 1
		end,
		tick,
		false
	)
	changeState(1)
end

function AvatarDuoBaoDrawView:setVisibleRankView(visible)
	self.ui.m_showMoneyNode:setVisible(not visible)
	self.ui.m_bottomNode:setVisible(not visible)
	self.ui.m_rankNode:setVisible(visible)
end

function AvatarDuoBaoDrawView:checkRankOpen()
	if self.ctl:isRankOpen() then
	else
		local size = self.ui.m_diamondBtn:getParent():getContentSize()
		self.ui.m_diamondBtn:setPreferredSize(cc.size(size.width / 2, size.height))
		self.ui.m_goldBtn:setPreferredSize(cc.size(size.width / 2, size.height))
		self.ui.m_goldBtn:setPositionX(size.width / 2)
		self.ui.m_sep1:setPositionX(size.width / 2)
		self.ui.m_rankRootNode:setVisible(false)
	end
end

function AvatarDuoBaoDrawView:onRateHelp(  )
	local view = Drequire("game.avatar.AvatarDuoRateHelp"):create(self.ctl.drawInfoData,self.ctl)
	PopupViewController:addPopupView(view)
end

return AvatarDuoBaoDrawView
