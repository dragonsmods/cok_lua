----------------------------
-- Author: Elex
-- Date: 2019-05-27 Monday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local AvatarDuoBaoDrawResultView_ui = class("AvatarDuoBaoDrawResultView_ui")

--#ui propertys


--#function
function AvatarDuoBaoDrawResultView_ui:create(owner, viewType, paramTable)
	local ret = AvatarDuoBaoDrawResultView_ui.new()
	CustomUtility:DoRes(0, true)
	CustomUtility:LoadUi("AvatarDuoBaoDrawResultView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function AvatarDuoBaoDrawResultView_ui:initLang()
	LabelSmoker:setText(self.m_pLabelTTF70, "101093")
	LabelSmoker:setText(self.m_pLabelTTF82, "176830")
	LabelSmoker:setText(self.m_buyOneSpriteLabel, "176824")
	LabelSmoker:setText(self.m_buyOneFreeLabel, "111124")
	LabelSmoker:setText(self.m_openOneLabel, "176825")
	LabelSmoker:setText(self.m_buyTenSpriteLabel, "176824")
	LabelSmoker:setText(self.m_openTenLabel, "176825")
	LabelSmoker:setText(self.m_pLabelTTF21, "176826")
	LabelSmoker:setText(self.txt_check, "176871")
end

function AvatarDuoBaoDrawResultView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function AvatarDuoBaoDrawResultView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function AvatarDuoBaoDrawResultView_ui:onClickBuyOneBtn(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBuyOneBtn", pSender, event)
end

function AvatarDuoBaoDrawResultView_ui:onClickBuyTenBtn(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBuyTenBtn", pSender, event)
end

function AvatarDuoBaoDrawResultView_ui:onSwitchHasAniBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onSwitchHasAniBtnClick", pSender, event)
end

return AvatarDuoBaoDrawResultView_ui

