--[[ 
	主城装扮
 ]]
local AvatarViewEx = class("AvatarViewEx", function (  )
	return ArcPopupBaseView:call("create", 7)
end)

local AvatarCell = class("AvatarCell", function (  )
	return cc.TableViewCell:create()
end)
local AvatarTagCell = class("AvatarTagCell", function (  )
	return cc.TableViewCell:create()
end)

local avatar_view_ins = nil

ccb = ccb or {}
ccb["cloud"] = ccb["cloud"] or {}

require("game.avatar.AvatarController")
local FuMoBuffInfoCell = Drequire('game.FuMo.FuMoBuffInfoCell')

local cell_index_1 = 1
local cell_index_2 = 2
local cell_index_3 = 3

local PAGE_STORE = 0
local PAGE_WARDROBE = 1

local SCENE_IMPERIAL = 0
local SCENE_WORLD = 1

local SkinScaleMgrIns = require('game.skinScale.SkinScaleMgr').getInstance()
AvatarViewEx.__index =  AvatarViewEx
function AvatarViewEx.create(activeStoreTag)
	local view = AvatarViewEx.new()
	Drequire("game.avatar.AvatarViewEx_ui"):create(view, 1)
    if view:initSelf(activeStoreTag) then
        return view
    end
    return nil
end

function AvatarViewEx:ctor(  )
	Dprint('AvatarViewEx:ctor')
	avatar_view_ins = self
	self.page = PAGE_STORE
	self.scene = SCENE_IMPERIAL
	self.touchIndex = nil
	self.m_isChangingScene = false

	-- 数据
	self.m_storeData = {}			-- 所有的商城数据
	self.m_wardrobeData = {}		-- 所有的装扮数据

	-- 页签的数组
	self.m_storeTags = {}
	self.m_wardrobeTags = {}

	-- 记录激活的页签
	self.m_activeStoreTag = AvatarType_Diamond
	self.m_activeWardrobeTag = AvatarType_Castle
	if CCCommonUtilsForLua:isFunOpenByKey("skin_mall") then
		self.m_activeWardrobeTag = AvatarType_None
	end

	-- 记录激活的index(每个tab里被点击的cellIndex)
	self.m_activeStoreIndexTable = {}
	self.m_activeWardrobeIndexTable = {}

	self.ctl = AvatarController:getInstance()
	self.ctl:refreshSellItemsInStore() -- refresh on msg
end

function AvatarViewEx:initSelf( activeStoreTag )
	Dprint('AvatarViewEx:initSelf', activeStoreTag)
	if FunOpenController:isUnlock("fun_avatar", true) == false then
		return false
	end

	self:call("setIsLua", true)
	self:call("setModelLayerDisplay", false)
	if activeStoreTag then
		self.m_activeStoreTag = activeStoreTag
	end
	local winsize = cc.Director:getInstance():getIFWinSize()
	-- if DynamicResourceController2:call("checkDynamicResource", "avatar_icon") == false then
	-- 	-- E100091=领主大人，资源下载中，请稍后尝试操作。
	-- 	CCCommonUtilsForLua:call("flyHint", "", "", getLang("E100091"))
	-- 	return false
	-- end
	CCLoadSprite:call("loadDynamicResourceByName", "dress_intr_face")
	CCLoadSprite:call("loadDynamicResourceByName", "avatar_icon")
	CCLoadSprite:call("loadDynamicResourceByName", "avatar_icon2")
	CCLoadSprite:call("loadDynamicResourceByName", "avatar_zhanshi_icon_face")
	CCLoadSprite:call("loadDynamicResourceByName", "race_base")
	CCLoadSprite:call("loadDynamicResourceByName", "race_base2")
	CCLoadSprite:call("loadDynamicResourceByName", "goods")
	CCLoadSprite:call("loadDynamicResourceByName", "SkinFetter_face")
    -- CCLoadSprite:call("doResourceByCommonIndex", 310, true)
	Dprint('AvatarViewEx:initSelf loadDynamicResourceByName')
	if getIsLowView() then
		local posY = self.ui.m_arcdlg:getPositionY()
		local arcdlySize = self.ui.m_arcdlg:getContentSize()
		self.ui.m_arcdlg:setScaleY(posY * 2 / arcdlySize.height)
	end

    self.m_civPreviewNode = cc.Node:create()
    self:addChild(self.m_civPreviewNode, -2000)
    self.m_civPreviewNode:setPosition(320, 610)
	self.startTouchPt = cc.p(0, 0)
	local function touchHandle(eventType, x, y)
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		else
			self:onTouchEnded(x, y)
		end
	end
	self:registerScriptTouchHandler(touchHandle)
	self:call("setTouchEnabled", true)
	self:call("setSwallowsTouches", true)
	self:call("setNeedCheckUpperAllAtOneceListenner", true)

	--【Awen】皮肤羁绊
	self.ui.m_nodeFetters:setVisible(CCCommonUtilsForLua:isFunOpenByKey("skin_fetters"))
	--【Awen】装扮分页签
	self.ui.m_nodeUseAll:setVisible(false)
	if CCCommonUtilsForLua:isFunOpenByKey("skin_mall") then
		self.ui.m_nodeTab:setVisible(true)
		self.ui.m_btnIndex:setVisible(true)

		self.ui.m_roomNode:setVisible(false)
		if CCCommonUtilsForLua:isFunOpenByKey("skin_fetters") then
			self.ui.m_nodeFetters:setPositionY(self.ui.m_nodeDressIntr:getPositionY())
			self.ui.m_nodeDressIntr:setPositionY(self.ui.m_roomNode:getPositionY())
		else
			self.ui.m_sceneNode:setPositionY(self.ui.m_sceneNode:getPositionY() - 40)
			self.ui.m_nodeDressIntr:setPositionY(self.ui.m_nodeDressIntr:getPositionY() + 40)
		end	
		if GlobalDataCtr.checkIsGreenServer() then
			self.ui.m_btnIndex:setVisible(false)
		else			
			local _x = self.ui.m_tagNode:getPositionX()
			local _size = self.ui.m_tagNode:getContentSize()
			self.ui.m_tagNode:setPositionX(_x + 100)
			self.ui.m_tagNode:setContentSize(cc.size(_size.width - 100, _size.height))
		end		
		
		local _frame = CCLoadSprite:call("getSF", "dresstype_index.png")
        if _frame then
			CCCommonUtilsForLua:call("setButtonSprite", self.ui.m_btnIndex, "dresstype_index.png")
		end		
	else
		self.ui.m_nodeTab:setVisible(false)
		self.ui.m_btnIndex:setVisible(false)
		self.ui.m_label6:setString(getLang("111901"))	--111901=去装扮
	end

	local handler = ImperialTouchHandler:call("create")
	handler:setAnchorPoint(cc.p(0, 0))
	handler:setContentSize(cc.size(640, 800))
	self.ui.m_imperialTouchNode:addChild(handler)
	self.m_impTouchHandler = handler

	self.m_gridView = cc.TableView:create(self.ui.m_listNode:getContentSize())
	self.m_gridView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
	self.m_gridView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
	self.m_gridView:setDelegate()
	self.m_gridView:setTouchEnabled(true)
	self.m_gridView:setSwallowsTouches(true)
	self.ui.m_listNode:addChild(self.m_gridView)

	local function cellSizeForTableMain( view, idx )
		return self:cellSizeForTableMain(view, idx)
	end

	local function tableCellAtIndexMain( view, idx )
		return self:tableCellAtIndexMain(view, idx)
	end

	local function numberOfCellsInTableViewMain( view )
		return self:numberOfCellsInTableViewMain(view)
	end

	self.m_gridView:registerScriptHandler(cellSizeForTableMain,cc.TABLECELL_SIZE_FOR_INDEX)
	self.m_gridView:registerScriptHandler(tableCellAtIndexMain,cc.TABLECELL_SIZE_AT_INDEX)
	self.m_gridView:registerScriptHandler(numberOfCellsInTableViewMain,cc.NUMBER_OF_CELLS_IN_TABLEVIEW)

	------------------------------------------------------------------------
	self.m_tableView1 = cc.TableView:create(self.ui.m_tagNode:getContentSize())
	self.m_tableView1:setDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL)
	self.m_tableView1:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
	self.m_tableView1:setDelegate()
	self.m_tableView1:setAnchorPoint(cc.p(0, 0))
	self.m_tableView1:setSwallowsTouches(true)
	self.ui.m_tagNode:addChild(self.m_tableView1)

	local function cellSizeForTable( view, idx )
		return self:cellSizeForTable(view, idx)
	end

	local function tableCellAtIndex( view, idx )
		return self:tableCellAtIndex(view, idx)
	end

	local function numberOfCellsInTableView( view )
		return self:numberOfCellsInTableView(view)
	end

	self.m_tableView1:registerScriptHandler(cellSizeForTable,cc.TABLECELL_SIZE_FOR_INDEX)
	self.m_tableView1:registerScriptHandler(tableCellAtIndex,cc.TABLECELL_SIZE_AT_INDEX)
	self.m_tableView1:registerScriptHandler(numberOfCellsInTableView,cc.NUMBER_OF_CELLS_IN_TABLEVIEW)

	self.ui.m_worldSpr:setVisible(true)
	self.ui.m_label5:setString(getLang("139503"))		-- 139503=世界
    self.ui.m_citySpr:setVisible(false)

	if CCCommonUtilsForLua:isFunOpenByKey("skin_mall") then
		self.ctl:reqStoreData()
	else
		self:generateStoreData()
	end

	-- UI最上方显示钻石数量
    self.ui.m_crystalSprite:setSpriteFrame(CCLoadSprite:call("loadResource", "diamond.png"))
    self.ui.m_crystalLabel:setString("0")
    if PlayerInfoController:getCrystalGold() then
	    self.ui.m_crystalLabel:setString(CC_CMDITOA(PlayerInfoController:getCrystalGold()))
	end
    CCCommonUtilsForLua:call("setSpriteMaxSize",  self.ui.m_crystalSprite, 64, true)
    if not CCCommonUtilsForLua:isFunOpenByKey("diamond_show") then
    	self.ui.m_crystalSprite:setVisible(false)
    	self.ui.m_crystalLabel:setVisible(false)
	end
	-- UI最上方显示金币数量
	self.ui.m_goldLabel:setString(CC_CMDITOA(GlobalData:call("getPlayerInfo"):getProperty("gold")))

	local default_currId = AvatarController:getInstance():getItemDefaultCurrId()
	if CCCommonUtilsForLua:isFunOpenByKey("mysterypiece_page") and ToolController:call("getToolInfoForLua", default_currId) then		-- 控制神秘碎片兑换是否开启
		-- UI最上方显示神秘碎片道具数量
		self.ui.m_pieceSprite:setSpriteFrame(CCLoadSprite:call("loadResource", CCCommonUtilsForLua:getPropByIdGroup("goods", tostring(default_currId), "icon")..".png"))
		self.ui.m_pieceLabel:setString("0")
			self.ui.m_pieceLabel:setString(CC_CMDITOA(ToolController:call("getToolInfoForLua", default_currId):call("getCNT")))
		CCCommonUtilsForLua:call("setSpriteMaxSize",  self.ui.m_pieceSprite, 48, true)
		-- -- 调整其他资产道具数量的显示
		-- CCCommonUtilsForLua:call("setSpriteMaxSize",  self.ui.m_crystalSprite, 48, true)
		-- self.ui.m_goldSprite:setScale(0.98)
		-- self.ui.m_goldSprite:setPositionX(self.ui.m_goldSprite:getPositionX()-50)
		-- self.ui.m_crystalSprite:setPositionX(self.ui.m_crystalSprite:getPositionX()-75)
		-- self.ui.m_goldLabel:setPositionX(self.ui.m_goldLabel:getPositionX()-50)
		-- self.ui.m_crystalLabel:setPositionX(self.ui.m_crystalLabel:getPositionX()-105)
		self:makeSpaceForOtherCoin(3)
	else
		self.ui.m_pieceSprite:setVisible(false)
		self.ui.m_pieceLabel:setVisible(false)
	end

    local function onNodeEvent( event )
		if event == "enter" then
			self:onEnter()
	    elseif event == "exit" then
			self:onExit()
	    end
	end
	self:registerScriptHandler(onNodeEvent)

	local im = ImperialScene:call("getInstance")
	if im == nil then
		return false
	end

	CCSafeNotificationCenter:call("postNotification", "msg_main_scence_savePos")
	im:call("setUnMoveScence", false)
	im:call("onMoveToBuildAndOpen", 400000000, 7)

	--打开图鉴
	self.dressIntrFunOn = CCCommonUtilsForLua:isFunOpenByKey("dress_introduction") 
	if self.dressIntrFunOn then
		self.ui.m_sprDressIntr:setPositionY(35)
		self.ui.m_labelDressIntr:setString(getLang("9200270")) 
		if CCLoadSprite:call("getSF", "dressIntroduction.png") then
			self.ui.m_sprDressIntr:setSpriteFrame(CCLoadSprite:call("loadResource", "dressIntroduction.png"))
		end
	else
		self.ui.m_nodeDressIntr:setVisible(false)
	end

	local function setSpriteIcon( spr, icon)
		local sf = CCSpriteFrameCache:sharedSpriteFrameCache():spriteFrameByName(icon)
		if sf and spr then
			spr:setSpriteFrame(sf)	
    	end
	end
	setSpriteIcon(self.ui.m_worldSpr, "icon_shop_world.png")
	setSpriteIcon(self.ui.m_citySpr, "icon_shop_castle.png")
	setSpriteIcon(self.ui.m_wardrobeSpr, "icon_shop_decorate.png")
	setSpriteIcon(self.ui.m_storeSpr, "ICON_fam_shop.png")
	setSpriteIcon(self.ui.m_sprDressIntr, "icon_shop_manual.png")
	if CCCommonUtilsForLua:isFunOpenByKey("skin_fetters") then
		setSpriteIcon(self.ui.m_sprFetters, "icon_fetter.png")
	end
	if CCCommonUtilsForLua:isFunOpenByKey("skin_mall") then
		self.ctl:reqSkinData()
	end

	self:handleAvatarV1Shop()

	if not SkinScaleMgrIns:isOpen() then
		self.ui.m_nodeSkinScale:setVisible(false)
	else
		SkinScaleMgrIns:reqData()
	end

	return true
end

function AvatarViewEx:getAvatarV1MgrIns(  )
	local av1MgrIns = self.m_av1MgrIns
	if not av1MgrIns then
	    av1MgrIns = require('game.LiBao.AvatarShop.AvatarShopV1Mgr').getInstance()
	    self.m_av1MgrIns = av1MgrIns
	end
	return av1MgrIns
end

function AvatarViewEx:handleAvatarV1Shop(  )
	if not self.m_avatarSubObj and self:getAvatarV1MgrIns():isOpen() then
		self.ui.m_nodeTab:setVisible( false )

		self.page = PAGE_STORE 
		self:changeRoom()

		CCLoadSprite:call("loadDynamicResourceByName", 'AvatarShopV1_face')

		if CCCommonUtilsForLua:isFunOpenByKey("avatar_shop_level_limit") and FunBuildController:call("getMainCityLv") >= 5 then
			local tn = self:makeLeftVerticalIcon('AvatarShopV1_09.png',handler(self,self.onClickShopV1))
			local pa = self.ui.m_nodeDressIntr:getParent(  )
			pa:addChild(tn)

			local px,py = self.ui.m_nodeDressIntr:getPosition()
			tn:setPosition( cc.p(px,py - 160) )
		end


		local t = {
	        self.ui.m_crystalSprite,
	        self.ui.m_crystalLabel,
	        self.ui.m_goldSprite,
	        self.ui.m_goldLabel,
	        self.ui.m_pieceSprite,
	        self.ui.m_pieceLabel,
	    }

	    for _,v in ipairs(t) do
	        v:setVisible(false)
	    end

		-- self:call("setTitleName", getLang("151217"))
		local tn2 = cc.LabelTTF:create(getLang("151217"), "Helvetica", 24)
		self.ui.m_topNode:addChild(tn2);
		tn2:setPositionY( -40 )
	end
end

function AvatarViewEx:makeLeftVerticalIcon( icon_res, click_func )
	local tn = cc.Node:create()
	local btn = utils.makeControlBtn({nil,cc.size(60,60)},click_func)
	tn:addChild(btn)

	local sf = utils.getSafeSprite( 'BG_tubiaokuang01.png', 'blankFrame.png' )
	tn:addChild(sf)
	sf:setScale( 0.6 )

	local sf = utils.getSafeSprite( icon_res, 'blankFrame.png' )
	tn:addChild(sf)

	tn:setScale( 0.9 )
	return tn
end

function AvatarViewEx:onClickShopV1( pSender )
	-- if utils.delayClickBtn( pSender, 1 ) then
	-- 	return
	-- end
	self:closeSelf()
	require('game.LiBao.AvatarShop.AvatarShopV1Mgr').getInstance():showMainView()
end

function AvatarViewEx:storeHasNTags( n )
	n = n or 4
	return #(self.m_storeTags or {}) == n
end

function AvatarViewEx:handleStoreTop(  )
	if not self.m_avatarSubObj and self:getAvatarV1MgrIns():isOpen() then
		return
	end
	local aMgrIns = AvatarController:getInstance()
	local need_forthNode = self:storeHasNTags(4) or (self:storeHasNTags(3) and not CCCommonUtilsForLua:isFunOpenByKey("mysterypiece_page"))
	if need_forthNode then
		local forth_type = aMgrIns:findNot_Coin_Diamon_Mestery(self.m_storeTags)
		if forth_type then
			local forth_node = self.m_topForthNode
			if not forth_node then
				forth_node = self:createCoin(aMgrIns:avatarTypeToCurrId(forth_type))
				self.m_topForthNode = forth_node
				self.ui.m_topNode:addChild(forth_node)
			end
		end
	end

	local forth_node = self.m_topForthNode
	if forth_node and not self.m_hadAdjustSpace then
		self.m_hadAdjustSpace = true
		CCCommonUtilsForLua:call("setSpriteMaxSize",  forth_node.m_icon_spr, 48, true)
		if self:storeHasNTags(4) then
			forth_node:setPosition(cc.p(132,-42))
			forth_node.m_innerTxt:setPositionX(50)
			self:makeSpaceForOtherCoin(4)
		elseif self:storeHasNTags(3) then
			forth_node:setPosition(cc.p(82,-42))
			self:makeSpaceForOtherCoin(3)
		end
	end
end

function AvatarViewEx:makeSpaceForOtherCoin( coinNum )
	if coinNum == 3 then
		CCCommonUtilsForLua:call("setSpriteMaxSize",  self.ui.m_crystalSprite, 48, true)
		self.ui.m_goldSprite:setScale(0.98)

		local r = {
			{self.ui.m_goldSprite,-222},
			{self.ui.m_goldLabel,-126},
			{self.ui.m_crystalSprite,-23},
			{self.ui.m_crystalLabel,46},
		}
		for _,v in ipairs(r) do
			v[1]:setPositionX(v[2])
		end
	elseif coinNum == 4 then
		CCCommonUtilsForLua:call("setSpriteMaxSize",  self.ui.m_crystalSprite, 48, true)
		self.ui.m_goldSprite:setScale(0.98)
		local r = {
			{self.ui.m_goldSprite,-222},
			{self.ui.m_goldLabel,-126-20},
			{self.ui.m_crystalSprite,-23 - 40},
			{self.ui.m_crystalLabel,46 - 50},
			{self.ui.m_pieceSprite,100 - 50},
			{self.ui.m_pieceLabel,146 - 50},
		}
		for _,v in ipairs(r) do
			v[1]:setPositionX(v[2])
		end

	end
end

function AvatarViewEx:createCoin( itemId )
	local tn = cc.Node:create()
	tn:setAnchorPoint(cc.p(0,0.5))

	local icon_png = CCCommonUtilsForLua:getPropByIdGroup("goods", tostring(itemId), "icon")..".png"
	local icon_spr = utils.getSafeSprite(icon_png,"blankFrame.png")
	icon_spr:setAnchorPoint(cc.p(0,0.5))
	tn:addChild(icon_spr)
	tn.m_icon_spr = icon_spr

	local tinfo = ToolController:call("getToolInfoForLua", tonumber(itemId))
	cclog("createCoin ,,,, %s,%s,%s",itemId,not not tinfo, tinfo and tinfo:call("getCNT") or '0')
	local innerTxt = nil
    innerTxt = cc.LabelTTF:create(tostring(tinfo and tinfo:call("getCNT") or '0'), "Helvetica", 18)
    tn.m_innerTxt = innerTxt
    innerTxt:setColor(cc.c3b(212,166,111))
    innerTxt:setAnchorPoint(cc.p(0,0.5))
    innerTxt:setHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
    innerTxt:setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_TOP)
    innerTxt:setDimensions(cc.size(270,0))
    innerTxt:setPosition(cc.p(70,0))
    tn:addChild(innerTxt,2)
    tn.m_iconTxt = innerTxt

    return tn
end

function AvatarViewEx:getIdxInTable( v, t )
	for i,vv in ipairs(t) do
		if vv == v then
			return i
		end
	end
	return nil
end

-- 获取商店数据
function AvatarViewEx:generateStoreData(  )
	Dprint("AvatarViewEx:generateStoreData")
	---从本读取上次的选择存贮的数据
	
	
	local localStr = cc.UserDefault:getInstance():getStringForKey("AvatarViewEx_storeData", "")
	
	if CCCommonUtilsForLua:isFunOpenByKey("dress_index") and localStr ~= ""then
		
		
		local json = require("CommonLib.dkjson")
		local storeData = json.decode(localStr)		
	    for k,v in pairs(storeData) do
	    	self.m_storeData[tonumber(k)] = v
	    end

		
		
    else
      	cc.UserDefault:getInstance():setStringForKey("AvatarViewEx_storeData", "")
    	self.m_storeData = AvatarController:getInstance():getAllATypeAndSellItemsInStore()
    end
  

  
	self.m_storeTags = {}
	for i=AvatarType_Diamond,AvatarType_MAX - 1 do
		if not CCCommonUtilsForLua:isFunOpenByKey("mysterypiece_page") and i==AvatarType_MysteryPiece then
		elseif nil ~= self.m_storeData[i] then
			self.m_storeTags[#self.m_storeTags + 1] = i
		end
	end

	if #self.m_storeTags == 4 then
		if self.m_storeTags[4] == AvatarType_ForthTag then
			self.m_storeTags[4],self.m_storeTags[3] = self.m_storeTags[3],self.m_storeTags[4]
		end
	end

	--【Awen】备份所有商城数据
	if CCCommonUtilsForLua:isFunOpenByKey("skin_mall") then
		if self.v_storeAllData == nil then
			self.v_storeAllData = clone(self.m_storeData)
		end
	end

	if nil == self.m_storeData[self.m_activeStoreTag] and #self.m_storeTags > 0 then
		self.m_activeStoreTag = self.m_storeTags[1]
	end

	for i=AvatarType_Castle,AvatarType_MAX - 1 do
		if self.ctl.storeActivityIdxTab[i] and self.m_storeData[i] then
			self.m_activeStoreIndexTable[i] = self:getIdxInTable(self.ctl.storeActivityIdxTab[i], self.m_storeData[i]) 
		end
	end

	for k,v in pairs(self.m_storeData) do
		local idx = self.m_activeStoreIndexTable[k]
		if nil == idx or idx > #v then
			self.m_activeStoreIndexTable[k] = nil
		end
	end

	self:handleStoreTop()
end

--将“永久”物品排在最前面
function AvatarViewEx:sortWardrobeDataByTag(tag)
	if tag == nil or self.m_wardrobeData[tag] == nil or #self.m_wardrobeData[tag] <= 1  then 
		return
	end

	local function isYongjiu(endTime)
		if endTime then
		  	return endTime == -1 or endTime > 1900000000
		else
			return false
		end
	end

	local function sort(a, b)
		if tag ~= AvatarType_None then
			if a.itemId < 200 or b.itemId < 200 then
				return a.itemId < b.itemId
			end
		end
		-- 将已标记的排在最前面
		local _aMark = tonumber(a.mark) or 0
		local _bMark = tonumber(b.mark) or 0
		if _aMark ~= _bMark then
			return _aMark > _bMark
		elseif isYongjiu(a.endTime) and not isYongjiu(b.endTime) then
			return true
		elseif ( isYongjiu(a.endTime) and isYongjiu(b.endTime) )
			or ( not isYongjiu(a.endTime) and not isYongjiu(b.endTime))
			then
			return a.itemId > b.itemId
		end
		return false
	end
	table.sort(self.m_wardrobeData[tag], sort)
end

function AvatarViewEx:sortAllWardrobeData()
	dump("sort all wardrobe data")
	for k, v in pairs(self.m_wardrobeData) do
		self:sortWardrobeDataByTag(k)
	end
end

function AvatarViewEx:getIdxInWardrobeTable( v, t )
	for i,vv in ipairs(t) do
		if vv.itemId == v then
			return i
		end
	end
	return nil
end

-- 获取装扮数据
function AvatarViewEx:generateWardrobeData( )
	self.m_wardrobeData = AvatarController:getInstance():getAllATypeAndItemsInWardrobe()
	-- dump(self.m_wardrobeData[100], "AvatarViewEx:generateWardrobeData")
	self:sortAllWardrobeData()
	
	local _startType = AvatarType_Castle
	if CCCommonUtilsForLua:isFunOpenByKey("skin_mall") then
		_startType = AvatarType_None
	end

	if table_is_empty(self.m_wardrobeTags) then
		self.m_wardrobeTags = {}
		for i = _startType, AvatarType_MAX - 1 do
			if nil ~= self.m_wardrobeData[i] then
				if i == AvatarType_HeadFrame and not CCCommonUtilsForLua:isFunOpenByKey("lord_frame_show") then 
				else
					self.m_wardrobeTags[#self.m_wardrobeTags + 1] = i
				end
			end
		end
	end    

	--【Awen】备份所有装扮数据
	if CCCommonUtilsForLua:isFunOpenByKey("skin_mall") then
		if self.v_wardrobeAllTags == nil then
			self.v_wardrobeAllTags = clone(self.m_wardrobeTags)
		end
	end	
    local localStr = cc.UserDefault:getInstance():getStringForKey("AvatarViewEx_wardrobeTags", "")
	if CCCommonUtilsForLua:isFunOpenByKey("dress_index")  and localStr ~= "" then			
		
		local json = require("CommonLib.dkjson")
		self.m_wardrobeTags = json.decode(localStr)		   
	        
	    
	else
	   cc.UserDefault:getInstance():setStringForKey("AvatarViewEx_wardrobeTags", "")
	end


	if nil == self.m_wardrobeData[self.m_activeWardrobeTag] and #self.m_wardrobeTags > 0 then
		self.m_activeWardrobeTag = self.m_wardrobeTags[1]
	end

	for i = _startType, AvatarType_MAX - 1 do
		if self.ctl.wardrobeActivityIdxTab[i] and self.m_wardrobeData[i] then
			self.m_activeWardrobeIndexTable[i] = self:getIdxInWardrobeTable(self.ctl.wardrobeActivityIdxTab[i], self.m_wardrobeData[i]) 
		end
	end
	
	for k,v in pairs(self.m_wardrobeData) do
		local idx = self.m_activeWardrobeIndexTable[k]
		if nil == idx or idx > #v then
			self.m_activeWardrobeIndexTable[k] = nil
		end
	end
end

-- 同步所有的展示皮肤
function AvatarViewEx:synchronizeAllTmpSkins(page)
	Dprint('AvatarViewEx:synchronizeAllTmpSkins page', page)
 	if page == PAGE_STORE then
 		local atype = nil
 		-- for i,v in ipairs(self.m_storeTags) do
 		-- 依次遍历各类型（城堡、行军、聊天气泡等），实现各类皮肤的替换
 		-- local useDiamondCastle = false
 		-- 钻石商店的装扮覆盖同类装扮
 		for i=AvatarType_Castle,AvatarType_MAX do
 			if atype ~= i then
	 			if self.m_storeData[i] ~= nil and self.m_activeStoreIndexTable[i] ~= nil then
	 				local itemId = self.m_storeData[i][self.m_activeStoreIndexTable[i]]
	 				if not itemId or itemId == "" then 
	 					return 
	 				end
					local ainfo = AvatarController:call("getAvatarInfoByGoodsId", itemId)
					if not ainfo then 
						return 
					end
		 			CCSafeNotificationCenter:call("postNotification", "MSG_TMP_SKIN_CHANGE", CCString:create(tostring(itemId)))
	 			else
	 				CCSafeNotificationCenter:call("postNotification", "MSG_TMP_SKIN_CHANGE", CCString:create(tostring(i)))
	 			end
	 		end
 		end
 		if AvatarType_Diamond == self.m_activeStoreTag then
 			if not self.m_activeStoreIndexTable[AvatarType_Diamond] then
 				return  
 			end
			local itemId = self.m_storeData[AvatarType_Diamond][self.m_activeStoreIndexTable[AvatarType_Diamond]]
			if not itemId or itemId == "" then 
				return 
			end
			local ainfo = AvatarController:call("getAvatarInfoByGoodsId", itemId)
			if not ainfo then 
				return
			end
			atype = tonumber(ainfo:call('getAvatarType'))
	 		if AvatarType_Item == atype then
				local statusId = ainfo:call("getStatusId")
				local diamondItemId = CCCommonUtilsForLua:call("getPropById", tostring(statusId), "effectart") -- 礼盒，取其中的城堡装扮
				if diamondItemId and '' ~= diamondItemId then
					itemId = diamondItemId
				end
	 		end
 			CCSafeNotificationCenter:call("postNotification", "MSG_TMP_SKIN_CHANGE", CCString:create(tostring(itemId)))
 		end
 	else
 		for i=AvatarType_Castle,AvatarType_MAX do
 			if self.m_wardrobeData[i] ~= nil and self.m_activeWardrobeIndexTable[i] ~= nil then
 				if self.m_activeWardrobeIndexTable[i] then 
 					local data = self.m_wardrobeData[i][self.m_activeWardrobeIndexTable[i]]
 					if data then 
	 					CCSafeNotificationCenter:call("postNotification", "MSG_TMP_SKIN_CHANGE", CCString:create(tostring(data.itemId)))
	 				end
	 			end
 			else
 				CCSafeNotificationCenter:call("postNotification", "MSG_TMP_SKIN_CHANGE", CCString:create(tostring(i)))
 			end
 		end
 	end
end 

function AvatarViewEx:refreshGridView(  )
	local ctl = AvatarController:getInstance()
	local unSeen = ctl:getUnSeenItemInStore(self.atype)
	if unSeen and 0 == #unSeen then -- first time entry
		ctl:markAsSeenByType(self.atype)
	end

	self.m_gridView:reloadData()
	self.m_gridView:setContentOffset(cc.p(0, self.ui.m_listNode:getContentSize().height - self.m_gridView:getContentSize().height))
end

function AvatarViewEx:refreshTagTableView(  )
	self.m_tableView1:reloadData()
	local preve_px = self.m_preve_px
	 self.m_preve_px = nil
	self.m_tableView1:setContentOffset(cc.p(preve_px or 0, 0))
	if preve_px then
		self.m_tableView1:scrollViewDidScroll(self.m_tableView1)
	end
end

function AvatarViewEx:refreshView(  )
	Dprint('AvatarViewEx:refreshView', self.m_activeStoreTag, index)
	self:refreshGridView()
	self:refreshTop()
	self:refreshTagTableView()
	self:synchronizeAllTmpSkins(self.page)
end

function AvatarViewEx:recordATypeShow( atype )
	if self.page == PAGE_WARDROBE then
		cc.UserDefault:getInstance():setBoolForKey("Avatar_atype_showed_" .. tostring(atype), true)
		cc.UserDefault:getInstance():flush()
	end
end

function AvatarViewEx:recordWardrobeItemIdShow( atype )
	if self.page == PAGE_WARDROBE then
		local data = self.m_wardrobeData[atype]
		if nil ~= data then
			for i,v in ipairs(data) do
				local tinfo = ToolController:call("getToolInfoForLua", v.itemId)
				if v.isInBag == true and tinfo then
					local tag = "Avatar_item_show_num_by_id_"
					tag = tag .. tostring(v.itemId)
					cc.UserDefault:getInstance():setIntegerForKey(tag, tinfo:call("getCNT"))
				end
			end
			cc.UserDefault:getInstance():flush()
			
		end
	end
end

function AvatarViewEx:checkTouchIndex( index )
	self.touchIndex = index
	if self.page == PAGE_STORE then
		if not self.m_activeStoreTag
			or not self.m_storeData[self.m_activeStoreTag] 
			or not self.m_storeData[self.m_activeStoreTag][index] then
			self.touchIndex = nil
		end
	else
		if not self.m_activeWardrobeTag 
			or not self.m_wardrobeData[self.m_activeWardrobeTag] 
			or not self.m_wardrobeData[self.m_activeWardrobeTag][index] then
			self.touchIndex = nil
		end
	end
end

function AvatarViewEx:reloadView( index )
	self:checkTouchIndex(index)
	local offset = self.m_gridView:getContentOffset()
	self.m_gridView:reloadData()
	if self.touchIndex and self.touchIndex > 3 then 
        self.m_gridView:setContentOffset(offset)
    end
end

function AvatarViewEx:onCellTouched( index )
	-- Dprint("AvatarViewEx:onCellTouched", self.m_activeStoreTag, index)
	self.touchedAvatarType = nil
	if self.page == PAGE_STORE then
		self.m_activeStoreIndexTable[self.m_activeStoreTag] = index
		local itemId = self.m_storeData[self.m_activeStoreTag][index]

 		if AvatarType_Diamond == self.m_activeStoreTag then
			local ainfo = AvatarController:call("getAvatarInfoByGoodsId", itemId)
			atype = tonumber(ainfo:call('getAvatarType'))
			self.touchedAvatarType = atype
	 		if AvatarType_Item == atype then
				local statusId = ainfo:call("getStatusId")
				local diamondItemId = CCCommonUtilsForLua:call("getPropById", tostring(statusId), "effectart") -- 礼盒，取其中的城堡装扮
				if diamondItemId and '' ~= diamondItemId then
					itemId = diamondItemId
				end
	 		end
	 	end

		CCSafeNotificationCenter:call("postNotification", "MSG_TMP_SKIN_CHANGE", CCString:create(tostring(itemId)))
	else
		self.m_activeWardrobeIndexTable[self.m_activeWardrobeTag] = index
		CCSafeNotificationCenter:call("postNotification", "MSG_TMP_SKIN_CHANGE", CCString:create(tostring(self.m_wardrobeData[self.m_activeWardrobeTag][index].itemId)))
	end
	self:refreshTop()
	self:reloadView(index)
end

function AvatarViewEx:onEnterFrame( ... )
	dump("AvatarViewEx:onEnterFrame+++")
	if not self.ctl:isStoreInitialized() then
		self.ctl:refreshSellItemsInStore()
		if self.ctl:isStoreInitialized() then
			self:generateStoreData()
			self:refreshView()
			if PAGE_STORE == self.page then
				CCSafeNotificationCenter:call("postNotification", "MSG_AVATARTAGCELL_TOUCHED", CCInteger:create(AvatarType_Diamond))
			end
		end
	end
end

function AvatarViewEx:onEnter(  )
	Dprint('AvatarViewEx:onEnter')

	local function refreshView_ ()
		self:refreshView()
	end
	runTimeDelayFunc(self, refreshView_, 0.2)

	local function onDataInit ()
		Dprint('AvatarViewEx onDataInit')
		self.ctl:refreshSellItemsInStore()
		self:generateStoreData()
		self:refreshView()
	end
	local handlerInit = self:registerHandler(onDataInit)
	CCSafeNotificationCenter:registerScriptObserver(self, handlerInit, "MSG_AVATAR_INIT")

	local function onTagCellTouched( ref )
		-- self.touchIndex = nil
		local atype = ref:getValue()

		-- 如有必要 需要进行场景的切换
		if self.page == PAGE_WARDROBE then
			-- 同步一下wardrobe小红点显示
			self:recordATypeShow(self.m_activeWardrobeTag)
			self:recordWardrobeItemIdShow(self.m_activeWardrobeTag)
			self.m_activeWardrobeTag = atype 
		else
			self.m_activeStoreTag = atype
		end

		self:refreshView()
	end
	local handler1 = self:registerHandler(onTagCellTouched)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "MSG_AVATARTAGCELL_TOUCHED")


	local function refreshSelf( ref )
		if self.page ~= PAGE_WARDROBE then
			return
		end
		self.m_activeWardrobeIndexTable[self.m_activeWardrobeTag] = nil
		self.v_wardrobeAllTags = nil
		self:generateWardrobeData()
		self:refreshView()
	end
	local handler2 = self:registerHandler(refreshSelf)

	CCSafeNotificationCenter:registerScriptObserver(self, handler2, "MSG_AVATAR_ACTIVE_WARDROBE_STATUS_BACK")
	CCSafeNotificationCenter:registerScriptObserver(self, handler2, "MSG_AVATAR_STATUS_CANCEL_BACK")
	CCSafeNotificationCenter:registerScriptObserver(self, handler2, "MSG_AVATAR_ITEM_USE")

	local function refreshCrystal( ref )
		Dprint("refreshCrystal")
		self.ui.m_crystalLabel:setString(CC_CMDITOA(PlayerInfoController:getCrystalGold()))
	end

	local handler3 = self:registerHandler(refreshCrystal)
	CCSafeNotificationCenter:registerScriptObserver(self, handler3, "MSG_REFRESH_CRYSTAL")

	local function refreshGold( ref )
		if CCCommonUtilsForLua:isFunOpenByKey("mysterypiece_page") then
			self.ui.m_pieceLabel:setString(CC_CMDITOA(ToolController:getToolCount(AvatarController:getInstance():getItemDefaultCurrId())))
		end

		if AvatarController:getInstance():has_AvatarType_ForthTag() and self.m_topForthNode then
			local currId = tonumber(AvatarController:getInstance():avatarTypeToCurrId(AvatarType_ForthTag))
			self.m_topForthNode.m_innerTxt:setString(CC_CMDITOA(ToolController:getToolCount(currId)))
		end
		Dprint("refreshGold")
		if self.ui.m_goldLabel then
			self.ui.m_goldLabel:setString(CC_CMDITOA(GlobalData:call("getPlayerInfo"):getProperty("gold")))
		end
		self:reloadView(self.touchIndex)
	end

	local handler4 = self:registerHandler(refreshGold)
	CCSafeNotificationCenter:registerScriptObserver(self, handler4, "msg.tool.change")
    registerScriptObserver(self, self.onConfirmBuy, "AvatarViewEx.confirmBuyItem")
	self:onEnterFrame()

	-- self.entry = self:getScheduler():scheduleScriptFunc(function(dt) self:onEnterFrame(dt) end, 1.0, false)
    local scene = ImperialScene:call("getInstance")
    if scene then
    	local viewport = scene:call("getHFViewport")
    	local rect = viewport:call("getWorldBound")
    	rect.y = rect.y - self.ui.m_listNode:getContentSize().height
    	rect.height = rect.height + self.ui.m_listNode:getContentSize().height
    	viewport:call("setWorldBound", rect)
    end
	registerScriptObserver(self, self.onActiveAvatar, "MSG_AVATAR_ACTIVE_BACK_WITH_PARAM")
	registerScriptObserver(self, self.refreshView, "AvatarViewEx:refreshView")
end

function AvatarViewEx:onExit(  )
	dump("AvatarViewEx:onExit+++")
	-- self:getScheduler():unscheduleScriptEntry(self.entry)
	if self.page == PAGE_WARDROBE then
		-- 同步一下wardrobe小红点显示
		self:recordATypeShow(self.m_activeWardrobeTag)
		self:recordWardrobeItemIdShow(self.m_activeWardrobeTag)
	end

	-- body
	CCSafeNotificationCenter:unregisterScriptObserver(self, "MSG_AVATARTAGCELL_TOUCHED")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "MSG_AVATAR_ACTIVE_WARDROBE_STATUS_BACK")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "MSG_AVATAR_STATUS_CANCEL_BACK")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "MSG_AVATAR_ITEM_USE")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "MSG_REFRESH_CRYSTAL")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "GOLDEXCHANGE_REFRESH_COMMAND")
	CCSafeNotificationCenter:unregisterScriptObserver(self, MSG_AVATAR_INIT)
	CCSafeNotificationCenter:unregisterScriptObserver(self, "AvatarViewEx.confirmBuyItem")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "msg.tool.change")
	-- 这个主要是通知各种城堡恢复原型
	for i=AvatarType_Castle,AvatarType_MAX - 1 do
		CCSafeNotificationCenter:call("postNotification", "msg.item.status.time.change", CCInteger:create(i))
	end
    
    local scene = ImperialScene:call("getInstance")
    if scene then
    	scene:configHFViewPort()
    end
    unregisterScriptObserver(self, "MSG_AVATAR_ACTIVE_BACK_WITH_PARAM")
    unregisterScriptObserver(self, "AvatarViewEx:refreshView")
    if self.curUseItemId then 
    	self.curUseItemId = nil
    	DressIntroductionController:pullFuMoSkills()
    end
end

 -- "AvatarViewEx:onActiveAvatar+++" 
 --     "_cok_"          = "635674000
 --     "effectState" = {
 --         "509171"    = "1537240534
 --         "startTime" = "1536635879
 --     }
 --     "enchant_skills" = {
 --         "509171" = {
 --             "1230" = "2"
 --         }
 --     }
 --     "endTime"        = "153724053
 --     "m_status"       = "0"
 --     "oldStatus"      = "500540"
 --     "statusId"       = "509171"
 -- }
function AvatarViewEx:onActiveAvatar( dict )
	-- dump(dictToLuaTable(dict), "AvatarViewEx:onActiveAvatar+++",10)
	if not dict then return end
	local enchant_skills = dict:objectForKey("enchant_skills")
	if enchant_skills then 
		local tblSkills = dictToLuaTable(enchant_skills)
		DressIntroductionController:processFuMoSkills(tblSkills)
	end
end

function AvatarViewEx:onConfirmBuy (ref)
	--没有被调用
    Dprint('avatar buy item', self.sellitemid)
    local sellItemInfo = AvatarController:getInstance().avatarShopConfig[self.sellitemid]
	-- local sellItemInfo = ToolController:call("getSellItemInfoBySellId", self.sellitemid)
	if nil == sellItemInfo then
		return
	end
	local value1 = tonumber(sellItemInfo.value1)
    local tbl = dictToLuaTable(ref)
	ToolController:call("shopBuyTool", sellItemInfo.id, tbl.count, tbl.count * value1)
end

function AvatarViewEx:getCurrenItemId(  )
	if self.page == PAGE_STORE then
		if nil == self.m_storeData[self.m_activeStoreTag] or nil == self.m_activeStoreIndexTable[self.m_activeStoreTag] then
			return self.m_activeStoreTag
		end
		return self.m_storeData[self.m_activeStoreTag][self.m_activeStoreIndexTable[self.m_activeStoreTag]]
	else
		if nil == self.m_wardrobeData[self.m_activeWardrobeTag] or nil == self.m_activeWardrobeIndexTable[self.m_activeWardrobeTag] then
			return self.m_activeWardrobeTag
		end
		return self.m_wardrobeData[self.m_activeWardrobeTag][self.m_activeWardrobeIndexTable[self.m_activeWardrobeTag]].itemId
	end
end

function AvatarViewEx:refreshButtonSpr( )
	if self.scene == SCENE_WORLD then
		self.ui.m_worldSpr:setVisible(false)
		self.ui.m_citySpr:setVisible(true)
		self.m_impTouchHandler:call("setASCENE", SCENE_WORLD)
		-- 151437=城堡
		self.ui.m_label5:setString(getLang("151437"))
	else
		self.ui.m_worldSpr:setVisible(true)
		self.ui.m_citySpr:setVisible(false)
		self.m_impTouchHandler:call("setASCENE", SCENE_IMPERIAL)
		-- 139503=世界
		self.ui.m_label5:setString(getLang("139503"))
	end

	if CCCommonUtilsForLua:isFunOpenByKey("skin_mall") then
		self.ui.m_nodeUseAll:setVisible(self.page ~= PAGE_STORE)
		self.ui.m_btnDress:setEnabled(self.page == PAGE_STORE)
		self.ui.m_btnShop:setEnabled(self.page ~= PAGE_STORE)
	else
		if self.page == PAGE_STORE then
			self.ui.m_storeSpr:setVisible(false)
			self.ui.m_wardrobeSpr:setVisible(true)
			self.ui.m_label6:setString(getLang("111901"))	--111901=去装扮
			self:call("setTitleName", getLang("111900"))	--111900=去购买
		else
			self.ui.m_storeSpr:setVisible(true)
			self.ui.m_wardrobeSpr:setVisible(false)
			self.ui.m_label6:setString(getLang("111900"))
			self:call("setTitleName", getLang("111901"))
		end
	end
end

function AvatarViewEx:refreshTop(  )
	-- Dprint("AvatarViewEx:refreshTop")
	self:refreshButtonSpr()
	self.ui.m_noLabel:setString("")
	local itemId = self:getCurrenItemId()
	-- Dprint("currentItemId ", itemId)
	local ainfo = AvatarController:call("getAvatarInfoByGoodsId", itemId)
	-- 经典ainfo为nil
	self.m_civPreviewNode:removeAllChildren()
	if self.page == PAGE_STORE then
		if ainfo and AvatarType_Civ == ainfo:call("getAvatarType") then
			self:refreshCivPreview(ainfo)
		end
	else
		-- 162022=使用
		-- CCCommonUtilsForLua:call("setButtonTitle", self.m_btn, getLang("162022"))
		if #self.m_wardrobeTags == 0 then
			-- 衣柜里没有皮肤
			-- self.m_lineNode:setVisible(false)
			self.ui.m_noLabel:setString(getLang("137941"))
		else
			local t = self.m_wardrobeData[self.m_activeWardrobeTag]
			if #t == 0 then
				-- 衣柜里没有皮肤
				-- self.m_lineNode:setVisible(false)
				self.ui.m_noLabel:setString(getLang("137941"))
			else
				if not self.m_activeWardrobeIndexTable[self.m_activeWardrobeTag] then 
					return 
				end
			end
		end
		if AvatarType_Civ == self.m_activeWardrobeTag then
			self:refreshCivPreview(ainfo)
		end
	end
	self:refreshASCENE()
	self:onEnterFrame()
end

function AvatarViewEx:refreshCivPreview(ainfo)
	-- dump("AvatarViewEx:refreshCivPreview+++")
	local civ = tostring(GlobalData:call("getPlayerInfo"):call("getCivilizationType")) -- default
	if ainfo then
		local statusId = ainfo:call("getStatusId")
		civ = CCCommonUtilsForLua:call("getPropById", tostring(statusId), "civilization_skin")
	end
	Dprint("civilization_skin ", civ)

    local m_xmlData = CCCommonUtilsForLua:getGroupByKey("civilization")
    if not m_xmlData then
        Dprint("AvatarViewEx m_xmlData error !")
        return nil
    end
    local civCfg
    for k,v in pairs(m_xmlData) do
    	if v.type == civ then
    		civCfg = v
    		break
    	end
    end
    dump(civCfg, 'civCfg')
    if not civCfg then
    	return
    end

    local iconTbl = string.split(civCfg.unlock_icon , "|")
    local img = iconTbl[2] .. ".png"
    -- dump(img,"img+++")
    local spr = CCLoadSprite:call("createSprite", img)
    local posx,posy = 0,100
    spr:setScale(1.6)
    if CCCommonUtilsForLua:call("isIosAndroidPad") then 
    	posy = -130
    end
    spr:setPosition(posx, posy)
	self.m_civPreviewNode:addChild(spr)
end

function AvatarViewEx:onTouchBegan( x, y )
	if not self:getParent(  ):isVisible(  ) then
		return false
	end

	self.startTouchPt = cc.p(x, y)
	self.ui.m_sceneNode:setScale(1)
	self.ui.m_nodeDressIntr:setScale(1)
	if isTouchInside(self.ui.m_sceneNode, x, y) then
		self.ui.m_sceneNode:setScale(1.2)
		return true
	end

	if not CCCommonUtilsForLua:isFunOpenByKey("skin_mall") then
		self.ui.m_roomNode:setScale(1)
		if isTouchInside(self.ui.m_roomNode, x, y) then
			self.ui.m_roomNode:setScale(1.2)
			return true
		end
	end
	if isTouchInside(self.ui.m_nodeDressIntr, x, y) then
		self.ui.m_nodeDressIntr:setScale(1.2)
		return true
	end

	--【Awen】皮肤羁绊 
	if CCCommonUtilsForLua:isFunOpenByKey("skin_fetters") then
		self.ui.m_nodeFetters:setScale(1)
		if isTouchInside(self.ui.m_nodeFetters, x, y) then
			self.ui.m_nodeFetters:setScale(1.2)
			return true
		end
	end
	return true
end

function AvatarViewEx:onTouchEnded( x, y )
	Dprint("vatarView:onTouchBegan")
	self.ui.m_sceneNode:setScale(1)
	self.ui.m_nodeDressIntr:setScale(1)
	local dis = 10
	if CCCommonUtilsForLua:call("isIosAndroidPad") then
		dis = 20
	end
	if cc.pGetDistance(self.startTouchPt, cc.p(x, y)) > dis then
		return
	end
	if isTouchInside(self.ui.m_sceneNode, x, y) then
		self:changeASCENE()
		return
	end

	if not CCCommonUtilsForLua:isFunOpenByKey("skin_mall") then
		self.ui.m_roomNode:setScale(1)
		if isTouchInside(self.ui.m_roomNode, x, y) then
			self:changeRoom()
			return
		end
	end

	--【Awen】皮肤羁绊 
	if CCCommonUtilsForLua:isFunOpenByKey("skin_fetters") then
		self.ui.m_nodeFetters:setScale(1)
		if isTouchInside(self.ui.m_nodeFetters, x, y) then
			local view = Drequire("game.avatar.AvatarFetterView").create()
        	PopupViewController:addPopupInView(view)
			return true
		end
	end

	if isTouchInside(self.ui.m_crystalSprite, x, y) then 
	 --    self:call("closeSelf")
		-- CCCommonUtilsForLua.jumpToTarget(9, 9990500)
		local view = Drequire("game.CommonPopup.ItemGetMethodView"):create("500003")
		PopupViewController:call("addPopupView", view)
	end
	if self.dressIntrFunOn and isTouchInside(self.ui.m_nodeDressIntr, x, y) then
		local view = Drequire("game.DressIntroduction.DressIntroductionView"):create()
        PopupViewController:addPopupInView(view)
		return
	end
end

-- 点击装扮/商城
function AvatarViewEx:onClickBtnTab()
	self:changeRoom()
end

-- 点击全部使用
function AvatarViewEx:onClickBtnUseAll()
	local saveTime = atoi(cc.UserDefault:getInstance():getStringForKey("SKIN_SCALE_CHANGE_CONFIRM", ""))
	local curTime = getTimeStamp()
	if curTime < saveTime 
	or not SkinScaleMgrIns:checkIsAllMatchStatus()
	or not self:isNeedScaleComfirm() then
		self:onUseAllChoose()
	else
		local function callback()
			self:onUseAllChoose()
			SkinScaleMgrIns:clearSkinScales()
		end
		local params = {strTip = getLang("52092118"), 
		strCheckIsNotShowToday = "SKIN_SCALE_CHANGE_CONFIRM",
		onOkChkCallback = callback}
		local view = Drequire("game.activity.GoldDigTreasure.GoldDigTreasureConfirm"):create(params)
		PopupViewController:addPopupView(view)
	end 
end

function AvatarViewEx:isNeedScaleComfirm()
	if table.isNilOrEmpty(self.m_activeWardrobeIndexTable) then
		return false
	end
	for k,v in pairs(self.m_activeWardrobeIndexTable) do
		local _data = self.m_wardrobeData[k][v]
		if not _data then 
			return false
		end
		local atype = _data.tag
		if SkinScaleMgrIns:checkIsSkinScaleType(atype) then
			return true
		end
	end
	return false
end

function AvatarViewEx:onUseAllChoose()
	local _statusList = {}
	for k,v in pairs(self.m_activeWardrobeIndexTable or {}) do
		local _data = self.m_wardrobeData[k][v]
		Dprint("AvatarViewEx:onClickBtnUseAll 1 ", k,v,_data.isInBag,_data.itemId,_data.endTime)
		if _data.isInBag then
			Dprint("AvatarViewEx:onClickBtnUseAll useTool", _data.itemId)
			ToolController:call("useTool", _data.itemId, 1, true, false)
		else
			if _data.endTime > 0 and _data.endTime < GlobalData:call("getWorldTime") then
				return
			end
			if _data.itemId < 200 then
				AvatarController:call("startCancelAvatar", _data.itemId)
				local actStatus = AvatarController:call("getActiveStatusByType", k)
				if actStatus > 0 then 
					DressIntroductionController:rmFuMoSkills(tostring(actStatus))
				end
			else
				local _ainfo = AvatarController:call("getAvatarInfoByGoodsId", _data.itemId)
				if _ainfo then
					local _selStatusId = _ainfo:call("getStatusId")
					local _actStatusId = AvatarController:call("getActiveStatusByType", k)
					Dprint("AvatarViewEx:onClickBtnUseAll 2 ",_selStatusId)
					if _selStatusId and _selStatusId ~= _actStatusId then
						table.insert(_statusList, _selStatusId)
					end
				end
			end
		end
	end
	
	local _statusIds = ''
	for i=1, #_statusList do
		_statusIds = _statusIds .. _statusList[i]
		if i < #_statusList then
			_statusIds = _statusIds .. ';'
		end
	end
	Dprint("AvatarViewEx:onClickBtnUseAll", _statusIds)
	if string.len(_statusIds) > 0 then
		self.ctl:reqBatchActive(_statusIds)
	end
end

-- 点击索引按钮
function AvatarViewEx:onClickBtnIndex()
	if self.page == PAGE_WARDROBE then
		-- 激活“全部”页签
		local _newAType = AvatarType_None
		if self.m_activeWardrobeIndexTable then
			local activeIndex = self.m_activeWardrobeIndexTable[_newAType]
			if activeIndex then
				if not self.m_wardrobeData[_newAType] or not self.m_wardrobeData[_newAType][activeIndex] then
					dump(index,"error, no wardrobe item index found2306+++")
				else
					self.touchIndex = activeIndex 
				end
			end
		end
		self.touchedAvatarType = self.touchedAvatarType or _newAType
		CCSafeNotificationCenter:call("postNotification", "MSG_AVATARTAGCELL_TOUCHED", CCInteger:create(_newAType))

		local view = Drequire("game.avatar.AvatarWardrobeIndexView").create(self, 1)
		PopupViewController:call("addPopupView", view)
	else
		local view = Drequire("game.avatar.AvataStoreIndexView").create(self, 2)
		PopupViewController:call("addPopupView", view)
	end
end

function AvatarViewEx:getAvatarType ()
	if self.page == PAGE_STORE then
		return self.m_activeStoreTag
	end
	return self.m_activeWardrobeTag
end

function AvatarViewEx:changeRoom(  )
	Dprint("AvatarViewEx:changeRoom")
	if self.page == PAGE_STORE then
		self.page = PAGE_WARDROBE
		self:generateWardrobeData()
	else
		-- 同步一下wardrobe小红点显示
		self:recordATypeShow(self.m_activeWardrobeTag)
		self:recordWardrobeItemIdShow(self.m_activeWardrobeTag)
		self.page = PAGE_STORE
	end

	self:refreshView()
end

-- 2019-10-16 hyp
function AvatarViewEx:changeToWardrobe()
	self.page = PAGE_WARDROBE
	self:generateWardrobeData()
	self:refreshView()
end


-- 刷新顶部的
function AvatarViewEx:refreshASCENE ()
	local itemId = self:getCurrenItemId()
	local ainfo = AvatarController:call("getAvatarInfoByGoodsId", itemId)
	-- 默认采用页签的类型
	local atype = self:getAvatarType()
	if ainfo then
		-- 对于钻石商城，要采用cell的类型
		atype = ainfo:call('getAvatarType')
	end

	if self.scene == SCENE_IMPERIAL then
		if atype == AvatarType_March 
			or atype == AvatarType_ChatBg 
			or atype == AvatarType_Nameplate 
			or atype == AvatarType_CastleEffect
			or atype == AvatarType_Wings
			or atype == AvatarType_CivFort
			or atype == AvatarType_Aura
			then
			self:changeASCENE()
		end
	else
		if atype == AvatarType_Ground then
			self:changeASCENE()
		end
	end
end

function AvatarViewEx:changeASCENE(  )
	if self.m_isChangingScene then
		return
	end
	if (self.page == PAGE_STORE and AvatarType_Civ == self.m_activeStoreTag) or
	   (self.page == PAGE_WARDROBE and AvatarType_Civ == self.m_activeWardrobeTag) then
		return
	end

	self.ui.m_nodeCloud:removeAllChildren()
	
	local function addCloudAndFadeIn(  )
		Dprint("AvatarViewEx:changeASCENE addCloudAndFadeIn")
		local winsize = cc.Director:getInstance():getIFWinSize()
		local aniNode = CCBReaderLoad("CloudLua", cc.CCBProxy:create(), self)
		aniNode:setPosition(winsize.width * 0.5, winsize.height * 0.5)
		self.ui.m_nodeCloud:addChild(aniNode)
		local animationManager = ccb["cloud"]["mAnimationManager"]
		animationManager:runAnimationsForSequenceNamed("FadeIn")
	end

	local function addWorld(  )
		Dprint("AvatarViewEx:changeASCENE addWorld")
		local arr = CCArray:create()
		if self.page == PAGE_STORE then
			for k,v in pairs(self.m_activeStoreIndexTable) do
				local itemId = self.m_storeData[k][v]
				arr:addObject(CCInteger:create(tonumber(itemId)))
			end
		else
			for k,v in pairs(self.m_activeWardrobeIndexTable) do
				local data = self.m_wardrobeData[k][v]
				if data then
					arr:addObject(CCInteger:create(tonumber(data.itemId)))
				end
			end
		end
		local world = VirtualWorld:call("createForLua", arr)
		if nil ~= world then
			world:call("showLensStretching", 0.8, 0)
			world:setPositionY(-480)
			self.ui.m_nodeWorld:addChild(world)
			Dprint("AvatarViewEx:changeASCENE", self.ui.m_nodeWorld:getPositionX(), self.ui.m_nodeWorld:getPositionY())
		end
	end

	local function switchScene(  )
		Dprint("AvatarViewEx:changeASCENE switchScene")
		if self.scene == SCENE_IMPERIAL then
			self.scene = SCENE_WORLD 
			self.ui.m_worldSpr:setVisible(false)
			self.ui.m_citySpr:setVisible(true)
			self.m_impTouchHandler:call("setASCENE", SCENE_WORLD)
			-- 151437=城堡
			self.ui.m_label5:setString(getLang("151437"))
		else
			self.scene = SCENE_IMPERIAL
			self.ui.m_worldSpr:setVisible(true)
			self.ui.m_citySpr:setVisible(false)
			self.m_impTouchHandler:call("setASCENE", SCENE_IMPERIAL)
			-- -- 139503=世界
			self.ui.m_label5:setString(getLang("139503"))
		end
		local param = tostring((self.touchedAvatarType or 0))
		CCSafeNotificationCenter:call("postNotification", "MSG_AVATAR_VIEW_SWITCH_SCENE", CCString:create(param))
	end

	local function removeWorld(  )
		Dprint("AvatarViewEx:changeASCENE removeWorld")
		self.ui.m_nodeWorld:removeAllChildren()
	end

	local function cloudeFadeOut(  )
		Dprint("AvatarViewEx:changeASCENE cloudeFadeOut")
		ccb["cloud"]["mAnimationManager"]:runAnimationsForSequenceNamed("FadeOut")
	end

	local function removeCloud(  )
		Dprint("AvatarViewEx:changeASCENE removeCloud")
		self.ui.m_nodeCloud:removeAllChildren()
		self.m_isChangingScene = false
	end

	self.m_isChangingScene = true

	local worldChange = cc.CallFunc:create(addWorld)
	if self.scene == SCENE_WORLD then
		worldChange = cc.CallFunc:create(removeWorld)
	end

	local sequence = cc.Sequence:create(cc.CallFunc:create(addCloudAndFadeIn), 
		cc.DelayTime:create(10 * 0.17),
		worldChange,
		cc.CallFunc:create(switchScene),
		cc.CallFunc:create(cloudeFadeOut),
		cc.DelayTime:create(0.17),
		cc.DelayTime:create(0.17),
		cc.CallFunc:create(removeCloud)
		)
	self:runAction(sequence)
end

function AvatarViewEx:getCurShowData(  )
	-- dump(self.m_storeData,"self.m_storeData+++")
	-- dump(self.m_wardrobeData,"self.m_wardrobeData+++")
	local data = nil
	if self.page == PAGE_STORE then
		data = self.m_storeData[self.m_activeStoreTag]
	else
		data = self.m_wardrobeData[self.m_activeWardrobeTag]
	end
	return data or {}
end

function AvatarViewEx:cellSizeForTableMain( view, idxx )
	if self.touchIndex and idxx then
		local row1 = idxx+1
		local row2 = math.ceil(self.touchIndex/3)
		if row1 == row2 then
			return 639, 495
		end
	end
	return 600, 195
end

function AvatarViewEx:tableCellAtIndexMain( view, idx )
	if not idx then 
		return 
	end

	local idx1 = 3*idx + 1
	local idx2 = idx1 + 1
	local idx3 = idx2 + 1
	local data = self:getCurShowData()
	if (idx1 > #data) then
		return nil
	end
	if (idx2 > #data) then
		idx2 = nil
	end
	if (idx3 > #data) then
		idx3 = nil
	end

	local bigCell = false
	if self.touchIndex then
		if idx1 then 
			local row1 = math.ceil(idx1/3)
			local row2 = math.ceil(self.touchIndex/3)
			if row1 == row2 then
				bigCell = true
			end
		end
	end
		
	local cell = view:dequeueCell()
	if (cell) then
		cell:setData(idx1,idx2,idx3)
	else
		cell = AvatarCell.new(idx1,idx2,idx3, self, self.ui.m_listNode)
	end
	cell:showBottomNode(bigCell)
	return cell
end

function AvatarViewEx:numberOfCellsInTableViewMain( view )
	local data = self:getCurShowData()
	if nil == data then
		return 0
	end
	return math.ceil(#data / 3.0)
end

--tab
function AvatarViewEx:cellSizeForTable(view, idx)
    if CCCommonUtilsForLua:isFunOpenByKey("skin_mall") and self.page == PAGE_STORE then
		return 181, 82
	end
	return 141, 82
end

--tab
-- "self.m_storeTags+++" = {
--     1 = 99
--     2 = 100
--     3 = 119
-- }

-- "self.m_wardrobeTags+++" = {
--     1 = 100
--     2 = 101
--     3 = 103
--     4 = 104
--     5 = 110
-- }

-- AvatarType_None = 0
-- AvatarType_Diamond = 98 --//钻石购买的
-- AvatarType_MysteryPiece = 99 -- //神秘礼盒碎片购买的
-- AvatarType_Castle = 100 --//城堡皮肤 包括内城和外城
-- AvatarType_March = 101 --// 行军皮肤
-- AvatarType_Ground = 102  --// 主城地表皮肤
-- AvatarType_ChatBg = 103 --// 聊天气泡
-- AvatarType_Nameplate = 104 --// 铭牌
-- AvatarType_CastleBubble = 105 --// 城堡上冒气泡
-- AvatarType_Protect = 106 --// 保护罩
-- AvatarType_HEHEHE = 107 -- 被莫名其妙占着了
-- AvatarType_CastleEffect = 108 --// 城堡上冒特效  和 105很像
-- AvatarType_Wings = 109  --// 翅膀
-- AvatarType_Civ = 110  --// 文明
-- AvatarType_CivFort = 114  --// 文明堡垒皮肤
-- AvatarType_HeadFrame = 115 -- // 头像框
-- AvatarType_Aura = 116, //光环
-- AvatarType_Coin = 119 -- //金币购买的
-- AvatarType_Item = 199
-- AvatarType_MAX = 200
function AvatarViewEx:tableCellAtIndex(view, idx)
	local avtar_ctrl = AvatarController:getInstance()
	if not self.initTagsPic then 
		self.initTagsPic = true
		self.tagsPic = {}
		self.tagsPic[AvatarType_None]={icon = "dresstype_all.png", dialog = "9200263"}	--9200263=全部
		self.tagsPic[AvatarType_Diamond]={icon = "diamond.png",dialog = ""}
		self.tagsPic[AvatarType_MysteryPiece]={icon = CCCommonUtilsForLua:getPropByIdGroup("goods", tostring(avtar_ctrl:getItemDefaultCurrId()), "icon")..".png", dialog = ""}
		self.tagsPic[AvatarType_Castle]={icon = "dresstype_castle.png",dialog = "9200264"}	--9200264=城堡
		self.tagsPic[AvatarType_March]={icon = "dresstype_queue.png",dialog = "9200267"}	--9200267=队列
		self.tagsPic[AvatarType_Ground]={icon = "city.png",dialog = "101482"}				--101482=装扮
		self.tagsPic[AvatarType_ChatBg]={icon = "dresstype_bubble.png",dialog = "9200268"}	--9200268=气泡
		self.tagsPic[AvatarType_Nameplate]={icon = "dresstype_nameplate.png",dialog = "9200269"}--9200269=铭牌
		self.tagsPic[AvatarType_CastleEffect]={icon = "dresstype_effect.png",dialog = "9200266"}--9200266=特效
		self.tagsPic[AvatarType_Wings]={icon = "dresstype_wing.png",dialog = "9200265"}		--9200265=翅膀
		self.tagsPic[AvatarType_Civ]={icon = "dresstype_castle.png",dialog = "9200264"}		--9200264=城堡
		self.tagsPic[AvatarType_CivFort]={icon = "dresstype_fortress.png",dialog = "310000"}	--310000=文明堡垒
		self.tagsPic[AvatarType_HeadFrame]={icon = "dresstype_headframe.png", dialog = "182071"}--182071=头像框
		self.tagsPic[AvatarType_Aura]={icon = "dresstype_guanghuan.png", dialog = "9442010"}	--9442010=光环
		self.tagsPic[AvatarType_Coin]={icon = "ui_gold.png",dialog = ""}
	end

	if AvatarController:getInstance():has_AvatarType_ForthTag() then
		self.tagsPic[AvatarType_ForthTag]={icon = CCCommonUtilsForLua:getPropByIdGroup("goods", tostring(avtar_ctrl:avatarTypeToCurrId(AvatarType_ForthTag)), "icon")..".png", dialog = ""}
	end
	-- dump(self.m_storeTags,"self.m_storeTags+++")
	-- dump(self.m_wardrobeTags,"self.m_wardrobeTags+++")
	idx = idx+1
    if idx > self:numberOfCellsInTableView(view) then
		return nil
    end
    local atype = 100

    if self.page == PAGE_STORE then
    	atype = self.m_storeTags[idx]
    else
    	atype = self.m_wardrobeTags[idx]
	end

	if CCCommonUtilsForLua:isFunOpenByKey("skin_mall") then
		return AvatarTagCell.new(atype, self)
	else
		local cell = view:dequeueCell()
		if cell ~= nil then 
			cell:setData(atype)
		else
			cell = AvatarTagCell.new(atype, self)
		end
		return cell
	end
end

--tab
function AvatarViewEx:numberOfCellsInTableView(view)
	local size = 0
	if self.page == PAGE_STORE then
		size = #self.m_storeTags
	else
		size = #self.m_wardrobeTags
	end
	return size
end

function AvatarViewEx:onClickGotoScale()
	if SkinScaleMgrIns:isOpen() then
		local isOpenSucess = SkinScaleMgrIns:OpenView()
		if isOpenSucess then
			PopupViewController:call("removePopupView", self)
		end
	end
end

--------------------------------------------------------------------------------------------------------------------------------------
function AvatarCell:ctor( idx1,idx2,idx3, father, boundNode )
	self.dataIndex1 = idx1
	self.dataIndex2 = idx2
	self.dataIndex3 = idx3
	self.father = father
	self.boundNode = boundNode
	self.rootPath = CCFileUtils:sharedFileUtils():getWritablePath() .. "dresource/"

	local proxy = cc.CCBProxy:create()
    local ccbiUrl = "AvatarCellNewEx.ccbi"
	local node = CCBReaderLoad(ccbiUrl, proxy, self)
    if nil == node then
        return false
    end
    self:addChild(node)

    self.touchLayer = cc.Layer:create()
	self:addChild(self.touchLayer)
	self.startTouchPt = cc.p(0, 0)
	local function touchHandle( eventType, x, y)
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		else
			self:onTouchEnded(x, y)
		end
	end
	self.touchLayer:registerScriptTouchHandler(touchHandle)
	self.touchLayer:setTouchEnabled(true)
	self.touchLayer:setSwallowsTouches(false)
	local function onNodeEvent( event )
		if event == "enter" then
			self:onEnter()
	    elseif event == "exit" then
	    	self:onExit()
	    end
	end
	self:registerScriptHandler(onNodeEvent)

    self:setData(idx1,idx2,idx3)
end

--购买皮肤
function AvatarCell:onBuyButton1Click(  )
	dump(self.father.touchIndex,"AvatarCell:onBuyButton1Click+++")
	if not self:isStore() then
		dump("error, not store+++1261")
		return
	end
	if not self.father.touchIndex then
		dump("error, no self.father.touchIndex+++1265")
		return 
	end
	local itemId = self:getItemId(self.father.touchIndex)
	if not itemId then 
		dump("error, no itemId+++1271")
		return 
	end

	local sellItemInfo = AvatarController:getInstance().avatarShopConfig[itemId]
	if nil == sellItemInfo then
		dump("error, no sellitemid+++1276")
		return
	end
	self.sellitemid = sellItemInfo.id
	local value1 = tonumber(sellItemInfo.value1)--sellItemInfo:getProperty("m_value1")
	if tonumber(sellItemInfo.value1_type) == 8 then
		if value1 > PlayerInfoController:getCrystalGold() then
			local view = Drequire("game.CommonPopup.ItemGetMethodView"):create("500003")
			PopupViewController:call("addPopupView", view)
			return
		end
	elseif tonumber(sellItemInfo.value1_type) == 11 then
		local currId = tonumber(AvatarController:getInstance():getItemCurrId(sellItemInfo))
		local be_defalut_currId = currId == AvatarController:getInstance():getItemDefaultCurrId()
		if ToolController:call("getToolInfoForLua", currId) ~= nil then
			if value1 > ToolController:call("getToolInfoForLua", currId):call("getCNT") then
				LuaController:flyHint("", "", getLang(be_defalut_currId and "350150" or "9711429"))	--350150=神秘碎片不足
				return
			end
		end
	else
		if value1 > GlobalData:call("getPlayerInfo"):getProperty("gold") then
			YesNoDialog:call("gotoPayTips")
			return
		end
	end
	
	local ainfo = AvatarController:call("getAvatarInfoByGoodsId", itemId)
	if AvatarType_Item == ainfo:call('getAvatarType') then
		AvatarController:getInstance():buyItem(itemId, 'AvatarView.confirmBuyItem')
		return
	end

	local function fun(  )
		--【Awen】使用新的购买协议
		if CCCommonUtilsForLua:isFunOpenByKey("skin_mall") then
			AvatarController:getInstance():reqBuyItem(self.sellitemid, 1)
		else
			ToolController:call("shopBuyTool", self.sellitemid, 1, value1)
		end
	end
	local dia = YesNoDialog:call("show", getLang("104919"), cc.CallFunc:create(fun))	--104919=我的领主，你确定购买此件物品吗？
	dia:call("showCancelButton")
	dia:call("setYesButtonTitle", getLang("confirm"))
	dia:call("setNoButtonTitle", getLang("cancel_btn_label"))
end

function AvatarCell:onFuMoBtnClick(  )
	dump("AvatarCell:onFuMoBtnClick+++")
    local tblParams = {mainViewId="FuMoView", goodsId=self.currentGoodsId}
    local JumpPageController = Drequire("game.JumpPageController")
	JumpPageController:jump2CommonPage( tblParams )	
end

function AvatarCell:onFuMoUseBtnClick(  )
	self:onUseButton1Click()
end

--使用皮肤
function AvatarCell:onUseButton1Click(  )
	local saveTime = atoi(cc.UserDefault:getInstance():getStringForKey("SKIN_SCALE_CHANGE_CONFIRM", ""))
	local curTime = getTimeStamp()
	if curTime < saveTime 
	or not SkinScaleMgrIns:checkIsAllMatchStatus()
	or not self:isCellNeedScaleComfirm() then
		self:onUseChoose()
	else
		local function callback()
			self:onUseChoose()
			SkinScaleMgrIns:clearSkinScales()
		end
		local params = {strTip = getLang("52092118"), 
		strCheckIsNotShowToday = "SKIN_SCALE_CHANGE_CONFIRM",
		onOkChkCallback = callback}
		local view = Drequire("game.activity.GoldDigTreasure.GoldDigTreasureConfirm"):create(params)
		PopupViewController:addPopupView(view)
	end 
end

function AvatarCell:isCellNeedScaleComfirm()
	if not self.father.touchIndex or not self.father.m_activeWardrobeTag then
		return false
	end
	if self.father.m_activeWardrobeTag == AvatarType_None then
		local _data = self.father.m_wardrobeData[self.father.m_activeWardrobeTag][self.father.touchIndex]
		if not _data then 
			return false
		end
		local atype = _data.tag
		return SkinScaleMgrIns:checkIsSkinScaleType(atype)
	end
	return SkinScaleMgrIns:checkIsSkinScaleType(self.father.m_activeWardrobeTag)
end

function AvatarCell:onUseChoose(  )
	dump(self.father.touchIndex,"AvatarCell:onUseButton1Click+++")
	if not self.father.touchIndex or not self.father.m_activeWardrobeTag then
		dump(self.father.m_activeWardrobeTag, "error, no self.father.touchIndex+++1304")
		return 
	end
	local data = self.father.m_wardrobeData[self.father.m_activeWardrobeTag][self.father.touchIndex]
	if not data or not data.itemId then 
		dump(data,"error, no data+++1309",10)
		return 
	end
	if data.isInBag then
		local itemId = data.itemId
		local hasPerSkin,perData = AvatarController:getInstance():hasPermanentSkin(itemId)
		if hasPerSkin then
			local per_name = string.split(perData.name,'|')
			CCCommonUtilsForLua:call("flyHint", "", "", getLang('113207',getLang(per_name[1],getLang(per_name[2]),getLang(per_name[3]) )))
			return
		end
		ToolController:call("useTool", itemId, 1, true, false)
        self.m_useButton1:setEnabled(false)
        self.father.curUseItemId = itemId        
	else
		if data.endTime > 0 and data.endTime < GlobalData:call("getWorldTime") then
			return
		end
		if data.itemId < 200 then
			AvatarController:call("startCancelAvatar", data.itemId)
			self.m_useButton1:setEnabled(false)
			local actStatus = AvatarController:call("getActiveStatusByType", self.father.m_activeWardrobeTag)
			if actStatus > 0 then 
				DressIntroductionController:rmFuMoSkills(tostring(actStatus))
			end
		else
			local ainfo = AvatarController:call("getAvatarInfoByGoodsId", data.itemId)
			if ainfo then
				AvatarController:call("startActiveAvatar", ainfo:call("getStatusId"))
				self.m_useButton1:setEnabled(false)
			end
		end
	end
end

--购买礼盒
function AvatarCell:onBuyButton2Click(  )
	dump(self.father.touchIndex,"AvatarCell:onBuyButton2Click+++")
	if not self.father.touchIndex then
		dump("error, no self.father.touchIndex+++1337") 
		return
	end
	local ainfo = self:getAInfo(self.father.touchIndex)
	if not ainfo then 
		dump("error, no ainfo+++1338")
		return
	end
	local itemId = self:getItemId(self.father.touchIndex)
	if not itemId then 
		dump("error, no itemId+++1347")
		return
	end
	if AvatarType_Item == ainfo:call("getAvatarType") then --AvatarType_Item，奖励的盒子
		local dict = CCDictionary:create()
		local rewardStr = CCCommonUtilsForLua:call("getPropById", tostring(itemId), "reward_info")

		-- @see open_GoodsRewardListView
		local rewardVec = string.split(rewardStr, '|')
		local rewardId = rewardVec[1]
		local rwd = GlobalData:call("getCachedRewardData", rewardId)
	    local rwdData = arrayToLuaTable(rwd)

	    if #rwdData == 0 then
		    GlobalData:call("checkAndRequestRewardData", rewardId)
	    end
	    local titleName
	    if #rewardVec < 2 then
		    titleName = getLang("9200246")
		else
			if tonumber(rewardVec[2]) == 0 then
				titleName = getLang("9200246")
	    	else
	    		titleName = getLang("9200247")
	    	end
	    end
	    local param = {rewardId = rewardId, reward = rwdData, btnName = getLang("101274"), titleName = titleName, rewardInfo = rewardVec}
		local view = Drequire("game.avatar.RewardListAvatarItemView"):create(itemId, param)
		PopupViewController:addPopupView(view)
	end
end

--使用盒子
function AvatarCell:onUseButton2Click(  )
	dump(self.father.touchIndex,"AvatarCell:onUseButton2Click+++")
	if not self.father.touchIndex then 
		dump("error:not self.father.touchIndex+++1377")
		return
	end
	local itemId = self:getItemId(self.father.touchIndex)
	if not itemId then 
		dump("error:no itemId+++1382")
		return 
	end
	local dict = CCDictionary:create()
    dict:setObject(CCString:create("ToolNumSelectView"), "name")
    dict:setObject(CCString:create(tostring(itemId)), "itemId")
    dict:setObject(CCString:create(tostring(0)), "opFrom")
    dict:setObject(CCString:create(""), "targetId")
    LuaController:call("openPopViewInLua", dict)
end

--查看盒子信息
function AvatarCell:onCheckButtonClick(  )
	dump(self.father.touchIndex,"AvatarCell:onCheckButtonClick+++")
	if not self.father.touchIndex then
		dump(self.father.touchIndex, "error, no self.father.touchIndex+++1397") 
		return
	end
	local ainfo = self:getAInfo(self.father.touchIndex)
	if not ainfo then 
		dump("error:not ainfo+++1403")
		return
	end
	local itemId = self:getItemId(self.father.touchIndex)
	if not itemId then 
		dump("error:not itemId+++1408")
		return
	end
	if AvatarType_Item == ainfo:call("getAvatarType") then --AvatarType_Item，奖励的盒子
		local dict = CCDictionary:create()
		local rewardStr = CCCommonUtilsForLua:call("getPropById", tostring(itemId), "reward_info")

		-- @see open_GoodsRewardListView
		local rewardVec = string.split(rewardStr, '|')
		local rewardId = rewardVec[1]
		local rwd = GlobalData:call("getCachedRewardData", rewardId)
	    local rwdData = arrayToLuaTable(rwd)

	    if #rwdData == 0 then
		    GlobalData:call("checkAndRequestRewardData", rewardId)
	    end
	    local titleName
	    if #rewardVec < 2 then
		    titleName = getLang("9200246")
		else
			if tonumber(rewardVec[2]) == 0 then
				titleName = getLang("9200246")
	    	else
	    		titleName = getLang("9200247")
	    	end
	    end
	    local param = {rewardId = rewardId, reward = rwdData, btnName = getLang("101274"), titleName = titleName, rewardInfo = rewardVec}
		local view = Drequire("game.avatar.RewardListAvatarItemView"):create(itemId, param)
		PopupViewController:addPopupView(view)
	end
end

-- 点击偏好
function AvatarCell:onClickBtnLike()
	local _ainfo = AvatarController:call("getAvatarInfoByGoodsId", self:getItemId(self.father.touchIndex))
	if _ainfo then
		local _data = self.father.m_wardrobeData[self.father.m_activeWardrobeTag][self.father.touchIndex]
		if (not _data) or not _data.itemId then 
			return 
		end
		AvatarController:getInstance():reqLike(_ainfo:call("getStatusId"), _data.mark == 0)
	end
end

function AvatarCell:getAvatarType(  ) --当前是哪个tab
	if self:isStore() then
		return self.father.m_activeStoreTag
	end
	return self.father.m_activeWardrobeTag
end

function AvatarCell:getAInfo( dataIndex )
	local itemId = self:getItemId(dataIndex)
	Dprint("AvatarCell:getAInfo ", itemId)
	return AvatarController:call("getAvatarInfoByGoodsId", itemId)
end

function AvatarCell:getItemId( dataIndex )
	if self:isStore() then
		return self.father.m_storeData[self.father.m_activeStoreTag][dataIndex]
	else
		-- dump(self.father.m_wardrobeData[self.father.m_activeWardrobeTag] ,"AvatarCell:getItemId")
		return self.father.m_wardrobeData[self.father.m_activeWardrobeTag][dataIndex].itemId
	end
end

function AvatarCell:getData( dataIndex )
	if self:isStore() then
		return self.father.m_storeData[self.father.m_activeStoreTag][dataIndex]
	else
		return self.father.m_wardrobeData[self.father.m_activeWardrobeTag][dataIndex]
	end
end

function AvatarCell:addYongJiuStars( cellIndex )
	local parent,yongJiuAniRootNode = self:getYongJiuRootNode(cellIndex)
	if yongJiuAniRootNode then 
		local path = self.rootPath.."wardrobe_yongjiu_star"
		local particle = ParticleController:call("createParticleForLua", path)
		if particle then
			particle:setPositionY(45)
			particle:setScale(1.2)
			yongJiuAniRootNode:addChild(particle)
		end
	end 
end

function AvatarCell:addYongJiuSplash(cellIndex)
	local parent,yongJiuAniRootNode = self:getYongJiuRootNode(cellIndex)
	if yongJiuAniRootNode then 
	    local skin_file = self.rootPath.."sk_wardrobe_spine.atlas"
	    local skin_json = self.rootPath.."wardrobe_spine.json"
	    if cc.FileUtils:getInstance():isFileExist(skin_file) and cc.FileUtils:getInstance():isFileExist(skin_json) then
	        local animationObj = IFSkeletonAnimation:call("create", skin_json, skin_file)
	        if animationObj then
	            animationObj:setAnimation(0, "animation", true)
	            yongJiuAniRootNode:addChild(animationObj)
	        end
	    end
	end
end

function AvatarCell:createYongJiuLable( )
	local yongJiuLabel = cc.Label:create()
	yongJiuLabel:setAnchorPoint(cc.p(0.5, 0))
 	yongJiuLabel:setSystemFontSize(18)
 	yongJiuLabel:setColor(cc.c3b(255, 233, 108))
 	yongJiuLabel:setString(getLang("101502")) --‘永久’
 	yongJiuLabel:setPositionY(8)
 	return yongJiuLabel
end

function  AvatarCell:addYongJiuLable( cellIndex )
	local parent,yongJiuAniRootNode = self:getYongJiuRootNode(cellIndex)
	if yongJiuAniRootNode then 
		local yongJiuLabel = self:createYongJiuLable()
	 	yongJiuAniRootNode:addChild(yongJiuLabel)
	end
end

function AvatarCell:getYongJiuRootNode( cellIndex )
	local function createRootNode( parent )
		local yongJiuAniRootNode = cc.Node:create()
		yongJiuAniRootNode:setPositionX(self.m_selectedSpr1:getContentSize().width/2)
		parent:addChild(yongJiuAniRootNode)
		return yongJiuAniRootNode
	end
	local parent = nil
	local yongJiuAniRootNode = nil
	if cellIndex == cell_index_1 then
		parent = self.m_Node1
		if not self.m_yongJiuAniRootNode1 then 
			self.m_yongJiuAniRootNode1 = createRootNode(parent)
		end
		yongJiuAniRootNode = self.m_yongJiuAniRootNode1
	elseif cellIndex == cell_index_2 then
		parent = self.m_Node2
		if not self.m_yongJiuAniRootNode2 then 
			self.m_yongJiuAniRootNode2 = createRootNode(parent)
		end
		yongJiuAniRootNode = self.m_yongJiuAniRootNode2
	elseif cellIndex == cell_index_3 then
		parent = self.m_Node3
		if not self.m_yongJiuAniRootNode3 then 
			self.m_yongJiuAniRootNode3 = createRootNode(parent)
		end
		yongJiuAniRootNode = self.m_yongJiuAniRootNode3
	else
		dump("error1386+++")
	end
	return parent,yongJiuAniRootNode
end

--添加永久动画到AvatarCell
function  AvatarCell:addYongJiuAnimation( cellIndex )
	-- dump(cellIndex, "AvatarCell:addYongJiuAnimation+++")
	local rootNode = nil
	if cellIndex == cell_index_1 then
		rootNode = self.m_yongJiuAniRootNode1
	elseif cellIndex == cell_index_2 then
		rootNode = self.m_yongJiuAniRootNode2
	elseif cellIndex == cell_index_3 then
		rootNode = self.m_yongJiuAniRootNode3
	else
		dump("error, wrong cellIndex1412+++")
		return
	end
	if rootNode then 
		-- dump("tip, already added+++")
		return
	end
	local parent,yongJiuAniRootNode = self:getYongJiuRootNode(cellIndex)
	if not yongJiuAniRootNode then 
		dump("error, fail yongJiuAniRootNode 1525+++")
		return 
	end

	self:addYongJiuSplash(cellIndex)
	self:addYongJiuLable(cellIndex)
	self:addYongJiuStars(cellIndex)
end

function  AvatarCell:setYongJiuAniVisible(visible,cellIndex)
	local yongJiuAniRootNode = nil
	if cellIndex == cell_index_1 then
		yongJiuAniRootNode = self.m_yongJiuAniRootNode1
	elseif cellIndex == cell_index_2 then
		yongJiuAniRootNode = self.m_yongJiuAniRootNode2
	elseif cellIndex == cell_index_3 then
		yongJiuAniRootNode = self.m_yongJiuAniRootNode3
	else
		dump(cellIndex,"tip 1412+++")
		return
	end
	if yongJiuAniRootNode then 
		yongJiuAniRootNode:setVisible(visible)
	end
end

function AvatarCell:setData( idx1,idx2,idx3 )
	self.dataIndex1 = idx1
	self.dataIndex2 = idx2
	self.dataIndex3 = idx3
	self:setCellData(cell_index_1, idx1)
	self:setCellData(cell_index_2, idx2)
	self:setCellData(cell_index_3, idx3)
end

function AvatarCell:setCellData( cellIndex, dataIndex )
	local haveNode = nil
	local bottomNode = nil
	local leftLabel = nil
	local goldNode = nil
	local redFlag = nil
	local haveLabel = nil
	local goldLabel = nil
	local goldSprite = nil
	local mSprite = nil
	local headNode = nil
	local fumoNode = nil
	local fumoLvLable = nil
	local _nodeOn = nil
	local _flagCollect = nil
	if cellIndex == cell_index_1 then
		if dataIndex then 
			haveNode = self.m_haveNode1
			bottomNode = self.m_bottomNode1
			leftLabel  = self.m_leftLabel1
			goldNode = self.m_goldNode1
			redFlag = self.m_redFlag1
			haveLabel = self.m_haveLabel1
			goldLabel = self.m_goldLabel1
			goldSprite = self.m_goldSprite1
			mSprite = self.m_sprite1
			selectedSpr = self.m_selectedSpr1
			headNode = self.m_headNode1
			fumoNode = self.m_nodeFumo1
			fumoLvLable = self.m_labelFumo1
			_nodeOn = self.m_nodeOn1
			_flagCollect = self.m_flagCollect1
			self.m_Node1:setVisible(true)
		else
			self.m_nodeFumo1:setVisible(false)
			self.m_Node1:setVisible(false)
			self.m_selectNode1:setVisible(false)
			return
		end
	elseif cellIndex == cell_index_2 then 
		if dataIndex then 
			haveNode = self.m_haveNode2
			bottomNode = self.m_bottomNode2
			leftLabel  = self.m_leftLabel2
			goldNode = self.m_goldNode2
			redFlag = self.m_redFlag2
			haveLabel = self.m_haveLabel2
			goldLabel = self.m_goldLabel2
			goldSprite = self.m_goldSprite2
			mSprite = self.m_sprite2
			selectedSpr = self.m_selectedSpr2
			headNode = self.m_headNode2
			fumoNode = self.m_nodeFumo2
			fumoLvLable = self.m_labelFumo2
			_nodeOn = self.m_nodeOn2
			_flagCollect = self.m_flagCollect2
			self.m_Node2:setVisible(true)
		else
			self.m_nodeFumo2:setVisible(false)
			self.m_Node2:setVisible(false)
			self.m_selectNode2:setVisible(false)
			return
		end
	elseif cellIndex == cell_index_3 then 
		if dataIndex then 
			haveNode = self.m_haveNode3
			bottomNode = self.m_bottomNode3
			leftLabel  = self.m_leftLabel3
			goldNode = self.m_goldNode3
			redFlag = self.m_redFlag3
			haveLabel = self.m_haveLabel3
			goldLabel = self.m_goldLabel3
			goldSprite = self.m_goldSprite3
			mSprite = self.m_sprite3
			selectedSpr = self.m_selectedSpr3
			headNode = self.m_headNode3
			fumoNode = self.m_nodeFumo3
			fumoLvLable = self.m_labelFumo3
			_nodeOn = self.m_nodeOn3
			_flagCollect = self.m_flagCollect3
			self.m_Node3:setVisible(true)
		else
			self.m_nodeFumo3:setVisible(false)
			self.m_Node3:setVisible(false)
			self.m_selectNode3:setVisible(false)
			return
		end
	else
		dump("error+++1448")
		return
	end

	fumoNode:setVisible(false)
	haveNode:setVisible(false)
	bottomNode:setVisible(false)
	leftLabel:setVisible(false)
	goldNode:setVisible(false)
	redFlag:setVisible(false)
	_flagCollect:setVisible(false)
	self:setYongJiuAniVisible(false,cellIndex)

	local ainfo = self:getAInfo(dataIndex)
	local now = GlobalData:call("getWorldTime")

	if self:isStore() then
		self.m_nodeLike:setVisible(false)
		goldNode:setVisible(true)
	    haveLabel:setString(getLang("114126"))	-- 114126=已拥有
	    if ainfo and AvatarController:getInstance():isAlreadyHave(ainfo:call("getItemId")) then
	    	Dprint("haveNode:setVisible(true)_11111")
			haveNode:setVisible(true)
		end

		-- 下方的显示
		if ainfo then
			local sellItemInfo = AvatarController:getInstance().avatarShopConfig[self:getItemId(dataIndex)]
			if sellItemInfo then --and sellItemInfo:call("isValidToSell")
				bottomNode:setVisible(true)
				goldLabel:setString(CC_CMDITOA(tonumber(sellItemInfo.value1)))
				-- Dprint("1212121212",sellitemid, sellItemInfo:getProperty("m_value1"),CCCommonUtilsForLua:getPropById(sellitemid, "value1_type"))
				if tonumber(sellItemInfo.value1_type) == 8 then -- 如果为钻石
					goldSprite:setSpriteFrame(CCLoadSprite:call("loadResource", "diamond.png"))
					CCCommonUtilsForLua:call("setSpriteMaxSize", goldSprite, 36, true)
				elseif tonumber(sellItemInfo.value1_type) == 11 then -- 如果为神秘礼盒碎片
					local currId = AvatarController:getInstance():getItemCurrId(sellItemInfo)
					goldSprite:setSpriteFrame(CCLoadSprite:call("loadResource", CCCommonUtilsForLua:getPropByIdGroup("goods", currId, "icon")..".png"))
					CCCommonUtilsForLua:call("setSpriteMaxSize", goldSprite, 36, true)
				else
					goldSprite:setSpriteFrame(CCLoadSprite:call("loadResource", "ui_gold.png"))
					CCCommonUtilsForLua:call("setSpriteMaxSize", goldSprite, 36, true)
				end
			end
		end
	else
		haveLabel:setString(getLang("169629"))	-- 169629=激活中
		leftLabel:setVisible(true)
		if ainfo then
			bottomNode:setVisible(true)
		end
		local actStatus = AvatarController:call("getActiveStatusByType", self.father.m_activeWardrobeTag)
		local tdata = self:getData(dataIndex)
		--【Awen】设置偏好
		if CCCommonUtilsForLua:isFunOpenByKey("skin_mall") then
			self.m_nodeLike:setVisible(true)
			_flagCollect:setVisible(tdata.mark > 0)
		end
		if tdata.isInBag then
			local tinfo = ToolController:call("getToolInfoForLua", tdata.itemId)
			if tinfo then
				-- 105546=剩余
				leftLabel:setString(getLang("105546") .. CC_CMDITOA(tinfo:call("getCNT")))
				local isFirstShow = cc.UserDefault:getInstance():getBoolForKey("Avatar_atype_showed_" .. tostring(ainfo:call("getAvatarType")), false) == false
				Dprint("isFirstShow ", ainfo:call("getAvatarType"), isFirstShow)
				local tag = "Avatar_item_show_num_by_id_"
				tag = tag .. tostring(tdata.itemId)
				if isFirstShow == false then
					local lastShowNum = cc.UserDefault:getInstance():getIntegerForKey(tag, 0)
					local nowNum = tinfo:call("getCNT")
					if nowNum > lastShowNum then
						redFlag:setVisible(true)
					end
				end
			end
		else
			if ainfo then
				-- 101502=永久
				if tdata:isYongjiuStatus() then
					leftLabel:setString("")--不使用旧版‘永久’标签
					self:addYongJiuAnimation(cellIndex)
					self:setYongJiuAniVisible(true,cellIndex)
					
					local isSkinCanFuMo = FuMoController:isSkinCanFuMo(tostring(tdata.itemId))
					if isSkinCanFuMo and fumoLvLable then 
						fumoNode:setVisible(true)
    					local lv = FuMoController:getSkinLv(tostring(tdata.itemId)) 
						fumoLvLable:setString(getLang("102272", tostring(lv)))
					end
				else
					local left = tdata.endTime - now
					left = math.max(0, left)
					leftLabel:setString(format_time(left))
				end
				if ainfo:call("getStatusId") == actStatus then
					Dprint("haveNode:setVisible(true)_22222")
					haveNode:setVisible(true) --激活中
				end
			else
				leftLabel:setString(getLang("101474"))	-- 101474=经典
				if self.father.m_activeWardrobeTag == 0 then
					if self:getData(dataIndex).tag then
						actStatus = AvatarController:call("getActiveStatusByType", self:getData(dataIndex).tag)
					else
						actStatus = AvatarController:call("getActiveStatusByType", self:getItemId(dataIndex))
					end
				end
				if actStatus == 0 then
					Dprint("haveNode:setVisible(true)_33333")
					haveNode:setVisible(true)
				end
			end
		end
	end

	local iconStr = "avatar_zhanshi_" .. tostring(self:getItemId(dataIndex)) .. ".png"
	local _avatarFrame = CCLoadSprite:call("getSF", iconStr)
	if ainfo then
		if AvatarType_Item == ainfo:call("getAvatarType") then
			-- local sellitemid = ToolController:call("getAvatarSellMapIdByItemId", )
			Dprint('iconStr AvatarType_Item', sellitemid)
	        iconStr = CCCommonUtilsForLua:call("getIcon", tostring(self:getItemId(dataIndex)), CCLoadSpriteType.CCLoadSpriteType_GOODS)
	        mSprite:setVisible(true)
        elseif AvatarType_HeadFrame == ainfo:call("getAvatarType") then 
        	mSprite:setVisible(false)
        	local statusId = CCCommonUtilsForLua:getPropById(tostring(self:getItemId(dataIndex)), "para1")
        	local frameId = CCCommonUtilsForLua:getPropById(statusId, "frameID")
        	local pic = GlobalData:call("shared"):getProperty("playerInfo"):getProperty("pic")
        	local picVer = GlobalData:call("shared"):getProperty("playerInfo"):getProperty("picVer")
        	local uid = GlobalData:call("shared"):getProperty("playerInfo"):getProperty("uid")

        	local picSpr = CCLoadSprite:call("createSprite", pic, CCLoadSpriteType.CCLoadSpriteType_HEAD_ICON)
			CCCommonUtilsForLua:setSpriteMaxSize(picSpr, 80, false)
			headNode:removeAllChildren()
		    headNode:addChild(picSpr)

		    if CCCommonUtilsForLua:call("isUseCustomPic", picVer) then
		        self.m_headImgNode = HFHeadImgNode:call("create")
		        self.m_headImgNode:call("initHeadImgUrl2", headNode, CCCommonUtilsForLua:call("getCustomPicUrl", uid, picVer), 1.0, 80, true)
		    end
		    local picName = CCCommonUtilsForLua:getPropByIdGroup("lord_image_frame", frameId, "pic_name")
		    local picCount = tonumber(CCCommonUtilsForLua:getPropByIdGroup("lord_image_frame", frameId, "pic_count"))
		    if picName ~= "" and picCount > 0 then

				local frameTable = {}
			    for i=1, picCount do
			    	local path = cc.FileUtils:getInstance():getWritablePath() .. "dresource/" .. picName .. "/" .. picName .. "_" .. tostring(i) 
			        local frame = cc.SpriteFrame:create(path..".png", cc.rect(0, 0, 140, 140))
			        frameTable[i] = frame
			    end
			    local spr = CCLoadSprite:call("createSprite", "")
			    headNode:addChild(spr)
			    local frameAnimation = cc.Animation:createWithSpriteFrames(frameTable, 0.1)
			    local frameAnimate = cc.Animate:create(frameAnimation)
			    local frameRepeat = cc.RepeatForever:create(frameAnimate)
			    spr:stopAllActions()
			    spr:runAction(frameRepeat)
			end
	    else
	    	mSprite:setVisible(true)
			Dprint("ainfo:getName", ainfo:call("getName"))
			-- iconStr = "avatar_zhanshi_" .. ainfo:call("getName") .. ".png"
			iconStr = self:getGoodsIcon(ainfo:call("getItemId"))
		end
	elseif not self:isStore() and AvatarType_Civ == self.father.m_activeWardrobeTag then
		local curRaceType = GlobalData:call("getPlayerInfo"):call("getCivilizationType")
		Dprint("curRaceType", curRaceType)
		for k,v in pairs(self.father.m_storeData[AvatarType_Civ]) do
			dump(v, 'self.father.m_storeData[AvatarType_Civ]')
			local civStatusInfo = AvatarController:call("getAvatarInfoByGoodsId", v)
			if civStatusInfo then
				local statusId = civStatusInfo:call("getStatusId")
				civ = CCCommonUtilsForLua:call("getPropById", tostring(statusId), "civilization_skin")
				Dprint("civ", civ)
				if tonumber(civ) == curRaceType then
					-- iconStr = "avatar_zhanshi_" .. civStatusInfo:call("getName") .. ".png"
					iconStr = self:getGoodsIcon(civStatusInfo:call("getItemId"))
					break
				end
			end
		end
	end

	Dprint("iconStr+++", iconStr)
	if iconStr ~= "avatar_zhanshi_115.png"  then 
		if ainfo == nil or AvatarType_HeadFrame ~= ainfo:call("getAvatarType") then
			headNode:removeAllChildren()
		end
		if _avatarFrame == nil then
			_avatarFrame = CCLoadSprite:call("getSF", iconStr)
		else
			Dprint("iconStraa+++", "avatar_zhanshi_" .. tostring(self:getItemId(dataIndex)) .. ".png")
		end
		if _avatarFrame ~= nil then 
			mSprite:setDisplayFrame(_avatarFrame)	
			mSprite:setVisible(true)		
		end
		CCCommonUtilsForLua:call("setSpriteMaxSize", mSprite, 150, true)
	else
		mSprite:setVisible(false)
		local pic = GlobalData:call("shared"):getProperty("playerInfo"):getProperty("pic")
    	local picVer = GlobalData:call("shared"):getProperty("playerInfo"):getProperty("picVer")
    	local uid = GlobalData:call("shared"):getProperty("playerInfo"):getProperty("uid")

    	local picSpr = CCLoadSprite:call("createSprite", pic, CCLoadSpriteType.CCLoadSpriteType_HEAD_ICON)
		CCCommonUtilsForLua:setSpriteMaxSize(picSpr, 60, false)
		headNode:removeAllChildren()
	    headNode:addChild(picSpr)

	    if CCCommonUtilsForLua:call("isUseCustomPic", picVer) then
	        self.m_headImgNode = HFHeadImgNode:call("create")
	        self.m_headImgNode:call("initHeadImgUrl2", headNode, CCCommonUtilsForLua:call("getCustomPicUrl", uid, picVer), 1.0, 80, true)
	    end
	end
	
	--【Awen】设置叠加图标
	if CCCommonUtilsForLua:isFunOpenByKey("shop_combine_icon") and _nodeOn then
		_nodeOn:removeAllChildren()
		local as = AvatarController:getInstance().avatarShopConfig
		local sellItemInfo = as and as[self:getItemId(dataIndex)]
		if sellItemInfo and sellItemInfo.combine_icon then
			Dprint("AvatarCell:setCellData", sellItemInfo.combine_icon)
			local _data = string.split(sellItemInfo.combine_icon, ',')
			if _data then
				local _iconName = _data[1]..'.png'
				if CCLoadSprite:call("getSF", _iconName) then
					local _iconSpr = CCLoadSprite:call("createSprite", _iconName)
					_iconSpr:setPosition(cc.p(atoi(_data[2]), atoi(_data[3])))
					_iconSpr:setScale(tonumber(_data[4]) or 0)
					_nodeOn:addChild(_iconSpr)
				end
			end
		end
	end	

	self:refreshUnSeenTag(cellIndex, dataIndex)
end

function AvatarCell:getGoodsIcon(itemId)
	local iconStr = ""
	if itemId then 
	    iconStr = CCCommonUtilsForLua:getPropByIdGroup("goods", tostring(itemId), "icon")..".png"
	end
	return iconStr
end

function AvatarCell:refreshUnSeenTag(cellIndex, dataIndex)
	local remindSprite = nil
	if cellIndex == cell_index_1 then
		remindSprite=self.m_remindSprite1
	elseif cellIndex == cell_index_2 then
		remindSprite=self.m_remindSprite2
	elseif cellIndex == cell_index_3 then
		remindSprite=self.m_remindSprite3
	else
		dump("error+++1608")
		return
	end
	remindSprite:setVisible(false)
	if AvatarType_Diamond == self:getAvatarType() then
		local ctl = AvatarController:getInstance()
		local unSeen = ctl:getUnSeenItemInStore(self:getAvatarType())
		remindSprite:setVisible((unSeen and #unSeen > 0) and not ctl:hasSeenItemInStore(self:getItemId(dataIndex)))
		-- self.m_remindSprite1:setVisible(not ctl:hasSeenItemInStore(self:getItemId()))
	end
end

function AvatarCell:isStore(  )
	return self.father.page == PAGE_STORE
end

function AvatarCell:isActive( dataIndex )
	if self:isStore() then
		return dataIndex == self.father.m_activeStoreIndexTable[self.father.m_activeStoreTag]
	end
	return dataIndex == self.father.m_activeWardrobeIndexTable[self.father.m_activeWardrobeTag]
end

function AvatarCell:onEnter(  )
	local function onCellTouched( ref )
		-- self.m_selectedSpr1:setVisible(self.touchCellIndex == cell_index_1)
		-- self.m_selectedSpr2:setVisible(self.touchCellIndex == cell_index_2)
		-- self.m_selectedSpr3:setVisible(self.touchCellIndex == cell_index_3)
		-- local index = ref:getValue()
		-- if self.index == index then
		-- 	self.m_selectedSpr:setVisible(true)
		-- else
		-- 	self.m_selectedSpr:setVisible(false)
		-- end
	end
	local handler1 = self:registerHandler(onCellTouched)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "MSG_AVATARCELL_TOUCHED")

	local function onGetToolChange( ref )
		-- self:setData(self.dataIndex1,self.dataIndex2,self.dataIndex3)
	end
	local handler2 = self:registerHandler(onGetToolChange)
	CCSafeNotificationCenter:registerScriptObserver(self, handler2, "msg.tool.change")

	self:onEnterFrame()
	self.entry = self:getScheduler():scheduleScriptFunc(function (  )
        self:onEnterFrame()
    	end, 1.0, false)
end

function AvatarCell:onExit(  )
	dump("AvatarCell:onExit+++")
	self:getScheduler():unscheduleScriptEntry(self.entry)
	CCSafeNotificationCenter:unregisterScriptObserver(self, "MSG_AVATARCELL_TOUCHED")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "msg.tool.change")
end

function AvatarCell:onTouchBegan( x, y )
	if avatar_view_ins and not avatar_view_ins:getParent(  ):isVisible(   ) then
		return
	end
	self.touchDataIndex = nil
	self.touchCellIndex = nil
	self.startTouchPt = cc.p(x, y)
	if isTouchInside(self.boundNode, x, y) == false then
		Dprint("AvatarCell:onTouchBegan not in boundNode")
		return false
	end
	if  not isTouchInside(self.m_selectedSprBg1, x, y) and
		not isTouchInside(self.m_selectedSprBg2, x, y) and
		not isTouchInside(self.m_selectedSprBg3, x, y) then
		Dprint("AvatarCell:onTouchBegan not in m_mainNode")
		return false
	end

	local dataIndex = nil
	local cellIndex = nil
	if self.dataIndex1 and isTouchInside(self.m_selectedSprBg1, x, y) then 
		dataIndex = self.dataIndex1
		cellIndex = cell_index_1
	elseif self.dataIndex2 and isTouchInside(self.m_selectedSprBg2, x, y) then 
		dataIndex = self.dataIndex2
		cellIndex = cell_index_2
	elseif self.dataIndex3 and isTouchInside(self.m_selectedSprBg3, x, y) then 
		dataIndex = self.dataIndex3
		cellIndex = cell_index_3
	else 
		dump("AvatarCell:onTouchBegan error not in any node+++1691")
		return false
	end
	if self:isActive(dataIndex) then
		Dprint("self active")
		local ainfo = self:getAInfo(dataIndex)
		if not ainfo then 
			dump("AvatarCell:onTouchBegan no ainfo+++")
			return false
		end
		if AvatarType_Item ~= ainfo:call("getAvatarType")  and self.m_tipsNode and self.m_tipsNode:isVisible() then
			dump("AvatarCell:onTouchBegan no AvatarType_Item+++")
			 return false
		end
	end
	self.touchDataIndex = dataIndex
	self.touchCellIndex = cellIndex
	return true
end

function AvatarCell:onTouchEnded( x, y )
	dump("AvatarCell:onTouchEnded+++"..x..","..y)
	local dis = 10
	if (CCCommonUtilsForLua:call("isIosAndroidPad")) then
		dis = 20
	end
	if (cc.pGetDistance(self.startTouchPt, cc.p(x, y)) > dis) then
		return
	end
	if not self.touchDataIndex or not self.touchCellIndex then
		dump("error1723+++")
		return
	end
	local itemId = self:getItemId(self.touchDataIndex)
	dump(itemId,"AvatarCell:onTouchEnded itemId+++")
	AvatarController:getInstance():markAsSeen(itemId)

	local remindSprite = nil
	if self.touchCellIndex == cell_index_1 then
		remindSprite = self.m_remindSprite1
	elseif self.touchCellIndex == cell_index_2 then
		remindSprite = self.m_remindSprite2
	
	elseif self.touchCellIndex == cell_index_3 then
		remindSprite = self.m_remindSprite3
	else
		dump("error1737+++")
		return
	end
	remindSprite:setVisible(false)

	Dprint("AvatarCell:onTouchEnded self.touchDataIndex+++ "..self.touchDataIndex, self:isStore())
	self.father:onCellTouched(self.touchDataIndex)
	CCSafeNotificationCenter:call("postNotification", "MSG_AVATARCELL_TOUCHED", CCInteger:create(self.touchDataIndex))
end

function AvatarCell:showBottomNode( bShow )
	dump(bShow,"AvatarCell:showBottomNode+++")
	local pos_y = 0
	if bShow and self.father.touchIndex then 
		self.father:checkTouchIndex(self.father.touchIndex)
		if self.father.touchIndex then 
			pos_y = 300
		else
			dump("error, show but no touchIndex+++1963")
			bShow = false
		end
	end
	self.m_Node1:setPositionY(pos_y)
	self.m_Node2:setPositionY(pos_y)
	self.m_Node3:setPositionY(pos_y)
	self.m_tipsNode:setVisible(bShow)
	if not bShow then 
		self.m_selectNode1:setVisible(false)
		self.m_selectNode2:setVisible(false)
		self.m_selectNode3:setVisible(false)
	else
		self:updateBottomView(self.father.touchIndex)
	end
end

function AvatarCell:updateBottomView( dataIndex )
	-- dump("AvatarCell:updateBottomView+++")
	self.m_btnFumoUse:setEnabled(true)
	self.m_buyButton1:setVisible(false)
	self.m_useButton1:setVisible(false)
	self.m_buyButton2:setVisible(false)
	self.m_useButton2:setVisible(false)
	self.m_checkButton:setVisible(false)
	self.m_nodeFumoBtns:setVisible(false)
	if CCCommonUtilsForLua:isFunOpenByKey("skin_mall") and self.father.page == PAGE_WARDROBE then
		self.m_desLabel:setVisible(false)
		self.m_labelDes:setVisible(true)
	else
		self.m_desLabel:setVisible(true)
	end
	self.m_selectNode1:setVisible(self.dataIndex1 == dataIndex)
	self.m_selectNode2:setVisible(self.dataIndex2 == dataIndex)
	self.m_selectNode3:setVisible(self.dataIndex3 == dataIndex)
	if not dataIndex then 
		return 
	end
	local ainfo = self:getAInfo(dataIndex)
	dump(ainfo, "AvatarCell:updateBottomView ainfo+++")
    self.father.ui.m_noLabel:setString("")
    CCCommonUtilsForLua:setButtonTitle(self.m_buyButton1, getLang("164253"))
    CCCommonUtilsForLua:setButtonTitle(self.m_useButton1, getLang("162022"))
    CCCommonUtilsForLua:setButtonTitle(self.m_buyButton2, getLang("164253"))
    CCCommonUtilsForLua:setButtonTitle(self.m_useButton2, _lang("162022"))
    CCCommonUtilsForLua:setButtonTitle(self.m_checkButton, _lang('164006'))
    CCCommonUtilsForLua:setButtonTitle(self.m_btnFumo, getLang("9200684")) --9200684=附魔
    CCCommonUtilsForLua:setButtonTitle(self.m_btnFumoUse, getLang("162022")) 

	local itemId = self:getItemId(self.father.touchIndex)
	dump(itemId, "AvatarCell:updateBottomView itemId+++")
	if not itemId then 
		dump(itemId, "error, AvatarCell:updateBottomView itemId+++")
		return
	end
	
	local toolName = getLang(CCCommonUtilsForLua:getPropById(tostring(itemId), "name"))
	local skin = CCCommonUtilsForLua:call("getPropById", tostring(itemId), "skin")
	if skin then
		toolName = getLang(skin)
	end
	local toolDes = getLang(CCCommonUtilsForLua:getPropById(tostring(itemId), "description"))
	if ainfo and AvatarType_Item == ainfo:call("getAvatarType") then --AvatarType_Item，奖励的盒子
    	local hasItem = AvatarController.getInstance():isAlreadyHave(itemId)
    	self.m_useButton2:setVisible(hasItem)
    	self.m_buyButton2:setVisible(not hasItem)
    	self.m_checkButton:setVisible(true)
    else
		if self.father.page == PAGE_STORE then
			-- 162013=购买
			if itemId < 200 then
				-- 101474=经典
				-- 101475=开启后，主城场景中和世界场景中的城堡外形改变为经典外形
				toolName = getLang("101474")
				toolDes = getLang("101475")
			else
				local sellItemInfo = AvatarController:getInstance().avatarShopConfig[itemId]
				if sellItemInfo then
					self.m_buyButton1:setVisible(true)
				end
			end
		else
			-- 162022=使用
			if #self.father.m_wardrobeTags == 0 then
				-- 衣柜里没有皮肤
				self.father.ui.m_noLabel:setString(getLang("137941"))
				self.father.ui.m_noLabel:setVisible(true)
			else
				local t = self.father.m_wardrobeData[self.father.m_activeWardrobeTag]
				if #t == 0 then
					-- 衣柜里没有皮肤
					self.father.ui.m_noLabel:setString(getLang("137941"))
					self.father.ui.m_noLabel:setVisible(true)
				else
					if not self.father.m_activeWardrobeTag 
						or not self.father.m_activeWardrobeIndexTable[self.father.m_activeWardrobeTag] then 
						return
					end
					local data = self.father.m_wardrobeData[self.father.m_activeWardrobeTag][self.father.m_activeWardrobeIndexTable[self.father.m_activeWardrobeTag]]
					if CCCommonUtilsForLua:isFunOpenByKey("skin_mall") then
						if data.mark == 0 then
							self.m_labelLike:setString(getLang("350171"))	--350171=设为偏好
						else
							self.m_labelLike:setString(getLang("350199"))	--350199=取消偏好
						end
					end
					
					if data and data.isInBag then
						self.m_useButton1:setEnabled(true)
						self.m_useButton1:setVisible(true)
					else
						if ainfo then
							local actItemId = AvatarController:call("getActiveItemByType", ainfo:call("getAvatarType"))
							-- 判断是否是激活的
							local isActiveItem = actItemId==itemId
							if isActiveItem then
								self.m_useButton1:setVisible(true)
								self.m_useButton1:setEnabled(false)
							else
								self.m_useButton1:setVisible(true)
								self.m_useButton1:setEnabled(true)
							end
							local isSkinCanFuMo = FuMoController:isSkinCanFuMo(tostring(itemId))
							local isYongJiuSkin = data and data:isYongjiuStatus()
							--对于拥有基础属性的外显，增加属性展示
							local hasBaseBuff = AvatarBuffController:getBufListById(itemId)
							-- Dprint("isYongJiuSkin+++", isSkinCanFuMo, isYongJiuSkin)
							if isSkinCanFuMo and isYongJiuSkin then 
								self.currentGoodsId = tostring(itemId)
								self.m_nodeFumoBtns:setVisible(true)
								self.m_useButton1:setVisible(false)
								self.m_desLabel:setVisible(false)
								self.m_labelDes:setVisible(false)
								local curSkinLv = FuMoController:getSkinLv(tostring(itemId))
								self:updateBufs(tostring(itemId), curSkinLv)
								self.m_btnFumoUse:setEnabled(not isActiveItem)
							elseif isYongJiuSkin and next(hasBaseBuff) then
								self.m_desLabel:setVisible(false)
								self.m_labelDes:setVisible(false)
								self.m_nodeFumoBtns:setVisible(true)
								self:updateBufs(tostring(itemId), 0)					
								self.m_btnFumo:setVisible(false)
								self.m_btnFumoUse:setVisible(false)								
							end
						else
							-- 101474=经典
							toolName = getLang("101474")
							toolDes = getLang("101474")
							local actItemId = AvatarController:call("getActiveItemByType", itemId)
							Dprint("werewr", actItemId, itemId)
							if actItemId > 200 then
								self.m_useButton1:setEnabled(true)
								self.m_useButton1:setVisible(true)
							else
								self.m_useButton1:setEnabled(false)
								self.m_useButton1:setVisible(true)
							end
						end
					end
				end
			end
		end
	end
	
	self.m_titleLabel:setString(toolName)
	self.m_desLabel:setString(toolDes)
	if CCCommonUtilsForLua:isFunOpenByKey("skin_mall") then
		self.m_labelDes:setString(toolDes)
	end
end

function AvatarCell:updateBufs( goodsId, curSkinLv )
	Dprint("AvatarCell:updateBufs", goodsId, curSkinLv)
	if self.scrollView == nil then
		local scrollView = cc.ScrollView:create()
	    scrollView:setViewSize(self.m_nodeFuMoBufList:getContentSize())
	    scrollView:setPosition(cc.p(0,0))
	    scrollView:setScale(1.0)
	    scrollView:ignoreAnchorPointForPosition(true)
	    scrollView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
	    self.m_nodeFuMoBufList:addChild(scrollView)
	    self.scrollView = scrollView
	end

	self.scrollView:getContainer():removeAllChildren()
	local cH = self.m_nodeFuMoBufList:getContentSize().height
    local height = 0
    local mainNode = cc.Node:create()

	--城堡自身属性
	if CCCommonUtilsForLua:isFunOpenByKey("dress_effect") then		
		local baseBuff = AvatarBuffController:getBufListById(goodsId)
		
		local content = getLang("176872") --176872=拥有属性（拥有即生效，无需穿戴使用）
		local cell = FuMoBuffInfoCell:create3( content, cc.c3b(236,220,170))
		mainNode:addChild(cell)
		height = height + 30
		cell:setPosition(cc.p(0, 0 - height))

		local index = 1
		for k,v in pairs(baseBuff or {}) do
			local content = getLang(v.dialogId,tostring(v.effValue))
			local cell = FuMoBuffInfoCell:create3(content, cc.c3b(132,233,170))
			mainNode:addChild(cell)
			height = height + 30
			if sizen(baseBuff) == 1 then
				height = height + 30
			end
			cell:setPosition(cc.p(0, 0 - height))
		end

		-- 当前无总加成 9200696=附魔 无
		if #baseBuff == 0 then
			local cell = FuMoBuffInfoCell:create3(getLang("108714"), cc.c3b(132,233,170))	
			mainNode:addChild(cell)
			height = height + 50
			cell:setPosition(cc.p(0, 0 - height))
		end
	else
		--附魔属性
		-- 当前总加成
		local curTotalBuff = FuMoController:getCurTotalBuff(goodsId, tostring(curSkinLv))
		local index = 1
		for k,v in pairs(curTotalBuff) do
			local title = nil
			if index == 1 then
				-- title = getLang('9200294') -- 9200294=当前总加成：
				title = getLang('9200695',tostring(curSkinLv)) --9200695=附魔 Lv{0}
				index = index + 1
			end

			local content = getLang(v.id, v.value)
			local cell = FuMoBuffInfoCell:create(title, content, cc.c3b(132,233,170))

			mainNode:addChild(cell)
			height = height + 30
			if sizen(curTotalBuff) == 1 then
				height = height + 30
			end
			cell:setPosition(cc.p(0, 0 - height))
		end

		-- 当前无总加成 9200696=附魔 无
		if index == 1 then
			local cell = FuMoBuffInfoCell:create(getLang('9200696'), "", cc.c3b(132,233,170))	
			mainNode:addChild(cell)
			height = height + 50
			cell:setPosition(cc.p(0, 0 - height))
		end
	end
    

    self.scrollView:addChild(mainNode)
    mainNode:setPosition(cc.p(0, height))
    self.scrollView:setContentSize(CCSize(self.m_nodeFuMoBufList:getContentSize().width,height))
    self.scrollView:setContentOffset(CCPoint(0, cH - height))
end

function AvatarCell:doUpdate( cellIndex, dataIndex )
	if not dataIndex or not cellIndex then 
		-- dump(dataIndex,"tip,dataIndex2127+++")
		-- dump(cellIndex,"tip,cellIndex1787+++")
		return
	end

	local leftLabel = nil
	if cellIndex == cell_index_1 then
		leftLabel = self.m_leftLabel1
	elseif cellIndex == cell_index_2 then
		leftLabel = self.m_leftLabel2
	
	elseif cellIndex == cell_index_3 then
		leftLabel = self.m_leftLabel3
	else
		dump("error,wrong cellIndex 1800+++")
		return
	end

	local data = self:getData(dataIndex)
	if not data or data.isInBag then
		return
	end
	if data:isYongjiuStatus() then
		-- 101502=永久
		-- self.m_leftLabel1:setString(getLang("101502"))
		return
	end
	local now = GlobalData:call("getWorldTime")
	local left = data.endTime - now
	left = math.max(0, left)
	leftLabel:setString(format_time(left))
end

function AvatarCell:onEnterFrame(  )
	if self:isStore() then
		return
	end
	self:doUpdate(cell_index_1, self.dataIndex1)
	self:doUpdate(cell_index_2, self.dataIndex2)
	self:doUpdate(cell_index_3, self.dataIndex3)
end

------------------------------------------------------------------------------------------------------------------------------------
--[[ 标签列表单元格 ]]
function AvatarTagCell:ctor( atype, father)
	self.atype = atype
	self.father = father

	local proxy = cc.CCBProxy:create()
	local ccbiUrl = "AvatarBtnCellEx.ccbi"
	if CCCommonUtilsForLua:isFunOpenByKey("skin_mall") and self.father.page == PAGE_STORE then
		ccbiUrl = "AvatarBtnStoreCell.ccbi"
	end
	local node = CCBReaderLoad(ccbiUrl, proxy, self)
    if nil == node then
        return false
    end
    self:addChild(node)

	self:setData(atype)

	self.touchLayer = cc.Layer:create()
	self:addChild(self.touchLayer)
	self.startTouchPt = cc.p(0, 0)
	local function touchHandle( eventType, x, y)
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		else
			self:onTouchEnded(x, y)
		end
	end
	self.touchLayer:registerScriptTouchHandler(touchHandle)
	self.touchLayer:setTouchEnabled(true)
	self.touchLayer:setSwallowsTouches(false)

	local function onNodeEvent( event )
		if event == "enter" then
			self:onEnter()
	    elseif event == "exit" then
	    	self:onExit()
	    end
	end
	self:registerScriptHandler(onNodeEvent)
end

function AvatarTagCell:setData( atype )
	self.atype = atype
	self:setBActive(self:isActive())
end

function AvatarTagCell:setBActive( b )
	self.m_light:setVisible(b)
	CCCommonUtilsForLua:call("setSpriteGray", self.m_spr, not b)
	local atype = self.atype
	local img = self.father.tagsPic[atype]
	if img and img.icon ~= "" then 
		-- dump(img.icon,"AvatarTagCell:setBActive+++")
		if img.dialog and img.dialog ~= "" then
			self.m_tLabel:setString(getLang(img.dialog))
		else
			self.m_tLabel:setString("")
		end
		local frame = CCLoadSprite:call("getSF", img.icon)
        if frame then
            -- dump("pic ok+++")
			self.m_spr:setDisplayFrame(frame)
        else
            dump(img.icon, "error: all store cell icon not found+++")
        end
        if self.atype == AvatarType_Diamond or self.atype == AvatarType_Coin then
        	CCCommonUtilsForLua:call("setSpriteMaxSize", self.m_spr, 68, true)
        end
	end
end

function AvatarTagCell:isActive(  )
	local activeAType = 0
	if self.father.page == PAGE_STORE then
		activeAType = self.father.m_activeStoreTag
	else
		activeAType = self.father.m_activeWardrobeTag
	end
	return self.atype == activeAType
end

function AvatarTagCell:onEnter(  )
	local function onTagCellTouched( ref )
		local id = ref:getValue()
		self:setBActive(id == self.atype)
	end
	local handler1 = self:registerHandler(onTagCellTouched)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "MSG_AVATARTAGCELL_TOUCHED")

	local function onSeeItem ()
		if AvatarType_Diamond ~= self.atype then
			return
		end
		local unSeen = AvatarController:getInstance():getUnSeenItemInStore(self.atype)
		dump(unSeen, 'onSeeItem')
		self.m_remindSprite:setVisible(unSeen and true or false)
	end
	local handlerOnSeeItem = self:registerHandler(onSeeItem)
	CCSafeNotificationCenter:registerScriptObserver(self, handlerOnSeeItem, "MSG_AVATARCELL_TOUCHED")

	self.m_remindSprite:setVisible(false)
	onSeeItem()
end

function AvatarTagCell:onExit(  )
	CCSafeNotificationCenter:unregisterScriptObserver(self, "MSG_AVATARTAGCELL_TOUCHED")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "MSG_AVATARCELL_TOUCHED")
end

function AvatarTagCell:onTouchBegan( x, y )
	if avatar_view_ins and not avatar_view_ins:getParent(  ):isVisible(   ) then
		return
	end
	self.startTouchPt = cc.p(x, y)
	if isTouchInside(self.m_bg, x, y) == false then
		return false
	end

	if self:isActive() then
		return false
	end
	return true
end

function AvatarTagCell:onTouchEnded( x, y )
	Dprint("AvatarTagCell:onTouchEnded")
	local dis = 10
	if (CCCommonUtilsForLua:call("isIosAndroidPad")) then
		dis = 20
	end
	if (cc.pGetDistance(self.startTouchPt, cc.p(x, y)) > dis) then
		return
	end
	if isTouchInside(self.m_bg, x, y) == false then
		return
	end

	local newAType = self.atype
	local activeIndex = nil
	self.father.touchIndex = nil
	if self.father.page == PAGE_STORE then
		if self.father.m_activeStoreIndexTable then
			activeIndex = self.father.m_activeStoreIndexTable[newAType]
			if activeIndex then 
				if not self.father.m_storeData[newAType] or not self.father.m_storeData[newAType][activeIndex] then
					-- self.father.touchIndex = nil
					dump(index,"error, no store item index found2294+++")
				else
					self.father.touchIndex = activeIndex --设置之前点击的cell
				end
			end
		end
	else
		if self.father.m_activeWardrobeIndexTable then
			activeIndex = self.father.m_activeWardrobeIndexTable[newAType]
			if activeIndex then
				if not self.father.m_wardrobeData[newAType] or not self.father.m_wardrobeData[newAType][activeIndex] then
					-- self.father.touchIndex = nil
					dump(index,"error, no wardrobe item index found2306+++")
				else
					self.father.touchIndex = activeIndex 
				end
			end
		end
	end

	local tv = self.father.m_tableView1
	self.father.m_preve_px = tv:getContentOffset().x
	self.father.touchedAvatarType = self.father.touchedAvatarType or newAType
	CCSafeNotificationCenter:call("postNotification", "MSG_AVATARTAGCELL_TOUCHED", CCInteger:create(newAType))
end

return AvatarViewEx
