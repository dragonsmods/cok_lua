--[[ 
    皮肤羁绊-单元格
    2019.4.25   Awen
 ]]
local AvatarFetterCell = class("AvatarFetterCell", function() return cc.Layer:create() end)
local CELL_COUNT = 2

function AvatarFetterCell:create()
    local cell = AvatarFetterCell.new()
    Drequire("game.avatar.AvatarFetterCell_ui"):create(cell, 0)
    cell:initView()
    return cell
end

function AvatarFetterCell:initView()
    registerTouchHandler(self)
    self:setTouchEnabled(true)
    -- self:setSwallowsTouches(false)
    for i = 1, CELL_COUNT do
        local node = self.ui['m_nodeItem'..i]
        if node then
            node:setUseTouchScale(true)
        end
    end
end

function AvatarFetterCell:onEnter()
    self:setSwallowsTouches(false)
end

function AvatarFetterCell:refreshCell(data, idx)
    self.v_data = data
    for i=1,CELL_COUNT do
        if data[i] then
            self.ui['m_nodeItem'..i]:setVisible(true)
            -- 名称
            self.ui['m_labelTitle'..i]:setString(getLang(data[i].name))
            -- 进度
            self.ui['m_labelProcess'..i]:setString(data[i].process)
            -- 图标
            if data[i].icon then
                local _icon = CCLoadSprite:createSprite(data[i].icon..'.png')
                if _icon then
                    self.ui['m_nodeIcon'..i]:addChild(_icon)
                end
            end
        else
            self.ui['m_nodeItem'..i]:setVisible(false)
        end
    end
end

function AvatarFetterCell:onTouchBegan( x, y )
    for i=1,CELL_COUNT do
        local node = self.ui['m_bg'..i]
        if isTouchInsideVis(node, x, y) then
            local item = self.ui['m_nodeItem'..i]
            if item then
                item:setTouchScaled(true)
            end
            return true
        end
    end
    return false
end

function AvatarFetterCell:onTouchEnded( x, y )
    for i=1,CELL_COUNT do
        local node = self.ui['m_nodeItem'..i]
        node:setTouchScaled(false)
        if isTouchInsideVis(self.ui['m_bg'..i], x, y) then
            -- local view = Drequire("game.avatar.AvatarFetterGroupView").create(self.v_data[i].id)
            -- PopupViewController:addPopupInView(view)
            XEvtTimer:post("AvatarFetterView:openAGroup", {
                id = self.v_data[i].id
            })
            break
        end
    end
end

return AvatarFetterCell