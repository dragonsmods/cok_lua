local AvatarFaceShowView = class("AvatarFaceShowView", function()
	return cc.Layer:create()
end)

-- nameAndMd5 用于处理出错的md5下载资源导致不刷新机制处理，默认为最后一个参数 ，格式为："trueMd5;DeathGod_gaoji_face;d7dbfa0d0120d4fc0ed1fb2191b3552c;775f772916fb945e4e464092db48c6f6"
function AvatarFaceShowView:ctor(configName, allParam, nameAndMd5)
	self:setConfig(configName, allParam, nameAndMd5)
	self:setAnchorPoint(cc.p(0, 0))
	registerNodeEventHandler(self)
	return self
end

function AvatarFaceShowView:resetFace(configName, allParam, nameAndMd5)
	self:stopAllActions()
	self:setPosition(self.m_origin_pos)
	if self.m_entryId then
		self:getScheduler():unscheduleScriptEntry(self.m_entryId)
		self.m_entryId = nil
	end
	self:setConfig(configName, allParam, nameAndMd5)
	self:onEnter()
end

function AvatarFaceShowView:setItemId(id)
	self.itemId = id
end

function AvatarFaceShowView:setConfig(configName, allParam, nameAndMd5)
	self.m_configName = configName
	self.allParam = allParam
	if nameAndMd5 then
		local tbl = string.split(nameAndMd5, ";")
		if #tbl == 4 and tbl[1] == "trueMd5" then
			self.faceName = tbl[2]
			if (isAndroid()) then
				self.faceMd5 = tbl[4]
			else
				self.faceMd5 = tbl[3]
			end
			DynamicResourceController2:call("initAvatarResource", self.faceName, self.faceMd5)
		end
	else
		self.faceName = nil
	end
	self.rootPath = CCFileUtils:sharedFileUtils():getWritablePath().."dresource/"
end

function AvatarFaceShowView:getAvatarConfigData()
	local lower_name = string.lower(self.m_configName)
	if string.find(lower_name,"headframe_") then
		self:createFace()
		self:stopTimeUpdate()
		return true
	end

	local configFilePath = self.rootPath.."skinparticle/"..self.m_configName..".config"
	local configDataFile = io.open(configFilePath, "r")
	local config = {}
	if configDataFile then
		local configLineContent = configDataFile:read()
		while(configLineContent) do
			local tbl = string.split(configLineContent, "=")
			config[tbl[1]] = tbl[2]
			configLineContent = configDataFile:read()
		end
	    io.close(configDataFile)
	end
	self.m_configData = config
	if table_is_empty(config) then
		return false
	else
		self:createFace()
		self:stopTimeUpdate()
		return true
	end
end

function AvatarFaceShowView:getAnimationObj()
	return self.animationObj
end

function AvatarFaceShowView:getIsNameplateFunc()
	return self.isNameplate
end



function AvatarFaceShowView:createFace()
-- parcnt=2
-- par1=icedragon_0,150,50,1,0
-- par2=icedragon_1,100,60,1,0
-- skeletoncnt=1
-- skeleton1=face_iceDragon_wai,sk_face_iceDragon_wai,dj,130,60,1
-- isMonster=1
-- hideNative=1
	self.m_origin_pos = cc.p(self:getPosition())
	self:removeAllChildren()
	local config = self.m_configData
	local mainPos = {0, 0}
	local cfgName = string.lower(self.m_configName)

	local from = string.find(cfgName, "nameplate_") --铭牌
	self.isNameplate = from == 1
	if from == 1 and not config.skeletoncnt then
		-- dump(from ,"is nameplate+++"..cfgName)
		self:createNameplate()
		return
	end

	from = string.find(cfgName, "headframe_") --头像框
	if from == 1 then 
		local headFrame = utils.getExtendClass("headFrame"):create(self.itemId)
		-- local modelSize = self:getContentSize()
		-- headFrame:setPosition(cc.p(modelSize.width/2 - 380, modelSize.height/2 - 430))
		headFrame:setPosition(cc.p(-50,120))
		headFrame:setScaleY(1.4)
		headFrame:setScaleX(1.4)
		self:addChild(headFrame)
		return
	end

	self.isMarch = false
	from = string.find(cfgName, "march_") --出征
	if from == 1 then
		-- dump(from ,"is march+++"..cfgName)
		self.isMarch = true
	end

	if config["is3dSkin"] == "1" then 
		self:create3dSkin()
	end

	local skeletoncnt = tonumber(config["skeletoncnt"]) or 0
	local max_sk_zorder = 0
	for i =1, skeletoncnt do
		local info = config["skeleton"..i]
		if info then
			local tbl = string.split(info, ",")
			if #tbl > 3 then
				local skin_file = self.rootPath .. tbl[2].. ".atlas" 
		        local skin_json = self.rootPath .. "/skinparticle/"..tbl[1]..".json"
		        if self.isMarch then 
					skin_file = self.rootPath .. tbl[1].. ".atlas" 
		        end
	            local animationObj = IFSkeletonAnimation:call("create", skin_json, skin_file)
	            if animationObj then
	            	-- dump("success to create animation+++")
	                self.animationObj = animationObj
					self:addChild(animationObj)
					local zOrder = config[string.format("sk_level_%d",i)]
					if zOrder then
						if tonumber(zOrder) > max_sk_zorder then
							max_sk_zorder = tonumber(zOrder)
						end
						animationObj:setLocalZOrder(tonumber(zOrder))
					end
	                -- tbl[3] = "gj"
	                if self.isMarch then
	                	-- dump("march is ok+++") 
	                	local time = self.allParam[7] or 10
						local xFrom = self.allParam[2] or 0
						local yFrom = self.allParam[3] or 0
						local xTo = self.allParam[5] or 100
						local yTo = self.allParam[6] or 100
						self.skinFile = skin_file
		        		self.skinJson = skin_json
						self.time = time	
						self.orgPos = {["x"]=xFrom,["y"]=yFrom}
						self.desPos = {["x"]=xTo,["y"]=yTo}
	                else
						animationObj:setAnimation(0, tbl[3], true)
						if self.isNameplate then
							animationObj:setPosition(cc.p(tonumber(tbl[4]),tonumber(tbl[5])))
						end
	                end
	                animationObj:setContentSize(cc.size(9999, 9999))
	            end
	            mainPos[1] = 0 - (tonumber(tbl[4]) or 0)
	            mainPos[2] = 0 - (tonumber(tbl[5]) or 0)
			end
		end
	end

	local parcnt = tonumber(config["parcnt"]) or 0
	for i = 1, parcnt do
		local info = config["par"..i]
		if info then
			local tbl = string.split(info, ",")
			-- 字段内容与其余皮肤保持一致
			-- ：粒子名称,坐标X,Y,是否在上面,是否在本地
			-- 是否在上面 暂时不需要
			local parPath = ""
			local particle = nil
			if tbl[5] == "1" then  		-- "1"在本地
				particle = ParticleController:call("createParticle", tbl[1])
			else
				local path =self.rootPath.. "skinparticle/" .. tbl[1]
				particle = ParticleController:call("createParticleForLua", path)
			end
			if particle then
				particle:setPosition(cc.p(mainPos[1] + tbl[2], mainPos[2] + tbl[3]))
				particle:setContentSize(cc.size(9999, 9999))
				self:addChild(particle,max_sk_zorder+1)
			end
		end
	end

	if self.isMarch then 
		self:startMarch()
	end
end

-- is3dSkin=1
-- skeletoncnt3d=1
-- skeleton3d1=bawanglong,_alpha_face_bawanglong3d,gongji,50,150,0.5,45,45,0
-- ske3dLight1=200,200,200,0,0,-1,200,0,0,128,0,0,0.5
-- hideNative=1
function AvatarFaceShowView:create3dSkin()
	local config = self.m_configData
	local skeletoncnt = tonumber(config["skeletoncnt3d"]) or 0
	for i =1, skeletoncnt do
		local info = config["skeleton3d"..i]
		if info then
			local tbl = string.split(info, ",")
			if #tbl > 8 then
				local model = IFSprite3D:call("create", tbl[1], tbl[2], tbl[3])
				if not model then 
					MyPrint("error, fail to create model+++",tbl[1], tbl[2], tbl[3])
					return
				end
			    model:call("autoTabDefaultAction", true)
			    model:setScale(tonumber(tbl[6]))
			    model:call("setRotation3D", cc.vec3( tonumber(tbl[7]), tonumber(tbl[8]), tonumber(tbl[9])))

			    local strLights = config["ske3dLight"..i]
				local tblLights = string.split(strLights, ",")
				if #tblLights > 12 then 
			    	local ambientLightColor = cc.c3b(tonumber(tblLights[1]),tonumber(tblLights[2]), tonumber(tblLights[3]))
                	local lightDirect = cc.vec3(tonumber(tblLights[4]),tonumber(tblLights[5]),tonumber(tblLights[6])) 	
                	local lightStartColor = cc.c3b(tonumber(tblLights[7]),tonumber(tblLights[8]),tonumber(tblLights[9]))
                	local lightEndColor = cc.c3b(tonumber(tblLights[10]),tonumber(tblLights[11]),tonumber(tblLights[12]))
                	local toEndLightTime = atoi(tonumber(tblLights[13]))
                	model:call("setLight", ambientLightColor, lightDirect, lightStartColor,lightEndColor, toEndLightTime)
			    end
    			self:addChild(model)
			end
		end
	end
end

function AvatarFaceShowView:createNameplate()
	local config = self.configData
	local spr = nil
    local path = self.rootPath ..self.m_configName..".plist"
    if cc.FileUtils:getInstance():isFileExist(path) then
        cc.SpriteFrameCache:getInstance():addSpriteFrames(path)
    else
    	return false
    end
    local iconName = self.m_configName..".png"
    local frame = CCLoadSprite:call("getSF", iconName)
    if frame ~= nil then 
        spr = CCLoadSprite:call("createSprite",iconName)
    else
        return false
    end
    self:addChild(spr)
    return true
end

function AvatarFaceShowView:startMarch()
	local function setDir( )
		-- dump(self.orgPos,"from setDir+++")
		-- dump(self.desPos,"to setDir+++")
		local dir = self:getAngle(self.orgPos.x, self.orgPos.y, self.desPos.x, self.desPos.y)
		self.animationObj:setAnimation(0, "walk_"..dir, true)

		local wpcnt = tonumber(self.m_configData["walkbonequadcnt"]) or 0
		for i = 1, wpcnt do
			local info = self.m_configData["walkbonequadcnt"..i]
			if info then
				local tbl = string.split(info, ",")
				if #tbl == 2 then
					local path =self.rootPath.. "skinparticle/" .. tbl[2]
					particle = ParticleController:call("createParticleForLua", path)
					if self.animationObj and particle then
						particle:setContentSize(cc.size(9999, 9999))
						self.animationObj:call("addBoneParticle", tbl[1], particle)
					end
				end
			end
		end
	end 
	local function callbackChangeDir( )
		-- dump("callbackChangeDir+++")
		if self.animationObj then 
			self.orgPos, self.desPos = self.desPos,self.orgPos
			setDir()
		end
	end
	local function callbackRecreateAni()
		-- dump("callbackRecreateAni+++")
		if self.animationObj then 
			self:removeChild(self.animationObj)
		end
		local animationObj = IFSkeletonAnimation:call("create", self.skinJson, self.skinFile)
        if animationObj then
            self:addChild(animationObj)
            self.animationObj = animationObj
            -- dump("march animation is ok+++")
        end
	end 

	setDir()
	local rt0 = cc.MoveTo:create(self.time, self.desPos)
	local rt1 = cc.MoveTo:create(self.time, self.orgPos)
	local cd = cc.CallFunc:create(callbackChangeDir)
	local rc = cc.CallFunc:create(callbackRecreateAni)
    local seq = cc.Sequence:create(rt0, rc, cd, rt1, rc, cd)
    self:runAction(cc.RepeatForever:create(seq))
end

function AvatarFaceShowView:getAngle( xFrom,yFrom,xTo,yTo )
	local angle = math.atan2(yTo-yFrom, xTo-xFrom)* 180 / math.pi 
	local direction = math.mod(angle+360, 360)
	-- dump("angle+++, "..angle..",direction:"..direction)
    local directionStr = 0;
    angle = 360 / 16;
    if((direction >= 360 - angle and direction <= 360) or (direction >= 0 and direction <= angle)) then
        directionStr = 4; -- 向东
    elseif(direction > angle and direction <= 90 - angle) then
        directionStr = 5; -- 向东北
    elseif(direction > 90 - angle and direction <= 90 + angle) then
        directionStr = 6; -- 向北
    elseif(direction > 90 + angle and direction <= 180 - angle) then
        directionStr = 7; -- 向西北
    elseif(direction > 180 - angle and direction <= 180 + angle) then
        directionStr = 0; -- 向西行军
    elseif(direction > 180 + angle and direction <= 270 - angle) then
        directionStr = 1; -- 向西南
    elseif(direction > 270 - angle and direction <= 270 + angle) then
        directionStr = 2; -- 向南
    elseif(direction > 270 + angle and direction <= 360 - angle) then
        directionStr = 3; -- 向东南
    end
    -- dump(directionStr,"directionStr+++")
    return directionStr; 
end

function AvatarFaceShowView:ondownloadAvatar(ref)
	-- MyPrint("AvatarFaceShowView:delayAvatar+++ ondownloadAvatar enter", ref)
	if not AvatarController:call("isDelayAvatarEnabled") then 
		return 
	end
	if ref then 
		local avatar_name = ref:getCString()
		local from = string.find(self.m_configName, avatar_name) 
		-- MyPrint("AvatarFaceShowView:delayAvatar+++ ondownloadAvatar", self.m_configName, avatar_name, from)
		if avatar_name == self.m_configName or from == 1 then
			-- MyPrint("AvatarFaceShowView:delayAvatar+++ ondownloadAvatar ok update")
    		unregisterScriptObserver(self, MSG_DYNAMIC_DOWNLOAD_FINISH)
			self:getAvatarConfigData(dt) 
		end
	end
end

function AvatarFaceShowView:downloadAvatar()
	-- MyPrint("AvatarFaceShowView:delayAvatar+++ m_configName", self.m_configName)
	if not AvatarController:call("isDelayAvatarEnabled") then 
		return 
	end
    unregisterScriptObserver(self, MSG_DYNAMIC_DOWNLOAD_FINISH)
    registerScriptObserver(self, self.ondownloadAvatar, MSG_DYNAMIC_DOWNLOAD_FINISH)
    if self.faceName == nil then
		local sid = AvatarController:getInstance():getStatusIdByCfgName(self.m_configName)
		if sid ~= 0 then 
			AvatarController:call("downloadAvatarById", sid)
		else
			DynamicResourceController2:call("initCombineSkinResFromXML", self.m_configName)
		end
	end
end

function AvatarFaceShowView:onEnter()
	if not self:getAvatarConfigData() then
		self:downloadAvatar()
		self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) 
			self:getAvatarConfigData(dt) 
			end, 3, false)
	end
end

function AvatarFaceShowView:onExit()
	self:stopTimeUpdate()
    unregisterScriptObserver(self, MSG_DYNAMIC_DOWNLOAD_FINISH)
end

function AvatarFaceShowView:stopTimeUpdate()
	if self.m_entryId then
		self:getScheduler():unscheduleScriptEntry(self.m_entryId)
		self.m_entryId = nil
	end
end

return AvatarFaceShowView