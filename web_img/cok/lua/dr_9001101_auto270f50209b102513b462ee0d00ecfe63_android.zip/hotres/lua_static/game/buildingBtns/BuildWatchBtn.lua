--瞭望塔
local BuildWatchBtn = class("BuildWatchBtn", Drequire("game.buildingBtns.BuildingAddBtn"))
function BuildWatchBtn:create(param)
    local btn = BuildWatchBtn.new(param)
    btn:initBtn()    
    return btn
end

function BuildWatchBtn:initBtn()
    self.buildKey = self.param:valueForKey("buildKey"):intValue()

    if isFunOpenByKey("functionopen") then
        if FunOpenController:isShow("fun_militaryInfo") then
            self:addBtn({
                icon = "icon_junshixiangqing.png",
                text = "102278",    --102278=军情
                callback = function ()
                    self:hideSelf()
                    local dict = CCDictionary:create()
                    dict:setObject(CCString:create("WatchtowerView"), "name")
                    LuaController:call("openPopViewInLua", dict)
                end
            })
        end
    end

    self:addExtensionBtn()
end

return BuildWatchBtn