--[[ 
    火器营
 ]]
local ArtilleryBtn = class("ArtilleryBtn", Drequire("game.buildingBtns.BuildingAddBtn"))

function ArtilleryBtn:create(param)
    local btn = ArtilleryBtn.new(param)
    btn:initBtn()    
    return btn
end
 
function ArtilleryBtn:initBtn()
    self.buildKey = self.param:valueForKey("buildKey"):intValue()
    if isFunOpenByKey("functionopen") and FunOpenController:isShow("fun_444000Produce") then 
        self:addBtn({
            icon = "artilleryProduce.png",
            text = "9490004", -- 9490004=生产
            callback = function()
                self:hideSelf()

                local view = Drequire("game.artillery.ArtilleryProduceView"):create(self.buildKey)
	            PopupViewController:addPopupInView(view) 
            end,
        })
    end
end

return ArtilleryBtn