--行军帐篷
local TroopsBtn = class("TroopsBtn", Drequire("game.buildingBtns.BuildingAddBtn"))
function TroopsBtn:create(param)
    local btn = TroopsBtn.new(param)
    btn:initBtn()    
    return btn
end

function TroopsBtn:initBtn()
    self.buildKey = self.param:valueForKey("buildKey"):intValue()
    self:addExtensionBtn()

end

return TroopsBtn