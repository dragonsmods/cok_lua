--[[ 
    贤者之塔
 ]]
local DragonTowerBtn = class("DragonTowerBtn", Drequire("game.buildingBtns.BuildingAddBtn"))

function DragonTowerBtn:create(param)
    local btn = DragonTowerBtn.new(param)
    btn:initBtn()    
    return btn
end
 
function DragonTowerBtn:initBtn()
    local buildKey = self.param:valueForKey("buildKey"):intValue()
    local buildType = tostring(math.floor(buildKey / 1000))
    if isFunOpenByKey("functionopen") and FunOpenController:isShow("fun_dragonTrials") then 
        self:addBtn({
            icon = "icon_dragonTower.png",
            text = "169103", -- 169103=龙塔试炼
            callback = function()
                self:hideSelf()

                CCCommonUtilsForLua.jumpToTarget( 7, "18" )
                CCSafeNotificationCenter:call("postNotification", GUIDE_INDEX_CHANGE, CCString:create(string.format("BU_%s_dt", buildType)))
                LogController:sendUserBehaviorEvent("building", 2, buildType, "dragonTower")
            end,
        })
    end
end

return DragonTowerBtn