--战争大厅
local BuildWarBtn = class("BuildWarBtn", Drequire("game.buildingBtns.BuildingAddBtn"))
function BuildWarBtn:create(param)
    local btn = BuildWarBtn.new(param)
    btn:initBtn()    
    return btn
end

function BuildWarBtn:initBtn()
    self.buildKey = self.param:valueForKey("buildKey"):intValue()
    self:addExtensionBtn()

end

return BuildWarBtn