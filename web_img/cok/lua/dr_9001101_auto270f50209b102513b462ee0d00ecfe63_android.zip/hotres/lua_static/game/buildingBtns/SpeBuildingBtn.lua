local SpeBuildingBtn = class("SpeBuildingBtn", cc.Node)

local BuildingBtnTag = 686868
local BuildingBtnLimit = 7
local BuildingBtnIcon = "bnt_02.png"

local fadeInTime = 0.27
local fadeOutTime = 0.16

-- 需要setTouchScaled(true)的类型
local UseScaleType = {
    [cc.CONTROL_EVENTTYPE_TOUCH_DOWN]  = 1,
--    [cc.CONTROL_EVENTTYPE_DRAG_INSIDE] = 2,
--    [cc.CONTROL_EVENTTYPE_DRAG_ENTER]  = 8,
}

local AllButtonEvent = {
    cc.CONTROL_EVENTTYPE_TOUCH_DOWN,
    cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE,
    cc.CONTROL_EVENTTYPE_TOUCH_UP_OUTSIDE,
    cc.CONTROL_EVENTTYPE_TOUCH_CANCEL,
}

-- 特殊建筑按钮基类
-- 此种建筑不涉及队列(除了文明圣殿,故暂不支持文明圣殿), 依次添加按钮就行了
-- 按钮添加请参考TavernBtn.lua
-- 任何问题联系suhongping@elex-tech.com

function SpeBuildingBtn:ctor(param)
    self.param = param
    self.btnNum = 0
    self.manager = require("game.buildingBtns.BuildingBtnManager").getInstance()
    self:initBase()
end

function SpeBuildingBtn:initBase()
    self:setTag(BuildingBtnTag)
    self.btnNode1 = cc.Node:create()
    self.btnNode2 = cc.Node:create()
    self.btnNode3 = cc.Node:create()
    self.btnNode4 = cc.Node:create()
    self.btnNode5 = cc.Node:create()
    self.btnNode6 = cc.Node:create()
    self.btnNode7 = cc.Node:create()

    self.btnNode1:setUseTouchScale(true)
    self.btnNode2:setUseTouchScale(true)
    self.btnNode3:setUseTouchScale(true)
    self.btnNode4:setUseTouchScale(true)
    self.btnNode5:setUseTouchScale(true)
    self.btnNode6:setUseTouchScale(true)
    self.btnNode7:setUseTouchScale(true)

    self:addChild(self.btnNode1)
    self:addChild(self.btnNode2)
    self:addChild(self.btnNode3)
    self:addChild(self.btnNode4)
    self:addChild(self.btnNode5)
    self:addChild(self.btnNode6)
    self:addChild(self.btnNode7)

    self.childTable = {}

    registerNodeEventHandler(self)
end

function SpeBuildingBtn:getBtnNum()
    return self.btnNum
end

function SpeBuildingBtn:addBtn(icon, text, callback, redpoint, iconSize)
    if not iconSize then
        iconSize = 90
    end
    if icon and text and callback then
        if self.btnNum < BuildingBtnLimit then
            self.btnNum = self.btnNum + 1

            local btn = CCControlButton:create(CCLoadSprite:call("createScale9Sprite", BuildingBtnIcon))
            btn:setPreferredSize(cc.size(100, 100))
            btn:setScale(0.8)
            self:addBtnEvent(btn, callback)
            btn:setTag(666)
            btn:setTouchPriority(4) 

            local bg = CCLoadSprite:createSprite(BuildingBtnIcon)
            local icon = CCLoadSprite:createSprite(icon)
            CCCommonUtilsForLua:setSpriteMaxSize(icon, iconSize, true)
    
            local txt = CCLabelIF:call("create1", getLang(text))
            txt:call("setColor", cc.c3b(254, 253, 212))
            txt:call("setFontSize", 20)
            txt:call("setAnchorPoint",ccp(0.5, 1))
            txt:call("setDimensions", cc.size(105, 75))
            txt:call("setHorizontalAlignment", cc.TEXT_ALIGNMENT_CENTER)
            txt:setPosition(cc.p(0, -35))
            if self["btnNode" .. self.btnNum] then
                self["btnNode" .. self.btnNum]:addChild(btn)
                self["btnNode" .. self.btnNum]:addChild(bg)
                self["btnNode" .. self.btnNum]:addChild(icon)
                self["btnNode" .. self.btnNum]:addChild(txt)
                if redpoint then
                    local _sprRedPoint = CCLoadSprite:createSprite("unlock_tipPt.png")
                    if _sprRedPoint then
                        _sprRedPoint:setPosition(btn:getContentSize().width / 2 - 15, btn:getContentSize().height / 2 - 15)
                        self["btnNode" .. self.btnNum]:addChild(_sprRedPoint)
                    end
                end
            end

            local node_child = {btn = btn, bg = bg, icon = icon, txt = txt}
            table.insert(self.childTable, self.btnNum, node_child)
        end
    end
end

function SpeBuildingBtn:addBtnEvent(btn, callback)
    local function realCallback(pSender, event)
        pSender:getParent():setTouchScaled(UseScaleType[event] ~= nil)

        if event ~= cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE then
            return
        end

        callback(pSender, event)
    end
    
    for _, eventType in ipairs(AllButtonEvent) do
        btn:addHandleOfControlEvent(realCallback, eventType)
    end
end

function SpeBuildingBtn:adapt()
    if self.btnNum == 1 then
        self.btnNode1:setPosition(0, -16)
    elseif self.btnNum == 2 then
        self.btnNode1:setPosition(-52, -10)
        self.btnNode2:setPosition(52, -10)
    elseif self.btnNum == 3 then
        self.btnNode1:setPosition(-107, 6)
        self.btnNode2:setPosition(0, -16)
        self.btnNode3:setPosition(107, 6)
    elseif self.btnNum == 4 then
        self.btnNode1:setPosition(-156, 30)
        self.btnNode2:setPosition(-52, -10)
        self.btnNode3:setPosition(52, -10)
        self.btnNode4:setPosition(156, 30)
    elseif self.btnNum == 5 then
        self.btnNode1:setPosition(-200, 60)
        self.btnNode2:setPosition(-107, 6)
        self.btnNode3:setPosition(0, -16)
        self.btnNode4:setPosition(107, 6)
        self.btnNode5:setPosition(200, 60)
    elseif self.btnNum == 6 then
        self.btnNode1:setPosition(-240, 110)
        self.btnNode2:setPosition(-156, 30)
        self.btnNode3:setPosition(-52, -10)
        self.btnNode4:setPosition(52, -10)
        self.btnNode5:setPosition(156, 30)
        self.btnNode6:setPosition(240, 110)
    elseif self.btnNum == 7 then
        self.btnNode1:setPosition(0, 100)
        self.btnNode2:setPosition(-150, 35)
        self.btnNode3:setPosition(-55, -6)
        self.btnNode4:setPosition(55, -6)
        self.btnNode5:setPosition(150, 35)
        self.btnNode6:setPosition(230, 95)
        self.btnNode7:setPosition(-230, 95)
    end
end

function SpeBuildingBtn:showAni(param)
    local intObj = tolua.cast(param, "CCInteger")
	if param and intObj then
		local aniType = intObj:getValue()
        for index = 1, self.btnNum do
            self:playAni(self["btnNode" .. index], aniType)
        end

        if aniType == 1 then
            self.manager:clearShowBtn()
        end
    end
end

function SpeBuildingBtn:hideSelf()
    self:setVisible(false)
    self.manager:clearShowBtn()

    local imscene = ImperialScene:call("getInstance")
	if imscene then
		imscene:call("hideBuildBtnView")
    end
end

function SpeBuildingBtn:playAni(node, aniType)
    if aniType == 0 then
        local fadeIn = cc.ScaleTo:create(fadeInTime, 1)
        local moveBy = cc.MoveBy:create(fadeInTime, ccp(0, -100))
        local spawn = cc.Spawn:create(fadeIn, moveBy)
        node:stopAllActions()
        node:setScale(0)
        node:runAction(spawn)
        node:setPositionY(node:getPositionY() + 100)
    else
        local fadeOut = cc.ScaleTo:create(fadeOutTime, 0)
        node:stopAllActions()
        node:setScale(1)
        node:runAction(fadeOut)
    end
end

function SpeBuildingBtn:onEnter()
    local function callback(param) self:showAni(param) end
    local handler = self:registerHandler(callback)
    CCSafeNotificationCenter:registerScriptObserver(self, handler, "msg_stop_questani")
end

function SpeBuildingBtn:onExit()
    CCSafeNotificationCenter:unregisterScriptObserver(self, "msg_stop_questani")
end

function SpeBuildingBtn:getBtn(index)
    if self["btnNode" .. index] then
        return self["btnNode" .. index]:getChildByTag(666)
    end
end

function SpeBuildingBtn:getGuideNodeByKey(key)
    dump("override me if necessary")
end

return SpeBuildingBtn