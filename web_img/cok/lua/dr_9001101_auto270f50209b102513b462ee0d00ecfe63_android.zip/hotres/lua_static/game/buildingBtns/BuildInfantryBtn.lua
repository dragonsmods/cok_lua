--步兵兵营
local BuildInfantryBtn = class("BuildInfantryBtn", Drequire("game.buildingBtns.BuildingAddBtn"))
function BuildInfantryBtn:create(param)
    local btn = BuildInfantryBtn.new(param)
    btn:initBtn()    
    return btn
end

function BuildInfantryBtn:initBtn()
    self.buildKey = self.param:valueForKey("buildKey"):intValue()
    self:addExtensionBtn()

end

return BuildInfantryBtn