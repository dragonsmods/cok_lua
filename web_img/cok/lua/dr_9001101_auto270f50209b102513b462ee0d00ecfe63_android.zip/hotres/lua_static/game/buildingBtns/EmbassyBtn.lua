--大使馆功能按钮(不包含升级与详情按钮)
local EmbassyBtn = class("EmbassyBtn", Drequire("game.buildingBtns.BuildingAddBtn"))
function EmbassyBtn:create(param)
    local btn = EmbassyBtn.new(param)
    btn:initBtn()    
    return btn
end

function EmbassyBtn:initBtn()
    self.buildKey = self.param:valueForKey("buildKey"):getCString()
    if self.buildKey == "" then
        self.buildKey = "402000"
    end
    self.nextCallHelpTime = 0
    
    if FunOpenController:isShow("fun_kingHall") then
        local callback1 = function()
            self:hideSelf()
    
            if CCCommonUtilsForLua:isFunOpenByKey("king_on") and WorldController:call("getInstance"):call("isOpenKingRihgts") and 
            GlobalData:call("shared"):getProperty("serverType") ~= ServerType.SERVER_DRAGON_BATTLE_GLOBAL and GlobalData:call("shared"):getProperty("serverType") ~= ServerType.SERVER_NATIONALWAR then
                if isFunOpenByKey("new_kingrights") and DynamicResourceController2:call("checkDynamicResource", "Kingrights_face") then
                    local view = Drequire('game.kingrights.KingRightsView').create()
                    PopupViewController:addPopupInView(view)
                elseif LuaController:call("checkValidActivityFromConfig", "kingrights") then
                    LuaController:call("showLuaViewByActivity", "kingrights")
                else
                    LuaController:flyHint("", "",getLang("E100091"))  --E100091=领主大人，资源下载中，请稍后尝试操作。
                end
            else
                local dict = CCDictionary:create()
                dict:setObject(CCString:create("AllianceHelpView"), "name")
                LuaController:call("openPopViewInLua", dict)
            end
        end
        if CCCommonUtilsForLua:isFunOpenByKey("king_on") and WorldController:call("getInstance"):call("isOpenKingRihgts") and 
        GlobalData:call("shared"):getProperty("serverType") ~= ServerType.SERVER_DRAGON_BATTLE_GLOBAL and GlobalData:call("shared"):getProperty("serverType") ~= ServerType.SERVER_NATIONALWAR then
            self:addBtn({
                icon = "ui_kingdom_icon.png",
                text = "146324",    --146324=国王大厅
                callback = callback1,
            }) 
        else
            self:addBtn({
                icon = "alliances_help.png",
                text = "108541",    --108541=帮助
                callback = callback1,
            })    
        end
    end

    if FunOpenController:isShow("fun_reinforcements") then
        local callback2 = function()  
            self:hideSelf()      
            local dict = CCDictionary:create()
            dict:setObject(CCString:create("YuanJunDetailView"), "name")
            LuaController:call("openPopViewInLua", dict)
        end
        self:addBtn({
            icon = "allianceYuanYun.png",
            text = "115151",    --115151=士兵援助
            callback = callback2,
        })
    end
    
    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
    if FunOpenController:isShow("fun_askHelp") and CCCommonUtilsForLua:isFunOpenByKey("alliance_help") and playerInfo:call("isInAlliance") and not isCrossServerNow() then
        local callback3 = function()
            self:hideSelf()
            if FunOpenController:isUnlock("fun_askHelp", true) then
                if self.nextCallHelpTime < getTimeStamp() then
                    require("game.alliance.AllianceAFHController").getInstance():onClickAFHBtn()
                end
            end
        end
        self:addBtn({
            icon = "alliance_currentnum.png",
            text = "610007",    --610007=求援
            callback = callback3,
            btnKey = "alliance_help",
        })
        self.nextCallHelpTime = playerInfo:getProperty("nextCallHelpTime")/1000
        local txt = CCLabelIF:call("create1","")
        txt:call("setColor", cc.c3b(222, 25, 25))
        txt:call("setFontSize", 20)
        txt:call("setAnchorPoint",ccp(0.5, 1))
        txt:setPosition(0, 6)
        txt:setTag(25)
        self.btnNode3 = self:getGuideNodeByKey("alliance_help")
        self.btnNode3:addChild(txt)
        if self.nextCallHelpTime > getTimeStamp() then
            self.btnNode3:removeChildByTag(99)
        end
    end 
    
    --扩建
    self:addExtensionBtn()

    -- 列王传
    if FunOpenController:isShow("fun_cokLegend") and require("game.activity.KingBiography.KingBiographyController").isOpen() then
        local callback5 = function()
            self:hideSelf()
            local view = Drequire("game.activity.KingBiography.KingBiographyView"):create()
            if view then
                PopupViewController:call("addPopupInView", view)
            end
        end
        local rpCnt = require("game.activity.KingBiography.KingBiographyController"):getInstance():getTotalRedPointCount()
        self:addBtn({
            icon = "Icon_biography_mainUI.png",
            text = "10010031",  --10010031=列王传
            callback = callback5,
            btnKey = "btnKingBiography",
            redpoint = rpCnt > 0
        })
    end

    if FunOpenController:isShow("fun_cokRoulette") and CCCommonUtilsForLua:isFunOpenByKey("card_roulette") then
        local callback6 = function()
            self:hideSelf()
            local view = Drequire("game.hero.NewUI.HeroGetRotateView"):create("41042001", "biography_type")
            if view then
                PopupViewController:call("addPopupInView", view)
            end
        end
        self:addBtn({
            icon = "icon_roulette_s.png",
            text = "5603001",   --5603001=列王转盘
            callback = callback6,
            btnKey = "btnBiographyRoulette"
        })
    end
end

function EmbassyBtn:onEnter2()    
    if self.entery ~= nil then
        self.entery = nil
    end      
    self.entry = tonumber(self:getScheduler():scheduleScriptFunc(function(dt) self:updateTime(dt) end, 1, false))
    self:updateTime(0)
end

function EmbassyBtn:onExit2()
    if self.entry then
		self:getScheduler():unscheduleScriptEntry(self.entry)
		self.entry = nil
    end
end

function EmbassyBtn:updateTime(dt)
    local now = getTimeStamp()
    local lessTime = self.nextCallHelpTime - now
    if lessTime < 0 then
        self:getScheduler():unscheduleScriptEntry(self.entry)
        self.entry = nil
    else
        local label = self.btnNode3:getChildByTag(25)
        label:call("setString",CC_SECTOA(lessTime))
    end
end

return EmbassyBtn
