--秘银矿
local SilverFactoryBtn = class("SilverFactoryBtn", Drequire("game.buildingBtns.BuildingAddBtn"))
function SilverFactoryBtn:create(param)
    local btn = SilverFactoryBtn.new(param)
    btn:initBtn()    
    return btn
end

function SilverFactoryBtn:initBtn()
    self.buildKey = self.param:valueForKey("buildKey"):intValue()
    self:addExtensionBtn()

end

return SilverFactoryBtn