--[[ 
    贤者之塔
 ]]
local HighTechBtn = class("HighTechBtn", Drequire("game.buildingBtns.BuildingAddBtn"))

function HighTechBtn:create(param)
    local btn = HighTechBtn.new(param)
    btn:initBtn()    
    return btn
end
 
function HighTechBtn:initBtn()
    self.buildKey = "436000"
    if isFunOpenByKey("functionopen") and FunOpenController:isShow("fun_analyse") then 
        self:addBtn({
            icon = "science_icon.png",
            text = "146506", -- 146506=研习
            callback = function()
                self:hideSelf()

                local HighTechBookView = Drequire("game.HighTech.HighTechView")
                local view = HighTechBookView.create()
                PopupViewController:call("addPopupInView", view)
            end,
        })
    end
end

return HighTechBtn