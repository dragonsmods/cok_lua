--文明圣殿
local PrestigeBtn = class("PrestigeBtn", Drequire("game.buildingBtns.SpeBuildingBtn"))

local ITEM_TYPE_SPD = 2

function PrestigeBtn:create(param)
    local btn = PrestigeBtn.new(param)
    btn:initBtn()    
    return btn
end

function PrestigeBtn:initBtn()
    self.buildKey = self.param:valueForKey("buildKey"):intValue()
    if self.buildKey == 0 then
        self.buildKey = SPE_BUILD_PRESTIGE
    end
    self.raceType = GlobalData:call("getPlayerInfo"):call("getCivilizationType")
    local typeNum = math.max(1, self.raceType)
    self.m_qid = QueueController:call("getMinTimeQidByType", QueueType.TYPE_RACETECH)
    self.lastTime = 0
    self.m_gold = 0
    self.m_toolInfoId = 0
    self.m_hasCreateCoinSpeed = false
    self.m_coinSpeedBtnIndex = 3
    local btnIndex = 0
    
    -- 声望
    if FunOpenController:isShow("fun_popularity") then
        btnIndex = btnIndex + 1
        self:addBtn(string.format("CivilizationRace_%d.png",typeNum), 
            "190405",   --190405=声望
            function()
                self:hideSelf()
                if self.raceType > 0 then
                    CivilizationController:fireCommonEvent("openPrestigeMainView", nil)
                end
            end)
    end

    -- 先祖之魂
    if FunOpenController:isShow("fun_ancestralSpirit") then
        btnIndex = btnIndex + 1
        self:addBtn("race_sci_icon.png", 
            "175673",   --175673=先祖之魂
            function()
                self:hideSelf()
                CCCommonUtilsForLua.jumpToTarget(7, "35")
            end)

        self:addExtraForBtn(btnIndex)
    end

    -- 金币加速
    self:onEnterFrame(1)

    -- 道具加速
    self:onUpdateToolBtn()

    -- 文明嘉年华
    if isFunOpenByKey("carnival") and FunOpenController:isShow("fun_ancestralCarnival") then
        local ccCtrl = require("game.civilization.Carnival.CivilizationCarnivalController").getInstance()
        ccCtrl:requestCelebrationInfoData()
        if ccCtrl.ccActStatus ~= ccCtrl.ccActStatusEnum.close then
            local callback = function()
                self:hideSelf()
                local view = Drequire("game.civilization.Carnival.CivilizationCarnivalView"):create()
                PopupViewController:addPopupInView(view)
            end 
            CCLoadSprite:call("loadDynamicResourceByName", "CivilizationCarnival_face")
            self:addBtn("CC_icon.png", "623052", callback)
        end
    end

    -- 先祖赐福
    if isFunOpenByKey("civi_scien_mission") and FunOpenController:isShow("fun_ancestralBless") then
        local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
        local inCiviMissActi = playerInfo:getProperty("inCiviMissActi")
        local abCtrl = require("game.civilization.Blessing.AncestorsBlessingController").getInstance()
        if inCiviMissActi and abCtrl.isActOutTime == false then
            local callback = function()
                self:hideSelf()
                local view = Drequire("game.civilization.Blessing.AncestorsBlessingView"):create()
                PopupViewController:addPopupInView(view)
            end 
            CCLoadSprite:call("loadDynamicResourceByName", "CivilizationCarnival_face")
            self:addBtn("ab_enter_icon.png", "623075", callback)
        end
    end
    
    --适配按钮位置
    self:adapt()
end

function PrestigeBtn:onEnterFrame(t)
    if self:isVisible() then
        if self.m_qid ~= QID_MAX then
            local queueInfos = GlobalData:call("shared"):getProperty("allQueuesInfo")
            local qInfo = queueInfos[self.m_qid]
            self.lastTime = qInfo:getProperty("finishTime") - getWorldTime()
            self.m_gold = CCCommonUtilsForLua:call("getGoldByTime", self.lastTime, qInfo:getProperty("type"))
            if self.coinNum then
                self.coinNum:call("setString",tostring(self.m_gold))
            end
            if self.lastTime<=0 and qInfo:getProperty("type") ~= QueueType.TYPE_BUILDING then
                self:setVisible(false)
                self:hideSelf()
            else
                if not self.m_hasCreateCoinSpeed then 
                    local callback = function()
                        self:hideSelf()
                        if PopupViewController:call("getCanPopPushView") then
                            local function callback() self:onCostGoldBack() end
                            local callfunc = cc.CallFunc:create(callback)
                            YesNoDialog:call("showTime", getLang("102283"), callfunc, self.lastTime, getLang("104903"), false)
                        else
                            self:onCostGoldBack()
                        end
                    end 
                    self.m_hasCreateCoinSpeed = true
                    self:addBtn("ui_gold.png", "104903", callback)
                    -- 适配金币和金币数
                    self:adaptCoinIconAndNum()
                end
            end
        end
    end
end

function PrestigeBtn:adaptCoinIconAndNum()
    if not table.isNilOrEmpty(self.childTable) and self.m_coinSpeedBtnIndex <= #self.childTable then
        local icon = self.childTable[self.m_coinSpeedBtnIndex].icon
        icon:setScale(1)
        icon:setPositionY(-12)
        self.coinNum = CCLabelIF:call("create1", tostring(self.m_gold))
        self.coinNum:call("setColor", cc.c3b(245, 178, 0))
        self.coinNum:call("setFontSize", 20)
        self.coinNum:call("setAnchorPoint",ccp(0.5, 0.5))
        self.coinNum:setPosition(25, 53)
        icon:addChild(self.coinNum)
    end
end

function PrestigeBtn:onCostGoldBack()
    if self.m_gold > 0 then
        local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
        local gold = playerInfo:getProperty("gold")
        if gold < self.m_gold then
            YesNoDialog:call("gotoPayTips")
            return
        end
    end
    
    QueueController:call("startCCDQueue", self.m_qid, "", false, self.m_gold, "", 1)
end

function PrestigeBtn:onUpdateToolBtn()
    local toolId = ToolController:call("getSPDItem", ItemSpdMenu.ItemSpdMenu_ALL, CCCommonUtilsForLua:isFunOpenByKey("speedup_new")) 
    
    if self.m_qid ~= QID_MAX and toolId > 0 then
        local toolInfo = ToolController:call("getToolInfoByIdForLua", toolId)
        if toolInfo:call("getCNT") > 0 and toolInfo:getProperty("type") == ITEM_TYPE_SPD then
            self.m_toolInfoId = toolId
            local icon = CCCommonUtilsForLua:call("getIcon", tostring(toolId))
            local callback = function()
                self:hideSelf()

                if self.m_qid ~= QID_MAX then
                    if CCCommonUtilsForLua:call("isFunOpenByKey", "speedup_UI") then
                        require("game.speedup.UseSpeedUpController").getInstance():openUI(ItemSpdMenu.ItemSpdMenu_RaceScience, self.buildKey, self.m_qid)
                    elseif CCCommonUtilsForLua:call("isFunOpenByKey", "speedup_new") then
                        local view = UseSpeedToolView:call("create", ItemSpdMenu.ItemSpdMenu_RaceScience, self.buildKey, self.m_qid)
                        PopupViewController:call("addPopupInView", view)
                    else
                        PropSpeedupView:call("show", ItemSpdMenu.ItemSpdMenu_RaceScience, self.buildKey, self.m_qid)
                    end
                end
            end 
            self:addBtn(icon, "104903", callback)
        end
    end
end

function PrestigeBtn:addExtraForBtn(btnIndex)
    if btnIndex > #self.childTable then
        return
    end
    local xmlData = CCCommonUtilsForLua:getGroupByKey("scienceRaceType")
    if xmlData and not table.isNilOrEmpty(self.childTable) then
        local isNew = false
        local icon = self.childTable[btnIndex].icon
        local scienceInfo = GlobalData:call("shared"):getProperty("scienceInfo")
        for k, v in pairs(xmlData) do
            local scienceIds = v.science
            local sciList = string.split(scienceIds, ";")
            if not table.isNilOrEmpty(sciList) then
                for i=1, #sciList do 
                    local scienceId = atoi(sciList[i])
                    if isNew == false and scienceInfo:call("getInfoRaceMapIsShowNewForLua",scienceId) then
                        local tips = CCLoadSprite:call("createSprite", "new_func_Icon.png")
                        if tips then
                            icon:addChild(tips)
                            tips:setPosition(cc.p(icon:getContentSize().width - 15, icon:getContentSize().height - 15))
                        end
                        isNew = true
                        break
                    end
                end
            end
            if isNew then
                break
            end
        end
    end
end

function PrestigeBtn:onEnter()
    self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:onEnterFrame(dt) end, 1, false)
    registerScriptObserver(self, self.showAni, "msg_stop_questani")
end

function PrestigeBtn:onExit()
    if self.m_entryId then
		self:getScheduler():unscheduleScriptEntry(self.m_entryId)
		self.m_entryId = nil
    end 
    unregisterScriptObserver(self, "msg_stop_questani")
end

return PrestigeBtn