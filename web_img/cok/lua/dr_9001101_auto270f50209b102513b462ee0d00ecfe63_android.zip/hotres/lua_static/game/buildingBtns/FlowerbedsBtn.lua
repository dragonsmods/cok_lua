--[[ 
    喷泉/鼎按钮
 ]]
local FlowerbedsBtn = class("FlowerbedsBtn", Drequire("game.buildingBtns.SpeBuildingBtn"))

function FlowerbedsBtn:create(param)
    local btn = FlowerbedsBtn.new(param)
    btn:initBtn()    
    return btn
end

function FlowerbedsBtn:initBtn()
    -- 鲜花排行榜
    if CCCommonUtilsForLua:isFunOpenByKey("send_flower") then
        self:addBtn("flower_enter.png", "164310", --164310=鲜花排行榜
            function()
                self:hideSelf()
                local view = myRequire("game.player.PlayerFlowerView"):create()
                PopupViewController:call("addPopupInView", view)
                
            end
        )
    end

    local isStar = CCCommonUtilsForLua:isFunOpenByKey("k_star_switch")--全服名人录
    if isStar then
        --最强王国
        local icon
		local obj = ActivityController:call("getInstance"):call("getActObj", "57155")
        if obj then
            if obj:getIconFrame() then
                icon = "activity_57155_list_cell_head_new.png"
            end
        else
            CCLoadSprite:call("doResourceByCommonIndex", 515, true)
            icon = "Dragon_icon.png"
        end

        self:addBtn(icon, "170947", --170947=最强王国
            function()
                self:hideSelf()
                local stage = FortressController.getInstance():getCurStage()
                if stage <= 2 then
                    myRequire("game.CommonPopup.ActivityViewPlus")
                    local view = ActivityViewPlus.create("57155")
                    PopupViewController:call("addPopupView", view)
                else
                    local view = myRequire("game.fortress.FortressSellView").create()
                    PopupViewController:call("addPopupInView", view)
                end
                
            end
        )
    else
        -- 网页活动
        if ActivityController:call("getInstance"):getProperty("showWebActivity") then
            self:addBtn("princess_task.png", "168620", --168620=网页活动
            function()
                self:hideSelf()
                local view = Drequire("game.activity.web.WebActivityView"):create()
                PopupViewController:addPopupInView(view)            
            end
        )
        end
    end

    -- 君王盛宴
    if ArmyController:call('getInstance'):call("isNewArmsFunOn", "p6_introduce") then
        self:addBtn("glory6Improve.png", "149900", --149900=君王盛宴
            function()
                self:hideSelf()
                local view = Drequire(game.Glory6.Glory6Introduction.Glory6IntroductionView):create()
                PopupViewController:addPopupView(view)
                
            end
        )
    end

    -- 王国新闻
    if CCCommonUtilsForLua:isFunOpenByKey("kingdom_news") and CCCommonUtilsForLua:isFunOpenByKey("blog") and GlobalData:call("shared"):call("checkModelAllow","blog") then
        self:addBtn("blog.png", "168103", --168103=王国新闻
            function()
                self:hideSelf()
                local view = Drequire("game.blog.PosterMainView"):create()
                PopupViewController:addPopupInView(view) 
                
            end
        )
    end

    if isStar then
        if FunOpenController:isShow("fun_whoswho") then
            self:addBtn("SeverRankings_icon.png", "4511017", --4511017=名人录
                function()
                    self:hideSelf()
                    local view = Drequire("game.rank.NewAllRankListView"):create()
                    PopupViewController:addPopupInView(view)
                end
            )
        end
    else
        if CCCommonUtilsForLua:isFunOpenByKey("civilization") then
            self:addBtn("civilizatoinIntroduction.png", "5530100", --5530100=文明崛起
                function()
                    self:hideSelf()
                    local view = Drequire("game.civilization.prestige.CivilizationIntroductionView").create()
                    PopupViewController:addPopupView(view)                
                end
            )
        end        
    end

    --web积分商城
    if CCCommonUtilsForLua:isFunOpenByKey("reward_point_mall") then
        self:addBtn("icon_ScoreMall.png", "42803400", --42803400=积分商城
            function()
                self:hideSelf()
                require("game.ScoreMall.ScoreMallMgr").getInstance():OpenView()
            end
        )
    end

    --列王资讯
    local ancCtrl = require("game.association.AssociationNewController").getInstance()
    if CCCommonUtilsForLua:isFunOpenByKey("mail_binding") 
    and ancCtrl:isEntranceOpen() then
        local isBind = ancCtrl:getBindStatus()
        self:addBtn("icon_kingSubscribeNews.png", "9201334", --9201334=列王资讯
            function()
                self:hideSelf()
                local view = Drequire("game.association.AssociationNewView"):create()
                PopupViewController:addPopupInView(view)
            end, not isBind
        )
    end

    -- 公告中心
    if CCCommonUtilsForLua:isFunOpenByKey("MessageCenterOpen") then
        self:addBtn("message_center_icon.png", "52034802", --52034802=公告中心
            function()
                self:hideSelf()
                local view = Drequire("game.MessageCenter.MessageCenterView"):create()
                PopupViewController:addPopupView(view) 
            end)
    end

    --亚马逊 
    if CCCommonUtilsForLua:isFunOpenByKey("amazon_activity_support") and PlayerInfoController:getRegCountry() ~= "CN" and PlayerInfoController:getRegCountry() ~= "RU" 
        and LocalController:call("getLanguageFileName") ~= "ru" then
        CCLoadSprite:call("loadDynamicResourceByName", "Common_209_face")
        self:addBtn("amazon_activity_icon.png", "",
            function()
                self:hideSelf()
                -- 新增打点
                LogController:postEventLog("AmazonBuildingIconClick")

                local view = Drequire("game.activity.web.WebActivityView"):create(nil, "AmazonActivity")
                PopupViewController:addPopupInView(view)
            end,
            nil, 65
        )
    end

    --适配按钮位置
    self:adapt()
end

return FlowerbedsBtn