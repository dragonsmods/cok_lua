--戒律大厅
local BuildNewArmsBtn = class("BuildNewArmsBtn", Drequire("game.buildingBtns.BuildingAddBtn"))
function BuildNewArmsBtn:create(param)
    local btn = BuildNewArmsBtn.new(param)
    btn:initBtn()    
    return btn
end

function BuildNewArmsBtn:initBtn()
    self.buildKey = self.param:valueForKey("buildKey"):intValue()
    if isFunOpenByKey("functionopen") and FunOpenController:isShow("fun_13army") then
        self:addBtn({
            icon = "glory6Train.png",
            text = "102276",    --102276=训练
            callback = function ()
                self:hideSelf()

	            local serverType = GlobalData:call("shared"):getProperty("serverType")
                if serverType == ServerType.SERVER_DRAGON_BATTLE_GLOBAL then
                    CCSafeNotificationCenter:postNotification("msg_dragon_worldcup_train")
                    return
                end

                local view = Drequire("game.Glory6.Glory6NewArmyTrainView"):create(self.buildKey)
                PopupViewController:addPopupInView(view)
            end
        })
    end

    if (isFunOpenByKey("angel_army") or isFunOpenByKey("night_army")) and FunOpenController:isShow("fun_14army") then
	    CCLoadSprite:call("loadDynamicResourceByName", "AngelArmy_face")
        local AngelArmyController = require("game.army.angel.AngelArmyController").getInstance()
        if AngelArmyController:isUnlock() then
            local callback = function()
                self:hideSelf()
                AngelArmyController:openView(self.buildKey)
            end
            self:addBtn({
                icon = "angel_train.png",
                text = "9712452",       --9712452=召唤天使士兵
                callback = callback,
                btnKey = "NewAngleArms",
            })
        else
            local buildInfo = FunBuildController:call("getFunbuildForLua", self.buildKey)
            if buildInfo then
                local callback = function()
                    self:hideSelf()
                    if FunOpenController:isUnlock("fun_14army", true) and buildInfo:getProperty("level") >= AngelArmyController:getUnlockLevel() then
                        AngelArmyController:openUnlockView({key = self.buildKey, items = AngelArmyController:getUnlockItems()})
                    else
                        LuaController:flyHint("", "", getLang("138666"))  --138666=等级不足
                    end
                end
                self:addBtn({
                    icon = "angel_train_locked.png",
                    text = "102113",    --102113=解锁
                    callback = callback,
                    btnKey = "NewAngleArms",
                })
            end
        end

        self:addLuckyAngleEffect()
    end

    self:addExtensionBtn()
end

function BuildNewArmsBtn:addLuckyAngleEffect()
    local AngelArmyController = require("game.army.angel.AngelArmyController").getInstance()

    if AngelArmyController:isLuckyAngelOpen() then
        local baseNode = self:getGuideNodeByKey("NewAngleArms")
        self:addBtnEffect(baseNode)
    end
end

return BuildNewArmsBtn