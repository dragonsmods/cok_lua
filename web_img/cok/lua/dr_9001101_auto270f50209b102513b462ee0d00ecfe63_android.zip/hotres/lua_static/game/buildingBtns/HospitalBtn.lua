--医疗帐篷功能按钮(不包含升级与详情按钮)
local HospitalBtn = class("HospitalBtn", Drequire("game.buildingBtns.BuildingAddBtn"))

local function isRevive2Open( ... )
   return CCCommonUtilsForLua:isFunOpenByKey("revive2_fun_new")
end

function HospitalBtn:create(param)
    local btn = HospitalBtn.new(param)
    btn:initBtn()    
    return btn
end

function HospitalBtn:initBtn()
    self.buildKey = self.param:valueForKey("buildKey"):intValue()

    -- 改成BuildingAddBtn后屏蔽"治疗"和"联盟医院" ，走C++代码逻辑
    -- --治疗
    -- local callback = function()
    --     self:hideSelf()
        
    --     local buildInfo = FunBuildController:call("getFunbuildForLua", self.buildKey)
    --     if buildInfo then
    --         local dict = CCDictionary:create()
    --         dict:setObject(buildInfo, "buildInfo")
    --         dict:setObject(CCString:create("BuildingHospitalPopUpView"), "name")
    --         LuaController:call("openPopViewInLua", dict)
    --     end
    -- end
    -- -- self:addBtn("icon_treatment.png", "102147", callback)
    -- self:addBtn({
    --     icon = "icon_treatment.png",
    --     text = "102147",
    --     callback = callback,
    -- }) 
    
    -- --联盟医院
    -- if CCCommonUtilsForLua:isFunOpenByKey("alliance_hospital") then
    --     if CCCommonUtilsForLua:isFunOpenByKey("alliance_hospital_show") then
    --         local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
    --         local isInAlliance = playerInfo:call("isInAlliance")
    --         local isHaveAllianceHospital = GlobalData:call("shared"):getProperty("isHaveAllianceHospital")
    --         local treatList = GlobalData:call("shared"):getProperty("allianceTreatList")
    --         local callback = function()
    --             self:hideSelf()
    --             local view = Drequire("game.allianceTerritory.AllianceHospitalTreatPopupView").create()
    --             PopupViewController:addPopupInView(view)
    --         end
    --         if (isInAlliance and isHaveAllianceHospital) or #treatList > 0 then
    --             -- self:addBtn("allianceMember.png", "4501000", callback)
    --             self:addBtn({
    --                 icon = "allianceMember.png",
    --                 text = "4501000",
    --                 callback = callback,
    --             }) 
    --        end       
    --     end
    -- end
    
    --流亡者大厅
    local crossServer = isCrossServerNow()
    -- revive_event 是否开启忠诚的流亡者活动
    if CCCommonUtilsForLua:isFunOpenByKey("graveyard") 
    and CCCommonUtilsForLua:isFunOpenByKey("graveyard_hospital_entrance") 
    and crossServer == false 
    and CCCommonUtilsForLua:isFunOpenByKey("revive_event")
    and FunOpenController:isShow("fun_exileTower")
    then
        if isRevive2Open() then 
            local valid = DynamicResourceController2:call("checkDynamicResource", "Revive2_face")
            if valid then
                CCLoadSprite:call("loadDynamicResourceByName", "Revive2_face")
            end
            local callback = function()
                self:hideSelf()
                if valid then
                    self:showReviveOpenView()
                else
                    CCCommonUtilsForLua:call("flyHint", "", "", getLang("E100091")) --E100091=领主大人，资源下载中，请稍后尝试操作。
                end
                LogController:sendUserBehaviorEvent("building", 2, tostring(math.floor(self.buildKey / 1000)), "revive")
            end
            self:addBtn({
                icon = "tile_pop_icon_revive.png",
                text = "145001",    --145001=流亡者之塔
                callback = callback,
                redpoint = require("game.revive2.ReviveController").getInstance():isOpen(),
            }) 

        else
            local valid = LuaController:call("checkValidActivityFromConfig", "revive")
            if valid then
                require("revive.ReviveCommandPlus")
                local cmd = ReviveGetInfoCmd.create()
                cmd:send()
            end

            local callback = function()
                self:hideSelf()

                if valid then
                    local rs = isInRevive()
                    if rs == 2 then   
                        local totaldead = tonumber(CEMETERY_INFO["KINGDOM"]["totaldead"])
                        local freedead = 0
                        if CEMETERY_INFO["PLAYER"] ~= nil and CEMETERY_INFO["PLAYER"]["freenum"] ~= nil then
                            freedead = tonumber(CEMETERY_INFO["PLAYER"]["freenum"])
                        end
                        if totaldead == 0 or freedead > 0 then
                            cc.UserDefault:getInstance():setIntegerForKey("__revive_open_key",0)
                            self:showReviveOpenView()
                        else
                            local officer =  GlobalData:comFunc("getPlayerInfo",0):getProperty("officer")
                            if officer == "216000" then --国王
                                self:showReviveView()
                            else
                                local savekey = cc.UserDefault:getInstance():getIntegerForKey("__revive_open_key")
                                if savekey == 1 then
                                    self:showReviveView()
                                else
                                    self:showReviveOpenView()
                                end
                            end
                        end
                    else
                        cc.UserDefault:getInstance():setIntegerForKey("__revive_open_key",0)
                        self:showReviveOpenView()
                    end
                else
                    CCCommonUtilsForLua:call("flyHint", "", "", getLang("E100091")) --E100091=领主大人，资源下载中，请稍后尝试操作。
                end
                LogController:sendUserBehaviorEvent("building", 2, tostring(math.floor(self.buildKey / 1000)), "revive")
            end
            self:addBtn({
                icon = "tile_pop_icon_revive.png",
                text = "145001",
                callback = callback,
            })
        end
    end

    --海域圣泉， 八国国战医院
    if isFunOpenByKey("ek_spring") and FunOpenController:isShow("fun_healingWell") then
        local serverType = GlobalData:call("shared"):getProperty("serverType")
        if (serverType == ServerType.SERVER_NATIONALWAR 
           or serverType == ServerType.SERVER_NORMAL 
           or serverType == ServerType.SERVER_TEST
           or serverType == ServerType.SERVER_INNER_TEST) then
            CCLoadSprite:call("loadDynamicResourceByName", "NationalWar_2_face")
            local callback = function()
                self:hideSelf()
                local view = Drequire("game.NationalWar.NationalWarHospitalView"):create()
                PopupViewController:addPopupInView(view)
                LogController:sendUserBehaviorEvent("building", 2, tostring(math.floor(self.buildKey / 1000)), "marineHeal")
            end
            self:addBtn({
                icon = "ek_spring_icon.png",
                text = "9200927",--9200927=海域圣泉
                callback = callback,
            }) 
        end
    end

    -- 联盟神像
    if CCCommonUtilsForLua:isFunOpenByKey("building_alliance_idol") and crossServer == false then
        CCLoadSprite:call("loadDynamicResourceByName", "AllianceTerritory_face")
        local atCtrl = require("game.allianceTerritory.AllianceTerritoryController").getInstance()
        local statuePoint = atCtrl:getStatuePoint()
        if statuePoint > 0 then
            local callback = function()
                self:hideSelf()
                SceneController:call("gotoScene", SCENE_ID_WORLD, false, true, statuePoint)
                LogController:sendUserBehaviorEvent("building", 2, tostring(math.floor(self.buildKey / 1000)), "greet")
            end
            self:addBtn({
                icon = "AT_icon_visit.png",
                text = "624855",    --624855=参拜
                callback = callback,
            }) 
        end
    end

    --扩建
    self:addExtensionBtn()

end

function HospitalBtn:showReviveOpenView()
    if isRevive2Open() then 
        require("game.revive2.ReviveController").getInstance():openView(self.params)
    else
        Drequire "revive.ReviveOpenViewPlus"
        local view = ReviveOpenView:create(self.params)
        if view ~= nil then
            PopupViewController:addPopupInView(view)
        end
    end
end

function HospitalBtn:showReviveView()
    if isRevive2Open() then 
        require("game.revive2.ReviveController").getInstance():openView()
    else
        local view = Drequire("revive.ReviveViewPlus"):create()
        if view ~= nil then
            PopupViewController:addPopupInView(view)
        end
    end
end

function HospitalBtn:getGuideNodeByKey(key)
    if key == "heal" then
        return self:getBtn(1)
    end
end

return HospitalBtn