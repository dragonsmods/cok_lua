--骑兵兵营
local BuildCavalryBtn = class("BuildCavalryBtn", Drequire("game.buildingBtns.BuildingAddBtn"))
function BuildCavalryBtn:create(param)
    local btn = BuildCavalryBtn.new(param)
    btn:initBtn()    
    return btn
end

function BuildCavalryBtn:initBtn()
    self.buildKey = self.param:valueForKey("buildKey"):intValue()
    self:addExtensionBtn()

end

return BuildCavalryBtn