--铁匠铺
local BlacksmithBtn = class("BlacksmithBtn", Drequire("game.buildingBtns.BuildingAddBtn"))
-- local BlacksmithBtn = class("BlacksmithBtn", Drequire("game.buildingBtns.BuildingBtn"))
function BlacksmithBtn:create(param)
    local btn = BlacksmithBtn.new(param)
    btn:initBtn()    
    return btn
end

function BlacksmithBtn:initBtn()
    self.m_actId = "57403"
    self.buildKey = self.param:valueForKey("buildKey"):intValue()
    self.buildType = tostring(math.floor(self.buildKey / 1000))
    self:handleMoveOpen()
    self:addExtensionBtn()
end

function BlacksmithBtn:handleMoveOpen(  )
    if isFunOpenByKey("functionopen") then
        if FunOpenController:isShow("fun_forging") then
            local redP = false
            if isFunOpenByKey("equipment_smelt") then
                redP = not cc.UserDefault:getInstance():getBoolForKey("EquipmentSmeltView_Open", false)
            end
            self:addBtn({
                icon = "icon_forging01.png",
                text = "102349",--102349=锻造
                redpoint = redP,
                callback = function()
                    self:hideSelf()
                    CCCommonUtilsForLua.jumpToTarget( 7, "34" )
                    CCSafeNotificationCenter:call("postNotification", GUIDE_INDEX_CHANGE, CCString:create(string.format("BU_%s_forge", self.buildType)))
                    LogController:sendUserBehaviorEvent("building", 2, self.buildType, "forge")
                end
            })
        end
    
        self:addBtn({
            icon = "glft003.png",
            text = "102350",--102350=储物箱
            callback = function()
                self:hideSelf()
                CCCommonUtilsForLua.jumpToTarget( 7, "20" )
                LogController:sendUserBehaviorEvent("building", 2, self.buildType, "storageBox")
            end
        })
    
        if isFunOpenByKey("equipment_rank") and FunOpenController:isShow("fun_forgingGod") then
            self:addBtn({
                icon = "icon_equipment_rank.png",
                text = "221118",--221118=锻造之神
                callback = function()
                    self:hideSelf()
                    local view = Drequire("game.equipment.EquipRank.EquipmentInfoView"):create()
                    PopupViewController:addPopupInView(view)
                    LogController:sendUserBehaviorEvent("building", 2, self.buildType, "forgingGod")
                end
            })
        end
    end

    if self:isMoveFlagOpen() and self:isCarnivalOpen() and not isCrossServerNow() then
        local obj = ActivityController:call("getActObj", self.m_actId)
        if obj then
            obj:getIconFrame()
        end

        local resReady = not not CCLoadSprite:call("loadResource", "activity_57403_list_cell_head_new.png")
        if resReady then
            local callback = function()
                self:hideSelf()
                if ActivityController.getInstance():isActivityOpenWithTime(self.m_actId) then
                    ActivityController.getInstance():shouActUIById(self.m_actId)
                end
            end

            self:addBtn({
                icon = "activity_57403_list_cell_head_new.png",
                text = "9461029",--9461029=装备强化狂欢
                callback = callback,
                btnKey = "BlacksmithBtn",
            })
        end
    end

    --【Awen】装备宝石
    if require("game.equipment.gem.EquipmentGemController").getInstance():isOpen() and FunOpenController:isShow("fun_gemDig") then
        local callback = function()
            self:hideSelf()
            require("game.equipment.gem.EquipmentGemController").getInstance():openDigView()
            LogController:sendUserBehaviorEvent("building", 2, self.buildType, "gem")
        end
        self:addBtn({
            icon = "icon_equipment_gem.png",
            text = "221261", --221261=宝石
            callback = callback,
            btnKey = "BlacksmithBtnGem",
        })
    end

    -- 全民挖宝（宝石活动）
    local digGemActCtl = require("game.activity.EveryoneDigGem.EveryoneDigGemMgr").getInstance()
    if digGemActCtl:isOpen() and ActivityController.getInstance():isActivityOpenWithTime(digGemActCtl:getActivityId()) then
        local callback = function()
            self:hideSelf()
            digGemActCtl:showView()
            LogController:sendUserBehaviorEvent("building", 2, self.buildType, "digTreasure")
        end
        self:addBtn({
            icon = "everyone_dig_gem_icon.png",
            text = "50005001",
            callback = callback,
            btnKey = "BlacksmithBtnDigGemAct",
            redpoint = digGemActCtl:getRedDotCount() > 0,
        })
    end
end

function BlacksmithBtn:isMoveFlagOpen(  )
    return CCCommonUtilsForLua:isFunOpenByKey("enhance_carnival_entry")
end

function BlacksmithBtn:isCarnivalOpen(  )
    return ActivityController.getInstance():isActivityOpenWithTime(self.m_actId)
end

return BlacksmithBtn