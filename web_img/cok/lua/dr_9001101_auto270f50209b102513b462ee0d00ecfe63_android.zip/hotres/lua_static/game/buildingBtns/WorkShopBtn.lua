--作坊
local WorkShopBtn = class("WorkShopBtn", Drequire("game.buildingBtns.SpeBuildingBtn"))

function WorkShopBtn:create(param)
    local btn = WorkShopBtn.new(param)
    btn:initBtn()    
    return btn
end

function WorkShopBtn:initBtn()
    CCLoadSprite:call("doResourceByCommonIndex", 4, true)
    self.param:setObject(CCString:create(getLang("102379")), "title")
    self.buildKey = self.param:valueForKey("buildType"):intValue()

    if FunOpenController:isShow("fun_materials") then
        local callback = function()
            self:hideSelf()
            local layer = SceneController:call("getCurrentLayerByLevel", LEVEL_SCENE)
            if layer then
                layer:call("setUnMoveScence", false)
                layer:call("onMoveToBuildAndOpen", tonumber(self.buildKey),2) 
            end
            local useLua = CCCommonUtilsForLua:call("isTestPlatformAndServer", "tool_create_ui")
            if useLua then
                local view = require("game.equipment.ToolCreateView"):create()
                PopupViewController:addPopupView(view)
            else
                local dict = CCDictionary:create()
                dict:setObject(CCString:create("OpenToolCreateView"), "name")
                LuaController:call("openPopViewInLua", dict)
            end
        end
        self:addBtn("icon_workShop.png","102379",callback)  --102379=作坊
    end
    
    if FunOpenController:isShow("fun_alchemy") then
        local callback2 = function()
            self:hideSelf()
            local view = Drequire("game.workShop.AlchemyHouseView"):create()
            PopupViewController:addPopupInView(view)
        end
        self:addBtn("icon_alchemyHouse.png","9711222",callback2)--9711222=炼金工坊
    end
    self:adapt()
end

return WorkShopBtn