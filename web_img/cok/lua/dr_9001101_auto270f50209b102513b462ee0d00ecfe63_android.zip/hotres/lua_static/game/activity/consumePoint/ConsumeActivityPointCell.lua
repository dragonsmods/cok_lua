-------------------------------------------- ConsumeActivityPointCell Start --------------------------------------------
local ConsumeActivityPointCell = class("ConsumeActivityPointCell", function()
    return cc.Layer:create()
end)

function ConsumeActivityPointCell:create(idx)
    local ret = ConsumeActivityPointCell.new()
    Drequire("game.activity.consumePoint.ConsumeActivityPointCell_ui"):create(ret)
    return ret
end

function ConsumeActivityPointCell:refreshCell(info , idx)
	self.ui.m_curPointLbl:setString(info.rewardMax)
	self.ui.m_progress:setVisible(false)
	self.ui.m_progress:setScaleX(0)
	if tonumber(info.costPoint) < tonumber(info.rewardMax) and tonumber(info.costPoint) > tonumber(info.rewardMin) then
		local delta = tonumber(info.costPoint) - tonumber(info.rewardMin)
		local all = tonumber(info.rewardMax) - tonumber(info.rewardMin)
		local scaleX = delta /  all 
		self.ui.m_progress:setScaleX(scaleX)
		self.ui.m_progress:setVisible(true)
	elseif tonumber(info.costPoint) >= tonumber(info.rewardMax) then
		self.ui.m_progress:setVisible(true)
		self.ui.m_progress:setScaleX(1)
	end
	if info.isGet then
		self.ui.m_rewardEmptySp:setVisible(true)
		self.ui.m_rewardSp:setVisible(false)
	else
		self.ui.m_rewardEmptySp:setVisible(false)
		self.ui.m_rewardSp:setVisible(true)
	end
end

function ConsumeActivityPointCell:onEnter()
end

function ConsumeActivityPointCell:onExit()
end

-------------------------------------------- ConsumeActivityPointCell End --------------------------------------------

return ConsumeActivityPointCell