----------------------------
-- Author: Elex
-- Date: 2017-06-22 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local ConsumeActivityView_ui = class("ConsumeActivityView_ui")

--#ui propertys


--#function
function ConsumeActivityView_ui:create(owner, viewType)
	local ret = ConsumeActivityView_ui.new()
	CustomUtility:DoRes(7, true)
	CustomUtility:DoRes(8, true)
	CustomUtility:LoadUi("ConsumeActivityView.ccbi", ret, owner, true, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then		owner:initTableViewByOwner()
	else		ret:initTableView()	end	return ret
end

function ConsumeActivityView_ui:initLang()
end

function ConsumeActivityView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function ConsumeActivityView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function ConsumeActivityView_ui:onClickClose(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickClose", pSender, event)
end

function ConsumeActivityView_ui:onClickRankList(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickRankList", pSender, event)
end

function ConsumeActivityView_ui:onHelpBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onHelpBtnClick", pSender, event)
end

function ConsumeActivityView_ui:initTableView()
	TableViewSmoker:createView(self, "m_stepList", "game.activity.consumePoint.ConsumeActivityPointCell", 0, 10, "ConsumeActivityPointCell")
	TableViewSmoker:createView(self, "m_rewardListNode", "game.activity.consumePoint.ConsumeActivityRewardCell", 1, 10, "ConsumeActivityRewardCell")
end

function ConsumeActivityView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return ConsumeActivityView_ui

