----------------------------
-- Author: Elex
-- Date: 2019-10-08 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local MasterArcherShop_ui = class("MasterArcherShop_ui")

--#ui propertys


--#function
function MasterArcherShop_ui:create(owner, viewType, paramTable)
	local ret = MasterArcherShop_ui.new()
	CustomUtility:LoadUi("MasterArcherShop.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function MasterArcherShop_ui:initLang()
end

function MasterArcherShop_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function MasterArcherShop_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function MasterArcherShop_ui:onDefaultButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onDefaultButtonClick", pSender, event)
end

function MasterArcherShop_ui:onLuxuryButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onLuxuryButtonClick", pSender, event)
end

function MasterArcherShop_ui:onLuxuryButtonClick1(pSender, event)
	ButtonSmoker:forwardFunction(self, "onLuxuryButtonClick1", pSender, event)
end

function MasterArcherShop_ui:onLuxuryButtonClick2(pSender, event)
	ButtonSmoker:forwardFunction(self, "onLuxuryButtonClick2", pSender, event)
end

function MasterArcherShop_ui:onClickRecord(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickRecord", pSender, event)
end

function MasterArcherShop_ui:initTableView()
	TableViewSmoker:createView(self, "m_listTableView_Default", "game.activity.CsmodItemStore.CsmodItemStoreCell", 1, 10, "CsmodItemStoreCell")
	TableViewSmoker:createView(self, "m_listTableView_Luxury", "game.activity.CsmodItemStore.CsmodItemStoreCell", 1, 10, "CsmodItemStoreCell")
	TableViewSmoker:createView(self, "m_listTableView_Luxury1", "game.activity.CsmodItemStore.CsmodItemStoreCell", 1, 10, "CsmodItemStoreCell")
	TableViewSmoker:createView(self, "m_listTableView_Luxury2", "game.activity.CsmodItemStore.CsmodItemStoreCell", 1, 10, "CsmodItemStoreCell")
end

function MasterArcherShop_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return MasterArcherShop_ui

