----------------------------
-- Author: Elex
-- Date: 2019-08-19 Monday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CsmodCarnival_ui = class("CsmodCarnival_ui")

--#ui propertys


--#function
function CsmodCarnival_ui:create(owner, viewType, paramTable)
	local ret = CsmodCarnival_ui.new()
	CustomUtility:LoadUi("CsmodCarnival.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function CsmodCarnival_ui:initLang()
end

function CsmodCarnival_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CsmodCarnival_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CsmodCarnival_ui:onDefaultButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onDefaultButtonClick", pSender, event)
end

function CsmodCarnival_ui:onLuxuryButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onLuxuryButtonClick", pSender, event)
end

function CsmodCarnival_ui:onRankButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onRankButtonClick", pSender, event)
end

function CsmodCarnival_ui:onClickRecord(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickRecord", pSender, event)
end

function CsmodCarnival_ui:onControlButton2(pSender, event)
	ButtonSmoker:forwardFunction(self, "onControlButton2", pSender, event)
end

function CsmodCarnival_ui:initTableView()
	TableViewSmoker:createView(self, "m_listTableView_Default", "game.activity.CsmodItemStore.CsmodItemStoreCell", 1, 10, "CsmodItemStoreCell")
	TableViewSmoker:createView(self, "m_listTableView_Luxury", "game.activity.CsmodItemStore.CsmodItemStoreCell", 1, 10, "CsmodItemStoreCell")
end

function CsmodCarnival_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return CsmodCarnival_ui

