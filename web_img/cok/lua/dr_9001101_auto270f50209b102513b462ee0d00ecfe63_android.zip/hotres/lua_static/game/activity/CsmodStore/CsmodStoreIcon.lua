-- 世界杯S4入口icon
local superClass = require("game.CommonPopup.UiCompoentIcon")
local CsmodStoreIcon = class("CsmodStoreIcon",superClass)

function CsmodStoreIcon.create(iconSize, contentSize)
    local view = CsmodStoreIcon.new(iconSize)
    if view:initView(iconSize, contentSize) then
        return view
    end
end

function CsmodStoreIcon:initView(iconSize, contentSize)
	self.m_iconSize = iconSize
	self:setContentSize(iconSize)
	self:setVisible(false)
	self:refreshUI()
	return true
end

function CsmodStoreIcon:onEnterFrame(dt)

end

function CsmodStoreIcon:refreshUI()
	local halfWidth = self.m_iconSize.width * 0.5
	local halfHeight = self.m_iconSize.height * 0.5
    local bg = CCLoadSprite:createSprite("icon_BG.png")
	bg:setPosition(ccp(halfWidth, halfHeight))
    bg:setScale(0.63)
    self:addChild(bg)

	CCLoadSprite:call("loadDynamicResourceByName", "worldCup_face")
    local icon = getSafeSprite("icon_ScoreMall.png", "worldCup_face.png")
    icon:setPosition(ccp(halfWidth, halfHeight))
    self:addChild(icon)

    self.t_name = cc.LabelTTF:create(getLang("42803400"), "Helvetica", 18)	--42803400=CoK世界杯
    self.t_name:setPosition(ccp(halfWidth,  2))
    self.t_name:setAnchorPoint(ccp(0.5, 0) )
	self:addChild(self.t_name, 2)
    utils.attachBgToLabel(self.t_name)
	
	for i = 0, 2 do
		local resName = string.format("QueueGlow_%d", i)
		local particle = ParticleController:call("createParticle", resName)
		if particle then
			particle:setPosition(ccp(halfWidth, halfHeight)) 
			self:addChild(particle)
		end
	end

	self:setVisible(true)
end

function CsmodStoreIcon:touchEvent()
    local view = Drequire("game.activity.CsmodItemStore.CsmodItemStoreView"):create()
	PopupViewController:addPopupInView(view)
	LogController:sendUserBehaviorEvent("right", 1, "dragonWorldCupS4")
end

function CsmodStoreIcon:onSceneChanged(sceneId)
	if atoi(self.iconType) ~= 1 then
		if sceneId == SCENE_ID_WORLD then
			self:setVisible(false)
		else
			self:setVisible(true)
		end
	end
end

return CsmodStoreIcon