----------------------------
-- Author: Elex
-- Date: 2020-02-07 Friday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local FestivalStoreCell_ui = class("FestivalStoreCell_ui")

--#ui propertys


--#function
function FestivalStoreCell_ui:create(owner, viewType, paramTable)
	local ret = FestivalStoreCell_ui.new()
	CustomUtility:DoRes(305, true)
	CustomUtility:DoRes(8, true)
	CustomUtility:LoadUi("FestivalStoreCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function FestivalStoreCell_ui:initLang()
end

function FestivalStoreCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function FestivalStoreCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function FestivalStoreCell_ui:onBuyButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBuyButtonClick", pSender, event)
end

return FestivalStoreCell_ui

