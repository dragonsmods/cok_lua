----------------------------
-- Author: Elex
-- Date: 2020-01-16 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CsmodStoreCell_ui = class("CsmodStoreCell_ui")

--#ui propertys


--#function
function CsmodStoreCell_ui:create(owner, viewType, paramTable)
	local ret = CsmodStoreCell_ui.new()
	CustomUtility:DoRes(305, true)
	CustomUtility:DoRes(8, true)
	CustomUtility:LoadUi("CsmodStoreCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CsmodStoreCell_ui:initLang()
end

function CsmodStoreCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CsmodStoreCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CsmodStoreCell_ui:onBuyButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBuyButtonClick", pSender, event)
end

return CsmodStoreCell_ui

