local ConsumeActivityView = class("ConsumeActivityView",
    function()
        return PopupBaseView:create()
    end
)
ConsumeActivityView.__index = ConsumeActivityView

---------------------------信息 Start ---------------------------
ConsumeActivityInfoCmd = class("ConsumeActivityInfoCmd", LuaCommandBase)
function ConsumeActivityInfoCmd.create()
    local ret = ConsumeActivityInfoCmd.new()
    ret:initWithName("continuedcost.info")
    return ret
end

function ConsumeActivityInfoCmd:handleReceive(dict)
    local flag, params = self:parseMsg(dict)
    Dprint("BalanceInputCmd:handleReceive | parse flag=", flag)
    if (type(flag) == "boolean") then
        return flag
    end
    CCSafeNotificationCenter:postNotification("consumeActivity_info",params)
    return true
end
--------------------------- 信息 End ---------------------------


function ConsumeActivityView:create()
	local view = ConsumeActivityView.new()
	Drequire("game.activity.consumePoint.ConsumeActivityView_ui"):create(view, 0)
	if view:initView() == false then
		return nil
	end
  	return view
end

function ConsumeActivityView:initView()
	callItSelfCallFunc(LuaController, "doResourceByCommonIndex", 7, true)
	callItSelfCallFunc(LuaController, "doResourceByCommonIndex", 8, true)
	callItSelfCallFunc(LuaController, "doResourceByCommonIndex", 11, true)
    callItSelfCallFunc(LuaController, "doResourceByCommonIndex", 101, true)
    callItSelfCallFunc(LuaController, "doResourceByCommonIndex", 500, true)
	
    local obj = ActivityController:call("getInstance"):call("getActObj", "57159")
    if obj and obj:getProperty("endTime") then
        self.m_endTime = tonumber(obj:getProperty("endTime"))
        local now = LuaController:call("getWorldTime")
        if now >= obj:getProperty("endTime") then
            LuaController:flyHint("","",getLang("102517"))
            return false
        end
    else
        LuaController:flyHint("","",getLang("102517"))
        return false
    end
    --dynamic pic
    local resname = ""
    local obj = ActivityController:call("getInstance"):call("getActObj", "57159")
    if obj and obj:getDyResName()  then
        resname = obj:getDyResName()
        if DynamicResourceController2:call("checkDynamicResource", resname) then
            CCLoadSprite:call("loadDynamicResourceByName", "57159_face")
            local adName = "57159_ad.png"
            local adSprSF = CCLoadSprite:call("getSF", adName)
            local adSpr = cc.Sprite:createWithSpriteFrame(adSprSF)
            if adSpr then
                self.ui.m_showPicNode:removeAllChildren()
                self.ui.m_showPicNode:addChild(adSpr)
                adSpr:setAnchorPoint(cc.p(0.5,0))
            end
        end
    end
    local descNode = CommonItemDescNode:call("create", "", "", false)
    self.ui.m_descNode:addChild(descNode)
    descNode:setVisible(false)
    self.descNode = descNode

    if CCCommonUtilsForLua:isFunOpenByKey("new_rank_cost") then
        self.ui.m_rankListNode:setVisible(true)
        local par1 = ParticleController:call("createParticle", "Rose_3")
        self.ui.m_rankListPar:addChild(par1)
        local par2 = ParticleController:call("createParticle", "VIPGlow_3")
        self.ui.m_rankListPar:addChild(par2)
    else
        self.ui.m_rankListNode:setVisible(false)
    end

    return true
end

function ConsumeActivityView:onClickClose()
	PopupViewController:call("removePopupView", self)
end

function ConsumeActivityView:onEnter()
	local cmd = ConsumeActivityInfoCmd.create()
    cmd:send()
    local function onRefresh( ref )
        local tbl = dictToLuaTable(ref)
        local xmlData = CCCommonUtilsForLua:getGroupByKey("continued_cost")
        if tbl.costType == "1" then
            local refreshTbl = {}
            local reachLv = tonumber(tbl.reachLv) or 0
            for k,v in pairs(xmlData) do
                local tempTbl = {}
                tempTbl.rewardMax = v.rewardMax
                tempTbl.rewardMin = v.rewardMin
                tempTbl.getLv = tbl.getLv
                tempTbl.costPoint = tbl.costPoint
                tempTbl.level = v.level

                local isGet = tonumber(tempTbl.level) <= reachLv 
                -- local getLvTable = string.split(tbl.getLv,",")
                -- for c,d in pairs(getLvTable) do
                --     if tonumber(d) == tonumber(v.level) then
                --         isGet = true
                --         break
                --     end
                -- end
                tempTbl.isGet = isGet
                for a,b in pairs(tbl.costReward) do
                    if tonumber(b.point) == tonumber(v.rewardMax) then
                        tempTbl.costReward = b
                        break
                    end
                end
                table.insert(refreshTbl , tempTbl)
            end
            self:onRefresh(refreshTbl)
        end
        local face_info = tbl.faceInfo
        self:addFaceInfo(face_info)
    end
    local t = tolua.cast(self, "cc.Node")
    local handler = t:registerHandler(onRefresh)
    CCSafeNotificationCenter:registerScriptObserver(self, handler, "consumeActivity_info")

    local function onRefreshGetReward( ref )
        local tbl = dictToLuaTable(ref)
        GCMRewardController:call("getInstance"):call("retReward2", luaTableToArray(tbl.rewardArray), true)

        if self.m_tableDatabottom then
            for k,v in pairs(self.m_tableDatabottom) do
                v.getLv = v.getLv .. "," .. tbl.getLv
                local isGet = false
                local getLvTable = string.split(v.getLv,",")
                for c,d in pairs(getLvTable) do
                    if tonumber(d) == tonumber(v.level) then
                        isGet = true
                        break
                    end
                end
                v.isGet = isGet
            end

            self:onRefresh(self.m_tableDatabottom)
        end
    end
    local handler2 = t:registerHandler(onRefreshGetReward)
    CCSafeNotificationCenter:registerScriptObserver(self, handler2, "consumeActivity_get_info")

    self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:update(dt) end, 1, false)
    self:update(0)
    cc.UserDefault:getInstance():setStringForKey("ACTIVITY_CONSUME", "1")
end

function ConsumeActivityView:onExit()
    CCSafeNotificationCenter:unregisterScriptObserver(self, "consumeActivity_info") 
    CCSafeNotificationCenter:unregisterScriptObserver(self, "consumeActivity_get_info")
    self:getScheduler():unscheduleScriptEntry(self.m_entryId)
    cc.UserDefault:getInstance():setStringForKey("ACTIVITY_CONSUME", "0")
end

function ConsumeActivityView:onRefresh( tbl )
    if tbl[1] and tbl[1].costPoint and tonumber(tbl[1].costPoint) > 0 then
        self.m_costPoint = tonumber(tbl[1].costPoint)
    else
        self.m_costPoint = 0
    end
    -- 中间描述
    self.m_needPoint = 0
    for k,v in pairs(tbl) do
        if self.m_costPoint >= tonumber(v.rewardMin) and self.m_costPoint <= tonumber(v.rewardMax) then
            self.m_needPoint = tonumber(v.rewardMax) - self.m_needPoint
            break
        end
    end
    self.m_needPoint = tonumber(self.m_needPoint) - self.m_costPoint
    local isGetAll = true
    for k,v in pairs(tbl) do
        if not v.isGet then
            isGetAll =false
            break
        end
    end
    local text = ""
    if isGetAll then
        text = getLang("133265")  -- 已全部领奖
    else
        if self.m_needPoint <= 0 then
            text = ""
        else
            text = getLang("140551", CC_CMDITOA(self.m_needPoint)) 
        end
    end
    self.ui.m_shouldBuyLabel:setString(text)
    self.ui.m_hasBuyLabel:setString(getLang("140550" , CC_CMDITOA(self.m_costPoint)))  
    self.ui.m_listTitleLabel:setString(getLang("140552"))  
    self.ui.m_titleLabel:setString(getLang("140547"))

    function sortById( a,b )
        return tonumber(a.level) < tonumber(b.level)
    end
    table.sort(tbl,sortById)
    -- 上方点数列表
    self.ui:setTableViewDataSource("m_stepList", tbl)

    local function _touchFunc(beShow, itemData, x, y)
        if beShow then
            self.descNode:setVisible(true)

            local itemId = itemData.value.id
            local name = CCCommonUtilsForLua:getPropById(itemId, "name")
            local content = CCCommonUtilsForLua:getPropById(itemId, "description")
            self.descNode:call("setItemNameAndContent", getLang(name), getLang(content))
            local contentSize = self.descNode:getContentSize()
            self.descNode:setPositionY(y + contentSize.height*0.5)
        else
            self.descNode:setVisible(false)
        end
    end

    self.m_tableDatabottom = {}
    for k,v in pairs(tbl) do
        local tempTbl = {}
        tempTbl.rewardMax = v.rewardMax
        tempTbl.rewardMin = v.rewardMin
        tempTbl.getLv = v.getLv
        tempTbl.costPoint = v.costPoint
        tempTbl.level = v.level
        tempTbl.isGet = v.isGet
        tempTbl.costReward = v.costReward
        table.insert(self.m_tableDatabottom , tempTbl)
        tempTbl.touchFunc = _touchFunc
        tempTbl.parent = self.ui.m_rewardListNode
    end

    function sortByIdAndIsGet(a,b)
        return tonumber(a.level) < tonumber(b.level)
    end
    table.sort( self.m_tableDatabottom, sortByIdAndIsGet )
    -- 下方列表
    self.ui:setTableViewDataSource("m_rewardListNode", self.m_tableDatabottom)


    -- 设定偏移
    local offNum = 0
    for index, data  in pairs(tbl) do
        if data.isGet == false then
            break
        else
            offNum = index
        end
    end

    local function getTableOffset(index, num)
        local tab = self.ui.m_stepList
        if index == 2 then
            tab = self.ui.m_rewardListNode
        end

        local width = 0
        local height = 0
        for i = 1, num do
            local sizeW, sizeH = self:cellSizeForTable(tab, i-1)
            width = width + sizeW
            height = height + sizeH
        end

        if index == 1 then
            return width
        else
            return height
        end
    end
    local function checkOffsetRange(tableView)
        local curPos = tableView:getContentOffset()
        local minPos = tableView:minContainerOffset()
        local maxPos = tableView:maxContainerOffset()
        if curPos.x < minPos.x or curPos.y < minPos.y then
           tableView:setContentOffset(minPos)
        end
        if curPos.x > maxPos.x or curPos.y > maxPos.y then
           tableView:setContentOffset(maxPos)
        end
    end

    if offNum > 0 then
        -- 设定上方点数偏移
        if offNum > 1 then
            local offsetWidth = getTableOffset(1, offNum - 1)
            local offset = self.ui.m_stepList:getContentOffset()
            self.ui.m_stepList:setContentOffset(cc.p(offset.x - offsetWidth, offset.y))
            checkOffsetRange(self.ui.m_stepList)
        end

        local offsetHeight = getTableOffset(2, offNum)
        local offset = self.ui.m_rewardListNode:getContentOffset()
        self.ui.m_rewardListNode:setContentOffset(cc.p(offset.x, offset.y + offsetHeight))
        checkOffsetRange(self.ui.m_rewardListNode)
    end
end
function ConsumeActivityView:cellSizeForTable(tab, idx)
    if tab == self.ui.m_stepList then
        return 100, 140
    elseif tab == self.ui.m_rewardListNode then
        local num = #self.m_tableDatabottom[idx + 1].costReward.reward
        if num <= 2 then
            num = 2
        end
        Dprint("ConsumeActivityView:cellSizeForTable idx/num=", idx, num)
        return 500, 50 + num * 40
    end
end

function ConsumeActivityView:update(dt)
    -- body
    local lastTime = self.m_endTime - getWorldTime()
    if lastTime > 0 then
        self.ui.m_timeLeftLbl:setString(format_time(lastTime))
    else
        -- PopupViewController:call("removePopupView", self)
    end
end

function ConsumeActivityView:onHelpBtnClick()
    local view = TipsView:call("create", getLang("140549"), 0)
    PopupViewController:addPopupView(view)
end

function ConsumeActivityView:addFaceInfo(face_info)
    if face_info and face_info ~= "" then
        local tbl = string.split(face_info, ",")
        if tbl[1] ~= "" then
            local avatarShow = Drequire("game.avatar.AvatarFaceShowView").new(tbl[1])
            self.ui.m_animShow:addChild(avatarShow)
            if tbl[2] then
                avatarShow:setPositionX(tonumber(tbl[2]))
            end
            if tbl[3] then
                avatarShow:setPositionY(tonumber(tbl[3]))
            end
            if tbl[4] then
                avatarShow:setScale(tonumber(tbl[4]))
            end
        end
    end
end

function ConsumeActivityView:onClickRankList()
    local _endTime = self.m_endTime
    PopupViewController:call("removePopupView", self)
    local data = {
        titleName = getLang("9450311"),     -- 9450311=累计消耗全服排行榜
        view1 = {
            viewType = 1,  -- 1,排名，2奖励
            viewInfoMsg = "continuedcost.ranking",       -- 拉取消息
            viewHideMsg = "continuedcost.hideking",      -- hide名字消息
            endTime = _endTime,
            btnName = getLang("140477"),
        },
        view2 = {
            viewType = 2,  -- 1,排名，2奖励
            viewInfoMsg = "continuedcost.global.reward",         -- 拉取消息
            btnName = getLang("140041"),
        },
    }
    local view = Drequire("game.rank.ActivityRankListView"):create(data)
    PopupViewController:addPopupInView(view)
end

return ConsumeActivityView

