

local superClass = Drequire("game.CommonPopup.commonRank.CommonRankView")

local CsmodRankView = class("CsmodRankView",superClass)

-- 栏目标题配置
local columnTile = {
    ['Csmod_store_mall'] = "108101;620073;102139", -- 108101=领主 620073=玩家杯数 102139=奖励
}

-- tips配置
local tipsTile = {
    ['Csmod_store_mall'] = "221125", -- 221125 每小时刷新一次
}

function CsmodRankView:createTitleCellData()
    local titleInfo = string.split(columnTile[self.m_type],";") 
    local dialogId1 = titleInfo[1] or "108101" -- 108101=领主
    local dialogId2 = self.m_powerStr --titleInfo[2] or "182091" -- 182091=本期积分
    local dialogId3 = titleInfo[3] or "102139" -- 102139=奖励
    local dialogTips
    local tipsId = tipsTile[self.m_type]
    if string.find(tipsId, ";") then 
        local tipsInfo = string.split(tipsId,";")   
        if self.m_viewType == 1 then    -- 本服   
            dialogTips = tipsInfo[1] or "660025"
        else                            -- 全服
            dialogTips = tipsInfo[2] or "660024"
        end

    else
        dialogTips = tipsId -- 每10分钟刷新一次
    end
    local titleCellData = {
        type = 3,
        parent = self,
        data = {
            name = getLang(dialogId1),
            power = getLang(dialogId2),
            server = getLang(dialogId3),
            tips = getLang(dialogTips),
        }
    }
    return titleCellData
end

function CsmodRankView:setPowerLable( powerStr )
    local _ = self.ui and self.ui.m_tPowerLabel and self.ui.m_tPowerLabel:setString(powerStr)
end

function CsmodRankView:create(params,powerStr)
    local view = CsmodRankView.new(params)
    self.m_powerStr = powerStr
    view.createTitleCellData = self.createTitleCellData
    Drequire("game.CommonPopup.commonRank.CommonRankView_ui"):create(view,0,params.viewSize)
    if view:initView(params) then
        return view
    end
end

return CsmodRankView