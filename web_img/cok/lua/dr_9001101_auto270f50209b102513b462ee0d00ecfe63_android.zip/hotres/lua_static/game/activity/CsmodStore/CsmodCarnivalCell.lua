local CsmodCarnivalCell = class("CsmodCarnivalCell", Drequire("game.shop.ShopMallCell"))

function CsmodCarnivalCell:create()
    local r = CsmodCarnivalCell.new("game.activity.CsmodStore.CsmodStoreCell_ui", "CsmodStore_BuyConfirm")
    r.ui.m_desLabel:setVisible(false)
    r.refreshCell = self.refreshCell
    return r
end

function CsmodCarnivalCell:refreshCell(info , idx) 
    self.m_info = info
    local shopData = info
    local createDataItemType = 0

    local itemId = shopData:getBuyItemId()
    createDataItemType = shopData:getItemType()
    -- 显示图标（带tip）
    local itemData = {
        type = createDataItemType,
        itemId = itemId,
        num = 1
    }

    LibaoCommonFunc.createDataItemTouchNode({
                itemData = itemData,
                iconNode = self.ui.m_iconNode,
                iconSize = 70,
                numLabel = nil,
                -- beTouch = false,   --默认可以触摸
                -- -- touchParentNode = self.m_info.parent,
                beTouch = true,   --默认可以触摸
                touchParentNode = self:getParent(),
                })

    -- local name = CCCommonUtilsForLua:call("getNameById", tostring(itemId))
    -- self.ui.m_nameLabel:setString(tostring(name))
    --装备
    if createDataItemType == 1 then
        local name = CCCommonUtilsForLua:call("getPropByIdGroup", "equipment", tostring(itemId), "name")
        local desc = CCCommonUtilsForLua:call("getPropByIdGroup", "equipment", tostring(itemId), "description")
        self.ui.m_nameLabel:setString(getLang(name))
        self.ui.m_desLabel:setString(getLang(desc))
    else
        local toolInfo = ToolController:call("getToolInfoForLua", atoi(itemId))
        if toolInfo then
            local name = toolInfo:call("getName")
            local desc = toolInfo:getProperty("des")
            self.ui.m_nameLabel:setString(name)
            self.ui.m_desLabel:setString(getLang(desc))
        end
    end

    -- 显示购买按钮的状态
    local canBuyNum = shopData:getAllCanBuyNum()
    local hasBuyNum = shopData:getHasBuyNum()
    local conditionOk = self:checkBuyCondition()
    if canBuyNum > 0 and hasBuyNum >= canBuyNum then
        self.ui.m_buyButton:setEnabled(false)
    else
        self.ui.m_buyButton:setEnabled(conditionOk)
    end

    -- 显示购买数量信息 服务当buyTimes为0时会发一个极大值,21亿左右,这里用0xffffff 限定购买次数
    if canBuyNum > 0 and canBuyNum < 0xffffff then
        self.ui.m_numNode:setVisible(true)
        self.ui.m_lLabel:setString(hasBuyNum)
        self.ui.m_rLabel:setString(canBuyNum)
        self.ui.m_lineLabel:setString('/')
    else
        self.ui.m_numNode:setVisible(false)
    end

    if shopData:checkBeHot() then
        self.ui.m_hotSprite:setVisible(true)
    else
        self.ui.m_hotSprite:setVisible(false)
    end

    -- 显示消耗道具图标
    local comumeItemID = shopData:getCurrencyId()
    if tonumber(comumeItemID) > 0 then
        local pic = CCCommonUtilsForLua:call("getIcon", tostring(comumeItemID))
        local icon = CCLoadSprite:call("createSprite", pic, CCLoadSpriteType.CCLoadSpriteType_RESOURCE)
        CCCommonUtilsForLua:setSpriteMaxSize(icon, 36, true)
        self.ui.m_itemNode1:addChild(icon)

        self.ui.m_itemNumLabel:setString('X' .. shopData:getItemSellPrice())
    end
    --子类展示其他信息
    self:showOther()
end

return CsmodCarnivalCell