
-----------
local AllianceQuicklyKillMonsterInfoCmd = class("AllianceQuicklyKillMonsterInfoCmd", LuaCommandBase)

function AllianceQuicklyKillMonsterInfoCmd:ctor(cb)
    self.super.ctor(self, "monsterhunter.getInfo")
	self.cb = cb
	MyPrint("AllianceQuicklyKillMonsterInfoCmd new")
end
function AllianceQuicklyKillMonsterInfoCmd:handleReceive(dict)
    local tbl = self:parseMsg(dict)
	if type(tbl) == "boolean" or tbl == nil then
		return tbl
	end
	if self.cb then
		self.cb(tbl)
	end
	return true
end
-----------
local AllianceQuicklyKillMonsterBuffCountCmd = class("AllianceQuicklyKillMonsterBuffCountCmd", LuaCommandBase)

function AllianceQuicklyKillMonsterBuffCountCmd:ctor(cb)
    self.super.ctor(self, "monsterhunter.buff")
	self.cb = cb
	MyPrint("AllianceQuicklyKillMonsterBuffCountCmd new")
end
function AllianceQuicklyKillMonsterBuffCountCmd:handleReceive(dict)
    local tbl = self:parseMsg(dict)
	if type(tbl) == "boolean" then
		return tbl
	end
	if self.cb then
		self.cb(tbl)
	end
	return true
end
----------

local AllianceQuicklyKillMonsterGetRewardCmd = class("AllianceQuicklyKillMonsterGetRewardCmd", LuaCommandBase)

function AllianceQuicklyKillMonsterGetRewardCmd:ctor(uuid, cb)
    self.super.ctor(self, "monsterhunter.reward")
	self:putParam("uuid", CCString:create(uuid))
	self.cb = cb
	MyPrint("AllianceQuicklyKillMonsterGetRewardCmd new")
end
function AllianceQuicklyKillMonsterGetRewardCmd:handleReceive(dict)
    local tbl = self:parseMsg(dict)
	if type(tbl) == "boolean" then
		return tbl
	end
	if self.cb then
		self.cb(tbl)
	end
	return true
end


----------------------cmd end----------------


 local AllianceQuicklyKillMonsterController = class("AllianceQuicklyKillMonsterController")
local   AllianceQuicklyKillMonsterInstance =   AllianceQuicklyKillMonsterInstance or nil
function AllianceQuicklyKillMonsterController.getInstance()
    if   AllianceQuicklyKillMonsterInstance == nil then
          AllianceQuicklyKillMonsterInstance = AllianceQuicklyKillMonsterController.new()
    end
    return   AllianceQuicklyKillMonsterInstance
end

function AllianceQuicklyKillMonsterController:reqQuicklyKillMonsterInfo()
    AllianceQuicklyKillMonsterInfoCmd.new(function(result) 
        self:handleQuicklyKillMonsterInfo(result)
    end):send()
end

function AllianceQuicklyKillMonsterController:handleQuicklyKillMonsterInfo(result)
    self.activityInfo = result

    -- if not result or tonumber(result.state or 0) == 0 then
    --     return
    -- end
    
    -- local totalScoreData = {
    --     param1 = self:getProgressViewData(result.personalReward, result.todayScore), 
    --     param2 = self:getProgressViewData(result.personalReward, result.allianceScore), 
    --     param3 = result.todayEndTime or 0, 
    --     param4 = result.rewardTime or 0,
    --     param5 = result.todayScore or 0,
    --     param6 = result.allianceScore or 0,
    --     processTitle1 = getLang("182202"),
    --     processTitle2 = getLang("182203"),
    -- }
    -- self:rankCtl():setDataByKey("totalScoreData",totalScoreData)

    -- local methodSprs = {
    --     [1] = "ico107109_small.png",
    -- }
    -- local methodNames = {
    --     [1] = "4510245",
    -- }
    -- local methodBtnLabels = {
    --     [1] = "221093",
    -- }
    -- local methodBtnDesc = {
    --     [1] = "221093",
    -- }
    -- local methodScore = {
    --     [1] = self:myTotalScore(),
    -- }
    -- local methodBtnJump = {
    --     [1] = {go_type = 12, targetId = 0},
    -- }
    -- local methodData = {
    --     param1 = methodSprs,
    --     param2 = methodNames,
    --     param3 = methodScore,
    --     param4 = methodBtnLabels,    
    --     param5 = methodBtnDesc,
    --     param6 = methodBtnJump     
    -- }

    -- self:rankCtl():setDataByKey("methodData",methodData)

    self.addEffectTimes = self.activityInfo and self.activityInfo.buffCount
    self:setMainCityNpcLeaderInfo()  
    --整理完毕，通知刷新界面
    CCSafeNotificationCenter:call("postNotification", "msg.AllianceQuicklyKillMonsterView.refreshView") 
end

function AllianceQuicklyKillMonsterController:activityEndAt()
    if self.activityInfo then
        return tonumber(self.activityInfo.endTime)
    end
    return 0
end

function AllianceQuicklyKillMonsterController:myRankOfFullServer()
    if self:getStateOpen() ~= 1 then
        return 0
    end
    if self.activityInfo then
        return tonumber(self.activityInfo.globalRank)
    end
    return 0
end

function AllianceQuicklyKillMonsterController:myRankOfMyServer()
    if self:getStateOpen() ~= 1 then
        return 0
    end
    
    if self.activityInfo then
        return tonumber(self.activityInfo.localRank)
    end
    return 0
end

function AllianceQuicklyKillMonsterController:myTodayScore()
    if self:getStateOpen() ~= 1 then
        return 0
    end
    if self.activityInfo then
        return tonumber(self.activityInfo.todayScore)
    end
    return 0
end

function AllianceQuicklyKillMonsterController:myTotalScore()
    if self:getStateOpen() ~= 1 then
        return 0
    end
    if self.activityInfo then
        return tonumber(self.activityInfo.totalScore)
    end
    return 0
end

function AllianceQuicklyKillMonsterController:allianceScore()
    if self:getStateOpen() ~= 1 then
        return 0
    end
    if self.activityInfo then
        return tonumber(self.activityInfo.allianceScore)
    end
    return 0
end

function AllianceQuicklyKillMonsterController:getActScoreInfo()
    local actData
    if self:getStateOpen() == 1 then
        local info = self.activityInfo
        local todayEndTime = info.todayEndTime or 0
        if tonumber(todayEndTime) > tonumber(self:activityEndAt()) then
            todayEndTime = self:activityEndAt()
        end
        actData = {
            processTitle1 = getLang("182202"),
            processTitle2 = getLang("182203"),
            singleProcess_num = info.todayScore,
            totalProcess_num = info.allianceScore,
            todayScoreData = self:getProgressViewData(info.personalReward, info.todayScore),
            totalScoreData =  self:getProgressViewData(info.allianceReward, info.allianceScore), 
            curEndTime = todayEndTime,
            totalEndTime = self:activityEndAt() -- info.rewardTime,
        }
    end
    
    return {
        actId = self:getActivityId(),
        openState = self:getStateOpen(),
        data = actData
    }
end

function AllianceQuicklyKillMonsterController:getActMethodInfo()
    local actData
    if self.activityInfo then
        actData = {
            methodSprNames = {
                "w_res_monster.png"
            },
            methodNames = {
                "4510245"
            },
            methodPowers = {
                self:myTodayScore()
            },
            btnLabels = {
                "221093"
            },
            btnDess = {
                "221093"
            },
            btnJumps = {
                {go_type = 12, targetId = 0}
            },  
        }
    end
    return {
        actId = self:getActivityId(),
        title = "182211",
        data = actData
    }
end

function AllianceQuicklyKillMonsterController:getProgressViewData(rewardArr, process)
    if not rewardArr or not process then
        return
    end
    local data = {}
    for k, v in pairs(rewardArr or {}) do
        local one = {
            uuid = v.uuid,
			reward = v.rewardId,
			-- state = v.has_got,
			target = v.score,
			curPro = tonumber(process),
        } 
        if tonumber(process) >= tonumber(v.score) then
            if tonumber(v.state) == 0 then
                one.state = "2" 
            else
                one.state = "1"
            end
        else
            if tonumber(v.state) == 0 then
                one.state = "0"
            else
                one.state = "3"
            end
        end
		data[#data + 1] = one
	end

	if data and #(data) > 0 then
		table.sort(
			data,
			function(a, b)
				return tonumber(a.target) < tonumber(b.target)
			end
		)
		local len = #(data)
		for i = 1, len do --插入bottom数据
            data[i].getRewardFunc = function()
                AllianceQuicklyKillMonsterGetRewardCmd.new(data[i].uuid, function(result)
                    createTableFlyReward(result.reward)
                end):send()
			end
			if i == 1 then
				data[1].bottom = "0"
			else
				data[i].bottom = data[i - 1].target
			end
		end
	end
	return data
end

function AllianceQuicklyKillMonsterController:getAllServerFirstInfo(serverType)
    local str = (serverType == nil or  serverType == "first") and "first" or "localFirst"
    if self.activityInfo and self.activityInfo[str] then
        local info = self.activityInfo[str]
        if type(info) == "table" and info.u_info then
            local ret = {
                playerUid = info.u_info.uid,
                playerName = info.u_info.name,
                allianceName = info.u_info.allianceName,
                tipLabel = getLang("182219"),
                head_pic = info.u_info.pic,
                head_picVer = info.u_info.picVer,
                picfraId = info.u_info.picfraId,
            }
            return ret
        else
            return self:getStateOpen()
        end
    else
        return self:getStateOpen()
    end
end

function AllianceQuicklyKillMonsterController:getActivityId()
    return "57405"
end

function AllianceQuicklyKillMonsterController:setMainCityNpcLeaderInfo()
    local firstInfo = self:getAllServerFirstInfo()
    if firstInfo and type(firstInfo) == "table" then
        local leaderInfo = {
            uid = firstInfo.playerUid,
            name = firstInfo.playerName,
            pic = firstInfo.head_pic,
            picVer = firstInfo.head_picVer,
            picfraId = firstInfo.picfraId,
        }
        local npcInfo = CityNpcController.getInstance():getNpcInfo(self:getActivityId())
        npcInfo:setLeaderInfo(leaderInfo)
        CCSafeNotificationCenter:call("postNotification", "msg.COSRankActNpc.refresh")
    end
end

function AllianceQuicklyKillMonsterController:getStateOpen()
    if not self.activityInfo or not self.activityInfo.state then
        return 0        -- 未确定
    elseif tonumber(self.activityInfo.state) == 0 then
        if self.activityInfo.first then
            return 3        -- 已结束
        else
            return 2        -- 未开始
        end
    else
        if self:activityEndAt() then
            local now = getTimeStamp()
            if tonumber(self:activityEndAt() or 0) / 1000 < tonumber(now) then
                return 3
            end 
        end
        return 1            -- 正在进行
    end
end

function AllianceQuicklyKillMonsterController:requestBuffCount()
    AllianceQuicklyKillMonsterBuffCountCmd.new(function (tbl)
        self.addEffectTimes = tbl.buffCount or 0
        CCSafeNotificationCenter:call("postNotification", "msg.AllianceQuicklyKillMonsterView.refreshBuffCount")
    end):send()
end

function AllianceQuicklyKillMonsterController:getAddEffectTimes()
    return tonumber(self.addEffectTimes or 0)
end

-- function AllianceQuicklyKillMonsterController:rankCtl()
--     return require("game.CommonPopup.RankActComponent.RankActDataController").getInstance()
-- end

return AllianceQuicklyKillMonsterController