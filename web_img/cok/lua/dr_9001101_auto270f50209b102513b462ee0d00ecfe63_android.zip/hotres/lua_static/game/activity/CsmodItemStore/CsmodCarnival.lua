local CsmodCarnival = class("CsmodCarnival",
    function()
        return PopupBaseView:create()
    end
)

CsmodCarnival.__index = CsmodCarnival

local GoldGroupBuyController = Drequire("game.activity.GoldGroupBuy.GoldGroupBuyController").new()

function CsmodCarnival:create(params)
    local view = CsmodCarnival.new()
    local ret = Drequire("game.activity.CsmodItemStore.CsmodCarnival_ui"):create(view, 8)

    if view:initView(params) then
        return view
    end
end

--设置需要进入的子页
function CsmodCarnival:setOpenParams(openParams)
    self.openParams = openParams
end

function CsmodCarnival:showDetailByOpenParams( )
    if not self.openParams then 
        return false
    end
    local openId = self.openParams.mainViewId
    if not openId then 
        self.openParams = nil 
        return false
    end
    local JumpPageController = Drequire("game.JumpPageController")
    if tonumber(openId) == JumpPageController.ActView57189_SubPage_HaoHuaShop then 
        self:toggleIdx(2)
        self.openParams = nil 
        return true
    end
    self.openParams = nil 
    return false
end

function CsmodCarnival:initView(params)
    self:registerTouchFuncs()
    self.ShopMallController = Drequire("game.shop.ShopMallController").new(22)
    self.m_convertIns = ConvertHappyCsmodContrllerInst
    self.m_boxIdDesc = {"freeItemId","payItemId"}
    -- self.actObj = params.actObj
    self.activityId = params.activityId

    self.m_openRank = self.m_convertIns:isRankOpen()

    self.m_switchBtns = self.m_openRank and {self.ui.m_defaultButton,self.ui.m_luxuryButton,self.ui.m_rankButton} or 
    {self.ui.m_defaultButton,self.ui.m_luxuryButton}

    local titles = {"9440072","9440073","9800015"}
    for k,v in ipairs(self.m_switchBtns) do
        CCCommonUtilsForLua:setButtonTitle(v, getLang(titles[k]))
    end

    self.m_contents = self.m_openRank and {self.ui.m_listTableView_Default,self.ui.m_listTableView_Luxury,self.ui.m_rankNode} or 
    {self.ui.m_listTableView_Default,self.ui.m_listTableView_Luxury}

    if not self.m_openRank then
        local p = {10,630}
        self.ui.m_rankBtnNode:setVisible(false)
        for i,v in ipairs(self.m_switchBtns) do
            v:setPreferredSize(cc.size(310,61))
            v:setPositionX(p[i])
        end
        self.ui.m_sep1:setPositionX(320)
    else
        self:addRankView()
    end


    self:refreshAddImage()
   return true
end

function CsmodCarnival:onInfoResp( tbl )
    
end

function CsmodCarnival:onBuyResp( tbl )
    
end

function CsmodCarnival:initTableViewByOwner()
    local TableViewSmoker = Drequire("Editor.TableViewSmoker")
    TableViewSmoker:createView(self.ui, "m_listTableView_Default", "game.activity.CsmodItemStore.CsmodCarnivalCell", 1, 10, "CsmodItemStoreCell")
    TableViewSmoker:createView(self.ui, "m_listTableView_Luxury", "game.activity.CsmodItemStore.CsmodCarnivalCell", 1, 10, "CsmodItemStoreCell")
end

function CsmodCarnival:onEnter()
    local act = ActivityController:call("getActObj", self.activityId)
    self:setTitleName(act and act:getProperty("name") or getLang("9440071"))
    UIComponent:call("getInstance"):call("showPopupView", 8)

    self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:update(dt) end, 1, false)
    self:update()

    -- 获取数据
    registerScriptObserver(self, self.getDataBack, self.ShopMallController.m_getShopItemnotifyKey)
    registerScriptObserver(self, self.getBuyDataBack, self.ShopMallController.m_buyShopItemNotifyKey)
    registerScriptObserver(self, self.onConfirmBuy, "CsmodItemStore_BuyConfirm")

    self:TryGetData()
    if not self:showDetailByOpenParams() then
        -- self:showDetail(false)
        self:toggleIdx(1)
    end
end

function CsmodCarnival:onExit()
    self:getScheduler():unscheduleScriptEntry(self.m_entryId)

    unregisterScriptObserver(self, self.ShopMallController.m_getShopItemnotifyKey)
    unregisterScriptObserver(self, self.ShopMallController.m_buyShopItemNotifyKey)
    unregisterScriptObserver(self, "CsmodItemStore_BuyConfirm")
end

function CsmodCarnival:update(dt)
    local act = ActivityController:call("getActObj", self.activityId)
    if act then
        local endTime = tonumber(act:getProperty("endTime"))
        local offTime = endTime - getWorldTime()
        if offTime > 0 then
            self.ui.m_timeLabel:setString(format_time(offTime))
        else
            self.ui.m_timeLabel:setString(format_time(0))-- PopupViewController:call("removeLastPopupView")
        end
    end
end

function CsmodCarnival:onTouchBegan(x, y)
    return true
end

function CsmodCarnival:onTouchMoved(x, y)

end

function CsmodCarnival:onTouchEnded(x, y)
end

function CsmodCarnival:getDataBack(fromBuy)
    local shopTbl = self.ShopMallController:getShopItemInfo()
    local defaultShopData = {}
    local luxuryShopData = {}
    self.ui.m_timeNode:setVisible(true)
    -- sort by display
    -- table.sort(shopTbl, function(a, b) return tonumber(a.m_display) < tonumber(b.m_display) end)
    local infoData = self.ShopMallController:getLastInfoRespData()
    self.defaultItemID = infoData[self.m_boxIdDesc[1]]
    self.luxuryItemID = infoData[self.m_boxIdDesc[2]]
    
    for key, shopItem in pairs(shopTbl) do
        -- local info = {
        --         data = shopItem, 
        --         parent = self.ui.m_listNode,
        --     }
        if shopItem.m_info.currId == self.defaultItemID then
            defaultShopData[#defaultShopData + 1] = shopItem
            -- self.defaultItemID = shopItem:getCurrencyId()
        else
            luxuryShopData[#luxuryShopData + 1] = shopItem
            -- self.luxuryItemID = shopItem:getCurrencyId()
        end
        --end
    end

    

    -- dump(defaultShopData, "CsmodCarnival:getDataBack() defaultShopData is: ")
    -- dump(luxuryShopData, "CsmodCarnival:getDataBack() luxuryShopData is: ")

    -- 设置列表显示内容
    self.ui:setTableViewDataSource("m_listTableView_Default", defaultShopData)
    self.ui:setTableViewDataSource("m_listTableView_Luxury", luxuryShopData)

    self:UpdateConsumeItemIconAndCount()

    --
    if not fromBuy then
        self.m_lastBoxProgressData = nil
        for i=1,2 do
            self:refreshBoxProgress(self:getBoxProgressData(i,self.ShopMallController:getLastInfoRespData()),i)
        end
    end
end

function CsmodCarnival:getBoxProgressData( idx,infoData )
    idx = math.numInRange(idx,1,2)
    if self.m_lastBoxProgressData and self.m_lastBoxProgressData[idx] then
        return self.m_lastBoxProgressData[idx]
    end

    -- local infoData = self.ShopMallController:getLastInfoRespData()
    infoData = infoData or self.ShopMallController:getLastInfoRespData()
    if not infoData then
        return
    end
    local boxData = self:parseBoxData(infoData)
    -- local keys = table.keys(boxData)
    self.m_boxData = boxData
    local bd = boxData[infoData[self.m_boxIdDesc[idx]]]

    self.m_lastBoxProgressData = self.m_lastBoxProgressData or {}
    self.m_lastBoxProgressData[idx] = self:getProgressData(bd)
    return self.m_lastBoxProgressData[idx]
end

function CsmodCarnival:toggleBox( idx )
    local isShow = idx < 3
    local box_uis = self.m_boxUis
    if not box_uis then
        box_uis = {self.ui.m_boxNode,self.ui.m_costBg,self.ui.m_itemNumLabel}
        self.m_boxUis = box_uis
    end
    for _,v in ipairs(self.m_boxUis) do
        v:setVisible(isShow)
    end
    if isShow then
        self:refreshBoxProgress(self:getBoxProgressData(idx),idx)
    end
end

function CsmodCarnival:getProgressData(t_data)
    local nowProgress, maxProcess = tonumber(t_data.score),tonumber(t_data.boxScoreConfig[#t_data.boxScoreConfig][2])
    nowProgress = math.min(nowProgress,maxProcess)

    --[[
        这里的处理逻辑是: boxStr 1;3;5 表示 1,3,5宝箱已经领过
    ]]
    local boxStats = {}
    local boxStrArr = not string.isNilOrEmpty(t_data.boxStr) and string.split(t_data.boxStr,';')
    --[[
        先将1;3;5置为1,1表示已经领过
    ]]
    if boxStrArr then
        for _,v in ipairs(boxStrArr) do
            boxStats[tonumber(v)] = '1'
        end
    end
    --[[
        再将除了1;3;5的其它位置 置为0,0表示未领过
    ]]
    for i,_ in ipairs(t_data.boxScoreConfig) do
        boxStats[i] = boxStats[i] or '0'
    end

    local data = {}

    for k, v in ipairs(t_data.boxConfig) do
        local one = {
            -- fetchId = v.target_id,
            reward = v[2], 
            target = t_data.boxScoreConfig[k][2], --v.target_score, 
            curPro = nowProgress, 
            maxPro = maxProcess,
            state = boxStats[k],
        }
        
        table.insert(data, one)
    end
    
    local function sortfunc(a,b)
        return tonumber(a.target) < tonumber(b.target) 
    end
    if data and #(data) > 0 then
        table.sort(data, sortfunc)
        local len = #(data)
        for i = 1, len do --插入bottom数据
            -- data[i].getRewardFunc = function()
            --     EquipUpgradeCarnivalFetchRewardCmd.new(data[i].fetchId, function (result)
            --         createTableFlyReward(result.reward)
            --     end):send()
            -- end
            if i == 1 then
                data[1].bottom = "0"
            else
                data[i].bottom = data[i - 1].target
            end
        end
    end
    return data
end

function CsmodCarnival:parseBoxData( infoData )
    local box_cfg = self.m_box_cfg
    if not box_cfg then
        box_cfg = {{"boxConfig","|;"},{"boxScoreConfig","|;"},{"boxStr"},{"score"}}
        self.m_box_cfg = box_cfg
    end

    local res = {}
    for k,v in ipairs(box_cfg) do
        local k1 = v[1]
        local pattern = "%d+_" .. k1
        local split = v[2]

        for k3,v3 in pairs(infoData) do
            local tn = string.findNumWithPattern(k3,pattern)

            if tn then
                -- cclog("string.find(k3,pattern) %s %s",tn,k3)
                local s_tn = tostring(tn)
                if not res[s_tn] then
                    res[s_tn] = {}
                end

                res[s_tn][k1] = split and string.splitNSep(v3,split) or v3
            end
        end
    end
    return res
end

function CsmodCarnival:UpdateConsumeItemIconAndCount()
    local consumItemID = (self.ui.m_listTableView_Default:isVisible() == true) and self.defaultItemID or self.luxuryItemID
    if consumItemID == nil then
        return
    end

    comumeItemID = tonumber(consumItemID)
    if comumeItemID > 0 then
        self.ui.m_itemPicNode:removeAllChildren()
        local pic = CCCommonUtilsForLua:call("getIcon", tostring(comumeItemID))
        
        local icon = CCLoadSprite:call("createSprite", pic, CCLoadSpriteType.CCLoadSpriteType_RESOURCE)
        CCCommonUtilsForLua:setSpriteMaxSize(icon, 36, true)
        self.ui.m_itemPicNode:addChild(icon)

        local tinfo = ToolController:call("getToolInfoForLua", comumeItemID)
        if tinfo == nil then
            return
        end

        local count = tinfo:call("getCNT")
        self.ui.m_itemNumLabel:setString('X' .. count)
    end
end

function CsmodCarnival:getBuyDataBack()
    local offset1 = self.ui.m_listTableView_Default:getContentOffset()
    local offset2 = self.ui.m_listTableView_Luxury:getContentOffset()
    self:getDataBack(true)
    self.ui.m_listTableView_Default:setContentOffset(offset1)
    self.ui.m_listTableView_Luxury:setContentOffset(offset2)

    self:UpdateConsumeItemIconAndCount()

    self.m_lastBoxProgressData = nil
    for i=1,2 do
        self:refreshBoxProgress(self:getBoxProgressData(i,self.ShopMallController:getLastBuRespData()),i)
    end
end

function CsmodCarnival:onDefaultButtonClick()
    self:toggleIdx(1)
end

function CsmodCarnival:onLuxuryButtonClick()
    self:toggleIdx(2)
end

function CsmodCarnival:onRankButtonClick()
    self:toggleIdx(3)
end

function CsmodCarnival:toggleIdx( idx )
    idx = idx or 1
    if self.m_curIdx == idx then
        return
    end

    self.m_curIdx = idx
    for i,v in ipairs(self.m_switchBtns) do
        v:setEnabled( i ~= idx )
    end

    for i,v in ipairs(self.m_contents) do
        v:setVisible( i == idx )
    end

    self:toggleBox(idx)
    if idx < 3 then
        self:UpdateConsumeItemIconAndCount()
        self.ui.m_activityNode:setVisible(true)
        
    elseif idx == 3 then
        self.ui.m_activityNode:setVisible(false)
        -- local content_node = self.m_randPage
        -- if not content_node then
        --     local params = self:getRandkParams()
        --     local winSize = params.viewSize

        --     local rankStr = self.luxuryItemID and getLang("9800011",utils.getItemNameByItemId(self.luxuryItemID)) or getLang("default")
        --     content_node = Drequire("game.activity.CsmodItemStore.CsmodRankView"):create(params,rankStr)
        --     content_node:setPosition(cc.p(0, winSize.height - content_node:getContentSize().height))
            
        --     content_node:setPowerLable(rankStr)
        --     self.ui.m_rankNode:addChild(content_node)
        -- end
    end

end

-- function CsmodCarnival:getRandkParams(  )
--     local winSize = self.ui.m_rankNode:getContentSize()
--     local params = {
--         type = "Csmod_item_mall",
--         viewType = 2,-- 全服
--         viewSize = winSize,
--         pageSize = 20,
--         selfId = utils.getSelfUid()
--     }
--     return params
-- end

function  CsmodCarnival:TryGetData()
    -- self.ShopMallController:getSellItem("21")
   self.ShopMallController:getSellItem()
end

function CsmodCarnival:onConfirmBuy(dict)
    local tbl = dictToLuaTable(dict)
    if tbl.shopId and tbl.count then
        self.ShopMallController:buyShopItem(tostring(tbl.shopId), tonumber(tbl.count))
    end
end

function CsmodCarnival:refreshAddImage(  )
    local act = ActivityController:call("getActObj", self.activityId)

    -- 活动图
    if act then
        local spr = nil
        local sf = act:getAdFrame()
        if sf ~= nil then
            spr = cc.Sprite:createWithSpriteFrame(sf)
        else
            spr = CCLoadSprite:call("createSprite", "activity_ad_beiyong.png")
        end
        local size = self.ui.m_picNode:getContentSize()
        local clipNode = CCClipNode:call("create", size.width, size.height)
        clipNode = tolua.cast(clipNode, "cc.Node")

        self.ui.m_picNode:addChild(clipNode)
        spr:setPosition(cc.p(size.width * 0.5, size.height * 0.5))
        clipNode:addChild(spr)
    end
end

function CsmodCarnival:refreshBoxProgress( _precessData,idx )
    idx = idx or 1
    if idx > 2 then
        return
    end
    if _precessData and #(_precessData) > 0 then
        local progressArr = self.m_progressArr
        if not progressArr then
            progressArr = {}
            self.m_progressArr = progressArr
        end

        local t_view = progressArr[idx]
        local need_create = (not t_view or t_view.m_lastData ~= _precessData)
        if need_create then
            local _view = Drequire("game.CommonPopup.CommonProgressView").create(_precessData, 580)
            if _view then
                if t_view then
                    self.ui.m_boxNode:removeChildByTag(idx)
                end
                _view.m_lastData = _precessData
                progressArr[idx] = _view
                _view:setTag(idx)
                self.ui.m_boxNode:addChild(_view)
            end
        -- else
        --     for i=1,2 do
        --         local _v = progressArr[i]
        --         if _v then
        --             _v:setVisible(i == idx)
        --         end
        --     end
        end

        for i=1,2 do
            local _v = progressArr[i]
            if _v then
                _v:setVisible(i == self.m_curIdx)
            end
        end
    end

    self:refreshMyCost(idx)
end

function CsmodCarnival:refreshMyCost( idx )
    if idx > 2 then
        return
    end
    local consumItemID = (self.ui.m_listTableView_Default:isVisible() == true) and self.defaultItemID or self.luxuryItemID
    if consumItemID == nil then
        return
    end

    self.ui.m_mycost:setString(getLang("9800010",utils.getItemNameByItemId(consumItemID),self.m_boxData[consumItemID].score))
end

function CsmodCarnival:showDetail(isDefaultOrLuxury)
    -- dump(isDefaultOrLuxury, "CsmodCarnival:showDetail isDefaultOrLuxury is:")
    assert(false)
    if (isDefaultOrLuxury) then
        self.ui.m_defaultButton:setEnabled(true)
        self.ui.m_luxuryButton:setEnabled(false)
    else
        self.ui.m_defaultButton:setEnabled(false)
        self.ui.m_luxuryButton:setEnabled(true)
    end

    if(isDefaultOrLuxury) then
        self.ui.m_listTableView_Default:setVisible(false)
        self.ui.m_listTableView_Luxury:setVisible(true)
    else
        self.ui.m_listTableView_Default:setVisible(true)
        self.ui.m_listTableView_Luxury:setVisible(false)
    end

    local act = ActivityController:call("getActObj", self.activityId)

    -- 活动图
    if act then
        local spr = nil
        local sf = act:getAdFrame()
        if sf ~= nil then
            spr = cc.Sprite:createWithSpriteFrame(sf)
        else
            spr = CCLoadSprite:call("createSprite", "activity_ad_beiyong.png")
        end
        local size = self.ui.m_picNode:getContentSize()

        local clipNode = CCClipNode:call("create", size.width, size.height)
        clipNode = tolua.cast(clipNode, "cc.Node")

        self.ui.m_picNode:addChild(clipNode)

        spr:setPosition(cc.p(size.width * 0.5, size.height * 0.5))
        clipNode:addChild(spr)
    end
    
    -- 两个按钮的文字
    -- CCCommonUtilsForLua:setButtonTitle(self.ui.m_defaultButton, getLang("9440072"));
    -- CCCommonUtilsForLua:setButtonTitle(self.ui.m_luxuryButton, getLang("9440073"));
end

function CsmodCarnival:onClickRecord()
    -- local text = getLang("4250196")
    local text = getLang("9440550")
    YesNoDialog:show(text)
end

function CsmodCarnival:addRankView()
    local configLocal = {
        name = "Csmod_item_mall",
        id = "35366001",
        title = "182045"
    }
    local configGlobal = {
        name = "Csmod_item_mall",
        id = "35366002",
        title = "182044"
    }
    local viewSize = self.ui.m_rankNode:getContentSize()
    local rankView 
    if CCCommonUtilsForLua:isFunOpenByKey("happy_mall_local_rank") and 
        CCCommonUtilsForLua:isFunOpenByKey("happy_mall_global_rank") then
        rankView = Drequire("game.CommonPopup.commonRank.CommonRankView"):createWithTwoGroup(
            configLocal, configGlobal, viewSize
        )
    else
        if CCCommonUtilsForLua:isFunOpenByKey("happy_mall_local_rank") then
            rankView = Drequire("game.CommonPopup.commonRank.CommonRankView"):createWithConfigId(
                configLocal.id, configLocal.name, viewSize
            )
        else
            rankView = Drequire("game.CommonPopup.commonRank.CommonRankView"):createWithConfigId(
                configGlobal.id, configGlobal.name, viewSize
            )
        end
    end
    if rankView then
        if self.rankView then
            self.ui.m_rankNode:removeChild(self.rankView)
        end
        self.rankView = rankView
        self.ui.m_rankNode:addChild(self.rankView)
    end
end

return CsmodCarnival



