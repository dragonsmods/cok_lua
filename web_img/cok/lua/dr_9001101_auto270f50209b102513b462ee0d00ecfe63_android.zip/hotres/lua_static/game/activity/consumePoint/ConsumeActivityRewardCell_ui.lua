----------------------------
-- Author: Elex
-- Date: 2017-05-27 16:42:56
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local ConsumeActivityRewardCell_ui = class("ConsumeActivityRewardCell_ui")

--#ui propertys


--#function
function ConsumeActivityRewardCell_ui:create(owner, viewType)
	local ret = ConsumeActivityRewardCell_ui.new()
	CustomUtility:LoadUi("ConsumeActivityRewardCell.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function ConsumeActivityRewardCell_ui:initLang()
end

function ConsumeActivityRewardCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function ConsumeActivityRewardCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return ConsumeActivityRewardCell_ui

