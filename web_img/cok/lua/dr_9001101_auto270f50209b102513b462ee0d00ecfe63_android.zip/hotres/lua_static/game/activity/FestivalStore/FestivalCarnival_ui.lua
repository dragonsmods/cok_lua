----------------------------
-- Author: Elex
-- Date: 2020-10-29 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local FestivalCarnival_ui = class("FestivalCarnival_ui")

--#ui propertys


--#function
function FestivalCarnival_ui:create(owner, viewType, paramTable)
	local ret = FestivalCarnival_ui.new()
	CustomUtility:LoadUi("FestivalCarnival.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function FestivalCarnival_ui:initLang()
end

function FestivalCarnival_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function FestivalCarnival_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function FestivalCarnival_ui:onDefaultButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onDefaultButtonClick", pSender, event)
end

function FestivalCarnival_ui:onLuxuryButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onLuxuryButtonClick", pSender, event)
end

function FestivalCarnival_ui:onRankButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onRankButtonClick", pSender, event)
end

function FestivalCarnival_ui:onClickRecord(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickRecord", pSender, event)
end

function FestivalCarnival_ui:onControlButton2(pSender, event)
	ButtonSmoker:forwardFunction(self, "onControlButton2", pSender, event)
end

function FestivalCarnival_ui:initTableView()
	TableViewSmoker:createView(self, "m_listTableView_Default", "game.activity.FestivalStore.FestivalStoreCell", 1, 10, "FestivalStoreCell")
	TableViewSmoker:createView(self, "m_listTableView_Luxury", "game.activity.FestivalStore.FestivalStoreCell", 1, 10, "FestivalStoreCell")
end

function FestivalCarnival_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return FestivalCarnival_ui

