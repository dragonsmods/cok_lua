local CsmodStoreView = class("CsmodStoreView",
    function()
        return PopupBaseView:create()
    end
)
CsmodStoreView.__index = CsmodStoreView

local ShopItemController = Drequire("game.shop.ShopItemController").new()
local GoldGroupBuyController = Drequire("game.activity.GoldGroupBuy.GoldGroupBuyController").new()

function CsmodStoreView:create()
    local view = CsmodStoreView.new()
    local ret = Drequire("game.activity.CsmodStore.CsmodStoreView_ui"):create(view, 8)

    if view:initView() then
        return view
    end
end

--设置需要进入的子页
function CsmodStoreView:setOpenParams(openParams)
    self.openParams = openParams
end

function CsmodStoreView:showDetailByOpenParams( )
    if not self.openParams then 
        return false
    end
    local openId = self.openParams.mainViewId
    if not openId then 
        self.openParams = nil 
        return false
    end
    local JumpPageController = Drequire("game.JumpPageController")
    if tonumber(openId) == JumpPageController.ActView57189_SubPage_HaoHuaShop then 
        self:showDetail(true)
        self.openParams = nil 
        return true
    end
    self.openParams = nil 
    return false
end

function CsmodStoreView:initView()

   self:registerTouchFuncs()

   return true
end

function CsmodStoreView:onEnter()
    self:setTitleName(getLang("8009801"))
    UIComponent:call("getInstance"):call("showPopupView", 8)

    self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:update(dt) end, 1, false)
    self:update()

    -- 获取数据
    registerScriptObserver(self, self.getDataBack, ShopItemController.m_getShopItemnotifyKey)
    registerScriptObserver(self, self.getBuyDataBack, ShopItemController.m_buyShopItemNotifyKey)
    registerScriptObserver(self, self.onConfirmBuy, "CsmodStore_BuyConfirm")

    self:TryGetData()
    if not self:showDetailByOpenParams() then
        self:showDetail(false)
    end
end

function CsmodStoreView:onExit()
    self:getScheduler():unscheduleScriptEntry(self.m_entryId)

    unregisterScriptObserver(self, ShopItemController.m_getShopItemnotifyKey)
    unregisterScriptObserver(self, ShopItemController.m_buyShopItemNotifyKey)
    unregisterScriptObserver(self, "CsmodStore_BuyConfirm")
end

function CsmodStoreView:update(dt)
    self.m_leftTime = 0
    if self.dailyLimit then
        local wt = getWorldTime()
        local offTime = 86400 - wt % 86400
        if offTime > 0 then
            self.ui.m_timeLabel:setString(format_time(offTime))
            self.m_leftTime = offTime
        end
    end
end

function CsmodStoreView:onTouchBegan(x, y)
    return true
end

function CsmodStoreView:onTouchMoved(x, y)

end

function CsmodStoreView:onTouchEnded(x, y)
end

function CsmodStoreView:getDataBack()
    local shopTbl = ShopItemController:getShopItemInfo()
    -- local ctl = CsmodStoreController:getShopItemInfo()
    local defaultShopData = {}
    local luxuryShopData = {}
    local isFirst = true
    -- sort by display
    table.sort(shopTbl, function(a, b) return tonumber(a.m_display) < tonumber(b.m_display) end)
    for key, shopItem in pairs(shopTbl) do
        --for i = 1, 3, 1 do -- for test
        if isFirst then
            self.dailyLimit = shopItem.m_buy_times_daily > 0
            self.ui.m_timeNode:setVisible(self.dailyLimit)
            isFirst = false
        end
        local info = {
                data = shopItem, 
                parent = self.ui.m_listNode,
            }
        if shopItem.m_page == "1" then
            defaultShopData[#defaultShopData + 1] = info
            self.defaultItemID = shopItem.m_value_item
        else
            luxuryShopData[#luxuryShopData + 1] = info
            self.luxuryItemID = shopItem.m_value_item
        end
        --end
    end

    -- 设置列表显示内容
    self.ui:setTableViewDataSource("m_listTableView_Default", defaultShopData)
    self.ui:setTableViewDataSource("m_listTableView_Luxury", luxuryShopData)

    self:UpdateConsumeItemIconAndCount()
end

function CsmodStoreView:UpdateConsumeItemIconAndCount()
    local consumItemID = (self.ui.m_listTableView_Default:isVisible() == true) and self.defaultItemID or self.luxuryItemID
    if consumItemID == nil then
        return
    end

    comumeItemID = tonumber(consumItemID)
    if comumeItemID > 0 then
        self.ui.m_itemPicNode:removeAllChildren()
        local pic = CCCommonUtilsForLua:call("getIcon", tostring(comumeItemID))
        
        local icon = CCLoadSprite:call("createSprite", pic, CCLoadSpriteType.CCLoadSpriteType_RESOURCE)
        CCCommonUtilsForLua:setSpriteMaxSize(icon, 36, true)
        self.ui.m_itemPicNode:addChild(icon)

        local tinfo = ToolController:call("getToolInfoForLua", comumeItemID)
        if tinfo == nil then
            return
        end

        local count = tinfo:call("getCNT")
        self.ui.m_itemNumLabel:setString('X' .. count)
    end
end

function CsmodStoreView:getBuyDataBack()
    local offset1 = self.ui.m_listTableView_Default:getContentOffset()
    local offset2 = self.ui.m_listTableView_Luxury:getContentOffset()
    self:getDataBack()
    self.ui.m_listTableView_Default:setContentOffset(offset1)
    self.ui.m_listTableView_Luxury:setContentOffset(offset2)

    self:UpdateConsumeItemIconAndCount()
end

function CsmodStoreView:onDefaultButtonClick()
    self:showDetail(false)    
    self:UpdateConsumeItemIconAndCount()
end

function CsmodStoreView:onLuxuryButtonClick()
    self:showDetail(true)
    self:UpdateConsumeItemIconAndCount()
end

function  CsmodStoreView:TryGetData()
    ShopItemController:getSellItem("200")
end

function CsmodStoreView:onConfirmBuy(dict)
    local tbl = dictToLuaTable(dict)
    if tbl.shopId and tbl.count then
        ShopItemController:buyShopItem(tostring(tbl.shopId), tonumber(tbl.count))
    end
end

function CsmodStoreView:showDetail(isDefaultOrLuxury)
    if (isDefaultOrLuxury) then
        self.ui.m_defaultButton:setEnabled(true)
        self.ui.m_luxuryButton:setEnabled(false)
    else
        self.ui.m_defaultButton:setEnabled(false)
        self.ui.m_luxuryButton:setEnabled(true)
    end

    if(isDefaultOrLuxury) then
        self.ui.m_listTableView_Default:setVisible(false)
        self.ui.m_listTableView_Luxury:setVisible(true)
    else
        self.ui.m_listTableView_Default:setVisible(true)
        self.ui.m_listTableView_Luxury:setVisible(false)
    end

    local act = ActivityController:call("getActObj", "5718901")

    -- 活动图
    if act then
        local sf = act:getAdFrame()
        if sf ~= nil then
            spr = cc.Sprite:createWithSpriteFrame(sf)
        else
            spr = CCLoadSprite:call("createSprite", "activity_ad_beiyong.png")
        end
        local size = self.ui.m_picNode:getContentSize()

        local clipNode = CCClipNode:call("create", size.width, size.height)
        clipNode = tolua.cast(clipNode, "cc.Node")

        self.ui.m_picNode:addChild(clipNode)

        spr:setPosition(cc.p(size.width * 0.5, size.height * 0.5))
        clipNode:addChild(spr)
    end
    
    -- 两个按钮的文字
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_defaultButton, getLang("8009804"));
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_luxuryButton, getLang("8009804"));

    -- Csmod_store_mall
    if CCCommonUtilsForLua:isFunOpenByKey("Csmod_store_mall") == false then
        local buttonHeight = self.ui.m_buttonNode:getContentSize().height
        self.ui.m_buttonNode:setVisible(false)
        self.ui.m_bannerNode:setPositionY(self.ui.m_bannerNode:getPositionY() + buttonHeight)
        self.ui.m_itemNode:setPositionY(self.ui.m_itemNode:getPositionY() + buttonHeight)

        local contentSize = self.ui.m_listNode:getContentSize()
        self.ui.m_listNode:setContentSize(cc.size(contentSize.width, contentSize.height + buttonHeight))
        self.ui.m_listTableView_Default:setViewSize(cc.size(contentSize.width, contentSize.height + buttonHeight))
    end
end

function CsmodStoreView:onClickRecord()
    local text = getLang("8009805")
    YesNoDialog:show(text)
end

return CsmodStoreView



