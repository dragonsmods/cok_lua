--[[
    2019-11-13
    出征军队详情单元
    BattleViewArmyDetailCell 
]]

local BattleViewArmyDetailCell = class("BattleViewArmyDetailCell", function()
    return cc.Layer:create()
end)


function BattleViewArmyDetailCell:create(idx)
    local view = BattleViewArmyDetailCell.new()
    Drequire("game.CommonPopup.BattleViewArmyDetailCell_ui"):create(view, 0)
    if view ~= nil then
        return view
    end 
end

function BattleViewArmyDetailCell:refreshCell(cellInfo , idx)
    -- dump(cellInfo, "BattleViewArmyDetailCell:refreshCell cellInfo")
    self.ui.m_nameLabel:setString(getLang(cellInfo.name))
    
    local value_str = ""
    -- cellInfo.mark    1:”-“前缀；2:"+"前缀
    if cellInfo.mark == 1 then
        value_str = value_str.."-"
    elseif cellInfo.mark == 2 then
        value_str = value_str.."+"
    end

    value_str = value_str..math.round(cellInfo.value)

    -- cellInfo.type    0:百分比数值；其他:常规数值
    if cellInfo.type == 0 then
        value_str = value_str.."%"
    end
    self.ui.m_valueLabel:setString(value_str)
end


return BattleViewArmyDetailCell