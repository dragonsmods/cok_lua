----------------------------
-- Author: Elex
-- Date: 2019-02-25 Monday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local ApplyRecordNode_ui = class("ApplyRecordNode_ui")

--#ui propertys


--#function
function ApplyRecordNode_ui:create(owner, viewType, paramTable)
	local ret = ApplyRecordNode_ui.new()
	CustomUtility:LoadUi("ApplyRecordNode.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function ApplyRecordNode_ui:initLang()
end

function ApplyRecordNode_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function ApplyRecordNode_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function ApplyRecordNode_ui:onClickBtnTransfer(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnTransfer", pSender, event)
end

function ApplyRecordNode_ui:initTableView()
	TableViewSmoker:createView(self, "m_listView", "game.CommonPopup.ChangeServer.ChangeServerApplyCell", 1, 5, "ChangeServerApplyCell")
end

function ApplyRecordNode_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return ApplyRecordNode_ui

