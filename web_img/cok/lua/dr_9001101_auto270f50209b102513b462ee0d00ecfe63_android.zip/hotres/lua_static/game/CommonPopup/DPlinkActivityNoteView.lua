
DPlinkActivityNoteLuaView = DPlinkActivityNoteLuaView or {}
ccb["DPlinkActivityNoteLuaView"] = DPlinkActivityNoteLuaView

-- --------------------------- 购买信息 Start ---------------------------
local DPlinkRewardCmd = class("DPlinkRewardCmd", LuaCommandBase)
function DPlinkRewardCmd.create(func,promotion)
  local ret = DPlinkRewardCmd.new()
  ret:initWithName("exchange.promotion.reward")
  ret:putParam("telkomselpromotion",CCString:create(promotion))
  ret.callback=func
  return ret
end

function DPlinkRewardCmd:handleReceive(dict)
  local tbl = self:parseMsg(dict)
  if type(tbl) == "boolean" then
    return tbl
  end
  
  dump(tbl,"----handleReceive------")
  if self.callback ~= nil then
    self.callback(dict)
  end

  return true
end
------------------------------------------------------------------------

local DPlinkActivityNoteView = class("DPlinkActivityNoteView",
    function()
        return PopupBaseView:call("create")
    end
)
DPlinkActivityNoteView.__index = DPlinkActivityNoteView

function DPlinkActivityNoteView:create(codeId,rewards)
  MyPrint("-------call DPlinkActivityNoteView:create -----")
  local view = DPlinkActivityNoteView.new()
  if view:initView(codeId,rewards) == false then
    return nil
  end
  return view
end

function DPlinkActivityNoteView:initView(codeId,rewards)
    if self:init(true, 0) == false then
      MyPrint("DPlinkActivityNoteView init error")
      return false  
    end
    math.randomseed(os.time())
    self:setHDPanelFlag(true)
    self.m_rewards = rewards
    self.m_codeId = codeId

    local actId = self:GetActivityId(codeId)
    local nameId,descId = self:GetActivityTextId(actId)

    MyPrint("--- Loading resource ---")
    callItSelfCallFunc(LuaController, "doResourceByCommonIndex", 500, true)

    ---根据活动读取不同的资源，这个广告资源分散成两部分，都需要动态下载
    if actId == "57016" then
      CCLoadSprite:call("loadDynamicResourceByName", "activity_ad")
    else
      CCLoadSprite:call("loadDynamicResourceByName", "activity_ad_2")
    end

    local proxy = cc.CCBProxy:create()
    local ccbiUrl = "ccbi/DPlinkActivityNoteView.ccbi"
    local ccbNode = CCBReaderLoad(ccbiUrl, proxy, self)
    if nil == ccbNode then
        MyPrint("CCB Load error!!")
        return false
    end

    if self:onAssignCCBMemberVariable() == false  then
      MyPrint(" CCB Memeber Variable bind error!!")
      return false
    end
    
    local winSize = cc.Director:getInstance():getIFWinSize()
    local bgSize  = self.m_viewBg:getContentSize()
    
    self:addChild(ccbNode)
    if CCCommonUtilsForLua:call("isIosAndroidPad") == true then
      ccbNode:setScale(2)
    end
    self:setContentSize(winSize);
    ccbNode:setPosition((winSize.width-640)*0.5, (winSize.height-852)*0.5)
    ccbNode:setAnchorPoint(0.5, 0.5)

    CCCommonUtilsForLua:setButtonTitle(self.m_btnGet,getLang("171022"))

    MyPrint("nameId="..nameId.."; descId=" ..descId)
    self.m_ActivityDesc:setString(getLang(descId));
    self.m_ActivityTitle:setString(getLang(nameId));

    local bgName,titleName = self:GetBgTitleIconName(actId)
    if bgName ~= "" then
        local cf = CCLoadSprite:call("getSF",bgName)
        if nil ~= cf then
          self.m_activityBg:initWithSpriteFrame(cf);
          self.m_activityBg:setScale(0.81)
        end
    end

    if titleName ~= "" then
        local title = CCLoadSprite:call("getSF",titleName);
        if nil~= title then
            self.m_TitleBg:initWithSpriteFrame(title)
        end
    end

  --[[
    if actId == "57100" or actId == "57105"  then
       local bgIcon = CCLoadSprite:call("getSF",actId.."_ad1_new.png")
       if nil ~= bgIcon then
        self.m_activityBg:initWithSpriteFrame(bgIcon) 
      end

       local titleIcon = CCLoadSprite:call("getSF","activity_"..actId.."_list_cell_head_new.png")
       if nil ~= titleIcon then
         self.m_TitleBg:initWithSpriteFrame(titleIcon)
       end 
       self.m_activityBg:setScale(0.81)
    end
    --]]
   

    return true
end

function DPlinkActivityNoteView:loadLuaResource(path)
   if (nil ~=path) then
     cc.SpriteFrameCache:getInstance():addSpriteFrames(path)
   end
end

function  DPlinkActivityNoteView:onCloseClick()
    self:call("closeSelf")
end  

function  DPlinkActivityNoteView:onClickGetReward()
    MyPrint(" --call onClickGetReward!")

    local function myCall(dict)
      self:openRewardView(dict)
    end
    
    local cmd = DPlinkRewardCmd.create(myCall,self.m_codeId)
    cmd:send()
end

function  DPlinkActivityNoteView:openRewardView(dict)
  
  local params = dict:objectForKey("params")
  if params == nil then
    MyPrint("------------params error!----------------")
    return
  end

  local arr = params:objectForKey("reward")
  if arr == nil then
    MyPrint("--------dict:objectForKey(reward) error!--------")
  end

  if nil ~= arr then
    local myView = require("game.CommonPopup.DPlinkRewardView"):create(self.m_rewards)
    PopupViewController:addPopupInView(myView)
    local rwdInfo = RewardController:call("retReward", arr)
  end
  self:call("closeSelf")
   
end

function DPlinkActivityNoteView:GetActivityId(codeId)
   MyPrint("----codeId" .. codeId )

  if codeId == "1RU12_AND" or codeId == "1RU19_AND" or codeId == "1RU25_AND" or  codeId =="1RU12_IOS" or codeId == "1RU19_IOS" or codeId == "1RU25_IOS" then
      local value = math.random(1,10000)
      if value > 5000 then
        return "57105"
      end
      return "57100"
  end

  if codeId == "1TR12_AND" or codeId == "1TR19_AND" or codeId == "1TR25_AND" or codeId == "1TR12_IOS" or codeId == "1TR19_IOS" or codeId == "1TR25_IOS" then
    local value = math.random(1,10000)
    if value > 5000 then
      return "57105"
    end
    return "57100"
  end

   if codeId == "2RU12_AND" or codeId == "2RU19_AND" or codeId == "2RU25_AND"  or codeId == "2RU12_IOS" or codeId == "2RU19_IOS" or codeId == "2RU25_IOS" then
      local value = math.random(1,10000)
      if value > 5000 then
        return "57016"
      end
      return ""
   end

  if codeId == "2TR12_AND" or codeId == "2TR19_AND" or codeId == "2TR25_AND"  or codeId == "2TR12_IOS" or codeId == "2TR19_IOS" or codeId == "2TR25_IOS" then
      local value = math.random(1,10000)
      if value > 5000 then
        return "57016"
      end
      return ""
  end
end

function  DPlinkActivityNoteView:GetBgTitleIconName(actId)
  --流亡者之塔
  if actId == "57105" then
    return "@57105_ad1_new.png","@57105_ad1_head_new.png"
  end
  --城内的巨龙
  if actId == "57100" then
    return "@57100_ad1_new.png","@57100_ad1_head_new.png"
  end
  --巨龙战役
  if actId == "57016" then
    return "57009_ad1.png",""
  end
  return "@castlskin_ad1_new.png","@castlskin_ad1_head_new.png"
end

function DPlinkActivityNoteView:GetActivityTextId(actId)
  --流亡者之塔
  if actId == "57105" then
    return "145001","151218"
  end
  --城内的巨龙
  if actId == "57100" then
    return "151219","151220"
  end
  --巨龙战役
  if actId == "57016" then
    return "151223","151224"
  end
  return "151221","151222"
end

function DPlinkActivityNoteView:onAssignCCBMemberVariable()

  if nil ~= DPlinkActivityNoteLuaView["m_viewBg"] then
    self.m_viewBg = tolua.cast(DPlinkActivityNoteLuaView["m_viewBg"],"cc.Node")
  end
  if self.m_viewBg == nil then
    MyPrint(" No match name :m_viewBg!  ")
    return false
  end

  if nil ~= DPlinkActivityNoteLuaView["m_btnClose"] then
      self.m_btnClose = tolua.cast(DPlinkActivityNoteLuaView["m_btnClose"],"ccui.Button")
  end
  if self.m_btnClose == nil then
    MyPrint("No match name :m_btnClose !")
    return false
  end

  if nil ~= DPlinkActivityNoteLuaView["m_btnGet"] then
      self.m_btnGet = tolua.cast(DPlinkActivityNoteLuaView["m_btnGet"],"ccui.Button")
  end
  if self.m_btnGet == nil then
    MyPrint("No match name :m_btnGet !")
    return false
  end

  if nil ~= DPlinkActivityNoteLuaView["m_ActivityTitle"] then
      self.m_ActivityTitle = tolua.cast(DPlinkActivityNoteLuaView["m_ActivityTitle"],"cc.LabelIF")
  end
  if self.m_ActivityTitle == nil then
    MyPrint("No match name :m_ActivityTitle !")
    return false
  end

  if nil ~= DPlinkActivityNoteLuaView["m_ActivityDesc"] then
      self.m_ActivityDesc = tolua.cast(DPlinkActivityNoteLuaView["m_ActivityDesc"],"cc.LabelIF")
  end
  if self.m_ActivityDesc == nil then
    MyPrint("No match name :m_ActivityDesc !")
    return false
  end

  if nil ~= DPlinkActivityNoteLuaView["m_activityBg"] then
      self.m_activityBg = tolua.cast(DPlinkActivityNoteLuaView["m_activityBg"],"cc.Sprite")
  end
  if self.m_activityBg == nil then
    MyPrint("No match name :m_activityBg !")
    return false
  end

  if nil ~= DPlinkActivityNoteLuaView["m_TitleBg"] then
    self.m_TitleBg = tolua.cast(DPlinkActivityNoteLuaView["m_TitleBg"],"cc.Sprite")
  end
  if self.m_TitleBg == nil then
    MyPrint(" No match name :m_TitleBg!  ")
    return false
  end

end

return DPlinkActivityNoteView