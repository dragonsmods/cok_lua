local AllyApplyCell = class("AllyApplyCell", Drequire("game.CommonPopup.ChangeServer.ChangeServerApplyCell"))

function AllyApplyCell:create()
    return AllyApplyCell.new("game.CommonPopup.ChangeServer.AllyApplyCell_ui")
end

function AllyApplyCell:showOther()
    local remain = atoi(self.info.rMax) - atoi(self.info.rCur)
    self.ui.m_reaminTxt:setString(getLang("173311", tostring(remain)))

    local allyNum = #self.info.allys
    self.ui.m_allysTxt:setString(getLang("173312", tostring(allyNum)))

    CCCommonUtilsForLua:setButtonTitle(self.ui.m_viewBtn, getLang("173320"))
end

function AllyApplyCell:onClickView()
    local allysView = Drequire("game.CommonPopup.ChangeServer.AllysTransferView"):create(self.info.allys)
    PopupViewController:addPopupView(allysView)
end

return AllyApplyCell