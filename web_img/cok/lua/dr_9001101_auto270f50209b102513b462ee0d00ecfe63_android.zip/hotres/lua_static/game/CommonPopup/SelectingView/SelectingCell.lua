

local SelectingCell = class("SelectingCell", function()
    return cc.Layer:create()
end)

function SelectingCell:create(idx)
    -- dump("SelectingCell:create+++")
    local ret = SelectingCell.new()
    Drequire("game.CommonPopup.SelectingView.SelectingCell_ui"):create(ret)
    return ret
end
SelectingCell.__index = SelectingCell

function SelectingCell:refreshCell(info , idx)
    -- dump(info, "SelectingCell+++")
    self.info = info
    self.ui.m_iconNode:removeAllChildren()
    self.ui.m_boxNameLabel:setString("")
    if self.info and self.info.selectingViewController then
        local check = self.info.selectingViewController:isDataChecked(self.info) 
        self.ui.m_yesSprite:setVisible(check)
    end
   
    self.celldata = {}
    self.celldata["itemId"] = self.info.itemId
    self.celldata["num"] = self.info.itemNum
    self.celldata["type"] = self.info.type
    LibaoCommonFunc.createItemInfoShow(self.celldata, self.ui.m_iconNode, 50, self.ui.m_boxNameLabel, self.ui.m_numLabel)
    if self.info.name then 
        self.ui.m_boxNameLabel:setString(self.info.name)
    end
end

function SelectingCell:onEnter()
    dump(CheckedDataChangedMsg, "SelectingCell:onEnter+++")
    registerScriptObserver(self, self.onCheckedDataChanged, CheckedDataChangedMsg)
end

function SelectingCell:onExit()
    dump(CheckedDataChangedMsg, "SelectingCell:onExit+++")
    unregisterScriptObserver(self, CheckedDataChangedMsg)
end

function SelectingCell:onCheckedDataChanged()
    dump("SelectingCell:onCheckedDataChanged+++")
    if self.info and self.info.selectingViewController then 
        local checked = self.info.selectingViewController:isDataChecked(self.info)
        self.ui.m_yesSprite:setVisible(checked)
    end
end

function SelectingCell:onBtnClicked( )
    if self.info and self.info.selectingViewController then 
        local checked = not self.info.selectingViewController:isDataChecked(self.info)
        self.ui.m_yesSprite:setVisible(checked)
        self.info.selectingViewController:addCheckedData(self.info, checked)
    end
end


return SelectingCell



