--戒律大厅
local Cell_NewSoldier = class("Cell_NewSoldier",Drequire("game.CommonPopup.OverView.Cell_Info.Cell_QueueFile"))

local TYPE_NEWARMY= 17 --新兵种训练17
local FUN_BUILD_NEWARMY = 439000  --荣耀6新兵营
function Cell_NewSoldier:create(Id)
    local ret = Cell_NewSoldier.new(Id)
    if ret:initBaseById(Id) then
        return ret
    end
end

function Cell_NewSoldier:getCureQueueInfo()
    if not self:checkIsVisible() then
        return
    end
    local tempTbl = {}
    local qid = QueueController:call("getMinTimeQidByType",TYPE_NEWARMY)
    tempTbl = self:getSubTypeCellTbl(qid)
    self.CellTbl.cellMeta={tempTbl}
    return self.CellTbl
end

function Cell_NewSoldier:getSubTypeCellTbl(qid)
    local TYPE_BUILDING = 0 --建筑
    local res = {}
	local _state = self.Queue_ST_Init
	local _finishTime = -1
	local _totalTime = -1
	local _label = ""
	local _type = type
    local _id = "30711035"
    local _name = ""
    local _icon = ""
    local _visible = ""

    local qInfo = self.allQueuesInfos[qid]

    if qid ~= QID_MAX then
        _state,_finishTime,_totalTime = self:getQueueState(qInfo)
	else
		_state = self.Queue_ST_IDLE
		_finishTime = 0
		
    end

    if _state == self.Queue_ST_IDLE then
        _label = "169606" --空闲中
    elseif _state == self.Queue_ST_WORK then
        _label = "2000430" --部队训练中
    elseif _state == self.Queue_ST_LOCK then
        _label = "2000442" --未解锁			
    end

    --未解锁
    if not self:checkIsUnLock(TYPE_NEWARMY) then
        _state = self.Queue_ST_LOCK
        _finishTime = -1
        _label = "2000442"
    end

    _name,_icon,_visible = self:getNameIconVisibleBySubId(_id)        
    res = {id = _id, state = _state, param1 = _finishTime, param2 = _totalTime,label = _label,name = _name,icon = _icon,order = _order,cell = self}
     
    if _visible == "1" then
        return res
    end
end

function Cell_NewSoldier:OnClickJump(_id,_state)
    if _id == "30711035" then
        if _state == self.Queue_ST_WORK or _state == self.Queue_ST_IDLE then            
            self:jumpByTypeAndTarget(1,FUN_BUILD_NEWARMY)
        elseif _state == self.Queue_ST_LOCK then
            --未解锁,目前是跳过去,会提示建造该建筑
            self:jumpByTypeAndTarget(1,FUN_BUILD_NEWARMY)
        end
    end
end

return Cell_NewSoldier