----------------------------
-- Author: Elex
-- Date: 2021-04-22 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local PreviewRootCell_ui = class("PreviewRootCell_ui")

--#ui propertys


--#function
function PreviewRootCell_ui:create(owner, viewType, paramTable)
	local ret = PreviewRootCell_ui.new()
	CustomUtility:LoadUi("InformationPreviewRootCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function PreviewRootCell_ui:initLang()
end

function PreviewRootCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function PreviewRootCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function PreviewRootCell_ui:onBtnClick9(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBtnClick9", pSender, event)
end

function PreviewRootCell_ui:onBtnClick8(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBtnClick8", pSender, event)
end

function PreviewRootCell_ui:onBtnClick7(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBtnClick7", pSender, event)
end

function PreviewRootCell_ui:onBtnClick6(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBtnClick6", pSender, event)
end

function PreviewRootCell_ui:onBtnClick5(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBtnClick5", pSender, event)
end

function PreviewRootCell_ui:onBtnClick4(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBtnClick4", pSender, event)
end

function PreviewRootCell_ui:onBtnClick3(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBtnClick3", pSender, event)
end

function PreviewRootCell_ui:onBtnClick2(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBtnClick2", pSender, event)
end

function PreviewRootCell_ui:onBtnClick1(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBtnClick1", pSender, event)
end

return PreviewRootCell_ui

