----------------------------
-- Author: Elex
-- Date: 2020-08-05 Wednesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local StoreBuyConfirmDialogForLua_ui = class("StoreBuyConfirmDialogForLua_ui")

--#ui propertys


--#function
function StoreBuyConfirmDialogForLua_ui:create(owner, viewType, paramTable)
	local ret = StoreBuyConfirmDialogForLua_ui.new()
	CustomUtility:DoRes(11, true)
	CustomUtility:LoadUi("StoreBuyConfirmDialogForLua.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function StoreBuyConfirmDialogForLua_ui:initLang()
end

function StoreBuyConfirmDialogForLua_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function StoreBuyConfirmDialogForLua_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function StoreBuyConfirmDialogForLua_ui:onUseClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onUseClick", pSender, event)
end

function StoreBuyConfirmDialogForLua_ui:onSubClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onSubClick", pSender, event)
end

function StoreBuyConfirmDialogForLua_ui:onAddClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onAddClick", pSender, event)
end

return StoreBuyConfirmDialogForLua_ui

