local RewardTblView = class("RewardTblView",function (  )
    return cc.Layer:create()    
end)

RewardTblView.__index = RewardTblView

--params:rewardId
--maxShowNum:显示cell的最大数量
--forceShowLen:黑色底框宽度显示设置
function RewardTblView:create(rewardId,maxShowNum,forceShowLen)
    local view = RewardTblView.new()
    Drequire("game.CommonPopup.RewardTblView_ui"):create(view,0)
    if view:initView(rewardId,maxShowNum,forceShowLen) then
        return view
    end
end

function RewardTblView:initView(rewardId,maxShowNum,forceShowLen)
    if rewardId == nil then
        return false
    end
    self.rewardId = rewardId
    self.maxShowNum = maxShowNum
    if forceShowLen then
        self.forceShowLen = forceShowLen
    end
    self:setRewardData()
    return true
end

function RewardTblView:setRewardData( )
    local rewardData = nil
    if type(self.rewardId) == 'table' then
        rewardData = self.rewardId
    else
        local reward = GlobalData:call("getCachedRewardData", tostring(self.rewardId))
        rewardData = arrayToLuaTable(reward)
    end
    
    local rewardNum = #rewardData
	if rewardNum > 0 then
        self.ui.m_listTableView:setTouchEnabled(true)
        if rewardNum > self.maxShowNum then rewardNum = self.maxShowNum end
        if self.forceShowLen ~= nil then
            rewardNum = self.forceShowLen
        end
        self.ui.m_listTableView:setViewSize(cc.size(85*rewardNum,90))
        self.ui.m_cellBG:setContentSize(self.ui.m_cellBG:getContentSize().width * rewardNum, self.ui.m_cellBG:getContentSize().height)
        self.ui:setTableViewDataSource("m_listTableView", rewardData)
	else
		self.m_requestedRewardId = self.rewardId
		GlobalData:call("requestRewardData", self.rewardId)
    end   
end

function RewardTblView:onEnter(  )
    local function onGetRewardDetailBack(ref)
		local rewardId = ""
		if ref then rewardId = ref:getCString() end
        if self.m_requestedRewardId and self.m_requestedRewardId == rewardId then		
            self:setRewardData()
            self.m_requestedRewardId = ""
		end
    end
    local t = tolua.cast(self, "cc.Node")
	local handler = t:registerHandler(onGetRewardDetailBack)
	CCSafeNotificationCenter:registerScriptObserver(self, handler, "MSG_GET_REWARD_DETAIL_BACK")
end

function RewardTblView:onExit()
    CCSafeNotificationCenter:unregisterScriptObserver(self, "MSG_GET_REWARD_DETAIL_BACK")
end

function RewardTblView:setCellBGVisible(visible)
    self.ui.m_cellBG:setVisible(visible)
end

return RewardTblView