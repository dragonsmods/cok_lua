-------------------------------------------- GoldBoxHeadCell Start --------------------------------------------
local GoldBoxHeadCell = class("GoldBoxHeadCell", function()
    return cc.Layer:create()
end)

function GoldBoxHeadCell:create(idx)
    local ret = GoldBoxHeadCell.new()
    Drequire("game.activity.consumePoint.ConsumeActivityPointCell_ui"):create(ret)
    ret.ui.nodeccb:setPositionY(-10)
    return ret
end

function GoldBoxHeadCell:refreshCell(info , idx)
    self.m_info = info
    self.ui.m_curPointLbl:setString(info.score)
    self.ui.m_progress:setVisible(false)
    self.ui.m_progress:setScaleX(0)
    if tonumber(info.curScore) < tonumber(info.score) and tonumber(info.curScore) > tonumber(info.lastScore) then
        local delta = tonumber(info.curScore) - tonumber(info.lastScore)
        local all = tonumber(info.score) - tonumber(info.lastScore)
        local scaleX = delta /  all 
        self.ui.m_progress:setScaleX(scaleX)
        self.ui.m_progress:setVisible(true)
    elseif tonumber(info.curScore) >= tonumber(info.score) then
        self.ui.m_progress:setVisible(true)
        self.ui.m_progress:setScaleX(1)
    end

    self.ui.m_parNode:setScale(0.8)
    self.ui.m_parNode:removeAllChildren()
    if info.status == 2 then
        self.ui.m_rewardEmptySp:setVisible(true)
        self.ui.m_rewardSp:setVisible(false)
    else
        self.ui.m_rewardEmptySp:setVisible(false)
        self.ui.m_rewardSp:setVisible(true)
        if info.status == 1 then
            local par1 = ParticleController:call("createParticle", "Rose_3")
            self.ui.m_parNode:addChild(par1)
            local par2 = ParticleController:call("createParticle", "VIPGlow_3")
            self.ui.m_parNode:addChild(par2)
            CCCommonUtilsForLua:call("setSpriteGray", self.ui.m_rewardSp, false)
        else
            CCCommonUtilsForLua:call("setSpriteGray", self.ui.m_rewardSp, true)
        end
    end
end

function GoldBoxHeadCell:onEnter()
end

function GoldBoxHeadCell:onExit()
end

function GoldBoxHeadCell:getInfo()
    return self.m_info
end

-------------------------------------------- GoldBoxHeadCell End --------------------------------------------

return GoldBoxHeadCell