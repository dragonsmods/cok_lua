
local MonthFundView = class("MonthFundView", 
	function()
    return PopupBaseView:create()
	end
	)
MonthFundView.__index =  MonthFundView

function MonthFundView:create(index)
 local view = MonthFundView.new()
    Drequire("game.CommonPopup.MonthFundView.MonthFundView_ui"):create(view, 0)
    if view:initView(index) then
        return view
    end
    return false
end

local month_fund_tab_index_19 = 1
local month_fund_tab_index_49 = 2
local month_fund_tab_index_99 = 3
local month_fund_tab_index_9 = 4

local buy_btn_act_get_reward = 1
local buy_btn_act_buy_month_cards = 2
local buy_btn_act_buy_libao = 3

function MonthFundView:initView()
	dump("MonthFundView:initView+++")
    CCLoadSprite:call("loadDynamicResourceByName", "uicompoent_face")
    self.MonthFundCtl = require("game.CommonPopup.MonthFundView.MonthFundController").getInstance()
    self:setTitleName(getLang("9441868"))
    self.ui.m_pLabelRewards:setString(getLang("9441873"))

	self.ui.m_pNodeIcon:removeAllChildren()
    local spr = CCLoadSprite:call("createSprite", "activity_ad_beiyong.png")
    local icon = CCLoadSprite:call("getSF", "yuejijin_ad.png")
    if icon ~= nil then 
        spr = CCLoadSprite:call("createSprite","yuejijin_ad.png")
    else
        dump("error:recharge legend bg icon is not found+++")
    end
    self.ui.m_pNodeIcon:addChild(spr)
 
    self.ui.m_pNodeIconRed:removeAllChildren()
    local spr1 = CCLoadSprite:call("createSprite", "activity_ad_beiyong.png")
    local icon1 = CCLoadSprite:call("getSF", "yuejijin_bg.png")
    if icon1 ~= nil then 
        spr1 = CCLoadSprite:call("createSprite","yuejijin_bg.png")
    else
        dump("error:recharge legend bg icon is not found2+++")
    end
    self.ui.m_pNodeIconRed:addChild(spr1)
   
 
    self:setBtnsPosition()
    function onTouch(eventType, x, y)  
        if eventType == "began" then  
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)  
        else  
            return self:onTouchEnded(x, y)  
        end
    end
    self:setTouchEnabled(true)
    self:registerScriptTouchHandler(onTouch)
    self.currentTabIndex = index or month_fund_tab_index_9
    --utils.attachBackFrom(self,"57268")
    return true
end
function MonthFundView:setBtnsPosition()
    local btnNum = self.MonthFundCtl:isNew99Open() and 4 or 3
    local btnSize = self.MonthFundCtl:isNew99Open()  and 155 or 210
    local btns = {self.ui.m_btn9,self.ui.m_btn19,self.ui.m_btn49,self.ui.m_btn99}
    self.ui.m_nodeBtn:setPositionX(-btnSize*btnNum/2)
    for i=1,4 do
        local nodebtn =  self.ui["m_nodebtn"..i]
        nodebtn:setVisible(i <= btnNum)
        nodebtn:setPositionX(btnSize * (i-1))
        self.ui["m_spe"..i]:setVisible(i ~= btnNum)
        self.ui["m_spe"..i]:setPositionX(btnSize)
        btns[i]:setPreferredSize(cc.size(btnSize,60))
    end
end
function MonthFundView:setJumpIndex(index)
    self.currentTabIndex = month_fund_tab_index_9
    self:updateViewData(self.currentTabIndex)
end

function MonthFundView:onEnter()
    dump("MonthFundView:onEnter+++") 
    UIComponent:call("showPopupView", 4)
    self.MonthFundCtl:pullMonthFundData()
    registerScriptObserver(self, self.onMonthFundDataBackMsg, MonthFundDataBackMsg)
   
    registerScriptObserver(self, self.payFinished, PAYMENT_COMMAND_RETURN)
end

function MonthFundView:onExit()
    dump("MonthFundView:onExit+++") 
    unregisterScriptObserver(self, MonthFundDataBackMsg)
    unregisterScriptObserver(self, PAYMENT_COMMAND_RETURN)
end
function  MonthFundView:payFinished()
    self.MonthFundCtl:pullMonthFundData()
end
function MonthFundView:onTouchBegan(x, y)
    return true
end

function MonthFundView:onTouchMoved(x, y)
end

function MonthFundView:onTouchEnded(x, y)
end

function MonthFundView:onMonthFundDataBackMsg()
    dump("MonthFundView:onMonthFundDataBackMsg+++")
    self:updateViewData(self.currentTabIndex)
end

function MonthFundView:highLightBtn( tabIndex )
    if tabIndex == month_fund_tab_index_19 then 
        self.ui.m_btn49:setEnabled(true)
        self.ui.m_btn19:setEnabled(false)
        self.ui.m_btn99:setEnabled(true)
        self.ui.m_btn9:setEnabled(true)
    elseif tabIndex == month_fund_tab_index_49 then
        self.ui.m_btn49:setEnabled(false)
        self.ui.m_btn19:setEnabled(true)
        self.ui.m_btn99:setEnabled(true)
        self.ui.m_btn9:setEnabled(true)
    elseif tabIndex == month_fund_tab_index_99 then
        self.ui.m_btn49:setEnabled(true)
        self.ui.m_btn19:setEnabled(true)
        self.ui.m_btn99:setEnabled(false)
        self.ui.m_btn9:setEnabled(true)
    elseif tabIndex == month_fund_tab_index_9 then
        self.ui.m_btn49:setEnabled(true)
        self.ui.m_btn19:setEnabled(true)
        self.ui.m_btn99:setEnabled(true)
        self.ui.m_btn9:setEnabled(false)
    end
end

function MonthFundView:updateViewData(tabIndex)
    dump("MonthFundView:updateViewData+++")
    self:highLightBtn(tabIndex)
    if not self.MonthFundCtl then 
        return
    end
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_btn19, _lang_1('9441870', self.MonthFundCtl.dollar19)) --9441870={0}基金
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_btn49, _lang_1('9441870', self.MonthFundCtl.dollar49))
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_btn99, _lang_1('9441870', self.MonthFundCtl.dollar99))
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_btn9, _lang_1('9441870', self.MonthFundCtl.dollar9))
    local multiple = ""
    self.needDollar = ""
    self.isActived = false
    self.needCardNum = 999
    self.curTotalCardNum = self.MonthFundCtl.curTotalMonthCards
    if tabIndex == month_fund_tab_index_19 then 
        self.allTblData=self.MonthFundCtl.fund19Rewards
        self.isActived = self.MonthFundCtl.isActived19
        self.needCardNum = self.MonthFundCtl.needCardNum19
        self.needDollar = self.MonthFundCtl.dollar19
        multiple = self.MonthFundCtl.fund19.multiple
    elseif tabIndex == month_fund_tab_index_49 then 
        self.allTblData=self.MonthFundCtl.fund49Rewards
        self.isActived = self.MonthFundCtl.isActived49
        self.needCardNum = self.MonthFundCtl.needCardNum49
        self.needDollar = self.MonthFundCtl.dollar49
        multiple = self.MonthFundCtl.fund49.multiple
    elseif tabIndex == month_fund_tab_index_99 then 
        self.allTblData=self.MonthFundCtl.fund99Rewards
        self.isActived = self.MonthFundCtl.isActived99
        self.needCardNum = self.MonthFundCtl.needCardNum99
        self.needDollar = self.MonthFundCtl.dollar99
        multiple = self.MonthFundCtl.fund99.multiple
    elseif tabIndex == month_fund_tab_index_9 then 
        self.allTblData=self.MonthFundCtl.fund9Rewards
        self.isActived = self.MonthFundCtl.isActived9
        self.needCardNum = self.MonthFundCtl.needCardNum9
        self.needDollar = self.MonthFundCtl.dollar9
        multiple = self.MonthFundCtl.fund9.multiple
    end
    self.ui:setTableViewDataSource("m_tableView1", self.allTblData)

    -- 9441871=激活{0}张以上月卡的用户，单次购买{1}以上礼包即可领取{2}月基金（单次充值只能激活一档月基金，奖励可以在‘日常奖励’界面领取）
    local tip = _lang_3("9441871", tostring(self.needCardNum), self.needDollar, self.needDollar)
    self.ui.m_pLabelActDes:setString(tip)

    self.ui.m_labelActived:setVisible(false)
    local btnTxt = ""
    if self.isActived then 
        btnTxt = getLang("9441877") --9441877=前往领奖
        self.buyBtnAct = buy_btn_act_get_reward
    elseif self.curTotalCardNum < self.needCardNum then
        btnTxt = getLang("9441875") --9441875=前往购买月卡
        self.buyBtnAct = buy_btn_act_buy_month_cards
        self.ui.m_labelActived:setVisible(true)
        self.ui.m_labelActived:setString(_lang_2("9441874", tostring(self.curTotalCardNum), tostring(self.needCardNum)) ) --9441874=已激活月卡数量{0}/{1}
    else  
        btnTxt = getLang("9441876") --9441876=前往购买礼包
        self.buyBtnAct = buy_btn_act_buy_libao
    end
    self.ui.m_labelRed:setString(multiple.."%")
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnBuy, btnTxt)

    --刷新宝箱
    if  not table.isNilOrEmpty(self.MonthFundCtl.progressBoxInfo) then
        if not self.libaoBox then
            self.libaoBox = Drequire("game.CommonPopup.MonthFundView.MonthFundBox"):create(self.MonthFundCtl.progressBoxInfo)
            self.ui.m_nodeBox:addChild(self.libaoBox)
        else
            self.libaoBox:refreshView(self.MonthFundCtl.progressBoxInfo)
        end
    end
    
  
end
function MonthFundView:onBtn9Click()
    self.currentTabIndex = month_fund_tab_index_9
    self:updateViewData(self.currentTabIndex)
end

function MonthFundView:onBtn49Click()
    dump("MonthFundView:onBtn49Click+++")
    self.currentTabIndex = month_fund_tab_index_49
    self:updateViewData(self.currentTabIndex)
end

function MonthFundView:onBtn19Click( )
    dump("MonthFundView:onBtn19Click+++")
    self.currentTabIndex = month_fund_tab_index_19
    self:updateViewData(self.currentTabIndex)
end

function MonthFundView:onBtn99Click()
    dump("MonthFundView:onBtn99Click+++")
    self.currentTabIndex = month_fund_tab_index_99
    self:updateViewData(self.currentTabIndex)
end

function MonthFundView:onBuyBtnClick()
    if self.buyBtnAct == buy_btn_act_get_reward then 
        -- PopupViewController:call("removeLastPopupView")
        local params = {}
        params.firstViewKey = "integrateMonthFund"
        local view = Drequire("game.WelfareIntegrate.WelfareIntegrateMainView"):create(params)
        PopupViewController:addPopupInView(view)
    elseif self.buyBtnAct == buy_btn_act_buy_month_cards then
        local params = {}
        params.firstViewKey = "integrateMonthCard"
        local view = Drequire("game.WelfareIntegrate.WelfareIntegrateMainView"):create(params)
        PopupViewController:addPopupInView(view)
    elseif self.buyBtnAct == buy_btn_act_buy_libao then
        LiBaoController.getInstance():showLiBaoView("showExchangePopup")
    end
end

function MonthFundView:onHelpBtnClick()
    -- 9441892=月基金分为高、低两档，玩家可以选择激活任意一档，也可以同时激活两档享受双重奖励！\n-同时拥有{0}张以上不同类型周卡/月卡的玩家单笔充值{1}以上即可领取{1}月基金\n-同时拥有{2}张以上不同类型周卡/月卡的玩家单笔充值{3}以上即可领取{3}月基金-满足上述条件的玩家，一次充值只会激活一档月基金奖励，优先激活需求金额高的月基金奖励\n-对应月基金奖励激活的状态下不会被重复激活
    local params = {}
    params.title = getLang("102271")
    local words1 = getLang("9441892",
        self.MonthFundCtl.needCardNum9,self.MonthFundCtl.dollar9,
        self.MonthFundCtl.needCardNum19,self.MonthFundCtl.dollar19)

    local param = {self.MonthFundCtl.needCardNum49,self.MonthFundCtl.dollar49}
    if self.MonthFundCtl.isNew99Open() then
        table.insert(param, self.MonthFundCtl.needCardNum99)
        table.insert(param, self.MonthFundCtl.dollar99)
    end
    local words2 = getLang("9461086",unpack(param)) 
    params.info = words1..words2
    local view = Drequire("game.DressIntroduction.CommonInfoViewNew"):create(params)
    PopupViewController:addPopupView(view)
end


return MonthFundView



