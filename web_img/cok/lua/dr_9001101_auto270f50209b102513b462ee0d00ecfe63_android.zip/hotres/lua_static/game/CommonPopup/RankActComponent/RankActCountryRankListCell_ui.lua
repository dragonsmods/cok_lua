----------------------------
-- Author: Elex
-- Date: 2019-05-05 Sunday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local RankActCountryRankListCell_ui = class("RankActCountryRankListCell_ui")

--#ui propertys


--#function
function RankActCountryRankListCell_ui:create(owner, viewType, paramTable)
	local ret = RankActCountryRankListCell_ui.new()
	CustomUtility:DoRes(0, true)
	CustomUtility:DoRes(10, true)
	CustomUtility:DoRes(11, true)
	CustomUtility:DoRes(7, true)
	CustomUtility:LoadUi("RankActCountryRankListCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function RankActCountryRankListCell_ui:initLang()
	LabelSmoker:setText(self.m_pLabelTTF17, "221128")
	LabelSmoker:setText(self.m_tipsLabel, "221125")
end

function RankActCountryRankListCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function RankActCountryRankListCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function RankActCountryRankListCell_ui:onSearchButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onSearchButtonClick", pSender, event)
end

function RankActCountryRankListCell_ui:onCountryRwdClick1(pSender, event)
	ButtonSmoker:forwardFunction(self, "onCountryRwdClick1", pSender, event)
end

function RankActCountryRankListCell_ui:onCountryRwdClick2(pSender, event)
	ButtonSmoker:forwardFunction(self, "onCountryRwdClick2", pSender, event)
end

function RankActCountryRankListCell_ui:onCountryRwdClick3(pSender, event)
	ButtonSmoker:forwardFunction(self, "onCountryRwdClick3", pSender, event)
end

function RankActCountryRankListCell_ui:initTableView()
	TableViewSmoker:createView(self, "m_countryRankTbl", "game.CommonPopup.RankActComponent.RankActCountryRankTblCell", 1, 10, "RankActCountryRankTblCell")
end

function RankActCountryRankListCell_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return RankActCountryRankListCell_ui

