--医院队列
local Cell_Hospital = class("Cell_Hospital",Drequire("game.CommonPopup.OverView.Cell_Info.Cell_QueueFile"))
local TYPE_HOSPITAL = 3 --医院
local FUN_BUILD_HOSPITAL = 411000 --医院
function Cell_Hospital:create(Id)
    local ret = Cell_Hospital.new(Id)
    if ret:initBaseById(Id) then
        return ret
    end
end

function Cell_Hospital:getCureQueueInfo()
    if not self:checkIsVisible() then
        return
    end
    local qid = QueueController:call("getMinTimeQidByType", TYPE_HOSPITAL)
    local tempTbl = self:getSubTypeCellTbl(qid)

    self.CellTbl.cellMeta={tempTbl}
    return self.CellTbl

end

function Cell_Hospital:getSubTypeCellTbl(qid)
    local res = {}
	local _state = self.Queue_ST_Init
	local _finishTime = -1
	local _totalTime = -1
	local _label = ""
	local _type = -1
    local _id = ""
    local _name = ""
    local _icon = ""
    local _visible = ""
    local _cancelJump = false
    
    local qInfo = self.allQueuesInfos[qid]

    if qid ~= QID_MAX then
        _state,_finishTime,_totalTime = self:getQueueState(qInfo)
	else
		_state = self.Queue_ST_IDLE
		_finishTime = 0		
	end

	if _state == self.Queue_ST_IDLE then
        _label = "2000428" --2000428=伤兵{0}/{1}
        local treatList = GlobalData:call("shared"):getProperty("treatList")
        local treateMax = ArmyController:call("getInstance"):call("getMaxNumByType",2)
        local limit = ArmyController:call('getInstance'):call("getHospitalLimit")
        local total = treateMax + limit
        local currentNum = 0
        for k,treatInfo in pairs(treatList) do
            if treatInfo then
                local dead = treatInfo:getProperty("dead")
                currentNum = currentNum + dead
            end
        end
        if currentNum == 0 then
            _label = "2000447" -- 没有伤兵
            _cancelJump = true
        end
        _finishTime = currentNum
        _totalTime = total				
    elseif _state == self.Queue_ST_WORK then
        if _finishTime == -1 then
            _label = "103678" --103678=伤兵完成治疗
        else
            _label = "2000437" --2000437=治疗中
        end
    end
    --未解锁
    if not self:checkIsUnLock(TYPE_HOSPITAL) then
        _state = self.Queue_ST_LOCK
        _finishTime = -1
        _label = "2000442"
    end
    _id = '30711034'
    if  _label ~= "" then
        _name,_icon,_visible = self:getNameIconVisibleBySubId(_id)        
		res = {id = _id, state = _state, param1 = _finishTime, param2 = _totalTime,label = _label,name = _name,icon = _icon,order = _order,cancelJump = _cancelJump,cell = self}
    end
    if _visible == "1" then
        return res
    end
end

function Cell_Hospital:OnClickJump(_id,_state)
    if _id == "30711034" then
        if _state == self.Queue_ST_WORK then
            local qid = QueueController:call("getMinTimeQidByType", TYPE_HOSPITAL)        
            local qInfo = self.allQueuesInfos[qid]
            local key = qInfo:getProperty("key")
            if key ~= "" then
                local targetId = math.floor( tonumber(key)/1000 )
                self:jumpByTypeAndTarget(1,targetId)
            end
        elseif _state == self.Queue_ST_IDLE or _state == self.Queue_ST_LOCK then            
            self:jumpByTypeAndTarget(1,FUN_BUILD_HOSPITAL)            
        end
    end
end

return Cell_Hospital