ActivityDetailBase = class("ActivityDetailBase", function  (  )
    return cc.Node:create()
end)
ActivityShowCellModel = class("ActivityShowCellModel", function (  )
	return cc.Layer:create()
end)
ActivityShowCellView = class("ActivityShowCellView", function (  )
	return cc.Node:create()
end)
ActivityShowCellViewDelegate = class("ActivityShowCellViewDelegate")
ActivityScrollLabelwidget = class("ActivityScrollLabelwidget", function (  )
	return cc.Node:create()
end)




-----------------------------------------cell base-----------------------------------
-----------------------------------------cell base-----------------------------------
-----------------------------------------cell base-----------------------------------
function ActivityDetailBase:ctor( id )
	self.m_id = id
	self:setContentSize(cc.size(538, 513))
	self.m_showHelp = false
end

function ActivityDetailBase:showHelpBtn(  )
	return self.m_showHelp
end

function ActivityDetailBase:setShowHelpBtn( flag )
	self.m_showHelp = flag
end

function ActivityDetailBase:setFather( father )
	self.m_father = father
end

function ActivityDetailBase:callHelp(  )
	-- body
end

function ActivityDetailBase:getObj(  )
	return ActivityController:call("getActObj", self.m_id)
end


function ActivityDetailBase:createAd(  )
	local obj = self:getObj()
	if nil == obj then
		return nil
	end

	local spr = nil
	local sf = obj:getAdFrame()
	if sf ~= nil then
		spr = cc.Sprite:createWithSpriteFrame(sf)
	else
		spr = CCLoadSprite:call("createSprite", "activity_ad_beiyong.png")
	end
	local nodesize = self.m_father:getAdNodeSize()
	local anchorY = CCCommonUtilsForLua:call("getPropById", self.m_id, "anchorY")
	if anchorY == "" then
		anchorY = 0.5
	else
		anchorY = tonumber(anchorY)
		MyPrint("anchorY  ", anchorY)
		if (1 - anchorY) * spr:getContentSize().height < nodesize.height * 0.5 then
			anchorY = 1 - nodesize.height * 0.5 / spr:getContentSize().height
		elseif anchorY * spr:getContentSize().height < nodesize.height * 0.5 then
			anchorY = nodesize.height * 0.5 / spr:getContentSize().height
		end
	end
	spr:setAnchorPoint(cc.p(0, anchorY))
	spr:setPositionY(nodesize.height * 0.5)
	return spr
end
-- 可重载
function ActivityDetailBase:createTopIcon( )
	local obj = self:getObj()
	if nil == obj then
		return nil
	end

	local spr = nil
	local sf = obj:getIconFrame()
	if nil ~= sf then
		spr = cc.Sprite:createWithSpriteFrame(sf)
	else
		spr = CCLoadSprite:call("createSprite", "Ativity_iconLogo_1.png")
	end
	CCCommonUtilsForLua:call("setSpriteMaxSize", spr, 130, true)
	return spr
end
-----------------------------------------cell base-----------------------------------
-----------------------------------------cell base-----------------------------------
-----------------------------------------cell base-----------------------------------




local defaultCellWidth = 89
-----------------------------------------ActivityShowCellViewDelegate-----------------------------------
-----------------------------------------ActivityShowCellViewDelegate-----------------------------------
-----------------------------------------ActivityShowCellViewDelegate-----------------------------------
-- 可重载
function ActivityShowCellViewDelegate:cellWidth( view )
	return defaultCellWidth
end

-- 使用者必须重载
ActivityShowCellViewDelegate.cellCount = nil
ActivityShowCellViewDelegate.createCellAtIdx = nil
-----------------------------------------ActivityShowCellViewDelegate-----------------------------------
-----------------------------------------ActivityShowCellViewDelegate-----------------------------------
-----------------------------------------ActivityShowCellViewDelegate-----------------------------------






-----------------------------------------ActivityShowCellView-----------------------------------
-----------------------------------------ActivityShowCellView-----------------------------------
-----------------------------------------ActivityShowCellView-----------------------------------

function ActivityShowCellView:ctor( delegate )
	self.m_delegate = delegate
	self.width = 538
	local proxy = cc.CCBProxy:create()
    local ccbiUrl = "ActivityShowCellView"
    local node = CCBReaderLoad(ccbiUrl, proxy, self)
    node:setPositionX(self.width * 0.5)
    node:setPositionY(0)
    self:addChild(node)
	
	self:setAnchorPoint(cc.p(0, 0))

	self.originMountY = self.m_mountNode:getPositionY()
	self.originTitleY = self.m_title:getPositionY()
end

function ActivityShowCellView:reloadData(  )
	self:setContentSize(cc.size(538, self.m_delegate:cellWidth(self) + 26))
	local dh = self.m_delegate:cellWidth(self) - defaultCellWidth
	self.m_mountNode:setPositionY(self.originMountY + dh * 0.5)
	self.m_title:setPositionY(self.originTitleY + dh)
	self.m_rightSpr:setPositionY(self.originTitleY + dh)
	self.m_leftSpr:setPositionY(self.originTitleY + dh)

	self.m_mountNode:removeAllChildren()

	local cnt = self.m_delegate:cellCount(self)
	for i=1,cnt do
		local cell = self.m_delegate:createCellAtIdx(self, i)
		if nil ~= cell then
			cell:setPositionX(-(cnt - 1) * self.m_delegate:cellWidth(self) * 0.5 + (i - 1) * self.m_delegate:cellWidth(self))
			self.m_mountNode:addChild(cell)
			-- MyPrint("self.m_mountNode:addChild(cell)")
		end
	end
end

function ActivityShowCellView:setTitle( str )
	self.m_title:setString(str)
	local size = self.m_title:getContentSize()
	self.m_leftSpr:setPositionX(-size.width * 0.5 - 10)
	self.m_rightSpr:setPositionX(size.width * 0.5 + 10)
	local scalex = (self.width * 0.5 - size.width * 0.5 - 10) / self.m_rightSpr:getContentSize().width
	self.m_leftSpr:setScaleX(scalex)
	self.m_rightSpr:setScaleX(scalex)
end
-----------------------------------------ActivityShowCellView-----------------------------------
-----------------------------------------ActivityShowCellView-----------------------------------
-----------------------------------------ActivityShowCellView-----------------------------------







-----------------------------------------ActivityShowCellModel-----------------------------------
-----------------------------------------ActivityShowCellModel-----------------------------------
-----------------------------------------ActivityShowCellModel-----------------------------------

-- 如果纯展示 可以用这个
function ActivityShowCellModel:ctor( idx, iconStr, num, colorStr )
	-- MyPrint("ActivityShowCellModel:ctor", idx, iconStr, num, colorStr)
	self.m_idx = idx
	self.m_iconStr = iconStr
	self.m_num = num
	self.m_colorStr = colorStr

	local proxy = cc.CCBProxy:create()
    local ccbiUrl = "ActivityShowCellModel"
    local node = CCBReaderLoad(ccbiUrl, proxy, self)
    self:addChild(node)
    
	self:initSelf()

	self:setContentSize(cc.size(0, 0))
end

function ActivityShowCellModel:initSelf(  )
	if nil ~= self.m_colorStr then
		local spr = CCLoadSprite:call("createSprite", self.m_colorStr)
		spr:setAnchorPoint(cc.p(0.5, 0.5))
		self.m_iconNode:addChild(spr)
		CCCommonUtilsForLua:call("setSpriteMaxSize", spr, 75, true)
		self.m_colorSpr = spr
	end
	if nil ~= self.m_iconStr then
		local spr = CCLoadSprite:call("createSprite", self.m_iconStr, CCLoadSpriteType.CCLoadSpriteType_GOODS)
		spr:setAnchorPoint(cc.p(0.5, 0.5))
		self.m_iconNode:addChild(spr)
		CCCommonUtilsForLua:call("setSpriteMaxSize", spr, 75, true)
		self.m_spr = spr
	end
	if nil ~= self.m_num then
		self.m_numLabel:setString(tostring(self.m_num))
	end
end

function ActivityShowCellModel:setSprSize( sizewidth )
	if nil ~= self.m_spr then
		CCCommonUtilsForLua:call("setSpriteMaxSize", self.m_spr, sizewidth, true)
	end
	if nil ~= self.m_colorSpr then
		CCCommonUtilsForLua:call("setSpriteMaxSize", self.m_colorSpr, sizewidth, true)
	end
end
-----------------------------------------ActivityShowCellModel-----------------------------------
-----------------------------------------ActivityShowCellModel-----------------------------------
-----------------------------------------ActivityShowCellModel-----------------------------------




-----------------------------------------ActivityScrollLabelwidget-----------------------------------
-----------------------------------------ActivityScrollLabelwidget-----------------------------------
-----------------------------------------ActivityScrollLabelwidget-----------------------------------

function ActivityScrollLabelwidget:ctor( str, size, horizonAlign )
	MyPrint("ActivityScrollLabelwidget:ctor")
	self:setContentSize(size)
	self:setAnchorPoint(cc.p(0, 0))

	local label = cc.Label:create()
	label:setString(str)
    label:setAnchorPoint(cc.p(0.5, 1))
    label:setSystemFontSize(18)
    label:setColor(cc.c3b(147, 122, 92))
    label:setDimensions(size.width - 20, 0)
    if horizonAlign == nil then
    	horizonAlign = cc.TEXT_ALIGNMENT_CENTER
    end
    label:setHorizontalAlignment(horizonAlign)
    label:setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_TOP)
    
    local labelsize = label:getContentSize()
    label:setPositionX(size.width * 0.5)
    if labelsize.height < size.height then
    	label:setPositionY(size.height - (size.height - labelsize.height) * 0.5)
    	self:addChild(label)
    else
    	local view = cc.ScrollView:create()
    	view:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
	    view:setViewSize(size)
	    view:setContentSize(cc.size(size.width, labelsize.height))
	    view:addChild(label)
	    label:setAnchorPoint(cc.p(0.5, 1))
	    label:setPosition(cc.p(size.width * 0.5, labelsize.height))
	    self:addChild(view)
	    view:setPosition(cc.p(0, 0))
	    view:setAnchorPoint(cc.p(0, 0))
	    view:setContentOffset(cc.p(0, size.height - labelsize.height))
	end
end
-----------------------------------------ActivityScrollLabelwidget-----------------------------------
-----------------------------------------ActivityScrollLabelwidget-----------------------------------
-----------------------------------------ActivityScrollLabelwidget-----------------------------------






