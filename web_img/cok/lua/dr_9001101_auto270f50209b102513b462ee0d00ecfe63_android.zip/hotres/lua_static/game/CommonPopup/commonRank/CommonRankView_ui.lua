----------------------------
-- Author: Elex
-- Date: 2019-08-26 Monday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CommonRankView_ui = class("CommonRankView_ui")

--#ui propertys


--#function
function CommonRankView_ui:create(owner, viewType, paramTable)
	local ret = CommonRankView_ui.new()
	CustomUtility:LoadUi("CommonRankView.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function CommonRankView_ui:initLang()
	LabelSmoker:setText(self.m_pLabelTTF21, "660017")
	LabelSmoker:setText(self.m_pLabelTTF17, "221128")
	LabelSmoker:setText(self.m_anonymousOpenLabel, "150687")
end

function CommonRankView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CommonRankView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CommonRankView_ui:onPhaseButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onPhaseButtonClick", pSender, event)
end

function CommonRankView_ui:onSearchButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onSearchButtonClick", pSender, event)
end

function CommonRankView_ui:onAnonymousClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onAnonymousClick", pSender, event)
end

function CommonRankView_ui:initTableView()
	TableViewSmoker:createView(self, "m_listTableView", "game.CommonPopup.commonRank.CommonRankPlayerTblCell", 1, 10, "CommonRankPlayerTblCell")
end

function CommonRankView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return CommonRankView_ui

