--RewardTableCell
local RewardTblCell = class("RewardTblCell", function()
	return CCTableViewCell:create()
end)

function RewardTblCell:create()
	local view = RewardTblCell.new()
	Drequire("game.CommonPopup.RewardTblCell_ui"):create(view, 0)
	view.orgPosy = view.ui.m_rwdNode:getPositionY()
	view.orgScale = view:getScale()
	return view
end

function RewardTblCell:refreshCell(info, idx)
	self.ui.m_iconSpNode:removeAllChildren()
    self.ui.m_iconNumLabel:setString("")
    self:setScale(info.scale or self.orgScale)
    self.ui.m_rwdNode:setPositionY(info.posy or self.orgPosy)
    LibaoCommonFunc.createRewardItemInfo(info, self.ui.m_iconSpNode, 76, nil, self.ui.m_iconNumLabel, nil, true)
end

return RewardTblCell