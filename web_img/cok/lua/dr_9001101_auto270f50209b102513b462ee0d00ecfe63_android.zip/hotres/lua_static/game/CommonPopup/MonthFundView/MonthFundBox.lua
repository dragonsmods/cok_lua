
--月基金礼包
local MonthFundBox = class("MonthFundBox",cc.Node)
local MonthFundBoxCell = class("MonthFundBoxCell", cc.Node)

local BOXSTATE = {
    BOXSTATE_NOT_FINISH = 0, --没有完成
    BOXSTATE_NOT_GET = 1, -- 已完成没领取
    BOXSTATE_GETED = 2--已领取
}

local TableViewSmoker = Drequire("Editor.TableViewSmoker")
function MonthFundBox:create(boxData,ccbi,cellccbi)
    local view = MonthFundBox.new()
    --Drequire("game.knightActivity.answerActivity.MonthFundBox_ui"):create(view, 5)
    local ccbi = ccbi or "MonthFundBox.ccbi"
    utils.getExtendClass( "Template_ui" ):create(view,ccbi,0,nil,true,{})
   
    self.cellccbi = cellccbi or "MonthFundBoxCell"
    if view:initView(boxData) then
        return view
    end
end

function MonthFundBox:initView( boxData)
    self.boxCells = {}
    local len = #boxData
    for i,v in ipairs(boxData) do
      
        local cell = MonthFundBoxCell:create(v)
        cell:setZOrder(len - i)
        self.ui.m_nodeBox:addChild(cell)
        cell:setPosition(ccp(130 * ( i - 1),0))
        table.insert(self.boxCells,cell)
        
    end
    
    return true
end

function MonthFundBox:refreshView(boxData)
    for i,v in ipairs(boxData) do
        if self.boxCells[i] then
            self.boxCells[i]:refreshCell(v,i)
        end
    end
end

function MonthFundBox:onEnter( )
end
function MonthFundBox:onExit( )
  
end
function MonthFundBox:onClickClose()
    self.ctl:reqPanelBaseData() 
    PopupViewController:call("goBackPopupView")
end


--------------------------------------------------

function MonthFundBoxCell:create(info)
	local view = MonthFundBoxCell.new()
	local ccbi = info.cellccbi or "MonthFundBoxCell.ccbi"
	utils.getExtendClass( "Template_ui" ):create(view,ccbi,0,nil,true,{})
      if view:initView(info) then
        return view
    end
    return view
end



function MonthFundBoxCell:initView(info)
    self.info = info
    self:registerTouch()
    self:refreshCell(  self.info )
    return true
end
function MonthFundBoxCell:registerTouch( ... )
    -- body
       local function touchHandle(eventType, x, y)
        if eventType == "began" then
          return self:onTouchBegan(x, y)
        elseif eventType == "ended" then
         -- self:onTouchEnded(x, y)
        end
     end
    
     self.ui.m_touchLayer:registerScriptTouchHandler(touchHandle)
     self.ui.m_touchLayer:setTouchEnabled(true)
     self.ui.m_touchLayer:setSwallowsTouches(false)
  
  end
function MonthFundBoxCell:onTouchBegan(x,y)
      if  touchInside( self.ui.m_touchLayer, x, y) then
         if self.info.state == BOXSTATE.BOXSTATE_NOT_GET  then
            --已完成没领取
            if self.info.reqRewardFunc  then
                self.ui.m_touchLayer:setTouchEnabled(false)
                self.info.reqRewardFunc()
            end
           
         else
            --弹出界面
            self:getRewardBack()
         end
         return true
      end
      return false
end
function MonthFundBoxCell:refreshCell(info,idx)
    self.info = info 
    self.ui.m_sprPro:setVisible(info.bottom ~= nil)
    self.ui.m_touchLayer:setTouchEnabled(true)
    CCCommonUtilsForLua:call("setSpriteGray",  self.ui.m_sprBox, false)
    self.ui.m_parNode:removeAllChildren()
    if info.state == BOXSTATE.BOXSTATE_NOT_GET then
        ---没有领取
        self:addEffect()
    elseif info.state == BOXSTATE.BOXSTATE_GETED then
       
        CCCommonUtilsForLua:call("setSpriteGray",  self.ui.m_sprBox, true)
    end
    if info.bottom  then
        local now = math.max(info.num - info.bottom,0)
        local target = info.target - info.bottom
        if target > 0 then
            local pro = math.min(now/target,1)
            self.ui.m_sprPro:setScaleX(pro)
        end
    end
   
end

function MonthFundBoxCell:addEffect()
    self.ui.m_parNode:removeAllChildren()
	local params = {}	
	params.tblParticles ={"DragonCristal_4_0.plist","DragonCristal_4_1.plist","DragonCristal_4_2.plist"}
	params.tblPositions = {cc.p(0,0),cc.p(0,0),cc.p(0,0)}
	params.isCreateNewParNode = true
	params.scale = 1
    self.ui.m_parNode:addChild(createParticlesNode(params))
	
end
function MonthFundBoxCell:onEnter()
    registerScriptObserver(self, self.getRewardBack, "MSG_GET_REWARD_DETAIL_BACK")
end
function MonthFundBoxCell:onExit()
    unregisterScriptObserver(self, "MSG_GET_REWARD_DETAIL_BACK")
end
function MonthFundBoxCell:getRewardBack(ref)
	if not self.info.rewardId or self.info.rewardId == "" then return end
    if ref and ref:getCString() ~= self.info.rewardId then
        return
    end
    local reward = GlobalData:call("getCachedRewardData", tostring(self.info.rewardId))
    if reward == nil then
        GlobalData:call("requestRewardData",self.info.rewardId)
	else
		
     
        local rwdData = arrayToLuaTable(reward)
        local data = {rewardId = self.info.rewardId,reward = rwdData, titleName = getLang(self.info.title)}
        local view = Drequire("game.CommonPopup.MonthFundView.MonthFundRewardView"):create(data)
        PopupViewController:addPopupView(view)
    end
end


return MonthFundBox