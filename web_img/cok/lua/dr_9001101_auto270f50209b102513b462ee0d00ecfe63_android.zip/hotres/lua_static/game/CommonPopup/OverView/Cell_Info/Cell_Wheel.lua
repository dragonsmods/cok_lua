--转盘(server)
local Cell_Wheel = class("Cell_Wheel",Drequire("game.CommonPopup.OverView.Cell_Info.Cell_MainFile"))
local PreviewController = require("game.CommonPopup.OverView.PreviewController")
local FUN_BUILD_SACRIFICE = 428000 --许愿池

function Cell_Wheel:create(Id)
    local ret = Cell_Wheel.new(Id)
    if ret:initBaseById(Id) then
        return ret
    end
end
function Cell_Wheel:getCellDataTbl()
    if not self:checkIsVisible() then
        return
    end
    local _id = ''
    local _finishTime = -1
    local _state = -1
    local _label = ""
    local _name = ""
    local _icon = ""
    local _visible = ""
    local _cancelJump = false
	local ctl = PreviewController.getInstance()
    local serverTbl = ctl.serverDataTbl or {}
    local tempTbl = {}
    --精铁转盘
    _id = "30711021"
    local heroTurnTableFreeTimes = tonumber(serverTbl.heroTurnTableFreeTimes) or 0    
    local buildId = FunBuildController:call("getMaxLvBuildByType", FUN_BUILD_SACRIFICE)
    if buildId > 0 then
        if heroTurnTableFreeTimes > 0 then
            _state = self.Queue_ST_WORK
            _finishTime = heroTurnTableFreeTimes
            _label = self:getDialogByIdIndex(_id,1)
        else
            _cancelJump = true
            _state = self.Queue_ST_IDLE
            _finishTime = heroTurnTableFreeTimes
            _label = self:getDialogByIdIndex(_id,3)
        end
    else
        _state = self.Queue_ST_LOCK
        _finishTime = -1
        _label = "2000442" --未解锁
    end
    _name,_icon,_visible = self:getNameIconVisibleBySubId(_id)
    local meta = {id = _id, name = _name,icon = _icon, state = _state,param1 = _finishTime, label = _label, cancelJump = _cancelJump,cell = self}
    if CCCommonUtilsForLua:isFunOpenByKey("hero_roulette") and _visible == "1" then
        table.insert(tempTbl, meta)
    end

    --水晶转盘
    _id = "30711022"
    _cancelJump = false
    local crystalTurnTableFreeTimes = tonumber(serverTbl.crystalTurnTableFreeTimes) or 0
    if crystalTurnTableFreeTimes > 0 then
        _state = self.Queue_ST_WORK
        _finishTime = crystalTurnTableFreeTimes
        _label = self:getDialogByIdIndex(_id,1)
    else
        _cancelJump = true
        _state = self.Queue_ST_IDLE
        _finishTime = crystalTurnTableFreeTimes
        _label = self:getDialogByIdIndex(_id,3)
    end
    _name,_icon,_visible = self:getNameIconVisibleBySubId(_id)
    local meta2 = {id = _id, name = _name,icon = _icon, state = _state,param1 = _finishTime, label = _label, cancelJump = _cancelJump,cell = self}
    if CCCommonUtilsForLua:isFunOpenByKey("dragonglass_charge") and _visible == "1" then
        table.insert(tempTbl, meta2)
    end
    if #tempTbl > 0 then
        self.CellTbl.cellMeta = tempTbl
    end
    return self.CellTbl

end
function Cell_Wheel:OnClickJump(_id,_state)
    if _id == "30711021" then
        if _state ~= self.Queue_ST_LOCK then
            self:jumpByTypeAndTarget(1,FUN_BUILD_SACRIFICE)
        else
            self:jumpByTypeAndTarget(1,FUN_BUILD_SACRIFICE)
        end
    
    elseif _id == "30711022" then
        local view = Drequire("game.hero.NewUI.HeroGetRotateView"):create("89698","crystal_type")
        PopupViewController:call("addPopupInView", view)
    end
end
return Cell_Wheel