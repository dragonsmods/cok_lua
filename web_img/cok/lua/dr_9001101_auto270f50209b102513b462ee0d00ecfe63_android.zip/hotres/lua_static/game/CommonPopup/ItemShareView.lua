local MSG_GET_REWARD_DETAIL_BACK = "MSG_GET_REWARD_DETAIL_BACK"

local ItemShareView = class("ItemShareView",
	function() 
		return PopupBaseView:create() 
	end
)
ItemShareView.__index = ItemShareView

function ItemShareView:create(itemId)
	local view = ItemShareView.new()
	if view:initView(itemId) then
		return view
	end
	return nil
end

function ItemShareView:initView(itemId)
	if self:init(true, 0) then
		self:setHDPanelFlag(true)

		local proxy = cc.CCBProxy:create()
		local ccbUri = "ItemShareView.ccbi"
		local node = CCBReaderLoad(ccbUri, proxy, self)
		
		local function onNodeEvent(event)
			if event == "enter" then
				self:onEnter()
			elseif event == "exit" then
				self:onExit()
			end
		end
		node:registerScriptHandler(onNodeEvent)
		self:addChild(node)

		local winSize = cc.Director:sharedDirector():getIFWinSize()
		self:setContentSize(winSize)

		if CCCommonUtilsForLua:isIosAndroidPad() then
			self.m_mainNode:setScale(2)
		end

		local listSize = self.m_listNode:getContentSize()
		self.m_tableView = cc.TableView:create(listSize)
		local numberOfCellsInTableView = function(tab)
			return self:numberOfCellsInTableView(tab)
		end
		local cellSizeForTable = function(tab, idx)
			return self:cellSizeForTable(tab, idx)
		end
		local tableCellAtIndex = function(tab, idx)
			return self:tableCellAtIndex(tab, idx)
		end
		self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
		self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
		self.m_tableView:setDelegate()
		self.m_tableView:registerScriptHandler(numberOfCellsInTableView, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
		self.m_tableView:registerScriptHandler(cellSizeForTable, cc.TABLECELL_SIZE_FOR_INDEX)
		self.m_tableView:registerScriptHandler(tableCellAtIndex, cc.TABLECELL_SIZE_AT_INDEX)
		self.m_listNode:addChild(self.m_tableView)

		self.touchLayer = cc.Layer:create()
		local function touchHandle(eventType, x, y)
			if eventType == "began" then
				return self:onTouchBegan(x, y)
			elseif eventType == "ended" then
				self:onTouchEnded(x, y)
			end
		end
		self.touchLayer:registerScriptTouchHandler(touchHandle)
		self.touchLayer:setTouchEnabled(true)
		self.touchLayer:setSwallowsTouches(false)
		self:addChild(self.touchLayer)

		self.m_titleTTF:setString(getLang("301120"))
		self.m_msgLabel:setString(getLang("301123"))
		CCCommonUtilsForLua:setButtonTitle(self.m_okBtn, getLang("107098"))

		self.m_itemId = tostring(itemId)
		Dprint("ItemShareView:initData self.m_itemId = " .. self.m_itemId)
		-- local toolInfo = ToolController:call("getToolInfoByIdForLua", tonumber(self.m_itemId))
		-- self.m_shareId = toolInfo:getProperty("para1")
		self.m_shareId = CCCommonUtilsForLua:call("getPropByIdGroup", "goods", self.m_itemId, "para1")
		Dprint("ItemShareView:initData self.m_shareId = " .. self.m_shareId)

		self:initData()

		return true
	end

	return false
end

function ItemShareView:removeWaitInterface( )
	if self.m_waitInterface then
    	self.m_waitInterface:call("remove")
    	self.m_waitInterface = nil
	end
end

function ItemShareView:addWaitInterface( ctl )
	self.m_waitInterface = GameController:call("showWaitInterface1", self.m_listTableView)
	local pos = cc.p(self.m_listTableView:getContentSize().width / 2, self.m_listTableView:getContentSize().height / 2)
	self.m_waitInterface:setPosition(pos)
end

function ItemShareView:initData()
	self.m_data = {}
	local rewardId = CCCommonUtilsForLua:call("getPropByIdGroup", "game_share", self.m_shareId, "reward")
	Dprint("ItemShareView:initData rewardId = " .. rewardId)
	if rewardId ~= nil then
		local rewardData = GlobalData:call("getCachedRewardData", rewardId)
		if rewardData ~= nil then
			rewardData = arrayToLuaTable(rewardData)
			for i, v in ipairs(rewardData) do
				self.m_data[#self.m_data + 1] = { rewardType = 0, rewardData = v }
			end
		else
			GlobalData:call("requestRewardData", rewardId)
		end
	end
	local statusStr = CCCommonUtilsForLua:call("getPropByIdGroup", "game_share", self.m_shareId, "status")
	Dprint("ItemShareView:initData statusStr = " .. statusStr)
	if statusStr ~= nil and statusStr ~= "" then
		local statusIds = string.split(statusStr, ";")
		for i = 1, #statusIds do
			local name = CCCommonUtilsForLua:call("getPropByIdGroup", "status", statusIds[i], "name")
			local icon = CCCommonUtilsForLua:call("getPropByIdGroup", "status", statusIds[i], "icon")
			self.m_data[#self.m_data + 1] = { rewardType = 1, rewardData = { name = name, icon = icon } }
		end
	end
	dump(self.m_data, "ItemShareView:initData")
end

function ItemShareView:reloadData()
	self:initData()
	self.m_tableView:reloadData()
end

function ItemShareView:onEnter()
	dump("ItemShareView:onEnter+++")
	self.m_tableView:reloadData()
	local function callback() self:reloadData() end
	local handler = self:registerHandler(callback)

	-- local function callback3(ref)
	-- 	dump(ref, "MSG_FBFeedDialogResult+++")
	-- 	if not ref then
	-- 		return
	-- 	end
	-- 	local flag = ref:getValue() or -911
	-- 	dump(flag,"flag+++")
	-- 	if flag == 1 then 
	-- 		self.m_okBtn:setEnabled(true)
	-- 	end
	-- 	self:logShareResult(tostring(flag))
	-- end

	-- local handler3 = self:registerHandler(callback3)
	CCSafeNotificationCenter:registerScriptObserver(self, handler, MSG_GET_REWARD_DETAIL_BACK)
	-- CCSafeNotificationCenter:registerScriptObserver(self, handler3, "MFBFeedDialogResult")
end

function ItemShareView:onExit()
	dump("ItemShareView:onExit+++")
	CCSafeNotificationCenter:unregisterScriptObserver(self, MSG_GET_REWARD_DETAIL_BACK)
	-- CCSafeNotificationCenter:unregisterScriptObserver(self, "MFBFeedDialogResult")
end

function ItemShareView:onTouchBegan(x, y)
	self.m_touchPoint = ccp(x, y)
	return true
end

function ItemShareView:onTouchEnded(x, y)
	if not isTouchInside(self.m_touchNode, x, y) and ccpDistance(ccp(x, y), self.m_touchPoint) < 20 then
		self:onCloseButtonClick()
	end
end

function ItemShareView:numberOfCellsInTableView(tab)
	return #self.m_data
end

function ItemShareView:cellSizeForTable(tab, idx)
	return 548, 70
end

function ItemShareView:tableCellAtIndex(tab, idx)
	if idx >= #self.m_data then return end

	local dict = self.m_data[idx + 1]
	dump(dict, "ItemShareView:tableCellAtIndex")
	local cell = tab:dequeueCell()
	if cell then
		local node = cell:getChildByTag(666)
		if node then node:setData(dict.rewardType, dict.rewardData) end
	else
		Drequire "game.CommonPopup.ItemShareCell"
		local node = ItemShareCell:create(dict.rewardType, dict.rewardData)
		node:setTag(666)
		cell = cc.TableViewCell:create()
		cell:addChild(node)
	end
	return cell
end

function ItemShareView:onCloseButtonClick()
	PopupViewController:call("removePopupView", self)
end

function ItemShareView:onOkClick()
	local function callback(tblData)
		if tblData.shareResult == 1 then
			ToolController:call("getInstance"):setProperty("m_willUseItem", self.m_itemId)
			ToolController:call("onOkUse")
			PopupViewController:call("removePopupView", self)
		end
	end
	local view = Drequire("game.CommonPopup.CommonShareView"):create(1, self.m_shareId, nil, callback, "ItemShare")
	if view and view:hasAnyShareChannel() then
		PopupViewController:addPopupView(view)	
	else
		callback({shareResult=1})
	end
end

return ItemShareView