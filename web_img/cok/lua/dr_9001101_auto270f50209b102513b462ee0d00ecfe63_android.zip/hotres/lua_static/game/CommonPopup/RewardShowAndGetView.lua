RewardShowAndGetView = class("RewardShowAndGetView", function (  )
	return PopupBaseView:call("create")
end)

RewardShowAndGetCell = class("RewardShowAndGetCell", function (  )
	return cc.TableViewCell:create()
end)


function RewardShowAndGetView.create( data, title )
	local ret = RewardShowAndGetView.new(data, title)
	if ret:initSelf() == false then
		ret = nil
	end
	return ret
end

function RewardShowAndGetView:ctor( data, title )
	self.data = data
	self.titlestr = title
	self.callBack = nil
end

function RewardShowAndGetView:initSelf(  )
	MyPrint("RewardShowAndGetView:initSelf")
	if self:init(true, 0) == false then
		MyPrint("RewardShowAndGetView init error")
    	return false	
	end
	self:setHDPanelFlag(true)

	local winsize = cc.Director:getInstance():getIFWinSize()

	self:setContentSize(winsize)

	local proxy = cc.CCBProxy:create()
    local ccbiUrl = "RewardShowAndGetView"
	local node = CCBReaderLoad(ccbiUrl, proxy, self)
    self:addChild(node)

    if CCCommonUtilsForLua:call("isIosAndroidPad") then
    	self.m_mainNode:setScale(2)
    end
    if nil == self.data then
    	return false
    end
    dump(self.data, "self.data")

    CCCommonUtilsForLua:call("setButtonTitle", self.m_okBtn, getLang("confirm"))

    self.m_tableView = cc.TableView:create(self.m_listNode:getContentSize())
	self.m_listNode:addChild(self.m_tableView)
	self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
	self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
	self.m_tableView:setDelegate()
	local function scrollViewDidScroll( view )
		return self:scrollViewDidScroll(view)
	end

	local function cellSizeForTable( view, idx )
		return self:cellSizeForTable(view, idx)
	end

	local function tableCellAtIndex( view, idx )
		return self:tableCellAtIndex(view, idx)
	end

	local function numberOfCellsInTableView( view )
		return self:numberOfCellsInTableView(view)
	end

	self.m_tableView:registerScriptHandler(scrollViewDidScroll,cc.SCROLLVIEW_SCRIPT_SCROLL)
	self.m_tableView:registerScriptHandler(cellSizeForTable,cc.TABLECELL_SIZE_FOR_INDEX)
	self.m_tableView:registerScriptHandler(tableCellAtIndex,cc.TABLECELL_SIZE_AT_INDEX)
	self.m_tableView:registerScriptHandler(numberOfCellsInTableView,cc.NUMBER_OF_CELLS_IN_TABLEVIEW)

	self.m_tableView:setAnchorPoint(cc.p(0, 0))
	self.m_tableView:reloadData()
	self.m_tableView:setContentOffset(cc.p(0, self.m_listNode:getContentSize().height - self.m_tableView:getContentSize().height))


	self.startTouchPt = cc.p(0, 0)
	self.touchLayer = cc.Layer:create()
	self:addChild(self.touchLayer)
	local function touchHandle( eventType, x, y )
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		else
			self:onTouchEnded(x, y)
		end
	end
	self.touchLayer:registerScriptTouchHandler(touchHandle)
	self.touchLayer:setTouchEnabled(true)
	self.touchLayer:setSwallowsTouches(false)


	self.m_titleLabel:setString(self.titlestr)

    return true
end

function RewardShowAndGetView:setCalllBack( call )
	self.callBack = call
end

function RewardShowAndGetView:setButtonTitle( str )
	CCCommonUtilsForLua:call("setButtonTitle", self.m_okBtn, str)
end

function RewardShowAndGetView:setButton1Title( str )
	CCCommonUtilsForLua:call("setButton1Title", self.m_btn1, str)
end

function RewardShowAndGetView:setButton1Visible( bVisible )
	self.m_btn1:setVisible(bVisible)
end

function RewardShowAndGetView:setButton1CallBack( call )
	self.btn1CallBack = call
end

function RewardShowAndGetView:setMsgLabel1( str )
	MyPrint("setMsgLabel1", str)
	self.m_msgLabel1:setString(str)
end

function RewardShowAndGetView:setMsgLabel2( str )
	MyPrint("setMsgLabel2", str)
	self.m_msgLabel2:setString(str)
end

function RewardShowAndGetView:onOkClick(  )
	if nil ~= self.callBack then
		self.callBack()
	end
	self:call("closeSelf")
end

function RewardShowAndGetView:onClickBtn1(  )
	if nil ~= self.btn1CallBack then
		self.btn1CallBack()
	end
end

function RewardShowAndGetView:scrollViewDidScroll( view )
	
end

function RewardShowAndGetView:cellSizeForTable( view, idx )
	return 530, 100
end

function RewardShowAndGetView:tableCellAtIndex( view, idx )
	idx = idx+1
    if idx > #self.data then
		return nil
    end
    local cell = view:dequeueCell()
    if cell ~= nil then 
		cell:setData(self.data[idx])
    else
        cell = RewardShowAndGetCell.new(self.data[idx])
    end
    return cell
end

function RewardShowAndGetView:numberOfCellsInTableView( view )
	return #self.data
end

function RewardShowAndGetView:onTouchBegan( x, y )
	if isTouchInside(self.m_touchNode, x, y) then
		return false
	end
	return true
end

function RewardShowAndGetView:onTouchEnded( x, y )
	if isTouchInside(self.m_touchNode, x, y) then
		return
	end
	self:call("closeSelf")
end

function RewardShowAndGetView:onCloseBtnClick(  )
	self:call("closeSelf")
end

function RewardShowAndGetCell:ctor( data )
	MyPrint("RewardShowAndGetCell:ctor")
	dump(data, "data")
	
	local proxy = cc.CCBProxy:create()
    local ccbiUrl = "RewardShowAndGetCell"
	local node = CCBReaderLoad(ccbiUrl, proxy, self)
    self:addChild(node)


    self:setData(data)

end

function RewardShowAndGetCell:_buildIcon( value,colorKey )
	if not value then
		return
	end
	colorKey = colorKey or "color"
	local bgSpr = CCLoadSprite:call("createSprite", "icon_kuang.png")

	local colorstr = CCCommonUtilsForLua:call("getToolBgByColor", tonumber(CCCommonUtilsForLua:call("getPropById", tostring(value.id), colorKey)) or 1)
	-- cclog("colorstr is %s,",colorstr)

	local colorSpr = CCLoadSprite:call("createSprite", colorstr)

	local icon = CCCommonUtilsForLua:call("getIcon", tostring(value.id))
    local spr = CCLoadSprite:call("createSprite", icon)
    spr:setAnchorPoint(cc.p(0.5, 0.5))
    CCCommonUtilsForLua:call("setSpriteMaxSize", bgSpr, 85, true)
    CCCommonUtilsForLua:call("setSpriteMaxSize", colorSpr, 75, true)
    CCCommonUtilsForLua:call("setSpriteMaxSize", spr, 75, true)
    self.m_iconNode:addChild(bgSpr)
    self.m_iconNode:addChild(colorSpr)
    self.m_iconNode:addChild(spr)
    local dialog = CCCommonUtilsForLua:call("getPropById", tostring(value.id), "name")
	self.m_nameLabel:setString(getLang(dialog))
	local addNum = value.num or value.rewardAdd
    if nil ~= addNum then
		self:setCnt(addNum)
    end
end

function RewardShowAndGetCell:setCnt( num )
	local s = CC_CMDITOA(num)
	local s_len = string.len(s)

	local txt = self.m_cntLabel
	local ori_x = txt.m_ori_x
	if not ori_x then
		ori_x = txt:getPositionX()
		txt.m_ori_x = ori_x
	end

	txt:setString("")
	txt:setAnchorPoint(cc.p(0.5,0.5))
	txt:setPositionX(ori_x)

	local adjust_flag = s_len > 5
	if adjust_flag then
		txt:setAnchorPoint(cc.p(1,0.5))
		txt:setPositionX(ori_x + 30)
	else
		txt:setPositionX(ori_x - 15)
	end
	txt:setString(s)

end

function RewardShowAndGetCell:setData( data )
	MyPrint("RewardShowAndGetCell:setData", data)
	dump(data, "data")
	if nil == data then
		return
	end

	local itemId = data and data.value and data.value.id
	if itemId then
		local isDragonSkill = CCCommonUtilsForLua:isDragonSkill(tonumber(itemId))
		if isDragonSkill then
			data.type = RewardTypeConfig.R_DRAGON_SKILL_ID
			CCLoadSprite:call("loadDynamicResourceByName", "dragonCave")
		end
	end

	self.m_iconNode:removeAllChildren()
	self.m_nameLabel:setString("")
	self.m_cntLabel:setString("")

	local t = tonumber(data.type)

	if t == 7 or t == 14 then
		-- 道具 装备
		self:_buildIcon(data.value,"color")
	elseif t == RewardTypeConfig.R_DRAGON_SKILL_ID then
		self:_buildIcon(data.value,"quality")
	else
		local pic = CCLoadSprite:call("createSprite", RewardController:call("getPicByType", t, -1), CCLoadSpriteType.CCLoadSpriteType_DEFAULT)
		CCCommonUtilsForLua:call("setSpriteMaxSize", pic, 94, true)
		self.m_iconNode:addChild(pic)

		local value = data.value
		if nil ~= value then
			value = tonumber(value)
			if nil ~= value then
				self:setCnt(value)
			end
		end
	end
end