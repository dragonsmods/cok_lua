----------------------------
-- Author: Elex
-- Date: 2019-03-26 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local RankActDesView_ui = class("RankActDesView_ui")

--#ui propertys


--#function
function RankActDesView_ui:create(owner, viewType, paramTable)
	local ret = RankActDesView_ui.new()
	CustomUtility:LoadUi("RankActDesView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function RankActDesView_ui:initLang()
	LabelSmoker:setText(self.m_labelTitle, "182107")
end

function RankActDesView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function RankActDesView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function RankActDesView_ui:onClickBtnClose(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnClose", pSender, event)
end

return RankActDesView_ui

