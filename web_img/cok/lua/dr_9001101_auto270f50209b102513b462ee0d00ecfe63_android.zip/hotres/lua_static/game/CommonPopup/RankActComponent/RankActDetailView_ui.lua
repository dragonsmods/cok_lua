----------------------------
-- Author: Elex
-- Date: 2019-09-24 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local RankActDetailView_ui = class("RankActDetailView_ui")

--#ui propertys


--#function
function RankActDetailView_ui:create(owner, viewType, paramTable)
	local ret = RankActDetailView_ui.new()
	CustomUtility:LoadUi("RankActDetailView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function RankActDetailView_ui:initLang()
	LabelSmoker:setText(self.m_labelTitle, "182107")
end

function RankActDetailView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function RankActDetailView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function RankActDetailView_ui:onClickBtnClose(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnClose", pSender, event)
end

function RankActDetailView_ui:initTableView()
	TableViewSmoker:createView(self, "m_tableView", "game.CommonPopup.RankActComponent.RankActInfoCell", 1, 30, "RankActInfoCell")
	TableViewSmoker:createView(self, "m_secTableView", "game.CommonPopup.RankActComponent.RankActInfoCell", 1, 30, "RankActInfoCell")
end

function RankActDetailView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return RankActDetailView_ui

