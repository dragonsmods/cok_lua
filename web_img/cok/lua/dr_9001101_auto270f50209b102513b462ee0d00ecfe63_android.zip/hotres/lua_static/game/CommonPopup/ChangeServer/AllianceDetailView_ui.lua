----------------------------
-- Author: Elex
-- Date: 2019-05-28 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local AllianceDetailView_ui = class("AllianceDetailView_ui")

--#ui propertys


--#function
function AllianceDetailView_ui:create(owner, viewType, paramTable)
	local ret = AllianceDetailView_ui.new()
	CustomUtility:DoRes(520, true)
	CustomUtility:LoadUi("AllianceDetailView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function AllianceDetailView_ui:initLang()
end

function AllianceDetailView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function AllianceDetailView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function AllianceDetailView_ui:onClickBtnTip(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnTip", pSender, event)
end

function AllianceDetailView_ui:onControlButton21(pSender, event)
	ButtonSmoker:forwardFunction(self, "onControlButton21", pSender, event)
end

function AllianceDetailView_ui:onClickMail(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickMail", pSender, event)
end

function AllianceDetailView_ui:onClickJoin(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickJoin", pSender, event)
end

function AllianceDetailView_ui:onClickBtnAdd(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnAdd", pSender, event)
end

return AllianceDetailView_ui

