--[[
    ServerStopNoticeView
    停服公告界面
]]

local ServerStopNoticeView = class("ServerStopNoticeView", PopupBaseView)

function ServerStopNoticeView:create()
    local view = ServerStopNoticeView.new()
    Drequire("game.CommonPopup.ServerStopNoticeView_ui"):create(view)
    if view:initView() then
        return view
    end
    return
end

function ServerStopNoticeView:initView()
    local scrollView = cc.ScrollView:create()
    self.m_viewSize = self.ui.m_contentNode1:getContentSize()
    scrollView:setViewSize(self.m_viewSize)
    scrollView:setPosition(CCPoint(0,0))
    scrollView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
    scrollView:setClippingToBounds(true)
    scrollView:setBounceable(true)
    self.ui.m_contentNode1:addChild(scrollView)
    self.m_scrollView = scrollView

    self.m_ruleContent = cc.Label:createWithSystemFont("", "Helvetica", 20, cc.size(self.m_viewSize.width,0))
    self.m_ruleContent:setColor(cc.c3b(184, 172, 132))
    scrollView:addChild(self.m_ruleContent)
    scrollView:setContentSize(self.m_ruleContent:getContentSize())
    scrollView:setContentOffset(cc.p(0, self.m_viewSize.height - self.m_ruleContent:getContentSize().height))

    local function touchHandle( eventType, x, y )
        if eventType == "began" then
            return self:onTouchBegan(x, y)
        elseif eventType == "moved" then
            return self:onTouchMoved(x,y)
        else
            self:onTouchEnded(x, y)
        end
    end
    self:registerScriptTouchHandler(touchHandle)
    self:setTouchEnabled(true)

    self.m_controller = require("game.CommonPopup.ServerStopNoticeController").getInstance()
    self:updateNotice()
    return true
end

function ServerStopNoticeView:updateNotice()
    local notice = self.m_controller:getValidNotice()
    if notice then
        self.ui.m_titleLabel:setString(getLang(notice.noticeTitleDialog))
        if notice.notice_data_dialog and #notice.notice_data_dialog > 0 then
            self.m_ruleContent:setString(getLang(notice.noticeInfoDialog, unpack(notice.notice_data_dialog)))
        else
            self.m_ruleContent:setString(getLang(notice.noticeInfoDialog))
        end
    else
        self.ui.m_titleLabel:setString("")
        self.m_ruleContent:setString("")
    end
    self.m_scrollView:setContentSize(self.m_ruleContent:getContentSize())
    self.m_scrollView:setContentOffset(cc.p(0, self.m_viewSize.height - self.m_ruleContent:getContentSize().height))
end

function ServerStopNoticeView:onClickKnow()
    self:onCloseButtonClick()
end

function ServerStopNoticeView:onCloseButtonClick()
    PopupViewController:call("removePopupView", self)
end

function ServerStopNoticeView:onEnter()
    registerScriptObserver(self, self.updateNotice, "ServerStopNotice")
end

function ServerStopNoticeView:onExit()
    unregisterScriptObserver(self, "ServerStopNotice")
end

function ServerStopNoticeView:onTouchBegan(x, y)
    self.touchedInView = true
    return true
end

function ServerStopNoticeView:onTouchMoved(x, y)
    self.touchedInView = false
end

function ServerStopNoticeView:onTouchEnded(x, y)
    if self.touchedInView and not touchInside(self.ui.m_sprBg, x, y) then 
        self:onCloseButtonClick()
    end
end

return ServerStopNoticeView

