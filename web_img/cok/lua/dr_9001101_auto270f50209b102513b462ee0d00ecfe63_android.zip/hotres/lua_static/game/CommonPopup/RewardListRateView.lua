-- 通用概率展示窗口
-- example：
-- rwdData =
-- {
--     {"value":{"id":"36004400","num":"1","rate":"4"},"type":"7"},
--     {"value":{"id":"211929","num":"1","rate":"20"},"type":"7"},
-- }


local RewardListRateView = class("RewardListRateView",
    function()
        return PopupBaseView:create()
    end
)
RewardListRateView.__index = RewardListRateView

function RewardListRateView:create(rwdData)
    local view = RewardListRateView.new()
    Drequire("game.CommonPopup.RewardListRateView_ui"):create(view, 0)
    if view:initView(rwdData) then
        return view
    end
end

function RewardListRateView:initView(rwdData)
    -- dump(" RewardListRateView:initView ")
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_confirmBtn, getLang("confirm"))

    local sumRate = 0

    for index, reward in ipairs(rwdData) do
        if reward.value and reward.value.rate then
            sumRate = sumRate + atoi(reward.value.rate)
        end
    end

    for index, reward in ipairs(rwdData) do
        reward.sumRate = sumRate
    end

    self:registerTouchFuncs()
    self:call("setModelLayerOpacity",0)
    self.ui.m_titleLabel:setString(getLang("101553"))
    self.ui:setTableViewDataSource("m_pTableView1", rwdData)
    return true
end

function RewardListRateView:onTouchBegan(x, y)
    self.touchType = nil
    if not touchInside(self.ui.m_sprBG, x, y) then
        self.touchType = 1
    end
    return true
end

function RewardListRateView:onTouchMoved(x, y)

end

function RewardListRateView:onTouchEnded(x, y)
    if self.touchType == 1 and touchInside(self.ui.m_sprBG, x, y)==false then
        PopupViewController:call("removeLastPopupView")
    end
end

function RewardListRateView:onConfirmBtnClick()
    PopupViewController:call("removeLastPopupView")
end

return RewardListRateView



