local AllyApplyNode = class("AllyApplyNode", PopupBaseView)

function AllyApplyNode:create(applyCb)
    local node = AllyApplyNode.new(applyCb)
    Drequire("game.CommonPopup.ChangeServer.AllyApplyNode_ui"):create(node, 1)
    node:initNode()
    return node
end

function AllyApplyNode:ctor(applyCb)
    self.applyCb = applyCb
    self.ctrl = require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance()
end

function AllyApplyNode:initTableViewByOwner()
    local TableViewSmoker = Drequire("Editor.TableViewSmoker")
    TableViewSmoker:createView(self.ui, "m_listView", "game.CommonPopup.ChangeServer.AllyApplyCell", 1, 10, "AllyApplyCell")
end

function AllyApplyNode:initNode()
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_refreshBtn, getLang("173226"))
    self:setScale(1)

    self:call("setModelLayerDisplay", false)
    self:call("setViewSwallowTouch", false)

    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
    if playerInfo:call("isInAlliance") then
         --拉数据
        self:addLoadingAni()
        self.ctrl:getAllyTransfer()
    else
        self.ui.m_noTxt:setString(getLang("115207"))
    end

    self.ui.m_hideLabel:setString(getLang("173317"))
    
    if self.ctrl:isAnonymous() then
        self.ui.m_selectSp:setVisible(true)
    else
        self.ui.m_selectSp:setVisible(false)
    end
end

function AllyApplyNode:addLoadingAni()
	self:removeLoadingAni()

	self.m_loadingIcon = CCLoadSprite:call("createSprite", "loading_1.png")
	self.m_loadingIcon:setAnchorPoint(ccp(0.5, 0.5))

    local size = self.ui.m_listNode:getContentSize()
	self.m_loadingIcon:setPosition(ccp(size.width / 2, size.height / 2))

	local rotateAction = cc.RotateTo:create(0.5, 720)
	local rotateForever = cc.RepeatForever:create(rotateAction)
	self.m_loadingIcon:runAction(rotateForever)
	self.ui.m_listNode:addChild(self.m_loadingIcon, 1000000)
end

function AllyApplyNode:removeLoadingAni()
	if self.m_loadingIcon then
		self.m_loadingIcon:removeFromParent()
		self.m_loadingIcon = nil
    end
    
    if self.waitInterface then
        self.waitInterface:call("remove")
        self.waitInterface = nil
    end
end

function AllyApplyNode:onEnter()
    registerScriptObserver(self, self.updateNode, "AllyApplyNode:updateNode")
end

function AllyApplyNode:onExit()
    unregisterScriptObserver(self, "AllyApplyNode:updateNode") 
end

function AllyApplyNode:updateNode(param)
    self:removeLoadingAni()
    local data = dictToLuaTable(param)
    self.sourceData = data.alliances or {}
    self.ui:setTableViewDataSource("m_listView", self.sourceData)
end

function AllyApplyNode:tableCellTouched(tab, cell)
    local view = Drequire("game.CommonPopup.ChangeServer.AllianceDetailView"):create(cell:getDetail(), self.applyCb)
    PopupViewController:addPopupInView(view)
end

function AllyApplyNode:onClickSet()
    local anonymous = self.ui.m_selectSp:isVisible()
    self.ctrl:setAnonymous(not anonymous)
    self.ui.m_selectSp:setVisible(not anonymous)
end

return AllyApplyNode