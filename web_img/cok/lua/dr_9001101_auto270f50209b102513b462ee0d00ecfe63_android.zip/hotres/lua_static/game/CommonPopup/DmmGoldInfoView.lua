--@author:MM
--@date:2017.06.28

--#pre decl
local CC_CMDITOA = CC_CMDITOA
local _lang = _lang

local DmmGoldInfoView = class("DmmGoldInfoView",
    function()
        return PopupBaseView:create()  
    end
)
DmmGoldInfoView.__index = DmmGoldInfoView

DmmGoldInfoView.gold = 0
DmmGoldInfoView.freeGold = 0
DmmGoldInfoView.paidSpecialGold = 0
DmmGoldInfoView.paidGold = 0
DmmGoldInfoView.dmmFreeGold = 0
DmmGoldInfoView.dmmPaidSpecialGold = 0
DmmGoldInfoView.dmmPaidGold = 0
DmmGoldInfoView.isDmmBinded = false

function DmmGoldInfoView:create(dict)
    local view = DmmGoldInfoView.new()
    if (view:initView(dict)) then
        return view
    end
end

function DmmGoldInfoView:initView(dict)
    if (self:init(true, 0)) then
        self:setHDPanelFlag(true)
        self:setTitleName(_lang("9401232"))

        local proxy = cc.CCBProxy:create()
        local ccbUri = "DmmGoldInfoView"
        local node = CCBReaderLoad(ccbUri, proxy, self)
        self:addChild(node)

        --获得基础数据。
        if nil ~= dict then
            self.gold = dict["gold"] ~= nil and dict["gold"] or 0
            self.freeGold = dict["freeGold"] ~= nil and dict["freeGold"] or 0
            self.paidSpecialGold = dict["paidSpecialGold"] ~= nil and dict["paidSpecialGold"] or 0
            self.paidGold = dict["paidGold"] ~= nil and dict["paidGold"] or 0
            self.dmmFreeGold = dict["dmmFreeGold"] ~= nil and dict["dmmFreeGold"] or 0
            self.dmmPaidSpecialGold = dict["dmmPaidSpecialGold"] ~= nil and dict["dmmPaidSpecialGold"] or 0
            self.dmmPaidGold = dict["dmmPaidGold"] ~= nil and dict["dmmPaidGold"] or 0
            self.isDmmBinded = dict["isDmmBinded"] ~= nil and dict["isDmmBinded"] or false
        end

        self:updateView()

        self:changeBGHeight(self.m_viewBg)
        local winSize = cc.Director:sharedDirector():getIFWinSize()
        self:setContentSize(winSize)

        Dprint("fg/psg/pg/dfg/dpsg/dpg/db=", self.freeGold, self.paidSpecialGold, self.paidGold, self.dmmFreeGold, self.dmmPaidSpecialGold, self.dmmPaidGold, self.isDmmBinded)

        for i = 1, 4 do
            local fire1 = ParticleController:call("createParticle", string.format("UiFire_%d", i))
            self.m_fireNode1:addChild(fire1)

            local fire2 = ParticleController:call("createParticle", string.format("UiFire_%d", i))
            self.m_fireNode2:addChild(fire2)
        end

        return true
    end

    return false
end

function DmmGoldInfoView:updateView()
    self.m_descText:setString(_lang("9440379"))
    
    self.m_freeGoldName:setString(_lang("9401334")) --免费金币
    self.m_freeGoldAmount:setString(CC_CMDITOA(self.freeGold))

    self.m_paidSpecialGoldName:setString(_lang("9440377")) --普通充值金币
    self.m_paidSpecialGoldAmount:setString(CC_CMDITOA(self.paidSpecialGold))

    self.m_paidGoldName:setString(_lang("9440378")) --礼包充值金币
    self.m_paidGoldAmount:setString(CC_CMDITOA(self.paidGold))

    if self.isDmmBinded then
        self.m_dmmFreeGoldNode:setVisible(true)
        self.m_dmmPaidSpecialGoldNode:setVisible(true)
        self.m_dmmPaidGoldNode:setVisible(true)

        self.m_dmmFreeGoldName:setString(_lang("9401234")) --DMM免费金币
        self.m_dmmFreeGoldAmount:setString(CC_CMDITOA(self.dmmFreeGold))

        self.m_dmmPaidSpecialGoldName:setString(_lang("9440433")) --DMM普通充值金币
        self.m_dmmPaidSpecialGoldAmount:setString(CC_CMDITOA(self.dmmPaidSpecialGold))

        self.m_dmmPaidGoldName:setString(_lang("9440434")) --DMM礼包充值金币
        self.m_dmmPaidGoldAmount:setString(CC_CMDITOA(self.dmmPaidGold))
    else
        self.m_dmmFreeGoldNode:setVisible(false)
        self.m_dmmPaidSpecialGoldNode:setVisible(false)
        self.m_dmmPaidGoldNode:setVisible(false)
    end
end

return DmmGoldInfoView

