----------------------------
-- Author: Elex
-- Date: 2021-03-17 Wednesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local MonthFundRewardView_ui = class("MonthFundRewardView_ui")

--#ui propertys


--#function
function MonthFundRewardView_ui:create(owner, viewType, paramTable)
	local ret = MonthFundRewardView_ui.new()
	CustomUtility:LoadUi("MonthFundRewardView.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function MonthFundRewardView_ui:initLang()
end

function MonthFundRewardView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function MonthFundRewardView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function MonthFundRewardView_ui:onInfoBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onInfoBtnClick", pSender, event)
end

function MonthFundRewardView_ui:initTableView()
	TableViewSmoker:createView(self, "m_pTableView1", "game.CommonPopup.MonthFundView.MonthFundRewardCell", 1, 5, "MonthFundRewardCell")
end

function MonthFundRewardView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return MonthFundRewardView_ui

