----------------------------
-- Author: Elex
-- Date: 2019-08-09 Friday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local DecomposeToolView_ui = class("DecomposeToolView_ui")

--#ui propertys


--#function
function DecomposeToolView_ui:create(owner, viewType, paramTable)
	local ret = DecomposeToolView_ui.new()
	CustomUtility:LoadUi("DecomposeToolView.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function DecomposeToolView_ui:initLang()
	ButtonSmoker:setText(self.m_btnMax, "550005")
	ButtonSmoker:setText(self.m_useBtn, "9200691")
end

function DecomposeToolView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function DecomposeToolView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function DecomposeToolView_ui:onClickBtnMax(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnMax", pSender, event)
end

function DecomposeToolView_ui:onUseClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onUseClick", pSender, event)
end

function DecomposeToolView_ui:onAddClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onAddClick", pSender, event)
end

function DecomposeToolView_ui:onSubClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onSubClick", pSender, event)
end

return DecomposeToolView_ui

