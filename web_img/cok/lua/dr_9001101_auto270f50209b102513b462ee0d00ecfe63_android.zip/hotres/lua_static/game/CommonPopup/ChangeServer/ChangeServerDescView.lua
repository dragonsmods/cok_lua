local ChangeServerDescView = class("ChangeServerDescView",
    function()
        return PopupBaseView:create()
    end
)
ChangeServerDescView.__index = ChangeServerDescView
-------------------------------------------- rewardRecordCell Start --------------------------------------------

local itemDataId = 211094
function ChangeServerDescView:create(param)
	local view = ChangeServerDescView.new()
	if view:initView(param) == false then
		return nil
	end
  	return view
end

function ChangeServerDescView:ctor()
	self.ctrl = require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance()
end

function ChangeServerDescView:initView(param)
	if self:init(true, 0) == false then
		print("ChangeServerDescView init error")
    	return false
	end

	dump(param or "ChangeServerDescView  param is nil ~~~~~")
	self:setHDPanelFlag(true)
    -- self:initBtnsFunc()
	callItSelfCallFunc(LuaController, "doResourceByCommonIndex", 7, true)
	callItSelfCallFunc(LuaController, "doResourceByCommonIndex", 8, true)
	callItSelfCallFunc(LuaController, "doResourceByCommonIndex", 310, true)
	callItSelfCallFunc(LuaController, "doResourceByCommonIndex", 505, true)

	self.newVersionSwitch = CCCommonUtilsForLua:isFunOpenByKey("alliance_talent_list")

	local m_bIsPad = CCCommonUtilsForLua:isIosAndroidPad()
	local  proxy = cc.CCBProxy:create()
	local ccbiURL = ""

	ccbiURL = "ccbi/Lua_ChangeServerDescView.ccbi"
  	self.m_bIsPad = m_bIsPad
  	local nodeccb = CCBReaderLoad(ccbiURL,proxy, self)
	if nodeccb == nil then
		print("ChangeServerDescView loadccb error")
		return false
	end
	self:addChild(nodeccb)
	local winSize = cc.Director:getInstance():getIFWinSize()
	local dh = 0
	if m_bIsPad then
		nodeccb:setScale(2.4)
		-- self.winSize = CCSize()
		self:setContentSize(winSize)
		nodeccb:setPosition((winSize.width-640)*0.5, (winSize.height-852)*0.5)
  		nodeccb:setAnchorPoint(0.5, 0.5)
	else
		self:setContentSize(nodeccb:getContentSize())
		local preHeight = self.m_buildBG:getContentSize().height
        self:changeBGHeight(self.m_buildBG)
        dh = self.m_buildBG:getContentSize().height - preHeight
        local newSize = CCSize(self.m_infoList:getContentSize().width, self.m_infoList:getContentSize().height + dh)
        self.m_infoList:setContentSize(newSize)

        local infoListSize = self.m_ruleList:getContentSize()
        infoListSize.height = infoListSize.height + dh
        self.m_ruleList:setContentSize(infoListSize)
        -- self.m_rultTitle:setPositionY(self.m_rultTitle:getPositionY() + dh)
        -- self.m_ruleList:setPositionY(self.m_ruleList)
	end

	local spriteHeight = 852*0.5 + 29 + dh
	addWrapSprite(self.bg_nodeCenter, "technology_09.png", spriteHeight)

	CCLoadSprite:call("loadDynamicResourceByName", "activity_ad")
	local sprite = CCLoadSprite:createSprite("changeServerAd.png")
	self.m_head_pic:addChild(sprite)
	sprite:setAnchorPoint(cc.p(0.5, 0))

	self:initRuleContent()
	self:initItemData()

	self.ccbNode = nodeccb
	local function onNodeEvent(event)
		if event == "enter" then
			self:onEnter()
		elseif event == "exit" then
			self:onExit()
		end
	end
  	self.ccbNode:registerScriptHandler(onNodeEvent)

  	local touchLayer = cc.Layer:create()
	self:addChild(touchLayer)

	local function touchHandle( eventType, x, y )
		print("touchHandle", eventType, x, y)
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		
		else
			self:onTouchEnded(x, y)
		end
	end
	touchLayer:registerScriptTouchHandler(touchHandle)
	touchLayer:setTouchEnabled(true)
	touchLayer:setSwallowsTouches(false)


    -- self:registerTouchFuncs()
    self.m_isInit = true

	-- CCCommonUtilsForLua:setButtonTitle(self.m_confirmBtn1, "购买道具")
	CCCommonUtilsForLua:setButtonTitle(self.m_confirmBtn2, getLang("153554"))
	CCCommonUtilsForLua:setButtonTitle(self.m_searchBtn, getLang("173221"))
	CCCommonUtilsForLua:setButtonTitle(self.m_recruitBtn, getLang("173222"))

	if self.newVersionSwitch then
		self.ctrl:getTransferState()
		self.m_confirmBtn2:setEnabled(false)
		self.m_searchBtn:setEnabled(false)
		self.m_recruitBtn:setEnabled(false)
	else
		self.m_searchBtn:setVisible(false)
		self.m_recruitBtn:setVisible(false)
	end

    return true
end

function ChangeServerDescView:initRuleContent()
	local scrollView = cc.ScrollView:create()
	local viewSize = self.m_ruleList:getContentSize()
    scrollView:setViewSize(viewSize)
    scrollView:setPosition(CCPoint(0,0))
    scrollView:setScale(1.0)
    scrollView:ignoreAnchorPointForPosition(true)
    scrollView:setDirection(1)
    scrollView:setClippingToBounds(true)
    scrollView:setBounceable(true)
    self.m_ruleList:addChild(scrollView)
    scrollView:setPositionX(20)

    -- self.m_rultTitle:setString(getLang("153551"))
    local ruleContent = cc.Label:createWithSystemFont("", "Helvetica", 22, cc.size(0.0,0))
    local needDay = CCCommonUtilsForLua:getPropById("6700001", "k1")
	local needLevel = CCCommonUtilsForLua:getPropById("6700001", "k2")
	if self.newVersionSwitch then
		ruleContent:setString(getLang("173272"))
	else
		ruleContent:setString(getLang("153552", needLevel, needDay))
	end
    ruleContent:setColor(cc.c3b(124, 101, 68))
    ruleContent:setAnchorPoint(cc.p(0, 0))
    ruleContent:setDimensions(600, 0)
	scrollView:addChild(ruleContent)


	local contentSize = ruleContent:getContentSize()
	scrollView:setContentSize(contentSize)
	dump(" contentSize.height: "..contentSize.height.." viewSize.height: "..viewSize.height)
	if contentSize.height < viewSize.height then
		scrollView:setTouchEnabled(false)
	end
	scrollView:setContentOffset(CCPoint(0, viewSize.height - contentSize.height))
	
end

function ChangeServerDescView:initItemData()
	CCCommonUtilsForLua:createGoodsIcon(itemDataId, self.m_iconNode, CCSize(88, 88))
	self.m_iconNode:removeChildByTag(GOODS_BG_TAG)
	self.m_iconTips:setString(getLang("153531"))

	local goldItem
	self.libaoItemId, goldItem = LiBaoController.getInstance():getGoldExchangeItemIdByShowType(3)
	if self.libaoItemId ~= "" and goldItem.bought then
		self.libaoItemId = ""
	end
	self.libaoDesc = ""
	dump("initItemData self.libaoItemId is: "..tostring(self.libaoItemId))
	-- 消费初始化
	local item = LiBaoController.getInstance():getGoldExchangeItemById(self.libaoItemId)
	if item then
		local dollar = item.dollar
		local product_id = item.product_id
		
		local label = LuaController:call("getDollarString", dollar, product_id)
		self.m_confirmBtn1:setEnabled(true)
		CCCommonUtilsForLua:setButtonTitle(self.m_confirmBtn1, label)
		self.libaoDesc = label
	else
		self.m_confirmBtn1:setEnabled(false)
		self:update()
	end

	self.m_confirmBtn1:setVisible(false)

	self:updateItemInfo()
end

function ChangeServerDescView:updateItemInfo()
	local itemInfo = ToolController:call("getToolInfoByIdForLua", itemDataId)
	self.curItemNum = itemInfo:comFunc("getCNT", 0):getValue()
	-- self.m_itemUuid = itemInfo:comFunc("getUuid", 0):getCString()
	self.m_itemNum:setString(tostring(self.curItemNum))
end

-- function ChangeServerDescView:addWrapSprite(node, spriteName, height)
-- 	local length = 0
-- 	local sprieHeight
-- 	while (length < height) do
-- 		local spr = CCLoadSprite:createSprite(spriteName)
-- 		sprieHeight = sprieHeight or spr:getContentSize().height
-- 		spr:setAnchorPoint(cc.p(0.5, 1))
-- 		node:addChild(spr)
-- 		spr:setPositionY(0- length)
-- 		length = length + sprieHeight
-- 	end
-- end

function ChangeServerDescView:updateState()
	if self.newVersionSwitch then
		if self.ctrl:showPublishReward() then
			self.m_rewardNode:setVisible(true)
			self.m_rewardTxt:setString(getLang("173223"))
		end

		if self.ctrl:isTransferState() then
			self.m_recruitBtn:setEnabled(false)
			self.m_confirmBtn2:setEnabled(true)	
			self.m_searchBtn:setEnabled(false)
		end

		if self.ctrl:isMatchState() then
			local canPublish = self.ctrl:getCanPublish()
			self.m_recruitBtn:setEnabled(canPublish)
			self.m_searchBtn:setEnabled(true)
			if self.ctrl:showPreview() then
				self:initPreviewNode()
			end
		end 

		if self.ctrl:getCanTransfer() == false then
			self.m_recruitBtn:setEnabled(false)
			self.m_searchBtn:setEnabled(false)
		end
	end
end

function ChangeServerDescView:initPreviewNode()
	local hyperText = "<s 18><c 84e9aaff><h " .. getLang("173318") .. "@1>"
	local pLabel = IFHyperlinkText:call("create", hyperText, cc.size(600,0), true)
    pLabel:setAnchorPoint(ccp(0.5, 0.5))
    self.m_previewNode:removeAllChildren()
    self.m_previewNode:addChild(pLabel)
	
	local function onRegisterHyper() self:onClickPreview() end
    local handlerSetHyperlink = self:registerHandler(onRegisterHyper)
    pLabel:call("SetHyperlinkTextClickLuaCallback", handlerSetHyperlink)
end

function ChangeServerDescView:onClickPreview()
	local view = Drequire("game.CommonPopup.ChangeServer.RecruitDetailView"):create(true)
	PopupViewController:addPopupInView(view)
end

function ChangeServerDescView:onEnter()
    self:setTitleName(getLang("153550"))
    -- self.m_title:setString(getLang("9400563"))
    self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:update(dt) end, 1, false)

	local function onPaySuccess( ref )
		-- 购买成功
		dump(" ~~~~~~~~~~~~~~ on onPaySuccess ref  is: "..tostring(ref))
		self:initItemData()
    end
    local handler = self:registerHandler(onPaySuccess)
	CCSafeNotificationCenter:registerScriptObserver(self, handler, PAYMENT_COMMAND_RETURN)

	local function callback1(param) self:updateState(param) end
    local handler1 = self:registerHandler(callback1)
    CCSafeNotificationCenter:registerScriptObserver(self, handler1, "ChangeServerDescView:updateState") 
end

function ChangeServerDescView:onExit()
	self:getScheduler():unscheduleScriptEntry(self.m_entryId)
	CCSafeNotificationCenter:unregisterScriptObserver(self, PAYMENT_COMMAND_RETURN)
	CCSafeNotificationCenter:unregisterScriptObserver(self, "ChangeServerDescView:updateState")
end

function ChangeServerDescView:update(dt)
	if self.libaoItemId == "" then
		self._dayEndTime = GlobalData:comFunc("shared",0):getProperty("tomorrow_time")
		local curTime = GlobalData:call("getTimeStamp")
		if self._dayEndTime < curTime then
			self._dayEndTime = self._dayEndTime + 86400
		end

		local txt = format_time(self._dayEndTime - curTime)
		CCCommonUtilsForLua:setButtonTitle(self.m_confirmBtn1, txt)
	end

	if self.newVersionSwitch then
		if self.ctrl:isMatchState() then
			self.m_stateLabel:setVisible(true)
			self.m_stateLabel:setString(getLang("173248"))
			self.m_stateTimeLabel:setVisible(true)

			local startTime = self.ctrl:getStartTime()
			local now = GlobalData:call("getTimeStamp")
			self.m_stateTimeLabel:setString(format_time(startTime - now))

			CCCommonUtilsForLua:setButtonTitle(self.m_confirmBtn2, "")
		elseif self.ctrl:isTransferState() then
			self.m_confirmBtn2:setEnabled(true)
			CCCommonUtilsForLua:setButtonTitle(self.m_confirmBtn2, getLang("153554"))
			self.m_stateLabel:setVisible(false)
			self.m_stateTimeLabel:setVisible(false)
		else
			CCCommonUtilsForLua:setButtonTitle(self.m_confirmBtn2, getLang("153554"))
			self.m_stateLabel:setVisible(false)
			self.m_stateTimeLabel:setVisible(false)
		end
	end
end

function ChangeServerDescView:onTouchBegan(x, y)
	-- dump("ChangeServerDescView onTouchBegan ~~~~~~~~~~~~~~")
	if isTouchInside(self.m_addIcon, x, y) then
		self.startTouchPoint = ccp(x, y)
		return true
	end

	return false
end

function ChangeServerDescView:onTouchMoved(x, y)
	-- dump("ChangeServerDescView onTouchMoved ~~~~~~~~~~~~~~")
end

function ChangeServerDescView:onTouchEnded(x, y)
	-- dump("ChangeServerDescView onTouchEnded ~~~~~~~~~~~~~~")
	if ccpDistance(self.startTouchPoint, ccp(x, y)) > 20 then return end 
	if isTouchInside(self.m_addIcon, x, y) then
		local ItemGetMethodView = Drequire("game.CommonPopup.ItemGetMethodView")
		local view = ItemGetMethodView:create(itemDataId)
		PopupViewController:addPopupView(view)
	end
end

function ChangeServerDescView:onConfirmClick1()
	dump(" ChangeServerDescView:onConfirmClick1 ~~~~~~~~~~~")
	-- payCtr:call("callPayment", item)
	LuaController:call("callPayment", self.libaoItemId)
end

function ChangeServerDescView:onConfirmClick2()
	-- dump(" ChangeServerDescView:onConfirmClick2 ~~~~~~~~~~~")
	if self.ctrl:showTransferDirectly() then
		local view = Drequire("game.CommonPopup.ChangeServer.ChangeServerApplyView"):create(2)
		PopupViewController:addPopupInView(view)
		return
	end

	local now = GlobalData:call("getTimeStamp")
	local cdTime = self.ctrl.cdTime
	if cdTime > now then
		local remain = cdTime - now
		YesNoDialog:call("showTimeWithDes", getLang("173295"), getLang("108659"), remain)
    	return
	end

	local lua_path = "game.CommonPopup.ChangeServer.ChangeServerView"
	package.loaded[lua_path] = nil
	local view = Drequire(lua_path):create({libaoItemId = self.libaoItemId, libaoDesc = self.libaoDesc})
	PopupViewController:addPopupInView(view)
end

function ChangeServerDescView:onTipBtnClick()
	-- PopupViewController:call("addPopupTipsView", getLang("153561"))
	-- PopupViewController:call("addPopupTipsView", getLang("153563"))
	FaqHelper:call("showSingleFAQ", "45281")
end

function ChangeServerDescView:onSearchClick()
	local view = Drequire("game.CommonPopup.ChangeServer.ChangeServerApplyView"):create(1)
	PopupViewController:addPopupInView(view)
end

function ChangeServerDescView:onRecruitClick()
	local playerInfo = GlobalData:call("getPlayerInfo")
	if playerInfo:call("isInAlliance") then
		local allianceInfo = playerInfo:getProperty("allianceInfo")
		local memberRank = allianceInfo:getProperty("rank")
		if memberRank < 4 then
			--173252=只有R4及以上玩家才可进入
			CCCommonUtilsForLua:call("flyHint", "", "", getLang("173252"))
			return
		end

		local thisLimit = self.ctrl.thisLimit
		if thisLimit <= 0 then
			--173360=本次招贤榜活动，贵联盟招募人数已经达到上限
			CCCommonUtilsForLua:call("flyHint", "", "", getLang("173360"))
			return
		end

		local free = self.ctrl.free
		if free <= 0 then
			--173253=您的联盟已经没有空余人数了，请空出空位后再来
			CCCommonUtilsForLua:call("flyHint", "", "", getLang("173253"))
			return
		end

		local view = Drequire("game.CommonPopup.ChangeServer.RecruitDetailView"):create()
		PopupViewController:addPopupInView(view)
	else
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("173252"))
	end
end

return ChangeServerDescView







