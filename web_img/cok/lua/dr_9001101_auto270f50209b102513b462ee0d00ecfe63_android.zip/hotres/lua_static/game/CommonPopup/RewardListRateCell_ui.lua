----------------------------
-- Author: Elex
-- Date: 2018-04-17 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local RewardListRateCell_ui = class("RewardListRateCell_ui")

--#ui propertys


--#function
function RewardListRateCell_ui:create(owner, viewType, paramTable)
	local ret = RewardListRateCell_ui.new()
	CustomUtility:LoadUi("RewardListRateCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function RewardListRateCell_ui:initLang()
end

function RewardListRateCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function RewardListRateCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return RewardListRateCell_ui

