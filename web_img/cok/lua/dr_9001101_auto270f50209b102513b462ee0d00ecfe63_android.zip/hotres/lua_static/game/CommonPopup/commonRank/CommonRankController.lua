local CommonRankController = class("CommonRankController")
local HeroRecruitRankCtl = require("game.hero.NewUI_v2.HeroRecruitRankController").getInstance()

--consumeSoldier.getRank 获取玩家排行
local PlayerRankDataCmd = class("PlayerRankDataCmd", LuaCommandBase)
-- type,group,page,pageSize,self_id
function PlayerRankDataCmd.req(params, callBack)
    GameController:call("getInstance"):call("showWaitInterface")
    local ret = PlayerRankDataCmd.new()
    local protocolName = "nrank.info"
    if params.page and tonumber(params.page) > 0 then
        protocolName = "nrank.page"
    end

    if params.protocol and params.protocol ~= "" then
        protocolName = params.protocol
    end

    ret:initWithName(protocolName)
    ret:putParam("type", CCString:create(params.type))
     --type|string|排行榜数据枚举
    ret:putParam("page", CCInteger:create(params.page))
     --page|int| 分页的页号  从0开始, 0,1,2,3,4,5,6.....
    ret:putParam("group", CCString:create(params.group)) --group|string| group是分组排行榜 local本服排行榜
    ret:putParam("pageSize", CCInteger:create(params.pageSize))
     --pageSize|int| 每页最大返回的数据量，默认20
    ret:putParam("selfId", CCString:create(params.selfId)) -- selfId|string|个人排行传uid，联盟排行再说
    if params.country then
        ret:putParam("country", CCString:create(params.country))
    end
    ret._callBack = callBack
    ret:send()
end

function PlayerRankDataCmd:handleReceive(dict)
    GameController:call("getInstance"):call("removeWaitInterface")
    local tbl = self:parseMsg(dict)
    if type(tbl) == "boolean" then
        CCSafeNotificationCenter:call("postNotification", "CommonRankView.rankDataFail")
        return tbl
    end
    if self._callBack then
        self._callBack(tbl)
    end
    return true
end

--consumeSoldier.getRank 获取玩家排行
local SetAnonymousStateCmd = class("SetAnonymousStateCmd", LuaCommandBase)
-- type,group,page,pageSize,self_id
function SetAnonymousStateCmd.req(params, callBack)
    GameController:call("getInstance"):call("showWaitInterface")
    local ret = SetAnonymousStateCmd.new()
    local protocolName = "nrank.anonymous"
    ret:initWithName(protocolName)
    ret:putParam("type", CCString:create(params.type))
     --type|string|排行榜数据枚举
    ret:putParam("selfId", CCString:create(params.selfId))
    ret:putParam("state", CCInteger:create(params.anonymous_state)) -- selfId|string|个人排行传uid，联盟排行再说
    ret._callBack = callBack
    ret:send()
end

function SetAnonymousStateCmd:handleReceive(dict)
    GameController:call("getInstance"):call("removeWaitInterface")
    local tbl = self:parseMsg(dict)
    if type(tbl) == "boolean" then
        return tbl
    end
    if self._callBack then
        self._callBack(tbl)
    end
    return true
end

-----------------cmd end---------

function CommonRankController:ctor()
    -- self.type = type
    --TODO,这两个数据具体是策划配前端表还是后端发过来
    self.maxGlobalRank = 5000 --最多全服排行，默认数据
    self.maxLocalRank = 2000 --最多本服排行，默认数据

    --全服玩家排行
    self.allPlayerRankData = {}
    --本服玩家排行
    self.localPlayerRankData = {}
end

function CommonRankController:pureData()
    --全服玩家排行
    self.allPlayerRankData = nil
    --本服玩家排行
    self.localPlayerRankData = nil
end

--请求
function CommonRankController:reqData(params)
    -- if params.type ~= self.type then
    --     return
    -- end
    local function callBack(data)
        self:processRankData(data, params)
    end
    local cmd = PlayerRankDataCmd.req(params, callBack)
end

function CommonRankController:processRankData(data, params)
    -- dump(data,"CommonRankController:processRankData is")
    --TOOD

    if params.group == "group" then
        data.allPlayerRankData = self.allPlayerRankData
        data.maxLocalRank = self.maxLocalRank
        self.allPlayerRankData = data
    else
        self.localPlayerRankData = data
    end
    self:checkTopPlayerData(params.group)
    CCSafeNotificationCenter:call("postNotification", "msg.CommonRankView.getLocalPlayerRank")
end

function CommonRankController:getRankDataByGroup(group)
    if group == "group" then
        return self.allPlayerRankData
    else
        return self.localPlayerRankData
    end
end

function CommonRankController:checkTopPlayerData(group)
    local tbl = self:getRankDataByGroup(group)
    -- dump(tbl, "CommonRankController:getTopPlayerData")
    local result
    if tbl then
        local rankList = {}
        if tbl.rank then
            rankList = tbl.rank
        elseif tbl.pagerank then
            rankList = tbl.pagerank
        end
        if rankList and #rankList > 0 then
            -- result = rankList[1]
            for _, v in pairs(rankList) do
                if tonumber(v.rank) == 1 then
                    result = v
                    break
                end
            end
        end
    end
    if result then
        if not self.topPlayer then
            self.topPlayer = {}
        end
        self.topPlayer[group] = result
    end
end

function CommonRankController:getTopPlayerData(group)
    -- dump(self.topPlayer, "CommonRankController:topPlayer")
    if self.topPlayer and self.topPlayer[group] then
        return self.topPlayer[group]
    end
end

function CommonRankController:doReqSetAnonymousState(type, selfId, anonymous_state, callback)
    if type and anonymous_state then
        anonymous_state = tonumber(anonymous_state) == 0 and 0 or 1
        SetAnonymousStateCmd.req(
            {
                type = type,
                selfId = selfId,
                anonymous_state = anonymous_state
            },
            function(tbl)
                Dprint("doReqSetAnonymousState:success,anonymous_state=" .. anonymous_state)
                if callback then
                    callback(tbl)
                end
            end
        )
    end
end

return CommonRankController
