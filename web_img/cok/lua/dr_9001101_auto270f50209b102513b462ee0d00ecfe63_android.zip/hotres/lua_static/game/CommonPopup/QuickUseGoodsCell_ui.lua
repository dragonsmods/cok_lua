----------------------------
-- Author: Elex
-- Date: 2020-02-24 Monday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local QuickUseGoodsCell_ui = class("QuickUseGoodsCell_ui")

--#ui propertys


--#function
function QuickUseGoodsCell_ui:create(owner, viewType, paramTable)
	local ret = QuickUseGoodsCell_ui.new()
	CustomUtility:LoadUi("QuickUseGoodsCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function QuickUseGoodsCell_ui:initLang()
end

function QuickUseGoodsCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function QuickUseGoodsCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function QuickUseGoodsCell_ui:onBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBtnClick", pSender, event)
end

return QuickUseGoodsCell_ui

