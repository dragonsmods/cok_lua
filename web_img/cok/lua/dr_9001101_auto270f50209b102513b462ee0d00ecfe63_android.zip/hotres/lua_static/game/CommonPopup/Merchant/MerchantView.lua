--@author: mm
--@date: 2016-11-14

--前置声明
-- local Drequire = Drequire
-- local Dprint = Dprint

-- local print = print
-- local math = math

local CC_SECTOA = format_time
local CC_ITOA = tostring
-- local isTouchInside = isTouchInside
-- local CC_CMDITOA = CC_CMDITOA 
-- local CCCommonUtilsForLua = CCCommonUtilsForLua
-- local _lang = _lang
-- local getLang = getLang
-- local ToolController = ToolController
-- local CCLoadSprite = CCLoadSprite

local mtc_path = "game.CommonPopup.Merchant.MerchantTabelCell"
-- package.loaded[mtc_path] = nil
local MerchantTabelCell = Drequire(mtc_path)

local tmgc_path = "game.CommonPopup.Merchant.ToolMerchantGetCommand"
local tmrc_path = "game.CommonPopup.Merchant.ToolMerchantRefreshCommand"

--merchant枚举
local MerchantToolType = {
    MerchantTool_RESOURCE = 0,
    MerchantTool_GOODS = 1,
    MerchantTool_EQUIP = 2,
}

--C常量
local TOP_HEIGHT = 75
local merchantTipNum = 8
local merchantTips = {"104934","104935","104936","104937","104938","104945","104946","104947"} -- num=8

local MERCHANTE_REFRESH_TIME_KEY = "merchante.fresh.key"
local MERCHANTE_REFRESH_COST_KEY = "merchante.fresh.cost"
local MERCHANTE_REFRESH_SHOW_FLAG_KEY = "merchante.fresh.show.flag"

local MSG_TOOL_MERCHANTE_LEAVE = "msg.tool.merchante.leave"
local MSG_BUY_CONFIRM_OK = "buy.confirm.ok"
local SHOW_CUR_WAITE = "show.cur.waite"
local DEL_CUR_WAITE = "del.cur.waite"
local MSG_MERCHANTE_REFRESH_ANIMATION_FINISH = "merchante.refresh.animation.finish"

--LUA常量
local daySec = 86400
local ttKey = "tomorrow_time"

--类定义
local MerchantView = class("MerchantView",
    function()
        return PopupBaseView:create()
    end
)


--fields (旧时完成，ccb里默认变量未添加在此，不要奇怪)
MerchantView.m_lastIndex = 0
MerchantView.m_lblDialog = nil -- CCSafeObject<CCLabelIF>
MerchantView.m_isInit = false
MerchantView.m_onTimer = false

MerchantView.m_entry_onNewDay = -1 -- onNewDay的回调，-1表示默认不存在
MerchantView.m_entry_onTimer = -1 -- onTimer的回调，-1表示默认不存在
MerchantView.m_refreshTipType = 0 -- //0-不显示 1-每日首次刷新 2-价格变化刷新 3-列表中拥有超值物品
MerchantView.m_refreshCost = 0 --int

MerchantView.m_waiteNode = nil -- cc.Node
MerchantView.m_waitInterface = nil -- WaitInterface
MerchantView.m_isRefresh = false
MerchantView.m_showRefreshEff = false
MerchantView.m_curFinAnimation = 0

MerchantView.m_lblRefresh = nil -- CCSafeObject<CCLabelIF>
MerchantView.m_leftTime = 0
MerchantView.m_refreshTime = 0
MerchantView.m_tabView = nil -- CCScrollView
MerchantView.m_dataCount = 0
MerchantView.ccbNode = nil

--funcctions
function MerchantView:create(param)
    local view = MerchantView.new()
    if view:initView(param) == false then
        return nil
    end
    return view
end

function MerchantView:initView(param)
    if self:init(true, 7) == false then
        print("MerchantView init error")
        return false
    end
    self:setHDPanelFlag(true)
    self:setTitleName("")

    --res
    CCLoadSprite:call("doResourceByCommonIndex", 11, true)
    CCLoadSprite:call("doResourceByCommonIndex", 8, true)
    CCLoadSprite:call("loadDynamicResourceByType", CCLoadSpriteType.CCLoadSpriteType_GOODS)
    self.superItems = nil
    self.bestItem = nil
    self.lastGoodsId = nil

    --现在都不处理这种情况了
    -- setCleanFunction([](){
    --     CCLoadSprite::doResourceByCommonIndex(11, false);
    --     CCLoadSprite::doResourceByCommonIndex(8, false);
    --     CCLoadSprite::releaseDynamicResourceByType(CCLoadSpriteType_GOODS);
    -- });

    --读取ccbi
    local proxy = cc.CCBProxy:create()
    local ccbiURL = "MerchantView_Lua.ccbi"
    local nodeccb = CCBReaderLoad(ccbiURL, proxy, self)
    if nodeccb == nil then
        Dprint("MerchantView loadccb error")
        return false
    else
        Dprint("MerchantView loadccb done")
    end
    self.ccbNode = nodeccb
    self:addChild(nodeccb)
    self:setContentSize(nodeccb:getContentSize())

    local size = cc.Director:getInstance():getIFWinSize()
    local isPad = CCCommonUtilsForLua:isIosAndroidPad()
    if isPad then
        size = cc.size(640, 852)
    end

    local dh = size.height - TOP_HEIGHT - 340

    if isPad then
        dh = dh + 80
    end

    self.m_infoList:setContentSize( cc.size(self.m_infoList:getContentSize().width,dh) )
    self.m_onTimer = false

    --触控系列
    local function onTouch(eventType, x, y)  
        if eventType == "began" then
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)  
        else  
            return self:onTouchEnded(x, y)  
        end
    end

    self:registerScriptTouchHandler(onTouch)

    -- Dprint("self.m_timeNode=", self.m_timeNode)
    -- Dprint("self.m_infoList=", self.m_infoList)
    -- Dprint("self.m_timeLeftText=", self.m_timeLeftText)

    local orgSize = cc.Director:getInstance():getVisibleSize()
    local color = cc.LayerColor:create(cc.c4b(0, 0, 0, 255), orgSize.width, orgSize.height) 
    self:addChild(color)
    color:setZOrder(-10)
    color:setPositionY(nodeccb:getPositionY() - 340)
    local realSize = cc.Director:getInstance():getIFWinSize()
    local scaleY_num = realSize.height / 852
    color:setScaleY(scaleY_num)

    self.m_tabView = cc.TableView:create(self.m_infoList:getContentSize())
    self.m_tabView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
    self.m_tabView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
    --self.m_tabView:setTouchPriority(cc,Touch_Default)
    self.m_tabView:setDelegate() --self?

    function scrollViewDidScroll(view)
        return self:scrollViewDidScroll(view)
    end
    function tableCellTouched(tab,cell) 
        return self:tableCellTouched(tab,cell)
    end

    function cellSizeForTable(tab,idx)
        return self:cellSizeForTable(tab,idx)
    end

    function tableCellAtIndex(tab, idx)
        return self:tableCellAtIndex(tab, idx)
    end

    function numberOfCellsInTableView(tab)
        return self:numberOfCellsInTableView(tab)
    end

    self.m_tabView:registerScriptHandler(scrollViewDidScroll, cc.SCROLLVIEW_SCRIPT_SCROLL)
    self.m_tabView:registerScriptHandler(tableCellTouched,cc.TABLECELL_TOUCHED)
    self.m_tabView:registerScriptHandler(cellSizeForTable, cc.TABLECELL_SIZE_FOR_INDEX)
    self.m_tabView:registerScriptHandler(tableCellAtIndex, cc.TABLECELL_SIZE_AT_INDEX)
    self.m_tabView:registerScriptHandler(numberOfCellsInTableView, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)

    self.m_infoList:addChild(self.m_tabView)

    self.m_itemNode1:setVisible(false)
    self.m_lblInfo1:setString(getLang("104950"))
    self.m_lblTitleRefresh:setString(getLang("104932"))

    -- local trLabelIF = tolua.cast(self.m_lblTitleRefresh, "cc.LabelIF")
    -- Dprint("trLabelIF=", trLabelIF)
    -- local osx = trLabelIF.call("getOriginScaleX")
    -- Dprint("trLabelIF osx=", osx)
    local sizeW = self.m_lblTitleRefresh:getContentSize().width * self.m_lblTitleRefresh:getScaleX() -- TODO: getOriginScaleX()
    local sizeBtn = self.m_btnRefresh:getContentSize()
    if (sizeBtn.width - 200 < sizeW) then
        self.m_btnRefresh:setPreferredSize(cc.size(sizeW+200, sizeBtn.height))
        local offsetX = (sizeW - (sizeBtn.width-200))*0.5
        self.m_lblTitleRefresh:setPositionX(self.m_lblTitleRefresh:getPositionX() + offsetX)
        self.m_sprRefresh:setPositionX(self.m_sprRefresh:getPositionX()+offsetX)
        self.m_lblRefresh:setPositionX(self.m_lblRefresh:getPositionX()+offsetX)
    end

    if GuideController:call("checkSubGuide", "3140100") then
        GuideController:call("triggerSubGuide", "3140100")
    end
    
    self.m_waiteNode = cc.Node:create()
    self.m_waiteNode:setContentSize(cc.Director:getInstance():getIFWinSize())
    local extH = self:call("getExtendHeight")
    self.m_waiteNode:setPosition(cc.p(0, -extH))
    self:addChild(self.m_waiteNode)
    self.m_waitInterface = nil

    local function onNodeEvent(event)
        if event == "enter" then
            Dprint("MerchantView | onNodeEvent enter")
            self:onEnter()
        elseif event == "exit" then
            Dprint("MerchantView | onNodeEvent exit")
            self:onExit()
        end
    end
    self:registerScriptHandler(onNodeEvent)

    return true
end

function MerchantView:refreshTip()
    self.m_itemNode1:stopAllActions()
    local index = 0
    local min = 5
    local max = merchantTipNum-1
    math.randomseed(tostring(os.time()):reverse():sub(1, 6))
    local getRandomInt = math.random

    if (self.m_lastIndex>=min and self.m_lastIndex<=max) then
        local a = getRandomInt(0, 1)
        if (self.m_lastIndex==min) then
            index = getRandomInt(min+1, max)
        elseif (self.m_lastIndex == max) then
            index = getRandomInt(min, max-1)
        else
            index = ( (a == 0) and getRandomInt(min, self.m_lastIndex-1) ) or getRandomInt(self.m_lastIndex+1, max)
        end
    else
        index = getRandomInt(min, max)
    end
    self:setTip(index)
    local delay = cc.DelayTime:create(90)
    local luafunc = function ()
        self:refreshTip()
    end 
    local cfunc = cc.CallFunc:create(luafunc)
    local seqAction = cc.Sequence:create(delay, cfunc)
    m_itemNode1:runAction(seqAction)
end

function MerchantView:setTip(index)
    self.m_lastIndex = index
    Dprint("tipindex=", merchantTips[index])

    self.m_lblDialog:setString(getLang(merchantTips[index]))
    local temp = m_itemNode1:getChildByTag(100)
    local scrollView = tolua.cast(temp, "cc.ScrollView")

    if (scrollView ~= nil) then
        local dialogH = self.m_lblDialog:getContentSize().height * self.m_lblDialog:getOriginScaleY()
        local scrollH = 120
        if(dialogH > scrollH) then
            self.m_lblDialog:setPositionY(0)
            scrollView:setTouchEnabled(true)
            scrollView:setContentOffset(cc.p(0, scrollH - dialogH))
            scrollView:getContainer():setContentSize(cc.size(320,dialogH))
        else
            self.m_lblDialog:setPositionY(scrollH - dialogH)
            scrollView:setTouchEnabled(false)
        end
    end
end

function MerchantView:onEnter()
    -- self.super:onEnter()
    
    -- self:setTouchMode(cc.TOUCHES_ONE_BY_ONE) --Touch::DispatchMode::ONE_BY_ONE) --这个方法在C里也没有实现，使用无意义。
    local touchNode = tolua.cast(self, "cc.CCIFTouchNode")
    touchNode:call("setTouchEnabled", true)

    -- //CCDirector::sharedDirector()->getTouchDispatcher()->addTargetedDelegate(this, Touch_Default, false);

    local t = tolua.cast(self, "cc.Node")

    local closeViewCb = function () self:closeView() end
    local handler = t:registerHandler(closeViewCb)
    CCSafeNotificationCenter:registerScriptObserver(self, handler, MSG_TOOL_MERCHANTE_LEAVE)

    local resetRefreshTipCb = function () self:resetRefreshTip() end
    local handler = t:registerHandler(resetRefreshTipCb)
    CCSafeNotificationCenter:registerScriptObserver(self, handler, MSG_BUY_CONFIRM_OK)

    local onShowWateInterFaceCb = function () self:onShowWateInterFace() end
    local handler = t:registerHandler(onShowWateInterFaceCb)
    CCSafeNotificationCenter:registerScriptObserver(self, handler, SHOW_CUR_WAITE)

    local onDelShowWateInterFaceCb = function () self:onDelShowWateInterFace() end
    local handler = t:registerHandler(onDelShowWateInterFaceCb)
    CCSafeNotificationCenter:registerScriptObserver(self, handler, DEL_CUR_WAITE)

    local gd = GlobalData:call("shared")

    local timeStamp = gd:call("getTimeStamp")
    local leftT = gd:getProperty(ttKey) - timeStamp

    Dprint("MerchantView:onEnter() | leftT=", leftT, " m_isInit=", self.m_isInit)

    local function luafunc()
        self:onNewDay()
    end

    if (leftT > 0) then
        self.m_entry_onNewDay = self:getScheduler():scheduleScriptFunc(luafunc, leftT, true)
        --this->schedule(schedule_selector(MerchantView::onNewDay), leftT, 1, 0)
    elseif (leftT < 0) then
        gd:setProperty(ttKey, gd:getProperty(ttKey) + daySec)
        leftT = gd:getProperty(ttKey) - timeStamp;
        self.m_entry_onNewDay = self:getScheduler():scheduleScriptFunc(luafunc, leftT, true)
        -- this->schedule(schedule_selector(MerchantView::onNewDay), leftT, 1, 0);
    else
        gd:setProperty(ttKey, gd:getProperty(ttKey) + daySec)
        self.m_entry_onNewDay = self:getScheduler():scheduleScriptFunc(luafunc, leftT, true)
        -- this->schedule(schedule_selector(MerchantView::onNewDay), daySec, 1, 0);
    end

    if not self.m_isInit then
        self:getHotItems()
    end
    self:setRandomUpdateTimer(true)
end

function MerchantView:onExit()
    self:setRandomUpdateTimer(false)
    self:onDelShowWateInterFace()
    local touchNode = tolua.cast(self, "cc.CCIFTouchNode")
    touchNode:call("setTouchEnabled", false)

    if (self.m_onTimer) then
        if (self.m_entry_onTimer ~= -1) then
            self:getScheduler():unscheduleScriptEntry(self.m_entry_onTimer)
        end
        self.m_onTimer = false
        self.m_entry_onTimer = -1
    end

    if (self.m_entry_onNewDay ~= -1) then
        self:getScheduler():unscheduleScriptEntry(self.m_entry_onNewDay)
        self.m_entry_onNewDay = -1
    end

    CCSafeNotificationCenter:unregisterScriptObserver(self, MSG_TOOL_MERCHANTE_LEAVE)
    CCSafeNotificationCenter:unregisterScriptObserver(self, MSG_BUY_CONFIRM_OK)
    CCSafeNotificationCenter:unregisterScriptObserver(self, MSG_MERCHANTE_REFRESH_ANIMATION_FINISH)
    CCSafeNotificationCenter:unregisterScriptObserver(self, SHOW_CUR_WAITE)
    CCSafeNotificationCenter:unregisterScriptObserver(self, DEL_CUR_WAITE)

    -- self.super:onExit()
end

function MerchantView:onNewDay()
    local gd = GlobalData:call("shared")
    gd:setProperty(ttKey, gd:getProperty(ttKey) + daySec)

    local ccud = cc.UserDefault:getInstance()

    ccud:setIntegerForKey(MERCHANTE_REFRESH_COST_KEY, 0)
    ccud:setIntegerForKey(MERCHANTE_REFRESH_SHOW_FLAG_KEY, 0)
    ccud:flush()

    self:getHotItems()

    if (self.m_entry_onNewDay ~= -1) then
        self:getScheduler():unscheduleScriptEntry(self.m_entry_onNewDay)
        self.m_entry_onNewDay = -1
    end

    local function luafunc()
        self:onNewDay()
    end
    self.m_entry_onNewDay = self:getScheduler():scheduleScriptFunc(luafunc, daySec, true)
end

function MerchantView:closeView(ccObj)
    self:closeSelf()
end

function MerchantView:resetRefreshTip(ccObj)
    if not self.bestItem then
        dump("MerchantView:resetRefreshTip fail, no bestItem+++")
        return
    end
    self.m_refreshTipType = 0
    local listItems = string.split(self.bestItem.goodsId, ";")
    local goodsItemId = tonumber(listItems[1])
    local goodsItemCount = tonumber(listItems[2])
    local goodsItemClr = tonumber(self.bestItem.color)

    local tc = ToolController:call("getInstance")

    local miTable = tc:getProperty("m_toolMerchantInfos") --vector<MerchantToolInfo>
    -- local miBest = tc:getProperty("merchantBestTool") --MerchantToolInfo
    local mb_itemId = goodsItemId --miBest:getProperty("itemId")
    local mb_num = goodsItemCount --miBest:getProperty("num")
    local mb_color = goodsItemClr --miBest:getProperty("color")

    Dprint("miTable #=", #miTable)
    for k, v in pairs(miTable) do
        if v:getProperty("itemId") == mb_itemId and v:getProperty("itemNum") == mb_num and v:getProperty("color") == mb_color then
            self.m_refreshTipType = 3
            return
        end
    end

-- //    if(m_refreshTipType!=3){
    local ccud = cc.UserDefault:getInstance()
    local gd = GlobalData:call("shared")
    local tomorrowTime = gd:getProperty(ttKey)

    local key = ccud:getStringForKey(MERCHANTE_REFRESH_TIME_KEY)
    if (string.len(key) > 0) then --!key.empty()
        local refreshTomorrow = tonumber(key)
        local timeStamp = gd:call("getTimeStamp")
        if (tomorrowTime > timeStamp) then
            if (tomorrowTime - refreshTomorrow > 0.1) then
                self.m_refreshTipType = 1
                return
            end
        end
    else
        self.m_refreshTipType = 1
    end

    local oldCost = ccud:getIntegerForKey(MERCHANTE_REFRESH_COST_KEY) --int
    local flag = ccud:getIntegerForKey(MERCHANTE_REFRESH_SHOW_FLAG_KEY) --int

    if (0 == flag) then
        if (oldCost ~= self.m_refreshCost) then
                self.m_refreshTipType = 2
        end
        ccud:setIntegerForKey(MERCHANTE_REFRESH_SHOW_FLAG_KEY, 1)
    elseif (1 == flag) then
        if (self.m_refreshCost > tc:call("getMerchanteCostTip")) then
            self.m_refreshTipType = 2
            ccud:setIntegerForKey(MERCHANTE_REFRESH_SHOW_FLAG_KEY, 2)
        end
    else
        --
    end
    ccud:flush()
-- //        if(oldCost>0 && oldCost!=m_refreshCost){
-- //            m_refreshTipType = 2;
-- //        }elseif(oldCost == 0 || m_refreshCost==0){
-- //            m_refreshTipType = 1;
-- //        }
-- //    }
end

function MerchantView:onShowWateInterFace()
    self.m_waitInterface = GameController:call("getInstance"):call("showWaitInterface1", self.m_waiteNode)
    self.m_waitInterface:setPosition(cc.p(self.m_waiteNode:getContentSize().width / 2, self.m_waiteNode:getContentSize().height / 2))
end

function MerchantView:onDelShowWateInterFace()
    if (self.m_waitInterface ~= nil) then
        self.m_waitInterface:call("remove")
        self.m_waitInterface = nil
    end
end

function MerchantView:getHotItems(useGold)
    useGold = useGold or false

    if (self.m_isRefresh == true) then
        return
    end

    local tc = ToolController:call("getInstance")

    self.m_isRefresh=true
    if (self.m_isInit and useGold) then
        self.m_showRefreshEff = true
        tc:call("setMerchante_animation", true)

        local t = tolua.cast(self, "cc.Node")
        local finishAnimationCb = function () self:finishAnimation() end
        local handler = t:registerHandler(finishAnimationCb)
        CCSafeNotificationCenter:registerScriptObserver(self, handler, MSG_MERCHANTE_REFRESH_ANIMATION_FINISH)

        self.m_curFinAnimation = 0

        local ccud = cc.UserDefault:getInstance()
        ccud:setIntegerForKey(MERCHANTE_REFRESH_COST_KEY, self.m_refreshCost)
        ccud:flush()
    end

    self:onShowWateInterFace(nil)

    local cmd = nil --CommandBase
    function cmdCb (dictParam)
        self:refreshTime(dictParam)
    end

    if not useGold then
        -- package.loaded[tmgc_path] = nil
        local ToolMerchantGetCommand = Drequire(tmgc_path)
        cmd = ToolMerchantGetCommand.create(cmdCb)
    else
        -- package.loaded[tmrc_path] = nil
        local ToolMerchantRefreshCommand = Drequire(tmrc_path)
        cmd = ToolMerchantRefreshCommand.create(cmdCb)
    end
    cmd:send()
    Dprint("MerchantView | cmd=ToolMerchantCmd test", cmd)
end

function MerchantView:finishAnimation(ccObj)
    self.m_curFinAnimation = self.m_curFinAnimation + 1
    local maxIndex = 4 --//ceil(m_infoList->getContentSize().height/cellSizeForTable(m_tabView).height);
    if (self.m_curFinAnimation >= maxIndex) then
        local tc = ToolController:call("getInstance")
        tc:call("setMerchante_animation", false)
        CCSafeNotificationCenter:unregisterScriptObserver(self, MSG_MERCHANTE_REFRESH_ANIMATION_FINISH)
        self.m_curFinAnimation = 0
    end
end

-- "bestItem" = {
--     "color"     = "6"
--     "goodsId"   = "200370;3"
--     "price"     = "500"
--     "priceType" = "5"
--     "price_hot" = "0"
--     "type"      = "1"
-- }
function MerchantView:getSuperItems(dict)
    self.allData = dictToLuaTable(dict)
    dump(self.allData, "allData+++")
    self.superItems = self.superItems or self.allData.bestItems
    dump(self.superItems, "superItems+++")
end

function MerchantView:setRandomBestItem()
    if self.superItems and #self.superItems > 0 then 
        local superItemsCount = #self.superItems
        if superItemsCount == 1 then 
            self.bestItem = self.superItems[1]
            dump(self.bestItem,"bestItem1+++")
            return 
        end
        math.randomseed(tostring(os.time()):reverse():sub(1, 6))
        local randomNum = math.random(1, superItemsCount)
        local goodsId = self.superItems[randomNum].goodsId
        while goodsId == self.lastGoodsId do 
            randomNum = math.random(1, superItemsCount)
            goodsId = self.superItems[randomNum].goodsId
        end
        self.lastGoodsId = goodsId
        self.bestItem = self.superItems[randomNum]
        dump(self.bestItem,"bestItem2+++")
    end
end

function MerchantView:setRandomUpdateTimer(bStart)
    if self.timerId then 
        self:getScheduler():unscheduleScriptEntry(self.timerId)
        self.timerId = nil
    end
    if bStart then 
        local function updateBestItems(dt)
            dump("updateBestItem+++")
            if self.superItems and #self.superItems > 1 then 
                self:setRandomBestItem()
                self:updateBestItem()
            end
        end
        self.timerId = tonumber(self:getScheduler():scheduleScriptFunc(updateBestItems, 5, false))
    end
end

function MerchantView:updateBestItem()
    if not self.bestItem then
        dump("MerchantView:updateBestItem fail+++") 
        return
    end

    if self.superItems and #self.superItems <= 1 then 
        return
    elseif self.superItems and #self.superItems > 1 then 
        self.m_desNode:setVisible(false)
    end

    dump(self.bestItem,"MerchantView:updateBestItem+++")
    local listItems = string.split(self.bestItem.goodsId, ";")
    local goodsItemId = listItems[1]
    local goodsItemCount = listItems[2]
    local mb_itemId = tonumber(goodsItemId)
    local m_itemNode1 = self.m_itemNode1
    local tc = ToolController:call("getInstance")
    if (mb_itemId ~= 0) then
        local label = m_itemNode1:getChildByTag(1) --tolua.cast(m_itemNode1:getChildByTag(1), "CCLabelIF")
        local picNode = tolua.cast(m_itemNode1:getChildByTag(2), "cc.Node")
        local label1 = m_itemNode1:getChildByTag(3) --tolua.cast(m_itemNode1:getChildByTag(3), "CCLabelIF")
        local nodePirce = tolua.cast(m_itemNode1:getChildByTag(5), "cc.Node")
        local sprPrice = tolua.cast(m_itemNode1:getChildByTag(6), "cc.Sprite")
        local lblPrice = m_itemNode1:getChildByTag(7) --tolua.cast(m_itemNode1:getChildByTag(7), "CCLabelIF")

        local bestTool = {} --for simple use
        bestTool.price = tonumber(self.bestItem.price) --miBest:getProperty("price")
        bestTool.priceType = tonumber(self.bestItem.priceType) --miBest:getProperty("priceType")
        bestTool.itemNum = tonumber(goodsItemCount) --miBest:getProperty("itemNum")
        bestTool.itemId = mb_itemId --miBest:getProperty("itemId")
        bestTool.priceHot = tonumber(self.bestItem.price_hot)--miBest:getProperty("priceHot")
        bestTool.type = tonumber(self.bestItem.type)--miBest:getProperty("type")


        if (label and picNode and label1 and nodePirce and sprPrice and lblPrice) then
            local showPrice = bestTool.price > 0 and true or false
            if (showPrice) then
                if (m_itemNode1:getChildByTag(8)) then
                    m_itemNode1:removeChildByTag(8)
                end

                if (bestTool.priceType < WorldResourceType.WorldResource_Max) then
                    local urlPrice = CCCommonUtilsForLua:call("getResourceIconByType", bestTool.priceType) --string
                    if (string.len(urlPrice) > 0) then
                        pFrame = CCSpriteFrameCache:sharedSpriteFrameCache():spriteFrameByName(urlPrice) --CCSpriteFrame
                        if pFrame ~= nil then
                            sprPrice:setSpriteFrame(pFrame)
                        end
                    end
                    sprPrice:setVisible(showPrice);
                else
                    local priceNode = CCNode:create()
                    local priceSpr = CCLoadSprite:call("createSprite" ,"Items_icon_kuang2.png") -- CCSprite
                    priceSpr:setScale(0.4)
                    priceNode:addChild(priceSpr)

                    CCCommonUtilsForLua:call( "createGoodsIcon", bestTool.priceType, priceNode, cc.size(35, 35) )
                    m_itemNode1:addChild(priceNode)
                    priceNode:setTag(8)
                    priceNode:setPosition(cc.p( sprPrice:getPositionX() - 10, sprPrice.getPositionY + 20 ) )
                    sprPrice:setVisible(false)
                end
                lblPrice:setString(CC_CMDITOA(bestTool.price))
            end

            lblPrice:setVisible(showPrice)

            local oldPrice = 0;
            label1:setString(" x" .. CC_CMDITOA(bestTool.itemNum))

            if (bestTool.itemId < WorldResourceType.WorldResource_Max) then
                local resourceName = CCCommonUtilsForLua:call("getResourceNameByType", bestTool.itemId) --string
                label:setString(resourceName)
                Dprint("label | resourceName=", resourceName)
                local iconName = CCCommonUtilsForLua:call("getResourceIconByType", bestTool.itemId)
                local pic = CCLoadSprite:call("createSprite", iconName)

                if (pic ~= nil) then
                    local sptName = CCCommonUtilsForLua:call("getToolBgByColor", 0) -- 0 == WHITE
                    local iconBg = CCLoadSprite:call("createSprite", sptName)

                    CCCommonUtilsForLua:call("setSpriteMaxSize", iconBg, 95, true)
                    picNode:addChild(iconBg)
                    CCCommonUtilsForLua:call("setSpriteMaxSize", pic, 75, true)
                    picNode:addChild(pic)
                end

                oldPrice = bestTool.priceHot
                self.m_desName:setString(resourceName)
                self.m_desLabel:setString(resourceName .. " x" .. tostring(bestTool.itemNum))
            else
                if (bestTool.type == MerchantToolType.MerchantTool_GOODS) then
                    CCCommonUtilsForLua:call("createGoodsIcon", bestTool.itemId, picNode, cc.size(95, 95), nil, self.m_desName, self.m_desLabel)
                    --MMHACK: 由于ccb里的CCLabel并不被CCCommonUtilsForLua:createGoodsIcon所支持，所以这里需要按逻辑手动赋值两个CCLabel，最终必须在tolua层面解决这问题，不然坑会越来越大。
                    local hackToolInfo = tc:call("getToolInfoByIdForLua", bestTool.itemId)
                    self.m_desName:setString(hackToolInfo:call("getName"))
                    self.m_desLabel:setString( _lang(hackToolInfo:getProperty("des")) )

                    label:setString(self.m_desName:getString())
                    --TODO: CMT
                    -- local tempStr = self.m_desName:getString()
                    -- Dprint("label | m_desName.str type=", type(tempStr), ", len=", string.len(tempStr))

                    if (bestTool.priceHot > 0) then
                        oldPrice = bestTool.priceHot
                    else
                        local info = tc:call("getToolInfoByIdForLua", bestTool.itemId) --ToolInfo
                        local info_price_hot = info:getProperty("price_hot")
                        if (info_price_hot > 0 and bestTool.priceType == WorldResourceType.Gold) then
                            oldPrice = info_price_hot * bestTool.itemNum
                        end
                    end
                elseif (bestTool.type == MerchantToolType.MerchantTool_EQUIP) then
                    local ec = EquipmentController:call("getInstance")
                    local eInfo = ec:call("getEquipInfoById", bestTool.itemId) --EquipmentInfo
                    if (eInfo == nil) then
                        return
                    end

                    local ename = getLang(eInfo:call("getName")) --string
                    local ebgPath = CCCommonUtilsForLua:call("getToolBgByColor", eInfo:call("getColor")) --string 
                    local ebgIcon = CCLoadSprite:call("createSprite", ebgPath) --Sprite
                    CCCommonUtilsForLua:call("setSpriteMaxSize", ebgIcon, 95, true)
                    picNode:addChild(ebgIcon)

                    local epicStr = CCCommonUtilsForLua:call("getIcon", tostring(bestTool.itemId)) --string
                    local eicon = CCLoadSprite:call("createSprite", epicStr, CCLoadSpriteType.CCLoadSpriteType_EQUIP); --Sprite
                    CCCommonUtilsForLua:call("setSpriteMaxSize", eicon, 95, true)
                    picNode:addChild(eicon)
                    self.m_desName:setString(ename)
                    local eDesc = getLang(eInfo:call("getDes"))
                    self.m_desLabel:setString(eDesc)

                    --TODO: CMT
                    Dprint("ename=", ename, ", eDesc=", eDesc)

                    oldPrice = bestTool.priceHot
                end
                
                if (showPrice and oldPrice>0 and nodePirce:getChildByTag(2)) then
                    local lbl = nodePirce:getChildByTag(2) --tolua.cast(nodePirce:getChildByTag(2), "CCLabelIF")
                    if(lbl) then
                        lbl:setString(CC_CMDITOA(oldPrice))
                        local scaleSpr = tolua.cast(nodePirce:getChildByTag(3), "ccui.Scale9Sprite")
                        if (scaleSpr) then
                            local scale = (lbl:getContentSize().width * lbl:getScaleX() + 10) * 1.0 / 107.0 --TODO: getOriginScaleX()
                            scaleSpr:setScaleX(scale)
                        end
                        lblPrice:setPositionY(52)
                        sprPrice:setPositionX(186)
                        sprPrice:setScale(1)
                        nodePirce:setVisible(true)
                    else
                        lblPrice:setPositionY(35)
                        sprPrice:setPositionX(196)
                        sprPrice:setScale(1)
                        nodePirce:setVisible(false)
                    end
                else
                    lblPrice:setPositionY(35)
                    sprPrice:setPositionX(186)
                    sprPrice:setScale(1)
                    nodePirce:setVisible(false)
                end
            end
        end
    end
end

function MerchantView:refreshTime(param) --在本次cmd的设计里，param就是dict
    Dprint("MerchantView | refreshTime!")
    self:onDelShowWateInterFace(nil)
    -- NetResult* result = dynamic_cast<NetResult*>(param);
    local dict = param
    self:getSuperItems(dict)
    self:setRandomBestItem()
    if not self.bestItem then 
        return 
    end
    -- auto dict = _dict(result->getData());
    if (dict:objectForKey("goldCost")) then
        self.m_refreshCost =  dict:valueForKey("goldCost"):intValue()
        if (self.m_refreshCost <= 0) then
            CCCommonUtilsForLua:setButtonTitle(self.m_btnRefresh, getLang("115062"))
            self.m_lblRefresh:setVisible(false)
            self.m_lblTitleRefresh:setVisible(false)
            self.m_sprRefresh:setVisible(false)
        else
            CCCommonUtilsForLua:setButtonTitle(self.m_btnRefresh, "")
            self.m_lblRefresh:setString(tostring(self.m_refreshCost))
            self.m_lblRefresh:setVisible(true)
            self.m_lblTitleRefresh:setVisible(true)
            self.m_sprRefresh:setVisible(true)
        end
    end

-- //    m_refreshTime = ToolController::getInstance()->getMerchante_time_e1();

    local gd =  GlobalData:call("shared")
    self.m_refreshTime = gd:getProperty("tomorrow_time")
    local nowTime = gd:call("getTimeStamp") --double
    
    self.m_leftTime = self.m_refreshTime - nowTime;
    self.m_timeLeftText:setString(getLang("102164") .. ": " .. CC_SECTOA(self.m_leftTime)) --CC_SECTOA

    local function luafunc()
        local mv = self
        mv:onTimer()
    end

    if not self.m_onTimer then
        self.m_entry_onTimer = self:getScheduler():scheduleScriptFunc(luafunc, 1.0, false)
        -- this->schedule(schedule_selector(MerchantView::onTimer),1.0);
        self.m_onTimer = true
    else
        -- this->unschedule(schedule_selector(MerchantView::onTimer));
        -- this->schedule(schedule_selector(MerchantView::onTimer),1.0);
        self:getScheduler():unscheduleScriptEntry(self.m_entry_onTimer)
        self.m_entry_onTimer = self:getScheduler():scheduleScriptFunc(luafunc, 1.0, false)
        self.m_onTimer = true --MMDOUBT: 原c里没加，似乎应该要加？
    end

    self.m_timeNode:setVisible(true)

    local tc = ToolController:call("getInstance")

    local m_itemNode1 = self.m_itemNode1 --临时省去添加大量self，并不推荐这么做。
    --local miBest = tc:getProperty("merchantBestTool") --MerchantToolInfo
    -- Dprint("mibest=", miBest)
    -- local mb_itemId = miBest:getProperty("itemId")
    dump(self.bestItem, "self.bestItemcheck1+++")
    local listItems = string.split(self.bestItem.goodsId, ";")
    local goodsItemId = listItems[1]
    local goodsItemCount = listItems[2]
    local mb_itemId = tonumber(goodsItemId)
    -- local mb_num = miBest:getProperty("num")
    -- local mb_color = miBest:getProperty("color")

    Dprint("miBest.itemId=", mb_itemId)

    if (mb_itemId ~= 0) then
        local label = m_itemNode1:getChildByTag(1) --tolua.cast(m_itemNode1:getChildByTag(1), "CCLabelIF")
        local picNode = tolua.cast(m_itemNode1:getChildByTag(2), "cc.Node")
        local label1 = m_itemNode1:getChildByTag(3) --tolua.cast(m_itemNode1:getChildByTag(3), "CCLabelIF")
        local nodePirce = tolua.cast(m_itemNode1:getChildByTag(5), "cc.Node")
        local sprPrice = tolua.cast(m_itemNode1:getChildByTag(6), "cc.Sprite")
        local lblPrice = m_itemNode1:getChildByTag(7) --tolua.cast(m_itemNode1:getChildByTag(7), "CCLabelIF")

        local bestTool = {} --for simple use
        bestTool.price = tonumber(self.bestItem.price) --miBest:getProperty("price")
        bestTool.priceType = tonumber(self.bestItem.priceType) --miBest:getProperty("priceType")
        bestTool.itemNum = tonumber(goodsItemCount) --miBest:getProperty("itemNum")
        bestTool.itemId = mb_itemId --miBest:getProperty("itemId")
        bestTool.priceHot = tonumber(self.bestItem.price_hot)--miBest:getProperty("priceHot")
        bestTool.type = tonumber(self.bestItem.type)--miBest:getProperty("type")
        dump(bestTool, "bestTool1+++")

        if (label and picNode and label1 and nodePirce and sprPrice and lblPrice) then
            local showPrice = bestTool.price > 0 and true or false
            if (showPrice) then
                if (m_itemNode1:getChildByTag(8)) then
                    m_itemNode1:removeChildByTag(8)
                end

                if (bestTool.priceType < WorldResourceType.WorldResource_Max) then
                    local urlPrice = CCCommonUtilsForLua:call("getResourceIconByType", bestTool.priceType) --string
                    if (string.len(urlPrice) > 0) then
                        pFrame = CCSpriteFrameCache:sharedSpriteFrameCache():spriteFrameByName(urlPrice) --CCSpriteFrame
                        if pFrame ~= nil then
                            sprPrice:setSpriteFrame(pFrame)
                        end
                    end
                    sprPrice:setVisible(showPrice);
                else
                    local priceNode = CCNode:create()
                    local priceSpr = CCLoadSprite:call("createSprite" ,"Items_icon_kuang2.png") -- CCSprite
                    priceSpr:setScale(0.4)
                    priceNode:addChild(priceSpr)

                    CCCommonUtilsForLua:call( "createGoodsIcon", bestTool.priceType, priceNode, cc.size(35, 35) )
                    m_itemNode1:addChild(priceNode)
                    priceNode:setTag(8)
                    priceNode:setPosition(cc.p( sprPrice:getPositionX() - 10, sprPrice.getPositionY + 20 ) )
                    sprPrice:setVisible(false)
                end
                lblPrice:setString(CC_CMDITOA(bestTool.price))
            end

            lblPrice:setVisible(showPrice)

            local oldPrice = 0;
            label1:setString(" x" .. CC_CMDITOA(bestTool.itemNum))

            if (bestTool.itemId < WorldResourceType.WorldResource_Max) then
                local resourceName = CCCommonUtilsForLua:call("getResourceNameByType", bestTool.itemId) --string
                label:setString(resourceName)
                Dprint("label | resourceName=", resourceName)
                local iconName = CCCommonUtilsForLua:call("getResourceIconByType", bestTool.itemId)
                local pic = CCLoadSprite:call("createSprite", iconName)

                if (pic ~= nil) then
                    local sptName = CCCommonUtilsForLua:call("getToolBgByColor", 0) -- 0 == WHITE
                    local iconBg = CCLoadSprite:call("createSprite", sptName)

                    CCCommonUtilsForLua:call("setSpriteMaxSize", iconBg, 95, true)
                    picNode:addChild(iconBg)
                    CCCommonUtilsForLua:call("setSpriteMaxSize", pic, 75, true)
                    picNode:addChild(pic)
                end

                oldPrice = bestTool.priceHot
                self.m_desName:setString(resourceName)
                self.m_desLabel:setString(resourceName .. " x" .. tostring(bestTool.itemNum))
            else
                if (bestTool.type == MerchantToolType.MerchantTool_GOODS) then
                    CCCommonUtilsForLua:call("createGoodsIcon", bestTool.itemId, picNode, cc.size(95, 95), nil, self.m_desName, self.m_desLabel)
                    --MMHACK: 由于ccb里的CCLabel并不被CCCommonUtilsForLua:createGoodsIcon所支持，所以这里需要按逻辑手动赋值两个CCLabel，最终必须在tolua层面解决这问题，不然坑会越来越大。
                    local hackToolInfo = tc:call("getToolInfoByIdForLua", bestTool.itemId)
                    self.m_desName:setString(hackToolInfo:call("getName"))
                    self.m_desLabel:setString( _lang(hackToolInfo:getProperty("des")) )

                    label:setString(self.m_desName:getString())
                    --TODO: CMT
                    -- local tempStr = self.m_desName:getString()
                    -- Dprint("label | m_desName.str type=", type(tempStr), ", len=", string.len(tempStr))

                    if (bestTool.priceHot > 0) then
                        oldPrice = bestTool.priceHot
                    else
                        local info = tc:call("getToolInfoByIdForLua", bestTool.itemId) --ToolInfo
                        local info_price_hot = info:getProperty("price_hot")
                        if (info_price_hot > 0 and bestTool.priceType == WorldResourceType.Gold) then
                            oldPrice = info_price_hot * bestTool.itemNum
                        end
                    end
                elseif (bestTool.type == MerchantToolType.MerchantTool_EQUIP) then
                    local ec = EquipmentController:call("getInstance")
                    local eInfo = ec:call("getEquipInfoById", bestTool.itemId) --EquipmentInfo
                    if (eInfo == nil) then
                        return
                    end

                    local ename = getLang(eInfo:call("getName")) --string
                    local ebgPath = CCCommonUtilsForLua:call("getToolBgByColor", eInfo:call("getColor")) --string 
                    local ebgIcon = CCLoadSprite:call("createSprite", ebgPath) --Sprite
                    CCCommonUtilsForLua:call("setSpriteMaxSize", ebgIcon, 95, true)
                    picNode:addChild(ebgIcon)

                    local epicStr = CCCommonUtilsForLua:call("getIcon", tostring(bestTool.itemId)) --string
                    local eicon = CCLoadSprite:call("createSprite", epicStr, CCLoadSpriteType.CCLoadSpriteType_EQUIP); --Sprite
                    CCCommonUtilsForLua:call("setSpriteMaxSize", eicon, 95, true)
                    picNode:addChild(eicon)
                    self.m_desName:setString(ename)
                    local eDesc = getLang(eInfo:call("getDes"))
                    self.m_desLabel:setString(eDesc)

                    --TODO: CMT
                    Dprint("ename=", ename, ", eDesc=", eDesc)

                    oldPrice = bestTool.priceHot
                end
                
                if (showPrice and oldPrice>0 and nodePirce:getChildByTag(2)) then
                    local lbl = nodePirce:getChildByTag(2) --tolua.cast(nodePirce:getChildByTag(2), "CCLabelIF")
                    if(lbl) then
                        lbl:setString(CC_CMDITOA(oldPrice))
                        local scaleSpr = tolua.cast(nodePirce:getChildByTag(3), "ccui.Scale9Sprite")
                        if (scaleSpr) then
                            local scale = (lbl:getContentSize().width * lbl:getScaleX() + 10) * 1.0 / 107.0 --TODO: getOriginScaleX()
                            scaleSpr:setScaleX(scale)
                        end
                        lblPrice:setPositionY(52)
                        sprPrice:setPositionX(186)
                        sprPrice:setScale(1)
                        nodePirce:setVisible(true)
                    else
                        lblPrice:setPositionY(35)
                        sprPrice:setPositionX(196)
                        sprPrice:setScale(1)
                        nodePirce:setVisible(false)
                    end
                else
                    lblPrice:setPositionY(35)
                    sprPrice:setPositionX(186)
                    sprPrice:setScale(1)
                    nodePirce:setVisible(false)
                end
            end
        end
-- //        addEffect();
-- //        if(!m_itemNode1->getChildByTag(10000)){
-- //            CCSize size = m_itemNode1->getContentSize();
-- //            ccColor3B color = {251, 183, 40};//{138,62,251};
-- //            MerchantShining *shine = MerchantShining::create(color,size);
-- //            shine->showEff2(true,0.7);
-- //            shine->setShineAlpha(255);
-- //            m_itemNode1->addChild(shine);
-- //            shine->setTag(10000);
-- //            shine->setPosition(ccp(size.width*0.5,size.height*0.5));
-- //            shine->startPlay(true);
-- //        }
    else 
        self.m_desNode:setVisible(false)
        self.m_itemNode1:removeAllChildren()

        local scrollView = CCScrollView:create(cc.size(320, 140))
        scrollView:setDirection(kCCScrollViewDirectionVertical)

        self.m_lblDialog = CCLabelIF:create()
        self.m_lblDialog:setAnchorPoint(cc.p(0, 0))
        self.m_lblDialog:setColor(cc.c3b(194, 158, 116))
        self.m_lblDialog:setDimensions(cc.size(320,0))
        self.m_lblDialog:setFontSize(20)

        scrollView:addChild(m_lblDialog)
        self.m_itemNode1:addChild(scrollView, 0, 100)
        scrollView:setPosition(cc.p(0, 40))
        self.m_timeNode:setVisible(false)
-- //        m_timeTitleText->setString(_lang("104931"));
        CCCommonUtilsForLua:call("setButtonTitle", self.m_btnRefresh, "")
        math.randomseed(tostring(os.time()):reverse():sub(1, 6))
        local index = math.random(0, 4)
        self:setTip(index)

        local delay = cc.DelayTime:create(90)
        local luafunc = function ()
            self:refreshTip()
        end 
        local cfunc = cc.CallFunc:create(luafunc)
        local seqAction = cc.Sequence:create(delay, cfunc)
        self.m_itemNode1:runAction(seqAction)
    end

    self.m_itemNode1:setVisible(true)
    self.m_isRefresh = false
    self.m_isInit = true
    self:refreshView()
end

function MerchantView:refreshView()
    self:generateData()
    self.m_tabView:reloadData()
    self.m_showRefreshEff=false
end

function MerchantView:onTimer() --dt=float
    local nowTime = GlobalData:call("getTimeStamp") --double
    self.m_leftTime = self.m_refreshTime - nowTime
    if (self.m_leftTime < 0) then
        local tc = ToolController:call("getInstance")
        tc:setProperty("m_merchantCurrIndex", 0)
-- //        if(m_isRefresh == true)
-- //            return;
        if (self.m_onTimer) then
            if (self.m_entry_onTimer ~= -1) then
                self:getScheduler():unscheduleScriptEntry(self.m_entry_onTimer)
            end
            self.m_onTimer = false
            self.m_entry_onTimer = -1
        end

        local temp = PopupViewController:call("getCurrentPopupView") --StoreBuyConfirmDialog
        local dialog = tolua.cast(temp, "StoreBuyConfirmDialog")
        if (dialog) then
            dialog:call("closeSelf")
        end
-- //        closeSelf();
-- //        getHotItems();
    else
        local txt = getLang("102164") .. ": " .. CC_SECTOA(self.m_leftTime)
        self.m_timeLeftText:setString(txt)
    end
end

function MerchantView:generateData()
    local tc = ToolController:call("getInstance")
    local items = tc:getProperty("m_toolMerchantInfos") --vector<MerchantToolInfo>
    Dprint("m_toolMerchantInfos items type=", type(items))
    self.m_dataCount = table.getn(items)
end

function MerchantView:onTouchBegan(x, y)
    Dprint("MerchantView:onTouchBegan | x=",x,",y=",y)
    self.m_desNode:setVisible(false)
    if (not isTouchInside(self.m_infoList, x, y)) then
        return true
    end
    return false
end

function MerchantView:onTouchMoved(x, y)
end

function MerchantView:onTouchEnded(x, y)
    Dprint("MerchantView:onTouchEnded | x=",x,",y=",y)
    if ( not isTouchInside(self.m_infoList, x, y)) then
    
    end

    if(self.m_itemNode1:isVisible() and isTouchInside(self.m_itemNode1:getChildByTag(4), x, y)) then
        self.m_desNode:setVisible(true)
    end
end

function MerchantView:scrollViewDidScroll(view)
    local mindy = self.m_tabView:minContainerOffset().y - 20 --TODO: 留意，如果有问题，可能是因为这个可能没有。
    local dy = self.m_tabView:getContentOffset().y;
    if ( dy < mindy) then
        self.m_tabView:setContentOffset(cc.p(0, mindy))
    end
end

function MerchantView:tableCellTouched(tab,cell)
    
end

function MerchantView:cellSizeForTable(tab,idx)
    return 600,170 --return table?
end

function MerchantView:tableCellAtIndex(tab, idx)
    if (idx >= self.m_dataCount) then
        return nil
    end
-- //    auto &items = ToolController::getInstance()->m_toolMerchantInfos;
    local cell = tab:dequeueCell() --MerchantTabelCell
    if (cell) then
        Dprint("MerchantView:tableCellAtIndex(tab, idx)， refresh", idx)
        cell:setData(idx,self.m_showRefreshEff);
    else
        Dprint("MerchantView:tableCellAtIndex(tab, idx)， create", idx)
        cell = MerchantTabelCell:create(idx, self.m_infoList);
    end
    return cell
end

function MerchantView:numberOfCellsInTableView(tab)
    return self.m_dataCount
end

-- CCSize MerchantView::tableCellSizeForIndex(CCTableView *table, ssize_t idx){
--     if(idx >= m_dataCount){
--         return CCSizeZero;
--     }
--     return CCSize(600, 170);
-- }

-- void MerchantView::tableCellWillRecycle(CCTableView* table, CCTableViewCell* cell){
-- }
    

function MerchantView:onRefreshClick()
    Dprint("MerchantView:onRefreshClick() p1")
    -- local kkoo = tc:call("getMerchante_animation")
    -- Dprint("kkoo type=", type(kkoo), ", value=", kkoo)
    -- if tc:call("getMerchante_animation") then
    --     return
    -- end

    self:resetRefreshTip()

    Dprint("MerchantView:onRefreshClick() p2")

    if (self.m_isRefresh) then
        return
    end

    Dprint("MerchantView:onRefreshClick() p3")

    if (1 == self.m_refreshTipType or 2 == self.m_refreshTipType) then
        if (self.m_refreshCost <= 0 )then
            self:onOkRefresh()
        else
            local function onOkRefreshCb()
                self:onOkRefresh()
            end
            YesNoDialog:call("showButtonAndGold", getLang("104939"), cc.CallFunc:create(onOkRefreshCb), getLang("104932"), self.m_refreshCost)
        end
    elseif (3 == self.m_refreshTipType) then
        local function onOkRefreshCb()
            self:onOkRefresh()
        end
        YesNoDialog:call("showButtonAndGold", getLang("104951"), cc.CallFunc:create(onOkRefreshCb), getLang("104932"), self.m_refreshCost)
    else
        self:onOkRefresh()
    end
end

function MerchantView:onOkRefresh()
    if (CCCommonUtilsForLua:call("isEnoughResourceByType", WorldResourceType.Gold, self.m_refreshCost)) then
        self:getHotItems(true)
    else
        YesNoDialog:call("gotoPayTips")
    end

    if (self.m_refreshTipType==1) then
        local gd = GlobalData:call("shared")
        local ccud = cc.UserDefault:getInstance()
        ccud:setStringForKey( MERCHANTE_REFRESH_TIME_KEY, CC_ITOA(gd:getProperty("tomorrow_time")) )
        ccud:setIntegerForKey(MERCHANTE_REFRESH_SHOW_FLAG_KEY, 0)
        ccud:flush()
    end
    self.m_refreshTipType = 0
end

function MerchantView:onTipClick()
    PopupViewController:call("addPopupTipsView", getLang("104952"))
end

--c里没有调用这个，但是注释留在这里做个备份。
-- void MerchantView::addEffect(){
--     string tmpStart = "UIGlow_LR_";
--     float offset = 80.0f;
--     float scale = 0.9f;
--     float scale1 = 0.5f;
--     int count = 3;
--     for (int i=1; i <= count; i++) {
--         if(i==2){
--             continue;
--         }
--         auto particle = ParticleController::createParticle(CCString::createWithFormat("%s%d",tmpStart.c_str(),i)->getCString());
--         particle->setPosition(ccp(offset, 0));
--         particle->setScaleY(scale);
--         particle->setScaleX(scale1);
--         m_receiveGlow->addChild(particle);
--     }
--     for (int i=1; i <= count; i++) {
--         if(i==2){
--             continue;
--         }
--         auto particle = ParticleController::createParticle(CCString::createWithFormat("%s%d",tmpStart.c_str(),i)->getCString());
--         particle->setPosition(ccp(-offset, 0));
--         particle->setScaleY(scale);
--         particle->setScaleX(scale1);
--         m_receiveGlow->addChild(particle);
--     }
--     tmpStart = "UIGlow_UD_";
--     for (int i=1; i <= count; i++) {
--         if(i==2){
--             continue;
--         }
--         auto particle = ParticleController::createParticle(CCString::createWithFormat("%s%d",tmpStart.c_str(),i)->getCString());
--         particle->setPosition(ccp(0, offset));
--         particle->setScaleX(scale);
--         particle->setScaleY(scale1);
--         m_receiveGlow->addChild(particle);
--     }
--     for (int i=1; i <= count; i++) {
--         if(i==2){
--             continue;
--         }
--         auto particle = ParticleController::createParticle(CCString::createWithFormat("%s%d",tmpStart.c_str(),i)->getCString());
--         particle->setPosition(ccp(0, -offset));
--         particle->setScaleX(scale);
--         particle->setScaleY(scale1);
--         m_receiveGlow->addChild(particle);
--     }
-- }

return MerchantView