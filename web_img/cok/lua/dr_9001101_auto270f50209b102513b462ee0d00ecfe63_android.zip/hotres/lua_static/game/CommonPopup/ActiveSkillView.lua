local ActiveSkillView = class("ActiveSkillView", function (  )
	return PopupBaseView:call("create")
end)
local ActiveSkillCell = class("ActiveSkillCell", function (  )
	return cc.TableViewCell:create()
end)

local General_Skill_Type = 0 --领主技能类型
local Alliance_CiviSkill_Type = 1 --文明星盘技能类型

local UseSkillCommand = class("UseSkillCommand", LuaCommandBase)
local CancelSkillCommand = class("CancelSkillCommand", LuaCommandBase)
local UseSkillViewItemView = class("UseSkillViewItemView", function (  )
	return PopupBaseView:call("create")
end)

function UseSkillCommand:ctor( skillId)
	MyPrint("UseSkillCommand:ctor ", skillId)
	self.super.ctor(self, "skill.use")

	self:putParam("skillId", CCString:create(tostring(skillId)))

	self.cacheSkillId = skillId
	local ginfo = GlobalData:call("getSelfGeneralInfo")
	if ginfo then
		self:putParam("gUid", CCString:create(tostring(ginfo:getProperty("uuid"))))
	end
end

function UseSkillCommand:handleReceive( dict )
	local cmdname = dict:valueForKey("cmd"):getCString()
	if cmdname ~= "skill.use" then
		return false
	end
	MyPrint("UseSkillCommand:handleReceive")
	local params = dict:objectForKey("params")
	if nil == params then
		return true
	end
	params:setObject(CCString:create(self.cacheSkillId), "cacheSkillId")
	if params:objectForKey("errorCode") ~= nil then
		local errorCode = params:valueForKey("errorCode"):getCString()
		MyPrint("UseSkillCommand:handleReceive ... errorCode .. " .. errorCode)
		CCCommonUtilsForLua:call("flyText", getLang(errorCode))
		CCSafeNotificationCenter:call("postNotification", "msg_useskillcmd_fail", params)
		return true
	end

	local skillId = params:valueForKey("skillId"):getCString()
	if skillId == "" then
		return true
	end

	GeneralManager:call("updateOneSkillCDInfo", params)

	local effectState = params:objectForKey("effectState")
	if effectState and effectState:objectForKey("501051") then
		local protectTime = effectState:valueForKey("501051"):doubleValue()
		local playerInfo = GlobalData:call("getPlayerInfo")
		playerInfo:setProperty("resourceProtectTimeStamp", protectTime)
	end
	if params:objectForKey("use_item") then
		ToolController:call("pushAddTool", params:objectForKey("use_item"))
	end

	CCSafeNotificationCenter:call("postNotification", "msg_useskillcmd_success", params)
	return true
end


function CancelSkillCommand:ctor( skillId, itemId )
	self.super.ctor(self, "skill.del")

	self:putParam("skillId", CCString:create(tostring(skillId)))

	local ginfo = GlobalData:call("getSelfGeneralInfo")
	if ginfo then
		self:putParam("gUid", CCString:create(tostring(ginfo:getProperty("uuid"))))
	end
end

function CancelSkillCommand:handleReceive( dict )
	local cmdname = dict:valueForKey("cmd"):getCString()
	if cmdname ~= "skill.del" then
		return false
	end
	MyPrint("CancelSkillCommand:handleReceive")
	local params = dict:objectForKey("params")
	if nil == params then
		return true
	end
	if params:objectForKey("errorCode") ~= nil then
		local errorCode = params:valueForKey("errorCode"):getCString()
		MyPrint("UseSkillCommand:handleReceive ... errorCode .. " .. errorCode)
		CCCommonUtilsForLua:call("flyText", getLang(errorCode))
		return true
	end

	local skillId = params:valueForKey("skillId"):getCString()
	if skillId == "" then
		return true
	end

	GeneralManager:call("updateOneSkillCDInfo", params)

	CCSafeNotificationCenter:call("postNotification", "skill.del")
	CCSafeNotificationCenter:call("postNotification", "msg_cancelskillcmd_back", CCString:create(skillId))
	return true
end

function UseSkillViewItemView:ctor( id, father )
	self.id = id
	self.father = father
end

function UseSkillViewItemView.create( id, father )
	local ret = UseSkillViewItemView.new(id, father)
	if ret:initSelf() ~= true then
		ret = nil 
	end
	return ret
end

function UseSkillViewItemView:initSelf(  )
	self:init(true, 0)
	self:setHDPanelFlag(true)

	local winsize = cc.Director:getInstance():getIFWinSize()
	self:setContentSize(winsize)
	local proxy = cc.CCBProxy:create()
    local ccbiUrl = "UseSkillViewCCB_ttt.ccbi"
	local node = CCBReaderLoad(ccbiUrl, proxy, self)
	self:addChild(node)

	if CCCommonUtilsForLua:call("isIosAndroidPad") then
		self.m_mainNode:setScale(2)
	end

	self.touchLayer = cc.Layer:create()
	self:addChild(self.touchLayer)
	self.startTouchPt = cc.p(0, 0)
	local function touchHandle( eventType, x, y )
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		else
			self:onTouchEnded(x, y)
		end
	end
	self.touchLayer:registerScriptTouchHandler(touchHandle)
	self.touchLayer:setTouchEnabled(true)
	self.touchLayer:setSwallowsTouches(false)

	local function onNodeEvent( event )
		if event == "enter" then
			self:onEnter()
	    elseif event == "exit" then
	    	self:onExit()
	    end
	end
	self:registerScriptHandler(onNodeEvent)

	local cdinfo = GeneralManager:call("getSkillCDInfoById", self.id)
	local generalInfo = GlobalData:call("getSelfGeneralInfo")
	if nil == generalInfo then
		return false
	end

	self.m_skillName:setString(getLang(CCCommonUtilsForLua:call("getPropById", self.id, "name")))
	local dialog = CCCommonUtilsForLua:call("getPropById", self.id, "description")
	local base = CCCommonUtilsForLua:call("getPropById", self.id, "")
	local t = math.tonumber(CCCommonUtilsForLua:call("getPropById", self.id, "type"))
	if t == 12 or t == 13 or t == 15 then
		self.m_descTxt:setString(getLang(dialog, base))
	elseif t == 14 then
		local ta = string.split(base, "|")
		if #ta == 2 then
			self.m_descTxt:setString(getLang(dialog, ta[1], ta[2]))
		end
	else
		self.m_descTxt:setString(getLang(dialog))
	end

	local iconstr = CCCommonUtilsForLua:call("getPropById", self.id, "icon") .. ".png"
	local head = CCLoadSprite:call("createSprite", iconstr)
	self.m_head:addChild(head)

	CCCommonUtilsForLua:call("setButtonTitle", self.m_useBtn1, getLang("150765"))
	CCCommonUtilsForLua:call("setButtonTitle", self.m_useBtn2, getLang("150766"))
	self.m_skillEffectNode1:setVisible(false)
	self.m_skillEffectNode2:setVisible(false)

	if self.id == "612400" then
		CCCommonUtilsForLua:call("setButtonTitle", self.m_useBtn1, "")
		CCCommonUtilsForLua:call("setButtonTitle", self.m_useBtn2, "")

		self.m_skillEffectNode1:setVisible(true)
		self.m_skillEffectNode2:setVisible(true)

		self.m_skillUse1:setString(getLang("150765"))
		self.m_skillUse2:setString(getLang("150766"))
	elseif self.id == "602700" then --救援不显示使用道具按钮
		self.m_useBtn2:setVisible(false)
		self.m_useBtn1:setPositionX(self.m_useBtn:getPositionX())
	end

	return true
end

function UseSkillViewItemView:onTouchBegan( x, y )
	self.startTouchPt = cc.p(x, y)
	if isTouchInside(self.m_clickArea, x, y) == false then
		return true
	end
	return false
end

function UseSkillViewItemView:onTouchEnded( x, y )
	if isTouchInside(self.m_clickArea, x, y) then
		return
	end

	self:call("closeSelf")
end

function UseSkillViewItemView:onEnter(  )
	-- body
end

function UseSkillViewItemView:onExit(  )
	-- body
end

function UseSkillViewItemView:onUseClick1(  )
	local id = self.id
	local father = self.father
	self:call("closeSelf")
	if id == "612400" then
		father:addResourceFunction(false)
	else
		father.m_skillItemId = ""
		father:generalUseClick()
	end
end

function UseSkillViewItemView:onUseClick2(  )
	local id = self.id
	local father = self.father
	self:call("closeSelf")
	if id == "612400" then
		father:addResourceFunction(true)
	else
		father.m_skillItemId = CCCommonUtilsForLua:call("getPropById", id, "item")
		father:generalUseClick()
	end
end

local function getKeyById( id )
	-- body
	if nil == id then
		return ""
	end
	id = math.tonumber(id)
	if id >= 600000 and id <= 699999 then
		return "general"
	end
	if (id >= 85100 and id <= 87999) or (id >= 53900 and id <= 54899) then --53900-54899是新的英雄技能
		return "hero"
	end
	if id >= 4906101 and id <= 4907000 then
		return "dragon"
	end
	return ""
end

local function isObtain( skillId )
	-- body
	local tag = getKeyById(skillId)
	if tag == "general" then
		local generalInfo = GlobalData:call("getSelfGeneralInfo")
		if nil == generalInfo then
			return false
		end
		return generalInfo:call("checkHaveStudy", skillId, generalInfo:getProperty("curMapIdx"))
	elseif tag == "hero" then
		local info = HeroManager.getActiveSkillInfoById(skillId)
		if nil == info then
			return false
		end
		return info:isObtain()
	elseif tag == "dragon" then
 		local data = DragonActiveSkillManager.getInstance():getDataById(skillId)
		if nil == data then
			return false
		end
		return data:getIsUnLocked()
	end
	return false
end

function ActiveSkillView:ctor(  )
	-- body
	-- all general dragon hero
	-- cc.UserDefault:getInstance():getStringForKey("ACTIVITY_GOLDBOX", "")
	-- cc.UserDefault:getInstance():setStringForKey("ACTIVITY_CONSUME", "0")
	self.isGreenServer = GlobalDataCtr.checkIsGreenServer()	
	self.page = cc.UserDefault:getInstance():getStringForKey("ActiveSkillView_page", "all")
	--怀旧服上目前只有领主技能
	if self.isGreenServer then
		self.page = "general"
	end	
	self.data = {}
	self.curData = {}
end

function ActiveSkillView.create(  )
	-- body
	local ret = ActiveSkillView.new()
	if ret:initSelf() ~= true then
		ret = nil 
	end
	return ret
end

function ActiveSkillView:initSelf(  )
	-- body
	self:init(true, 0)
	self:setHDPanelFlag(true)

	CCLoadSprite:call("doResourceByCommonIndex", 105, true)
	CCLoadSprite:call("doResourceByCommonIndex", 5, true)
	CCLoadSprite:call("loadDynamicResourceByName", "newHero")
	CCLoadSprite:call("loadDynamicResourceByName", "science")
	CCLoadSprite:call("loadDynamicResourceByName", "Common_209_face")
	CCLoadSprite:call("loadDynamicResourceByName", "dragonCave")
	CCLoadSprite:call("loadDynamicResourceByName", "dragonCave1")
	CCLoadSprite:call("doResourceByCommonIndex", 500, true)

	local winsize = cc.Director:getInstance():getIFWinSize()

	self:setContentSize(winsize)
	local proxy = cc.CCBProxy:create()
    local ccbiUrl = "ActiveSkillView"
	local node = CCBReaderLoad(ccbiUrl, proxy, self)
    self:addChild(node)

    if CCCommonUtilsForLua:call("isIosAndroidPad") then
    	self.m_middleNode:setScale(2)
    end

	self:initData()
	
	--怀旧服不显示分页
	if self.isGreenServer then
		self.m_toggleRootNode:setVisible(false)
		self.m_sprLine:setVisible(false)
		local originSize = self.m_listNode:getContentSize()
		self.m_listNode:setContentSize(cc.size(originSize.width, originSize.height + 60))
	end

    local delegate = {}
    delegate.gridAtIndex = function(tab, idx) return self:gridAtIndex(tab, idx) end
    delegate.numberOfCellsInTableView = function(tab) return self:numberOfCellsInTableView(tab) end
    delegate.numberOfGridsInCell = function(tab) return self:numberOfGridsInCell(tab) end
    delegate.gridSizeForTable = function(tab, idx) return self:gridSizeForTable(tab, idx) end

    self.m_tabView = myRequire("game.utility.TableViewMultiCol").new(self.m_listNode:getContentSize())
    self.m_tabView:setDelegate(delegate)
	self.m_tabView:setDirection(kCCScrollViewDirectionVertical)
	self.m_tabView:setVerticalFillOrder(kCCTableViewFillTopDown)
	self.m_listNode:addChild(self.m_tabView)

	local function onNodeEvent( event )
		if event == "enter" then
			self:onEnter()
	    elseif event == "exit" then
	    	self:onExit()
	    end
	end
	self:registerScriptHandler(onNodeEvent)

	self.startTouchPt = cc.p(0, 0)
	self.touchLayer = cc.Layer:create()
	self:addChild(self.touchLayer)
	local function touchHandle( eventType, x, y )
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		else
			self:onTouchEnded(x, y)
		end
	end
	self.touchLayer:registerScriptTouchHandler(touchHandle)
	self.touchLayer:setTouchEnabled(true)
	self.touchLayer:setSwallowsTouches(false)

	-- 169855=全部
	-- 169856=领主
	-- 169858=龙
	-- 169857=英雄
	self.m_tab1Label:setString(getLang("169855"))
	self.m_tab2Label:setString(getLang("169856"))
	self.m_tab3Label:setString(getLang("169858"))
	self.m_tab4Label:setString(getLang("169857"))
	-- 118000=主动技能
	self.m_titleLabel:setString(getLang("118000"))

	self.m_tab1Button:setEnabled(self.page ~= "all")
	self.m_tab2Button:setEnabled(self.page ~= "general")
	self.m_tab3Button:setEnabled(self.page ~= "dragon")
	self.m_tab4Button:setEnabled(self.page ~= "hero")

	self:onNoCellTouch()	
	return true
end

function ActiveSkillView:gridSizeForTable(table)
	return 168, 225
end

function ActiveSkillView:gridAtIndex(table, idx)
	idx = idx + 1
	if (idx > #self.curData) then
		return nil
	end

	local cell = table:dequeueGrid()
	local id = self.curData[idx]
	
	
	if (cell) then
		cell:setData(id)
	else
		cell = ActiveSkillCell.new(id, self)
	end
	
	return cell
end

function ActiveSkillView:numberOfCellsInTableView(table)
	local cellNum = #self.curData
	if cellNum % 3 == 0 then
		return math.floor(cellNum / 3)
	else
		return math.floor(cellNum / 3) + 1
	end
end

function ActiveSkillView:numberOfGridsInCell(multiTable)
	return 3
end

function ActiveSkillView:initData(  )
	-- body
	self.data = {}

	-- 领主
	local generalData = {}
	local data = CCCommonUtilsForLua:getGroupByKey("sk")
	for k,v in pairs(data) do
		if math.tonumber(v.type) >= 10 then
			generalData[#generalData + 1] = k
		end
	end
	table.sort( generalData, function ( k1, k2 )
		return data[k1].activeskill_index < data[k2].activeskill_index
	end )
	for i,v in ipairs(generalData) do
		self.data[#self.data + 1] = v
	end

	-- 龙
	local dragonSkillIds = DragonActiveSkillManager.getInstance():getOwnDragonActiveSkillIds()
	dump(dragonSkillIds,"ActiveSkillView dragonSkillIds  ")
	if not self.isGreenServer and CCCommonUtilsForLua:call("isFunOpenByKey","dragon_talentskill") then--wangyian
		for i,v in ipairs(dragonSkillIds) do
			self.data[#self.data + 1] = v
		end
	end

	-- 英雄
	if not self.isGreenServer then
		local heroSkillIds = HeroManager.getAllActiveSkillIds()
		for i,v in ipairs(heroSkillIds) do
			self.data[#self.data + 1] = v
		end
	end	

	local obtainTable = {}
	for i,v in ipairs(self.data) do
		obtainTable[v] = isObtain(v)
	end

	table.sort( self.data, function ( id1, id2 )
		-- body
		if obtainTable[id1] == true and obtainTable[id2] == false then
			return true
		end
		if obtainTable[id1] == false and obtainTable[id2] == true then
			return false
		end
		return false
	end )
	
end

function ActiveSkillView:refreshCurData(  )
	-- body
	self.curData = {}
	if self.page == "all" then
		self.curData = clone(self.data)
		return
	end
	for i,v in ipairs(self.data) do
		if getKeyById(v) == self.page then
			self.curData[#self.curData + 1] = v
		end
	end
end

function ActiveSkillView:refreshListView(  )
	-- body
	self.m_tabView:reloadData()
	self.m_tabView:setContentOffset(cc.p(0, self.m_listNode:getContentSize().height - self.m_tabView:getContentSize().height))
end

function ActiveSkillView:onChangeSkillBtnClick(  )
	-- body

	local changeToNo=true
	local generalInfo = GlobalData:call("getSelfGeneralInfo")
	if nil == generalInfo then
		return
	end

    local tempSuperMap = generalInfo:getProperty("generalSkillMaps")
    if nil == tempSuperMap then
    	return
    end
    local firstV = tempSuperMap[1 - generalInfo:getProperty("curMapIdx")]
    if firstV ~= nil then
        for k, v in pairs(firstV) do
            for p, q in pairs(v) do
                if q and q:getProperty("level") > 0 then
                    changeToNo = false
                end
            end
        end
    end

    if changeToNo then
        YesNoDialog:call("showYesDialog",_lang("137655"))
        return
    end

	local function confirm(  )
		-- body
		self.m_changeSkillBtn:setEnabled(false)

		local generalInfo = GlobalData:call("getSelfGeneralInfo")
		if nil == generalInfo then
			return
		end

		local cmd = myRequire("game.command.GeneralSkillSwitchCommand"):create(generalInfo:getProperty("uuid"), 1 - generalInfo:getProperty("curMapIdx"))
		cmd:send()
	end

	local changeCost = tonumber(CCCommonUtilsForLua:call("getPropById", "99006", "k2"))
    YesNoDialog:call("show", _lang_1("137656", CC_ITOA(changeCost)) , cc.CallFunc:create(confirm))
	
	
end

function ActiveSkillView:refreshChangeBtn(  )
	-- body
	MyPrint("ActiveSkillView:refreshChangeBtn ", self.page)
	self.m_changeNode:setVisible(false)
	if self.page == "dragon" and #self.curData == 0 then
		self.m_labelTips:setVisible(true)
		self.m_labelTips:setString(getLang("161046"))
	else
		self.m_labelTips:setVisible(false)
	end

	if self.page ~= "general" then
		return
	end

	local showChangeBtnLv = math.tonumber(CCCommonUtilsForLua:call("getPropById", "99006", "k1"))
	local ds_switch = CCCommonUtilsForLua:call("getPropById", "99006", "k3")
	MyPrint("ds_switch ", ds_switch)
	MyPrint("showChangeBtnLv ", showChangeBtnLv)
	MyPrint("my level ", GlobalData:call("getPlayerInfo"):getProperty("SVIPLevel"))
	if CCCommonUtilsForLua:call("getPropById", "checkVersion", ds_switch) and showChangeBtnLv <= GlobalData:call("getPlayerInfo"):getProperty("SVIPLevel") then
		self.m_changeNode:setVisible(true)
		self.m_changeSkillBtn:setEnabled(true)
	end

end

function ActiveSkillView:onDragonSkillData()
	local dragonSkillIds = DragonActiveSkillManager.getInstance():getOwnDragonActiveSkillIds()
	dump(dragonSkillIds,"ActiveSkillView dragonSkillIds  ")
	if CCCommonUtilsForLua:call("isFunOpenByKey","dragon_talentskill") then--wangyian
		for i,v in ipairs(dragonSkillIds) do
			self.data[#self.data + 1] = v
		end
	end
	self:refreshCurData()
	self:refreshListView()
	self:refreshChangeBtn()
end

function ActiveSkillView:onEnter(  )
	self:refreshCurData()
	self:refreshListView()
	self:refreshChangeBtn()

	local function onGetChangeBack( dict )

		self.m_changeSkillBtn:setEnabled(true)

		if nil == dict then
			return
		end

		local generalInfo = GlobalData:call("getSelfGeneralInfo")
		if nil == generalInfo then
			return
		end

		if dict:objectForKey("gold") then
			GlobalData:call("shared"):call("getPlayerInfo"):setProperty("gold", dict:valueForKey("gold"):intValue())
			CCSafeNotificationCenter:call("postNotification", "city_resources_update")

			local curMapIdx = generalInfo:getProperty("curMapIdx")
			if curMapIdx == 0 then
				generalInfo:setProperty("curMapIdx", 1)
			elseif curMapIdx == 1 then
				generalInfo:setProperty("curMapIdx", 0)
			end

			GeneralManager:call("resetGeneralSkillEffectValue")
			GeneralManager:call("resetSkillCDMap")

		end

		self:initData()
		self:refreshCurData()
		self:refreshListView()
		self:refreshChangeBtn()
	end
	local handler1 = self:registerHandler(onGetChangeBack)
	CCSafeNotificationCenter:call("registerScriptObserver", self, handler1, "GeneralSkillSwitch_back")
	
	registerScriptObserver(self, self.onDragonSkillData, "msg_dragonactiveskill_data_back")
	registerScriptObserver(self, self.onCloseClick, 'ActiveSkillView.onCloseClick')
end

function ActiveSkillView:onExit(  )
	cc.UserDefault:getInstance():setStringForKey("ActiveSkillView_page", self.page)
	CCSafeNotificationCenter:call("unregisterScriptObserver", self, "GeneralSkillSwitch_back")
    unregisterScriptObserver(self, "msg_dragonactiveskill_data_back")
    unregisterScriptObserver(self, 'ActiveSkillView.onCloseClick')
end

function ActiveSkillView:onTouchBegan( x, y )
	-- body
	if isTouchInside(self.m_touchNode, x, y) == false then
		return true
	end
	return false
end

function ActiveSkillView:onTouchEnded( x, y )
	-- body
	if isTouchInside(self.m_touchNode, x, y) == false then
		self:call("closeSelf")
	end
end

function ActiveSkillView:onCloseClick(  )
	self:call("closeSelf")
end

function ActiveSkillView:onTab1ButtonClick(  )
	-- body
	self.m_tab1Button:setEnabled(false)
	self.m_tab2Button:setEnabled(true)
	self.m_tab3Button:setEnabled(true)
	self.m_tab4Button:setEnabled(true)
	self.page = "all"
	self:refreshCurData()
	self:refreshListView()
	self:refreshChangeBtn()
end

function ActiveSkillView:onTab2ButtonClick(  )
	-- body
	self.m_tab1Button:setEnabled(true)
	self.m_tab2Button:setEnabled(false)
	self.m_tab3Button:setEnabled(true)
	self.m_tab4Button:setEnabled(true)
	self.page = "general"
	self:refreshCurData()
	self:refreshListView()
	self:refreshChangeBtn()
end
function ActiveSkillView:onTab3ButtonClick(  )
	-- body
	self.m_tab1Button:setEnabled(true)
	self.m_tab2Button:setEnabled(true)
	self.m_tab3Button:setEnabled(false)
	self.m_tab4Button:setEnabled(true)
	self.page = "dragon"
	self:refreshCurData()
	self:refreshListView()
	self:refreshChangeBtn()
end
function ActiveSkillView:onTab4ButtonClick(  )
	-- body
	self.m_tab1Button:setEnabled(true)
	self.m_tab2Button:setEnabled(true)
	self.m_tab3Button:setEnabled(true)
	self.m_tab4Button:setEnabled(false)
	self.page = "hero"
	self:refreshCurData()
	self:refreshListView()
	self:refreshChangeBtn()
end

function ActiveSkillView:onCellTouch( cell )
	-- body
	-- 146323=技能在冷却中
	-- 169629=激活中

	local nowTimeStamp = GlobalData:call("getTimeStamp")
	local nowWorldTime = GlobalData:call("getWorldTime")

	if self.m_desNode:isVisible() == false then
		self.m_desNode:setVisible(true)
		self.m_labelNode:removeAllChildren()
		local id = cell.id
		local name = ""
		local timeStr = ""
		local desc = ""
		local isActive = false
		local isInCD = false
		local color = cc.c3b(255, 255, 255)

		local tag = getKeyById(id)

		if tag == "general" then
			local generalInfo = GlobalData:call("getSelfGeneralInfo")
			local cdinfo = GeneralManager:call("getSkillCDInfoById", id)
			if nil == generalInfo then
				return
			end
			name = getLang(CCCommonUtilsForLua:call("getPropById", id, "name"))
			local dialog = CCCommonUtilsForLua:call("getPropById", id, "description")
			local base = CCCommonUtilsForLua:call("getPropById", id, "base")
			local t = math.tonumber(CCCommonUtilsForLua:call("getPropById", id, "type"))
			if cdinfo then
				local skillType = cdinfo:getProperty("type")
				if skillType == Alliance_CiviSkill_Type then
					local civiBase = require("game.allianceTerritory.civiMiracle.CiviMiracleManager").getSkillCiviBase(id)
					if civiBase then base = civiBase end
				end
			end

			if t == 12 or t == 13 or t == 15 then
				desc = getLang(dialog, base)
			elseif t == 14 then
				local ta = string.split(base, "|")
				if #ta == 2 then
					desc = getLang(dialog, ta[1], ta[2])
				end
			else
				desc = getLang(dialog)
			end

			local gapTime = 0
			local effectTime = 0
			if generalInfo:call("checkHaveStudy", id, generalInfo:getProperty("curMapIdx")) then
				if cdinfo and cdinfo:getProperty("endTime") ~= 0 then
					gapTime = cdinfo:getProperty("endTime") - nowWorldTime
					if cdinfo:getProperty("effectEndTime") ~= 0 then
						effectTime = cdinfo:getProperty("effectEndTime") - nowWorldTime
					end
				end
				if effectTime > 0 then
					isActive = true
					-- self.m_btnLabel:setString(format_time(effectTime))
					-- self.m_greenButton:setEnabled(false)
				elseif gapTime > 0 then
					isInCD = true
					-- self.m_btnLabel:setString(format_time(gapTime))
					-- self.m_greenButton:setEnabled(false)
				else
					if (self.id == "602700" or self.id == "603100")
						and gapTime == 0
						and cdinfo
						and cdinfo:getProperty("stat") == 1
						then
						-- 130088=已激活
						-- self.m_btnLabel:setString("130088")
						-- self.m_greenButton:setEnabled(false)
						isActive = true
					else
						-- self.m_btnLabel:setString(getLang("105460"))
					end
				end
			end
		elseif tag == "dragon" then
			local data = DragonActiveSkillManager.getInstance():getDataById(id)
			if nil == data then
				return
			end
			name = data:getName()
			-- 【awen】新天赋显示新描述
			if DragonActiveSkillManagerNew.getInstance():isNewSkillType(id) then
				desc = DragonActiveSkillManagerNew.getInstance():getDescInBook(id)
			else
				desc = data:getDescriptionByLevel(data:getLevel())
			end
			if data:getIsUnLocked() == false then
				-- self.m_yellowButton:setVisible(true)
				-- self.m_btnLabel:setString(getLang("118006"))
			else
				-- self.m_greenButton:setVisible(true)
				if data:isActive() then
					isActive = true
					-- local left = data:getActEndTime() - nowTimeStamp
					-- self.m_btnLabel:setString(format_time(left))
					-- self.m_greenButton:setEnabled(false)
				elseif data:isInCD() then
					isInCD = true
					-- local left = data:getCDEndTime() - nowTimeStamp
					-- left = math.max(0, left)
					-- self.m_btnLabel:setString(format_time(left))
					-- self.m_greenButton:setEnabled(false)
				else
					-- self.m_btnLabel:setString(getLang("105460"))
				end
			end
		elseif tag == "hero" then
			local info = HeroManager.getActiveSkillInfoById(id)
			if nil == info then
				return
			end
			name = info:getName()
			desc = info:getDesStr()
			if info:isObtain() == false then
				-- self.m_yellowButton:setVisible(true)
				-- self.m_btnLabel:setString(getLang("118006"))
			else
				-- self.m_greenButton:setVisible(true)
				if info:isActive() then
					isActive = true
					-- self.m_greenButton:setEnabled(false)
					-- local left = info:getActEndtime() - nowTimeStamp
					-- left = math.max(0, left)
					-- self.m_btnLabel:setString(format_time(left))
				elseif info:isInCD() then
					isInCD = true
					-- self.m_greenButton:setEnabled(false)
					-- local left = info:getCDEndTime() - nowTimeStamp
					-- left = math.max(0, left)
					-- self.m_btnLabel:setString(format_time(left))
				else
					-- self.m_btnLabel:setString(getLang("105460"))
				end
			end
		end
		if isActive then
			timeStr = getLang("169629")
			color = cc.c3b(255, 225, 58)
		elseif isInCD then
			timeStr = getLang("146323")
			color = cc.c3b(58, 216, 255)
		end
		local th = 0
		local label1 = cc.Label:create()
		label1:setString(name)
        label1:setSystemFontSize(16)
        label1:setAnchorPoint(cc.p(0.5, 1))
        label1:setColor(cc.c3b(229, 198, 148))
        label1:setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
        label1:setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_TOP)
        label1:setDimensions(330, 0)
        self.m_labelNode:addChild(label1)
        th = th + label1:getContentSize().height

        local label2 = nil
        if "" ~= timeStr then
        	label2 = cc.Label:create()
	        label2:setSystemFontSize(16)
			label2:setString(timeStr)
	        label2:setAnchorPoint(cc.p(0.5, 1))
	        label2:setColor(color)
	        label2:setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
	        label2:setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_TOP)
	        label2:setDimensions(330, 0)
	        self.m_labelNode:addChild(label2)
	        th = th + label2:getContentSize().height
	    end

	    local label3 = cc.Label:create()
		label3:setString(desc)
        label3:setSystemFontSize(16)
        label3:setAnchorPoint(cc.p(0.5, 1))
        label3:setColor(cc.c3b(152, 114, 56))
        label3:setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
        label3:setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_TOP)
        label3:setDimensions(330, 0)
        self.m_labelNode:addChild(label3)
        th = th + label3:getContentSize().height

        label1:setPositionY(th * 0.5)
        if label2 then
        	label2:setPositionY(th * 0.5 - label1:getContentSize().height)
        end
        label3:setPositionY(-th * 0.5 + label3:getContentSize().height)

        th = math.max(th, 150)
        self.m_desBg:setContentSize(cc.size(360, th))
        self.m_desBg:setPreferredSize(cc.size(360, th))
    end

    local posx = 0
    local posy = 0
    local th = self.m_desBg:getContentSize().height
    local wp = cell.m_picNode:convertToWorldSpace(cc.p(0, 0))
    local pos = self.m_listNode:convertToNodeSpace(wp)
    if pos.x > self.m_listNode:getContentSize().width * 0.5 + 20 then
    	posx = 165
	elseif pos.x < self.m_listNode:getContentSize().width * 0.5 - 20 then
		posx = 340
	else 
		posx = self.m_listNode:getContentSize().width * 0.5
	end
	if math.abs(posx - self.m_listNode:getContentSize().width * 0.5) < 10 then
		-- if pos.y < self.m_listNode:getContentSize().height * 0.5 then
		-- 	posy = pos.y + th * 0.5 + 90
		-- else
		-- 	posy = pos.y - th * 0.5 - 120
		-- end
			posy = pos.y + th * 0.5 + 50
	else
		posy = pos.y
	end
	self.m_desNode:setPosition(cc.p(posx, posy))
end

function ActiveSkillView:onNoCellTouch(  )
	-- body
	self.m_desNode:setVisible(false)
end


function ActiveSkillCell:ctor( id, father )
	-- body

	self.id = id
	self.father = father
	self.m_skillItemId = ""
	self.m_iconNode = nil 
	local proxy = cc.CCBProxy:create()
    local ccbiUrl = "ActiveSkillCell"
	local node = CCBReaderLoad(ccbiUrl, proxy, self)
    self:addChild(node)


	local function onNodeEvent( event )
		if event == "enter" then
			self:onEnter()
	    elseif event == "exit" then
	    	self:onExit()
	    end
	end
	self:registerScriptHandler(onNodeEvent)

	self.startTouchPt = cc.p(0, 0)
	self.touchLayer = cc.Layer:create()
	self:addChild(self.touchLayer)
	local function touchHandle( eventType, x, y )
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
			self:onTouchMoved(x, y)
		else
			self:onTouchEnded(x, y)
		end
	end
	self.touchLayer:registerScriptTouchHandler(touchHandle)
	self.touchLayer:setTouchEnabled(true)
	self.touchLayer:setSwallowsTouches(false)

	self:setData(self.id)
end



function ActiveSkillCell:onTouchBegan( x, y )
	-- body
	self.touchBeginPoint = nil
	self.touchBeginPoint = {x = x, y = y}
	if isTouchInside(self.m_bg, x, y) then
		MyPrint("self.id touchbegan ", self.id)
		self.father:onCellTouch(self)
		return true
	end
	return false
end

function ActiveSkillCell:onTouchMoved( x, y )
	-- body
	if self.touchBeginPoint then 
		if CCCommonUtilsForLua:call("isIosAndroidPad") then

			if y - self.touchBeginPoint.y > 240 then 
				self.father:onNoCellTouch()
			elseif self.touchBeginPoint.y - y > 240 then 
				self.father:onNoCellTouch()
			end
		else
			if y - self.touchBeginPoint.y > 100 then 
				self.father:onNoCellTouch()
			elseif self.touchBeginPoint.y - y > 100 then 
				self.father:onNoCellTouch()
			end
		end
	end

		--self.father:onNoCellTouch()
	-- if isTouchInside(self.m_bg, x, y) then
	-- 	self.father:onCellTouch(self)
	-- else
	-- 	self.father:onNoCellTouch()
	-- end
end

function ActiveSkillCell:onTouchEnded( x, y )
	-- body
	self.touchBeginPoint = nil
	self.father:onNoCellTouch()
end

function ActiveSkillCell:setData( id )
	-- body
	-- MyPrint("ActiveSkillCell:setData ", id)
	self.id = id
	self.m_skillItemId = ""
	self.m_lockSprite:setVisible(false)
	CCCommonUtilsForLua:call("setSpriteGray", self.m_picSprite, false)

	if self.m_dragonNode ~= nil then 
		self.m_dragonNode:setVisible(false)
	end

	local tag = getKeyById(id)
	if tag == "general" then
		local cdinfo = GeneralManager:call("getSkillCDInfoById", self.id)
		local generalInfo = GlobalData:call("getSelfGeneralInfo")
		if nil == generalInfo then
			return
		end
		local pic = CCCommonUtilsForLua:call("getPropById", self.id, "icon") .. ".png"
		MyPrint("pic .. ", pic)
	    local sf = CCLoadSprite:call("getSF", pic)
	    if sf == nil then
	        pic = "dragon_skill_1.png"
	    end
	    local frame = CCLoadSprite:call("loadResource", pic)
		self.m_picSprite:setDisplayFrame(frame)

		if generalInfo:call("checkHaveStudy", self.id, generalInfo:getProperty("curMapIdx")) then
		else
			CCCommonUtilsForLua:call("setSpriteGray", self.m_picSprite, true)
			self.m_lockSprite:setVisible(true)
		end
	    CCCommonUtilsForLua:call("setSpriteMaxSize", self.m_picSprite, 110, true)

		-- self.m_nameLabel:setString(getLang(CCCommonUtilsForLua:call("getPropById", self.id, "name")))
		-- local dialog = CCCommonUtilsForLua:call("getPropById", self.id, "description")
		-- local base = CCCommonUtilsForLua:call("getPropById", self.id, "base")
		-- MyPrint("dialog base ", dialog, base)
		-- local t = math.tonumber(CCCommonUtilsForLua:call("getPropById", self.id, "type"))
		-- if t == 12 or t == 13 or t == 15 then
		-- 	self.m_desLabel:setString(getLang(dialog, base))
		-- elseif t == 14 then
		-- 	local ta = string.split(base, "|")
		-- 	if #ta == 2 then
		-- 		self.m_desLabel:setString(getLang(dialog, ta[1], ta[2]))
		-- 	end
		-- else
		-- 	self.m_desLabel:setString(getLang(dialog))
		-- end
		
	elseif tag == "dragon" then
		local skillInfo = DragonActiveSkillManager.getInstance():getDataById(self.id)
		if nil == skillInfo then
			MyPrint("nil !!!! dragonskillInfo")
			return
		end
		dump(skillInfo,"skillInfo")
		local pic = CCCommonUtilsForLua:call("getPropById", self.id, "icon") .. ".png"
		local born_dragon = CCCommonUtilsForLua:call("getPropById", self.id, "born_dragon") 
		local dragon_icon_file = CCCommonUtilsForLua:call("getPropById", born_dragon, "head_icon") .. ".png"
		MyPrint("pic .. ", pic,"dragon_icon_file",dragon_icon_file)
	    local sf = CCLoadSprite:call("getSF", pic)
	    if sf == nil then
	        pic = "dragon_skill_1.png"
	    end
	    local frame = CCLoadSprite:call("loadResource", pic)
	    local dragon_icon = CCLoadSprite:call("createSprite",dragon_icon_file)
	    self.m_picSprite:setDisplayFrame(frame)
	    if skillInfo:getIsUnLocked() == false then
	    	CCCommonUtilsForLua:call("setSpriteGray", self.m_picSprite, true)
	    else
	    	CCCommonUtilsForLua:call("setSpriteGray", self.m_picSprite, false)
	    end
	    CCCommonUtilsForLua:call("setSpriteMaxSize", self.m_picSprite, 100, true)
	    if self.m_dragonHeadNode ~= nil and dragon_icon ~= nil then 
	    	local spriteFrame = dragon_icon:getSpriteFrame()
	    	local clip_node = IFRoundSprite:call("createWithSpriteFrame", spriteFrame, 35)
	    	self.m_dragonHeadNode:addChild(clip_node)
	    	self.m_dragonNode:setVisible(true)
	    	self.m_dragonHeadNode:setVisible(true)
	    	clip_node:setScale(0.3)
	    end
	    -- self.m_nameLabel:setString(skillInfo:getName())
	    -- self.m_desLabel:setString(skillInfo:getDescriptionByLevel(skillInfo:getLevel()))
	elseif tag == "hero" then
		local info = HeroManager.getActiveSkillInfoById(self.id)
		if nil == info then
			MyPrint("nil !!!! heroskillInfo")
			return
		end
		local pic = info:getIconStr()
		local sf = CCLoadSprite:call("getSF", pic)
		if nil == sf then
			pic = "dragon_skill_1.png"
		end
		local frame = CCLoadSprite:call("loadResource", pic)
		self.m_picSprite:setDisplayFrame(frame)
		if info:isObtain() == false then
			CCCommonUtilsForLua:call("setSpriteGray", self.m_picSprite, true)
		else
			CCCommonUtilsForLua:call("setSpriteGray", self.m_picSprite, false)
		end
		CCCommonUtilsForLua:call("setSpriteMaxSize", self.m_picSprite, 95, true)
	end

	self:onEnterFrame()
end

function ActiveSkillCell:onEnter(  )
	-- body
	self:onEnterFrame()
	self.entry = tonumber(self:getScheduler():scheduleScriptFunc(function (  )
        self:onEnterFrame()
        -- self:setData(self.data)
    end, 1.0, false))

    local function onGetMsgUseSkillCmdSuccess( ref )
		self:successCallBack(ref)
	end
	local handler1 = self:registerHandler(onGetMsgUseSkillCmdSuccess)
	CCSafeNotificationCenter:call("registerScriptObserver", self, handler1, "msg_useskillcmd_success")

	local function onGetMsgUseSkillCmdFail( ref )
		self:failCallBack(ref)
	end
	local handler1 = self:registerHandler(onGetMsgUseSkillCmdFail)
	CCSafeNotificationCenter:call("registerScriptObserver",self, handler1, "msg_useskillcmd_fail")


	local function onGetCancelCmdBack( ref )
		self:onRetCancelSkill(ref)
	end
	local handler1 = self:registerHandler(onGetCancelCmdBack)
	CCSafeNotificationCenter:call("registerScriptObserver",self, handler1, "msg_cancelskillcmd_back")

	local function onGetDragonSkillUseCmdBack( ref )
		self:onGetDragonSkillUseCmdBack(ref)
	end
	local handler1 = self:registerHandler(onGetDragonSkillUseCmdBack)
	CCSafeNotificationCenter:call("registerScriptObserver",self, handler1, "msg_dragonactiveskill_use_back")

end

function ActiveSkillCell:onExit(  )
	-- body
	self:getScheduler():unscheduleScriptEntry(self.entry)
	CCSafeNotificationCenter:call("unregisterScriptObserver", self, "msg_useskillcmd_success")
	CCSafeNotificationCenter:call("unregisterScriptObserver", self, "msg_useskillcmd_fail")
	CCSafeNotificationCenter:call("unregisterScriptObserver", self, "msg_cancelskillcmd_back")
	CCSafeNotificationCenter:call("unregisterScriptObserver", self, "msg_dragonactiveskill_use_back")

end

function ActiveSkillCell:failCallBack( ref )
	if nil == ref then
		return
	end
	local id = ref:valueForKey("cacheSkillId"):getCString()
	if id ~= self.id then
		return
	end
	self:setData(self.id)
end

function ActiveSkillCell:successCallBack( ref )
	MyPrint("ActiveSkillCell:successCallBack ", ref)
	if nil == ref then
		return
	end

	local id = ref:valueForKey("cacheSkillId"):getCString()
	MyPrint("id ", id)
	if id ~= self.id then
		return
	end
	MyPrint("self.id ", self.id)
	local skillType = math.tonumber(CCCommonUtilsForLua:call("getPropById", self.id, "type"))
	local tip = ""
	MyPrint("skillType ", skillType)
	if skillType == 10 then
		PopupViewController:call("removeAllPopupView")
		SceneController:call("gotoScene", 11)
		return
	elseif skillType == 11 then
		-- 118002=获得了救援效果，当你的部队下一次在城堡外发生战斗时优先产生伤兵。
		CCCommonUtilsForLua:call("flyText", getLang("118002"))
	elseif skillType == 21 then
		-- 150812=技能已激活，下次攻击敌方城堡的队伍将会与对方决斗。被攻击方援助无效，双方损失的兵将直接死亡。
		CCCommonUtilsForLua:call("flyText", getLang("150812"))
	elseif skillType == 12 then
		local para1 = CCCommonUtilsForLua:call("getPropById", self.id, "para1")
		local param1 = math.tonumber(para1)
		local outPutSec = param1 * 60 * 60
		local harvestInfo = ""
		harvestInfo = tostring(outPutSec)
		harvestInfo = harvestInfo .. "|"
		harvestInfo = harvestInfo .. "2350"
		harvestInfo = harvestInfo .. "|"
		harvestInfo = harvestInfo .. "70"
		GlobalData:call("shared"):setProperty("m_harvestInfo", harvestInfo)

		local currentSceneId = SceneController:call("getCurrentSceneId")
		if currentSceneId ~= SCENE_ID_MAIN then
			local world = WorldMapView:call("instance")
			if world then
				world:call("leaveWorld")
			else 
				SceneController:call("gotoScene", SCENE_ID_MAIN)
			end
		else
			CCSafeNotificationCenter:call("postNotification", "msg_change_scence_and_show_harvest")
		end

		tip = getLang("118001")
	elseif skillType == 13 then
	elseif skillType == 14 then
		CCCommonUtilsForLua:call("flyText", getLang("118003"))
	elseif skillType == 15 then
		local fortInfo = ""
		if ref:objectForKey("trap") then
			local trap = ref:objectForKey("trap")
			if trap and trap:objectForKey("id") and trap:objectForKey("free") then
				local str = trap:valueForKey("free"):getCString()
				if str ~= "" then
					fortInfo = trap:valueForKey("id"):getCString() .. "|" .. trap:valueForKey("free"):getCString()
				end
			end
		end
		GlobalData:call("shared"):setProperty("m_skillFortInfo", fortInfo)
		local currentSceneId = SceneController:call("getCurrentSceneId")
		if currentSceneId ~= SCENE_ID_MAIN then
			local world = WorldMapView:call("instance")
			if world then
				world:call("leaveWorld")
			else
				SceneController:call("gotoScene", SCENE_ID_MAIN)
			end
		else
			CCSafeNotificationCenter:call("postNotification", "msg_show_fort_skill_effect")
		end

		if ref:objectForKey("trap") then
			local trap = ref:objectForKey("trap")
			if trap and trap:objectForKey("id") and trap:objectForKey("free") then
				local str = trap:valueForKey("free"):getCString()
				if str ~= "" then
					local getCount = trap:valueForKey("free"):intValue()
					local addPower = 0
					local fortInfo = GlobalData:call("getArmyInfoById", trap:valueForKey("id"):getCString())
					if fortInfo then
						addPower = getCount * fortInfo:getProperty("power")
						addPower = math.max(addPower, 0)
						GlobalData:call("getPlayerInfo"):setProperty("fortPower", GlobalData:call("getPlayerInfo"):getProperty("fortPower") + addPower)
					end
					GlobalData:call("getPlayerInfo"):setProperty("addPower", addPower)
					CCSafeNotificationCenter:call("postNotification", "msg_collect_soldier_add_power")
				end
			end
		end
	elseif skillType == 18 or skillType == 19 then
		ToolController:call("retUseTool", ref)
	elseif skillType == 20 then
		if ref:objectForKey("itemEffectObj") then
			local effectObj = ref:objectForKey("itemEffectObj")
			if effectObj and effectObj:objectForKey("stamina") then
				CCSafeNotificationCenter:call("postNotification", "msg_stamine_add_eff")
				WorldController:call("getInstance"):setProperty("currentStamine", effectObj:valueForKey("stamina"):intValue())
				WorldController:call("getInstance"):setProperty("lastStamineTime", effectObj:valueForKey("lastStaminaTime"):doubleValue())
				CCSafeNotificationCenter:call("postNotification", "msg_currentStamine")
			end
		end
	elseif skillType == 23 then
		if ref and ref:objectForKey("reward") then
			local arr = ref:objectForKey("reward")
			if nil ~= arr then
				PortActController:call("flyReward", arr, true)
				local rwdInfo = RewardController:call("retReward", arr)
				CCCommonUtilsForLua:call("flyHint", "", "", rwdInfo)
			end
		end
		if ref:objectForKey("stamina") then
			CCSafeNotificationCenter:call("postNotification", "msg_stamine_add_eff")
			local dicTemp = ref:objectForKey("stamina")
			WorldController:call("getInstance"):setProperty("currentStamine", dicTemp:valueForKey("stamina"):intValue())
			WorldController:call("getInstance"):setProperty("lastStamineTime", dicTemp:valueForKey("lastStaminaTime"):doubleValue())
			CCSafeNotificationCenter:call("postNotification", "msg_currentStamine")
		end
	elseif skillType == 27 then --更新其他技能CD时间
		--领主技能CD更新 
		if ref:objectForKey("userSkArr") then
			local list = ref:objectForKey("userSkArr")
			GeneralManager:call("updateSkillData",list)		
		end

		--英雄技能CD更新	
		if ref:objectForKey("newGenSkArr") then
			local list = ref:objectForKey("newGenSkArr")
			local data = arrayToLuaTable(list)
			local refreshTbl = {}
			for _,v in pairs(data or {}) do
				local heroId = v.ownerId
				if nil == refreshTbl[heroId] then
					refreshTbl[heroId] = {}
				end				
				local skillInfo = {skillId = v.skillId, endTime = v.endTime, state = v.state, actTime = v.actTime}
				table.insert( refreshTbl[heroId], skillInfo )				
			end
			for k,v in pairs(refreshTbl) do
				HeroManager.refreshSkillInfo(k, {skillInfo=v})
			end
		end
	elseif skillType == 28 then --年兽次数增加
		if ref:objectForKey("remainAttackTime") then
			local time = ref:valueForKey("remainAttackTime"):intValue()
			local lordInfo = GlobalData:call("shared"):getProperty("lordInfo")
			if lordInfo then
				lordInfo:setProperty("remainAttackTime",time)
			end
		end	
	else
	end

	if tip ~= "" then
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("118001"))
	end
	if skillType ~= 11 and skillType ~= 14 and skillType ~= 21 and skillType ~= 27 then
		PopupViewController:call("removeAllPopupView")
	else
		self:setData(self.id)
	end

end

function ActiveSkillCell:onEnterFrame(  )
	-- body
	local nowWorldTime = GlobalData:call("getWorldTime")
	local nowTimeStamp = GlobalData:call("getTimeStamp")
	local tag = getKeyById(self.id)
	self.m_greenButton:setEnabled(true)
	self.m_yellowButton:setEnabled(true)
	self.m_greenButton:setVisible(false)
	self.m_yellowButton:setVisible(false)
	self.m_btnLabel:setColor(cc.c3b(255, 255, 255))
	if tag == "general" then
		local generalInfo = GlobalData:call("getSelfGeneralInfo")
		local cdinfo = GeneralManager:call("getSkillCDInfoById", self.id)
		if nil == generalInfo then
			return
		end

		local gapTime = 0
		local effectTime = 0
		
		if generalInfo:call("checkHaveStudy", self.id, generalInfo:getProperty("curMapIdx")) then
			self.m_greenButton:setVisible(true)
			if cdinfo and cdinfo:getProperty("endTime") ~= 0 then
				MyPrint("cdinfo endTime", cdinfo, cdinfo:getProperty("endTime"))
				gapTime = cdinfo:getProperty("endTime") - nowWorldTime
				if cdinfo:getProperty("effectEndTime") ~= 0 then
					effectTime = cdinfo:getProperty("effectEndTime") - nowWorldTime
				end
				if self.id == "602700" and gapTime < 0 then
					cdinfo:setProperty("stat", 0)
				end
			end

			if effectTime > 0 then
				self.m_btnLabel:setColor(cc.c3b(255, 225, 58))
				self.m_btnLabel:setString(format_time(effectTime))
				self.m_greenButton:setEnabled(false)
			elseif gapTime > 0 then
				self.m_btnLabel:setColor(cc.c3b(58, 216, 255))
				self.m_btnLabel:setString(format_time(gapTime))
				self.m_greenButton:setEnabled(false)
			else
				if (self.id == "602700" or self.id == "603100")
					and gapTime == 0
					and cdinfo
					and cdinfo:getProperty("stat") == 1
					then
					-- 111906=取消
					self.m_greenButton:setEnabled(true)
					self.m_btnLabel:setString(getLang("111906"))
				else
					self.m_btnLabel:setString(getLang("105460"))
				end
			end
			if self.id == "603100" or self.id == "602700" then
				if cdinfo and cdinfo:getProperty("stat") == 1 then
					self.m_btnLabel:setString(getLang("108532"))
				end
			end
		else
			self.m_yellowButton:setVisible(true)
			-- 118006=去看看
			self.m_btnLabel:setString(getLang("118006"))
		end
	elseif tag == "dragon" then
		local data = DragonActiveSkillManager.getInstance():getDataById(self.id)
		if nil == data then
			return
		end
		if data:getIsUnLocked() == false then
			self.m_yellowButton:setVisible(true)
			self.m_btnLabel:setString(getLang("118006"))
		else
			self.m_greenButton:setVisible(true)
			if data:isActive() then
				local left = data:getActEndTime() - nowTimeStamp
				self.m_btnLabel:setColor(cc.c3b(255, 225, 58))
				self.m_btnLabel:setString(format_time(left))
				self.m_greenButton:setEnabled(false)
			elseif data:isInCD() then
				local left = data:getCDEndTime() - nowTimeStamp
				left = math.max(0, left)
				self.m_btnLabel:setColor(cc.c3b(58, 216, 255))
				self.m_btnLabel:setString(format_time(left))
				self.m_greenButton:setEnabled(false)
			else
				self.m_btnLabel:setString(getLang("105460"))
			end
		end
	elseif tag == "hero" then
		local info = HeroManager.getActiveSkillInfoById(self.id)
		if nil == info then
			return
		end
		if info:isObtain() == false then
			self.m_yellowButton:setVisible(true)
			self.m_btnLabel:setString(getLang("118006"))
		else
			self.m_greenButton:setVisible(true)
			if info:isActive() then
				self.m_greenButton:setEnabled(false)
				local left = info:getActEndtime() - nowTimeStamp
				MyPrint("endTime >>> ", info:getActEndtime())
				left = math.max(0, left)
				self.m_btnLabel:setColor(cc.c3b(255, 225, 58))
				self.m_btnLabel:setString(format_time(left))
			elseif info:isInCD() then
				self.m_greenButton:setEnabled(false)
				local left = info:getCDEndTime() - nowTimeStamp
				MyPrint("cdendTime >>> ", info:getCDEndTime())
				left = math.max(0, left)
				self.m_btnLabel:setColor(cc.c3b(58, 216, 255))
				self.m_btnLabel:setString(format_time(left))
			else
				self.m_btnLabel:setString(getLang("105460"))
			end
		end
	end

end

function ActiveSkillCell:checkSkillActivating( skillId )
	local generalInfo = GlobalData:call("getSelfGeneralInfo")
	if nil == generalInfo then
		return false
	end
	local skillActivating = false
	if generalInfo:call("checkHaveStudy", skillId, generalInfo:getProperty("curMapIdx")) then
		local cdinfo = GeneralManager:call("getSkillCDInfoById", skillId)
		if cdinfo and cdinfo:getProperty("endTime") < 1 and cdinfo:getProperty("effectEndTime") < 1 and cdinfo:getProperty("stat") == 1 then
			skillActivating = true
		end
	end
	return skillActivating
end

function ActiveSkillCell:generalUseClick(  )
	-- body
	local tag = getKeyById(self.id)
	if tag ~= "general" then
		return
	end

	local generalInfo = GlobalData:call("getSelfGeneralInfo")
	if nil == generalInfo then
		return
	end
	local cdinfo = GeneralManager:call("getSkillCDInfoById", self.id)

	local maxStan = GlobalData:call("shared"):getProperty("MaxStamina")

	if self.id == "622300" 
		and (WorldController:call("getInstance"):getProperty("currentStamine") + 30) > maxStan
		then
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("168034"))
		return
	end

	if self:skillCanUse() == false then
		return
	end

	if self.id == "603100" then
		if self:checkSkillActivating("603100") then
			YesNoDialog:call("show", getLang("168036"), cc.CallFunc:create(function (  )
				self:sendCancelSkill()
			end))
			return
		end
		if self:checkSkillActivating("602700") then
			YesNoDialog:call("show", getLang("150760"))
			return
		end
	elseif self.id == "602700" then
		if self:checkSkillActivating("603100") then
			YesNoDialog:call("show", getLang("150760"))
			return
		end
	elseif self.id == "622700" then
		if WorldController:call("getInstance"):getProperty("currentStamine") < 5 then
			YesNoDialog:call("show", getLang("150812"))
			return
		end
	elseif self.id == "622900" then -- 激活龙友好度回满技能
		if CCCommonUtilsForLua:call("isFunOpenByKey", "dragon_science_skill") == false then
			YesNoDialog:call("show", getLang("164662"))
			return
		else
			local info = DragonController:call("getActiveDragonInfo")
			if nil == info then
				YesNoDialog:call("show", getLang("164641"))
				return
			end
			if info:call("getInMarch") then
				YesNoDialog:call("show", getLang("164642"))
				return
			end
			if info:call("getIntimacy") > info:call("getIntimacyTopLimit") then
				YesNoDialog:call("show", getLang("164643"))
				return
			end
			local des = getLang("164640", getLang(info:call("getName")), info:call("getNickName"), tostring(info:call("getIntimacy")))
			
			YesNoDialog:call("showYesNoFun", des, cc.CallFunc:create(function (  )
				self:sendUseSkillCommand()
			end), getLang("confirm"), nil, getLang("cancel_btn_label"))
			return
		end
	elseif self.id == "613700" then --CD技能球		
		--para3是英雄
		--para2领主
		local genCDSkills = string.split(CCCommonUtilsForLua:call("getPropByIdGroup","sk",self.id,"para2"),";")
		local canUse = false
		local nowWorldTime = GlobalData:call("getWorldTime")
		--检查领主技能中是否有在CD中的
		for k,v in pairs(genCDSkills or {}) do
			local _info = GeneralManager:call("getSkillCDInfoById", v)
			if _info and _info:getProperty("endTime") ~= 0 then
				if _info:getProperty("endTime") - nowWorldTime > 0 then
					canUse = true
					break
				end
			end
		end
		--如果没有再检查英雄技能中是否有在CD中的
		if not canUse then
			local heroCDSkills = string.split(CCCommonUtilsForLua:call("getPropByIdGroup","sk",self.id,"para3"),";")
			for k,v in pairs(heroCDSkills or {}) do
				local info = HeroManager.getActiveSkillInfoById(v)
				if info and info:isInCD() then
					canUse = true
					break
				end
			end
		end
		if not canUse then
			YesNoDialog:call("show", getLang("9711179"))--9711179=当前无已进入CD的技能
			return
		end	
	end
	-- 判断城市增益中有没有同组增益正在使用
	local actNumber = math.tonumber(CCCommonUtilsForLua:call("getPropById", self.id, "para1"))
	local group = math.tonumber(CCCommonUtilsForLua:call("getPropById", tostring(actNumber), "group"))
	local findSid = GlobalData:call("getActiveStatusByGroup", actNumber)
	local curStatusGid = 0
	if findSid > 0 then
		local findGroup = CCCommonUtilsForLua:call("getPropById", tostring(findSid), "group")
		curStatusGid = math.tonumber(findGroup)
	end
	if curStatusGid > 0 then
		if group >= curStatusGid then
			-- 可以覆盖//领主大人，此状态不可叠加，若使用该技能，之前的状态将被覆盖！
			YesNoDialog:call("show", getLang("101454"), cc.CallFunc:create(function (  )
				self:sendUseSkillCommand()
			end))
		else
			YesNoDialog:call("showYesDialog", getLang("101433"))
		end
	else
		self:sendUseSkillCommand()
	end
end

function ActiveSkillCell:onGreenButtonClick(  )
	-- body
	local tag = getKeyById(self.id)
	if tag == "general" then
		local generalInfo = GlobalData:call("getSelfGeneralInfo")
		if nil == generalInfo then
			return
		end
		local cdinfo = GeneralManager:call("getSkillCDInfoById", self.id)
		local specialUse = false
		if self.id == "603100" or self.id == "602700" then
			if cdinfo and cdinfo:getProperty("stat") == 1 then
				-- 取消
				self:sendCancelSkill()
				return
			else
				specialUse = true
			end
		elseif self.id == "612400" or self.id == "622700" then
			specialUse = true
		end

		if specialUse then
			MyPrint("ActiveSkillCell specialUse ", self.id)
			local view = UseSkillViewItemView.create( self.id, self )
			PopupViewController:call("addPopupView", view)
			return
		end

		self:generalUseClick()
	elseif tag == "dragon" then
		DragonActiveSkillManager.getInstance():startUseSkill(self.id)
		self.m_greenButton:setEnabled(false)
	elseif tag == "hero" then
		local info = HeroManager.getActiveSkillInfoById(self.id)
		if nil == info then
			return
		end
		local heroInfo = info:getHeroInfo()
		if nil == heroInfo then
			return
		end
		if heroInfo.state == HeroState.Captured or heroInfo.state == HeroState.Dead then
			CCCommonUtilsForLua:call("flyHint", "", "", getLang("169734"))
			return
		end
		HeroManager.useSkill(tonumber(info:getHeroId()), self.id)
		self.m_greenButton:setEnabled(false)
	end
end

function ActiveSkillCell:onYellowButtonClick(  )
	-- body
	local tag = getKeyById(self.id)
	if tag == "general" then
		local generalInfo = GlobalData:call("getSelfGeneralInfo")
		if nil == generalInfo then
			return
		end
		 
		local from = CCCommonUtilsForLua:call("getPropById", self.id, "source")
		if from == "1" or from == "" then
			local isLua = CCCommonUtilsForLua:isFunOpenByKey("general_skill_new") -- 改为新的开关控制，启用lua代码 -- CCCommonUtilsForLua:call("isTestPlatformAndServer", "general_skill_list_view")
			if isLua then
				local t = {}
				t.abilityId = generalInfo:call("getAbilityBySkillId", self.id, generalInfo:getProperty("curMapIdx"))
				t.skillId = self.id
				PopupViewController:call("removeAllPopupView")
				onFireEvent("open_GeneralSkillListPopUpView", t)
			else
				-- openPopViewInLua
				local dic = CCDictionary:create()
				dic:setObject(CCString:create("GeneralSkillListPopUpView"), "name")
				dic:setObject(CCString:create(generalInfo:call("getAbilityBySkillId", self.id, generalInfo:getProperty("curMapIdx"))), "abilityId")
				dic:setObject(CCString:create(self.id), "skillId")
				PopupViewController:call("removeAllPopupView")
				LuaController:call("openPopViewInLua", dic)
			end
		elseif from == "2" then
			PopupViewController:call("removeAllPopupView")
			local dict = CCDictionary:create() 
	  	    dict:setObject(CCString:create("ScienceListView"), "name")
	   	    LuaController:call("openPopViewInLua", dict)
		end
	elseif tag == "dragon" then
		local skillInfo = DragonActiveSkillManager.getInstance():getDataById(self.id)
		if nil == skillInfo then
			return
		end
		local dragonInfo = skillInfo:getDragonInfo()
		if nil == dragonInfo then
			return
		end
		PopupViewController:call("removeAllPopupView")
		if CCCommonUtilsForLua:isFunOpenByKey("dragon_new_ui_switch") then
			local view = Drequire("game.NewDragon.NewDragon_V2.DragonListNewView"):create()			
			PopupViewController:call("addPopupInView", view)
			if nil ~= view then					
				local dragonView = view:openDragonViewByUuid(dragonInfo:call("getUuid"),dragonInfo:call("getBaseId"))
				if nil ~= dragonView then
					dragonView:OnClicktalent()
				end
			end
		else
			local view = myRequire("game.NewDragon.DragonCave_New"):create({uuid = dragonInfo:call("getUuid")})
			if nil ~= view then
				PopupViewController:call("addPopupInView", view)
				view:OnClicktalent()
			end
		end				
		return
	elseif tag == "hero" then
		local info = HeroManager.getActiveSkillInfoById(self.id)
		if nil == info then
			return
		end
		local heroInfo = info:getHeroInfo()
		if nil == heroInfo then
			return
		end
		local luaPath = "game.hero.NewUI_v2.HeroTalentView"
	    local herotalent = Drequire(luaPath):create(info:getHeroId(), self.id)
	    PopupViewController:call("removeAllPopupView")
	    PopupViewController:call("addPopupInView", herotalent)	
	end
end

function ActiveSkillCell:sendUseSkillCommand(  )
	local generalInfo = GlobalData:call("getSelfGeneralInfo")
	if nil == generalInfo then
		return
	end

	local skillId = self.id
	local t = math.tonumber(CCCommonUtilsForLua:call("getPropById", self.id, "type"))
	local cdinfo = GeneralManager:call("getSkillCDInfoById", skillId)
	if t == 11 and cdinfo and cdinfo:getProperty("stat") ~= 0 then
		YesNoDialog:call("showYesDialog", getLang("105465"))
		return
	end

	local cmd = UseSkillCommand.new(self.id)
	if self.m_skillItemId and self.m_skillItemId ~= 0 and self.m_skillItemId ~= "" then
		local tinfo = ToolController:call("getToolInfoForLua", tonumber(self.m_skillItemId))
		if tinfo and tinfo:call("getCNT") > 0 then
			cmd:putParam("useItem", CCString:create(tinfo:getProperty("uuid")))
		end
	end
	cmd:send()
	self.m_greenButton:setEnabled(false)
end

function ActiveSkillCell:addResourceFunction( useItem )
	-- body
	MyPrint("ActiveSkillCell:addResourceFunction", useItem)
	if self:skillCanUse() == false then
		return
	end

	local resourceType = 4
	if not useItem then
		local randomNum = math.random(0, 9999)
		resourceType = randomNum % 4
	end
	PopupViewController:call("forceClearAll", true)
	WorldController:call("getInstance"):setProperty("openAddResourceType", resourceType)
	local index = WorldController:call("getIndexByPoint", WorldController:call("getInstance"):getProperty("selfPoint"))
	-- if SceneController:call("getInstance"):getProperty("currentSceneId") == SCENE_ID_WORLD then
	if SceneController:call("getCurrentSceneId") == SCENE_ID_WORLD then
		WorldMapView:call("instance"):call("gotoTilePoint", WorldController:call("getInstance"):getProperty("selfPoint"))
	else
		SceneController:call("gotoScene", SCENE_ID_WORLD, false, true, index)
	end
end

function ActiveSkillCell:skillCanUse(  )
	if self.skillId ~= "603100" and self.skillId ~= "612400" and self.skillId ~= "622700" then
		return true
	end

	local tipsMessage = self:checkSkillOpen()
	if tipsMessage ~= "" then
		YesNoDialog:call("show", tipsMessage)
		return false
	end

-- 	    //判断是否处于跨服状态
-- //    SERVER_BATTLE_FIELD,//远古战场服务器
-- //    SERVER_DRAGON_BATTLE //巨龙战役服务器
	if GlobalData:call("getPlayerInfo"):getProperty("crossFightSrcServerId") > 0
		and GlobalData:call("getPlayerInfo"):getProperty("crossFightSrcServerId") ~= GlobalData:call("getPlayerInfo"):getProperty("selfServerId")
		then
		if self.id == "603100" 
			and GlobalData:call("shared"):getProperty("serverType") ~= ServerType.SERVER_BATTLE_FIELD
			and GlobalData:call("shared"):getProperty("serverType") ~= ServerType.SERVER_DRAGON_BATTLE
			then
			-- //如果是决斗技能，非远古和巨龙服务器，可以使用决斗
			return true
		end
		YesNoDialog:call("show", getLang("150811"))
		return false
	end

	return true
end

function ActiveSkillCell:checkSkillOpen(  )
	local tipsMessage = ""
	local skillSwitchKey = ""
	local externSwitchKey = ""
	if self.id == "603100" then
		skillSwitchKey = "45skill_combat"
		--决斗技能: 跨服王座战场有额外开关
		local crossThroneManager = require("game.crossThrone.CrossThroneManager")
		if crossThroneManager:isDespotServer() then
			externSwitchKey = "overlord_duel_off"
		elseif crossThroneManager:isEmpireServer() then
			externSwitchKey = "monarch_duel_off"
		end
	elseif self.id == "612400" then
		skillSwitchKey = "45skill_development"
	elseif self.id == "622700" then
		skillSwitchKey = "45skill_support"
	end
	if skillSwitchKey ~= "" then
		if CCCommonUtilsForLua:call("isFunOpenByKey", skillSwitchKey) == false then
			tipsMessage = getLang("150794")
		end
	end
	if externSwitchKey ~= "" then
		--开关打开不让用
		if CCCommonUtilsForLua:call("isFunOpenByKey", externSwitchKey) == true then
			tipsMessage = getLang("150811")
		end
	end
	return tipsMessage
end

function ActiveSkillCell:sendCancelSkill(  )
	local generalInfo = GlobalData:call("getSelfGeneralInfo")
	if nil == generalInfo then
		return
	end
	if self.id ~= "603100" and self.id ~= "602700" then
		return
	end

	local cmd = CancelSkillCommand.new(self.id)
	cmd:send()
	self.m_greenButton:setEnabled(false)
end
function ActiveSkillCell:onRetCancelSkill( ref )
	if nil == ref then
		return
	end
	local skillId = ref:getCString()
	if skillId ~= self.id then
		return
	end
	self:setData(self.id)
end
function ActiveSkillCell:onGetDragonSkillUseCmdBack( ref )
	-- body
	MyPrint("UseSkillPopUpCell:onGetDragonSkillUseCmdBack")
	if nil == ref then
		return
	end
	local skillId = ref:getCString()
	MyPrint("skillId self.id", skillId, self.id)
	if skillId ~= self.id then
		return
	end
	self:setData(self.id)
end








return ActiveSkillView