----------------------------
-- Author: Elex
-- Date: 2019-06-25 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local ChangeServerApplyView_ui = class("ChangeServerApplyView_ui")

--#ui propertys


--#function
function ChangeServerApplyView_ui:create(owner, viewType, paramTable)
	local ret = ChangeServerApplyView_ui.new()
	CustomUtility:LoadUi("ChangeServerApplyView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function ChangeServerApplyView_ui:initLang()
end

function ChangeServerApplyView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function ChangeServerApplyView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function ChangeServerApplyView_ui:onClickBtnAlli(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnAlli", pSender, event)
end

function ChangeServerApplyView_ui:onClickBtnRc(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnRc", pSender, event)
end

function ChangeServerApplyView_ui:onClickBtnAlly(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnAlly", pSender, event)
end

function ChangeServerApplyView_ui:onClickBtnTip(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnTip", pSender, event)
end

return ChangeServerApplyView_ui

