--积分途径解释界面
local RankActDetailView = class("RankActDetailView", function()
    return PopupBaseView:create()
end)
RankActDetailView.__index = RankActDetailView

function RankActDetailView.create(actId, title, filter)
	local view = RankActDetailView.new(actId)
	Drequire("game.CommonPopup.RankActComponent.RankActDetailView_ui"):create(view, 0)

	if view:initView(actId, title, filter) == false then
		return nil
	end
  	return view
end

function RankActDetailView:initView(actId, title, filter)
    Dprint("RankActDetailView:initView")
    if title then
        self.ui.m_labelTitle:setString(title)
    end
    
    if actId then self.m_actId = actId end
    
	local function touchHandle( eventType, x, y )
        if eventType == "began" then
            return self:onTouchBegan(x, y)
        elseif eventType == "moved" then
        else
            self:onTouchEnded(x, y)
        end
    end
    self:registerScriptTouchHandler(touchHandle)
    local touchNode = tolua.cast(self, "cc.CCIFTouchNode")
    touchNode:call("setTouchEnabled", true)
    touchNode:call("setSwallowsTouches" , true)

    -- 数据
    local _xmlData = CCCommonUtilsForLua:getGroupByKey("time_event_info")
    if _xmlData == nil then
        return false
    end
    local _data = {}
    for k,v in pairs(_xmlData) do
        if v.pos == self.m_actId then
            v.activityId = self.m_actId
            if not filter or filter(v) then
                table.insert(_data, v)
            end
        end
    end
    table.sort( _data, function(a, b)
        if a and b then
            local _aid = tonumber(a.id) or 0
            local _bid = tonumber(b.id) or 0
            return _aid < _bid
        end
        return false
    end)
    dump(_data, "RankActDetailView:initView")
	self.ui:setTableViewDataSource("m_tableView", _data)

	return true
end

-- 点击关闭
function RankActDetailView:onClickBtnClose(  )
	PopupViewController:call("removePopupView", self)
end

function RankActDetailView:onTouchBegan(x, y)
	self.touchBeganX = x
	self.touchBeganY = y
	return true
end

function RankActDetailView:onTouchEnded(x, y)
    if (not isTouchInside(self.ui.m_bg, self.touchBeganX, self.touchBeganY)) then
        self:onClickBtnClose()
	end
end

return RankActDetailView