----------------------------
-- Author: Elex
-- Date: 2019-03-27 Wednesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local RankActPlayerRankListCell_ui = class("RankActPlayerRankListCell_ui")

--#ui propertys


--#function
function RankActPlayerRankListCell_ui:create(owner, viewType, paramTable)
	local ret = RankActPlayerRankListCell_ui.new()
	CustomUtility:DoRes(0, true)
	CustomUtility:DoRes(11, true)
	CustomUtility:DoRes(7, true)
	CustomUtility:LoadUi("RankActPlayerRankListCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function RankActPlayerRankListCell_ui:initLang()
	LabelSmoker:setText(self.m_pLabelTTF17, "221128")
	LabelSmoker:setText(self.m_tipsLabel, "221125")
end

function RankActPlayerRankListCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function RankActPlayerRankListCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function RankActPlayerRankListCell_ui:onSearchButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onSearchButtonClick", pSender, event)
end

function RankActPlayerRankListCell_ui:onClickPicBtn1(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickPicBtn1", pSender, event)
end

function RankActPlayerRankListCell_ui:onRewardButton1Click(pSender, event)
	ButtonSmoker:forwardFunction(self, "onRewardButton1Click", pSender, event)
end

function RankActPlayerRankListCell_ui:onClickPicBtn2(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickPicBtn2", pSender, event)
end

function RankActPlayerRankListCell_ui:onRewardButton2Click(pSender, event)
	ButtonSmoker:forwardFunction(self, "onRewardButton2Click", pSender, event)
end

function RankActPlayerRankListCell_ui:onClickPicBtn3(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickPicBtn3", pSender, event)
end

function RankActPlayerRankListCell_ui:onRewardButton3Click(pSender, event)
	ButtonSmoker:forwardFunction(self, "onRewardButton3Click", pSender, event)
end

function RankActPlayerRankListCell_ui:initTableView()
	TableViewSmoker:createView(self, "m_listTableView", "game.CommonPopup.RankActComponent.RankActPlayerRankTblCell", 1, 10, "RankActPlayerRankTblCell")
end

function RankActPlayerRankListCell_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return RankActPlayerRankListCell_ui

