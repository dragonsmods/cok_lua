--[[
    2019-11-13
    出征界面 C++转Lua
]]

local PVE_TEAM_CACHE = "pve.team.cache"

local SoldierChallengeType = {
    SOILDERCHALLENGETYPE_DEFAULT             = 0,
    SOILDERCHALLENGETYPE_LOAD                = 1, -- 负重优先
    SOILDERCHALLENGETYPE_LEVEL               = 2, -- 等级优先
    SOILDERCHALLENGETYPE_SPEED               = 3, -- 速度优先
    SOILDERCHALLENGETYPE_Prop                = 4, -- 搭配优先
    SOILDERCHALLENGETYPE_RECOMMEND_INITIATOR = 5, -- 发起集结者推荐
    SOILDERCHALLENGETYPE_RECOMMEND_SYSTEM    = 6, -- 系统推荐
    SOILDERCHALLENGETYPE_MONSTER             = 7, -- 怪物优先
}

local SoldierChallengeImage = {
    ["CanNotFind"]                                                  = {name = "item007.png",            scale = 0.5},
    [SoldierChallengeType.SOILDERCHALLENGETYPE_LOAD]                = {name = "item507.png",            scale = 0.5},
    [SoldierChallengeType.SOILDERCHALLENGETYPE_LEVEL]               = {name = "icon_combat.png",        scale = 1},
    [SoldierChallengeType.SOILDERCHALLENGETYPE_SPEED]               = {name = "tile_pop_icon15.png",    scale = 0.5},
    [SoldierChallengeType.SOILDERCHALLENGETYPE_Prop]                = {name = "item007.png",            scale = 0.5},
    [SoldierChallengeType.SOILDERCHALLENGETYPE_RECOMMEND_INITIATOR] = {name = "diy_mass_initiator.png", scale = 1},
    [SoldierChallengeType.SOILDERCHALLENGETYPE_RECOMMEND_SYSTEM]    = {name = "diy_mass_system.png",    scale = 1},
    [SoldierChallengeType.SOILDERCHALLENGETYPE_MONSTER]             = {name = "mail-gwyj4.png",         scale = 0.5},
}


local SuperCampAttackStamina = 50
local bv_numPerRow   = 1.0
local soilder_perSet = 0

local PveTrainingType = {
    PveHeroTraining = -1,
}

local TreasureFamType = {
    TreasureFamMonster = -101, -- 秘境守卫
    TreasureFamMine    = -102, -- 秘境矿产
}

local ArenaBattleType = {
    ArenaBattle        = -68, -- 竞技场战斗
    AllianceDuelBattle = -69, -- 联盟对决
}

local CommericalType = {
    CommericalBattle = -168, --商镖出征
}

local HERO_TAB_TYPE = {
    HERO_TAB_ALL     = 0, -- 全部
    HERO_TAB_COMBAT  = 1, -- 战斗
    HERO_TAB_DEV     = 2, -- 发展
    HERO_TAB_SUPPORT = 3, -- 辅助
}

local Music_Sfx_world_click_attack = "world_atcbutton"  -- 世界中点击他人城堡后点击攻击、宣战、占领音效
local Music_Sfx_world_click_march  = "world_march"      -- 世界中点击行军部队、出征音效，有军队行军的声音

local ArmType = {
    ARMY = 0,
    FORT = 1,
    TREAT_ARMY = 2,
}

local COMMAND_EFFECT = 8
local FLT_EPSILON = 1.192092896e-07

local FUN_BUILD_HOSPITAL    = 411000    -- 医院
local FUN_BUILD_KNIGHT      = 431000    -- 龙语神殿
local FUN_BUILD_BARRACK1    = 423000    

local DUEL_SOILDER_NUM_EFFECT = 3374   -- 决斗道具作用号
local DULE_SKILL_LIMIT_EFFECT = 5178   -- 决斗技能出兵上限作用号

local DragonState = {
    Dragon_UnActive = 0, -- 未激活
    Dragon_Hatching = 1, -- 孵化中
    Dragon_Hatched  = 2,  -- 孵化完成
    Dragon_Normal   = 3,   -- 正常状态
};

local Error_OK = 0
local Error_OP_FAILURE = 4

local MSG_CURRENT_STAMINE = "msg_currentStamine"

-- 客户端打点
local BATTLE_VIEW_CLICK_SKILL       = "BattleViewClickSkill"       -- 天赋组按钮点击次数
local BATTLE_VIEW_CLICK_BUFF        = "BattleViewClickBuffInfo"    -- 当前生效增益/技能点击次数
local BATTLE_VIEW_CLICK_FIGHT_POWER = "BattleViewClickFightPower"  -- 总战斗力详情点击次数
local BATTLE_VIEW_CLICK_USE         = "BattleViewClickSkill"       -- 去使用按钮点击次数
local BATTLE_VIEW_CLICK_EXTERN      = "BattleViewClickExtern"      -- 右上角编队下拉点击次数
local BATTLE_VIEW_CLICK_SETTING     = "BattleViewClickSetting"     -- 设置按钮点击次数


ccb["BattleViewOwner"] = ccb["BattleViewOwner"] or {}

local BattleView = class("BattleView", function()
	return PopupBaseView:create()
end)

function BattleView:ctor()
    self.m_startIndex           = 0
    self.m_targetIndex          = 0
    self.m_haveOwner            = 0
    self.m_rally                = 0
    self.m_bType                = -1
    self.m_wtIndex              = 0
    self.m_other                = ""
    self.m_targetType           = 0
    self.m_slow                 = 1.0
    self.m_isSuperRally         = 0
    self.m_duelMarch            = false
    self.m_heroId               = ""
    self.m_dragonIndex          = -1
    self.m_allianceBossId       = ""
    self.soilderChallengeType   = SoldierChallengeType.SOILDERCHALLENGETYPE_DEFAULT
    self.m_dragonPower          = 0
    self.m_armyPower            = 0
    self.m_equipPower           = 0
    self.m_leaderPower          = 0
    self.m_enemyPower           = 0
    self.m_heroTabType          = HERO_TAB_TYPE.HERO_TAB_COMBAT
    self.m_diyRally             = 0
    self.m_rallyEndTime         = 0.0
    self.m_ekPlunder            = false

    self.darkCiv = 0
    self.m_civiRate = {}
end

function BattleView:createImpl(param)
	local view = BattleView.new()
	if view:initView(param) then
		return view
	end
	return nil
end

--[[
    -----------------------  BattleView:create  -----------------------
    --  BattleView:create 用于地图行军
        参数列表           必选(*)/可选(?)   默认值        注释
    param["startIndex"]         *           --      出发点，用于计算行军时间
    param["targetIndex"]        *           --      目标点
    param["haveOwner"]          *           --      有无拥有者
    param["slow"]               ?           1.0     时间系数
    param["rally"]              ?           0       集结，援军相关
    param["bType"]              ?           -1      -1（默认） 或 PveTrainingType 或 MarchMethodType
    param["wtIndex"]            ?           -1      self.m_bType == MarchMethodType.MethodRally 时使用
    param["other"]              ?           ""      self.m_bType == MarchMethodType.MethodUnion 时使用
    param["targetType"]         ?           0       活动怪物boss/联盟boss/野蛮人城堡/世界boss信息地块 等情况使用，这些类型可能获取不到cityType
    param["isSuperRally"]       ?           0       超级集结  C++相关方法传的是int，改为一致
    param["duelMarch"]          ?           false   联盟对决
    param["specialMass"]        ?           0       默认为0 王国集结为1 竞技场集结为2
    param["diyRally"]           ?           0       自定义集结【0:否   1:发起集结    2:参与集结】
    param["vacantFightId"]      ?           -1      虚空战场
    param["plunder"]            ?           false   掠夺
    param["rallyEndTime"]       ?            0      集结结束时间
    param["ekPlunder"]          ?           false   海域掠夺
]]
-- 用于地图行军
function BattleView:create(param)
    -- dump(param, "BattleView:create param")
    if self:initParam(param) then
        return self:createImpl(param)
    end
	return nil
end


--[[
    -----------------------  BattleView:createViewForPve  -----------------------
    --  BattleView:createViewForPve 用于英雄试炼
    参数列表           必选(*)/可选(?)   默认值        注释
    startIndex              *           --      
    targetIndex             *           --      
    battleType              *           --      PveTrainingType.PveHeroTraining
    level                   *           --      层数
]]
--  用于英雄试炼
function BattleView:createViewForPve(startIndex, targetIndex, battleType, level, isEndless)
    local param = {["startIndex"] = startIndex, ["targetIndex"] = targetIndex}
    if self:initParam(param) and self:setPveInfo(battleType, level, isEndless) then
        return self:createImpl(param)
    end
	return nil
end


--[[
    -----------------------  BattleView:createViewForTreasureFam  -----------------------
    --  BattleView:createViewForTreasureFam 用于秘境
    参数列表           必选(*)/可选(?)   默认值        注释   
    battleType              *           --      秘境守卫/秘境矿产 TreasureFamType
    mineIndex               *           --      层数
    mineOwnerUid            *           --      拥有者
    maxArmyLimit            *           --      兵力限制
]]
-- 秘境
function BattleView:createViewForTreasureFam(battleType, mineIndex, mineOwnerUid, maxArmyLimit)
    local param = {["startIndex"] = 0, ["targetIndex"] = mineIndex}
    if self:initParam(param) and self:setTreasureFamInfo(battleType, mineIndex, mineOwnerUid, maxArmyLimit) then
        return self:createImpl(param)
    end
end


-- 没有用到的地方，先注释掉
-- function BattleView:createViewForCOSAct(startIndex, targetIndex, bType)
--     local param = {["startIndex"] = startIndex, ["targetIndex"] = targetIndex, ["bType"] = bType}
--     if self:initParam(param) then
--         return self:createImpl(param)
--     end
-- 	return nil
-- end


--[[
    -----------------------  BattleView:createViewForArena  -----------------------
    --  BattleView:createViewForArena 用于竞技场
    参数列表           必选(*)/可选(?)   默认值        注释   
    type                    *           --      ArenaBattleType.ArenaBattle -68
    uid                     *           --      
]]
-- 用于竞技场
function BattleView:createViewForArena(type, uid)
    local param = {}
    if self:initParam(param) and self:setArenaUid(type, uid) then
        return self:createImpl(param)
    end
	return nil
end


--[[
    -----------------------  BattleView:createViewForAllianceDuel  -----------------------
    --  BattleView:createViewForAllianceDuel 联盟对决
    参数列表           必选(*)/可选(?)   默认值        注释   
    type                    *           --      ArenaBattleType.AllianceDuelBattle -69
    pointIndex              *           --      
]]
-- 联盟对决
function BattleView:createViewForAllianceDuel(type, pointIndex)
    local param = {}
    if self:initParam(param) and self:setAllianceDuelPointIndex(type, pointIndex) then
        return self:createImpl(param)
    end
	return nil
end

--[[
    -----------------------  BattleView:createViewForCommercial  -----------------------
    --  BattleView:createViewForCommercial 商旅
    参数列表           必选(*)/可选(?)   默认值        注释   
    type                    *           --      CommericalType.CommericalBattle -69
    id                      *           --      镖车ID
    key                     *           --      消息名字
    maxForceNum             *           --      出兵上限  
]]
-- 商旅
function BattleView:createViewForCommercial(type, id, key, maxForceNum)
    local param = {}
    if self:initParam(param) and self:setCommercialData(type, id, key, maxForceNum) then
        return self:createImpl(param)
    end
	return nil
end

--[[
    -----------------------  BattleView:createViewForFightDeath  -----------------------
    -- 领主死斗
    参数列表           必选(*)/可选(?)   默认值        注释   
    armyScope                *          --        出征上限
    armyMinLv                *          --        士兵最低等级
]]
function BattleView:createViewForFightDeath(armyScope, armyMinLv)
    local param = {bType = MarchMethodType.FightDeath}
    if self:initParam(param) and self:setFightDeath(armyScope, armyMinLv) then
        return self:createImpl(param)
    end
	return nil
end

function BattleView:initParam(param)
    if param == nil then
        return false
    end

    --重置元表数据
    self.m_battlType = 0

    -- 默认参数
    param["startIndex"]     = tonumber(param["startIndex"])             or 0        -- 出发点，用于计算行军时间
    param["targetIndex"]    = tonumber(param["targetIndex"])            or 0        -- 目标点
    param["haveOwner"]      = tonumber(param["haveOwner"])              or 0        -- 有无拥有者
    param["slow"]           = tonumber(param["slow"])                   or 1.0      -- 时间系数
    param["rally"]          = tonumber(param["rally"])                  or 0        -- 集结，援军相关
    param["bType"]          = tonumber(param["bType"])                  or -1       -- -1（默认） 或 PveTrainingType 或 MarchMethodType
    param["wtIndex"]        = tonumber(param["wtIndex"])                or -1       -- self.m_bType == MarchMethodType.MethodRally 时使用
    param["other"]          = tostring(param["other"])                  or ""       -- self.m_bType == MarchMethodType.MethodUnion 时使用
    param["targetType"]     = tonumber(param["targetType"])             or 0        -- 对应WorldCityType
    param["isSuperRally"]   = tonumber(param["isSuperRally"])           or 0        -- 超级集结
    param["duelMarch"]      = tostring(param["duelMarch"]) == "true"    or false    -- 联盟对决
    param["specialMass"]    = tonumber(param["specialMass"])            or 0        -- 默认为0 王国集结为1 竞技场集结为2
    param["diyRally"]       = tonumber(param["diyRally"])               or 0        -- diyRally：自定义集结【0:否   1:发起集结    2:参与集结】
    param["vacantFightId"]  = tonumber(param["vacantFightId"])          or -1       -- 虚空战场
    param["plunder"]        = tostring(param["plunder"]) == "true"      or false    -- 掠夺
    param["rallyEndTime"]   = tostring(param["rallyEndTime"])           or 0.0      -- 集结结束时间
    param["ekPlunder"]      = tostring(param["ekPlunder"]) == "true"      or false    -- 海域掠夺

    return true
end

function BattleView:updateParams( dict )
    --通过消息传参，之前传参太多了。。。
    local data = dictToLuaTable(dict)
    dump(data, 'updateParams---')
    local darkCiv = data.darkCiv;
    if darkCiv and darkCiv>0 then
        self.darkCiv = darkCiv
        local str = _lang("3100112")
        local tmpUsePower = self:getDarkCivPower()
        str = str..CC_ITOA(tmpUsePower);
        self.m_msg2Label:setString(str)
    end
    if data.monsterId then
        self.monsterId = data.monsterId
        local usePower = CCCommonUtilsForLua:getPropById(data.monsterId, "usePower")
        if usePower ~= "" then
           self.m_msg2Label:setVisible(true)
           self.m_msg2Label:setString(_lang("3100112")..usePower)
        end
    end
end

function BattleView:setPveInfo(type, level, isEndless)
    if type == nil or level == nil then
        return false
    end
    self.m_battlType = type;
    self.m_levelIndex = level;
    self.isEndless = isEndless
    return true;
end

function BattleView:loadResource()
    CCLoadSprite:call("doResourceByCommonIndex", 8,   true, false)
    CCLoadSprite:call("doResourceByCommonIndex", 7,   true, false)
    CCLoadSprite:call("doResourceByCommonIndex", 504, true, false)
    CCLoadSprite:call("doResourceByCommonIndex", 105, true, false)
    CCLoadSprite:call("doResourceByCommonIndex", 204, true, false)
    CCLoadSprite:call("doResourceByCommonIndex", 509, true, false)
    CCLoadSprite:call("loadDynamicResourceByName", DynamicResource.DRAGON_CAVE)
    CCLoadSprite:call("loadDynamicResourceByName", DynamicResource.NewHero)
    CCLoadSprite:call("loadDynamicResourceByName", DynamicResource.DIY_MASS_FACE)

    -- 技能图标
    CCLoadSprite:call("loadDynamicResourceByType", CCLoadSpriteType.CCLoadSpriteType_SCIENCE)
	-- CCLoadSprite:call("loadDynamicResourceByName", "dragonCave")
	CCLoadSprite:call("loadDynamicResourceByName", "dragonCave1")
	-- CCLoadSprite:call("loadDynamicResourceByName", "newHero")
	CCLoadSprite:call("loadDynamicResourceByName", "science")
	CCLoadSprite:call("loadDynamicResourceByName", "Common_209_face")
    CCLoadSprite:call("loadDynamicResourceByName", "AngelArmy_face")
end

function BattleView:initView(param)
    self:loadResource()
    -- self:setIsHDPanel(true)
    self:initData(param)
    
    ----------
    if self.m_bType == -1 and self.m_targetType == 1 then
        ArmyController:call("getInstance"):setProperty("LoadSt", true)
    end
    ----------
    self.title_base_str = _lang("3100112")
    self:initTitleCommonFunc() -- 先初始化，不然有可能报错
    self:initUI()

	local function onNodeEvent(event)
		if event == "enter" then
			self:onEnter()
		elseif event == "exit" then
			self:onExit()
		end
	end
    self:registerScriptHandler(onNodeEvent)
    
    return true
end

function BattleView:initData(param)
    self.m_slow = param["slow"];
    self.m_spd = 0;
    self.m_maxCorrectNum = 0;
    self.willCloseSelf = false;
    self.m_maxForceNumPve = 0;
    self.m_maxForceNum = -1;
    TroopsController:call("getInstance"):call("resetGeneralToSend") -- TroopsController::getInstance()->resetGeneralToSend();
    self.m_startIndex    = param["startIndex"];
    self.m_targetIndex   = param["targetIndex"];
    self.m_haveOwner     = param["haveOwner"];
    self.m_rally         = param["rally"]
    self.m_bType         = param["bType"]
    self.m_wtIndex       = param["wtIndex"]
    self.m_other         = param["other"]
    self.m_targetType    = param["targetType"]
    self.m_isSuperRally  = param["isSuperRally"]
    self.m_duelMarch     = param["duelMarch"]
    self.m_specialMass   = param["specialMass"]
    self.m_plunder       = param["plunder"]
    self.m_diyRally      = CCCommonUtilsForLua:isFunOpenByKey("arrange_arms") and param["diyRally"] or 0; --[awen-junyu] 设置自定义集结状态
    self.m_vacantFightId = param["vacantFightId"];
    self.m_civiBuildTag  = false;
    self.m_lvSet         = 0;
    self.m_soilder_perSet = 0;
    self.m_rallyEndTime  = param["rallyEndTime"]
    self.m_ekPlunder     = param["ekPlunder"]
    self.m_marchTime     = 0 -- 行军时间
    
    self.m_allianceBossId = WorldController:call("getInstance"):getProperty("tmpBossId")

end

function BattleView:initTitleCommonFunc()
    self.titleCommonFunc = {}
    self.titleCommonFunc["CanNotFind"] = function ()
        return self.title_base_str
    end

    local info = WorldController:call("getCityInfoByIndex", self.m_targetIndex)
    -- 活动怪物boss
    self.titleCommonFunc[WorldCityType.ActBossTile] = function ()
        return self.title_base_str..CC_ITOA(GlobalData:call("shared"):getProperty("worldConfig"):getProperty("boss_decr"))
    end

    -- 联盟boss
    self.titleCommonFunc[WorldCityType.AllianceBoss] = function ()
        if self.m_allianceBossId ~= nil and self.m_allianceBossId ~= "" then
            return self.title_base_str..CCCommonUtilsForLua:getPropById(tostring(self.m_allianceBossId), "power")
        elseif info then
            local fieldMonsterInfo = info:call("getFieldMonsterInfo")
            return self.title_base_str..CCCommonUtilsForLua:getPropById(fieldMonsterInfo:getProperty("monsterId"), "power")
        end
    end

    -- 44 野蛮人城堡
    self.titleCommonFunc[WorldCityType.Barbarian] = function ()
        return self.title_base_str..CCCommonUtilsForLua:getPropById(info:getProperty("m_barbarianInfo"):getProperty("barbarianId"), "usePower")
    end

     -- 世界boss信息地块
    self.titleCommonFunc[WorldCityType.tile_HpWorldBoss] = function ()
        local info_type = info:getProperty("hpWorldBossInfo"):getProperty("type")
        local bbinfo = WorldBossController:call("getInstance"):call("getBossInfoByType", tonumber(info_type))
        if bbinfo then
            return self.title_base_str..CC_ITOA(bbinfo:getProperty("HpBoss_stamineCost"))
        end
    end

    -- 野怪周边 ？？？
    self.titleCommonFunc[WorldCityType.MonsterRange] = function ()
        local usePower = WorldController:call("getInstance"):call("getMonsterUsePower", self.m_targetIndex)
        if usePower == 0 then
            usePower = GlobalData:call("shared"):getProperty("worldConfig"):getProperty("stamineCostPerTime")
        end
        return self.title_base_str..CC_ITOA(usePower)
    end
    -- 9 野怪
    self.titleCommonFunc[WorldCityType.FieldMonster]             = self.titleCommonFunc[WorldCityType.MonsterRange]
    --【Awen】4格普通野怪 85
    self.titleCommonFunc[WorldCityType.FOUR_FIELD_MONSTER]       = self.titleCommonFunc[WorldCityType.MonsterRange]
    --【Awen】4格普通野怪周边 86
    self.titleCommonFunc[WorldCityType.FOUR_FIELD_MONSTER_RANGE] = self.titleCommonFunc[WorldCityType.MonsterRange]
    -- 英雄主题月 异国旅人怪物点 106
    self.titleCommonFunc[WorldCityType.hero_maintheme_monster]   = self.titleCommonFunc[WorldCityType.MonsterRange]
    -- 古迹争夺战 游寇野怪 134
    self.titleCommonFunc[WorldCityType.dark_civ_monster]         = self.titleCommonFunc[WorldCityType.MonsterRange]

    -- 守护者 
    self.titleCommonFunc[WorldCityType.DEFENSOR] = function ()
        local tmpUsePower = 0
        local tdic = CCDictionary:create()
        tdic:setObject(CCInteger:create(self.m_targetIndex), "index")
        -- guiCommonLocal.on_getUsePower(tdic) --- !!!!! LuaController::getInstance()->fireEventRef("getUsePower", &tdic);
        tmpUsePower = tdic:valueForKey("power"):intValue()
        return self.title_base_str..CC_ITOA(tmpUsePower)
    end

    -- 营地
    self.titleCommonFunc[WorldCityType.city_barracks] = function ()
        local tmpUsePower = GlobalData:call("shared"):getProperty("worldConfig"):getProperty("city_barracks_userPower")
        return self.title_base_str..CC_ITOA(tmpUsePower)
    end

    -- 八国国战世界boss
    self.titleCommonFunc[WorldCityType.nationalwar_boss] = function ()
        local usePower = WorldController:call("getInstance"):call("getMonsterUsePower", self.m_targetIndex)
        if usePower == 0 then
            usePower =  GlobalData:call("shared"):getProperty("worldConfig"):getProperty("stamineCostPerTime")
        end
        return self.title_base_str..CC_ITOA(usePower)
    end
    -- 八国国战世界boss周边
    self.titleCommonFunc[WorldCityType.nationalwar_boss_range] = self.titleCommonFunc[WorldCityType.nationalwar_boss]

    -- 王国传送门兵营
    self.titleCommonFunc[WorldCityType.SuperCampsiteRally] = function ()
        local tmpUsePower = SuperCampAttackStamina
        local sPower = CCCommonUtilsForLua:getPropByIdGroup("data_config", "super_camp", "k4")
        if sPower ~= nil and sPower ~= "" then
            tmpUsePower = tonumber(sPower)
        end
        return self.title_base_str..CC_ITOA(tmpUsePower);
    end

     -- 世界争霸boss
    self.titleCommonFunc[WorldCityType.craft_boss] = self.titleCommonFunc[WorldCityType.nationalwar_boss]
end

function BattleView:getTitleCommon(targetType, type, luaType)
    local realType = nil
    if type == WorldCityType.LuaNewTile then
        realType = luaType
    elseif targetType ~= nil then
        realType = targetType
    else
        realType = type
    end

    if self.titleCommonFunc[realType] then
        return self.titleCommonFunc[realType]()
    else
        return self.titleCommonFunc["CanNotFind"]()
    end
end

function BattleView:isBuffAndFightPowerAreaValid()
    -- 以后需要特殊处理buff和战斗力显示的都可以写在这里
    -- 押镖没有对应的 MarchMethodType，暂时不显示buff和总战斗力部分
    return self.m_battlType ~= CommericalType.CommericalBattle
end

function BattleView:initUI()
    if self:init(true, 5) == false then
        Dprint("BattleView init error")
        return false
    end

    --读取ccbi
    local CustomUtility = Drequire("Editor.CustomUtility")
    CustomUtility:LoadUi("MarchForLua.ccbi", self, self, 1)

    local view_size = self:getContentSize()
    local bg_size   = self.m_viewBg_bk:getContentSize()
    self.m_viewBg_bk:setScaleX(view_size.width / bg_size.width)
    self.m_viewBg_bk:setScaleY(view_size.height / bg_size.height)

    self.m_animationManager = ccb["BattleViewOwner"]["mAnimationManager"]

    self.m_delHeroBtn:setVisible(false);
    self.m_delDragonBtn:setVisible(false);
    self.m_externNode:setVisible(false);
    self.m_externBtnNode:setVisible(false);

    -- 战斗力
    self.m_fightPowerName:setString(getLang("105024")) -- 105024=部队战斗力
    CCCommonUtilsForLua:setButtonTitle(self.m_detailBtn, getLang("140236"))  -- 140236=详情

    -- 新增天赋组、增益跳转
    self:updateSkillBtnTitle()
    CCCommonUtilsForLua:setButtonTitle(self.m_buffBtn, getLang("10200033")) -- 10200033=去使用

    -- 新增增益显示
    -- 增加新开关-增益/技能区
    self.m_new_battle_view_buff = CCCommonUtilsForLua:isFunOpenByKey("new_battle_view_buff")
    self.m_buffArea:setVisible(self.m_new_battle_view_buff and self:isBuffAndFightPowerAreaValid())
    self.m_buffIconNode:setVisible(false)
    -- 增加新开关-战斗力详情
    self.m_new_battle_view_detail = CCCommonUtilsForLua:isFunOpenByKey("new_battle_view_detail")
    self.m_detailNode:setVisible(self.m_new_battle_view_detail and self:isBuffAndFightPowerAreaValid())

    self.m_noBuffDesc:setVisible(false)
    self.m_buffDesc:setVisible(false)
    self.m_noBuffDesc:setString(getLang("10200032")) -- 10200032=当前无生效的增益/技能
    self.m_buffDesc:setString(getLang("10200031"))   -- 10200031=当前生效的增益/技能
    
    -- 增益icon
    self.m_buff_icon_arr = {}
    for i = 1, 5 do
        self.m_buff_icon_arr[i] = self["m_buffIcon"..tostring(i)]
    end

    local mainCityLv = FunBuildController:call("getMainCityLv")
    self:updateHeroRootNode(mainCityLv >= 4)    -- 城堡4级解锁英雄
    self:updateDragonRootNode(mainCityLv >= 6)  -- 城堡6级解锁龙
    self:updateBookRootNode(mainCityLv >= 21)   -- 城堡21级解锁阵法

    ----- 此处可以考虑单独写
    if not CCCommonUtilsForLua:isFunOpenByKey("dragon_battle") and not CCCommonUtilsForLua:isFunOpenByKey("general_battle") then
        self.m_extraNode:setVisible(false)
    end
    
    TroopsController:call("getInstance"):setProperty("m_curSelHeroNum", 0)
    TroopsController:call("getInstance"):setProperty("m_curLoadNum", 0)
    CCCommonUtilsForLua:setButtonTitle(self.m_quickBtn, _lang("105149"))
    
    local new_go_battle = CCCommonUtilsForLua:isFunOpenByKey("new_go_battle")
    if new_go_battle then
        local receiver = {}
        -- CCSafeNotificationCenter:postNotification("msg_soilderSet_getData", receiverDict)
        require("game.setting.SoildersMarchSettingController").getInstance():addSetNodeForLua(receiver, true)
        self.m_marchSettingNode = receiver["node"]
        if self.m_marchSettingNode then
            local size = self.m_marchSettingNode:getContentSize();
            local listSize = self.m_infoList:getContentSize();
            local height = listSize.height - size.height;
            self.m_marchSettingNode:setPosition(cc.p(listSize.width/2 + self.m_infoList:getPositionX(), height + self.m_infoList:getPositionY()))
            self.m_infoList:getParent():addChild(self.m_marchSettingNode)
            self.m_infoList:setContentSize(CCSize(listSize.width, height))
        end

        self.m_lvSet = tonumber(receiver["lvSet"])
        self.m_soilder_perSet = tonumber(receiver["perSet"])
        self.m_lvOrderSet = receiver["lvOrderSet"]
        self.m_typeOrderSet = receiver["typeOrderSet"]
        self.m_numOrderSet = receiver["numOrderSet"]
    end

    -- 自定义集结默认有两个编队，没条件限制
    local dis = 55
    if self.m_diyRally > 0 then
        self.m_formationNode:setVisible(true)
        self.m_formation1:setVisible(true)
        self.m_formation1:setPositionX(-dis)
        self.m_formation2:setVisible(true)
        for i = 3, 10 do
            self["m_formation"..i]:setVisible(false)
        end
        
        local frame = CCLoadSprite:call("getSF", "diy_mass_team_common.png")
        if frame then
            CCCommonUtilsForLua:call("setButtonSprite", self.m_formationBtn1, "diy_mass_team_common.png")
            CCCommonUtilsForLua:call("setButtonSprite", self.m_formationBtn2, "diy_mass_team_common.png")
        end
    else
        -- 判断是否有编队功能按钮:15本两个,SVIP根据等级取值
        local formationCount = 0
        local LvLimit = atoi(CCCommonUtilsForLua:getPropByIdGroup("data_config","form_into_columns","k1"))
        local baseNum = atoi(CCCommonUtilsForLua:getPropByIdGroup("data_config","form_into_columns","k2"))
        LvLimit = LvLimit == 0 and 15 or LvLimit
        baseNum = baseNum == 0 and 2 or baseNum
        if FunBuildController:call("getMainCityLv") >= LvLimit then
            formationCount = formationCount + baseNum
        end

        local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
        local svipLv = playerInfo:getProperty("SVIPLevel")
        if VipUtil:call("isSVIP") and svipLv > 0 and playerInfo:getProperty("vipEndTime") > GlobalData:call("shared"):call("getWorldTime") then
            local itemID = 7010 + svipLv-1
            local value = tonumber(CCCommonUtilsForLua:getPropById(tostring(itemID), "troop"))
            if value > 0 then
                formationCount = formationCount + value
            end
        end

        local externFormation = 0  -- 多出的编队
        local columns_switch_34 = CCCommonUtilsForLua:isFunOpenByKey("columns_switch_34")
        local limit = columns_switch_34 and 10 or 5
        if formationCount > 5 then   -- 目前最多可以有10个编队 多余5个显示额外编队按钮
            self.m_externNode:setVisible(columns_switch_34)
            if formationCount > limit then
                formationCount = limit
            end
        end

        local formationVec = {
            self.m_formation1, self.m_formation2, self.m_formation3, self.m_formation4, self.m_formation5, 
            self.m_formation6, self.m_formation7, self.m_formation8, self.m_formation9, self.m_formation10
        }
        if formationCount > 0 and GlobalData:call("shared"):getProperty("march_formation_switch") == 2 then
            self.m_formationNode:setVisible(true)
            for i = 1, 10 do
                formationVec[i]:setVisible(false)
            end
            
            self.m_formationLabel6:setString(_lang_1("103699", "6"))
            self.m_formationLabel7:setString(_lang_1("103699", "7"))
            self.m_formationLabel8:setString(_lang_1("103699", "8"))
            self.m_formationLabel9:setString(_lang_1("103699", "9"))
            self.m_formationLabel10:setString(_lang_1("103699", "10"))
            
            for i = 1, formationCount do
                formationVec[i]:setVisible(true)
                -- 前五个编队水平摆放
                if (i <= 5) then
                    if (formationCount <= 5) then
                        formationVec[i]:setPositionX((i-formationCount) * dis)
                    else -- 需要显示下拉按钮
                        formationVec[i]:setPositionX((i-6) * dis)
                    end
                end
            end
            self.m_externNode:setPositionX(0)
            self.m_externBtnNode:setPositionX(-120)
        else
            self.m_formationNode:setVisible(false)
        end
    end

    self.m_timeText:setString(_lang("108536"))
    self.m_msg1Label:setString("0/")

    local maxSoilderNum = self:getMaxSoilderNum()
    self.m_msg3Label:setString(CC_ITOA(math.floor(maxSoilderNum)))
    self.m_msg2Label:setString(tostring(TroopsController:call("getInstance"):getProperty("m_curLoadNum")))
    self.m_timeLabel:setString(CC_SECTOA(0))
    self:call("setModelLayerOpacity", 200)
    self.m_tmpArray = {} -- CCArray:create()
    local info = WorldController:call("getCityInfoByIndex", self.m_targetIndex)
    local type    = -1
    local luaType = -1
    local info_cityType = nil
    local info_luaType = nil
    if info ~= nil then
        info_cityType = info:getProperty("cityType") -- 使用type和luaType的地方，不一定判定info非空，所以type和luaType不一定存的是info中的值。为了避免重复取值，使用info_cityType和info_luaType
        info_luaType = info:getProperty("luaType")
        type    = info_cityType
        luaType = info_luaType
    end

    ---------------- 这段逻辑可以分离
    if self.m_battlType == PveTrainingType.PveHeroTraining and CCCommonUtilsForLua:isFunOpenByKey("test_hero_switch") then  -- 不在m_cityInfo 里面
        self.m_bType = PveTrainingType.PveHeroTraining
        self:initPveInfo()
    elseif self.m_battlType == TreasureFamType.TreasureFamMonster and CCCommonUtilsForLua:isFunOpenByKey("treasure_fam_on") then
        self:initTreasureFamMonsterInfo()
    elseif self.m_battlType == TreasureFamType.TreasureFamMine and CCCommonUtilsForLua:isFunOpenByKey("treasure_fam_on") then
        self:initTreasureFamMineInfo()
    elseif self.m_bType == MarchMethodType.COSDonateSoldireMarch and CCCommonUtilsForLua:isFunOpenByKey("consume_soldier_defend") then
        self.m_bType = MarchMethodType.COSDonateSoldireMarch
        self:initCOSInfo()
    elseif self.m_bType == MarchMethodType.FightDeath then
        self:initFightDeath()
    elseif GlobalDataCtr.checkIsGreenServer() then
        self:marchForGreenServer()
    else
        self:generateData()
        if new_go_battle then
            self:sortTmpArrayByLv()
        end
    end
    ---------------- 
    
    self.m_tipNode = nil
    self.node_hintJump:setVisible(false)

    self.m_texShowTips = ""
    ---------------- 普通出征与杀戮战场区别设置
    local serverType = GlobalData:call("shared"):getProperty("serverType")
    if #self.m_tmpArray == 0 then
        self.m_hintText:setString(_lang("102151")) -- 102151=领主大人，您的城市中现在没有士兵可以出征！
        if serverType == ServerType.SERVER_ANCESTRAL then
            self.node_hintJump:setVisible(false)
        elseif CCCommonUtilsForLua:isFunOpenByKey("expedition_interface_jump") then  -- 杀戮战场中，不显示跳转
            self.node_hintJump:setVisible(true)
            self.node_hintJump:setPositionY(-10)
            CCCommonUtilsForLua:setButtonTitle(self.btn_trainJump, _lang("114345")) -- 114345=训练士兵
            CCCommonUtilsForLua:setButtonTitle(self.btn_healJump, _lang("114344"))  -- 114344=伤病治疗
            local tempHealNum = self:getHealSoldierNum()
            local tempHealAllianceNum = ArmyController:call("getInstance"):call("getHealAllianceSoldierNum")
            if tempHealNum > 0 or tempHealAllianceNum > 0 then  -- 有受伤部队
                if tempHealNum > 0 then
                    self.m_texShowTips = _lang_1("114347", CC_ITOA(tempHealNum)).."\n"  -- 114347=急救帐篷:{0}（急救帐篷伤兵数量
                end
                if tempHealAllianceNum > 0 then
                    self.m_texShowTips = self.m_texShowTips.._lang_1("114348", CC_ITOA(tempHealAllianceNum)).."\n"  -- 114348=联盟医院:{0}（联盟医院伤兵数量）
                end
                self.m_hintText2:setString(_lang_1("114343", CC_ITOA(tempHealNum + tempHealAllianceNum)))  -- 114343=受伤部队:{0}
                self.pic_tipIcon:setPositionX(self.m_hintText2:getPositionX() + self.m_hintText2:getContentSize().width + 5)
                self.btn_healJump:setVisible(true)
                self.m_hintText2:setVisible(true)
                self.pic_tipIcon:setVisible(true)
                self.pit_tipTouch:setVisible(true)
            else
                self.btn_trainJump:setPositionY(self.btn_healJump:getPositionY())
                self.btn_healJump:setVisible(false)
                self.m_hintText2:setVisible(false)
                self.pic_tipIcon:setVisible(false)
                self.pit_tipTouch:setVisible(false)
            end
        end
    else
        self.m_hintText:setString("")
        self.node_hintJump:setVisible(false)
    end
    --------------------

    if self.m_bType == MarchMethodType.MethodRally 
        or (self.m_bType == MarchMethodType.MethodTeamRally and self.m_wtIndex > 0) then
        CCCommonUtilsForLua:setButtonTitle(self.m_marchBtn, "")
        self.ui.m_labelTitle:setString(_lang("108582"))  --108582=集结
        self.m_timeText:setString(_lang("108582"))
    elseif self.m_bType == MarchMethodType.MethodUnion 
        or self.m_bType == MarchMethodType.MethodTeamUnion then
        CCCommonUtilsForLua:setButtonTitle(self.m_marchBtn, "")
        self.ui.m_labelTitle:setString(_lang("108582"))  --108582=集结
        self.m_timeText:setString(_lang("108582"))
    elseif self.m_bType == MarchMethodType.MethodYuanSolider then
        CCCommonUtilsForLua:setButtonTitle(self.m_marchBtn, "")
        self.ui.m_labelTitle:setString(_lang("115176"))  --115176=士兵援助
        self.m_timeText:setString(_lang("115176"))
    elseif self.m_bType == MarchMethodType.DarkCivOne or self.m_bType == MarchMethodType.DarkCivThree then
        self.ui.m_labelTitle:setString(_lang("108582"))  --108582=集结
        self.m_timeText:setString(_lang("108582"))
    elseif self.m_bType == MarchMethodType.FightDeath then
        self.ui.m_labelTitle:setString(_lang("9900230"))  --9900230=编辑阵容
        self.m_timeText:setString(_lang("623503"))--623503=保存
    else
        self.ui.m_labelTitle:setString(_lang("105150"))  --105150=出征
    end

    if luaType == WorldCityType.tile_civi_miracle and self.m_bType == -1 then
        CCCommonUtilsForLua:setButtonTitle(self.m_marchBtn, "")
        self.m_timeText:setString(_lang("250014"))
        self:setCiviBuildNode()
        self.m_civiBuildTag = true
    end

    local list_size = self.m_infoList:getContentSize()
    self.m_tabView = cc.TableView:create(list_size)
    self.m_tabView:setTag(1234)
    self.m_tabView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
    self.m_tabView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
    self.m_tabView:setDelegate()
    self.m_tabView:registerScriptHandler(function(table, cell) self:tableCellTouched(table, cell)           end, cc.TABLECELL_TOUCHED)
    self.m_tabView:registerScriptHandler(function(table, idx)  return self:cellSizeForTable(table, idx)     end, cc.TABLECELL_SIZE_FOR_INDEX)
    self.m_tabView:registerScriptHandler(function(table)       return self:numberOfCellsInTableView(table)  end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
    self.m_tabView:registerScriptHandler(function(table, idx)  return self:tableCellAtIndex(table, idx)     end, cc.TABLECELL_SIZE_AT_INDEX)
    self.m_infoList:addChild(self.m_tabView, 1)

    -- self.m_marchBtn:setEffectStr("") -- 点击声音，暂时略过
    -- this->scheduleOnce(schedule_selector(BattleView:loadResource), 0.02); -- 先改在最后使用 self:updateInfo()
    self:updateLoadInfo(nil)


    if (self.m_targetType == WorldCityType.ActBossTile 
        or self.m_targetType == WorldCityType.AllianceBoss 
        or self.m_targetType == WorldCityType.AllianceBoss
        or (type == WorldCityType.FieldMonster
            or type == WorldCityType.FOUR_FIELD_MONSTER 
            or type == WorldCityType.FOUR_FIELD_MONSTER_RANGE
            or type == WorldCityType.hero_maintheme_monster
            or type == WorldCityType.dark_civ_monster
            or type == WorldCityType.DEFENSOR
            or type == WorldCityType.MonsterTile
            or type == WorldCityType.MonsterRange
            or type == WorldCityType.ActBossTile
            or type == WorldCityType.AllianceBoss
            or type == WorldCityType.Barbarian
            or type == WorldCityType.tile_HpWorldBoss
            or (type == WorldCityType.LuaNewTile and luaType == WorldCityType.city_barracks)
            or (type == WorldCityType.LuaNewTile and luaType == WorldCityType.nationalwar_boss)
            or (type == WorldCityType.LuaNewTile and luaType == WorldCityType.nationalwar_boss_range)
            or (type == WorldCityType.LuaNewTile and luaType == WorldCityType.craft_boss)
            or (type == WorldCityType.LuaNewTile and (luaType == WorldCityType.city_barracks or luaType == WorldCityType.SuperCampsiteRally)))
        ) then
        self.m_iconContainer:removeAllChildren()
        local sprite = CCLoadSprite:createSprite("Ui_tili.png")
        sprite:setScale(0.65)
        self.m_iconContainer:addChild(sprite)

        local new_str = self:getTitleCommon(self.m_targetType, type, luaType)
        self.m_msg2Label:setString(new_str)
    elseif (info ~= nil and info_cityType == WorldCityType.Resource_new or info_cityType == WorldCityType.Resource_new_dragon 
            or info_cityType == WorldCityType.ResourceTile) then
        local tempType = 0;
        local cityType = info_cityType
        if cityType == WorldCityType.Resource_new or cityType == WorldCityType.Resource_new_dragon then
            tempType = WorldResourceType.Gold;
        elseif cityType == WorldCityType.ResourceTile then
            tempType = info:getProperty("resource"):getProperty("type") --!!!!!!
        end
        self.m_iconContainer:removeAllChildren()
        local icon = CCCommonUtilsForLua:call("getResourceIconByType", tonumber(tempType))
        local sprite = CCLoadSprite:createSprite(icon)
        CCCommonUtilsForLua:call('setSpriteMaxSize', sprite, 40)
        self.m_iconContainer:addChild(sprite)
        -- 设置英雄页签类型为发展
        self.m_heroTabType = HERO_TAB_TYPE.HERO_TAB_DEV
    elseif info ~= nil and (info_luaType == WorldCityType.expedition_super_mine or info_luaType == WorldCityType.expedition_super_mine_sub) then
        local itemId = info:getProperty("resource"):getProperty("type")
        local icon = CCCommonUtilsForLua:getPropByIdGroup("goods", CC_ITOA(itemId), "icon")..".png"
        local sprite = CCLoadSprite:createSprite(icon, CCLoadSpriteType.CCLoadSpriteType_GOODS)
        sprite:setScale(0.5)
        CCCommonUtilsForLua:call('setSpriteMaxSize', sprite, 40)
        self.m_iconContainer:removeAllChildren()
        self.m_iconContainer:addChild(sprite)
    elseif (info ~= nil and (info_cityType == WorldCityType.ResourceBattleTile or info_cityType == WorldCityType.NewResourceBattleTile 
            or (info_cityType == WorldCityType.LuaNewTile and info_luaType == WorldCityType.NeutralLand_Resource) 
            or (info_cityType == WorldCityType.LuaNewTile and info_luaType== WorldCityType.nationalwar_mine))) then
        self.m_iconContainer:removeAllChildren();
        self.m_msg2Label:setVisible(false);
        self.m_stamineNode:setVisible(false);
        self.m_helpBtn:setVisible(false);
    end

    self:setChallengeState()
    
    self.m_saveArenaFormation = CCCommonUtilsForLua:isFunOpenByKey("battle_view_save_arena_formation") and self.m_battlType == ArenaBattleType.ArenaBattle
    self.m_saveFamFormation = CCCommonUtilsForLua:isFunOpenByKey("battle_view_save_fam_formation") and self.m_battlType == TreasureFamType.TreasureFamMonster
    if self.m_saveArenaFormation or self.m_saveFamFormation then
        self:initFromLastFormation()
    else
        self:onClickQuickBtn(nil, cc.CONTROL_EVENTTYPE_TOUCH_DOWN)
    end

    SoundController:call("playEffects", Music_Sfx_world_click_attack)
    
    local modelLayer = CCModelLayerColor:call("create")
    modelLayer:setOpacity(0)
    modelLayer:setColor(cc.RED)
    modelLayer:setContentSize(self.m_bTouchNode:getContentSize())
    modelLayer:setAnchorPoint(ccp(0.5, 0.5))
    self.m_bTouchNode:addChild(modelLayer)
    -- [awen-gaorui] 加英雄删除按钮后，隐藏已选择英雄的标志
    self.m_heroYesSpr:getParent():setVisible(false)
    self.m_dragonYesSpr:getParent():setVisible(false)
    self.m_dragonYesSpr:setVisible(false)
    self.m_heroTxt:setString(_lang("169041"))     -- 169041=选择英雄
    self.m_dragonTxt:setString(_lang("169040"))   -- 169040=选择龙
    
    self:getHeroData()
    self:getDragonData()
    self.m_aormationId = ""
    self.m_delBookBtn:setVisible(false)
    -- self.m_aormationTxtNode:setVisible(false)
    local dict = CCDictionary:create()
    if isFunOpenByKey('formation_train') then
        FormationTrainCtr.getInstance():setBattleSel(dict)
        self:setAormationInfo(dict:objectForKey("aormationId"))
    elseif CCCommonUtilsForLua:isFunOpenByKey("aormation") then
        TacticalDepController.getInstance():setBattleSel(dict)
        if dict:objectForKey("aormationId") then
            local aormationId = dict:valueForKey("aormationId"):getCString()
            if aormationId ~= "" then
                self:setAormationInfo(dict:objectForKey("aormationId"));
            else
                self:setAormationInfo(CCString:create(""))
            end
        end
    else
        self.m_bookNode:setVisible(false)
    end
    -- 虚空战场和杀戮战场暂时屏蔽阵法
    if GlobalData:call("shared"):getProperty("isInVoidBattlefieldServer") or 
        serverType == ServerType.SERVER_ANCESTRAL then
        self.m_bookNode:setVisible(false)
    end
    
    -- 英雄试炼优化   默认选择已有英雄
    if(self.m_battlType == PveTrainingType.PveHeroTraining and CCCommonUtilsForLua:isFunOpenByKey("test_hero_switch") and CCCommonUtilsForLua:isFunOpenByKey("hero_challenge_optimize")) then
        local PveDataController = require("game.Training.PveDataController")
        local arr = PveDataController:getInstance():getPveMarchHeroIds()
        for index, value in ipairs(arr) do
            if value ~= nil then
                self:setHero(CCString:create(value))
                break
            end
        end
    end
    
    self:updateInfo()
    self:updateBuffIcon()
    return true
end

-- 英雄
function BattleView:updateHeroRootNode(visible)
    self.m_heroBgLeft:setVisible(visible)
    self.m_heroBgRight:setVisible(visible)
    self.m_heroBgX:setVisible(visible)
    self.m_heroBg1:setVisible(visible)
    self.m_heroRootNode:setVisible(visible)
end

-- 龙
function BattleView:updateDragonRootNode(visible)
    self.m_dragonBgLeft:setVisible(visible)
    self.m_dragonBgRight:setVisible(visible)
    self.m_dragonBgX:setVisible(visible)
    self.m_dragonBg1:setVisible(visible)
    self.m_dragonRootNode:setVisible(visible)
end

-- 阵法
function BattleView:updateBookRootNode(visible)
    self.m_formationBgLeft:setVisible(visible)
    self.m_formationBgRight:setVisible(visible)
    self.m_bookNode:setVisible(visible)
end

function BattleView:updateSkillBtnTitle()
    local generalInfo = GlobalData:call("shared"):getProperty("generals") --map<string,GeneralInfo>
    local info = table.firstvalue(generalInfo)--GeneralInfo
    local curMapIdx = info:getProperty("curMapIdx")
    CCCommonUtilsForLua:setButtonTitle(self.m_skillBtn, getLang("10200200")..tostring(curMapIdx+1)) -- 10200200=天赋组
end

function BattleView:getHealSoldierNum()
    local currentNum = 0;
    local treatList = GlobalData:call("shared"):getProperty("treatList")
    for key, value in pairs(treatList) do
        currentNum = currentNum + value:getProperty("dead")
    end
    
    -- 小与最大可治疗数
    local total = ArmyController:call("getInstance"):call("getMaxNumByType", ArmType.TREAT_ARMY);
    
    local st = ActivityController:call("getInstance"):call("isInNewThroneBattle")
    local serverType = GlobalData:call("shared"):getProperty("serverType")
    if serverType == ServerType.SERVER_BATTLE_FIELD or serverType == ServerType.SERVER_DRAGON_BATTLE or serverType == ServerType.SERVER_DRAGON_BATTLE_GLOBAL or st then
        if st then
            WorldController:call("getInstance"):setProperty("dragonPlayoffHospitalAddition", ActivityController:call("getHealEff"))
        end

        local dragonAdd = WorldController:call("getInstance"):getProperty("dragonPlayoffHospitalAddition")
        local worldcupAdd = WorldController:call("getInstance"):getProperty("worldcupHospitalAdditionNum")
        if dragonAdd > 0 or worldcupAdd > 0 then
            if serverType == ServerType.SERVER_DRAGON_BATTLE_GLOBAL then
                total = total + worldcupAdd
            else
                total = total * dragonAdd / 100;
                total = total + ArmyController:call('getInstance'):call("getHospitalLimit")
            end
        end
    else
        total = total + ArmyController:call('getInstance'):call("getHospitalLimit")
    end

    if currentNum > total then
        currentNum = total
    end
    
    return currentNum
end


function BattleView:refreshMaxTroop(heroId)
    if self.m_battlType ~= PveTrainingType.PveHeroTraining then
        return 
    end
    self:unselectAll()
    self:generateDataPve(heroId)
    self:refreshOperation()
end


function BattleView:refreshOperation()
    local maxSoilderNum = self:getMaxSoilderNum()
    self.m_msg3Label:setString(CC_ITOA(math.floor(maxSoilderNum)))
    local loadNum = TroopsController:call("getInstance"):getProperty("m_curLoadNum")
    self.m_msg2Label:setString(CC_ITOA(loadNum))
    self.m_timeLabel:setString(CC_SECTOA(0))
    self:onClickQuickBtn(nil, cc.CONTROL_EVENTTYPE_TOUCH_DOWN)
    self:selectAll()
    TroopsController:call("getInstance"):call("changeArrTime")
    local cell_count = self:numberOfCellsInTableView()
    for index = 1, cell_count do
        local cell = self.m_tabView:cellAtIndex(index-1)
        if cell then
            cell:refresh()
        end
    end
    if self.m_tabView then
        self.m_tabView:reloadData()
    end
end


function BattleView:setChallengePopClose(ref)
    self.node_challengePop:setVisible(false)
end


-- 添加挑战预测和编队顺序
function BattleView:setChallengeState()
    if CCCommonUtilsForLua:isFunOpenByKey("troops_set_off") then
        --[awen-junyu] 获取配置种类标签的最大宽度
        local curWidth = 0.0
        local maxWidth = 0.0
        self.txt_challengeSpeed:setString(_lang("300030"))
        maxWidth = self.txt_challengeSpeed:getContentSize().width
        -- hxq杀戮战场中怪物优先代替负重优先
        local serverType = GlobalData:call("shared"):getProperty("serverType")
        if serverType == ServerType.SERVER_ANCESTRAL then
            self.txt_challengeLoad:setString(_lang("4510245"))--4510245=击杀野怪
            self.spr_challengeLoad:setVisible(false)
            self.spr_challengeMonster:setVisible(true)
        else
            self.txt_challengeLoad:setString(_lang("300031"))--300031=负重优先
            self.spr_challengeLoad:setVisible(true)
            self.spr_challengeMonster:setVisible(false)
        end
        curWidth = self.txt_challengeLoad:getContentSize().width
        if maxWidth < curWidth then
            maxWidth = curWidth
        end
        self.txt_challengeLevel:setString(_lang("300029"))--300029=等级优先
        curWidth = self.txt_challengeLevel:getContentSize().width
        if maxWidth < curWidth then
            maxWidth = curWidth
        end
        self.txt_challengeProp:setString(_lang("300032"))--300032=搭配优先
        curWidth = self.txt_challengeProp:getContentSize().width
        if maxWidth < curWidth then
            maxWidth = curWidth
        end
        self.node_marchType:setVisible(true)

        self.node_marchBtn:setPositionX(165)
        self.node_selectBtn:setPositionX(-45)

        if serverType == ServerType.SERVER_ANCESTRAL then
            self.node_marchType:setVisible(false)
            self:addPubgQuickBtn()
        end

        -- [awen-junyu] 自定义集结默认配兵
        if self.m_diyRally > 0 then
            local size = self.m_changlePopBg:getContentSize()
            self.m_changlePopBg:setPreferredSize(CCSize(size.width, size.height + 80 * self.m_diyRally))
            -- 系统推荐
            self.m_recSystemNode:setVisible(true);
            self.m_recSystemLb:setString(_lang("9441277"));
            curWidth = self.m_recSystemLb:getContentSize().width
            if maxWidth < curWidth then
                maxWidth = curWidth
            end
            
            if self.m_diyRally == 1 then
                self.m_recInitiatorNode:setVisible(false)
                self:changeSoilderType(SoldierChallengeType.SOILDERCHALLENGETYPE_RECOMMEND_SYSTEM)
            else
                -- 发起者推荐
                self.m_recInitiatorNode:setVisible(true)
                self.m_recInitiatorLb:setString(_lang("9441276"))
                curWidth = self.m_recInitiatorLb:getContentSize().width
                if maxWidth < curWidth then
                    maxWidth = curWidth
                end
                self:changeSoilderType(SoldierChallengeType.SOILDERCHALLENGETYPE_RECOMMEND_INITIATOR)
            end
        else
            self.m_recSystemNode:setVisible(false);
            self.m_recInitiatorNode:setVisible(false);
            -- local info = WorldController::getInstance()->m_cityInfo.find(m_targetIndex);
            local info = WorldController:call("getCityInfoByIndex", self.m_targetIndex)
            local info_cityType = nil
            local info_luaType = nil
            if info ~= nil then
                info_cityType = info:getProperty("cityType") -- 为了避免重复取值，使用info_cityType和info_luaType
                info_luaType = info:getProperty("luaType")
            end

            if info == nil then
                -- 等级优先
                self:changeSoilderType(SoldierChallengeType.SOILDERCHALLENGETYPE_Prop) -- SOILDERCHALLENGETYPE_LEVEL
                self.node_challenge:setVisible(false)
            else
                if (info_cityType == WorldCityType.ResourceTile -- 资源
                        or info_cityType == WorldCityType.tile_superMine -- 联盟超级矿
                        or info_cityType == WorldCityType.Resource_new
                        or info_cityType == WorldCityType.Resource_new_dragon
                        -- or info_luaType == WorldCityType.expedition_super_mine
                        -- or info_luaType == expedition_super_mine_sub  //远征超级矿取消负重优先:石彧
                    ) then -- 活动资源点
                    -- 负重优先
                    self:changeSoilderType(SoldierChallengeType.SOILDERCHALLENGETYPE_LOAD)
                else
                    -- 等级优先
                    self:changeSoilderType(SoldierChallengeType.SOILDERCHALLENGETYPE_Prop)  -- SOILDERCHALLENGETYPE_LEVEL
                end

                if (info_cityType == WorldCityType.FieldMonster or 
                    info_cityType == WorldCityType.FOUR_FIELD_MONSTER or 
                    info_cityType == WorldCityType.hero_maintheme_monster or 
                    info_cityType == WorldCityType.dark_civ_monster or 
                    (info_cityType == WorldCityType.LuaNewTile and info_luaType == WorldCityType.nationalwar_boss) or 
                    (info_cityType == WorldCityType.LuaNewTile and info_luaType == WorldCityType.craft_boss)) then
                    self.node_challenge:setVisible(true)
                else
                    self.node_challenge:setVisible(false)
                end
            end
        end
        
        -- [awen-junyu] 获取配置种类标签相对背景框的x位置
        local posX = self.m_recSystemLb:getPositionX() + self.m_recSystemLb:getParent():getPositionX() - self.m_changlePopBg:getPositionX()
        -- CCLog("BattleView:setChallengeState %f  %f  %f", maxWidth, self.m_changlePopBg:getContentSize().width, posX)
        local offset = posX + maxWidth - self.m_changlePopBg:getContentSize().width
        -- [awen-junyu] 当标签的宽度大于背景的宽度时，重新设置背景宽度
        if offset > 0 then
            local size = self.m_changlePopBg:getContentSize()
            self.m_changlePopBg:setPreferredSize(CCSize(size.width + offset + 20, size.height))
        end
    else
        self.node_marchType:setVisible(false)
        self.node_challenge:setVisible(false)

        self.node_marchBtn:setPositionX(126)
        self.node_selectBtn:setPositionX(-121)
    end
end

function BattleView:loadResourceForTable(time)
    self:updateInfo()
end

function BattleView:setAddBtnState()
    if CCCommonUtilsForLua:call("getStateEffectValueByNum", COMMAND_EFFECT) > FLT_EPSILON then
        self.m_addBtn:setVisible(false)
        self.m_addIcon:setVisible(false)
        self.m_addIcon1:setVisible(false)
        self.m_msg3Label:setColor(ccc3(86, 180, 29))
    else
        self.m_addBtn:setVisible(true)
        self.m_addIcon:setVisible(true)
        self.m_addIcon1:setVisible(true)
        self.m_msg3Label:setColor(ccc3(255, 247, 255))
        self.m_animationManager:runAnimationsForSequenceNamed("Default Timeline")
    end
    
    if self.m_battlType == PveTrainingType.PveHeroTraining and CCCommonUtilsForLua:isFunOpenByKey("test_hero_switch") then
        self.m_addBtn:setVisible(false)
        self.m_addIcon:setVisible(false)
        self.m_addIcon1:setVisible(false)
    end
    
    if ((self.m_battlType == ArenaBattleType.ArenaBattle and CCCommonUtilsForLua:isFunOpenByKey("ladder_expedition_limit"))
        or (self.m_battlType == ArenaBattleType.AllianceDuelBattle and CCCommonUtilsForLua:isFunOpenByKey("alliance_duel")))
        or (self.m_bType == MarchMethodType.FightDeath and CCCommonUtilsForLua:isFunOpenByKey("player_battle")) then
        self.m_addBtn:setVisible(false)
        self.m_addIcon:setVisible(false)
        self.m_addIcon1:setVisible(false)
    end
    
    -- 城市增益按钮4级以上显示 城堡装扮按钮6级以上显示
    local mainCityLv = FunBuildController:call("getMainCityLv")
    local bBtnVisible = (mainCityLv>=5) and CCCommonUtilsForLua:isFunOpenByKey("march_buff_open")
    self.m_labelCityLv:setString(_lang("104953"))
    self.m_nodeCityLv:setVisible(bBtnVisible)
    self.m_labelDragonWords:setString(_lang("160297"))
    
    --一键换装
    --【awen】换装按钮
    if CCCommonUtilsForLua:isFunOpenByKey("user_onekey_reload_switch") then
        self.node_oneKey:setVisible(true)
    elseif (GlobalData:call("getEndTimeByStatus", 509061) ~= 0 and CCCommonUtilsForLua:isFunOpenByKey("user_onekey_reload")) then  -- 5090061 一键切换
        self.node_oneKey:setVisible(true)
    else
        self.node_oneKey:setVisible(false)
    end

    self.node_oneKey:setPositionX(-230)
    if not GlobalDataCtr.checkIsGreenServer() then
        self.m_soildersSetNode:setVisible(true)
        self.m_soildersSetNode:setPositionX(-300)
    end

    -- 隐藏龙语、城市增益、一键buff等
    self.m_nodeDragonWords:setVisible(false)
    self.m_nodeCityLv:setVisible(false)
    self.node_oneKeyBuff:setVisible(false)
    -- if CCCommonUtilsForLua:isFunOpenByKey("onekey_buff") then
    --     self.node_oneKeyBuff:setVisible(true)
    -- else
    --     self.node_oneKeyBuff:setVisible(false)
    -- end
    
    if CCCommonUtilsForLua:isFunOpenByKey("dragonwords_march") then
        self.m_nodeDragonWords:setVisible(true)
        local info = FunBuildController:call("getInstance"):call("getBuildNumByType", FUN_BUILD_KNIGHT) -- 是否有龙语神殿建筑
        if info < 1 then
            self.m_dragonWordsBtn:setColor({120,120,120});
        end
    else
        self.m_nodeDragonWords:setVisible(false);
    end

    -- if not self.m_nodeCityLv:isVisible() then
    --     self.m_nodeDragonWords:setPosition(self.m_nodeCityLv:getPosition())
    -- end

    -- if((self.m_nodeDragonWords:isVisible() == false) and (self.node_oneKey:isVisible() == true)) then
    --     self.node_oneKey:setPositionX(self.node_oneKey:getPositionX()+80)
    --     self.node_oneKeyBuff:setPositionX(self.node_oneKeyBuff:getPositionX()+80)
    -- end

    -- if (CCCommonUtilsForLua:isFunOpenByKey("new_go_battle")) then
    --     self.m_nodeDragonWords:setVisible(false)
    --     self.m_nodeCityLv:setVisible(true)
    --     self.m_soildersSetNode:setVisible(true)

    --     self.m_nodeCityLv:setPositionX(240)
    --     self.node_oneKey:setPositionX(-230)
    --     self.node_oneKeyBuff:setPositionX(120)
    --     self.m_soildersSetNode:setPositionX(-300)
    -- end

    if (self.m_battlType == PveTrainingType.PveHeroTraining and CCCommonUtilsForLua:isFunOpenByKey("test_hero_switch")) then
        self.m_dragonSprCover:setVisible(true)
        self.m_dragonBgLeft:setColor(cc.GRAY)
        self.m_dragonBgRight:setColor(cc.GRAY)
        
        if (self.m_dragonSelectNode) then
            self.m_dragonSelectNode:setVisible(false)
        end

        if (self.m_dragonBgX) then
            self.m_dragonBgX:setVisible(false)
        end

        self.m_dragonSpr:setVisible(false)
        self.m_dragonSprCover:setVisible(false)
        self.m_delDragonBtn:setVisible(false)

        if (self.node_oneKey) then
            self.node_oneKey:setVisible(false)
        end

        if (self.node_oneKeyBuff) then
            self.node_oneKeyBuff:setVisible(false)
        end

        if (self.m_nodeDragonWords) then
            self.m_nodeDragonWords:setVisible(false)
        end

        if (self.m_nodeCityLv) then
            self.m_nodeCityLv:setVisible(false)
        end

        self.m_formation1:setVisible(false)
        self.m_formation2:setVisible(false)
        self.m_formation3:setVisible(false)
        self.m_formation4:setVisible(false)
        self.m_formation5:setVisible(false)
        self.m_formation6:setVisible(false)
        self.m_formation7:setVisible(false)
        self.m_formation8:setVisible(false)
        self.m_formation9:setVisible(false)
        self.m_formation10:setVisible(false)
        self.m_formation1:setPositionX(self.m_formation5:getPositionX())

        self:updateDragonRootNode(false)
        self:updateBookRootNode(false)
        self.m_nodeSkill:setVisible(false)

        if self.isEndless == "1" then
            self.m_soildersSetNode:setVisible(false)
        end

    end
    
    --【Awen】先祖战场屏蔽部分按钮
    local serverType = GlobalData:call("shared"):getProperty("serverType")
    if serverType == ServerType.SERVER_ANCESTRAL then
        self.m_addBtn:setVisible(false)
        self.m_addIcon:setVisible(false)
        self.m_addIcon1:setVisible(false)
        
        if (self.node_oneKey) then
            self.node_oneKey:setVisible(false)
        end
        
        if (self.node_oneKeyBuff) then
            self.node_oneKeyBuff:setVisible(false)
        end

        if (self.m_nodeDragonWords) then
            self.m_nodeDragonWords:setVisible(false);
        end

        if (self.m_nodeCityLv) then
            self.m_nodeCityLv:setVisible(false)
        end

        if(self.m_formationNode) then
            self.m_formationNode:setVisible(false)
        end

        self.m_dragonBgX:setVisible(false)
        self.m_dragonBtn:getParent():setVisible(false)
        
        -- 显示快速选择按钮
        if (self.m_formationNode2 and CCCommonUtilsForLua:isFunOpenByKey("war_trial_queue")) then
            self.m_formationNode2:setVisible(true)
        end
    end
end

function BattleView:generateData()
    TroopsController:call("getInstance"):setProperty("m_tmpFreeSoldiers", {})
    TroopsController:call("getInstance"):setProperty("m_tmpBattleInfos", {})
    TroopsController:call("getInstance"):setProperty("m_tmpConfSoldiers", {})
    self.m_tmpArray = {}

    local b_angel_army = isFunOpenByKey("angel_army")
    local armyId_14 = {}
    if b_angel_army then
        if self.angelArmyId_format then
            armyId_14[self.angelArmyId_format] = true
        else
            local tempArmyId = require("game.army.angel.AngelArmyController").getInstance():getSettingArmy(1)
            if tempArmyId then
                armyId_14[tempArmyId] = true
            end
        end
    end

    local b_night_army = isFunOpenByKey("night_army")
    if b_night_army then
        if self.nightArmyId_format then
            armyId_14[self.nightArmyId_format] = true
        else
            local tempArmyId = require("game.army.angel.AngelArmyController").getInstance():getSettingArmyByGroup(1, SpecialArmyGroup.NIGHT_ARMY)
            if tempArmyId then
                armyId_14[tempArmyId] = true
            end
        end
    end

    local armyList = GlobalData:call("shared"):getProperty("armyList") 
    for key, value in pairs(armyList) do
        if value:getProperty("free") > 0 and value:getProperty("isArmy") and value:getProperty("armyLevel") >= self.m_lvSet - 1 then
            local isAdd14Army = true
            if b_angel_army or b_night_army then
                if value:getProperty("armyLevel") == 13 then
                    if not armyId_14[key] then
                        isAdd14Army = false
                    end
                end
            end
            
            if isAdd14Army then
                local tmpFreeSoldiers = TroopsController:call("getInstance"):getProperty("m_tmpFreeSoldiers")
                local tmpConfSoldiers = TroopsController:call("getInstance"):getProperty("m_tmpConfSoldiers")

                tmpFreeSoldiers[key] = value:getProperty("free")
                tmpConfSoldiers[key] = value:getProperty("free")

                TroopsController:call("getInstance"):setProperty("m_tmpFreeSoldiers", tmpFreeSoldiers)
                TroopsController:call("getInstance"):setProperty("m_tmpConfSoldiers", tmpConfSoldiers)

                local addFlag = false
                for tmp_index, tmp_value in ipairs(self.m_tmpArray) do
                    local armyId = tmp_value
                    local armyLevel = atoi(CCCommonUtilsForLua:getPropByIdGroup("arms", armyId, "level"))
                    if armyLevel - 1 < value:getProperty("armyLevel") then
                        table.insert(self.m_tmpArray, tmp_index, key)  -- self.m_tmpArray:insertObject(CCString:create(key), index)
                        addFlag = true
                        break
                    end
                end

                if not addFlag then
                    table.insert(self.m_tmpArray, key)  -- self.m_tmpArray:addObject(CCString:create())
                end
            end
        end
    end
end

-- 按指定字段排序
function BattleView:sortTmpArrayByLv()
    local compare = function (armgId1, armgId2)
        local lvRank1 = tonumber(CCCommonUtilsForLua:getPropByIdGroup("arms", armgId1, "level_rank")) or 0
        local lvRank2 = tonumber(CCCommonUtilsForLua:getPropByIdGroup("arms", armgId2, "level_rank")) or 0
        -- true代表升序 false降序
        if self.m_lvOrderSet then
            return lvRank1 < lvRank2
        else 
            return lvRank2 < lvRank1
        end
    end
    
    table.sort(self.m_tmpArray, compare)
end

function BattleView:sortTmpArrayByType()
    local compare = function (armgId1, armgId2)
        local armRank1 = tonumber(CCCommonUtilsForLua:getPropByIdGroup("arms", armgId1, "arms_rank")) or 0
        local armRank2 = tonumber(CCCommonUtilsForLua:getPropByIdGroup("arms", armgId2, "arms_rank")) or 0
        if self.m_typeOrderSet then
            return armRank1 < armRank2
        else 
            return armRank2 < armRank1
        end
    end
    
    table.sort(self.m_tmpArray, compare)
end

function BattleView:sortTmpArrayByNum()
    local compare = function (armgId1, armgId2)
        local armyList = GlobalData:call("shared"):getProperty("armyList")
        local armNum1 = armyList[armgId1]:getProperty("free")
        local armNum2 = armyList[armgId2]:getProperty("free")
        if self.m_numOrderSet then
            return armNum1 < armNum2
        else 
            return armNum2 < armNum1
        end
    end
    
    table.sort(self.m_tmpArray, compare)
end


function BattleView:updateInfo()
    self.m_tabView:reloadData()
end


function BattleView:onEnter()
    -- CCNode::onEnter();
    -- 更新天赋组显示
    self.m_marchBtn:setEnabled(true)
    self:updateSkillBtnTitle()

    self:setTouchEnabled(true)
    self:setAddBtnState()
    self:updateLoadInfo(nil)

    if self.m_bType == MarchMethodType.MethodRally 
        or (self.m_bType == MarchMethodType.MethodTeamRally and self.m_wtIndex > 0) then
        self.ui.m_labelTitle:setString(_lang("108582"))  --108582=集结
    elseif self.m_bType == MarchMethodType.MethodUnion 
        or self.m_bType == MarchMethodType.MethodTeamUnion then
        self.ui.m_labelTitle:setString(_lang("108582"))  --108582=集结
    elseif self.m_bType == MarchMethodType.MethodYuanSolider then
        self.ui.m_labelTitle:setString(_lang("115176"))  --115176=士兵援助
    elseif self.m_bType == MarchMethodType.DarkCivOne or self.m_bType == MarchMethodType.DarkCivThree then
        self.ui.m_labelTitle:setString(_lang("108582"))  --108582=集结
    elseif self.m_bType == MarchMethodType.FightDeath then
        self.ui.m_labelTitle:setString(_lang("9900230"))  --9900230=编辑阵容
    end

    if ((self.m_bType == MarchMethodType.MethodRally or 
        self.m_bType == MarchMethodType.MethodUnion or 
        self.m_bType == MarchMethodType.MethodTeamRally or
        self.m_bType == MarchMethodType.MethodTeamUnion or 
        self.m_bType == MarchMethodType.DarkCivOne or 
        self.m_bType == MarchMethodType.DarkCivThree) 
    and self.m_isSuperRally == 1) then
        UIComponent:call("getInstance"):call("showPopupView", 1)
        self.m_svipHelpBtn:setVisible(true)
        self.m_svipLb:setVisible(true)
        self.m_svipLb:setString(_lang("163000"))
    else
        self.m_svipHelpBtn:setVisible(false)
        self.m_svipLb:setVisible(false)
    end

    TroopsController:call("getInstance"):call("changeArrTime")
    self:makeArrTime(nil)
    registerScriptObserver(self, self.updateArmyNumber      , MessageType.MSG_TROOPS_BACK)
    registerScriptObserver(self, self.updateLoadInfo        , MessageType.MSG_TROOPS_BATTLE_LOAD)
    registerScriptObserver(self, self.makeArrTime           , MessageType.MSG_TROOPS_TIME)
    registerScriptObserver(self, self.setHero               , MessageType.MSG_BATTLEHERO_SELECTED_HERO)
    registerScriptObserver(self, self.setDragon             , MessageType.MSG_BATTLEHERO_SELECTED_DRAGON)
    registerScriptObserver(self, self.setChallengePopClose  , MessageType.MSG_CLOSE_CHALLENGEPOPVIEW)
    registerScriptObserver(self, self.onCorrectMarchNum     , MessageType.MSG_CORRECT_MARCH_NUM)
    registerScriptObserver(self, self.cancelGuardCallback   , MessageType.MSG_DRAGON_CANCEL_GUARD)
    registerScriptObserver(self, self.setAormationInfo      , MessageType.MSG_BATTLEVIEW_AORMATION)
    registerScriptObserver(self, self.confirmBattle         , MessageType.MSG_BATTLEVIEW_MARCH)
    registerScriptObserver(self, self.soilderSetUpdate      , MessageType.MSG_SOILDERSET_UPDATE)
    registerScriptObserver(self, self.checkCanMarch         , MessageType.MSG_WORLD_MARCH_CHECK_CALLBACK)
    registerScriptObserver(self, self.callSuccess           , MessageType.MSG_WORLD_MARCH_CALLBACK)
    registerScriptObserver(self, self.callCloseSelf         , MessageType.MSG_WORLD_MARCH_CALLBACK_CLOSE)
    registerScriptObserver(self, self.updateSkillBtn        , "GeneralSkillSwitch_back")
    registerScriptObserver(self, self.onUpdateBuffIcon      , MessageType.MSG_BATTLE_VIEW_BUFF)
    registerScriptObserver(self, self.updateBuffIcon        , MessageType.MSG_SEND_BATTLE_VIEW_BUFF_CMD)
    registerScriptObserver(self, self.updateParams          , MessageType.MSG_UPDATE_BATTLE_PARAMS)
    registerScriptObserver(self, self.updateMarchTime       , MessageType.MSG_COMMERCIAL_MARCHTIME)
    registerScriptObserver(self, self.updateBuffIcon        , MSG_ITME_STATUS_TIME_CHANGE)
    registerScriptObserver(self, self.resetArmyIdFormat     , "BattleView:resetArmyIdFormat")
    self:refreshArmyMax(nil)
    
    if(getWorldTime() - TroopsController:call("getInstance"):getProperty("m_checkMarchNumTime") < 60*30) then  -- 小于30分钟
        -- 发送出征上限的请求
    end
end


function BattleView:onExit()
    self:setTouchEnabled(false)
    unregisterScriptObserver(self, MessageType.MSG_TROOPS_BACK)
    unregisterScriptObserver(self, MessageType.MSG_TROOPS_BATTLE_LOAD)
    unregisterScriptObserver(self, MessageType.MSG_TROOPS_TIME)
    unregisterScriptObserver(self, MessageType.MSG_BATTLEHERO_SELECTED_HERO)
    unregisterScriptObserver(self, MessageType.MSG_BATTLEHERO_SELECTED_DRAGON)
    unregisterScriptObserver(self, MessageType.MSG_CLOSE_CHALLENGEPOPVIEW)
    unregisterScriptObserver(self, MessageType.MSG_CORRECT_MARCH_NUM)
    unregisterScriptObserver(self, MessageType.MSG_DRAGON_CANCEL_GUARD)
    unregisterScriptObserver(self, MessageType.MSG_BATTLEVIEW_AORMATION)
    unregisterScriptObserver(self, MessageType.MSG_BATTLEVIEW_MARCH)
    unregisterScriptObserver(self, MessageType.MSG_SOILDERSET_UPDATE)
    unregisterScriptObserver(self, MessageType.MSG_WORLD_MARCH_CHECK_CALLBACK)
    unregisterScriptObserver(self, MessageType.MSG_WORLD_MARCH_CALLBACK)
    unregisterScriptObserver(self, MessageType.MSG_WORLD_MARCH_CALLBACK_CLOSE)
    unregisterScriptObserver(self, "GeneralSkillSwitch_back")
    unregisterScriptObserver(self, MessageType.MSG_BATTLE_VIEW_BUFF)
    unregisterScriptObserver(self, MessageType.MSG_SEND_BATTLE_VIEW_BUFF_CMD)
    unregisterScriptObserver(self, MessageType.MSG_UPDATE_BATTLE_PARAMS)
    unregisterScriptObserver(self, MessageType.MSG_COMMERCIAL_MARCHTIME)
    unregisterScriptObserver(self, MSG_ITME_STATUS_TIME_CHANGE)
    unregisterScriptObserver(self, "BattleView:resetArmyIdFormat")
    -- CCNode::onExit();
    ----------
    ArmyController:call("getInstance"):setProperty("LoadSt", false) --  ArmyController::getInstance()->LoadSt = false;
    ----------
    ArmyController:call("getInstance"):call("clearCache");
    self:setChallengePopClose(nil)
    self.m_maxForceNum = -1 -- 执行onenter 的时候重新计算上限
end


function BattleView:refreshArmyMax(obj)
    if not self.m_notFirstOpen and (self.m_saveArenaFormation or self.m_saveFamFormation) then
        self.m_notFirstOpen = true
        self:initFromLastFormation()
    else
        self:refreshOperation()
    end
end

function BattleView:onTouchBegan(x, y)
    if isTouchInside(self.pit_tipTouch, x, y) and self.pit_tipTouch:isVisible() then
        if  not self.m_tipNode then
            self.m_tipNode = CommonItemDescNode:call("create", "", "", false)
            self:addChild(self.m_tipNode)
        end
        self.m_tipNode:setVisible(true)
        local nameMsg = _lang("114346") -- 114346=受伤部队情况
        self.m_tipNode:setItemNameAndContent(nameMsg, self.m_texShowTips)
        local offy = self.m_tipNode:getContentSize().height/2+50
        self.m_tipNode:setPosition(self:convertToNodeSpace(cc.p(x,y)) + ccp(0, offy))
    end
    return true
end

function BattleView:onTouchEnded(x, y)
    if self.m_tipNode then
        self.m_tipNode:setVisible(false)
    end
    self.m_externBtnNode:setVisible(false)
    self:setChallengePopClose(nil)
end

function BattleView:generalSelect()

end

function BattleView:getDarkCivPower(  )
    local _idx = -1;
    if self.m_bType == MarchMethodType.DarkCivOne then
        _idx = 1
    elseif self.m_bType == MarchMethodType.DarkCivTwo then
        _idx = 2
    elseif self.m_bType == MarchMethodType.DarkCivThree then
         _idx = 3
    elseif self.darkCiv>0 then
        _idx = self.darkCiv
    end
    if _idx <= 0 then
        return 0
    end
    local tmpUsePower = 0
    local sPowers = CCCommonUtilsForLua:getPropByIdGroup("data_config", "dark_civilization", "k3")
    if sPowers ~= nil and sPowers ~= "" then
        sPowers = string.split(sPowers, '|')
        if _idx <= #sPowers then
            tmpUsePower = tonumber(sPowers[_idx])
        end
    end
    return tmpUsePower
end

function BattleView:updateLoadInfo(obj)
    self:setChallengePopClose(obj)
    local loadNum = TroopsController:call("getInstance"):getProperty("m_curLoadNum")

    local info = WorldController:call("getCityInfoByIndex", self.m_targetIndex)
    local type    = -1
    local luaType = -1
    local info_cityType = nil
    local info_luaType = nil
    if info ~= nil then
        info_cityType = info:getProperty("cityType") -- 使用type和luaType的地方，不一定判定info非空，所以type和luaType不一定存的是info中的值。为了避免重复取值，使用info_cityType和info_luaType
        info_luaType = info:getProperty("luaType")
        type    = info_cityType
        luaType = info_luaType
    end

    if(info ~= nil and (type == WorldCityType.ResourceTile or type == WorldCityType.tile_superMine or type == WorldCityType.Resource_new 
            or type == WorldCityType.Resource_new_dragon or luaType == WorldCityType.expedition_super_mine or luaType == WorldCityType.expedition_super_mine_sub)) then
        local numerator = 1
        if type == WorldCityType.ResourceTile then
            local resource_type = info:getProperty("resource"):getProperty("type")
            numerator = CCCommonUtilsForLua:call("getResourceLoadByType", resource_type);
        elseif type == WorldCityType.tile_superMine then
            local mine_type = info:getProperty("m_superMineInfo"):getProperty("type")
            numerator = CCCommonUtilsForLua:call("getResourceLoadByType", mine_type);
        elseif type == WorldCityType.Resource_new then
            -- 奇迹宝藏
            local newResourceInfo = info:getProperty("m_newResourceInfo")
            local itemId = newResourceInfo:getProperty("itemId")
            if (itemId ~= "") then
                numerator = newResourceInfo:getProperty("conversion")
                -- 奇迹石月卡购买后，负重加倍
                local reciverQIJISHI = CCDictionary:create()
                -- LuaController::getInstance()->fireEventRef("checkIsBuySpecialMonthCard", reciverQIJISHI);
                MonthCardController.getInstance():checkIsBuySpecialMonthCard(reciverQIJISHI)
                
                if (reciverQIJISHI:objectForKey("isBuy")) then
                    local isBuyQijishiNum = reciverQIJISHI:valueForKey("isBuy"):getCString() -- 是否购买了奇迹石
                    if (isBuyQijishiNum == "1") then
                        numerator = math.floor(numerator / 2)
                    end
                end
            else
                numerator = newResourceInfo:getProperty("type")   -- CCCommonUtils:getResourceLoadByType(info->second.m_newResourceInfo->type)
            end
        elseif (type == WorldCityType.Resource_new_dragon) then
            -- 巨龙宝藏
            local newResourceInfo = info:getProperty("m_newResourceInfo")
            numerator = newResourceInfo:getProperty("conversion")
        elseif (luaType == WorldCityType.expedition_super_mine or luaType == WorldCityType.expedition_super_mine_sub) then
            numerator = tonumber(CCCommonUtilsForLua:getPropByIdGroup("data_config", "super_steel_mine_config", "k1"))
        end
        
        if (numerator == 0) then
            -- dump("BattleView:updateLoadInfo - zero!!!")
            loadNum = 0
        else
            loadNum = math.floor(loadNum / numerator)
        end
        
        if(loadNum == 0) then
            self.m_msg2Label:setColor(cc.RED)
            local fadeOut = cc.FadeTo:create(0.6, 127)
            local fadeIn = cc.FadeTo:create(0.6, 255)
            local delay = cc.DelayTime:create(2.0)
            local action = cc.Sequence:create(fadeOut, fadeIn, delay)
            self.m_msg2Label:runAction(cc.RepeatForever:create(action))
        else
            self.m_msg2Label:stopAllActions()
            self.m_msg2Label:setOpacity(255)
            self.m_msg2Label:setColor(ccc3(255, 255, 255))
        end
    end
    self.m_helpBtn:setVisible(true)
    self.m_stamineNode:setVisible(false)
    if (self.m_targetType == WorldCityType.ActBossTile or self.m_targetType == WorldCityType.AllianceBoss
        or (type == WorldCityType.FieldMonster
            or type == WorldCityType.FOUR_FIELD_MONSTER  -- 4格野怪
            or type == WorldCityType.hero_maintheme_monster
            or type == WorldCityType.dark_civ_monster
            or type == WorldCityType.FOUR_FIELD_MONSTER_RANGE
            or type == WorldCityType.DEFENSOR
            or type == WorldCityType.MonsterTile
            or type == WorldCityType.MonsterRange
            or type == WorldCityType.ActBossTile
            or type == WorldCityType.AllianceBoss
            or type == WorldCityType.Barbarian
            or type == WorldCityType.tile_HpWorldBoss
            or self.m_battlType == PveTrainingType.PveHeroTraining
            or self.m_battlType == TreasureFamType.TreasureFamMonster
            or self.m_battlType == TreasureFamType.TreasureFamMine
            )
        or (type == WorldCityType.LuaNewTile and luaType == WorldCityType.city_barracks)
        or (type == WorldCityType.LuaNewTile and luaType == WorldCityType.nationalwar_boss)
        or (type == WorldCityType.LuaNewTile and luaType == WorldCityType.nationalwar_boss_range)
        or (type == WorldCityType.LuaNewTile and luaType == WorldCityType.craft_boss)
        or (type == WorldCityType.LuaNewTile and (luaType == WorldCityType.city_barracks or luaType == WorldCityType.SuperCampsiteRally))
        or (type == WorldCityType.LuaNewTile and (luaType == WorldCityType.dark_civilization)
        or (self.m_targetType == WorldCityType.dark_civilization)) 
        ) then

        self.m_iconContainer:removeAllChildren()
        local sprite = CCLoadSprite:createSprite("Ui_tili.png")
        sprite:setScale(0.65)
        self.m_iconContainer:addChild(sprite)

        local str = _lang("3100112")
        
        if self.m_targetType == WorldCityType.ActBossTile or type == WorldCityType.ActBossTile then
            
            local fieldMonsterInfo = info and info:call("getFieldMonsterInfo")
            if fieldMonsterInfo then
                str = str..CCCommonUtilsForLua:getPropById(fieldMonsterInfo:getProperty("monsterId"), "usePower")
            else
                str = str..CC_ITOA(GlobalData:call("shared"):getProperty("worldConfig"):getProperty("boss_decr"))
            end
        elseif self.m_targetType == WorldCityType.AllianceBoss or type == WorldCityType.AllianceBoss then
            -- self.titleCommonFunc[self.m_targetType]()
            if self.m_allianceBossId ~= nil and self.m_allianceBossId ~= "" then
                str = str..CCCommonUtilsForLua:getPropById(tostring(self.m_allianceBossId), "power")
            elseif info then
                local fieldMonsterInfo = info:call("getFieldMonsterInfo")
                str = str..CCCommonUtilsForLua:getPropById(fieldMonsterInfo:getProperty("monsterId"), "power")
            end
        elseif self.m_targetType == WorldCityType.Barbarian then
            str = str..CCCommonUtilsForLua:getPropById(info:getProperty("m_barbarianInfo"):getProperty("barbarianId"), "usePower")
        elseif self.m_targetType == WorldCityType.tile_HpWorldBoss or type == WorldCityType.tile_HpWorldBoss then
            local info_type = info:getProperty("hpWorldBossInfo"):getProperty("type")
            local bbinfo = WorldBossController:call("getInstance"):call("getBossInfoByType", tonumber(info_type))
            if bbinfo then
                str = str..CC_ITOA(bbinfo:getProperty("HpBoss_stamineCost"))
            end
        elseif (type == WorldCityType.MonsterRange or type == WorldCityType.FieldMonster or type == WorldCityType.FOUR_FIELD_MONSTER 
                or type == WorldCityType.FOUR_FIELD_MONSTER_RANGE or type == WorldCityType.hero_maintheme_monster or type == WorldCityType.dark_civ_monster) then
            local usePower = WorldController:call("getInstance"):call("getMonsterUsePower", self.m_targetIndex)
            if usePower == 0 then
                usePower = GlobalData:call("shared"):getProperty("worldConfig"):getProperty("stamineCostPerTime")
            end
            str = str..CC_ITOA(usePower)
        elseif type == WorldCityType.DEFENSOR then
            local tmpUsePower = 0
            local tdic = CCDictionary:create()
            tdic:setObject(CCInteger:create(self.m_targetIndex), "index")
            -- guiCommonLocal.on_getUsePower(tdic) --- !!!!! LuaController::getInstance()->fireEventRef("getUsePower", &tdic);
            tmpUsePower = tdic:valueForKey("power"):intValue()
            str = str..CC_ITOA(tmpUsePower)
        elseif type == WorldCityType.LuaNewTile and luaType == WorldCityType.city_barracks then
            local tmpUsePower = GlobalData:call("shared"):getProperty("worldConfig"):getProperty("city_barracks_userPower")
            str = str..CC_ITOA(tmpUsePower)
        elseif type == WorldCityType.LuaNewTile and (luaType == WorldCityType.nationalwar_boss or luaType == WorldCityType.nationalwar_boss_range and luaType == WorldCityType.craft_boss) then
            local usePower = WorldController:call("getInstance"):call("getMonsterUsePower", self.m_targetIndex)
            if usePower == 0 then
                usePower =  GlobalData:call("shared"):getProperty("worldConfig"):getProperty("stamineCostPerTime")
            end
            str = str..CC_ITOA(usePower)
        elseif type == WorldCityType.LuaNewTile and luaType == WorldCityType.SuperCampsiteRally then
            local tmpUsePower = SuperCampAttackStamina
            local sPower = CCCommonUtilsForLua:getPropByIdGroup("data_config", "super_camp", "k4")
            if sPower ~= nil and sPower ~= "" then
                tmpUsePower = tonumber(sPower)
            end
            str = str..CC_ITOA(tmpUsePower);
        elseif type == WorldCityType.LuaNewTile and luaType == WorldCityType.dark_civilization or self.m_targetType == WorldCityType.dark_civilization then
            local tmpUsePower = self:getDarkCivPower()
            str = str..CC_ITOA(tmpUsePower);
        end
        self.m_msg2Label:setString(str)
        self.m_helpBtn:setVisible(false)
        self.m_stamineNode:setVisible(true)
    else
        local loadInfo = CC_CMDITOA(loadNum)
        self.m_msg2Label:setString(loadInfo)
    end
    -- 崩溃修改 by sxy
    if (info ~= nil) then
        if (type == WorldCityType.ResourceBattleTile or WorldCityType.NewResourceBattleTile == type 
            or (info_cityType == WorldCityType.LuaNewTile and info_luaType == WorldCityType.NeutralLand_Resource) 
            or (info_cityType == WorldCityType.LuaNewTile and info_luaType == WorldCityType.nationalwar_mine)
        ) then
            self.m_helpBtn:setVisible(false)
        end
    end
    local playertype = PlayerType.PlayerNone
    local isHomePlace = false
    if (info ~= nil) then
        local playerInfo = info:getProperty("playerInfo")
        if playerInfo ~= nil then
            playertype = playerInfo:getProperty("type")
        end
        isHomePlace = info:getProperty("m_isMyAArea")
    end
    local isAllianceCity = (type == WorldCityType.CityTile and playertype ~= PlayerType.PlayerOther)
    local isOriginTile = (type == WorldCityType.OriginTile and self.m_targetType ~= WorldCityType.dark_civilization)--加入集结时原点判断有问题

    if GlobalData:call("shared"):getProperty("serverType") == ServerType.SERVER_WORLD_CRAFT then isOriginTile = false end

    local isHomeAllianceArea = (type == WorldCityType.Tile_allianceArea)
    local isHomeTower = (type == WorldCityType.tile_tower and isHomePlace)
    local isThroneFight = (type == WorldCityType.Throne)
    if (isAllianceCity or isOriginTile or isHomeAllianceArea or isHomeTower or isThroneFight) then
        self.m_iconContainer:setVisible(false)
        self.m_msg2Label:setVisible(false)
        self.m_helpBtn:setVisible(false)
    end
    
    if (info ~= nil and (info_cityType == WorldCityType.tile_superMine or info_cityType == WorldCityType.Resource_new or info_cityType == WorldCityType.Resource_new_dragon)) then
        local tempType = -1
        if (info_cityType == WorldCityType.tile_superMine) then
            tempType = info:getProperty("m_superMineInfo"):getProperty("type") --info->second.m_superMineInfo->type;
        elseif (info_cityType == WorldCityType.Resource_new) then
            local newResourceInfo = info:getProperty("m_newResourceInfo")
            local itemId = newResourceInfo:getProperty("itemId")
            if (itemId ~= "") then
                tempType = tonumber(itemId);
            else
                tempType = info:getProperty("m_newResourceInfo"):getProperty("type")
            end
        elseif (info_cityType == WorldCityType.Resource_new_dragon) then
            tempType = tonumber(WorldController:call("getInstance"):call("dragonhome_item_resource"))
        end

        if (tempType ~= -1) then
            self.m_iconContainer:removeAllChildren()
            if (tempType > 1000) then
                CCCommonUtilsForLua:createGoodsIcon(tempType, self.m_iconContainer, CCSize(50, 50))
                self.m_iconContainer:removeChildByTag(GOODS_BG_TAG)
            else
                local sprite = CCLoadSprite:createSprite(CCCommonUtilsForLua:call("getResourceIconByType", tempType))
                CCCommonUtilsForLua:call('setSpriteMaxSize', sprite, 40)
                self.m_iconContainer:addChild(sprite)
            end
        end
    end
    
    local total = 0
    self.m_armyPower = 0
    local battleInfos = TroopsController:call("getInstance"):getProperty("m_tmpBattleInfos")
    local armyList = GlobalData:call("shared"):getProperty("armyList")
    for key, value in pairs(battleInfos) do
        if (value > 0) then
            total = total + value
            if (armyList[key] ~= nil) then
                local armyPower = armyList[key]:getProperty("power")
                self.m_armyPower = self.m_armyPower + armyPower * value
            end
        end
    end

    self:updateFightPower()
    
    --战斗预测
    self:setChallengeJudgement()

    -- 炮弹阻断提示
    -- setArtilleryPrevent();
    -- [awen-junyu] 自定义集结总百分比
    if (self.m_diyRally > 0) then
        local maxSoilder = self:getMaxSoilderNum()
        local rate = 100.0 * total / maxSoilder
        self.m_msg1Label:setString(string.format("%.2f%%/", rate))   -- CCString:createWithFormat("%.2f%%/", rate)->getCString());
        self.m_msg3Label:setString(CC_ITOA(math.floor(maxSoilder)));
    else
        self.m_msg1Label:setString(CC_ITOA(total).."/");
        local maxSoilder = self:getMaxSoilderNum()
        self.m_msg3Label:setString(CC_ITOA(math.floor(maxSoilder)));
    end
    
    local serverType = GlobalData:call("shared"):getProperty("serverType")
    if ((self.m_battlType == PveTrainingType.PveHeroTraining and CCCommonUtilsForLua:isFunOpenByKey("test_hero_switch"))
        or (GuideController:call("isInTutorial") and GuideController:call("getGuideMonster"))
        or (info_cityType == WorldCityType.LuaNewTile and info_luaType == WorldCityType.ANNUA_SEVEN_NPC) 
        or (serverType == ServerType.SERVER_ANCESTRAL)) then --【Awen】先祖战场出征界面屏蔽此UI

        self.m_iconContainer:setVisible(false)
        self.m_msg2Label:setVisible(false)
        self.m_stamineNode:setVisible(false)
        self.m_helpBtn:setVisible(false)
    end

    if (self.m_civiBuildTag) then
        self:refreshCiviRate()
    end
end

--------- 可以考虑单独写
function BattleView:initTreasureFamMineInfo() -- 秘境矿脉PVP
    TroopsController:call("getInstance"):setProperty("m_tmpFreeSoldiers", {})
    TroopsController:call("getInstance"):setProperty("m_tmpBattleInfos", {})
    TroopsController:call("getInstance"):setProperty("m_tmpConfSoldiers", {})
    self.m_tmpArray = {}

    local b_angel_army = isFunOpenByKey("angel_army")
    local armyId_14 = {}
    if b_angel_army then
        if self.angelArmyId_format then
            armyId_14[self.angelArmyId_format] = true
        else
            local tempArmyId = require("game.army.angel.AngelArmyController").getInstance():getSettingArmy(1)
            if tempArmyId then
                armyId_14[tempArmyId] = true
            end
        end
    end

    local b_night_army = isFunOpenByKey("night_army")
    if b_night_army then
        if self.nightArmyId_format then
            armyId_14[self.nightArmyId_format] = true
        else
            local tempArmyId = require("game.army.angel.AngelArmyController").getInstance():getSettingArmyByGroup(1, SpecialArmyGroup.NIGHT_ARMY)
            if tempArmyId then
                armyId_14[tempArmyId] = true
            end
        end
    end

    local armyList = GlobalData:call("shared"):getProperty("armyList")
    for key, army_value in pairs(armyList) do
        if army_value:getProperty("free") > 0 and army_value:getProperty("isArmy") then
            local isAdd14Army = true
            if b_angel_army or b_night_army then
                if army_value:getProperty("armyLevel") == 13 then
                    if not armyId_14[key] then
                        isAdd14Army = false
                    end
                end
            end
            
            if isAdd14Army then
                local tmpFreeSoldiers = TroopsController:call("getInstance"):getProperty("m_tmpFreeSoldiers")
                local tmpConfSoldiers = TroopsController:call("getInstance"):getProperty("m_tmpConfSoldiers")

                tmpFreeSoldiers[key] = army_value:getProperty("free") + army_value:getProperty("march")
                tmpConfSoldiers[key] = army_value:getProperty("free") + army_value:getProperty("march")

                TroopsController:call("getInstance"):setProperty("m_tmpFreeSoldiers", tmpFreeSoldiers)
                TroopsController:call("getInstance"):setProperty("m_tmpConfSoldiers", tmpConfSoldiers)

                local addFlag = false
                for tmp_index, tmp_value in ipairs(self.m_tmpArray) do
                    local armyId = tmp_value
                    local armyLevel = atoi(CCCommonUtilsForLua:getPropByIdGroup("arms", armyId, "level")) - 1
                    if (armyLevel < army_value:getProperty("armyLevel")) then
                        table.insert(self.m_tmpArray, tmp_index, key)
                        addFlag = true
                        break
                    end
                end

                if (not addFlag) then
                    table.insert(self.m_tmpArray, key)
                end
            end
        end
    end
end

function BattleView:initTreasureFamMonsterInfo()
    if (self.m_dragonSprCover) then
        self.m_dragonSprCover:setVisible(true)
    end
    
    TroopsController:call("getInstance"):setProperty("m_tmpFreeSoldiers", {})
    TroopsController:call("getInstance"):setProperty("m_tmpBattleInfos", {})
    TroopsController:call("getInstance"):setProperty("m_tmpConfSoldiers", {})
    self.m_tmpArray = {}
    -- CCDictionary* dict = CCDictionary::create();
    -- LuaController::getInstance()->fireEventRef("setTreasureFamMonsterArmyData", dict);
    
    -- dict:setObject(CCString:create(TreasureFamManager.m_monsterSoldiersStr), "armyStr")
    -- dict:setObject(CCString:create(TreasureFamManager.m_monsterMarchLimit), "armyLimit")
    self.m_maxForceNumForTreasureMonster = tonumber((TreasureFamManager.m_monsterMarchLimit)) -- 出征上限
    local armyDataStr = TreasureFamManager.m_monsterSoldiersStr
    local vec = splitString(armyDataStr, "|")
    local treasureFamMonsterArmyDict = {}
    for index, value in ipairs(vec) do
        local tmpVec = splitString(value, ";")
        if (#tmpVec == 2) then
            treasureFamMonsterArmyDict[tmpVec[1]] = tonumber(tmpVec[2])
        end
    end

    for key, value in pairs(treasureFamMonsterArmyDict) do
        local armyID = key
        -- TroopsController::getInstance()->m_tmpFreeSoldiers[it->first] =  treasureFamMonsterArmyDict[armyID];
        -- TroopsController::getInstance()->m_tmpConfSoldiers[it->first] =  treasureFamMonsterArmyDict[armyID];
        local tmpFreeSoldiers = TroopsController:call("getInstance"):getProperty("m_tmpFreeSoldiers")
        local tmpConfSoldiers = TroopsController:call("getInstance"):getProperty("m_tmpConfSoldiers")

        tmpFreeSoldiers[key] = treasureFamMonsterArmyDict[armyID]
        tmpConfSoldiers[key] = treasureFamMonsterArmyDict[armyID]

        TroopsController:call("getInstance"):setProperty("m_tmpFreeSoldiers", tmpFreeSoldiers)
        TroopsController:call("getInstance"):setProperty("m_tmpConfSoldiers", tmpConfSoldiers)
        
        local addFlag = false
        local level = tonumber(CCCommonUtilsForLua:getPropByIdGroup("arms", armyID, "level")) - 1
        for tmp_index, tmp_value in ipairs(self.m_tmpArray) do
            local tmp_armyId = tmp_value
            local armyLevel = tonumber(CCCommonUtilsForLua:getPropByIdGroup("arms", tmp_armyId, "level")) - 1
            if (armyLevel < level) then
                table.insert(self.m_tmpArray, tmp_index, key)
                addFlag = true
                break
            end
        end

        if (not addFlag) then
            table.insert(self.m_tmpArray, key)
        end
    end
end

function BattleView:initCOSInfo()
    local size = self.m_infoList:getContentSize()
    self.m_infoList:setContentSize(CCSize(size.width, size.height + 40))

    self.m_formationNode:setVisible(false)
    self.m_extraNode:setVisible(false)
    local hrefNode = self.m_nodeCityLv:getParent()
    if (hrefNode) then
        hrefNode:setVisible(false)
    end

    self.m_helpBtn:setVisible(false)
    self.m_iconContainer:setVisible(false)
    self.m_msg2Label:setVisible(false)
    self.m_cosActNode:setVisible(true)
    self.m_cosTipsLabel:setString(_lang("182172"))
    if (DynamicResourceController2:call("checkDynamicResource", "COSAct_face")) then
        CCLoadSprite:call("loadDynamicResourceByName", "COSAct_face")
        local pFrame = CCSpriteFrameCache:sharedSpriteFrameCache():spriteFrameByName("spr_AD.png")
        self.m_cosADSpr:setSpriteFrame(pFrame)
    end
    self:generateData()
end

function BattleView:generateDataPve(heroId)
    TroopsController:call("getInstance"):setProperty("m_tmpFreeSoldiers", {})
    TroopsController:call("getInstance"):setProperty("m_tmpBattleInfos", {})
    TroopsController:call("getInstance"):setProperty("m_tmpConfSoldiers", {})

    local dict = CCDictionary:create()
    local dataController = require("game.Training.PveDataController")
	PveDataController:getInstance():refreshArmInfoInPve(dict)
    
    local maxHeroNums = 5
    local index = 0
    self.m_maxForceNumPve = 0
    self.m_tmpArray = {}

    local troopTypeNum = atoi(dict:valueForKey("troopTypeNum"):getCString())
    local soldierMaxLevel = 0
    for i = 1, troopTypeNum do
        local key = string.format("generalid_%d", i)
        local generalId = dict:valueForKey(key):getCString()
        local tmpSoldierMaxLevel = string.format("soldierMaxLevel_%d", i)
        soldierMaxLevel = dict:valueForKey(tmpSoldierMaxLevel):getCString()
        if (heroId ==  generalId or heroId == "") then
            index = i
            heroId = generalId
            break
        end
    end

    self.m_heroId = heroId
    self.soldierMaxLevel = atoi(soldierMaxLevel)
    if self.isEndless == "1" then
        self.m_nodeEndlessInfo:setVisible(true)
        self.m_lblEndlessTips:setString(getLang("52052090") .. self.soldierMaxLevel)
    end
    if (index == 0) then
        return
    end

    self.m_queueId = index
    
    local pveArmyDict = {}
    local key = string.format("army_%d",index)
    local keyForce = string.format("forceNumMax_%d",index)
    local pveArmyTmp = dict:valueForKey(key):getCString()
    self.m_maxForceNumPve = dict:valueForKey(keyForce):intValue()
    local vec = splitString(pveArmyTmp, "|")
    for index, value in ipairs(vec) do
        local tmpArmy = splitString(value, ";")
        if (#tmpArmy == 2) then
            local armyId = tmpArmy[1]
            local num  = tonumber(tmpArmy[2])
            pveArmyDict[armyId] = num
        end
    end


    for key, value in pairs(pveArmyDict) do
        local armyID = key
        -- TroopsController::getInstance()->m_tmpFreeSoldiers[it->first] =  pveArmyDict[armyID];//(it->second).free;
        -- TroopsController::getInstance()->m_tmpConfSoldiers[it->first] =  pveArmyDict[armyID];//(it->second).free;
        local tmpFreeSoldiers = TroopsController:call("getInstance"):getProperty("m_tmpFreeSoldiers")
        local tmpConfSoldiers = TroopsController:call("getInstance"):getProperty("m_tmpConfSoldiers")

        tmpFreeSoldiers[key] = pveArmyDict[armyID]
        tmpConfSoldiers[key] = pveArmyDict[armyID]

        TroopsController:call("getInstance"):setProperty("m_tmpFreeSoldiers", tmpFreeSoldiers)
        TroopsController:call("getInstance"):setProperty("m_tmpConfSoldiers", tmpConfSoldiers)

        local tmp_index = 0
        local addFlag = false
        local level = tonumber(CCCommonUtilsForLua:getPropByIdGroup("arms", armyID, "level")) - 1
        for tmp_index, tmp_value in ipairs(self.m_tmpArray) do
            local tmp_armyId = tmp_value
            local armyLevel = tonumber(CCCommonUtilsForLua:getPropByIdGroup("arms", tmp_armyId, "level")) - 1
            if (armyLevel < level) then
                table.insert(self.m_tmpArray, tmp_index, key)
                addFlag = true
                break
            end
        end

        if (not addFlag) then
            table.insert(self.m_tmpArray, key)
        end
    end
end

function BattleView:initPveInfo()
    if (self.m_dragonSprCover) then
        self.m_dragonSprCover:setVisible(true)
    end
    self:generateDataPve("")
end

function BattleView:initFightDeath()
    TroopsController:call("getInstance"):setProperty("m_tmpFreeSoldiers", {})
    TroopsController:call("getInstance"):setProperty("m_tmpBattleInfos", {})
    TroopsController:call("getInstance"):setProperty("m_tmpConfSoldiers", {})
    self.m_tmpArray = {}

    local b_angel_army = isFunOpenByKey("angel_army")
    local armyId_14 = {}
    if b_angel_army then
        if self.angelArmyId_format then
            armyId_14[self.angelArmyId_format] = true
        else
            local tempArmyId = require("game.army.angel.AngelArmyController").getInstance():getSettingArmy(1)
            if tempArmyId then
                armyId_14[tempArmyId] = true
            end
        end
    end

    local b_night_army = isFunOpenByKey("night_army")
    if b_night_army then
        if self.nightArmyId_format then
            armyId_14[self.nightArmyId_format] = true
        else
            local tempArmyId = require("game.army.angel.AngelArmyController").getInstance():getSettingArmyByGroup(1, SpecialArmyGroup.NIGHT_ARMY)
            if tempArmyId then
                armyId_14[tempArmyId] = true
            end
        end
    end
    local armyList = GlobalData:call("shared"):getProperty("armyList") 
    for key, value in pairs(armyList) do
        local free = value:getProperty("free")
        local armyLevel = value:getProperty("armyLevel")
        local deadMarch = math.max(0, value:getProperty("deadMarch"))
        if free + deadMarch > 0 and value:getProperty("isArmy") and armyLevel >= self.m_armyMinLv - 1 then
            local isAdd14Army = true
            if b_angel_army or b_night_army then
                if value:getProperty("armyLevel") == 13 then
                    if not armyId_14[key] then
                        isAdd14Army = false
                    end
                end
            end
            
            if isAdd14Army then
                local tmpFreeSoldiers = TroopsController:call("getInstance"):getProperty("m_tmpFreeSoldiers")
                local tmpConfSoldiers = TroopsController:call("getInstance"):getProperty("m_tmpConfSoldiers")

                tmpFreeSoldiers[key] = free + deadMarch
                tmpConfSoldiers[key] = free + deadMarch

                TroopsController:call("getInstance"):setProperty("m_tmpFreeSoldiers", tmpFreeSoldiers)
                TroopsController:call("getInstance"):setProperty("m_tmpConfSoldiers", tmpConfSoldiers)

                local addFlag = false
                for tmp_index, tmp_value in ipairs(self.m_tmpArray) do
                    local armyInfo = armyList[tmp_value]
                    if armyInfo then
                        local deadMarch2 = math.max(0, armyInfo:getProperty("deadMarch"))
                        if deadMarch > deadMarch2 then
                            table.insert(self.m_tmpArray, tmp_index, key)
                            addFlag = true
                            break
                        end
                    end
                end
                if not addFlag then
                    table.insert(self.m_tmpArray, key)
                end
            end
        end
    end
end

function BattleView:setChallengeJudgement()
    -- 领主战斗力+当前部队战斗力+当前装备战斗力+龙战斗力
    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
    self.m_leaderPower = playerInfo:getProperty("playerPower")
    self.m_equipPower = playerInfo:getProperty("equipPower")
    local myPowerAll = self.m_armyPower -- 暂时只需要军队战斗力，以后可能会变成4部分相加
    
    self.m_enemyPower = 0
    local info = WorldController:call("getCityInfoByIndex", self.m_targetIndex)
    
    if(info ~= nil and info:call("getFieldMonsterInfo")) then
        local fieldMonsterInfo = info:call("getFieldMonsterInfo")
        if fieldMonsterInfo ~= nil then
            local monsterId = fieldMonsterInfo:getProperty("monsterId")
            if monsterId ~= nil and monsterId ~= "" then
                self.m_enemyPower = atoi(CCCommonUtilsForLua:getPropById(monsterId, "arm_num"))
            end
        end
    end
    
    if (myPowerAll >= self.m_enemyPower * 2) then
        self.txt_challenge:setString(_lang("300026"))  -- 300026=胜算较高，建议出征
    elseif (myPowerAll >= self.m_enemyPower and myPowerAll < self.m_enemyPower * 2) then
        self.txt_challenge:setString(_lang("300027"))  -- 300027=胜负难测，请谨慎出征
    elseif (myPowerAll < self.m_enemyPower) then
        self.txt_challenge:setString(_lang("300028"))  -- 300028=胜算较低，不建议出征
    end
end

function BattleView:getMaxSoilderNum(forceRefresh)
    forceRefresh = forceRefresh or false
    if (self.m_maxCorrectNum > 0) then
        return self.m_maxCorrectNum
    end

    if (self.m_battlType == PveTrainingType.PveHeroTraining and CCCommonUtilsForLua:isFunOpenByKey("test_hero_switch")) then
        return self.m_maxForceNumPve
    end

    if (self.m_battlType == TreasureFamType.TreasureFamMonster and CCCommonUtilsForLua:isFunOpenByKey("treasure_fam_on")) then
        return self.m_maxForceNumForTreasureMonster
    end

    if (self.m_battlType == TreasureFamType.TreasureFamMine and CCCommonUtilsForLua:isFunOpenByKey("treasure_fam_on")) then
        return self.m_maxForceNumForTreasureMine
    end

    if (self.m_battlType == ArenaBattleType.ArenaBattle and CCCommonUtilsForLua:isFunOpenByKey("ladder_expedition_limit")) then
        local max_cfg = CCCommonUtilsForLua:getPropByIdGroup("data_config", "ladder_para_client", "k2")
        return tonumber(max_cfg) or 0
    end

    if self.m_battlType == CommericalType.CommericalBattle and self.m_maxForceNumForCmr > 0 then
        return self.m_maxForceNumForCmr
    end

    --【Awen】领主死斗
    if self.m_bType == MarchMethodType.FightDeath then
        return tonumber(self.m_armyScope) or 0
    end

    if (self.m_maxForceNum > 0 and forceRefresh == false) then
        return self.m_maxForceNum
    end
    
    local maxForceNum = TroopsController:call("getMaxSoilder", self.m_bType) -- TroopsController::getInstance()->getMaxSoilder(m_bType);
    if (self.m_rally > 0) then
        maxForceNum = math.min(self.m_rally, maxForceNum)
    end

    if (self.m_bType == MarchMethodType.MethodUnion 
        or self.m_bType == MarchMethodType.MethodYuanSolider
        or self.m_bType == MarchMethodType.MethodTeamUnion) then
        maxForceNum = math.min(self.m_rally, maxForceNum)
    elseif ((self.m_bType == MarchMethodType.MethodBattle or self.m_bType == -1) and self.m_targetType == WorldCityType.CityTile) then
        maxForceNum = self:setMaxSoilderBySkill(maxForceNum)
    end

    self.m_maxForceNum = maxForceNum
    return maxForceNum
end


function BattleView:checkIsInDuel()
    -- 检查是否已开启决斗技能
    if not self.m_duelMarch then
        return false
    end
    
    local skillOn = false
    local skillId = "603100"
    -- 修复获取技能信息问题
    local skillCD = GeneralManager:call("getSkillCDInfoById", skillId)
    if (skillCD ~= nil) then
        if (skillCD:getProperty("stat") == 1 and skillCD:getProperty("duelMarchNum") == 0 and skillCD:getProperty("duelSoldierNum") > 0 ) then
            skillOn = true
        end
    end

    -- 检查是否使用决斗道具
    if (CCCommonUtilsForLua:call("getEffectLeftTimeByNum", DUEL_SOILDER_NUM_EFFECT) > 0) then
        skillOn = true
    end
    return skillOn
end

function BattleView:setMaxSoilderBySkill(maxSoilder)
    local finalSoilderNum = maxSoilder
    
    if not self.m_duelMarch then
        -- 算上单兵作用号
        finalSoilderNum = finalSoilderNum + CCCommonUtilsForLua:call("getEffectValueByNum", 2099)
        return finalSoilderNum
    end

    local skillId = "603100"
    -- 修复获取技能信息问题
    local skillCD = GeneralManager:call("getSkillCDInfoById", skillId)
    if (skillCD ~= nil) then
        if (skillCD:getProperty("stat") == 1 and skillCD:getProperty("duelMarchNum") == 0 and skillCD:getProperty("duelSoldierNum") > 0 ) then
            finalSoilderNum = skillCD:getProperty("duelSoldierNum")
            finalSoilderNum = finalSoilderNum + CCCommonUtilsForLua:call("getEffectValueByNum", DULE_SKILL_LIMIT_EFFECT)
        end
    end
    
    -- 决斗道具
    if (CCCommonUtilsForLua:call("getEffectLeftTimeByNum", DUEL_SOILDER_NUM_EFFECT) > 0) then
        finalSoilderNum = CCCommonUtilsForLua:call("getStateEffectValueByNum", DUEL_SOILDER_NUM_EFFECT)
    end
    
    return finalSoilderNum
end

function BattleView:onClickBtnBack()
    PopupViewController:call("goBackPopupView")
    -- 领主死斗返回准备界面
    if self.m_bType == MarchMethodType.FightDeath then
        require("game.fightDeath.FightDeathController").getInstance():openReadyView()
    end
end

function BattleView:onFormation1Click(pSender, event)
    self:clickFormation(1)
end

function BattleView:onFormation2Click(pSender, event)
    self:clickFormation(2)
end

function BattleView:onFormation3Click(pSender, event)
    self:clickFormation(3)
end

function BattleView:onFormation4Click(pSender, event)
    self:clickFormation(4)
end

function BattleView:onFormation5Click(pSender, event)
    self:clickFormation(5)
end

function BattleView:onFormation6Click(pSender, event)
    self:clickFormation(6)
    self.m_externBtnNode:setVisible(false)
end

function BattleView:onFormation7Click(pSender, event)
    self:clickFormation(7);
    self.m_externBtnNode:setVisible(false)
end

function BattleView:onFormation8Click(pSender, event)
    self:clickFormation(8)
    self.m_externBtnNode:setVisible(false)
end

function BattleView:onFormation9Click(pSender, event)
    self:clickFormation(9)
    self.m_externBtnNode:setVisible(false)
end

function BattleView:onFormation10Click(pSender, event)
    self:clickFormation(10)
    self.m_externBtnNode:setVisible(false)
end

function BattleView:onFormationExternClick(pSender, event)
    -- 新增打点
    
    local isVisible = self.m_externBtnNode:isVisible()
    self.m_externBtnNode:setVisible(not isVisible)
end

function BattleView:onClickSoildersSet(pSender, event)
    if self.isEndless == "1" then -- 无尽的试炼不设置出兵等级
        return
    end
    -- 新增打点
    CCSafeNotificationCenter:postNotification("msg_soilderSet_open")
end


function BattleView:soilderSetUpdate(ref)
    if (ref == nil) then
        return
    end

    local receiver = dictToLuaTable(ref)
    if (receiver == nil) then
        return
    end

    local cInt1 = tonumber(receiver["lvSet"])
    if cInt1 then
        self.m_lvSet = cInt1
        self:unselectAll()
        self:generateData()
        self:onClickQuickBtn(nil, cc.CONTROL_EVENTTYPE_TOUCH_DOWN)
    end
    
    local cInt2 = tonumber(receiver["perSet"])
    if cInt2 then
        self.m_soilder_perSet = cInt2
    end
    
    local cBool1 = receiver["lvOrderSet"]
    if cBool1 ~= nil then
        self.m_lvOrderSet = cBool1
        self:sortTmpArrayByLv()
    end
    
    local cBool2 = receiver["typeOrderSet"]
    if cBool2 ~= nil then
        self.m_typeOrderSet = cBool2
        self:sortTmpArrayByType()
    end
    
    local cBool3 = receiver["numOrderSet"]
    if cBool3 ~= nil then
        self.m_numOrderSet = cBool3
        self:sortTmpArrayByNum()
    end
    
    self.m_tabView:reloadData()
end

function BattleView:updateMarchTime(ref)
    if ref == nil then
        return
    end

    local param = dictToLuaTable(ref)
    self.m_commercialTime = atoi(param.time) / 1000
    self:makeArrTime(nil)
end

function BattleView:onClickHeroBtn(pSender, event)
    local general_battle = CCCommonUtilsForLua:isFunOpenByKey("general_battle")
    if (not general_battle) then
        CCCommonUtilsForLua:call("flyHint", "", "", _lang("169042"))
        return
    end

    if (FunBuildController:call("getMainCityLv") < GlobalData:call("shared"):getProperty("heroMarchMainCityLvLimit")) then
        CCCommonUtilsForLua:call("flyHint", "", "", _lang_1("169685", CC_ITOA(GlobalData:call("shared"):getProperty("heroMarchMainCityLvLimit"))))
        return
    end

    if (general_battle and self:checkIsInDuel()) then
        CCCommonUtilsForLua:call("flyHint", "", "", _lang("167050"))  -- 决斗不能带龙、英雄
        return
    end

    local serverType = GlobalData:call("shared"):getProperty("serverType")
    if (serverType == ServerType.SERVER_ARENA or serverType == ServerType.SERVER_ARENA_TEST) then
        CCCommonUtilsForLua:call("flyHint", "", "", _lang("169042"))
        return
    end

    self:setChallengePopClose(nil)
    local arr = nil
    local type = SOILDERTYPE.HERO; -- C++ SOILDERTYPE.HERO
    if (self.m_battlType == PveTrainingType.PveHeroTraining and CCCommonUtilsForLua:isFunOpenByKey("test_hero_switch")) then
        -- arr = CCCommonUtils::getCanMarchHeroIdInPve();
        local PveDataController = require("game.Training.PveDataController")
        arr = PveDataController:getInstance():getPveMarchHeroIds()
        type = SOILDERTYPE.NEWHEROTRAINING
    else
        arr = arrayToLuaTable(getCanMarchHeroId())
    end

    local count = 0
    local idVec = {}
    for index, value in ipairs(arr) do
        if value ~= nil then
            table.insert(idVec, value)
            local heroInfo = HeroManager.getHeroInfoById(value);
            if heroInfo ~= nil then
                local battle = tonumber(heroInfo["battle"])
                if battle == 1 then
                        count = count + 1
                end
            end
        end
    end
    
    if #idVec == 1 then
        if (count == 0) then
            CCCommonUtilsForLua:call("flyHint", "", "", _lang("169683"))
            return
        end
        
        if (self.m_heroId == "" or (self.m_battlType == PveTrainingType.PveHeroTraining and CCCommonUtilsForLua:isFunOpenByKey("test_hero_switch"))) then
            self:setHero(CCString:create(idVec[1]))
        else
            self:setHero(CCString:create(""))
        end
        return
    end
    
    if (#idVec <= 0) then
        CCCommonUtilsForLua:call("flyHint", "", "", _lang("169684"))
        return
    end
    
    if self:checkHeroAtDestnation() then
        CCCommonUtilsForLua:call("flyHint", "", "", _lang("10200532"))  -- 目标点已经有英雄
        return
    end
    
    local selectIndex = -1
    for index, value in ipairs(idVec) do
        if self.m_heroId == value then
            selectIndex = index
            break
        end
    end

    local dict = CCDictionary:create()
    dict:setObject(CCString:create("OpenBattleHeroSelectView"), "name")
    dict:setObject(CCString:create(type), "type")
    dict:setObject(CCString:create(selectIndex), "selectIndex")
    dict:setObject(CCString:create(self.m_heroTabType), "heroTabType")
    dict:setObject(CCString:create("false"), "isFormation")
    dict:setObject(CCString:create(self.m_heroId), "heroId")
    LuaController:call("openPopViewInLua", dict)
end

-- [awen-gaorui] 删除英雄
function BattleView:onClickDelHero(pSender, event)
    if (not CCCommonUtilsForLua:isFunOpenByKey("general_battle")) then
        CCCommonUtilsForLua:call("flyHint", "", "", _lang("169042"))
        return
    end

    if (FunBuildController:call("getMainCityLv") < GlobalData:call("shared"):getProperty("heroMarchMainCityLvLimit")) then
        CCCommonUtilsForLua:call("flyHint", "", "", _lang_1("169685", CC_ITOA(GlobalData:call("shared"):getProperty("heroMarchMainCityLvLimit"))))
        return
    end

    if(self.m_battlType == PveTrainingType.PveHeroTraining and CCCommonUtilsForLua:isFunOpenByKey("test_hero_switch")) then
        CCCommonUtilsForLua:call("flyHint", "", "", _lang("4502038")) -- 提示
        return
    end

    self:setHero(CCString:create(""))
end

-- 删除龙
function BattleView:onClickDelDragon(pSender, event)
    self:setDragon(CCInteger:create(-1))
end

-- 删除阵法
function BattleView:onClickDelBook(pSender, event)
    self.m_aormationId = ""
    self.m_delBookBtn:setVisible(false)
    self.txt_aormationName:setString("")
    -- self.m_aormationTxtNode:setVisible(false)
    self.m_aormationSpr:setVisible(false)
    self.m_aorSprCover:setVisible(true)
    self:updateBuffIcon()
end

-- 阵法选择
function BattleView:onClickAormation(pSender, event)
    local dict = CCDictionary:create()
    dict:setObject(CCString:create(self.m_aormationId), "aormationId")

    if (CCCommonUtilsForLua:isFunOpenByKey("player_battle")) and self.m_bType == MarchMethodType.FightDeath then
        dict:setObject(CCString:create("MarchDead"), "type")
    end
    if isFunOpenByKey('formation_train') then
        local view = Drequire("game.formationTrain.common.FTBattleView"):create(dict)
        PopupViewController:addPopupView(view)
    else
        local view = Drequire("game.TacticalDeploy.TacticalDepBattleView"):create(dict)
    	PopupViewController:addPopupView(view)
    end
end

function BattleView:setAormationInfo(ref)
    if not ref then
        return
    end

    self.m_aormationId = ref:getCString()
    if (self.m_aormationId == "") then
        self.txt_aormationName:setString("")
        -- self.m_aormationTxtNode:setVisible(false)
        self.m_aormationSpr:setVisible(false)
        self.m_aorSprCover:setVisible(true)
        self.m_delBookBtn:setVisible(false)
    else
        self.m_delBookBtn:setVisible(true)
        self.m_aorSprCover:setVisible(false)
        self.m_aormationSpr:setVisible(true)
        -- self.m_aormationTxtNode:setVisible(true)
        local name = ''
        if isFunOpenByKey('formation_train') then
            local bagModel = FormationTrainCtr:getInstance():getBagModel()
            name = bagModel:getPageNameByIdx(self.m_aormationId)
        else
            name = CCCommonUtilsForLua:getPropByIdGroup("Aormation_info", self.m_aormationId, "name")
            name = _lang(name)
        end
        self.txt_aormationName:setString(name)
    end
    self:updateBuffIcon()
end


function BattleView:onClickCityLvBtn(pSender, event)
    if(self.m_battlType == PveTrainingType.PveHeroTraining and CCCommonUtilsForLua:isFunOpenByKey("test_hero_switch")) then
        CCCommonUtilsForLua:call("flyHint", "", "", _lang("4502039"))  --提示
        return
    end

    self:setChallengePopClose(nil)
    local dict = CCDictionary:create()
    dict:setObject(CCInteger:create(1), "entrance")   -- 参数1，表示需要根据march_show判断是否显示该项目
    if CCCommonUtilsForLua:isFunOpenByKey("new_player_20210104_show") then
        local view = Drequire("game.CommonPopup.ItemStatusView_v2021"):create(dict)
        PopupViewController:addPopupInView(view)
    else
        local view = Drequire("game.CommonPopup.ItemStatusView"):create(dict)
        PopupViewController:addPopupInView(view)
    end
end

function BattleView:onClickDragonWordsBtn(pSender, event)
    local info = FunBuildController:call("getInstance"):call("getBuildNumByType", FUN_BUILD_KNIGHT) -- FunBuildController::getInstance()->getBuildNumByType(FUN_BUILD_KNIGHT);
    
    if info < 1 then
        CCCommonUtilsForLua:call("flyHint", "", "", _lang("160869")) -- 提示
        return
    else
        self:setChallengePopClose(nullptr)
        local view = Drequire("game.CommonPopup.Knight.KnightListView"):create()
	    PopupViewController:addPopupInView(view)
    end
end

function BattleView:onClickOneKeyBtn(pSender, event)
    if(self.m_battlType == PveTrainingType.PveHeroTraining and CCCommonUtilsForLua:isFunOpenByKey("test_hero_switch")) then
        CCCommonUtilsForLua:call("flyHint", "", "", _lang("4502039")) -- 提示
        return
    end

    self:setChallengePopClose(nil)
    onFireEvent("openQuickEquipView")
    -- QuickEquipmentController.getInstance():openUi()
end

function BattleView:onClickOneKeyBuffBtn(pSender, event)
    if(self.m_battlType == PveTrainingType.PveHeroTraining and CCCommonUtilsForLua:isFunOpenByKey("test_hero_switch")) then
        CCCommonUtilsForLua:call("flyHint", "", "", _lang("4502039"))  -- 提示
        return
    end
    -- LuaController::getInstance()->fireEvent("OneKeyBuffMainView");
    local view = Drequire("game.OneKeyBuff.OneKeyBuffMainView"):create()
	PopupViewController:addPopupInView(view)
end

function BattleView:onClickMarchTypeBtn(pSender, event)
    if (self.node_marchType:isVisible()) then
        if (self.node_challengePop:isVisible()) then
            self:setChallengePopClose(nil)
        else
            self.node_challengePop:setVisible(true)
            if self.soilderChallengeType == SoldierChallengeType.SOILDERCHALLENGETYPE_LOAD then
                self.node_marchTypeSelectBg:setPositionY(0)
            elseif self.soilderChallengeType ==  SoldierChallengeType.SOILDERCHALLENGETYPE_LEVEL then
                self.node_marchTypeSelectBg:setPositionY(-74)
            elseif self.soilderChallengeType ==  SoldierChallengeType.SOILDERCHALLENGETYPE_SPEED then
                self.node_marchTypeSelectBg:setPositionY(-148)
            elseif self.soilderChallengeType ==  SoldierChallengeType.SOILDERCHALLENGETYPE_Prop then
                self.node_marchTypeSelectBg:setPositionY(74)
            elseif self.soilderChallengeType ==  SoldierChallengeType.SOILDERCHALLENGETYPE_RECOMMEND_INITIATOR then
                self.node_marchTypeSelectBg:setPositionY(self.m_recInitiatorNode:isVisible() and 222 or 74)
            elseif self.soilderChallengeType ==  SoldierChallengeType.SOILDERCHALLENGETYPE_RECOMMEND_SYSTEM then
                self.node_marchTypeSelectBg:setPositionY(self.m_recSystemNode:isVisible() and 148 or 74)
            else
                self.node_marchTypeSelectBg:setPositionY(74)
            end
        end
    end
end

function BattleView:onClickMarchLoadBtn(pSender, event)
    if self.node_challengePop:isVisible() and self.soilderChallengeType ~= SoldierChallengeType.SOILDERCHALLENGETYPE_LOAD and self.soilderChallengeType ~= SoldierChallengeType.SOILDERCHALLENGETYPE_MONSTER then
        self.node_marchTypeSelectBg:setPositionY(0)
        
        -- 在杀戮战场中替换为怪物优先
        local serverType = GlobalData:call("shared"):getProperty("serverType")
        if serverType == ServerType.SERVER_ANCESTRAL then
            self:changeSoilderType(SoldierChallengeType.SOILDERCHALLENGETYPE_MONSTER)
        else
            self:changeSoilderType(SoldierChallengeType.SOILDERCHALLENGETYPE_LOAD)
        end
        self:onClickQuickBtn(nil, cc.CONTROL_EVENTTYPE_TOUCH_DOWN)
    end
    self:setChallengePopClose(nil)
end

function BattleView:onClickMarchLevelBtn(pSender, event)
    if(self.node_challengePop:isVisible() and self.soilderChallengeType ~= SoldierChallengeType.SOILDERCHALLENGETYPE_LEVEL) then
        self.node_marchTypeSelectBg:setPositionY(-74)
        self:changeSoilderType(SoldierChallengeType.SOILDERCHALLENGETYPE_LEVEL)
        self:onClickQuickBtn(nil, cc.CONTROL_EVENTTYPE_TOUCH_DOWN)
    end
    self:setChallengePopClose(nil)
end

function BattleView:onClickMarchSpeedBtn(pSender, event)
    if self.node_challengePop:isVisible() and self.soilderChallengeType ~= SoldierChallengeType.SOILDERCHALLENGETYPE_SPEED then
        self.node_marchTypeSelectBg:setPositionY(-148)
        self:changeSoilderType(SoldierChallengeType.SOILDERCHALLENGETYPE_SPEED)
        self:onClickQuickBtn(nil, cc.CONTROL_EVENTTYPE_TOUCH_DOWN)
    end
    self:setChallengePopClose(nil)
end

function BattleView:onClickMarchPropBtn(pSender, event)
    if self.node_challengePop:isVisible() and self.soilderChallengeType ~= SoldierChallengeType.SOILDERCHALLENGETYPE_Prop then
        self.node_marchTypeSelectBg:setPositionY(74)
        self:changeSoilderType(SoldierChallengeType.SOILDERCHALLENGETYPE_Prop)
        self:onClickQuickBtn(nil, cc.CONTROL_EVENTTYPE_TOUCH_DOWN)
    end
    self:setChallengePopClose(nil)
end

function BattleView:onClickMarchSystemRecBtn(pSender, event)
    if self.node_challengePop:isVisible() and self.soilderChallengeType ~= SoldierChallengeType.SOILDERCHALLENGETYPE_RECOMMEND_SYSTEM then
        self.node_marchTypeSelectBg:setPositionY(148)
        self:changeSoilderType(SoldierChallengeType.SOILDERCHALLENGETYPE_RECOMMEND_SYSTEM)
        self:onClickQuickBtn(nil, cc.CONTROL_EVENTTYPE_TOUCH_DOWN)
    end
    self:setChallengePopClose(nil)
end

function BattleView:onClickMarchInitiatorRecBtn(pSender, event)
    if self.node_challengePop:isVisible() and self.soilderChallengeType ~= SoldierChallengeType.SOILDERCHALLENGETYPE_RECOMMEND_INITIATOR then
        self.node_marchTypeSelectBg:setPositionY(222)
        self:changeSoilderType(SoldierChallengeType.SOILDERCHALLENGETYPE_RECOMMEND_INITIATOR)
        self:onClickQuickBtn(nil, cc.CONTROL_EVENTTYPE_TOUCH_DOWN)
    end
    self:setChallengePopClose(nil)
end

function BattleView:onQuickSelect1Click(pSender, event)
    if (self.soilderChallengeType ~= SoldierChallengeType.SOILDERCHALLENGETYPE_Prop) then
        self:changeSoilderType(SoldierChallengeType.SOILDERCHALLENGETYPE_Prop)
        self:onClickQuickBtn(nil, cc.CONTROL_EVENTTYPE_TOUCH_DOWN)
    end
end

function BattleView:onQuickSelect2Click(pSender, event)
    if (self.soilderChallengeType ~= SoldierChallengeType.SOILDERCHALLENGETYPE_MONSTER) then
        self:changeSoilderType(SoldierChallengeType.SOILDERCHALLENGETYPE_MONSTER)
        self:onClickQuickBtn(nil, cc.CONTROL_EVENTTYPE_TOUCH_DOWN)
    end
end

function BattleView:onQuickSelect3Click(pSender, event)
    if (self.soilderChallengeType ~= SoldierChallengeType.SOILDERCHALLENGETYPE_LEVEL) then
        self:changeSoilderType(SoldierChallengeType.SOILDERCHALLENGETYPE_LEVEL)
        self:onClickQuickBtn(nil, cc.CONTROL_EVENTTYPE_TOUCH_DOWN)
    end
end

function BattleView:onQuickSelect4Click(pSender, event)
    if (self.soilderChallengeType ~= SoldierChallengeType.SOILDERCHALLENGETYPE_SPEED) then
        self:changeSoilderType(SoldierChallengeType.SOILDERCHALLENGETYPE_SPEED)
        self:onClickQuickBtn(nil, cc.CONTROL_EVENTTYPE_TOUCH_DOWN)
    end
end

function BattleView:onClickHealJumpBtn(pSender, event)
    -- QuestController::getInstance()->speJumpItemId = FUN_BUILD_HOSPITAL;
    QuestController:call("getInstance"):setProperty("speJumpItemId", FUN_BUILD_HOSPITAL)
    
    local jumpEffectIndex = 3
    if self:getHealSoldierNum() <= 0 and ArmyController:call("getInstance"):call("getHealAllianceSoldierNum") > 0 then
        jumpEffectIndex = 4
    end

    PopupViewController:call("removeAllPopupView")
    QuestController:call("getInstance"):setProperty("speJumpEffectIndex", jumpEffectIndex)
    QuestController:call("getInstance"):call("makeSpeJump", 1)
end

function BattleView:onClickTrainJumpBtn(pSender, event)
    QuestController:call("getInstance"):setProperty("speJumpItemId", FUN_BUILD_BARRACK1)
    QuestController:call("getInstance"):setProperty("speJumpEffectIndex", 3)
    QuestController:call("getInstance"):call("makeSpeJump", 1)
end

-- 设置军队偏好
function BattleView:changeSoilderType(soldierChallengeType)
    self.soilderChallengeType = soldierChallengeType
    local image_info = SoldierChallengeImage[self.soilderChallengeType]
    if image_info == nil then
        image_info = SoldierChallengeImage["CanNotFind"]
    end

    local pFrame = CCSpriteFrameCache:sharedSpriteFrameCache():spriteFrameByName(image_info.name)
    self.spr_marchType:setScale(image_info.scale)
    self.spr_marchType:setSpriteFrame(pFrame)
    self:unselectAll()
end

function BattleView:onClickDragonBtn(pSender, event)
    if self.m_battlType == PveTrainingType.PveHeroTraining and CCCommonUtilsForLua:isFunOpenByKey("test_hero_switch") then -- 屏蔽龙
        CCCommonUtilsForLua:call("flyHint", "", "", _lang("4502026"))  -- 提示
        return
    end

    self:setChallengePopClose(nil)
    
    if (not CCCommonUtilsForLua:isFunOpenByKey("dragon_battle")) then
        CCCommonUtilsForLua:call("flyHint", "", "", _lang("169042"))  -- 开关没开
        return
    end

    if (CCCommonUtilsForLua:isFunOpenByKey("general_battle") and self:checkIsInDuel()) then
        CCCommonUtilsForLua:call("flyHint", "", "", _lang("167050"))  -- 决斗不能带龙、英雄
        return
    end

    local serverType = GlobalData:call("shared"):getProperty("serverType")
    if (serverType == ServerType.SERVER_ARENA or serverType == ServerType.SERVER_ARENA_TEST) then
        CCCommonUtilsForLua:call("flyHint", "", "", _lang("169042"))
        return
    end

    local dragons = DragonController:call("getDragonVector")
    local indexVec = {}
    for index, value in ipairs(dragons) do
        if (value:call("getInMarch") == false and value:call("getObtain") and value:call("getState") == DragonState.Dragon_Normal) then
            table.insert(indexVec, index)
        end
    end

    if (self:checkPlayerDragonCount() and #indexVec == 1) then
        local dragonConfig = DragonController:call("getInstance"):call("getDragonDataConfig")
        if (not self:checkPlayerDragonLevel() and #dragonConfig > 5) then
            CCCommonUtilsForLua:call("flyHint", "", "", _lang_1("169043", dragonConfig[6]))  -- DragonController::getInstance()->dragonConfig[5]
            return;
        end

        --【awen】龙友好度优化
        if (CCCommonUtilsForLua:isFunOpenByKey("dragon_friend_polish")) then
            local dragonInfo = dragons[indexVec[1]]
            
            -- 139340  巨龙正在驻守城堡，出征将会取消驻守状态，确认要出征吗？
            if (dragonInfo:call("getUseFlag") == 1) then
                local dialog = YesNoDialog:call("showVariableTitle", _lang("139340"), cc.CallFunc:create(function() self:cancelGuard() end ), _lang("110031"))   -- 110031=确定
                dialog:call("setNoButtonTitle", _lang("cancel_btn_label"))
                dialog:call("showCancelButton")
                return
            end
        end
        
        if (self.m_dragonIndex == -1) then
            self:setDragon(CCInteger:create(indexVec[1]-1))
        else
            self:setDragon(CCInteger:create(-1))
        end
        return
    end

    if (#indexVec <= 0) then
        CCCommonUtilsForLua:call("flyHint", "", "", _lang("169044"))  -- 所有龙都已经出征
        return
    end

    if (self:checkDragonAtDestnation()) then
        CCCommonUtilsForLua:call("flyHint", "", "", _lang("168033"))  -- 目标点已经有龙
        return
    end

    local selectIndex = -1
    for index, value in ipairs(indexVec) do 
        if (self.m_dragonIndex == value-1) then
            selectIndex = value-1
            break
        end
    end

    local dict = CCDictionary:create()
    dict:setObject(CCString:create("OpenBattleHeroSelectView"), "name")
    dict:setObject(CCString:create(SOILDERTYPE.DRAGON), "type")
    dict:setObject(CCString:create(selectIndex), "selectIndex")
    dict:setObject(CCString:create(HERO_TAB_TYPE.HERO_TAB_COMBAT), "heroTabType")
    dict:setObject(CCString:create("false"), "isFormation")
    dict:setObject(CCString:create(""), "heroId")
    if (CCCommonUtilsForLua:isFunOpenByKey("new_go_battle")) and self.m_bType ~= MarchMethodType.FightDeath then
        dict:setObject(CCString:create("true"), "isDeadMarch")
    end
    LuaController:call("openPopViewInLua", dict)
end

--【awen】取消驻守龙
function BattleView:cancelGuard()
    local dragons = DragonController:call("getDragonVector")
    local indexVec = {}
    for index, value in ipairs(dragons) do
        if (value:call("getInMarch") == false and value:call("getObtain") and value:call("getState") == DragonState.Dragon_Normal) then
            table.insert(indexVec, index)
        end
    end

    if (#indexVec == 1) then
        local dragonInfo = dragons[indexVec[1]]
        if dragonInfo then
            local dict = CCDictionary:create()
            dict:setObject(CCString:create(dragonInfo:call("getUuid")),"DragonUid")
            DragonController:call("dragonCancelGarrisonForLua",dict)
            -- DragonController:call("getInstance"):call("cancelGuardByIndex", indexVec[1])
        end
    end
end

--【awen】取消驻守成功后将龙添加到出征界面
function BattleView:cancelGuardCallback(obj)
    -- hxq 取消驻守龙后重算龙buff
    self:unselectAll()
    self:getMaxSoilderNum(true)
    self:refreshOperation()
    
    if (obj == nil) then
        return
    end
    
    local dragons = DragonController:call("getDragonVector")
    local indexVec = {}
    for index, value in ipairs(dragons) do
        if (value:call("getInMarch") == false and value:call("getObtain") and value:call("getState") == DragonState.Dragon_Normal) then
            table.insert(indexVec, index)
        end
    end

    if (#indexVec == 1) then
        self:setDragon(CCInteger:create(indexVec[1]-1))
    end
end

function BattleView:checkPlayerDragonCount()
    local ret = false
    local dragons = DragonController:call("getDragonVector")
    local count = 0
    for index, value in ipairs(dragons) do
        if (value:call("getState") == DragonState.Dragon_Normal) then
            if count ~= 0 then  -- 没有必要遍历完
                return false
            end
            count = count + 1
        end
    end

    if (count == 1) then
        ret = true
    end
    
    return ret
end

function BattleView:checkPlayerDragonLevel()
    local ret = false
    local dragons = DragonController:call("getDragonVector")

    if (#dragons == 0) then
        return false
    end

    local dragonConfig = DragonController:call("getInstance"):call("getDragonDataConfig")
    if #dragonConfig <= 5 then
        return false
    end

    if (dragons[1]:call("getLevel") < tonumber(dragonConfig[6])) then
        return false
    end

    return true
end

function BattleView:checkDragonAtDestnation()
    local uuid = WorldController:call("getMyMarchUuidAtIndex", self.m_targetIndex)
    local info = WorldController:call("getWorldMarchInfoByUuid", uuid)
    if (info == nil or info:getProperty("stateType") ~= MarchStateType.StateOccupy) then
        return false
    end

    local dragons = info:getProperty("playerDragon")
    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
    return dragons ~= nil and dragons[playerInfo:getProperty("uid")] ~= nil
end


function BattleView:checkHeroAtDestnation()
    local uuid = WorldController:call("getMyMarchUuidAtIndex", self.m_targetIndex)
    local info = WorldController:call("getWorldMarchInfoByUuid", uuid)
    if (info == nil or info:getProperty("stateType") ~= MarchStateType.StateOccupy) then
        return false
    end

    local heros = info:getProperty("playerHero")
    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
    return heros ~= nil and heros[playerInfo:getProperty("uid")] ~= nil
end


function BattleView:usePveTeam()  -- pve 使用上一次保存的编队信息
    local saveTeam = CCUserDefault:sharedUserDefault():getStringForKey(PVE_TEAM_CACHE,"") -- CCUserDefault::getInstance()->getStringForKey(PVE_TEAM_CACHE,"");
    if saveTeam == "" then
        return
    end

    local vector1 = splitString(saveTeam, "|")
    -- local num = #vector1
    self:unselectAll()
    local method = ""
    local maxForceNum = self:getMaxSoilderNum()
    -- 判断单支兵种数量是否超出，超出就用现有部分
    for index, value in ipairs(vector1) do
        local vector2 = splitString(value, ";")
        if (#vector2 == 2) then
            local per = tonumber(vector2[2]) -- 此处为百分比
            local tmp = maxForceNum * per/1000
            local selNum = math.floor(tmp)
            local tmpFreeSoldiers = TroopsController:call("getInstance"):getProperty("m_tmpFreeSoldiers")
            local totalNum = (tmpFreeSoldiers[vector2[1]] or 0) -- + TroopsController::getInstance()->m_tmpBattleInfos[vector2[0]];
            if (selNum > totalNum) then
                TroopsController:call("getInstance"):call("updateTmpBattleData", vector2[1], totalNum, vector2[1],false)
            else
                TroopsController:call("getInstance"):call("updateTmpBattleData", vector2[1], selNum, vector2[1],false)
            end
        else
            CCCommonUtilsForLua:call("flyText", _lang("103686"))
            return
        end
    end
    TroopsController:call("getInstance"):call("makeLoadNumAll")
    self:updateInfo()
end

function BattleView:saveLastFormation()
    if not (self.m_saveArenaFormation or self.m_saveFamFormation) then
        return
    end

    local soldierDict = dictToLuaTable(TroopsController:call("getInstance"):call("saveBattle"))
    local formatStr = ""
    local sumFormat = 0
    for key, value in pairs(soldierDict) do
        local id = CC_ITOA(key)
        local num = CC_ITOA(value)
        if formatStr == "" then
            formatStr = string.join(",", id, num)
        else
            formatStr = string.format("%s|%s,%s", formatStr, id, num)
        end

        sumFormat = sumFormat + atoi(key)
    end
    
    local dragonUuid = ""
    local dragonInfo = DragonController:call("getInstance"):call("getDragonInfoByIndex", self.m_dragonIndex)
    if dragonInfo ~= nil then
        dragonUuid = dragonInfo:call("getUuid")
    end

    local lastFormat = {
        formatStr = formatStr,
        formatMode = 0,
        formatHeroId = self.m_heroId,
        formatDragonUUid = dragonUuid,
        formatAormation = self.m_aormationId,
        sumFormat = sumFormat,
    }

    local json = require("CommonLib.dkjson")
    local lastFormatStr = json.encode(lastFormat)
    local key = self.m_saveArenaFormation and "lastArenaFormation" or "lastFamFormation"
    CCUserDefault:sharedUserDefault():setStringForKey(key, lastFormatStr)
end

function BattleView:initFromLastFormation()
    if not (self.m_saveArenaFormation or self.m_saveFamFormation) then
        return
    end

    if self.m_saveFamFormation then
        local temp_lvSet = self.m_lvSet
        self.m_lvSet = 0
        self:initTreasureFamMonsterInfo()
        self.m_lvSet = temp_lvSet
    elseif (CCCommonUtilsForLua:isFunOpenByKey("new_go_battle")) and self.m_bType ~= MarchMethodType.FightDeath then
        -- 编队显示所有部队 穿透兵种等级限制
        local temp_lvSet = self.m_lvSet
        self.m_lvSet = 0
        self:generateData()
        self.m_lvSet = temp_lvSet
    end

    local key = self.m_saveArenaFormation and "lastArenaFormation" or "lastFamFormation"
    local lastFormatStr = CCUserDefault:sharedUserDefault():getStringForKey(key, "")
    if lastFormatStr == "" then
        self:onClickQuickBtn(nil, cc.CONTROL_EVENTTYPE_TOUCH_DOWN)
        return
    end

    self.soilderChallengeType = SoldierChallengeType.SOILDERCHALLENGETYPE_DEFAULT
    self:setChallengePopClose(nil)
    self.m_formationName:setString("")
    self.m_formationName:setVisible(false)
    
    local lastFormatJson = utils.jsonDecode(lastFormatStr)

    local flag = lastFormatJson.formatStr ~= ""
    if flag then
        local formatStr = lastFormatJson.formatStr
        local dataVec = string.split(formatStr, "|")
        local sumFormat = 0
        if #dataVec > 0 then
            for index, value in ipairs(dataVec) do
                local itemVec = string.split(value, ",")
                if #itemVec == 2 then
                    sumFormat = sumFormat + atoi(itemVec[2])
                end
            end
        end

        lastFormatJson.sumFormat = sumFormat

        -- 先判断总上限是否超出,超出按照当前比例换算
        -- 如果是百分比配置方式,亦按照比例换算
        local numTotal = sumFormat
        local maxForceNum = self:getMaxSoilderNum()
        local mode = lastFormatJson.formatMode
        self:unselectAll()
        local method = ""
        if (numTotal > maxForceNum or mode == 1) then
            method = self:resetFormatStrByIndex(lastFormatJson, maxForceNum)
        else
            method = lastFormatJson.formatStr
        end
        
        local vector1 = splitString(method, "|")
        for index, value in ipairs(vector1) do
            vector1[index] = splitString(value, ",")
        end

        -- 等级排序
        local sortFunc = function (info1, info2)
            local army1Level = atoi(info1[1]) % 100;
            local army2Level = atoi(info2[1]) % 100;
            return army1Level > army2Level
        end
        table.sort(vector1, sortFunc)
        local num = #vector1
        
        -- 判断单支兵种数量是否超出，超出就用现有部分
        
        -- 出兵限制
        for index, value in ipairs(vector1) do
            local vector2 = value
            if (#vector2 == 2) then
                local selNum = tonumber(vector2[2])
                
                local arm = CCCommonUtilsForLua:getPropById(vector2[1], "arm")
                local armType = tonumber(arm)
                
                local tmpFreeSoldiers = TroopsController:call("getInstance"):getProperty("m_tmpFreeSoldiers")
                local battleInfos = TroopsController:call("getInstance"):getProperty("m_tmpBattleInfos")
                local totalNum = (tmpFreeSoldiers[vector2[1]] or 0) + (battleInfos[vector2[1]] or 0)
                if (selNum > totalNum) then
                    TroopsController:call("getInstance"):call("updateTmpBattleData", vector2[1], totalNum, vector2[1],false)
                else
                    TroopsController:call("getInstance"):call("updateTmpBattleData", vector2[1], selNum, vector2[1],false)
                end
            else
                CCCommonUtilsForLua:call("flyText", _lang("103686"))
                return
            end
        end

        TroopsController:call("getInstance"):call("makeLoadNumAll")

        self:updateInfo()
        if (num == 0) then
            local use_union_format = self.m_diyRally > 0 and CCCommonUtilsForLua:isFunOpenByKey("arrange_arms")
            CCCommonUtilsForLua:call("flyText", use_union_format and _lang("9711888") or _lang("103685"))
        end

        if (CCCommonUtilsForLua:isFunOpenByKey("general_battle") and lastFormatJson.formatHeroId ~= "") then
            local heroId = lastFormatJson.formatHeroId
            local heroInfo = HeroManager.getHeroInfoById(heroId)
            if (heroInfo) then
                local battle = 0
                if (heroInfo["battle"]) then
                    battle = tonumber(heroInfo["battle"])
                end

                local state = 1
                if (heroInfo["state"]) then
                    local dou = tonumber(heroInfo["state"])
                    if dou then
                        state = dou
                    end
                end
                
                if (state == 1 and battle == 1 and not self:isInVoidBattleField(heroId, 0)) then
                    self:setHero(CCString:create(heroId))
                else
                    CCCommonUtilsForLua:call("flyHint", "", "", _lang("164969"))
                end
            end
        end

        if (CCCommonUtilsForLua:isFunOpenByKey("dragon_battle") and not self:checkDragonAtDestnation() and lastFormatJson.formatDragonUUid ~= "") then
            local dragonUuid = lastFormatJson.formatDragonUUid
            local dragonInfo = DragonController:call("getDragonInfoByUuid", dragonUuid)
            if dragonInfo ~= nil then
                --【awen】使用编队时，如果龙的友好度为0或正在驻守，不能选择
                if (CCCommonUtilsForLua:isFunOpenByKey("dragon_friend_polish")) then
                    -- 139341  龙处于驻守状态，无法出征
                    if (dragonInfo:call("getUseFlag") == 1) then
                        CCCommonUtilsForLua:call("flyHint", "", "", _lang("139341"))
                        return
                    end
                end
                
                if (dragonInfo:call("getInMarch") == false and dragonInfo:call("getObtain") and dragonInfo:call("getState") == DragonState.Dragon_Normal and not self:isInVoidBattleField(dragonUuid, 1)) then
                    local dragonIndex = DragonController:call("getDragonIndexByUuid", dragonUuid)
                    self:setDragon(CCInteger:create(dragonIndex))
                else
                    CCCommonUtilsForLua:call("flyHint", "", "", _lang("164970"))
                end
            end
        end
        
        if lastFormatJson.formatAormation ~= "" then
            local aormationId = lastFormatJson.formatAormation
            local dict = CCDictionary:create()
            dict:setObject(CCString:create(aormationId), "aormationId")
            -- LuaController::getInstance()->fireEventRef("checkAormationState", &dict)
            if isFunOpenByKey('formation_train') then
                FormationTrainCtr.getInstance():checkAormationState(dict)
            else
                TacticalDepController.getInstance():checkAormationState(dict)
            end
        end
    else
        -- CCCommonUtilsForLua:call("flyText", use_union_format and _lang("9711888") or _lang("103685"))
    end
    TroopsController:call("getInstance"):call("changeArrTime")
    self:makeArrTime(nil)
end

function BattleView:resetFormatStrByIndex(lastFormatJson, maxCanTroop)
    local numTotal = lastFormatJson.sumFormat
    local oldFormatStr = lastFormatJson.formatStr
    local shouldScale = maxCanTroop/numTotal
    
    local dataMap = {}
    local modelItemVec = {}
    modelItemVec = string.split(oldFormatStr, "|")

    local tempSum = 0
    local lastKey = nil
    for index, value in ipairs(modelItemVec) do
        local modelStr = modelItemVec[index]
        local detailVec = string.split(modelStr, ",")
        if #detailVec == 2 then
            local id = atoi(detailVec[1])
            local num = atoi(detailVec[2])
            dataMap[id] = floor(num * shouldScale)
            tempSum = tempSum + dataMap[id]
            lastKey = id
        end
    end

    if tempSum < maxCanTroop then
        local sub = maxCanTroop - tempSum
        if lastKey then
            dataMap[lastKey] = dataMap[lastKey] + sub
        end
    end

    local newStr = ""
    for key, value in pairs(dataMap) do
        local id = CC_ITOA(key)
        local num = CC_ITOA(value)
        if newStr == "" then
            newStr = string.join(",", id, num)
        else
            newStr = string.format("%s|%s,%s", newStr, id, num)
        end
    end
    
    return newStr
end

function BattleView:clickFormation(index)
    if (self.m_battlType == PveTrainingType.PveHeroTraining and CCCommonUtilsForLua:isFunOpenByKey("test_hero_switch")) then
        self:usePveTeam()
        return
    elseif self.m_bType == MarchMethodType.FightDeath and CCCommonUtilsForLua:isFunOpenByKey("player_battle") then
        return
    end
    
    -- [awen-junyu] 当自定义集结打开，使用联盟编队
    local use_union_format = self.m_diyRally > 0 and CCCommonUtilsForLua:isFunOpenByKey("arrange_arms")
    if use_union_format then
        index = index + 100
    end

    -- 判定空编队逻辑前移
    local flag = TroopsController:call("getInstance"):call("getFormatStrByIndex", index) ~= ""
    if not flag then
        CCCommonUtilsForLua:call("flyText", use_union_format and _lang("9711888") or _lang("103685"))
        return
    end

    if isFunOpenByKey("angel_army") then
        self.angelArmyId_format = TroopsController:call("getFormatAngleArmyIdByIndex", index)
    end

    if isFunOpenByKey("night_army") then
        self.nightArmyId_format = TroopsController:call("getFormatSpecialArmyIdByIndex", index, SpecialArmyGroup.NIGHT_ARMY)
    end

    if (CCCommonUtilsForLua:isFunOpenByKey("new_go_battle")) and self.m_bType ~= MarchMethodType.FightDeath then
        -- 编队显示所有部队 穿透兵种等级限制
        local temp_lvSet = self.m_lvSet
        self.m_lvSet = 0
        self:generateData()
        self.m_lvSet = temp_lvSet
    end

    self.soilderChallengeType = SoldierChallengeType.SOILDERCHALLENGETYPE_DEFAULT
    self:setChallengePopClose(nil)
    self.m_formationName:setString("")
    self.m_formationName:setVisible(false)
    self.m_index = index

    if flag then
        -- 先判断总上限是否超出,超出按照当前比例换算
        -- 如果是百分比配置方式,亦按照比例换算
        local numTotal = TroopsController:call("getInstance"):call("getFormatSumByIndex", index)
        local maxForceNum = self:getMaxSoilderNum()
        local mode = TroopsController:call("getInstance"):call("getFormatModeByIndex", index)
        self:unselectAll()
        local method = ""
        if (numTotal > maxForceNum or mode == 1) then
            method = TroopsController:call("getInstance"):call("resetFormatStrByIndex", index, maxForceNum)
        else
            method = TroopsController:call("getInstance"):call("getFormatStrByIndex", index)
        end
        
        local vector1 = splitString(method, "|")
        for index, value in ipairs(vector1) do
            vector1[index] = splitString(value, ",")
        end

        -- 等级排序
        local sortFunc = function (info1, info2)
            local army1Level = atoi(info1[1]) % 100;
            local army2Level = atoi(info2[1]) % 100;
            return army1Level > army2Level
        end
        table.sort(vector1, sortFunc)
        local num = #vector1
        
        -- 判断单支兵种数量是否超出，超出就用现有部分
        
        -- 出兵限制
        for index, value in ipairs(vector1) do
            local vector2 = value
            if (#vector2 == 2) then
                local selNum = tonumber(vector2[2])
                
                local arm = CCCommonUtilsForLua:getPropById(vector2[1], "arm")
                local armType = tonumber(arm)
                
                local tmpFreeSoldiers = TroopsController:call("getInstance"):getProperty("m_tmpFreeSoldiers")
                local battleInfos = TroopsController:call("getInstance"):getProperty("m_tmpBattleInfos")
                local totalNum = (tmpFreeSoldiers[vector2[1]] or 0) + (battleInfos[vector2[1]] or 0)
                if (selNum > totalNum) then
                    TroopsController:call("getInstance"):call("updateTmpBattleData", vector2[1], totalNum, vector2[1],false)
                else
                    TroopsController:call("getInstance"):call("updateTmpBattleData", vector2[1], selNum, vector2[1],false)
                end
            else
                CCCommonUtilsForLua:call("flyText", _lang("103686"))
                return
            end
        end

        TroopsController:call("getInstance"):call("makeLoadNumAll")

        self:updateInfo()
        if (num == 0) then
            CCCommonUtilsForLua:call("flyText", use_union_format and _lang("9711888") or _lang("103685"))
        end
        local name = TroopsController:call("getFormatNameByIndex", index)
        self.m_formationName:setString(name)
        
        if (CCCommonUtilsForLua:isFunOpenByKey("general_battle") and TroopsController:call("getInstance"):call("getFormatHeroIdByIndex", index) ~= "") then
            local heroId = TroopsController:call("getInstance"):call("getFormatHeroIdByIndex", index)
            local heroInfo = HeroManager.getHeroInfoById(heroId)
            if (heroInfo) then
                local battle = 0
                if (heroInfo["battle"]) then
                    battle = tonumber(heroInfo["battle"])
                end

                local state = 1
                if (heroInfo["state"]) then
                    local dou = tonumber(heroInfo["state"])
                    if dou then
                        state = dou
                    end
                end
                
                if (state == 1 and battle == 1 and not self:isInVoidBattleField(heroId, 0)) then
                    self:setHero(CCString:create(heroId))
                else
                    CCCommonUtilsForLua:call("flyHint", "", "", _lang("164969"))
                end
            end
        end

        if (CCCommonUtilsForLua:isFunOpenByKey("dragon_battle") and not self:checkDragonAtDestnation() and TroopsController:call("getInstance"):call("getFormatDragonUUidByIndex", index) ~= "") then
            local dragonUuid = TroopsController:call("getInstance"):call("getFormatDragonUUidByIndex", index)
            local dragonInfo = DragonController:call("getDragonInfoByUuid", dragonUuid)
            if dragonInfo ~= nil then
                --【awen】使用编队时，如果龙的友好度为0或正在驻守，不能选择
                if (CCCommonUtilsForLua:isFunOpenByKey("dragon_friend_polish")) then
                    -- 139341  龙处于驻守状态，无法出征
                    if (dragonInfo:call("getUseFlag") == 1) then
                        CCCommonUtilsForLua:call("flyHint", "", "", _lang("139341"))
                        return
                    end
                end
                
                if (dragonInfo:call("getInMarch") == false and dragonInfo:call("getObtain") and dragonInfo:call("getState") == DragonState.Dragon_Normal and not self:isInVoidBattleField(dragonUuid, 1)) then
                    local dragonIndex = DragonController:call("getDragonIndexByUuid", dragonUuid)
                    self:setDragon(CCInteger:create(dragonIndex))
                else
                    CCCommonUtilsForLua:call("flyHint", "", "", _lang("164970"))
                end
            end
        end
        
        if (TroopsController:call("getFormatAormationIdByindex", index) ~= "") then
            local aormationId = TroopsController:call("getFormatAormationIdByindex", index)
            local dict = CCDictionary:create()
            dict:setObject(CCString:create(aormationId), "aormationId")
            -- LuaController::getInstance()->fireEventRef("checkAormationState", &dict)
            if isFunOpenByKey('formation_train') then
                FormationTrainCtr.getInstance():checkAormationState(dict)
            else
                TacticalDepController.getInstance():checkAormationState(dict)
            end
        end
    else
        CCCommonUtilsForLua:call("flyText", use_union_format and _lang("9711888") or _lang("103685"))
    end
    TroopsController:call("getInstance"):call("changeArrTime")  -- TroopsController::getInstance()->changeArrTime();
    self:makeArrTime(nil)
end


-- 虚空战场增加判断
function BattleView:isInVoidBattleField(id, type)
    local isIn = false
    if (CCCommonUtilsForLua:isFunOpenByKey("vacant_on") and GlobalData:call("shared"):getProperty("isInVoidBattlefieldServer")) then
        local vecInfo = {}
        if (type == 0) then  -- 判断英雄
            vecInfo = GlobalData:call("shared"):getProperty("voidBattlefieldHeroList")
        else
            vecInfo = GlobalData:call("shared"):getProperty("voidBattlefieldDragonList")
        end
        
        for index, value in ipairs(vecInfo) do
            if (id == value) then
                isIn = true
                break
            end
        end
    end
    return isIn
end


function BattleView:onHelpClick(pSender, pCCControlEvent)
    if GlobalData:call("shared"):getProperty("serverType") == ServerType.SERVER_WORLD_CRAFT then
        local perLoad = atoi(CCCommonUtilsForLua:call("getPropByIdGroup", "data_config", "worldCraft", "k5"))
        local view = TipsView:call("create", getLang("45000768", CC_CMDITOA(perLoad)))
        PopupViewController:addPopupView(view)
    else
        local view = TipsView:call("create", getLang("102194"))
        PopupViewController:addPopupView(view)
    end
    -- PopupViewController::getInstance()->addPopupView(TipsView::create(_lang("102194")));
end


function BattleView:onSvipHelpClick(pSender, pCCControlEvent)
    if isIOS() then
        GlobalData:call("shared"):setProperty("isBind", true) -- GlobalData::shared()->isBind = true;
    end
    self:setChallengePopClose(nil)
    FaqHelper:call("getInstance"):call("showSingleFAQ", "45223")
end

function BattleView:resetArmyIdFormat()
    self.angelArmyId_format = nil
    self.nightArmyId_format = nil
end

function BattleView:onClickMarchBtn(pSender, pCCControlEvent)
    if GuideController:call("isInTutorial") and GuideController:call("getGuideMonster") then
        self:closeSelf()
        return
    end
    self:setChallengePopClose(nil)
    local haveSoldier = false
    local battleInfos = TroopsController:call("getInstance"):getProperty("m_tmpBattleInfos")
    for key, value in pairs(battleInfos) do 
        if (value > 0) then
            haveSoldier = true
            break;
        end
    end
    
    local info = WorldController:call("getCityInfoByIndex", self.m_targetIndex)
    
    if (TroopsController:call("getInstance"):call("isHaveDefHeroInBattle") and TroopsController:call("getInstance"):getProperty("m_isNotice")) then
        YesNoDialog:call("show", _lang("102193"), cc.CallFunc:create(function() self:march() end), 0, false, nil, cc.CallFunc:create(function() self:notice() end))
    else
        if (info == nil or self.m_battlType == CommericalType.CommericalBattle or self.m_battlType == ArenaBattleType.AllianceDuelBattle) then
            if (self.m_battlType == PveTrainingType.PveHeroTraining and CCCommonUtilsForLua:isFunOpenByKey("test_hero_switch")) then
                if (self.m_heroId == "") then
                    CCCommonUtilsForLua:call("flyHint", "", "", _lang("4502038"))  -- 提示 4502038=您必须选择一个英雄出征
                    return
                end

                if (self.m_maxForceNumPve <= 0) then
                    CCCommonUtilsForLua:call("flyHint", "", "", _lang("4502042"))  -- 提示 4502042=您当前英雄携带的士兵数量为0，无法战斗
                    return
                end
                self:marchForPve()
                return
            elseif (self.m_battlType == TreasureFamType.TreasureFamMonster and CCCommonUtilsForLua:isFunOpenByKey("treasure_fam_on")) then
                self:marchForTreasureMonster()
                return
            elseif (self.m_battlType == TreasureFamType.TreasureFamMine and CCCommonUtilsForLua:isFunOpenByKey("treasure_fam_on")) then
                self:marchForTreasurePVP()
                return
            elseif (self.m_battlType == ArenaBattleType.ArenaBattle) then
                self:marchForArena()
                return
            elseif (self.m_battlType == ArenaBattleType.AllianceDuelBattle) then
                self:marchForAllianceDuel()
                return
            elseif (self.m_battlType == CommericalType.CommericalBattle) then
                self:marchForCommercial()
                return
            end
            if self.m_targetType == WorldCityType.dark_civilization then
                WorldController:call("getInstance"):call("sendWorldMarchCheckCommand", self.m_targetIndex, self.m_targetType)
                GameController:call("getInstance"):call("showWaitInterface")
            else
                self:march()
            end
            
        else
            local info_cityType = info:getProperty("cityType")
            local info_luaType = info:getProperty("luaType")
            if ( info_cityType   == WorldCityType.ResourceTile
                or info_cityType == WorldCityType.ResourceBattleTile
                or info_cityType == WorldCityType.NewResourceBattleTile
                or info_cityType == WorldCityType.OriginTile
                or info_cityType == WorldCityType.CampTile
                or info_luaType  == WorldCityType.expedition_super_mine
                or info_luaType  == WorldCityType.expedition_super_mine_sub
                or info_luaType  == WorldCityType.dark_civilization) then
            
                WorldController:call("getInstance"):call("sendWorldMarchCheckCommand", self.m_targetIndex, info_cityType)
                GameController:call("getInstance"):call("showWaitInterface")
            elseif (info_cityType == WorldCityType.Barbarian) then
                local power = 0
                local battleInfos = TroopsController:call("getInstance"):getProperty("m_tmpBattleInfos")
                local armyList = GlobalData:call("shared"):getProperty("armyList")
                for key, value in pairs(battleInfos) do 
                    if (value > 0) then
                        if (armyList[key] ~= nil) then
                            local armyPower = armyList[key]:getProperty("power")
                            power = power + value * armyPower
                        end
                    end
                end
                
                local info_power = info:getProperty("m_barbarianInfo"):getProperty("power")
                if (power <= info_power) then
                    local dialog = YesNoDialog:call("showVariableTitle", _lang("165005"), cc.CallFunc:create(function() self:march() end), _lang("105153"))
                    dialog:call("setNoButtonTitle",  _lang("cancel_btn_label"))
                    dialog:call("showCancelButton")
                elseif(power > info_power and power <= info_power * 2) then
                    local dialog = YesNoDialog:call("showVariableTitle", _lang("165006"), cc.CallFunc:create(function() self:march() end), _lang("105153"))
                    dialog:call("setNoButtonTitle",  _lang("cancel_btn_label"))
                    dialog:call("showCancelButton")
                else
                    self:march()
                end
            elseif (info_cityType == WorldCityType.LuaNewTile and info_luaType == WorldCityType.city_barracks) then
                -- 营地次数判断
                self:marchForBarrack()
            else
                if (self.m_bType == MarchMethodType.COSDonateSoldireMarch) then
                    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
                    local key = "COSDonateSoldireTipsView" + playerInfo:getProperty("uid")
                    local keyValue = cc.UserDefault:getInstance():getIntegerForKey(key, 0);
                    local now = getTimeStamp()
                    if (now > keyValue) then
                        COSDataController.getInstance():fireEventRef("march") -- LuaController::getInstance()->fireEventRef("onCOSDataCtlEvent", "march");
                        return
                    end
                end
                self:march()
            end
        end
    end
end


---------------- 这段逻辑可以分离
function BattleView:marchForBarrack()
    WorldController:call("getInstance"):call("sendWorldMarchCheckCommand", self.m_targetIndex, WorldCityType.city_barracks)
    GameController:call("getInstance"):call("showWaitInterface")
end

function BattleView:marchForPve()
    local soldierDict = TroopsController:call("getInstance"):call("saveBattle")
    local soldierTable = dictToLuaTable(soldierDict)
    local armyMap = {}
    for key, value in pairs(soldierTable) do
        local valueInt = tonumber(value)
        if valueInt ~= nil then
            local keyInt = tonumber(key)
            armyMap[keyInt] = valueInt
        end
    end

    local army     = "";
    local armySave = "";
    local sign     = "";
    local max      = self:getMaxSoilderNum();
    local armyList = GlobalData:call("shared"):getProperty("armyList")
    for key, value in pairs(armyMap) do
        local keyStr = tostring(key)
        local armyIt = armyList[keyStr]
        if (armyIt ~= nil) then
            -- local load   = CC_ITOA(armyIt:getProperty("load"))
            -- local speed  = CC_ITOA(armyIt:getProperty("speed"))
            local armyId = armyIt:getProperty("armyId")
            army = string.join("", army, sign, armyId, ";", CC_ITOA(value))
            local per = value * 1000 / max
            armySave = string.join("", armySave, sign, armyId, ";", CC_ITOA(per))
            sign = "|" -- 为了拼分割符
        end
    end

    self:retain()
    PopupViewController:call("goBackPopupView")
    local dict = CCDictionary:create()
    dict:setObject(CCString:create(tostring(self.m_targetIndex)), "XXindex")
    dict:setObject(CCString:create(army),"army")
    dict:setObject(CCString:create(tostring(self.m_queueId)),"queueId")
    dict:setObject(CCString:create(tostring(self.m_levelIndex)),"level")
    dict:setObject(CCString:create(tostring(self.isEndless)),"isEndless")
    -- LuaController::getInstance()->fireEventRef("marchForPve", &dict);
    -- local dataController = require("game.Training.PveDataController")
    PveDataController:getInstance():sendChallengePve(dict)

    cc.UserDefault:getInstance():setStringForKey(PVE_TEAM_CACHE, armySave)
    self:release()
end

function BattleView:marchForTreasureMonster()
    local soldierDict = TroopsController:call("getInstance"):call("saveBattle")
    local soldierTable = dictToLuaTable(soldierDict)
    local armyMap = {}
    self:saveLastFormation()

    for key, value in pairs(soldierTable) do
        local valueInt = tonumber(value)
        if valueInt ~= nil then
            local keyInt = tonumber(key)
            armyMap[keyInt] = valueInt
        end
    end

    local army = "";
    local sign = "";
    for key, value in pairs(armyMap) do
        army = string.join("", army, sign, CC_ITOA(key), ";", CC_ITOA(value))
        sign = "|"   -- 为了拼分割符
    end

    self:retain()
    PopupViewController:call("goBackPopupView")
    
    local dragonUuid = "";
    local dragonInfo = DragonController:call("getInstance"):call("getDragonInfoByIndex", self.m_dragonIndex)
    if dragonInfo ~= nil then
        dragonUuid = dragonInfo:call("getUuid")
    end

    local dict = CCDictionary:create()
    dict:setObject(CCString:create(army),"army");
    dict:setObject(CCString:create(self.m_heroId), "generalId");
    dict:setObject(CCString:create(dragonUuid), "dragonId");
    dict:setObject(CCString:create(self.m_aormationId),"aormationId");
    TreasureFamManager:marchForTreasureMonster(dict)
    self:release()
end

function BattleView:marchForTreasurePVP()
    local soldierDict = TroopsController:call("getInstance"):call("saveBattle")
    local soldierTable = dictToLuaTable(soldierDict)
    local armyMap = {}

    for key, value in pairs(soldierTable) do
        local valueInt = tonumber(value)
        if valueInt ~= nil then
            local keyInt = tonumber(key)
            armyMap[keyInt] = valueInt
        end
    end
    
    local army = "";
    local sign = "";
    for key, value in pairs(armyMap) do
        army = string.join("", army, sign, CC_ITOA(key), ";", CC_ITOA(value))
        sign = "|"   -- 为了拼分割符
    end

    self:retain()
    PopupViewController:call("goBackPopupView")
    
    local dragonUuid = "";
    local dragonInfo = DragonController:call("getInstance"):call("getDragonInfoByIndex", self.m_dragonIndex)
    if dragonInfo ~= nil then
        dragonUuid = dragonInfo:call("getUuid")
    end

    local dict = CCDictionary:create()
    dict:setObject(CCString:create(army),"army");
    dict:setObject(CCString:create(self.m_heroId), "generalId")
    dict:setObject(CCString:create(dragonUuid), "dragonId")
    dict:setObject(CCString:create(self.m_aormationId),"aormationId")
    dict:setObject(CCInteger:create(self.m_mineIndex), "mineIndex")
    dict:setObject(CCString:create(self.m_mineOwnerUid), "mineOwnerUid")
    TreasureFamManager:marchForTreasureMine(dict)
    self:release()
end

function BattleView:marchForArena()
    local soldierDict = TroopsController:call("getInstance"):call("saveBattle")
    self:saveLastFormation()

    self:retain()
    PopupViewController:call("goBackPopupView")
    
    local dragonUuid = "";
    local dragonInfo = DragonController:call("getInstance"):call("getDragonInfoByIndex", self.m_dragonIndex)
    if dragonInfo ~= nil then
        dragonUuid = dragonInfo:call("getUuid")
    end

    local dict = CCDictionary:create()
    dict:setObject(CCString:create(self.m_arenaUid), "matcher")
    dict:setObject(CCString:create(dragonUuid), "petDragonUid")
    dict:setObject(CCString:create(self.m_heroId), "generalId")
    dict:setObject(CCString:create(self.m_aormationId), "aormationId")
    dict:setObject(soldierDict, "soldiers")
    CCSafeNotificationCenter:postNotification("RacingOpponent:marchForArena", dict)
    self:release();
end

function BattleView:marchForAllianceDuel()
    local soldierDict = TroopsController:call("getInstance"):call("saveBattle")
    
    self:retain()
    PopupViewController:call("goBackPopupView")
    
    local dragonUuid = "";
    local dragonInfo = DragonController:call("getInstance"):call("getDragonInfoByIndex", self.m_dragonIndex)
    if dragonInfo ~= nil then
        dragonUuid = dragonInfo:call("getUuid")
    end

    local dict = CCDictionary:create()
    dict:setObject(CCString:create(CC_ITOA(self.m_allianceDuelPointIndex)), "pointIndex")
    dict:setObject(CCString:create(dragonUuid), "petDragonUid")
    dict:setObject(CCString:create(self.m_heroId), "generalId")
    dict:setObject(CCString:create(self.m_aormationId), "aormationId")
    dict:setObject(soldierDict, "soldiers")
    CCSafeNotificationCenter:postNotification("AllianceDuel:march", dict)
    self:release()
end

function BattleView:marchForCommercial()
    local soldierDict = TroopsController:call("getInstance"):call("saveBattle")
    
    self:retain()
    PopupViewController:call("goBackPopupView")
    
    local dragonUuid = "";
    local dragonInfo = DragonController:call("getInstance"):call("getDragonInfoByIndex", self.m_dragonIndex)
    if dragonInfo ~= nil then
        dragonUuid = dragonInfo:call("getUuid")
    end

    local dict = CCDictionary:create()
    dict:setObject(CCString:create(self.m_commercialId), "id")
    dict:setObject(CCString:create(dragonUuid), "petDragonUid")
    dict:setObject(CCString:create(self.m_heroId), "generalId")
    dict:setObject(CCString:create(self.m_aormationId), "aormationId")
    dict:setObject(soldierDict, "soldiers")
    CCSafeNotificationCenter:postNotification(self.m_commercialKey, dict)
    self:release()
end

--怀旧服出征
function BattleView:marchForGreenServer()
    local size = self.m_infoList:getContentSize()
    self.m_infoList:setContentSize(CCSize(size.width, size.height + 0))
    self.m_cosADSpr:setPositionY(130)--广告图
    self.m_extraNode:setVisible(false)--阵法、英雄、龙等选项
    --屏蔽增益区
    local buffNode = self.m_buffArea:getParent()
    if (buffNode) then
        buffNode:setVisible(false)
    end
    self.m_cosActNode:setVisible(true)
    self.m_cosTipsLabel:setVisible(false)
    local pFrame = CCSpriteFrameCache:sharedSpriteFrameCache():spriteFrameByName("greenServer_zhuzheng.png")
    self.m_cosADSpr:setSpriteFrame(pFrame)
    self:generateData()
end

function BattleView:setTreasureFamInfo(type, mineIndex, mineOwnerUid, maxArmyLimit)
    self.m_battlType = type
    self.m_mineIndex = mineIndex
    self.m_mineOwnerUid = mineOwnerUid
    self.m_maxForceNumForTreasureMine = maxArmyLimit
    self.m_maxForceNumForTreasureMonster = 0
    return true
end

function BattleView:setArenaUid(type, uid)
    self.m_arenaUid = uid
    self.m_battlType = type
    return true
end

function BattleView:setAllianceDuelPointIndex(type, allianceDuelPointIndex)
    self.m_allianceDuelPointIndex = allianceDuelPointIndex
    self.m_battlType = type
    return true
end

function BattleView:setCommercialData(type, id, key, maxForceNum)
    self.m_battlType = type
    self.m_commercialId = id
    self.m_commercialKey = key
    self.m_maxForceNumForCmr = maxForceNum or 0
    self.m_commercialTime = 0
    self.m_targetIndex = -1
    return true
end

function BattleView:setFightDeath(armyScope, armyMinLv)
    self.m_armyScope = atoi(armyScope)
    self.m_armyMinLv = atoi(armyMinLv)
    return true
end

function BattleView:checkCanMarch(paramDict)
    GameController:call("getInstance"):call("removeWaitInterface")
    local result = dictToLuaTable(paramDict)
    -- dump(result, "---------- checkCanMarch result")

    if (result and result["errorCode"] == Error_OP_FAILURE) then
        -- CCLOGFUNCF("出现错误,关闭此面板");
        PopupViewController:call("removeAllPopupView")
    else
        local params = result["params"]
        if (params ~= nil) then
            if tonumber(params["needBreakShield"]) == 1 then
                if (GuideController:call("share"):call("getCurrentId") == "3030700") then
                    PopupViewController:call("removeAllPopupView")
                    GuideController:call("share"):call("setGuideEnd")
                    GuideController:call("share"):call("setGuide", "3030800")
                    return
                end
                
                -- 101438=侦查或攻击敌人都会解除战争守护状态，是否继续操作？
                local warningTips = ToolController:call("getBeforeBattleWarning")
                if warningTips ~= "" then
                    YesNoDialog:call("show", warningTips, cc.CallFunc:create(function() self:march() end))
                else
                    self:march()
                end
            else
                local info = WorldController:call("getCityInfoByIndex", self.m_targetIndex)
                local info_cityType = nil
                local info_luaType = nil
                if info ~= nil then
                    info_cityType = info:getProperty("cityType")
                    info_luaType = info:getProperty("luaType")
                end
                
                if (info == nil) then
                    self:march()
                elseif ((info_cityType == WorldCityType.ResourceTile or info_cityType == WorldCityType.ResourceBattleTile or info_cityType == WorldCityType.NewResourceBattleTile
                        or (info_cityType == WorldCityType.LuaNewTile and info_luaType == WorldCityType.city_barracks)) and info:getProperty("playerName") ~= "") then
                    local marchingAlertFlag = false
                    local marchInfos = WorldController:call("getInstance"):getProperty("m_marchInfo")
                    for key, value in pairs(marchInfos) do
                        if(value:getProperty("stateType") == MarchStateType.StateMarch and value:getProperty("endPointIndex") == self.m_targetIndex) then
                            marchingAlertFlag = true
                            break
                        end
                    end
                    
                    if (marchingAlertFlag) then
                        -- 108897=请注意！有其他领主正在往该资源点行军，如果您选择继续行军，可能会引发战争！是否继续出征？
                        YesNoDialog:call("marchAlertShow", _lang("108897"), cc.CallFunc:create(function() self:march() end), cc.CallFunc:create(function() self:closeSelf() end))
                    else
                        self:march()
                    end
                else
                    self:march()
                end
            end
        else
            self:march()
        end
    end
end

function BattleView:updateArmyNumber(obj)
    local armyList = GlobalData:call("shared"):getProperty("armyList") 
    local hasNewArmy = false
    for key, value in pairs(armyList) do
        if value:getProperty("isArmy") then
            local free = value:getProperty("free")
            local tmpConfSoldiers = TroopsController:call("getInstance"):getProperty("m_tmpConfSoldiers")
            if tmpConfSoldiers[key] and free ~= tmpConfSoldiers[key] then
                local tmpFreeSoldiers = TroopsController:call("getInstance"):getProperty("m_tmpFreeSoldiers")
                local count = free - tmpConfSoldiers[key]
                tmpConfSoldiers[key] = free
                tmpFreeSoldiers[key] = tmpFreeSoldiers[key] + count

                TroopsController:call("getInstance"):setProperty("m_tmpFreeSoldiers", tmpFreeSoldiers)
                TroopsController:call("getInstance"):setProperty("m_tmpConfSoldiers", tmpConfSoldiers)
            end
        end
    end

    return
end

function BattleView:checkPowerEnough(  )
    local isEnough = true
    local stamina = WorldController:call("getInstance"):getProperty("currentStamine")
    local cost = 0
    if self.m_bType == MarchMethodType.DarkCivOne or self.m_bType == MarchMethodType.DarkCivTwo or self.m_bType == MarchMethodType.DarkCivThree or self.darkCiv>0 then
        cost = self:getDarkCivPower()
    end
    if stamina < cost then
        isEnough = false
        CCCommonUtilsForLua:call("flyHint", "", "", _lang("137490"))
    end
    return isEnough
end

function BattleView:march()
    -- TRACETICK_FUNCTION();
    CCSafeNotificationCenter:postNotification(GUIDE_INDEX_CHANGE, CCString:create("ED_attack"))
    if (self.m_civiBuildTag) then
        self:shareCiviMiracleBuild()
    end

    local dict = CCDictionary:create()
    local soldierDict = TroopsController:call("getInstance"):call("saveBattle")
    local soldierTable = dictToLuaTable(soldierDict)
    local isNoElement = true
    for key, value in pairs(soldierTable) do
        if value > 0 then
            isNoElement = false
            break
        end
    end
    if isNoElement then
        YesNoDialog:call("showYesDialog", _lang("105112"))  --105112=没有选择出征的士兵
        return;
    end

    if isFunOpenByKey("angel_army") then
        local armyId_march = require("game.army.angel.AngelArmyController").getInstance():getSettingArmy(1)
        if armyId_march ~= self.angelArmyId_format and string.isNilOrEmpty(self.angelArmyId_format) == false then
            if atoi(soldierTable[self.angelArmyId_format]) > 0 then
                YesNoDialog:call("showYesDialog", _lang("9712460")) --9712460=当前选定天使士兵与设置不符，无法出征，请重新设置天使士兵。
                return
            end
        end
    end

    if isFunOpenByKey("night_army") then
        local armyId_march = require("game.army.angel.AngelArmyController").getInstance():getSettingArmyByGroup(1, SpecialArmyGroup.NIGHT_ARMY)
        if armyId_march ~= self.nightArmyId_format and string.isNilOrEmpty(self.nightArmyId_format) == false then
            if atoi(soldierTable[self.nightArmyId_format]) > 0 then
                YesNoDialog:call("showYesDialog", _lang("9712460")) --9712460=当前选定天使士兵与设置不符，无法出征，请重新设置天使士兵。
                return
            end
        end
    end

    dict:setObject(soldierDict, "soldier")
    dict:setObject(CCInteger:create(self.m_targetIndex), "targetIndex")
    dict:setObject(CCInteger:create(self.m_haveOwner), "haveOwner")
    local arr = CCArray:create()
    dict:setObject(arr, "generals")
    
    local other = ""
    if self.m_bType == MarchMethodType.MethodRally 
        or self.m_bType == MarchMethodType.MethodTeamRally then
        other = CC_ITOA(self.m_wtIndex)
    elseif self.m_bType == MarchMethodType.MethodUnion 
        or self.m_bType == MarchMethodType.MethodTeamUnion then
        other = self.m_other
        if (TroopsController:call("getInstance"):getProperty("m_saveSoldierNum") > self.m_rally) then
            YesNoDialog:call("showYesDialog", _lang_1("115194", CC_ITOA(self.m_rally)))
            return
        end
    elseif self.m_bType == MarchMethodType.MethodYuanSolider then
        if (TroopsController:call("getInstance"):getProperty("m_saveSoldierNum")> self.m_rally) then
            YesNoDialog:call("showYesDialog", _lang_1("115166",CC_ITOA(self.m_rally)))
            return
        end
    end

    SoundController:call("playEffects", Music_Sfx_world_click_march)
    self.m_marchBtn:setEnabled(false)

    --领主死斗
    if self.m_bType == MarchMethodType.FightDeath and CCCommonUtilsForLua:isFunOpenByKey("player_battle") then
        local data = {}
        --英雄
        data.generalId = self.m_heroId
        --龙
        local dragonInfo = DragonController:call("getInstance"):call("getDragonInfoByIndex", self.m_dragonIndex)
        if dragonInfo ~= nil then
            data.petDragonUid = dragonInfo:call("getUuid")
        end
        --阵法
        data.aormationId = self.m_aormationId
        --士兵
        data.soldiers = soldierDict
        require("game.fightDeath.FightDeathController").getInstance():reqEditArmy(data)
        return
    end

    --体力判断
    if not self:checkPowerEnough() then
        return
    end
    if (SceneController:call("getCurrentSceneId") == SCENE_ID_WORLD and self.m_bType ~= MarchMethodType.MethodRally and self.m_bType ~= MarchMethodType.KingdomTeamBattle 
            and self.m_bType ~= MarchMethodType.KingdomTeamAssembly and self.m_bType ~= MarchMethodType.ArenaTeamBattle and self.m_bType ~= MarchMethodType.ArenaTeamAssembly
            and self.m_bType ~= MarchMethodType.DarkCivOne and self.m_bType ~= MarchMethodType.DarkCivThree and self.m_bType ~= MarchMethodType.DarkCivTwo
            and self.m_bType ~= MarchMethodType.MethodTeamRally) then
        local dragonUuid = "";
        local dragonInfo = DragonController:call("getInstance"):call("getDragonInfoByIndex", self.m_dragonIndex)
        if dragonInfo ~= nil then
            dragonUuid = dragonInfo:call("getUuid")
        end
        
        if (self.m_bType == MarchMethodType.COSDonateSoldireMarch) then
            dragonUuid = ""
            self.m_aormationId = ""
            self.m_heroId = ""
        end
    
        -- WorldMapView::instance()->afterMarchDeploy(dict,m_bType,other,m_targetType,m_duelMarch,m_heroId,dragonUuid,m_aormationId, m_vacantFightId, m_plunder);
        local afterMarch = function () 
            -- 杀戮战场，更新出征队列信息
            local serverType = GlobalData:call("shared"):getProperty("serverType")
            if serverType == ServerType.SERVER_ANCESTRAL then
                self:addAttackDataForPubg()
                CCSafeNotificationCenter:postNotification("AncestralTrialMainUI:refreshGeneralProperty")
            end
            self.willCloseSelf = true
        end
        if self.monsterId ~= "" then
            dict:setObject(CCString:create(self.monsterId), "monsterId")
        end

        if self.m_ekPlunder then
            dict:setObject(CCString:create(1), "ekPlunder")
        end

        if CCCommonUtilsForLua:isFunOpenByKey("gather_accelerate") 
            and self:isJoinRally() 
            and not self:isRallyLeftTimeEnough() then 
                local params = {marchTime=self.m_marchTime,rallyEndTime=self.m_rallyEndTime}
                local extParams = {
                    bType = self.m_bType,
                    other = other,
                    targetType = self.m_targetType,
                    duelMarch = self.m_duelMarch,
                    heroId = self.m_heroId,
                    dragonUuid = dragonUuid,
                    aormationId = self.m_aormationId,
                    vacantFightId = self.m_vacantFightId,
                    plunder = self.m_plunder,
                }
                local view = Drequire("game.watchTower.RallyQuickMarchView"):create(params, dict, extParams)
                view:setBack(afterMarch)
                PopupViewController:addPopupView(view)
                self.m_marchBtn:setEnabled(true)
        else 
            WorldMapView:call("instance"):call("afterMarchDeploy", dict, self.m_bType, other, self.m_targetType, self.m_duelMarch, self.m_heroId, dragonUuid, self.m_aormationId, self.m_vacantFightId, self.m_plunder)
            afterMarch()
        end
    else
        if (self.m_bType == -1) then
            return
        end

        if (self.m_specialMass == 1 and self.m_bType ~= MarchMethodType.KingdomTeamAssembly) then
            self.m_bType = MarchMethodType.KingdomTeamBattle
        elseif(self.m_specialMass == 2 and self.m_bType ~= MarchMethodType.ArenaTeamAssembly) then
            self.m_bType = MarchMethodType.ArenaTeamBattle
        end
        
        local march_dict = CCDictionary:create()
        march_dict:setObject(CCString:create(self.m_targetIndex), "index")
        march_dict:setObject(CCString:create(self.m_bType), "marchType")
        march_dict:setObject(CCString:create(1), "ownerFlag")
        march_dict:setObject(soldierDict, "army")
        -- march_dict:setObject(CCArray:create(), "resArr")
        march_dict:setObject(CCString:create(-1), "monsterIndex")
        march_dict:setObject(CCArray:create(), "generals")
        march_dict:setObject(CCString:create(self.m_wtIndex), "wtIndex")
        march_dict:setObject(CCString:create(self.m_other), "teamId")
        march_dict:setObject(CCString:create(-1), "warehouse")
        march_dict:setObject(CCString:create(0), "showPanel")
        march_dict:setObject(CCString:create(self.m_isSuperRally), "isSuperRally")
        -- march_dict:setObject(, "vacantFightId")

        if (self.m_duelMarch) then
            -- cmd->putParam("duel", CCInteger::create(1));
            march_dict:setObject(CCString:create(1), "duel")
        end

        if self.m_ekPlunder then
            march_dict:setObject(CCString:create(1), "ekPlunder")
        end
        
        if (self.m_aormationId ~= "") then
            -- cmd->addExtParam("aormationId",m_aormationId);
            march_dict:setObject(CCString:create(self.m_aormationId), "aormationId")
        end
        
        if (self.m_heroId ~= "") then
            -- cmd->addExtParam("generalId", m_heroId);
            march_dict:setObject(CCString:create(self.m_heroId), "generalId")
        end

        -- [awen-junyu] 将diy集结标志及士兵总数发给后端
        march_dict:setObject(CCString:create(self.m_diyRally), "diyRally")
        if (self.m_diyRally > 0) then
            -- cmd->putParam("isDiyRally", CCInteger::create(1));
            -- cmd->putParam("maxSoilderNum", CCInteger::create(getMaxSoilderNum()));
            march_dict:setObject(CCString:create(1), "isDiyRally")
            march_dict:setObject(CCString:create(self:getMaxSoilderNum()), "maxSoilderNum")
        end

        if self.m_dragonIndex ~= nil then
            march_dict:setObject(CCString:create(self.m_dragonIndex), "dragonIndex")
        end

        local afterMarch = function () 
            -- 检查自动集结是否需要取消当前任务
            if self.m_bType == MarchMethodType.MethodUnion and isFunOpenByKey("monster_boss_modify") then
                require("game.controller.ActBossController").getInstance():checkScheduler(self.m_other)
            end

            cc.UserDefault:getInstance():setIntegerForKey("isSuperRally", self.m_isSuperRally)
            cc.UserDefault:getInstance():setIntegerForKey("isDiyRally", self.m_diyRally)
            cc.UserDefault:getInstance():flush()
        end

        if CCCommonUtilsForLua:isFunOpenByKey("gather_accelerate") 
            and self:isJoinRally() 
            and not self:isRallyLeftTimeEnough() then 
                local params = {marchTime=self.m_marchTime,rallyEndTime=self.m_rallyEndTime}
                local view = Drequire("game.watchTower.RallyQuickMarchView"):create(params, march_dict, nil)
                view:setBack(afterMarch)
                PopupViewController:addPopupView(view)
                self.m_marchBtn:setEnabled(true)
        else 
            WorldController:call("getInstance"):call("sendWorldMarchCommand", march_dict)
            afterMarch()
        end
    end
end

function BattleView:callCloseSelf()
    if self.willCloseSelf then
        self.willCloseSelf = false
        PopupViewController:call("removeAllPopupView")
    end
end

function BattleView:sendChat( type, result )
    -- 发送到聊天
    local params = result["params"]
        if params ~= nil then
            local teamInfo = nil
            if (type == MarchMethodType.KingdomTeamBattle) then
                teamInfo = params["kingdomBattleTeam"]
            else
                teamInfo = params["allianceBattleTeam"]
            end

            if GlobalData:call("shared"):getProperty("teamMode") then
                teamInfo = params["smallBattleTeam"]
            end

            if (teamInfo ~= nil) then
                if CCCommonUtilsForLua:isFunOpenByKey("march_queue_cell_show_team_count") then
                    CCSafeNotificationCenter:postNotification("BuildQueueView::refreshTeamData")
                end

                local waitTime = atoi(teamInfo["waitTime"])/1000;
                -- local waitTime = 0
                -- if (tempTime ~= 0) then
                --     waitTime = GlobalData:call("shared"):call("changeTime", tempTime)
                -- end

                local teamId = teamInfo["teamId"] or ""
                
                local view_dict = CCDictionary:create()
                view_dict:setObject(CCString:create("AllianceWarDetailView"), "name")
                view_dict:setObject(CCString:create(tostring(self.m_specialMass)), "specialMass")
                view_dict:setObject(CCString:create(teamId), "teamUuid")
                LuaController:call("openPopViewInLua", view_dict)
                
                local openTime = cc.UserDefault:getInstance():getIntegerForKey("firstRallyTipOpen", 0)
                if (openTime == 0 and self.m_isSuperRally == 1) then
                    cc.UserDefault:getInstance():setIntegerForKey("firstRallyTipOpen", 1);
                    cc.UserDefault:getInstance():flush();
                    local view_dict = CCDictionary:create()
                    view_dict:setObject(CCString:create("IFSuperRallyTip"), "name")
                    LuaController:call("openPopViewInLua", view_dict)
                end
                
                if (type == MarchMethodType.MethodRally 
                    or type == MarchMethodType.DarkCivOne 
                    or type == MarchMethodType.DarkCivThree
                    or type == MarchMethodType.MethodTeamRally ) then
                    -- 发聊天信息
                    if CCCommonUtilsForLua:isFunOpenByKey("battle_rally_chat_v2019") then -- 启用新版聊天
                        local nameStr = "";
                        local monsterId = teamInfo["monsterId"] or ""
                        local targetType = atoi(teamInfo["targetType"])
                        local nameIsDialog = true
                        if (targetType == WorldCityType.ActBossTile) then
                            -- 修改较多, 需要注意
                            local resStr = CCCommonUtilsForLua:getPropByIdGroup("field_monster", monsterId, "name")
                            nameStr = resStr
                        elseif (targetType == WorldCityType.AllianceBoss) then
                            local bossId = monsterId
                            nameStr = CCCommonUtilsForLua:getPropById(bossId, "name")
                        elseif (targetType == WorldCityType.SuperCampsiteRally) then
                            nameStr = "650293"
                        elseif (targetType == WorldCityType.dark_civilization) then
                            local DarkCivilizationCtr = require('game.darkCivilization.DarkCivilizationCtr')
                            local targetId = teamInfo["targetId"]
                            nameStr = DarkCivilizationCtr.getInstance():getCityProByIndex('k4', targetId)
                        elseif (targetType == WorldCityType.craft_building) then
                            local targetId = teamInfo["targetId"]
                            local build = require("game.worldCraft.battle.WorldCraftController").getInstance():getBuildConfig(targetId)
                            nameStr = build.name
                        elseif (targetType == WorldCityType.Crystal
                                or targetType == WorldCityType.Armory
                                or targetType == WorldCityType.TrainingField
                                or targetType == WorldCityType.SupplyPoint
                                or targetType == WorldCityType.BessingTower
                                or targetType == WorldCityType.MedicalTower
                                or targetType == WorldCityType.DragonTower
                                or targetType == WorldCityType.Barracks
                                or targetType == WorldCityType.TransferPoint
                                or targetType == WorldCityType.barracks_new
                                or targetType == WorldCityType.world_cup_crystal
                                or targetType == WorldCityType.world_cup_armory
                                or targetType == WorldCityType.world_cup_training_field
                                or targetType == WorldCityType.world_cup_supply_point
                                or targetType == WorldCityType.world_cup_blessing_tower
                                or targetType == WorldCityType.world_cup_medical_tower
                                or targetType == WorldCityType.world_cup_dragon_tower
                                or targetType == WorldCityType.world_cup_transferPoint) then
                            nameStr = require("game.dragonBattle.S8.DragonBattleS8Controller").getInstance():getBuildNameByType(targetType)
                        else
                            local targetAAbbr = teamInfo["targetAAbbr"] or ""
                            local targetName = teamInfo["targetName"] or ""
                            if (targetAAbbr ~= "") then
                                nameStr = string.join("", nameStr, "(", targetAAbbr, ")", targetName)
                            else
                                nameStr = nameStr..targetName
                            end
                            nameIsDialog = false
                        end

                        local dialog = "132118"
    
                        if (nameStr == "" or teamId == "") then
                            return
                        end

                        local endTime
                        if waitTime ~= 0 then
                            endTime = math.floor(waitTime)
                        end
                        self:sendBattleRallyMessage(ChannelMsgType.CHANNEL_TYPE_ALLIANCE, self.m_specialMass, nameStr, nameIsDialog, dialog, teamId, endTime)
                    else
                        local nameStr = "";
                        local monsterId = teamInfo["monsterId"] or ""
                        local targetType = atoi(teamInfo["targetType"])
                        if (targetType == WorldCityType.ActBossTile) then
                            -- 修改较多, 需要注意
                            local resStr = CCCommonUtilsForLua:getPropByIdGroup("field_monster", monsterId, "name")
                            nameStr = _lang(resStr)
                        elseif (targetType == WorldCityType.AllianceBoss) then
                            local bossId = monsterId
                            nameStr = _lang(CCCommonUtilsForLua:getPropById(bossId, "name"))
                        elseif (targetType == WorldCityType.SuperCampsiteRally) then
                            nameStr = _lang("650293")
                        elseif (targetType == WorldCityType.dark_civilization) then
                            local DarkCivilizationCtr = require('game.darkCivilization.DarkCivilizationCtr')
                            local targetId = teamInfo["targetId"]
                            nameStr = getLang(DarkCivilizationCtr.getInstance():getCityProByIndex('k4', targetId))
                        elseif (targetType == WorldCityType.craft_building) then
                            local targetId = teamInfo["targetId"]
                            local build = require("game.worldCraft.battle.WorldCraftController").getInstance():getBuildConfig(targetId)
                            nameStr = build.name
                        elseif (targetType == WorldCityType.Crystal
                                or targetType == WorldCityType.Armory
                                or targetType == WorldCityType.TrainingField
                                or targetType == WorldCityType.SupplyPoint
                                or targetType == WorldCityType.BessingTower
                                or targetType == WorldCityType.MedicalTower
                                or targetType == WorldCityType.DragonTower
                                or targetType == WorldCityType.Barracks
                                or targetType == WorldCityType.TransferPoint
                                or targetType == WorldCityType.barracks_new
                                or targetType == WorldCityType.world_cup_crystal
                                or targetType == WorldCityType.world_cup_armory
                                or targetType == WorldCityType.world_cup_training_field
                                or targetType == WorldCityType.world_cup_supply_point
                                or targetType == WorldCityType.world_cup_blessing_tower
                                or targetType == WorldCityType.world_cup_medical_tower
                                or targetType == WorldCityType.world_cup_dragon_tower
                                or targetType == WorldCityType.world_cup_transferPoint) then
                            nameStr = require("game.dragonBattle.S8.DragonBattleS8Controller").getInstance():getBuildNameByType(targetType)
                        else
                            local targetAAbbr = teamInfo["targetAAbbr"] or ""
                            local targetName = teamInfo["targetName"] or ""
                            if (targetAAbbr ~= "") then
                                nameStr = string.join("", nameStr, "(", targetAAbbr, ")", targetName)
                            else
                                nameStr = nameStr..targetName
                            end
                        end
                        local msg = _lang_1("132118", nameStr)
                        local dialog = "132118";
                        local msgArr = CCArray:create()
                        msgArr:addObject(CCString:create(nameStr))
    
                        if (nameStr == "" or teamId == "") then
                            return
                        end

                        if (not CCCommonUtilsForLua:isFunOpenByKey("sys_standalone")) then
                            local dict = CCDictionary:create()
                            dict:setObject(CCString:create(msg), "msg")
                            dict:setObject(CCString:create(ChatType.CHAT_TYPE_ALLIANCE_RALLY), "post")
                            dict:setObject(CCString:create(""), "sendLocalTime")
                            dict:setObject(CCString:create(dialog), "dialog")
                            dict:setObject(msgArr, "resArr")
                            dict:setObject(CCString:create(teamId), "teamUuid")
                            ChatController:call("getInstance"):call("sendAllianceMessageCommand", dict)
                        else
                            local dialogExtraStr = ""
                            local dialogExtraStrTable = {"["}
                            if (msgArr ~= nil) then
                                for i = 0, msgArr:count()-1, 1 do
                                    local dialogExtra = msgArr:objectAtIndex(i)
                                    if (dialogExtra) then
                                        local str = CCCommonUtilsForLua:call("escapeJsonString", dialogExtra:getCString())
                                        if (#dialogExtraStrTable > 1) then
                                            table.insert(dialogExtraStrTable, ",")
                                        end
                                        table.insert(dialogExtraStrTable, "\"")
                                        table.insert(dialogExtraStrTable, str)
                                        table.insert(dialogExtraStrTable, "\"")
                                    end
                                end
                            end
    
                            table.insert(dialogExtraStrTable, "]")
                            dialogExtraStr = table.concat(dialogExtraStrTable)
    
                            local extraStratStrTable = {"{\"teamUuid\":\"", teamId, "\""}
                            if (waitTime ~= 0) then
                                local temp = math.floor(waitTime)
                                if (temp ~= 0) then
                                    table.insert(extraStratStrTable, ",\"endTime\":\"")
                                    table.insert(extraStratStrTable, CC_ITOA(temp))
                                    table.insert(extraStratStrTable, "\"")
                                end
                            end
                            table.insert(extraStratStrTable, "}")
                            local attachmentId = table.concat(extraStratStrTable)
                            -- dump(attachmentId, "attachmentId")
                            ChatController:call("getInstance"):call("sendCountryOldChatFromStandalone", ChannelMsgType.CHANNEL_TYPE_ALLIANCE, ChatType.CHAT_TYPE_ALLIANCE_RALLY, msg, dialog, dialogExtraStr, attachmentId)
                        end
                    end
                elseif (type == MarchMethodType.KingdomTeamBattle) then
                    if (teamId == "") then
                        return
                    end
                    
                    local targetName = "#"..CC_ITOA(GlobalData:call("shared"):getProperty("neutralLandWorldId"))
                    local msg = _lang_2("660501", targetName, _lang("165009"))
                    local dialog = "660501"
                    
                    local str_table = {
                        "[{\"type\":0,\"text\":\"",
                        targetName,
                        "\"},{\"type\":2,\"dialog\":\"165009\"}]"
                    }
                    local dialogExtraStr = table.concat(str_table)

                    local json = string.join("", "\"", teamId, "\",\"", CC_ITOA(GlobalData:call("shared"):getProperty("neutralLandWorldId")), "\"")
                    local extraStratStrTable = {"{"}
                    if (waitTime ~= 0) then
                        local temp = math.ceil(waitTime)
                        if (temp ~= 0) then
                            table.insert(extraStratStrTable, "\"endTime\":\"")
                            table.insert(extraStratStrTable, CC_ITOA(temp))
                            table.insert(extraStratStrTable, "\",")
                        end
                    end
                    table.insert(extraStratStrTable, "\"description\":{\"useDialog\":true,\"text\":\"")
                    table.insert(extraStratStrTable, dialog)
                    table.insert(extraStratStrTable, "\",\"dialogExtra\":")
                    table.insert(extraStratStrTable, dialogExtraStr)
                    table.insert(extraStratStrTable, "},\"actionArgs\":[")
                    table.insert(extraStratStrTable, json)
                    table.insert(extraStratStrTable, "]}")

                    local attachmentId = table.concat(extraStratStrTable)
                    ChatController:call("getInstance"):call("sendCountryOldChatFromStandalone", ChannelMsgType.CHANNEL_TYPE_COUNTRY, ChatType.CHAT_TYPE_KINGDOM_RALLY, msg, dialog, dialogExtraStr, attachmentId)
                end
            end
        end
end

function BattleView:sendBattleRallyMessage(channelMsgType, specialMass, nameID, nameIsDialog, msg, teamUuid, endTime)
    -- ChannelMsgType.CHANNEL_TYPE_ALLIANCE, ChatType.CHAT_TYPE_ALLIANCE_RALLY
    -- ChannelMsgType.CHANNEL_TYPE_COUNTRY, ChatType.CHAT_TYPE_KINGDOM_RALLY
    if not channelMsgType then
        return
    end
    --世界争霸
    if self.m_wtIndex < 0 then return end
    local playerInfo = GlobalData:call("getPlayerInfo")
    local teamMode = GlobalData:call("shared"):getProperty("teamMode")
    
    if playerInfo:call("isInAlliance") or teamMode then
        local mineUid = playerInfo:getProperty("uid")
        local channelId = playerInfo:call("getAllianceId")

        if teamMode then
            local team = GlobalData:call("shared"):getProperty("team")
            channelId = team:getProperty("uuid")
            channelMsgType = ChannelMsgType.CHNNAEL_TYPE_TEAM
        end

        local dialog = "132118" -- 132118=我向{0}发起了集结进攻，请各位协助！

        local param = 
        {
            key = "BattleRallyMessage",
            uid = mineUid,
            allianceId = channelId,
            -- index = pos,
            teamUuid = teamUuid,
            endTime = endTime,
            specialMass = specialMass,
        }
        --回调参数
        local json = require("CommonLib.dkjson")
        local paramStr = json.encode(param)
    
        local tData = {
            channelType = channelMsgType, 
            channelId = channelId,
            content = dialog,
            post = 41,
            extra = 
            {
                sourceType = 1,
                isShowHorn = 0,
                isSelfCanClick = 1,
                recordClickStatu = 0,
                bubbleImageName = "https://cok-chat-asset.elex-tech.net/100001/image/bubble/godgift/chat_bubble_god_gift_{isSelfMessage}_normal_v1.9.png",

                -- 消息有标题的时候设置标题信息
                titleInfo = 
                {
                    content = "10200069",      -- 标题的内容 10200069=进攻集结
                    contentType = 2,           -- 标题的类型 1：纯文本  2：dialogId 3：游戏xmlId
                    textColor = "#e4a29f",     -- 标题的显示颜色
                    textGrayColor = "#cacaca", -- 过期变灰标题的显示颜色
                },

                contentInfo = 
                {
                    contentType = 2,
                    textColor = "#e4a29f",
                    clickInfo =
                    {
                        jumpType = 1,
                        param = paramStr,
                    },
                    replaceWords = 
                    {
                        {
                            content = nameID,
                            contentType = nameIsDialog and 2 or 1,
                            color = "#ff0000",
                            underlineColor = "#ff0000",
                            clickInfo =
                            {
                                jumpType = 1,
                                param = paramStr,
                            },
                        },
                    }
                }
            }
        }

        if endTime then
            tData["extra"]["endTimeInfo"] = {    --消息有到期时间的时候设置信息
                endTime = endTime,      --到期时间
                textColor = "#cacaca",  --时间的显示颜色
            }
        end
    
        -- dump(tData, "tData", 5)
        require("game.controller.ChatSharedController").onSharedChatDialogV2019(tData)

        if teamMode then
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("45000781"))
        else
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("681118"))
        end
    else
        CCCommonUtilsForLua:call("flyText", getLang("111138"));
    end
end

function BattleView:callSuccess(paramDict)
    local type = self.m_bType;
    -- AutoSafeRef temp(this);
    local result = dictToLuaTable(paramDict)
    PopupViewController:call("removeAllPopupView");
    local info = WorldController:call("getCityInfoByIndex", self.m_targetIndex)
    if (type == MarchMethodType.MethodRally 
        or type == MarchMethodType.KingdomTeamBattle
        or type == MarchMethodType.MethodTeamRally) then
        if (info ~= nil) then
            local info_cityType = info:getProperty("cityType")
            local info_luaType = info:getProperty("luaType")
            if (info_cityType == WorldCityType.ActBossTile or self.m_targetType == WorldCityType.ActBossTile) then
                local stamina = WorldController:call("getInstance"):getProperty("currentStamine")
                local monsterId = ""
                local params = result.params.allianceBattleTeam
                if  params  and params.monsterId and params.monsterId ~= "" then
                    monsterId = params.monsterId
                end
                local usePower = CCCommonUtilsForLua:getPropById(monsterId, "usePower")
                local cost = usePower ~= "" and tonumber(usePower) or GlobalData:call("shared"):getProperty("worldConfig"):getProperty("boss_decr")
                stamina = stamina - cost
                WorldController:call("getInstance"):setProperty("currentStamine", stamina)
                CCSafeNotificationCenter:postNotification(MSG_CURRENT_STAMINE)
            elseif (info_cityType == WorldCityType.AllianceBoss or self.m_targetType == WorldCityType.AllianceBoss) then
                local cost = 0
                if (self.m_allianceBossId ~= "") then
                    cost = tonumber(CCCommonUtilsForLua:getPropById(self.m_allianceBossId, "power"))
                elseif (info ~= nil) then
                    local fieldMonsterInfo = info:call("getFieldMonsterInfo")
                    if (fieldMonsterInfo ~= nil) then
                        local monsterId = fieldMonsterInfo:getProperty("monsterId")
                        cost = tonumber(CCCommonUtilsForLua:getPropById(monsterId, "power"))
                    end
                end
                
                local stamina = WorldController:call("getInstance"):getProperty("currentStamine")
                stamina = stamina - cost
                WorldController:call("getInstance"):setProperty("currentStamine", stamina)
                CCSafeNotificationCenter:postNotification(MSG_CURRENT_STAMINE)
            end
        end
        
        self:sendChat(type, result)
        
    else
        local info_cityType = -1
        local info_luaType = -1
        if (info ~= nil) then
            info_cityType = info:getProperty("cityType")
            info_luaType = info:getProperty("luaType")
        end
        if (self.m_targetType == WorldCityType.ActBossTile) then
            -- WorldController::getInstance()->currentStamine -= GlobalData::shared()->worldConfig.boss_decr;
            -- CCSafeNotificationCenter::sharedNotificationCenter()->postNotification(MSG_CURRENT_STAMINE);
            local stamina = WorldController:call("getInstance"):getProperty("currentStamine")
            local monsterId = ""
            local params = result.params.allianceBattleTeam
            if  params  and params.monsterId and params.monsterId ~= "" then
                monsterId = params.monsterId
            end
            if self.monsterId then
                monsterId = self.monsterId 
            end
            local usePower = CCCommonUtilsForLua:getPropById(monsterId, "usePower")
            local cost = usePower ~= "" and tonumber(usePower) or GlobalData:call("shared"):getProperty("worldConfig"):getProperty("boss_decr")
           
            stamina = stamina - cost
            WorldController:call("getInstance"):setProperty("currentStamine", stamina)
            CCSafeNotificationCenter:postNotification(MSG_CURRENT_STAMINE)
        elseif (self.m_targetType == WorldCityType.AllianceBoss) then
            local cost = 0
            if (self.m_allianceBossId ~= "") then
                cost = tonumber(CCCommonUtilsForLua:getPropById(self.m_allianceBossId, "power"))
            elseif (info ~= nil) then
                local fieldMonsterInfo = info:call("getFieldMonsterInfo")
                if (fieldMonsterInfo ~= nil) then
                    local monsterId = fieldMonsterInfo:getProperty("monsterId")
                    cost = tonumber(CCCommonUtilsForLua:getPropById(monsterId, "power"))
                end
            end
            
            local stamina = WorldController:call("getInstance"):getProperty("currentStamine")
            stamina = stamina - cost
            WorldController:call("getInstance"):setProperty("currentStamine", stamina)
            CCSafeNotificationCenter:postNotification(MSG_CURRENT_STAMINE)
        elseif (self.m_targetType == WorldCityType.tile_HpWorldBoss) then
            local info = WorldController:call("getCityInfoByIndex", self.m_targetIndex)
            if (info ~= nil) then
                local bbinfo = WorldBossController:call("getInstance"):call("getBossInfoByType", tonumber(info_type))
                if bbinfo then
                    local stamina = WorldController:call("getInstance"):getProperty("currentStamine")
                    stamina = stamina - tonumber(bbinfo:getProperty("HpBoss_stamineCost"))
                    WorldController:call("getInstance"):setProperty("currentStamine", stamina)
                end
                CCSafeNotificationCenter:postNotification(MSG_CURRENT_STAMINE)
            end
        elseif (self.m_targetType == WorldCityType.dark_civilization) or (info_luaType == WorldCityType.dark_civilization) then
            local cost = self:getDarkCivPower()
            local stamina = WorldController:call("getInstance"):getProperty("currentStamine")
            stamina = stamina - cost
            WorldController:call("getInstance"):setProperty("currentStamine", stamina)
            CCSafeNotificationCenter:postNotification(MSG_CURRENT_STAMINE)
            if type == MarchMethodType.DarkCivOne or type == MarchMethodType.DarkCivThree then
                self:sendChat(type, result)
            end
        end
        SceneController:call("gotoScene", SCENE_ID_WORLD)
    end
end

function BattleView:notice()
    -- TroopsController::getInstance()->m_isNotice = !TroopsController::getInstance()->m_isNotice;
    local isNotice = TroopsController:call("getInstance"):getProperty("m_isNotice") == 1
    TroopsController:call("getInstance"):setProperty("m_isNotice", (not isNotice))
end

function BattleView:selectAll(marchNum)
    local totalNum = 0
    local maxForceNum = self:getMaxSoilderNum()
    
    local serverType = GlobalData:call("shared"):getProperty("serverType")
    if serverType == ServerType.SERVER_ANCESTRAL and marchNum then 
        if maxForceNum > marchNum then
            maxForceNum = marchNum
        else
            maxForceNum = maxForceNum
        end
    end

    for index, value in ipairs(self.m_tmpArray) do
        local soldierId = tostring(value)
        TroopsController:call("getInstance"):call("updateTmpBattleData", soldierId, 0, soldierId, false);
    end
    
    local isResourceLimit = false;
    local totalResource = 0;
    local loadPerUnit = 0;
    local info = WorldController:call("getCityInfoByIndex", self.m_targetIndex)
    if(info ~= nil and (info:getProperty("cityType") == WorldCityType.ResourceTile)) then -- 只有普通资源田计算采集量
        local type = -1;
        type = info:getProperty("cityType")
        local luaType = info:getProperty("luaType")
        if (type == WorldCityType.ResourceTile or type == WorldCityType.tile_superMine or type == WorldCityType.Resource_new or type == WorldCityType.Resource_new_dragon) then
            local isInMarch = false
            if (type == WorldCityType.ResourceTile) then
                loadPerUnit = CCCommonUtilsForLua:call("getResourceLoadByType", info:getProperty("resource"):getProperty("type"))
            elseif (type == WorldCityType.tile_superMine) then
                loadPerUnit = CCCommonUtilsForLua:call("getResourceLoadByType", info:getProperty("m_superMineInfo"):getProperty("type"))
            elseif (type == WorldCityType.Resource_new or type == WorldCityType.Resource_new_dragon) then
                loadPerUnit = CCCommonUtilsForLua:call("getResourceLoadByType", info:getProperty("m_newResourceInfo"):getProperty("type"))
            end
            
            local marchInfos = WorldController:call("getInstance"):getProperty("m_marchInfo")
            for key, value in pairs(marchInfos) do
                if (value:getProperty("endPointIndex") == self.m_targetIndex) then
                    isInMarch = true
                    break
                end
            end
            
            if not isInMarch then
                isResourceLimit = true
                if (type == WorldCityType.ResourceTile or luaType == WorldCityType.expedition_super_mine or luaType == WorldCityType.expedition_super_mine_sub) then
                    totalResource = tonumber(info:getProperty("resource"):getProperty("sum")) + 3  -- 防止采集剩余容错3个资源量
                elseif (type == WorldCityType.tile_superMine) then
                    totalResource = tonumber(info:getProperty("m_superMineInfo"):getProperty("sum")) + 3  -- 防止采集剩余容错3个资源量
                elseif (type == WorldCityType.Resource_new or type == WorldCityType.Resource_new_dragon) then -- 巨龙宝藏 没有矿石数量上限
                    totalResource = -1
                end
            end
        end
    end
    
    if ((self.soilderChallengeType == SoldierChallengeType.SOILDERCHALLENGETYPE_LOAD or self.soilderChallengeType == SoldierChallengeType.SOILDERCHALLENGETYPE_LEVEL or self.soilderChallengeType == SoldierChallengeType.SOILDERCHALLENGETYPE_SPEED
        or self.soilderChallengeType == SoldierChallengeType.SOILDERCHALLENGETYPE_MONSTER) and CCCommonUtilsForLua:isFunOpenByKey("troops_set_off")) then
        local list = {}
        for index, value in ipairs(self.m_tmpArray) do
            local soldierId = value
            table.insert(list, soldierId)
        end

        if(self.soilderChallengeType == SoldierChallengeType.SOILDERCHALLENGETYPE_LOAD) then
            list = ArmyController:call("getInstance"):call("setChallengeLoadDataForLua", maxForceNum, totalResource, loadPerUnit, list, isResourceLimit)
        elseif(self.soilderChallengeType == SoldierChallengeType.SOILDERCHALLENGETYPE_LEVEL) then
            list = ArmyController:call("getInstance"):call("setChallengeLevelDataForLua", maxForceNum, totalResource, loadPerUnit, list, isResourceLimit)
        elseif(self.soilderChallengeType == SoldierChallengeType.SOILDERCHALLENGETYPE_SPEED) then
            list = ArmyController:call("getInstance"):call("setChallengeSpeedDataForLua", maxForceNum, totalResource, loadPerUnit, list, isResourceLimit)
        elseif(self.soilderChallengeType == SoldierChallengeType.SOILDERCHALLENGETYPE_MONSTER) then
            list = ArmyController:call("getInstance"):call("setChallengeMonsterDataForLua", maxForceNum, totalResource, loadPerUnit, list, isResourceLimit)
        end

        self.m_tmpArray = {}
        for index, value in ipairs(list) do
            table.insert(self.m_tmpArray, value)
        end
        self.m_tabView:reloadData()
        TroopsController:call("getInstance"):call("makeLoadNumAll")
        CCSafeNotificationCenter:postNotification(GUIDE_INDEX_CHANGE, CCString:create("ED_quick"))
        return
    end
    
    -- [awen-junyu] 自定义集结配兵
    if (self.m_diyRally > 0 and CCCommonUtilsForLua:isFunOpenByKey("arrange_arms")) then
        local configMap = {}
        if(self.soilderChallengeType == SoldierChallengeType.SOILDERCHALLENGETYPE_RECOMMEND_INITIATOR) then  -- 发起者推荐
            configMap = WorldController:call("getInstance"):getProperty("m_diyArm")
        elseif(self.soilderChallengeType == SoldierChallengeType.SOILDERCHALLENGETYPE_RECOMMEND_SYSTEM) then  -- 系统推荐
            configMap = GlobalData:call("shared"):getProperty("recSystemList")
        end

        local isEmpty = true;
        for key, value in pairs(configMap) do
            if value ~= nil then
                isEmpty = false
            end
        end
        
        if not isEmpty then
            local arrayArm = {}
            
            for key, value in pairs(configMap) do
                local type = tonumber(key)
                local rate = tonumber(value)
                if (rate > 0) then
                    arrayArm = {}
                    
                    -- 取出同类别的英雄
                    for tmp_index, tmp_value in ipairs(self.m_tmpArray) do
                        local info = GlobalData:call("shared"):call("getArmyInfoById", tmp_value)
                        if (info:getProperty("armType") == type) then
                            table.insert(arrayArm, info)
                        end
                    end

                    if #arrayArm > 0 then
                        local recommendCount = rate * self:getMaxSoilderNum()
                        local armInfo = arrayArm[1]
                        -- 根据等级排序
                        table.sort(arrayArm, function(info1, info2) 
                            if (info1 and info2) then
                                return info1:getProperty("armyLevel") > info2:getProperty("armyLevel")
                            end
                            return false
                        end)

                        for array_index, array_value in ipairs(arrayArm) do
                            local info = array_value
                            -- 当前拥有的闲置士兵数量
                            local armyId = info:getProperty("armyId")
                            local ownCount = TroopsController:call("getInstance"):getProperty("m_tmpConfSoldiers")[armyId] or 0
    
                            if ( recommendCount > ownCount ) then
                                TroopsController:call("getInstance"):call("updateTmpBattleData", armyId, ownCount, armyId, false)
                                recommendCount = recommendCount - ownCount;
                            else
                                TroopsController:call("getInstance"):call("updateTmpBattleData", armyId, recommendCount, armyId, false)
                                break
                            end
                        end
                        TroopsController:call("getInstance"):call("makeLoadNumAll")
                    end
                end
            end
            self.m_tabView:reloadData()
            return
        end
    end

    --领主死斗
    if self.m_bType == MarchMethodType.FightDeath and CCCommonUtilsForLua:isFunOpenByKey("player_battle") then
        local armyList = GlobalData:call("shared"):getProperty("armyList") 
        for key, value in pairs(armyList) do
            local deadMarch = math.max(0, value:getProperty("deadMarch"))
            if deadMarch > 0 then
                TroopsController:call("getInstance"):call("updateTmpBattleData", key, deadMarch, key, false)
            end
        end
        TroopsController:call("getInstance"):call("makeLoadNumAll")
        self.m_tabView:reloadData()
        return
    end

    if (not isResourceLimit) then
        if (#self.m_tmpArray > 0) then
            local soldierIdCnt = #self.m_tmpArray <= 8 and #self.m_tmpArray or 8
            local preSoldierNum = math.ceil(maxForceNum/soldierIdCnt);
            local _tmpLastNum = maxForceNum;
            
            local tmpQuickNum = {}
            for index, value in ipairs(self.m_tmpArray) do
                local soldierId = value
                local tmpCntNum = TroopsController:call("getInstance"):getProperty("m_tmpConfSoldiers")[soldierId] or 0
                tmpCntNum = tmpCntNum > preSoldierNum and preSoldierNum or tmpCntNum
                tmpCntNum = tmpCntNum > _tmpLastNum and _tmpLastNum or tmpCntNum
                table.insert(tmpQuickNum, tmpCntNum)
                _tmpLastNum = _tmpLastNum - tmpCntNum
                if (index >= soldierIdCnt) then
                    break
                end
            end
            
            if (_tmpLastNum >= 0) then
                for index, value in ipairs(self.m_tmpArray) do
                    local soldierId = value
                    local tmpCntNum = 0
                    local sendNum = 0
                    tmpCntNum = TroopsController:call("getInstance"):getProperty("m_tmpConfSoldiers")[soldierId] or 0
                    if (index <= #tmpQuickNum) then
                        tmpCntNum = tmpCntNum - tmpQuickNum[index]
                        tmpCntNum = tmpCntNum > _tmpLastNum and _tmpLastNum or tmpCntNum
                        tmpQuickNum[index] = tmpQuickNum[index] + tmpCntNum
                        sendNum = tmpQuickNum[index]
                        _tmpLastNum = _tmpLastNum - tmpCntNum
                    else
                        tmpCntNum = tmpCntNum > _tmpLastNum and _tmpLastNum or tmpCntNum;
                        sendNum = tmpCntNum;
                        _tmpLastNum = _tmpLastNum - tmpCntNum;
                    end
                    
                    local armType = tonumber(CCCommonUtilsForLua:getPropByIdGroup("arms", soldierId, "arm"))

                    TroopsController:call("getInstance"):call("updateTmpBattleData", soldierId, sendNum, soldierId, false)
                    if (_tmpLastNum <= 0 and index >= soldierIdCnt) then
                        break
                    end
                end
                TroopsController:call("getInstance"):call("makeLoadNumAll")
            end
        end
    else
        for index, value in ipairs(self.m_tmpArray) do
            local soldierId = value
            local armType = tonumber(CCCommonUtilsForLua:getPropByIdGroup("arms", soldierId, "arm"))
            local tmpCntNum = 0
            tmpCntNum = TroopsController:call("getInstance"):getProperty("m_tmpConfSoldiers")[soldierId] or 0
            tmpCntNum = totalNum + tmpCntNum >= maxForceNum and (maxForceNum - totalNum) or tmpCntNum
            if (isResourceLimit) then
                --if (GlobalData::shared()->armyList.find(soldierId) != GlobalData::shared()->armyList.end()) {
                local armyList = GlobalData:call("shared"):getProperty("armyList") 
                local armyInfo = armyList[soldierId]
                if (armyInfo ~= nil) then
                    local generalToSend = TroopsController:call("getInstance"):getProperty("m_generalToSend")
                    local loadPerSoldier = ArmyController:call("getInstance"):call("getLoad", armyInfo, #generalToSend)
                    local curLoadNum = TroopsController:call("getInstance"):getProperty("m_curLoadNum")
                    if(totalResource < math.floor(math.floor(curLoadNum + tmpCntNum * loadPerSoldier) / loadPerUnit)) then
                        local num = math.ceil((totalResource * loadPerUnit - curLoadNum) / loadPerSoldier)
                        tmpCntNum = (num > tmpCntNum and tmpCntNum or num)
                    end
                end
            end
            
            TroopsController:call("getInstance"):call("updateTmpBattleData", soldierId, tmpCntNum, soldierId)
            
            if(totalNum + tmpCntNum >= maxForceNum) then
                break
            end

            if(isResourceLimit and (totalResource*loadPerUnit < math.floor(TroopsController:call("getInstance"):getProperty("m_curLoadNum")))) then
                break
            end
                
            totalNum = totalNum + tmpCntNum
        end
        TroopsController:call("getInstance"):call("makeLoadNumAll")
    end
    CCSafeNotificationCenter:postNotification(GUIDE_INDEX_CHANGE, CCString:create("ED_quick"))
end


function BattleView:unselectAll()
    for index, value in ipairs(self.m_tmpArray) do
        local soldierId = value
        TroopsController:call("getInstance"):call("updateTmpBattleData", soldierId, 0, soldierId, false)
    end
    TroopsController:call("getInstance"):call("makeLoadNumAll")
end

function BattleView:onAddClick(pSender, pCCControlEvent)
    self:setChallengePopClose(nil)
    local getTypeArray = function (type)
        local city_lv = FunBuildController:call("getMainCityLv")
        local goodsTable = CCCommonUtilsForLua:getGroupByKey("goods")
        local array = {}
        if (goodsTable ~= nil) then
            for key, value in pairs(goodsTable) do
                if(type == tonumber(value["type2"]) and tonumber(value["type"]) == 4 and city_lv >= tonumber(value["lv"])) then
                    table.insert(array, value)
                end
            end
        end

        table.sort(array, function (value_1, value_2)
            return value_1["order_num"] >= value_2["order_num"]
        end)

        return array
    end

    local typeItems = ToolController:call("getInstance"):getProperty("m_typeItems")
    typeItems[14] = getTypeArray(14)

    -- LuaController::getInstance()->fireEventRef("open_UseItemStatusView", dict);
    local view = require("game.CommonPopup.UseItemStatusView"):create(14, _lang("101413"), _lang("101450"), true)
	PopupViewController:addPopupInView(view)
end

function BattleView:onAddStamineClick(pSender, pCCControlEvent)
    self:setChallengePopClose(nil)

	local view = Drequire("game.CommonPopup.UseResToolView"):create(13, false)
	PopupViewController:addPopupInView(view)
end

function BattleView:selectInGuide()
    for index, value in ipairs(self.m_tmpArray) do
        local soldierId = value
        TroopsController:call("getInstance"):call("updateTmpBattleData", soldierId, 15, soldierId,false);
    end
    TroopsController:call("getInstance"):call("makeLoadNumAll")
end

function BattleView:onClickQuickBtn(pSender, pCCControlEvent)
    self:setChallengePopClose(nil)
    self.m_formationName:setString("")
    if (#self.m_tmpArray == 0) then
        return
    end

    if(math.floor(TroopsController:call("getInstance"):getProperty("m_curLoadNum")) == 0) then
        self:selectAll()
        if (GuideController:call("share"):call("getCurGuideID") == "3030500") then
            self:selectInGuide()
        end
        CCCommonUtilsForLua:setButtonTitle(self.m_quickBtn, _lang("105146"))
    else
        CCCommonUtilsForLua:setButtonTitle(self.m_quickBtn, _lang("105149"))
        self:unselectAll()
    end
    
    TroopsController:call("getInstance"):call("changeArrTime")
    local cell_count = self:numberOfCellsInTableView()
    for index = 1, cell_count do
        local cell = self.m_tabView:cellAtIndex(index-1)
        if cell then
            cell:refresh()
        end
    end
end

function BattleView:makeArrTime(obj)
    if self.m_battlType == CommericalType.CommericalBattle then
        self.m_timeLabel:setString(CC_SECTOA(self.m_commercialTime))
        return
    end

    local spd = TroopsController:call("getInstance"):getProperty("m_minSpeed")
    if spd == 0 then
        self.m_spd = spd;
        self.m_timeLabel:setString(CC_SECTOA(0))
        local info = WorldController:call("getCityInfoByIndex", self.m_targetIndex)
        if info ~= nil then
            if (info:getProperty("cityType") == WorldCityType.Resource_new_dragon) then -- 巨龙巢穴 到达时间1分钟
                self.m_timeLabel:setString(CC_SECTOA(60))
            end
        end
        return
    end

    if (self.m_spd == spd) then
        return
    end
    self.m_spd = spd
    
    local mType = MarchMethodType.MethodBattle
    if (self.m_bType >= 0) then
        mType = self.m_bType
    end
    local cityType = WorldCityType.CityTile
    local monsterId = ""
    local info = WorldController:call("getCityInfoByIndex", self.m_targetIndex)
    if info ~= nil then
        cityType = info:getProperty("cityType")
        if(cityType == WorldCityType.FieldMonster) then
            local fieldMonsterInfo = info:call("getFieldMonsterInfo")
            if (fieldMonsterInfo ~= nil) then
                monsterId = fieldMonsterInfo:getProperty("monsterId")
            end
        end
    end

    local march_time = WorldController:call("getInstance"):call("getMarchTime1", self.m_startIndex, self.m_targetIndex, cityType, mType)
    local time = math.floor(march_time / 1000)
    time = time * self.m_slow
    --【Awen】修改攻打新等级怪物的行军时间
    if (cityType == WorldCityType.FieldMonster and monsterId ~= "") then
        local levelStr = CCCommonUtilsForLua:getPropByIdGroup("field_monster", monsterId, "level")
        local levelInt = tonumber(levelStr)
        local temp_time = WorldController:call("getInstance"):getProperty("firstAttachMonsterMarchTime")
        if (levelInt < temp_time and WorldController:call("getInstance"):getProperty("currentMonsterLevel") + 1 == levelInt 
            and temp_time > 0) then
            time = temp_time
        end
    end

    self.m_marchTime = time
    self.m_timeLabel:setString(CC_SECTOA(time))

    if (info ~= nil and info:getProperty("cityType") == WorldCityType.Resource_new_dragon) then
        -- 巨龙巢穴 到达时间1分钟
        self.m_timeLabel:setString(CC_SECTOA(60))
    end

    if (self.m_battlType == PveTrainingType.PveHeroTraining and CCCommonUtilsForLua:isFunOpenByKey("test_hero_switch")) then
        self.m_timeLabel:setString(CC_SECTOA(0))
    end

    -- 消耗士兵 到达时间走配置
    if (self.m_bType == MarchMethodType.COSDonateSoldireMarch and CCCommonUtilsForLua:isFunOpenByKey("consume_soldier_defend")) then
        local arrTime = tonumber( CCCommonUtilsForLua:getPropByIdGroup("data_config", "consume_soldier", "k1"))
        self.m_timeLabel:setString(CC_SECTOA(arrTime))
    end

    -- 异国旅人怪物行军时间
    if (info ~= nil and info:getProperty("cityType") == WorldCityType.hero_maintheme_monster) then
        local arrTime = tonumber( CCCommonUtilsForLua:getPropByIdGroup("data_config", "hero_theme", "k1"))
        self.m_timeLabel:setString(CC_SECTOA(arrTime))
    end

    -- 异国旅人奖励领取行军时间
    if (info ~= nil and info:getProperty("luaType") == WorldCityType.hero_maintheme_resource) then
        local arrTime = tonumber( CCCommonUtilsForLua:getPropByIdGroup("data_config", "hero_theme", "k2"))
        self.m_timeLabel:setString(CC_SECTOA(arrTime))
    end

    if (cityType == WorldCityType.tile_HpWorldBoss and CCCommonUtilsForLua:isFunOpenByKey("new_worldboss_617")) then
        self.m_timeLabel:setString(CC_SECTOA(60))
    end
end


-- TableView
function BattleView:cellSizeForTable(table, idx)
    return 640, 105
end

function BattleView:tableCellAtIndex(table, idx)
    if idx >= #self.m_tmpArray then
        return nil
    end
    
    local maxForceNum = self:getMaxSoilderNum()
    local cell = table:dequeueCell()
    if idx < #self.m_tmpArray then
        local gid = self.m_tmpArray[idx+1]
        local num = 0;
        local battleInfos = TroopsController:call("getInstance"):getProperty("m_tmpBattleInfos")
        if battleInfos[gid] ~= nil then
            num = battleInfos[gid]
        end

        if cell then
            cell:setData(gid, num, self.m_bType, self.m_rally, maxForceNum)
            cell:setTag(idx)
        else
            cell = Drequire("game.CommonPopup.SoldierCell"):create(self, gid, num, self.m_bType, self.m_rally, maxForceNum, self.m_diyRally, self.m_battlType)
            cell:setTag(idx)
        end
    end
    return cell
end

function BattleView:numberOfCellsInTableView(table)
    return #self.m_tmpArray
end

function BattleView:tableCellTouched(table, cell)
    if cell ~= nil then
        cell:cellTouchEnded()
    end
end


function BattleView:getGuideNode(_key)
    if (_key == "LUA_ED_attack" or _key == "LUA_CZ_attack") then
        self.m_guideKey = _key
        GuideController:call("setCallback", cc.CallFunc:create(function() self:guideFunc() end))
        return self.m_marchBtn
    elseif (_key == "LUA_ED_quick" or _key == "LUA_CZ_quick") then
        return self.m_quickBtn
    elseif (_key == "LUA_ED_hero" or _key == "LUA_CZ_hero") then
        self.m_guideKey = _key
        GuideController:call("setCallback", cc.CallFunc:create(function() self:guideFunc() end))
        return self.m_heroBtn
    end
    return nil
end

function BattleView:guideFunc()
    if(self.m_guideKey == "attack") then
        self:onClickMarchBtn(nil, cc.CONTROL_EVENTTYPE_TOUCH_DOWN)
    elseif (self.m_guideKey == "hero") then
        self:onClickHeroBtn(nil, cc.CONTROL_EVENTTYPE_TOUCH_DOWN)
    end
end

function BattleView:getHeroData()
    local notUseHero = false
    -- 文明奇迹建造默认不带英雄，虚空战场默认不带英雄
    if (self.m_duelMarch == true 
    or self.m_civiBuildTag == true 
    or GlobalData:call("shared"):getProperty("isInVoidBattlefieldServer") 
    or self.m_bType == MarchMethodType.COSDonateSoldireMarch
    or GlobalDataCtr.checkIsGreenServer()) then
        notUseHero = true
    else
        local info = WorldController:call("getCityInfoByIndex", self.m_targetIndex)
        if (info ~= nil) then
            local cityType = info:getProperty("cityType")
            if (cityType == WorldCityType.ResourceTile -- 资源
                or cityType == WorldCityType.tile_superMine -- 联盟超级矿
                or cityType == WorldCityType.Resource_new
                or cityType == WorldCityType.Resource_new_dragon
                ) then   -- 活动资源点
                notUseHero = true
            end
        end
    end
    
    -- 当前分类里等级最高的英雄id
    local maxLvHeroId = ""
    -- 最高等级
    local maxLv = 0
    -- 最高等级英雄的系别
    local maxLvSubtype = -1
    
    local dataVec ={}
    local arr = {}
    if (self.m_battlType == PveTrainingType.PveHeroTraining and CCCommonUtilsForLua:isFunOpenByKey("test_hero_switch")) then
        -- arr = arrayToLuaTable(getCanMarchHeroIdInPve())
        local PveDataController = require("game.Training.PveDataController")
        arr = PveDataController:getInstance():getPveMarchHeroIds()
    else
        arr = arrayToLuaTable(getCanMarchHeroId())
    end

    local count = 0
    for key, value in pairs(arr) do
        if value ~= nil then
            local heroId = value
            local heroInfo = HeroManager.getHeroInfoById(heroId)
            if (heroInfo ~= nil and heroInfo["battle"] ~= nil) then
                local battle = tonumber(heroInfo["battle"])
                if (battle == 1) then
                    count = count + 1
                    
                    if not notUseHero then
                        if heroInfo["subtype"] ~= nil then
                            local subtype = tonumber(heroInfo["subtype"])
                            -- 如果是通用分类或者是自己分类
                            if(subtype == HERO_TAB_TYPE.HERO_TAB_ALL or subtype == self.m_heroTabType) then
                                if heroInfo["level"] ~= nil then
                                    local level = tonumber(heroInfo["level"])
                                    if level ~= nil then
                                        -- 选择等级高的，或者同等级通用英雄（因为通用英雄在英雄列表里靠前）
                                        if(maxLv < level or (maxLv == level and subtype == HERO_TAB_TYPE.HERO_TAB_ALL and maxLvSubtype ~= HERO_TAB_TYPE.HERO_TAB_ALL)) then
                                            maxLv = level
                                            maxLvSubtype = subtype
                                            maxLvHeroId = heroId
                                        end
                                    end
                                end
                            end
                        end
                    end
                end       
            end
        end
    end

    local arr_len = #arr
    if (arr_len > 0) then
        if not (arr_len == 1 and count == 0) then
            self.m_heroSprCover:setVisible(true)
            
            -- [awen-gaorui] 当开关打开时默认带英雄
            if ((self.m_battlType == PveTrainingType.PveHeroTraining and CCCommonUtilsForLua:isFunOpenByKey("test_hero_switch") or CCCommonUtilsForLua:isFunOpenByKey("march_with_hero"))) then
                -- 如果找到分类里最高等级的英雄id
                if(maxLvHeroId ~= "" and not (self.m_battlType == PveTrainingType.PveHeroTraining and CCCommonUtilsForLua:isFunOpenByKey("test_hero_switch"))) then
                    -- dump(maxLvHeroId, "------ maxLvHeroId")
                    self:setHero(CCString:create(maxLvHeroId))
                end
            end
        end
    end
end

function BattleView:getDragonData()
    -- 虚空战场默认不带龙
    if (not CCCommonUtilsForLua:isFunOpenByKey("dragon_battle") 
    or self:checkDragonAtDestnation() 
    or GlobalData:call("shared"):getProperty("isInVoidBattlefieldServer") 
    or self.m_bType == MarchMethodType.COSDonateSoldireMarch
    or GlobalDataCtr.checkIsGreenServer()) then
        self.m_dragonSprCover:setVisible(false)
        self.m_dragonBgLeft:setColor(cc.GRAY)
        self.m_dragonBgRight:setColor(cc.GRAY)
        return
    end
    
    local useDragon = false;
    local dragons_vec = DragonController:call("getDragonVector")
    
    local info = WorldController:call("getCityInfoByIndex", self.m_targetIndex)
    if (info ~= nil) then
        local cityType = info:getProperty("cityType")
        if (cityType == WorldCityType.ResourceTile -- 资源
            or cityType == WorldCityType.tile_superMine -- 联盟超级矿
            or cityType == WorldCityType.Resource_new
            or cityType == WorldCityType.Resource_new_dragon
            ) then      -- 活动资源点
            useDragon = true
        end
    end

    local count = 0
    for index, value in ipairs(dragons_vec) do
        if (value:call("getInMarch") == false and value:call("getObtain") and value:call("getState") == DragonState.Dragon_Normal 
            and value:call("getUseFlag") == 0 and value:call("getIntimacy") > 0) then
            count = count + 1
        end
    end
    
    if (count > 0) then
        if (self:checkPlayerDragonCount() and count == 1 and not self:checkPlayerDragonLevel()) then
            self.m_dragonSprCover:setVisible(true)
            self.m_dragonBgLeft:setColor(cc.GRAY)
            self.m_dragonBgRight:setColor(cc.GRAY)
        else
            self.m_dragonSprCover:setVisible(false)
            -- 是资源的默认选择黑龙出征
            if (useDragon) then
                for index, value in ipairs(dragons_vec) do
                    if (value:call("getUseFlag") == 0 and value:call("getInMarch") == false and value:call("getObtain") and value:call("getState") == DragonState.Dragon_Normal and value:call("getBaseId") == "109000") then
                        self:setDragon(CCInteger:create(index-1))
                        break
                    end
                end
            else  -- 否则按照最高级龙出征
                local index = 1
                local maxLevel = 0
                for idx, value in ipairs(dragons_vec) do
                    if (value:call("getUseFlag") == 0 and value:call("getInMarch") == false and value:call("getObtain") and value:call("getState") == DragonState.Dragon_Normal and value:call("getIntimacy") > 0) then
                        local tlevel = value:call("getLevel")
                        if (tlevel > maxLevel) then
                            maxLevel = tlevel
                            index = idx
                        end
                    end
                end
                self:setDragon(CCInteger:create(index-1)) 
            end
        end
    end
end

function BattleView:setHero(ref)
    if (ref == nil) then
        return
    end

    self.m_heroId = ref:getCString()
    local heroInfo = HeroManager.getHeroInfoById(self.m_heroId)
    if (heroInfo and self.m_heroId ~= "") then
        self.m_delHeroBtn:setVisible(true)
        local picName = heroInfo.pic
        
        --【Awen】英雄换装
        if (CCCommonUtilsForLua:isFunOpenByKey("hero_avatar_chuzheng")) then
            local dict = CCDictionary:create()
            dict:setObject(CCString:create(self.m_heroId), "heroId")
            -- LuaController::getInstance()->fireEventRef("onHeroSkinEvent", "isHeroEquipSkin", &dict);
            require("game.hero.HeroSkinManager").getInstance():fireCommonEvent("isHeroEquipSkin", dict)

            local status = 0
            if (dict:objectForKey("isEquip")) then
                status = dict:valueForKey("isEquip"):intValue()
            end
            if(status == 1 and dict:objectForKey("skinId")) then
                picName = picName..dict:valueForKey("skinId"):getCString()
            end
        end

        picName = picName..".png"
        if (CCLoadSprite:call("getSF", picName) == nil) then
            picName = "hero_head_1.png"
        end

        local pFrame = CCSpriteFrameCache:sharedSpriteFrameCache():spriteFrameByName(picName)
        self.m_heroSpr:setSpriteFrame(pFrame)
        self.m_heroSpr:setScale(0.85)
        local title = CCCommonUtilsForLua:getPropById(self.m_heroId, "title")
        title = _lang(title)
        self.m_heroTxt:setString(title)
        self.m_heroYesSpr:setVisible(true)
        self.m_heroSprCover:setVisible(false)
    else
        self.m_delHeroBtn:setVisible(false)
        local sprName = "icon_battle_head_hero.png"
        self.m_heroSprCover:setVisible(true)
        local pFrame = CCSpriteFrameCache:sharedSpriteFrameCache():spriteFrameByName(sprName)
        self.m_heroSpr:setSpriteFrame(pFrame)
        self.m_heroTxt:setString(_lang("169041"))
        self.m_heroYesSpr:setVisible(false)   
    end
    self:refreshMaxTroop(self.m_heroId)
    self:updateBuffIcon()
end

function BattleView:setDragon(ref)
    if (ref == nil) then
        return
    end

    self.m_dragonIndex = ref:getValue()
    local dragonInfo = DragonController:call("getInstance"):call("getDragonInfoByIndex", self.m_dragonIndex)
    if dragonInfo ~= nil then
        local picName = dragonInfo:call("getHeadPic")
        local pFrame = CCSpriteFrameCache:sharedSpriteFrameCache():spriteFrameByName(picName)
        self.m_dragonSpr:setSpriteFrame(pFrame)
        self.m_dragonTxt:setString(_lang(dragonInfo:call("getName")))
        self.m_dragonYesSpr:setVisible(true)
        self.m_dragonPower = dragonInfo:call("getPower")
        self:setChallengeJudgement()
        self.m_delDragonBtn:setVisible(true)
        self.m_dragonSprCover:setVisible(false)
    else
        local speName = "icon_battle_head_dragon.png"
        self.m_dragonSprCover:setVisible(true)
        local pFrame = CCSpriteFrameCache:sharedSpriteFrameCache():spriteFrameByName(speName)
        self.m_dragonSpr:setSpriteFrame(pFrame)
        self.m_dragonTxt:setString(_lang("169040"))
        self.m_dragonYesSpr:setVisible(false)
        self.m_dragonPower = 0
        self.m_delDragonBtn:setVisible(false)
    end
    self:updateBuffIcon()
end

function BattleView:onCorrectMarchNum(obj)
    if (obj == nil) then
        return
    end

    self.m_maxCorrectNum = obj:intValue()
    self:unselectAll()
    self:onClickQuickBtn(nil, cc.CONTROL_EVENTTYPE_TOUCH_DOWN)
    self.m_marchBtn:setEnabled(true)
end

function BattleView:setCiviBuildNode()
    self.m_extraNode:setVisible(false)
    self.m_formationNode:setVisible(true)
    self.m_formation1:setVisible(false)
    self.m_formation2:setVisible(false)
    self.m_formation3:setVisible(false)
    self.m_formation4:setVisible(false)
    self.m_formation5:setVisible(false)
    self.m_externBtnNode:setVisible(false)
    
    self.m_formationName:setAnchorPoint(ccp(0.5, 0.5))
    self.m_formationName:setPositionX(-265)
    self.m_formationName:setColor(ccc3(221, 179, 124))
    
    local infoNode = CCNode:create()
    local root = self.m_extraNode:getParent()
    infoNode:setPosition(self.m_extraNode:getPositionX(), self.m_extraNode:getPositionY())
    root:addChild(infoNode)
    
    local info = WorldController:call("getCityInfoByIndex", self.m_targetIndex)
    if info ~= nil then
        local buildId = info:getProperty("m_allianceMiracleInfo"):getProperty("buildConfigId")
        local buildSpd = CCCommonUtilsForLua:getPropByIdGroup("alliance_building", buildId, "build_speed")
        local name = CCCommonUtilsForLua:getPropByIdGroup("alliance_building", buildId, "name")
        self.ui.m_labelTitle:setString(_lang(name))
        
        local t1 = splitString(buildSpd, "|")
        if (#t1 == 4) then
            for index, value in ipairs(t1) do
                local t2 = splitString(value, ";")
                if (#t2 == 2) then
                    self.m_civiRate[tonumber(t2[1])] = tonumber(t2[2])
                end
            end
        end
    end
    
    self.m_cvBuildLabel = {}
    
    local cow = 3
    local row = 4
    for i = 1, cow do
        for j = 1, row do
            local label = cc.Label:create()
            label:setSystemFontSize(24)
            label:setColor(ccc3(221, 179, 124))
            label:setPosition(ccp((i - 2) * 180, (2 - j) * 30 + 30))
            infoNode:addChild(label)
            
            if (i == 1) then
                if (j == 1) then
                    label:setString(_lang("250019"))
                elseif (j == 2) then
                    label:setString(_lang("250020"))
                elseif (j == 3) then
                    label:setString(_lang("250021"))
                else
                    label:setString(_lang("250022"))
                end
            elseif (i == 2) then
                label:setString(CC_ITOA_1(self.m_civiRate[j]))
            else
                table.insert(self.m_cvBuildLabel, label)
            end
        end
    end
end

function BattleView:refreshCiviRate()
    local sum = {0.0, 0.0, 0.0, 0.0}
    
    local k4 = WorldController:call("getInstance"):getProperty("m_buildSpdK4")
    local k5 = WorldController:call("getInstance"):getProperty("m_buildSpdK5")
    local factor = k4 * k5 * 3600
    
    local battleInfos = TroopsController:call("getInstance"):getProperty("m_tmpBattleInfos")
    for key, value in pairs(battleInfos) do
        if (value > 0) then
            local arm = CCCommonUtilsForLua:getPropById(key, "arm");
            local power = tonumber(CCCommonUtilsForLua:getPropById(key, "power"))
            local armType = tonumber(arm)
        
            local count = value
            -- 步兵
            if (armType == ArmEnumType.ARM_BU or armType == ArmEnumType.ARM_QIANG) then
                sum[1] = sum[1] + count * power * self.m_civiRate[1] * factor
            end
            -- 骑兵
            if (armType == ArmEnumType.ARM_RIDE or armType == ArmEnumType.ARM_RIDE_SHE) then
                sum[2] = sum[2] + count * power * self.m_civiRate[2] * factor
            end
            -- 弓兵
            if (armType == ArmEnumType.ARM_GONG or armType == ArmEnumType.ARM_NU) then
                sum[3] = sum[3] + count * power * self.m_civiRate[3] * factor
            end
            -- 车兵
            if (armType == ArmEnumType.ARM_TOU_SHI_BING or armType == ArmEnumType.ARM_CHE) then
                sum[4] = sum[4] + count * power * self.m_civiRate[4] * factor
            end
        end
    end
    
    local count = #self.m_cvBuildLabel
    local total = 0.0;
    for index, value in ipairs(self.m_cvBuildLabel) do
        local label = value
        if label then
            label:setString((CC_ITOA(sum[index])).._lang("102201"))
        end
        total = total + sum[index]
    end
    
    local totalStr = _lang("250023").."  "..CC_ITOA(total).._lang("102201")
    self.m_formationName:setString(totalStr)
end

function BattleView:shareCiviMiracleBuild()
    local info = WorldController:call("getCityInfoByIndex", self.m_targetIndex)
    if info ~= nil then
        local state = info:getProperty("m_allianceMiracleInfo"):getProperty("state")
        if (state == AAreaState.Astate_BeforeBuild) then
            local vm = {}
            vm["item"] = info:getProperty("m_allianceMiracleInfo"):getProperty("buildConfigId")
            vm["point"] = CC_ITOA(self.m_targetIndex)
            require("game.allianceTerritory.civiMiracle.CiviMiracleManager").shareCiviMiracleBuild(vm)
        end
    end
end

function BattleView:confirmBattle(ref)
    if (ref == nil) then
        return
    end
    
    local key = ref:getCString()
    if (key == "yes") then
        self:march()
    end
end

-- 天赋组按钮
function BattleView:onClickSkill()
    -- 新增打点 BATTLE_VIEW_CLICK_SKILL
    
    -- local skill_view = Drequire("game.CommonPopup.NewActiveSkillView").create({entrance = 1, open_page = "general"}) -- entrance 参数是1，表示从出征界面打开；open_page表示打开时切换到的页签
    -- PopupViewController:call("addPopupView", skill_view)
    self:gotoGeneralSkillView() -- 跳转到领主-天赋界面
end

-- 跳转到领主-天赋界面
function BattleView:gotoGeneralSkillView()  -- guiCommonLocal.onOpen_GeneralSkillListPopUpView
    local GeneralSkillListPopUpView = Drequire("game.general.GeneralSkillListPopUpView")
    
    local generals = GlobalData:call("shared"):getProperty("generals")
    if table.nums(generals) <= 0 then
        -- Dprint("onOpen_GeneralSkillListPopUpView | no general!")
        return
    end

    local info = table.firstvalue(generals)
	--最终调用的数据。
	local view = GeneralSkillListPopUpView:create(info, "50000", "")
    PopupViewController:addPopupInView(view)
end

-- ”去使用“按钮 -- 跳转到技能书增益
function BattleView:onClickBuff()
    -- 新增打点
    
    local skill_view = Drequire("game.CommonPopup.NewActiveSkillView").create({entrance = 1, open_page = "buff"}) -- entrance 参数是1，表示从出征界面打开；open_page表示打开时切换到的页签
    PopupViewController:call("addPopupView", skill_view)
end

-- 总攻击力详情按钮
function BattleView:onClickDetail()
    -- 新增打点
    
    -- BattleViewArmyDetailView
    local view = Drequire("game.CommonPopup.BattleViewArmyDetailView"):create()
    if view ~= nil then
		PopupViewController:call("addPopupView", view)
	end
end

-- 切换天赋组后刷新按钮显示
function BattleView:updateSkillBtn(dict)
    if nil == dict then
        return
    end

    local dictTable = dictToLuaTable(dict)
    local infoDic = dictTable["infoDic"]
    if infoDic ~= nil and infoDic["page"] ~= nil then
        local page = tonumber(infoDic["page"])
        if page ~= nil then
            CCCommonUtilsForLua:setButtonTitle(self.m_skillBtn, getLang("660911")..tostring(page)) -- 660911 技能组
        end
    end
end

function BattleView:updateBuffIcon()
    if not self.m_new_battle_view_buff or not self:isBuffAndFightPowerAreaValid() then
        return
    end

    local dragonUuid = "";
    local dragonInfo = DragonController:call("getInstance"):call("getDragonInfoByIndex", self.m_dragonIndex)
    if dragonInfo ~= nil then
        dragonUuid = dragonInfo:call("getUuid")
    end

    local params = {
        point        = self.m_targetIndex,
        petDragonUid = dragonUuid, 
        generalId    = self.m_heroId,
        aormationId  = self.m_aormationId,
        type         = self:getRealBType(),
        isRally      = self:isRally(),           -- 集结
        isSuperRally = self.m_isSuperRally == 1, -- 超级集结
        soldierDict = TroopsController:call("getInstance"):call("saveBattle"), -- 新增兵种参数
    }

    -- dump(params, "params")
    require("game.controller.BattleViewActiveBuffController").getInstance():sendBuffCommand(params)
end

function BattleView:onUpdateBuffIcon(dict)
    local params = require("game.controller.BattleViewActiveBuffController").getInstance():getBuffInfo()
    -- dump(params, "onUpdateBuffIcon")

    local icon_index = 1
    local itemArray = params["itemArray"]
    if itemArray then
        for index, value in ipairs(itemArray) do
            local toolInfo = ToolController:call("getToolInfoByIdForLua", tonumber(value.itemId))
            if toolInfo then
                self["m_buffIcon"..tostring(icon_index)]:removeAllChildren()
                CCCommonUtilsForLua:createGoodsIcon(toolInfo:getProperty("itemId"), self["m_buffIcon"..tostring(icon_index)], cc.size(25, 25))
                icon_index = icon_index + 1
                if icon_index > 5 then
                    break
                end
            end
        end
    end

    if icon_index <= 5 then
        local lordSkillArray = params["lordSkillArray"]
        if lordSkillArray then
            for index, value in ipairs(lordSkillArray) do
                local generalInfo = GlobalData:call("getSelfGeneralInfo")
                if generalInfo then
                    local pic = CCCommonUtilsForLua:call("getPropById", value.skillId, "icon") .. ".png"
                    if CCLoadSprite:call("getSF", pic) == nil then
                        pic = "dragon_skill_1.png"
                    end
                    local icon = CCLoadSprite:call("createSprite", pic)
                    local size = icon:getContentSize()
                    icon:setScale(25/size.width)
                    -- icon:setPosition(ccp(15, 15))
                    self["m_buffIcon"..tostring(icon_index)]:removeAllChildren()
                    self["m_buffIcon"..tostring(icon_index)]:addChild(icon)

                    icon_index = icon_index + 1
                    if icon_index > 5 then
                        break
                    end
                end
            end
        end
    end

    if icon_index <= 5 then
        local skillArray = params["skillArray"]
        if skillArray then
            for index, value in ipairs(skillArray) do
                local info = HeroManager.getActiveSkillInfoById(value.skillId)
                if info ~= nil  then
                    local pic = info:getIconStr()
                    if CCLoadSprite:call("getSF", pic) == nil then
                        pic = "dragon_skill_1.png"
                    end
                    local icon = CCLoadSprite:call("createSprite", pic)
                    local size = icon:getContentSize()
                    icon:setScale(25/size.width)
                    -- icon:setPosition(ccp(15, 15))
                    self["m_buffIcon"..tostring(icon_index)]:removeAllChildren()
                    self["m_buffIcon"..tostring(icon_index)]:addChild(icon)
            
                    icon_index = icon_index + 1
                    if icon_index > 5 then
                        break
                    end
                end
            end
        end
    end

    if icon_index <= 5 then
        local dragonArray = params["dragonArray"]
        if dragonArray then
            for index, value in ipairs(dragonArray) do
                local skillInfo = DragonActiveSkillManager.getInstance():getDataById(value.skillId)
                if nil ~= skillInfo then
                    local pic = CCCommonUtilsForLua:call("getPropById", value.skillId, "icon") .. ".png"
                    if CCLoadSprite:call("getSF", pic) == nil then
                        pic = "dragon_skill_1.png"
                    end
                    local icon = CCLoadSprite:call("createSprite", pic)
                    local size = icon:getContentSize()
                    icon:setScale(25/size.width)
                    -- icon:setPosition(ccp(15, 15))
                    self["m_buffIcon"..tostring(icon_index)]:removeAllChildren()
                    self["m_buffIcon"..tostring(icon_index)]:addChild(icon)

                    icon_index = icon_index + 1
                    if icon_index > 5 then
                        break
                    end
                end
            end
        end
    end

    -- 清除多余的图标
    for i = icon_index, 5 do
        self["m_buffIcon"..tostring(i)]:removeAllChildren()
    end

    self.m_buffIconNode:setVisible(icon_index > 1)
    self.m_buffDesc:setVisible(icon_index > 1)
    self.m_noBuffDesc:setVisible(icon_index <= 1)
end

function BattleView:getRealBType()
    if (SceneController:call("getCurrentSceneId") == SCENE_ID_WORLD and self.m_bType ~= MarchMethodType.MethodRally and self.m_bType ~= MarchMethodType.KingdomTeamBattle 
            and self.m_bType ~= MarchMethodType.KingdomTeamAssembly and self.m_bType ~= MarchMethodType.ArenaTeamBattle and self.m_bType ~= MarchMethodType.ArenaTeamAssembly
            and self.m_bType ~= MarchMethodType.DarkCivOne and self.m_bType ~= MarchMethodType.DarkCivThree and self.m_bType ~= MarchMethodType.DarkCivTwo
            and self.m_bType ~= MarchMethodType.MethodTeamRally) then
        local type = MarchMethodType.MethodBattle
        local info = WorldController:call("getCityInfoByIndex", self.m_targetIndex)
        if(self.m_targetType == WorldCityType.ActBossTile or info ~= nil) then
            local cityType = info and info:getProperty("cityType") or nil
            local luaType = info and info:getProperty("luaType") or nil
            if(self.m_targetType == WorldCityType.ActBossTile
            or cityType == WorldCityType.FieldMonster
            or cityType == WorldCityType.FOUR_FIELD_MONSTER  -- 4格野怪
            or (cityType == WorldCityType.LuaNewTile and info:getProperty("luaType") == WorldCityType.nationalwar_boss)
            or (cityType == WorldCityType.LuaNewTile and info:getProperty("luaType") == WorldCityType.craft_boss)
            or cityType == WorldCityType.hero_maintheme_monster
            or cityType == WorldCityType.dark_civ_monster
            or cityType == WorldCityType.ActBossTile
            or cityType == WorldCityType.AllianceBoss
            or cityType == WorldCityType.tile_HpWorldBoss) then

                type = MarchMethodType.MethodFieldMonster
                
                if (info ~= nil and cityType == WorldCityType.tile_HpWorldBoss and info:getProperty("hpWorldBossInfo"):getProperty("type") == 4) then -- WorldBossType.WorldBossType_Npc
                    type = MarchMethodType.MethodNpcWorldBoss
                elseif (info  ~= nil and cityType == WorldCityType.hero_maintheme_monster) then
                    type = MarchMethodType.HeroThemeMonster
                end
            elseif (self.m_targetType == WorldCityType.Barbarian) then
                -- nothing
            elseif (cityType == WorldCityType.LuaNewTile and luaType == WorldCityType.city_barracks) then
                type = MarchMethodType.MethodCAMP
            elseif (cityType == WorldCityType.LuaNewTile and luaType == WorldCityType.hero_maintheme_resource) then
                type = MarchMethodType.HeroThemeCollect
            end
        end

        if (self.m_bType ~= -1) then
            type = self.m_bType
        end
        return type
    else
        if(self.m_bType == -1) then
            return MarchMethodType.MethodBattle   -- 如果返回-1，服务端会报错
        end

        if (self.m_specialMass == 1 and self.m_bType ~= MarchMethodType.KingdomTeamAssembly) then
            self.m_bType = MarchMethodType.KingdomTeamBattle
        elseif (self.m_specialMass == 2 and self.m_bType ~= MarchMethodType.ArenaTeamAssembly) then
            self.m_bType = MarchMethodType.ArenaTeamBattle
        end

        return self.m_bType
    end
end

function BattleView:isRally()
    return self.m_bType == MarchMethodType.MethodRally or self.m_bType == MarchMethodType.MethodUnion                   -- 集结 or 参与集结 
        or self.m_bType == MarchMethodType.KingdomTeamBattle or self.m_bType == MarchMethodType.KingdomTeamAssembly     -- 王国集结 or 参与 
        or self.m_bType == MarchMethodType.ArenaTeamBattle or self.m_bType == MarchMethodType.ArenaTeamAssembly         -- 竞技场组队集结 or 参与
        or self.m_bType == MarchMethodType.DarkCivOne or self.m_bType == MarchMethodType.DarkCivThree                   -- 暗黑文明城堡第一 or 第三阶段
        or self.m_bType == MarchMethodType.MethodTeamRally or self.m_bType == MarchMethodType.MethodTeamUnion           -- 小队集结 or 参与小队集结 
end

function BattleView:onClickBuffIconNode()
    -- 新增打点
    
    local view = Drequire("game.CommonPopup.BattleViewActiveBuffView"):create()
    if view ~= nil then
		PopupViewController:call("addPopupView", view)
	end
end

function BattleView:updateFightPower()
    self.m_fightPower:setString(tostring(math.floor(self.m_armyPower)))
end

-- 是否是参与集结
function BattleView:isJoinRally()
    return self:isRally() and self.m_other ~= ""   
end

function BattleView:isRallyLeftTimeEnough()
    local isEnough = true
    local now = getWorldTime()
    local leftTime = self.m_rallyEndTime - now 
    if leftTime > 0 and leftTime < self.m_marchTime then
        isEnough = false
    end
    return isEnough
end

-- 无尽的试炼提示
function BattleView:onBtnInfo()
    local params = {}
	params.title = getLang("108730")
	params.info = getLang("52052091") 
	local view = Drequire("game.DressIntroduction.CommonInfoViewNew"):create(params)
	PopupViewController:addPopupView(view)
end

-- pubg快捷攻击
function BattleView:addAttackDataForPubg()
    local serverType = GlobalData:call("shared"):getProperty("serverType")
    if serverType ~= ServerType.SERVER_ANCESTRAL then return end

    --集结不记录数据
    if self.m_bType == MarchMethodType.MethodRally or self.m_bType == MarchMethodType.MethodUnion then
        return
    end

    local info = WorldController:call("getCityInfoByIndex", self.m_targetIndex)
    if not info then return end

    local playerInfo = info:getProperty("playerInfo")
    if not playerInfo then return end

    local userUid = playerInfo:getProperty("userUid")

    if self.m_targetType == WorldCityType.CityTile then
        BattlefieldController.getInstance():addQuickAttackData(userUid)
    end
end

-- pubg快捷配兵按钮
function BattleView:addPubgQuickBtn()
    local parent = self.node_marchType:getParent()
    local x, y = self.node_marchType:getPosition()

    local rate1 = BattlefieldController.getInstance().v_ancestralMarchRate1
    local function quick()
        self:quickConfig4pubg(rate1)
    end

    local btn = CCControlButton:create(CCLoadSprite:call("createScale9Sprite", "BTN_lvanniu.png"))
    btn:setPreferredSize(cc.size(98, 56))
    btn:addHandleOfControlEvent(quick, cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE)
    btn:setPosition(x + 30, y + 78)
    CCCommonUtilsForLua:setButtonTitle(btn, getLang("102205", rate1))
    parent:addChild(btn)

    local rate2 = BattlefieldController.getInstance().v_ancestralMarchRate2
    local function quick()
        self:quickConfig4pubg(rate2)
    end

    local btn = CCControlButton:create(CCLoadSprite:call("createScale9Sprite", "BTN_lvanniu.png"))
    btn:setPreferredSize(cc.size(98, 56))
    btn:addHandleOfControlEvent(quick, cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE)
    btn:setPosition(x + 30, y + 18)
    CCCommonUtilsForLua:setButtonTitle(btn, getLang("102205", rate2))
    parent:addChild(btn)
end

function BattleView:quickConfig4pubg(rate)
    local totalFree = ArmyController:call("getTotalFree")
    local marchNum = math.floor(totalFree * atoi(rate) / 100)

    self:selectAll(marchNum)

    TroopsController:call("getInstance"):call("changeArrTime")
    local cell_count = self:numberOfCellsInTableView()
    for index = 1, cell_count do
        local cell = self.m_tabView:cellAtIndex(index-1)
        if cell then
            cell:refresh()
        end
    end
end

return BattleView
