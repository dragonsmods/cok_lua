--建筑建造
local Cell_Science = class("Cell_Science",Drequire("game.CommonPopup.OverView.Cell_Info.Cell_QueueFile"))
--科技研究队列
local SCIENCE_QUEUE_1ST = 3701
local SCIENCE_QUEUE_2ND = 3702
local FUN_BUILD_SCIENE = 403000

function Cell_Science:create(Id)
    local ret = Cell_Science.new(Id)
    if ret:initBaseById(Id) then
        return ret
    end
end

function Cell_Science:getCureQueueInfo()
    if not self:checkIsVisible() then
        return
    end
    local tempTbl = {}
    tempTbl[#tempTbl+1] = self:getSubTypeCellTbl(SCIENCE_QUEUE_1ST)
    tempTbl[#tempTbl+1] = self:getSubTypeCellTbl(SCIENCE_QUEUE_2ND)
    self.CellTbl.cellMeta=tempTbl
    return self.CellTbl
end

function Cell_Science:getSubTypeCellTbl(qid)
    local res = {}
	local _state = self.Queue_ST_Init
	local _finishTime = -1
	local _totalTime = -1
	local _label = ""
	local _type = -1
    local _id = ""
    local _name = ""
    local _icon = ""
    local _visible = ""
    
    local qInfo = self.allQueuesInfos[qid]

    if qid ~= QID_MAX then
        _state,_finishTime,_totalTime = self:getQueueState(qInfo)
	else
		_state = self.Queue_ST_IDLE
		_finishTime = 0
		
	end

    local isLock = self:checkIsUnLock(FUN_BUILD_SCIENE)	

	if _state == self.Queue_ST_LOCK then
        _label = "2000442" --2000442=未解锁
    elseif _state == self.Queue_ST_IDLE then
        _label = "169606" --空闲
    elseif _state == self.Queue_ST_WORK then
        _label = "2000431" --研究中
    end
    if qid == SCIENCE_QUEUE_1ST then
        _id = "30711007"
    elseif qid == SCIENCE_QUEUE_2ND then
        _id = "30711008"
    end		

    if not isLock then
		_state = self.Queue_ST_LOCK
		_finishTime = -1
		_label = "2000442"
	end

    if  _label ~= "" then
        _name,_icon,_visible = self:getNameIconVisibleBySubId(_id)        
		res = {id = _id, state = _state, param1 = _finishTime, param2 = _totalTime,label = _label,name = _name,icon = _icon,cell = self}
    end
    if _visible == "1" then
        return res
    end
end

function Cell_Science:OnClickJump(_id,_state)
    if _id == "30711007" or _id == "30711008" then
        if _state == self.Queue_ST_WORK or _state == self.Queue_ST_IDLE then            
            local dict = CCDictionary:create() 
            dict:setObject(CCString:create("ScienceListView"), "name")
            LuaController:call("openPopViewInLua", dict)
        elseif _state == self.Queue_ST_LOCK then
            --未解锁,目前是跳过去,会提示建造该建筑
            self:jumpByTypeAndTarget(1,FUN_BUILD_SCIENE)
        end
    end
end

return Cell_Science