----------------------------
-- Author: Elex
-- Date: 2019-07-23 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CommonRankGroupTitleView_ui = class("CommonRankGroupTitleView_ui")

--#ui propertys


--#function
function CommonRankGroupTitleView_ui:create(owner, viewType, paramTable)
	local ret = CommonRankGroupTitleView_ui.new()
	CustomUtility:LoadUi("CommonRankGroupTitleView.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CommonRankGroupTitleView_ui:initLang()
	LabelSmoker:setText(self.m_globalLabel, "140459")
	LabelSmoker:setText(self.m_localLabel, "140460")
end

function CommonRankGroupTitleView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CommonRankGroupTitleView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CommonRankGroupTitleView_ui:onClickBtnGlobal(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnGlobal", pSender, event)
end

function CommonRankGroupTitleView_ui:onClickBtnLocal(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnLocal", pSender, event)
end

return CommonRankGroupTitleView_ui

