local MSG_BUY_CELL = "msg.buy.cell"
local MSG_TOOL_CHANGE = "msg.tool.change"
local MSG_REFREASH_DRAGONTOOL_DATA = "msg_refreash_dragontool_data"
local MSG_BUY_CONFIRM_OK_WITHOUT_TWEEN = "buy.confirm.ok.without.tween"
GoldBoxRankView = class("GoldBoxRankView", function()
        return PopupBaseView:create()
    end
)
GoldBoxRankView.__index = GoldBoxRankView

local GoldBoxRankCellSize = cc.size(640,110)
local GoldBoxRankCellHDSize = CCSize(1476, 290)
local cellButtonNumPosY = 22
local myActivityId = ""
local isHideName = 1
local infoListPosY = 0
local TOP_HEIGHT_HD = 154
local infoListContentDeltaHeight = 120
local infoListContentSizeHeight = 0
---------------------------排行 Start ---------------------------
GoldBoxRankCmd = class("GoldBoxRankCmd", LuaCommandBase)
function GoldBoxRankCmd.create()
    local ret = GoldBoxRankCmd.new()
    ret:initWithName("goldwheel.rank")
    return ret
end

function GoldBoxRankCmd:handleReceive(dict)
    local cmdname = dict:valueForKey("cmd"):getCString()
    if cmdname ~= "goldwheel.rank" then
        return false
    end
    --dump("GoldBoxRankCmd:handleReceive")
    local params = dict:objectForKey("params")
    if nil == params then
        --dump("GoldBoxRankCmd.create no params...")
        return true
    end
    params = tolua.cast(params, "CCDictionary")
    local tbl = dictToLuaTable(params)
    --dump(tbl)

    if tbl.errorCode and tbl.errorCode ~= "" then
        LuaController:flyHint("", "", getLang(tbl.errorCode))
        return true
    end
    CCSafeNotificationCenter:postNotification("goldbox_get_wheelRank",params)

    return true
end
--------------------------- 排行 End ---------------------------

---------------------------隐藏姓名 Start ---------------------------
GoldBoxRankHideCmd = class("GoldBoxRankHideCmd", LuaCommandBase)
function GoldBoxRankHideCmd.create()
    local ret = GoldBoxRankHideCmd.new()
    ret:initWithName("goldwheel.update")
    return ret
end

function GoldBoxRankHideCmd:handleReceive(dict)
    local cmdname = dict:valueForKey("cmd"):getCString()
    if cmdname ~= "goldwheel.update" then
        return false
    end
    dump("GoldBoxRankHideCmd:handleReceive")
    local params = dict:objectForKey("params")
    if nil == params then
        --dump("GoldBoxRankHideCmd.create no params...")
        return true
    end
    params = tolua.cast(params, "CCDictionary")
    local tbl = dictToLuaTable(params)
    dump(tbl,"cjy GoldBoxRankHideCmd")

    if tbl.errorCode and tbl.errorCode ~= "" then
        LuaController:flyHint("", "", getLang(tbl.errorCode))
        return true
    end
    CCSafeNotificationCenter:postNotification("goldbox_get_wheelRank",params)

    return true
end
--------------------------- 排行 End ---------------------------

------------------------------------------ GoldBoxRankCell Start --------------------------------------------
local GoldBoxRankCell = class("GoldBoxRankCell", function()
    return cc.Layer:create()
end)

function GoldBoxRankCell:create(i,dataList)
    local ret = GoldBoxRankCell.new()
    if ret:init(i,dataList) == false then
        return nil
    end
    return ret
end

function GoldBoxRankCell:init(i,dataList)
    --初始化界面
    --MyPrint("GoldBoxRankCell init start")
    local proxy = cc.CCBProxy:create()
    local ccbiURL = ""
    ccbiURL = "ccbi/GoldBoxRankCellForLua.ccbi"

    local nodeccb = CCBReaderLoad(ccbiURL,proxy, self)
    if nodeccb == nil then
        --MyPrint("GoldBoxRankCell loadccb error")
        return false
    end

    self:setContentSize(nodeccb:getContentSize())
    self:addChild(nodeccb)

    local function onNodeEvent(event)
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end
    self.ccbNode = nodeccb
    self.ccbNode:registerScriptHandler(onNodeEvent)

    function onTouch(eventType, x, y)  
        if eventType == "began" then  
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)  
        else  
            return self:onTouchEnded(x, y)  
        end
    end
    self:setTouchEnabled(true)
    self:registerScriptTouchHandler(onTouch)

    self.m_index = i 
    self.m_dataList = dataList
    self:refreshCell()

    return true
end

function GoldBoxRankCell:onTouchBegan(x, y)
    
end

function GoldBoxRankCell:onTouchMoved(x, y)
end

function GoldBoxRankCell:onTouchEnded(x, y)
end

function GoldBoxRankCell:refreshCell()
    --MyPrint("GoldBoxRankCell setData start")
    self.m_sprBG1:setVisible(false)
    self.m_sprBG2:setVisible(false)
    self.m_sprBG3:setVisible(false)
    self.m_sprBG4:setVisible(false)
    local maxCount = 30
    if CCCommonUtilsForLua:isFunOpenByKey("golden_roulette_31_50") then
        maxCount = 50
    end
    if self.m_index == 1 then
        self.m_numspr2:setVisible(false)
        self.m_numspr3:setVisible(false)
        self.m_sprBG1:setVisible(true)
        self.m_numText:setVisible(false) 
    elseif self.m_index == 2 then
        self.m_numspr1:setVisible(false)
        self.m_numspr3:setVisible(false)
        self.m_sprBG2:setVisible(true)
        self.m_numText:setVisible(false) 
    elseif self.m_index == 3 then
        self.m_numspr2:setVisible(false)
        self.m_numspr1:setVisible(false)
        self.m_sprBG3:setVisible(true)
        self.m_numText:setVisible(false) 
    elseif self.m_index >= 4 and self.m_index <= maxCount then 
        self.m_numspr2:setVisible(false)
        self.m_numspr1:setVisible(false) 
        self.m_numspr3:setVisible(false)
        self.m_numText:setString(tostring(self.m_index))
        self.m_numText:setVisible(true) 
    else
        self.m_numspr2:setVisible(false)
        self.m_numspr1:setVisible(false) 
        self.m_numspr3:setVisible(false)
        self.m_numText:setVisible(false)        
    end
    if tostring(GlobalData:call("shared"):getProperty("playerInfo"):getProperty("uid")) == tostring(self.m_dataList.uid) then -- 是自己
        self.m_sprBG4:setVisible(true)
        if isHideName then
            self.m_text1:setString(getLang("140473"))
            self.m_text2:setString("")
        else
            self.m_text1:setString(self.m_dataList.name)
            self.m_text2:setString(getLang("111895",self.m_dataList.kingId))
        end
    elseif self.m_dataList.hideKing then
        if self.m_dataList.hideKing == "1" then
            self.m_text1:setString(getLang("140473"))
            self.m_text2:setString("")
        elseif self.m_dataList.hideKing == "0" then
            self.m_text1:setString(self.m_dataList.name)
            self.m_text2:setString(getLang("111895",self.m_dataList.kingId))
        end
    end
    
    self.m_text3:setString(self.m_dataList.count)
end

function GoldBoxRankCell:onEnter()
end

function GoldBoxRankCell:onExit()
end
------------------------------------------ GoldBoxRankCell End --------------------------------------------

------------------------------------------ GoldBoxRankRewardCell Start --------------------------------------------
local GoldBoxRankRewardCell = class("GoldBoxRankRewardCell", function()
    return cc.Layer:create()
end)

function GoldBoxRankRewardCell:create()
    local ret = GoldBoxRankRewardCell.new()
    if ret:init() == false then
        return nil
    end
    return ret
end

function GoldBoxRankRewardCell:init()
    --初始化界面
    --MyPrint("GoldBoxRankRewardCell init start")
    local proxy = cc.CCBProxy:create()
    local ccbiURL = ""
    ccbiURL = "ccbi/GoldBoxRankRewardCellForLua.ccbi"

    local nodeccb = CCBReaderLoad(ccbiURL,proxy, self)
    if nodeccb == nil then
        --MyPrint("GoldBoxRankRewardCell loadccb error")
        return false
    end

    self:setContentSize(nodeccb:getContentSize())
    local layer = cc.LayerColor:create(cc.c4b(0, 0, 0, 255))
    --MyPrint("cjy self.node_rankAD:getContentSize() ",self.node_rankAD:getContentSize().width,self.node_rankAD:getContentSize().height)
    layer:setContentSize(self.node_rankAD:getContentSize())
    self:addChild(layer)
    self:addChild(nodeccb)

    local function onNodeEvent(event)
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end
    self.ccbNode = nodeccb
    self.ccbNode:registerScriptHandler(onNodeEvent)

    function onTouch(eventType, x, y)  
        if eventType == "began" then  
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)  
        else  
            return self:onTouchEnded(x, y)  
        end
    end
    self:setTouchEnabled(true)
    self:registerScriptTouchHandler(onTouch)

    CCCommonUtilsForLua:setButtonTitle(self.btn_reward,getLang("115331"))  -- 查看详情
    MyPrint("getPropByIdGroup golden_roulette ")
    -- local adtype_dialog = CCCommonUtilsForLua:getPropByIdGroup("golden_roulette","89600", "adtype_dialog")
    --CCCommonUtilsForLua:getPropById("89600", "adtype_dialog")

    self.txt_reward2:setString(getLang("140471"))   -- 140471=全球限量奖励只在激战黄金宝箱!
    self.txt_reward3:setString(getLang("140472"))   -- 140472=超值宝箱,各类排名,送您超值大奖!
    --dynamic pic

    local resname = ""
    --MyPrint("cjy myActivityId ",myActivityId)
    local obj = ActivityController:call("getInstance"):call("getActObj", tostring(myActivityId))
    if obj and obj:getDyResName()  then
        resname = obj:getDyResName()
        if DynamicResourceController2:call("checkDynamicResource", resname) then
            local adType = tonumber(CCCommonUtilsForLua:getPropById("89600", "adType"))
            if adType then
                CCLoadSprite:call("loadDynamicResourceByName", "57153_face_"..adType)
                local adName = myActivityId .. "_ad_"..adType..".png"
                local adSprSF = CCLoadSprite:call("getSF", adName)
                local adSpr = cc.Sprite:createWithSpriteFrame(adSprSF)
                if adSpr then
                    self.node_rankDynamic:removeAllChildren()
                    self.node_rankDynamic:addChild(adSpr) --物品背景图
                    adSpr:setAnchorPoint(cc.p(0,1))
                    self.spr_rewardPic:setVisible(false)
                end
            end
        end
    end
    self.sprIndex = 1
    local sprNum = self:getAvatarSprNums()
    self:changeAvatarSpr(self.sprIndex)
    self:changeLabelInfo(self.sprIndex)
    if sprNum > 1 then
        self.m_leftArr:setVisible(false) --先屏蔽左侧按钮
        self.m_rightArr:setVisible(true)
    else
        self.m_leftArr:setVisible(false)
        self.m_rightArr:setVisible(false)
    end
    
    local fi1 = cc.FadeIn:create(1)
    local fo1 = cc.FadeOut:create(1)
    local seq =cc.Sequence:create(fi1,fo1,nil)
    local rp1 = cc.RepeatForever:create(seq)
    self.m_rightArr:runAction(rp1)

    local fi2 = cc.FadeIn:create(1)
    local fo2 = cc.FadeOut:create(1)
    local seq1 =cc.Sequence:create(fi2,fo2,nil)
    local rp2 = cc.RepeatForever:create(seq1)
    self.m_leftArr:runAction(rp2)

    return true
end

function GoldBoxRankRewardCell:getAvatarSprNums()
    local resNum = 1
    local str = CCCommonUtilsForLua:getPropById("89601", "adShow")
    if str~=nil or str~="" then
        resNum = 2
    end
    return resNum
end

function GoldBoxRankRewardCell:changeAvatarSpr(index)
    self.m_AvatarSpr:removeAllChildren()
    local function addSKNode(faceInfo, node)
        local tbl = string.split(faceInfo, ",")
        if tbl[1] ~= "" then
            local md5 = nil
            if #tbl > 4 then
                md5 = tbl[#tbl]
            end
            local avatarShow = Drequire("game.avatar.AvatarFaceShowView").new(tbl[1], nil, md5)
            node:addChild(avatarShow)
            if tbl[2] then
                avatarShow:setPositionX(tonumber(tbl[2]))
            end
            if tbl[3] then
                avatarShow:setPositionY(tonumber(tbl[3]))
            end
            if tbl[4] then
                avatarShow:setScale(tonumber(tbl[4]))
            end
        end
    end
    local str = ""
    if index == 1 then
        str = CCCommonUtilsForLua:getPropById("89600", "adShow")
    elseif index == 2 then
        str = CCCommonUtilsForLua:getPropById("89601", "adShow")
    end
    local showNode = cc.Node:create()
    self.m_AvatarSpr:addChild(showNode)
    showNode:setPosition(cc.p(0, 970 - 570))
    local tmp = string.split(str, "|")

    for i, faceInfo in pairs(tmp) do
        if faceInfo ~= "" then
            addSKNode(faceInfo, showNode)
        end
    end
end

function GoldBoxRankRewardCell:changeLabelInfo(index)
    local adtype_dialog = "140470"
    if index == 1 then
        adtype_dialog =CCCommonUtilsForLua:call("getPropByIdGroup", "golden_roulette", "89600","adtype_dialog")
    elseif index == 2 then
        adtype_dialog =CCCommonUtilsForLua:call("getPropByIdGroup", "golden_roulette", "89601","adtype_dialog")
    end
    self.txt_reward1:setString(getLang(adtype_dialog))   -- 140470=云中城震撼来袭
end

function GoldBoxRankRewardCell:onClickReward(  )

    local lua_path = "game.CommonPopup.GoldBoxTipsView"
    package.loaded[lua_path] = nil
    local view = require(lua_path):create()
    PopupViewController:addPopupView(view)
    
end

function GoldBoxRankRewardCell:onClickChangeSpr()
    if self.sprIndex == 1 then
        self.sprIndex = 2
        self.m_rightArr:setVisible(false)
        self.m_leftArr:setVisible(true)
    else
        self.sprIndex = 1
        self.m_rightArr:setVisible(true)
        self.m_leftArr:setVisible(false)
    end
    self:changeAvatarSpr(self.sprIndex)
    self:changeLabelInfo(self.sprIndex)
end
function GoldBoxRankRewardCell:onTouchBegan(x, y)
    
end

function GoldBoxRankRewardCell:onTouchMoved(x, y)
end

function GoldBoxRankRewardCell:onTouchEnded(x, y)
end

function GoldBoxRankRewardCell:onEnter()
end

function GoldBoxRankRewardCell:onExit()
end
------------------------------------------ GoldBoxRankRewardCell End --------------------------------------------

------------------------------------------ GoldBoxRankView Start --------------------------------------------

function GoldBoxRankView:create(activityId)
    local view = GoldBoxRankView.new()
    if view:initView(activityId) == false then
        return nil
    end
    return view
end

function GoldBoxRankView:initView(activityId)
    if self:init(true) == false then
        --MyPrint("AllianceRankView init error")
        return false
    end

    self.m_type = type
    myActivityId = activityId
    self:setIsHDPanel(true)
    CCLoadSprite:call("doResourceByCommonIndex", 7, true)
    CCLoadSprite:call("doResourceByCommonIndex", 205, true)

    --读取ccbi
    local proxy = cc.CCBProxy:create()
    local ccbiURL = "ccbi/GoldBoxRankViewForLua.ccbi"
    local nodeccb = CCBReaderLoad(ccbiURL, proxy, self)
    if nodeccb == nil then
        MyPrint("GoldBoxRankView loadccb error")
        return false
    else
        MyPrint("GoldBoxRankView loadccb done")
    end
    local layer = cc.LayerColor:create(cc.c4b(0, 0, 0, 255))
    self:addChild(layer)
    self.ccbNode = nodeccb
    self:addChild(nodeccb)

    if CCCommonUtilsForLua:isIosAndroidPad() then
        self.ccbNode:setScale(2.4)
        local realSize = cc.Director:getInstance():getIFWinSize()
        -- self.ccbNode:setPosition(cc.p(0, (realSize.height-852)*0.5 - 570))
        -- local realSize = cc.Director:getInstance():getIFWinSize()
        self.ccbNode:setPosition((realSize.width-640)*0.5, (realSize.height-852))
        nodeccb:setAnchorPoint(0.5, 1)
        -- self.ccbNode:setPosition((realSize.width)*0.5, (realSize.height)*0.5)
        self:setContentSize(realSize)
    else
        self:setContentSize(self.ccbNode:getContentSize())
    end

    local extH = self:getExtendHeight()
    local oldBgHeight = self.m_buildBG:getContentSize().height
    self:changeBGHeight(self.m_buildBG)
    local newBgHeight = self.m_buildBG:getContentSize().height
    local addHeight = newBgHeight - oldBgHeight
    local winSize = cc.Director:sharedDirector():getIFWinSize()
    if CCCommonUtilsForLua:isIosAndroidPad() then
        addHeight = (winSize.height - 2048) / 2.4
        newBgHeight = winSize.height - TOP_HEIGHT_HD
        newBgHeight = newBgHeight / 2.4
    end
    local oldWidth = self.m_infoList:getContentSize().width
    local oldHeight = self.m_infoList:getContentSize().height
    self.m_infoList:setPositionY(self.m_infoList:getPositionY()-addHeight)
    infoListPosY = self.m_infoList:getPositionY()
    self.m_infoList:setContentSize(cc.size(oldWidth, oldHeight+addHeight))
    infoListContentSizeHeight = self.m_infoList:getContentSize().height
    layer:setPositionY(layer:getPositionY() - addHeight)

    local scrollView3 = cc.ScrollView:create()
    if scrollView3 ~= nil then
        scrollView3:setViewSize(self.m_infoList:getContentSize())
        scrollView3:setPosition(cc.p(0,0))
        scrollView3:setScale(1.0)
        scrollView3:ignoreAnchorPointForPosition(true)
        scrollView3:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
        self.m_infoList:addChild(scrollView3);
        local cH = self.m_infoList:getContentSize().height
        local height = 980
        local mainNode = cc.Node:create();
        local cell = nil            
        cell = GoldBoxRankRewardCell:create()
        mainNode:addChild(cell)
        cell:setContentSize(cc.size(640,height))
        cell:setPosition(cc.p(0, -height ))
        scrollView3:addChild(mainNode);
        mainNode:setPosition(cc.p(0, height))
        scrollView3:setContentSize(CCSize(self.m_infoList:getContentSize().width,height))
        scrollView3:setContentOffset(CCPoint(0, cH - height))

    end
    self.scrollView3 = scrollView3

    self.m_tableView = {}

    local BGcount = (newBgHeight-80)/100+1-1
    for i = 0, BGcount - 1, 1 do
        local pic = CCLoadSprite:call("createSprite", "technology_09.png")
        self.m_totalNode:addChild(pic)
        pic:setPositionY(219-(i+1)*100)
    end
    self.m_waiteNode = cc.Node:create()
    self.m_waiteNode:setContentSize(winSize)
    self.m_waiteNode:setPosition(cc.p(0, -extH))
    self:addChild(self.m_waiteNode)
    self.m_waitInterface = nil

    local function onNodeEvent(event)
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end
    self.ccbNode:registerScriptHandler(onNodeEvent)
    function onTouch(eventType, x, y)  
        if eventType == "began" then  
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)  
        else  
            return self:onTouchEnded(x, y)  
        end
    end
    local touchif = tolua.cast(self,"cc.CCIFTouchNode")
    if touchif ~= nil then
        local dic1 = CCDictionary:create()
        dic1:setObject(CCBool:create(true),"1")
        touchif:comFunc("setTouchEnabled", dic1)

        --MyPrint("BagExchangeView:registerScriptTouchHandler")
        touchif:registerScriptTouchHandler(onTouch)
    end

    self = tolua.cast(self,"PopupBaseView")
    self.m_deltTime = 0
    self.m_nowRankIndex = 1
    -- CCCommonUtilsForLua:setButtonTitle(self.m_rankBtn1, getLang("140474"))
    -- CCCommonUtilsForLua:setButtonTitle(self.m_rankBtn2, getLang("140476"))
    -- CCCommonUtilsForLua:setButtonTitle(self.m_rankBtn3, getLang("140477"))
    self.m_colorLight = cc.c3b(104,88,73)
    self.m_colorDark = cc.c3b(255,206,87)
    self.txt_rankBtn1:setString(getLang("140474"))
    self.txt_rankBtn2:setString(getLang("140476"))
    self.txt_rankBtn3:setString(getLang("140477"))
    self.m_rankTitle:setString(getLang("140485"))
    self.m_textTitle1:setString("")
    self.m_textTitle2:setString("")
    self:setTitleName(getLang("150289"))
    self.m_rankConstruction:setString(getLang("140501" , ActivityController.getInstance():getProperty("goldBoxScoreLimit")))
    local cmd = GoldBoxRankCmd:create()
    cmd:send()
    self.titlePositionX = self.m_rankTitle:getPositionX()
    return true
end

function GoldBoxRankView:onTipBtnClick(  )
    
end
function GoldBoxRankView:update( dt )
    self.m_deltTime = self.m_deltTime - 1
    if self.m_deltTime < 0 then
        self.m_deltTime = 0
    end
    self.m_timeLeftText:setString(format_time(self.m_deltTime))
end
function GoldBoxRankView:onEnter()
    local function onRefresh( ref )
        local tbl = dictToLuaTable(ref)
        self.rankDataList = tbl
        --dump(tbl,"cjy tbl111")
        -- self:onRefresh(tbl,true)
        self:onNewRefresh(tbl, self.m_nowRankIndex)
        if self.m_nowRankIndex == 1 then
            self:onClickRankBtn1()
        elseif self.m_nowRankIndex == 2 then
            self:onClickRankBtn2()
        elseif self.m_nowRankIndex == 3 then
            self:onClickRankBtn3()
        end
    end 
    local t = tolua.cast(self, "cc.Node")
    local handler = t:registerHandler(onRefresh)
    CCSafeNotificationCenter:registerScriptObserver(self, handler, "goldbox_get_wheelRank")

    self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:update(dt) end, 1, false)
    self:onClickRankBtn1()
end

function GoldBoxRankView:onExit()
    CCSafeNotificationCenter:unregisterScriptObserver(self, "goldbox_get_wheelRank")    
    if self.m_entryId ~= nil then
        self:getScheduler():unscheduleScriptEntry(self.m_entryId)
        self.m_entryId = nil
    end
end

function GoldBoxRankView:onTouchBegan(x, y)
    return false
end

function GoldBoxRankView:onTouchMoved(x, y)
end

function GoldBoxRankView:onTouchEnded(x, y)

end

-------------------------------------------- rankItemCell Start --------------------------------------------
local rankItemCell = class("rankItemCell", function()
    return CCTableViewCell:new()
end)
local rankItemCellSize = CCSize(640, 110)
function rankItemCell:create(param)
    --初始化界面
    self:setContentSize(rankItemCellSize)
    self:refresh(param)
    return self
end

function rankItemCell:refresh(param)
    self.itemData = param.itemData
    self.m_index = param.index
    self:removeAllChildren()
    local cell = GoldBoxRankCell:create(self.m_index, self.itemData)
    self:addChild(cell)
end

-------------------------------------------- rankItemCell End --------------------------------------------

function GoldBoxRankView:initDataTable(rankType)
    if self.m_tableView[rankType] then
        self.m_tableView[rankType]:reloadData()
    else
        local listViewSize = cc.size(self.m_infoList:getContentSize().width,infoListContentSizeHeight - infoListContentDeltaHeight)

        local function createFunc(index)
            local item = rankItemCell.new()
            return item:create({
                itemData = self.m_rankList[rankType][index + 1],
                index = index + 1,
            })
        end

        local function refreshFunc(cell, index)
            cell:refresh({
                itemData = self.m_rankList[rankType][index + 1],
                index = index + 1,
                })
        end

        local function _numFunc()
            return #self.m_rankList[rankType]
        end

        self.m_tableView[rankType] = require("game.utility.TableViewExt").new({
            size        = listViewSize,
            direction   = kCCScrollViewDirectionVertical,
            createFunc  = createFunc,
            refreshFunc = refreshFunc,
            numFunc     = _numFunc,
            cellSize    = rankItemCellSize,
        })
        self.m_infoList:addChild(self.m_tableView[rankType])
    end
end

function GoldBoxRankView:onNewRefresh(tbl, rankIndex)
    if table.isNilOrEmpty(tbl) then
        return
    end
    if not tbl.local_ref or not tbl.global_ref or not tbl.end_time then
        return
    end

    self.m_time1 = tbl.end_time
    self.m_time2 = tbl.local_ref
    self.m_time3 = tbl.global_ref    

    if tbl.hide and tonumber(tbl.hide) == 1 then
        isHideName = true
    else
        isHideName = false
    end
    if isHideName then
        self.txt_hideName:setString(getLang("140495"))
    else
        self.txt_hideName:setString(getLang("140478"))
    end

    -- 整理下数据结构
    self.m_rankList = {}
    self.m_rankList[1] = tbl.rankLocal or {}
    self.m_rankList[2] = tbl.rankGlobal or {}

    if rankIndex == 2 then
        self:initDataTable(1)
    elseif rankIndex == 3 then
        self:initDataTable(2)
    end

    if self.m_nowRankIndex == 1 then
        self.m_rankShowTitle:setString("")
    elseif self.m_nowRankIndex == 2 then
        if #tbl.rankLocal > 0 then
            if tbl.myLrank == "-1" then
                self.m_rankShowTitle:setString("Rank:999+")
            else
                self.m_rankShowTitle:setString("Rank:"..tbl.myLrank)
            end
        else
            self.m_rankShowTitle:setString("")
        end
    elseif self.m_nowRankIndex == 3 then
        if #tbl.rankGlobal > 0 then
            if tbl.myGRank == "-1" then
                self.m_rankShowTitle:setString("Rank:999+")
            else
                self.m_rankShowTitle:setString("Rank:"..tbl.myGRank)
            end
        else
            self.m_rankShowTitle:setString("")
        end
    end
end

function GoldBoxRankView:onClickRankBtn1(  )    
    self.m_rankTitle:setString(getLang("140485"))
    self.m_rankTitle:setPositionX(self.titlePositionX-10)
    self.m_infoList:setContentSize(cc.size(self.m_infoList:getContentSize().width, infoListContentSizeHeight ))
    self.m_rankBtn1:setEnabled(false)
    self.m_rankBtn2:setEnabled(true)
    self.m_rankBtn3:setEnabled(true)
    self.txt_rankBtn1:setColor(self.m_colorDark)
    self.txt_rankBtn2:setColor(self.m_colorLight)
    self.txt_rankBtn3:setColor(self.m_colorLight)
    -- self.scrollView3:setPositionX(0)
    self.scrollView3:setVisible(true)

    for i = 1, 2 do
        if self.m_tableView[i] then
            self.m_tableView[i]:setVisible(false)
        end
    end
    self.m_nowRankIndex = 1
    if self.m_time1 ~= nil then
        self.m_deltTime = tonumber(self.m_time1) - tonumber(LuaController:call("getTimeStamp"))
        self:update(nil)
    end

    self.m_textTitle1:setString(getLang(""))
    self.m_textTitle2:setString(getLang(""))
    self.node_hideNameBtn:setVisible(false)
    self.node_rankTitle2:setVisible(false)
    self.m_rankShowTitle:setString("")
end
function GoldBoxRankView:onClickRankBtn2(  )
    self.m_rankTitle:setString(getLang("133073"))
    -- self.m_infoList:setPositionY(infoListPosY - infoListContentDeltaHeight)
    self.m_rankTitle:setPositionX(self.titlePositionX)
    self.m_infoList:setContentSize(cc.size(self.m_infoList:getContentSize().width,infoListContentSizeHeight - infoListContentDeltaHeight))
    self.m_rankBtn1:setEnabled(true)
    self.m_rankBtn2:setEnabled(false)
    self.m_rankBtn3:setEnabled(true)
    self.txt_rankBtn1:setColor(self.m_colorLight)
    self.txt_rankBtn2:setColor(self.m_colorDark)
    self.txt_rankBtn3:setColor(self.m_colorLight)
    -- self.scrollView3:setPositionX(9999)
    self.scrollView3:setVisible(false)

    self.m_nowRankIndex = 2
    if self.m_time2 ~= nil then
        self.m_deltTime = tonumber(self.m_time2) - tonumber(LuaController:call("getTimeStamp"))
        self:update(nil)
    end
    self.m_textTitle1:setString(getLang("140351"))
    self.m_textTitle2:setString(getLang("165223"))
    self.node_hideNameBtn:setVisible(true)
    self.node_rankTitle2:setVisible(true)
    -- self:onRefresh(self.rankDataList,false)
    self:onNewRefresh(self.rankDataList, 2)

    if self.m_tableView[1] then
        self.m_tableView[1]:setVisible(true)
    end
    if self.m_tableView[2] then
        self.m_tableView[2]:setVisible(false)
    end
end
function GoldBoxRankView:onClickRankBtn3(  )
    self.m_rankTitle:setString(getLang("133073"))
    self.m_rankTitle:setPositionX(self.titlePositionX)
    self.m_infoList:setContentSize(cc.size(self.m_infoList:getContentSize().width,infoListContentSizeHeight - infoListContentDeltaHeight))
    
    self.m_rankBtn1:setEnabled(true)
    self.m_rankBtn2:setEnabled(true)
    self.m_rankBtn3:setEnabled(false)
    self.txt_rankBtn1:setColor(self.m_colorLight)
    self.txt_rankBtn2:setColor(self.m_colorLight)
    self.txt_rankBtn3:setColor(self.m_colorDark)
    -- self.scrollView3:setPositionX(9999)
    self.scrollView3:setVisible(false)
    self.m_nowRankIndex = 3
    self.m_textTitle1:setString(getLang("140351"))
    self.m_textTitle2:setString(getLang("165223"))
    if self.m_time3 ~= nil then
        self.m_deltTime = tonumber(self.m_time3) - tonumber(LuaController:call("getTimeStamp"))
    end
    self.node_hideNameBtn:setVisible(true)
    self.node_rankTitle2:setVisible(true)
    -- self:onRefresh(self.rankDataList,false)
    self:onNewRefresh(self.rankDataList, 3)

    if self.m_tableView[1] then
        self.m_tableView[1]:setVisible(false)
    end
    if self.m_tableView[2] then
        self.m_tableView[2]:setVisible(true)
    end
end

function GoldBoxRankView:onclickHide(  )
    local cmd = GoldBoxRankHideCmd:create()
    cmd:send()
end
return GoldBoxRankView







