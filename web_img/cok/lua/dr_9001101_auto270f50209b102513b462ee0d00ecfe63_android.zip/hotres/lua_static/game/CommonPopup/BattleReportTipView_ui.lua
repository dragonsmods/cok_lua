----------------------------
-- Author: Elex
-- Date: 2019-10-08 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local BattleReportTipView_ui = class("BattleReportTipView_ui")

--#ui propertys


--#function
function BattleReportTipView_ui:create(owner, viewType, paramTable)
	local ret = BattleReportTipView_ui.new()
	CustomUtility:LoadUi("BattleReportTipView.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function BattleReportTipView_ui:initLang()
end

function BattleReportTipView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function BattleReportTipView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function BattleReportTipView_ui:onClickBtnMail(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnMail", pSender, event)
end

function BattleReportTipView_ui:onClickBtnClose(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnClose", pSender, event)
end

return BattleReportTipView_ui

