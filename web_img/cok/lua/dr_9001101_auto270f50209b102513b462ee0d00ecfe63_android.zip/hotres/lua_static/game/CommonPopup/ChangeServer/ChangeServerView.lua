local ChangeServerView = class("ChangeServerView",
    function()
        return PopupBaseView:create()
    end
)
ChangeServerView.__index = ChangeServerView

local ServerCellNumOneLine = 3

-------------------------------------------- ServerListCell Start --------------------------------------------
local ServerListCell = class("ServerListCell", function()
    return CCTableViewCell:new()
end)
local ServerListCellSize = CCSize(640, 100)
function ServerListCell:create(param)
	--初始化界面
	local  proxy = cc.CCBProxy:create()
	local ccbiURL = ""
	ccbiURL = "ccbi/Lua_ChangeServerCell.ccbi"
  	self.m_bIsPad = m_bIsPad
  	local nodeccb = CCBReaderLoad(ccbiURL,proxy, self)
	if nodeccb == nil then
		print("ActivityBankView loadccb error")
		return false
	end
	self:setContentSize(ServerListCellSize)
	self:addChild(nodeccb)
	nodeccb:setPosition(cc.p(ServerListCellSize.width*0.5, ServerListCellSize.height*0.5))

	self.callBack = param.callBack

	local touchLayer = cc.Layer:create()
	touchLayer:setContentSize(cc.size(640,90))
	self:addChild(touchLayer)

	local function touchHandle( eventType, x, y )
		print("touchHandle", eventType, x, y)
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		
		else
			self:onTouchEnded(x, y)
		end
	end
	touchLayer:registerScriptTouchHandler(touchHandle)
	touchLayer:setTouchEnabled(true)
	touchLayer:setSwallowsTouches(false)

	for i = 1, 3 do
		self["m_hightNode"..i]:setVisible(false)
	end

	self:refresh(param)
    return self
end

function ServerListCell:refresh(param)
	self.itemData = param.itemData   --领取状态
	self.idx = param.idx
	-- dump(self.itemData, " ServerListCell ~~~~~~~~~~ itemData is: ")

	for i = 1, 3 do
		local serverInfo = self.itemData[i]
		if serverInfo then
			self["m_head"..i]:setVisible(true)
			self["m_serverName"..i]:setString(serverInfo.name)--.." #" .. serverInfo.id
			
			self["m_hightNode"..i]:setVisible(false)
			if nil ~= serverInfo.state then
				if tonumber(serverInfo.state) == 1 then
					self["m_serverId"..i]:setString(getLang("153591"))
					self["m_serverId"..i]:setColor(cc.c3b(255,255,255))
				elseif tonumber(serverInfo.state) == 2 then
					self["m_serverId"..i]:setString(getLang("153592"))
					self["m_serverId"..i]:setColor(cc.c3b(0,255,0))
				elseif tonumber(serverInfo.state) == 3 then
					self["m_serverId"..i]:setString(getLang("153593"))
					self["m_serverId"..i]:setColor(cc.c3b(255,47,22))
				else
					self["m_serverName"..i]:setString(serverInfo.name)
					self["m_serverId"..i]:setString("#"..serverInfo.id)
				end
			end

			if serverInfo.assign ~= nil then
				if serverInfo.assign == false then
					self["m_serverId"..i]:setColor(cc.c3b(147, 147, 147))
					self["m_serverName"..i]:setColor(cc.c3b(147, 147, 147))
				end
			end
		else
			self["m_head"..i]:setVisible(false)
		end
	end
end

function ServerListCell:onTouchBegan(x,y)
	local index
	for index = 1, 3, 1 do
		if isTouchInside(self["m_cellSprite"..index],x,y) then
			self.touchIndex = index
			return true
		end
	end
	return false
	
end

function ServerListCell:onTouchEnded(x,y)
	if self.touchIndex then
		if self["m_cellSprite"..self.touchIndex]:isVisible(true) and isTouchInside(self["m_cellSprite"..self.touchIndex],x,y) then
			self:onClickCell(self.touchIndex)
		end	
	end
end

function ServerListCell:onClickCell(index)
	local serverInfo = self.itemData[index]
	if serverInfo then
		if serverInfo.assign ~= nil and serverInfo.assign == false then return end
		-- 自身点亮
		self:setBtnHight(index, true)
		-- 告知tableview点亮了哪个
		self.callBack(self.idx, index)
	end
end

function ServerListCell:setBtnHight(index, hightLight)
	local spr = self["m_cellSprite"..index]
	if spr then
		self["m_hightNode"..index]:setVisible(hightLight)
	end
end

--153590=目标服务器转入人数已到上限，无法进行转服
-------------------------------------------- ServerListCell End --------------------------------------------

local itemDataId = 211094
function ChangeServerView:create(param)
	local view = ChangeServerView.new()
	if view:initView(param) == false then
		return nil
	end
  	return view
end

function ChangeServerView:ctor()
	self.ctrl = require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance()
end

function ChangeServerView:initView(param)
	if self:init(true, 0) == false then
		print("ChangeServerView init error")
    	return false
	end

	dump(param or "ChangeServerView  param is nil ~~~~~")
	-- self.libaoItemId = param.libaoItemId
	-- self.libaoDesc = param.libaoDesc
	self:setHDPanelFlag(true)
    self:setTitleName(getLang("153550"))
    -- self:initBtnsFunc()
	callItSelfCallFunc(LuaController, "doResourceByCommonIndex", 6, true)
	callItSelfCallFunc(LuaController, "doResourceByCommonIndex", 7, true)
	callItSelfCallFunc(LuaController, "doResourceByCommonIndex", 11, true)

	local m_bIsPad = CCCommonUtilsForLua:isIosAndroidPad()
	local  proxy = cc.CCBProxy:create()
	local ccbiURL = ""

	ccbiURL = "ccbi/Lua_ChangeServerView.ccbi"
  	self.m_bIsPad = m_bIsPad
  	local nodeccb = CCBReaderLoad(ccbiURL,proxy, self)
	if nodeccb == nil then
		print("ChangeServerView loadccb error")
		return false
	end
	self:addChild(nodeccb)
	local winSize = cc.Director:getInstance():getIFWinSize()
	local dh = 0
	if m_bIsPad then
		nodeccb:setScale(2.4)
		-- self.winSize = CCSize()
		self:setContentSize(winSize)
		nodeccb:setPosition((winSize.width-640)*0.5, (winSize.height-852)*0.5)
  		nodeccb:setAnchorPoint(0.5, 0.5)
	else
		self:setContentSize(nodeccb:getContentSize())
		local preHeight = self.m_buildBG:getContentSize().height
        self:changeBGHeight(self.m_buildBG)
        dh = self.m_buildBG:getContentSize().height - preHeight
        local newSize = CCSize(self.m_infoList:getContentSize().width, self.m_infoList:getContentSize().height + dh)
        self.m_infoList:setContentSize(newSize)

        local infoListSize = self.m_ruleList:getContentSize()
        infoListSize.height = infoListSize.height + dh
        dump("dh is: "..dh.." and m_ruleList height is: "..infoListSize.height)
        self.m_ruleList:setContentSize(infoListSize)
        -- self.m_ruleList:setPositionY(self.m_ruleList)
	end

	local spriteHeight = 852*0.5 + 29 + dh
	addWrapSprite(self.bg_nodeCenter, "technology_09.png", spriteHeight)

	self.ccbNode = nodeccb
	local function onNodeEvent(event)
		dump("enter event ~~~~~~~"..event)
		if event == "enter" then
			self:onEnter()
		elseif event == "exit" then
			self:onExit()
		end
	end
  	self.ccbNode:registerScriptHandler(onNodeEvent)

    -- self:registerTouchFuncs()
	self.m_isInit = true
	self.kingdomMap = {}
	self.serverItemMap = {}
    self.m_contryListTitle:setString(getLang("153558"))
	self.m_itemNeed:setString(getLang("153555"))
	self.m_searchNode:setVisible(false)

    self.m_btnCost:setEnabled(self.libaoItemId ~= "")
	self.m_btnCost:setVisible(false)

	-- CCCommonUtilsForLua:setButtonTitle(self.m_btnCost, self.libaoDesc)
	self:initGoldItem()
	self.m_downBtnLabel:setString(getLang("153560"))
		-- dump(" ~~~~~~~~ ChangeServerView:init() ~~~~~~~~~~~~ 11111111111")

	local touchLayer = cc.Layer:create()
	self:addChild(touchLayer)

	local function touchHandle( eventType, x, y )
		print("touchHandle", eventType, x, y)
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		
		else
			self:onTouchEnded(x, y)
		end
	end
	touchLayer:registerScriptTouchHandler(touchHandle)
	touchLayer:setTouchEnabled(true)
	touchLayer:setSwallowsTouches(false)

	self.m_iconNode:removeAllChildren(true)
	CCCommonUtilsForLua:createGoodsIcon(itemDataId, self.m_iconNode, CCSize(100, 100))
	self.m_iconNode:removeChildByTag(GOODS_BG_TAG)

	self.recruits = {}
	self.newVersionSwitch = CCCommonUtilsForLua:isFunOpenByKey("transfer_enroll")
	self.m_applyTimeTxt:setVisible(false)
	self.m_applyStateTxt:setVisible(false)
	self.m_applyNode:setVisible(false)
	self.m_applyBtnNode:setVisible(false)
	self.m_finalRankBtn:setVisible(false)
	self.m_applyTipNode:setVisible(false)
	self.m_itemNode:setVisible(true)

	if self.newVersionSwitch then self.m_confirmBtn2:setEnabled(false) end

	self:initConditionNode()
	self:initDialogNode()
	self:initLimitNode()

    -- local function callBack(data)
    --     self:getTransferData(data)
    -- end
    self.ctrl:getInfo(callBack)

    return true
end

function ChangeServerView:initConditionNode()
    local x, y = self.m_conditionTxt:getPosition()
    local anchor = self.m_conditionTxt:getAnchorPoint()
    local parent = self.m_conditionTxt:getParent()

	local hyperText = "<s 18><c 84e9aaff><h " .. getLang("153594") .. "@1>"
	local pLabel = IFHyperlinkText:call("create", hyperText, cc.size(300,0), true)
    pLabel:setAnchorPoint(anchor)
    pLabel:setPosition(x, y)
    parent:addChild(pLabel)
	
	local function onRegisterHyper() self:onClickCondition() end
    local handlerSetHyperlink = self:registerHandler(onRegisterHyper)
    pLabel:call("SetHyperlinkTextClickLuaCallback", handlerSetHyperlink)
end

function ChangeServerView:initLimitNode()
	local x, y = self.m_limitTxt:getPosition()
    local anchor = self.m_limitTxt:getAnchorPoint()
    local parent = self.m_limitTxt:getParent()

	local hyperText = "<s 18><c 84e9aaff><h " .. getLang("173349", "") .. "@1>"
	local pLabel = IFHyperlinkText:call("create", hyperText, cc.size(300,0), true)
    pLabel:setAnchorPoint(anchor)
    pLabel:setPosition(x, y)
    parent:addChild(pLabel)
	
	local function onRegisterHyper() self:onClickLimit() end
    local handlerSetHyperlink = self:registerHandler(onRegisterHyper)
    pLabel:call("SetHyperlinkTextClickLuaCallback", handlerSetHyperlink)
end

function ChangeServerView:initDialogNode()
	self.m_dialogNode:removeAllChildren()

	self.scrollView = cc.ScrollView:create()
    self.viewSize = self.m_dialogNode:getContentSize()
    self.scrollView:setViewSize(self.viewSize)
    self.scrollView:setPosition(cc.p(0,0))
    self.scrollView:setScale(1.0)
    self.scrollView:ignoreAnchorPointForPosition(true)
    self.scrollView:setDirection(1)
    self.scrollView:setClippingToBounds(true)
    self.scrollView:setBounceable(true)

    self.m_dialogNode:addChild(self.scrollView)

    self.msgLabel = cc.Label:createWithSystemFont("", "Helvetica", 20, cc.size(self.viewSize.width,0)) 
    self.msgLabel:setColor(cc.c3b(132, 233, 170))
	self.msgLabel:setAnchorPoint(cc.p(0, 0))
	self.msgLabel:setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    self.scrollView:addChild(self.msgLabel)
end

function ChangeServerView:adaptMsg()
    local msgHeight = self.msgLabel:getContentSize().height
    if msgHeight <= self.viewSize.height then
        self.scrollView:setTouchEnabled(false)
    else
        self.scrollView:setTouchEnabled(true)
    end
    self.scrollView:setContentSize(CCSize(self.viewSize.width, msgHeight))
    self.scrollView:setContentOffset(ccp(0, self.viewSize.height - msgHeight))
end

function ChangeServerView:initGoldItem()
	self.libaoItemId, goldItem = LiBaoController.getInstance():getGoldExchangeItemIdByShowType(3)
	if self.libaoItemId ~= "" and goldItem.bought then
		self.libaoItemId = ""
	end

	if self.libaoItemId ~= "" then
		local item = LiBaoController.getInstance():getGoldExchangeItemById(self.libaoItemId)
		if item then
			local dollar = item.dollar
			local product_id = item.product_id
			
			local label = LuaController:call("getDollarString", dollar, product_id)
			self.m_btnCost:setEnabled(true)
			CCCommonUtilsForLua:setButtonTitle(self.m_btnCost, label)
		else
			self.m_btnCost:setEnabled(false)
			self:update()
		end
	end
end

function ChangeServerView:initServerListContent()
	if not self.serverListData or #self.serverListData <= 0 then
		return
	end
	local viewSize = self.m_ruleList:getContentSize()
	viewSize.height = viewSize.height - 100

	local function createFunc(index)
        local item = ServerListCell.new()
        return item:create({
            viewSize = viewSize,
            itemData = self.serverListData[index+1],
            idx = index+1,
            callBack = function(tblIndex, btnIndex) self:selectServerId(tblIndex, btnIndex) end
        })
    end

    local function refreshFunc(cell, index)
        cell:refresh({
        	itemData = self.serverListData[index+1],
        	idx = index+1,
        	})
    end

	self._tableviewList = require("game.utility.TableViewExt").new({
        size        = viewSize,
        direction   = kCCScrollViewDirectionVertical,
        createFunc  = createFunc,
        refreshFunc = refreshFunc,
        cellNum     = #self.serverListData,
        cellSize    = ServerListCellSize,
        -- _scrollFunc = function() self.recordListTime = 3 end
    })
	dump(" create self._tableviewList nums is: "..#self.serverListData)
    self.m_ruleList:addChild(self._tableviewList)

    local cell = self._tableviewList:cellAtIndex(0)
    cell:onClickCell(1)

    local maxHeight = #self.serverListData * ServerListCellSize.height
    if maxHeight < viewSize.height then
    	self._tableviewList:setTouchEnabled(false)
    end
    self._tableviewList:setBounceable(false)
    -- self:selectServerId(1, 1)
end

-- function ChangeServerView:initItemData()

-- 	local itemInfo = ToolController:call("getToolInfoByIdForLua", itemDataId)
-- 	-- self.curItemNum = tonumber(itemInfo:call("getCNT"))
-- 	self.curItemNum = itemInfo:comFunc("getCNT", 0):getValue()
-- 	self.m_itemUuid = itemInfo:comFunc("getUuid", 0):getCString()
-- 	-- dump(" initItemData m_itemNum is: "..self.curItemNum.." m_itemUuid is: "..self.m_itemUuid)
-- 	self.m_itemNum:setString(self.curItemNum.."/"..self.data.cost)
-- 	if self.curItemNum < self.data.cost then
-- 		self.m_itemNum:setColor(cc.c3b(255, 20, 20))
-- 	else
-- 		self.m_itemNum:setColor(cc.c3b(255, 241, 36))
-- 	end
-- end

function ChangeServerView:updateItemData()
	self.isInCdTime = false

	local function showTime()
		if self.isActivityOpen then
			self.m_timeTips:setString(getLang("154143"))--距离本次关闭
			local nextTime = self.ActEndTime - GlobalData:call("getTimeStamp")
			self.m_cdTimeLbl:setString(format_time(nextTime))
			if not self.newVersionSwitch then
				self.m_confirmBtn2:setEnabled(true)
			end
		else
			self.m_timeTips:setString(getLang("154142"))--距离下次开放
			local nextTime = self.nextStTime - GlobalData:call("getTimeStamp")
			self.m_cdTimeLbl:setString(format_time(nextTime))
			self.m_confirmBtn2:setEnabled(false)
		end
	end
	if self.data.times > 0 then
		local offsetTime = self.data.cd - GlobalData:call("getTimeStamp")
		--在转服cd时间内 > 转服活动开启结束时间
		if offsetTime > 0 then
			self.isInCdTime = true
			self.m_cdTimeLbl:setVisible(true)
			-- self.m_cdTimeBg:setVisible(true)
			self.m_timeTips:setString(getLang("153599"))
			self.m_cdTimeLbl:setString(format_time(offsetTime))
			self.m_cdTimeLbl:setColor(cc.c3b(255, 20, 20))
			self.m_confirmBtn2:setEnabled(false)

		else
			self.data.times = 0
			self.data.limit = 0
			-- self.m_cdTimeLbl:setVisible(false)
			-- self.m_cdTimeBg:setVisible(false)
			showTime()
		end
	else
		showTime()
		-- self.m_cdTimeLbl:setVisible(false)
		-- self.m_cdTimeBg:setVisible(false)
	end

	local itemInfo = ToolController:call("getToolInfoByIdForLua", itemDataId)
	-- self.curItemNum = tonumber(itemInfo:call("getCNT"))
	self.curItemNum = itemInfo:comFunc("getCNT", 0):getValue()
	self.m_itemUuid = itemInfo:comFunc("getUuid", 0):getCString()
	-- dump(" initItemData m_itemNum is: "..self.curItemNum.." m_itemUuid is: "..self.m_itemUuid)
	if self.data.cost == nil then self.data.cost = 0 end
	self.m_itemNum:setString(self.curItemNum.."/"..self.data.cost)
	if self.curItemNum < self.data.cost then
		self.m_itemNum:setColor(cc.c3b(255, 20, 20))
	else
		self.m_itemNum:setColor(cc.c3b(255, 241, 36))
	end
end

function ChangeServerView:getServerItem(param)
	local tbl = dictToLuaTable(param)
	if tbl and tbl.cost then
		self.serverItemMap[tostring(tbl.infoDic.serverId)] = atoi(tbl.cost)
		self.data.cost = atoi(tbl.cost)
		self:updateItemData()
	end
end

function ChangeServerView:search(param)
	if param then
		local kingdom = param:getCString()
		if self.kingdomMap[kingdom] then
			local index = self.kingdomMap[kingdom]
			Dprint("kingdomMap index", index)
			local row = math.ceil(index / ServerCellNumOneLine)
			local cow = index % 3
			if cow == 0 then cow = 3 end
			
			local minOffset = self._tableviewList:minContainerOffset()
			self._tableviewList:setContentOffset(ccp(minOffset.x, minOffset.y + (row - 1) * ServerListCellSize.height))
			self:selectServerId(row, cow)
		else
			LuaController:call("flyHint", "", "", getLang("153507"))
		end
	end
end

function ChangeServerView:onEnter()
	self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:update(dt) end, 1, false)

	local function onPaySuccess( ref )
		-- 购买成功
		dump(" ~~~~~~~~~~~~~~ on onPaySuccess ref  is: "..tostring(ref))
		--self:initItemData()
		self:updateItemData()
    end
    local t = tolua.cast(self, "cc.Node")
    local handler = t:registerHandler(onPaySuccess)
	CCSafeNotificationCenter:registerScriptObserver(self, handler, PAYMENT_COMMAND_RETURN)
	registerScriptObserver(self, self.getServerItem, "ChangeServerView:getServerItem")
	registerScriptObserver(self, self.search, "ChangeServerView:search")
	registerScriptObserver(self, self.getTransferData, "ChangeServerView:getTransferData")
end

function ChangeServerView:onExit()
	self:getScheduler():unscheduleScriptEntry(self.m_entryId)
	CCSafeNotificationCenter:unregisterScriptObserver(self, PAYMENT_COMMAND_RETURN)
	unregisterScriptObserver(self, "ChangeServerView:getServerItem")
	unregisterScriptObserver(self, "ChangeServerView:search")
	unregisterScriptObserver(self, "ChangeServerView:getTransferData")
end

function ChangeServerView:onTouchBegan(x, y)
	-- dump("ChangeServerView onTouchBegan ~~~~~~~~~~~~~~")
	if isTouchInside(self.m_addIcon, x, y) then
		self.startTouchPoint = ccp(x, y)
		return true
	end

	return false
end

function ChangeServerView:onTouchMoved(x, y)
	-- dump("ChangeServerView onTouchMoved ~~~~~~~~~~~~~~")
end

function ChangeServerView:onTouchEnded(x, y)
	-- dump("ChangeServerView onTouchEnded ~~~~~~~~~~~~~~")
	if ccpDistance(self.startTouchPoint, ccp(x, y)) > 20 then return end 
	if isTouchInsideVis(self.m_addIcon, x, y) then
		local ItemGetMethodView = Drequire("game.CommonPopup.ItemGetMethodView")
		local view = ItemGetMethodView:create(itemDataId)
		PopupViewController:addPopupView(view)
	end
end

function ChangeServerView:onCostClick()
	dump(" ChangeServerView:onConfirmClick1 ~~~~~~~~~~~")
	LuaController:call("callPayment", self.libaoItemId)
end

function ChangeServerView:onConfirmClick2()
	-- dump(" ChangeServerView:onConfirmClick2 ~~~~~~~~~~~")
	--
	if not self.serverListTblIndex or not self.serverListBtnIndex then
		return
	end
	--改：爆满可以准服请求
	-- if tonumber(self.data.state) == 3 then
	-- 	YesNoDialog:show(getLang("153590"))
	-- 	return
	-- end
	local param = {}
	param.cost = self.data.cost
	param.cdCondition = self.isInCdTime
	local serverId = self.serverListData[self.serverListTblIndex][self.serverListBtnIndex].id
	local serverName = self.serverListData[self.serverListTblIndex][self.serverListBtnIndex].name
	param.serverId = serverId
	param.targetServerName = serverName.."#"..serverId
	local view = Drequire("game.CommonPopup.ChangeServer.ChangeServerConditions"):create(param)
	PopupViewController:addPopupView(view)

	-- if not self.serverListTblIndex or not self.serverListBtnIndex then
	-- 	return
	-- end
	-- --迁服cd
	-- if self.data.cd and (self.data.cd > GlobalData:call("getTimeStamp")) then
	-- 	CCCommonUtilsForLua:call("flyHint", "", "", getLang("153574"))
	-- 	return
	-- end
	-- --道具不足
	-- if self.curItemNum < self.data.cost then
	-- 	require("game.CommonPopup.ItemGetMethodView")
	-- 	local view = ItemGetMethodView:create(itemDataId)
	-- 	PopupViewController:addPopupView(view)
	-- 	return
	-- end


	-- local function confirmFunc()
	-- 	local function changeServer() self:startChangeServer() end
	-- 	local function faqTip() self:onTipBtnClick() end
	-- 	local noTxt = getLang("153571")

	-- 	local view = WarningView:call("create", getLang("105261"), getLang("153570"), cc.CallFunc:create(changeServer), "", cc.CallFunc:create(faqTip), getLang("153571"))
	-- 	view:call("exchangeBtnPos")
	-- 	PopupViewController:addPopupView(view)
	-- end

	-- local itemInfo = ToolController:call("getToolInfoByIdForLua", itemDataId)
	-- local name = itemInfo:call("getName")
	-- local count = atoi(self.serverListData[self.serverListTblIndex][self.serverListBtnIndex].cost)
	-- local serverId = self.serverListData[self.serverListTblIndex][self.serverListBtnIndex].id
	-- local serverName = self.serverListData[self.serverListTblIndex][self.serverListBtnIndex].name
	-- local targetServer = serverName .. "#" .. serverId
	-- YesNoDialog:show(getLang("153569", tostring(count), name, targetServer), confirmFunc)
end

function ChangeServerView:startChangeServer()
	-- 开始转服
	local function callBack (data)
		dump(data, " onConfirmClick2 ~~~~~******************")
		--self.m_confirmBtn2:setEnabled(true)
		if nil ~= data.errorCode and data.errorCode ~= "" then
			-- dump(self.name.. " create errorCode...")
			local param = ""
			if data.errorCode == "E100316" then
				param = getLang(CCCommonUtilsForLua:call("getPropByIdGroup", "goods", data.itemId, "name"))
			elseif data.errorCode == "153581" then
				param = CC_CMDITOA(data.mailNum)
			end
			LuaController:flyHint("", "", getLang(data.errorCode, param))
			return
		end

		local serverInfo = data.serverInfo
		local ip = serverInfo.ip
		local zone = serverInfo.zone
		local port = serverInfo.port
		local gameUid = serverInfo.uid
		
	    local infoDict = CCDictionary:create()
	    infoDict:setObject(CCString:create(ip), tostring("ip"))
	    infoDict:setObject(CCString:create(zone), tostring("zone"))
	    infoDict:setObject(CCInteger:create(port), tostring("port"))

	    local dict = CCDictionary:create()
	    dict:setObject(infoDict, tostring("serverInfo"))
	    dict:setObject(CCBool:create(false), tostring("showBG"))
	    ActivityController:call("changeServerByInfo", dict)
	    --PopupViewController:comFunc("removeAllPopupView",0)
	end

	local serverId = self.serverListData[self.serverListTblIndex][self.serverListBtnIndex].id
	self.ctrl:transfer(serverId, self.m_itemUuid, callBack)
	-- callBack()

	self.m_confirmBtn2:setEnabled(false)
end

function ChangeServerView:update(dt)
	if self.m_isInit then return end

	self:updateItemData()

	if self.libaoItemId == "" then
		self._dayEndTime = GlobalData:comFunc("shared",0):getProperty("tomorrow_time")
		local curTime = GlobalData:call("getTimeStamp")
		if self._dayEndTime < curTime then
			self._dayEndTime = self._dayEndTime + 86400
		end

		local txt = format_time(self._dayEndTime - curTime)
		CCCommonUtilsForLua:setButtonTitle(self.m_btnCost, txt)
		self.m_btnCost:setEnabled(false)
	else
		self.m_btnCost:setEnabled(true)
	end

	if self.newVersionSwitch then
		local now = GlobalData:call("getTimeStamp")
		self.m_confirmBtn2:setEnabled(false)
		if self.ctrl.applyState == 0 then
			self.m_applyStateTxt:setString(getLang("173326"))
			self.m_applyStateTxt:setColor(cc.c3b(255, 35, 35))
			self.m_applyBtnTxt:setString(getLang("173338"))
			self.m_applyBtnTimeTxt:setString("")
			if self.ctrl.applyCd > now then
				local remian = self.ctrl.applyCd - now
				self.m_applyBtnTimeTxt:setString(format_time(remian))
				self.m_applyBtnTxt:setPositionY(105)
				self.m_applyBtnTimeTxt:setPositionY(75)
			else
				self.m_applyBtnTxt:setPositionY(90)
			end
		elseif self.ctrl.applyState == 1 then
			self.m_applyStateTxt:setString(getLang("173327")) 
			self.m_applyStateTxt:setColor(cc.c3b(236, 220, 170))
			self.m_applyBtnTxt:setString(getLang("173339"))
			self.m_applyBtnTimeTxt:setString("")
			self.m_applyBtnTxt:setPositionY(90)
		elseif self.ctrl.applyState == 2 then
			self.m_applyStateTxt:setString(getLang("173330", self.ctrl.applyServer))
			self.m_applyStateTxt:setColor(cc.c3b(61, 164, 198))
			self.m_confirmBtn2:setEnabled(true)
			self.m_searchNode:setVisible(false)
		elseif self.ctrl.applyState == 3 then
			self.m_applyBtnTxt:setString(getLang("173338"))
			self.m_applyBtnTxt:setPositionY(90)
			self.m_applyBtnTimeTxt:setString("")
			self.m_applyStateTxt:setString(getLang("173328"))
			self.m_applyStateTxt:setColor(cc.c3b(61, 164, 198))
			self.m_finalRankBtn:setVisible(false)
			self.m_confirmBtn2:setPositionY(58)
			self.m_confirmBtn2:setEnabled(true)
		elseif self.ctrl.applyState == 4 then
			self.m_applyStateTxt:setString(getLang("173329"))
			self.m_applyStateTxt:setColor(cc.c3b(255, 35, 35))
			self.m_confirmBtn2:setEnabled(false)
		end

		if self.ctrl.applyServer ~= 0 then
			local serverStr = "\n" .. getLang("173348", self.ctrl.applyServer)
			local limitStr = "\n" .. getLang("173349", self.ctrl.applyLimit)
			self.msgLabel:setString(serverStr .. "\n" .. limitStr)
			-- self.msgLabel:setFontSize(22)
		else
			self.msgLabel:setString(getLang("173324"))
			-- self.msgLabel:setFontSize(18)
		end
		self:adaptMsg()

		if self.ctrl:isTransferApply() then
			local remain = self.ctrl.applyEt - now
			self.m_itemNeed:setString(getLang("173321", format_time(remain)))
			self.m_rankBtn:setEnabled(true)	
			self.m_applyBtn:setEnabled(true)
		elseif self.ctrl:isTransferConfirm() then
			local remain = self.ctrl.applyCt - now
			self.m_itemNeed:setString(getLang("173322", format_time(remain)))
			self.m_applyStateTxt:setString(getLang("173345"))
			self.m_rankBtn:setEnabled(false)
			self.m_applyBtn:setEnabled(false)
			if remain == 0 then self:notifyClose() end
		elseif self.ctrl:isTransferFly() then
			local remain = self.ctrl.flyEndTime - now
			self.m_itemNeed:setString(getLang("173323", format_time(remain)))

			if self.ctrl.applyState == 0 then
				self.m_applyStateTxt:setString(getLang("173359"))
				self.m_applyStateTxt:setColor(cc.c3b(255, 35, 35))
				self.m_confirmBtn2:setPositionY(58)
				self.m_confirmBtn2:setEnabled(false)
			end
		else
			self.m_confirmBtn2:setEnabled(false)
		end
	end
end

function ChangeServerView:getTransferData(param)
	-- dump(data, " ~~~~~~~~~~ ChangeServerView:getTransferData ~~~~~~~~~~~~~")
	local data = dictToLuaTable(param)
	
	self.data = {}
	self.data.cd = tonumber(data.cd)
	self.data.limit = tonumber(data.limit)
	self.data.times = tonumber(data.times)
	-- self.data.cost = tonumber(data.cost)
	self.serverListData = {}
	self.isActivityOpen = false
	local ActStartTime = data.nextStartTime
	self.ActEndTime = data.endTime
	if nil == ActStartTime and nil ~= self.ActEndTime then
		self.isActivityOpen = true
		self.endTime = tonumber(self.ActEndTime)
	else
		self.isActivityOpen = false
		self.nextStTime = tonumber(ActStartTime)
	end
	self.m_searchNode:setVisible(true)
	
	self:resortServer(data.servers)

	self.kingdomMap = {}
	for index, data in ipairs(data.servers or {}) do
		self.kingdomMap[data.id] = index
	end
	-- for key, serverInfo in pairs(data.servers) do
	-- 	self.serverListData[key] = serverInfo
	-- end

	-- self.serverListData = {}
	local key = 1
	-- 此处的-1-2-3需要跟ServerCellNumOneLine值关联
	while data.servers[key*ServerCellNumOneLine-2] do
		self.serverListData[#self.serverListData + 1] = {
			data.servers[key*ServerCellNumOneLine-2],
			data.servers[key*ServerCellNumOneLine-1],
			data.servers[key*ServerCellNumOneLine],
		}
		key = key + 1
	end

	dump(self.serverListData)

	--默认是第一个服的道具消费数量
	if data.servers[1] then
		self.data.state = atoi(data.servers[1].state)
		self.ctrl:getServerItem(atoi(data.servers[1].id))
	end

	if #data.servers == 0 then
		self.m_tipsLabel:setString(getLang("301180"))
	else
		self.m_tipsLabel:setString("")
	end

	self.m_isInit = false

	--招募通知
	if self.newVersionSwitch then
		-- self.recruits = data.recruits or {}

		-- -- for index = 1, 20 do
		-- -- 	table.insert(self.recruits, {
		-- -- 		serverId = math.random(1, 2000),
		-- -- 		name = tostring(index) .. "alli",
		-- -- 		abbr = tostring(index) .. "abbr",
		-- -- 		rank = math.random(1, 1000),
		-- -- 	})
		-- -- end

		-- self.m_tableView:reloadData()
		-- self.times = 0
		-- self.random = math.random(1, 4)
	end

	--self:initItemData()
	--self:updateItemData()

	self:initServerListContent()
	self:initApplyNode()
end

function ChangeServerView:resortServer(servers)
	if self.newVersionSwitch then
		local isTransferFly = self.ctrl:isTransferFly()
		if self.ctrl.applyServer ~= 0 and self.ctrl.applyState == 2 then
			local rmIndex = -1
			for index, server in ipairs(servers or {}) do
				if isTransferFly then
					servers[index].assign = false
				end

				if atoi(server.id) == self.ctrl.applyServer then
					rmIndex = index
					if  isTransferFly then
						servers[index].assign = true
					end
				end
			end

			if rmIndex > 0 then
				local applyServer = table.remove(servers, rmIndex)
				table.insert(servers, 1, applyServer)
			end
		end
	end
end

function ChangeServerView:initApplyNode()
	if self.newVersionSwitch then
		self.m_nextNode:setVisible(false)
		self.m_applyTimeTxt:setVisible(true)
		self.m_applyStateTxt:setVisible(true)
		self.m_applyTipNode:setVisible(true)
		if self.ctrl:isTransferApply() then
			self.m_applyNode:setVisible(true)
			self.m_applyBtnNode:setVisible(true)
			self.m_finalRankBtn:setVisible(false)
			self.m_itemNode:setVisible(false)
			self.m_itemNeed:setVisible(true)
			self.m_confirmBtn2:setVisible(false)
		elseif self.ctrl:isTransferConfirm() then
			self.m_applyNode:setVisible(true)
			self.m_applyBtnNode:setVisible(true)
			self.m_finalRankBtn:setVisible(false)
			self.m_itemNode:setVisible(false)
			self.m_itemNeed:setVisible(true)
			self.m_confirmBtn2:setVisible(false)
		elseif self.ctrl:isTransferFly() then
			self.m_applyNode:setVisible(false)
			self.m_applyBtnNode:setVisible(false)
			self.m_finalRankBtn:setVisible(self.ctrl.applyState ~= 0)
			self.m_itemNode:setVisible(true)
			self.m_itemNeed:setVisible(true)
		end

		CCCommonUtilsForLua:setButtonTitle(self.m_rankBtn, getLang("173325"))
		CCCommonUtilsForLua:setButtonTitle(self.m_finalRankBtn, getLang("173335"))
		self:update()
	end
end

function ChangeServerView:notifyClose()
	PopupViewController:call("goBackPopupView")
	YesNoDialog:show(getLang("173340"))
end

function ChangeServerView:setBtnHight(hight)
	if self.serverListTblIndex and self.serverListBtnIndex then
		local cell = self._tableviewList:cellAtIndex(self.serverListTblIndex-1)
		if cell then
			cell:setBtnHight(self.serverListBtnIndex, hight)
		end
	end
end

function ChangeServerView:selectServerId(tblIndex, btnIndex)
	--置灰之前选中的
	self:setBtnHight(false)

	self.serverListTblIndex = tblIndex 
	self.serverListBtnIndex = btnIndex
	
	--高亮现在选的
	self:setBtnHight(true)

	--self.data.cost = atoi(self.serverListData[self.serverListTblIndex][self.serverListBtnIndex].cost)
	self.data.state = atoi(self.serverListData[self.serverListTblIndex][self.serverListBtnIndex].state)

	local serverId = self.serverListData[self.serverListTblIndex][self.serverListBtnIndex].id
	if self.serverItemMap[tostring(serverId)] then
		self.data.cost = atoi(self.serverItemMap[tostring(serverId)])
		self:updateItemData()
	else
		self.ctrl:getServerItem(serverId)
	end
	--self:updateItemData()
end

function ChangeServerView:onTipBtnClick()
	FaqHelper:call("showSingleFAQ", "45281")
end

function ChangeServerView:onSearchBtnClick()
	local view = Drequire("game.CommonPopup.ChangeServer.ChangeServerSearchView"):create()
	PopupViewController:addPopupView(view)
end

function ChangeServerView:onApplyTipClick()
	local view = Drequire("game.FestivalActivities.FestivalActivitiesExplainView"):create(getLang("173347"))
	PopupViewController:addPopupView(view)
end

function ChangeServerView:onClickRank()
	local serverId = self.serverListData[self.serverListTblIndex][self.serverListBtnIndex].id
	local view = Drequire("game.CommonPopup.ChangeServer.ApplyRankView"):create(serverId)
	PopupViewController:addPopupInView(view)
end

function ChangeServerView:onClickFinal()
	local view = Drequire("game.CommonPopup.ChangeServer.ApplyRankView"):create(self.ctrl.applyServer)
	PopupViewController:addPopupInView(view)
end

function ChangeServerView:onClickApply()
	if self.ctrl:isTransferApply() then
		local now = GlobalData:call("getTimeStamp")
		local serverId = self.serverListData[self.serverListTblIndex][self.serverListBtnIndex].id
		
		if self.ctrl.applyState == 0 then
			local applyCd = self.ctrl.applyCd
			if now < applyCd then
				CCCommonUtilsForLua:call("flyHint", "", "", getLang("173337"))
				return
			end
			
			self.ctrl:apply(serverId)
			self.canCancelTime = now + 20
		elseif self.ctrl.applyState == 1 then
			if self.canCancelTime then
				if now < self.canCancelTime then
					CCCommonUtilsForLua:call("flyHint", "", "", getLang("173344"))
					return
				end
			end

			local confirm = function() self.ctrl:applyCancel() end
			YesNoDialog:show(getLang("173336"), confirm)
		elseif self.ctrl.applyState == 3 then
			CCCommonUtilsForLua:call("flyHint", "", "", getLang("173328"))
		end
	end
end

function ChangeServerView:onClickCondition()
	if isCrossServerNow() then
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("115869"))
	else
		local selfServerId = GlobalData:call("getPlayerInfo"):getProperty("selfServerId")
		Dprint("selfServerId", selfServerId)
		local param = {}
		param.confirm = true
		param.serverId = selfServerId
		param.targetServerName = ""
		local view = Drequire("game.CommonPopup.ChangeServer.ChangeServerConditions"):create(param)
		PopupViewController:addPopupView(view)
	end
end

function ChangeServerView:onClickLimit()
	if isCrossServerNow() then
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("115869"))
	else
		local areaView = Drequire("game.CommonPopup.ChangeServer.ChangeServerLimitView").new()
    	PopupViewController:addPopupView(areaView)
	end
end

return ChangeServerView







