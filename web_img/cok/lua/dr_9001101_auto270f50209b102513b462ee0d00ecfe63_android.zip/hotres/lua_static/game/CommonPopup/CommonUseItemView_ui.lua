----------------------------
-- Author: Elex
-- Date: 2018-11-29 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CommonUseItemView_ui = class("CommonUseItemView_ui")

--#ui propertys


--#function
function CommonUseItemView_ui:create(owner, viewType, paramTable)
	local ret = CommonUseItemView_ui.new()
	CustomUtility:LoadUi("CommonUseItemView.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function CommonUseItemView_ui:initLang()
end

function CommonUseItemView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CommonUseItemView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CommonUseItemView_ui:onCloseBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onCloseBtnClick", pSender, event)
end

function CommonUseItemView_ui:initTableView()
	TableViewSmoker:createView(self, "m_listView", "game.CommonPopup.CommonUseItemCell", 1, 4, "CommonUseItemCell")
end

function CommonUseItemView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return CommonUseItemView_ui

