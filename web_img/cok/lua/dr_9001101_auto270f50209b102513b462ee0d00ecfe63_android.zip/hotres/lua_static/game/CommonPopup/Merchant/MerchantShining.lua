--@author: mm
--@date: 2016-11-16

--pre dec
--local print = print
local loprint = function(...)
    -- print(...)
end
-- local math = math
-- local CCLoadSprite = CCLoadSprite
-- local ParticleController = ParticleController

--enum
local ligthEffectType =
{
    NONE = 0,
    LOTTERY = 1,
    MERCHANT = 2,
}

--class
local MerchantShining = class("MerchantShining",
    function()
        return cc.Node:create()
    end
)

-- MerchantShining.__index = MerchantShining


--fields
MerchantShining.mTopSprite = nil --CCSprite
MerchantShining.mBottomSprite = nil --CCSprite
MerchantShining.mTopSprite1 = nil --CCSprite
MerchantShining.mBottomSprite1 = nil --CCSprite
MerchantShining.mEffSprite = nil --ButtonLightEffect
MerchantShining.mEffSprite1 = nil --CCParticleSystemQuad
MerchantShining.m_startPlay = false
MerchantShining.m_fAlpha = 0.0


--functions
function MerchantShining:create(color, size, shiningtype) --color/size/int
    local view = MerchantShining.new()
    if view:initView(color, size, shiningtype) == false then
        return nil
    end
    return view
end

function MerchantShining:initView(color, size, shiningtype)
    if not self:init() then
        return false
    end

    CCLoadSprite:call("doResourceByCommonIndex", 102, true)

    -- setCleanFunction([](){
    --     CCLoadSprite::doResourceByCommonIndex(102, false);
    -- });

    self.mBottomSprite = CCLoadSprite:call("createSprite", "TravelBusiness.png") --sprite
    self.mBottomSprite:setAnchorPoint(cc.p(0.5, 0))
    local orgSize = self.mBottomSprite:getContentSize() --ccsize
    local fScaleX = size.width / orgSize.width
    local fScaleY = size.height * 0.5 / orgSize.height
    self.mBottomSprite:setScaleX(fScaleX)
    self.mBottomSprite:setScaleY(-fScaleY)
    self:addChild(self.mBottomSprite)
    self.mBottomSprite:setPositionY(0)
    
    self.mBottomSprite1 = CCLoadSprite:call("createSprite", "TravelBusiness.png")
    self.mBottomSprite1:setAnchorPoint(cc.p(0.5, 0))
    self.mBottomSprite1:setScaleX(fScaleX)
    self.mBottomSprite1:setScaleY(-fScaleY)
    self:addChild(self.mBottomSprite1)
    self.mBottomSprite1:setPositionY(0)
    
    self.mTopSprite = CCLoadSprite:call("createSprite", "TravelBusiness.png")
    self.mTopSprite:setAnchorPoint(cc.p(0.5, 0))
    self.mTopSprite:setScaleX(fScaleX)
    self.mTopSprite:setScaleY(fScaleY)
    self:addChild(self.mTopSprite)
    self.mTopSprite:setPositionY(0)
    
    self.mTopSprite1 = CCLoadSprite:call("createSprite", "TravelBusiness.png")
    self.mTopSprite1:setAnchorPoint(cc.p(0.5, 0))
    self.mTopSprite1:setScaleX(fScaleX)
    self.mTopSprite1:setScaleY(fScaleY)
    self:addChild(self.mTopSprite1)
    self.mTopSprite1:setPositionY(0)
    
    self.mBottomSprite:setColor(color)
    self.mTopSprite:setColor(color)
    self.mBottomSprite1:setColor(color)
    self.mTopSprite1:setColor(color)

    local cbf1 = cc.blendFunc(1, 1) --GL_ONE, can't find
    self.mTopSprite:setBlendFunc(cbf1)
    self.mBottomSprite:setBlendFunc(cbf1)
    
-- //        CCSpriteFrame *pEffFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("ButtonLight_1.png");
-- //        pEffFrame->getTexture()->setAntiAliasTexParameters();
    local effSize = size
    if (shiningtype == 1) then
        effSize.width = 2 * effSize.width
    end
-- //        effSize.height += 20;
    math.randomseed(tostring(os.time()):reverse():sub(1, 6))
    local delayT = math.random(2, 5)

    self.mEffSprite = ButtonLightEffect:call("create", effSize, color, false, delayT, ligthEffectType.MERCHANT)

    -- local esNode = tolua.cast(self.mEffSprite, "cc.Node")
    loprint("self.mEffSprite=", self.mEffSprite, ", effSize=(", effSize.width, ",", effSize.height, ", color=", color, ", delayT=", delayT)

    -- esNode:setScaleX(1)
    self.mEffSprite:setScaleX(20)

    if (shiningtype == 1) then
        -- esNode:setVisible(false)
        self.mEffSprite:setVisible(false)
    end

    self:addChild(self.mEffSprite)
    -- self:addChild(esNode)
    self.mEffSprite:call("setBlendFunc", cbf1)
    self.m_startPlay = true
-- //        m_maxEffDelay = CCMathUtils::getRandomInt(50, 80);
-- //        m_curEffDelay = m_maxEffDelay;
-- //        m_playEff = true;
    return true
end

function MerchantShining:setShineColor(color) --color3b
    self.mBottomSprite:setColor(color)
    self.mTopSprite:setColor(color)
    self.mBottomSprite1:setColor(color)
    self.mTopSprite1:setColor(color)
    self.mEffSprite:call("setEffColor", color)
end

function MerchantShining:setShineAlpha(alpha) --int
    self.mBottomSprite:setOpacity(alpha)
    self.mTopSprite:setOpacity(alpha)
    self.mBottomSprite1:setOpacity(alpha)
    self.mTopSprite1:setOpacity(alpha)
    self.m_fAlpha = alpha
end

function MerchantShining:showEff2(show, scale) --bool/float
    scale = scale or 1
    loprint("MerchantShining:showEff2, show=", show, ", scale=", scale, ", btnEffect=", self.mEffSprite, ", particle=", self.mEffSprite1)
    if (self.mEffSprite1 ~= nil) then
        self.mEffSprite1:removeFromParent()
        self.mEffSprite1 = nil
    end

    if (show) then
        self.mEffSprite1 = ParticleController:call("createParticle", "TravelBusiness") --or createParticle ?
        -- self.mEffSprite1 = tolua.cast(self.mEffSprite1, "cc.ParticleSystemQuad")
        self:addChild(self.mEffSprite1)
        local size = self.mTopSprite:getContentSize()
        self.mEffSprite1:setPositionY(size.height + 20 * scale)
        self.mEffSprite1:setScale(scale)
        self.mEffSprite1:resume() --deprecated resumeSchedulerAndActions()
    end
end

function MerchantShining:startPlay(play) --bool
    if (self.m_startPlay and not play) then
        self.mEffSprite:call("stopEffect")
-- //        this->unschedule(schedule_selector(MerchantShining::playFrame));
        self.m_startPlay=false
    elseif (not self.m_startPlay and play) then
        self.mEffSprite:call("playEffect")
-- //        this->schedule(schedule_selector(MerchantShining::playFrame), 0.07);
        self.m_startPlay=true
    end
end

return MerchantShining