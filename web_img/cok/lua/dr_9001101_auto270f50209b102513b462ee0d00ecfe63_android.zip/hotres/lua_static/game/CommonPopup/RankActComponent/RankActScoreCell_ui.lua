----------------------------
-- Author: Elex
-- Date: 2020-04-17 Friday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local RankActScoreCell_ui = class("RankActScoreCell_ui")

--#ui propertys


--#function
function RankActScoreCell_ui:create(owner, viewType, paramTable)
	local ret = RankActScoreCell_ui.new()
	CustomUtility:DoRes(0, true)
	CustomUtility:LoadUi("RankActScoreCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function RankActScoreCell_ui:initLang()
	LabelSmoker:setText(self.m_labelCurOver, "176075")
	LabelSmoker:setText(self.m_labelTotalOver, "176075")
end

function RankActScoreCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function RankActScoreCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function RankActScoreCell_ui:onClickBtnCalendar(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnCalendar", pSender, event)
end

return RankActScoreCell_ui

