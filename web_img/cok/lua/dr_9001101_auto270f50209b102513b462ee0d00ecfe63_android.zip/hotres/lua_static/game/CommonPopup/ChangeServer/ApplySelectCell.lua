local ApplySelectCell = class("ApplySelectCell", cc.TableViewCell)

local gridSize = cc.size(184, 68)
local bgSize = cc.size(150, 56)

function ApplySelectCell:create()
   local ret = ApplySelectCell.new()
   ret:init()
   return ret 
end

function ApplySelectCell:ctor()

end

function ApplySelectCell:init()
    self:setContentSize(gridSize)

    self.bg = CCLoadSprite:call("createScale9Sprite", "BG_danse01.png")
    self.bg:setContentSize(bgSize)
    self.bg:setPosition((gridSize.width - bgSize.width) / 2, (gridSize.height - bgSize.height) / 2)
    self.bg:setAnchorPoint(ccp(0, 0))
    self.bg:ignoreAnchorPointForPosition(false)
    self:addChild(self.bg)

    self.selectSp = CCLoadSprite:call("createScale9Sprite", "DEC_biaotihongguang.png")
    self.selectSp:setContentSize(bgSize)
    self.selectSp:setPosition((gridSize.width - bgSize.width) / 2, (gridSize.height - bgSize.height) / 2)
    self.selectSp:setAnchorPoint(ccp(0, 0))
    self.selectSp:ignoreAnchorPointForPosition(false)
    self:addChild(self.selectSp)
    self.selectSp:setVisible(false)

    self.text = CCLabelIF:call("create")
    self.text:call("setFontSize", 18)
    self.text:call("setColor", cc.c3b(184, 172, 132))
    self.text:setPosition(gridSize.width / 2, gridSize.height / 2)
    self:addChild(self.text)

    local touchLayer = cc.Layer:create()
	self:addChild(touchLayer)

	local function touchHandle( eventType, x, y )
		print("touchHandle", eventType, x, y)
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		
		else
			self:onTouchEnded(x, y)
		end
	end
	touchLayer:registerScriptTouchHandler(touchHandle)
	touchLayer:setTouchEnabled(true)
    touchLayer:setSwallowsTouches(false)
    
    registerNodeEventHandler(self)
end

function ApplySelectCell:refreshCell(info)
    self.info = info
    self.text:call("setString", info.text)
    self:option()    
end

function ApplySelectCell:onTouchBegan(x, y)
    if self.bg:isVisible() and isTouchInside(self.info.view, x, y) and isTouchInside(self.bg, x, y) then
        self.startPoint = ccp(x, y)
        return true
    end
end

function ApplySelectCell:onTouchEnded(x, y)
    local distance = ccpDistance(self.startPoint, ccp(x, y))
    if distance > 10 then return end
    local passer = CCDictionary:create()
    passer:setObject(CCString:create(tostring(self.info.text)), "text")
    passer:setObject(CCString:create(tostring(self.info.id)), "id")
    CCSafeNotificationCenter:postNotification("changerServer.select", passer)
end

function ApplySelectCell:onEnter()
    local function callback1(param) self:option(param) end
	local handler1 = self:registerHandler(callback1)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "changerServer.option")
end

function ApplySelectCell:onExit()
    CCSafeNotificationCenter:unregisterScriptObserver(self, "changerServer.option")
end

function ApplySelectCell:option()
    local beSelected = self.info.selectCb(self.info.text)
    self.selectSp:setVisible(beSelected)
end

return ApplySelectCell