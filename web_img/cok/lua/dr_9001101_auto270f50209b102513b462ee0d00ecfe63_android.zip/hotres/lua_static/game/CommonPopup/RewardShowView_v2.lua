RewardShowView_v2 = class("RewardShowView_v2", function (  )
	return PopupBaseView:call("create")
end)
RewardShowCell_v2 = class("RewardShowCell_v2", function (  )
	return cc.TableViewCell:create()
end)


function RewardShowView_v2.create( data, title, frameId )
	local ret = RewardShowView_v2.new(data, title, frameId)
	if ret:initSelf() == false then
		ret = nil
	end
	return ret
end

function RewardShowView_v2:ctor( data, title ,frameId)
	self.data = data
	self.titlestr = title
	self.frameId = frameId or ""
end

function RewardShowView_v2:initSelf(  )
	MyPrint("RewardShowView_v2:initSelf")
	if self:init(true, 0) == false then
		MyPrint("RewardShowView_v2 init error")
    	return false	
	end
	self:setHDPanelFlag(true)

	local winsize = cc.Director:getInstance():getIFWinSize()

	self:setContentSize(winsize)

	local proxy = cc.CCBProxy:create()
    local ccbiUrl = "RewardShowView_v2"
	local node = CCBReaderLoad(ccbiUrl, proxy, self)
    self:addChild(node)

    if CCCommonUtilsForLua:call("isIosAndroidPad") then
    	self.m_mainNode:setScale(2)
    end
    if nil == self.data then
    	return false
    end
    dump(self.data, "self.data")


    if self.frameId ~= "" then 
	    self.m_listNode:setContentSize(cc.size(540, 500))
	    self.m_headFrameNode:setVisible(true)
	    local name = CCCommonUtilsForLua:getPropById(self.frameId, "name")
	    self.m_headFraneDesLabel:setString(getLang(name))
	    local utils = cc.FileUtils:getInstance()
		local wpath = utils:getWritablePath()
		local dpath = wpath .. "dresource/"

		local json = ""
		if CCCommonUtilsForLua:getPropById(self.frameId, "frame") == "gold" then 
			json = "Spine/other/jin.json"
		elseif CCCommonUtilsForLua:getPropById(self.frameId, "frame") == "silver" then 
			json = "Spine/other/yin.json"
		elseif CCCommonUtilsForLua:getPropById(self.frameId, "frame") == "bronze" then 
			json = "Spine/other/tong.json"
		end
		local atlas = dpath .. "sk_TouXiangKuang_face.atlas"
		local aniName = "animation"
		if cc.FileUtils:getInstance():isFileExist(json) == true and cc.FileUtils:getInstance():isFileExist(atlas) == true then 
			local frameAni = IFSkeletonAnimation:call("create", json, atlas)
			if frameAni then 
				self.m_headFrameAniNode:addChild(frameAni)
				frameAni:setAnimation(0, tostring(aniName), true)
			end
		end
	   local iconStr = CCCommonUtilsForLua:getPropById(self.frameId, "icon") .. ".png"
	   local iconSpr = CCLoadSprite:createSprite(iconStr)
	   iconSpr:setPositionY(-40)
	   self.m_headFrameAniNode:addChild(iconSpr)

	end



    self.m_tableView = cc.TableView:create(self.m_listNode:getContentSize())
	self.m_listNode:addChild(self.m_tableView)
	self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
	self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
	self.m_tableView:setDelegate()
	local function scrollViewDidScroll( view )
		return self:scrollViewDidScroll(view)
	end

	local function cellSizeForTable( view, idx )
		return self:cellSizeForTable(view, idx)
	end

	local function tableCellAtIndex( view, idx )
		return self:tableCellAtIndex(view, idx)
	end

	local function numberOfCellsInTableView( view )
		return self:numberOfCellsInTableView(view)
	end

	self.m_tableView:registerScriptHandler(scrollViewDidScroll,cc.SCROLLVIEW_SCRIPT_SCROLL)
	self.m_tableView:registerScriptHandler(cellSizeForTable,cc.TABLECELL_SIZE_FOR_INDEX)
	self.m_tableView:registerScriptHandler(tableCellAtIndex,cc.TABLECELL_SIZE_AT_INDEX)
	self.m_tableView:registerScriptHandler(numberOfCellsInTableView,cc.NUMBER_OF_CELLS_IN_TABLEVIEW)

	self.m_tableView:setAnchorPoint(cc.p(0, 0))
	self.m_tableView:reloadData()
	self.m_tableView:setContentOffset(cc.p(0, self.m_listNode:getContentSize().height - self.m_tableView:getContentSize().height))


	self.startTouchPt = cc.p(0, 0)
	self.touchLayer = cc.Layer:create()
	self:addChild(self.touchLayer)
	local function touchHandle( eventType, x, y )
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		else
			self:onTouchEnded(x, y)
		end
	end
	self.touchLayer:registerScriptTouchHandler(touchHandle)
	self.touchLayer:setTouchEnabled(true)
	self.touchLayer:setSwallowsTouches(false)


	self.m_titleLabel:setString(self.titlestr)

    return true
end

function RewardShowView_v2:scrollViewDidScroll( view )
	
end

function RewardShowView_v2:cellSizeForTable( view, idx )
	return 550, 60
end

function RewardShowView_v2:tableCellAtIndex( view, idx )
	idx = idx+1
    if idx > #self.data then
		return nil
    end
    local cell = view:dequeueCell()
    if cell ~= nil then 
		cell:setData(self.data[idx])
    else
        cell = RewardShowCell_v2.new(self.data[idx])
    end
    return cell
end

function RewardShowView_v2:numberOfCellsInTableView( view )
	return #self.data
end

function RewardShowView_v2:onTouchBegan( x, y )
	if isTouchInside(self.m_touchNode, x, y) then
		return false
	end
	return true
end

function RewardShowView_v2:onTouchEnded( x, y )
	if isTouchInside(self.m_touchNode, x, y) then
		return
	end
	self:call("closeSelf")
end

function RewardShowView_v2:onCloseBtnClick(  )
	self:call("closeSelf")
end

function RewardShowCell_v2:ctor( data )
	MyPrint("RewardShowCell_v2:ctor")
	dump(data, "data")
	
	local proxy = cc.CCBProxy:create()
    local ccbiUrl = "RewardShowCell_v2"
	local node = CCBReaderLoad(ccbiUrl, proxy, self)
    self:addChild(node)


    self:setData(data)

end

function RewardShowCell_v2:setData( data )
	MyPrint("RewardShowCell_v2:setData", data)
	dump(data, "data")
	if nil == data then
		return
	end
	self.m_iconNode:removeAllChildren()
	-- self.m_sprChestBg:setVisible(true)
	self.m_nameLabel:setHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
	self.m_nameLabel:setString("")
	self.m_cntLabel:setString("")

	local t = tonumber(data.type)

	-- 只显示label  类型是1000时
	if t == 1000 then
		self.m_nameLabel:setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
		-- self.m_sprChestBg:setVisible(false)
		if nil ~= data.label then
			self.m_nameLabel:setString(data.label)
		end
	elseif t == 7 or t == 14 then
		-- 道具 装备
		local value = data.value
	    if nil ~= value then
	    	local colorstr = CCCommonUtilsForLua:call("getToolBgByColor", tonumber(CCCommonUtilsForLua:call("getPropById", tostring(value.id), "color")) or 0)
	    	local colorSpr = CCLoadSprite:call("createSprite", colorstr)

	    	local icon = CCCommonUtilsForLua:call("getIcon", tostring(value.id))
		    local spr = CCLoadSprite:call("createSprite", icon)
		    spr:setAnchorPoint(cc.p(0.5, 0.5))
		    CCCommonUtilsForLua:call("setSpriteMaxSize", colorSpr, 48, true)
		    CCCommonUtilsForLua:call("setSpriteMaxSize", spr, 48, true)
		    self.m_iconNode:addChild(colorSpr)
		    self.m_iconNode:addChild(spr)
		    local dialog = CCCommonUtilsForLua:call("getPropById", tostring(value.id), "name")
		    self.m_nameLabel:setString(getLang(dialog))
		    if nil ~= value.num then
		    	self.m_cntLabel:setString(tostring(value.num))
		    end
	    end
	end
end