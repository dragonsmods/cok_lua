----------------------------
-- Author: Elex
-- Date: 2019-06-28 Friday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local FirstKillRewardCell_ui = class("FirstKillRewardCell_ui")

--#ui propertys


--#function
function FirstKillRewardCell_ui:create(owner, viewType, paramTable)
	local ret = FirstKillRewardCell_ui.new()
	CustomUtility:LoadUi("FirstKillRewardCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function FirstKillRewardCell_ui:initLang()
end

function FirstKillRewardCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function FirstKillRewardCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return FirstKillRewardCell_ui

