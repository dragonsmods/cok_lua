local PreviewController = class("PreviewController")
local _PreviewController = _PreviewController or nil

--cell主类别,和XML表配置一致
local Cell_Building = "30710001" --建筑建造
local Cell_Soldier = "30710002" --士兵训练
local Cell_Science = "30710003" --科技研究
local Cell_Troop = "30710004" --行军队列
local Cell_Pier = "30710005" --码头装卸
local Cell_Wish = "30710006" --许愿
local Cell_Fort = "30710007" --陷阱
local Cell_Alliance = "30710008" --联盟
local Cell_Monster = "30710009" --年兽
local Cell_Wheel = '30710010' --转盘
local Cell_Wonder = '30710011' --奇迹
local Cell_Srtength = '30710012' --强化
local Cell_ArmyUpgrade = '30710013' --士兵进阶
local Cell_Magic = "30710014" --魔法学院
local Cell_Hero = "30710015" --英雄招募
local Cell_DragonTower = '30710016' --龙
local Cell_Hospital = "30710017" --医院
local Cell_NewSoldier = "30710018" --戒律大厅
--后续新加也需单独处理，保持与表ID一致
--TODO 

--------------------------Command BEGIN---------------------------

--获取转盘，奇迹，强化，士兵进阶，龙塔等的数据
-- 加英雄试炼（stage、maxPassedGroupId、groupId、levelLimit）、龙塔试炼数据（quickBattleMaxLayer、quickBattleCurrentLayer），用于领主辅助
local PreviewGetInfoCmd = class("PreviewGetInfoCmd", LuaCommandBase)
function PreviewGetInfoCmd.create()
    local ret = PreviewGetInfoCmd.new()
    ret:initWithName("overview.data")
    return ret
end

function PreviewGetInfoCmd:handleReceive(dict)
    local tbl = self:parseMsg(dict)
    if type(tbl) == "boolean" then
        return tbl
	end
	if self._callBack then
		self:_callBack(tbl)
	end
	PreviewController.getInstance():getServerCellData(tbl)
    return true
end
----------------------------Command END----------------------------

function PreviewController:ctor ()
	--返回要显示的列表
	self.previewInfoData = {}--key,name,icon,order,cellMeta,edit(str)
	--来自服务器的部分数据
	self.serverDataTbl = {}--服务器给的key-value(str)
	--设施是否显示的列表
	self.previewSelectData={} --key,isVisible(bool)
end

function PreviewController.getInstance ()
	if not _PreviewController then
		_PreviewController = PreviewController.new()
	end
	return _PreviewController
end

--信息刷新
function PreviewController:initInfo()
	self.previewInfoData = {}
	self.serverDataTbl = {}
	self.previewSelectData={}
	self:readXMLTable()
	--向服务器请求数据了
	local cmd = PreviewGetInfoCmd.create()
	cmd:send()
	------------------------------队列类 start-----------------------------
	--建造信息
	local CellInfo = Drequire("game.CommonPopup.OverView.Cell_Info.Cell_Building"):create(Cell_Building)
	self.previewInfoData[Cell_Building] = CellInfo:getCureQueueInfo()

	--士兵训练
	local CellInfo = Drequire("game.CommonPopup.OverView.Cell_Info.Cell_Soldier"):create(Cell_Soldier)
	self.previewInfoData[Cell_Soldier] = CellInfo:getCureQueueInfo()


	--科技研究
	local CellInfo = Drequire("game.CommonPopup.OverView.Cell_Info.Cell_Science"):create(Cell_Science)
	self.previewInfoData[Cell_Science] = CellInfo:getCureQueueInfo()

	--行军队列
	local CellInfo = Drequire("game.CommonPopup.OverView.Cell_Info.Cell_Troop"):create(Cell_Troop)
	self.previewInfoData[Cell_Troop] = CellInfo:getCureQueueInfo()
	

	--医院
	local CellInfo = Drequire("game.CommonPopup.OverView.Cell_Info.Cell_Hospital"):create(Cell_Hospital)
	self.previewInfoData[Cell_Hospital] = CellInfo:getCureQueueInfo()

	--戒律大厅
	local CellInfo = Drequire("game.CommonPopup.OverView.Cell_Info.Cell_NewSoldier"):create(Cell_NewSoldier)
	self.previewInfoData[Cell_NewSoldier] = CellInfo:getCureQueueInfo()
	--陷阱建造
	local CellInfo = Drequire("game.CommonPopup.OverView.Cell_Info.Cell_Fort"):create(Cell_Fort)
	self.previewInfoData[Cell_Fort] = CellInfo:getCureQueueInfo()
	------------------------------队列类 end-----------------------------


	------------------------------非队列类 start-----------------------------
	--码头装卸
	local CellInfo = Drequire("game.CommonPopup.OverView.Cell_Info.Cell_Pier"):create(Cell_Pier)
	self.previewInfoData[Cell_Pier] = CellInfo:getCellDataTbl()
	--许愿
	local CellInfo = Drequire("game.CommonPopup.OverView.Cell_Info.Cell_Wish"):create(Cell_Wish)
	self.previewInfoData[Cell_Wish] = CellInfo:getCellDataTbl()
	--联盟
	local CellInfo = Drequire("game.CommonPopup.OverView.Cell_Info.Cell_Alliance"):create(Cell_Alliance)
	self.previewInfoData[Cell_Alliance] = CellInfo:getCellDataTbl()
	--年兽
	local CellInfo = Drequire("game.CommonPopup.OverView.Cell_Info.Cell_Monster"):create(Cell_Monster)
	self.previewInfoData[Cell_Monster] = CellInfo:getCellDataTbl()
	--魔法屋研习
	local CellInfo = Drequire("game.CommonPopup.OverView.Cell_Info.Cell_Magic"):create(Cell_Magic)
	self.previewInfoData[Cell_Magic] = CellInfo:getCellDataTbl()
	--英雄招募开关 
	local CellInfo = Drequire("game.CommonPopup.OverView.Cell_Info.Cell_Hero"):create(Cell_Hero)
	self.previewInfoData[Cell_Hero] = CellInfo:getCellDataTbl()
	------------------------------非队列类 end-----------------------------
end

--读取xml可设置列表
function PreviewController:readXMLTable()
	self.previewSelectData={} --key,isVisible	
	--总表 canEidt、cellId、id、name、order、unlockLv、visible、icon
	local typeCells = CCCommonUtilsForLua:getGroupByKey("pandectType")
	local cityLv = FunBuildController:call("getMainCityLv")
	for k,v in pairs(typeCells or {}) do
		if v.visible == '1' and v.canEidt == "1" and tonumber(v.unlockLv)<= cityLv then
			self.previewSelectData[k] = {visible=self:getCellkeyVisible(k),local_order = self:getCellkeyOrder(k) ,order = v.order,key = v.id,name = v.name,icon = v.icon}
		end
	end
end

--服务器来数据了
function PreviewController:getServerCellData( tbl )
	self.serverDataTbl = tbl
	
	--尝试添加
	local CellInfo = Drequire("game.CommonPopup.OverView.Cell_Info.Cell_ArmyUpgrade"):create(Cell_ArmyUpgrade)
	self.previewInfoData[Cell_ArmyUpgrade] = CellInfo:getCellDataTbl()

	local CellInfo = Drequire("game.CommonPopup.OverView.Cell_Info.Cell_DragonTower"):create(Cell_DragonTower)
	self.previewInfoData[Cell_DragonTower] = CellInfo:getCellDataTbl()

	local CellInfo = Drequire("game.CommonPopup.OverView.Cell_Info.Cell_Wheel"):create(Cell_Wheel)
	self.previewInfoData[Cell_Wheel] = CellInfo:getCellDataTbl()

	local CellInfo = Drequire("game.CommonPopup.OverView.Cell_Info.Cell_Wonder"):create(Cell_Wonder)
	self.previewInfoData[Cell_Wonder] = CellInfo:getCellDataTbl()

	local CellInfo = Drequire("game.CommonPopup.OverView.Cell_Info.Cell_Srtength"):create(Cell_Srtength)
	self.previewInfoData[Cell_Srtength] = CellInfo:getCellDataTbl()

	--刷新界面
	CCSafeNotificationCenter:postNotification("InformationPreview:refreshView")
	CCSafeNotificationCenter:postNotification("CityAssistView:refreshItems")
end

--获取当前主类别是否显示
function PreviewController:getCellkeyVisible(cellKey)
	local key = "Preview_"..cellKey	
	return cc.UserDefault:getInstance():getBoolForKey(key, true)		
end

--设置当前主类别是否显示
function PreviewController:setCellkeyVisible(cellKey, visible)
	local key = "Preview_"..cellKey	
	cc.UserDefault:getInstance():setBoolForKey(key, visible)
	cc.UserDefault:getInstance():flush()	
end

--设置主类别的顺序<用户编辑后的顺序>
function PreviewController:setCellkeyOrder(cellKey,order)
	local init_order = order
	local key = "Preview_"..cellKey.."_order"
	cc.UserDefault:getInstance():setIntegerForKey(key, init_order)
	cc.UserDefault:getInstance():flush()
end
--读取主类别的编辑顺序
function PreviewController:getCellkeyOrder(cellKey)
	local key = "Preview_"..cellKey.."_order"
	local order = cc.UserDefault:getInstance():getIntegerForKey(key,1)
	return order
end

--保存列表显示信息的变更
function PreviewController:saveCellShowSwitch( )
	local showIds = ""
	for k,v in pairs(self.previewSelectData or {}) do
		self:setCellkeyVisible(k,v.visible)
		self:setCellkeyOrder(k,v.local_order)
		if v.visible == true then			
			showIds = showIds..k..";"		
		end
	end
	local now = getTimeStamp()
	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	local myUid = playerInfo:getProperty("uid")
	self.previewInfoData = {}
	self:initInfo()
end

--重置到策划初始状态
function PreviewController:resetLocalProps()
	local typeCells = CCCommonUtilsForLua:getGroupByKey("pandectType")
	for k,v in pairs(typeCells or {}) do
		self:setCellkeyVisible(k,true)
		self:setCellkeyOrder(k,1)
	end
	self:initInfo()
end

return PreviewController