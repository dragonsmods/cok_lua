--玩家排行TableViewCell
local PlayerCellView = Drequire("game.CommonPopup.commonRank.CommonRankPlayerTblCell")
local CommonRankAllianceTblCell = class("CommonRankAllianceTblCell", PlayerCellView)

function CommonRankAllianceTblCell:create(idx)
    local view = CommonRankAllianceTblCell.new()
    Drequire("game.CommonPopup.commonRank.CommonRankPlayerTblCell_ui"):create(view, 0)
    return view
end

function CommonRankAllianceTblCell:refreshViewByType(info, type)
    if type ~= 1 then
        self.super.refreshViewByType(self, info, type)
    else
        local rankStr = "0"
        if info.data.rank and info.data.rank ~= "" then
            rankStr = info.data.rank
        end
        local showSearch = info.showSearch
        if (tonumber(rankStr) or 0) <= 0 then
            rankStr = getLang("150290")
            showSearch = false
        end
        if not showSearch then
            self.ui.m_rankLabel:setPositionY(0)
            self.ui.m_searchBtn:setVisible(false)
        end

        self.ui.m_rankLabel:setString(rankStr)
        local _score = tonumber(info.data.score) or 0
        self.ui.m_numLabel:setString(CC_CMDITOAL(_score))

        -- 玩家是否隐藏名字
        -- if info.hideKing == "1" or info.data.anonymous_state == 1 then
        if self:isHideKing() then
            self.ui.m_pNameLabel:setString(getLang("9800070")) -- 9800070=联盟信息已隐藏
        else
            local name = string.join("", getLang("102161"), ": (", info.data.abbr or "", ")", info.data.name or "")
            self.ui.m_pNameLabel:setString(name)
        end

        local str = nil

        -- if info.hideKing == "1" or info.data.anonymous_state == 1 then
        if self:isHideKing() then
            str = ""
        else
            str = getLang("138027") .. ": " -- 138027=王国
            if info.data.sid and info.data.sid ~= "" then
                local serverId = resetGreenServerId(info.data.sid)                              
                str = str .. serverId                
            end
        end

        if str then
            self.ui.m_sNumLabel:setString(str)
        end

        self.ui.m_headNode:removeAllChildren()

        local pic = info.data.icon
        self.ui.m_headNode:removeAllChildren()
        if (self:isHideKing() or (not pic) or pic == "") then
            pic = CCLoadSprite:call("createSprite", "Allance_flay.png")
            pic:setScale(0.5)
            self.ui.m_headNode:addChild(pic)
        else
            local mpic = pic .. ".png"
            local flag = AllianceFlagPar:call("create", mpic)
            local flagLayer = tolua.cast(flag, "cc.Layer")
            flagLayer:setScale(0.5)
            self.ui.m_headNode:addChild(flagLayer)
        end
    end
end

function CommonRankAllianceTblCell:onClickPicBtn(pSender, event)
    -- if self.m_info and self.m_info.hideKing == "1" or self.m_info.data.anonymous_state == 1 then
    if self:isHideKing() then
        return
    end
    if self.parent and self.m_info and self.m_info.data and self.parent.openAllianceViewByRankInfo then
        self.parent:openAllianceViewByRankInfo(self.m_info.data)
    end
end

function CommonRankAllianceTblCell:isHideKing()
    local info = self.m_info
    if not info or not info.data then
        return true
    end
    if not info.config or not info.config.getAnonymousOpen or not info.config:getAnonymousOpen() then
        return false
    end
    if not info.isSelf and (info.hideKing == "1" or tonumber(info.data.anonymous_state) == 1) then
        -- if self.m_info and not self.isSelfFixed and (self.m_info.hideKing == "1" or self.m_info.data.anonymous_state == 1) then
        return true
    end
    return false
end

return CommonRankAllianceTblCell
