----------------------------
-- Author: Elex
-- Date: 2017-11-21 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local AuctionHouseInputAckView_ui = class("AuctionHouseInputAckView_ui")

--#ui propertys


--#function
function AuctionHouseInputAckView_ui:create(owner, viewType)
	local ret = AuctionHouseInputAckView_ui.new()
	CustomUtility:LoadUi("AuctionHouseInputAckView.ccbi", ret, owner, true, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function AuctionHouseInputAckView_ui:initLang()
end

function AuctionHouseInputAckView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function AuctionHouseInputAckView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function AuctionHouseInputAckView_ui:onOkBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onOkBtnClick", pSender, event)
end

return AuctionHouseInputAckView_ui

