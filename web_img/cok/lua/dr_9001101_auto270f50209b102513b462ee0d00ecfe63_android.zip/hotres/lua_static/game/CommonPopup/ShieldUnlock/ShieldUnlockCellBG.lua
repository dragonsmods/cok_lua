local ShieldUnlockCellBG = class("ShieldUnlockCellBG", function()
    return cc.Layer:create()
end)

function ShieldUnlockCellBG:create(idx)
    local ret = ShieldUnlockCellBG.new()
    Drequire("game.CommonPopup.ShieldUnlock.ShieldUnlockCellBG_ui"):create(ret)
    return ret
end

function ShieldUnlockCellBG:refreshCell(info , idx)
	self.uuid = info.uuid
	self.uid = info.uid
	self.ui.m_picContainer:removeAllChildren()
  	self.m_headImgNode = HFHeadImgNode:comFunc("create",0)
	local dict = CCDictionary:create()
	local name = info.name
	local picStr = info.picStr
	local power = info.power
	local picVer = info.picVer
	if info.uuid ~=nil then
		if name ~= nil then
			self.ui.m_nameText:setString(name)
		end
		if picStr ~= nil then
			pic = CCLoadSprite:comFunc("createSprite",dict:setObject(CCInteger:create(CCLoadSpriteType_HEAD_ICON),"2"):setObject(CCString:create(picStr),"1"))
			pic:setScale(0.6)
			self.ui.m_picContainer:addChild(pic)
			dict:setObject(CCInteger:create(picVer),"1")
			if CCCommonUtilsForLua:call("isUseCustomPic",dict) == false then
			    dict:setObject(CCString:create(self.uid),"1")
			    dict:setObject(CCInteger:create(picVer), "2")
			    local arg2 = CCCommonUtilsForLua:comFunc("getCustomPicUrl",dict)
			    dump(arg2,"hanxiao arg2 is")
			    dict:setObject(self.ui.m_picContainer,"1")
			    dict:setObject(arg2,"2")
			    dict:setObject(CCFloat:create(1),"3")
			    dict:setObject(CCFloat:create(81),"4")
			    dict:setObject(CCBool:create(true),"5")
			    self.m_headImgNode:comFunc("initHeadImgUrl2",dict)
			end			
		end
		if power ~= nil then
			self.ui.m_power:setString(tostring(power))
		end
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_unBlockBtn, getLang("105315"))
		self.ui.m_unBlockBtn:setEnabled(true)
	end
end
function ShieldUnlockCellBG:onUnBlockClick()
	local uuid = self.uuid
	if uuid ~= nil then
		ChatController:call("setdChatUnLockCommand", uuid)
		local dict = CCDictionary:create()
		dict:setObject(CCString:create(uuid),"uuid")
		CCSafeNotificationCenter:call("postNotification","Shield_onClickUnBlockBtnMessage",dict)
	end
end

return ShieldUnlockCellBG