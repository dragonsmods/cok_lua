----------------------------
-- Author: Elex
-- Date: 2019-03-26 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local RankActPlayerRankTblCell_ui = class("RankActPlayerRankTblCell_ui")

--#ui propertys


--#function
function RankActPlayerRankTblCell_ui:create(owner, viewType, paramTable)
	local ret = RankActPlayerRankTblCell_ui.new()
	CustomUtility:DoRes(11, true)
	CustomUtility:LoadUi("RankActPlayerRankTblCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function RankActPlayerRankTblCell_ui:initLang()
end

function RankActPlayerRankTblCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function RankActPlayerRankTblCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function RankActPlayerRankTblCell_ui:onClickSearchBtn(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickSearchBtn", pSender, event)
end

function RankActPlayerRankTblCell_ui:onClickPicBtn(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickPicBtn", pSender, event)
end

function RankActPlayerRankTblCell_ui:onRewardButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onRewardButtonClick", pSender, event)
end

function RankActPlayerRankTblCell_ui:onMoreButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onMoreButtonClick", pSender, event)
end

return RankActPlayerRankTblCell_ui

