TestView = class("TestView", function (  )
	return PopupBaseView:call("create")
end)

function TestView.create( )
	local ret = TestView.new()
	if ret:initSelf() ~= true then
		ret = nil
	end
	return ret
end

function TestView:initSelf( ... )
	self:init(true, 0)
	self:setHDPanelFlag(true)
    CCLoadSprite:doResourceByCommonIndex(513, true)

	local node = cc.Node:create()

    if CCCommonUtilsForLua:call("isIosAndroidPad") then
    	self:setContentSize(cc.size(1536, 2048))
    	node:setScale(2.4)
    else
		self:setContentSize(cc.size(640, 852))
	end
	node:setPositionX(0)
	node:setPositionY(self:getContentSize().height)

	self:addChild(node)

	local totalH = cc.Director:getInstance():getIFWinSize().height
    local height = 0
	while math.abs(height) < totalH do
    	local spr = CCLoadSprite:call("createSprite", "technology_09.png")
    	spr:setAnchorPoint(cc.p(0, 1))
    	spr:setPositionX(0)
    	spr:setPositionY(height)
    	node:addChild(spr)
    	height = height - spr:getContentSize().height
    end


    node = cc.Node:create()
    node:setPositionX(self:getContentSize().width * 0.5)
    node:setPositionY(self:getContentSize().height * 0.5)
    self:addChild(node)
    self.mainNode = node

    -- node:removeAllChildren()
    -- local spr1 = CCLoadSprite:call("createSprite", "c513_lbv4_gold.png")
    -- local spr2 = CCLoadSprite:call("createSprite", "c513_lbv4_gold.png")
    -- spr2:setScale(0.1)
    -- spr1:addChild(spr2)
    -- spr1:setScale(10)
    -- spr1:runAction(cc.ScaleTo:create(100, 3))
    -- node:addChild(spr1)

    -- local function fun(  )
    --     MyPrint("trigger one")
    -- 	node:removeAllChildren()
	   --  local spr1 = CCLoadSprite:call("createSprite", "c513_lbv4_gold.png")
	   --  local spr2 = CCLoadSprite:call("createSprite", "c513_lbv4_gold.png")
    --     spr1:setAnchorPoint(cc.p(0.5, 0.5))
    --     spr2:setAnchorPoint(cc.p(0.5, 0.5))
	   --  spr2:setScale(0.1)
    --     spr2:setPositionX(spr1:getContentSize().width * 0.5)
    --     spr2:setPositionY(spr1:getContentSize().height * 0.5)
	   --  spr1:addChild(spr2)
	   --  spr1:setScale(10)
	   --  node:addChild(spr1)
	   --  spr1:runAction(cc.ScaleTo:create(3, 100, 100))
    -- end
    
    -- self:runAction(cc.Sequence:create(cc.CallFunc:create(fun), cc.DelayTime:create(3)))
    registerNodeEventHandler(self)

    return true
end

function TestView:onEnter(  )
    -- local function fun(  )
    --     MyPrint("trigger one")
    --     self.mainNode:removeAllChildren()
    --     local spr1 = CCLoadSprite:call("createSprite", "c513_lbv4_gold.png")
    --     local spr2 = CCLoadSprite:call("createSprite", "c513_lbv4_gold.png")
    --     local spr3 = CCLoadSprite:call("createSprite", "c513_lbv4_gold.png")
    --     local spr4 = CCLoadSprite:call("createSprite", "c513_lbv4_gold.png")

    --     spr1:setAnchorPoint(cc.p(0.5, 0.5))
    --     spr2:setAnchorPoint(cc.p(0.5, 0.5))
    --     spr3:setAnchorPoint(cc.p(0.5, 0.5))
    --     spr4:setAnchorPoint(cc.p(0.5, 0.5))


    --     spr2:setScale(0.1)
    --     spr3:setScale(0.1)
    --     spr4:setScale(0.1)

    --     spr2:setPositionX(spr1:getContentSize().width * 0.5)
    --     spr2:setPositionY(spr1:getContentSize().height * 0.5)
    --     spr3:setPositionX(spr2:getContentSize().width * 0.5)
    --     spr3:setPositionY(spr2:getContentSize().height * 0.5)
    --     spr4:setPositionX(spr3:getContentSize().width * 0.5)
    --     spr4:setPositionY(spr3:getContentSize().height * 0.5)
    --     spr1:addChild(spr2)
    --     spr2:addChild(spr3)
    --     spr3:addChild(spr4)
    --     spr1:setScale(100)
    --     self.mainNode:addChild(spr1)
    --     spr1:runAction(cc.ScaleTo:create(3, 1000, 1000))
    -- end
    -- fun()
    -- self.entry = tonumber(self:getScheduler():scheduleScriptFunc(fun, 3, false))


    local spr1 = CCLoadSprite:call("createSprite", "c513_lbv4_gold.png")
    local spr2 = CCLoadSprite:call("createSprite", "c513_lbv4_gold.png")
    local spr3 = CCLoadSprite:call("createSprite", "c513_lbv4_gold.png")
    local spr4 = CCLoadSprite:call("createSprite", "c513_lbv4_gold.png")

    spr1:setAnchorPoint(cc.p(0.5, 0.5))
    spr2:setAnchorPoint(cc.p(0.5, 0.5))
    spr3:setAnchorPoint(cc.p(0.5, 0.5))
    spr4:setAnchorPoint(cc.p(0.5, 0.5))


    spr2:setScale(0.1)
    spr3:setScale(0.1)
    spr4:setScale(0.1)

    spr2:setPositionX(spr1:getContentSize().width * 0.5)
    spr2:setPositionY(spr1:getContentSize().height * 0.5)
    spr3:setPositionX(spr2:getContentSize().width * 0.5)
    spr3:setPositionY(spr2:getContentSize().height * 0.5)
    spr4:setPositionX(spr3:getContentSize().width * 0.5)
    spr4:setPositionY(spr3:getContentSize().height * 0.5)
    spr1:addChild(spr2)
    spr2:addChild(spr3)
    spr3:addChild(spr4)
    spr1:setScale(100)
    self.mainNode:addChild(spr1)

    local function fun(  )
        spr1:stopAllActions()
        spr1:setScale(100)
        spr1:runAction(cc.ScaleTo:create(3, 1000, 1000))
    end
    fun()
    self.entry = tonumber(self:getScheduler():scheduleScriptFunc(fun, 3, false))
end

function TestView:onExit(  )
    self:getScheduler():unscheduleScriptEntry(self.entry)
end