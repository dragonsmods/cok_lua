local MultiSelectDialog = class("MultiSelectDialog",
    function()
        return PopupBaseView:create()
    end
)
MultiSelectDialog.__index = MultiSelectDialog

function MultiSelectDialog:create(params)
    local view = MultiSelectDialog.new()
    Drequire("game.CommonPopup.MultiSelectDialog_ui"):create(view)
    if view:initView(params) then
        return view
    end
    return ret
end

function MultiSelectDialog:initView(params)
    -- dump(params,"MultiSelectDialog:initView+++")
    self.params = params
    self.ui.m_labelInfo:setString(params.info)
    for k,itemInfo in pairs(params.items) do
        self.ui["m_goodsNum"..k]:setString(itemInfo.num)
        if not itemInfo.isGold then
            local iconPic = CCCommonUtilsForLua:getPropByIdGroup("goods",itemInfo.goodsid, "icon")..".png"
            -- dump(iconPic,"iconPic+++")
            local sprSF = CCLoadSprite:call("getSF", iconPic)
            if sprSF then 
                self.ui["m_goodsIcon"..k]:setSpriteFrame(sprSF)
                self.ui["m_goodsIcon"..k]:setScale(0.4)
            end
            if itemInfo.isShowTotalLeft then
                local label = self.ui["m_labelTotalLeft"..k]
                if label then 
                    label:setString(getLang("9500004", getToolCount(itemInfo.goodsid)))
                end
            end
        end
    end
    self:registerTouchFuncs()
    return true
end

function MultiSelectDialog:doAck(index)
    local data = self.params.items[index]
    if data then 
        if not data.isGold then
            local myToolCount = 0
            local tinfo = ToolController:call("getToolInfoForLua", tonumber(data.goodsid))
            if tinfo then
                myToolCount = tinfo:call("getCNT")
            end
            if myToolCount < data.num then 
                CCCommonUtilsForLua:call("flyHint", "", "", getLang("9200725"))
                return 
            end
        end
        local dict = CCDictionary:create() 
        dict:setObject(CCInteger:create(index), 'selectedItemIndex')
        CCSafeNotificationCenter:call("postNotification", self.params.ackMsg, dict)
    end
end

function MultiSelectDialog:onBtnOk1()
    self:doAck(1)
    self:onCloseButtonClick()
end

function MultiSelectDialog:onBtnOk2()
    self:doAck(2)
    self:onCloseButtonClick()
end

function MultiSelectDialog:onCloseButtonClick()
    PopupViewController:call("removePopupView", self)
end

function MultiSelectDialog:onEnter()
    
end

function MultiSelectDialog:onExit()
   
end

function MultiSelectDialog:onTouchBegan(x, y)
    self.touchedInView = true
    return true
end

function MultiSelectDialog:onTouchMoved(x, y)
    self.touchedInView = false
end

function MultiSelectDialog:onTouchEnded(x, y)
    if self.touchedInView and not touchInside(self.ui.m_sprBg, x, y) then 
        self:onCloseButtonClick()
    end
end

return MultiSelectDialog

