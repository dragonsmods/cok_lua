
local AuctionHouseCell = class("AuctionHouseCell", function()
    return cc.Layer:create()
end)

function AuctionHouseCell:create(idx)
    -- dump("AuctionHouseCell:create+++")
    local ret = AuctionHouseCell.new()
    Drequire("game.CommonPopup.AuctionHouse.AuctionHouseCell_ui"):create(ret)
    return ret
end
AuctionHouseCell.__index = AuctionHouseCell


function AuctionHouseCell:refreshCell(info , idx)
    -- dump(info, "AuctionHouseCell:refreshCell+++")
    self.info = info
    self.timeCount = 0
    self.ui.m_pLabelPrice:setString(getLang("176265")) --176265=当前价格
    self.ui.m_pLabelPriceNum:setString(self.info.price)
    self.ui.m_pLabelRaisePrice:setString(getLang("9440883"))
    self.ui.m_pLabelRaisePriceNum:setString(self.info.add)
    self.ui.m_pLabelOnePrice:setString(getLang("176257")) --176257=一口价
    self.ui.m_pLabelOnePriceNum:setString(self.info.decision) 
    self.ui.m_pNodeItemIcon:removeAllChildren()

    CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnTakePrice, getLang("176264"))--176264=竞价
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnRaisePrice, getLang("176257"))
    if self.info.decision == "9999999" then --只可竞价，不让一口价
        self.ui.m_btnRaisePrice:setVisible(false)
    else
        self.ui.m_btnRaisePrice:setVisible(true)
    end

    self.ui.m_pNodeItemIcon:removeAllChildren()
    --reward, iconNode, width, nameLabel, numLabel, nameWithNum, beTouch, touchParentNode)
    local spr = LibaoCommonFunc.createRewardItemInfo(
        {type="7", value={id=tostring(self.info.itemId),num=tostring(self.info.num)} },
         self.ui.m_pNodeItemIcon, 100, nil, nil, true, true, nil)

    self.ui.m_labelNum:setString(CC_CMDITOA(self.info.num))
    local name = CCCommonUtilsForLua:getPropById(tostring(self.info.itemId), "name")
    self.ui.m_pLabelItemName:setString(getLang(name))
    if self.info.selfAuctioned == "0" then 
        self.ui.m_btnRaisePrice:setEnabled(true)
        self.ui.m_btnTakePrice:setEnabled(true)
    else
        self.ui.m_btnRaisePrice:setEnabled(false)
        self.ui.m_btnTakePrice:setEnabled(false)
    end
end

function AuctionHouseCell:onEnter()
    self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:update(dt) end, 1, false)
    self:update(0)
end

function AuctionHouseCell:onExit()
    self:getScheduler():unscheduleScriptEntry(self.m_entryId)
end

function AuctionHouseCell:update(dt)
    local curTime = GlobalData:call("getTimeStamp")
    local endTime = self.info.endTime/1000
    if endTime - curTime >= 0 then 
        local time = format_time( endTime - curTime)
        self.ui.m_pLabelTime:setString(time)
    else
        if self.timeCount and self.timeCount >= 60*3 then
            self.timeCount = 0
        else
            if self.timeCount == 0 then
                dump("time is 00,pull data+++")
                AuctionHouseController:pullAuctionHouseViewData(false)
            end
            self.timeCount = self.timeCount+1
        end
    end
end

function AuctionHouseCell:isAuctionTimeOver(  )
    local curTime = GlobalData:call("getTimeStamp")
    local endTime = self.info.endTime/1000
    if endTime - curTime >= 0 then 
        return false
    end
    return true
end

--一口价
function AuctionHouseCell:onAddPriceClicked()
    -- dump("AuctionHouseCell:onAddPriceClicked+++")
    if self:isAuctionTimeOver() then 
        LuaController:flyHint("", "", getLang("9440925")) 
        return
    end

    local totalGold = GlobalDataCtr.getPlayerGold()+tonumber(AuctionHouseController:getGoldCountInAuction())
    if totalGold < tonumber(self.info.decision) then 
        LuaController:flyHint("", "", getLang("111909")) --金币不足
        return
    end
    
    -- dump(self.info,"cell info+++")
    local function confirmFunc()
        AuctionHouseController:decisionPrice(self.info.uuid, AuctionHouseController:getAnonmous())
    end
    local name = CCCommonUtilsForLua:getPropById(tostring(self.info.itemId), "name")
    local tipInfo = _lang_2("176267", self.info.decision, getLang(name)) --176267=您确定花费{0}金币一口价购买{1}吗？
    local dia = YesNoDialog:show(tipInfo, confirmFunc) 
end

--竞价
function AuctionHouseCell:onGivePriceClicked()
    AuctionHouseController.curAuctionCellInfo = nil
    if self:isAuctionTimeOver() then 
        LuaController:flyHint("", "", getLang("9440925")) 
        return
    end

    local goldInAuction = tonumber(AuctionHouseController:getGoldCountInAuction())  
    local totalGold = goldInAuction + GlobalDataCtr.getPlayerGold()
    local minNum = tonumber(self.info.add) + tonumber(self.info.price)
    local maxNum = totalGold
    if maxNum < minNum then 
        -- dump("not enough gold+++")
        return
    end

    -- 176263=请输入您的竞拍加价！  
    -- 176264=竞价
    AuctionHouseController.curAuctionCellInfo = self.info
    local NewToolNumSelectView = Drequire("game.CommonPopup.NewToolNumSelectView")
    local view = NewToolNumSelectView:create(nil, minNum, maxNum, nil, 5, "176263" , "176264" , nil , AuctionAckGrivePriceNow , nil)
    PopupViewController:addPopupView(view)
end

return AuctionHouseCell



