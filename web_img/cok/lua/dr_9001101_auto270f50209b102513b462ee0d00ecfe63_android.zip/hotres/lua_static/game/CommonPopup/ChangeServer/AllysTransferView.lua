local AllysTransferView = class("AllysTransferView", PopupBaseView)

function AllysTransferView:create(allys)
    local view = AllysTransferView.new(allys)
    Drequire("game.CommonPopup.ChangeServer.AllysTransferView_ui"):create(view, 1)
    if view:initView() then return view end
end

function AllysTransferView:ctor(allys)
    self.allys = allys
end

function AllysTransferView:initView()
    self:setHDPanelFlag(true)

    if CCCommonUtilsForLua:isIosAndroidPad() then
        self.ui.nodeccb:setScale(2.0)
    end

    registerTouchHandler(self)
    self:setTouchEnabled(true)

    self.ui.m_titleLabel:setString(getLang("173314"))
    self.ui:setTableViewDataSource("m_listView", self.allys or {})

    return true
end

function AllysTransferView:onTouchBegan(x, y)
    if not isTouchInsideVis(self.ui.m_bg, x, y) then
        self.touchPoint = ccp(x, y)
        return true
    end
end

function AllysTransferView:onTouchEnded(x, y)
    if ccpDistance(self.touchPoint, ccp(x, y)) > 10 then return end
    self:call("closeSelf")
end

return AllysTransferView