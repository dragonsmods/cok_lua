local ApplyRecordNode = class("ApplyRecordNode", PopupBaseView)

function ApplyRecordNode:create()
    local node = ApplyRecordNode.new()
    Drequire("game.CommonPopup.ChangeServer.ApplyRecordNode_ui"):create(node, 1)
    node:initNode()
    return node
end

function ApplyRecordNode:ctor()
    self.dstServerId = -1
    self.dstServerName = ""
end

function ApplyRecordNode:initNode()
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_transferBtn, getLang("173231"))
    --拉数据
    self:addLoadingAni()
    require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance():getTransferRecord()
    self.ui.m_transferBtn:setEnabled(false)
    self:setScale(1)
    self:call("setModelLayerDisplay", false)
	self:call("setViewSwallowTouch", false)
end

function ApplyRecordNode:updateNode(param)
    self:removeLoadingAni()

    local data = dictToLuaTable(param)
    self.sourceData = data.alliances or {}
    for _, alliance in ipairs(data.alliances) do
        if alliance.state == "2" then
            self.sourceData  = {}
            table.insert(self.sourceData, alliance)
            break
        end
    end
    self.ui:setTableViewDataSource("m_listView", self.sourceData)

    self:checkGoal()
end

function ApplyRecordNode:checkGoal()
    for _, alliance in ipairs(self.sourceData) do
        if alliance.state == "2" then
            self.dstServerId = alliance.serverId
            self.dstServerName = alliance.serverName
        end
    end
end

function ApplyRecordNode:addApplyRecord(alliance)
    self.sourceData = self.sourceData or {}

    local notExist = true

    for _, data in ipairs(self.sourceData) do
        if alliance.allianceId == data.allianceId then
            notExist = false
            break
        end
    end

    if notExist then
        table.insert(self.sourceData, 1, alliance)
        self.refreshOnEnter = true
    end
end

function ApplyRecordNode:addLoadingAni()
	self:removeLoadingAni()

	self.m_loadingIcon = CCLoadSprite:call("createSprite", "loading_1.png")
	self.m_loadingIcon:setAnchorPoint(ccp(0.5, 0.5))

    local size = self.ui.m_listNode:getContentSize()
	self.m_loadingIcon:setPosition(ccp(size.width / 2, size.height / 2))

	local rotateAction = cc.RotateTo:create(0.5, 720)
	local rotateForever = cc.RepeatForever:create(rotateAction)
	self.m_loadingIcon:runAction(rotateForever)
	self.ui.m_listNode:addChild(self.m_loadingIcon, 1000000)
end

function ApplyRecordNode:removeLoadingAni()
	if self.m_loadingIcon then
		self.m_loadingIcon:removeFromParent()
		self.m_loadingIcon = nil
    end
    
    if self.waitInterface then
        self.waitInterface:call("remove")
        self.waitInterface = nil
    end
end

function ApplyRecordNode:onEnterFrame(dt)
    if require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance():isTransferState() then
        if self.dstServerId ~= -1 and self.dstServerName ~= "" then
            self.ui.m_transferBtn:setEnabled(true)
        else
            self.ui.m_transferBtn:setEnabled(false)
        end
    else
        self.ui.m_transferBtn:setEnabled(false)
    end
end

function ApplyRecordNode:onEnter()
    if self.refreshOnEnter then
        self.refreshOnEnter = false
        self.ui:setTableViewDataSource("m_listView", self.sourceData)
    end

    local function callback1(param) self:updateNode(param) end
    local handler1 = self:registerHandler(callback1)
    CCSafeNotificationCenter:registerScriptObserver(self, handler1, "ApplyRecordNode:updateNode")

    self:onEnterFrame(0)
	self.entry = tonumber(self:getScheduler():scheduleScriptFunc(function(dt) self:onEnterFrame(dt) end, 1, false))
end

function ApplyRecordNode:onExit()
    self:getScheduler():unscheduleScriptEntry(self.entry)
    CCSafeNotificationCenter:unregisterScriptObserver(self, "ApplyRecordNode:updateNode") 
end

function ApplyRecordNode:tableCellTouched(tab, cell)
    local detail = cell:getDetail()
    local view = Drequire("game.CommonPopup.ChangeServer.AllianceDetailView"):create(detail)
    PopupViewController:addPopupInView(view)
end

function ApplyRecordNode:onClickBtnTransfer()
    local param = {}
	param.cdCondition = require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance():getCanTransfer()
	local serverId = self.dstServerId
	local serverName = self.dstServerName
	param.serverId = serverId
	param.targetServerName = serverName .. "#" .. serverId
	local view = Drequire("game.CommonPopup.ChangeServer.ChangeServerConditions"):create(param)
	PopupViewController:addPopupView(view)
end

return ApplyRecordNode