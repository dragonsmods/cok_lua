--该类只存放封装好的数据给各个组件用，不与后台交互
--今后各个排行榜活动把自己的数据封装好，传递给该类，按照每个cell的数据插入顺序进行赋值
local RankActDataController = class("RankActDataController")

---------------------------CELL DATA-----------------------
--全服第一CellData
local KingHeadCellData = class("KingHeadCellData")
function KingHeadCellData:create(data)
    local ret = KingHeadCellData.new()
    ret:initData(data)
    return ret
end
function KingHeadCellData:ctor()    
    self.playerName = "playerName"
    self.allianceName = "allianceName"
    self.tipLabel = "tipsLabel"
    self.head_pic = ""
    self.head_picVer = ""
    self.picfraId = ""
    self.playerUid = ""
end
function KingHeadCellData:initData(data)    
    if data then
        dump(data,"hxq headCellData is")
        self.playerName = data.param1 or self.playerName
        self.allianceName = data.param2 or self.allianceName
        self.tipLabel = data.param3 or self.tipLabel
        self.head_pic = data.param4 or self.head_pic
        self.head_picVer = data.param5 or self.head_picVer
        self.picfraId = data.param6 or self.picfraId
        self.playerUid = data.param7 or self.playerUid
    end    
end

--积分获取途径CellData
local MethodCellData = class("MethodCellData")
function MethodCellData:create(data)
    local ret = MethodCellData.new()
    ret:initData(data)
    return ret
end
function MethodCellData:ctor()    
    self.methodSprNames = {}
    self.methodNames = {}
    self.methodPowers = {}
    self.btnLabels = {}
    self.btnDess = {} 
    self.btnJumps = {}   
end
function MethodCellData:initData(data)    
    if data then       
        self.methodSprNames = data.param1 or self.methodSprNames
        self.methodNames = data.param2 or self.methodNames
        self.methodPowers = data.param3 or self.methodPowers
        self.btnLabels = data.param4 or self.btnLabels
        self.btnDess = data.param5 or self.btnDess
        self.btnJumps = data.param6 or self.btnJumps
    end    
end

--全服玩家排行榜CellData
local AllPlayerRankData = class("AllPlayerRankData")
function AllPlayerRankData:create(data)
    local ret = AllPlayerRankData.new()
    ret:initData(data)
    return ret
end

function AllPlayerRankData:initData(data)    
    if data then
        self.playerRankData = data
    end    
end

--本服玩家排行CellData
local LocalPlayerRankData = class("LocalPlayerRankData")
function LocalPlayerRankData:create(data)
    local ret = LocalPlayerRankData.new()
    ret:initData(data)
    return ret
end
function LocalPlayerRankData:initData(data)    
    if data then
        self.playerRankData = data
    end    
end

local AllServerRankData = class("AllServerRankData")
function AllServerRankData:create(data)
    local ret = AllServerRankData.new()
    ret:initData(data)
    return ret
end
function AllServerRankData:initData(data)
    if data then
        self.countryRankData = data        
    end
end


--活动积分CellData
local TotalScoreCellData = class("TotalScoreCellData")
function TotalScoreCellData:create(data)
    local ret = TotalScoreCellData.new()
    ret:initData(data)
    return ret
end
function TotalScoreCellData:ctor()      
    self.todayScoreData = {} --当前积分
    self.totalScoreData = {} --本期积分
    self.curEndTime = 0 -- 当前积分倒计时
    self.totalEndTime = 0 --本期积分倒计时
    self.singleProcess_num = 0
    self.totalProcess_num = 0
end
function TotalScoreCellData:initData(data)    
    if data then
        self.todayScoreData = data.param1 or self.todayScoreData
        self.totalScoreData = data.param2 or self.totalScoreData
        self.curEndTime = data.param3 or self.curEndTime
        self.totalEndTime = data.param4 or self.totalEndTime
        self.singleProcess_num = data.param5 or self.singleProcess_num
        self.totalProcess_num = data.param6 or self.totalProcess_num
        self.processTitle1 = data.processTitle1
        self.processTitle2 = data.processTitle2
    end    
end

--今日活动积分CellData
local TodayScoreCellData = class("TodayScoreCellData")
function TodayScoreCellData:create(data)
    local ret = TodayScoreCellData.new()
    ret:initData(data)
    return ret
end
function TodayScoreCellData:ctor()    
      
end
function TodayScoreCellData:initData(data)    
    if data then
        
    end    
end

--TODO
---------------------------CELL DATA-----------------------

local __instance = nil
function RankActDataController.getInstance(  )
	if nil == __instance then
		__instance = RankActDataController.new()
	end
	return __instance	
end

function RankActDataController:ctor(  )
    self.actId = ""
    self.isOver = 0
    --排行第一玩家信息
    self.kingHeadData = nil
    --积分获取途径
    self.methodData = nil
    --全服玩家排行
    self.allPlayerRankData = nil
    --本服玩家排行
    self.localPlayerRankData = nil
    --服务器排行
    self.allServerRankData = nil
    --活动积分
    self.totalScoreData = nil
end

function RankActDataController:pureData()
    self.actId = ""
    self.isOver = 0
    --排行第一玩家信息
    self.kingHeadData = nil
    --积分获取途径
    self.methodData = nil
    --全服玩家排行
    self.allPlayerRankData = nil
    --本服玩家排行
    self.localPlayerRankData = nil
    --服务器排行
    self.allServerRankData = nil
    --活动积分
    self.totalScoreData = nil
end

--赋值
function RankActDataController:setDataByKey(key,data)    
    if key == "kingHeadData" then
        local ret = KingHeadCellData:create(data)        
        self.kingHeadData = ret
        CCSafeNotificationCenter:call("postNotification", "msg.RankActKingHeadCell.refreshView")        
    elseif key == "methodData" then
        local ret = MethodCellData:create(data)        
        self.methodData = ret 
    elseif key == "allPlayerRankData" then
        local ret = AllPlayerRankData:create(data)
        self.allPlayerRankData = ret
        CCSafeNotificationCenter:call("postNotification", "msg.RankActPlayerRankListCell.getLocalPlayerRank")               
    elseif key == "localPlayerRankData" then
        local ret = LocalPlayerRankData:create(data)
        self.localPlayerRankData = ret
        CCSafeNotificationCenter:call("postNotification", "msg.RankActPlayerRankListCell.getLocalPlayerRank") 
    elseif key == "totalScoreData" then
        local ret = TotalScoreCellData:create(data)
        self.totalScoreData = ret

    elseif key == "allServerRankData" then
        local ret = AllServerRankData:create(data)
        self.allServerRankData = ret
        CCSafeNotificationCenter:call("postNotification", "msg.RankActCountryRankListCell.getServerRank") 
    end
end

--取值
function RankActDataController:getDataBykey(key)
    if self[key] then
        return self[key]
    end
    return nil
end



return RankActDataController