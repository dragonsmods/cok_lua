----------------------------
-- Author: Elex
-- Date: 2019-02-25 Monday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local RecruitDetailView_ui = class("RecruitDetailView_ui")

--#ui propertys


--#function
function RecruitDetailView_ui:create(owner, viewType, paramTable)
	local ret = RecruitDetailView_ui.new()
	CustomUtility:LoadUi("RecruitDetailView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function RecruitDetailView_ui:initLang()
end

function RecruitDetailView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function RecruitDetailView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function RecruitDetailView_ui:onControlButton22(pSender, event)
	ButtonSmoker:forwardFunction(self, "onControlButton22", pSender, event)
end

function RecruitDetailView_ui:onControlButton21(pSender, event)
	ButtonSmoker:forwardFunction(self, "onControlButton21", pSender, event)
end

function RecruitDetailView_ui:onClickRecruit(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickRecruit", pSender, event)
end

function RecruitDetailView_ui:onBtnActive1Click(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBtnActive1Click", pSender, event)
end

function RecruitDetailView_ui:onBtnActive2Click(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBtnActive2Click", pSender, event)
end

function RecruitDetailView_ui:onBtnActive3Click(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBtnActive3Click", pSender, event)
end

return RecruitDetailView_ui

