----------------------------
-- Author: Elex
-- Date: 2018-03-27 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local NewMerchantView_ui = class("NewMerchantView_ui")

--#ui propertys


--#function
function NewMerchantView_ui:create(owner, viewType)
	local ret = NewMerchantView_ui.new()
	CustomUtility:DoRes(11, true)
	CustomUtility:LoadUi("NewMerchantView.ccbi", ret, owner, true, viewType, viewSize, params)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function NewMerchantView_ui:initLang()
end

function NewMerchantView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function NewMerchantView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function NewMerchantView_ui:onTipClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onTipClick", pSender, event)
end

function NewMerchantView_ui:onRefreshClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onRefreshClick", pSender, event)
end

function NewMerchantView_ui:initTableView()
	TableViewSmoker:createView(self, "m_originList", "game.CommonPopup.Merchant.NewMerchant.NewMerchantCell", 1, 8, "NewMerchantCell")
	TableViewSmoker:createView(self, "m_newInfoList", "game.CommonPopup.Merchant.NewMerchant.NewMerchantBigCell", 1, 8, "NewMerchantBigCell")
end

function NewMerchantView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return NewMerchantView_ui

