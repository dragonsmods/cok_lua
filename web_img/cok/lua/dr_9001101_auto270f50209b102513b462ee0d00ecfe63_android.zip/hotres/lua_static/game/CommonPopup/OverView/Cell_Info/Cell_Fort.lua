--戒律大厅
local Cell_Fort = class("Cell_Fort",Drequire("game.CommonPopup.OverView.Cell_Info.Cell_QueueFile"))

local TYPE_FORT = 2 --陷阱
local FUN_BUILD_FORT = 416000 --战争堡垒
function Cell_Fort:create(Id)
    local ret = Cell_Fort.new(Id)
    if ret:initBaseById(Id) then
        return ret
    end
end

function Cell_Fort:getCureQueueInfo()
    if not self:checkIsVisible() then
        return
    end
    local tempTbl = {}
    local qid = QueueController:call("getMinTimeQidByType",TYPE_FORT)
    tempTbl = self:getSubTypeCellTbl(qid)

    self.CellTbl.cellMeta={tempTbl}
    return self.CellTbl

end

function Cell_Fort:getSubTypeCellTbl(qid)
    local TYPE_BUILDING = 0 --建筑
    local res = {}
	local _state = self.Queue_ST_Init
	local _finishTime = -1
	local _totalTime = -1
	local _label = ""
	local _type = type
    local _id = ""
    local _name = ""
    local _icon = ""
    local _visible = ""

    local qInfo = self.allQueuesInfos[qid]

    if qid ~= QID_MAX then
        _state,_finishTime,_totalTime = self:getQueueState(qInfo)
        if _finishTime > 0 then
            _startTime = qInfo:getProperty("startTime")
            _totalTime = _finishTime - _startTime
            _finishTime = _finishTime
        end
	else
		_state = self.Queue_ST_IDLE
		_finishTime = 0		
	end

    if _state == self.Queue_ST_IDLE then
        _label = "169606" --空闲中
    elseif _state == self.Queue_ST_WORK then
        _label = "2000433" --制造中
    elseif _state == self.Queue_ST_LOCK then
        _label = "2000442" --未解锁			
    end
    _id = "30711017"

    --未解锁
    if not self:checkIsUnLock(TYPE_FORT) then
        _state = self.Queue_ST_LOCK
        _finishTime = -1
        _label = "2000442"
    end

    _name,_icon,_visible = self:getNameIconVisibleBySubId(_id)        
    res = {id = _id, state = _state, param1 = _finishTime, param2 = _totalTime,label = _label,name = _name,icon = _icon,order = _order,cell = self}
     
    if _visible == "1" then
        return res
    end
end

function Cell_Fort:OnClickJump(_id,_state)
    if _id == "30711017" then
        if _state == self.Queue_ST_WORK or _state == self.Queue_ST_IDLE then            
            self:jumpByTypeAndTarget(1,FUN_BUILD_FORT)
        elseif _state == self.Queue_ST_LOCK then
            --未解锁,目前是跳过去,会提示建造该建筑
            self:jumpByTypeAndTarget(1,FUN_BUILD_FORT)
        end
    end
end

return Cell_Fort