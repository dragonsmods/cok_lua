--非队列都继承该类
local Cell_MainFile = class("Cell_MainFile")
Cell_MainFile.__index = Cell_MainFile

local FUN_BUILD_BARRACK1 = 423000	--兵营
local FUN_BUILD_BARRACK2 = 424000	--马厩
local FUN_BUILD_BARRACK3 = 425000	--靶场
local FUN_BUILD_BARRACK4 = 426000	--战车
local FUN_BUILD_NEWARMY = 439000  --荣耀6新兵营
local FUN_BUILD_HOSPITAL = 411000 --医院
local FUN_BUILD_SCIENE  = 403000 --学院
local FUN_BUILD_FORT = 416000 --战争堡垒
local FUN_BUILD_SACRIFICE = 428000 --许愿池
local FUN_BUILD_HALLOFHERO = 433000   --英雄殿堂
local FUN_BUILD_DRAGONTOWER = 432000 --龙塔
local FUN_BUILD_NEWARMY_IMPROVE = 440000 --新兵种强化所
--主类别信息
function Cell_MainFile:ctor(id)
    if id == nil then
        return
    end
    self:initBaseById(id)    
end

--主类别的基本信息获取
function Cell_MainFile:initBaseById( id )
    self.id = id
    self.name = CCCommonUtilsForLua:call("getPropByIdGroup", "pandectType", self.id, "name")
    self.icon = CCCommonUtilsForLua:call("getPropByIdGroup", "pandectType", self.id, "icon")
    self.visible = CCCommonUtilsForLua:call("getPropByIdGroup", "pandectType", self.id, "visible")
    self.order = tonumber(CCCommonUtilsForLua:call("getPropByIdGroup", "pandectType", self.id, "order"))
    self.limitLv = tonumber(CCCommonUtilsForLua:call("getPropByIdGroup", "pandectType", self.id, "unlockLv"))
    self.edit = CCCommonUtilsForLua:call("getPropByIdGroup", "pandectType", self.id, "canEidt")
    local cellKey = "Preview_"..self.id.."_order"
	self.local_order = cc.UserDefault:getInstance():getIntegerForKey(cellKey,1)
    self.CellTbl = {key = self.id,icon = self.icon,local_order = self.local_order,order = self.order, name = self.name, edit = self.edit}
    --状态信息
    self.Queue_ST_Init = -1 
    self.Queue_ST_IDLE = 0 --空闲
    self.Queue_ST_WORK = 1 --工作
    self.Queue_ST_LOCK = 2	--未解锁
    self.mainCityLv = FunBuildController:call("getMainCityLv")
    return true
end

--[[
    返回数据表
    格式:self.CellTbl = {key=self.id,cellMeta={cell1,cell2,cell3...}}
    cell1={id=subCell_id,icon=subCell_icon,state=_state,label=_label,param1=_param1,param2=_param2}
    subCell_id:子类别ID，与表pandect一致
    param1:只有一个参数的情况下选择param1，比如免费次数：免费{0}次
    param2:两个参数情况下，比如param1是开始时间，param2是结束时间，用于倒计时
--]]
function Cell_MainFile:getCellDataTbl()
    -- overwrite me !!!!
end

--判断主类别是否显示
function Cell_MainFile:checkIsVisible()  
    local key = "Preview_"..self.id
    local userDefaultValue = cc.UserDefault:getInstance():getBoolForKey(key, true)
    if self.visible == "1" and self.mainCityLv >= self.limitLv and userDefaultValue == true then
        return true
    else
        return false
    end
end

--是否可编辑
function Cell_MainFile:checkIsEdit( )
    if self.edit == "1" then
        return true
    else
        return false
    end
end

--根据子类别ID读取子表pandect的name,icon,visible
function Cell_MainFile:getNameIconVisibleBySubId( subId )
    local name = CCCommonUtilsForLua:call("getPropByIdGroup", "pandect", subId, "name") or ""		
    local icon = CCCommonUtilsForLua:call("getPropByIdGroup", "pandect", subId, "icon") or ""
    local visible = CCCommonUtilsForLua:call("getPropByIdGroup", "pandect", subId, "visible") or "0"
    return name,icon,visible
end

--根据子列表ID和index返回dialog号
function Cell_MainFile:getDialogByIdIndex(subId,index)
    local dialog = CCCommonUtilsForLua:call("getPropByIdGroup", "pandect", subId, "dialog"..index) or ""
    return dialog
end

--跳转供外接口
function Cell_MainFile:OnClickJump(subId,state)
    -- override me!!!
end

--1:主城建筑 2:世界
function Cell_MainFile:jumpByTypeAndTarget(type,targetId)
    local currentSceneId = SceneController:call("getCurrentSceneId")
    if type == 1 then
        if currentSceneId == SCENE_ID_MAIN then
            CCCommonUtilsForLua.jumpToTarget(1, targetId)
        else
            SceneController:call("gotoScene", SCENE_ID_MAIN)
        end
    elseif type == 2 then
        PopupViewController:call("forceClearAll", true)
        if SceneController:call("getCurrentSceneId") ~= 11 then
            SceneController:call("gotoScene", 11)
        end
    end
end

--判断建筑是否已经解锁
function Cell_MainFile:checkIsUnLock(type)
    local res = false
	local buildType
	if type == TYPE_NEWARMY then
		buildType = FUN_BUILD_NEWARMY
	elseif type == TYPE_FORCE then
		buildType = FUN_BUILD_BARRACK1
	elseif type == TYPE_RIDE_SOLDIER then
		buildType = FUN_BUILD_BARRACK2
	elseif type == TYPE_BOW_SOLDIER then
		buildType = FUN_BUILD_BARRACK3
	elseif type == TYPE_CAR_SOLDIER then
		buildType = FUN_BUILD_BARRACK4
	elseif type == TYPE_HOSPITAL then
		buildType = FUN_BUILD_HOSPITAL
	elseif type == TYPE_SCIENCE then
		buildType = FUN_BUILD_SCIENE
	elseif type == TYPE_FORT then
		buildType = FUN_BUILD_FORT
	else
		buildType = type
	end
    local buildId = FunBuildController:call("getMaxLvBuildByType", buildType)
    if buildId > 0 then
        local buildInfo = FunBuildController:call("getInstance"):call("getFunbuildForLua", buildId)
        --该建筑已有，判断是否解锁
        if buildInfo then
            local m_info_level = buildInfo:getProperty("level")
            local gloryUnlockType = buildInfo:getProperty("gloryUnlockType")
            local gloryUnlockValue = buildInfo:getProperty("gloryUnlockValue")
            local gloryUnlock = buildInfo:getProperty("gloryUnlock")
            local open = buildInfo:getProperty("open")
            --荣耀建筑解锁条件
            local gloryUnLock = gloryUnlock == false and gloryUnlockType ~= "" and gloryUnlockValue ~= ""
            --达到指定等级后开放条件（开放不一定解锁）
            local openUnLock = open > self.mainCityLv
            if gloryUnLock or openUnLock then
                res = false
            else
                res = true
            end
            -- local name = buildInfo:getProperty("name")		
            -- dump(getLang(name),"hxq name is")
            -- dump(open,"hxq open is")
            -- dump(gloryUnlock,"hxq gloryUnlock is")
            -- dump(gloryUnlockType,"hxq gloryUnlockType is")		
        end
    end
	return res
end

return Cell_MainFile