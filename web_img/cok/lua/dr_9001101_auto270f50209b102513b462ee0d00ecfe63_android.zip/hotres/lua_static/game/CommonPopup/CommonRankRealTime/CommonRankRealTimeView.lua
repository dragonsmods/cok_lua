-- @Author:fenghaibin 
-- @Date: 2020-10-29
-- @Description: 实时排行榜view
--[[ 
------------------------------通用实时排行榜界面------------------------------
配置:
@params:
	name:排行榜活动类型，不同活动排行榜拥有不同的type类型，与后端约定好 比如:formation
	id:前端表ranking_display中对应的配置id
	secondShowId:页面有本服、全服排行榜切换需求时,配第二个要展示榜行榜的ranking_display中对应id
	viewSize:界面尺寸大小
]]

local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local CommonRankRealTimeView = class("CommonRankRealTimeView", function()
    return cc.Layer:create() 
end)
CommonRankRealTimeView.__index = CommonRankRealTimeView

local REFRESH_LIMIT_TIME = 5
local REFRESH_LIMIT_TIME_TAIL = 5 * 60
local cellHeight = 92
function CommonRankRealTimeView:create(params)
    local view = CommonRankRealTimeView.new()
    local viewSize = params.viewSize
    utils.getExtendClass( "Template_ui" ):create(view,"CommonRankRealTimeView.ccbi", 0, viewSize, true,
        {'onSwitchBtnClick', 'onAnonymousClick', 'onRefreshButtonClick', 'onSearchButtonClick'})
    view.ctl = require("game.CommonPopup.CommonRankRealTime.CommonRankRealTimeMgr").getInstance()
	if view:initView(params) then 
    	return view 
    end
end

function CommonRankRealTimeView:onCleanup()
	self.ctl.m_refreshViewEvent:remove(self.onDataBack,self)
	self.ctl.m_refreshPageDataEvent:remove(self.parsePageData,self)
	self.ctl.m_setAnonymousStateEvent:remove(self.refreshAnonymousView,self)
end

function CommonRankRealTimeView:resetData()
	self.m_hadInit = false
	self.m_pageIndex = 0
	self.m_curMaxRank = 0
	self.m_isSearching = false -- 是否在查找排名
	self.m_searchingRank = 0 -- 要查找的排名
	self.m_cellDataList = {}
	self.totalPageNum = 0
	self.pageSize = 0
	self.maxShowNum = 0
	self.m_rewardIdTab = nil
end

function CommonRankRealTimeView:initView(params)
	CCLoadSprite:call("loadDynamicResourceByName", "AllServerRank_face")
	CCLoadSprite:call("loadDynamicResourceByName", "HeadIcon")
	self.m_switchSprTbl = {'rank_switch_icon.png', 'rank_trophy_icon.png'}
	local configTbl = {}
	local firstShowConfig = Drequire("game.CommonPopup.commonRank.CommonRankConfig"):create(params.id, params.name)
	table.insert(configTbl, firstShowConfig)
	if not string.isNilOrEmpty(params.secondShowId) then
		local secondShowConfig = Drequire("game.CommonPopup.commonRank.CommonRankConfig"):create(params.secondShowId, params.name)
		table.insert(configTbl, secondShowConfig)
	end
	self.m_configTbl = configTbl
	self.m_curConfigIdx = 1
	self.config = configTbl[self.m_curConfigIdx]
	self.rankCellNode = self.config:getRankCellNode()
	-- self.ui.m_serchNode:setVisible(true)
	self.m_pageIndex = 0
	self.m_curMaxRank = 0 -- 当前最大的排名
	self.m_isSearching = false -- 是否在查找排名
	self.m_searchingRank = 0 -- 要查找的排名
	self.pageSize = 0

	local titleTxtId = self.config:getRankTitleDialog()
	self.ui.m_titleLabel:setString(getLang(titleTxtId))
    self.ui.m_anonymousOpenLabel:setString(getLang('9461492'))	--9461492=隐藏名字
    self.ui.m_refreshRankTxt:setString(getLang('9461493'))		-- 9461493=刷新榜单
	self.ui.m_searchTxt:setString(getLang('221128'))
	self.ui.m_anonymousNode:setVisible(false)
	self.ui.m_refreshNode:setVisible(false)
	self.ui.m_swithNode:setVisible(false)

	self.ctl.m_refreshViewEvent:add(self.onDataBack,self)
	self.ctl.m_refreshPageDataEvent:add(self.parsePageData,self)
	self.ctl.m_setAnonymousStateEvent:add(self.refreshAnonymousView,self)
	self:initTableView()
	self:initParticle( )

	local reqParams = self.config:getReqParams(self.m_pageIndex)
	self.ctl:requestInfo(reqParams)
	-- self:onDataBack()
	return true
end

function CommonRankRealTimeView:initParticle( )
    self.ui.m_particle:removeAllChildren()
    local rootPath = CCFileUtils:sharedFileUtils():getWritablePath().."dresource/"
    local plistPath = rootPath.."skinparticle/"
    local particles={"richangfulibaoxiang3_star","richangfulibaoxiang3fx4"}
    for k,v in pairs(particles) do
        local particle = ParticleController:call("createParticleForLua", plistPath..v..".plist")
        if particle then 
            self.ui.m_particle:addChild(particle)
        end
    end
end

function CommonRankRealTimeView:refreshView()
	if self.m_configTbl and #self.m_configTbl > 1 then
		self.ui.m_swithNode:setVisible(true)
		local titleTxtId = self.config:getRankTitleDialog()
		self.ui.m_titleLabel:setString(getLang(titleTxtId))
		local switchTxtId = self.config:getSwitchTextDialog()
		self.ui.m_switchTxt:setString(getLang(switchTxtId))
		local sf = CCLoadSprite:call("getSF", self.m_switchSprTbl[self.m_curConfigIdx])
		if sf then
			self.ui.m_sprSwitchRank:setSpriteFrame(sf)
		end		
	end
	if not table.isNilOrEmpty( self.m_cellDataList ) then
		local innerContainer = self.ui.m_tableNode:getChildren()[1]
		local prevePosY = innerContainer:getPositionY()
        self:setTableViewDataSource("m_tableNode", self.m_cellDataList)
		if not self.m_hadInit then
			self.m_hadInit = true
			self.ui.m_refreshNode:setVisible(true)
		else
			innerContainer:setPositionY( prevePosY )
			self.ui.m_tableNode:scrollViewDidScroll(self.ui.m_tableNode)
		end
	end
end

function CommonRankRealTimeView:onDataBack(tbl)
	if table.isNilOrEmpty(tbl) or table.isNilOrEmpty(tbl.rank) then
		LuaController:flyHint("", "", getLang("138130")) -- 138130=暂无记录
		GameController:call("removeWaitInterface")
		return
	end
	self.pageSize = atoi(tbl.pageSize)
	self.totalPageNum = atoi(tbl.pagenum or self.totalPageNum)
	self.maxShowNum = self.pageSize * self.totalPageNum
	local selfrank = tbl.selfrank
	if not table.isNilOrEmpty(selfrank) then
		self.m_selfrank = selfrank
		self.myRank = tonumber(selfrank.rank)
		self.m_isShowName = atoi(selfrank.isShowName)
		self:refreshAnonymousView()
		self:parsePageData(tbl.rank)
	end
end

function CommonRankRealTimeView:parsePageData(rankPage)
	local cellDataList = {}
	self.m_curMaxRank = self.m_curMaxRank or 1
	local maxRankUpdate = false
	if rankPage and #rankPage > 0 then
		table.sort( rankPage, function(a, b)
			return atoi(a.rank) < atoi(b.rank)
		end)
		local _rank = tonumber(rankPage[#rankPage].rank)
		if _rank > self.m_curMaxRank then
			self.m_curMaxRank = _rank
			maxRankUpdate = true
		end
	end

	-- rankPage头部处理
	if self.m_pageIndex == 0 then
		local top3List = {rankPage[1], rankPage[2], rankPage[3]}
		local top3Data = self:createTop3CellData(top3List)
		table.insert(cellDataList, top3Data)
		local titleCellData = self:createTitleCellData()
		table.insert(cellDataList, titleCellData)
		-- 计算我的排名
		if self.m_selfrank and next(self.m_selfrank) then
			local myRankNum = atoi(self.m_selfrank.rank)
			if self.m_selfrank.score then
				local myCellData = {
					type = 1,
					parent = self,
					data = self.m_selfrank,
					config = self.config
				}
				myCellData.callback = function(x)
					self:onRewardButtonClick(tonumber(x))
				end
				myCellData.dataType = 0 -- 排名数据
				myCellData.showSearch = true
				myCellData.searchCallback = function(x)
					self:searchRankInfo(tonumber(x))
				end
				myCellData.parent = self
				myCellData.isSelf = true
				myCellData.maxShowNum = self.maxShowNum
				table.insert(cellDataList, myCellData)
			end
		end
	end

	-- rankPage数据处理
	if #rankPage > 0 then
		local start = 1
		if self.m_pageIndex == 0 then
			start = 4
		end
		for i = start, #rankPage do
			local cellData = {
				type = 1,
				parent = self,
				data = rankPage[i],
				config = self.config
			}
			-- 为 cell 添加查看奖品的回调
			cellData.callback = function(x)
				self:onRewardButtonClick(tonumber(x))
			end
			cellData.dataType = 0 -- 排名数据
			if i == 1 then
				cellData.checkPageDataUpdate = function(x)
					self:onCheckPageDataUpdate(tonumber(x))
				end
			end
			table.insert(cellDataList, cellData)
		end
	end

	-- rankPage尾部处理
	self.m_cellDataList = self.m_cellDataList or {}
	if maxRankUpdate or self.m_isSearching then
		if #self.m_cellDataList >= 1 then
			table.remove(self.m_cellDataList, #self.m_cellDataList)
		end
		if self.m_pageIndex + 1 < self.totalPageNum then
			local cellData = {
				type = 2,
				data = {
					dataType = 1,
					getMoreRank = function()
						self.m_pageIndex = self.m_pageIndex + 1
						self.m_refreshMore = true
						self.reqPreIndexData = true
						self:reqData()
					end
				}, -- 获取更多
				config = self.config
			}
			table.insert(cellDataList, cellData)
		else
			if self.m_isSearching then
				self.m_searchingRank = self.m_curMaxRank
			end
			local cellData = {
				type = 2,
				data = {
					dataType = 2
				},
				config = self.config
			}
			table.insert(cellDataList, cellData)
		end
	end

	-- 数据更新
	if not table.isNilOrEmpty(cellDataList) then
		for k,v in ipairs(cellDataList) do
			local idx = self.m_pageIndex * self.pageSize + k
			self.m_cellDataList[idx] = v
		end
	end

	if self.m_isSearching then
		if self.m_searchingRank <= self.m_curMaxRank then
			GameController:call("removeWaitInterface")
			self.m_isSearching = false
			self:setTableViewDataSource("m_tableNode", self.m_cellDataList)
			self:jumpToSearchingRank(self.m_searchingRank)
		else
			self.m_pageIndex = self.m_pageIndex + 1
			self:reqData()
		end
	else
		if self.m_pageIndex > 0 and self.reqPreIndexData then
			self.m_pageIndex = self.m_pageIndex - 1
			self.reqPreIndexData = false
			self.m_inReqPreData = true
			self:reqData()
		else
			GameController:call("removeWaitInterface")
			if self.m_inReqPreData  then
				self.m_inReqPreData = false
				self.m_pageIndex = self.m_pageIndex + 1
			end
			self:refreshView()
			if self.m_refreshMore then
				local jumpIdx = self.m_pageIndex * self.pageSize - 1
				self:jumpToSearchingRank(jumpIdx)
				self.m_refreshMore = false
			end
		end
	end
end

function CommonRankRealTimeView:reqData()
	GameController:call("showWaitInterface")
	local params = self.config:getReqParams(self.m_pageIndex)
	self.ctl:requestPageInfo(params)
end

function CommonRankRealTimeView:onCheckPageDataUpdate(idx)
	if self.m_refreshMore then
		return
	end
	local cellIdx = idx+1
	local cellData = self.m_cellDataList[cellIdx]
	if table.isNilOrEmpty(cellData) then
		return
	end
	if self.m_lastUpdateIdx ~= cellIdx then
		local pageIdx = math.floor(cellIdx/self.pageSize)
		local timeCount = getTimeStamp() - math.floor(cellData.data.updateTime / 1000)
		self.m_lastUpdateIdx = cellIdx
		if (pageIdx < 5 and timeCount > REFRESH_LIMIT_TIME)
		or (pageIdx > 4 and timeCount > REFRESH_LIMIT_TIME_TAIL) then
			self.m_pageIndex = pageIdx
			-- self.reqPreIndexData = true
			-- self:reqData()
		end
	end
end

function CommonRankRealTimeView:jumpToSearchingRank(idx)
	local minOffsetY = self.ui.m_contentNode:getContentSize().height - self.ui.m_tableNode:getContentSize().height
	local maxOffsetY = self.ui.m_contentNode:getContentSize().height
	local offsetY = minOffsetY + (idx - 4 - 1) * cellHeight
	if offsetY < minOffsetY then
		offsetY = minOffsetY
	elseif offsetY > maxOffsetY then
		offsetY = maxOffsetY
	end
	self.ui.m_tableNode:setContentOffset(cc.p(0, offsetY))
end

function CommonRankRealTimeView:onEnter()
	local function onGetRewardDetailBack(ref)
		local rewardId = ""
		if ref then
			rewardId = ref:getCString()
		end
		if self.m_requestingRewardIdTab and #self.m_requestingRewardIdTab > 0 then
			for i = 1, #self.m_requestingRewardIdTab do
				if rewardId == self.m_requestingRewardIdTab[i] then
					table.remove(self.m_requestingRewardIdTab, i)
					break
				end
			end
			if #self.m_requestingRewardIdTab == 0 then
				GameController:call("removeWaitInterface")
				self:getRewardDataAndOpenView()
			end
		end
	end
	local handler = self:registerHandler(onGetRewardDetailBack)
	CCSafeNotificationCenter:registerScriptObserver(self, handler, "MSG_GET_REWARD_DETAIL_BACK")
end

function CommonRankRealTimeView:onExit()
	CCSafeNotificationCenter:unregisterScriptObserver(self, "MSG_GET_REWARD_DETAIL_BACK")
end

function CommonRankRealTimeView:initTableView()
	TableViewSmoker:createView(self.ui, 
		"m_tableNode", 
        self.rankCellNode.luaPath,
		cc.SCROLLVIEW_DIRECTION_VERTICAL, 10, 
		self.rankCellNode.ccbiName)

	self.m_cellDataList = {
		self:createTop3CellData(),
		self:createTitleCellData()
	}
	self:setTableViewDataSource("m_tableNode", self.m_cellDataList)
end

function CommonRankRealTimeView:tableCellTouched(tab, cell)
end

function CommonRankRealTimeView:scrollViewDidScroll(tab)
	local offset = tab:getContentOffset()
	local contentSize = tab:getContentSize()
	local viewSize = tab:getViewSize()
	local topOffestY = viewSize.height - contentSize.height
	self.ui.m_headLayer:setVisible(offset.y - topOffestY > 50)
end

function CommonRankRealTimeView:cellSizeForTable(tv, idx)
	if not self.m_cellDataList then
		return 0, 0
	end
	local data = self.m_cellDataList[idx + 1]
	if data then
		if data.type == 1 then
			return 574, 92
		elseif data.type == 2 then
			return 574, 92
		elseif data.type == 3 then
			return 576, 80
		else
			return 576, 420
		end
	else
		return 0, 0
	end
end

function CommonRankRealTimeView:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self.ui, tvName, data)
end

function CommonRankRealTimeView:createTop3CellData(tbl)
	local top3Data = {
		type = 4,
		parent = self,
		data = {
			rankList = tbl,
			luaFile = self.rankCellNode.luaTop3Path,
		},
		config = self.config
	}
	return top3Data
end

function CommonRankRealTimeView:createTitleCellData()
	local titleInfo = string.split(self.config:getColumnTitle() or "108101;182091;102139", ";")
	local dialogId1 = titleInfo[1] or "108101" -- 108101=领主
	local dialogId2 = titleInfo[2] or "182091" -- 182091=本期积分
	local dialogId3 = titleInfo[3] or "102139" -- 102139=奖励
	local dialogTips = self.config:getRefreshDialog()
	local titleCellData = {
		type = 3,
		parent = self,
		data = {
			name = getLang(dialogId1),
			power = getLang(dialogId2),
			server = getLang(dialogId3),
			tips = getLang(dialogTips)
		},
		config = self.config
	}
	return titleCellData
end

function CommonRankRealTimeView:hasReward()
    if string.isNilOrEmpty(self.config:getRewardTbl()) == false 
    or string.isNilOrEmpty(self.config:getRewardId()) == false then
		return true
	end
	return false
end

function CommonRankRealTimeView:onRewardButtonClick(idx)
	if self:hasReward() then
		-- 打点需求
		local rankName = self.config:getRankName() or ""
		local groupName = self.config:getRankGroupType() or ""

		self.m_idx = idx
		self:getRewardDataWithCheck()
	end
end

-- 解析奖励
function CommonRankRealTimeView:parseRewardId()
	if not self.m_rewardIdTab then
		self.m_rewardIdTab = {}
		local xmlName = self.config:getRewardTbl()
		local rewardId = self.config:getRewardId()
		local reward = CCCommonUtilsForLua:call("getPropByIdGroup", xmlName, rewardId, "reward")
		local rwdTab = string.split(reward, "|")
		for i = 1, #rwdTab do
			local rwdItem = string.split(rwdTab[i], ";")
			if #rwdItem >= 2 then
				local rwdIdx = string.split(rwdItem[1], "-")
				if #rwdIdx >= 2 then
					self.m_rewardIdTab[i] = {left = tonumber(rwdIdx[1]), right = tonumber(rwdIdx[2]), rewardId = rwdItem[2]}
				elseif #rwdIdx >= 1 then
					self.m_rewardIdTab[i] = {left = tonumber(rwdIdx[1]), right = tonumber(rwdIdx[1]), rewardId = rwdItem[2]}
				end
			end
		end
	end
end

-- 检查奖励数据
function CommonRankRealTimeView:checkRewardData()
	self:parseRewardId()
	self.m_requestingRewardIdTab = {}
	for i = 1, #self.m_rewardIdTab do
		local rwd = GlobalData:call("getCachedRewardData", self.m_rewardIdTab[i].rewardId)
		local rwdData = arrayToLuaTable(rwd)
		if #rwdData == 0 then
			self.m_requestingRewardIdTab[#self.m_requestingRewardIdTab + 1] = self.m_rewardIdTab[i].rewardId
		end
	end
end

-- 获取奖励数据（没有时向服务器请求）
function CommonRankRealTimeView:getRewardDataWithCheck()
	self:checkRewardData()
	if #self.m_requestingRewardIdTab == 0 then
		self:getRewardDataAndOpenView()
	else
		GameController:call("showWaitInterface")
		for i = 1, #self.m_requestingRewardIdTab do
			GlobalData:call("requestRewardData", self.m_requestingRewardIdTab[i])
		end
	end
end

-- 获取奖励数据并打开奖励界面
function CommonRankRealTimeView:getRewardDataAndOpenView()
	local myRank = self.myRank or 0
	local idx = self.m_idx or 1
	local found = false
	local index = 0
	local rewardTab = {}
	if myRank > 0 then
		for i = 1, #(self.m_rewardIdTab or {}) do
			local left = self.m_rewardIdTab[i].left
			local right = self.m_rewardIdTab[i].right
			if left <= myRank and myRank <= right then
				if idx == myRank then
					found = true
					index = #rewardTab
				end
				local titleStr = getLang("221120") .. " (" .. getLang("170008") .. ": " .. myRank .. ")"
				rewardTab[#rewardTab + 1] = {type = 1000, label = titleStr}
				local rwd = GlobalData:call("getCachedRewardData", self.m_rewardIdTab[i].rewardId)
				local rwdData = arrayToLuaTable(rwd)
				for _, v in pairs(rwdData) do
					rewardTab[#rewardTab + 1] = v
				end
				break
			end
		end
	end
	for i = 1, #(self.m_rewardIdTab or {}) do
		local left = self.m_rewardIdTab[i].left
		local right = self.m_rewardIdTab[i].right
		if not found then
			if left <= idx and idx <= right then
				found = true
				index = #rewardTab
			end
		end
		local titleStr = ""
		if left ~= right then
			titleStr = getLang("221119", tostring(left), tostring(right))
		else
			titleStr = getLang("221121", tostring(left))
		end
		rewardTab[#rewardTab + 1] = {type = 1000, label = titleStr}
		local rwd = GlobalData:call("getCachedRewardData", self.m_rewardIdTab[i].rewardId)
		local rwdData = arrayToLuaTable(rwd)
		for _, v in pairs(rwdData) do
			rewardTab[#rewardTab + 1] = v
		end
	end

	local titleName = getLang(self.config:getRewardTitle())
	local tipsDes = getLang(self.config:getRewardTips() or "221122")
	self:showRewardView(rewardTab, index, titleName, tipsDes)
end

function CommonRankRealTimeView:showRewardView(rewardTab, index, titleName, tipsDes)
	local view = Drequire("game.equipment.EquipRank.EquipmentRewardView"):create(rewardTab, index, titleName, tipsDes)
	PopupViewController:call("addPopupView", view)
end

function CommonRankRealTimeView:onSwitchBtnClick(pSender)
	if utils.delayClickBtn( pSender, 1, true ) then
		return
	end
	if self.m_configTbl and #self.m_configTbl > 1 then
		self.m_curConfigIdx = self.m_curConfigIdx == #self.m_configTbl and 1 or self.m_curConfigIdx + 1
		self.config = self.m_configTbl[self.m_curConfigIdx]
		self:resetData()
		GameController:call("showWaitInterface")
		local reqParams = self.config:getReqParams(self.m_pageIndex)
		self.ctl:requestInfo(reqParams)
	end
end

function CommonRankRealTimeView:refreshAnonymousView(tbl)
	if self.config:getAnonymousOpen() and self.config:getHasAnonymousPermission() then
		if not table.isNilOrEmpty(tbl) then
			self.m_isShowName = atoi(tbl.state)
			local flyTxt = self.m_isShowName == 0 and getLang('9461498') or getLang('9461499')
			CCCommonUtilsForLua:call("flyHint", "", "", flyTxt)
			local s_uid = GlobalData:call("shared"):getProperty("playerInfo"):getProperty("uid")
			local rankData = table.find(self.m_cellDataList, function(cur)
				if cur.data then 
					if cur.data.rankList then
						for _,v in ipairs(cur.data.rankList) do
							if v.u_info and v.u_info.uid == s_uid then
								v.isShowName = tostring(self.m_isShowName)
								return true
							end
						end
					elseif not cur.showSearch and cur.data.u_info then
						return cur.data.u_info.uid == s_uid
					end
				end
				return false
			end)
			if rankData and not rankData.data.rankList then 
				rankData.data.isShowName = tostring(self.m_isShowName) 
			end
			self:refreshView()
		end
		self.ui.m_anonymousNode:setVisible(true)
		if not self.m_isShowName or self.m_isShowName == 0 then
			self.ui.m_anonymousOpenLabel:setString(getLang("9461497"))	--9461497=显示名字
		else
			self.ui.m_anonymousOpenLabel:setString(getLang("9461492"))	--9461492=隐藏名字
		end
	else
		self.ui.m_anonymousNode:setVisible(false)
	end
end

function CommonRankRealTimeView:onAnonymousClick(pSender)
	if utils.delayClickBtn( pSender, 1, true ) then
		return
	end
	if self.config and self.config:getAnonymousOpen() and self.config:getRankName() then
		local params = self.config:getReqParams(self.m_pageIndex)
		local newState = self.m_isShowName == 0
		self.ctl:reqSetAnonymousState(params, newState)
	end
end

function CommonRankRealTimeView:onRefreshButtonClick(pSender)
	if utils.delayClickBtn( pSender, 5, true ) then
		return
	end
	self.ui.m_refreshRankTxt:stopAllActions()
	local times = REFRESH_LIMIT_TIME
	local function refreshTime()
		self.ui.m_refreshRankTxt:setString(times .. 's')
		times = times - 1
	end
	local function resetBtnTxt()
		self.ui.m_refreshRankTxt:setString(getLang('9461493'))	-- 9461493=刷新榜单
	end
	local fun1 = cc.CallFunc:create(handler(self, refreshTime))
	local delay = cc.DelayTime:create(1)
	local seq1 = cc.Sequence:create(fun1, delay)
	local actionRepeat = cc.Repeat:create(seq1, REFRESH_LIMIT_TIME)
	local fun2 = cc.CallFunc:create(handler(self, resetBtnTxt))
	local seq2 = cc.Sequence:create(actionRepeat, fun2)
	self.ui.m_refreshRankTxt:runAction(seq2)

	if self.m_pageIndex > 0 then
		self.reqPreIndexData = true
	end
	self:reqData()
end

function CommonRankRealTimeView:onSearchButtonClick()
	local callback = function (index)
		self:searchRankInfo(tonumber(index))
	end
	local view = Drequire("game.CommonPopup.CommonInputView"):create(getLang("221129"), callback)
	PopupViewController:call("addPopupView", view)
end

function CommonRankRealTimeView:searchRankInfo(idx)
	if not self.maxShowNum then
		return
	end
	local maxRank = self.maxShowNum
	if idx <= 3 then
		idx = 3 + 1
	elseif idx > maxRank then
		idx = maxRank
	end
	if idx <= self.m_curMaxRank then
		self:jumpToSearchingRank(idx)
	else
		self.m_isSearching = true
		self.m_searchingRank = idx
		self.m_pageIndex = self.m_pageIndex + 1
		self:reqData()
	end
end

return CommonRankRealTimeView