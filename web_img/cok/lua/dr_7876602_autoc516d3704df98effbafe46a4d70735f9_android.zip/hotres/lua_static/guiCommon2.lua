guiCommonGlobal = guiCommonGlobal or {}
local guiCommonLocal = {}
MyPrint("requireing")

function getInLuaEffectValueByNum( num )
	-- MyPrint("getInLuaEffectValueByNum ", num)
	local ret = 0
	-- 龙系统
	ret = ret + DragonActiveSkillManager.getInstance():getEffectValueByNum(num)
	ret = ret + CivilizationController:getEffectValueByNum(num)
	ret = ret + FangJianBeiEffectMgr.getInstance():getEffectValueByNum(num) -- 奇迹／方尖碑
	--世界等级
	ret = ret + require("game.worldLevel.WorldLevelManager").getEffectValueByNum(num)
	--领主王冠
	ret = ret + require("game.crown.CrownManager").getEffectValueByNum(num)
	ret = ret + DressIntroductionController:getEffectValueByNum(num) --图鉴
	-- 英雄
	ret = ret + require('game.hero.NewUI_v2.HeroBuffManager'):getEffectValueByNum(num)	-- 英雄图鉴
	-- 士兵进阶
	ret = ret + require('game.army.ArmyController'):getEffectValueByNum(num)
	-- 文明星盘
	ret = ret + require("game.allianceTerritory.civiMiracle.CiviMiracleManager").getEffectValueByNum(num)
	-- 【Awen】先祖战场
	require('game.Battlefield.BattlefieldController')
	ret = ret + BattlefieldController.getInstance():getEffectValuebyNum(num)
	-- MyPrint("getInLuaEffectValueByNum ", num, ret)
	--魔法学院
	ret = ret + require("game.magic.MagicManager").getEffectValueByNum(num)
	-- 月卡等级
	ret = ret + MonthCardController.getInstance():getEffectValueByNum(num)
	-- 节日活动
	ret = ret + require("game.FestivalActivities.FestivalActivitiesController").getInstance():getEffectValueByNum(num)
	--竞技场
	ret = ret + TournamentControllerInst:getEffectValueByNum(num)
	return ret
end

function guiCommonLocal.oninitCrownTableView( dict )
	require("game.crown.CrownManager").initCrownEntranceTableView(dict)
end

function guiCommonLocal.on_open_SubEquipSelectView( data )
	if nil == data then
		return
	end
	myRequire("game.equipment.SubEquipSelectView")
	local view = SubEquipSelectView.create(data["groupId"], data["posy"])
	PopupViewController:call("addPopupView", view)
end

function guiCommonLocal.on_put_allianceBoss( data )
	-- body
	if nil == data then
		return
	end

	require("game.allianceBoss.AllianceBossController")
	AllianceBossController.getInstance():startOpenBoss(data.bossId or "", data.index or 1)
end

function guiCommonLocal.on_get_put_equip_id( dict )
	MyPrint("get_put_equip_id")
	if nil == dict then
		return
	end

	local groupId = dict:objectForKey("groupId")
	groupId = tolua.cast(groupId, "CCInteger")
	groupId = groupId:getValue()
	local uuid = EquipmentController:call("getInstance"):getPutOnEquipByEquipGroupId(groupId)
	dict:setObject(CCString:create(uuid), "uuid")

	return
end

function guiCommonLocal.on_requestActValueAndTime(data)
	MyPrint("on_requestActValueAndTime")
	if nil == data then
		return
	end
	LuaActivityController.getInstance():requestServerActValue(data.key)
	return
end


function guiCommonLocal.on_get_act_key_value( dict )
	MyPrint("on_get_act_key_value")
	if nil == dict then
		return
	end

	local key = dict:valueForKey("key"):getCString()
	MyPrint("key ", key)
	local value = LuaActivityController.getInstance():getValueByKey(key)
	if value ~= nil then
		dict:setObject(CCString:create(tostring(value)), "value")
	end
end

function guiCommonLocal.dumpDictionary(param)
	local tbl = dictToLuaTable(param)
	dump(tbl, "dumpDictionary", 10)
end

function guiCommonLocal.dumpArray(param)
	local tbl = arrayToLuaTable(param)
	dump(tbl, "dumpArray", 10)
end

function guiCommonLocal.openWorldLevelInfoView()
	local view = Drequire("game.worldLevel.WorldLevelInfoView"):create()
	PopupViewController:addPopupView(view)
end

function guiCommonLocal.OneKeyBuffMainView()
	local view = Drequire("game.OneKeyBuff.OneKeyBuffMainView"):create()
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.worldLevelInterface(param)
	require("game.worldLevel.WorldLevelManager").interface(param)
end

function guiCommonLocal.openWebActivityView()
	local view = Drequire("game.activity.web.WebActivityView"):create()
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.openDragonBattleRecordView(param)
	local parentView = PopupViewController:call("getCurrentPopupView")
	local view = Drequire("game.dragonBattle.DragonBattleRecordView"):create(param)
	if parentView then
		view:setInOtherView()
		parentView:addChild(view)
	else
		PopupViewController:addPopupView(view)
	end
end

function guiCommonLocal.openDragonBattleComparisonView()
	local view = Drequire("game.dragonBattle.DragonBattleDataComparisonView"):create()
	PopupViewController:addPopupView(view)
end

function guiCommonLocal.openCrossThroneTowerDetailsView(vm)
	if vm and vm.buildId and vm.cityIndex then
		local detailsView = Drequire("game.crossThrone.CrossThroneTowerDetailsView"):create(vm.buildId, vm.cityIndex)
    	PopupViewController:addPopupInView(detailsView)
	end
end

function guiCommonLocal.webActivityInterface(param)
	require("game.activity.web.WebActivityManager").interface(param)
end

function guiCommonLocal.openArtillerySelectView(vm)
	local view = Drequire("game.artillery.ArtillerySelectView"):create(vm)
	PopupViewController:addPopupView(view)
end

function guiCommonLocal.openArtilleryProduceView(vm)
	local view = Drequire("game.artillery.ArtilleryProduceView"):create(vm.buildingKey)
	PopupViewController:addPopupInView(view) 
end

function guiCommonLocal.ArtilleryInterface(param)
	require("game.artillery.ArtilleryManager").operate(param)
end

function guiCommonLocal.openPlayerSearchListView(vm)
	local dataTbl = {}
	dataTbl.item = "212054"
	dataTbl.data = {}
	dataTbl.data[1] =  {
		name = vm.name,
		uid = vm.uid,
	}
	local view = Drequire("game.Spy.PlayerSearchListView"):create(dataTbl, true)
	PopupViewController:addPopupView(view)
end

function guiCommonLocal.openCiviMiraclePopupView(vm)
	local view = Drequire("game.allianceTerritory.civiMiracle.CiviMiraclePopupView"):create(vm.id, vm.index)
	PopupViewController:addPopupView(view)
end

function guiCommonLocal.ReqCiviMiracleCancel(vm)
	Drequire("game.allianceTerritory.civiMiracle.CiviMiracleCmdHelper").destoryMiracle(vm.uid, vm.point)
end

function guiCommonLocal.isCiviMiracleExist(dict)
	require("game.allianceTerritory.civiMiracle.CiviMiracleManager").isCiviMiracleExist(dict)
end

function guiCommonLocal.openCiviMiracleFunctionView()
	local view = Drequire("game.allianceTerritory.civiMiracle.CiviMiracleFunctionView"):create()
    if view then
    	PopupViewController:addPopupInView(view)
    end
end

function guiCommonLocal.shareCiviMiracleBuild(vm)
	require("game.allianceTerritory.civiMiracle.CiviMiracleManager").shareCiviMiracleBuild(vm)
end

function guiCommonLocal.shareCiviMiracleHelp(vm)
	require("game.allianceTerritory.civiMiracle.CiviMiracleManager").shareCiviMiracleHelp(vm)
end

function guiCommonLocal.getCiviMiraclePic(dict)
	require("game.allianceTerritory.civiMiracle.CiviMiracleManager").getCiviMiraclePic(dict)
end

function guiCommonLocal.getQIJISHIFreeTimes(dict)
	require("game.allianceTerritory.civiMiracle.CiviMiracleManager").getQIJISHIFreeTimes(dict)
end 

function guiCommonLocal.getCiviMiracleFreeTimes(dict)
	require("game.allianceTerritory.civiMiracle.CiviMiracleManager").getCiviMiracleFreeTimes(dict)
end 

function guiCommonLocal.checkIsBuySpecialMonthCard(dict)
	MonthCardController.getInstance():checkIsBuySpecialMonthCard(dict)
end 

function guiCommonLocal.showCiviMiracleAni(vm)
	if CCLoadSprite:call("loadDynamicResourceByName", "CiviMiracle_face") 
			and CCLoadSprite:call("loadDynamicResourceByName", "CiviMiracleStar_face") 
				and CCLoadSprite:call("loadDynamicResourceByName", "CiviMiracleAni_face") then
		local view = Drequire("game.allianceTerritory.civiMiracle.CiviMiracleAniView"):create(vm.aniType)
		if view then PopupViewController:addPopupView(view) end
	end
end

function guiCommonLocal.openRpActiveView(vm)
	local view = Drequire("game.equipment.NewEquip.NewEquipActiveView"):create(vm.uuid)
	if view then
    	PopupViewController:addPopupView(view)
    end
end

function guiCommonLocal.onAccessCSData(dict)
	require("game.crossThrone.CrossServerBattleManager"):initData(dict)
end

function guiCommonLocal.canTipsEventShow(dict)
	require("game.tipsEvent.TipsEventManager"):canTipsEventShow(dict)
end

function guiCommonLocal.tipsEventGoto(dict)
	require("game.tipsEvent.TipsEventManager"):tipsEventGoto(dict)
end

function guiCommonLocal.activeHeroSkin(dict)
	local data = dictToLuaTable(dict)
	dump(data, "activeHeroSkin")
	require("game.hero.HeroSkinManager").getInstance():activeSkin(data)
end

--【Awen】英雄换装
function guiCommonLocal.onHeroSkinEvent(data, key)
	require("game.hero.HeroSkinManager").getInstance():fireCommonEvent(key, data)
end

function guiCommonLocal.hero_start_put_monster(data)
	HeroManager.startPutMonster(data)
end

function guiCommonLocal.addSafeArea()
	NeutralLandManager.addSafeArea()
end

function guiCommonLocal.openDragonBattleRewardView()
	local view = Drequire("game.dragonBattle.DragonBattleRewardView"):create()
	if view then
		PopupViewController:addPopupInView(view)
	end
end

function guiCommonLocal.openDragonBattleUpdateView()
	local params = {}
    params.title = getLang("140773")
    params.info =  getLang("140774")
    local view = Drequire("game.DressIntroduction.CommonInfoViewNew"):create(params)
    PopupViewController:addPopupView(view)
end

function guiCommonLocal.openDragonPlayoffUpdateView()
    local view = Drequire("game.dragonBattle.DragonPlayoffRecordView"):create()
    PopupViewController:addPopupView(view)
end

function guiCommonLocal.openDragonBattlePlayOffRewardView()
	local view = Drequire("game.dragonBattle.DragonBattlePlayOffRewardView"):create()
	if view then 
		PopupViewController:addPopupInView(view) 
	end
end

function guiCommonLocal.openDragonBattlePlayOffRewardViewNew()
	local view = Drequire("game.dragonBattle.DragonBattlePlayOffRewardViewNew"):create()
	if view then 
		PopupViewController:addPopupInView(view) 
	end
end

function guiCommonLocal.addBuildBtnInLua(dict)
	require("game.buildingBtns.BuildingBtnManager").getInstance():addBtn(dict)
end

function guiCommonLocal.addLuaFlyHint(dict)
	require("game.flyHint.FlyHintManager").getManager():enQueue(dict)
end

function guiCommonLocal.getConfigHeight(dict)
	require("game.Mail.MailConfigManager").getManager():getConfigHeight(dict)
end

function guiCommonLocal.getConfigNode(dict)
	require("game.Mail.MailConfigManager").getManager():getConfigNode(dict)
end

function guiCommonLocal.openAllianceResourceView()
	local view = Drequire("game.alliance.AllianceResourceView"):create()
    PopupViewController:addPopupInView(view)
end

function guiCommonLocal.openDragonMinimapView()
	local view = Drequire("game.dragonBattle.DragonBattleMiniMapView"):create()
    PopupViewController:addPopupInView(view)
end

function guiCommonLocal.on_get_act_key_time( dict )
	MyPrint("on_get_act_key_time")
	if nil == dict then
		return
	end

	local key = dict:valueForKey("key"):getCString()
	MyPrint("key ", key)
	local time = LuaActivityController.getInstance():getTimeByKey(key)
	MyPrint("time ", time)
	if time ~= nil then
		dict:setObject(CCString:create(tostring(time)), "time")
	end
end

function guiCommonLocal.on_get_29_boss_resetTime( dict )
	MyPrint("on_get_29_boss_resetTime")
	if nil == dict then
		return
	end
	local key = "S$long_worldboss_icedragon_count"
	local time = LuaActivityController.getInstance():getTimeByKey(key)
	local refreshInterval = LuaActivityController.getInstance():getRealRefreshIntervalByKey(key)
	MyPrint("refreshInterval ", refreshInterval)
	if nil == time or "" == time or "0" == time then
		return
	end
	local now = GlobalData:call("getTimeStamp")
	time = tonumber(time) / 1000
	if time > now then
		MyPrint("behind now")
		dict:setObject(CCString:create(tostring(time)), "time")
		return
	end
	if refreshInterval == nil or refreshInterval == 0 then
		return
	end

	local add = now - time
	local mod = add % refreshInterval
	dict:setObject(CCString:create(tostring(now + refreshInterval - mod)), "time")
	return
end

function guiCommonLocal.open_DailyTaskCommand()
	-- MyPrint("open_DailyTaskCommand")
	-- package.loaded["game.command.OpenDailyTaskCommand"] = nil
	-- local cmd = require("game.command.OpenDailyTaskCommand").create(1)
	-- cmd:send()
end

function guiCommonLocal.open_DailyTaskView()
	MyPrint("open_DailyTaskView")
	package.loaded["game.command.OpenDailyTaskCommand"] = nil
	local cmd = require("game.command.OpenDailyTaskCommand").create(2)
	cmd:send()
end

function guiCommonLocal.on_clickchatmsg( argList )
	MyPrint("on_clickchatmsg ", argList)
	if nil == argList then
		return
	end
	if argList:count() <= 0 then
		return
	end
	local id = argList:objectAtIndex(0):getCString()
	MyPrint("id ",id)
	if id == "57153" then
		onFireEvent("open_ActivityGoldBox")
	elseif id == "57159" then
		onFireEvent("open_ConsumeActivityView")
	elseif id == "9450292" then
		-- 9450292=大家快来给{0}送鲜花吧！
		if argList:count() ~= 2 then
			return
		end
		local uid = argList:objectAtIndex(1):getCString()
		if uid == GlobalData:call("getPlayerInfo"):getProperty("uid") or uid == "" then
			onFireEvent("open_PlayerFlowerView")
		else
			local dict = CCDictionary:create() 
 		    dict:setObject(CCString:create("GeneralsPopupView"), "name")
 		    dict:setObject(argList:objectAtIndex(1), "uid")
 		    LuaController:call("openPopViewInLua", dict)
		end
	end
end

function guiCommonLocal.on_get_libao_data(  )
	MyPrint("on_get_libao_data")
	-- 服务器新排序机制
	LiBaoController.getInstance():getExchangeDataRefersh()
end

function guiCommonLocal.funNoFinishIconFlag(dict)
	local flag = DailyTaskController.getInstance():getNoFinishIconFlag()
	MyPrint("funNoFinishIconFlag",flag)
	dict:setObject(CCBool:create(flag), "ret")
end

function guiCommonLocal.on_open_AvatarView_fromchat_1( ... )
	myRequire("game.avatar.AvatarView")
	local view = AvatarView.create()
	view:call("setCallbackNative" , true)
	view:call("setCallbackViewName" , "AvatarView")
	PopupViewController:call("addPopupInView", view)
end

function guiCommonLocal.on_open_AvatarView_fromchat_0( ... )
	myRequire("game.avatar.AvatarView")
	local view = AvatarView.create()
	view:call("setCallbackNative" , false)
	view:call("setCallbackViewName" , "AvatarView")
	PopupViewController:call("addPopupInView", view)
end

function guiCommonLocal.on_createTotemBounder( dict )
	if nil == dict then
		return
	end
	local range = dict:objectForKey("range"):getValue()
	
	local node = myRequire("game.Totem.TotemRange").new(range)
	dict:setObject(node, "rangeNode")
end

function guiCommonLocal.open_NewEquipListView(ref)
	if not ref then return end
	local WeapType = ref:valueForKey("WeapType"):intValue()
	local view = require("game.equipment.NewEquip.NewEquipListView"):create(WeapType)
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.open_NewSuitListView(  )
    local view = Drequire("game.equipment.NewEquip.NewSuitListView"):create()
    PopupViewController:addPopupInView(view)
end

function guiCommonLocal.open_NewEquipView(  )
	local vipView = Drequire("game.equipment.NewEquip.NewEquipMainView"):create()
	PopupViewController:addPopupInView(vipView)
end

function guiCommonLocal.open_RaceSettingView()
	local view = Drequire("game.civilization.raceSetting.RaceSettingView_new"):create()
	PopupViewController:addPopupView(view)
end

function guiCommonLocal.onGetCivilizationBuildCCBName( dict )
	local ccbName = CivilizationController:getBuildingCCBName()
	dict:setObject(CCString:create(ccbName), "ccbName")
end

function guiCommonLocal.open_ChangeNickNameView_fromchat_1(ref)
	if not ref then return end
	local uuid = ref:valueForKey("uuid"):getCString()
	local guide = false
	if ref:valueForKey("guide") then
		guide = ref:valueForKey("guide"):boolValue()
	end
	local view = require("game.role.ChangeNickNameView"):create(uuid, guide)
	view:call("setCallbackNative" , true)
	view:call("setCallbackViewName" , "ChangeNickNameView")
	PopupViewController:addPopupView(view)
end

function guiCommonLocal.on_open_alliance_boss(  )
	PopupViewController:call("addPopupInView", myRequire("game.allianceBoss.AllianceBossView").create()) 
end

function guiCommonLocal.open_ChangeNickNameView_fromchat_0(ref)
	if not ref then return end
	local uuid = ref:valueForKey("uuid"):getCString()
	local guide = false
	if ref:valueForKey("guide") then
		guide = ref:valueForKey("guide"):boolValue()
	end
	local view = require("game.role.ChangeNickNameView"):create(uuid, guide)
	view:call("setCallbackNative" , false)
	view:call("setCallbackViewName" , "ChangeNickNameView")
	PopupViewController:addPopupView(view)
end

function guiCommonLocal.open_DmmGoldInfoView(dict)
	local view = Drequire("game.CommonPopup.DmmGoldInfoView"):create(dict)
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.setAntiAddictionData(dict)
	local isAddict = false
	local isAuth = true
	local realName = 0
	local dc = DataController

	if dict then
		local pf = dict["platform"]
		if pf ~= nil then
			if "android" == pf then
				if dict["isAddict"] ~= nil then
					isAddict = dict["isAddict"]
				end
				if dict["isAuth"] ~= nil then
					isAuth = dict["isAuth"]
				end
				dc.isAddict = isAddict
				dc.isAuth = isAuth
			elseif "ios" == pf then
				if dict["realName"] ~= nil then
					realName = tonumber(dict["realName"])
				end
				dc.realName = realName
			end
		end
	end
	print("AntiAddictionData: isAddict/isAuth/realName=", isAddict, isAuth, realName)
end

function guiCommonLocal.setLoginDataInfo(dict, newKey)
	if newKey == "lordInfo" then
		local obj = dict:objectForKey("init_time")
		if obj then
			ToNewServerController.getInstance():setInitTime(obj:getCString())
		end
	end
end

--------------ZT专用，嘿嘿，避免冲突 Start----------------------
function guiCommonLocal.onNewbeeCastleEvent(data, newKey)
	-- if NewbeeCastleController == nil then
	-- 	NewbeeCastleController = Drequire("game.activity.NewbeeCastle.NewbeeCastleController").new()
	-- end
	NewbeeCastleController:fireCommonEvent(newKey, data)
end

function guiCommonLocal.onPayUserRewardEvent(data, newKey)
	if UserRewardController == nil then
		UserRewardController = Drequire("game.activity.UserReward.UserRewardController").new()
	end
	UserRewardController:fireCommonEvent(newKey, data)
end

function guiCommonLocal.onShowRechargeFeedBack(data)
	dump(data, "onShowRechargeFeedBack dat is: ")
    local view = Drequire("game.LiBao.RechargeFeedBack.RechargeFeedBackView").create(data)
    if view then
    	PopupViewController:call("addPopupView", view)
    else
	    local view = Drequire("game.LiBao.RechargeFeedBack.RechargeFeedBackDefaultView").create(data)
	    PopupViewController:call("addPopupView", view)
	end
end

function guiCommonLocal.onNewRecallEvent(data, newKey)
	NewRecallController:fireCommonEvent(newKey, data)
end

function guiCommonLocal.onCivilizationEvent(data, newKey)
	CivilizationController:fireCommonEvent(newKey, data)
end

function guiCommonLocal.onGetPrestigeDonateTipsTime(dict)
	local donateTime = CivilizationController:getPrestigeDonateTime()
	dict:setObject(CCString:create(donateTime), "donateTime")
	return donateTime
end

function guiCommonLocal.onCreateDragonFeature(dict)
	local NewDragonFunc = Drequire("game.NewDragon.NewDragonFunc")
	local DragonSkinManager = Drequire("game.NewDragon.DragonSkin.DragonSkinManager")
	local data = dictToLuaTable(dict)	
	local dragon3dModel
	if data.skinId and data.skinId ~= "" then
		dragon3dModel = DragonSkinManager:getSkinSpineModel(data.skinId,data.width,data.actionName,data.pro)
	else
		dragon3dModel = NewDragonFunc.getDragonTexture(data.baseId, data.actionName, data.width, data.pro)
	end
	
	if dragon3dModel then
		dict:setObject(dragon3dModel, "3dModel")
	end
	return dragon3dModel
end

function guiCommonLocal.onGetDragonAvatarFeature(dict)
	local DragonSkinManager = Drequire("game.NewDragon.DragonSkin.DragonSkinManager")
	DragonSkinManager:setSkinBaseInfo(dict)
end

function guiCommonLocal.open_luckyDay_View(dict)
	dump("open_luckyDay_View dict is: ")
	local luckyType = dict.luckyType

	if luckyType == 10 then
		-- 龙升级幸运日
		local dragonInfo = DragonController:call("getActiveDragonInfo")
		if nil == dragonInfo then
			--跳转到龙列表
			if CCCommonUtilsForLua:isFunOpenByKey("dragon_new_ui_switch") then
				local view = Drequire("game.NewDragon.NewDragon_V2.DragonListNewView"):create()			
				PopupViewController:call("addPopupInView", view)
			else
				local DragonList_New = myRequire("game.NewDragon.DragonList_New")
				local view = DragonList_New:create()
				PopupViewController:call("addPopupInView", view) 
			end
			return
		end
		if CCCommonUtilsForLua:isFunOpenByKey("dragon_new_ui_switch") then
			local view = Drequire("game.NewDragon.NewDragon_V2.DragonListNewView"):create()			
			PopupViewController:call("addPopupInView", view)
			if nil ~= view then					
				local dragonView = view:openDragonViewByUuid(dragonInfo:call("getUuid"),dragonInfo:call("getBaseId"))
				if nil ~= dragonView then
					dragonView:onClickInformation()
				end
			end
		else
			local view = Drequire("game.NewDragon.DragonCave_New"):create({uuid = dragonInfo:call("getUuid")})
			if nil ~= view then
				view:onClickInformation()
			end
			PopupViewController:call("addPopupInView", view)
		end
	end
end

function guiCommonLocal.onCivFortressEvent(dict, newKey)
	CivFortressController:fireCommonEvent(newKey, dict)
end

-- 【Awen】文明堡垒分城
function guiCommonLocal.onCivFortress2Event(dict, newKey)
	CivFortress2Controller:fireCommonEvent(newKey, dict)
end

function guiCommonLocal.onWorldControllerEvent(dict, newKey)
	LuaWorldController:fireCommonEvent(newKey, dict)
end

function guiCommonLocal.onActivityPageController(dict, newKey)
	ActivityPageController:fireCommonEvent(newKey, dict)
end

function guiCommonLocal.onPlayerInfoController(dict, newKey)
	PlayerInfoController:fireCommonEvent(newKey, dict)
end

function guiCommonLocal.onAvatarCommonEvent(dict, newKey)
	require("game.avatar.AvatarController")
	AvatarController:getInstance():fireCommonEvent(newKey, dict)
end

function guiCommonLocal.onNewLoadingEvent(dict)
	local parent = dict:objectForKey("loadingLayer")
	local loadingui_id = dict:objectForKey("loadingui_id"):getCString()
	local result = Drequire("game.loading.newLoadingView"):create(parent, loadingui_id)
	if not result then
		local civType = math.random(0, 3)
		myRequire("game.loading.loading_" .. tostring(civType) .. ".loadinguiPlus")
		return loadingui:create(parent)
	end
end

function guiCommonLocal.openCrossBattleStatusView(dict)
	local uid = ""
	if dict and dict.uid then
		uid = dict.uid
	end
	local view = Drequire("game.role.RoleCrossbattleStatusView").create(uid)
	PopupViewController:call("addPopupView", view)
end

function guiCommonLocal.getUserSettingSwitch(dict)
	local switchKey = dict:objectForKey("switchKey"):getCString()

	-- local result = Drequire("game.setting.UserSettingController").getUserSettingByKey(switchKey)
	local result = UserSettingController.getUserSettingByKey(switchKey)
	local value = result and "1" or "0"
	dict:setObject(CCString:create(value), "result")
end

function guiCommonLocal.onActivityDataEvent(dict, newKey)
	ActivityController.getInstance():fireActivityEvent(newKey, dict)
end
--------------ZT专用，嘿嘿，避免冲突 Ended----------------------
	
function guiCommonLocal.open_FlowerRank( )
    local prlvPath = "game.rank.PlayerRankListView"
    local PlayerRankListView = Drequire(prlvPath)
    PopupViewController:call("addPopupInView", PlayerRankListView:create(7))
end 

function guiCommonLocal.open_HeroGetRotate( )
    local prlvPath = "game.hero.NewUI.HeroGetRotateView"
    local view = Drequire(prlvPath)
    PopupViewController:call("addPopupInView", view:create("89699","hero_type"))
end 

-- 英雄抽卡
function guiCommonLocal.onHeroLuckDraw(dict, newKey)
	MyPrint("guiCommon2:onHeroLuckDraw")
    HeroLuckDrawController:fireCommonEvent(newKey, dict)
end

--龙商店
function guiCommonLocal.open_DragonShop( )
    local prlvPath = "game.dragon.DragonShopView"
    local view = Drequire(prlvPath)
    PopupViewController:call("addPopupInView", view:create())
end 

function guiCommonLocal.ActivityListView_New()
    local viewPath = "game.activityCenter.ActivityListView_New"
    local view = Drequire(viewPath)
    PopupViewController:call("addPopupInView", view:create())
end

--------------SHP专用，嘿嘿，避免冲突 Start----------------------
function guiCommonLocal.openDragonGlobalManagerView()
	local managerView = require("game.dragonWorldCup.DragonWorldCupManagerView"):create(true)
	PopupViewController:addPopupInView(managerView)
end

function guiCommonLocal.openDragonWorldCupHallOfFameView()
	MyPrint("openDragonWorldCupHallOfFameView")
	local lua_path = "game.dragonWorldCup.hallOfFame.DragonWorldCupHallOfFameView"
	package.loaded[lua_path] = nil
	local view = require(lua_path):create()
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.openNewDragonVictoryView(param)
	if not param then return end

	local marchData = dictToLuaTable(param)
	local lua_path = "game.dragonWorldCup.DragonWorldCupVictoryView"
	package.loaded[lua_path] = nil
	local view = require(lua_path):create(marchData)
	PopupViewController:addPopupView(view, false, false)
end

function guiCommonLocal.openChooseItemView(ref)
	if not ref then return end

	local str = tolua.cast(ref, "CCString")
	if str then
		local itemId = tonumber(str:getCString())
		if CCCommonUtilsForLua:isFunOpenByKey("optional_box_2") then
			local lua_path = "game.CommonPopup.NewSelectInNView"
			local view = Drequire(lua_path):create(itemId)
			PopupViewController:addPopupView(view)
		else
			local lua_path = "game.CommonPopup.SelectInNView"
			local view = Drequire(lua_path):create(itemId)
			PopupViewController:addPopupView(view)
		end
	end
end

function guiCommonLocal.openRewardBoxShowView(ref)
	if not ref then return end

	local str = tolua.cast(ref, "CCString")
	if str then
		local itemId = tonumber(str:getCString())

		local lua_path = "game.CommonPopup.RewardBoxShowView"
		--package.loaded[lua_path] = nil
		local view = Drequire(lua_path):create(itemId)
		PopupViewController:addPopupView(view)
	end
end

function guiCommonLocal.openCrossThroneEntryView()
	local view = Drequire("game.crossThrone.CrossThroneEntryView"):create()
	if view then
		PopupViewController:addPopupInView(view)
	end
end

function guiCommonLocal.openCrossThroneWorldView()
	local worldView = Drequire("game.crossThrone.CrossThroneWorldView"):create()
	if worldView then
		PopupViewController:addPopupInView(worldView)
	end
end

function guiCommonLocal.openCrossThroneBuffView(ref)
	if not ref then return end

	local battleType = ref:valueForKey("battleType"):intValue()
	local buffView = Drequire("game.crossThrone.CrossThroneBuffView"):create(battleType)
	PopupViewController:addPopupInView(buffView)
end

function guiCommonLocal.reqCrossThroneBattleRank()
	require("game.crossThrone.CrossThroneManager"):requestBattleRankData()
end

function guiCommonLocal.openCrossThroneHonorView()
	if DynamicResourceController2:call("checkDynamicResource", "crossThrone_face") then
		CCLoadSprite:call("loadDynamicResourceByName", "crossThrone_face")
		local view = Drequire("game.crossThrone.CrossThroneHonorView"):create()
		if view then
			PopupViewController:addPopupInView(view)
		end
	else
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("E100091"))
	end
end

--跨服王座操作
function guiCommonLocal.crossThroneOperation(dict)
	require("game.crossThrone.CrossThroneManager"):operation(dict)
end

function guiCommonLocal.addDespotBuildSwitch(vm)
	if vm then
		local world = WorldMapView:call("instance")
		if world and world.addDespotBuildSwitch then
	    	world:addDespotBuildSwitch(vm.cityIndex, vm.switch)
		end
	end
end
--------------SHP专用，嘿嘿，避免冲突 End----------------------

function openChapterAni()
	if ChapterController:getInstance().m_StoryIsOver  == true then 
		return 
	end
	ChapterController.getInstance():openChapterView()
end

--【Awen】检查章节任务是否开启
function guiCommonLocal.onChapterEvent(data, newKey)
	ChapterController.getInstance():fireEventRef(newKey, data)
end

function onOpenReportNickName(dict)
	local tmp = dictToLuaTable(dict)
	dump(tmp,"onOpenReportNickName")
	local view  =  require("game.Nickname.NicknameView"):create(tmp.uid,tmp.time,tmp.defname)
	PopupViewController:call("addPopupView", view)
end

function getCivPrestigeNameByLevel(dict)
	local level = dict:objectForKey("level")
	level = tolua.cast(level, "CCInteger")
	level = level:getValue()
	MyPrint("getCivPrestigeNameByLevel level:",level)
	local name = CivilizationController:getCivPrestigeNameByLevel(level)
	dict:setObject(CCString:create(name),"name")
	return name
end

function getCivPresigeLevelByType(dict)
	local type = dict:objectForKey("type")
	type = tolua.cast(type, "CCInteger")
	type = type:getValue()
	local level = CivilizationController:getCivPresigeLevelByType(type)
	dict:setObject(CCString:create(level),"curLevel")
	return level
end

function getCivilizationNameByType(dict)
	local type = dict:objectForKey("type")
	type = tolua.cast(type, "CCInteger")
	type = type:getValue()
	local name = CivilizationController:getCivilizationNameByType(type)
	dict:setObject(CCString:create(name),"civiName")
	return name
end

function getIconNameByLevel(dict)
	local level = dict:objectForKey("level")
	level = tolua.cast(level, "CCInteger")
	level = level:getValue()
	local icon = CivilizationController:getIconNameByLevel(level)
	dict:setObject(CCString:create(icon),"icon")
	return icon
end

function onHeroGarrisonViewNew(  )
	local view = Drequire("game.hero.NewHeroGarrison.HeroGarrisonView_new"):create()
	PopupViewController:addPopupInView(view)
end

function openAllStoreView(  )
	local view = Drequire("game.shop.AllStoreView"):create()
	PopupViewController:addPopupInView(view)
end

function open_PermitView()
	-- local tmp = dictToLuaTable(dict)
	-- dump(tmp,"onOpenReportNickName")
	-- local view  =  require("game.Nickname.NicknameView"):create(tmp.uid,tmp.time,tmp.defname)
	local view  =  require("game.setting.PermitView"):create()
	PopupViewController:call("addPopupView", view)
end

function open_SetupUsernameLockView( )
	local view = Drequire("game.UsernameLock.SetupUsernameLockView"):create()
	PopupViewController:addPopupView(view)
end

function open_CancelUsernameLockView( )
	local view = Drequire("game.UsernameLock.CancelUsernameLockView"):create()
	PopupViewController:addPopupView(view)
end

function open_CrownMainView( )
	if FunBuildController:call("getMainCityLv") < 15  then
		CCCommonUtilsForLua:call("flyHint", "", getLang("5600191"))
		return
	end
	local isInit = require("game.crown.CrownManager").isInit
	if require("game.crown.CrownManager").crown_list == nil  then -- not isInit
		CCCommonUtilsForLua:call("flyHint", "", getLang("5600192"))
		return
	end
	local view = nil 
	if require("game.crown.CrownManager").isNewCrown() then 
		view = Drequire("game.crown.CrownTopView"):create()
	else
		view = Drequire("game.crown.CrownMainView"):create(1)
	end
	PopupViewController:addPopupInView(view)
end

function getDailyTaskNode(dict )
	local view = require("game.Tavern.DailyTaskView"):create()
	dict:setObject(view,"dailytask")

end

function open_NewMerchantView(dict )
    local view = Drequire("game.CommonPopup.Merchant.NewMerchant.NewMerchantView"):create()
    PopupViewController:addPopupInView(view)
end

function open_ArmyUpgradeView(dict )
	local sourceArmyId = dict:valueForKey("sourceArmyId"):getCString()
    local view = Drequire("game.armyUpgrade.armyUpgradeView"):create(sourceArmyId)
	PopupViewController:addPopupInView(view)
end

function open_UseMultySpeedView(dict )
	local useTag = dict:valueForKey("useTag"):getCString()
	local timeCost = dict:valueForKey("timeCost"):getCString()
    local view = Drequire("game.CommonPopup.UseMultySpeedView"):create(useTag, timeCost)
	PopupViewController:addPopupView(view)
end

function open_MagicDrawView(dict )
    local view = Drequire("game.magic.LuckDraw.MagicLuckDrawView").create()
    PopupViewController:call("addPopupInView", view)
end

function open_MagicBookView(dict )
    local view = Drequire("game.magic.book.MagicBookView").create()
    PopupViewController:call("addPopupInView", view)
end

function open_PermitChooseView(dict )
    local view = Drequire("game.setting.PermitChooseView"):create()
    -- PopupViewController:addPopupView(view)
end

function open_PermitViewForEUView(dict )
    local view = Drequire("game.setting.PermitViewForEU"):create()
    -- PopupViewController:addPopupView(view)
end

function open_PermitDisaViewForEUView(dict )
    local view = Drequire("game.setting.PermitDisapprovalViewForEU"):create()
    -- PopupViewController:addPopupView(view)
end

--拍卖行
function open_AuctionHouseView( dict )
	local cross = GlobalData:call("getPlayerInfo"):getProperty("crossFightSrcServerId")
    dump(cross,"open_AuctionHouseView cross+++")
    if cross and cross ~= -1 then
        if cross then dump(cross,"cross+++") end
        LuaController:flyHint("", "", getLang("9440926"))   --跨服状态,不能开启拍卖行
        return 
    end

	--先获取数据，活动不开启，inActivity=0
	AuctionHouseController:pullAuctionHouseViewData()
end

function dumpDict( dict )
	local tbl = dictToLuaTable(dict)
    dump(tbl,"dumpDict", 10)
end

function guiCommonLocal.onOpen_FangJianBeiView(dict)
	dump("onOpen_FangJianBeiView | begin")

	local FangJianBeiView = Drequire("game.FangJianBei.FangJianBeiView")

	local view = FangJianBeiView:create()

	PopupViewController:addPopupInView(view)
	
	dump("onOpen_FangJianBeiView | end")
end


function getCivilizationIconByType( dict )
	local tbl = dictToLuaTable(dict)
	local icon_file = "CivilizationRace_1.png"
	if tbl.civilization_type == 2 then
		icon_file = "CivilizationRace_2.png"
	elseif tbl.civilization_type == 3 then
		icon_file = "CivilizationRace_3.png"
	elseif tbl.civilization_type == 4 then
		icon_file = "CivilizationRace_4.png"
	end
	dict:setObject(CCString:create(icon_file),"icon")
end

function open_EquipmentRecastView( dict )
	-- local uuid = dict:objectForKey("uuid")
	
	local uuid = dict:valueForKey("uuid"):getCString()
	local view = Drequire("game.equipment.NewEquip.EquipmentRecastView"):create(uuid)
	PopupViewController:addPopupInView(view)
end


function open_GoodsRewardListView( dict )
	local rewardVec = string.split(dict:valueForKey("rewardId"):getCString(), "|")
	local rewardId = rewardVec[1]
	local rwd = GlobalData:call("getCachedRewardData", rewardId)
    local rwdData = arrayToLuaTable(rwd)

    if #rwdData == 0 then
	    GlobalData:call("checkAndRequestRewardData", rewardId)
    end
    local titleName
    if #rewardVec < 2 then  
	    titleName = getLang("9200246")
	else
		if tonumber(rewardVec[2]) == 0 then 
			titleName = getLang("9200246")
    	else 
    		titleName = getLang("9200247")
    	end
    end
	local view = Drequire("commonView.RewardListShowView"):create({rewardId = rewardId, reward = rwdData, btnName = getLang("101274"), titleName = titleName})
	PopupViewController:addPopupView(view)
end

function guiCommonLocal.onOpen_OneRechargeView()

	local act = ActivityController:call("getActObj", "57190")
	if act and act:getProperty("endTime") then
		local now = LuaController:call("getWorldTime")
		if now >= act:getProperty("endTime") then
			LuaController:flyHint("","",getLang("102517"))
			return false
		end
	else
		LuaController:flyHint("","",getLang("102517"))
		return false
	end

	local view = Drequire("game.activity.OneRecharge.OneRechargeView"):create()
	PopupViewController:addPopupInView(view)
end

-- 建造界面
function guiCommonLocal.onOpen_TerritoryHospitalPopupView (dict)
	local TerritoryHospitalPopupView = Drequire("game.allianceTerritory.TerritoryHospitalPopupView")
	dump(dict, 'onOpen_TerritoryHospitalPopupView')
	local view = TerritoryHospitalPopupView.create(dict.point)
	PopupViewController:call("addPopupView", view)
end

function guiCommonLocal.onOpen_AllianceHospitalPopupView (dict)
	local AllianceHospitalPopupView = Drequire("game.allianceTerritory.AllianceHospitalPopupView")
	MyPrint('onOpen_AllianceHospitalPopupView', dict)
	local view = AllianceHospitalPopupView.create(dict.uid, dict.point)
	PopupViewController:call("addPopupInView", view)
end

function guiCommonLocal.on_sendAllianceHospitalCancelCmd (dict)
	Drequire("game.allianceTerritory.AllianceHospitalCmd")('cancel', dict):send()
end

function guiCommonLocal.onOpen_AllianceHospitalTreatPopupView ()
	local AllianceHospitalTreatPopupView = Drequire("game.allianceTerritory.AllianceHospitalTreatPopupView")
	MyPrint('onOpen_AllianceHospitalTreatPopupView')
	local view = AllianceHospitalTreatPopupView.create()
	PopupViewController:call("addPopupInView", view)
end

function guiCommonLocal.on_AllianceHospitalCureFinish (tbl)

	Drequire("game.allianceTerritory.AllianceHospitalController")
	--MyPrint('on_AllianceHospitalCureFinish', tbl.quid)
	local ctl = AllianceHospitalController.getInstance()
	ctl:cureFinish(tbl.quid)
end

function guiCommonLocal.openPveStartView()
	local view = Drequire("game.Training.PveStartView").create()
	PopupViewController:call("addPopupInView", view)
	MyPrint("openPveStartView")
	-- body
end

local function openPveMapView( )
	local view = Drequire("game.Training.PveMapView").create()
	PopupViewController:call("addPopupInView", view)
end

function guiCommonLocal.createTrainingMapNode( dict)
	local tmp = dictToLuaTable(dict)
	dump(tmp,"createTrainingMapNodes")
	--local node = Drequire("game.Training.PveMapNode"):create(tmp.index)
	local node = Drequire("game.Training.PveMapNode_v2"):create(tmp.index)
	dict:setObject(node,"node")
end
function guiCommonLocal.marchForPve(dict)
	local dataController = require("game.Training.PveDataController")
	PveDataController:getInstance():sendChallengePve(dict)
end

function guiCommonLocal.setPveArmyData(dict)
	local dataController = require("game.Training.PveDataController")
	PveDataController:getInstance():refreshArmInfoInPve(dict)
end
function guiCommonLocal.openHeroList(dict)
	local view = Drequire("game.Training.PveHeroListView"):create()
	PopupViewController:call("addPopupView", view)
end

function guiCommonLocal.refreshStarInfo( dict )
	local PveDataController = require("game.Training.PveDataController")
	local total_star = PveDataController:getInstance().m_totalStar
	dict:setObject(CCString:create(total_star),"total")
end

function guiCommonLocal.createPveMapOver( dict )
------------宝箱奖励部分
--	local  m_belowNode = dict:objectForKey("m_belowNode")
--	local  titleNode   = dict:objectForKey("titleNode")
	--local PveController = require("game.Training.PveController")
	--PveController:getInstance():setRewardInfo(m_belowNode,data)
	--Drequire("game.Training.PveMainBoxNode"):create(m_belowNode,titleNode)

    Drequire("game.Training.HeroPveMainView_v2"):create(dict)
end
function guiCommonLocal.addBuildingOnPve(dict)
	MyPrint("addBuildingOnPve")
	local PveController = require("game.Training.PveController")
	-- PveController:getInstance():getChallenge()
	PveController:getInstance():addSelBuildingfOnMap(dict)

end

function getMapFile(dict)
	local PveController = require("game.Training.PveController")
	PveController:getInstance():getMapFile(dict)
end

function guiCommonLocal.addStarProgressNode( dict)
	local  parent = dict:objectForKey("m_starNode")
	local m_titleTxt =  dict:objectForKey("m_titleTxt")
	local node = Drequire("game.Training.PveLevelProgressNode"):create(parent,m_titleTxt)

end

function guiCommonLocal.clearPveLevel( ... )
	local PveController = require("game.Training.PveController")
	PveController:getInstance():clear()
end

function guiCommonLocal.removePopUpMenu( dict )
	local PveController = require("game.Training.PveController")
	PveController:getInstance():removeTilePopUpMenu()
	-- body
end
function guiCommonLocal.onOpen_ProductionSoldierView(dict)
	if not dict then return end
	local m_buildingKey = tonumber(dict.m_buildingKey)
	--local info_get = dict["1"]
	local lua_path = "game.productionSoldier.ProductionSoldierView"
	package.loaded[lua_path] = nil
	
	local view = require(lua_path):create(m_buildingKey)
	PopupViewController:call("addPopupInView", view)
	if dict.m_armyId ~= nil then
		local m_armyId = tostring(dict.m_armyId)
		local m_needNum = tonumber(dict.m_needNum)
		view:setSoldierIdAndNum(m_armyId,m_needNum)
	end
    --ProductionSoldierController:getInstance():openProductionSoldierView(m_buildingKey)
end

function guiCommonLocal.onOpen_HeroPopupViewForLua(dict)
	local lua_path = "game.newHero.HeroPopupViewForLua"
	package.loaded[lua_path] = nil

	local view = Drequire(lua_path):create()
	PopupViewController:call("addPopupView", view)
end
function guiCommonLocal.getNeutralSaveStatus( dict )
	dict:setObject(CCString:create(NeutralLandManager.neutralSaveStatus), "neutralSaveStatus") 
	return NeutralLandManager.neutralSaveStatus
end

function open_alliance_legend(  )
	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	local allianceInfo = playerInfo:getProperty("allianceInfo")
	local obj = ActivityController:call("getInstance"):call("getActObj", "57235")
	if obj ~= nil then
		local st = obj:getProperty("startTime")
		local et = obj:getProperty("endTime")
		local now = GlobalData:call("getWorldTime")
		MyPrint("open_alliance_legend", st,et,now)
		if now > et or now < st then
			local function fun(  )
		    end
			YesNoDialog:call("show", getLang("160637"), cc.CallFunc:create(fun)) --160637=该联盟活动暂未开启
			return
		end
	end
	AllianceLegendManager.getInstance():getQuestListData()
end

function guiCommonLocal.openDragonTowerRewardsView(dict)
	if nil == dict then
		return
	end
	local view = Drequire("game.dragonTower.DragonTowerRewardsView"):create(dict)
	PopupViewController:call("addPopupView",view)
end

function guiCommonLocal.openDragonTowerRankView()
     local view = Drequire("game.dragonTower.DragonTowerRankList"):create()
     PopupViewController:call("addPopupInView",view)
end

function guiCommonLocal.checkDragonTowerRewardsData()
	local DragonTowerRewardsController = require("game.dragonTower.DragonTowerRewardsController")
	DragonTowerRewardsController.getInstance():initDataFromSever()
end

function guiCommonLocal.on_checkIsInSaveZone( dict )
	local tbl = dictToLuaTable(dict)
	local point = {}
	point.x = tbl.pointX
	point.y = tbl.pointY
	local isSave = NeutralLandManager.checkIsInSaveZone(point)
	dict:setObject(CCBool:create(isSave), "isSave")
	local tbl = dictToLuaTable(dict)
	dump(tbl, "on_checkIsInSaveZone")
	return isSave
end

function guiCommonLocal.on_luckyReturn (dict)
	-- local status = tolua.cast(ref, "CCInteger"):getValue()
	MyPrint('on_luckyReturn')
	local tbl = dictToLuaTable(dict)
	local status = tonumber(tbl.lucky_return)
	local endTime = tonumber(tbl.lucky_return_endTime)
	MyPrint('on_luckyReturn', status, ' ', endTime)
	ToNewServerController.getInstance():setStatus(status, endTime)

	if tbl.invite_times then
		local invite_times = tonumber(tbl.invite_times)
		ToNewServerController.getInstance():setInviteTimes(invite_times)
	end
	return true
end

function guiCommonLocal.get_luckyReturn(dict)
	if not dict then
		return
	end
	local ctl = ToNewServerController.getInstance()
	local now = GlobalData:call("getTimeStamp")
	if ctl.status == 4 and ctl.chooseEndTime >= now then
		dict:setObject(CCString:create("1"), "isLuckyReturn")
	else
		dict:setObject(CCString:create("0"), "isLuckyReturn")
	end
end

function guiCommonLocal.open_select_throne_time(  )
	local view = Drequire("game.NewKingdomWar.NewWarBuildInfo"):create()
	PopupViewController:call("addPopupView", view)
end


function guiCommonLocal.get_kingdom_war_time_str( dict )
	local tbl = dictToLuaTable(dict)
	local timeIndex = tbl.timeIndex
	local timeStr = NewKingdomWarController:getBattleTimeStr(timeIndex)
	MyPrint('get_kingdom_war_time_str', timeStr)
	dict:setObject(CCString:create(timeStr), "timeStr")
	return timeStr
end

function guiCommonLocal.onOpen_PlayerFlowerViewForLua( dict )
	local tbl = dictToLuaTable(dict)
	-- dump(tbl, "@@onOpen_PlayerFlowerViewForLua")
	local view = Drequire("game.player.FlowerGetPopupView"):create(tbl)

	if view and not GuideController:call("share"):call("isInTutorial") then 
		local popupController = PopupViewController:call("getInstance")
		if tonumber(popupController:call("getCurrViewCount")) == 0 and not popupController:call("getPrincessShow") then
			popupController:call("addPopupView", view)
		else
			popupController:call("pushPop", view, true)
		end
	end
end

function guiCommonLocal.postIsHeroUnlockInList( dict )
	local HeroManager = require("game.hero.HeroManager")
	HeroManager.postIsHeroUnlockInList(dict)
end
function guiCommonLocal.open_TreasureFamActivityView(  )
    local mlv = FunBuildController:call("getMainCityLv") -- 玩家主城等级
    if mlv < TreasureFamManager.m_castleLimit then
        local function fun(  )
        end
        YesNoDialog:call("show", getLang("160639", TreasureFamManager.m_castleLimit), cc.CallFunc:create(fun)) --160639=该活动需要您的城堡到达{0}以上
    else
        local view = Drequire("game.TreasureFam.TreasureFamMainView"):create()
        PopupViewController:call("addPopupInView", view)
    end
end
function guiCommonLocal.setTreasureFamMonsterArmyData( dict )
	dict:setObject(CCString:create(TreasureFamManager.m_monsterSoldiersStr), "armyStr")
	dict:setObject(CCString:create(TreasureFamManager.m_monsterMarchLimit), "armyLimit")
end
function guiCommonLocal.marchForTreasureMonster( dict )
	TreasureFamManager:marchForTreasureMonster(dict)
end
function guiCommonLocal.marchForTreasureMine( dict )
	TreasureFamManager:marchForTreasureMine(dict)
end
function guiCommonLocal.openCacheBattleWin( dict )
	
	local PveController = require("game.Training.PveController")
	PveController:getInstance():openCacheBattleWin()
end

function guiCommonLocal.checkAbortReport( dict ) --战报为C++ cmd 返回消息后打开 有可能延迟，如果LUA 界面已经关闭。 就没必要再打开战报界面
	local PveController = require("game.Training.PveController")
	PveController:getInstance():chenkAbortBattleReport(dict)
end

--每月签到
function guiCommonLocal.onOpen_integrateSignInView()
	local view = Drequire("game.WelfareIntegrate.WelfareIntegrateMainView"):create()
	PopupViewController:addPopupInView(view)
end

-- 全服名人录
function guiCommonLocal.onOpen_FamousRank()
	local view = Drequire("game.activity.AllServerRank.AllServerRankView"):create()
	if view then
		PopupViewController:addPopupInView(view)
	end
end

-- 【awen】获取当前是否有进阶龙
function guiCommonLocal.onDragonConfig( data, newKey )
	require('game.NewDragon.DragonConfig'):onDragonConfig(newKey, data)
end

-- 【Awen】士兵进阶
function guiCommonLocal.onArmyUp( data, newKey )
	require('game.army.ArmyController'):fireEventRef(newKey, data)
end

-- 【Awen】视频广告
function guiCommonLocal.onAdVideo( data, newKey )
	require("game.controller.LuaAdController").getInstance():fireEventRef(newKey, data)
end

-- 【Awen】新加速
function guiCommonLocal.onUseSpeedUp( data, newKey )
	require("game.speedup.UseSpeedUpController").getInstance():fireEventRef(newKey, data)
end

-- hxq士兵技能转化
function guiCommonLocal.openGlory6SkillChangeView()
	local view = Drequire("game.Glory6.Glory6SkillChangeView"):create()
	if view then
		PopupViewController:addPopupInView(view)
	end
end
--hxq 打开四周年赠送道具界面
function guiCommonLocal.openFourthAnniversaryGiftView(data)
	if nil == data then
		return
	end
	local itemId = tonumber(data["itemId"])
	local FourthAnniversaryBlessData = require("game.activity.FourthAnniversary.FourthAnniversaryBlessData").getInstance()
	FourthAnniversaryBlessData:checkSendGiftCondition(itemId)
end
--hxq 打开四周年集画活动界面
function guiCommonLocal.openFourthAnniversaryBlessView()
	local FourthAnniversaryBlessData = require("game.activity.FourthAnniversary.FourthAnniversaryBlessData").getInstance()
	if FourthAnniversaryBlessData:isActiveOpen() then
		local view = Drequire("game.activity.FourthAnniversary.FourthAnniversaryView"):create(3)
		PopupViewController:addPopupView(view)
	else
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("146313"))
	end
end

-- 【Awen】先祖战场
function guiCommonLocal.onAncestralTrial( data, newKey )
	local BattlefieldController = require('game.Battlefield.BattlefieldController')
	BattlefieldController.getInstance():fireEventRef(newKey, data)
end

--【Awen】军团降临限时活动
function guiCommonLocal.onTrainingTroopsEvent( data, newKey )
	local TrainingTroopsController = require('game.Training.troops.TrainingTroopsController')
	TrainingTroopsController.getInstance():fireEventRef(newKey, data)
end

-- 文明堡垒限时活动
function guiCommonLocal.onCivilizationTimeLimitedEvent( data, newKey )
	local CivilizationTimeLimitedController = require('game.civilization.CivilizationTimeLimited.CivilizationTimeLimitedController')
	CivilizationTimeLimitedController.getInstance():fireEventRef(newKey, data)
end

--【Awen】王者之路
function guiCommonLocal.onKingRoad( data, newKey )
	local KingRoadController = require('game.WelfareIntegrate.kingRoad.KingRoadController')
	KingRoadController.getInstance():fireEventRef(newKey, data)
end

-- 【Awen】引导打开view
function guiCommonLocal.onLuaViewForGuide( data, newKey )
	Dprint("guiCommonLocal.onLuaViewForGuide", newKey)
	if newKey == "openChapterIntro" then	--打开章节介绍（黑屏白字）
		ChapterController.getInstance():openChapterIntroView(data)
	elseif newKey == "openChapterView" then	--打开章节界面
		ChapterController.getInstance():openChapterView()
	elseif newKey == "openMainCityUpResult" then	--打开建造升级结果界面
		local view = Drequire("game.buildingUpView.MainCityUpResultView").create(data)
		PopupViewController:call("addPopupView", view)
	elseif newKey == "openRaceSettingView" then		--打开选择文明界面
		local showType = "1"
		if data then
			showType = data:valueForKey("para"):getCString()
		end
		CivilizationController:fireCommonEvent("openRaceSettingView", CCInteger:create(showType))
	elseif newKey == "openShowChapterIcon" then	--显示章节入口图标
		CCSafeNotificationCenter:postNotification("UiCompoentLuaLayer:animChapter")
	elseif newKey == "openHideChapterIcon" then	--隐藏章节入口图标
		CCSafeNotificationCenter:postNotification("UiCompoentLuaLayer:animHideChapter")
	elseif newKey == "openKingRoadDialog" then	--打开王者之路引导对话框
		local KingRoadController = require('game.WelfareIntegrate.kingRoad.KingRoadController')
		KingRoadController.getInstance():fireEventRef("openDialog")
	end
end

--【Awen】装扮图鉴
function guiCommonLocal.onDressIntroduction( data, newKey )
	DressIntroductionController:fireEventRef(newKey, data)
end

-- 分享
function guiCommonLocal.openCommonShareView(dict)
	local tbl = dictToLuaTable(dict)
	local shareType = tbl.shareType
	local shareId   = tbl.shareId
	local shareLink = tbl.shareLink
	local callback  = tbl.callback
	local shareTag  = tbl.shareTag
	local view = Drequire("game.CommonPopup.CommonShareView"):create(shareType, shareId, shareLink, callback, shareTag)
	PopupViewController:addPopupView(view)
end

function guiCommonLocal.openDragonNodeIcons(dict)
	local node = dict:objectForKey("node")
	local view = Drequire("game.NewDragon.NewDragon_V2.DragonNodeIcons"):create(dict)
	node:addChild(view)
end

function guiCommonLocal.openActivityDayMakexxxSendGiftView(data)
	dump(data, "openActivityDayMakexxxSendGiftView+++0")
	if data then
		local para1 = CCCommonUtilsForLua:call("getPropByIdGroup", "goods", data["itemId"], "para1")
		local tbl = string.split(para1,";")
		require("game.FestivalActivities.FestivalActivitiesMakexxxController").getInstance():openMailWriteByStoreBagView(data.itemId,tbl[2])
	end
end

function guiCommonLocal.onProcessSndGiftMailInLua(dict)
	local data = dictToLuaTable(dict)
	require("game.FestivalActivities.FestivalActivitiesMakexxxController").getInstance():sendGiftMail(data)
end

function guiCommonLocal.openActivityDayMakexxxView(data)
	dump(data, "openActivityDayMakexxxView+++")
	local para1 = CCCommonUtilsForLua:call("getPropByIdGroup", "goods", tostring(data.itemId), "para1")
	local tbl = string.split(para1,";")
	require("game.FestivalActivities.FestivalActivitiesHelper").openFestivalView(tbl[1],tbl[2])
end

function guiCommonLocal.open_UserLockedView()
	local view = Drequire("game.UsernameLock.UserLockedView"):create()
	PopupViewController:addPopupView(view)
end

function guiCommonLocal.open_EquipmentRankView()
	local view = Drequire("game.equipment.EquipRank.EquipmentInfoView"):create()
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.open_HeroRecruitRankView()
	local view = Drequire("game.hero.NewUI_v2.HeroRecruitRankView"):create()
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.open_ShuaHaoPingView(  )
	local view = Drequire("game.ShuaHaoPing.ShuaHaoPingView"):create()
	PopupViewController:addPopupView(view)
end

function guiCommonLocal.send_ChaPingCmd(dict)
	local comment = dict:valueForKey("comment"):getCString()
	local sendType = dict:valueForKey("type"):intValue()
	local cmd = Drequire("game.ShuaHaoPing.ShuaHaoPingCmd").create(comment, sendType)
	cmd:send()
end

function guiCommonLocal.open_longjingInfoView( dict )
	local uuid = dict:valueForKey("uuid"):getCString()
	local view = Drequire("game.longjing.LongjingInfoView"):create(uuid)
	PopupViewController:addPopupView(view)
end

function guiCommonLocal.open_CrystalGetRotate( ) --水晶转盘
    local view = Drequire("game.hero.NewUI.HeroGetRotateView"):create("89698","crystal_type")
    PopupViewController:call("addPopupInView", view)
end 

function guiCommonLocal.open_EquipmentUpgradeView( dict ) --装备强化
	local uuid = dict:valueForKey("uuid"):getCString()
	local view = Drequire("game.equipment.EquipmentUpgrade.EquipmentStrengthView"):create(uuid)
	PopupViewController:addPopupView(view)
end

--幸运回归，小公主首弹
function guiCommonLocal.open_LuckyReturnNPCView( )
	local dialog1 = getLang("4249606")
	local dialog2 = getLang("4249607")
	local dialogs = {dialog1,dialog2}
	if LuaNpcTalkView == nil then
		require("game.CommonPopup.LuaNpcTalkView")
	end
	local view = LuaNpcTalkView.create(dialogs,0)
	if view ~= nil then
		local function callBack( )
			CCSafeNotificationCenter:postNotification("LuckyReturnNodeIcon.showGuide")
		end
		local showEntrance = cc.UserDefault:getInstance():getBoolForKey("show_lucky_return_entrance", false)
		if not showEntrance then
			cc.UserDefault:getInstance():setBoolForKey("show_lucky_return_entrance", true)
			cc.UserDefault:getInstance():flush()
		end		
		view:setCloseCallBack(callBack)
		PopupViewController:call("addPopupView", view)
	end
end

--王者回归活动玩家开始时间设置
function guiCommonLocal.kingRerutnActivate( dict )
	local actStartTime = dict:valueForKey("actStartTime"):getCString()
	local ctl = ToNewServerController.getInstance()
	ctl:setActStartTimeAndEndTime(actStartTime)
end

function guiCommonLocal.open_SnkLoginView( dict )
	local view = Drequire("game.activity.SNKMetalSlug.SNKLoginView"):create()
	PopupViewController:addPopupView(view)
end 

function guiCommonLocal.get_UicommonentName( dict )
	-- if DynamicResourceController2:call("checkDynamicResource", "SNKUi_face") and CCCommonUtilsForLua:isFunOpenByKey("snk_ui") then
	-- 	dict:setObject(CCString:create("gameUISNK"), "ccbiName")
	-- 	dict:setObject(CCString:create("SNKUi_face"), "dynResName")
	-- 	dict:setObject(CCString:create("BG_SNK_IPXtaitou.png"), "IPXHeadName")
	-- else
	
	--ob 不走节日UI
	if require("game.dragonBattle.DragonBattleOBController").getInstance():isNewOBOpen() then
		dict:setObject(CCString:create("gameUI"), "ccbiName")
		dict:setObject(CCString:create("IPX_mainHead.png"), "IPXHeadName")
	elseif DynamicResourceController2:call("checkDynamicResource", "XmasUi_face") and CCCommonUtilsForLua:isFunOpenByKey("2018_christmas_ui") then
		dict:setObject(CCString:create("gameUIXmas"), "ccbiName")
		dict:setObject(CCString:create("XmasUi_face"), "dynResName")
		dict:setObject(CCString:create("X_quyu.png"), "IPXHeadName")
	elseif DynamicResourceController2:call("checkDynamicResource", "AllSaintsDay_face") and CCCommonUtilsForLua:isFunOpenByKey("all_saints_day_skin") then
		dict:setObject(CCString:create("gameUIAllSaintsDay"), "ccbiName")
		dict:setObject(CCString:create("AllSaintsDay_face"), "dynResName")
		dict:setObject(CCString:create("BG_WSJ_IPXtaitou.png"), "IPXHeadName")
	elseif DynamicResourceController2:call("checkDynamicResource", "Chunjie_ui_face") and CCCommonUtilsForLua:isFunOpenByKey("2019_cnyear_ui") then
		dict:setObject(CCString:create("gameUIChunjie"), "ccbiName")
		dict:setObject(CCString:create("Chunjie_ui_face"), "dynResName")
		dict:setObject(CCString:create("chunjie_UI_2.png"), "IPXHeadName")
	elseif DynamicResourceController2:call("checkDynamicResource", "SNKUi_face") and CCCommonUtilsForLua:isFunOpenByKey("snk_ui") then
		dict:setObject(CCString:create("gameUISNK"), "ccbiName")
		dict:setObject(CCString:create("SNKUi_face"), "dynResName")
		dict:setObject(CCString:create("BG_SNK_IPXtaitou.png"), "IPXHeadName")
	else
		dict:setObject(CCString:create("gameUI"), "ccbiName")
		dict:setObject(CCString:create("IPX_mainHead.png"), "IPXHeadName")
	end
end

function guiCommonLocal.OpenPreInfoView(dict)
	local node = dict:objectForKey("Node")
	if node then
		node:removeChildByTag(666)
		local view = Drequire("game.CommonPopup.OverView.InformationPreview"):create(dict)
		-- PopupViewController:addPopupView(view)
		node:addChild(view)
		view:setTag(666)
	end
end

function guiCommonLocal.getConstId( dict )
	-- ThroneId
	Dprint("getConstId ", ThroneId)
	local tempTbl = dictToLuaTable(dict)
	if tempTbl and tempTbl.constName and tempTbl.constName == "ThroneId" then
		Dprint("getThroneId getString ")
		dict:setObject(CCString:create(tostring(ThroneId)), "constValue")
	end
	dump(dictToLuaTable(dict), "getThroneId tbl")
end

function guiCommonLocal.screenAlarmView( dict )
	local tempTbl = dictToLuaTable(dict)
	dump(tempTbl, "screenAlarmView dict")
	if tempTbl then
		Drequire("game.UIComponent.ScreenAlarmView"):create(tempTbl)
	end
end

function guiCommonLocal.setKingCompensateData( dict )
	local tempTbl = dictToLuaTable(dict)
	dump(tempTbl, "setKingCompensateData dict")
	if tempTbl and tempTbl.params and tempTbl.params.newCompensateObj then
		ImperialSceneLuaManager.getInstance():setKingCompensateData(tempTbl.params.newCompensateObj)
	end
end

function guiCommonLocal.getKingCompensateData( dict )
	Dprint("getKingCompensateData 1")
	if dict then
		Dprint("getKingCompensateData 2")
		ImperialSceneLuaManager.getInstance():getKingCompensateData(dict)
	end
end
function guiCommonLocal.get_heroPropertyDetail( dict )
	local heroId = dict:valueForKey("heroId"):getCString()
	local cmd = Drequire("game.general.GeneralDetailCmdForHero").create(heroId)
	cmd:send()
end

function guiCommonLocal.get_dragonPropertyDetail( dict )
	local dragonUuid = dict:valueForKey("dragonUuid"):getCString()
	local cmd = Drequire("game.general.GeneralDetailCmdForDragon").create(dragonUuid)
	cmd:send()
end

function guiCommonLocal.OpenAllianceRallyPoint(dict)
	local view = Drequire("game.WorldMapView.AllianceMark.AllianceMarkView"):create(dict)
	PopupViewController:call("addPopupView", view)
end

function guiCommonLocal.set_AllianceRallyPointInfo(dict)
	require("game.WorldMapView.AllianceMark.AllianceMarkController").getInstance():setPointInfo(dict)
end

function guiCommonLocal.init_AllianceRallyPointInfo(dict)
	require("game.WorldMapView.AllianceMark.AllianceMarkController").getInstance():initPointInfo(dict)
end

function guiCommonLocal.openVoidBattlefieldKingdomListView(dict)
	local serverId = dict:valueForKey("serverId"):getCString()
	local params = {}
	params.serverId = tonumber(serverId)
	local view = Drequire("game.VoidBattlefield.VoidBattlefieldKingdomListView"):create(params)
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.openVoidBattlefieldDeclareWarView(dict)
	local view = Drequire("game.VoidBattlefield.VoidBattlefieldDeclareWarView"):create()
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.open_AllianceBossPopUp( dict )
	local cityIndex = dict:valueForKey("cityIndex"):getCString()
	local view = Drequire("game.allianceBoss.AllianceBossPopUp"):create(cityIndex)
	PopupViewController:addPopupView(view)
end

function guiCommonLocal.OpenTacticalDepView( dict )
	local view = Drequire("game.TacticalDeploy.TacticalDepMainView"):create()
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.open_TacSelectView(dict)
	local view = Drequire("game.TacticalDeploy.TacticalDepBattleView"):create(dict)
	PopupViewController:addPopupView(view)
end

function guiCommonLocal.open_CreateLuaTilereviveInLua(dict)
	dump(dict,"open_CreateLuaTilereviveInLua+++")
	if dict then 
		if dict:objectForKey("WorldCityInfo") then 
			local cinfo = dict:objectForKey("WorldCityInfo")
			dump(cinfo,"open_CreateLuaTilereviveInLua+++2")
			local tile = Drequire("game.revive2.ReviveTilePlus"):create(cinfo)
			if tile then 
				dump("open_CreateLuaTilereviveInLua+++3")
				dict:setObject(tile, "tile")
			end
		end
	end
end

function guiCommonLocal.onAddRuningActBoat(dict)	
	Drequire("game.activity.RunningRingAct.ImperialDAUBoatNode"):create(dict)
end

function guiCommonLocal.onCheckAormaionSel(dict)
	TacticalDepController.getInstance():setBattleSel(dict)
end

function guiCommonLocal.onCheckAormationState(dict)
	TacticalDepController.getInstance():checkAormationState(dict)
end

function guiCommonLocal.onMoveInMapCenterArea(dict)
	COSDataController.getInstance():sendPushLimitInfo(dict)
end

function guiCommonLocal.onCOSDataCtlEvent( data, newKey )
	COSDataController.getInstance():fireEventRef(newKey, data)
end

function guiCommonLocal.onAddCOSDragon(data, newKey)
	if newKey == "dragon" then
		Drequire("game.activity.CallOfSoldiresAct.COSThroneDragon"):create(data)	
	elseif newKey == "panel" then
		Drequire("game.activity.CallOfSoldiresAct.COSThroneNamePanel"):create(data)
	end
end

function guiCommonLocal.onSendDonateSoldire(dict)
	COSDataController.getInstance():sendDonateSoldire(dict)
end

function guiCommonLocal.onSendDonateSoldireFinish(dict)
	COSDataController.getInstance():sendQueueFinish(dict)
end

function guiCommonLocal.onAllianceAskForHelp(dict)
	require("game.alliance.AllianceAFHController").getInstance():onClickAFHBtn()
end

function guiCommonLocal.onDragonWarmUpConfig(data, newKey)
	DragonWarmUpManager:fireEventRef(newKey,data)
end

local g_fireEventTable = 
{
	["initCrownEntranceView"] = guiCommonLocal.oninitCrownTableView,
	["createLuaTilereviveInLua"] = guiCommonLocal.open_CreateLuaTilereviveInLua,

	-- 获取服务器活动相关的数据
	["requestActValueAndTime"] = guiCommonLocal.on_requestActValueAndTime,
	-- 获取活动key对应的value
	["get_act_key_value"] = guiCommonLocal.on_get_act_key_value,
	-- 获取活动key对应的time
	["get_act_key_time"] = guiCommonLocal.on_get_act_key_time,
	-- 获取29活动类型世界boss的重置时间
	["get_29_boss_resetTime"] = guiCommonLocal.on_get_29_boss_resetTime,
	["open_SubEquipSelectView"] = guiCommonLocal.on_open_SubEquipSelectView,
	["get_put_equip_id"] = guiCommonLocal.on_get_put_equip_id,
	-- 点击聊天
	["clickchatmsg"] = guiCommonLocal.on_clickchatmsg,
	--获取每日任务未完成的状态
	["funNoFinishIconFlag"] = guiCommonLocal.funNoFinishIconFlag,
	--每日任务通讯
	["open_DailyTaskCommand"] = guiCommonLocal.open_DailyTaskCommand,
	-- 图腾放置时的底图
	["createTotemBounder"] = guiCommonLocal.on_createTotemBounder,
	--打开每日任务界面
	["open_DailyTaskView"] = guiCommonLocal.open_DailyTaskView,	
	["openChapterAni"] = openChapterAni,
	["onChapterEvent"] = guiCommonLocal.onChapterEvent,

    ["open_AvatarView_fromchat_1"] = guiCommonLocal.on_open_AvatarView_fromchat_1,
    ["open_AvatarView_fromchat_0"] = guiCommonLocal.on_open_AvatarView_fromchat_0,
	["open_ChangeNickNameView_fromchat_1"] = guiCommonLocal.open_ChangeNickNameView_fromchat_1,	
	["open_ChangeNickNameView_fromchat_0"] = guiCommonLocal.open_ChangeNickNameView_fromchat_0,	
	["open_alliance_boss"] = guiCommonLocal.on_open_alliance_boss,
	["get_libao_data"] = guiCommonLocal.on_get_libao_data,

	--新版活动中心
	["ActivityListView_New"] = guiCommonLocal.ActivityListView_New,
	--龙模型数据获取
	["onCreateDragonFeature"] = guiCommonLocal.onCreateDragonFeature, 
--------------SHP专用，嘿嘿，避免冲突 Start----------------------
	["openDragonGlobalManagerView"] = guiCommonLocal.openDragonGlobalManagerView,
	["openDragonWorldCupHallOfFameView"] = guiCommonLocal.openDragonWorldCupHallOfFameView,
	["openNewDragonVictoryView"] = guiCommonLocal.openNewDragonVictoryView,
	--道具多选
	["openChooseItemView"] = guiCommonLocal.openChooseItemView,
	["openRewardBoxShowView"] = guiCommonLocal.openRewardBoxShowView,
	--跨服王座战
	["openCrossThroneEntryView"] = guiCommonLocal.openCrossThroneEntryView,
	["openCrossThroneWorldView"] = guiCommonLocal.openCrossThroneWorldView,
	["openCrossThroneBuffView"] = guiCommonLocal.openCrossThroneBuffView,
	["reqCrossThroneBattleRank"] = guiCommonLocal.reqCrossThroneBattleRank,
	["openCrossThroneHonorView"] = guiCommonLocal.openCrossThroneHonorView,
	["openCrossThroneTowerDetailsView"] = guiCommonLocal.openCrossThroneTowerDetailsView,
	["crossThroneOperation"] = guiCommonLocal.crossThroneOperation,
	["addDespotBuildSwitch"] = guiCommonLocal.addDespotBuildSwitch,
	["dumpDictionary"] = guiCommonLocal.dumpDictionary,
	["dumpArray"] = guiCommonLocal.dumpArray,
	["worldLevelInterface"] = guiCommonLocal.worldLevelInterface,
	["openWorldLevelInfoView"] = guiCommonLocal.openWorldLevelInfoView,
	["OneKeyBuffMainView"] = guiCommonLocal.OneKeyBuffMainView, -- 一键buff
	["webActivityInterface"] = guiCommonLocal.webActivityInterface,
	["openWebActivityView"] = guiCommonLocal.openWebActivityView,
	["openDragonBattleRecordView"] = guiCommonLocal.openDragonBattleRecordView,
	["openDragonBattleComparisonView"] = guiCommonLocal.openDragonBattleComparisonView,
	--大炮
	["ArtilleryInterface"] = guiCommonLocal.ArtilleryInterface,
	["openArtillerySelectView"] = guiCommonLocal.openArtillerySelectView,
	["openArtilleryProduceView"] = guiCommonLocal.openArtilleryProduceView,
	["openPlayerSearchListView"] = guiCommonLocal.openPlayerSearchListView,
	--文明奇迹
	["openCiviMiraclePopupView"] = guiCommonLocal.openCiviMiraclePopupView,
	["ReqCiviMiracleCancel"] = guiCommonLocal.ReqCiviMiracleCancel,
	["isCiviMiracleExist"] = guiCommonLocal.isCiviMiracleExist,
	["openCiviMiracleFunctionView"] = guiCommonLocal.openCiviMiracleFunctionView,
	["shareCiviMiracleBuild"] = guiCommonLocal.shareCiviMiracleBuild,
	["shareCiviMiracleHelp"] = guiCommonLocal.shareCiviMiracleHelp,
	["getCiviMiraclePic"] = guiCommonLocal.getCiviMiraclePic,
	["showCiviMiracleAni"] = guiCommonLocal.showCiviMiracleAni,
	["getCiviMiracleFreeTimes"] = guiCommonLocal.getCiviMiracleFreeTimes,
	["getQIJISHIFreeTimes"] = guiCommonLocal.getQIJISHIFreeTimes,
	["checkIsBuySpecialMonthCard"] = guiCommonLocal.checkIsBuySpecialMonthCard,
	--随机属性激活
	["openRpActiveView"] = guiCommonLocal.openRpActiveView,
	--跨服战斗接受数据
	["onAccessCSData"] = guiCommonLocal.onAccessCSData,
	--主UI任务提示
	["canTipsEventShow"] = guiCommonLocal.canTipsEventShow,
	["tipsEventGoto"] = guiCommonLocal.tipsEventGoto,
	--英雄皮肤
	["activeHeroSkin"] = guiCommonLocal.activeHeroSkin,
	["onHeroSkinEvent"] = guiCommonLocal.onHeroSkinEvent,
	------英雄-------
	["hero_start_put_monster"] = guiCommonLocal.hero_start_put_monster,
	-----矿脉安全区------
	["addSafeArea"] = guiCommonLocal.addSafeArea,
	-----巨龙奖励展示-------
	["openDragonBattleRewardView"] = guiCommonLocal.openDragonBattleRewardView,
	["openDragonBattleUpdateView"] = guiCommonLocal.openDragonBattleUpdateView,
	["openDragonBattlePlayOffRewardView"] = guiCommonLocal.openDragonBattlePlayOffRewardView,
	["openDragonBattlePlayOffRewardViewNew"] = guiCommonLocal.openDragonBattlePlayOffRewardViewNew,
	["openDragonPlayoffUpdateView"] = guiCommonLocal.openDragonPlayoffUpdateView,
	-----建筑按钮--------
	["addBuildBtnInLua"] = guiCommonLocal.addBuildBtnInLua,
	-----LuaFlyHint------
	["addLuaFlyHint"] = guiCommonLocal.addLuaFlyHint,
	-----战报配置-----
	["getConfigHeight"] = guiCommonLocal.getConfigHeight,
	["getConfigNode"] = guiCommonLocal.getConfigNode,
	-----联盟资源-----
	["openAllianceResourceView"] = guiCommonLocal.openAllianceResourceView,
	-----巨龙OB小地图------
	["openDragonMinimapView"] = guiCommonLocal.openDragonMinimapView,

--------------SHP专用，嘿嘿，避免冲突 End----------------------


--------------ZT专用，嘿嘿，避免冲突 Start----------------------
	["onNewbeeCastleEvent"] = guiCommonLocal.onNewbeeCastleEvent,
	["onPayUserRewardEvent"] = guiCommonLocal.onPayUserRewardEvent,
	["onShowRechargeFeedBack"] = guiCommonLocal.onShowRechargeFeedBack,
	["onNewRecallEvent"] = guiCommonLocal.onNewRecallEvent,
	-- 文明系统事件函数
	["onCivilizationEvent"] = guiCommonLocal.onCivilizationEvent,
	["open_luckyDay_View"] = guiCommonLocal.open_luckyDay_View,
	["onCivFortressEvent"] = guiCommonLocal.onCivFortressEvent,
	["onCivFortress2Event"] = guiCommonLocal.onCivFortress2Event,	-- 【Awen】文明堡垒分城
	["onWorldControllerEvent"] = guiCommonLocal.onWorldControllerEvent,
	["onActivityPageController"] = guiCommonLocal.onActivityPageController,
	["onPlayerInfoController"] = guiCommonLocal.onPlayerInfoController,
    ["onAvatarCommonEvent"] = guiCommonLocal.onAvatarCommonEvent,
	["newLoadingEvent"] = guiCommonLocal.onNewLoadingEvent,
	["openCrossBattleStatusView"] = guiCommonLocal.openCrossBattleStatusView,

	["getUserSettingSwitch"] = guiCommonLocal.getUserSettingSwitch,
	["setLoginDataInfo"] = guiCommonLocal.setLoginDataInfo,			-- 用于登录信息同步lua
	["onActivityDataEvent"] = guiCommonLocal.onActivityDataEvent,			-- 用于登录信息同步lua
--------------ZT专用，嘿嘿，避免冲突 Ended----------------------
	--可冲突版DMM金币展现
	["open_DmmGoldInfoView"] = guiCommonLocal.open_DmmGoldInfoView,
	--接收防沉迷数据
	["setAntiAddictionData"] = guiCommonLocal.setAntiAddictionData,
	--鲜花排行榜
	["open_FlowerRank"] = guiCommonLocal.open_FlowerRank,
	["start_put_allianceBoss"] = guiCommonLocal.on_put_allianceBoss,
	--英雄转盘获取
	["open_HeroGetRotate"] = guiCommonLocal.open_HeroGetRotate,
	-- 英雄抽卡
	["onHeroLuckDraw"] = guiCommonLocal.onHeroLuckDraw,			-- 英雄抽卡
	--龙商店
	["open_DragonShop"] = guiCommonLocal.open_DragonShop,
	--选择种族
	["open_RaceSettingView"] = guiCommonLocal.open_RaceSettingView,
	--获取建筑ccbName
	["onGetCivilizationBuildCCBName"] = guiCommonLocal.onGetCivilizationBuildCCBName,
	--声望捐献相关
	["onGetPrestigeDonateTipsTime"] = guiCommonLocal.onGetPrestigeDonateTipsTime ,
	["open_Report_NickName"] = onOpenReportNickName ,
	["get_CivPrestige_Name_By_Level"] = getCivPrestigeNameByLevel,
	
	["get_CivPrestige_Level_By_Type"] = getCivPresigeLevelByType,
	["get_Civilization_Name_By_Type"] = getCivilizationNameByType,
	["get_Icon_Name_By_Level"] = getIconNameByLevel,
	--新英雄驻守
	["onHeroGarrisonViewNew"] = onHeroGarrisonViewNew ,
	--商店入口整合界面
	["open_AllStoreView"] = openAllStoreView,
	--新装备系统
	["open_NewEquipView"] = guiCommonLocal.open_NewEquipView,
	["open_NewSuitListView"] = guiCommonLocal.open_NewSuitListView,
	["open_NewEquipListView"] = guiCommonLocal.open_NewEquipListView,
	--隐私条款面板
	["open_PermitView"] = open_PermitView,
	["getDailyTaskNode"] = getDailyTaskNode,
	--旅行商人
	["open_NewMerchantView"] = open_NewMerchantView,
	["open_SetupUsernameLockView"] = open_SetupUsernameLockView,
	["open_CancelUsernameLockView"] = open_CancelUsernameLockView,
	["dumpDict"] = guiCommonLocal.dumpDict,
	["open_FangJianBeiView"] = guiCommonLocal.onOpen_FangJianBeiView,
	["getCivilizationIconByType"] = getCivilizationIconByType,
	["open_AuctionHouseView"] = open_AuctionHouseView, --拍卖行
	["open_EquipmentRecastView"] = open_EquipmentRecastView,
	["open_GoodsRewardListView"] = open_GoodsRewardListView,

	["open_OneRechargeView"] = guiCommonLocal.onOpen_OneRechargeView,

	["openHeroList"] = guiCommonLocal.openHeroList,
	["marchForPve"] = guiCommonLocal.marchForPve,
	["createMapNode"] = guiCommonLocal.createTrainingMapNode,
	["createPveMapOver"] = guiCommonLocal.createPveMapOver,
	["addBuildingOnPve"] = guiCommonLocal.addBuildingOnPve,
	["removePopUpMenu"] = guiCommonLocal.removePopUpMenu,
	["setPveArmyData"] = guiCommonLocal.setPveArmyData,
	["clearPveLevel"] = guiCommonLocal.clearPveLevel,
	["refreshStarInfo"] = guiCommonLocal.refreshStarInfo,
	["addStarProgressNode"] = guiCommonLocal.addStarProgressNode,
	["getMapFile"] = getMapFile,
	--联盟医院UI
	["open_TerritoryHospitalPopupView"] = guiCommonLocal.onOpen_TerritoryHospitalPopupView,
	["open_AllianceHospitalPopupView"] = guiCommonLocal.onOpen_AllianceHospitalPopupView,
	["open_AllianceHospitalTreatPopupView"] = guiCommonLocal.onOpen_AllianceHospitalTreatPopupView,
	['allianceHospitalCureFinish'] = guiCommonLocal.on_AllianceHospitalCureFinish,
	['sendAllianceHospitalCancelCmd'] = guiCommonLocal.on_sendAllianceHospitalCancelCmd,
	['openPveStartView'] = guiCommonLocal.openPveStartView,

	["getNeutralSaveStatus"] = guiCommonLocal.getNeutralSaveStatus,
	["open_alliance_legend"] = open_alliance_legend,
	["on_checkIsInSaveZone"] = guiCommonLocal.on_checkIsInSaveZone,
	['onLuckyReturn'] = guiCommonLocal.on_luckyReturn,
	['getLuckyReturn'] = guiCommonLocal.get_luckyReturn,
	["open_CrownMainView"] = open_CrownMainView,
	["open_select_throne_time"] = guiCommonLocal.open_select_throne_time,
	["get_kingdom_war_time_str"] = guiCommonLocal.get_kingdom_war_time_str,
	["open_TreasureFamActivityView"] = guiCommonLocal.open_TreasureFamActivityView,
	["setTreasureFamMonsterArmyData"] = guiCommonLocal.setTreasureFamMonsterArmyData,
	["marchForTreasureMonster"] = guiCommonLocal.marchForTreasureMonster,
	["marchForTreasureMine"] = guiCommonLocal.marchForTreasureMine,
	-- 欧盟条款
	["open_PermitViewForEUView"] = open_PermitViewForEUView,
	["open_PermitDisaViewForEUView"] = open_PermitDisaViewForEUView,
	["open_PermitChooseView"] = open_PermitChooseView,
	-- 士兵升级
	["open_ArmyUpgradeView"] = open_ArmyUpgradeView,
	--批量使用加速道具
	["open_UseMultySpeedView"] = open_UseMultySpeedView,
	--魔法学院 抽卡
	["open_MagicDrawView"] = open_MagicDrawView,
	["open_MagicBookView"] = open_MagicBookView,

--------------HXQ专用，嘿嘿，避免冲突 Start----------------------
	--造兵新UI
    ["open_ProductionSoldierView"] = guiCommonLocal.onOpen_ProductionSoldierView,
    --小公主界面
	["open_HeroPopupViewForLua"] = guiCommonLocal.onOpen_HeroPopupViewForLua,
	["open_PlayerFlowerViewForLua"] = guiCommonLocal.onOpen_PlayerFlowerViewForLua,
	["postIsHeroUnlockInList"] = guiCommonLocal.postIsHeroUnlockInList,
	["openCacheBattleWin"] = guiCommonLocal.openCacheBattleWin,
	["checkAbortReport"] = guiCommonLocal.checkAbortReport,
	["open_DragonTowerRewardsView"] = guiCommonLocal.openDragonTowerRewardsView,
    ["open_DragonTowerRankView"] = guiCommonLocal.openDragonTowerRankView,
	["check_DragonTowerRewardsData"] = guiCommonLocal.checkDragonTowerRewardsData,
	["openGlory6SkillChangeView"] = guiCommonLocal.openGlory6SkillChangeView,
	["open_FourthAnniversaryGiftView"] = guiCommonLocal.openFourthAnniversaryGiftView,
	["open_FourthAnniversaryBlessView"] = guiCommonLocal.openFourthAnniversaryBlessView,
	--新版龙界面
	["open_DragonList_New_V2"] = guiCommonLocal.openDragonNodeIcons,
	--装备强化
	["open_EquipmentUpgradeView"] = guiCommonLocal.open_EquipmentUpgradeView,
	--小公主回归对话
	["open_LuckyReturnNPCView"] = guiCommonLocal.open_LuckyReturnNPCView,
	["kingRerutnActivate"] = guiCommonLocal.kingRerutnActivate,
	--总览
	["open_PreInfoView"] = guiCommonLocal.OpenPreInfoView,
	--联盟标记
	["open_AllianceRallyPoint"] = guiCommonLocal.OpenAllianceRallyPoint,
	["set_AllianceRallyPointInfo"] = guiCommonLocal.set_AllianceRallyPointInfo,
	["init_AllianceRallyPointInfo"] = guiCommonLocal.init_AllianceRallyPointInfo,	
	--阵法
	["open_tacticalDepView"] = guiCommonLocal.OpenTacticalDepView,
	["open_TacSelectView"] = guiCommonLocal.open_TacSelectView,
	["onAddRuningActBoat"] = guiCommonLocal.onAddRuningActBoat,
	["checkAormaionSel"] = guiCommonLocal.onCheckAormaionSel,
	["checkAormationState"] = guiCommonLocal.onCheckAormationState,
	--消耗士兵活动
	--世界地图上进入王座视野范围
	["moveInMapCenterArea"] = guiCommonLocal.onMoveInMapCenterArea,
	["onCOSDataCtlEvent"] = guiCommonLocal.onCOSDataCtlEvent,
	["onAddCOSDragon"] = guiCommonLocal.onAddCOSDragon,
	["onSendDonateSoldire"] = guiCommonLocal.onSendDonateSoldire,
	["send_donateSoldire_finish"] = guiCommonLocal.onSendDonateSoldireFinish,
	--获取龙皮肤相关信息
	["onGetDragonAvatarFeature"] = guiCommonLocal.onGetDragonAvatarFeature,
	--巨龙演武场相关
	["onDragonWarmUpConfig"] = guiCommonLocal.onDragonWarmUpConfig,
--------------HXQ专用，嘿嘿，避免冲突 Ended----------------------

	["onOpen_integrateSignInView"] = guiCommonLocal.onOpen_integrateSignInView,
	["onOpen_FamousRank"] = guiCommonLocal.onOpen_FamousRank, -- 全服名人录

	-- 【Awen】获取当前是否有进阶龙
	["onDragonConfig"] = guiCommonLocal.onDragonConfig,
	-- 【Awen】士兵进阶
	["onArmyUp"] = guiCommonLocal.onArmyUp,
	-- 【Awen】先祖战场
	["onAncestralTrial"] = guiCommonLocal.onAncestralTrial,
	-- 【Awen】引导打开view
	["onLuaViewForGuide"] = guiCommonLocal.onLuaViewForGuide,
	-- 【Awen】装扮图鉴
	["onDressIntroduction"] = guiCommonLocal.onDressIntroduction,
	-- 【Awen】视频广告
	["onAdVideo"] = guiCommonLocal.onAdVideo,
	-- 分享
	["open_CommonShareView"] = guiCommonLocal.openCommonShareView,
	["open_ActivityDayMakexxxSendGiftView"] = guiCommonLocal.openActivityDayMakexxxSendGiftView,
	["open_ActivityDayMakexxxView"] = guiCommonLocal.openActivityDayMakexxxView,
	["processSndGiftMailInLua"] = guiCommonLocal.onProcessSndGiftMailInLua,
	["open_UserLockedView"] = guiCommonLocal.open_UserLockedView,
	--装备详情和战力排行榜
	["open_EquipmentRankView"] = guiCommonLocal.open_EquipmentRankView,
	--招募之神界面
	["open_HeroRecruitRankView"] = guiCommonLocal.open_HeroRecruitRankView,
	["open_ShuaHaoPingView"] = guiCommonLocal.open_ShuaHaoPingView,
	["send_ChaPingCmd"] = guiCommonLocal.send_ChaPingCmd,
	["open_longjingInfoView"] = guiCommonLocal.open_longjingInfoView,
	["open_CrystalGetRotate"] = guiCommonLocal.open_CrystalGetRotate,
	["open_SnkLoginView"] = guiCommonLocal.open_SnkLoginView,
	["get_UicommonentName"] = guiCommonLocal.get_UicommonentName,
	["getConstId"] = guiCommonLocal.getConstId,
	["screenAlarmView"] = guiCommonLocal.screenAlarmView,
	["setKingCompensateData"] = guiCommonLocal.setKingCompensateData,-- 国王援助 传递字段
	["getKingCompensateData"] = guiCommonLocal.getKingCompensateData,-- 国王援助 传递字段
	["get_heroPropertyDetail"] = guiCommonLocal.get_heroPropertyDetail,
	["get_dragonPropertyDetail"] = guiCommonLocal.get_dragonPropertyDetail,
	--虚空战场王国界面
	["openVoidBattlefieldKingdomListView"] = guiCommonLocal.openVoidBattlefieldKingdomListView,
	--虚空战场宣战界面
	["openVoidBattlefieldDeclareWarView"] = guiCommonLocal.openVoidBattlefieldDeclareWarView,
	
	["open_AllianceBossPopUp"] = guiCommonLocal.open_AllianceBossPopUp,
	["onTrainingTroopsEvent"] = guiCommonLocal.onTrainingTroopsEvent,--【Awen】军团降临限时活动
	["onCivilizationTimeLimitedEvent"] = guiCommonLocal.onCivilizationTimeLimitedEvent,-- 文明堡垒限时活动
	['onKingRoad'] = guiCommonLocal.onKingRoad,	--【Awen】王者之路
	["checkAndSendAFHCmd"] = guiCommonLocal.onAllianceAskForHelp,
	["onUseSpeedUp"] = guiCommonLocal.onUseSpeedUp, --【Awen】新加速
}

function onFireEvent2(eventID, data, newKey)
	-- MyPrint("onFireEvent2 ", eventID)
	-- dump(data, "onFireEvent2: " .. eventID.." newKey is: "..tostring(newKey))
	if g_fireEventTable[eventID] then
		g_fireEventTable[eventID](data, newKey)
	end
end

