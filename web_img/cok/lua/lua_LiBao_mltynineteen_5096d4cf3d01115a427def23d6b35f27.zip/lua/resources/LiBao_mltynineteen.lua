cfg_table = {
	["layerX"] = -10,
	["layerY"] = -30,
	["layerScale"] = 1
}