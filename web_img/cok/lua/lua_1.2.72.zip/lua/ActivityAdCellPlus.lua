-- require "externCOK2"
-- require "CCBReaderLoadCOK2"
-- require "commonCOK2"

ActivityAdLuaCellNew = ActivityAdLuaCellNew or {}
ccb["ActivityAdLuaCellNew"] = ActivityAdLuaCellNew

ActivityAdCellPlus = class("ActivityAdCellPlus", function() return cc.Layer:create() end)
ActivityAdCellPlus.__index = ActivityAdCellPlus

function ActivityAdCellPlus:create( actId)
    --print "---203----"

    local node = ActivityAdCellPlus.new()
    --print "---204----"

    node:init(actId)
    return node
end

function ActivityAdCellPlus:init( actId )
    --print "---205----"

    -- local actObj = ActivityController:getInstance():getActObj(actId)
    local dict = CCDictionary:create()
    dict:setObject(CCString:create(tostring(actId)),"1")
    local actObj = ActivityController:comFunc("getActObj",dict)
    
    if actObj == nil then
        return false
    end
    self.params = actObj

    ActivityAdLuaCellNew[actId] = ActivityAdLuaCellNew[actId] or {}

    self.rootPath = cc.FileUtils:getInstance():getWritablePath() .. "lua/" .. actId .. "/"
    --print "---206----"
    
    self.id = actId
    --print "---207----"
    
    loadLuaResource(self.rootPath .. "resources/activity_" .. self.id .. "_new.plist")

    --print "---208----"

    local proxy = cc.CCBProxy:create()
    --print "---209----"

    local ccbiURL = self.rootPath .. "ccbi/Activity" .. self.id .. "AdLuaCell_new.ccbi"
    --print "---210----"

    local node = CCBReaderLoad(ccbiURL, proxy, ActivityAdLuaCellNew[actId])
    --print "---211----"

    local layer = tolua.cast(node, "cc.Layer")
    --print "---212----"
    

    if nil ~= ActivityAdLuaCellNew[actId]["m_nameLabel"] then
        self.m_nameLabel = tolua.cast(ActivityAdLuaCellNew[actId]["m_nameLabel"], "cc.Label")
        if nil ~= self.m_nameLabel then
            self.m_nameLabel:setString(self.params:getProperty("name"))
        end
    end

    if nil ~= ActivityAdLuaCellNew[actId]["m_desLabel"] then
        self.m_desLabel = tolua.cast(ActivityAdLuaCellNew[actId]["m_desLabel"], "cc.Label")
        if nil ~= self.m_desLabel then
            self.m_desLabel:setString(self.params:getProperty("desc"))
        end
    end

    if nil ~= ActivityAdLuaCellNew[actId]["m_timeLabel"] then
        self.m_timeLabel = tolua.cast(ActivityAdLuaCellNew[actId]["m_timeLabel"], "cc.Label")
    end

    if nil ~= node then
        local function tick(  )
            print ("tick()")
            if nil == self.m_timeLabel then return end
            local nowTime = LuaController:getWorldTime()
            local startTime = tonumber(self.params.getProperty("startTime"))

            local endTime = tonumber(self.params.getProperty("endTime"))

            if nowTime < startTime then
                -- self.m_timeLabel:setString(string.format(LuaController:getLang1("105804", string.format(LuaController:getSECLang(startTime - nowTime)))))
                local tdic1 = CCDictionary:create()
                tdic1:setObject(CCString:create("105804"), "1")
                local tdic2 = CCDictionary:create()
                local time1 = startTime - nowTime
                tdic2:setObject(CCInteger:create(tonumber(time1)), "1")
                local pStrTime = LuaController:comFunc("getSECLang", tdic2)
                tdic1:setObject(pStrTime, "2")
                local pStr = LuaController:comFunc("getLang1", tdic1)
                self.m_timeLabel:setString(pStr:getCString())
            elseif nowTime< endTime then
                -- self.m_timeLabel:setString(string.format(LuaController:getLang1("105805", string.format(LuaController:getSECLang(endTime - nowTime)))))
                local tdic1 = CCDictionary:create()
                tdic1:setObject(CCString:create("105805"), "1")
                local tdic2 = CCDictionary:create()
                local time1 = endTime - nowTime
                tdic2:setObject(CCInteger:create(tonumber(time1)), "1")
                local pStrTime = LuaController:comFunc("getSECLang", tdic2)
                tdic1:setObject(pStrTime, "2")
                local pStr = LuaController:comFunc("getLang1", tdic1)
                self.m_timeLabel:setString(pStr:getCString())
            else
                -- self.m_timeLabel:setString(string.format(LuaController:getLang("105800")))
                local tdic1 = CCDictionary:create()
                tdic1:setObject(CCString:create("105800"), "1")
                local pStr = LuaController:comFunc("getLang", tdic1)
                self.m_timeLabel:setString(pStr:getCString())
            end
        end
        local function eventHandler( eventType )
            if eventType == "enter" then
                tick()
                self.m_entryId = tonumber(node:getScheduler():scheduleScriptFunc(tick, 1, false))
            elseif eventType == "exit" then
                if nil ~= self.m_entryId then
                    node:getScheduler():unscheduleScriptEntry(self.m_entryId)
                end
            elseif eventType == "cleanup" then
                local targetPlatform = cc.Application:getInstance():getTargetPlatform()
                if (3 == targetPlatform) then
                    releaseLuaResourceForAndroid(self.rootPath .. "resources/", "activity_" .. self.id .. "_new")
                else
                    releaseLuaResource(self.rootPath .. "resources/activity_" .. self.id .. "_new")
                end
                node:unregisterScriptHandler()
            end
        end
        --print "---225----"
        node:registerScriptHandler(eventHandler)
        --print "---226----"
        self:addChild(node)
        --print "---227----"
    end
end