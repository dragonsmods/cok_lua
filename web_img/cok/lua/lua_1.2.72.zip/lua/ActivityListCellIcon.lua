-- require "externCOK2"
-- require "CCBReaderLoadCOK2"
-- require "commonCOK2"

local ActivityListCellIcon = class("ActivityListCellIcon", function() return cc.Layer:create() end)
ActivityListCellIcon.__index = ActivityListCellIcon

function ActivityListCellIcon:create( actId)
    -- print "---3----"
    local node = ActivityListCellIcon.new()
    -- print "---4----"
    node:init(actId)
    return node
end

function ActivityListCellIcon:init( actId )
    -- print "---5----"
    self.rootPath = cc.FileUtils:getInstance():getWritablePath() .. "lua/" .. actId .. "/"
    -- print "---6----"
    self.id = actId
    -- print "---7----"
    loadLuaResource(self.rootPath .. "resources/activity_" .. self.id .. "_new.plist")
    -- print "---8----"
    local frame = cc.SpriteFrameCache:getInstance():getSpriteFrame("activity_" .. self.id .. "_list_cell_head_new.png");
    -- print "---9----"
    if nil ~= frame then
        -- print "---10----"
        local sprite = cc.Sprite:createWithSpriteFrame(frame)
        -- print "---11----"
        local function eventHandler( eventType )
            -- print "---12----"
            if eventType == "enter" then
                -- print "enter"
            elseif eventType == "exit" then
                -- print "exit"
            elseif eventType == "cleanup" then
                -- print "cleanup"
                -- print "---13----"
                if (3 == targetPlatform) then
                    releaseLuaResourceForAndroid(self.rootPath .. "resources/", "activity_" .. self.id .. "_new")
                else
                    releaseLuaResource(self.rootPath .. "resources/activity_" .. self.id .. "_new")
                end
               -- print "---14----"
                sprite:unregisterScriptHandler()
            end
        end
        -- print "---15----"
        sprite:registerScriptHandler(eventHandler)
        -- print "---16----"
        self:addChild(sprite)
        -- print "---17----"
    end
end

return ActivityListCellIcon