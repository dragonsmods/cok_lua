-- require "externCOK2"
-- require "CCBReaderLoadCOK2"
-- require "commonCOK2"

ActivityAdLuaCellNew = ActivityAdLuaCellNew or {}
ccb["ActivityAdLuaCellNew"] = ActivityAdLuaCellNew

local ActivityListCellSprite = class("ActivityListCellSprite", function() return cc.Layer:create() end)
ActivityListCellSprite.__index = ActivityListCellSprite

function ActivityListCellSprite:create( actId)
    local node = ActivityListCellSprite.new()

    node:init(actId)
    return node
end

function ActivityListCellSprite:init( actId )
    local dict = CCDictionary:create()
    dict:setObject(CCString:create(tostring(actId)),"1")
    local actObj = ActivityController:comFunc("getActObj",dict)
    
    if actObj == nil then
        return false
    end
    self.params = actObj

    ActivityAdLuaCellNew[actId] = ActivityAdLuaCellNew[actId] or {}

    self.rootPath = cc.FileUtils:getInstance():getWritablePath() .. "lua/" .. actId .. "/"
    self.id = actId
    loadLuaResource(self.rootPath .. "resources/activity_" .. self.id .. "_new.plist")

    local proxy = cc.CCBProxy:create()
    local ccbiURL = cc.FileUtils:getInstance():getWritablePath() .. "lua/ccbi/ActivityCommonCell.ccbi"
    local node = CCBReaderLoad(ccbiURL, proxy, ActivityAdLuaCellNew[actId])
    dump(node, "ActivityListCellSprite node is ")

    local layer = tolua.cast(node, "cc.Layer")
    dump(ActivityAdLuaCellNew[actId], " ActivityAdLuaCellNew[actId] is: ")

    if nil ~= ActivityAdLuaCellNew[actId]["m_nameLabel"] then
        self.m_nameLabel = tolua.cast(ActivityAdLuaCellNew[actId]["m_nameLabel"], "cc.Label")
        if nil ~= self.m_nameLabel then
            self.m_nameLabel:setString(self.params:getProperty("name"))
        end
    end

    if nil ~= ActivityAdLuaCellNew[actId]["m_desLabel"] then
        self.m_desLabel = tolua.cast(ActivityAdLuaCellNew[actId]["m_desLabel"], "cc.Label")
        if nil ~= self.m_desLabel then
            self.m_desLabel:setString(self.params:getProperty("desc"))
        end
    end

    if nil ~= ActivityAdLuaCellNew[actId]["m_sprite"] then
        self.m_sprite = tolua.cast(ActivityAdLuaCellNew[actId]["m_sprite"], "cc.Sprite")

        if self.m_sprite then
            local frame = cc.SpriteFrameCache:getInstance():getSpriteFrame(self.id .. "_ad1_new.png");
            -- dump(" get ad1 New is: "..tostring(frame))
            self.m_sprite:setSpriteFrame(frame)
        end
    end

    if nil ~= node then
        
        local function eventHandler( eventType )
            -- dump(" ActivityListCellSprite eventHandler type is: "..tostring(eventType))
            if eventType == "enter" then
            elseif eventType == "exit" then
            elseif eventType == "cleanup" then
                local targetPlatform = cc.Application:getInstance():getTargetPlatform()
                if (3 == targetPlatform) then
                    releaseLuaResourceForAndroid(self.rootPath .. "resources/", "activity_" .. self.id .. "_new")
                else
                    releaseLuaResource(self.rootPath .. "resources/activity_" .. self.id .. "_new")
                end
                node:unregisterScriptHandler()
            end
        end
        node:registerScriptHandler(eventHandler)
        self:addChild(node)
    end

    -- dump("ActivityListCellSprite load finish ~~~~~~~~~~")
end

return ActivityListCellSprite