function __G__TRACKBACK__(msg)
    --print("----------------------------------------")
    --print("LUA ERROR: " .. tostring(msg) .. "\n")
    --print(debug.traceback())
    --print("----------------------------------------")
end

collectgarbage("setpause", 100) 
collectgarbage("setstepmul", 5000)

require ("lua_static.initLib")

-- if DEBUG_OPEN == nil then
--   require('mobdebug').start("10.1.39.241")
--   DEBUG_OPEN = true
-- end


function isLibExist(path,libname)
	-- body
	if package.loaded[libname] ~= nil then
		--print ("isLibExist___1")
		return true
	else
		--print ("isLibExist___2")
		local path1 = ""
		local vvv = string.split(libname, ".")
		for i,v in ipairs(vvv) do
			if string.len(v) > 0 then
				path1 = path1 .. "/" .. v
			end
		end
		if path1 ~= "" then
			path1 = path .. path1 .. ".lua" 
			--print ("isLibExist___3 [ " .. path1 .. " ]")
			if cc.FileUtils:getInstance():isFileExist(path1) == true then 
				require (libname)
				--print ("isLibExist___4 success")
				return true
			end
		end
	end
	return false
end

--init config
function initRefConfig()
	print "initRefConfig"
	local chechV = "2.0.12"
	local dict = CCDictionary:create()
	dict:setObject(CCString:create(tostring(chechV)),"1")
	if (CCCommonUtilsForLua:comFunc("checkVersion",dict):getValue() == true) then
  --if CCCommonUtilsForLua:checkVersion(chechV) == true then
    	local path = cc.FileUtils:getInstance():getWritablePath() .. "lua"
    	if isLibExist(path,"kingrights.KingRightsDataPlus") == true then
      		if KingRightsMap == nil then
        		initKingRights()
      		end
    	end
  	end
end

function showActivityIcon(path,actname)
	print ("showActivityIcon id:"..actname)
	local view = LuaController:comFunc("getActivityIcon", 0)
	if isLibExist(path,"activityIconPlus") == true and nil ~= view then
		-- require("activityIconPlus")
		activityIconPlus:create(view,path,actname)
	else
		print ("showActivityIcon getActivityIcon:nil")
	end
end
--activity test code
function showActPopup(path,actname)
  	if actname == "57034" then
		if isLibExist(path,"57034.ActivityViewPlus") == true then
			local newLayer = ActivityView:create(path,actname)
			if nil ~= newLayer then
				local dict = CCDictionary:create()
				dict:setObject(newLayer, "1")
				PopupViewController:comFunc("addPopupInView", dict)
				-- PopupViewController:getInstance():addPopupInView(newLayer)
			end
		end
	elseif actname == "57057" or actname == "57058" or actname == "57059" or actname == "57060" or actname == "57061" or actname == "57063" or actname == "57065" or actname == "57066" then
		if isLibExist(path, actname .. ".ActivityViewPlus") == true then
			local newLayer = ActivityView:create(path, actname)
			if nil ~= newLayer then
				local dict = CCDictionary:create()
				dict:setObject(newLayer, "1")
				PopupViewController:comFunc("addPopupInView", dict)
				-- PopupViewController:getInstance():addPopupInView(newLayer)
			end
		end
	elseif actname == "57090" then
		if isLibExist(path, actname .. ".EasterEggView_plus") == true then
			local newLayer = EasterEggView:create(path)
			if nil ~= newLayer then
				local dict = CCDictionary:create()
				dict:setObject(newLayer, "1")
				PopupViewController:comFunc("addPopupInView", dict)
				-- PopupViewController:getInstance():addPopupInView(newLayer)
			end
		end
	elseif actname == "57077" then
		local file_zip1 = cc.FileUtils:getInstance():getWritablePath() .. "tmpZR_57077.zip"
		local file_zip2 = cc.FileUtils:getInstance():getWritablePath() .. "tmpZR_57077_a.zip"
		if isLibExist(path, actname .. ".ActivityMainView_EuropeanCup_plus") == true and cc.FileUtils:getInstance():isFileExist(file_zip1)==false and cc.FileUtils:getInstance():isFileExist(file_zip2)==false then
			local newLayer = ActivityMainView_EuropeanCup_plus:create()
			if nil~=newLayer then
				-- PopupViewController:getInstance():addPopupView(newLayer)
				local dict = CCDictionary:create()
				dict:setObject(newLayer, "1")
				-- dict:setObject(CCString:create(tostring("0")),"2")
				PopupViewController:comFunc("addPopupView", dict)
			end
		end
	elseif actname == "57089" then
		local file_zip1 = cc.FileUtils:getInstance():getWritablePath() .. "tmpZR_57089.zip"
		local file_zip2 = cc.FileUtils:getInstance():getWritablePath() .. "tmpZR_57089_a.zip"
		if isLibExist(path, actname .. ".ActivityMainView_57089_plus") == true and cc.FileUtils:getInstance():isFileExist(file_zip1)==false and cc.FileUtils:getInstance():isFileExist(file_zip2)==false then
			local newLayer = ActivityMainView_57089_plus:create()
			if nil~=newLayer then
				-- PopupViewController:getInstance():addPopupView(newLayer)
				local dict = CCDictionary:create()
				dict:setObject(newLayer, "1")
				-- dict:setObject(CCString:create(tostring("0")),"2")
				PopupViewController:comFunc("addPopupView", dict)
			end
		end
	elseif actname == "57083" then
		--print("showinfoview_____0-57083")
		local file = cc.FileUtils:getInstance():getWritablePath() .. "lua/57083/ActivityMainView_PlayerBack_plus.lua"
		if cc.FileUtils:getInstance():isFileExist(file) == true then
	        print("showinfoview_____1")
	        require "57083.ActivityMainView_PlayerBack_plus"
	        local newLayer = ActivityMainView_PlayerBack_plus:create()
	        if nil ~= newLayer then
	            print("showinfoview_____2")
	            local dict = CCDictionary:create()
				dict:setObject(newLayer, "1")
				-- dict:setObject(CCString:create(tostring("0")),"2")
				PopupViewController:comFunc("addPopupView", dict)
	            -- PopupViewController:getInstance():addPopupView(newLayer)
	            -- PopupViewController:getInstance():addPopupInView(newLayer)
	        end
	    else
	        print("57083.ActivityMainView_PlayerBack_plus not exist")
	    end
	elseif actname == "57092" then
		local file_zip1 = cc.FileUtils:getInstance():getWritablePath() .. "tmpZR_57092.zip"
		local file_zip2 = cc.FileUtils:getInstance():getWritablePath() .. "tmpZR_57092_a.zip"
		package.loaded["57092.ActivityMainView_Olympic_plus"] = nil
		package.loaded["57092.ActivityMainView_OlympicCell_plus"] = nil
		package.loaded["57092.ActivityInfoView_Olympic_plus"] = nil
		package.loaded["57092.ActivityInfoView_OlympicCell_plus"] = nil
		if isLibExist(path, actname .. ".ActivityMainView_Olympic_plus") == true and cc.FileUtils:getInstance():isFileExist(file_zip1)==false and cc.FileUtils:getInstance():isFileExist(file_zip2)==false then
			local newLayer = ActivityMainView_Olympic_plus:create()
			if nil~=newLayer then
				-- PopupViewController:getInstance():addPopupView(newLayer)
				local dict = CCDictionary:create()
				dict:setObject(newLayer, "1")
				-- dict:setObject(CCString:create(tostring("0")),"2")
				PopupViewController:comFunc("addPopupView", dict)
			end
		end
	elseif actname == "knight_title" then
		if isLibExist(path,"knight.KnightTitleViewPlus") == true then
			local newLayer = KnightTitleView:create(path)
			if nil ~= newLayer then
				local dict = CCDictionary:create()
				dict:setObject(newLayer, "1")
				PopupViewController:comFunc("addPopupInView", dict)
				-- PopupViewController:getInstance():addPopupInView(newLayer)
			end
		end
	elseif actname == "kingrights" then
		KingRightServerId = tostring(GlobalData:comFunc("getPlayerInfo",0):getProperty("selfServerId"))
		--KingRightServerId = tostring(GlobalData:shared():getPlayerInfo():getProperty("selfServerId"))
		local chechV = "2.0.12"
		local dict = CCDictionary:create()
		dict:setObject(CCString:create(tostring(chechV)),"1")
		if (CCCommonUtilsForLua:comFunc("checkVersion",dict):getValue() == false) then
    	--if CCCommonUtilsForLua:checkVersion(chechV) == false then
			local function confirmFun()
			--print("confirmFun click")
			end
			dict:setObject(CCString:create(tostring("145035")),"1")
			local tip = LuaController:comFunc("getLang",dict):getCString()
			--local tip = LuaController:getLang("145035")
			local fun = cc.CallFunc:create(confirmFun)
			-- YesNoDialog:show(tip,fun)
			dict:setObject(CCString:create(tostring(tip)),"1")
			dict:setObject(fun,"2")
			TemporaryViewNoticController:comFunc("YesNoDialog:show",dict)
			return
    	end
    	if isLibExist(path,"kingrights.KingRightsDataPlus") == false then
      		return
    	end
    	if KingRightData == nil then
      		return
    	end
    	local hasKing = false
    	if KingRightData["kingName"] ~= nil then  
      		if string.len(tostring(KingRightData["kingName"])) > 0 then
        		hasKing = true
      		end
    	end
    	if hasKing == true then
			if isLibExist(path,"kingrights.KingRightsViewPlus") == true then
				--print("kingrights.KingRightsView___1")
				local newLayer = KingRightsView:create(path)
				--print("kingrights.KingRightsView___2")
				if nil ~= newLayer then
					dict:setObject(newLayer, "1")
					PopupViewController:comFunc("addPopupInView", dict)
					-- PopupViewController:getInstance():addPopupInView(newLayer)
				end
			end
		else
			local chechV = "2.0.12"
			dict:setObject(CCString:create(tostring(chechV)),"1")
			if (CCCommonUtilsForLua:comFunc("checkVersion",dict):getValue() == false) then
	    	--if CCCommonUtilsForLua:checkVersion(chechV) == false then
	    		dict:setObject(CCString:create(tostring("146339")),"1")
	    		local arg3 = LuaController:comFunc("getLang",dict)
	    		dict:setObject(CCString:create(tostring("")),"1")
	    		dict:setObject(CCString:create(tostring("")),"2")
	    		dict:setObject(arg3,"3")
	    		LuaController:comFunc("flyHint",dict)
	        	--LuaController:flyHint("","",LuaController:getLang("146339"))
	        else
	        	dict:setObject(CCString:create(tostring("146339")),"1")
	    		local arg3 = LuaController:comFunc("getLang",dict)
	    		dict:setObject(CCString:create(tostring("")),"1")
	    		dict:setObject(CCString:create(tostring("")),"2")
	    		dict:setObject(arg3,"3")
	    		dict:setObject(CCFloat:create(0.5),"4")
	    		LuaController:comFunc("flyHint",dict)
	        	--LuaController:flyHint("","",LuaController:getLang("146339"),0.5)
	    	end
		end
	else
		-- common lua files
		print("show common infoview")
		if isLibExist(path, "ActivityViewPopup") == true then
			print("show common view exist!!")
			local newLayer = ActivityView:create(path,actname)
			if nil ~= newLayer then
				print("show common view -- popup")
				local dict = CCDictionary:create()
				dict:setObject(newLayer, "1")
				PopupViewController:comFunc("addPopupInView", dict)
			end
		end
	end

	return true
end

function showActPopupWithConfig(path,actname,config)
	--print ("showLuaViewByActivityAndConfig:path"..path)
	--print ("showLuaViewByActivityAndConfig:actname"..actname)
	--print ("showLuaViewByActivityAndConfig:config"..config)
  	if actname == "kingrights" then
		KingRightServerId = config
		KingRightData = nil
		local chechV = "2.0.12"
		local dict = CCDictionary:create()
		dict:setObject(CCString:create(tostring(chechV)),"1")
		if (CCCommonUtilsForLua:comFunc("checkVersion",dict):getValue() == false) then
	    --if CCCommonUtilsForLua:checkVersion(chechV) == false then
			local function confirmFun()
			--print("confirmFun click")
			end
			dict:setObject("145035","1")
			local tip = LuaController:comFunc("getLang",dict)
			--local tip = LuaController:getLang("145035")
			local fun = cc.CallFunc:create(confirmFun)
			dict:setObject(CCString:create(tostring(tip)),"1")
			dict:setObject(fun,"2")
			TemporaryViewNoticController:comFunc("YesNoDialog:show",dict)
			-- YesNoDialog:show(tip,fun)
			return
	    end
	    if isLibExist(path,"kingrights.KingRightsDataPlus") == false then
	      return
	    end
	    if isLibExist(path,"kingrights.KingRightsViewPlus") == true then
			--print("kingrights.KingRightsView___1")
			local newLayer = KingRightsView:create(path)
			--print("kingrights.KingRightsView___2")
			if nil ~= newLayer then
				dict:setObject(newLayer, "1")
				PopupViewController:comFunc("addPopupInView", dict)
				-- PopupViewController:getInstance():addPopupInView(newLayer)
			end
		end
	end
end

function backCMDError(cmdname,path,params)
  	if isLibExist(path,"kingrights.KingRightsDataPlus") == true then
    	if cmdname == "skill.king.use" then
      		if KingRightCMDStatus["kskill"] == true then
        		KingRightCMDStatus["kskill"] = false
      		end
    	end
  	end
  	local popup = PopupViewController:comFunc("getCurrentPopupView",0)
	if popup == nil then
		print ("cur popup is nil")
		return
	end
	if(popup:comFunc("getIsLua",0):getValue() == true) then
		if popup.CMDCallbackForLua then
			popup:CMDCallbackForLua(cmdname,params)
			print ("CMDCallbackForLua4")
		end
	end
end

function backCMD(params,cmdname,path)
	print ("backCMD [" .. cmdname .. "]")
    if cmdname == "init_knight" then
    	if isLibExist(path,"knight.KnightTitleControllerPlus") == true then
    		KnightTitleController:getInstance():retInitData(params)
    	end
	elseif cmdname == "knight_puton" then
		if isLibExist(path,"knight.KnightTitleControllerPlus") == true then
    		KnightTitleController:getInstance():retPutOnKnightTitle(params)
    	end
	elseif cmdname == "knight_unlock" then
		if isLibExist(path,"knight.KnightTitleControllerPlus") == true then
    		KnightTitleController:getInstance():retUnlockKnightTitle(params)
    	end
	elseif cmdname == "knight_update" then
		if isLibExist(path,"knight.KnightTitleControllerPlus") == true then
			KnightTitleController:getInstance():UpdateUnlockKnight(params)
		end
	elseif cmdname == "knight_bedge" then
		if isLibExist(path,"knight.KnightTitleControllerPlus") == true then
			KnightTitleController:getInstance():setBedges(params)
		end
	elseif cmdname == "push.lua.postMail" then
		--print ("================backCMD [" .. cmdname .. "]")
		local dict = CCDictionary:create()
		dict:setObject(CCString:create(tostring("push.lua.postMail.newMail")),"1")
		CCSafeNotificationCenter:comFunc("postNotification",dict)
		-- CCSafeNotificationCenter:sharedNotificationCenter():postNotification("push.lua.postMail.newMail")
    else
    	-- if isLibExist(path,"revive.RevivePlus") == true then
    	-- 	if nil ~= backCemeteryCMD then
    	-- 		backCemeteryCMD(cmdname,params)
    	-- 	end
    	-- end
    	if isLibExist(path,"kingrights.KingRightsDataPlus") == true then
    		if nil ~= backKingRightsCMD then
    			backKingRightsCMD(cmdname,params)
    		end
    	end
    end

	-- local popup = PopupViewController:getInstance():getCurrentPopupView()
	local popup = PopupViewController:comFunc("getCurrentPopupView",0)
	if popup == nil then
		print ("cur popup is nil")
		return
	end
	if(popup:comFunc("getIsLua",0):getValue() == true) then
		if popup.CMDCallbackForLua then
			if popup.CMDCallbackForLua then
				popup:CMDCallbackForLua(cmdname,params)
			end
		end
			print ("CMDCallbackForLua4")
	end
end

function backNotification(cmdname,path)
	local popup = PopupViewController:comFunc("getCurrentPopupView",0)
	--local popup = PopupViewController:getInstance():getCurrentPopupView()
	if popup == nil then
		-- print ("cur popup is nil")
		return
	end
	if(popup:comFunc("getIsLua",0):getValue() == true) then
	--if(popup:getIsLua() == true) then
		-- print ("NotificationCallbackForLua")
		local dict = CCDictionary:create()
		dict:setObject(CCString:create(tostring(cmdname)),"1")
		popup:comFunc("NotificationCallbackForLua",dict)
		--popup:NotificationCallbackForLua(cmdname)
	end
end

function backNotificationWithParams(cmdname,path,params)
	local popup = PopupViewController:comFunc("getCurrentPopupView",0)
	if popup == nil then
		-- print ("cur popup is nil")
		return
	end
	if(popup:comFunc("getIsLua",0):getValue() == true) then
	--if(popup:getIsLua() == true) then
		-- print ("NotificationCallbackForLuaWithParams")
		local dict = CCDictionary:create()
		dict:setObject(CCString:create(tostring(cmdname)),"1")
		--dict:setObject(CCString:create(cmdname),"2")
		popup:comFunc("NotificationCallbackForLuaWithParams",dict)
		--popup:NotificationCallbackForLuaWithParams(cmdname,params)
	end
end

function on_Imperial_exit_dy( ... )
	
	return true
end

function onImperialEnter( ... )
	MyPrint("onImperialEnter _DY")
  	initRefConfig()
  	local layer = LuaController:comFunc("getImperialTouchLayer",0)
	--local layer = LuaController:getInstance():getImperialTouchLayer()
	layer = tolua.cast(layer, "cc.Node")
	local dict = CCDictionary:create()
	dict:setObject(CCString:create(tostring("57057")),"1")
	local actObj = ActivityController:comFunc("getActObj",dict)
	--local actObj = ActivityController:getInstance():getActObj("57057")
	local resloaded = false
    if actObj ~= nil then
        local file = cc.FileUtils:getInstance():getWritablePath() .. "lua/57057/ActivityImperialBgPlus.lua"
		if cc.FileUtils:getInstance():isFileExist(file) then
			require "57057.ActivityImperialBgPlus"
			local node = ActivityImperialBg:create()
			if nil ~= node and nil ~= layer then
				layer:addChild(node)
				node:setLocalZOrder(91)
				node:setName("57057ImperialBg")
				resloaded = true
			end
		end
    end
    local resfile = "lua/57057/resources/activity_57057_new_res.plist"
    --print "resfile is"
    --print(resfile)
    setResToCache(resfile, resloaded)
    dict:setObject(CCString:create(tostring("57065")),"1")
	local act57065 = ActivityController:comFunc("getActObj",dict)
    --local act57065 = ActivityController:getInstance():getActObj("57065")
    if act57065 ~= nil then
		local file = cc.FileUtils:getInstance():getWritablePath() .. "lua/57065/ActivityImperial_elephantPlus.lua"
		local file_zip1 = cc.FileUtils:getInstance():getWritablePath() .. "tmpZR_57065.zip"
		local file_zip2 = cc.FileUtils:getInstance():getWritablePath() .. "tmpZR_57065_a.zip"
		if cc.FileUtils:getInstance():isFileExist(file) and cc.FileUtils:getInstance():isFileExist(file_zip1)==false and cc.FileUtils:getInstance():isFileExist(file_zip2)==false then
			require "57065.ActivityImperial_elephantPlus"
			local node = ActivityImperial_elephant:create()
			if nil ~= node and nil ~= layer then
				layer:addChild(node)
				node:setLocalZOrder(20460)
				node:setName("ActivityImperialElephant")
				resloaded = true
			end
		end
	else
		--print("act57065 = nil")
	end
	dict:setObject(CCString:create(tostring("57066")),"1")
	local act57066 = ActivityController:comFunc("getActObj",dict)
	--local act57066 = ActivityController:getInstance():getActObj("57066")
    if act57066 ~= nil then
		local file = cc.FileUtils:getInstance():getWritablePath() .. "lua/57066/ActivityImperial_yinghuaPlus.lua"
		local file_zip1 = cc.FileUtils:getInstance():getWritablePath() .. "tmpZR_57066.zip"
		local file_zip2 = cc.FileUtils:getInstance():getWritablePath() .. "tmpZR_57066_a.zip"
		if cc.FileUtils:getInstance():isFileExist(file) and cc.FileUtils:getInstance():isFileExist(file_zip1)==false and cc.FileUtils:getInstance():isFileExist(file_zip2)==false then
			require "57066.ActivityImperial_yinghuaPlus"
			local node = ActivityImperial_yinghua:create()
			if nil ~= node and nil ~= layer then
				layer:addChild(node)
				node:setLocalZOrder(150)
				node:setName("ActivityImperialYingHua")
				resloaded = true
			end
		end
	else
		--print("act57066 = nil")
	end
	local playerInfo = GlobalData:comFunc("getPlayerInfo",0)
	--local playerInfo = GlobalData:shared():getPlayerInfo()
	local crossFightSrcServerId = playerInfo:getProperty("crossFightSrcServerId")
    if tostring(crossFightSrcServerId)=="-1" then--跨服不参加活动
    	dict:setObject(CCString:create(tostring("57067")),"1")
		local act57067 = ActivityController:comFunc("getActObj",dict)
		--local act57067 = ActivityController:getInstance():getActObj("57067")
	    if act57067 ~= nil then
	    	local file_zip1 = cc.FileUtils:getInstance():getWritablePath() .. "tmpZR_57067.zip"
			local file_zip2 = cc.FileUtils:getInstance():getWritablePath() .. "tmpZR_57067_a.zip"
			local file = cc.FileUtils:getInstance():getWritablePath() .. "lua/57067/ActivityImperial_postPlus.lua"
			if cc.FileUtils:getInstance():isFileExist(file) and cc.FileUtils:getInstance():isFileExist(file_zip1)==false and cc.FileUtils:getInstance():isFileExist(file_zip2)==false then
				require "57067.ActivityImperial_postPlus"
				local node = ActivityImperial_post:create()
				if nil ~= node and nil ~= layer then
					layer:addChild(node)
					node:setLocalZOrder(300)
					node:setName("ActivityImperialPost")
					resloaded = true
				end
			end
		else
			--print("act57067 = nil")
		end
	else
		--print("init57067-crossFightSrcServerId:"..crossFightSrcServerId)
	end
	dict:setObject(CCString:create(tostring("57069")),"1")
	local act57069 = ActivityController:comFunc("getActObj",dict)
	--local act57069 = ActivityController:getInstance():getActObj("57069")
    if act57069 ~= nil then
		local file = cc.FileUtils:getInstance():getWritablePath() .. "lua/57069/ActivityImperial_57069Plus.lua"
		local file_zip1 = cc.FileUtils:getInstance():getWritablePath() .. "tmpZR_57069.zip"
		local file_zip2 = cc.FileUtils:getInstance():getWritablePath() .. "tmpZR_57069_a.zip"
		if cc.FileUtils:getInstance():isFileExist(file) and cc.FileUtils:getInstance():isFileExist(file_zip1)==false and cc.FileUtils:getInstance():isFileExist(file_zip2)==false then
			require "57069.ActivityImperial_57069Plus"
			local node = ActivityImperial_57069:create()
			if nil ~= node and nil ~= layer then
				layer:addChild(node)
				node:setLocalZOrder(300)
				node:setName("ActivityImperial57069")
				resloaded = true
			end
		end
	else
		--print("act57069 = nil")
	end
	dict:setObject(CCString:create(tostring("57074")),"1")
	local act57074 = ActivityController:comFunc("getActObj",dict)
	--local act57074 = ActivityController:getInstance():getActObj("57074")
    if act57074 ~= nil then
		local file = cc.FileUtils:getInstance():getWritablePath() .. "lua/57074/ActivityImperial_japanPlus.lua"
		local file_zip1 = cc.FileUtils:getInstance():getWritablePath() .. "tmpZR_57074.zip"
		local file_zip2 = cc.FileUtils:getInstance():getWritablePath() .. "tmpZR_57074_a.zip"
		if cc.FileUtils:getInstance():isFileExist(file) and cc.FileUtils:getInstance():isFileExist(file_zip1)==false and cc.FileUtils:getInstance():isFileExist(file_zip2)==false then
			require "57074.ActivityImperial_japanPlus"
			local node = ActivityImperial_japan:create()
			if nil ~= node and nil ~= layer then
				layer:addChild(node)
				node:setLocalZOrder(2050)
				node:setName("ActivityImperialJapan")
				resloaded = true
			end
		end
	else
		--print("act57074 = nil")
	end

	dict:setObject(CCString:create(tostring("57079")),"1")
	local act57079 = ActivityController:comFunc("getActObj",dict)
    if act57079 ~= nil then
		local file = cc.FileUtils:getInstance():getWritablePath() .. "lua/57079/ActivityImperial_beefPlus.lua"
		local file_zip1 = cc.FileUtils:getInstance():getWritablePath() .. "tmpZR_57079.zip"
		local file_zip2 = cc.FileUtils:getInstance():getWritablePath() .. "tmpZR_57079_a.zip"
		if cc.FileUtils:getInstance():isFileExist(file) and cc.FileUtils:getInstance():isFileExist(file_zip1)==false and cc.FileUtils:getInstance():isFileExist(file_zip2)==false then
			require "57079.ActivityImperial_beefPlus"
			local node = ActivityImperial_beefPlus:create()
			if nil ~= node and nil ~= layer then
				layer:addChild(node)
				node:setLocalZOrder(2050)
				node:setName("ActivityImperialBeefPlus")
				resloaded = true
			end
		end
	else
		print("act57079 = nil")
	end

	dict:setObject(CCString:create(tostring("57087")),"1")
	local act57087 = ActivityController:comFunc("getActObj",dict)
    if act57087 ~= nil then
		local file = cc.FileUtils:getInstance():getWritablePath() .. "lua/57087/ActivityImperial_HeroPlus.lua"
		local file_zip1 = cc.FileUtils:getInstance():getWritablePath() .. "tmpZR_57087.zip"
		local file_zip2 = cc.FileUtils:getInstance():getWritablePath() .. "tmpZR_57087_a.zip"
		if cc.FileUtils:getInstance():isFileExist(file) and cc.FileUtils:getInstance():isFileExist(file_zip1)==false and cc.FileUtils:getInstance():isFileExist(file_zip2)==false then
			require "57087.ActivityImperial_HeroPlus"
			local node = ActivityImperial_HeroPlus:create()
			if nil ~= node and nil ~= layer then
				print("use new item")
				layer:addChild(node)
				node:setLocalZOrder(2050)
				node:setName("ActivityImperialHeroPlus")
				resloaded = true
			end
		end
	else
		print("act57087 = nil")
	end

	dict:setObject(CCString:create(tostring("57112")),"1")
	local act57112 = ActivityController:comFunc("getActObj",dict)
    if act57112 ~= nil then
    	MyPrint("act57112 ~= nil")
		local file = cc.FileUtils:getInstance():getWritablePath() .. "lua/57112/WangLihongNpc.lua"
		local file_zip1 = cc.FileUtils:getInstance():getWritablePath() .. "tmpZR_57112.zip"
		local file_zip2 = cc.FileUtils:getInstance():getWritablePath() .. "tmpZR_57112_a.zip"
		if cc.FileUtils:getInstance():isFileExist(file) and cc.FileUtils:getInstance():isFileExist(file_zip1)==false and cc.FileUtils:getInstance():isFileExist(file_zip2)==false then
			require "57112.WangLihongNpc"
			if nil ~= WangLihongNpcController then
				WangLihongNpcController.getInstance():onImperialEnter()
			end
		end
	else
		print("act57112 = nil")
	end
	
	dict:setObject(CCString:create(tostring("57139")),"1")
	MyPrint("check 57139")
	local act57139 = ActivityController:comFunc("getActObj",dict)
    if act57139 ~= nil then
    	MyPrint("act57139 ~= nil")
    	local chechV = "2.24.0"
		dict:setObject(CCString:create(tostring(chechV)),"1")
		local file = cc.FileUtils:getInstance():getWritablePath() .. "lua/57139/ActivityDMW.lua"
		local file_zip1 = cc.FileUtils:getInstance():getWritablePath() .. "tmpZR_57139.zip"
		local file_zip2 = cc.FileUtils:getInstance():getWritablePath() .. "tmpZR_57139_a.zip"
		if CCCommonUtilsForLua:comFunc("checkVersion",dict):getValue() == true and cc.FileUtils:getInstance():isFileExist(file) and cc.FileUtils:getInstance():isFileExist(file_zip1)==false and cc.FileUtils:getInstance():isFileExist(file_zip2)==false then
			require "57139.ActivityDMW"
			if nil ~= DmwController then
				DmwController.getInstance():onImperialEnter()
			end
		end
	else
		print("act57139 = nil")
	end
	
	return true
end

function useKingRightsSkill(skillid,pValue)
	local path = cc.FileUtils:getInstance():getWritablePath() .. "lua"
	if isLibExist(path,"kingrights.KingRightsDataPlus") == true then
		if KingRightsMap == nil then
			--print("KingRightsMap is nil")
			return
		end
		if KingRightData == nil then
			--print("KingRightData is nil")
			return
		end
		if kingRightsBeforeSendUseSkillCMDCheck(skillid) == true then
			kingRightsSendUseSkillCMD(skillid,0,tostring(pValue))
		end
	end
end

function checkKingRightsSkill(fpath,skilltype)
	print "checkKingRightsSkill"
	local path = cc.FileUtils:getInstance():getWritablePath() .. "lua"
	if isLibExist(path,"kingrights.KingRightsDataPlus") == true then
		if KingRightsMap == nil then
			initKingRights()
			return 0
		end
		if KingRightData == nil then
			return 0
		end
		
		if tonumber(skilltype) == 17 then  -- 丰收技能
			local localData = KingRightsMap["1503008"]
			if localData ~= nil then
				if localData["needEdition"] ~= nil then
					local chechV = tostring(localData["needEdition"])
					local dict = CCDictionary:create()
					dict:setObject(CCString:create(tostring(chechV)),"1")
					if CCCommonUtilsForLua:comFunc("checkVersion",dict):getValue() == false then
					--if CCCommonUtilsForLua:checkVersion(chechV) == false then
						return 0
					end
				end
				local canUse = false
				if localData["canUse"] == nil then
					if KingRightsUI == nil then
						return 0
					end
					local uiTab = KingRightsUI[2][2]
					if uiTab ~= nil then
           				if table.indexof(uiTab,"1503008_1",1) == false then
							return 0
						else
							canUse = true
						end
					end
				elseif localData["canUse"] == true then
				    canUse = true
				end
				if canUse == true then
					local check,skCate,cost,have = checkKingrightsPrivilige(localData,nil,0)
					if check == 1 then
						return 1
					end
				end
			end
		end
	end
	return 0
end

function purgeActData()

end

function checkLoginDataState(path,name)
	if name == "init_knight" then
		if cc.FileUtils:getInstance():isFileExist(path .. "/knight/KnightTitleControllerPlus.lua") then
    		require("knight.KnightTitleControllerPlus")
			return KnightTitleController:getInstance():isInit()
		end
	elseif name == "" then
	end
	return 0
end

function createActivityAdCellByActMain( actId )
	dump(" createActivityAdCellByActMain actId is: "..tostring(actId))
	local path = cc.FileUtils:getInstance():getWritablePath().."lua/"

	-- 新统一加载逻辑
	path = path .."ActivityListCellSprite.lua"
	if cc.FileUtils:getInstance():isFileExist(path) then
		dump(" createActivityAdCellByActMain use newCell ~~~~~~~~~~~path is: "..tostring(path))
		local actvityCell = require("ActivityListCellSprite")
		return actvityCell:create(actId)
	end

	path = path .. actId .."/ActivityAdCellPlus.lua"
	if cc.FileUtils:getInstance():isFileExist(path) then
		dump(" createActivityAdCellByActMain use oldCell ~~~~~~~~~~~old path is: "..tostring(path))
		require(actId .. ".ActivityAdCellPlus")
		return ActivityAdCellPlus:create(actId)
	end
	return nil
end

function createActivityListCellSpriteByActMain( actId )
	local path = cc.FileUtils:getInstance():getWritablePath().."lua/"

	-- 新统一加载逻辑
	path = path .."ActivityListCellIcon.lua"
	if cc.FileUtils:getInstance():isFileExist(path) then
		dump(" createActivityListCellSpriteByActMain use newCell ~~~~~~~~~~~path is: "..tostring(path))
		local actvityCell = require("ActivityListCellIcon")
		return actvityCell:create(actId)
	end

	path = path .. actId .."/ActivityListCellSpritePlus.lua"
	if cc.FileUtils:getInstance():isFileExist(path) then
		dump(" createActivityListCellSpriteByActMain use oldCell ~~~~~~~~~~~old path is: "..tostring(path))
		require(actId .. ".ActivityListCellSpritePlus")
		return ActivityListCellSpritePlus:create(actId)
	end
	return nil
end

function setResToCache( resfile, add )
	-- 异步加载资源的名称的缓存
	--print "setResToCache"
	local asynres = cc.UserDefault:getInstance():getStringForKey("dynamic.preload.res", "")
    local vvv = string.split(asynres, ";")
    if vvv == true or vvv == false then
    	return
    end
    if add == false then
    	--print "add == false"
    	for i,v in ipairs(vvv) do
    		--print(i,v)
    		if v == resfile then
    			vvv[i] = ""
    			break
    		end
    	end
    else
    	--print "add == true"
    	local already_have = false
    	for i,v in ipairs(vvv) do
    		print(i,v)
    		if v == resfile then
    			already_have = true
    			break
    		end
    	end
    	--print "already_have"
    	--print(already_have)
    	if already_have == false then
    		local cnt = table.getn(vvv)
    		vvv[cnt + 1] = resfile
    	end
    end
    local asynres_new = ""
    local alread_append = false
    for i,v in ipairs(vvv) do
    	if v ~= "" then
	    	if alread_append == true then
	    		asynres_new = asynres_new .. ";"
	    	end
	    	asynres_new = asynres_new .. v
	    	alread_append = true
	    end
    end
    --print("asynres_new >> " .. asynres_new)
    cc.UserDefault:getInstance():setStringForKey("dynamic.preload.res", asynres_new)
end

function createLoadingUi(pparent, idd)
	local checkTmpZip = cc.FileUtils:getInstance():getWritablePath() .. "tmpZR_" .. string.format(idd) .. ".zip"
	--print ("checkTmpZip :: " .. checkTmpZip)
	if cc.FileUtils:getInstance():isFileExist(checkTmpZip) then
		--print "1"
		return false
	end
		--print "2"
	if cc.FileUtils:getInstance():isFileExist(cc.FileUtils:getInstance():getWritablePath() .. "lua/" .. string.format(idd) .. "/loadinguiPlus.lua") == false then
		--print "3"
		return false
	end
	require (string.format(idd) .. ".loadinguiPlus")
	return loadingui:create(pparent, idd)
end

function showAvatarGround(name)
	local dict = CCDictionary:create()
	dict:setObject(CCString:create(tostring(name)),"1")
	if CCCommonUtilsForLua:comFunc("isTmpZipFileExist",dict):getValue() == true then
		return false
	end
	if cc.FileUtils:getInstance():isFileExist(cc.FileUtils:getInstance():getWritablePath() .. "lua/" .. string.format(name) .. "/avatarGroundPlus.lua") == false then
		return false
	end
	require (string.format(name) .. ".avatarGroundPlus")
	if nil == avatarGround then
		return false
	end
	if nil == avatarGround[name] then
		return false
	end
	return avatarGround[name]:create()
end

local function on_data_init_end_dy( dict )
	MyPrint("on_data_init_end_dy")

	-- 国王大厅相关数据处理
	initRefConfig()

	-- 王力宏活动
	local dict = CCDictionary:create()


	dict:setObject(CCString:create(tostring("57112")),"1")
	local act57112 = ActivityController:comFunc("getActObj",dict)
    if act57112 ~= nil then
    	MyPrint("act57112 ~= nil")
		local file = cc.FileUtils:getInstance():getWritablePath() .. "lua/57112/WangLihongNpc.lua"
		local file_zip1 = cc.FileUtils:getInstance():getWritablePath() .. "tmpZR_57112.zip"
		local file_zip2 = cc.FileUtils:getInstance():getWritablePath() .. "tmpZR_57112_a.zip"
		if cc.FileUtils:getInstance():isFileExist(file) and cc.FileUtils:getInstance():isFileExist(file_zip1)==false and cc.FileUtils:getInstance():isFileExist(file_zip2)==false then
			require "57112.WangLihongNpc"
			if nil ~= WangLihongNpcController then
				WangLihongNpcController.getInstance():onImperialEnter()
			end
		end
	else
		print("act57112 = nil")
	end

	-- 大魔王活动
	dict:setObject(CCString:create(tostring("57139")),"1")
	local act57139 = ActivityController:comFunc("getActObj",dict)
    if act57139 ~= nil then
    	MyPrint("act57139 ~= nil")
		local file = cc.FileUtils:getInstance():getWritablePath() .. "lua/57139/ActivityDMW.lua"
		local file_zip1 = cc.FileUtils:getInstance():getWritablePath() .. "tmpZR_57139.zip"
		local file_zip2 = cc.FileUtils:getInstance():getWritablePath() .. "tmpZR_57139_a.zip"
		if cc.FileUtils:getInstance():isFileExist(file) and cc.FileUtils:getInstance():isFileExist(file_zip1)==false and cc.FileUtils:getInstance():isFileExist(file_zip2)==false then
			require "57139.ActivityDMW"
			if nil ~= DmwController then
				DmwController.getInstance():onDataInitEnd()
			end
		end
	else
		print("act57139 = nil")
	end
	
	return true
end

local function on_purge_Controller_dy( dict )
	-- controller清理数据
	if nil ~= DmwController and nil ~= DmwController.purge then
		DmwController.purge()
	end

	return true
end

local function on_open_act_popup_dy( dict )
	local path = dict["path"]
	local actId = dict["actId"]
	-- 调用老的接口
	showActPopup(path, actId)
	return true
end

local function on_show_act_icon_dy( dict )
	local actId = dict["actId"]
	local path = dict["path"]

	-- 调用老的接口
	showActivityIcon(path, actId)

	return true
end

local function on_show_act_popup_with_config( dict )
	local path = dict["path"]
	local actId = dict["actId"]
	local config = dict["config"]
	
	-- 调用老接口
	showActPopupWithConfig(path, actId, config)

	return true
end

local function on_use_KingRightsSkill( dict )
	local skillid = dict["id"]
	local index = dict["index"]

	useKingRightsSkill(skillid,index)

	return true
end

-- 这个是2.15.0才加上去的
local g_fireEventTable_dy = 
{
	-- system
	{"purge_controller", on_purge_Controller_dy},
	{"data_init_end", on_data_init_end_dy},
	-- trigger
	{"on_Imperial_enter", onImperialEnter},
	{"on_Imperial_exit", on_Imperial_exit_dy},
	{"use_KingRightsSkill", on_use_KingRightsSkill},
	-- open ui
	{"open_act_popup", on_open_act_popup_dy},
	{"show_act_popup_with_config", on_show_act_popup_with_config},
	-- createicon
	{"show_act_icon", on_show_act_icon_dy},
}

function onFireDynamicEvent( eventID, dict )
	MyPrint("onFireDynamicEvent: " .. eventID)
	for k,v in ipairs(g_fireEventTable_dy) do
		if v[1] == eventID then
			local f = v[2]
			dump(dict)
			return f(dict)
		end
	end
	return false
end