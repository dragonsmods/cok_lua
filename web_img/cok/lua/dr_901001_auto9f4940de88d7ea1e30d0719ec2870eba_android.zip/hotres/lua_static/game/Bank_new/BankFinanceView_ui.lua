----------------------------
-- Author: Elex
-- Date: 2019-11-05 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local BankFinanceView_ui = class("BankFinanceView_ui")

--#ui propertys


--#function
function BankFinanceView_ui:create(owner, viewType, paramTable)
	local ret = BankFinanceView_ui.new()
	CustomUtility:DoRes(8, true)
	CustomUtility:LoadUi("BankFinanceView_Lua.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function BankFinanceView_ui:initLang()
end

function BankFinanceView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function BankFinanceView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function BankFinanceView_ui:onCloseClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onCloseClick", pSender, event)
end

function BankFinanceView_ui:onHelpButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onHelpButtonClick", pSender, event)
end

function BankFinanceView_ui:onStoreButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onStoreButtonClick", pSender, event)
end

function BankFinanceView_ui:onBagButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBagButtonClick", pSender, event)
end

function BankFinanceView_ui:onRecordButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onRecordButtonClick", pSender, event)
end

return BankFinanceView_ui

