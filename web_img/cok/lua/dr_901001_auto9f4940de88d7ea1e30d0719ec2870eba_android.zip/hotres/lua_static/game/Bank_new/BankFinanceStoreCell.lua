local BankFinanceStoreCell = class("BankFinanceStoreCell", 
	function() 
		return cc.TableViewCell:create()
	end
)

function BankFinanceStoreCell:create(data,index)
	-- MyPrint("-------call BankFinanceStoreCell:create -----")
	local view = BankFinanceStoreCell.new()
	require("game.Bank_new.BankFinanceStoreCell_ui"):create(view,1)
	if view:initView(data,index) == false then 
		view = nil 
	end

	return view
end

function BankFinanceStoreCell:initView(data,index)
	dump(data,"BankFinanceStoreCell data ")
	self.m_data = data
	self.m_index = index
	self.m_time = data.time
	self.base_id = self.m_data.type
	local str_time = format_time(self.m_time)
	self.ui.m_nameStoreLabel:setString(_lang( CCCommonUtilsForLua:getPropById(self.base_id,"name")))
	local icon_file = CCCommonUtilsForLua:getPropById(self.base_id,"pic")..".png"
	MyPrint("icon_file ,",icon_file)

	self.isLock = false

	-- self.m_data.payTotal = "30"

	if self.m_data.paygold and self.m_data.payTotal and tonumber(self.m_data.payTotal) < tonumber(self.m_data.paygold) then
		self.isLock = true
	end

	if not CCCommonUtilsForLua:isFunOpenByKey("new_bank_produce_limit") then -- 购买限制开关
		self.isLock = false
	end

	local spr_cion = CCLoadSprite:call("createSprite", icon_file)
	local str_rate = string.format("%0.2f%%",tostring(self.m_data.rate))
	self.ui.m_rateLabel_num:setString(str_rate)
	if tonumber(self.m_data.extraRate)>0 then
		local extra_rate = string.format( "%0.2f%%", self.m_data.extraRate)
		self.ui.m_extraRateNum:setString("+"..extra_rate)
		local size_w = self.ui.m_rateLabel_num:getPositionX() + self.ui.m_rateLabel_num:getContentSize().width
		self.ui.m_extraRateNum:setPositionX(size_w)
	end
	self.ui.m_iconNode:removeAllChildren()
	self.ui.m_iconNode:addChild(spr_cion)
	self.ui.m_cycleLabel:setString(_lang("149304"))
	self.ui.m_cycleLabel_time:setString(str_time)
	self.ui.m_rateLabel:setString(_lang("149305"))	
	self.ui.m_getStoreButton:setTitleForState(_lang("149306"), cc.CONTROL_STATE_NORMAL)

	self.ui.m_endLabel:setString(_lang("660930")) -- 660930=购买截止
	local act = ActivityController:call("getActObj", self.m_data.activityId)
	-- dump(self.m_data.activityId, "self.m_data.activityId")
	-- dump(act, "act")
	if act then
		local startTime = tonumber(act:getProperty("startTime"))
		local endTime = tonumber(act:getProperty("endTime"))
		local now = getWorldTime()
		-- dump(startTime, "activity startTime")
		-- dump(endTime, "activity endTime")
		if startTime <= now and now < endTime then
			self.ui.m_endLabel_time:setString(format_time(endTime-now)) -- 理财产品的活动时间倒计时
		else
			self.ui.m_endLabel_time:setString(_lang("660931")) -- 660931=已结束
		end
	else
		self.ui.m_endLabel_time:setString(_lang("660931")) -- 660931=已结束
	end
	
	-- self.ui.m_endLabel:setString(_lang("149304"))
	-- self.ui.m_endLabel_time:setString(str_time)

	if self.isLock then
		local icon_lock = "img_lock.png"
		local spr_lock = CCLoadSprite:call("createSprite", icon_lock)
		self.ui.m_iconNode:addChild(spr_lock)
		
		spr_cion:setColor(cc.c3b(120,120,120))
		CCCommonUtilsForLua:call("setSpriteGray", spr_cion, true)
	end

	self.ui.m_buyLimitLabel:setString(_lang("660941")) -- 660941=购买数量
	local now_count = BankController:getInstance():getFinanceCountByProductID(self.m_data.type)
	--local max_count = BankController:getInstance():getFinanceMaxCount(self.m_data.currType, self.m_data.currId)
	self.ui.m_buyCountLabel:setString(tostring(now_count))

	return true
end	


function BankFinanceStoreCell:onGetStoreButtonClick(pSender, event) 
	-- local  cmd = require("game.Bank_new.BankProductsBuyCmd"):create()

	local function confirmFunc()
     	-- PopupViewController:call("removePopupView",self)
     	-- PopupViewController:call("removeAllPopupView")
     	LiBaoController.getInstance():showLiBaoView("showExchangePopup")
    end

	if self.isLock then
		local text = getLang("149475",self.m_data.paygold) -- 需累计充值达到{0}才可购买该档产品。\n是否立即前往解锁？
		local btnText = getLang("149476") -- 前往解锁

		Dprint(" @@ BankFinanceStoreCell ",text , btnText)
    	local dia = YesNoDialog:show(text, confirmFunc)

    	dia:call("setYesButtonTitle", btnText)
	else
		local view  = Drequire("game.Bank_new.BankSaveDrawView"):create(self.m_data,nil,nil,BankViewType.BANK_FINANCE)
		PopupViewController:call("addPopupView", view)	
		MyPrint("BankFinanceStoreCell:onGetStoreButtonClick")
	end
end

return BankFinanceStoreCell
