----------------------------
-- Author: Elex
-- Date: 2017-10-17 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local BankMainBagCell_ui = class("BankMainBagCell_ui")

--#ui propertys


--#function
function BankMainBagCell_ui:create(owner, viewType)
	local ret = BankMainBagCell_ui.new()
	CustomUtility:LoadUi("BankMainBagCell.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function BankMainBagCell_ui:initLang()
end

function BankMainBagCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function BankMainBagCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function BankMainBagCell_ui:onDesBagButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onDesBagButtonClick", pSender, event)
end

function BankMainBagCell_ui:onDesOkButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onDesOkButtonClick", pSender, event)
end

return BankMainBagCell_ui

