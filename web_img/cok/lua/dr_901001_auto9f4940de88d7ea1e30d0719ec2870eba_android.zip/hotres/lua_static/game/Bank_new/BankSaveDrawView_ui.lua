----------------------------
-- Author: Elex
-- Date: 2018-12-10 Monday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local BankSaveDrawView_ui = class("BankSaveDrawView_ui")

--#ui propertys


--#function
function BankSaveDrawView_ui:create(owner, viewType, paramTable)
	local ret = BankSaveDrawView_ui.new()
	CustomUtility:DoRes(305, true)
	CustomUtility:DoRes(7, true)
	CustomUtility:DoRes(8, true)
	CustomUtility:LoadUi("BankSaveDrawView_Lua_1.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function BankSaveDrawView_ui:initLang()
end

function BankSaveDrawView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function BankSaveDrawView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function BankSaveDrawView_ui:onClickCloseBtn(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickCloseBtn", pSender, event)
end

function BankSaveDrawView_ui:onOkButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onOkButtonClick", pSender, event)
end

return BankSaveDrawView_ui

