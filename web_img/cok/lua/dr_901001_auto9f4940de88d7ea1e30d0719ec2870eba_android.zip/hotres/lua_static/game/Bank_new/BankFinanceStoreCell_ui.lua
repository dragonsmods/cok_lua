----------------------------
-- Author: Elex
-- Date: 2019-11-07 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local BankFinanceStoreCell_ui = class("BankFinanceStoreCell_ui")

--#ui propertys


--#function
function BankFinanceStoreCell_ui:create(owner, viewType, paramTable)
	local ret = BankFinanceStoreCell_ui.new()
	CustomUtility:DoRes(7, true)
	CustomUtility:LoadUi("BankFinanceStoreCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function BankFinanceStoreCell_ui:initLang()
end

function BankFinanceStoreCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function BankFinanceStoreCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function BankFinanceStoreCell_ui:onDesStoreButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onDesStoreButtonClick", pSender, event)
end

function BankFinanceStoreCell_ui:onGetStoreButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onGetStoreButtonClick", pSender, event)
end

return BankFinanceStoreCell_ui

