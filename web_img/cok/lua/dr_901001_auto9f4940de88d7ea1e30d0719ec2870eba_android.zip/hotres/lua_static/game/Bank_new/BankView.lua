local BankView = class("BankView", 
	function() 
		return PopupBaseView:create() 
	end
)

function BankView:create()
	MyPrint("-------call BankView:create -----")
	local view = BankView.new()
	require("game.Bank_new.BankView_ui"):create(view,1)
	if view:initBase() == false then 
	 	view = nil 
	end

	return view
end

function BankView:initBase(  )
	self.m_tabIndex = 1
	self.m_tabView = {}
	self:setIsHDPanel(true)
	
	self.ui.m_bagButton:setEnabled(true)
	self.ui.m_detailLabel:setString(_lang("149301"))
	self.ui.m_detailLabel:setString(_lang("149301"))
	self.ui.m_recordButton:setTitleForState(_lang("149208"), cc.CONTROL_STATE_NORMAL)
	self.ui.m_titleTxt:setString(_lang("149300"))

	self.ui.m_storeButton:setTitleForState(_lang("149302"), cc.CONTROL_STATE_NORMAL)	
	self.ui.m_bagButton:setTitleForState(_lang("149303"), cc.CONTROL_STATE_NORMAL)	
	self.ui.m_storeButton:setEnabled(false)
	CCLoadSprite:call("loadDynamicResourceByName", "bank_new")
	return true
end

function BankView:initView(index)
	self:createTabView(index)
	self:setLatestLabel()
	return true
end

function BankView:setLatestLabel()
	if self.m_entryId then
        cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.m_entryId)
        self.m_entryId = nil
    end
    self.d_time = nil
	local list = BankController:getInstance().m_deposit_list
    if list == nil or #list < 1 then 
		self.ui.m_deadlineLabel:setString(_lang("149316"))
	else
		local cell = nil 
		for k,v in pairs(list ) do 
			if cell == nil then 
				cell = v 
			end
			if cell.endTime/1000 > v.endTime/1000 then 
				cell = v 
			end
		end
		if cell == nil  then 
			return 
		end
		local now_time = getTimeStamp()
    	self.d_time  = (cell.endTime/1000 - now_time )
    	---启动upodate
		if self.m_entryId then
        	cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.m_entryId)
        	self.m_entryId = nil 
    	end
    	self.m_entryId = cc.Director:getInstance():getScheduler():scheduleScriptFunc(function(dt) self:update(dt) end, 1, false)
	end
end

function BankView:update(t)
	if self.d_time == nil then 
		return 
	end
	
	self.d_time = self.d_time - t 
	if self.d_time < 0 then 
    	self.d_time = 0
    	self.ui.m_deadlineLabel:setString(_lang("149465"))
    	self:refreshTip()
    	self:setLatestLabel()
    else
		local str_left_time = format_time(self.d_time )
		self.ui.m_deadlineLabel:setString(_lang_1("149315",str_left_time))
    end
end

function BankView:createTabView(index)
	MyPrint("createTabView index",index)
	-- self.ui.m_bagListNode:setContentSize(cc.size(640, 500))
	if self.m_tabView[index] == nil then
		local delegate = {}
		delegate.gridAtIndex = function(tab, idx) return self:gridAtIndex(tab, idx) end
	    delegate.numberOfCellsInTableView = function(tab) return self:numberOfCellsInTableView(tab) end
	    delegate.numberOfGridsInCell = function(tab) return self:numberOfGridsInCell(tab) end
	    delegate.gridSizeForTable = function(tab, idx) return self:gridSizeForTable(tab, idx) end

	    local list_size = self.ui.m_bagListNode:getContentSize()
	   	self.m_tabView[index]= require("game.utility.TableViewMultiCol").new(list_size)
	    self.m_tabView[index]:setDelegate(delegate)
		self.m_tabView[index]:setDirection(kCCScrollViewDirectionVertical)
		self.m_tabView[index]:setVerticalFillOrder(kCCTableViewFillTopDown)
		self.ui.m_bagListNode:addChild(self.m_tabView[index])
	end
	self.m_tabView[index]:reloadData()
end

function BankView:onEnter()
	Drequire("game.Bank_new.BankProductsCmd")
	local function onBankListCBack( ref )
        self:onRefreshBankList(ref)
        self:refreshTip()
        self:setLatestLabel()
    end
	local handler = self:registerHandler(onBankListCBack)

	local function onReLoadInBag( ref )
		ref = tolua.cast(ref, "CCString")
		local key = ref:getCString()
		MyPrint("onReload key =",key)
		BankController:getInstance():removeDepositByKey(key)
		self:onBagButtonClick()
		self:setLatestLabel()
		self:refreshTip()
	end
	local handler2 = self:registerHandler(onReLoadInBag)

	local function onBuyItemBack( ref )
        local delayS = function()
            BankController:getInstance():refreshDeposit()
        end
        local node = cc.Node:create()
        self:addChild(node)
        performWithDelay(node,delayS,1)
    end
	local handler3 = self:registerHandler(onBuyItemBack)
    CCSafeNotificationCenter:registerScriptObserver(self, handler, "MSG_REFRESH_BANK_LIST")
    CCSafeNotificationCenter:registerScriptObserver(self, handler2, "MSG_RELOAD_BANK_BAG")
    CCSafeNotificationCenter:registerScriptObserver(self, handler3, "MSG_BANG_BUY")

    if self.m_entryId then
        cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.m_entryId)
        self.m_entryId = nil 
    end
    self.m_entryId =  cc.Director:getInstance():getScheduler():scheduleScriptFunc(function(dt) self:update(dt) end, 1, false)

    local cmd = BankProductsCmd:create()
	cmd:send()
end

function BankView:onExit( )
	CCSafeNotificationCenter:unregisterScriptObserver(self, "MSG_REFRESH_BANK_LIST")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "MSG_RELOAD_BANK_BAG")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "MSG_BANG_BUY")
	if self.m_entryId then
        cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.m_entryId)
    end
end

function BankView:onRefreshBankList( ref )
	local tbl = dictToLuaTable(ref)
	if (tbl.cmd == "bank.enter" and self.m_tabIndex == 1 ) or (tbl.cmd == "bank.getDeposit" and self.m_tabIndex == 2)then 
		self:initView(self.m_tabIndex)
	end
end

function BankView:gridAtIndex(tab, idx)
	local cell = tab:dequeueGrid()
	if self.m_tabIndex == 1 then 
		local index = idx + 1
		MyPrint("create BankMainStoreCell ",index)
		local list = BankController:getInstance().m_product_list
		if cell then
			cell:initView(list[index],index)
		else
			cell = Drequire("game.Bank_new.BankMainStoreCell"):create(list[index],index)
		end
		return cell
	elseif  self.m_tabIndex == 2 then
		local index = idx + 1
		MyPrint("create BankMainBagCell ",index)
		local list = BankController:getInstance().m_deposit_list
		if cell then
			cell:initView(list[index],index)
		else
			cell = Drequire("game.Bank_new.BankMainBagCell"):create(list[index],index)
		end
		return cell
	end
end

function BankView:numberOfCellsInTableView(tab)
	if  self.m_tabIndex == 1 then 
		return #BankController:getInstance().m_product_list
	elseif  self.m_tabIndex == 2 then 
		return #BankController:getInstance().m_deposit_list
	end
end

function BankView:numberOfGridsInCell(tab)
	return 1
end

function BankView:gridSizeForTable(tab, idx)
	if self.m_tabIndex == 1 then 
		return 640,156
	else
		return 640,160
	end 
end

function BankView:onStoreButtonClick( pSender)
	self.ui.m_storeButton:setEnabled(false)
	self.ui.m_bagButton:setEnabled(true)
	self.m_tabIndex = 1
   for i = 1, 2,1 do
        if self.m_tabView[i] then
            self.m_tabView[i]:setVisible(false)
        end
    end
    if self.m_tabView[1] ~= nil then 
		self.m_tabView[1]:setVisible(true)
		self.m_tabView[1]:reloadData()
	else
		local cmd = BankProductsCmd:create()
		cmd:send()
	end 
end

function BankView:onBagButtonClick( pSender )
	self.ui.m_storeButton:setEnabled(true)
	self.ui.m_bagButton:setEnabled(false)
	self.m_tabIndex = 2
    for i = 1, 2 ,1 do
        if self.m_tabView[i] then
            self.m_tabView[i]:setVisible(false)
        end
    end
	if self.m_tabView[self.m_tabIndex] == nil then 
		local cmd = BankGetDeposit:create()
		cmd:send()
		return
	end
	-- if BankController:getInstance():refreshDeposit() == true then
	-- 	 return 
	-- end

	self.m_tabView[2]:setVisible(true)
	self.m_tabView[2]:reloadData()
end

function BankView:reFreshBagView()

end

function BankView:onHelpButtonClick(pSender)
    FaqHelper:call("showSingleFAQ", "45278")
end

function BankView:onCloseClick(pSender)
	PopupViewController:call("removePopupView", self)
end

function BankView:onRecordButtonClick(pSender )
	local view = Drequire("game.Bank_new.BankRecordView"):create()
	PopupViewController:call("addPopupView", view)
end

function BankView:refreshTip()
	if BankController:getInstance():haveCanGet() then
		self.ui.m_tipSpr:setVisible(true)
	else
		self.ui.m_tipSpr:setVisible(false)
	end
end
return BankView

