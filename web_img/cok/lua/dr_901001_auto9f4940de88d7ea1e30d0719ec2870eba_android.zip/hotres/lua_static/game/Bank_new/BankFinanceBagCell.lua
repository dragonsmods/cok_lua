local BankFinanceBagCell = class("BankFinanceBagCell", 
	function() 
		return cc.TableViewCell:create()
	end
)

function BankFinanceBagCell:create(data,index)
	-- MyPrint("-------call BankFinanceBagCell:create -----")
	local view = BankFinanceBagCell.new()
	require("game.Bank_new.BankFinanceBagCell_ui"):create(view,1)
	if view:initView(data,index) == false then 
		view = nil 
	end

	return view
end

function BankFinanceBagCell:initView(data,index)
	-- dump(data,"initView data")
	self.m_data = data
	self.m_index = index
	self.m_endTime = data.endTime/1000
	self.base_id = self.m_data.type
	self.m_key = data.key
	self.ui.m_nameBagLabel:setString(_lang( CCCommonUtilsForLua:getPropById(self.base_id,"name")))
	self.ui.m_desBagButton:setTitleForState(_lang("149306"), cc.CONTROL_STATE_NORMAL)

	local planed_gold =math.ceil(((tonumber(data.extraRate)+tonumber(data.rate))/100+ 1)* self.m_data.num)
	self.ui.m_planLabel:setString(_lang("149317"))
	self.ui.m_goldLabel:setString(_lang("149318"))
	self.ui.m_timeLabel:setString(_lang("149319"))
	self.ui.m_limitLabel:setString(_lang("149320"))
	self.ui.m_planNumLabel:setString(CC_CMDITOA(planed_gold))
	self.ui.m_goldNumLabel:setString(CC_CMDITOA(self.m_data.num))
	self.ui.m_desOkButton:setVisible(false)
	self.ui.m_desBagButton:setVisible(true)
	local now_time =  getTimeStamp()
    self.d_time  = (self.m_endTime - now_time )
    local str_end_time = CCCommonUtilsForLua:call("timeStampToDHM",self.m_endTime)
	self.ui.m_timeEnd:setString(str_end_time)
	local began_data =CCCommonUtilsForLua:call("timeStampToDHM",self.m_endTime - data.time)
	self.ui.m_timeStart:setString(began_data)
	-- MyPrint("self.d_time ",self.d_time,"endtime ",self.m_endTime," now_time ",now_time)
	if self.m_endTime <= now_time then --已经到时间可以领取
		self.ui.m_desOkButton:setTitleForState(_lang("149321"), cc.CONTROL_STATE_NORMAL)
		self.ui.m_desOkButton:setVisible(true)
		self.ui.m_desBagButton:setVisible(false)
	end

	local icon = CCCommonUtilsForLua:getPropById(self.m_data.type,"icon")
	if icon == nil or icon == "" then
		icon = "ui_gold.png"
	end
    self.ui.m_icon_1:setSpriteFrame(CCLoadSprite:call("loadResource", icon))
    self.ui.m_icon_2:setSpriteFrame(CCLoadSprite:call("loadResource", icon))
    local size = self.ui.m_icon_1:getContentSize()
    self.ui.m_icon_1:setScale(25/size.width)
    self.ui.m_icon_2:setScale(25/size.width)
	return true
end	

function BankFinanceBagCell:update(t)
    self.d_time  = self.d_time - t
    local str_left_time = format_time(self.d_time)
    self.ui.m_timeEnd:setString(str_left_time)
end


function BankFinanceBagCell:onDesBagButtonClick(pSender, event) 
	-- local  cmd = require("game.Bank_new.BankProductsBuyCmd"):create()
	local view  = Drequire("game.Bank_new.BankSaveDrawView"):create(self.m_data,self.m_index,2,BankViewType.BANK_FINANCE)
	PopupViewController:call("addPopupView", view)
	-- MyPrint("BankFinanceBagCell:onDesBagButtonClick")
end

function BankFinanceBagCell:onDesOkButtonClick(pSender, event)
	-- if ElexSdkUtil:call("getIsWatched") then
 --        CCCommonUtilsForLua:call("flyHint", "", "", getLang("149454"))
 --        return
 --    end

	local cmd = BankDrawMoneyCmd:create(self.m_key)
    cmd:send()
end
return BankFinanceBagCell
