local CrossServerRewardCell = class("CrossServerRewardCell",
	function()
		return cc.Layer:create()
	end
)


function CrossServerRewardCell:create(idx)
	local cell = CrossServerRewardCell.new()
	Drequire("game.crossThrone.CrossServerRewardCell_ui"):create(cell)
	return cell
end

function CrossServerRewardCell:refreshCell(data, idx)
	local itemId = data.itemId
    local desc = data.desc
    local num = data.num

	self.ui.m_iconNode:removeAllChildren()

	local itemData = {
        type = 0,
        itemId = atoi(itemId)
    }

    LibaoCommonFunc.createDataItemTouchNode(
        {
            itemData = {
                            type = 0,
                            itemId = atoi(itemId),
                            desScale = isPad and 1.8 or 1,
                        },
            iconNode = self.ui.m_iconNode,
            iconSize = 56,
            beTouch = true,
        }
    )

    local bg = self.ui.m_iconNode:getChildByTag(GOODS_BG_TAG)
    if bg then
        local color = CCCommonUtilsForLua:call("getPropById", tostring(itemId), "color")
        local bgPath = getItemBgByColor(atoi(color))
        bg:setSpriteFrame(CCLoadSprite:call("loadResource", bgPath))
    end

    local icon_bg = CCLoadSprite:call("createSprite", "BG_zhuangbeiwaikuang.png")
    icon_bg:setScale(0.6)
    self.ui.m_iconNode:addChild(icon_bg)

    if num then 
        self.ui.m_numLabel:setVisible(true)
        self.ui.m_numLabel:setString("  x" .. num) 
    end 
   
    self.ui.m_desLabel:setString(getLang(desc))
end

function CrossServerRewardCell:onEnter( ... )

end

function CrossServerRewardCell:onExit( ... )

end

return CrossServerRewardCell