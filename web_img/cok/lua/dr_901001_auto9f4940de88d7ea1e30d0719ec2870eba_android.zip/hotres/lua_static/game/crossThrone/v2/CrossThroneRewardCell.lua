local CrossThroneRewardCell = class("CrossThroneRewardCell", cc.Layer)

function CrossThroneRewardCell:create()
    local cell = CrossThroneRewardCell.new()
    Drequire("game.crossThrone.v2.CrossThroneRewardCell_ui"):create(cell, 0)
    cell.ui.m_btn:setSwallowsTouches(false)
    return cell
end

function CrossThroneRewardCell:refreshCell(info, idx)
    self.info = info

    self.ui.m_node1:setVisible(false)
    self.ui.m_node2:setVisible(false)
    self.ui.m_node3:setVisible(false)
    self.ui.m_rwdNode:removeAllChildren()

    if info._type == 1 then
        self:refreshArrow()
        self.ui.m_node1:setVisible(true)

        local rParam = self:getRealParam(info.param)
        self.ui.m_text1:setString(getLang("52045407", rParam))
    elseif info._type == 2 then
        self.ui.m_node2:setVisible(true)
    else
        local rParam = self:getRealParam(info.param)
        self.ui.m_text3:setString(rParam)
        self.ui.m_node3:setVisible(true)
        self:showReward()
    end 
end

local internal = 60
function CrossThroneRewardCell:showReward()
    local reward = GlobalData:call("getCachedRewardData", self.info.rewardId)
    local rewardData = arrayToLuaTable(reward)

    local rewardItems = {}
    for _, rwd in ipairs(rewardData or {}) do
        if rwd.type == "7" then
            rwd.value.type = 0
            table.insert(rewardItems, rwd.value)
        elseif rwd.type == "14" then
            rwd.value.type = 1
            table.insert(rewardItems, rwd.value)
        end
    end

    local startX = 0
    for index, reward in ipairs(rewardItems) do 
        local node = getRewardItemNode(reward, 45, true, true)
        node:setPositionX(startX)
        self.ui.m_rwdNode:addChild(node)
        startX = startX + internal
    end
end


function CrossThroneRewardCell:getRealParam(param)
    local solt = splitString(param, "-")
    if solt[1] == solt[2] then
        return solt[1]
    end

    return param
end

function CrossThroneRewardCell:refreshArrow()
    if self.info.open then
        self.ui.m_groupArrow:setRotation(90)
    else
        self.ui.m_groupArrow:setRotation(0)
    end
end

function CrossThroneRewardCell:onClickGroup()
    if self.info.cb then
        self.info.open = not self.info.open
        self.info.cb()
    end
end

return CrossThroneRewardCell