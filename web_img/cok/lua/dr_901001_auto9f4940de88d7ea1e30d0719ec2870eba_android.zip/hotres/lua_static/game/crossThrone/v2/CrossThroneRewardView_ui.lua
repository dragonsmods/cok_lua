----------------------------
-- Author: Elex
-- Date: 2021-09-23 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CrossThroneRewardView_ui = class("CrossThroneRewardView_ui")

--#ui propertys


--#function
function CrossThroneRewardView_ui:create(owner, viewType, paramTable)
	local ret = CrossThroneRewardView_ui.new()
	CustomUtility:DoRes(0, true)
	CustomUtility:LoadUi("CrossThroneRewardView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function CrossThroneRewardView_ui:initLang()
	LabelSmoker:setText(self.m_titleTxt, "52045335")
	LabelSmoker:setText(self.m_pLabelTTF11, "52045335")
	LabelSmoker:setText(self.m_pLabelTTF5, "52045336")
	ButtonSmoker:setText(self.m_btn1, "52045401")
	ButtonSmoker:setText(self.m_btn2, "52045402")
	ButtonSmoker:setText(self.m_btn3, "52045403")
end

function CrossThroneRewardView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CrossThroneRewardView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CrossThroneRewardView_ui:onTipBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onTipBtnClick", pSender, event)
end

function CrossThroneRewardView_ui:onClickBtn1(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtn1", pSender, event)
end

function CrossThroneRewardView_ui:onClickBtn2(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtn2", pSender, event)
end

function CrossThroneRewardView_ui:onClickBtn3(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtn3", pSender, event)
end

function CrossThroneRewardView_ui:initTableView()
	TableViewSmoker:createView(self, "m_listView", "game.crossThrone.v2.CrossThroneRewardCell", 1, 6, "CrossThroneRewardCell")
end

function CrossThroneRewardView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return CrossThroneRewardView_ui

