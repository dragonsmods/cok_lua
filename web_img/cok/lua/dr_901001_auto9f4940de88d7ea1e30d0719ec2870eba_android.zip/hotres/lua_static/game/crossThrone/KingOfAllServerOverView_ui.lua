----------------------------
-- Author: Elex
-- Date: 2017-08-25 11:41:40
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local KingOfAllServerOverView_ui = class("KingOfAllServerOverView_ui")

--#ui propertys


--#function
function KingOfAllServerOverView_ui:create(owner, viewType)
	local ret = KingOfAllServerOverView_ui.new()
	CustomUtility:DoRes(310, true)
	CustomUtility:DoRes(6, true)
	CustomUtility:DoRes(7, true)
	CustomUtility:LoadUi("KingOfAllServerOverView.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	ret:initTableView()
	return ret
end

function KingOfAllServerOverView_ui:initLang()
end

function KingOfAllServerOverView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function KingOfAllServerOverView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function KingOfAllServerOverView_ui:onOkButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onOkButtonClick", pSender, event)
end

function KingOfAllServerOverView_ui:initTableView()
	TableViewSmoker:createView(self, "m_listTableView", "game.crossThrone.KingOfAllServerOverCell", 1, 20, "KingOfAllServerOverCell")
end

function KingOfAllServerOverView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return KingOfAllServerOverView_ui

