----------------------------
-- Author: Elex
-- Date: 2021-08-17 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CrossThroneDispatchView_ui = class("CrossThroneDispatchView_ui")

--#ui propertys


--#function
function CrossThroneDispatchView_ui:create(owner, viewType, paramTable)
	local ret = CrossThroneDispatchView_ui.new()
	CustomUtility:DoRes(0, true)
	CustomUtility:LoadUi("CrossThroneDispatchView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function CrossThroneDispatchView_ui:initLang()
	LabelSmoker:setText(self.m_titleTxt, "52045353")
	ButtonSmoker:setText(self.m_dispatchBtn, "52045327")
	MarqueeSmoker:setText(self.m_titleLbl, "52045325")
end

function CrossThroneDispatchView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CrossThroneDispatchView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CrossThroneDispatchView_ui:onClickDispatch(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickDispatch", pSender, event)
end

function CrossThroneDispatchView_ui:onTipBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onTipBtnClick", pSender, event)
end

function CrossThroneDispatchView_ui:initTableView()
	TableViewSmoker:createView(self, "m_listView", "game.crossThrone.v2.CrossThroneDispatchCell", 1, 6, "CrossThroneDispatchCell")
end

function CrossThroneDispatchView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return CrossThroneDispatchView_ui

