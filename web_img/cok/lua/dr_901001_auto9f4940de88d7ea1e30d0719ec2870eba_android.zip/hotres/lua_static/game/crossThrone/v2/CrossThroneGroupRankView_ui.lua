----------------------------
-- Author: Elex
-- Date: 2021-12-06 Monday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CrossThroneGroupRankView_ui = class("CrossThroneGroupRankView_ui")

--#ui propertys


--#function
function CrossThroneGroupRankView_ui:create(owner, viewType, paramTable)
	local ret = CrossThroneGroupRankView_ui.new()
	CustomUtility:DoRes(0, true)
	CustomUtility:LoadUi("CrossThroneGroupRankView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function CrossThroneGroupRankView_ui:initLang()
	LabelSmoker:setText(self.m_pLabelTTF112, "52045332")
	LabelSmoker:setText(self.m_noDataText, "138130")
	ButtonSmoker:setText(self.m_soloBtn, "52045331")
	ButtonSmoker:setText(self.m_allianceBtn, "52045330")
	ButtonSmoker:setText(self.m_okBtn, "138341")
	MarqueeSmoker:setText(self.m_rankText2, "52045334")
	MarqueeSmoker:setText(self.m_titleLbl, "52045329")
end

function CrossThroneGroupRankView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CrossThroneGroupRankView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CrossThroneGroupRankView_ui:onClickSolo(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickSolo", pSender, event)
end

function CrossThroneGroupRankView_ui:onClickAlliance(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickAlliance", pSender, event)
end

function CrossThroneGroupRankView_ui:onClickClose(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickClose", pSender, event)
end

function CrossThroneGroupRankView_ui:onClickOk(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickOk", pSender, event)
end

function CrossThroneGroupRankView_ui:initTableView()
	TableViewSmoker:createView(self, "m_tabView", "game.crossThrone.v2.CrossThroneGroupTabCell", 0, 5, "CrossThroneGroupTabCell")
	TableViewSmoker:createView(self, "m_listView", "game.crossThrone.v2.CrossThroneRankCell", 1, 4, "CrossThroneRankCell")
end

function CrossThroneGroupRankView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return CrossThroneGroupRankView_ui

