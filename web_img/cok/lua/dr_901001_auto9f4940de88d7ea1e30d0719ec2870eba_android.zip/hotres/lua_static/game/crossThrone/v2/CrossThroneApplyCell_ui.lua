----------------------------
-- Author: Elex
-- Date: 2021-12-03 Friday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CrossThroneApplyCell_ui = class("CrossThroneApplyCell_ui")

--#ui propertys


--#function
function CrossThroneApplyCell_ui:create(owner, viewType, paramTable)
	local ret = CrossThroneApplyCell_ui.new()
	CustomUtility:LoadUi("CrossThroneApplyCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CrossThroneApplyCell_ui:initLang()
end

function CrossThroneApplyCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CrossThroneApplyCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CrossThroneApplyCell_ui:onClickBtn1(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtn1", pSender, event)
end

function CrossThroneApplyCell_ui:onClickBtn2(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtn2", pSender, event)
end

return CrossThroneApplyCell_ui

