local CrossThroneOccupyRankCell = class("CrossThroneOccupyRankCell", function()
    return cc.Layer:create()
end)

function CrossThroneOccupyRankCell:create(idx)
    local ret = CrossThroneOccupyRankCell.new()
    Drequire("game.crossThrone.CrossThroneOccupyRankCell_ui"):create(ret)
    return ret
end

function CrossThroneOccupyRankCell:refreshCell(data , idx)
	self.m_data = data

	local name = "#" .. self.m_data.kingdom
	if self.m_data.abbr and self.m_data.abbr ~= "" then
		name = name .. "(" .. self.m_data.abbr .. ")"
	end
	name = name .. " " .. self.m_data.name
	
	local occupyTime = tonumber(self.m_data.occupyTime) or 0
	local rank = tonumber(self.m_data.rank) or 0
	local uid = tostring(self.m_data.uid) or ""
	local pic = tostring(self.m_data.pic) .. ".png"	
	local picVer = tostring(self.m_data.picVer) or 0
	if self.m_data.pic == "" then pic = "g044.png" end

	local img = CCLoadSprite:call("createSprite", pic, CCLoadSpriteType.CCLoadSpriteType_HEAD_ICON)
	CCCommonUtilsForLua:call("setSpriteMaxSize", img, 60, true)
	self.ui.m_headNode:removeAllChildren()
	self.ui.m_headNode:addChild(img)

	if CCCommonUtilsForLua:call("isUseCustomPic", picVer) then
        self.m_headImgNode = HFHeadImgNode:call("create")
        local url = CCCommonUtilsForLua:call("getCustomPicUrl", uid, picVer)
        self.m_headImgNode:call("initHeadImgUrl2", self.ui.m_headNode, url, 1.0, 60, true)
    end

	self.ui.m_playerLabel:setString(name)
	self.ui.m_timeLabel:setString(format_time(occupyTime))

	if rank == 1 then
		self.ui.m_numSprite1:setVisible(true)
		self.ui.m_numSprite2:setVisible(false)
		self.ui.m_numSprite3:setVisible(false)
		self.ui.m_numLabel:setVisible(false)
	elseif rank == 2 then
		self.ui.m_numSprite1:setVisible(false)
		self.ui.m_numSprite2:setVisible(true)
		self.ui.m_numSprite3:setVisible(false)
		self.ui.m_numLabel:setVisible(false)
	elseif rank == 3 then
		self.ui.m_numSprite1:setVisible(false)
		self.ui.m_numSprite2:setVisible(false)
		self.ui.m_numSprite3:setVisible(true)
		self.ui.m_numLabel:setVisible(false)
	else
		self.ui.m_numSprite1:setVisible(false)
		self.ui.m_numSprite2:setVisible(false)
		self.ui.m_numSprite3:setVisible(false)
		self.ui.m_numLabel:setVisible(true)
		self.ui.m_numLabel:setString(tostring(rank))
	end
	--self.ui.m_timeLabel:setVisible(false)

	local ctManager = require("game.crossThrone.CrossThroneManager")
	local battleType = ctManager:isDespotServer() and DESPOT_BATTLE or EMPIRE_BATTLE
	local timeSwitch = (battleType == DESPOT_BATTLE) and "overlord_ranking_time_off" or "monarch_ranking_time_off"
	if (CCCommonUtilsForLua:isFunOpenByKey(timeSwitch)) then
		self.ui.m_timeLabel:setVisible(false)
		self.ui.m_playerLabel:setAnchorPoint(ccp(0.5, 0.5))
		self.ui.m_playerLabel:setPositionX(76)
	else
		self.ui.m_timeLabel:setVisible(true)
	end
end

function CrossThroneOccupyRankCell:onEnterFrame( )
	local occupyTime = tonumber(self.m_data.occupyTime) or 0
	self.ui.m_timeLabel:setString(format_time(occupyTime))
end

function CrossThroneOccupyRankCell:onEnter(  )
	local function update(dt) self:onEnterFrame(dt) end 
	self.entry = tonumber(cc.Director:getInstance():getScheduler():scheduleScriptFunc(update, 1.0, false))
end

function CrossThroneOccupyRankCell:onExit( )
	cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
end

return CrossThroneOccupyRankCell