local CrossThroneGroupView = class("CrossThroneGroupView", PopupBaseView)

function CrossThroneGroupView:ctor()
    Drequire("game.CommonPopup.CommonEmptyView_ui"):create(self, 1)
    self.ctMgr = require("game.crossThrone.CrossThroneManager")
    self.areas = {}
    self.areaCache = {}
    self.groupData = {}
    self:initView()
end

function CrossThroneGroupView:initView()
    self.m_tableView = cc.TableView:create(self.ui.m_listNode:getContentSize())
	self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
	self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
	self.m_tableView:setDelegate()
	self.m_tableView:registerScriptHandler(function(tab, idx) return self:cellSizeForTable(tab, idx) end, cc.TABLECELL_SIZE_FOR_INDEX)
	self.m_tableView:registerScriptHandler(function(tab, idx) return self:tableCellAtIndex(tab, idx) end, cc.TABLECELL_SIZE_AT_INDEX)
	self.m_tableView:registerScriptHandler(function(tab) return self:numberOfCellsInTableView(tab) end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
	self.ui.m_listNode:addChild(self.m_tableView)

    local xmlData = CCCommonUtilsForLua:getGroupByKey("overlord")
    for _, data in ipairs4ScatteredT(xmlData) do
        table.insert(self.areas, data.game_servers)
    end

    local serverId = PlayerInfoController:getSelfServerId()
    if isCrossServerNow() then
        serverId = GlobalData:call("getPlayerInfo"):getProperty("crossFightSrcServerId")
    end
    local despotId = self.ctMgr:getDespotId()
    table.insert(self.groupData, {title = getLang("52045344", serverId, despotId)})

    local despotNum = self.ctMgr:getDespotNum()
    for i = 1, despotNum do
        table.insert(self.groupData, {group = i, open = (i == atoi(despotId)), view = self})
    end
    self:showGroup(atoi(despotId) + 1)

    self.ui.m_titleTxt:setString(getLang("52045343"))
    self.ui.m_tipBtn:setVisible(false)
end

function CrossThroneGroupView:cellSizeForTable(tab, idx)
    if self.groupData[idx + 1].title then
        return 640, 58
    elseif self.groupData[idx + 1].group then
        return 640, 68
    else
        return 640, 52
    end
end

function CrossThroneGroupView:tableCellAtIndex(tab, idx)
    if idx + 1 > table.getn(self.groupData) then
		return
    end
    local cell = tab:dequeueCell()
    if cell then 
		cell:refreshCell(self.groupData[idx + 1], idx + 1)
    else
        cell = Drequire("game.crossThrone.v2.CrossThroneGroupCell").new(self.groupData[idx + 1], idx + 1)
    end
    return cell 
end

function CrossThroneGroupView:numberOfCellsInTableView()
    return table.getn(self.groupData)
end

function CrossThroneGroupView:showGroup(index)
    local solt = self.groupData[index]
    if solt.open then
        local areas = self.areaCache[tostring(solt.group)]
        if not areas then
            areas = {}
            
            local area = self.areas[atoi(solt.group)]
            local tbl = splitString(area, ";")
            local temp = {}
            for i = 1, #tbl do
                local areaStr = tbl[i]
                local areaVec = splitString(areaStr, "-")
                if #areaVec == 1 then
                    table.insert(temp, areaVec[1])
                elseif #areaVec == 2 then
                    local begin = tonumber(areaVec[1])
                    local endTo = tonumber(areaVec[2])
                    for j = begin, endTo, 1 do
                        table.insert(temp, j)
                    end
                end
            end

            local unit = {}
            for i, s in ipairs(temp) do
                table.insert(unit, s)

                if table.getn(unit) == 3 then
                    table.insert(areas, unit)
                    unit = {}
                end
            end

            if table.getn(unit) > 0 then
                table.insert(areas, unit)
            end
            self.areaCache[tostring(solt.group)] = areas
        end

        
        local num = table.getn(areas)
        for j = num, 1, -1 do
            table.insert(self.groupData, index + 1, {belong = atoi(solt.group), servers = areas[j]})
        end
    else
        local num = table.getn(self.groupData)
        for index = num, 1, -1 do 
            if self.groupData[index].belong == atoi(solt.group) then
                table.remove(self.groupData, index)
            end
        end
    end
    self:updateContent()
end

function CrossThroneGroupView:updateContent()
    local oldOffset = self.m_tableView:getContentOffset()
    local oldContent = self.m_tableView:getContentSize()
    self.m_tableView:reloadData()
    local newContent = self.m_tableView:getContentSize()
    local newOffset = ccp(oldOffset.x, oldOffset.y - (newContent.height - oldContent.height))
    
    local maxOffset = self.m_tableView:maxContainerOffset()
    local minOffset = self.m_tableView:minContainerOffset()
    if newOffset.y > maxOffset.y then newOffset.y = maxOffset.y end
    if newOffset.y < minOffset.y then newOffset.y = minOffset.y end
    self.m_tableView:setContentOffset(newOffset)
end

return CrossThroneGroupView