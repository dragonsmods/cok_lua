local CrossThroneApplyView = class("CrossThroneApplyView", PopupBaseView)

function CrossThroneApplyView:ctor()
    Drequire("game.crossThrone.v2.CrossThroneApplyView_ui"):create(self, 1)
    self.ctMgr = require("game.crossThrone.CrossThroneManager")
    self:initView()
end

function CrossThroneApplyView:initView()
    registerTouchHandler(self)

    local temp = {}
    local showData = {}
    
    local function callback(despotId, btn) self:confirm(despotId, btn) end
    for _, unit in ipairs(self.ctMgr.despot or {}) do
        unit.cb = callback

        table.insert(temp, unit)
        if table.getn(temp) == 2 then
            table.insert(showData, temp)
            temp = {}
        end
    end
    
    if table.getn(temp) > 0 then
        table.insert(showData, temp)
    end

    self.ui.m_listView._notMoveWhenAllShow = true
    self.ui:setTableViewDataSource("m_listView", showData)
end

function CrossThroneApplyView:applySuccess()
    PopupViewController:call("removePopupView", self)
end

function CrossThroneApplyView:onEnter()
    registerScriptObserver(self, self.applySuccess, "msg.crossthrone.apply")
end

function CrossThroneApplyView:onExit()
    unregisterScriptObserver(self, "msg.crossthrone.apply")
end

function CrossThroneApplyView:confirm(despotId, btn)
    local function confirm()
        local function apply()
            self.waitInterface = GameController:call("showWaitInterface1", btn)
            self.ctMgr:apply(despotId)
        end

        local name = self.ctMgr:getDespotName(despotId)
        local tickets = self.ctMgr:getNeedTickets(despotId)
        YesNoDialog:call("showYesNoFun", getLang("52045404", getLang(name), tickets), cc.CallFunc:create(apply), getLang("confirm"), nil, getLang("cancel_btn_label"))
    end

    confirm()
end

function CrossThroneApplyView:onTouchBegan(x, y)
    if not isTouchInside(self.ui.m_bg,x,y) then
        self.touchPoint = ccp(x, y)
		return true
	end
end

function CrossThroneApplyView:onTouchEnded(x, y)
    if ccpDistance(self.touchPoint, ccp(x, y)) > 10 then return end
    PopupViewController:call("removePopupView", self)
end


return CrossThroneApplyView