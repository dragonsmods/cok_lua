local CrossThroneBattleRankView = class("CrossThroneBattleRankView",
	function()
		return PopupBaseView:create()
	end
)

local CrossThroneBattleRankCell = class("CrossThroneBattleRankCell",
	function()
		return cc.Layer:create()
	end
)

function CrossThroneBattleRankView:create(rankData)
	local view = CrossThroneBattleRankView.new()
	Drequire("game.crossThrone.KingOfAllServerOverView_ui"):create(view, 1)
	if view:initView(rankData) then
		return view
	end
end

function CrossThroneBattleRankView:initView(rankData)
	if self:init(true, 0) == false then
		return false
	end
	
	self.rankData = rankData or {}

	for _, v in ipairs(rankData) do
		if tonumber(v.rank) == 1 then
			self.king = v
		end
	end

	local kingStr = ""
	if self.king then
		local kingdom = self.king.kingdom and ("# " .. self.king.kingdom) or ""
		kingStr = kingStr .. kingdom
		local abbr = self.king.abbr and ("(" .. self.king.abbr .. ")") or ""
		kingStr = kingStr .. abbr
		kingStr = kingStr .. self.king.name
		self.king.str = kingStr
	else
		self.king = {}
		self.king.str = ""
	end

	self.ui.m_lvLabel:setString(getLang("170008"))
	self.ui.m_nameLabel:setString(getLang("170009"))
	self.ui.m_timeLabel:setString(getLang("138338"))

	local crossThroneManager = require("game.crossThrone.CrossThroneManager") 
	if crossThroneManager:isDespotServer() then
		local despotCastleName = crossThroneManager:getDespotCastleNameByServerId()
		self.ui.m_titleLabel:setString(despotCastleName)
		self.ui.m_desLabel:setString(getLang("138339", kingStr, despotCastleName))
	elseif crossThroneManager:isEmpireServer() then
		
	else

	end

	self:setHDPanelFlag(true)
	--self:call("setModelLayerDisplay", false)

	if CCCommonUtilsForLua:isIosAndroidPad() then
		self:setScale(2)
	end

	self.ui.m_listNode:removeAllChildren()
	self.m_tableView = cc.TableView:create(self.ui.m_listNode:getContentSize())
	self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
	self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
	self.m_tableView:setDelegate()
	self.m_tableView:registerScriptHandler(function(tab, idx) return self:cellSizeForTable(tab, idx) end, cc.TABLECELL_SIZE_FOR_INDEX)
	self.m_tableView:registerScriptHandler(function(tab, idx) return self:tableCellAtIndex(tab, idx) end, cc.TABLECELL_SIZE_AT_INDEX)
	self.m_tableView:registerScriptHandler(function(tab) return self:numberOfCellsInTableView(tab) end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
	self.ui.m_listNode:addChild(self.m_tableView)
	self.m_tableView:reloadData()

	CCCommonUtilsForLua:setButtonTitle(self.ui.m_okButton, getLang("confirm"))

	local touchLayer = cc.Layer:create()
	self:addChild(touchLayer)

	local function touchHandle( eventType, x, y )
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		
		else
			self:onTouchEnded(x, y)
		end
	end
	touchLayer:registerScriptTouchHandler(touchHandle)
	touchLayer:setTouchEnabled(true)
	touchLayer:setSwallowsTouches(false)

	return true
end

function CrossThroneBattleRankView:onEnter()

end

function CrossThroneBattleRankView:onExit()

end

function CrossThroneBattleRankView:cellSizeForTable(tabView, idx)
	return 480, 50
end

function CrossThroneBattleRankView:tableCellAtIndex(tabView, idx)
	if (idx >= sizen(self.rankData)) then return end

	local cell = tabView:dequeueCell()
	if cell then
		local node = cell:getChildByTag(666)
		node:setData(self.rankData[idx + 1])
	else
		cell = cc.TableViewCell:create()
		local node = CrossThroneBattleRankCell:create(self.rankData[idx + 1])
		node:setTag(666)
		cell:addChild(node)
	end
	
	return cell
end

function CrossThroneBattleRankView:numberOfCellsInTableView(tabView)
	Dprint("numberOfCellsInTableView", #self.rankData)
	return self.rankData and #self.rankData or 0
end

function CrossThroneBattleRankView:onTouchBegan(x, y)
	self.touchPoint = ccp(x, y)
	return true
end

function CrossThroneBattleRankView:onTouchEnded(x, y)
	if ccpDistance(self.touchPoint, ccp(x, y)) > 20 then
		return
	end

	if not isTouchInside(self.ui.m_touchNode, x, y) then
		local crossThroneManager = require("game.crossThrone.CrossThroneManager") 
		--兼容本服王战结算排名
		if (not crossThroneManager:isDespotServer()) and (not crossThroneManager:isEmpireServer()) then
			PopupViewController:call("removePopupView", self)
		end
	end
end

function CrossThroneBattleRankView:onOkButtonClick()
	local crossThroneManager = require("game.crossThrone.CrossThroneManager") 
	--兼容本服王战结算排名
	if crossThroneManager:isDespotServer() or crossThroneManager:isEmpireServer() then
		local function confirm()
			crossThroneManager:exitCrossThrone()
		end
		local despotCastleName = crossThroneManager:getDespotCastleNameByServerId()
		YesNoDialog:show(getLang("138339", self.king.str, despotCastleName), confirm)
	else
		PopupViewController:call("removePopupView", self)
	end
end

-------------------CrossThroneBattleRankCell-------------------------

function CrossThroneBattleRankCell:create(rankData)
	local view = CrossThroneBattleRankCell.new()
	Drequire("game.crossThrone.KingOfAllServerOverCell_ui"):create(view, 1)
	if view:initNode(rankData) then
		return view
	end
end

function CrossThroneBattleRankCell:initNode(rankData)
	self:setData(rankData)
	return true
end

function CrossThroneBattleRankCell:setData(rankData)
	dump(rankData, "rankData")

	local nameStr = rankData.kingdom and ("# " .. rankData.kingdom) or ""
	local abbr = rankData.abbr and ("(" .. rankData.abbr .. ")") or ""
	nameStr = nameStr .. abbr
	nameStr = nameStr .. rankData.name

	self.ui.m_nameLabel1:setString(nameStr)

	local occupyTimeStr = format_time(tonumber(rankData.occupyTime))
	self.ui.m_timeLabel1:setString(occupyTimeStr)

	self.ui.m_numSprite1:setVisible(false)
	self.ui.m_numSprite2:setVisible(false)
	self.ui.m_numSprite3:setVisible(false)

	local rank = tonumber(rankData.rank)
	if (rank < 4) then
		self.ui["m_numSprite" .. rank]:setVisible(true)
	else
		self.ui.m_numLabel:setString(rankData.rank)
	end
end

-------------------CrossThroneBattleRankCell-------------------------

return CrossThroneBattleRankView