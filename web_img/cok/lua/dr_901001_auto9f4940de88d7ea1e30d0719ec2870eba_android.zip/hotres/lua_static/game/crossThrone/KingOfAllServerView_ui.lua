----------------------------
-- Author: Elex
-- Date: 2019-04-09 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local KingOfAllServerView_ui = class("KingOfAllServerView_ui")

--#ui propertys


--#function
function KingOfAllServerView_ui:create(owner, viewType, paramTable)
	local ret = KingOfAllServerView_ui.new()
	CustomUtility:LoadUi("KingOfAllServerView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function KingOfAllServerView_ui:initLang()
end

function KingOfAllServerView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function KingOfAllServerView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function KingOfAllServerView_ui:onBtnRuleClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBtnRuleClick", pSender, event)
end

function KingOfAllServerView_ui:onBtnPointClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBtnPointClick", pSender, event)
end

function KingOfAllServerView_ui:onTipBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onTipBtnClick", pSender, event)
end

function KingOfAllServerView_ui:onThisButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onThisButtonClick", pSender, event)
end

function KingOfAllServerView_ui:onLookButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onLookButtonClick", pSender, event)
end

return KingOfAllServerView_ui

