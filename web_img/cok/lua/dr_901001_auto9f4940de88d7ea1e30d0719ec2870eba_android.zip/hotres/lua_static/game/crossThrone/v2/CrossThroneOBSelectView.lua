local CrossThroneOBSelectView = class("CrossThroneOBSelectView", PopupBaseView)

function CrossThroneOBSelectView:ctor()
    Drequire("game.crossThrone.v2.CrossThroneOBSelectView_ui"):create(self, 1)
    self.ctMgr = require("game.crossThrone.CrossThroneManager")
    self.obItemId = self.ctMgr:getObItemId()
    self.despotMap = {}
    self:initView()
end

function CrossThroneOBSelectView:initView()
    registerTouchHandler(self)
    self.ctMgr:reqObData()
    self.ui.m_listView._notMoveWhenAllShow = true
end

function CrossThroneOBSelectView:refreshView(param)
    local data = dictToLuaTable(param)
    local temp = {}
    local showData = {}
    local function callback(despotId, btn) self:obConfirm(despotId, btn) end 
    for _, unit in ipairs(data.despot or {}) do
        self.despotMap[unit.despotId] = (unit.obNeedTicket == "1")

        local name = self.ctMgr:getDespotName(atoi(unit.despotId))
        table.insert(temp, {id = unit.despotId, cb = callback, name = getLang(name)})
        if table.getn(temp) == 2 then
            table.insert(showData, temp)
            temp = {}
        end
    end
    
    if table.getn(temp) > 0 then
        table.insert(showData, temp)
    end

    self.ui:setTableViewDataSource("m_listView", showData)
end

function CrossThroneOBSelectView:onEnter()
    registerScriptObserver(self, self.refreshView, "msg.crossthrone.obData")
end

function CrossThroneOBSelectView:onExit()
    unregisterScriptObserver(self, "msg.crossthrone.obData")
end

function CrossThroneOBSelectView:obConfirm(despotId, btn)
    local function confirm()
        local function enter()
            self.waitInterface = GameController:call("showWaitInterface1", btn)
            self.ctMgr:enterOb(despotId)
        end

        YesNoDialog:call("showYesNoFun", getLang("52045380"), cc.CallFunc:create(enter), getLang("confirm"), nil, getLang("cancel_btn_label"))
    end

    local needTicket = self.despotMap[despotId]
    if needTicket then
        local tInfo = ToolController:call("getToolInfoForLua", self.obItemId)
        local cnt = tInfo and tInfo:call("getCNT") or 0
        if cnt > 0 then
            confirm()
        else
            PopupViewController:call("removePopupView", self)

            local view = Drequire("game.crossThrone.v2.CrossThroneTicketView").new()
            PopupViewController:addPopupView(view) 
        end
    else
        confirm()
    end
end

function CrossThroneOBSelectView:onTouchBegan(x, y)
    if not isTouchInside(self.ui.m_bg,x,y) then
        self.touchPoint = ccp(x, y)
		return true
	end
end

function CrossThroneOBSelectView:onTouchEnded(x, y)
    if ccpDistance(self.touchPoint, ccp(x, y)) > 10 then return end
    PopupViewController:call("removePopupView", self)
end

function CrossThroneOBSelectView:onClickClose()
    PopupViewController:call("removePopupView", self)
end

return CrossThroneOBSelectView