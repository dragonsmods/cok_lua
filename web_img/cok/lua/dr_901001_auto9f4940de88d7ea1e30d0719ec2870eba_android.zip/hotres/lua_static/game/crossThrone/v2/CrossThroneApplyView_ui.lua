----------------------------
-- Author: Elex
-- Date: 2021-12-03 Friday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CrossThroneApplyView_ui = class("CrossThroneApplyView_ui")

--#ui propertys


--#function
function CrossThroneApplyView_ui:create(owner, viewType, paramTable)
	local ret = CrossThroneApplyView_ui.new()
	CustomUtility:LoadUi("CrossThroneApplyView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function CrossThroneApplyView_ui:initLang()
	LabelSmoker:setText(self.m_Title, "52045321")
end

function CrossThroneApplyView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CrossThroneApplyView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CrossThroneApplyView_ui:initTableView()
	TableViewSmoker:createView(self, "m_listView", "game.crossThrone.v2.CrossThroneApplyCell", 1, 3, "CrossThroneApplyCell")
end

function CrossThroneApplyView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return CrossThroneApplyView_ui

