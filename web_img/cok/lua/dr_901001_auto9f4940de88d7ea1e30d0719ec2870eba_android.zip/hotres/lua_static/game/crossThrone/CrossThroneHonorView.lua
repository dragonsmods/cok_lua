local despotEnum = {
	despot_honor = 1,
	despot_reward = 2,
	despot_list = 3,
	despot_zone = 4,
}

local despotEnumDialog = {
	"138370", -- 霸主荣耀
	"138372", -- 霸主封赏
	"138374", -- 霸主列传
	"138376", -- 霸主疆域
}

local kingIsMine = false

local CrossThroneHonorView = class("CrossThroneHonorView",
	function()
		return PopupBaseView:create()
	end
)

local CrossThroneHonorCell = class("CrossThroneHonorCell",
	function() 
		return cc.Layer:create() 
	end
)
CrossThroneHonorCell.__index = CrossThroneHonorCell

function CrossThroneHonorView:create()
	local view = CrossThroneHonorView.new()
	Drequire("game.crossThrone.KingOfAllServerFunctionView_ui"):create(view, 0)
	if view:initView() then
		return view
	end
end

function CrossThroneHonorView:ctor()
	self.databack = false
end

function CrossThroneHonorView:initView()
	if self:init(true, 0) then
		self:setHDPanelFlag(true)
		self.ipadLike = CCCommonUtilsForLua:isIosAndroidPad()
		if self.ipadLike then
			self.ui.m_topNode:setScale(2.4)
			self.ui.m_topNode:setPositionY(self.ui.m_topNode:getPositionY() + 300)
			self.ui.m_listNode:setScale(0.8)
			self.ui.m_listNode:setPositionY(self.ui.m_listNode:getPositionY() + 50)
			self.ui.m_kingPic:setScale(0.6)
			self.ui.m_kingPic:setPositionY(self.ui.m_kingPic:getPositionY() - 50)
			self.ui.m_castleNode:setPositionY(self.ui.m_castleNode:getPositionY() - 110)
		else
			self.ui.m_kingPic:setScale(0.8)
		end

		self.ctManager = require("game.crossThrone.CrossThroneManager")

		local localPath = CCFileUtils:sharedFileUtils():getWritablePath() .. "dresource/"
		local jsonPath = localPath .. "crossThroneFlag.json"
		local atlasPath = localPath .. "crossThroneFlag.atlas"

		if (CCFileUtils:sharedFileUtils():isFileExist(jsonPath) and CCFileUtils:sharedFileUtils():isFileExist(atlasPath)) then
			local x, y = self.ui.m_castleNode:getPosition()
			local par = self.ui.m_castleNode:getParent()

			local aniObj1 = IFSkeletonAnimation:call("create", jsonPath, atlasPath)
			aniObj1:setToSetupPose()
			aniObj1:setAnimation(0, "animation", true)

			if self.ipadLike then
				aniObj1:setPosition(x - 240, y - 150) 
			else
				aniObj1:setPosition(x - 240, y - 260) 
			end
			
			par:addChild(aniObj1)

			local aniObj2 = IFSkeletonAnimation:call("create", jsonPath, atlasPath)
			aniObj2:setToSetupPose()
			aniObj2:setAnimation(0, "animation", true)

			if self.ipadLike then
				aniObj2:setPosition(x + 230, y - 150) 
			else
				aniObj2:setPosition(x + 230, y - 260) 
			end
			
			aniObj2:setScaleX(-1) 
			par:addChild(aniObj2)
		end

		self.m_data = {}
		if self.ctManager:isDespotServer() then
			self.battleType = DESPOT_BATTLE
			self.ui.m_funLabel1:setString(getLang("138370"))
			self.ui.m_funLabel2:setString(getLang("138372"))
			self.ui.m_funLabel3:setString(getLang("138374"))
			self.ui.m_funLabel4:setString(getLang("138376"))
		else
			self.battleType = EMPIRE_BATTLE
		end

		local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
		self.battleServerId = playerInfo:getProperty("currentServerId")

		self.ctManager:requestHororData(self.battleType, self.battleServerId)

		CCLoadSprite:call("loadDynamicResourceByName", "race_base")
		CCLoadSprite:call("loadDynamicResourceByName", "race_base2")

		self.ui.m_kingPic:setSpriteFrame(CCLoadSprite:call("loadResource", "mid_king_01.png"))

		local touchLayer = cc.Layer:create()
		self:addChild(touchLayer)

		local function touchHandle( eventType, x, y )
			if eventType == "began" then
				return self:onTouchBegan(x, y)
			elseif eventType == "moved" then
			
			else
				self:onTouchEnded(x, y)
			end
		end
		touchLayer:registerScriptTouchHandler(touchHandle)
		touchLayer:setTouchEnabled(true)
		touchLayer:setSwallowsTouches(false)

		return true
	end

	return false
end

function CrossThroneHonorView:refreshView(param)
	if param == nil then return end
	local tbl = dictToLuaTable(param)
	dump(tbl, "refreshView param")

	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	local myUid = playerInfo:getProperty("uid")

	local despotCastleName = self.ctManager:getDespotCastleNameByServerId()
	self.ui.m_titleLabel:setString(despotCastleName)

	if tbl.uid and tbl.uid ~= "" then

		kingIsMine = (myUid == tbl.uid)

		self.kingUid = tbl.uid
		self.kingName = tbl.name
		self.kingPic = tbl.pic
		self.kingPicVer = tonumber(tbl.picVer)
		self.kingdom = tbl.kingdom
		self.kingAbbr = tbl.abbr
		self.kingCoord = splitString(tbl.coordinate, ";")


		local format = "K：%s X:%s Y:%s"
		local coordinateStr = "" or string.format(format, self.kingCoord[1], self.kingCoord[2], self.kingCoord[3])
		self.ui.m_kxyLabel:setString(coordinateStr)

		self.kingdomStr = ""
		if self.kingdom ~= "" then
			self.kingdomStr = self.kingdomStr .. "#" .. self.kingdom
		end
		if self.kingAbbr ~= "" then
			self.kingdomStr = self.kingdomStr .. "(" .. self.kingAbbr .. ")"
		end

		self.ui.m_nameLabel:setString(self.kingdomStr .. " " .. self.kingName)

		--self.ui.m_headNode:removeAllChildren()
	else
		--没有霸主
		self.ui.m_nameLabel:setString(getLang("138329"))
	end

	self.databack = true
end

function CrossThroneHonorView:onEnter()
	if self.battleType == DESPOT_BATTLE then
		self:setTitleName(getLang("138420"))
	else
		self:setTitleName(getLang("138343"))
	end
	local function callback1(param) self:refreshView(param) end
	local handler1 = self:registerHandler(callback1)
	CCSafeNotificationCenter:call("registerScriptObserver", self, handler1, "crossThrone.honor")
end

function CrossThroneHonorView:onExit()
	CCSafeNotificationCenter:call("unregisterScriptObserver", self, "crossThrone.honor")
end

function CrossThroneHonorView:onTouchBegan(x, y)
	for i = 1, 4 do
		if isTouchInside(self.ui["m_enum" .. i], x, y) then
			self.m_touchPoint = ccp(x, y)
			return true
		end
	end

	return false
end

function CrossThroneHonorView:onTouchEnded(x, y)
	if ccpDistance(self.m_touchPoint, ccp(x, y)) > 20 then return end

	local kingData = {
		uid = self.kingUid or "",
		name = (self.kingdomStr or "") .. (self.kingName or ""),
		pic = self.kingPic,
		picVer = self.kingPicVer,
	}
	
	for i = 1, 4 do
		if isTouchInside(self.ui["m_enum" .. i], x, y) then
			if i == 1 then
				local rewardView = Drequire("game.crossThrone.CrossThroneKingRewardView"):create("138370")
				PopupViewController:addPopupView(rewardView)
			elseif i == 2 and self.databack then
				local giftView = Drequire("game.crossThrone.CrossThroneKingGiftView"):create("138372", kingIsMine, kingData)
				PopupViewController:addPopupInView(giftView)
			elseif i == 3 then
				local kingListView = Drequire("game.crossThrone.CrossThroneKingListView"):create("138374", kingData)
				PopupViewController:addPopupInView(kingListView)
			elseif i == 4 then
				local areaView = Drequire("game.crossThrone.CrossThroneAreaView"):create("138376")
				PopupViewController:addPopupView(areaView)
			end
			break
		end
	end 
end

-----------------------CrossThroneHonorCell-----------------------

function CrossThroneHonorCell:create(dialogId, parView)
	local view = CrossThroneHonorCell.new()
	Drequire("game.crossThrone.KingOfAllServerFunctionCell_ui"):create(view, 1)
	if view:initView(dialogId, parView) then
		return view
	end
end

function CrossThroneHonorCell:initView(dialogId, parView)
	self:setData(dialogId, parView)

	local touchLayer = cc.Layer:create()
	self:addChild(touchLayer)

	local function touchHandle( eventType, x, y )
		Dprint("touchHandle", eventType, x, y)
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		
		else
			self:onTouchEnded(x, y)
		end
	end
	touchLayer:registerScriptTouchHandler(touchHandle)
	touchLayer:setTouchEnabled(true)
	touchLayer:setSwallowsTouches(false)

	return true
end

function CrossThroneHonorCell:setData(dialogId, parView)
	self.dialogId = dialogId
	self.parView = parView
	self.ui.m_funLabel:setString(getLang(dialogId))
end

function CrossThroneHonorCell:onTouchBegan(x, y)
	if isTouchInside(self.ui.m_touchNode, x, y) then
		self.m_touchPoint = ccp(x, y)
		return true
	end

	return false
end

function CrossThroneHonorCell:onTouchEnded(x, y)
	if isTouchInside(self.ui.m_touchNode, x, y) then
		if ccpDistance(self.m_touchPoint, ccp(x, y)) > 20 then
			return
		end
		Dprint("self.dialogId onTouchEnded", self.dialogId)

		local kingData = {
			uid = self.parView.kingUid or "",
			name = (self.parView.kingdomStr or "") .. (self.parView.kingName or ""),
			pic = self.parView.kingPic,
			picVer = self.parView.kingPicVer,
		}

		if self.dialogId == "138370" then
			local rewardView = Drequire("game.crossThrone.CrossThroneKingRewardView"):create(self.dialogId)
			PopupViewController:addPopupView(rewardView)
		elseif self.dialogId == "138372" then
			local giftView = Drequire("game.crossThrone.CrossThroneKingGiftView"):create(self.dialogId, kingIsMine, kingData)
			PopupViewController:addPopupInView(giftView)
		elseif self.dialogId == "138374" then

			local kingListView = Drequire("game.crossThrone.CrossThroneKingListView"):create(self.dialogId, kingData)
			PopupViewController:addPopupInView(kingListView)
		elseif self.dialogId == "138376" then
			local areaView = Drequire("game.crossThrone.CrossThroneAreaView"):create(self.dialogId)
			PopupViewController:addPopupView(areaView)
		end
	end
end

-----------------------CrossThroneHonorCell-----------------------

return CrossThroneHonorView
