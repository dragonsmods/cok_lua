----------------------------
-- Author: Elex
-- Date: 2017-12-05 21:47:57
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CrossThroneOccupyRankView_ui = class("CrossThroneOccupyRankView_ui")

--#ui propertys


--#function
function CrossThroneOccupyRankView_ui:create(owner, viewType)
	local ret = CrossThroneOccupyRankView_ui.new()
	CustomUtility:DoRes(305, true)
	CustomUtility:DoRes(500, true)
	CustomUtility:DoRes(7, true)
	CustomUtility:LoadUi("CrossThroneOccupyRankView.ccbi", ret, owner, true, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	ret:initTableView()
	return ret
end

function CrossThroneOccupyRankView_ui:initLang()
end

function CrossThroneOccupyRankView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CrossThroneOccupyRankView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CrossThroneOccupyRankView_ui:onTabButton1Click(pSender, event)
	ButtonSmoker:forwardFunction(self, "onTabButton1Click", pSender, event)
end

function CrossThroneOccupyRankView_ui:onTabButton2Click(pSender, event)
	ButtonSmoker:forwardFunction(self, "onTabButton2Click", pSender, event)
end

function CrossThroneOccupyRankView_ui:initTableView()
	TableViewSmoker:createView(self, "m_listTableView", "game.crossThrone.CrossThroneOccupyRankCell", 1, 20, "CrossThroneOccupyRankCell")
end

function CrossThroneOccupyRankView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return CrossThroneOccupyRankView_ui

