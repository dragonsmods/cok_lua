----------------------------
-- Author: Elex
-- Date: 2021-09-23 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CrossThroneGroupCell_ui = class("CrossThroneGroupCell_ui")

--#ui propertys


--#function
function CrossThroneGroupCell_ui:create(owner, viewType, paramTable)
	local ret = CrossThroneGroupCell_ui.new()
	CustomUtility:LoadUi("CrossThroneGroupCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CrossThroneGroupCell_ui:initLang()
end

function CrossThroneGroupCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CrossThroneGroupCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CrossThroneGroupCell_ui:onClickGroup(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickGroup", pSender, event)
end

return CrossThroneGroupCell_ui

