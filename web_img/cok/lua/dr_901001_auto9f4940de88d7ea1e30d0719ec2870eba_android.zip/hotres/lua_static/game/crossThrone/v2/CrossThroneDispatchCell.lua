local CrossThroneDispatchCell = class("CrossThroneDispatchCell", cc.TableViewCell)

function CrossThroneDispatchCell:create()
    local cell = CrossThroneDispatchCell.new()
    Drequire("game.crossThrone.v2.CrossThroneDispatchCell_ui"):create(cell, 0)
    cell:initEditBox()
    return cell
end

function CrossThroneDispatchCell:initEditBox()
    local function callback1(num) self:editBox1Return(num) end
    local function callback2(num) self:editBox2Return(num) end
    self.editBox1 = self:createEditBox(self.ui.m_editNode1, callback1, "")
    self.editBox2 = self:createEditBox(self.ui.m_editNode2, callback2, "")
end

function CrossThroneDispatchCell:createEditBox(node, callback, placeHolder)
    local size = node:getContentSize()
    local sprite9 = CCLoadSprite:call("createScale9Sprite", "blankFrame.png")
    local editBox = CCEditBox:create(size, sprite9)
    editBox:setAnchorPoint(ccp(0, 0))
    editBox:setFontSize(14)
    editBox:setPlaceHolder(getLang(placeHolder))
    editBox:setMaxLength(6)
    editBox:setFontColor(cc.c3b(255, 255, 255))
    editBox:setInputMode(cc.EDITBOX_INPUT_MODE_NUMERIC)
    editBox:setPosition(ccp(0, 0))
    node:addChild(editBox)

    local function editCB (strEventName,pSender)
        if tostring(pSender) == "return" then
            -- 当用户点击编辑框的键盘以外的区域，或者键盘的Return按钮被点击时所调用
            callback(editBox:getText())    
        end
    end

    editBox:registerScriptEditBoxHandler(editCB) --输入框的事件，主要有光标移进去，光标移出来，以及输入内容改变等
    
    return editBox
end

function CrossThroneDispatchCell:refreshCell(info, idx)
    self.info = info
    
    self.ui.m_node1:setVisible(false)
    self.ui.m_node2:setVisible(false)

    if info[1] then
        self.ui.m_node1:setVisible(true)
        self.ui.m_name1:setString(info[1].name)
        self.editBox1:setText(tostring(info[1].dispatch))
    end

    if info[2] then
        self.ui.m_node2:setVisible(true)
        self.ui.m_name2:setString(info[2].name)
        self.editBox2:setText(tostring(info[2].dispatch))
    end

    if idx % 2 == 0 then
        self.ui.m_oddBg:setVisible(true)
        self.ui.m_evenBg:setVisible(false)
    else
        self.ui.m_oddBg:setVisible(false)
        self.ui.m_evenBg:setVisible(true)
    end
end

function CrossThroneDispatchCell:editBox1Return(num)
    self.info[1].dispatch = self.info[1].dpCb(self.info[1].uid, atoi(num))
    self.editBox1:setText(tostring(self.info[1].dispatch))
end

function CrossThroneDispatchCell:editBox2Return(num)
    self.info[2].dispatch = self.info[2].dpCb(self.info[2].uid, atoi(num))
    self.editBox2:setText(tostring(self.info[2].dispatch))
end

return CrossThroneDispatchCell