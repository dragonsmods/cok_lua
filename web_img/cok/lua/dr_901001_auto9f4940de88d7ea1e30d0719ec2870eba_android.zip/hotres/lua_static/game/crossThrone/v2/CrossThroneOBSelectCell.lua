local CrossThroneOBSelectCell = class("CrossThroneOBSelectCell", cc.TableViewCell)

function CrossThroneOBSelectCell:create()
    local cell = CrossThroneOBSelectCell.new()
    Drequire("game.crossThrone.v2.CrossThroneOBSelectCell_ui"):create(cell, 0)
    cell.ui.m_btn1:setSwallowsTouches(false)
    cell.ui.m_btn2:setSwallowsTouches(false)
    return cell
end

function CrossThroneOBSelectCell:refreshCell(info, idx)
    self.info = info

    self.ui.m_btn1:setVisible(false)
    self.ui.m_btn2:setVisible(false)
    if info[1] then
        self.ui.m_btn1:setVisible(true)
        CCCommonUtilsForLua:setButtonTitle(self.ui.m_btn1, info[1].name)
    end

    if info[2] then
        self.ui.m_btn2:setVisible(true)
        CCCommonUtilsForLua:setButtonTitle(self.ui.m_btn2, info[2].name)
    end 
end

function CrossThroneOBSelectCell:onClickBtn1()
    self.info[1].cb(self.info[1].id, self.ui.m_btn1)
end

function CrossThroneOBSelectCell:onClickBtn2()
    self.info[2].cb(self.info[2].id, self.ui.m_btn2)
end

return CrossThroneOBSelectCell