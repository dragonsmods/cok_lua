local CrossThronePointRewardNode = class("CrossThronePointRewardNode", cc.Node)



function CrossThronePointRewardNode:create(viewSize)
	local node = CrossThronePointRewardNode.new()
	if node:initNode(viewSize) then return node end
end

function CrossThronePointRewardNode:initNode(viewSize)

	self.viewSize = viewSize
	self:setContentSize(self.viewSize)

	local bg = CCLoadSprite:call("createScale9Sprite", "BG_danse07.png")
	bg:setContentSize(viewSize)
	bg:setAnchorPoint(0, 0)
	self:addChild(bg)
	
	self.csManager = require("game.crossThrone.CrossThroneManager")
	self.csManager:getPointRwdData()
	self:addLoadingAni()
	registerNodeEventHandler(self)

	return true
end

function CrossThronePointRewardNode:refreshBase( )
	self:removeLoadingAni()

	if not self.m_tableView then
		self.buildNode = Drequire("game.crossThrone.CrossThronePointNode"):create(BUILD_POINT_TYPE)
		self.killNode = Drequire("game.crossThrone.CrossThronePointNode"):create(KILL_POINT_TYPE)

		self.cellHeight = self.buildNode:getContentSize().height

		self.buildNode:setPositionY(self.viewSize.height - self.cellHeight)
		self.killNode:setPositionY(self.viewSize.height - 2 * self.cellHeight)
		self:addChild(self.buildNode)
		self:addChild(self.killNode)

		local tableViewSize = cc.size(self.viewSize.width, self.viewSize.height - self.cellHeight)

		self.m_tableView = cc.TableView:create(tableViewSize)
		self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
		self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
		self.m_tableView:setDelegate()
		self.m_tableView:registerScriptHandler(function(tab, idx) return self:cellSizeForTable(tab, idx) end, cc.TABLECELL_SIZE_FOR_INDEX)
		self.m_tableView:registerScriptHandler(function(tab, idx) return self:tableCellAtIndex(tab, idx) end, cc.TABLECELL_SIZE_AT_INDEX)
		self.m_tableView:registerScriptHandler(function(tab) return self:numberOfCellsInTableView(tab) end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
		self:addChild(self.m_tableView)
	end
end

function CrossThronePointRewardNode:refreshNode(pObj)
	if pObj then
		self.rwdSourceData = {}

		local pointType = pObj:valueForKey("pointType"):intValue()
		local openShow = pObj:valueForKey("openShow"):boolValue()

		if openShow == true then
			if pointType == BUILD_POINT_TYPE then
				self.buildNode:setVisible(true)
				self.killNode:setVisible(false)
			else
				self.buildNode:setVisible(false)
				self.killNode:setVisible(true)
				self.killNode:setPositionY(self.viewSize.height - self.cellHeight)
			end

			local _, scoreList = self.csManager:getPointData(pointType)
			local rwdData = self.csManager:getPointRewardData(pointType)

			for i = 1, #rwdData do
				table.insert(self.rwdSourceData, atoi(scoreList[i]) or 0)

				for j = 1, table.getn(rwdData[i] or { }) do
					table.insert(self.rwdSourceData, rwdData[i][j])
				end
			end
		else
			self.buildNode:setVisible(true)
			self.killNode:setVisible(true)
			self.killNode:setPositionY(self.viewSize.height - 2 * self.cellHeight)
		end

		self.m_tableView:reloadData()
	end
end

function CrossThronePointRewardNode:cellSizeForTable(tabView, idx)
	return 640, 56
end

function CrossThronePointRewardNode:tableCellAtIndex(tabView, idx)
	local rIdx = idx + 1
	if rIdx > table.getn(self.rwdSourceData) then return end

	local cell = tabView:dequeueCell()
	if not cell then
		cell = Drequire("game.crossThrone.CrossThronePointRewardCell"):create(rIdx, self.rwdSourceData[rIdx])
	end
	cell:refreshCell(rIdx, self.rwdSourceData[rIdx])
	return cell
end

function CrossThronePointRewardNode:numberOfCellsInTableView(tabView)
	return self.rwdSourceData and #self.rwdSourceData or 0
end

function CrossThronePointRewardNode:addLoadingAni()
	self:removeLoadingAni()

	self.m_loadingIcon = CCLoadSprite:call("createSprite", "loading_1.png")
	self.m_loadingIcon:setAnchorPoint(ccp(0.5, 0.5))

	self.m_loadingIcon:setPosition(ccp(self.viewSize.width / 2, self.viewSize.height / 2))

	local rotateAction = cc.RotateTo:create(0.5, 720)
	local rotateForever = cc.RepeatForever:create(rotateAction)
	self.m_loadingIcon:runAction(rotateForever)
	self:addChild(self.m_loadingIcon, 1000000)
end

function CrossThronePointRewardNode:removeLoadingAni()
	if self.m_loadingIcon then
		self.m_loadingIcon:removeFromParent()
		self.m_loadingIcon = nil
	end
end

function CrossThronePointRewardNode:onEnter()
	local function callback1(pObj) self:refreshNode(pObj) end
	local handler1 = self:registerHandler(callback1)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "crossthrone.pointRwdShow") 

	local function callback2(pObj) self:refreshBase(pObj) end
	local handler2 = self:registerHandler(callback2)
	CCSafeNotificationCenter:registerScriptObserver(self, handler2, "crossthrone.pointData")
end

function CrossThronePointRewardNode:onExit( ... )
	CCSafeNotificationCenter:unregisterScriptObserver(self, "crossthrone.pointRwdShow")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "crossthrone.pointData")
end

return CrossThronePointRewardNode