CrossThroneBuffTowerTile = class("CrossThroneBuffTowerTile", 
    function()
        return NewBaseTileLuaInfo:call("create")
    end
)

local NotOpen = 0
local OpenNoKing = 1
local PeaceTime = 2
local WarTime = 3
local WarWaiting = 4

function CrossThroneBuffTowerTile.create( index )
    local ret = CrossThroneBuffTowerTile.new()
    if ret:initView(index) == false then
        ret = nil
    end
    return ret
end

function CrossThroneBuffTowerTile:initView( index )
    Dprint("@@ CrossThroneBuffTowerTile:initView".. tostring(index))
    self.cityIndex = index
    self:call("setCityIndex", index)

    if self:call("initTile", true) == false then
        return false
    end

    local cityInfo = self:call("getCityInfo")
    Dprint("cityInfo", cityInfo)
    if nil == cityInfo then
        return false
    end
    self.m_cityInfo = cityInfo

    self.m_luaMap = cityInfo:call("getLuaMap")
    registerNodeEventHandler(self)
    self:call("addToParent")
    self:setVisible(false)
    return true
end

function CrossThroneBuffTowerTile:onEnter()
    registerScriptObserver(self, self.refreshDetail, "GET_WORLD_DETAIL_CMD_BACK")
    local WorldDetailCommand = Drequire("game.command.WorldDetailCommand")
    local cmd = WorldDetailCommand:create(self.cityIndex, self.m_cityInfo:getProperty("tileServerId"))
    cmd:send()
end

function CrossThroneBuffTowerTile:onExit()
    unregisterScriptObserver(self, "GET_WORLD_DETAIL_CMD_BACK")
end

function CrossThroneBuffTowerTile:refreshDetail(ref)
    local data = dictToLuaTable(ref)
    if ref == nil then
        return
    end
    dump(data,"@@ CrossThroneBuffTowerTile")

    self.data = data
    self:refreshView()
end

function CrossThroneBuffTowerTile:refreshView()
    self:setVisible(true)
    local playerInfo = GlobalData:call("getPlayerInfo")
    local allianceInfo = playerInfo:getProperty("allianceInfo")

    local function isSelfBuilding(uid, allianceId)
        if playerInfo:call("isInAlliance") then
            return allianceInfo:getProperty("uid") == allianceId
        else
            return playerInfo:getProperty("uid") == uid
        end

        return false
    end

    local selfBuild = self.data and isSelfBuilding(self.data.uid, self.data.allianceId) or false
    local tileServerId = self.m_cityInfo:getProperty("tileServerId")

    local function setCallBack(name, index, func, state)
        local function callback() func(self) end
        self:call("setButtonName", index, name)
        self:call("setButtonState", index, state)
        self:call("setButtonCallback", index, cc.CallFunc:create(callback))
    end

    if WorldController:call("isInSelfServer", tileServerId) then
        local fight_of_king = 0
        local state = WorldController:call("getInstance"):call("getKingActivityStateByType", fight_of_king)
        if state == NotOpen or state == OpenNoKing then
            self:setNotOpenTimeButtons(setCallBack)
        elseif state == PeaceTime then
            self:setPeaceTimeButtons(setCallBack)
        else
            if selfBuild then
                self:setDefenderWarTimeButtons(setCallBack)
            else
                self:setAttackerWarTimeButtons(setCallBack)
            end
        end
    else
        self:setPeaceTimeButtons(setCallBack)
    end
end

function CrossThroneBuffTowerTile:setNotOpenTimeButtons( setCallBack )
    self:call("setButtonCount", 1)
    setCallBack(getLang("110076"), 1, self.onInfoClick, TileButtonState.ButtonInformation)
end

function CrossThroneBuffTowerTile:setPeaceTimeButtons( setCallBack )
    self:call("setButtonCount", 1)
    setCallBack(getLang("110076"), 1, self.onInfoClick, TileButtonState.ButtonInformation)
end

function CrossThroneBuffTowerTile:setAttackerWarTimeButtons( setCallBack )
    local watchTowerEnabel = FunBuildController:call("isExistBuildByTypeLv", 417000, 2)
    local rallyPos = 4
    if watchTowerEnabel then
        self:call("setButtonCount", 4)
        setCallBack(getLang("108722"), 5, self.onClickScout, TileButtonState.ButtonScout)
    else
        self:call("setButtonCount", 3)
        rallyPos = 1
    end
    setCallBack(getLang("110076"), 2, self.onInfoClick, TileButtonState.ButtonInformation)
    setCallBack(getLang("108723"), 3, self.onClickAttack, TileButtonState.ButtonMarch)
    setCallBack(getLang("108726"), rallyPos, self.onClickRally, TileButtonState.ButtonRally)
end

function CrossThroneBuffTowerTile:setDefenderWarTimeButtons( setCallBack )
    self:call("setButtonCount", 4)
    setCallBack(getLang("110076"), 2, self.onInfoClick, TileButtonState.ButtonInformation)
    setCallBack(getLang("108728"), 3, self.onClickSurpport, TileButtonState.ButtonSupport)
    setCallBack(getLang("110067"), 4, self.onClickRally, TileButtonState.ButtonRally)
    setCallBack(getLang("108724"), 5, self.onClickTroop, TileButtonState.ButtonViewTroop)
end

function CrossThroneBuffTowerTile:onInfoClick( ... )
    local dict = CCDictionary:create()
    dict:setObject(CCString:create(tostring(self.cityIndex)), "cityIndex")
    dict:setObject(CCString:create("WarBuildInfoPopUpView"), "name")
    LuaController:call("openPopViewInLua", dict)

    self:closeTile()
end

function CrossThroneBuffTowerTile:onClickScout( ... )
    SoundController:call("playEffects", Music_Sfx_click_button)
    
    if not self.data.uid or self.data.uid == "" then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("165072"))
        self:closeTile()
        return
    end

    local warningTips = ToolController:call("getBeforeBattleWarning")
    local function scout() 
        WorldController:call("openScoutView", self.cityIndex) 
        self:closeTile()
    end
    local warningTips = ToolController:call("getBeforeBattleWarning")
    if warningTips ~= "" then
        YesNoDialog:show(warningTips, scout)
    else
        scout()
    end
end

function CrossThroneBuffTowerTile:onClickAttack( ... )
    local function march()
        WorldController:call("openMarchDeploy", self.cityIndex, 1)
        self:closeTile()
    end
    local warningTips = ToolController:call("getBeforeBattleWarning")
    if warningTips ~= "" then
        YesNoDialog:call("show", warningTips, cc.CallFunc:create(march))
    else
        march()
    end
end

function CrossThroneBuffTowerTile:onClickRally(  )
    local function rally()
        AllianceManager:call("openAllianceMassView",self.cityIndex)
        self:closeTile()
    end
    local warningTips = ToolController:call("getBeforeBattleWarning")
    if warningTips ~= "" then
        YesNoDialog:call("show", warningTips, cc.CallFunc:create(rally))
    else
        rally()
    end
end

function CrossThroneBuffTowerTile:onClickSurpport( ... )
    SoundController:call("playEffects", Music_Sfx_click_button)
    YuanJunTipView:call("openYuanYunView", self.cityIndex, self.m_cityInfo:getProperty("luaType"), 0)
    self:closeTile()
end

function CrossThroneBuffTowerTile:onClickTroop( ... )
    SoundController:call("playEffects", Music_Sfx_click_button)
    
    local uuid = ""
    local marchInfo = WorldController:call("getInstance"):getProperty("m_marchInfo")
    for k, v in pairs(marchInfo) do
        if v:getProperty("ownerType") == PlayerType.PlayerSelf and v:getProperty("endPointIndex") == self.cityIndex then
            uuid = v:getProperty("uuid")

            if v:getProperty("teamUid") ~= "" then
                uuid = v:getProperty("teamUid")
            end
        end
    end

    local dict = CCDictionary:create()
    dict:setObject(CCString:create("TroopBuildingDetailView"), "name")
    dict:setObject(CCString:create(uuid), "uuid")
    dict:setObject(CCString:create(tostring(self.cityIndex)), "pointId")
    LuaController:call("openPopViewInLua", dict)

    self:closeTile()
end

function CrossThroneBuffTowerTile:closeTile()
    self = tolua.cast(self, "NewBaseTileLuaInfo")
    self:call("closeThis")
end
