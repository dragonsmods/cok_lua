local CrossServerRewardView = class("CrossServerRewardView",
	function()
		return PopupBaseView:create()
	end
)

function CrossServerRewardView:create(rewards, descs, stars)
	local view = CrossServerRewardView.new()
	Drequire("game.crossThrone.CrossServerRewardView_ui"):create(view, 1)
	if view:initView(rewards, descs, stars) then
		return view
	end
end

function CrossServerRewardView:initView(rewards, descs, stars)
	self:setHDPanelFlag(true)
	if CCCommonUtilsForLua:isIosAndroidPad() then
		self.ui.nodeccb:setScale(2.0)
	end

	local rsolts = splitString(rewards, "|")
	local dsolts = splitString(descs, "|")
	
	if #rsolts ~= #dsolts then return false end

	local sourceData = {}
	for index = 1, #rsolts do
		table.insert(sourceData, {itemId = rsolts[index], desc = dsolts[index]})
	end
	self.ui:setTableViewDataSource("m_listTableView", sourceData)

	self.ui.m_titleLabel:setString(getLang("138572"))
	self.ui.m_desLabel:setString(getLang("138573"))

	local stars = atoi(stars)
	local originPosX = 0

	if stars % 2 == 0 then
		originPosX = (stars / 2 + 1) * (-50) + 25
	else
		originPosX = math.floor(stars / 2 + 1) * (-50)
	end

	for index = 1, stars do
		local star = CCLoadSprite:createSprite("ICON_xingxing01.png")
        local particle1 = ParticleController:call("createParticle", "UIGlowLoop_1")
        local particle2 = ParticleController:call("createParticle", "UIGlowLoop_2")
        star:setPosition(originPosX + index * 50, 15)
        particle1:setPosition(originPosX + index * 50, 15)
        particle2:setPosition(originPosX + index * 50, 15)
        self.ui.m_starListNode:addChild(star)
        self.ui.m_starListNode:addChild(particle1)
        self.ui.m_starListNode:addChild(particle2)
	end

	self.ui.m_starListNode:setScale(0.8)

	local touchLayer = cc.Layer:create()
	self:addChild(touchLayer)

	local function touchHandle( eventType, x, y )
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		
		else
			self:onTouchEnded(x, y)
		end
	end
	touchLayer:registerScriptTouchHandler(touchHandle)
	touchLayer:setTouchEnabled(true)
	touchLayer:setSwallowsTouches(false)

	return true
end

function CrossServerRewardView:onEnter( )

end

function CrossServerRewardView:onExit( )
	
end

function CrossServerRewardView:onTouchBegan(x, y)
	if not isTouchInside(self.ui.m_touchNode, x, y) then
		self.m_tp = ccp(x, y)
		self.m_tt = GlobalData:call("getTimeStamp")
		return true
	end

	return false
end

function CrossServerRewardView:onTouchEnded(x, y)
	if ccpDistance(self.m_tp, ccp(x, y)) > 10 then return end
	if self.m_tt - GlobalData:call("getTimeStamp") > 0 then return end
	self:call("closeSelf")
end

return CrossServerRewardView