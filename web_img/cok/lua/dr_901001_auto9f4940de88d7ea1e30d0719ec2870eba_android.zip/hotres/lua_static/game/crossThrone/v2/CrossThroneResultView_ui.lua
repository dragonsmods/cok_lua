----------------------------
-- Author: Elex
-- Date: 2021-11-10 Wednesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CrossThroneResultView_ui = class("CrossThroneResultView_ui")

--#ui propertys


--#function
function CrossThroneResultView_ui:create(owner, viewType, paramTable)
	local ret = CrossThroneResultView_ui.new()
	CustomUtility:LoadUi("CrossThroneResultView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CrossThroneResultView_ui:initLang()
	LabelSmoker:setText(self.m_pLabelTTF120, "52045483")
end

function CrossThroneResultView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CrossThroneResultView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return CrossThroneResultView_ui

