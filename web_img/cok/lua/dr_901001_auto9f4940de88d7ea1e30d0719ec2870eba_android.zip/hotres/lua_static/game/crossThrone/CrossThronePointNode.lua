local CrossThronePointNode = class("CrossThronePointNode", cc.Node)

function CrossThronePointNode:create(pointType)
	local node = CrossThronePointNode.new()
	Drequire("game.crossThrone.KingOfAllServerRewardCell1_ui"):create(node, 0)
	if node:initNode(pointType) then return node end
end

function CrossThronePointNode:initNode(pointType)
	self.pointType = pointType
	self.csManager = require("game.crossThrone.CrossThroneManager")
	self.openShow = false
	self:refreshNode()
	return true
end

function CrossThronePointNode:refreshNode()
	local curScore, scoreList = self.csManager:getPointData(self.pointType)
	local _, rewardStateList = self.csManager:getPointRewardData(self.pointType)

	--Dprint("curScore, scoreList, rewardStateList", curScore, scoreList, rewardStateList)
	if curScore and scoreList and rewardStateList then
		local sourceData = { }
		for index, score in ipairs(scoreList) do
			table.insert(sourceData,{
										["curScore"] = curScore, 
										["stageScore"] = score, 
										["beforeScore"] = scoreList[index - 1] and scoreList[index - 1] or 0,
										["state"] = rewardStateList[index],
										["pointType"] = self.pointType,
									}
						)
		end

		--local offset = self.ui.m_scrollView:getContentOffset()
		self.ui:setTableViewDataSource("m_scrollView", sourceData)
		--self.ui.m_scrollView:setContentOffset(offset)
		self.ui.m_pointLabel:setString(CC_CMDITOA(curScore))
	end

	if self.pointType == BUILD_POINT_TYPE then
		self.ui.m_tileLabel:setString(getLang("138625"))
	else
		self.ui.m_tileLabel:setString(getLang("138626"))
	end
end

function CrossThronePointNode:onEnter( ... )
	
end

function CrossThronePointNode:onExit( ... )
	
end

function CrossThronePointNode:onTouchBegan(x, y)
	-- body
end

function CrossThronePointNode:onTouchMoved(x, y)
	-- body
end

function CrossThronePointNode:onTouchEnded(x, y)
	-- body
end

function CrossThronePointNode:onShowBtnClick()
	--先看有没有奖励数据
	local pointRwd = self.csManager:getPointRewardData(self.pointType)
	if pointRwd then 
		self.openShow = not self.openShow
		self.ui.m_arrowSp:setRotation(self.openShow and -90 or 90)

		local passer = CCDictionary:create()
		passer:setObject(CCString:create(tostring(self.pointType)), "pointType")
		passer:setObject(CCString:create(tostring(self.openShow)), "openShow")
		CCSafeNotificationCenter:postNotification("crossthrone.pointRwdShow", passer)
	end
end

function CrossThronePointNode:onBtnAddClick()
	local WorldMineHowView = Drequire("game.city.WorldMineHowView")
	local introDialogId = (self.pointType == BUILD_POINT_TYPE) and "138602" or "138603"
    local view = WorldMineHowView:create(introDialogId)
    PopupViewController:addPopupView(view)
end

return CrossThronePointNode