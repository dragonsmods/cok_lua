local CrossThroneTicketView = class("CrossThroneTicketView", PopupBaseView)

function CrossThroneTicketView:ctor()
    Drequire("game.crossThrone.v2.CrossThroneTicketView_ui"):create(self, 1)
    self.ctMgr = require("game.crossThrone.CrossThroneManager")
    self.battleItemId = self.ctMgr:getDespotItemId()
    self.obItemId = self.ctMgr:getObItemId()
    self.despotId = self.ctMgr:getDespotId()
    self:initView()
end

function CrossThroneTicketView:initView()
    local tInfo = ToolController:call("getToolInfoForLua", self.battleItemId)
    if tInfo then
        self.price1 = tInfo:getProperty("price")
        self.ui.m_goldNum1:setString(CC_CMDITOA(self.price1))
    end

    local tInfo = ToolController:call("getToolInfoForLua", self.obItemId)
    if tInfo then
        self.price2 = tInfo:getProperty("price")
        self.ui.m_goldNum2:setString(CC_CMDITOA(self.price2))
    end

    registerTouchHandler(self)
end

function CrossThroneTicketView:buy(params)
    local data = dictToLuaTable(params)

    local function confirm()
        
        self.waitInterface1 = GameController:call("showWaitInterface1", self.ui.m_buyBtn1)
        self.ctMgr:buyTicket(tostring(self.battleItemId), atoi(data.count))

    end

    local tip = getLang("52045342", CC_CMDITOA(self.price1 * atoi(data.count)))
    YesNoDialog:call("showYesNoFun", tip, cc.CallFunc:create(confirm), getLang("confirm"), nil, getLang("cancel_btn_label"))
end

function CrossThroneTicketView:buySuccess(params)
    -- local data = dictToLuaTable(params)
    -- local itemId = atoi(data.infoDic.itemId)
    -- if itemId == self.battleItemId then
    --     self.waitInterface1:call("remove")
    -- else
    --     self.waitInterface2:call("remove")
    -- end
    PopupViewController:call("removePopupView", self)
end

function CrossThroneTicketView:onEnter()
    registerScriptObserver(self, self.buy, "msg.crossthrone.ticket")
    registerScriptObserver(self, self.buySuccess, "msg.crossthrone.buy")
end

function CrossThroneTicketView:onExit()
    unregisterScriptObserver(self, "msg.crossthrone.ticket")
    unregisterScriptObserver(self, "msg.crossthrone.buy")
end

function CrossThroneTicketView:onTouchBegan(x, y)
    if not isTouchInside(self.ui.m_bg,x,y) then
        self.touchPoint = ccp(x, y)
		return true
	end
end

function CrossThroneTicketView:onTouchEnded(x, y)
    if ccpDistance(self.touchPoint, ccp(x, y)) > 10 then return end
    PopupViewController:call("removePopupView", self)
end

function CrossThroneTicketView:onClickBuy1()
    if not (self.ctMgr:hasApplyed() and PlayerInfoController:isInAlliance()) then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("52045415"))
        return 
    end

    local reach, condition = self.ctMgr:isConditionReach(self.despotId)
    if not reach then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("52045373", unpack(condition)))
        return
    end 

    local tInfo = ToolController:call("getToolInfoForLua", self.battleItemId)
    local cnt = tInfo and tInfo:call("getCNT") or 0

    local tipQueue = {}
    local needNum = self.ctMgr:getNeedTickets(self.despotId)
    if cnt >= needNum then
        table.insert(tipQueue, getLang("52045365"))
    end

    local tipCount = 0
    local function confirm()
        tipCount = tipCount + 1

        if tipQueue[tipCount] then
            YesNoDialog:call("showYesNoFun", tipQueue[tipCount], cc.CallFunc:create(confirm), getLang("confirm"), nil, getLang("cancel_btn_label"))
        else
            if self.price1 > GlobalData:call("getPlayerInfo"):getProperty("gold") then
                self:call("closeSelf")
                YesNoDialog:call("gotoPayTips")
                return
            end

            local StoreBuyConfirmDialogForLua = Drequire("game.CommonPopup.StoreBuyConfirmDialogForLua")
            local params = {}
            params.itemId = tostring(self.battleItemId)
            params.curNum = needNum - cnt
            params.maxNum = needNum - cnt
            params.messagePosted = "msg.crossthrone.ticket"
            params.singlePoint = self.price1
            params.moneyIcon = "ui_gold.png"
            params.id = ""
    
            local view = StoreBuyConfirmDialogForLua:create(params)
            PopupViewController:addPopupView(view)
        end
    end
    
    confirm()
end

function CrossThroneTicketView:onClickBuy2()
    local reach, condition = self.ctMgr:isConditionReach(self.despotId, true)
    if not reach then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("52045373", unpack(condition)))
        return
    end 

    local tInfo = ToolController:call("getToolInfoForLua", self.obItemId)
    local cnt = tInfo and tInfo:call("getCNT") or 0

    local tipQueue = {}
    if cnt > 0 then
        table.insert(tipQueue, getLang("52045365"))
    end

    table.insert(tipQueue, getLang("52045342", CC_CMDITOA(self.price2)))
        
    local tipCount = 0
    local function confirm()
        tipCount = tipCount + 1

        if tipQueue[tipCount] then
            YesNoDialog:call("showYesNoFun", tipQueue[tipCount], cc.CallFunc:create(confirm), getLang("confirm"), nil, getLang("cancel_btn_label"))
        else
            if self.price2 > GlobalData:call("getPlayerInfo"):getProperty("gold") then
                self:call("closeSelf")
                YesNoDialog:call("gotoPayTips")
                return
            end

            self.waitInterface2 = GameController:call("showWaitInterface1", self.ui.m_buyBtn2)
            self.ctMgr:buyTicket(tostring(self.obItemId), 1)
        end
    end
    
    confirm()
end

function CrossThroneTicketView:onClickClose()
    PopupViewController:call("removePopupView", self)
end

return CrossThroneTicketView