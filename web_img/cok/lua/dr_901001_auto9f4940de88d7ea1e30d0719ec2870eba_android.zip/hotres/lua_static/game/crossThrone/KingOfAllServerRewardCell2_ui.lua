----------------------------
-- Author: Elex
-- Date: 2018-11-01 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local KingOfAllServerRewardCell2_ui = class("KingOfAllServerRewardCell2_ui")

--#ui propertys


--#function
function KingOfAllServerRewardCell2_ui:create(owner, viewType, paramTable)
	local ret = KingOfAllServerRewardCell2_ui.new()
	CustomUtility:LoadUi("KingOfAllServerRewardCell2.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function KingOfAllServerRewardCell2_ui:initLang()
end

function KingOfAllServerRewardCell2_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function KingOfAllServerRewardCell2_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return KingOfAllServerRewardCell2_ui

