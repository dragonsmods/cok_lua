local CrossThroneKingRewardView = class("CrossThroneKingRewardView",
	function()
		return PopupBaseView:create()
	end)

function CrossThroneKingRewardView:create(dialogId)
	local view = CrossThroneKingRewardView.new()
	Drequire("game.crossThrone.KingOfAllServerPrizeView_ui"):create(view, 1)
	if view:initView(dialogId) then
		return view
	end
end

function CrossThroneKingRewardView:initView(dialogId)
	if self:init(true, 0) == false then
		return false
	end
	
	self:setHDPanelFlag(true)
	--self:call("setModelLayerDisplay", false)

	local crossThroneManager = require("game.crossThrone.CrossThroneManager") 
	if crossThroneManager:isDespotServer() then
		self.battleType = DESPOT_BATTLE
		self.ui.m_detailLabel:setString(getLang("138355"))
	else
		self.battleType = EMPIRE_BATTLE
		self.ui.m_detailLabel:setString(getLang("138378"))
	end

	local rewardStr = crossThroneManager:getDespotPropertyByKey("reward_show")
	local rewardVec = splitString(rewardStr, "|")
	self.reward = {}
	for i = 1, #rewardVec do
		local rd = splitString(rewardVec[i], ";")
		if #rd == 2 then
			local itemId = tonumber(rd[1])
			local itemNum = tonumber(rd[2])
			self.reward[#self.reward + 1] = {
				id = itemId,
				num = itemNum,
			}
		end
	end

	dump(self.reward, "CrossThroneKingRewardView reward")

	if self.reward[1] then
		local itemInfo = ToolController:call("getToolInfoByIdForLua", self.reward[1].id)
		local itemName = itemInfo:call("getName")
		local iconName = itemInfo:getProperty("icon") .. ".png"
        local itemIcon = CCLoadSprite:createSprite(iconName, CCLoadSpriteType.CCLoadSpriteType_EQUIP)
        self.ui.m_iconLabel1:setString(itemName)
        self.ui.m_iconNode1:removeAllChildren()
        self.ui.m_iconNode1:addChild(itemIcon)
        CCCommonUtilsForLua:call("setSpriteMaxSize", itemIcon, 120, true)

        local color = itemInfo:getProperty("color")
        Dprint("color", color)
     	local colorBg = "color_c_" .. color .. ".png"
	    local iconBg = CCLoadSprite:call("loadResource", colorBg)
	    self.ui.m_colorSprite1:setSpriteFrame(iconBg)
	end

	if self.reward[2] then
		local itemInfo = ToolController:call("getToolInfoByIdForLua", self.reward[2].id)
		local itemName = itemInfo:call("getName")
        local itemIcon = CCLoadSprite:createSprite(iconName)
        self.ui.m_iconLabel2:setString(itemName)
        self.ui.m_numLabel1:setString(tostring(self.reward[2].num))
		CCCommonUtilsForLua:call("createGoodsIcon", self.reward[2].id, self.ui.m_iconNode2, cc.size(108, 108))
	end

	if self.reward[3] then
		local itemInfo = ToolController:call("getToolInfoByIdForLua", self.reward[3].id)
		local itemName = itemInfo:call("getName")
        local itemIcon = CCLoadSprite:createSprite(iconName)
        self.ui.m_iconLabel3:setString(itemName)
        self.ui.m_numLabel2:setString(tostring(self.reward[3].num))
		CCCommonUtilsForLua:call("createGoodsIcon", self.reward[3].id, self.ui.m_iconNode3, cc.size(108, 108))
	end


	if CCCommonUtilsForLua:isIosAndroidPad() then
		self:setScale(2)
	end

	self.ui.m_titleLabel:setString(getLang(dialogId))
	
	local touchLayer = cc.Layer:create()
	self:addChild(touchLayer)

	local function touchHandle( eventType, x, y )
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		
		else
			self:onTouchEnded(x, y)
		end
	end
	touchLayer:registerScriptTouchHandler(touchHandle)
	touchLayer:setTouchEnabled(true)
	touchLayer:setSwallowsTouches(false)


	return true
end

function CrossThroneKingRewardView:onEnter()

end

function CrossThroneKingRewardView:onExit()
	-- body
end

function CrossThroneKingRewardView:onTouchBegan(x, y)
	self.m_touchPoint = ccp(x, y)
	return true
end

function CrossThroneKingRewardView:onTouchEnded(x, y)
	if not isTouchInside(self.ui.m_touchNode, x, y) then
		local distance = ccpDistance(self.m_touchPoint, ccp(x, y))
		if distance > 20 then
			return
		end

		PopupViewController:call("removePopupView", self)

	end
end


return CrossThroneKingRewardView