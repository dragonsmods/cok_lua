local CrossThroneTowerDetailsView = class("CrossThroneTowerDetailsView", PopupBaseView)

local cellWidth = 0
local cellHeight = 122

function CrossThroneTowerDetailsView:create(buildId, cityIndex)
	local view = CrossThroneTowerDetailsView.new()
	Drequire("game.crossThrone.KingOfAllServerBuildingView_ui"):create(view, 0)
	view:initView(buildId, cityIndex)
	return view
end

function CrossThroneTowerDetailsView:initView(buildId, cityIndex)
	self.buildId = buildId
	self.cityIndex = cityIndex
	self.smallCellOpenHeight = 0
	
	CCLoadSprite:call("loadDynamicResourceByName", "crossThrone_entry")
	CCLoadSprite:call("doResourceByCommonIndex", 204, true)

	local playerInfo = GlobalData:call("getPlayerInfo")
	self.currentServerId = playerInfo:getProperty("currentServerId")
	self.csManager = require("game.crossThrone.CrossThroneManager")
	self.csManager:reqBuildData(self.currentServerId, self.cityIndex)

	self:setHDPanelFlag(true)

	self:call("setSwallowsTouches", true)
	self:call("setModelLayerDisplay", true)
	
	local clipSize = self.ui.m_picNode:getContentSize()
    self.m_clipNode = CCClipNode:call("create", clipSize.width, clipSize.height)
    self.ui.m_picNode:addChild(self.m_clipNode)

    local pic = CCCommonUtilsForLua:call("getPropByIdGroup", "overlord_building", tostring(buildId), "pic")
    local name = CCCommonUtilsForLua:call("getPropByIdGroup", "overlord_building", tostring(buildId), "name")
    local paras = splitString(CCCommonUtilsForLua:call("getPropByIdGroup", "overlord_building", tostring(buildId), "para2"), ";")
    local desc = CCCommonUtilsForLua:call("getPropByIdGroup", "overlord_building", tostring(buildId), "dec")
    self.ui.m_desLabel:setString(getLang(desc, paras[1], paras[2], paras[3]))
    self.ui.m_titleTxt:setString(getLang(name))
    self.ui.m_tileLabel:setString(getLang(name))

    local bg = CCLoadSprite:createSprite(pic .. ".png")
    local bgSize = bg:getContentSize()
    bg:setAnchorPoint(ccp(0, 0))
    bg:setPosition((clipSize.width - bgSize.width) / 2, (clipSize.height - bgSize.height))
	self.m_clipNode:addChild(bg)

	local showSwitch = CCCommonUtilsForLua:call("getPropByIdGroup", "overlord_building", tostring(buildId), "on_off")
    if showSwitch ~= "1" then
    	local size = self.ui.m_listNode:getContentSize()
    	self.ui.m_listNode:setContentSize(cc.size(size.width, size.height + 76))
    	self.ui.m_switchNode:setVisible(false)
    end

	local touchLayer = cc.Layer:create()
	self:addChild(touchLayer)

	local function touchHandle( eventType, x, y )
		-- print("touchHandle", eventType, x, y)
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
			self:onTouchMoved(x, y)
		else
			self:onTouchEnded(x, y)
		end
	end
	touchLayer:registerScriptTouchHandler(touchHandle)
	touchLayer:setTouchEnabled(true)
	touchLayer:setSwallowsTouches(false)

	self:addLoadingAni()

	self.dataList = {}
	self.m_tableView = cc.TableView:create(self.ui.m_listNode:getContentSize())
	self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
	self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
	self.m_tableView:setDelegate()

	self.m_tableView:registerScriptHandler(function(tab, cell) self:tableCellTouched(tab, cell) end, cc.TABLECELL_TOUCHED)
	self.m_tableView:registerScriptHandler(function(tab, idx) return self:cellSizeForTable(tab, idx) end, cc.TABLECELL_SIZE_FOR_INDEX)
	self.m_tableView:registerScriptHandler(function(tab, idx) return self:tableCellAtIndex(tab, idx) end, cc.TABLECELL_SIZE_AT_INDEX)
	self.m_tableView:registerScriptHandler(function(tab) return self:numberOfCellsInTableView(tab) end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
	self.ui.m_listNode:addChild(self.m_tableView)
end

function CrossThroneTowerDetailsView:addLoadingAni()
	self:removeLoadingAni()

	self.m_loadingIcon = CCLoadSprite:call("createSprite", "loading_1.png")
	self.m_loadingIcon:setAnchorPoint(ccp(0.5, 0.5))

	local cSize = self.ui.m_listNode:getContentSize()
	self.m_loadingIcon:setPosition(ccp(cSize.width / 2, cSize.height / 2))

	local rotateAction = cc.RotateTo:create(0.5, 720)
	local rotateForever = cc.RepeatForever:create(rotateAction)
	self.m_loadingIcon:runAction(rotateForever)
	self.ui.m_listNode:addChild(self.m_loadingIcon, 1000000)
end

function CrossThroneTowerDetailsView:removeLoadingAni()
	if self.m_loadingIcon then
		self.ui.m_listNode:removeChild(self.m_loadingIcon)
		self.m_loadingIcon = nil
	end
end

function CrossThroneTowerDetailsView:onEnter( ... )
	UIComponent:call("showPopupView", 1)
	self:call("setModelLayerOpacity", 255)
	self:call("setModelLayerPosition", self.ui.m_topNode:getPosition())

	local function callback1(param) self:updateView(param) end
	local handler1 = self:registerHandler(callback1)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "crossthrone.buildData")

	local function callback2(param) self:refreshTableView() end
	local handler2 = self:registerHandler(callback2)
	CCSafeNotificationCenter:registerScriptObserver(self, handler2, "crossthrone.cellTouch")

	local function callback3(param) self:updateSwitch(param) end
	local handler3 = self:registerHandler(callback3)
	CCSafeNotificationCenter:registerScriptObserver(self, handler3, "crossthrone.switch")
end

function CrossThroneTowerDetailsView:onExit( ... )
	CCSafeNotificationCenter:unregisterScriptObserver(self, "crossthrone.buildData")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "crossthrone.cellTouch")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "crossthrone.switch")
end

function CrossThroneTowerDetailsView:updateView(ref )
	if not ref then return end

	self:removeLoadingAni()
	
	local tbl = dictToLuaTable(ref)   
	self.dataList = {}
	self.sourceData = tbl
	
	local allArmyList = tbl.army 
	local nowContain = 0
	local beCopy = true

	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	local selfAllianceId = playerInfo:call("getAllianceId")

	if nil == allArmyList or allArmyList == {} then
		MyPrint("army dataList is nil")
	else
		for i,v in ipairs(allArmyList) do
			nowContain = nowContain + tonumber(allArmyList[i].totalTroops)
			allArmyList[i].isOpen = "0"
		end

	
		if tbl.owner and selfAllianceId ~= tbl.owner.allianceId then
			beCopy = false
		end
		
		if tbl.owner and playerInfo:getProperty("uid") == tbl.owner.uid then
			self.canOperateSwitch = true
		else
			self.canOperateSwitch = false
		end

		if beCopy then
			self.dataList = allArmyList
		end
	end

	if tbl.maxSoldiers then
		nowContain = math.min(nowContain,tonumber(tbl.maxSoldiers))
		--self.m_tipsLabel:setString(getLang("165042",nowContain .. "/" .. tbl.maxSoldiers))
		
		if nowContain >= tonumber(tbl.maxSoldiers) then
			self.canMarch = false
		else
			self.canMarch = true
		end
	end  

	self.beCopy = beCopy
	--检查军队是否可见
	
	if tbl.owner and selfAllianceId == tbl.owner.allianceId then
		self.canSeeArmy = true
		self.m_tableView:reloadData()
	else
		self.canSeeArmy = false
		self.canMarch = false
	end

	self:resetSwitch()
end

function CrossThroneTowerDetailsView:updateSwitch(param)
	if self.sourceData and param then
		local pointId = param:valueForKey("pointId"):getCString()
		local switch = param:valueForKey("switch"):getCString()
		if atoi(pointId) == atoi(self.cityIndex) then
			self.sourceData.switch = switch
			self:resetSwitch()
		end
	end
end

function CrossThroneTowerDetailsView:resetSwitch()
	--开关状态
	self.ui.m_stateNode:removeAllChildren()

	local sicon = "crossThroneActive"

	if self.sourceData.switch == "1" then
		self.ui.m_touchBtn:setPositionX(29)
		self.ui.m_touchBtn1:setPositionX(29)
		CCCommonUtilsForLua:setSpriteGray(self.ui.m_stateBtnBg, false)
        CCCommonUtilsForLua:setSpriteGray(self.ui.m_touchBtn1, false)
        self.ui.m_stateLabel:setString(getLang("138605"))
        sicon = "crossThroneActive"
	else
		self.ui.m_touchBtn:setPositionX(-29)
		self.ui.m_touchBtn1:setPositionX(-29)
		CCCommonUtilsForLua:setSpriteGray(self.ui.m_stateBtnBg, true)
        CCCommonUtilsForLua:setSpriteGray(self.ui.m_touchBtn1, true)
        self.ui.m_stateLabel:setString(getLang("138604"))
        sicon = "crossThroneUnActive"
	end

	local ssp = CCLoadSprite:createSprite(sicon .. ".png")
	self.ui.m_stateNode:addChild(ssp) 
end

function CrossThroneTowerDetailsView:tableCellTouched(tab,cell)
	if cell then 
		cell:touchCellCB() 
	end
end

function CrossThroneTowerDetailsView:cellSizeForTable(tab,idx)
	if self.canSeeArmy == false then
		return 0, 0
	end
	local idIndex = idx + 1
	if self.canMarch and idIndex == #self.dataList + 1 then
		return cellWidth,cellHeight
	end
	if idIndex > #self.dataList then
		return 0, 0
	end
	local nowcellHeight = cellHeight
	if self.dataList[idIndex].isOpen == "1" then
		nowcellHeight = nowcellHeight + self.smallCellOpenHeight
	end
	return cellWidth, nowcellHeight    
end

function CrossThroneTowerDetailsView:tableCellAtIndex(tab, idx)
	if self.canSeeArmy == false then return end
	    
	local idIndex = idx + 1
	if self.canMarch and idIndex == #self.dataList + 1 then--最末行添加“+”
		if idIndex > #self.dataList + 1 then return end
		local cell = tab:dequeueCell()
		if not cell then
			cell = Drequire("game.crossThrone.CrossThroneTowerDetailsCell"):create()
		end	
		cell:refresh(-1)
		return cell   
	end

	if idIndex > #self.dataList then return end
	local cell = tab:dequeueCell()
	if not cell then
		Dprint("self.dataList", self.dataList)
		cell = Drequire("game.crossThrone.CrossThroneTowerDetailsCell"):create()
	end

	local function setOpenHeight(height)
		self.smallCellOpenHeight = height
	end
	cell:refresh(self.dataList[idIndex], self.dataList, self.cityIndex, setOpenHeight)
	return cell    
end

function CrossThroneTowerDetailsView:numberOfCellsInTableView(tab)
    if self.canSeeArmy == false then
        return 0 
    else
        if self.canMarch then
            return table.getn(self.dataList) + 1 --最末行添加“+”
        else        
            return table.getn(self.dataList)
        end
    end
end

function CrossThroneTowerDetailsView:refreshTableView( )
    local curr = self.m_tableView:getContentOffset()
    local max = self.m_tableView:maxContainerOffset()
    local min = self.m_tableView:minContainerOffset()
    self.m_tableView:reloadData()
    curr.y = curr.y + self.m_tableView:minContainerOffset().y - min.y
    if curr.y > self.m_tableView:maxContainerOffset(). y then
    	curr.y = self.m_tableView:maxContainerOffset(). y
    end
   	if curr.y < self.m_tableView:minContainerOffset().y then
   		curr.y = self.m_tableView:minContainerOffset().y
   	end
    self.m_tableView:setContentOffset(curr)
end

function CrossThroneTowerDetailsView:onTouchBegan(x, y)
	if isTouchInside(self.ui.m_stateBtnBg, x, y) then
		self.m_tp = ccp(x, y)
		self.m_tt = GlobalData:call("getTimeStamp")
		return true
	end

	return false
end

function CrossThroneTowerDetailsView:onTouchMoved(x, y)

end

function CrossThroneTowerDetailsView:onTouchEnded(x, y)
	if self.canOperateSwitch then
		if ccpDistance(self.m_tp, ccp(x, y)) > 10 then return end
		if self.m_tt - GlobalData:call("getTimeStamp") > 0 then return end

		if self.sourceData.switch == "0" then
			self.sourceData.switch = "1"
		else
			self.sourceData.switch = "0"
		end
		self.csManager:operateBuildSwitch(self.currentServerId, self.cityIndex, self.sourceData.switch)
	end
end

return CrossThroneTowerDetailsView