local CrossThroneGiftDetailView = class("CrossThroneGiftDetailView",
	function()
		return PopupBaseView:create()
	end
)

local CrossThroneGiftDetailCell = class("CrossThroneGiftDetailCell",
	function()
		return cc.Layer:create()
	end
)

function CrossThroneGiftDetailView:create(rewardConfig)
	local view = CrossThroneGiftDetailView.new()
	Drequire("game.crossThrone.KingOfAllServerGiftBagView_ui"):create(view, 1)
	if view:initView(rewardConfig) then
		return view
	end
end

function CrossThroneGiftDetailView:initView(rewardConfig)
	if self:init(true, 0) == false then
		return false
	end

	self:setHDPanelFlag(true)
	--self:call("setModelLayerDisplay", false)

	if CCCommonUtilsForLua:isIosAndroidPad() then
		self.ui.nodeccb:setScale(2)
	end

	self.ui.m_titleLabel:setString(getLang(rewardConfig.name))

	self.rewardId = rewardConfig.id

	local reload = false
	local rwd = GlobalData:call("getCachedRewardData", self.rewardId)
	self.m_data = arrayToLuaTable(rwd)
	
	local count = #self.m_data
	if count == 0 then
		GlobalData:call("checkAndRequestRewardData", self.rewardId)
	else
		reload = true
	end

	local listSize = self.ui.m_listNode:getContentSize()
	self.m_tableView = cc.TableView:create(listSize)
	self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
	self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
	self.m_tableView:setAnchorPoint(ccp(0, 0))
	self.m_tableView:setDelegate()
	self.m_tableView:registerScriptHandler(function(tab, idx) return self:cellSizeForTable(tab, idx) end, cc.TABLECELL_SIZE_FOR_INDEX)
	self.m_tableView:registerScriptHandler(function(tab, idx) return self:tableCellAtIndex(tab, idx) end, cc.TABLECELL_SIZE_AT_INDEX)
	self.m_tableView:registerScriptHandler(function(tab) return self:numberOfCellsInTableView(tab) end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
	self.ui.m_listNode:addChild(self.m_tableView)

	if reload then
		self.m_tableView:reloadData()
	end

	CCCommonUtilsForLua:setButtonTitle(self.ui.m_okButton, getLang("confirm"))

	local touchLayer = cc.Layer:create()
	self:addChild(touchLayer)

	local function touchHandle( eventType, x, y )
		-- print("touchHandle", eventType, x, y)
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		
		else
			self:onTouchEnded(x, y)
		end
	end
	touchLayer:registerScriptTouchHandler(touchHandle)
	touchLayer:setTouchEnabled(true)
	touchLayer:setSwallowsTouches(false)

	return true
end

function CrossThroneGiftDetailView:getRewardDetailBack(param)
	if param then
		local rewardId = param:getCString()
		--MyPrint("getRewardDetailBack", rewardId, self.rewardInfo.id)
		if rewardId == "" or self.rewardId ~= rewardId then return end

		local rwd = GlobalData:call("getCachedRewardData", self.rewardId)
		self.m_data = arrayToLuaTable(rwd)
		self.m_tableView:reloadData()
	end
end

function CrossThroneGiftDetailView:onEnter()
	local function onGetRwdDetailBack(param) self:getRewardDetailBack(param) end
    local handler1 = self:registerHandler(onGetRwdDetailBack)
    CCSafeNotificationCenter:registerScriptObserver(self, handler1, "MSG_GET_REWARD_DETAIL_BACK")
end

function CrossThroneGiftDetailView:onExit()
	CCSafeNotificationCenter:unregisterScriptObserver(self, "MSG_GET_REWARD_DETAIL_BACK")
end

function CrossThroneGiftDetailView:onOkButtonClick()
	PopupViewController:call("removePopupView", self)
end

function CrossThroneGiftDetailView:tableCellAtIndex(tabView, idx)
	if (idx >= #self.m_data) then return end

	local rewardId = self.m_data[idx + 1].rewardId
	local cell = tabView:dequeueCell()
	if cell then
		local node = cell:getChildByTag(666)
		node:setData(self.m_data[idx + 1])
	else
		cell = cc.TableViewCell:create()
		local node = CrossThroneGiftDetailCell:create(self.m_data[idx + 1])
		node:setTag(666)
		cell:addChild(node)
	end
	
	return cell
end

function CrossThroneGiftDetailView:numberOfCellsInTableView(tabView)
	return #self.m_data
end

function CrossThroneGiftDetailView:cellSizeForTable(tabView, idx)
	return 500, 80
end

function CrossThroneGiftDetailView:onTouchBegan(x, y)
	self.touchPoint = ccp(x, y)
	return true
end

function CrossThroneGiftDetailView:onTouchEnded(x, y)
	if ccpDistance(self.touchPoint, ccp(x, y)) > 20 then
		return
	end

	if not isTouchInside(self.ui.m_touchNode, x, y) then
		PopupViewController:call("removePopupView", self)
	end
end

-----------------------CrossThroneGiftDetailView-----------------------

function CrossThroneGiftDetailCell:create(rewardInfo)
	local view = CrossThroneGiftDetailCell.new()
	Drequire("game.crossThrone.KingOfAllServerGiftBagCell_ui"):create(view, 1)
	if view:initView(rewardInfo) then
		return view
	end
end

function CrossThroneGiftDetailCell:initView(rewardInfo)
	self:setData(rewardInfo)
	return true
end

function CrossThroneGiftDetailCell:setData(rewardInfo)
	local name = ""
	local icon  = ""

	local rewardType = tonumber(rewardInfo.type) or 0
    --MyPrint("rewardType", rewardType)
	local value = tonumber(rewardInfo.value) or 0
    local id = 0
	if rewardType == RewardTypeConfig.R_GOODS then
        local valueObj = rewardInfo.value
        id = tonumber(valueObj.id) or 0
		name = RewardController:call("getNameByType", rewardType, id)
		icon = RewardController:call("getPicByType", rewardType, id)
        value = tonumber(valueObj.num) or 0
	elseif rewardType == RewardTypeConfig.R_EFFECT then
		name = CCCommonUtilsForLua:call("getNameById", tostring(value))
		if name == "" then
			if value == 502600 then
				name = getLang("138074")
			elseif value == 502601 then
				name = getLang("138075")
			elseif value == 502602 then
				name = getLang("138076")
			end
		end

		icon = CCCommonUtilsForLua:call("getICon", tostring(value))
		value = 1
	else
		if rewardType == RewardTypeConfig.R_DRAGON_MODEL then
			name = getLang("140357")
		elseif rewardType == RewardTypeConfig.R_DRAGON_RING then
			name = getLang("140358")
		else 
			name = RewardController:call("getNameByType", rewardType, id)
		end

		icon = RewardController:call("getPicByType", rewardType, value)
	end

	self.ui.m_nameLabel:setString(name)

	local t = "X" .. CC_CMDITOA(value)
    if rewardType == RewardTypeConfig.R_EFFECT then t = "" end
	self.ui.m_numLabel:setString(t)

	local color = 2
	if rewardType == RewardTypeConfig.R_GOODS then
        local toolInfo = ToolController:call("getToolInfoByIdForLua", id)
        if toolInfo then
        	color = toolInfo:getProperty("color")
        end
    elseif (rewardType == RewardTypeConfig.R_EFFECT or rewardType == RewardTypeConfig.R_CRYSTAL or rewardType == RewardTypeConfig.R_WIN_POINT 
    			or rewardType == RewardTypeConfig.R_GOLD or rewardType == RewardTypeConfig.R_DRAGON_MODEL or rewardType == RewardTypeConfig.R_DRAGON_RING) then
    	color = 5
    end
    --MyPrint("DragonWorldCupRewardCell color", color)

    self.ui.m_iconNode:removeAllChildren()


    local colorBg = CCCommonUtilsForLua:call("getToolBgByColor", color)
    local iconBg = CCLoadSprite:call("createSprite", colorBg)
    CCCommonUtilsForLua:setSpriteMaxSize(iconBg, 60, true)
    self.ui.m_iconNode:addChild(iconBg, -100)

    local spr = CCLoadSprite:call("createSprite", icon)
    CCCommonUtilsForLua:setSpriteMaxSize(spr, 50, false)
    self.ui.m_iconNode:addChild(spr)

end



-----------------------CrossThroneGiftDetailCell-----------------------


return CrossThroneGiftDetailView