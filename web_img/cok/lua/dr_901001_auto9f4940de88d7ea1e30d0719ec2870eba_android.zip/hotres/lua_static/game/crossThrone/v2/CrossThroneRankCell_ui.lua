----------------------------
-- Author: Elex
-- Date: 2021-09-26 Sunday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CrossThroneRankCell_ui = class("CrossThroneRankCell_ui")

--#ui propertys


--#function
function CrossThroneRankCell_ui:create(owner, viewType, paramTable)
	local ret = CrossThroneRankCell_ui.new()
	CustomUtility:DoRes(7, true)
	CustomUtility:LoadUi("CrossThroneRankCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CrossThroneRankCell_ui:initLang()
end

function CrossThroneRankCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CrossThroneRankCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return CrossThroneRankCell_ui

