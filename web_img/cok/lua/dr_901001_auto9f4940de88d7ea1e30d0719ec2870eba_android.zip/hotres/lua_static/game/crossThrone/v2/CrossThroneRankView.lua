local CrossThroneRankView = class("CrossThroneRankView", PopupBaseView)

function CrossThroneRankView:ctor(finish, data, ccb)
    CCLoadSprite:call("loadDynamicResourceByName", "crossThrone_entry")
    Drequire(ccb or "game.crossThrone.v2.CrossThroneRankView_ui"):create(self, 1)
    self.ctMgr = require("game.crossThrone.CrossThroneManager")
    self.allianceRank = {}
    self.soloRank = {}
    self.finish = finish
    self.finalData = data
    self:initView()
end

function CrossThroneRankView:initView()
    if self.finish then
        self.ui.m_okBtn:setVisible(true)
        self.ui.m_closeBtn:setVisible(false)

        local size = self.ui.m_listView:getViewSize()
        local y = self.ui.m_listView:getPositionY()
        self.ui.m_listView:setPositionY(y + 80)

        local nSize = cc.size(size.width, size.height - 80)
        self.ui.m_listView:setViewSize(nSize)

        self:refreshView()
    else
        self.ui.m_okBtn:setVisible(false)
        self.ui.m_closeBtn:setVisible(true)
        registerTouchHandler(self)
        self:reqRankData()
    end
end

function CrossThroneRankView:refreshView(params)
    local tbl = params and dictToLuaTable(params) or self.finalData
    self.occupier = tbl.occupier
	self.soloRank = tbl.rank or {}
	self.allianceRank = {}
    self.recieveTime = getTimeStamp()
    
    self.allianceMap = {}
    self.soloMap = {}

    local function sort(m1, m2) 
        if atoi(m1.score) == atoi(m2.score) then
            return m1.uid < m2.uid
        else
            return atoi(m2.score) < atoi(m1.score)
        end
    end
    if table.getn(self.soloRank) > 1 then table.sort(self.soloRank, sort) end
    
    self.nativeRank = {}
    local allianceId = PlayerInfoController:getAllianceId()

    for _, v in ipairs(self.soloRank) do
        v.showName = string.join("", "#", v.kingdom, "(", v.abbr, ")", v.name)
        v.baseTime = v.occupyTime
        v.personly = true

        if not self.allianceMap[v.allianceId or v.abbr] then
            self.allianceMap[v.allianceId or v.abbr] = 
            {
                showName = string.join("", "#", v.kingdom, "(", v.abbr, ")"),
                kingdom = kingdom, 
                occupyTime = 0,
                order = v.allianceId
            }
            table.insert(self.allianceRank, self.allianceMap[v.allianceId or v.abbr])
        end

        self.soloMap[v.uid] = v
        self.allianceMap[v.allianceId or v.abbr].occupyTime = self.allianceMap[v.allianceId or v.abbr].occupyTime + atoi(v.occupyTime)
        self.allianceMap[v.allianceId or v.abbr].baseTime = self.allianceMap[v.allianceId or v.abbr].occupyTime
    
        if v.allianceId == allianceId then
            table.insert(self.nativeRank, v)
        end
    end

    --过滤占领时间为0的联盟
    for index, aRank in ripairs(self.allianceRank) do
        if aRank.occupyTime <= 0 then
            table.remove(self.allianceRank, index)
        end
    end

    local function sort(m1, m2) 
        if m1.occupyTime == m2.occupyTime then
            return m1.order < m2.order
        else
            return m2.occupyTime < m1.occupyTime
        end
    end

    if table.getn(self.allianceRank) > 1 then table.sort(self.allianceRank, sort) end

    --盟内有排名，则显示  【盟内个人排行榜】若盟内没有排名，或观众，则显示52045372=本组个人排行
    if table.getn(self.nativeRank) > 0 then
        self.soloRank = self.nativeRank
        CCCommonUtilsForLua:setButtonTitle(self.ui.m_soloBtn, getLang("52045331"))
    else
        CCCommonUtilsForLua:setButtonTitle(self.ui.m_soloBtn, getLang("52045372"))
    end
    self:onClickAlliance()
end

function CrossThroneRankView:reqRankData()
    self.ctMgr:requestOccupyData()
end

function CrossThroneRankView:updatePerSec(dt)
    if self.occupier then
        local pass = getTimeStamp() - self.recieveTime
        local uid = self.occupier.uid
        local allianceId = self.occupier.allianceId or self.occupier.abbr
        if self.soloMap[uid] then
            self.soloMap[uid].occupyTime = atoi(self.soloMap[uid].baseTime) + pass
        end

        if self.allianceMap[allianceId] then
            self.allianceMap[allianceId].occupyTime = atoi(self.allianceMap[allianceId].baseTime) + pass
        end

        local count = self.ui.m_listView:getMaxCellCount()
        for index = 1, count do
            local cell = self.ui.m_listView:cellAtIndex(index - 1)
            if cell then cell:updatePerSec() end
        end
    end
end

function CrossThroneRankView:onEnter()
    -- self:updatePerSec(1)
    -- self.entry = self:getScheduler():scheduleScriptFunc(function(dt) self:updatePerSec(dt) end, 1, false)
    registerScriptObserver(self, self.refreshView, "crossThrone.occupyRank")
    registerScriptObserver(self, self.reqRankData, "crossThrone.refreshOccupyRank")
end

function CrossThroneRankView:onExit()
    -- self:getScheduler():unscheduleScriptEntry(self.entry)
    unregisterScriptObserver(self, "crossThrone.occupyRank")
    unregisterScriptObserver(self, "crossThrone.refreshOccupyRank")
end

function CrossThroneRankView:onTouchBegan(x, y)
    if not isTouchInside(self.ui.m_bg,x,y) then
        self.touchPoint = ccp(x, y)
		return true
	end
end

function CrossThroneRankView:onTouchEnded(x, y)
    if ccpDistance(self.touchPoint, ccp(x, y)) > 10 then return end
    PopupViewController:call("removePopupView", self)
end

function CrossThroneRankView:onClickAlliance()
    self.ui.m_soloBtn:setEnabled(true)
    self.ui.m_allianceBtn:setEnabled(false)
    self.ui.m_rankText:setString(getLang("52045333"))
    self.ui.m_rankText2:setString(getLang("52045334"))
    self.ui:setTableViewDataSource("m_listView", self.allianceRank)

    if table.getn(self.allianceRank) == 0 then
        self.ui.m_noDataText:setVisible(true)
    else
        self.ui.m_noDataText:setVisible(false)
    end
end

function CrossThroneRankView:onClickSolo()
    self.ui.m_soloBtn:setEnabled(false)
    self.ui.m_allianceBtn:setEnabled(true)
    self.ui.m_rankText:setString(getLang("138026"))
    self.ui.m_rankText2:setString(getLang("52045408"))
    self.ui:setTableViewDataSource("m_listView", self.soloRank)

    if table.getn(self.soloRank) == 0 then
        self.ui.m_noDataText:setVisible(true)
    else
        self.ui.m_noDataText:setVisible(false)
    end
end

function CrossThroneRankView:onClickClose()
    PopupViewController:call("removePopupView", self)
end

function CrossThroneRankView:onClickOk()
    self.ctMgr:exitCrossThrone()
    self.waitInterface = GameController:call("showWaitInterface1", self.ui.m_okBtn)
end

return CrossThroneRankView