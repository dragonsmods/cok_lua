----------------------------
-- Author: Elex
-- Date: 2017-08-25 11:05:19
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local KingOfAllServerOverCell_ui = class("KingOfAllServerOverCell_ui")

--#ui propertys


--#function
function KingOfAllServerOverCell_ui:create(owner, viewType)
	local ret = KingOfAllServerOverCell_ui.new()
	CustomUtility:DoRes(7, true)
	CustomUtility:LoadUi("KingOfAllServerOverCell.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function KingOfAllServerOverCell_ui:initLang()
end

function KingOfAllServerOverCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function KingOfAllServerOverCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return KingOfAllServerOverCell_ui

