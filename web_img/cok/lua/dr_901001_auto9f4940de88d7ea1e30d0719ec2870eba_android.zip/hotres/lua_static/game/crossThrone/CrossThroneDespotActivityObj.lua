

local CrossThroneDespotActivityObj = class("CrossThroneDespotActivityObj", function (	)
	return ActivityEventObjForLua:call("create")
end)

local crossThroneManager = require("game.crossThrone.CrossThroneManager")

function CrossThroneDespotActivityObj.create( params )
	MyPrint("CrossThroneDespotActivityObj.create")
	local ret = CrossThroneDespotActivityObj.new()
	if ret:init(params) == false then
		ret = nil
	end
	return ret
end

-- 可重载
function CrossThroneDespotActivityObj:parse( params )
	MyPrint("ActivityEventObjForLua:parse")
	ActivityEventObjForLua.parse(self, params)
end

function CrossThroneDespotActivityObj:getCurActivityStageAndLeftTime( )
	--MyPrint("CrossThroneDespotActivityObj:getCurActivityStageAndLeftTime")
	local despotId = crossThroneManager:getDespotId()
	local isDespotCanEnter = crossThroneManager:isDespotCanEnter(despotId)
	--Dprint("isDespotCanEnter", isDespotCanEnter)
	if isDespotCanEnter then
		return ActivityStage.ActivityStage_Running, -666
	end
	--return self:getNormalCurActivityStageAndLeftTime()
	return ActivityStage.ActivityStage_Preparing, -666
end

function CrossThroneDespotActivityObj:getGameTickStr( )
	local despotId = crossThroneManager:getDespotId()
	return crossThroneManager:getDespotStateTime(despotId)
end

function CrossThroneDespotActivityObj:requestActivityDetail()
	Dprint("CrossThroneDespotActivityObj:requestActivityDetail")
	if CCCommonUtilsForLua:isFunOpenByKey("overlord") then 
		crossThroneManager:requestCrossThroneData()
	end
end

return CrossThroneDespotActivityObj