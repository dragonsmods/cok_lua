local CrossThroneOccupyRankView = class("CrossThroneOccupyRankView", 
	function() 
		return PopupBaseView:call("create") 
	end
)

function CrossThroneOccupyRankView:create(data)
    local ret = CrossThroneOccupyRankView.new()
    Drequire("game.crossThrone.CrossThroneOccupyRankView_ui"):create(ret, 0)
    if ret:initView(data) == false then
        return nil
    end
    return ret
end

function CrossThroneOccupyRankView:initView( data )
	if self:init(true, 0) == false then
		return false
	end
	self:setIsHDPanel(true)
 	self:onTabButton2Click()

	CCCommonUtilsForLua:setButtonTitle(self.ui.m_tabButton1, getLang("138482"))
	CCCommonUtilsForLua:setButtonTitle(self.ui.m_tabButton2, getLang("138483"))


	self.ui.m_titleLabel:setString(getLang("138484"))
	self.ui.m_desLabel:setString(getLang("138485"))
	self.ui.m_nowLabel:setString(getLang("138487"))

	self.ui.m_desLabel:retain()
	self.ui.m_desLabel:removeFromParent()

	local parent = self.ui.m_desScroll:getParent()
	local x, y = self.ui.m_desScroll:getPosition()
	local size = self.ui.m_desLabel:getContentSize()
	local scrollView = cc.ScrollView:create()
	local viewSize = self.ui.m_desScroll:getContentSize()
    scrollView:setViewSize(viewSize)
    scrollView:setPosition(CCPoint(x, y))
    scrollView:setScale(1.0)
    scrollView:ignoreAnchorPointForPosition(true)
    scrollView:setDirection(1)
    scrollView:setBounceable(true)
    scrollView:setClippingToBounds(true)
    scrollView:setContentSize(size)
    scrollView:setContentOffset(ccp(0, viewSize.height - size.height))
    scrollView:setDelegate()
  	parent:addChild(scrollView)
	scrollView:addChild(self.ui.m_desLabel)
	self.ui.m_desLabel:setPosition(0, 0)
	self.ui.m_desLabel:release()

	self.ui.m_topLabel:setString(getLang("170008"))
	self.ui.m_allianceLabel:setString(getLang("138488"))
	self.ui.m_inTimeLabel:setString(getLang("138338"))

	self.beingRequest = true
	--请求数据
	self.ctManager = require("game.crossThrone.CrossThroneManager")
	self.ctManager:requestOccupyData()
	self.battleType = self.ctManager:isDespotServer() and DESPOT_BATTLE or EMPIRE_BATTLE

	local timeSwitch = (self.battleType == DESPOT_BATTLE) and "overlord_ranking_time_off" or "monarch_ranking_time_off"
	if (CCCommonUtilsForLua:isFunOpenByKey(timeSwitch)) then
		self.ui.m_inTimeLabel:setVisible(false)
		self.ui.m_allianceLabel:setPositionX(self.ui.m_allianceLabel:getPositionX() + 120)
	else
		self.ui.m_inTimeLabel:setVisible(true)
	end
end

function CrossThroneOccupyRankView:onEnter(  )
	if self.battleType == DESPOT_BATTLE then
		self:setTitleName(getLang("138316"))
	else
		self:setTitleName(getLang("138385"))
	end

	local function callback1(param) self:refreshView(param) end
	local handler1 = self:registerHandler(callback1)
	CCSafeNotificationCenter:call("registerScriptObserver", self, handler1, "crossThrone.occupyRank")

	local function callback2(param) self:refreshOccupyRank(param) end
	local handler2 = self:registerHandler(callback2)
	CCSafeNotificationCenter:call("registerScriptObserver", self, handler2, "crossThrone.refreshOccupyRank")
	
	self:onEnterFrame(0)
	local function update(dt) self:onEnterFrame(dt) end 
	self.entry = tonumber(cc.Director:getInstance():getScheduler():scheduleScriptFunc(update, 1.0, false))
end

function CrossThroneOccupyRankView:onExit(  )
	CCSafeNotificationCenter:call("unregisterScriptObserver", self, "crossThrone.occupyRank")
	CCSafeNotificationCenter:call("unregisterScriptObserver", self, "crossThrone.refreshOccupyRank")
	cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
end

function CrossThroneOccupyRankView:onEnterFrame(  )
	if self.battleType == DESPOT_BATTLE then
		local endTime = ActivityController:call("getInstance"):getProperty("despotBattleEt")
		local now = GlobalData:call("getTimeStamp")
		local remain = endTime - now
		self.ui.m_overTimeLabel:setString(getLang("138486") .. format_time(remain))

		if (remain <= 0) then
			self:call("closeSelf")
		end
	end

	if self.m_occupier and self.m_data and (self.beingRequest == false) then
		for index, occupier in ipairs(self.m_data) do
			if self.m_occupier.uid == occupier.uid then
				self.m_data[index].occupyTime = tostring(atoi(self.m_data[index].occupyTime) + 1)

				if index > 1 then
					local preOccupyTime = atoi(self.m_data[index - 1].occupyTime)
					if (atoi(self.m_data[index].occupyTime) > preOccupyTime) then
						self.beingRequest = true
						self.ctManager:requestOccupyData()
					end
				end
				break

			end
		end
	end
end

function CrossThroneOccupyRankView:refreshView( params )
	local tbl = dictToLuaTable(params)
	dump(tbl, "CrossThroneOccupyRankView:refreshView tbl~~~")
	
	self.beingRequest = false
	self.m_occupier = tbl.occupier
	self.m_data = tbl.rank

	if self.m_occupier and self.m_data then
		local occupier = "#" .. self.m_occupier.kingdom
		if self.m_occupier.abbr and self.m_occupier.abbr ~= "" then
			occupier = occupier .. "(" .. self.m_occupier.abbr .. ")"
		end
		occupier = occupier .. " " .. self.m_occupier.name
		self.ui.m_nowLabel:setString(getLang("138487") .. " " .. occupier)
	end

	self.ui:setTableViewDataSource("m_listTableView", self.m_data)
end

function CrossThroneOccupyRankView:refreshOccupyRank()
	self.beingRequest = true
	self.ctManager:requestOccupyData()
end

function CrossThroneOccupyRankView:onTabButton1Click(  )
	self.ui.m_warLogNode:setVisible(false)
	self.ui.m_explainNode:setVisible(true)
	self.ui.m_tabButton1:setEnabled(false)
	self.ui.m_tabButton2:setEnabled(true)

	--打点
end

function CrossThroneOccupyRankView:onTabButton2Click(  )
	self.ui.m_warLogNode:setVisible(true)
	self.ui.m_explainNode:setVisible(false)
	self.ui.m_tabButton1:setEnabled(true)
	self.ui.m_tabButton2:setEnabled(false)

	--打点
end

return CrossThroneOccupyRankView