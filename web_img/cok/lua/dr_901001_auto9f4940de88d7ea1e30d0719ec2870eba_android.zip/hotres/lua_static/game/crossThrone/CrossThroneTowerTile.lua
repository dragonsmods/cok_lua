CrossThroneTowerTile = class("CrossThroneTowerTile", 
    function()
        return NewBaseTileLuaInfo:call("create")
    end
)

local NotOpen = 0
local OpenNoKing = 1
local PeaceTime = 2
local WarTime = 3
local WarWaiting = 4

function CrossThroneTowerTile.create( index )
    local ret = CrossThroneTowerTile.new()
    if ret:initView(index) == false then
        ret = nil
    end
    return ret
end

function CrossThroneTowerTile:initView( index )
    Dprint("@@ CrossThroneTowerTile:initView".. tostring(index))
    self.cityIndex = index
    self:call("setCityIndex", index)

    if self:call("initTile", true) == false then
        return false
    end

    local cityInfo = self:call("getCityInfo")
    Dprint("cityInfo", cityInfo)
    if nil == cityInfo then
        return false
    end
    self.m_cityInfo = cityInfo

    self.m_luaMap = cityInfo:call("getLuaMap")
    dump(self.m_luaMap, "CrossThroneTowerTile")
    self.dataBack = false
    self:initNodeEvent()
    self:call("addToParent")
    self:refreshView()
    Dprint("CrossThroneTowerTile:initView finish")
    return true
end

function CrossThroneTowerTile:initNodeEvent()
    local function onNodeEvent(event)
        Dprint("@@ onNodeEvent",event)
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(onNodeEvent)
end


function CrossThroneTowerTile:onEnter()
    Dprint("@@ CrossThroneTowerTile:onEnter ")
    registerScriptObserver(self, self.refreshDetail, "GET_WORLD_DETAIL_CMD_BACK")

    Dprint("@@ WorldDetailCommand send",self.m_cityInfo:getProperty("tileServerId"))
    local WorldDetailCommand = Drequire("game.command.WorldDetailCommand")
    local cmd = WorldDetailCommand:create(self.cityIndex, self.m_cityInfo:getProperty("tileServerId"))
    cmd:send()
end

function CrossThroneTowerTile:onExit()
    unregisterScriptObserver(self, "GET_WORLD_DETAIL_CMD_BACK")
end

function CrossThroneTowerTile:refreshDetail(ref)
    local data = dictToLuaTable(ref)
    if ref == nil then
        return
    end
    dump(data,"@@ CrossThroneTowerTile")

    self.data = data
    self:refreshView()
end


function CrossThroneTowerTile:refreshView()

    local playerInfo = GlobalData:call("getPlayerInfo")
    local allianceInfo = playerInfo:getProperty("allianceInfo")


    local function isSelfBuilding(uid, allianceId)
        if playerInfo:call("isInAlliance") then
            return allianceInfo:getProperty("uid") == allianceId
        else
            return playerInfo:getProperty("uid") == uid
        end

        return false
    end

    local selfBuild = self.data and isSelfBuilding(self.data.uid, self.data.allianceId) or false
    local tileServerId = self.m_cityInfo:getProperty("tileServerId")

    local function setCallBack(name, index, func, state)
        local function callback() func(self) end
        self:call("setButtonName", index, name)
        self:call("setButtonState", index, state)
        self:call("setButtonCallback", index, cc.CallFunc:create(callback))
    end

    if WorldController:call("isInSelfServer", tileServerId) then
        local fight_of_king = 0
        local state = WorldController:call("getInstance"):call("getKingActivityStateByType", fight_of_king)
        if state == NotOpen or state == OpenNoKing then
            self:setNotOpenTimeButtons(setCallBack)
        elseif state == PeaceTime then
            self:setPeaceTimeButtons(setCallBack)
        else
            if selfBuild then
                self:setDefenderWarTimeButtons(setCallBack)
            else
                self:setAttackerWarTimeButtons(setCallBack)
            end
        end
    else
        self:setPeaceTimeButtons(setCallBack)
    end
end

function CrossThroneTowerTile:setNotOpenTimeButtons( setCallBack )
    Dprint("setNotOpenTimeButtons")
    self:call("setButtonCount", 1)
    setCallBack(getLang("110076"), 1, self.onInfoClick, TileButtonState.ButtonInformation)
end

function CrossThroneTowerTile:setPeaceTimeButtons( setCallBack )
    Dprint("setPeaceTimeButtons")
    self:call("setButtonCount", 1)
    setCallBack(getLang("110076"), 1, self.onInfoClick, TileButtonState.ButtonInformation)
end

function CrossThroneTowerTile:setAttackerWarTimeButtons( setCallBack )
    Dprint("setAttackerWarTimeButtons")
    local watchTowerEnabel = FunBuildController:call("isExistBuildByTypeLv", 417000, 2)
    local rallyPos = 4
    if watchTowerEnabel then
        self:call("setButtonCount", 4)
        setCallBack(getLang("108722"), 5, self.onClickScout, TileButtonState.ButtonScout)
    else
        self:call("setButtonCount", 3)
        rallyPos = 1
    end
    setCallBack(getLang("110076"), 2, self.onInfoClick, TileButtonState.ButtonInformation)
    setCallBack(getLang("108723"), 3, self.onClickAttack, TileButtonState.ButtonMarch)
    setCallBack(getLang("108726"), rallyPos, self.onClickRally, TileButtonState.ButtonRally)
end

function CrossThroneTowerTile:setDefenderWarTimeButtons( setCallBack )
    Dprint("setDefenderWarTimeButtons")

    self:call("setButtonCount", 4)
    setCallBack(getLang("110076"), 2, self.onInfoClick, TileButtonState.ButtonInformation)
    setCallBack(getLang("108728"), 3, self.onClickSurpport, TileButtonState.ButtonSupport)
    setCallBack(getLang("110067"), 4, self.onClickRally, TileButtonState.ButtonRally)
    setCallBack(getLang("108724"), 5, self.onClickTroop, TileButtonState.ButtonViewTroop)
end

function CrossThroneTowerTile:onInfoClick( ... )
    local detailsView = Drequire("game.crossThrone.CrossThroneTowerDetailsView"):create(self.m_luaMap.buildId, self.cityIndex)
    PopupViewController:addPopupInView(detailsView)
end

function CrossThroneTowerTile:onClickScout( ... )
    SoundController:call("playEffects", Music_Sfx_click_button)

    local warningTips = ToolController:call("getBeforeBattleWarning")
    local function scout() 
        WorldController:call("openScoutView", self.cityIndex) 
        self:closeTile()
    end
    local warningTips = ToolController:call("getBeforeBattleWarning")
    if warningTips ~= "" then
        YesNoDialog:show(warningTips, scout)
    else
        scout()
    end
end

function CrossThroneTowerTile:onClickAttack( ... )
    local function march()
        WorldController:call("openMarchDeploy", self.cityIndex, 1)
        self:closeTile()
    end
    local warningTips = ToolController:call("getBeforeBattleWarning")
    if warningTips ~= "" then
        YesNoDialog:call("show", warningTips, cc.CallFunc:create(march))
    else
        march()
    end
end

function CrossThroneTowerTile:onClickRally( ... )
    local playerInfo = GlobalData:call("getPlayerInfo")
    if playerInfo == nil then
        MyPrint("KingdomMiracleTile:clickAllianceRally playerInfo is nil")
        return
    end

    if not playerInfo:call("isInAlliance") then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("115218"))
        self:closeTile()
        return
    end

    self.cityInfo = WorldController:call("getCityInfoByIndex", self.cityIndex)
    if self.cityInfo == nil then return end

    local function rally()
        AllianceManager:call("openAllianceMassView",self.cityIndex)
        self:closeTile()
    end
    local warningTips = ToolController:call("getBeforeBattleWarning")
    if warningTips ~= "" then
        YesNoDialog:call("show", warningTips, cc.CallFunc:create(rally))
    else
        rally()
    end
end

function CrossThroneTowerTile:onClickSurpport( ... )
    SoundController:call("playEffects", Music_Sfx_click_button)
    YuanJunTipView:call("openYuanYunView", self.cityIndex, self.m_cityInfo:getProperty("luaType"), 0)
    self:closeTile()
end

function CrossThroneTowerTile:onClickTroop( ... )
    SoundController:call("playEffects", Music_Sfx_click_button)
    
    local uuid = ""
    local marchInfo = WorldController:call("getInstance"):getProperty("m_marchInfo")
    for k, v in pairs(marchInfo) do
        if v:getProperty("ownerType") == PlayerType.PlayerSelf and v:getProperty("endPointIndex") == self.cityIndex then
            uuid = v:getProperty("uuid")

            if v:getProperty("teamUid") ~= "" then
                uuid = v:getProperty("teamUid")
            end
        end
    end

    local dict = CCDictionary:create()
    dict:setObject(CCString:create("TroopBuildingDetailView"), "name")
    dict:setObject(CCString:create(uuid), "uuid")
    dict:setObject(CCString:create(tostring(self.cityIndex)), "pointId")
    LuaController:call("openPopViewInLua", dict)

    self:closeTile()
end

function CrossThroneTowerTile:closeTile()
    self = tolua.cast(self, "NewBaseTileLuaInfo")
    self:call("closeThis")
end
