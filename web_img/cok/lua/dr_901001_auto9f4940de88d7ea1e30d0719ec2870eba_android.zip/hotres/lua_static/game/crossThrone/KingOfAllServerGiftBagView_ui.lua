----------------------------
-- Author: Elex
-- Date: 2017-09-14 17:07:29
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local KingOfAllServerGiftBagView_ui = class("KingOfAllServerGiftBagView_ui")

--#ui propertys


--#function
function KingOfAllServerGiftBagView_ui:create(owner, viewType)
	local ret = KingOfAllServerGiftBagView_ui.new()
	CustomUtility:LoadUi("KingOfAllServerGiftBagView.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function KingOfAllServerGiftBagView_ui:initLang()
end

function KingOfAllServerGiftBagView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function KingOfAllServerGiftBagView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function KingOfAllServerGiftBagView_ui:onOkButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onOkButtonClick", pSender, event)
end

return KingOfAllServerGiftBagView_ui

