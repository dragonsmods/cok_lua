----------------------------
-- Author: Elex
-- Date: 2021-10-08 Friday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CrossThroneMainView_ui = class("CrossThroneMainView_ui")

--#ui propertys


--#function
function CrossThroneMainView_ui:create(owner, viewType, paramTable)
	local ret = CrossThroneMainView_ui.new()
	CustomUtility:DoRes(0, true)
	CustomUtility:LoadUi("CrossThroneMainView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CrossThroneMainView_ui:initLang()
	LabelSmoker:setText(self.m_titleTxt, "138316")
	ButtonSmoker:setText(self.m_storeBtn, "52045396")
	ButtonSmoker:setText(self.m_rewardBtn, "52045349")
	ButtonSmoker:setText(self.m_groupBtn, "52045343")
	ButtonSmoker:setText(self.m_applyBtn, "52045400")
	ButtonSmoker:setText(self.m_ticketBtn, "52045350")
	ButtonSmoker:setText(self.m_battleBtn, "52045354")
	ButtonSmoker:setText(self.m_obBtn, "52045355")
	ButtonSmoker:setText(self.m_dispatchBtn, "52045353")
end

function CrossThroneMainView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CrossThroneMainView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CrossThroneMainView_ui:onTipBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onTipBtnClick", pSender, event)
end

function CrossThroneMainView_ui:onClickStore(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickStore", pSender, event)
end

function CrossThroneMainView_ui:onClickReward(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickReward", pSender, event)
end

function CrossThroneMainView_ui:onClickGroup(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickGroup", pSender, event)
end

function CrossThroneMainView_ui:onClickApply(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickApply", pSender, event)
end

function CrossThroneMainView_ui:onClickTicket(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickTicket", pSender, event)
end

function CrossThroneMainView_ui:onClickRank(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickRank", pSender, event)
end

function CrossThroneMainView_ui:onClickBattle(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBattle", pSender, event)
end

function CrossThroneMainView_ui:onClickOB(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickOB", pSender, event)
end

function CrossThroneMainView_ui:onClickDispatch(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickDispatch", pSender, event)
end

return CrossThroneMainView_ui

