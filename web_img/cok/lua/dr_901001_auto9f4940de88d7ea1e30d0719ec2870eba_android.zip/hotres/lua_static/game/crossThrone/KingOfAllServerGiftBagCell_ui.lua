----------------------------
-- Author: Elex
-- Date: 2017-09-04 18:21:45
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local KingOfAllServerGiftBagCell_ui = class("KingOfAllServerGiftBagCell_ui")

--#ui propertys


--#function
function KingOfAllServerGiftBagCell_ui:create(owner, viewType)
	local ret = KingOfAllServerGiftBagCell_ui.new()
	CustomUtility:DoRes(305, true)
	CustomUtility:LoadUi("KingOfAllServerGiftBagCell.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function KingOfAllServerGiftBagCell_ui:initLang()
end

function KingOfAllServerGiftBagCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function KingOfAllServerGiftBagCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return KingOfAllServerGiftBagCell_ui

