----------------------------
-- Author: Elex
-- Date: 2021-08-23 Monday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CrossThroneTicketView_ui = class("CrossThroneTicketView_ui")

--#ui propertys


--#function
function CrossThroneTicketView_ui:create(owner, viewType, paramTable)
	local ret = CrossThroneTicketView_ui.new()
	CustomUtility:DoRes(0, true)
	CustomUtility:LoadUi("CrossThroneTicketView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CrossThroneTicketView_ui:initLang()
	MarqueeSmoker:setText(self.m_titleLbl, "52045338")
	MarqueeSmoker:setText(self.m_pMarquee106, "52045339")
	MarqueeSmoker:setText(self.m_pMarquee108, "52045340")
end

function CrossThroneTicketView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CrossThroneTicketView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CrossThroneTicketView_ui:onClickClose(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickClose", pSender, event)
end

function CrossThroneTicketView_ui:onClickBuy1(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBuy1", pSender, event)
end

function CrossThroneTicketView_ui:onClickBuy2(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBuy2", pSender, event)
end

return CrossThroneTicketView_ui

