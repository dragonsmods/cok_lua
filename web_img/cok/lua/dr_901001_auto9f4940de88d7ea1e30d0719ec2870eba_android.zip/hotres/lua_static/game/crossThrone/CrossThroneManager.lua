------跨服王座战
local CrossThroneManager = class("CrossThroneManager")

--------------------------------command--------------------------------

------请求信息
local CrossThroneInfoCmd = class("CrossThroneInfoCmd", LuaCommandBase)

function CrossThroneInfoCmd:create()
  local ret = CrossThroneInfoCmd.new()
  ret:initWithName("crossthrone.info")
  return ret
end

function CrossThroneInfoCmd:handleReceive( dict )
	Dprint("CrossThroneInfoCmd:handleReceive")
	
	local tbl, params = self:parseMsg(dict, true)
    Dprint("CrossThroneInfoCmd:handleReceive | parse tbl=", tbl)
    if (type(tbl) == "boolean") then
        return tbl
    end
	require("game.crossThrone.CrossThroneManager"):parseCrossThroneData(tbl)
	CCSafeNotificationCenter:postNotification("crossThrone.data")

	return true
end

------进入战场
local CrossThroneEnterCmd = class("CrossThroneEnterCmd", LuaCommandBase)

function CrossThroneEnterCmd:create(battleType)
	local ret = CrossThroneEnterCmd.new()
	ret:initWithName("crossthrone.enter")
	ret:putParam("battleType", CCInteger:create(battleType))
	return ret
end

function CrossThroneEnterCmd:handleReceive( dict )
	Dprint("CrossThroneEnterCmd:handleReceive")

	local tbl, params = self:parseMsg(dict, true)
    if (type(tbl) == "boolean") then
    	if tbl == true then
    		CCSafeNotificationCenter:postNotification("crossThrone.removeWait")
    	end
        return tbl
    end
    if tbl.needWait == "1" or tbl.needWait == "true" then
    	YesNoDialog:show(getLang("138324"))
	  else
		SceneController:call("setChangeSceneType", BattleChangeType.EkWar)
    	GameController:call("crossServerHandler", params, true)
    end
end

------占领排行
local CrossThroneOccupyRankCmd = class("CrossThroneOccupyRankCmd", LuaCommandBase)

function CrossThroneOccupyRankCmd:create()
	local ret = CrossThroneOccupyRankCmd.new()
	ret:initWithName("crossthrone.occupyInfo")
	return ret
end

function CrossThroneOccupyRankCmd:handleReceive(dict)
	Dprint("CrossThroneOccupyRankCmd:handleReceive")

	local tbl, params = self:parseMsg(dict, true)
	Dprint("CrossThroneOccupyRankCmd:handleReceive | parse tbl=", tbl)
	if (type(tbl) == "boolean") then
		return tbl
	end

	CCSafeNotificationCenter:postNotification("crossThrone.occupyRank", params)
end 

------战场排名
local CrossThroneRankCmd = class("CrossThroneRankCmd", LuaCommandBase)

function CrossThroneRankCmd:create()
	local ret = CrossThroneRankCmd.new()
	ret:initWithName("crossthrone.rank")
	return ret
end

function CrossThroneRankCmd:handleReceive(dict)
	Dprint("CrossThroneRankCmd:handleReceive")

	local tbl, params = self:parseMsg(dict, true)
    Dprint("CrossThroneRankCmd:handleReceive | parse tbl=", tbl)
    if (type(tbl) == "boolean") then
        return tbl
    end

    local rankView = Drequire("game.crossThrone.CrossThroneBattleRankView"):create(tbl.rank)
    PopupViewController:addPopupView(rankView)
end

------退出战场
local CrossThroneExitCmd = class("CrossThroneExitCmd", LuaCommandBase)

function CrossThroneExitCmd:create(battleType)
	local ret = CrossThroneExitCmd.new()
	ret:initWithName("crossthrone.exit")
	return ret
end

function CrossThroneExitCmd:handleReceive( dict )
	Dprint("CrossThroneExitCmd:handleReceive")

	local tbl, params = self:parseMsg(dict, true)
    Dprint("CrossThroneExitCmd:handleReceive | parse tbl=", tbl)
    if (type(tbl) == "boolean") then
    	if tbl == true then
    		GameController:call("removeWaitInterface")
    	end
        return tbl
    end

    GameController:call("removeWaitInterface")

	--不保存战场的账号
	SceneController:call("setChangeSceneType", BattleChangeType.OwnServer)
    GameController:call("crossServerHandler", params, false)

end

--请求王座信息
local CrossThronePalaceCmd = class("CrossThronePalaceCmd", LuaCommandBase)

function CrossThronePalaceCmd:create(battleType, serverId)
	local ret = CrossThronePalaceCmd.new()
	ret:initWithName("crossthrone.throneInfo")
	ret:putParam("type", CCInteger:create(battleType))
	ret:putParam("serverId", CCInteger:create(serverId))
	return ret
end

function CrossThronePalaceCmd:handleReceive(dict)
	Dprint("CrossThronePalaceCmd:handleReceive")

	local tbl, params = self:parseMsg(dict, true)
	Dprint("CrossThronePalaceCmd:handleReceive | parse tbl=", tbl)
	if (type(tbl) == "boolean") then
		return tbl
	end

	CCSafeNotificationCenter:postNotification("crossThrone.honor", params)
end

--请求礼包发送信息
local CrossThroneRewardCmd = class("CrossThroneRewardCmd", LuaCommandBase)

function CrossThroneRewardCmd:create(battleType, serverId, uid)
	local ret = CrossThroneRewardCmd.new()
	ret:initWithName("crossthrone.rewardInfo")
	ret:putParam("type", CCInteger:create(battleType))
	ret:putParam("serverId", CCInteger:create(serverId))
	ret:putParam("uid", CCString:create(uid))
	return ret
end

function CrossThroneRewardCmd:handleReceive(dict)
	Dprint("CrossThroneRewardCmd:handleReceive")

	local tbl, params = self:parseMsg(dict, true)
	Dprint("CrossThroneRewardCmd:handleReceive | parse tbl=", tbl)
	if (type(tbl) == "boolean") then
		return tbl
	end
	CCSafeNotificationCenter:postNotification("crossThrone.gift", params)
end

--发送礼包
local CrossThroneRewardGiveCmd = class("CrossThroneRewardGiveCmd", LuaCommandBase)

function CrossThroneRewardGiveCmd:create(battleType, battleServerId, rewardType, rewardId, serverId, name)
	local ret = CrossThroneRewardGiveCmd.new()
	ret:initWithName("crossthrone.giveReward")
	ret:putParam("type", CCInteger:create(battleType))
	ret:putParam("battleServerId", CCInteger:create(battleServerId))
	ret:putParam("rewardType", CCInteger:create(rewardType))
	ret:putParam("serverId", CCInteger:create(serverId))
	ret:putParam("rewardId", CCInteger:create(rewardId))
	ret:putParam("name", CCString:create(name))
	return ret
end

function CrossThroneRewardGiveCmd:handleReceive(dict)
	Dprint("CrossThroneRewardGiveCmd:handleReceive")

	local tbl, params = self:parseMsg(dict, true)
	Dprint("CrossThroneRewardGiveCmd:handleReceive | parse tbl=", tbl)
	if (type(tbl) == "boolean") then
		if tbl == true then
    		CCSafeNotificationCenter:postNotification("crossThrone.removeWait")
    	end
		return tbl
	end

	CCCommonUtilsForLua:call("flyHint", "", "", getLang("138454"))
	CCSafeNotificationCenter:postNotification("crossthrone.sendGift", params)
end

--历任君主
local CrossThroneKingListCmd = class("CrossThroneKingListCmd", LuaCommandBase)

function CrossThroneKingListCmd:create(battleType, serverId)
	local ret = CrossThroneKingListCmd.new()
	ret:initWithName("crossthrone.kingList")
	ret:putParam("type", CCInteger:create(battleType))
	ret:putParam("serverId", CCInteger:create(serverId))
	return ret
end

function CrossThroneKingListCmd:handleReceive(dict)
	Dprint("CrossThroneKingListCmd:handleReceive")

	local tbl, params = self:parseMsg(dict, true)
	Dprint("CrossThroneKingListCmd:handleReceive | parse tbl=", tbl)
	if (type(tbl) == "boolean") then
		return tbl
	end

	CCSafeNotificationCenter:postNotification("crossThrone.kingList", params)
end

--城防数据
local CrossThroneDefenseCmd = class("CrossThroneDefenseCmd", LuaCommandBase)

function CrossThroneDefenseCmd:create()
	local ret = CrossThroneDefenseCmd.new()
	ret:initWithName("crossthrone.defense")
	return ret
end

function CrossThroneDefenseCmd:handleReceive(dict)
	Dprint("CrossThroneDefenseCmd:handleReceive")

	local tbl, params = self:parseMsg(dict, true)
	Dprint("CrossThroneDefenseCmd:handleReceive | parse tbl=", tbl)
	if (type(tbl) == "boolean") then
		return tbl
	end

	CCSafeNotificationCenter:postNotification("crossthrone.defense", params)
end

--战场建筑详情
local CrossThroneBuildCmd = class("CrossThroneBuildCmd", LuaCommandBase)

function CrossThroneBuildCmd:create(serverId, pointId)
	local ret = CrossThroneBuildCmd.new()
	ret:initWithName("crossthrone.buildDetail")
	ret:putParam("serverId", CCString:create(serverId))
	ret:putParam("pointId", CCInteger:create(pointId))
	return ret
end

function CrossThroneBuildCmd:handleReceive(dict)
	Dprint("CrossThroneBuildCmd:handleReceive")

	local tbl, params = self:parseMsg(dict, true)
	Dprint("CrossThroneBuildCmd:handleReceive | parse tbl=", tbl)
	if (type(tbl) == "boolean") then
		return tbl
	end

	CCSafeNotificationCenter:postNotification("crossthrone.buildData", params)
end

--打开关闭战场建筑开关
local CrossThroneObsCmd = class("CrossThroneObsCmd", LuaCommandBase)

function CrossThroneObsCmd:create(serverId, pointId, switch)
	local ret = CrossThroneObsCmd.new()
	ret:initWithName("crossthrone.switch")
	ret:putParam("serverId", CCString:create(serverId))
	ret:putParam("pointId", CCInteger:create(pointId))
	ret:putParam("switch", CCInteger:create(switch))
	return ret
end

function CrossThroneObsCmd:handleReceive(dict)
	Dprint("CrossThroneObsCmd:handleReceive")

	local tbl, params = self:parseMsg(dict, true)
	Dprint("CrossThroneObsCmd:handleReceive | parse tbl=", tbl)
	if (type(tbl) == "boolean") then
		return tbl
	end

end

--获取积分奖励数据
local CrossThroneGetPointRwdDataCmd = class("CrossThroneGetPointRwdDataCmd", LuaCommandBase)

function CrossThroneGetPointRwdDataCmd:create(needDetail)
	local ret = CrossThroneGetPointRwdDataCmd.new()
	ret:initWithName("crossthrone.getPointRewardData")
	ret:putParam("needDetail", CCBool:create(needDetail))
	return ret
end

function CrossThroneGetPointRwdDataCmd:handleReceive(dict)
	Dprint("CrossThroneGetPointRwdDataCmd:handleReceive")

	local tbl, params = self:parseMsg(dict, true)
	Dprint("CrossThroneGetPointRwdDataCmd:handleReceive | parse tbl=", tbl)
	if (type(tbl) == "boolean") then
		return tbl
	end

	require("game.crossThrone.CrossThroneManager"):parseCrossThronePointData(tbl)
	CCSafeNotificationCenter:postNotification("crossthrone.pointData")
end

--领取积分奖励
local CrossThroneGetPointRwdCmd = class("CrossThroneGetPointRwdCmd", LuaCommandBase)

function CrossThroneGetPointRwdCmd:create(pointType, index)
	local ret = CrossThroneGetPointRwdCmd.new()
	ret:initWithName("crossthrone.getPointReward")
	ret:putParam("type", CCInteger:create(atoi(pointType)))
	ret:putParam("index", CCInteger:create(atoi(index)))
	return ret
end

function CrossThroneGetPointRwdCmd:handleReceive(dict)
	Dprint("CrossThroneGetPointRwdCmd:handleReceive")

	local tbl, params = self:parseMsg(dict, true)
	Dprint("CrossThroneGetPointRwdCmd:handleReceive | parse tbl=", tbl)
	if (type(tbl) == "boolean") then
		return tbl
	end


	require("game.crossThrone.CrossThroneManager"):parseCrossThronePointData(tbl)
	CCSafeNotificationCenter:postNotification("crossthrone.pointData")

	if tbl.reward then
		local rwdArr = luaToArray(tbl.reward)
		PortActController:call("flyReward", rwdArr, false)
		local rwdInfo = RewardController:call("retReward", rwdArr)
		CCCommonUtilsForLua:call("flyHint", "", "", rwdInfo)
	end
end
--------------------------------command--------------------------------



DESPOT_BATTLE = 1 --霸主战
EMPIRE_BATTLE = 2 --帝王战

CROSSTHRONE_PAUSE_STATE = 0 --暂停状态
CROSSTHRONE_PEACE_STATE = 1 --和平状态
CROSSTHRONE_READY_STATE = 2 --准备状态
CROSSTHRONE_BATTLE_STATE = 3 --争夺状态

--封赏类型
KINGDOM_TITLE = 1 --国家称号
PERSONLY_TITLE = 2 --个人称号
PERSONLY_GIFT = 3 --个人礼包

DEFAULT_THRONE_INDEX = 302 --王座默认类型

--参加条件类型
CS_SERVER_OPEN_DAY = 0 --服务器开启天数
CS_CITY_LEVEL = 1 --城堡等级
CS_LORD_LEVEL = 2 --领主等级
CS_CIVI_LEVEL = 3 --文明等级

BUILD_POINT_TYPE = 1
KILL_POINT_TYPE = 2

local coordinate = {
	{ x = 0, y = 200},
    { x = 200, y = 100},
    { x = 200, y = -100},
    { x = 0, y = -200},
    { x = -200, y = -100},
    { x = -200, y = 100},
}

function CrossThroneManager:initConfig(dataConfig)
	if self.despotConfig == nil then
		self.despot = {}
		self.despotServer2Config = {}
		self.despotConfig = {} 
		local configData = dictToLuaTable(LocalController:call("DBXMLManager"):call("getGroupByKey", "overlord"))
		if configData then
			for k, v in pairs(configData) do
				local _type = tonumber(v.type)
				self.despotConfig[_type] = {
						name = v.name or "",
						coordinate = v.coordinate or "",
						pic = v.pic or "server_1",
						serverId = v.server_id,
						condition = v.condition,
					}
				self.despotServer2Config[tostring(v.server_id or "1")] = {
					name = v.buff_name,
					desc = v.buff_dec,
					icon = v.buff_icon,
					param = v.buff_num,
					castleName = v.name or "",
					reward_show = v.reward_show or "",
					award_reward = v.award_reward or "",
					award_num = v.award_num or "",
					award_colour = v.award_colour or 0,
					award_dec = v.award_dec or "",
					award_name = v.award_name or "",
					award_icon = v.award_icon or "",
					area = v.game_servers or "", 
					superarmy_item = v.superarmy_item_goods or "",
					superarmy_item_num = v.superarmy_item or "",
				}
			end
		end
	end

    -- Dprint(dataConfig, "dataConfig")
    if dataConfig ~= nil then
        local DespotDataConfig = dataConfig:objectForKey("overlord_open_type")
        if nil ~= DespotDataConfig then
        	DespotDataConfig = tolua.cast(DespotDataConfig, "CCString"):getCString()
        	if nil ~= DespotDataConfig then
        		-- Dprint(DespotDataConfig, "DespotDataConfig")
        		self.enableDespot = splitString(DespotDataConfig, ";") --开启的霸主服务器类型
        	end
        end

        local DespotDataConfig = dataConfig:objectForKey("overlord_random")
        if nil ~= DespotDataConfig then
        	DespotDataConfig = tolua.cast(DespotDataConfig, "CCDictionary")
        	if nil ~= DespotDataConfig then
        		DespotDataConfig = dictToLuaTable(DespotDataConfig)
        		--地图大小
        		self.despot_world_row = tonumber(DespotDataConfig.k1)
        		--战争地带
        		self.despot_battle_row = tonumber(DespotDataConfig.k2)
        		GlobalData:call("shared"):getProperty("worldConfig"):setProperty("despot_world_row", self.despot_world_row)
        	end
        end
    end
end

function CrossThroneManager:obCrossThroneBattle(battleServerId)
	-- body
	if battleServerId == nil then return end
	--GlobalData:call("shared"):setProperty("serverType", ServerType.SERVER_DESPOT)
	--GlobalData:call("shared"):setProperty("obing", true)
	GlobalData:call("shared"):setProperty("crossThroneObTag", true)
	--UIComponent:call("setMainUiState", true)
	--UIComponent:call("OnHomeBackBtnClick")

	--之前加在下面就 可以现在不知道为什么不行了 转换场景之前就把serverId改了吧
	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	playerInfo:setProperty("currentServerId", battleServerId)

	local center = math.floor((self.despot_world_row - 1) / 2)
	local index = center + center * self.despot_world_row + 1
	SceneController:call("gotoScene", SCENE_ID_WORLD, false, true, tonumber(index), MapType.DESPOT_MAP)

	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	playerInfo:setProperty("currentServerId", battleServerId)

	-- local obLabel = UIComponent:call("getInstance"):getProperty("m_labelOB")
	-- local castleName = self:getDespotCastleNameByServerId()
	-- obLabel:call("setString", castleName)
end

--切换服务器数据
function CrossThroneManager:crossThroneHomeBack()
	-- local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	-- local currentServerId = playerInfo:getProperty("currentServerId")

	-- if self:isDespotServerByServerId(currentServerId) then
	-- 	WorldController:call("getInstance"):setProperty("currentMapType", MapType.DESPOT_MAP)
	-- 	WorldController:call("getInstance"):setProperty("_current_tile_count_x", self.despot_world_row)
	-- 	WorldController:call("getInstance"):setProperty("_current_tile_count_y", self.despot_world_row)
	-- 	WorldController:call("getInstance"):setProperty("_current_map_width", self.despot_world_row)
	-- 	WorldController:call("getInstance"):setProperty("_current_map_height", self.despot_world_row)
	-- else
	-- 	WorldController:call("getInstance"):setProperty("currentMapType", MapType.NORMAL_MAP)
	-- 	WorldController:call("getInstance"):setProperty("_current_tile_count_x", _tile_count_x)
	-- 	WorldController:call("getInstance"):setProperty("_current_tile_count_y", _tile_count_y)
	-- 	WorldController:call("getInstance"):setProperty("_current_map_width", _tile_count_x)
	-- 	WorldController:call("getInstance"):setProperty("_current_map_height", _tile_count_y)
	-- end
	--GlobalData:call("shared"):setProperty("serverType", ServerType.SERVER_NORMAL)
	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	local serverId = playerInfo:getProperty("selfServerId")
	playerInfo:setProperty("currentServerId", serverId)
	--GlobalData:call("shared"):setProperty("obing", false)
	GlobalData:call("shared"):setProperty("crossThroneObTag", false)

	local selfPoint = WorldController:call("getInstance"):getProperty("selfPoint")
	local index = selfPoint.x + selfPoint.y * _tile_count_y + 1
	SceneController:call("gotoScene", SCENE_ID_WORLD, false, true, tonumber(index), MapType.NORMAL_MAP)
end

--是否在霸主服
function CrossThroneManager:isDespotServer()
	local serverType = GlobalData:call("shared"):getProperty("serverType")
	local isDespotServer = (serverType == ServerType.SERVER_DESPOT)
	if isDespotServer then
		return true
	else
		local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
		local serverId = playerInfo:getProperty("currentServerId")
		if self.despotServer2Config[tostring(serverId)] then
			return true
		end
	end

	return false
end

--通过serverId判断是不是霸主服
function CrossThroneManager:isDespotServerByServerId(serverId)
	if self.despotServer2Config[tostring(serverId)] then
		return true
	else
		return false
	end
end

--是否处于战争地带
function CrossThroneManager:isInDespotBattleZone()
	-- body
	if self.despot_world_row == nil then return false end
	if self.despot_battle_row == nil then return false end

	local selfPoint = WorldController:call("getInstance"):getProperty("selfPoint")
	local origin = math.floor((self.despot_world_row - self.despot_battle_row) / 2)
	local rect = cc.rect(origin, origin, self.despot_battle_row - 1, self.despot_battle_row - 1)
	return cc.rectContainsPoint(rect, selfPoint)
end

--是否在第王服
function CrossThroneManager:isEmpireServer()
	local serverType = GlobalData:call("shared"):getProperty("serverType")
	return serverType == ServerType.SERVER_EMPIRE 
end

--获取当前霸主服务器宫殿名字
function CrossThroneManager:getDespotCastleNameByServerId()
	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	local serverId = playerInfo:getProperty("currentServerId")
	return getLang(self.despotServer2Config[tostring(serverId)] and self.despotServer2Config[tostring(serverId)].castleName or "")
end

--获取所在区域
function CrossThroneManager:getMyDespotArea()
	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	local serverId = playerInfo:getProperty("selfServerId")

	--在战场
	if self.despotServer2Config[tostring(serverId)] then
		return self.despotServer2Config[tostring(serverId)].area
	end
	--不在战场
	for k, v in pairs(self.despotServer2Config) do
		local tbl = splitString(v.area, ";")
		for i = 1, #tbl do
			local areaStr = tbl[i]
			local areaVec = splitString(areaStr, "-")
			if #areaVec == 1 then
				if tonumber(areaVec[1]) == serverId then
					return v.area
				end
			elseif #areaVec == 2 then
				local begin = tonumber(areaVec[1])
				local endTo = tonumber(areaVec[2])
				if begin <= serverId and serverId <= endTo then
					return v.area
				end
			end
		end
	end
end

--获取霸主服务器霸主奖励
function CrossThroneManager:getDespotPropertyByKey(key)
	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	local serverId = playerInfo:getProperty("currentServerId")
	return self.despotServer2Config[tostring(serverId)] and self.despotServer2Config[tostring(serverId)][key] or ""
end

--获取当前霸主服务器增益数据
function CrossThroneManager:getDespotBuffData()
	-- local serverId = CCUserDefault:sharedUserDefault():getStringForKey("server_id", "")
	-- Dprint("serverId", serverId)
	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	local serverId = playerInfo:getProperty("currentServerId")
	local buffData = {}

	local buff = self.despotServer2Config[tostring(serverId)]
	if buff then
		local nameVec = splitString(buff.name, "|")
		local descVec = splitString(buff.desc, "|")
		local iconVec = splitString(buff.icon, "|")
		local paramVec = splitString(buff.param, "|")

		for i = 1, #nameVec do
			buffData[i] = {
				name = nameVec[i] or "123",
				desc = descVec[i] or "123",
				icon = iconVec[i] or "",
				param = paramVec[i],
			}
		end
	end

	return buffData
end

--获取霸主服数量
function CrossThroneManager:getDespotNum()
	return self.despotConfig and sizen(self.despotConfig) or 0
end

--获取用户所在霸主区域ID
function CrossThroneManager:getDespotId()
	return self.despotId or 0
end

--是否是用户所在霸主区域
function CrossThroneManager:isUserDespot(despotId)
	return self.despotId == despotId
end

function CrossThroneManager:getDespotBattleServerId(despotId)
	if self.despotId and self.despotId ~= 0 then
		return self.despot[despotId].serverId
	end
end

--是否用户所在霸主区域
function CrossThroneManager:isDespotCanEnter(despotId)
	if self.despot then
		if self:isDespotReady(despotId) or self:isDespotBattle(despotId) then
			return self:isUserDespot(despotId)
		end
	end

	return false
end

--霸主服激活状态
function CrossThroneManager:isDespotEnable(despotId)
	--test
	local ret = false
	
	for k, v in ipairs(self.enableDespot or {} ) do
		if v == tostring(despotId) then
			ret = true
			break
		end
	end

	return ret
end

--请求跨服王座战总数据
function CrossThroneManager:requestCrossThroneData()
	local reqCmd = CrossThroneInfoCmd:create()
	reqCmd:send()
end

--请求王座占领数据
function CrossThroneManager:requestOccupyData()
	local reqCmd = CrossThroneOccupyRankCmd:create()
	reqCmd:send()
end

--请求战场排名数据
function CrossThroneManager:requestBattleRankData()
	local reqCmd = CrossThroneRankCmd:create()
	reqCmd:send()
end

--请求宫殿数据
function CrossThroneManager:requestHororData(battleType, serverId)
	local reqCmd = CrossThronePalaceCmd:create(battleType, serverId)
	reqCmd:send()
end

--请求礼包发送信息
function CrossThroneManager:requestGiftData(battleType, serverId, uid)
	local reqCmd = CrossThroneRewardCmd:create(battleType, serverId, uid)
	reqCmd:send()
end

--发送礼包
function CrossThroneManager:giveGift2Someone(battleType, battleServerId, rewardType, rewardId, serverId, name)
	local giveCmd = CrossThroneRewardGiveCmd:create(battleType, battleServerId, rewardType, rewardId, serverId, name)
	giveCmd:send()
end

--请求历代霸主/帝王
function CrossThroneManager:requestKingListData(battleType, serverId)
	local reqCmd = CrossThroneKingListCmd:create(battleType, serverId)
	reqCmd:send()
end

--请求城防数据
function CrossThroneManager:requestDefenseData()
	local reqCmd = CrossThroneDefenseCmd:create()
	reqCmd:send()
end

--请求建筑数据
function CrossThroneManager:reqBuildData(serverId, pointId)
	local reqCmd = CrossThroneBuildCmd:create(serverId, pointId)
	reqCmd:send()
end

--打开关闭建筑开关
function CrossThroneManager:operateBuildSwitch(serverId, pointId, switch)
	local reqCmd = CrossThroneObsCmd:create(serverId, pointId, switch)
	reqCmd:send()
end

--积分奖励数据
function CrossThroneManager:getPointRwdData()
	local needDetail = true
	if self.build_reward_list and self.kill_reward_list then needDetail = false end

	local reqCmd = CrossThroneGetPointRwdDataCmd:create(needDetail)
	reqCmd:send()
end

--领取积分奖励
function CrossThroneManager:getPointRwd(pointType, index)
	local reqCmd = CrossThroneGetPointRwdCmd:create(pointType, index)
	reqCmd:send()
end

--解析积分数据
function CrossThroneManager:parseCrossThronePointData(data)
	if data.buildScore then
		self.buildScore = atoi(data.buildScore)
	end

	if data.killScore then
		self.killScore = atoi(data.killScore)
	end

	if data.build_reward_state then
		self.build_reward_state = data.build_reward_state
	end

	if data.kill_reward_state then
		self.kill_reward_state = data.kill_reward_state
	end

	if data.build_score_list then
		self.build_score_list = data.build_score_list
	end

	if data.kill_score_list then
		self.kill_score_list = data.kill_score_list
	end

	if data.build_reward_list then
		self.build_reward_list = data.build_reward_list
	end

	if data.kill_reward_list then
		self.kill_reward_list = data.kill_reward_list
	end
end

function CrossThroneManager:getPointData(pointType)
	if pointType == BUILD_POINT_TYPE then
		return self.buildScore, self.build_score_list
	else
		return self.killScore, self.kill_score_list
	end
end

function CrossThroneManager:getPointRewardData(pointType)
	if pointType == BUILD_POINT_TYPE then
		return self.build_reward_list, self.build_reward_state
	else
		return self.kill_reward_list, self.kill_reward_state
	end
end

function CrossThroneManager:parseCrossThroneData(data)
	--玩家所在霸主区域
	self.despotId = tonumber(data.myDespotId) or 0
	--霸主区域入场ID
	self.despotItemId = tonumber(data.myDespotItemId) or 0
	self.despot = {}

	if data.despot then
		for k, v in ipairs(data.despot) do
			local despotId = tonumber(v.despotId)
			self.despot[despotId] = {
				despotId = tonumber(v.despotId),
				serverId = tonumber(v.serverId),
				--despotState = tonumber(v.despotState) or CROSSTHRONE_PAUSE_STATE,
				despotStartTime = tonumber(v.despotStartTime) or 0,
				despotReadyTime = tonumber(v.despotReadyTime) or 0,
				despotEndTime = tonumber(v.despotEndTime) or 0,

				lastDespotId = v.lastDespotId or "",
				lastDespotName = v.lastDespotName or "",
				pic = v.pic or "",
				picVer = tonumber(v.picVer) or 0,

				kingdom = v.kingdom or "",
				abbr = v.abbr or "",
			}
		end
	end
	
	
	if data.empire then
		--self.empireState = tonumber(data.empire.empireState) or CROSSTHRONE_PAUSE_STATE
		self.empireStartTime = tonumber(data.empire.empireStartTime) or 0
		self.empireReadyTime = tonumber(data.empire.empireReadyTime) or 0
		self.empireEndTime = tonumber(data.empire.empireEndTime) or 0
		self.empireItemId = tonumber(data.empire.empireItemId) or 0

		self.lastEmpireId = data.empire.lastEmpireId or ""
		self.lastEmpireName = data.empire.lastEmpireName or ""
		self.lastEmpirePic = data.empire.pic or ""
		self.lastEmpirePivVer = tonumber(data.empire.picVer) or 0
		self.lastEmpireKingdom = data.empire.kingdom or ""
		self.lastEmpireAbbr = data.empire.abbr or ""
	end
end

--进入跨服战场
function CrossThroneManager:enterCrossThrone(battleType)
	local serverType = GlobalData:call("shared"):getProperty("serverType")
	local totalDead = ArmyController:call("getTotalDead")
	local queueNum = QueueController:call("getQueueNumByType", QueueType.TYPE_HOSPITAL)
	if ( (serverType ~= ServerType.SERVER_DRAGON_BATTLE or serverType ~= ServerType.SERVER_DRAGON_BATTLE_GLOBAL) and (totalDead > 0 or queueNum > 0)) then
		local function callback() self:healSoldier() end
		local callfunc = cc.CallFunc:create(callback)
		--E100293=请先治疗伤兵，再进入跨服战场
		local diaglog = YesNoDialog:call("show", getLang("E100293"), callfunc)
		diaglog:call("setYesButtonTitle", getLang("138113"))
		CCSafeNotificationCenter:postNotification("crossThrone.removeWait")
		return		
	end

	local enterCmd = CrossThroneEnterCmd:create(battleType)
	enterCmd:send()
end

--修复伤兵
function CrossThroneManager:healSoldier()
	local buildId = FunBuildController:call("getMaxLvBuildByType", FUN_BUILD_HOSPITAL)
	if buildId <= 0 then return end

	if QueueController:call("getQueueNumByType", QueueType.TYPE_HOSPITAL) > 0 then
		local buildType = math.floor(buildId / 1000)
		local qid = 0
		local qType = CCCommonUtilsForLua:call("getQueueTypeByBuildType", buildType)
		if qType ~= -1 then
			qid = QueueController:call("getMinTimeQidByType", qType)
		end

		local qInfos = GlobalData:call("shared"):getProperty("allQueuesInfo")
		local qInfo = qInfos[qid]
		if qInfo then
			local lastTime = qInfo:getProperty("finishTime") - qInfo:getProperty("startTime")
			local costGold = CCCommonUtilsForLua:call("getGoldByTime", lastTime)

			if PopupViewController:call("getCanPopPushView") then
				local function callback() self:onCostGoldBack(qid, costGold) end
				local callfunc = cc.CallFunc:create(callback)
				--138481=伤兵正在治疗中，无法进入跨服战场，是否花费金币立即治疗这些伤兵？
				YesNoDialog:call("showTime", getLang("138481"), callfunc, lastTime, getLang("104903"), false)
			else
				if costGold > 0 then
					local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
					local gold = playerInfo:getProperty("gold")
					if gold < costGold then
						YesNoDialog:call("gotoPayTips")
						return
					end
				end
				
				QueueController:call("startCCDQueue", qid, "", false, costGold "", 1)
			end

			return
		end
	else
		local buildInfo = FunBuildController:call("getFunbuildForLua", buildId)
		PopupViewController:call("removeAllPopupView")

		local dict = CCDictionary:create()
		dict:setObject(buildInfo, "buildInfo")
		dict:setObject(CCString:create("BuildingHospitalPopUpView"), "name")
		LuaController:call("openPopViewInLua", dict) 
	end	
end

function CrossThroneManager:onCostGoldBack(qid, costGold)
	if costGold > 0 then
		local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
		local gold = playerInfo:getProperty("gold")
		if gold < costGold then
			YesNoDialog:call("gotoPayTips")
			return
		end
	end

	QueueController:call("startCCDQueue", qid, "", false, costGold, "", 1)
end

--退出跨服战场
function CrossThroneManager:exitCrossThrone()
	GameController:call("showWaitInterface")
	local exitCmd = CrossThroneExitCmd:create()
	exitCmd:send()
end

--霸主战场进入道具
function CrossThroneManager:getDespotItemId()
	return self.despotItemId or 0
end

--霸主服务器图片
function CrossThroneManager:getDespotCastlePic(despotId)
	local pic = ""
	if self.despotConfig[despotId] then
		pic =  self.despotConfig[despotId].pic
	end

	return pic == "" and "server_1.png" or (pic .. ".png")
 end

 --霸主服务器进入条件
function CrossThroneManager:getDespotCondition(despotId)
	local condition = getLang("138459") .. "\n"
	if self.despotConfig[despotId] then
		local conditionStr = self.despotConfig[despotId].condition
		local cver = splitString(conditionStr, "|")
		for index, value in ipairs(cver) do
			local c = splitString(value, ";")
			local vec = splitString(c[2], "-")
			local dialog = ""
			if tonumber(c[1]) == CS_SERVER_OPEN_DAY then
				dialog = "138455"
			elseif tonumber(c[1]) == CS_CITY_LEVEL then
				dialog = "138456"
				vec[1] = (atoi(vec[1]) > 30) and (getLang("160001") .. " " .. (atoi(vec[1]) - 30)) or vec[1]
				vec[2] = (atoi(vec[2]) > 30) and (getLang("160001") .. " " .. (atoi(vec[2]) - 30)) or vec[2]
			elseif tonumber(c[1]) == CS_LORD_LEVEL then
				dialog = "138457"
			elseif tonumber(c[1]) == CS_CIVI_LEVEL then
				dialog = "138458"
				vec[1] = CivilizationController:getCivPrestigeNameByLevel(atoi(vec[1]))
				vec[2] = CivilizationController:getCivPrestigeNameByLevel(atoi(vec[2]))
			end
			condition = condition .. getLang(dialog, vec[1], vec[2]) .. "\n"
		end
	end

	return condition
end

--是否满足进入条件
function CrossThroneManager:isConditionReach(despotId)
	if self.despotConfig[despotId] then
		local condition = self.despotConfig[despotId].condition
		local cver = splitString(condition, "|")
		for index, value in ipairs(cver) do
			local c = splitString(value, ";")
			local vec = splitString(c[2], "-")
			if tonumber(c[1]) == CS_SERVER_OPEN_DAY then
				local now = GlobalData:call("getTimeStamp")
				local gap = now - GlobalData:call("shared"):getProperty("serverOpenTime")
				gap = gap / SEC_OF_DAY 
				if gap < atoi(vec[1]) or gap > atoi(vec[2]) then 
					return false 
				end
			elseif tonumber(c[1]) == CS_CITY_LEVEL then
				local mainCityLv = FunBuildController:call("getMainCityLv") + FunBuildController:call("getMainCityHonorLv")
				if mainCityLv < atoi(vec[1]) or mainCityLv > atoi(vec[2]) then
					return false
				end
			elseif tonumber(c[1]) == CS_LORD_LEVEL then
				local lordLevel = GlobalData:call("getPlayerInfo"):getProperty("level")
				if lordLevel < atoi(vec[1]) or lordLevel > atoi(vec[2]) then
					return false
				end
			elseif tonumber(c[1]) == CS_CIVI_LEVEL then
				local civiLevel = CivilizationController:getCurCivilizationPrestigeLevel()
				if civiLevel < atoi(vec[1]) or civiLevel > atoi(vec[2]) then
					return false
				end
			end
		end
	end

	return true
end

 --霸主服务器名字
 function CrossThroneManager:getDespotCastleName(despotId)
 	local name = ""
	if self.despotConfig[despotId] then
		name =  self.despotConfig[despotId].name
	end

	return name == "" and getLang("138312") or getLang(name)
 end

--霸主服务器坐标
function CrossThroneManager:getDespotCoordinate(despotId)
	if self.despotConfig[despotId] then
		 local cstr = self.despotConfig[despotId].coordinate or ""
		 local t = splitString(cstr, ";")
		 if #t == 2 then
		 	return t[1], t[2]
		 end
	end

	return coordinate[despotId].x,  coordinate[despotId].y
end

--霸主uid
function CrossThroneManager:getDespotUid(despotId)
	if self.despot[despotId] then
		return self.despot[despotId].lastDespotId
	end

	return ""
end

function CrossThroneManager:getDespotPic(despotId)
	if self.despot[despotId] then
		return self.despot[despotId].pic
	end

	return ""
end

function CrossThroneManager:getDespotPicVer(despotId)
	if self.despot[despotId] then
		return self.despot[despotId].picVer
	end

	return 0
end

--霸主名字
function CrossThroneManager:getDespotName(despotId)
	if self.despot[despotId] then
		 local ret = ""
		 local despot = self.despot[despotId]
		 if despot.kingdom ~= "" then
		 	ret = ret .. "#" .. despot.kingdom
		 end

		 if despot.abbr ~= "" then
		 	ret = ret .. "(" .. despot.abbr .. ")"
		 end

		 ret = ret .. despot.lastDespotName

		 return ret
	end

	return ""
end

--霸主王座是和平状态
function CrossThroneManager:isDespotPeace(despotId)
	if self.despot[despotId] then
		local now = LuaController:call("getTimeStamp")
		local startTime = self.despot[despotId].despotStartTime or 0
		local endTime = self.despot[despotId].despotEndTime or 0
		return now < startTime or now > endTime
	end

	return false
end

--霸主王座是准备状态
function CrossThroneManager:isDespotReady(despotId)
	if self.despot[despotId] then
		local now = LuaController:call("getTimeStamp")
		local startTime = self.despot[despotId].despotStartTime or 0
		local readyEndTime = self.despot[despotId].despotReadyTime or 0
		return now >= startTime and now <= readyEndTime
	end

	return false
end

--霸王王座是争夺状态
function CrossThroneManager:isDespotBattle(despotId)
	if self.despot[despotId] then
		local now = LuaController:call("getTimeStamp")
		local readyEndTime = self.despot[despotId].despotReadyTime or 0
		local endTime = self.despot[despotId].despotEndTime or 0
		return now > readyEndTime and now < endTime
	end

	return false
end

--霸主状态图片
function CrossThroneManager:getDespotStatePic(despotId)
	if self:isDespotPeace(despotId) then
		return "allianceHelpAll.png"
	elseif self:isDespotReady(despotId) then
		return "al_order_icon.png"
	elseif self:isDespotBattle(despotId) then
		return "allianceWar.png"
	else
		return "allianceHelpAll.png"
	end
end

--霸主状态文本
function CrossThroneManager:getDespotStateText(despotId)
	if self:isDespotPeace(despotId) then
		return getLang("138309"), cc.c3b(0, 100, 0)
	elseif self:isDespotReady(despotId) then
		return getLang("138310"), cc.c3b(247, 238, 214)
	elseif self:isDespotBattle(despotId) then
		return getLang("138311"), cc.c3b(251, 0, 0)
	else
		return "", cc.c3b(255, 251, 240)
	end
end

--霸主状态时间
function CrossThroneManager:getDespotStateTime(despotId)
	local now = LuaController:call("getTimeStamp")
	if self:isDespotPeace(despotId) then
		local remain = self.despot[despotId].despotStartTime - now
		local hour = ActivityController:call("getInstance"):getProperty("despotBattleHour")
		if remain < hour * 3600 then
			return getLang("138342", format_time(remain)), cc.c3b(0, 100, 0)
		else
			return ""
		end
	elseif self:isDespotReady(despotId) then
		local remain = self.despot[despotId].despotReadyTime - now
		if remain > 0 then
			return getLang("138321", format_time(remain)), cc.c3b(247, 238, 214)
		end
	elseif self:isDespotBattle(despotId) then
		local remain = self.despot[despotId].despotEndTime - now
		if remain > 0 then
			return getLang("138322", format_time(remain)), cc.c3b(251, 0, 0)
		end
	end
end

--帝王uid
function CrossThroneManager:getEmpireUid()
	return self.lastEmpireId or ""
end

--帝王名字
function CrossThroneManager:getEmpireName()
	local ret = ""
	if self.lastEmpireKingdom ~= "" then
		ret = ret .. "#" .. self.lastEmpireKingdom
	end

	if self.lastEmpireAbbr ~= "" then
		ret = ret .. "(" .. self.lastEmpireAbbr .. ")"
	end

	ret = ret .. self.lastEmpireName

	return ret
end

function CrossThroneManager:getEmpirePic()
	return self.lastEmpirePic or ""
end

function CrossThroneManager:getEmpirePicVer()
	return self.lastEmpirePivVer or 0
end

--帝王战场进入道具
function CrossThroneManager:getEmpireItemId()
	return self.empireItemId or 0
end

--帝王王座是和平状态
function CrossThroneManager:isEmpirePeace()
	local now = LuaController:call("getTimeStamp")
	local startTime = self.empireStartTime or 0
 	local endTime = self.empireEndTime or 0

	return now < startTime or now > endTime
end

--帝王王座是准备状态
function CrossThroneManager:isEmpireReady()
	local now = LuaController:call("getTimeStamp")
	local startTime = self.empireStartTime or 0
	local readyEndTime = self.empireReadyTime or 0

	return now >= startTime and now <= readyEndTime
end

--帝王王座是争夺状态
function CrossThroneManager:isEmpireBattle()
	local now = LuaController:call("getTimeStamp")
	local readyEndTime = self.empireReadyTime or 0
	local endTime = self.empireEndTime or 0

	return now > readyEndTime and now < endTime
end

--获取帝王王座图片
function CrossThroneManager:getEmpireCastlePic(picId)
	
end

--帝王状态图片
function CrossThroneManager:getEmpireStatePic()
	if self:isEmpirePeace() then
		return "allianceHelpAll.png"
	elseif self:isEmpireReady() then
		return "al_order_icon.png"
	elseif self:isEmpireBattle() then
		return "allianceWar.png"
	else
		return ""
	end
end

--帝王状态文本
function CrossThroneManager:getEmpireStatleText()
	if self:isEmpirePeace() then
		return getLang("138309"), cc.c3b(0, 100, 0)
	elseif self:isEmpireReady() then
		return getLang("138310"), cc.c3b(247, 238, 214) 
	elseif self:isEmpireBattle() then
		return getLang("138311"), cc.c3b(251, 0, 0)
	else
		return "", cc.c3b(255, 251, 240)
	end
end

--获取王座战类型图标
function CrossThroneManager:getThroneTypePic(battleType)
	if (battleType == DESPOT_BATTLE) then
		return "despot_crown.png"
	elseif (battleType == EMPIRE_BATTLE) then
		return "empire_crown.png" 
	else
		return ""
	end
end

--使用新保护罩
function CrossThroneManager:useCrossThroneProtect()
	local despot_guard_switch = CCCommonUtilsForLua:isFunOpenByKey("overlord_guard")
	local empire_guard_switch = CCCommonUtilsForLua:isFunOpenByKey("monarch_guard")
	local isDespotServer = self:isDespotServer()
	local isEmpireServer = self:isEmpireServer()
	local itemType = 0
	if isDespotServer then
		itemType = 49
	elseif isEmpireServer then
		itemType = 50
	end
	return (despot_guard_switch and isDespotServer) or (empire_guard_switch and isEmpireServer), itemType
end

--跨服王座操作
function CrossThroneManager:operation(dict)
	local operation = dict:valueForKey("operation"):getCString()
	local ret = nil
	if operation == "homeback" then
		self:crossThroneHomeBack()
	elseif operation == "inDespotServer" then
		ret = self:isDespotServer()
	elseif operation == "inEmpireServer" then
		ret = self:isEmpireServer()
	elseif operation == "checkTeleport" then
		local targetX = dict:valueForKey("targetX"):intValue()
		local targetY = dict:valueForKey("targetY"):intValue()
		ret = self:checkTeleport(targetX, targetY)
	elseif operation == "getSupplyRallyItem" then
		ret = self:getSupplyRallyItem()
	end

	if ret then
		dict:setObject(CCString:create(tostring(ret)), "ret")
	end
end

--休战地区迁往非休战地区破掉保护罩
function CrossThroneManager:checkTeleport(targetX, targetY)
	if self:isDespotServer() then
		if self:isInDespotBattleZone() then
			return false
		else
			if self.despot_world_row == nil then return false end
			if self.despot_battle_row == nil then return false end

			local origin = math.floor((self.despot_world_row - self.despot_battle_row) / 2)
			local rect = cc.rect(origin, origin, self.despot_battle_row - 1, self.despot_battle_row - 1)
			Dprint("despot_world_row, despot_battle_row, targetX, targetY, origin", self.despot_world_row, self.despot_battle_row, targetX, targetY, origin)
			return cc.rectContainsPoint(rect, ccp(targetX, targetY))
		end
	end

	return false
end

--获取超级集结所需道具信息
function CrossThroneManager:getSupplyRallyItem()
	local superRallyCnt = WorldController:call("getInstance"):getProperty("superRallyCnt")
	local superTotalCnt = WorldController:call("getInstance"):getProperty("superTotalCnt")
	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	local serverId = playerInfo:getProperty("currentServerId")
	if self.despotServer2Config[tostring(serverId)] then
		local itemId = self.despotServer2Config[tostring(serverId)].superarmy_item
		local info = self.despotServer2Config[tostring(serverId)].superarmy_item_num
		local unit = splitString(info, "|")
		local tbl = {}

		for _, value in ipairs(unit) do
			local vec = splitString(value, ";")
			local t = splitString(vec[1], "-")
			if #t > 1 then
				for i = atoi(t[1]), atoi(t[2]), 1 do
					tbl[tostring(i)] = vec[2]
				end
			else
				tbl[tostring(vec[1])] = vec[2]
			end
		end

		if (superRallyCnt >= superTotalCnt) then
			return itemId .. ";" .. tbl[tostring(superRallyCnt)]
		else
			return itemId .. ";" .. tbl[tostring(superRallyCnt + 1)]
		end
	end

	return "-1;0"
end

function CrossThroneManager:purge()
	self.despotConfig  = nil
	self.buildScore = nil
	self.killScore = nil
	self.build_score_list = nil
	self.kill_score_list = nil
	self.build_reward_list = nil
	self.kill_reward_list = nil
end

return CrossThroneManager
