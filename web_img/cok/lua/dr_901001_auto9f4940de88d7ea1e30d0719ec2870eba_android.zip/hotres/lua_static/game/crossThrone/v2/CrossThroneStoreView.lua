local CrossThroneStoreView = class("CrossThroneStoreView", Drequire("game.Battlefield.room.PubgStoreView"))

function CrossThroneStoreView:getStoreParams()
    return 
        {
            mallId = 128,
            itemId = 36009061,
            descrip = "52045397",
            notifyKey = "CSStore_BuyConfirm",
        }
end

function CrossThroneStoreView:onEnter()
    UIComponent:call("showPopupView", 0)
    self:setTitleName(getLang("52045396"))
end

return CrossThroneStoreView