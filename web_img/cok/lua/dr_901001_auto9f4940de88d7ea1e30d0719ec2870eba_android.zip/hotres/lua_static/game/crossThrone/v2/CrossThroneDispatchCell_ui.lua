----------------------------
-- Author: Elex
-- Date: 2021-08-17 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CrossThroneDispatchCell_ui = class("CrossThroneDispatchCell_ui")

--#ui propertys


--#function
function CrossThroneDispatchCell_ui:create(owner, viewType, paramTable)
	local ret = CrossThroneDispatchCell_ui.new()
	CustomUtility:LoadUi("CrossThroneDispatchCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CrossThroneDispatchCell_ui:initLang()
	MarqueeSmoker:setText(self.m_pMarquee6, "52045323")
	MarqueeSmoker:setText(self.m_pMarquee8, "52045323")
end

function CrossThroneDispatchCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CrossThroneDispatchCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return CrossThroneDispatchCell_ui

