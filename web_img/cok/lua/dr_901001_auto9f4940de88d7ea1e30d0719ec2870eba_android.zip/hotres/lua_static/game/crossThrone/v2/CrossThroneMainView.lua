local CrossThroneMainView = class("CrossThroneMainView", PopupBaseView)

function CrossThroneMainView:ctor()
    Drequire("game.crossThrone.v2.CrossThroneMainView_ui"):create(self, 1)
    self.ctMgr = require("game.crossThrone.CrossThroneManager")
    self.hasRefresh = false
    self:initView()
end

function CrossThroneMainView:initView()

end

function CrossThroneMainView:updatePerSec(dt)
    self.despotId = self.ctMgr:getDespotId()
    
    self.ui.m_normalNode:setVisible(false)
    self.ui.m_dspNode:setVisible(false)

    local time, color = self.ctMgr:getDespotStateTime(self.despotId) 
	self.ui.m_descText:setString(time)
    -- self.ui.m_descText:setColor(color)

    local hasApplyed = self.ctMgr:hasApplyed()

    if self.ctMgr:isDespotFinish(self.despotId) and self.hasRefresh == false then
        self.hasRefresh = true
        self.ctMgr:requestCrossThroneData()
    end

    if self.ctMgr:isDespotCanEnter(self.despotId) then
        self.ui.m_normalNode:setVisible(true)
        self.ui.m_dspNode:setVisible(false)
        self.ui.m_battleBtn:setEnabled(hasApplyed)
        self.ui.m_obBtn:setEnabled(true)
    -- elseif self.ctMgr:isCanDispatch() then
    --     self.ui.m_normalNode:setVisible(false)
    --     self.ui.m_dspNode:setVisible(true)
    --     self.ui.m_dispatchBtn:setEnabled(self.ctMgr.canDispatch)
    end

    if hasApplyed then
        --52045406=你的联盟已报名“{0}“\n该组需要{1}张门票参战，请按时参加！
        local applyId = self.ctMgr:getApplyId()
        local name = self.ctMgr:getDespotName(applyId)
        local tickets = self.ctMgr:getNeedTickets(applyId)
        self.ui.m_applyText:setString(getLang("52045406", getLang(name), tickets))
    else
        self.ui.m_applyText:setString("")
    end

    if self.ctMgr.prepareParseRwd then self.ctMgr:parseRwd() end
end

function CrossThroneMainView:onEnter()
    self:updatePerSec(1)
    self.entry = self:getScheduler():scheduleScriptFunc(function(dt) self:updatePerSec(dt) end, 1, false)
end

function CrossThroneMainView:onExit()
    self:getScheduler():unscheduleScriptEntry(self.entry)
end

function CrossThroneMainView:onClickRule()
    local view = Drequire("game.FestivalActivities.FestivalActivitiesExplainView"):create(getLang("52045348"))
    PopupViewController:addPopupView(view)
end

function CrossThroneMainView:onClickReward()
    if self.ctMgr.allRankReward then
        local view = Drequire("game.crossThrone.v2.CrossThroneRewardView").new()
        PopupViewController:addPopupInView(view)
    end
end

function CrossThroneMainView:onClickGroup()
    local view = Drequire("game.crossThrone.v2.CrossThroneGroupView").new()
    PopupViewController:addPopupInView(view) 
end

function CrossThroneMainView:onClickApply()
    if self.ctMgr:hasApplyed() then
        local tipText = self.ui.m_applyText:getString()
        CCCommonUtilsForLua:call("flyHint", "", "", tipText)
        return
    end

    if self.ctMgr:isDespotCanEnter(self.despotId) then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("52045412"))
        return
    end

    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
    local allianceInfo = playerInfo:getProperty("allianceInfo")
    local rank = allianceInfo:getProperty("rank")
    if rank < 5 then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("52045405"))
        return
    end

    local view = Drequire("game.crossThrone.v2.CrossThroneApplyView").new()
    PopupViewController:addPopupView(view)
end

function CrossThroneMainView:onClickTicket()
    if self.ctMgr:getDespotItemId() > 0 then
        local view = Drequire("game.crossThrone.v2.CrossThroneTicketView").new()
        PopupViewController:addPopupView(view) 
    end
end

function CrossThroneMainView:onClickBattle()
    if not PlayerInfoController:isInAlliance() then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("137448"))
        return
    end

    local reach, condition = self.ctMgr:isConditionReach(self.despotId)
    if not reach then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("52045374", unpack(condition)))
        return
    end 
    
    local tipQueue = {}
    table.insert(tipQueue, getLang("52045379"))

    if self.ctMgr:isDespotBattleTip(self.despotId) then
        table.insert(tipQueue, getLang("52045393"))
    end
        
    local tipCount = 0
    local function confirm()
        tipCount = tipCount + 1

        if tipQueue[tipCount] then
            YesNoDialog:call("showYesNoFun", tipQueue[tipCount], cc.CallFunc:create(confirm), getLang("confirm"), nil, getLang("cancel_btn_label"))
        else
            self.waitInterface = GameController:call("showWaitInterface1", self.ui.m_battleBtn)
            self.ctMgr:enterCrossThrone(DESPOT_BATTLE)
        end
    end
    
    if self.ctMgr.needTicket then
        local itemId = self.ctMgr:getDespotItemId()
        local tInfo = ToolController:call("getToolInfoForLua", itemId)
        local count = tInfo and tInfo:call("getCNT") or 0
        local needNum = self.ctMgr:getNeedTickets(self.despotId)
        if count < needNum then
            self:onClickTicket()
        else
            confirm()
        end
    else
        confirm()
    end
end

function CrossThroneMainView:onClickOB()
    local reach, condition = self.ctMgr:isConditionReach(self.despotId, true)
    if not reach then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("52045374", unpack(condition)))
        return
    end
    
    local view = Drequire("game.crossThrone.v2.CrossThroneOBSelectView").new()
    PopupViewController:addPopupView(view)
end

function CrossThroneMainView:onClickRank()
    -- if not self.ctMgr:hasApplyed() then
    --     CCCommonUtilsForLua:call("flyHint", "", "", getLang("52045422"))
    --     return 
    -- end

    -- if not PlayerInfoController:isInAlliance() then
    --     CCCommonUtilsForLua:call("flyHint", "", "", getLang("52045414"))
    --     return 
    -- end

    -- local view = Drequire("game.crossThrone.v2.CrossThroneRankView").new()
    -- PopupViewController:addPopupView(view)
    local view = Drequire("game.crossThrone.v2.CrossThroneGroupRankView").new()
    PopupViewController:addPopupView(view)
end

function CrossThroneMainView:onClickDispatch()
    local view = Drequire("game.crossThrone.v2.CrossThroneDispatchView").new()
    PopupViewController:addPopupInView(view)
end

function CrossThroneMainView:onClickStore()
    local view = Drequire("game.crossThrone.v2.CrossThroneStoreView").new()
    PopupViewController:addPopupInView(view)
end

function CrossThroneMainView:onTipBtnClick()
    FaqHelper:call("showSingleFAQ", "45279")
end

return CrossThroneMainView