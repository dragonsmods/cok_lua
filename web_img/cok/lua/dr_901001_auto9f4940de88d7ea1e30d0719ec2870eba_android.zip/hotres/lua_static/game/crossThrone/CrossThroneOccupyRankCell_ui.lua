----------------------------
-- Author: Elex
-- Date: 2017-11-29 21:45:54
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CrossThroneOccupyRankCell_ui = class("CrossThroneOccupyRankCell_ui")

--#ui propertys


--#function
function CrossThroneOccupyRankCell_ui:create(owner, viewType)
	local ret = CrossThroneOccupyRankCell_ui.new()
	CustomUtility:DoRes(7, true)
	CustomUtility:LoadUi("CrossThroneOccupyRankCell.ccbi", ret, owner, true, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CrossThroneOccupyRankCell_ui:initLang()
end

function CrossThroneOccupyRankCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CrossThroneOccupyRankCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return CrossThroneOccupyRankCell_ui

