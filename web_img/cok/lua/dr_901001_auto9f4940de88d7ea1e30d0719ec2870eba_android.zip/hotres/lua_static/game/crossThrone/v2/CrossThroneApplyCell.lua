local CrossThroneApplyCell = class("CrossThroneApplyCell", cc.TableViewCell)

function CrossThroneApplyCell:create()
    local cell = CrossThroneApplyCell.new()
    Drequire("game.crossThrone.v2.CrossThroneApplyCell_ui"):create(cell, 0)
    cell.ui.m_btn1:setSwallowsTouches(false)
    cell.ui.m_btn2:setSwallowsTouches(false)
    return cell
end

function CrossThroneApplyCell:refreshCell(info, idx)
    self.info = info

    self.ui.m_btn2:setVisible(false)

    if info[1] then
        CCCommonUtilsForLua:setButtonTitle(self.ui.m_btn1, getLang(info[1].name))
    end

    if info[2] then
        self.ui.m_btn2:setVisible(true)
        CCCommonUtilsForLua:setButtonTitle(self.ui.m_btn2, getLang(info[2].name))
    end
end

function CrossThroneApplyCell:onClickBtn1()
    self.info[1].cb(self.info[1].despotId, self.ui.m_btn1)
end

function CrossThroneApplyCell:onClickBtn2()
    self.info[2].cb(self.info[2].despotId, self.ui.m_btn2)
end

return CrossThroneApplyCell