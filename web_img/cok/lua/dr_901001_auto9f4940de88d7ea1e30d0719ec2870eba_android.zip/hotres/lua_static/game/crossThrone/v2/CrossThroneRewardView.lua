local CrossThroneRewardView = class("CrossThroneRewardView", PopupBaseView)

function CrossThroneRewardView:ctor()
    Drequire("game.crossThrone.v2.CrossThroneRewardView_ui"):create(self, 1)
    self.ctMgr = require("game.crossThrone.CrossThroneManager")
    self.btnIndex = 1
    self:initView()
end

function CrossThroneRewardView:initView()
    local funKey = string.join("", "onClickBtn", self.btnIndex)
    self[funKey](self)

    for index, data in ipairs(self.ctMgr.despot) do
        if index < 4 then
            local btnKey = string.join("", "m_btn", index)
            CCCommonUtilsForLua:setButtonTitle(self.ui[btnKey], getLang(data.name))
        end
    end
end

function CrossThroneRewardView:showTab(index)
    self.btnIndex = index

    local showData = {}
    self.sourceData = self.ctMgr.allRankReward[index] or {}
    
    local function refresh() self:showTab(index) end

    local tOpen = false
    for _, data in ipairs(self.sourceData) do
        if data._type == 1 then
            tOpen = data.open
            data.cb = refresh
            table.insert(showData, data)
        end

        if data._type ~= 1 and tOpen then
            table.insert(showData, data)
        end
    end

    local oldOffset = self.ui.m_listView:getContentOffset()
    local oldContent = self.ui.m_listView:getContentSize()

    self.ui:setTableViewDataSource("m_listView", showData)
    
    local newContent = self.ui.m_listView:getContentSize()
    local newOffset = ccp(oldOffset.x, oldOffset.y - (newContent.height - oldContent.height))
    local maxOffset = self.ui.m_listView:maxContainerOffset()
    local minOffset = self.ui.m_listView:minContainerOffset()
    if newOffset.y > maxOffset.y then newOffset.y = maxOffset.y end
    if newOffset.y < minOffset.y then newOffset.y = minOffset.y end
    self.ui.m_listView:setContentOffset(newOffset)
    self.ui.m_highZorder:setLocalZOrder(168)

    self:refreshBtn()
end

function CrossThroneRewardView:refreshBtn()
    self.ui.m_btn1:setEnabled(self.btnIndex ~= 1)
    self.ui.m_btn2:setEnabled(self.btnIndex ~= 2)
    self.ui.m_btn3:setEnabled(self.btnIndex ~= 3)
end

function CrossThroneRewardView:onClickBtn1()
    self:showTab(1)
end

function CrossThroneRewardView:onClickBtn2()
    self:showTab(2)
end

function CrossThroneRewardView:onClickBtn3()
    self:showTab(3)
end

return CrossThroneRewardView