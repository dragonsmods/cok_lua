--[[ 
    霸主战结算界面
 ]]
local CrossThroneResultView = class("CrossThroneResultView", PopupBaseView)

function CrossThroneResultView.create(data)
    CCLoadSprite:call("loadDynamicResourceByName", "crossThrone_entry")
    local view = CrossThroneResultView.new()
	Drequire("game.crossThrone.v2.CrossThroneResultView_ui"):create(view, 0)
	if view:initView(data) == false then
		return nil
	end
    return view
end

function CrossThroneResultView:initView(data)
    registerTouchHandler(self)
    self.canTouch = false
    self.data = data
    local rootPath = CCFileUtils:sharedFileUtils():getWritablePath() .. "dresource/"
	local jsonFile = string.join("", rootPath, "overlord_settlement_tx.json")
	local atlasFile = string.join("", rootPath, "sk_overlord_settlement_tx.atlas")

    if cc.FileUtils:getInstance():isFileExist(jsonFile) or cc.FileUtils:getInstance():isFileExist(atlasFile) then
        local animationObj = IFSkeletonAnimation:call("create", jsonFile, atlasFile)
        if animationObj then
            animationObj:setToSetupPose()
            animationObj:setAnimation(0, "ani_1", false)
            animationObj:setPosition(0, 0)

            local function callback(event)
                animationObj:setAnimation(0, "ani_2_loop", true)
                self.canTouch = true
            end
            animationObj:registerSpineEventHandler(callback, spEventType.SP_ANIMATION_COMPLETE)
            self.ui.m_nodeAnim:addChild(animationObj)
        end

        if data.winAid then
            for i, v in ipairs(data.rank or {}) do
                if data.winAid == v.allianceId then
                    self.ui.m_labelLord:setString(getLang("52045484", v.name))      --52045484=领主:{0}
                    self.ui.m_labelAlliance:setString(getLang("52045485", v.abbr))  --52045485=联盟:{0}
                    self.ui.m_labelServer:setString(getLang("52045486", v.kingdom)) --52045486=王国:{0}
                    break
                end
            end
        end

        self.ui.m_nodeText:setVisible(false)
        self.ui.m_nodeText:runAction(
            cc.Sequence:create(
                cc.DelayTime:create(0.5),
                cc.Show:create()
            ))

        return true
    end
    return false
end

function CrossThroneResultView:onEnter()
    CCCommonUtilsForLua:call("setHardExitEnabled" , false)
end

function CrossThroneResultView:onExit()
    CCCommonUtilsForLua:call("setHardExitEnabled", true)
end

function CrossThroneResultView:onTouchBegan(x, y)
    return self.canTouch
end

function CrossThroneResultView:onTouchMoved(x, y)
end

function CrossThroneResultView:onTouchEnded(x, y)
    local view = Drequire("game.crossThrone.v2.CrossThroneRankView").new(true, self.data)
    PopupViewController:addPopupView(view)

    PopupViewController:call("removePopupView", self)
end

return CrossThroneResultView