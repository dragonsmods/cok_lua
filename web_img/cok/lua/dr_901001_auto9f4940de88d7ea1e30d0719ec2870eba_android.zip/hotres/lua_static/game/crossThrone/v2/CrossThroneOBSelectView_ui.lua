----------------------------
-- Author: Elex
-- Date: 2021-08-19 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CrossThroneOBSelectView_ui = class("CrossThroneOBSelectView_ui")

--#ui propertys


--#function
function CrossThroneOBSelectView_ui:create(owner, viewType, paramTable)
	local ret = CrossThroneOBSelectView_ui.new()
	CustomUtility:DoRes(0, true)
	CustomUtility:LoadUi("CrossThroneOBSelectView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function CrossThroneOBSelectView_ui:initLang()
	LabelSmoker:setText(self.m_pLabelTTF109, "52045321")
	MarqueeSmoker:setText(self.m_titleLbl, "52045320")
end

function CrossThroneOBSelectView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CrossThroneOBSelectView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CrossThroneOBSelectView_ui:onClickClose(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickClose", pSender, event)
end

function CrossThroneOBSelectView_ui:initTableView()
	TableViewSmoker:createView(self, "m_listView", "game.crossThrone.v2.CrossThroneOBSelectCell", 1, 3, "CrossThroneOBSelectCell")
end

function CrossThroneOBSelectView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return CrossThroneOBSelectView_ui

