local CrossThronePopupView = class("CrossThronePopupView",
	function()
		return PopupBaseView:create()
	end)

function CrossThronePopupView:create(battleType, despotId)
	local view = CrossThronePopupView.new()
	Drequire("game.crossThrone.KingOfAllServerPopupView_ui"):create(view, 1)
	if view:initView(battleType, despotId) then
		return view
	end
end

function CrossThronePopupView:initView(battleType, despotId)
	if self:init(true, 0) == false then
		return false
	end
		
	self.ctManager = require("game.crossThrone.CrossThroneManager") 

	self.battleType = battleType or DESPOT_BATTLE
	self.despotId = despotId or 0
	self.battleServerId = self.ctManager:getDespotBattleServerId(despotId)
	self.needTicket = true

	if CCCommonUtilsForLua:isFunOpenByKey("overlord_ticket_off") and self.battleType == DESPOT_BATTLE then
		self.needTicket = false
	end

	self:setHDPanelFlag(true)
	--self:call("setModelLayerDisplay", false)

	if CCCommonUtilsForLua:isIosAndroidPad() then
		self:setScale(2)
	end

	self:refreshView()

	local touchLayer = cc.Layer:create()
	self:addChild(touchLayer)

	local function touchHandle( eventType, x, y )
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		
		else
			self:onTouchEnded(x, y)
		end
	end
	touchLayer:registerScriptTouchHandler(touchHandle)
	touchLayer:setTouchEnabled(true)
	touchLayer:setSwallowsTouches(false)

	return true
end

function CrossThronePopupView:onEnter()
	local function callback1() self:refreshView() end
	local handler1 = self:registerHandler(callback1)
	CCSafeNotificationCenter:call("registerScriptObserver", self, handler1, "crossThrone.data")

	local function callback2() self:removeWaitInterface() end
	local handler2 = self:registerHandler(callback2)
	CCSafeNotificationCenter:call("registerScriptObserver", self, handler2, "crossThrone.removeWait")
end

function CrossThronePopupView:onExit()
	CCSafeNotificationCenter:call("unregisterScriptObserver", self, "crossThrone.data")
	CCSafeNotificationCenter:call("unregisterScriptObserver", self, "crossThrone.removeWait")
end

function CrossThronePopupView:removeWaitInterface()
	if self.waitInterface then
		self.waitInterface:call("remove")
		self.waitInterface = nil
	end
end

function CrossThronePopupView:refreshView()
	self.ui.m_cityNode:removeAllChildren()
	self.ui.m_stateNode:removeAllChildren()
	self.ui.m_headNode:removeAllChildren()
	self.ui.m_picNode:removeAllChildren()
	
	if self.battleType == DESPOT_BATTLE then
		local despotCastleName = self.ctManager:getDespotCastleName(self.despotId)
		self.ui.m_cityNameLabel:setString(despotCastleName)
		self.ui.m_titleLabel:setString(getLang("138316"))

		local pic =  self.ctManager:getDespotCastlePic(self.despotId)
		local castle = CCLoadSprite:call("createSprite", pic)
		self.ui.m_cityNode:addChild(castle)
		CCCommonUtilsForLua:setSpriteMaxSize(castle, 200, true)

		local canEnter = self.ctManager:isDespotCanEnter(self.despotId)
		local extraConditionReach = self.ctManager:isConditionReach(self.despotId)
		self.ui.m_goButton:setEnabled(canEnter and extraConditionReach)

		local statePic = self.ctManager:getDespotStatePic(self.despotId)
		local stateIcon = CCLoadSprite:call("createSprite", statePic, CCLoadSpriteType.CCLoadSpriteType_GOODS)
		self.ui.m_stateNode:addChild(stateIcon)
		CCCommonUtilsForLua:setSpriteMaxSize(stateIcon, 80, true)

		local stateText, stateColor = self.ctManager:getDespotStateText(self.despotId)
		self.ui.m_stateLabel:setString(stateText)
		self.ui.m_stateLabel:setColor(stateColor)

		local itemId = self.ctManager:getDespotItemId()
		CCCommonUtilsForLua:call("createGoodsIcon", tonumber(itemId), self.ui.m_itemNode, CCSizeMake(30, 30))

		self.ui.m_haveNode:setVisible(true)

		local uid = self.ctManager:getDespotUid(self.despotId)
		local pic = self.ctManager:getDespotPic(self.despotId)
		local picVer = self.ctManager:getDespotPicVer(self.despotId)
		self:showDespotInfo(uid, pic, picVer)
	else

	end

	local typePic = self.ctManager:getThroneTypePic(self.battleType)
	local icon = CCLoadSprite:call("createSprite", typePic, CCLoadSpriteType.CCLoadSpriteType_GOODS)
	self.ui.m_picNode:addChild(icon)
	self.ui.m_picNode:setScale(0.8)
	CCCommonUtilsForLua:setSpriteMaxSize(castle, 50, true)
	CCCommonUtilsForLua:setButtonTitle(self.ui.m_lookButton, getLang("138314"))	

	self.ui.m_goLabel:setString(getLang("138315"))
	if self.needTicket then
		self.ui.m_itemNumLabel:setString("x 1")
	else
		self.ui.m_itemNode:setVisible(false)
		self.ui.m_goLabel:setPositionY(0)
	end
end

function CrossThronePopupView:showDespotInfo(uid, pic, picVer)
	--头像
	if (pic == "") then
		pic = "despot_empty.png"
	else
		pic = pic .. ".png"
	end
	--CCLoadSprite:call("loadDynamicResourceByName", "HeadIcon")
	local icon = CCLoadSprite:call("createSprite", pic, CCLoadSpriteType.CCLoadSpriteType_HEAD_ICON)
	CCCommonUtilsForLua:setSpriteMaxSize(icon, 57, true)
	self.ui.m_headNode:addChild(icon)
	if (CCCommonUtilsForLua:call("isUseCustomPic", picVer)) then
		local headImgNode = HFHeadImgNode:call("create")

		local picUrl = CCCommonUtilsForLua:call("getCustomPicUrl", uid, picVer)
		headImgNode:call("initHeadImgUrl2", self.ui.m_headNode, picUrl, 1.0, 57, true)
	end

	local despotName = self.ctManager:getDespotName(self.despotId)
	if despotName == "" then despotName = getLang("138329") end
	self.ui.m_nameLabel:setString(despotName)
end

function CrossThronePopupView:onTouchBegan(x, y)
	self.touchPoint = ccp(x, y)
	return true
end

function CrossThronePopupView:onTouchEnded(x, y)
	if ccpDistance(self.touchPoint, ccp(x, y)) > 20 then
		return
	end

	if isTouchInside(self.ui.m_goButton, x, y) and (self.ctManager:isUserDespot(self.despotId) == false) then
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("E100276"))
	end

	if not isTouchInside(self.ui.m_touchNode, x, y) then
		PopupViewController:call("removePopupView", self)
	end
end

function CrossThronePopupView:onGoButtonClick()
	local itemId = self.ctManager:getDespotItemId()
	local toolInfo = ToolController:call("getToolInfoByIdForLua", itemId)
	local cnt = toolInfo:call("getCNT")
	if cnt <= 0  and self.needTicket then
		local function confirm()
			local ItemGetMethodView = Drequire("game.CommonPopup.ItemGetMethodView")
			local view = ItemGetMethodView:create(itemId)
			PopupViewController:addPopupView(view)
		end
		local itemName = toolInfo:call("getName")
		YesNoDialog:show(getLang("E100275", itemName), confirm)
	else
		self.waitInterface = GameController:call("showWaitInterface1", self.ui.m_goButton)
		--打点

		self.ctManager:enterCrossThrone(self.battleType)
	end
end

function CrossThronePopupView:onHelpBtnClick()
	Dprint("CrossThronePopupView:onHelpBtnClick")
	local condition = ""
	if self.battleType == DESPOT_BATTLE then
		condition = self.ctManager:getDespotCondition(self.despotId)
	else

	end

	YesNoDialog:call("show", condition)
end

function CrossThronePopupView:onLookButtonClick()
	local canOb = false
	if self.battleType == DESPOT_BATTLE then
		canOb = CCCommonUtilsForLua:isFunOpenByKey("overlord_OB")
	else
		canOb = CCCommonUtilsForLua:isFunOpenByKey("monarch_OB")
	end

	if canOb then
		--打点

		if self.battleServerId ~= nil then
			self.ctManager:obCrossThroneBattle(self.battleServerId)
		else
			CCCommonUtilsForLua:call("flyHint", "", "", getLang("9442075"))
		end
	else
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("102192"))
	end
end

return CrossThronePopupView