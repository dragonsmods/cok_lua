local CrossThroneDispatchView = class("CrossThroneDispatchView", PopupBaseView)

function CrossThroneDispatchView:ctor()
    Drequire("game.crossThrone.v2.CrossThroneDispatchView_ui"):create(self, 1)
    self.ctMgr = require("game.crossThrone.CrossThroneManager")
    self.dispatchMap = {}
    self:initView()
end

function CrossThroneDispatchView:initView()
    self.ctMgr:reqDpList()
    -- self:refreshView()
    self.ui.m_dispatchBtn:setEnabled(false)
    self.ui.m_listView._notMoveWhenAllShow = true
end

function CrossThroneDispatchView:refreshView(params)
    local data = dictToLuaTable(params)
    -- dump(data, "refreshView")
    self.total = atoi(data.total)
    self.min = atoi(data.min)
    self.sourceData = data.players or {}

    self.showData = {}
    local function callback(uid, num)
        return self:dispatch(uid, num)
    end

    local t = {}
    for _, player in ipairs(self.sourceData) do
        player.dispatch = self.min
        player.dpCb = callback

        self.dispatchMap[player.uid] = self.min
        
        table.insert(t, player)
        if table.getn(t) == 2 then
            table.insert(self.showData, t) 
            t = {}
        end
    end

    if table.getn(t) > 0 then
        table.insert(self.showData, t) 
    end
    self:refreshRemain()
    self.ui:setTableViewDataSource("m_listView", self.showData)
end

function CrossThroneDispatchView:dispatch(uid, num)
    local remain = self.remain + atoi(self.dispatchMap[uid])
    
    if num > remain then num = remain end
    if num < self.min then
        num = self.min 
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("52045371", self.min))
    end
    
    self.dispatchMap[uid] = num
    self:refreshRemain()

    return num
end

function CrossThroneDispatchView:refreshRemain()
    local dpCount = 0
    for _, num in pairs(self.dispatchMap) do
        dpCount = dpCount + num                                                   
    end

    self.remain = self.total - dpCount
    self.ui.m_remainText:setString(getLang("52045326", CC_CMDITOA(self.remain)))
    self.ui.m_dispatchBtn:setEnabled(self.total == dpCount and self.total > 0)
end

function CrossThroneDispatchView:onEnter()
    registerScriptObserver(self, self.refreshView, "msg.crossthrone.dispatchList")
end

function CrossThroneDispatchView:onExit()
    unregisterScriptObserver(self, "msg.crossthrone.dispatchList")
end

function CrossThroneDispatchView:onClickDispatch()
    local function confirm()
        local dispatch = {}
        for uid, num in pairs(self.dispatchMap) do
            table.insert(dispatch, string.join(";", uid, num))
        end
        self.ctMgr:dispatch(table.concat(dispatch, "|"))
        PopupViewController:call("goBackPopupView")
    end

    YesNoDialog:call("showYesNoFun", getLang("52045328"), cc.CallFunc:create(confirm), getLang("confirm"), nil, getLang("cancel_btn_label"))
end

return CrossThroneDispatchView
