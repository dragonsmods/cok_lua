----------------------------
-- Author: Elex
-- Date: 2021-12-06 Monday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CrossThroneGroupTabCell_ui = class("CrossThroneGroupTabCell_ui")

--#ui propertys


--#function
function CrossThroneGroupTabCell_ui:create(owner, viewType, paramTable)
	local ret = CrossThroneGroupTabCell_ui.new()
	CustomUtility:LoadUi("CrossThroneGroupTabCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CrossThroneGroupTabCell_ui:initLang()
	ButtonSmoker:setText(self.m_tabBtn, "52045330")
end

function CrossThroneGroupTabCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CrossThroneGroupTabCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CrossThroneGroupTabCell_ui:onClickTab(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickTab", pSender, event)
end

return CrossThroneGroupTabCell_ui

