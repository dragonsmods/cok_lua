----------------------------
-- Author: Elex
-- Date: 2018-11-01 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local KingOfAllServerRewardCell1_ui = class("KingOfAllServerRewardCell1_ui")

--#ui propertys


--#function
function KingOfAllServerRewardCell1_ui:create(owner, viewType, paramTable)
	local ret = KingOfAllServerRewardCell1_ui.new()
	CustomUtility:LoadUi("KingOfAllServerRewardCell1.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function KingOfAllServerRewardCell1_ui:initLang()
end

function KingOfAllServerRewardCell1_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function KingOfAllServerRewardCell1_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function KingOfAllServerRewardCell1_ui:onBtnAddClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBtnAddClick", pSender, event)
end

function KingOfAllServerRewardCell1_ui:onShowBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onShowBtnClick", pSender, event)
end

function KingOfAllServerRewardCell1_ui:initTableView()
	TableViewSmoker:createView(self, "m_scrollView", "game.crossThrone.CrossThronePointCell", 0, 6, "KingOfAllServerPointCell")
end

function KingOfAllServerRewardCell1_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return KingOfAllServerRewardCell1_ui

