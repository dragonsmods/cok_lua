local CrossThroneRankCell = class("CrossThroneRankCell", cc.TableViewCell)

function CrossThroneRankCell:create()
    local cell = CrossThroneRankCell.new()
    Drequire("game.crossThrone.v2.CrossThroneRankCell_ui"):create(cell, 0)
    return cell
end

function CrossThroneRankCell:refreshCell(info, idx)
    self.info = info
    self.ui.m_nameLabel:setString(info.showName)

    local rank = idx + 1
    if rank > 3 then
        self.ui.m_numSprite:setVisible(false)
        self.ui.m_numLabel:setVisible(true)
        self.ui.m_numLabel:setString(tostring(rank))
    else
        self.ui.m_numSprite:setVisible(true)
        self.ui.m_numLabel:setVisible(false)

        local path = string.format("Alliance_Ranking%d.png", rank + 1)
        local sf = CCLoadSprite:call("loadResource", path)
        if sf then self.ui.m_numSprite:setSpriteFrame(sf) end
    end

    self:updatePerSec()
end

function CrossThroneRankCell:updatePerSec()
    if self.info.personly then
        self.ui.m_timeLabel:setString(CC_CMDITOA(atoi(self.info.score)))
    else
        self.ui.m_timeLabel:setString(format_time(atoi(self.info.occupyTime)))
    end
end

return CrossThroneRankCell