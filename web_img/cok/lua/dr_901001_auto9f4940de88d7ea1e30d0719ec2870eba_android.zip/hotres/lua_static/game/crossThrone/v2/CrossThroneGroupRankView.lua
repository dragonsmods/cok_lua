local CrossThroneGroupRankView = class("CrossThroneGroupRankView", Drequire("game.crossThrone.v2.CrossThroneRankView"))

function CrossThroneGroupRankView:ctor()
    self.super.ctor(self, false, nil, "game.crossThrone.v2.CrossThroneGroupRankView_ui")
    self:initTab()
end

function CrossThroneGroupRankView:initTab()
    local function refresh(despotId) return self.despotId == despotId end
    local function callback(despotId, btn) self:changeTab(despotId) end 
    for index, unit in ipairs(self.ctMgr.despot or {}) do
        unit.tabCb = callback
        unit.selectCb = refresh
        if index == 1 then self.despotId = unit.despotId end
    end

    self.ui:setTableViewDataSource("m_tabView", self.ctMgr.despot)

    self:changeTab(self.despotId)
end

function CrossThroneGroupRankView:reqRankData()
    if self.despotId and self.despotId > 0 then
        self.ctMgr:reqNewRank(self.despotId)
    end
end

function CrossThroneGroupRankView:refreshView(param)
    local cInt = tolua.cast(param, "CCInteger")
    local despotId = cInt and cInt:getValue() or 0

    if despotId == 0 then return end
    
    self.despotId = despotId
    self.finalData = self.ctMgr:getNewRank(despotId)
    if self.finalData then self.super.refreshView(self) end
end

function CrossThroneGroupRankView:onEnter()
    registerScriptObserver(self, self.refreshView, "msg.crossthrone.rank")
end

function CrossThroneGroupRankView:onExit()
    self.ctMgr:clearRankData()
    unregisterScriptObserver(self, "msg.crossthrone.rank")
end

function CrossThroneGroupRankView:changeTab(despotId)
    self.despotId = despotId

    self.finalData = self.ctMgr:getNewRank(despotId)
    if self.finalData then 
        self.super.refreshView(self)
    else    
        self:reqRankData()
    end 

    CCSafeNotificationCenter:postNotification("msg.crossthrone.tab", CCInteger:create(self.despotId))
end

return CrossThroneGroupRankView