----------------------------
-- Author: Elex
-- Date: 2018-07-09 Monday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CrossServerListView_ui = class("CrossServerListView_ui")

--#ui propertys


--#function
function CrossServerListView_ui:create(owner, viewType, paramTable)
	local ret = CrossServerListView_ui.new()
	CustomUtility:LoadUi("CrossServerListView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CrossServerListView_ui:initLang()
end

function CrossServerListView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CrossServerListView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return CrossServerListView_ui

