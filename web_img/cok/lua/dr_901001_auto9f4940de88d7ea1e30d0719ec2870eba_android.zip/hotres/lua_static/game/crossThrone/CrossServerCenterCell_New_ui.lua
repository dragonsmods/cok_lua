----------------------------
-- Author: Elex
-- Date: 2019-11-19 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CrossServerCenterCell_New_ui = class("CrossServerCenterCell_New_ui")

--#ui propertys


--#function
function CrossServerCenterCell_New_ui:create(owner, viewType, paramTable)
	local ret = CrossServerCenterCell_New_ui.new()
	CustomUtility:DoRes(11, true)
	CustomUtility:LoadUi("CrossServerCenterCell_New.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CrossServerCenterCell_New_ui:initLang()
end

function CrossServerCenterCell_New_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CrossServerCenterCell_New_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CrossServerCenterCell_New_ui:onHelpButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onHelpButtonClick", pSender, event)
end

function CrossServerCenterCell_New_ui:onMoreClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onMoreClick", pSender, event)
end

return CrossServerCenterCell_New_ui

