local CrossThroneKingListView = class("CrossThroneKingListView",
	function()
		return PopupBaseView:create()
	end
)

local CrossThroneKingListCell = class("CrossThroneKingListCell",
	function()
		return cc.Layer:create()
	end
)

function CrossThroneKingListView:create(dialogId, kingData)
	local view = CrossThroneKingListView.new()
	Drequire("game.crossThrone.KingOfAllServerHistoryView_ui"):create(view, 0)
	if view:initView(dialogId, kingData) then
		return view
	end
end    

function CrossThroneKingListView:initView(dialogId, kingData)
	if self:init(true, 0) == false then
		return false
	end

	self:setHDPanelFlag(true)
	self.dialogId = dialogId

	self.ui.m_headNode:removeAllChildren()
	self.ui.m_kingNode:removeAllChildren()
	self.ui.m_listNode:removeAllChildren()

	if kingData.uid ~= "" then
		if (kingData.pic == "") then
			kingData.pic = "g044.png"
		else
			kingData.pic = kingData.pic .. ".png"
		end

		local icon = CCLoadSprite:call("createSprite", kingData.pic, CCLoadSpriteType.CCLoadSpriteType_HEAD_ICON)
		CCCommonUtilsForLua:setSpriteMaxSize(icon, 67, true)
		self.ui.m_headNode:addChild(icon)

		if (CCCommonUtilsForLua:call("isUseCustomPic", kingData.picVer)) then
			local headImgNode = HFHeadImgNode:call("create")

			local picUrl = CCCommonUtilsForLua:call("getCustomPicUrl", kingData.uid, kingData.picVer)
			headImgNode:call("initHeadImgUrl2", self.ui.m_headNode, picUrl, 1.0, 67, true)
		end
	else
		local icon = CCLoadSprite:call("createSprite", "despot_empty.png", CCLoadSpriteType.CCLoadSpriteType_HEAD_ICON)
		CCCommonUtilsForLua:setSpriteMaxSize(icon, 67, true)
		self.ui.m_headNode:addChild(icon)
	end

	self.ipadLike = CCCommonUtilsForLua:isIosAndroidPad()
	if self.ipadLike then
		self.ui.m_topNode:setScale(2.4)
		self.ui.m_bellowNode:setScale(2.4)
	end

	self.ctManager = require("game.crossThrone.CrossThroneManager")
	if self.ctManager:isDespotServer() then
		self.battleType = DESPOT_BATTLE
		self.ui.m_historyLabel:setString(getLang("138381"))
		self.ui.m_detailLabel:setString(getLang("138382"))

		if kingData.name ~= "" then
			self.ui.m_nameLabel2:setString(getLang("138312") .. " " .. kingData.name)
		else
			--self.ui.m_headNode:setVisible(false)
			self.ui.m_nameLabel2:setString(getLang("138329"))
		end
	else
		self.battleType = EMPIRE_BATTLE
		self.ui.m_historyLabel:setString(getLang("138380"))
		self.ui.m_detailLabel:setString(getLang("138368"))
	end

	local typePic = self.ctManager:getThroneTypePic(self.battleType)
	local icon = CCLoadSprite:call("createSprite", typePic, CCLoadSpriteType.CCLoadSpriteType_GOODS)
	self.ui.m_kingNode:addChild(icon)
	self.ui.m_kingNode:setScale(0.8)

	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	self.serverId = playerInfo:getProperty("currentServerId")
	
	self.ctManager:requestKingListData(self.battleType, self.serverId)
	self.m_data = {}

	self.ui.m_nameLabel1:setString(getLang("170009"))
	self.ui.m_timeLabel:setString(getLang("138338"))
	self.ui.m_detaLabel:setString(getLang("138369"))

	self.ui.m_listNode:removeAllChildren()
	local addHeight = self:getExtendHeight()
	local oldSize = self.ui.m_listNode:getContentSize()
	self.ui.m_listNode:removeAllChildren()
	self.ui.m_listNode:setContentSize(cc.size(oldSize.width, oldSize.height + addHeight))
	Dprint("oldSize", oldSize.width, oldSize.height, addHeight)

	local listSize = self.ui.m_listNode:getContentSize()
	self.m_tableView = cc.TableView:create(listSize)
	self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
	self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
	self.m_tableView:setDelegate()
	self.m_tableView:registerScriptHandler(function(tab, idx) return self:cellSizeForTable(tab, idx) end, cc.TABLECELL_SIZE_FOR_INDEX)
	self.m_tableView:registerScriptHandler(function(tab, idx) return self:tableCellAtIndex(tab, idx) end, cc.TABLECELL_SIZE_AT_INDEX)
	self.m_tableView:registerScriptHandler(function(tab) return self:numberOfCellsInTableView(tab) end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
	self.ui.m_listNode:addChild(self.m_tableView)

	self:addLoadingAni()

	local tip = (self.battleType == DESPOT_BATTLE and "138471" or "138472")
	self.tipLabel = cc.Label:createWithSystemFont(getLang(tip), "Helvetica", 30)
	self.ui.m_listNode:addChild(self.tipLabel)
	self.tipLabel:setPosition(listSize.width / 2, listSize.height / 2)
	self.tipLabel:setVisible(false)

	return true
end

function CrossThroneKingListView:addLoadingAni()
	self:removeLoadingAni()

	self.m_loadingIcon = CCLoadSprite:call("createSprite", "loading_1.png")
	self.m_loadingIcon:setAnchorPoint(ccp(0.5, 0.5))

	local cSize = self.ui.m_listNode:getContentSize()
	self.m_loadingIcon:setPosition(ccp(cSize.width / 2, cSize.height / 2))

	local rotateAction = cc.RotateTo:create(0.5, 720)
	local rotateForever = cc.RepeatForever:create(rotateAction)
	self.m_loadingIcon:runAction(rotateForever)
	self.ui.m_listNode:addChild(self.m_loadingIcon, 1000000)
end

function CrossThroneKingListView:removeLoadingAni()
	if (self.m_loadingIcon) then
		self.ui.m_listNode:removeChild(self.m_loadingIcon)
		self.m_loadingIcon = nil
	end
end

function CrossThroneKingListView:refreshView(param)
	if param then
		self:removeLoadingAni()
		
		local tbl = dictToLuaTable(param)
		dump(tbl, "CrossThroneKingListView refreshView")
		if tbl.kingList then
			self.m_data = tbl.kingList
			self.m_tableView:reloadData()

			if #self.m_data  == 0 then
				self.tipLabel:setVisible(true)
			end
		end	
	end
end

function CrossThroneKingListView:onEnter()
	self:setTitleName(getLang(self.dialogId))

	local function callback1(param) self:refreshView(param) end
	local handler1 = self:registerHandler(callback1)
	CCSafeNotificationCenter:call("registerScriptObserver", self, handler1, "crossThrone.kingList")
end

function CrossThroneKingListView:onExit()
	CCSafeNotificationCenter:call("unregisterScriptObserver", self, "crossThrone.kingList")
end

function CrossThroneKingListView:cellSizeForTable(tabView, idx)
	return 640, 45
end

function CrossThroneKingListView:tableCellAtIndex(tabView, idx)
	if (idx >= #self.m_data) then return end

	local rewardId = self.m_data[idx + 1].rewardId
	local cell = tabView:dequeueCell()
	if cell then
		local node = cell:getChildByTag(666)
		node:setData(self.m_data[idx + 1])
	else
		cell = cc.TableViewCell:create()
		local node = CrossThroneKingListCell:create(self.m_data[idx + 1])
		node:setTag(666)
		cell:addChild(node)
	end
	
	return cell
end

function CrossThroneKingListView:numberOfCellsInTableView(tabView)
	return #self.m_data 
end

------------------------------CrossThroneKingListView------------------------------

function CrossThroneKingListCell:create(listData)
	local view = CrossThroneKingListCell.new(listData)
	Drequire("game.crossThrone.KingOfAllServerHistoryCell_ui"):create(view, 1)
	if view:initView(listData) then
		return view
	end
end

function CrossThroneKingListCell:initView(listData)
	self:setData(listData)

	return true
end

function CrossThroneKingListCell:setData(listData)
	self.listData = listData

	local nameStr = ""
	if listData.kingdom ~= "" then
		nameStr = nameStr .. "#" .. listData.kingdom
	end

	if listData.abbr ~= "" then
		nameStr = nameStr .. "(" .. listData.abbr .. ")"
	end

	nameStr = nameStr .. listData.name

	self.ui.m_nameLabel:setString(nameStr)
	self.ui.m_timeLabel:setString(format_time(tonumber(listData.occupyTime)))
	self.ui.m_dateLabel:setString(CCCommonUtilsForLua:call("timeStampToYMD", tonumber(listData.accedeTime) / 1000))
end

return CrossThroneKingListView