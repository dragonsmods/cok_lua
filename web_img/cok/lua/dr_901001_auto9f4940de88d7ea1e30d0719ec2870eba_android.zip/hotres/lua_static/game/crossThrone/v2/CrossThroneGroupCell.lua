local CrossThroneGroupCell = class("CrossThroneGroupCell", cc.Layer)

function CrossThroneGroupCell:ctor(info, idx)
    Drequire("game.crossThrone.v2.CrossThroneGroupCell_ui"):create(self, 0)
    self:refreshCell(info, idx)
end

function CrossThroneGroupCell:refreshCell(info, idx)
    self.info = info
    self.idx = idx

    self.ui.m_titleNode:setVisible(false)
    self.ui.m_groupNode:setVisible(false)
    self.ui.m_serverNode:setVisible(false)

    if info.title then
        self.ui.m_titleNode:setVisible(true)
        self.ui.m_titleText:setString(info.title)
    elseif info.group then
        self:refreshArrow()
        self.ui.m_groupNode:setVisible(true)
        self.ui.m_groupText:setString(getLang("52045322", info.group))
    else
        self.ui.m_serverNode:setVisible(true)
        self.ui.m_server1:setString("")
        self.ui.m_server2:setString("")
        self.ui.m_server3:setString("")
        if info.servers[1] then
            self.ui.m_server1:setString(info.servers[1])
        end
        if info.servers[2] then
            self.ui.m_server2:setString(info.servers[2])
        end
        if info.servers[3] then
            self.ui.m_server3:setString(info.servers[3])
        end
    end 
end

function CrossThroneGroupCell:refreshArrow()
    if self.info.open then
        self.ui.m_groupArrow:setRotation(90)
    else
        self.ui.m_groupArrow:setRotation(0)
    end
end

function CrossThroneGroupCell:onClickGroup()
    if self.info.view then
        self.info.open = not self.info.open
        self.info.view:showGroup(self.idx)
        self:refreshArrow()
    end
end

return CrossThroneGroupCell