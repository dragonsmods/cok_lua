----------------------------
-- Author: Elex
-- Date: 2021-09-26 Sunday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CrossThroneRewardCell_ui = class("CrossThroneRewardCell_ui")

--#ui propertys


--#function
function CrossThroneRewardCell_ui:create(owner, viewType, paramTable)
	local ret = CrossThroneRewardCell_ui.new()
	CustomUtility:LoadUi("CrossThroneRewardCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CrossThroneRewardCell_ui:initLang()
	LabelSmoker:setText(self.m_t1, "52045331")
	LabelSmoker:setText(self.m_t2, "138108")
end

function CrossThroneRewardCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CrossThroneRewardCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CrossThroneRewardCell_ui:onClickGroup(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickGroup", pSender, event)
end

return CrossThroneRewardCell_ui

