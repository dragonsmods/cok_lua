local CrossThroneGroupTabCell = class("CrossThroneGroupTabCell", cc.TableViewCell)

function CrossThroneGroupTabCell:create()
    local cell = CrossThroneGroupTabCell.new()
    Drequire("game.crossThrone.v2.CrossThroneGroupTabCell_ui"):create(cell, 0)
    cell.ui.m_tabBtn:setSwallowsTouches(false)
    return cell
end

function CrossThroneGroupTabCell:refreshCell(info, idx)
    self.info = info
    self:refreshSelect()
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_tabBtn, getLang(info.name))
end

function CrossThroneGroupTabCell:refreshSelect()
    if self.info.selectCb(self.info.despotId) then
        self.ui.m_tabBtn:setEnabled(false)
    else
        self.ui.m_tabBtn:setEnabled(true)
    end
end

function CrossThroneGroupTabCell:onEnter()
    registerScriptObserver(self, self.refreshSelect, "msg.crossthrone.tab")
end

function CrossThroneGroupTabCell:onExit()
    unregisterScriptObserver(self, "msg.crossthrone.tab")
end 

function CrossThroneGroupTabCell:onClickTab()
    self.info.tabCb(self.info.despotId)
end

return CrossThroneGroupTabCell