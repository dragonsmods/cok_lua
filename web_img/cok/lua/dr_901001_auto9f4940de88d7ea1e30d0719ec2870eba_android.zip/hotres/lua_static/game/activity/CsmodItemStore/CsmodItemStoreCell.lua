local CsmodItemStoreCell = class("CsmodItemStoreCell",
    function()
        return cc.Layer:create()
    end
)

local LibaoCommonFunc = Drequire("game.LiBao.LibaoCommonFunc")

CsmodItemStoreCell.__index = CsmodItemStoreCell

function CsmodItemStoreCell:create(idx)
    local ret = CsmodItemStoreCell.new()
    Drequire("game.activity.CsmodItemStore.CsmodItemStoreCell_ui"):create(ret)
    registerTouchHandler(ret)
    ret:setTouchEnabled(true)
    ret:setSwallowsTouches(false)

    return ret
end

local TYPE2_EQUIPMENT = 2
function CsmodItemStoreCell:refreshCell(info , idx) 
    -- dump(info,"CsmodItemStoreCell:refreshCell+++",10)   
    self.m_info = info
    local shopData = info.data
    local createDataItemType = 0 
    if info.data.m_type2 == TYPE2_EQUIPMENT then 
        createDataItemType = 1
    end

    -- 显示图标（带tip）
    local itemData = {
        type = createDataItemType,
        itemId = shopData.m_item_id,
        num = 1
    }

    LibaoCommonFunc.createDataItemTouchNode({
                itemData = itemData,
                iconNode = self.ui.m_iconNode,
                iconSize = 70,
                numLabel = nil,
                -- beTouch = true,   默认可以触摸
                touchParentNode = self.m_info.parent,
                })

    local name = CCCommonUtilsForLua:call("getNameById", tostring(shopData.m_item_id))
    self.ui.m_nameLabel:setString(tostring(name))

    -- 显示购买按钮的状态
    shopData.hasBuyNum = shopData.m_totalBuy 
    shopData.canBuyNum = shopData.m_buy_times
    if shopData.m_buy_times_daily > 0 then
        shopData.hasBuyNum = shopData.m_todayBuy
        shopData.canBuyNum = shopData.m_buy_times_daily
    end

    if shopData.canBuyNum > 0 and shopData.hasBuyNum >= shopData.canBuyNum then
        self.ui.m_buyButton:setEnabled(false)
    else
        self.ui.m_buyButton:setEnabled(true)
    end

    -- 显示购买数量信息
    if shopData.canBuyNum > 0 then
        self.ui.m_numNode:setVisible(true)
        self.ui.m_lLabel:setString(shopData.hasBuyNum)
        self.ui.m_rLabel:setString(shopData.canBuyNum)
        self.ui.m_lineLabel:setString('/')
    else
        self.ui.m_numNode:setVisible(false)
    end

    if shopData.m_sale == "99" then
        self.ui.m_hotSprite:setVisible(true)
    else
        self.ui.m_hotSprite:setVisible(false)
    end

    -- 显示消耗道具图标
    local comumeItemID = tonumber(shopData.m_value_item)
    if comumeItemID > 0 then
        local pic = CCCommonUtilsForLua:call("getIcon", tostring(comumeItemID))
        local icon = CCLoadSprite:call("createSprite", pic, CCLoadSpriteType.CCLoadSpriteType_RESOURCE)
        CCCommonUtilsForLua:setSpriteMaxSize(icon, 36, true)
        self.ui.m_itemNode1:addChild(icon)

        self.ui.m_itemNumLabel:setString('X' .. shopData.m_value_item_num)
    end
end

function CsmodItemStoreCell:onBuyButtonClick()
    local info = self.m_info
    local shopData = info.data

    local comumeItemID = tonumber(shopData.m_value_item)
    local tinfo = ToolController:call("getToolInfoForLua", comumeItemID)
    if tinfo == nil then
        return
    end
    local price = tonumber(shopData.m_value_item_num)
    local count = tinfo:call("getCNT")
    local maxBuyMoney = math.max(1, math.floor(count / price))

    local StoreBuyConfirmDialogForLua = Drequire("game.CommonPopup.StoreBuyConfirmDialogForLua")
    local params = {}
    params.itemId = shopData.m_item_id
    params.maxNum = (shopData.canBuyNum > 0) and (shopData.canBuyNum - shopData.hasBuyNum) or 20000
    params.maxNum = math.min(params.maxNum, maxBuyMoney)
    params.messagePosted = "CsmodItemStore_BuyConfirm"
    params.priceType = comumeItemID
    params.singlePoint = price
    params.moneyIcon = CCCommonUtilsForLua:call("getIcon", tostring(shopData.m_value_item))
    params.id = shopData.m_id

    local view = StoreBuyConfirmDialogForLua:create(params)
    PopupViewController:addPopupView(view)
end

return CsmodItemStoreCell


