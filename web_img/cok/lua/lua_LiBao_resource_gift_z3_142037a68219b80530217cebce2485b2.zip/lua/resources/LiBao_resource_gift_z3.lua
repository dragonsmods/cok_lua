cfg_table = {
	["layerX"] = -16,
	["layerY"] = -33,
	["layerScale"] = 1,

}