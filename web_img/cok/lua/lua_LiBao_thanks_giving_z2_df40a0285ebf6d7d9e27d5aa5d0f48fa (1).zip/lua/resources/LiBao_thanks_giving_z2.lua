cfg_table = {
	["layerX"] = -19,
	["layerY"] = -33,
	["layerScale"] = 1,
}