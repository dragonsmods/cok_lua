
LUA_DEBUG = LUA_DEBUG or 0
local path = cc.FileUtils:getInstance():getWritablePath() .. "lua_debug_file_sign"
if cc.FileUtils:getInstance():isFileExist(path) then
	LUA_DEBUG = 1
end

