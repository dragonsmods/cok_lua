
myRequire = myRequire or function ( path )
	if 1 == LUA_DEBUG then
		package.loaded[path] = nil
	end
	return require(path)
end

function createDynamicLoadingUi(pparent, idd)
	local checkTmpZip = cc.FileUtils:getInstance():getWritablePath() .. "tmpZR_" .. string.format(idd) .. ".zip"
	--print ("checkTmpZip :: " .. checkTmpZip)
	if cc.FileUtils:getInstance():isFileExist(checkTmpZip) then
		--print "1"
		return false
	end
		--print "2"
	if cc.FileUtils:getInstance():isFileExist(cc.FileUtils:getInstance():getWritablePath() .. "lua/" .. string.format(idd) .. "/loadinguiPlus.lua") == false then
		--print "3"
		return false
	end
	myRequire(string.format(idd) .. ".loadinguiPlus")
	return loadingui:create(pparent, idd)
end

function createStaticLoadingUi(pparent, civilizationType)
	print("createStaticLoadingUi ", pparent, civilizationType)
	if civilizationType < 0 or civilizationType > 4 then
		civilizationType = 0
	end
	myRequire("game.loading.loading_" .. tostring(civilizationType) .. ".loadinguiPlus")
	return loadingui:create(pparent)
end

-- ZT test 1