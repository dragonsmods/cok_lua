--医疗帐篷功能按钮(不包含升级与详情按钮)
local MainCityBtn = class("MainCityFunBtn", Drequire("game.buildingBtns.BuildingAddBtn"))

function MainCityBtn:create(param)
    local btn = MainCityBtn.new(param)
    btn:initBtn()    
    return btn
end

function MainCityBtn:initBtn()
    self.buildKey = self.param:valueForKey("buildKey"):intValue()
    local cityLv = FunBuildController:call("getMainCityLv")
    -- 皮肤缩放功能入口
    -- local avatarLv = FunOpenController:getLimitLv(FUN_ICON_UI_AVATAR)
    -- local skinScaleMgrIns = require('game.skinScale.SkinScaleMgr').getInstance()
    -- if cityLv >= avatarLv and skinScaleMgrIns:isOpen() then
    --     self:addCustomBtn(function (  )
    --         return skinScaleMgrIns:isOpen()
    --     end,nil,'icon_SkinScaleBtn.png','cityskin_status.png','132206','skinScaleEntry',function (  )--132206=自定义
    --         skinScaleMgrIns:OpenView()
    --     end)
    -- end

    -- 城市增益入口
    local buffLv = FunOpenController:getLimitLv(FUN_ICON_UI_CITYBUFF)
    if FunOpenController:isShowAndDef("fun_cityBuff", cityLv >= buffLv) then
        local callback = function()
            self:hideSelf()
            -- local view = Drequire("game.CommonPopup.ItemStatusView"):create()
            -- PopupViewController:addPopupInView(view)
            onFireEvent("open_ItemStatusView")
            local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
            local level = playerInfo:getProperty("level")
            FBUtiliesInLua:call("appEventCityEffectLog", cityLv, level)
            LogController:sendUserBehaviorEvent("building", 2, tostring(FUN_BUILD_MAIN), "buff")
        end
        self:addBtn({
            icon = "tile_pop_icon20.png",
            text = "102282",    --102282=城市增益
            callback = callback,
            btnKey = "cityBuff",
        })
    end

    self:addExtensionBtn()

    --城建排行榜入口
    if FunOpenController:isShowAndDef("fun_cityConstruction", cityLv > 14) and CCCommonUtilsForLua:isFunOpenByKey("building_rank")  then
        CCLoadSprite:call("loadDynamicResourceByName", "buildExtension_face")
        local callback = function()
            self:hideSelf()
            local view = Drequire("game.buildExtension.buildRankAct.BuildRankMainView"):create()
            if view then
                PopupViewController:addPopupInView(view)
            end        
        end
        local iconName = "icon_buildExtension.png"
        local sf = CCLoadSprite:call("getSF", "icon-xinchengbao.png")
        if sf then
            iconName = "icon-xinchengbao.png"
        end
        self:addBtn({
            icon = iconName,
            text = "195001",    --195001=城建之神
            callback = callback,
            btnKey = "buildRank",
            })
    end

    -- 新皮肤商城入口
    if CCCommonUtilsForLua:isFunOpenByKey("avatar_shop_level_limit") and FunBuildController:call("getMainCityLv") >= 5 then
        local avatarV1Ins = require('game.LiBao.AvatarShop.AvatarShopV1Mgr').getInstance()
        self:addCustomBtn(function (  )
            return avatarV1Ins:isOpen()
        end,avatarV1Ins:getDynRes(),'AvatarShopV1_09.png','icon_buildExtension.png','9900289','avatarV1Entry',function (  )
            avatarV1Ins:showMainView()
        end)
    end

    -- 纪元按钮
    if CCCommonUtilsForLua:isFunOpenByKey("csmod_overlord") then
        CCLoadSprite:call("loadDynamicResourceByName", "Common_209_face")
        self:addBtn({
            icon = "epoch_icon.png",
            text = "52145660", -- 52145660=王国编年史
            callback = function()
                self:hideSelf()
                local view = Drequire("game.crossThrone.CrossThroneEntryView"):create()
                PopupViewController:addPopupInView(view)
            end,
            btnKey = "epochView",
        })
    end



    -- toko dekorasi
    if CCCommonUtilsForLua:isFunOpenByKey("dekorasi_kastil") and FunBuildController:call("getMainCityLv") >= 5 then
    -- if CCCommonUtilsForLua:isFunOpenByKey("dekorasi_kastil") then
        CCLoadSprite:call("loadDynamicResourceByName", "Common_209_face")
        self:addBtn({
            icon = "cityskin_status.png",
            text = "101482", -- 101482=王国编年史
            callback = function()
                self:hideSelf()
                local view = Drequire("game.avatar.AvatarViewEx"):create()
                PopupViewController:addPopupInView(view)
            end,
            btnKey = "epochView",
        })
    end


-- csmod_store_btn
if CCCommonUtilsForLua:isFunOpenByKey("csmod_store_btn") and FunBuildController:call("getMainCityLv") >= 14 then
    CCLoadSprite:call("loadDynamicResourceByName", "Common_209_face")
    self:addBtn({
        icon = "icon_StoneJing_face.png",
        text = "8009801",
        callback = function()
            self:hideSelf()
            local view = Drequire("game.activity.CsmodStore.CsmodStoreView"):create()
            PopupViewController:addPopupInView(view)
        end,
        btnKey = "csmodstore",
    })
end


if CCCommonUtilsForLua:isFunOpenByKey("hero_store_btn") then
    CCLoadSprite:call("loadDynamicResourceByName", "Common_209_face")
    self:addBtn({
        icon = "7dayIcon.png",
        text = "134123",
        callback = function()
            self:hideSelf()
            local view = Drequire("game.ChristmasGift.ChristmasGiftView"):create()
            PopupViewController:addPopupInView(view)
        end,
        btnKey = "herostore",
    })
end
--end


end

return MainCityBtn
