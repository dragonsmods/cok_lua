local localize={
	["localize/*.png"]=1, 
}
return localize
