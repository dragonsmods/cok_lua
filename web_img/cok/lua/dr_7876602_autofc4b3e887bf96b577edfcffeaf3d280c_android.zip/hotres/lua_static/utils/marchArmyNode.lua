-- @Author: tangwen
-- @Date:   2019-06-10 15:49:21
-- @Last Modified by:   tangwen
-- @Last Modified time: 2019-06-14 12:18:02
--[[
	需要放置在起点结点,终点结点同级下
]]

local utils = utils

local marchArmyNode = class("utils.marchArmyNode",cc.Node)

utils.marchArmyNode = marchArmyNode


function marchArmyNode:create(param)
    local view = marchArmyNode.new()
    if view:initView(param) then return view end
end

function marchArmyNode:onEnter()

end

function marchArmyNode:onExit()
  
end

function marchArmyNode:resetParam( param )
	assert(param.startPos)
	assert(param.endPos)

	self.m_param = param
	self.m_startPos = param.startPos
	self.m_endPos = param.endPos

	local t_angle = cc.pGetAngleNormalVector(param.startPos, self.m_endPos)
	self.m_angle = math.radian2angle(t_angle )
end

function marchArmyNode:initView(param)
	self.soldireNode = cc.Node:create()
	self:addChild(self.soldireNode)

	self:resetParam(param)
    return true
end

function marchArmyNode:showAttackAnima(  )
	self.soldireNode:stopAllActions()
    self.soldireNode:removeAllChildren()
    self.soldireNode:setPosition(self.m_startPos)

    local function createMarchLine(  )
    	local src = self.m_startPos
    	local dst = self.m_endPos

    	local lineRes = self.m_param.lineRes or "foot64_ob.png"
    	local lineWidth = self.m_param.lineWidth or 20
    	local marchSpeed = self.m_param.lineSpeed or 128

    	local marchLine = CCLineBatchedSprite:call("createForLua", lineRes, src, dst, lineWidth, marchSpeed, true)
    	self:addChild(marchLine)
    end

    local function createSoldire()
        self.soldireNode:removeAllChildren()
        local dir = "N_"
        local rota = self.m_angle --0
        local flipX = false

        local armyList = FictitiousMarchArmy:call("create",false,false,dir,flipX)               
        tolua.cast(armyList, "cc.Node")
        armyList:setScale(0.75)
        armyList:setTag(25)
        armyList:setRotation(rota)               
        self.soldireNode:addChild(armyList)
    end
    
    local function soldireAttack()
        local soldire = self.soldireNode:getChildByTag(25)                
        if soldire then
            tolua.cast(soldire, "cc.Node")            
            local rota = self.pos_dir == 0 and 75 or 0
            soldire:setRotation(rota)
            tolua.cast(soldire, "FictitiousMarchArmy")
            soldire:call("armyAttackAndDisappear",8)
        end
    end

    local endPos = self.m_endPos --cc.p(300,300)
    local func0 = cc.CallFunc:create(createMarchLine)
    local func1 = cc.CallFunc:create(createSoldire)
    local func2 = cc.CallFunc:create(soldireAttack)
    local func3 = cc.CallFunc:create(function() 
        if self.m_param.cb then
        	self.m_param.cb()
        end
    end)

    local move_to = cc.MoveTo:create(2.0,endPos)
    local delay1 = cc.DelayTime:create(self.m_param.startDelay or 1)
    local delay2 = cc.DelayTime:create(self.m_param.endDelay or 2)
    local seq = cc.Sequence:create(delay1,func0,func1,move_to,func2,delay2,func3)
    self.soldireNode:runAction(seq)  
end

