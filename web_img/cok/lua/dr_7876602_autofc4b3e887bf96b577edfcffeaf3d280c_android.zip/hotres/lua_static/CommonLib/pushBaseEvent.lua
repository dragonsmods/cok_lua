------------------------------------------------------------------
-------- 在这里不断的增加处理函数吧 ----------------
------------------------------------------------------------------
local onPushHandler = {}
-- 英雄界面
local function onUpdate_HeroInfo(dict)
	-- package.loaded["game.hero.HeroManager"] = nil
	local HeroManager = require("game.hero.HeroManager")
	HeroManager.initHeroInfo(dict)
end

local function onUpdate_HeroPrisonInfo(dict)
	-- package.loaded["game.hero.HeroManager"] = nil
	local HeroManager = require("game.hero.HeroManager")
	HeroManager.initPrisonerInfo(dict)
	CCSafeNotificationCenter:call("postNotification", "hero_prisoner_info_refresh")
end

local function onPushHeroSkillHospital( dict )
	local HeroManager = require("game.hero.HeroManager")
	HeroManager.onPushHeroSkillHospital( dict )
end

local function onPushMonthFund( dict )
	dump("onPushMonthFund+++")
	MonthFundController:onPushMonthFund( dict )
end

local function onPushLiBaoPopValue( dict )
	dump("onPushLiBaoPopValue+++")
	LiBaoController.getInstance():onPushLiBaoPopValue( dict )
end

local function onDuoBaoLiBaoTooMuch( dict )
	dump("onDuoBaoLiBaoTooMuch+++")
    if not dict then 
        dump("error,dict is empty36+++")
        return 
    end
    DuoBaoActivityController:processLiBaoTooMuch(dict)
end

local function onGetPushEffectUser(dict)
	dump(dict, " on getPushEffectUser ~~~~")
	local tbl = dictToLuaTable(dict)
	dump(tbl)
	package["game.controller.ServerActionPush"] = nil
	local ServerActionPush = require("game.controller.ServerActionPush")
	ServerActionPush.getPushEffectUser(tbl)
end

--关联邮件成功推送
local function onGetPushAssociateInfo(dict)
	MyPrint("onGetPushAssociateInfo", dict)
	if (dict == nil) then return end
	local associationManager = require("game.association.AssociationManager") 
	associationManager.getAssoEmailPush(dict)
end

local function onUpdateNeutralLandInfo(dict)
	MyPrint("onUpdateNeutralLandInfo")
	NeutralLandManager.refreshData(dict)
end

local function onUpdateNeutralLandMiracleInfo(dict)
	MyPrint("onUpdateNeutralLandMiracleInfo")
	NeutralLandManager.refreshMiracleData(dict)
end

local function onPushArenaState(dict)
	MyPrint("onPushArenaState")
	ArenaController.getInstance():pushArenaData(dict)
end

local function onPushArenaScore(dict)
	MyPrint("onPushArenaScore")
	ArenaController.getInstance():scroePushHandler(dict)
end

--荣耀6新兵种虚弱信息同步
local function onUpdateNewArmyWeakInfo(dict)
	require("game.Glory6.Glory6Manager").syncWeakArmy(dict)
end

--章节任务完成
local function onChapterTaskStatusChanged( dict )
	-- body
	ChapterController.getInstance():sendGetChapterList()
    ChapterController.getInstance():setTaskStatus(true, dict)
	MyPrint("onChapterTaskStatusChanged")
end 

local function onDailyTashCompletePush( dict )
	--taskId  int
	CCCommonUtilsForLua:call("flyHint", "", "", _lang("167558"))
end
-- 英雄使用主动技能 减少锻造时间
local function on_CutEquipTime( dict )
	-- body
	if nil == dict then
		return
	end
	-- local qid = dict:valueForKey("queueId"):intValue()
	-- qid = CCCommonUtilsForLua:call("getQueueSortByType", QueueType.TYPE_FORGE) * 1000 + (QueueType.TYPE_FORGE + 1) * 100 + qid
	-- qid = CCCommonUtils::getQueueSortByType(this->type) *1000 + (this->type + 1)*100+this->qid;
	local uuid = dict:valueForKey("queueId"):getCString()
	local queueInfo = QueueController:call("getQueueInfoByUuid", uuid)
	if nil == queueInfo then
		MyPrint("nil == queueInfo !!!")
		return
	end
	local updateTime = dict:valueForKey("updateTime"):doubleValue()
	updateTime = updateTime / 1000
	if updateTime == 0 then
		queueInfo:setProperty("finishTime", 0)
	else
		updateTime = GlobalData:call("changeTime", updateTime)
		queueInfo:setProperty("finishTime", updateTime)
	end
end

-- local function onRefreshThroneRank( dict )
-- 	if nil == dict then 
-- 		return
-- 	end
-- 	local cmd = Drequire("game.command.NewKingdonRankCmd").create("Get.FightOfKing.Info", laFunc)
-- 	cmd:sendAndRelease()
-- end

local function onThroneOccupyChange( dict )
	MyPrint("onThroneOccupyChange")
	if nil == dict then
		return
	end

	local cmd = Drequire("game.command.NewKingdomRankCmd").create()
	cmd:send()
end

local function onCrossThroneOccupyChange( dict )
	local serverType = GlobalData:call("shared"):getProperty("serverType")
	if (serverType == ServerType.SERVER_DESPOT or serverType == ServerType.SERVER_EMPIRE) then
		CCSafeNotificationCenter:postNotification("crossThrone.refreshOccupyRank")
	end
end

local function onSetCrystalGold(dict)
	local tbl = dictToLuaTable(dict)
	dump(tbl, "onSetCrystalGold is: ")
	local crystalGoldNum = tonumber(tbl.crystalGold)
	-- MyPrint("crystalGoldNum", crystalGoldNum)
	PlayerInfoController:setCrystalGold(crystalGoldNum)
	CCSafeNotificationCenter:postNotification("MSG_REFRESH_CRYSTAL")
end

local function onQuickUpgradeComplete_Science(dict)
	dump(dictToLuaTable(dict), "onQuickUpgradeComplete_Science")
	local keyIndex = 1;
	while true do
		local upgradeDict = dict:objectForKey(""..keyIndex)
		if upgradeDict == nil then
			break
		end
		ScienceController:call("getInstance"):call("retFinishScience", upgradeDict)
		keyIndex = keyIndex + 1
	end
end

local function onQuickUpgradeComplete_Building(dict)
	dump(dictToLuaTable(dict), "onQuickUpgradeComplete_Building")
	local keyIndex = 1;
	while true do
		local upgradeDict = dict:objectForKey(""..keyIndex)
		if upgradeDict == nil then
			break
		end
		FunBuildController:call("getInstance"):call("endUpFunBuild", upgradeDict, 1)
		keyIndex = keyIndex + 1
	end
end

local function onPushMilitaryBuf(dict)
	local dataArr = dict:objectForKey("skillBuffArr")
	local arc = ArmedRankController:call("getInstance")
	arc:call("updateArmedBuffArr", dataArr)
end

local function onAuctionGivePricePushBack( dict )
	local data = dictToLuaTable(dict)
	dump(data, "onPushBaseEvent-onAuctionGivePricePushBack+++")
	AuctionHouseController:processGivePriceData(data)
end 

local function onGlobalAuctionDataChangedPushBack( dict )
	local data = dictToLuaTable(dict)
	dump(data, "onPushBaseEvent-onGlobalAuctionDataChangedPushBack+++")
	AuctionHouseController:processGlobalAuctionDataChanged(data)
end 

local function onGlobalAuctionPriceReplaced( dict )
	local data = dictToLuaTable(dict)
	dump(data, "onPushBaseEvent-onGlobalAuctionPriceReplaced+++")
	AuctionHouseController:processGlobalAuctionPriceReplaced(data)
end

local function onPushFestivalActivitTips( dict )
	local data = dictToLuaTable(dict)
	dump(data, "onPushBaseEvent-onPushFestivalActivitTips+++")
	require("game.FestivalActivities.FestivalActivitiesMakexxxController").getInstance():processActTips(data)
end

local function onAuctionAddPricePushBack( dict )
	local data = dictToLuaTable(dict)
	dump(data, "onPushBaseEvent-onAuctionAddPricePushBack+++")
	AuctionHouseController:processAddPriceData(data)
end 

local function onAuctionMyPriceIsReplaced( dict )
	local data = dictToLuaTable(dict)
	dump(data, "onPushBaseEvent-onAuctionMyPriceIsReplaced+++")
	AuctionHouseController:processMyPriceIsReplacedData(data)
end 

local function onAuctionListViewDataChanged(dict)
	local data = dictToLuaTable(dict)
	dump(data, "onPushBaseEvent-onAuctionListViewDataChanged+++")
	AuctionHouseController:processListViewDataChanged(data)
end

local function onTerritoryHospitalCreate (dict)
	local data = dictToLuaTable(dict)
	dump(data, "onTerritoryHospitalCreate")
	Drequire('game.allianceTerritory.AllianceHospitalController')
	AllianceHospitalController.getInstance():handlePushTerritoryCreate(data)
end

local function onTerritoryHospitalUpdate (dict)
	local data = dictToLuaTable(dict)
	dump(data, "onTerritoryHospitalUpdate")
	Drequire('game.allianceTerritory.AllianceHospitalController')
	AllianceHospitalController.getInstance():handlePushTerritoryUpdate(data)
end

local function onTerritoryHospitalCancel (dict)
	local data = dictToLuaTable(dict)
	dump(data, "onTerritoryHospitalCancel")
	Drequire('game.allianceTerritory.AllianceHospitalController')
	AllianceHospitalController.getInstance():handlePushTerritoryCancel(data)
end

local function onAllianceHospitalTreated (dict)
	local data = dictToLuaTable(dict)
	dump(data, "onAllianceHospitalTreated")
	Drequire('game.allianceTerritory.AllianceHospitalController')
	AllianceHospitalController.getInstance():handlePushTreated(data)
end

local function onPushEffects(dict)
	local data = dictToLuaTable(dict)
	dump(data, "onPushEffects")
	if data.crown_effects then
		require("game.crown.CrownManager").updateEffects(data.crown_effects)
	end
end

local function onPushAllianceLengendComplete(dict)
	GlobalData:call("shared"):setProperty("allianceLegendComplete", true)
end

local function onPushArtilleryDamage(dict)
	local data = dictToLuaTable(dict)
	dump(data, "onPushArtilleryDamage")
	require("game.artillery.ArtilleryManager").updateDamage(data.damage)
	CCSafeNotificationCenter:postNotification("artillery.damage")
end

local function onPushArtilleryChange(dict)
	local data = dictToLuaTable(dict)
	dump(data, "onPushArtilleryChange")
	require("game.artillery.ArtilleryManager").updateArtilleryData(data.id, data.num, nil, data.timeStamp)
end

local function onPushArtillryStatus(dict)
	local data = dictToLuaTable(dict) 
	dump(data, "onPushArtillryStatus")
	require("game.artillery.ArtilleryManager").updateStatus(data.status)
end

local function onPushArtilleryCityDefense(dict)
	local data = dictToLuaTable(dict) 
	dump(data, "onPushArtilleryCityDefense")
	require("game.artillery.ArtilleryManager").updateCityDefense(data.cityDefValue)
end

local function onPushAllianceStar(dict)
	local data = dictToLuaTable(dict) 
	dump(data, "onPushAllianceStar")
	require("game.allianceTerritory.civiMiracle.CiviMiracleManager").updateAllianceStar(data)
end

local function onPushCiviMiracleFinish(dict)
	local data = dictToLuaTable(dict) 
	dump(data, "onPushCiviMiracleFinish")
	--改变结构 调用统一数据同步接口
	if data.civiMiracle then
        local finishinfo = data.finishinfo
        data = data.civiMiracle
        data.finishinfo = finishinfo
    end
    require("game.allianceTerritory.civiMiracle.CiviMiracleManager").clearStarMap()
	require("game.allianceTerritory.civiMiracle.CiviMiracleManager").updateData(data)
	CCSafeNotificationCenter:postNotification("civiMiracle.refreshStar")  
end

local function onPushAllianceCiviEffect(dict)
	local data = dictToLuaTable(dict) 
	dump(data, "onPushAllianceCiviEffect")
	require("game.allianceTerritory.civiMiracle.CiviMiracleManager").updateData(data)
end

local function onPushAllianceCiviJoin(dict)
	local data = dictToLuaTable(dict)
	dump(data, "onPushAllianceCiviJoin")
	require("game.allianceTerritory.civiMiracle.CiviMiracleManager").updateData(data)

	--同步所有个人技能信息
	local generalSkillArray = tolua.cast(dict:objectForKey("generalSkillArray"), "CCArray")
	if generalSkillArray then
		local skills =  tolua.cast(generalSkillArray:objectAtIndex(0), "CCArray")
		if skills then
			local count = skills:count()
			for index = 1, count - 1 do
				local cdInfo = skills:objectAtIndex(index)
				if cdInfo then
					GeneralManager:call("updateOneSkillCDInfo", cdInfo)
				end
			end
		end
	end
end

local function onPushCiviMiracleRecommend(dict)
	local data = dictToLuaTable(dict)
	dump(data, "onPushCiviMiracleRecommend")
	require("game.allianceTerritory.civiMiracle.CiviMiracleManager").updateData(data)
	CCSafeNotificationCenter:postNotification("civiMiracle.refreshStar") 
end

local function onPushCiviPerSkill(dict)
	local data = dictToLuaTable(dict)
	dump(data, "onPushCiviPerSkill")
	GeneralManager:call("updateOneSkillCDInfo", dict)
end

local function onPushDragonTalentPoints(dict)
	local data = dictToLuaTable(dict)
	DragonActiveSkillManagerNew.getInstance():updateData(data)
end

local function pushTreasureFamChange( dict )
	CCSafeNotificationCenter:postNotification("treasurefam_changed")
end

local function pushTreasureFamColllectTimeChanged( dict )
	local data = dictToLuaTable(dict) 
	dump(data,"pushTreasureFamColllectTimeChanged+++",10)
	local selfEndTime = tonumber(data.collectionEndTime)
	TreasureFamManager:setCollectionEndTime(selfEndTime)
	CCSafeNotificationCenter:postNotification("treasurefam_collect_time_changed")
end

local function onPushAllianceBossOpen( dict )
	if dict then 
        local params = dictToLuaTable(dict) 
        dump(params,"onPushAllianceBossOpen+++")
        if params.bossId and params.pointId and params.endTime then
            AllianceBossController.getInstance():refreshBossStatus(params, 1)
        end
    end
end

local function onPushAllianceBossDead( dict )
	if dict then 
        local params = dictToLuaTable(dict) 
        dump(params,"onPushAllianceBossDead+++")
        if params.bossId then
            AllianceBossController.getInstance():refreshBossStatus(params, 2)
        end
    end
end

local function onPushAncientArmyChange( dict )
	local data = dictToLuaTable(dict)
	dump(data,"onPushAncientArmyChange")
	require("game.army.ArmyController"):syncAncientArmy(data)
end

local function onPushCrossThroneSwitch(dict)
	local data = dictToLuaTable(dict)
	dump(data, "onPushCrossThroneSwitch")
	CCSafeNotificationCenter:postNotification("crossthrone.switch", dict)

	local scene = WorldMapView:call("instance")
	if nil ~= scene and nil ~= scene.addDespotBuildSwitch then
		MyPrint("scene.addDespotBuildSwitch")
		scene:addDespotBuildSwitch(atoi(data.pointId), (data.switch == "1"))
	end
end

local function pushKingdomBattleTeam( dict )
	local data = dictToLuaTable(dict)
	UiCompoentControoller.kingdomBattleTeam(data)
end

local function pushBoxScience( dict )
    ScienceController:call("getInstance"):call("retFinishScience", dict)
end

-- 活动排行榜数据
local function onPushTriggerRank( dict )
	ActivityWeekController.getInstance():ackRank(dict)
end

--【Awen】更新龙技能状态
local function onPushDragonSkillState( dict )
	DragonActiveSkillManager.getInstance():pushUpdateState(dict)
end

----------------------------------------------- 
-- 【Awen】更新文明堡垒占领信息
local function onPushCivOccupy( dict )
	CCSafeNotificationCenter:postNotification("CivFortressAddUnder:updataOccupy", dict)
end

-- 【Awen】文明堡垒状态
local function onPushCivStatus( dict )
	CivFortress2Controller:setStatus(dict)
end

----------------------------------------------- 
-- 【Awen】先祖战场：等待确认参战
local function onPushAncestralWaitConfirm(dict)
	local data = dictToLuaTable(dict)
	BattlefieldController.getInstance():pushAncestralWaitConfirm(data)
end

-- 【Awen】先祖战场：确认参战人数
local function onPushAncestralConfirmCount(dict)
	local data = dictToLuaTable(dict)
	BattlefieldController.getInstance():pushAncestralConfirmCount(data)
end

-- 【Awen】先祖战场：等待进入战场
local function onPushAncestralWaitAccess(dict)
	local data = dictToLuaTable(dict)
	BattlefieldController.getInstance():pushAncestralWaitAccess(data)
end
	
-- 【Awen】先祖战场：所有人信息
local function onPushAncestralAllInfo(dict)
	local data = dictToLuaTable(dict)
	BattlefieldController.getInstance():pushAncestralAllInfo(data)
end

-- 【Awen】先祖战场：更新玩家积分
local function onPushAncestralUserScore(dict)
	local data = dictToLuaTable(dict)
	BattlefieldController.getInstance():pushAncestralUserScore(data)
end

-- 【Awen】先祖战场：更新玩家血量
local function onPushAncestralUserHp(dict)
	local data = dictToLuaTable(dict)
	BattlefieldController.getInstance():pushAncestralUserHp(data)
end

-- 【Awen】先祖战场：更新玩家击杀数
local function onPushAncestralUserKill(dict)
	local data = dictToLuaTable(dict)
	BattlefieldController.getInstance():pushAncestralUserKill(data)
end

-- 【Awen】先祖战场：推送奖励
local function onPushAncestralReware(dict)
	local data = dictToLuaTable(dict)
	BattlefieldController.getInstance():pushAncestralReward(data)
end

-- 【Awen】先祖战场：即将燃烧的区域
local function onPushAncestralFireArea(dict)
	local data = dictToLuaTable(dict)
	BattlefieldController.getInstance():pushAncestralFireArea(data)
end

-- 【Awen】先祖战场：击杀信息
local function onPushAncestralKillInfo(dict)
	local data = dictToLuaTable(dict)
	BattlefieldController.getInstance():pushAncestralKillInfo(data)
end

-- 【Awen】先祖战场：同步point
local function onPushAncestralSynPoint(dict)
	local data = dictToLuaTable(dict)
	BattlefieldController.getInstance():pushAncestralSynPoint(data)
end

-- 【Awen】先祖战场：同步当前存活数
local function onPushAncestralSynLive(dict)
	local data = dictToLuaTable(dict)
	BattlefieldController.getInstance():pushAncestralSynLive(data)
end

-- 【Awen】先祖战场：结算
local function onPushAncestralResult(dict)
	local data = dictToLuaTable(dict)
	BattlefieldController.getInstance():pushAncestralResult(data)
end
--hxq 王者归来活动开启
local function onPushKingReturnState( dict )
	local data = dictToLuaTable(dict)
	ToNewServerController.getInstance():pushKingReturnState(data)
end

-- 【Awen】先祖战场：boss数据
local function onPushAncestralBossData(dict)
	local data = dictToLuaTable(dict)
	BattlefieldController.getInstance():pushAncestralBossData(data)
end

-- 【Awen】先祖战场：boss增益
local function onPushAncestralBossBuff(dict)
	local data = dictToLuaTable(dict)
	BattlefieldController.getInstance():pushAncestralBossBuff(data)
end

local function onRefreshVipInfo( dict )
	if dict and dict:objectForKey("vip") then
		local vipInfo = dictToLuaTable(dict:objectForKey("vip"))
		dump(vipInfo, "dsfgdfhgfghfgh")
		local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
		playerInfo:setProperty("vipPoints", tonumber(vipInfo.score))
		playerInfo:setProperty("vipEndTime", tonumber(vipInfo.vipEndTime))
		playerInfo:setProperty("nextDayLoginVipReward", tonumber(vipInfo.nextDayScore))
		playerInfo:setProperty("consecutiveLoginDays", tonumber(vipInfo.loginDays))
		playerInfo:setProperty("SVIPPoint",tonumber(vipInfo.spoint))
		playerInfo:setProperty("SVIPLevel",tonumber(vipInfo.slevel))
		playerInfo:setProperty("svipShop_level", tonumber(vipInfo.shop_level))
		playerInfo:setProperty("svipShop_exp", tonumber(vipInfo.shop_exp))
		CCSafeNotificationCenter:postNotification("vip.refresh")
	end
end

local function onPushMiracleSpeState(dict)
	CCSafeNotificationCenter:postNotification("MiracleDetailView:updateSpeState", dict)
end

-- 虚空战场攻击时VS信息
local function onPushVoidBattlefieldVSInfo(dict)
	local data = dictToLuaTable(dict)
	VoidBattlefieldController.getInstance():pushVoidBattlefieldVSInfo(data)
end

local function onPushTransferApply(dict)
	local data = dictToLuaTable(dict)
	dump(data, "onPushTransferApply")
	require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance():joinSuccess(data)
end

local function onPushAormationItemInfo(dict)
	local data = dictToLuaTable(dict)
	TacticalDepController.getInstance():getPushData(1,data)
end

local function onPushAormationMarch(dict)
	local data = dictToLuaTable(dict)
	TacticalDepController.getInstance():getPushData(2,data)
end

local function onPushAormationReturn(dict)
	local data = dictToLuaTable(dict)
	TacticalDepController.getInstance():getPushData(3,data)
end

local function onPushEquipmentStrength(dict)
	local data = dictToLuaTable(dict)
	dump(data, "onPushEquipmentStrength")
	EquipmentController:call("getInstance"):strengthPerfectEquip(data)
end

local function onPushKillMonsterBuff(dict)
	dump("onPushKillMonsterBuff")
	CCSafeNotificationCenter:postNotification("MSG_kill_monster_buff", dict)
end

local function onPushMonthlyCardsExtra(dict)
	local data = dictToLuaTable(dict)
	dump(data, "onPushMonthlyCardsExtra")
	MonthCardController.getInstance():updateExtraData(data)
end

local function onPushNewSerActTipsNum(dict)
	local data = dictToLuaTable(dict)
	dump(data,"onPushNewSerActTipsNum data is ")
	require('game.WelfareIntegrate.kingRoad.KingRoadController').getInstance():setPushTipsNum(data)
	require("game.WelfareIntegrate.advancedRoad.advancedRoadController").getInstance():setPushTipsNum(data)
end

local function onPushBindResult( dict )
	local data = dictToLuaTable(dict)
	dump(data, "onPushBindResult")
	if data.resultCode then
		if data.resultCode == "100" then 
			CCCommonUtilsForLua:call("flyHint", "", "", _lang("105290"))-- 105290=绑定成功
		elseif data.resultCode == "101" then

		elseif data.resultCode == "102" then -- 您已经被其他玩家绑定了，不能再绑定其他玩家
			CCCommonUtilsForLua:call("flyHint", "", "", _lang("9700311"))
		elseif data.resultCode == "103" then -- 目标玩家已经被太多玩家绑定了，换个人试试
			CCCommonUtilsForLua:call("flyHint", "", "", _lang("9700312"))
		elseif data.resultCode == "104" then -- 已绑定
			CCCommonUtilsForLua:call("flyHint", "", "", _lang("149505"))
		end
	end
end

local function onPushArmyUpdate( dict )
	local armyData = dictToLuaTable(dict)
	local armyInfo = armyData.armyInfo or {}
	-- armyId|string|兵种id
	-- num|int|兵种数量
	dump(armyInfo,"hxq armyInfo is ")
	if #armyInfo > 0 then
		local _armylist = GlobalData:call("shared"):getProperty("armyList") 
		for k,v in pairs(armyInfo) do
			local _armyInfo = _armylist[v.armyId]
			if _armyInfo then
				_armyInfo:setProperty("free", tonumber(v.num))
			end
		end
	end
end

local function onPushCOSSoldire(dict)
	COSDataController.getInstance():getPushData(dict)
end

local function onPushDBScore(dict)
	local data = dictToLuaTable(dict)
	dump(data, "onPushDBScore")
	require("game.dragonBattle.DragonBattleOBController").getInstance():refreshScore(data)
	CCSafeNotificationCenter:postNotification("db.score.change", dict)
end

local function onPushDBOBMarch(dict)
	local data = dictToLuaTable(dict)
	dump(data, "onPushDBOBMarch")
	require("game.dragonBattle.DragonBattleOBController").getInstance():refreshMarch(data)
end

local function onPushDBOBBuild(dict)
	local data = dictToLuaTable(dict)
	dump(data, "onPushDBOBBuild")
	require("game.dragonBattle.DragonBattleOBController").getInstance():refreshBuild(data)
end

local function onPushDBOBTrans(dict)
	local data = dictToLuaTable(dict)
	dump(data, "onPushDBOBTrans")
	require("game.dragonBattle.DragonBattleOBController").getInstance():refreshTrans(data)
end

local function onPushDBOBMember(dict)
	local data = dictToLuaTable(dict)
	dump(data, "onPushDBOBMember")
	require("game.dragonBattle.DragonBattleOBController").getInstance():refreshMember(data)
end

local function onPushDBOBMass(dict)
	local data = dictToLuaTable(dict)
	dump(data, "onPushDBOBMass")
	require("game.dragonBattle.DragonBattleOBController").getInstance():refreshMass(data)
end

local function onPushRunActBox(dict)
	local data = dictToLuaTable(dict)
	require("game.activity.RunningRingAct.RunningRingActController").getInstance():processFlyHint(data)
end

local function onPushAllianceBossAct(dict)
	local data = dictToLuaTable(dict)
	dump(data, "onPushAllianceBossAct")
	require("game.controller.ActBossController").getInstance():refreshData(data)
end

local function onPushBattlePassNewTaskFinish(dict)
   
    --更新battlepass任务小红点
     CCSafeNotificationCenter:postNotification("FestivalActivitiesBattlePassIconRedDot_refresh",dict)
end


local function onPushFavorabilityScore(dict)
	local data = dictToLuaTable(dict)
	dump(data, "onPushFavorabilityScore")
	data.infoDic = {}
	data.infoDic.activityId = data.activityId
	require("game.FestivalActivities.Favorability.FavorabilityController").getInstance():parseData(data)
end

function onPushHandler.onPushAddEquip(dict)
	local equipArr = dict:objectForKey("equip")
    if equipArr then
        EquipmentController:call("addEquip", equipArr)
    end
end

--竞技场货币变化
local function onPushLadderCoin(dict)
	local data = dictToLuaTable(dict)
	dump(data, "onPushLadderCoin")
	if data.remain then
		local res = {}
		res.curCoin = data.remain
		TournamentControllerInst:refreshRaceData(res)
		CCSafeNotificationCenter:postNotification("ladder_data_change")
	end
end

--竞技场Buf变化
local function onPushLadderBuf(dict)
	local skillBuffArr = dict:objectForKey("skillBuffArr")
	if skillBuffArr then
		local buffArr = arrayToLuaTable(skillBuffArr)
		dump(buffArr, "onPushLadderBuf")
		TournamentControllerInst:updateBuffMap(buffArr)
	end
end

function onPushHandler.onPushOpenDoor(dict)
	require("game.FestivalActivities.FestivalActKingdomTransController").getInstance():parsePushInfo(dict)
end

local function onPushTanchuang(dict)
	local data = dictToLuaTable(dict)
	dump(data, "onPushTanchuang")
	if data.tanchuangObj then
		require("game.PropaPopup.PropaPopupController").getInstance():enQueue(data.tanchuangObj)
	end
end
------------------------------------------------------------------
-- all function *MUST* defined forward!!!
-- 增加的一个事件映射表。
local g_pushBaseEventTable = 
{
	-- system
	["push.general.info"] = onUpdate_HeroInfo,
	["push.general.prison"] = onUpdate_HeroPrisonInfo,
	["push.sub.effect.user"] = onGetPushEffectUser,
	["push.server.action"] = TriggerEventUtils.handleEvent,
	["push.overlap.status"] = TriggerEventUtils.handleOverLap,
	["push.city.status"] = TriggerEventUtils.handleWorldCityAvatar,
	["push.associate.info"] = onGetPushAssociateInfo,
	["push.user.neutral.info"] = onUpdateNeutralLandInfo,
	-- ["push.world.march.win"] = require("game.push.WorldMarchWinPush"),
	["push.user.gold"] = require("game.push.userGoldPush"),
	["push.world.building"] = onUpdateNeutralLandMiracleInfo,
	["push.arena.state"] = onPushArenaState,
	["push.arena.score"] = onPushArenaScore,
	["push.weakness.receive"] = onUpdateNewArmyWeakInfo,
	["push.story.task.complete"] = onChapterTaskStatusChanged,
	["push.gemeral.useskill.equip"] = on_CutEquipTime,
	["push.daily.task.complete"] = onDailyTashCompletePush,
	-- ["push.throne.occupy.change"] = onRefreshThroneRank,
	["push.throne.occupy.change"] = onThroneOccupyChange,
	["push.user.crystalGold"] = onSetCrystalGold,
	["push.science.quickUpgrade"] = onQuickUpgradeComplete_Science,
	["push.building.quickUpgrade"] = onQuickUpgradeComplete_Building,
	["push.military.buf"] = onPushMilitaryBuf,
	["push.crossThrone.occupy.change"] = onCrossThroneOccupyChange,
	["push.auction"] = onAuctionGivePricePushBack,         --拍卖行出价返回
	["push.add.price"] = onAuctionAddPricePushBack,        --拍卖行加价返回
	["push.auction.replace"] = onAuctionMyPriceIsReplaced, --拍卖行自己的最高价被超越
	["push.auction.list"] = onAuctionListViewDataChanged,  --拍卖行列表数据变化
	["push.decision"] = onAuctionListViewDataChanged,	   --一口价消息返回
	["push.auction.global"] = onGlobalAuctionDataChangedPushBack,  			--全服拍卖数据变化
	["push.auction.replace.global"] = onGlobalAuctionPriceReplaced,			--全服拍卖价格被超越
	["push.act.notice"] = onPushFestivalActivitTips, --活动推送
	["push.territory.hospital.create"] = onTerritoryHospitalCreate,
	["push.territory.hospital.update"] = onTerritoryHospitalUpdate,  --
	["push.territory.hospital.cancel"] = onTerritoryHospitalCancel,  --
	["push.alliance.hospital.treat"] = onAllianceHospitalTreated,  --
	["push.effects"] = onPushEffects, --作用号变化推送
	["push.bounty.task.complete"] = onPushAllianceLengendComplete, -- 当前联盟传奇任务完成
	["push.artillery.damage"] = onPushArtilleryDamage, --大炮破坏值改变
	["push.artillery.change"] = onPushArtilleryChange, --大炮数量改变
	["push.artillery.status"] = onPushArtillryStatus, --大炮所受状态推送
	["push.artillery.city.defence"] = onPushArtilleryCityDefense, --大炮打城防推送
	["push.civiMiracle.allianceStar"] = onPushAllianceStar, --联盟星盘等级升级推送  
	["push.civiMiracle.finish"] = onPushCiviMiracleFinish, --文明奇迹建成
	["push.alliance.civi.effect"] = onPushAllianceCiviEffect, --文明奇迹技能作用号推送
	["push.alliance.civi.join"] = onPushAllianceCiviJoin, --加入联盟同步技能还有作用号
	["push.alliance.civi.pers.skill"] = onPushCiviPerSkill, --点亮文明星盘个人技能同步技能信息
	["push.civiMiracle.recommend"] = onPushCiviMiracleRecommend, --星盘推荐推送
	["push.dragontalent.points"] = onPushDragonTalentPoints, --龙天赋点数
	["push.treasure.fam.change"] = pushTreasureFamChange, 
	["push.treasure.fam.end.time"] = pushTreasureFamColllectTimeChanged, 
	["push.ancient.army.change"] = onPushAncientArmyChange,
	["push.allianceboss.win"] = onPushAllianceBossDead,
	["push.allianceboss.open"] = onPushAllianceBossOpen,
	--大王战建筑开关推送
	["push.crossthrone.switch"] = onPushCrossThroneSwitch,
	-- 英雄技能
	['push.hospital'] = onPushHeroSkillHospital,		-- 英雄技能【斩草】：单人攻城胜利可以使敌方急救帐篷内8%的伤兵死亡
	["push.get.monthly.fund"] = onPushMonthFund, 
	["push.exchange.pop.change"] = onPushLiBaoPopValue, --礼包pop值变化 
	["push.win.gift.charge"] = onDuoBaoLiBaoTooMuch, 	--夺宝冲礼包跨阶段 
	["push.kingdomBattleTeam"] = pushKingdomBattleTeam, --王国集结推送数据
    ["push.box.science"] = pushBoxScience,

	-- 【Awen】活动排行榜数据
	['push_trigger_rank'] = onPushTriggerRank,
	-- 【Awen】更新龙技能状态
	['push.dragon.talent.skill.state'] = onPushDragonSkillState,
	-- 【Awen】更新文明堡垒占领信息
	['push.civiCastle.occupy'] = onPushCivOccupy,
	-- 【Awen】文明堡垒状态
	['push.civi.castle.status'] = onPushCivStatus,
	--------------------------------------- 
	-- 【Awen】先祖战场：等待确认参战
	['push.ancestrial.wait.confirm'] = onPushAncestralWaitConfirm,
	-- 【Awen】先祖战场：确认参战人数
	['push.ancestrial.confirm.count'] = onPushAncestralConfirmCount,
	-- 【Awen】先祖战场：等待进入战场
	['push.ancestrial.wait.access'] = onPushAncestralWaitAccess,
	-- 【Awen】先祖战场：所有人信息
	['push.ancestrial.allinfo'] = onPushAncestralAllInfo,
	-- 【Awen】先祖战场：更新玩家积分
	['push.ancestrial.score'] = onPushAncestralUserScore,
	-- 【Awen】先祖战场：更新玩家血量
	['push.ancestrial.hp'] = onPushAncestralUserHp,
	-- 【Awen】先祖战场：更新玩家击杀数
	['push.ancestrial.kill'] = onPushAncestralUserKill,
	-- 【Awen】先祖战场：推送奖励
	['push.ancestrial.reward'] = onPushAncestralReware,
	-- 【Awen】先祖战场：即将燃烧的区域
	['push.ancestrial.firearea'] = onPushAncestralFireArea,
	-- 【Awen】先祖战场：击杀信息
	['push.ancestrial.killinfo'] = onPushAncestralKillInfo,
	-- 【Awen】先祖战场：同步point
	['push.ancestrial.move'] = onPushAncestralSynPoint,
	-- 【Awen】先祖战场：同步当前存活数
	['push.ancestrial.live'] = onPushAncestralSynLive,
	-- 【Awen】先祖战场：结算
	['push.ancestrial.finish'] = onPushAncestralResult,
	--hxq 王者归来活动：活动开始
	['push.lucky.return.state'] = onPushKingReturnState,
	-- 【Awen】先祖战场：精英boss数据
	['push.ancestrial.monster'] = onPushAncestralBossData,
	-- 【Awen】先祖战场：精英boss增益
	['push.ancestrial.bossBuff'] = onPushAncestralBossBuff,
	-- 刷新vip信息
	["push.vip.score.new"] = onRefreshVipInfo,
	-- 矿脉特殊状态
	["push.miracle.speState"] = onPushMiracleSpeState,
	-- 虚空战场攻击时VS信息
	['push.vcant.attack'] = onPushVoidBattlefieldVSInfo,

	-- 加入转服联盟成功
	["push.transfer.apply"] = onPushTransferApply,

	--阵法研习成功
	["push.aormation.change"] = onPushAormationItemInfo,
	--阵法出征
	["push.aormation.march"] = onPushAormationMarch,
	--阵法出征回归
	["push.aormation.march.return"] = onPushAormationReturn,
	-- 装备强化跑马灯推送
	["push.equipment.strength"] = onPushEquipmentStrength,
	-- 急速杀怪buff变化推送
	["push.buff.level.up"] = onPushKillMonsterBuff,
	-- 月卡等级相关信息改变
	["push.monthLyCards.extra"] = onPushMonthlyCardsExtra,
	--新服活动任务角标推送处理
	["push_open_server_task_finish"] = onPushNewSerActTipsNum,
	-- 呼朋唤友绑定结果推送
	["push.bind.result"] = onPushBindResult,
	--校场士兵数量推送处理
	["push.army.update"] = onPushArmyUpdate,
	--士兵消耗活动推送
	["push.consume.soldier.num"] = onPushCOSSoldire,

	--巨龙积分变化
	["push.db.score.change"] = onPushDBScore,
	--巨龙OB的积分变化
	["push.ob.score.change"] = onPushDBScore,
	--巨龙ob数据推送
	["push.ob.dragonbattle.march"] = onPushDBOBMarch,
	["push.ob.dragonbattle.build"] = onPushDBOBBuild,
	["push.ob.dragonbattle.moveport"] = onPushDBOBTrans,
	["push.ob.dragonbattle.member"] = onPushDBOBMember,
	["push.ob.dragonbattle.supermass"] = onPushDBOBMass,
	--跑环5星宝藏推送
	["push_treasure_chip_star_box"]	= onPushRunActBox,
	["push.ob.dragonbattle.supermass"] = onPushDBOBMass,	
	["push.alliance.boss.attact"] = onPushAllianceBossAct,
     ---新battlepass完成任务推送
	["push_battle_pass_task_finish"] = onPushBattlePassNewTaskFinish,
	--好感度积分推送
	["push.user.activity.score"] = onPushFavorabilityScore,
	["push.add.equip"] = onPushHandler.onPushAddEquip,
	--竞技场
	["push.ladder.coin"] = onPushLadderCoin,
	["push.ladder.buf"] = onPushLadderBuf,
	--传送门开启push
	["push.open.door"] = onPushHandler.onPushOpenDoor,
	--游戏宣传推送
	["push.tanchuang"] = onPushTanchuang,
}

function onPushBaseEvent(eventID, data)
	dump(data, "onPushBaseEvent: " .. eventID)
	if g_pushBaseEventTable[eventID] then
		g_pushBaseEventTable[eventID](data)
	end
end
