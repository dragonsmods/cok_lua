require ("utils.utils")

guiCommonGlobal = guiCommonGlobal or {}
local guiCommonLocal = {}

print("LUA_DEBUG = ? ", LUA_DEBUG)
function MyPrint( ... )
    if 1 == LUA_DEBUG then
    	print(...)
    end
end

myRequire = myRequire or function ( path )
	if 1 == LUA_DEBUG then
		package.loaded[path] = nil
	end
	return require(path)
end
-- 模仿C的函数建立get和set函数
function CC_SYNTHESIZE(owner, name, funName)
    local function get(self)
        return self[name] or 0
    end

    local function set(self, data)
        self[name] = data
    end
    owner["set"..funName] = set
    owner["get"..funName] = get
end

local __purge_ctrl_arr__ = {}

--this function need before initLib
function guiCommonGlobal.controllerAutoPurge( ins )
	if not table.findVar(__purge_ctrl_arr__,ins) then
		table.insert(__purge_ctrl_arr__,ins)
	end
end

require("game.utility.gameConst")
require("debugSign")
require("initLib")
require("game.utility.utilityFunc")
require("game.utility.gameCommonFunc")
require("guiCommon2")

-- 随机数
math.randomseed(tostring(os.time()):reverse():sub(1, 7))
local Dprint = Dprint
local Drequire = Drequire
local table = table

Cocos_iPhoneXBottomSpace = GlobalConfig:call("shared"):getProperty("iPhoneXBottomSpace")

function __FILE__() return debug.getinfo(2, 'S').source end
function __LINE__() return debug.getinfo(2, 'l').currentline end
function __FUNC__() 
	--return "fire function: " .. debug.getinfo(2, "n").name
	return ""
end
------------------------------------------------------------------
------------------------------------------------------------------
------------------------------------------------------------------

local tmpEntry;
function guiCommonLocal.requestgamedo()


     local dic1 = CCDictionary:create()
     dic1:setObject(CCString:create("33"), "type")

     dic1:setObject(CCString:create("param"), "param")

    CCSafeNotificationCenter:call("postNotification", "SpecialNotice", dic1)

    local scheduler = cc.Director:getInstance():getScheduler()
    scheduler:unscheduleScriptEntry(tmpEntry)
 
end



function guiCommonLocal.gameDo()
	MyPrint("gameDo ... ")
	local ccud = cc.UserDefault:getInstance()

	ccud:setIntegerForKey("cn_force_pl", 1)
	ccud:flush()
	local analyticId = GlobalDataCtr.getAnalyticID();

	print("zhangyuemeng  game do"..analyticId)

 	tmpEntry = cc.Director:getInstance():getScheduler():scheduleScriptFunc( requestgamedo , 1.0, false)
end


function guiCommonLocal.onInitConfigData(dict)
	-- dict 过大，切莫直接转table
	DragonManager.initDragonDataConfig(dict)
	LiBaoController.getInstance():initConfigData(dict)
	EggController:getInstance():initConfigData(dict)

	-- 初始化文明类
	CivilizationController:initConfigData(dict)	

	--初始化装备
	EquipmentController:initConfigData(dict)
	CivFortressController:initConfigData(dict)
	CivFortress2Controller:initConfigData(dict)
	NeutralLandManager.initConfigData(dict)
	AllianceLegendManager:initConfigData(dict)
	NewKingdomWarController:initConfigData(dict)
	TreasureFamManager:initConfigData(dict)
	ToNewServerController.getInstance():initConfig(dict)
	--批量开启宝箱的最大值
	local treasure_box_max = dict:objectForKey("treasure_box_max")
	if treasure_box_max then 
		local tbl = dictToLuaTable(treasure_box_max)
		local maxNum = tonumber(tbl.k1)
		require("game.generalTreasureBox.GeneralTreasureBoxController").setMaxBatchOpenCount(maxNum)
		dump(maxNum,"maxNum++++++")
	end

	--批量开启宝箱的最大值
	local sign_monthly = dict:objectForKey("sign_monthly")
	if sign_monthly then 
		local tbl = dictToLuaTable(sign_monthly)
		dump(tbl, "sign_monthly")
		require('game.WelfareIntegrate.signIn.integrateSignInController').initItemConfig(tbl)
	end

	--鲜花榜2期
	local flower_charm = dict:valueForKey("flower_charm"):intValue()
	if flower_charm then 
		dump(flower_charm,"has flower_charm+++")
		require("game.player.FlowerDataController").initFlowerCharm(flower_charm)
	end

	--夺宝活动
	local win_super_gift = dict:objectForKey("win_super_gift")
	if win_super_gift then 
		DuoBaoActivityController:initItemConfig(win_super_gift)
	end
    MonthCardController.getInstance():initDataConfig(dict)
    FuMoController:initConfigData(dict)
    require("game.WelfareIntegrate.creatorHero.CreatorHeroController").getInstance():initConfigData(dict)
    require("game.activity.DiamonDiscount.DiamondDiscountController").getInstance():initConfigData(dict)
    require("game.FestivalActivities.FestivalActivitiesMakexxxController").getInstance():initConfigData(dict)
	--付费转服
	require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance():initConfig(dict)
	--【Awen】流亡者之塔
	require("game.revive2.ReviveController").getInstance():initConfig(dict)
end

-- 处理释放controller操作
function guiCommonLocal.onPurge_Controller(dict)
	MyPrint(__FUNC__())

	LuaCmdController.purge()
	
	NpcController.purge()
	
	AvatarController.purge()

	ImperialSceneLuaManager.purge()

	HeroManager.purge()

	MagicManager.purge()
	
	OneKeyBuffManager.purge()

	LuaActivityController.purge()

	LiBaoController.getInstance():purge()

	HighTechController.purge()
	RecallController.purge()

	require("game.mirro.MirroSelectManager")
	MirroSelectManager.purge()

	UiCompoentControoller.purge()

	require("game.updateAnnouncement.UpdateAnnounceManager")
	UpdateAnnounceManager.purge()

	if nil ~= NDaysQuestController then
		NDaysQuestController.purge()
	end

	NeutralLandManager.purge()
	ActivityController.getInstance():purge()

	local firstPopController = require("game.activity.firstPop.firstPopController")
	firstPopController.purge()

	MonthCardController.purge()
	
	MergeServerManager.purge()
	DragonActiveSkillManager.purge()
	ToolController:purge()
	FavoriteListController.purge()
	FangJianBeiEffectMgr.purge()

	FortressController.purge()

	if QuickEquipmentController then
		QuickEquipmentController.purge()
	end

	if AllianceBossController then
		AllianceBossController.purge()
	end

	-- if AllianceDailyController then
	-- 	AllianceDailyController.purge()
	-- end
	

	require("game.deviceAccount.DeviceAccountManager").purge()
	require("game.dailyActivity.DailyActivityManager").purge()
	require("game.dragonWorldCup.DragonWorldCupManager").purge()
	if DailyTaskController then
		DailyTaskController.purge()
	end
	GrowthFundController:purge()
	if GoldVowController then
		GoldVowController:purge()
	end

	require("game.crossThrone.CrossThroneManager"):purge()

	PlayerInfoController:purge()
	require("game.worldLevel.WorldLevelManager").purge()
	require("game.crown.CrownManager").purge()

	FeedBackController:purge()
	KnightController.purge()

	require("game.artillery.ArtilleryManager").purge()
	require("game.allianceTerritory.civiMiracle.CiviMiracleManager").purge()

	-- 【awen】清空英雄图鉴作用号数据
	require("game.hero.NewUI_v2.HeroBuffManager"):purge()
	-- 【awen】清空士兵进阶item数据
	require("game.army.ArmyController"):purge()
	-- 【awen】清空装扮图鉴作用号数据
	DressIntroductionController:purge()
	-- 【Awen】清空王者之路数据
	require('game.WelfareIntegrate.kingRoad.KingRoadController').getInstance():purge()

	require("game.crossThrone.CrossServerBattleManager"):purge()
	require("game.hero.HeroSkinManager").getInstance():purge()
	require("game.FestivalActivities.FestivalActivitiesController").getInstance():pureData()
	require("game.activity.RunningRingAct.RunningRingActController").getInstance():pureData()
	require("game.flyHint.FlyHintManager").getManager():purge()
	require("game.CommonPopup.RankActComponent.RankActDataController").getInstance():pureData()
	require("game.dragonBattle.DragonBattleOBController").getInstance():purge()
	DragonWarmUpManager:purge()
	UserSettingController.purge()
	-- ActBossControllerInst:purge()
	-- ActivityCalendarCtrlInst:purge()
	table.walk(__purge_ctrl_arr__,function ( v )
		v:purge()
	end)
	ToNewServerController.getInstance().purge()
	require("game.WelfareIntegrate.signIn.integrateSignInController").purge()
	require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance():purge()
	TournamentControllerInst:purge()
	require("game.PropaPopup.PropaPopupController").getInstance():purge()
	return true
end 

--联盟签到
function guiCommonLocal.openAllianceSignHelpView()
	local lua_path = "game.allianceSignHelp.allianceSignHelpView"
    local view = Drequire(lua_path):create()
    PopupViewController:addPopupView(view)
end

--魔镜道具
function guiCommonLocal.onOpen_MirroSelectView()
	MyPrint(__FUNC__())
	local MirroSelectManager = require("game.mirro.MirroSelectManager")
	if MirroSelectManager == nil then
		return
	end

	if MirroSelectManager.mirroFindCount >= MirroSelectManager.mirroMaxUseTime then
		CCCommonUtilsForLua:call("flyText", getLang("104745"))
		return
	end

	local mainCityLv = FunBuildController:call("getMainCityLv")
	if mainCityLv < MirroSelectManager.getMinUnlockLevel() then
		CCCommonUtilsForLua:call("flyText", getLang("104744", tostring(MirroSelectManager.getMinUnlockLevel())))
		return
	end

	local lua_path = "game.mirro.MirroSelectView"
	package.loaded[lua_path] = nil
	require(lua_path)
	PopupViewController:addPopupView(MirroSelectView:create())
end

--中立地带选择矿区弹出框
function guiCommonLocal.onOpen_NeurtalSelectPopUpView(dict)
	MyPrint(__FUNC__())
	local lua_path = "game.NeutralLand.NeutralSelectPopUpView"
    package.loaded[lua_path] = nil
    require(lua_path)
    PopupViewController:addPopupView(NeutralSelectPopUpView:create(dict.serveId))
end

--中立地带积分排行榜
function guiCommonLocal.onOpen_WorldMineRankView(dict)
	MyPrint(__FUNC__())
    local WorldMineRankView = Drequire("game.city.WorldMineRankView")
    local view = WorldMineRankView:create()
    PopupViewController:addPopupInView(view, true)
end

--商队兑换
function guiCommonLocal.onOpen_MerchantExchangeView()
	MyPrint(__FUNC__())	
	local lua_path = "game.merchantExchange.MerchantExchangeView"
	package.loaded[lua_path] = nil
	require(lua_path)
	PopupViewController:addPopupView(MerchantExchangeView:create())
end

--博客
function guiCommonLocal.onOpen_BlogView()
	MyPrint(__FUNC__())
	local lua_path = "game.blog.BlogView"
	package.loaded[lua_path] = nil
	require(lua_path)
	PopupViewController:addPopupInView(BlogView:create())
end

--背包兑换
function guiCommonLocal.onOpen_BagExchangeView(dict)
	MyPrint(__FUNC__())
	local lua_path = "game.store.BagExchangeView"
	package.loaded[lua_path] = nil
	require(lua_path)
	local itemId = dict["itemId"]
	PopupViewController:addPopupInView(BagExchangeView:create(itemId))
end

--远征
function guiCommonLocal.onOpen_KingdomThroneQuestView()
	MyPrint(__FUNC__())
	local lua_path = "game.kingdomThrone.KingdomThroneQuestView"
	package.loaded[lua_path] = nil
	require(lua_path)
	PopupViewController:addPopupInView(KingdomThroneQuestView:create())
end

-- 英雄界面
function guiCommonLocal.onOpen_HeroMainView()
	MyPrint(__FUNC__())
	local lua_path = "game.hero.HeroMainView"
	package.loaded[lua_path] = nil
	require(lua_path)
	HeroMainView:create()
end


function guiCommonLocal.onOpen_HeroGraveView()
	MyPrint(__FUNC__())
	local HeroManager = require("game.hero.HeroManager")
	local flag = false
	for k,v in pairs(HeroManager.getHeroInfo()) do
		if v.state == HeroState.Dead then
			flag = true
			break
		end
	end
	if flag then
		local lua_path = "game.hero.HeroGraveView"
		package.loaded[lua_path] = nil
		require(lua_path)
		HeroGraveView:create("53500")
	else
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("164934"))
	end
end


-- 英雄监狱界面
function guiCommonLocal.onOpen_HeroPrisonView()
	MyPrint(__FUNC__())
	local HeroManager = require("game.hero.HeroManager")
	local prisonInfo = HeroManager.getPrisonerInfo()
	if table_is_empty(prisonInfo) then
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("164933"))
	else
		local lua_path = "game.hero.HeroPrisonView"
		package.loaded[lua_path] = nil
		require(lua_path)
		HeroPrisonView:create()
	end
end

-- 新版英雄列表入口
function guiCommonLocal.onOpen_NewHeroListView(dict)
	local lua_path = "game.hero.NewUI_v2.HeroListView"
	package.loaded[lua_path] = nil
	local view = require(lua_path):create(tonumber(dict.entrance))
	PopupViewController:call("addPopupInView", view)
end

-- 英雄扫荡入口
function guiCommonLocal.onOpen_NewHeroCleanView()
	local lua_path = "game.hero.NewHeroClean.HeroTowerCleanPopupView"
    package.loaded[lua_path] = nil
    local view = require(lua_path):create()
    PopupViewController:addPopupView(view)
end



-- 城防界面
function guiCommonLocal.onOpen_LuaCityDefenseView(dict)
	MyPrint(__FUNC__())
	local lua_path = "game.cityDefense.LuaCityDefenseView"
	package.loaded[lua_path] = nil
	require(lua_path)
	LuaCityDefenseView:create(dict)
	return true
end

-- 建筑升星界面
function guiCommonLocal.onOpen_UpstarView(dict)
	MyPrint(__FUNC__())
	local lua_path = "game.buildingUpView.UpStarView"
	package.loaded[lua_path] = nil
	require(lua_path)
	UpStarView:create(dict)
	return true
end

-- 宝箱抽奖界面
function guiCommonLocal.onOpen_GeneralTreasureBoxView(dict)
	MyPrint(__FUNC__())
	local lua_path = "game.generalTreasureBox.GeneralTreasureBoxView"
	package.loaded[lua_path] = nil
	require(lua_path)
	GeneralTreasureBoxView:create(dict)
	return true
end

-- 宝箱抽奖界面
function guiCommonLocal.on_open_GeneralTreasureBoxView_from_luckyday(dict)
	MyPrint(__FUNC__())

	local itemId = dict["itemId"]
	local tinfo = ToolController:call("getToolInfoForLua", itemId)
	if nil == tinfo then
		return false
	end

	-- 
	if tinfo:call("getCNT") <= 0 then
		local ItemGetMethodView = Drequire("game.CommonPopup.ItemGetMethodView")
		local view = ItemGetMethodView:create(itemId)
		PopupViewController:call("addPopupView", view)
		return true
	else
		local lua_path = "game.generalTreasureBox.GeneralTreasureBoxView"
		package.loaded[lua_path] = nil
		require(lua_path)
		GeneralTreasureBoxView:create(dict)
		return true
	end
end

-- vip宝箱抽奖
function guiCommonLocal.onOpen_VipTreasureBoxView(dict)
	MyPrint(__FUNC__())
	local lua_path = "game.generalTreasureBox.VipTreasureBoxView"
	package.loaded[lua_path] = nil
	local vipBoxView = require(lua_path):create(dict)
	PopupViewController:addPopupInView(vipBoxView, false)
	return true
end

-- vip宝箱分享
function guiCommonLocal.onOpen_VipTreasureBoxShareView(dict)
	MyPrint(__FUNC__())
	local lua_path = "game.generalTreasureBox.VipTreasureBoxShareView"
	require(lua_path)
	VipTreasureBoxShareView:create(dict)
	return true
end

function guiCommonLocal.onOpen_ActivityBankView(dict)
	local lua_path = "game.activity.bank.ActivityBankView"
	package.loaded[lua_path] = nil
	local bank = Drequire(lua_path):create(dict)
	PopupViewController:addPopupInView(bank)
end

g_SerialOpenGoldBox100IsClicked = false --进入客户端第一次点击100连开，即type2
g_SerialOpenGoldBox500IsClicked = false --进入客户端第一次点击500连开，即type3
function guiCommonLocal.onOpen_ActivityGoldBox(dict)
	if isCrossServerNow() then
		LuaController:flyHint("", "", getLang("164891"))   --跨服状态,不能开启
		return
	end
	local lua_path = "game.CommonPopup.GoldBoxView"
    package.loaded[lua_path] = nil
    local view = require(lua_path):create("57153")
    local result = true
    if view == nil then
    	result = false
    else
	    PopupViewController:addPopupInView(view)
    end
    if dict then
	    dict:setObject(CCBool:create(result), "result")
	end
end

function guiCommonLocal.onOpen_GoldBoxEndRank()--黄金宝箱结束后排行榜
	local lua_path = "game.CommonPopup.GoldBoxEndRankView"
    package.loaded[lua_path] = nil
    local view = require(lua_path):create()
    PopupViewController:addPopupInView(view)
end

function guiCommonLocal.onOpen_ConsumeActivityView()
	ActivityController.getInstance():openActUI("57159")
end

function guiCommonLocal.onOpen_NuetralShop()
	local lua_path = "game.NeutralLand.NeutralShop.NeutralShopView"
    package.loaded[lua_path] = nil
    local view = require(lua_path):create()
    PopupViewController:addPopupInView(view)
end

function onPush_initLibao(dict)
	LiBaoController.getInstance():initLibaoData(dict)
end

function guiCommonLocal.on_objForLua_getCurActivityStageAndLeftTime( dict )
 	if nil == dict then
 		return
 	end

 	local obj = dict:objectForKey("obj")
 	if nil == obj then
 		return
 	end

 	if obj.getCurActivityStageAndLeftTime == nil then
 		return
 	end

 	local stage, left = obj:getCurActivityStageAndLeftTime()

 	if nil ~= stage and nil ~= left then
 		dict:setObject(CCString:create(tostring(stage)), "stage")
 		dict:setObject(CCString:create(tostring(left)), "left")
 	end
end

function guiCommonLocal.on_objForLua_getGameTickStr( dict )
	if nil == dict then
		return
	end

	local obj = dict:objectForKey("obj")
	if nil == obj then
		return
	end

	if nil == obj.getGameTickStr then
		return
	end

	local str = obj:getGameTickStr()

	if nil ~= str then
		dict:setObject(CCString:create(tostring(str)), "str")
	end
end

function guiCommonLocal.on_objForLua_requestActivityDetail( obj )
	if nil == obj or nil == obj.requestActivityDetail then
		return
	end
	obj:requestActivityDetail()
end

function guiCommonLocal.on_createActLuaObj( dict )
	MyPrint("on_createActLuaObj")
	if nil == dict then
		return
	end
	local params = dict:objectForKey("params")
	local obj = ActivityController.getInstance():createActObjByParams(params)
	if nil == obj then
		return
	end
	dict:setObject(obj, "obj")
	return
end

-- 英雄驻守
function guiCommonLocal.onOpen_HeroGarrisonView(dict)
	local lua_path = "game.hero.HeroGarrisonView"
	local bank = myRequire(lua_path):create(dict)
	PopupViewController:addPopupInView(bank)
end

-- 巨龙对战列表
function guiCommonLocal.onOpen_DragonBattleListView(dict)
	local lua_path = "game.dragonBattle.DragonBattleListView"
	package.loaded[lua_path] = nil
	local bank = require(lua_path):create(dict)
	PopupViewController:addPopupInView(bank)
end

-- 巨龙OB战报
function guiCommonLocal.onOpen_DragonOBReportView(dict)
	local lua_path = "game.dragonBattle.DragonOBReportView"
	package.loaded[lua_path] = nil
	local bank = require(lua_path):create(dict)
	PopupViewController:addPopupInView(bank)
end


-- 屏蔽人物列表
function guiCommonLocal.onOpen_ShieldUnLockPage(dict)
	MyPrint(__FUNC__())
	local lua_path = "game.CommonPopup.ShieldUnlock.ShieldUnLockView"
	Drequire(lua_path)
	local view = ShieldUnLockView:create()
	PopupViewController:addPopupInView(view, true)
	return true
end

-- 语言选择
function guiCommonLocal.onOpen_LanguageChoosePage(dict)

	MyPrint(__FUNC__())
	-- traceback()
	
	local lua_path = "game.CommonPopup.LanguageSettingView"
	require(lua_path)
	LanguageSettingView:create(dict)
	return true
end

function guiCommonLocal.onOpen_SelectNetView(dict)
	MyPrint(__FUNC__())

	local lua_path = "game.CommonPopup.SelectNetView"
	-- package.loaded[lua_path] = nil
	local SelectNetView = require(lua_path)
	if (SelectNetView.USE_NEW_NET) then
		PopupViewController:addPopupInView(SelectNetView:create(dict))
	end
end

function guiCommonLocal.onOpen_MerchantView(dict)
	MyPrint(__FUNC__())
	local MerchantView = Drequire("game.CommonPopup.Merchant.MerchantView")
	local view = MerchantView:create(dict)
	PopupViewController:addPopupInView(view)

	local isLog = dict["isLog"] ~= nil and true or false --是否打点
	if isLog then
		local LOG_MERCHANT_AVATAR = "logMerchantAvatar"
		LogController:call("getInstance"):call("postEventLog", LOG_MERCHANT_AVATAR)
	end
end

function guiCommonLocal.onOpen_EquipLongjingView(dict)
	-- MyPrint("onOpen_EquipLongjingView | begin")
	local page = dict["enterPage"] ~= nil and dict["enterPage"] or 1
    local useAnim = dict["useAnim"] ~= nil and true or false
    -- print("onOpen_EquipLongjingView page=", page, ", useAnim=", useAnim)
	local EquipLongjingView = Drequire("game.longjing.EquipLongjingView")

	local view = EquipLongjingView:create(page)
	-- MyPrint("onOpen_EquipLongjingView | create, inst=", view)
	if not useAnim then
		PopupViewController:addPopupInView(view)
	else
		PopupViewController:addPopupInView(view, true, useAnim)
	end

	-- MyPrint("onOpen_EquipLongjingView | end")
end

function guiCommonLocal.onOpen_MainCityView(dict)
	MyPrint("onOpen_MainCityView | begin")
	local lua_path = "game.city.MainCityView"
	local MainCityView = Drequire(lua_path)
	MyPrint("onOpen_MainCityView | require")

	local FUN_BUILD_MAIN_CITY_ID = 400000000
	local view = MainCityView:create(FUN_BUILD_MAIN_CITY_ID)
	MyPrint("onOpen_MainCityView | create, inst=", view)
	PopupViewController:addPopupInView(view)

	MyPrint("onOpen_MainCityView | end")
end

function guiCommonLocal.onOpen_AllRankListPopUpView(dict)
	local view = Drequire("game.rank.NewAllRankListView"):create()
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.onOpen_GeneralSkillListPopUpView(dict)
	Dprint("onOpen_GeneralSkillListPopUpView | begin")
	local GeneralSkillListPopUpView = Drequire("game.general.GeneralSkillListPopUpView")
	Dprint("onOpen_GeneralSkillListPopUpView | require")

	local info = dict["info"] --GeneralInfo* 默认：xxx.firstvalue
	local abilityId = dict["abilityId"] --str  默认："50000"
	local skillId = dict["skillId"] --str 默认：""

	if info == nil then
		local generals = GlobalData:call("shared"):getProperty("generals") --map!!
		if table.nums(generals) <= 0 then
			Dprint("onOpen_GeneralSkillListPopUpView | no general!")
			return
		end
		info = table.firstvalue(generals)
	end

	if abilityId == nil then
		abilityId = "50000"
	end

	if skillId == nil then
		skillId = ""
	end

	--最终调用的数据。
	local view = GeneralSkillListPopUpView:create(info, abilityId, skillId)
	Dprint("onOpen_GeneralSkillListPopUpView | create, inst=", view)
	PopupViewController:addPopupInView(view)
	Dprint("onOpen_GeneralSkillListPopUpView | end")
end

--许愿池
function guiCommonLocal.onOpen_SacrificePopUpView(dict)
	Dprint("onOpen_SacrificePopUpView | begin")
	local SacrificePopUpView = Drequire("game.sacrifice.SacrificePopUpView")
	Dprint("onOpen_SacrificePopUpView | require")

	local view = SacrificePopUpView:create()
	Dprint("onOpen_SacrificePopUpView | create, inst=", view)
	PopupViewController:addPopupInView(view)
	Dprint("onOpen_SacrificePopUpView | end")
end
function guiCommonLocal.onOpen_BankMainView(dict)
	-- Dprint("onOpen_BankMainView | begin")
	-- local BankMainView = Drequire("game.Bank.BankMainView")
	-- Dprint("onOpen_BankMainView | require")

	-- local view = BankMainView:create()
	-- Dprint("onOpen_BankMainView | create, inst=", view)
	-- PopupViewController:addPopupView(view)
	-- Dprint("onOpen_BankMainView | end")
	BankController:getInstance():openBankView()
end

function guiCommonLocal.onOpen_ArmedStateView(dict)
	Dprint("onOpen_ArmedStateView | begin")
	local ArmedStateView = Drequire("game.MilitaryRank.ArmedStateView")
	Dprint("onOpen_ArmedStateView | require")

	local view = ArmedStateView:create()
	Dprint("onOpen_ArmedStateView | create, inst=", view)
	PopupViewController:addPopupInView(view)
	Dprint("onOpen_ArmedStateView | end")
end

-- 热卖界面
function guiCommonLocal.onOpen_BigSellView(dict)
	local view = Drequire("game.LiBao.TimeRewardView"):create()
	PopupViewController:addPopupView(view)
	return true
end

-- 热卖界面
function guiCommonLocal.onOpen_GoldExchangeView(dict)
	local lua_path = "game.LiBao.LuaGoldExchangeView"
	package.loaded[lua_path] = nil
	require(lua_path)
	local view = LuaController:comFunc("getSaleViewContainer", 0)
	if nil ~= view then
		local path = dict["2"]
		local params = dict["3"]
		local retFlag = LuaGoldExchangeView:create(view,path,params)
		print("retFlag:"..tostring(retFlag))
		if nil ~= retFlag then
			return true
		end
	end	

	return false
end

-- 
function guiCommonLocal.onOpen_SocialActivityPage(dict)
	MyPrint(__FUNC__())
	local lua_path = "game.CommonPopup.SocialPopUpView"
	require(lua_path)
	SocialPopUpView:create()
	return true
end

--
function onOpen_DragonEffectView( dict )
	MyPrint(__FUNC__())
	local lua_path = "lua_static.game.dragon.dragonEffectView"
	require(lua_path)
	PopupViewController:addPopupView(DragonEffectView:create())
	return true
end

function onOpen_DragonSkillView( dict )
	MyPrint(__FUNC__)
	local lua_path = "game.dragon.DragonSkillView"
	package.loaded[lua_path] = nil
	require(lua_path)
	PopupViewController:addPopupInView(DragonSkillView:create(dict))
	return true
end

function onOpen_DragonPreviewView( dict )
	local lua_path = "game.dragon.DragonPreviewView"
	package.loaded[lua_path] = nil
	require(lua_path)
	PopupViewController:addPopupInView(DragonPreviewView:create(dict))
	return true
end

function onOpen_HeroSkillView( dict )
	MyPrint(__FUNC__())
	local lua_path = "lua_static.game.hero.HeroSkillView"
	package.loaded[lua_path] = nil
	require(lua_path)
	PopupViewController:addPopupInView(HeroSkillView:create())
	return true
end

-- -- 屏蔽刷新
-- function guiCommonLocal.onRefresh_ShieldUnLockPage(dict)
-- 	MyPrint(__FUNC__())
-- 	ShieldUnLockView:setDataList()
-- 	return true
-- end

function guiCommonLocal.onData_init_end(dict)
	dump("onData_init_end ")
	-- 判断是否有银行活动入口
	local ActivityBankController = require("game.activity.bank.ActivityBankController")
	ActivityBankController.getInvestBankState()

	TriggerEventUtils.triggerMonsterProGet( )

	-- 初始化特殊作用号
	CCCommonUtilsForLua.fixFuncCorrelationEffNum()

	functionOpenKeyInit()
	-- 告知UI界面数据初始化完成（最起码是开关初始化完成）
	UiCompoentControoller.setInitData()

	-- 龙主动技能请求数据
	-- DragonActiveSkillManager.getInstance():startRequestData()
	CCSafeNotificationCenter:call("postNotification", "notify_data_init_end")

	--主动刷新一次章节数据 通过数据判断是新用户还是老用户 是否显示章节按钮
	ChapterController:getInstance():sendGetChapterList()
	CivFortressController:initDataEnd()

	local dict = CCDictionary:create() 
    dict:setObject(CCString:create("loadBattleWarDataFinish"), "name")
    LuaController:call("getNotifyInLua", dict)

    FeedBackController:init()
end

function guiCommonLocal.monthCardOrders(array, orders)
	MonthCardController.getInstance():monthCardOrders(orders, array)
end

--------------ZT专用，嘿嘿，避免冲突 Start----------------------
function guiCommonLocal.onOpen_LuaLiBaoController(dict)
	LiBaoController.getInstance():getCurLiBaoMap(dict)
end

function guiCommonLocal.onPush_insertNewLibao(dict)
	LiBaoController.getInstance():insertNewLibao(dict)
end

function guiCommonLocal.onRefresh_LibaoItemData(dict)
	dump(" onRefresh_LibaoItemData ~~~~~~~")
	LiBaoController.getInstance():refreshLibaoItemData(dict)
end
function guiCommonLocal.onUpdate_LibaoItemData(dict)
	dump(" onUpdate_LibaoItemData ~~~~~~~")
	local tbl = dictToLuaTable(dict)
	LiBaoController.getInstance():updateLibaoItemData(tbl, false)
end
function guiCommonLocal.onDelete_LibaoItemData(dict)
	dump(" onDelete_LibaoItemData ~~~~~~~")
	-- local tbl = dictToLuaTable(dict)
	LiBaoController.getInstance():updateLibaoItemData(dict, true)
end

function guiCommonLocal.onNewRefreshExchangeData(dict)
	dump("onNewRefreshExchangeData ~~~~~")
	LiBaoController.getInstance():onNewRefreshExchangeData(dict)
end

function guiCommonLocal.onPush_GiftPopCount(dict )
	dump(dict)
	LiBaoController.getInstance():countPopupItem(dict)
end

function guiCommonLocal.open_SubscribeView(dict)
	local lua_path = "game.LiBao.LuaSubscribeView"
	package.loaded[lua_path] = nil
	local view = require(lua_path):create(dict)
	PopupViewController:addPopupView(view)
end

function guiCommonLocal.open_randomLibao(dict)
	local lua_path = "game.LiBao.RandomLibao"
	package.loaded[lua_path] = nil
	local view = require(lua_path):create(dict)
	PopupViewController:addPopupView(view)
end

function guiCommonLocal.on_open_AvatarView( ... )
	if CCCommonUtilsForLua:isFunOpenByKey("new_avatar_shop") then
		local AvatarViewEx = Drequire("game.avatar.AvatarViewEx")
		local view = AvatarViewEx.create()
		PopupViewController:call("addPopupInView", view)
		return
	end
	myRequire("game.avatar.AvatarView")
	local view = AvatarView.create()
	PopupViewController:call("addPopupInView", view)
end

function guiCommonLocal.on_open_wish_act_view( ... )
	require("game.WishingAct.WishingActView")
	local view = WishingActView.create()
	PopupViewController:call("addPopupView", view)
end

function guiCommonLocal.on_createSuitStoneView( dict )
	if nil == dict then
		return
	end
	require("game.equipment.SuitStoneView")
	local height = dict:objectForKey("height")
	height = tolua.cast(height, "CCInteger")
	height = height:getValue()
	local view = SuitStoneView.create(height)
	if nil ~= view then
		dict:setObject(view, "stoneView")
	end

	return
end

function guiCommonLocal.on_type_zero_tool_click( data )
	local id = data["id"]

	-- 活动id  锤子
	if id == 211276 then
		local tdata = {}
		-- ActivityController:call("shouActUIById", "57127")
		ActivityController.getInstance():shouActUIById("57127")
	else
	end
end

function guiCommonLocal.on_isSpeEffNumConditionOk( dict )
	if nil == dict then
		return
	end

	if nil == dict:objectForKey("num") then
		return
	end

	local num = dict:objectForKey("num"):getValue()

	local ret = CCCommonUtilsForLua.isSpeEffNumConditionOk(num)

	if ret == true then
		dict:setObject(CCString:create("1"), "ret")
	end
end

function guiCommonLocal.on_onClickFlySystem(params)
	MyPrint("on_onClickFlySystem")
	if nil == params then
		return
	end
	local data = dictToLuaTable(params)
	dump(data, "on_onClickFlySystem data")
	if nil == data then
		return
	end
	if nil == data.msgId then
		return
	end
	MyPrint("data.msgId ", data.msgId)
	if data.msgId == "140440" then
		if cc.UserDefault:getInstance():getStringForKey("ACTIVITY_GOLDBOX", "") ~= "1" then
			guiCommonLocal.onOpen_ActivityGoldBox()
		end
	elseif data.msgId == "176361" or data.msgId == "176362" then 
		ActivityController.getInstance():shouActUIById("57273") --夺宝活动
	elseif data.msgId == "176262" or data.msgId == "176256" or data.msgId == "176366" then
		local mainCityLv = FunBuildController:call("getMainCityLv") 
		if mainCityLv >= 6 then
			Drequire("game.dailyActivity.DailyActivityManager").gotoSystem("17") --拍卖行
		end
	elseif data.msgId == "149618" or data.msgId == "149627" then
		ActivityController:call("shouActUIById", "57158")
	elseif data.msgId == "169847" then -- 英雄转盘
	    local prlvPath = "game.hero.NewUI.HeroGetRotateView"
	    local view = Drequire(prlvPath)
	    PopupViewController:call("addPopupInView", view:create("89699","hero_type"))
	elseif data.msgId == "149622" then
		local obj = ActivityController:call("getActObj", "57158")
		MyPrint("hahahahah", obj, obj.centerPoint)
		if obj and obj.centerPoint and obj.centerPoint > 0 then
	  		LuaController:call("gotoWorldTile", obj.centerPoint)
	    end
	elseif data.msgId == "140542" then
		if cc.UserDefault:getInstance():getStringForKey("ACTIVITY_CONSUME", "") ~= "1" then
			guiCommonLocal.onOpen_ConsumeActivityView()
		end
	elseif data.msgId == "176342" then
		if CCCommonUtilsForLua:isFunOpenByKey("hotstore_new") then
			local view = Drequire("game.CommonPopup.Merchant.NewMerchant.NewMerchantView"):create()
    		PopupViewController:addPopupInView(view)
		else
			local MerchantView = Drequire("game.CommonPopup.Merchant.MerchantView")
			local view = MerchantView:create(dict)
			PopupViewController:addPopupInView(view)
			LogController:call("getInstance"):call("postEventLog", "logMerchantAvatar")
		end
		LogController:call("getInstance"):call("postEventLog", "logMerchant")
	elseif data.msgId == "103832" 
		or data.msgId == "103833" 
		or data.msgId == "103834"
		or data.msgId == "103891"
		or data.msgId == "103892"
		or data.msgId == "103893"
		or data.msgId == "151311"
		or data.msgId == "151312"
		or data.msgId == "151313"
		or data.msgId == "151779"
		or data.msgId == "151780"
		or data.msgId == "151781"
		or data.msgId == "152361"
		or data.msgId == "152362"
		or data.msgId == "152363"
		or data.msgId == "152348"
		or data.msgId == "152349"
		or data.msgId == "152350"
		or data.msgId == "152380"
		or data.msgId == "152381"
		or data.msgId == "152382"
		or data.msgId == "152393"
		or data.msgId == "152394"
		or data.msgId == "152395"

		or data.msgId == "152487"
		or data.msgId == "152488"
		or data.msgId == "152489"
		or data.msgId == "152500"
		or data.msgId == "152501"
		or data.msgId == "152502"
		or data.msgId == "152513"
		or data.msgId == "152514"
		or data.msgId == "152515"
		or data.msgId == "3200144"
		then
		if data.para and data.para[1] then
			local pos = math.tonumber(data.para[1])
			PopupViewController:call("forceClearAll", true)
			if SceneController:call("getCurrentSceneId") == 11 then
	            local point = WorldController:call("getPointByIndex", tonumber(pos))
	            WorldMapView:call("gotoTilePoint", point)
	        else
	            SceneController:call("gotoScene", 11, false, true, tonumber(pos))
	        end
        end
    elseif data.msgId == "175450"
        or data.msgId == "175451"
        or data.msgId == "175452"
        then
        if data.para and data.para[1] and data.para[2] then
        	local pos = math.tonumber(data.para[2])
        	local serverId = math.tonumber(data.para[1])
        	PopupViewController:call("forceClearAll", true)
        	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
        	local playerServerId = playerInfo:getProperty("currentServerId")
        	playerServerId = math.tonumber(playerServerId)
			if SceneController:call("getCurrentSceneId") == 11 then
	            local point = WorldController:call("getPointByIndex", tonumber(pos))
	            if serverId~=playerServerId then
	            	WorldMapView:call("gotoTilePoint", point,serverId)
	            else
	            	WorldMapView:call("gotoTilePoint", point)
	            end
	        else
	        	if serverId~=playerServerId then
	        		playerInfo:setProperty("currentServerId", serverId)	        		
	        	end
	            SceneController:call("gotoScene", 11, false, true, tonumber(pos))
	        end
        end
	elseif data.msgId == "221058"
		or data.msgId == "221059"
		then
		if data.para and data.para[3] then
			local pos = math.tonumber(data.para[3])
			PopupViewController:call("forceClearAll", true)
			if SceneController:call("getCurrentSceneId") == 11 then
	            local point = WorldController:call("getPointByIndex", tonumber(pos))
	            WorldMapView:call("gotoTilePoint", point)
	        else
	            SceneController:call("gotoScene", 11, false, true, tonumber(pos))
	        end
        end
    elseif data.msgId == "112180" then 
    	local dict = CCDictionary:create()
	    dict:setObject(CCString:create("GeneralsPopupView"), "name")
	    dict:setObject(CCString:create(data.para[2]), "uid")
	    LuaController:call("openPopViewInLua", dict)
	end
end

function guiCommonLocal.on_toolUseBtnClick( data )
	if nil == data then
		return
	end
	local itemId = data["itemId"]
	local itemType = data["itemType"]
	local itemPara = data["para"]
	
	MyPrint("on_toolUseBtnClick"..itemId..":"..itemType)
	dump(itemPara, "itemPara+++")

	local JumpPageController = Drequire("game.JumpPageController")
	if itemPara and itemPara ~= "" then
		--j2p;ActId;MainViewId;SubViewId;xxx;yyy;zzz
		local paramsTbl = string.split(itemPara,";")
		-- dump(paramsTbl+++,"paramsTbl+++")
		local jumpParamTbl = {
						cmd = paramsTbl[1],
						actId = paramsTbl[2],
						mainViewId = paramsTbl[3],
						subViewId = paramsTbl[4],
						allParam = itemPara
						}
		-- dump(jumpParamTbl,"jumpParamTbl+++")
		if JumpPageController:jump2PageByCmd(jumpParamTbl) then
			dump("successed to jump by cmd+++")	
			return
		end
	end

	local paramsTbl = {}
	paramsTbl.itemId = itemId
	paramsTbl.itemType = itemType
	JumpPageController:jump2PageByItemInfo(paramsTbl)
	-- CCCommonUtilsForLua.onStoreBagItemClick(itemId, itemType)
end

function guiCommonLocal.on_toolAllUseBtnClick( data )
	MyPrint("on_toolAllUseBtnClick")
	if nil == data then
		return
	end
	local itemId = data["itemId"]
	MyPrint("itemId ", itemId)
end

function guiCommonLocal.on_act_obj_getDyResName( dict )
	local obj = dict:objectForKey("obj")
	dict:setObject(CCString:create(obj:getDyResName()), "resName")
	return
end

function guiCommonLocal.on_activity_getAdFrame(dict)
	MyPrint("on_activity_getAdFrame")
	if nil == dict then
		return
	end
	local obj = dict:objectForKey("obj")
	if nil == obj then
		return
	end
	if nil == obj.getAdFrame then
		return
	end
	local frame = obj:getAdFrame()
	if nil ~= frame then
		dict:setObject(frame, "frame")
	end
	return
end
function guiCommonLocal.on_activity_getIconFrame(dict)
	MyPrint("on_activity_getIconFrame")
	if nil == dict then
		return
	end
	local obj = dict:objectForKey("obj")
	if nil == obj then
		return
	end
	if nil == obj.getIconFrame then
		return
	end
	local frame = obj:getIconFrame()
	if nil ~= frame then
		dict:setObject(frame, "frame")
	end
	return
end

function guiCommonLocal.on_getKingThroneQianChengCnt( dict )
	MyPrint("on_getKingThroneQianChengCnt")
	if nil == dict then
		return 
	end
	local cnt = FortressController.getInstance():getKingThroneQianChengCnt()
	dict:setObject(CCString:create(tostring(cnt)), "ret")
	return
end

function guiCommonLocal.on_checkServerCanJoin( dict )
	MyPrint("on_checkServerCanJoin")
	if nil == dict then
		return
	end
	if nil == dict:objectForKey("serverId") then
		return
	end
	local serverId = dict:objectForKey("serverId"):getValue()
	require("game.fortress.FortressController")
	local ret = FortressController.getInstance():checkServerCanJoin(serverId)
	MyPrint("ret:::", ret)
	if ret then
		dict:setObject(CCString:create("1"), "ret")
	else
		dict:setObject(CCString:create("0"), "ret")
	end

	return
end

function guiCommonLocal.on_getKingThroneServerId( dict )
	if nil == dict then
		return
	end
	require("game.fortress.FortressController")
	local serverId = FortressController.getInstance():getKingThroneServerId()
	dict:setObject(CCString:create(tostring(serverId)), "serverId")
	return
end

function guiCommonLocal.on_jumpToTarget( data )
	local goType = data["goType"]
	local goItemId = data["goItemId"]
	CCCommonUtilsForLua.jumpToTarget(goType, goItemId)
end

function guiCommonLocal.on_open_StoneSelectView( data )
	if nil == data then
		return
	end
	require("game.equipment.StoneSelectView")
	local view = StoneSelectView.create(data["groupId"], data["posy"])
	PopupViewController:call("addPopupView", view)
end

function guiCommonLocal.on_open_PintuView( data )
	local id = data["id"]
	require("game.ThreeYearsActivity.ActivityPintuView")
    local view = ActivityPintuView.create(id)
    PopupViewController:call("addPopupView", view)
end

function guiCommonLocal.on_open_LuckyBagView( ... )
	ActivityTYController:getInstance():openActivityThreeYearPopupView()
end 

function guiCommonLocal.on_get_put_stone_id( dict )
	if nil == dict then
		return
	end

	local groupId = dict:objectForKey("groupId")
	groupId = tolua.cast(groupId, "CCInteger")
	groupId = groupId:getValue()
	local itemId = EquipmentController:call("getInstance"):getPutOnStoneByEquipGroupId(groupId)
	dict:setObject(CCInteger:create(tonumber(itemId)), "itemId")

	return
end

function guiCommonLocal.on_suit_detailview_onenter( ... )
	EquipmentController:call("getInstance"):clearCachedStonePutOnData()
	EquipmentController:call("getInstance"):clearCachedEquipPutOnData()
end

function guiCommonLocal.on_suit_detailview_onexit( ... )
	EquipmentController:call("getInstance"):clearCachedStonePutOnData()
	EquipmentController:call("getInstance"):clearCachedEquipPutOnData()
end

function guiCommonLocal.on_forge_suit_equip_with_stone( data )
	local groupId = data["groupId"]
	local uuid = data["uuid"]
	EquipmentController:call("getInstance"):startForgeSuitEquipWithStone(groupId, uuid)
end

function guiCommonLocal.onPush_ComponentEvent(ref)
	local eventType = ref:objectForKey("type"):getValue()

	if eventType == 1 then
		local node = ref:objectForKey("node")
		local layer = UiCompoentControoller.create(ref)
		node:addChild(layer)
	else
		local layer = UiCompoentControoller.getCompoentLayer()
		if layer then
			-- 继续操作
			if eventType == 2 then
				local sceneId = ref:objectForKey("sceneId"):getValue()
				layer:onSceneChanged(sceneId)
			end
		end
	end
end

function guiCommonLocal.onOpen_SevenDayPayView()
	local lua_path = "game.LiBao.SevenDayPayView"
	package.loaded[lua_path] = nil
	local view = require(lua_path):create()
	PopupViewController:addPopupInView(view)
end

-- function guiCommonLocal.onPushServerAction(dict)
-- 	local tbl = dictToLuaTable(dict)
-- 	dump(tbl)
-- 	local SeverActionPush = require("game.controller.SeverActionPush")
-- 	SeverActionPush.getServerPush(tbl)
-- end

function guiCommonLocal.activityShowEnterView(dict)
	dump(tbl, "activityShowEnterView ~~~~~~~~")
	-- package.loaded["game.activity.firstPop.firstPopController"] = nil
	local firstPopCtr = require("game.activity.firstPop.firstPopController")
	firstPopCtr.getInstance():activityShowEnterView()
	dump(tbl, "activityShowEnterView ~~~~~~~~ ended ~~~~~")
end

function guiCommonLocal.onCreateGoldExchangeAdView(dict)
	-- 创建小的礼包弹窗
	local tbl = dictToLuaTable(dict)
    local path = "game.LiBao.LuaGoldExchangeAdView"
    package.loaded[path] = nil
    local advNode = require(path).new(tbl.show_type, tbl.isSmall)
    dict:setObject(advNode, tostring("advNode"))
end

function guiCommonLocal.onFireRepayEvent(dict, newKey)
	require("game.LiBao.Repay.RepayController")
	RepayController.getInstance():fireEvent(newKey, dict)
end

function guiCommonLocal.onShareCommonMsg(dict)
	local tbl = arrayToLuaTable(dict)
	dump(tbl, "onShareCommonMsg ~")
	local chat = require("game.controller.ChatSharedController")
	chat.touchMsg(tbl)
end

function guiCommonLocal.showLiBaoView(dict, newKey)
    LiBaoController.getInstance():showLiBaoView(newKey, dict)
end

function guiCommonLocal.showVipDetailView(dict)
	local vipView = Drequire("game.Vip.VipDetailView"):create()
	PopupViewController:addPopupInView(vipView)
end

function guiCommonLocal.open_GroupActivityView(data)
    local view = Drequire("game.activity.groupAct.groupActCell").create(data.id)
	PopupViewController:addPopupView(view)
end

function guiCommonLocal.onFireToolEvent(dict, newKey)
	ToolController:fireToolEvent(newKey, dict)
end

function guiCommonLocal.openFallsLibaoView()
	local view = Drequire("game.LiBao.LibaoFallsView").create()
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.openFavoriteListView()
	local view = Drequire("game.WorldMapView.FavoriteListView").create()
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.favoriteListMsg(dict, newKey)
    FavoriteListController.favoriteListMsg(newKey, dict)
end

function guiCommonLocal.openQuickEquipView(data)
	QuickEquipmentController.getInstance():openUi()
end

function guiCommonLocal.openAllianceDailyPlublishView(data)
	local view = Drequire("game.alliance.AllianceDailyPublishView"):create()
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.onUseHeroSkill(data)
	HeroManager.useHeroSkillBySaveData(data)
end
--------------ZT专用，嘿嘿，避免冲突 Ended----------------------

function guiCommonLocal.onOpen_ChangeServerPage(dict)
	dump(dict, " open_ChangeServerPage ~~~~~~~")
	local lua_path = "game.CommonPopup.ChangeServer.ChangeServerDescView"
	package.loaded[lua_path] = nil
	local view = require(lua_path):create(dict)
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.onOpen_SelectAccountView(dict)
    dump(dict, " open_SelectAccountView ~~~~~~~")
    local lua_path = "game.CommonPopup.SelectAccount"
    require(lua_path)
    PopupViewController:addPopupView(SelectAccountView:create(dict))

end

--打开elex账号切换界面。
function guiCommonLocal.onOpen_ElexSelectAccountView(dict)
    dump(dict, " onOpen_ElexSelectAccountView ~~~~~~~")
    local lua_path = "game.CommonPopup.ElexSelectAccountView"
    local ElexSelectAccountView = Drequire(lua_path)
    PopupViewController:addPopupView(ElexSelectAccountView:create(dict))

end

function guiCommonLocal.on_use_item_to_other( data )
	if nil == data then
		return
	end

	local uid = data["uid"]
	local itemId = data["itemId"]
	TriggerEventUtils.useItemToTarget(uid, itemId)
end

function guiCommonLocal.onOpen_DPlinkActivityNoteView(ref)
	MyPrint("-------onOpen_DPlinkActivityNoteView---")
	if nil == ref then
		MyPrint("-------param is nill---")
		return
	end

	local dict = tolua.cast(ref, "CCDictionary")
	local params = dictToLuaTable(dict)

	dump(params,"-------onOpen_DPlinkActivityNoteView param---")
	if nil == params then
		MyPrint("--params is nil--")
		return
	end

	for key, value in pairs(params) do      
    	MyPrint("key" .. key)  
	end  
	
	if nil == params["reward"] then
		MyPrint("---not find reward key!!")
		return
	end
	
	if nil == params["name"] then
		MyPrint("--- not find  name key !!!!")
		return
	end

	local lua_path = "game.CommonPopup.DPlinkActivityNoteView"
	package.loaded[lua_path] = nil
	local view = require(lua_path):create(params["name"],params["reward"])
	view:call("setExcluded",true)
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.open_QuestMainView(ref)
	require "game.quest.QuestMainView"
	local view = QuestMainView:create()
	PopupViewController:addPopupInView(view, true, false, false, true)
end

function guiCommonLocal.open_TreasureView(ref)
	require "game.brotherhood.TreasureView"
	local view = TreasureView:create()
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.open_FriendsView(ref)
	local FriendsView = Drequire "game.brotherhood.FriendsView"
	local view = FriendsView:create()
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.open_AchievementView(ref)
	require "game.role.WallOfHonor"
	local openType = 0
	if (ref) then
		openType = ref:valueForKey("openType"):intValue()
	end
	local view = WallOfHonor:create(openType)
	PopupViewController:call("addPopupInView", view)
end

function guiCommonLocal.open_GiveFlowerView(ref)
	if not ref then return end
	
	local uid = ref:valueForKey("uid"):getCString()
	local name = ref:valueForKey("name"):getCString()
	local abbr = ref:valueForKey("abbr"):getCString()
	local pic = ref:valueForKey("pic"):getCString()
	local picVer = ref:valueForKey("pic"):intValue()
	local flowerNum = ref:valueForKey("flowerNum"):intValue()
	local serverId = ref:valueForKey("serverId"):intValue()
	local view = myRequire("game.player.GiveFlowerView"):create(uid, name, abbr, pic, picVer, flowerNum, serverId)
	PopupViewController:call("addPopupInView", view)
end

function guiCommonLocal.open_PlayerFlowerView(ref)
	-- local view = require("game.player.PlayerFlowerView"):create()
	-- PopupViewController:call("addPopupInView", view)


	local view = myRequire("game.player.PlayerFlowerView"):create()
	PopupViewController:call("addPopupInView", view)


end

function guiCommonLocal.open_ChangeNickNameView(ref)
	if not ref then return end
	local uuid = ref:valueForKey("uuid"):getCString()
	local guide = false
	if ref:valueForKey("guide") then
		guide = ref:valueForKey("guide"):boolValue()
	end
	local view = require("game.role.ChangeNickNameView"):create(uuid, guide)
	PopupViewController:addPopupView(view)
end

function guiCommonLocal.open_DailyActiveView(ref)
	if CCCommonUtilsForLua:isFunOpenByKey("new_daily_active_switch") then
		local view = Drequire("game.NewDailyActive.NewDailyActiveFrameView"):create()
		PopupViewController:addPopupInView(view)
	else
		local view = Drequire("game.Tavern.DailyActiveView"):create()
		PopupViewController:addPopupInView(view)
	end
end

function guiCommonLocal.open_AssociationEntryView()
	MyPrint("open_AssociationEntryView")
	local view = require("game.association.AssociationEntryView"):create()
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.open_ToolCreateView()
	MyPrint("open_ToolCreateView")
	local view = require("game.equipment.ToolCreateView"):create()
	PopupViewController:addPopupView(view)
end

function guiCommonLocal.open_ItemStatusView(dict)
	local view = Drequire("game.CommonPopup.ItemStatusView"):create(dict)
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.open_UseItemStatusView(ref)
	if not ref then return end

	local _type = ref:valueForKey("type"):intValue()
	local title = ref:valueForKey("title"):getCString()
	local description = ref:valueForKey("description"):getCString()
	local statusFlag = ref:valueForKey("statusFlag"):boolValue()

	local view = require("game.CommonPopup.UseItemStatusView"):create(_type, title, description, statusFlag)
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.open_UseToolView(ref)
	if not ref then return end

	local _type = ref:valueForKey("type"):getCString()
	local dict = nil
	if (ref:objectForKey("dict")) then 
		dict = ref:objectForKey("dict")
	end
	local title = ""
	if ref:valueForKey("title") then
		title = ref:valueForKey("title"):getCString()
	end
	MyPrint("open_UseToolView", _type, dict, title)
	local view = Drequire("game.CommonPopup.UseToolView"):create(_type, dict, title)
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.open_UseResToolView(ref)
	if not ref then return end

	local resType = ref:valueForKey("resType"):intValue()
	local showIndex = false
	if ref:valueForKey("showIndex") then
		showIndex = ref:valueForKey("showIndex"):intValue() > 0
	end
	local view = Drequire("game.CommonPopup.UseResToolView"):create(resType, showIndex)
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.open_KnightListView(ref)
	local view = Drequire("game.CommonPopup.Knight.KnightListView"):create()
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.open_BedgeComposeView(ref)
	if not ref then return end

	local _type = ref:valueForKey("type"):intValue()
	local view = myRequire("game.CommonPopup.Knight.BedgeComposeView"):create(_type)
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.open_AllianceScienceView()
	local view = require("game.alliance.AllianceScienceView"):create()
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.open_AllianceScienceDonateView(ref)
	if not ref then return end

	local scienceId = ref:valueForKey("scienceId"):intValue()
	MyPrint("scienceId", scienceId)
	local view = require("game.alliance.AllianceScienceDonateView"):create(scienceId)
	view:setFromTreeCell()
	PopupViewController:addPopupView(view)
end

function guiCommonLocal.open_AllianceHelpView()
	local lua_path = "game.alliance.AllianceHelpView"
	package.loaded[lua_path] = nil
	local view = require("game.alliance.AllianceHelpView"):create()
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.open_Manual()
	local view = require("game.manual.ManualMainView"):create()
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.isManualVisible(ref)
	local open = require("game.manual.ManualManager"):isManualVisible()
	ref:setObject(CCString:create(tostring(open)), "manual")
end

function guiCommonLocal.isManualShowInMainCity(ref)
	local open = require("game.manual.ManualManager"):isManualShowInMainCity()
	ref:setObject(CCString:create(tostring(open)), "manual")
end

function guiCommonLocal.open_DeviceAccountView()
	-- if 1 == LUA_DEBUG then
		local view = Drequire("game.deviceAccount.DeviceAccount_v2_View"):create()
		PopupViewController:addPopupInView(view)
	-- else
	-- 	if CCCommonUtilsForLua:isFunOpenByKey("role_on") then
	-- 		local lua_path = "game.deviceAccount.DeviceAccountView"
	-- 		package.loaded[lua_path] = nil
	-- 		local view = require("game.deviceAccount.DeviceAccountView"):create()
	-- 		PopupViewController:addPopupInView(view)
	-- 	else
	-- 		local analyticId = GlobalDataCtr.getAnalyticID()
	-- 		if analyticId == "cn1" then
	-- 			local view = Drequire("game.deviceAccount.DeviceAccount_v2_View"):create()
	-- 			PopupViewController:addPopupInView(view)
	-- 		end
	-- 	end
	-- end
end

function guiCommonLocal.open_SearchView()
	local lua_path = "game.setting.SearchView"
	package.loaded[lua_path] = nil
	local view = require("game.setting.SearchView"):create()
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.openDailyActivityView()
	local lua_path = "game.dailyActivity.DailyActivityView"
	package.loaded[lua_path] = nil
	local view = require(lua_path):create()
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.Glory6IsFunOpenByKey(reciever)
	MyPrint("Glory6IsFunOpenByKey")

	if not reciever then return end

	local funKey = reciever:valueForKey("funKey"):getCString()
	local funOn = require("game.Glory6.Glory6Manager").isFunOpenByKey(funKey)
	reciever:setObject(CCString:create(tostring(funOn)), "funOn")
end

function guiCommonLocal.isGloryNeedUnlock(ref)
	local uuid = ref:valueForKey("uuid"):getCString()
	local need = require("game.Glory6.Glory6Manager").isNeedUnlock(uuid)
	ref:setObject(CCString:create(tostring(need)), "isNeedUnlock")
end


function guiCommonLocal.openGlory6StrengthenView()
	MyPrint("openGlory6StrengthenView guicommon")
	local lua_path = "game.Glory6.Glory6StrengthenView"
	package.loaded[lua_path] = nil
	local view = require(lua_path):create()
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.openGlory6UnlockView(ref)
	if not ref then return end

	local uuid = ref:valueForKey("uuid"):getCString()
	local unlockType = ref:valueForKey("unlockType"):intValue()

	local lua_path = "game.Glory6.Glory6UnlockView"
	package.loaded[lua_path] = nil
	local view = require(lua_path):create(uuid, unlockType)
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.openGlory6NewArmyTrainView(ref)
	MyPrint("openGlory6NewArmyTrainView")
	if not ref then return end

	local lua_path = "game.Glory6.Glory6NewArmyTrainView"
	package.loaded[lua_path] = nil
	local buildingKey = ref:valueForKey("buildingKey"):intValue()
	local view = require(lua_path):create(buildingKey)
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.openGlory6NewArmyCureView(ref)
	MyPrint("openGlory6NewArmyCureView")
	if not ref then return end

	local lua_path = "game.Glory6.Glory6NewArmyCureView"
	package.loaded[lua_path] = nil
	local buildingKey = ref:valueForKey("buildingKey"):intValue()
	local view = require(lua_path):create(buildingKey)
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.Glory6CancelCure()
	MyPrint("Glory6CancelCure")
	require("game.Glory6.Glory6Manager").cancelCure()
end

function guiCommonLocal.Glory6CureComplete(ref)
	if not ref then return end

	local uuid = ref:valueForKey("uuid"):getCString()
	require("game.Glory6.Glory6Manager").cureComplete(uuid)
end

function guiCommonLocal.Glory6UpdateWeakInClient()
	-- MyPrint("Glory6UpdateWeakInClient")
	require("game.Glory6.Glory6Manager").updateWeakInClient()
end

function guiCommonLocal.Glory6FinishCureNewArmy()
	MyPrint("Glory6FinishCureNewArmy")
	require("game.Glory6.Glory6Manager").finishCureNewArmy()
end

function guiCommonLocal.Glory6GetTotalCure(ref)
	MyPrint("Glory6GetTotalCure")
	if not ref then return end

	local totalCure = require("game.Glory6.Glory6Manager").getTotalCure()
	ref:setObject(CCString:create(tostring(totalCure)), "totalCure")
end

function guiCommonLocal.Glory6GetNewArmsTotalUpkeep(ref)
	-- MyPrint("Glory6GetNewArmsTotalUpkeep")

	if not ref then return end

	local totalUpkeep = require("game.Glory6.Glory6Manager").getNewArmsTotalUpkeep()
	ref:setObject(CCString:create(tostring(totalUpkeep)), "totalUpkeep")
end

function guiCommonLocal.Glory6GetWeakArmyMsg(ref)
	MyPrint("Glory6GetWeakArmyMsg")
	if not ref then return end

	local weakMsg = require("game.Glory6.Glory6Manager").getArmyWeakMsg()
	ref:setObject(CCString:create(weakMsg), "weakMsg")
end

function guiCommonLocal.openGlory6IntroductionView()
	local lua_path = "game.Glory6.Glory6Introduction.Glory6IntroductionView"
	package.loaded[lua_path] = nil
	local view = require(lua_path):create()
	PopupViewController:addPopupView(view)
end

function guiCommonLocal.on_open_ActivityView( data )
	MyPrint("on_open_ActivityView")
	dump(data, "data")
	local id = data["id"]
	if nil == id then
		return
	end
	id = tostring(id)
	ActivityView = nil
	package.loaded["game.CommonPopup.ActivityView"] = nil
	require("game.CommonPopup.ActivityView")
	local view = ActivityView:create(id)
	PopupViewController:call("addPopupInView", view)
end

function guiCommonLocal.on_open_ActivityViewPlus( data )
	MyPrint("on_open_ActivityViewPlus")

	-- if true then
	-- 	myRequire("game.CommonPopup.TestView")
	-- 	local view = TestView.create()
	-- 	PopupViewController:call("addPopupInView", view)
	-- 	return
	-- end

	dump(data, "data")
	local id = data["id"]
	if nil == id then
		return
	end
	id = tostring(id)
	myRequire("game.CommonPopup.ActivityViewPlus")
	local view = ActivityViewPlus.create(id)
	PopupViewController:call("addPopupView", view)
end

function guiCommonLocal.on_isLeftSceneOpened( dict )
	if nil == dict then
		return
	end
	local open = ImperialSceneLuaManager.getInstance():isLeftSceneOpened()
	if open ~= true then
		open = false
	end
	dict:setObject(CCBool:create(open), "open")
end

function guiCommonLocal.onOpen_NewTroopsView( dict )
	local lua_path = "game.soldier.NewTroopsView"
	--package.loaded[lua_path] = nil
	
	-- [awen-junyu] 加入口类型，0:普通编队  1:联盟编队
	local _type = 0
	if dict then
		_type = dict['type'] or 0
	end

	local view = Drequire(lua_path):create(_type)
	PopupViewController:addPopupInView(view)
end

function guiCommonLocal.onOpen_SoldierMoreInfoView(dict)
	require("game.soldier.SoldierInfoView")
	dict = tolua.cast(dict, "CCDictionary")
	local m_info = tolua.cast(dict:objectForKey("m_info"),"ArmyInfo")
	local m_buildingId = tolua.cast(dict:objectForKey("m_buildingId"),"CCInteger"):getValue()
	local m_armyIds = dictToLuaTable(tolua.cast(dict:objectForKey("m_armyIds"),"CCDictionary"))
	-- print("m_buildingId == "..m_buildingId)
	local sortTab = {}
	for k,v in pairs(m_armyIds) do
		sortTab[tonumber(k)] = v
		-- print("m_armyIds ,k,v == ",k,v)
	end
	m_armyIds = sortTab
	local view = SoldierMoreInfoView:create(m_info,m_buildingId,m_armyIds)
	PopupViewController:call("getInstance"):call("addPopupView",view);
end


function guiCommonLocal.onOpen_SoldierInfoView(dict)
	require("game.soldier.SoldierInfoView")
	dict = tolua.cast(dict, "CCDictionary")
	local m_info = tolua.cast(dict:objectForKey("m_info"),"ArmyInfo")
	local m_buildingId = tolua.cast(dict:objectForKey("m_buildingId"),"CCInteger"):getValue()
	local view = SoldierInfoView:create(m_info,m_buildingId)
	PopupViewController:call("getInstance"):call("addPopupView",view);
end

function guiCommonLocal.on_open_ComposeMaterialView( data )
	if nil == data then
		return
	end

	local ids = data.ids
	if nil == ids then
		return
	end
	local view = myRequire("game.CommonPopup.ComposeMaterialView").create(ids)
	PopupViewController:call("addPopupView", view)
end

------------------------------------------------------------------
-------- 在这里不断的增加处理函数吧 ----------------
------------------------------------------------------------------

-- 初始化数据
function guiCommonLocal.on_init_data(ref )
	MyPrint("on_init_data_")
	if ref == nil then
		return
	end
	
	local dict = tolua.cast(ref, "CCDictionary")

	ImperialSceneLuaManager.getInstance():initData(dict)

	HeroManager.initHeroInfoFromXML()
	HeroManager.initHeroInfo(dict)
	HeroManager.initPrisonerInfo(dict)

	-- 魔法学院
	MagicManager.initMagicDataConfigData(dict)

	OneKeyBuffManager.initBuffDataConfigData(dict)

	HighTechController.getInstance():initServerData(dict)
	HeroManager.initHeroDataConfigData(dict)
	
	--联盟累充
	RechargeLegendController:initRechargeLegendConfigData(dict)
	RecallController.getInstance():initServerData(dict)

	local MirroSelectManager = require("game.mirro.MirroSelectManager")
	MirroSelectManager.initMirroConfig(dict)

	local UpdateAnnounceManager = require("game.updateAnnouncement.UpdateAnnounceManager")
	UpdateAnnounceManager.initConfig(dict)

	local AssociationManager = require("game.association.AssociationManager")
	AssociationManager.initAssoConfig(dict)
	
	require("game.manual.ManualManager"):initConfig(dict)
	--荣耀6
	require("game.Glory6.Glory6Manager").initConfig(dict)

	NewbeeCastleController = Drequire("game.activity.NewbeeCastle.NewbeeCastleController").new()

	NeutralLandManager.initData(dict)
	MergeServerManager.initData(dict)
	FortressController.getInstance():parseConfig(dict)
	ArenaController.getInstance():initData(dict)
	require("game.resBattleNew.NewResBattleData"):parse(dict)
	require("game.dailyActivity.DailyActivityManager").initConfig(dict)
	require("game.dragonWorldCup.DragonWorldCupManager").initConfig(dict)

	DragonActiveSkillManager.getInstance():initData(dict)
	GrowthFundController:initData(dict)	
	GoldVowController:initData(dict)
	NewRecallController:initData(dict)
	MonthFundController:initConfigData(dict)
	
	require("game.crossThrone.CrossThroneManager"):initConfig(dict)
	require("game.worldLevel.WorldLevelManager").initConfig(dict)
	require("game.crown.CrownManager").initConfig(dict)
	require("game.artillery.ArtilleryManager").initConfig(dict)
	require("game.allianceTerritory.civiMiracle.CiviMiracleManager").initConfig(dict)

	-- 【awen】设置英雄图鉴item数据
	require("game.hero.NewUI_v2.HeroBuffManager"):initConfig(dict)
	-- 【awen】设置士兵进阶item数据
	require("game.army.ArmyController"):initConfig(dict)
	-- 【awen】设置一键换装item数据
	QuickEquipmentController.getInstance():initConfig(dict)
	-- 【Awen】技能面板item数据
	require("game.controller.NewActiveSkillController"):initConfig(dict)

	local KingdomTeamInfo = dict:objectForKey("KingdomTeamInfo")
    if KingdomTeamInfo ~= nil then
    	tblKingdomTeamInfo = dictToLuaTable(KingdomTeamInfo)
        UiCompoentControoller.kingdomBattleTeam(tblKingdomTeamInfo)
    end
    require("game.controller.ShareController").getInstance():initConfigData(dict)

	require("game.activity.FourthAnniversary.FourthAnniversaryBlessData").getInstance():initConfig(dict)

	require("game.activity.MidAutumnFestival.MAFJadeRabbitController").getInstance():initConfigData(dict)
	-- 银行理财数据
	require("game.Bank_new.BankController").getInstance():initDeposit(dict)
	--联盟标记
	require("game.WorldMapView.AllianceMark.AllianceMarkController").getInstance():initConfigData(dict)
	-- 急速杀怪
	local killMonsterBuffInfo = dict:objectForKey("killMonsterBuffObj")
	if killMonsterBuffInfo ~= nil then
        CCSafeNotificationCenter:postNotification("MSG_kill_monster_buff", killMonsterBuffInfo)
	end
	COSDataController.getInstance():initConfigData(dict)
	--付费转服
	require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance():initData(dict)

	UserSettingController.parseData(dict)
	TournamentControllerInst:initData(dict)
	require("game.PropaPopup.PropaPopupController").getInstance():initData(dict)
end

function guiCommonLocal.on_init_preEnterGame_data( ... )
	MyPrint("on_init_preEnterGame_data")

	NpcController.getInstance():initNpcDyResource()
	ToolController:call("getInstance"):initInLua()
end

function guiCommonLocal.on_ImperialScene_init( ref )
	MyPrint("on_ImperialScene_init")
	if ref == nil then
		return
	end
	local scene = tolua.cast(ref, "ImperialScene")
	scene:initInLua()
end

function guiCommonLocal.on_show_avatar_ground(dict)
	if nil == dict then
		return
	end

	local name = dict:valueForKey("name"):getCString()
	MyPrint("on_show_avatar_ground", name)
	local ret = false
	-- if CCCommonUtilsForLua:call("isTmpZipFileExist",name) == false 
	-- 	and cc.FileUtils:getInstance():isFileExist(cc.FileUtils:getInstance():getWritablePath() .. "lua/" .. string.format(name) .. "/avatarGroundPlus.lua") == true
	-- 	then
	-- 	require (string.format(name) .. ".avatarGroundPlus")
	-- 	if nil ~= avatarGround and nil ~= avatarGround[name] and nil ~= avatarGround[name].create then
	-- 		ret = avatarGround[name]:create()
	-- 	end
	-- end

	ret = Drequire("game.ImperialScene.AvatarGround"):create(name)

	dict:setObject(CCBool:create(ret), "ret")

	return
end

function guiCommonLocal.on_int_UIComponent_in_lua( ui )
	MyPrint("on_int_UIComponent_in_lua")
	if nil == ui then
		return
	end
	if nil == ui.initInLua then
		return
	end

	ui:initInLua()
end

function guiCommonLocal.on_UI_monster_pro_touched(monsterPro)
	if nil == monsterPro then
		return
	end
	if nil == monsterPro.onTouched then
		return
	end
	monsterPro:onTouched()
end

function guiCommonLocal.on_world_createCity( info )
	if nil == info then
		return
	end
	local scene = WorldMapView:call("instance")
	if nil == scene then
		return
	end
	scene:createCityInLua(info)
end

function guiCommonLocal.on_world_releaseCity( info )
	if nil == info then
		return
	end
	local scene = WorldMapView:call("instance")
	if nil == scene then
		return
	end
	scene:releaseCityInLua(info)
end

function guiCommonLocal.on_set_lua_debug_flag( data )
	if nil ~= data["debug"] then
		LUA_DEBUG = data["debug"]
	end
end

function guiCommonLocal.on_end_CD_queue( dict )
	MyPrint("on_end_CD_queue")

	QueueController:call("getInstance"):endCDQueue(dict)
end

function guiCommonLocal.on_end_finish_queue( dict )
	MyPrint("on_end_finish_queue")

	QueueController:call("getInstance"):endFinishQueue(dict)
end

function guiCommonLocal.on_end_cancel_queue( dict )
	MyPrint("on_end_cancel_queue")

	QueueController:call("getInstance"):endCancelQueue(dict)
end

function guiCommonLocal.on_open_HighTechBookView( ... )
	-- myRequire("game.MergeServer.MergeServerView")
	-- local view = MergeServerView:create()
	-- PopupViewController:call("addPopupInView", view)

	MyPrint("on_open_HighTechBookView")
	local HighTechBookView = Drequire("game.HighTech.HighTechView")
	local view = HighTechBookView.create()
	PopupViewController:call("addPopupInView", view)
end

function guiCommonLocal.on_retUseTool( dict )
	-- body
end

function guiCommonLocal.on_open_ActivityUI( data )
	if nil == data then
		return
	end

	local id = data["id"]
	if id == nil or "" == id then
		return
	end

	ActivityController.getInstance():openActUI(id)
end

function guiCommonLocal.on_get_act_monster_pro(dict)
	if nil == dict then
		return
	end

	dict:setObject(CCString:create(tostring(LuaActivityController.getInstance().actValue)), "nowCnt")
	dict:setObject(CCString:create(tostring(LuaActivityController.getInstance().actMaxValue)), "totalCnt")
	
end



function guiCommonLocal.on_getUsePower( dict )
	MyPrint("on_getUsePower")
end

function guiCommonLocal.on_check_isRecallOpen( dict )
	if nil == dict then
		return false
	end
	local b = RecallController.getInstance():isRecallOpen()
	dict:setObject(CCBool:create(b), "open")
	return true
end

function guiCommonLocal.on_check_isShouldShowRecallPop( dict )
	if nil == dict then
		return false
	end

	local b = RecallController.getInstance():isCanRwdToday() 
	dict:setObject(CCBool:create(b), "show")
	return true
end

function guiCommonLocal.on_open_RecallView( ... )
	MyPrint("on_open_RecallView")

	local obj = ActivityController:call("getActObj", "57150")
	local rate = 1
	if nil ~= obj then
		rate = math.random(0, 1)
	end
	MyPrint("rate::::", rate)
	local mainCityLv = FunBuildController:call("getMainCityLv")
	if mainCityLv < 16 then
		rate = 1
	end
	if rate > 0.5 then
		require("game.recall.RecallView")
		local view = RecallView.create()
		PopupViewController:call("addPopupView", view)
	else
		ActivityController.getInstance():shouActUIById("57150")
	end
end

function guiCommonLocal.on_open_ProtectorPlaceNoticeView( data )
	MyPrint("on_open_ProtectorPlaceNoticeView")
	local id = data["defensorId"]
	local index = data["index"]
	local itemId = data["itemId"]

	if 1 == LUA_DEBUG then
		package.loaded["game.protector.ProtectorPlaceNoticeView"] = nil
	end
	require("game.protector.ProtectorPlaceNoticeView")
	PopupViewController:call("addPopupView", ProtectorPlaceNoticeView.create(id, index, itemId))
end

function guiCommonLocal.on_createDefensorBounder( dict )
	if nil == dict then
		return
	end
	local range = dict:objectForKey("range"):getValue()

	if 1 == LUA_DEBUG then
		package.loaded["game.protector.ProtectorWorldItems"] = nil
	end
	require("game.protector.ProtectorWorldItems")
	local node = ProtectorRange.new(range)
	dict:setObject(node, "rangeNode")
end

function guiCommonLocal.on_lua_cmd_back( dict )
	MyPrint("on_lua_cmd_back")
	LuaCmdController.getInstance():onGetCmdBack(dict)
end

function guiCommonLocal.onOpen_ItemGetMethodView(dict)
	if dict == nil then
		return false
	end
	dump(dict, "onOpen_ItemGetMethodView")
	local itemId = tostring(dict.itemId)
	local ItemGetMethodView = Drequire("game.CommonPopup.ItemGetMethodView")
	local view = ItemGetMethodView:create(itemId)
	PopupViewController:call("addPopupView", view)
end

function guiCommonLocal.onOpen_UpdateAnnounceView(dict)
	if dict == nil then
		return false
	end
	local UpdateAnnounceManager = require("game.updateAnnouncement.UpdateAnnounceManager")
	if UpdateAnnounceManager.haveUnshowAnnounce(dict) == false then
		return false
	end
	
	local lua_path = "game.updateAnnouncement.UpdateAnnounceView"
	package.loaded[lua_path] = nil
	require(lua_path)
	local view = UpdateAnnounceView:create(dict)
	PopupViewController:call("addPopupView", view)
end

function guiCommonLocal.on_open_armed_item_shop_enter_view( ... )
	local view = myRequire("game.MilitaryRank.ArmedItemsShopEnterView").create()
	PopupViewController:call("addPopupInView", view)
end

function guiCommonLocal.onOpen_CommonChangeNameView(dict)
	if dict == nil then
		return false
	end

	local lua_path = "game.CommonPopup.CommonChangeNameView"
	package.loaded[lua_path] = nil
	require(lua_path)
	local view = CommonChangeNameView:create(dict)
	PopupViewController:call("addPopupView", view)
end

function guiCommonLocal.onOpen_NewPlayerSignInRewardView()
	local lua_path = "game.CommonPopup.NewPlayerSignInRewardView"
	package.loaded[lua_path] = nil
	require(lua_path)
	local view = NewPlayerSignInRewardView:create()
	PopupViewController:call("addPopupInView", view)
end

function guiCommonLocal.onOpen_NeutralLandMinimapIntroView()
	local lua_path = "game.NeutralLand.NeutralLandMinimapIntroView"
	package.loaded[lua_path] = nil
	require(lua_path)
	local view = NeutralLandMinimapIntroView:create()
	PopupViewController:call("addPopupView", view)
end

function guiCommonLocal.onOpen_FindResTileView()
	local lua_path = "game.WorldMapView.FindResTileView"
	package.loaded[lua_path] = nil
	require(lua_path)
	local view = FindResTileView:create()
	PopupViewController:call("addPopupView", view)
end

function guiCommonLocal.onOpen_TipsWithPicView(dict)
	if dict == nil then
		return false
	end

	local lua_path = "game.WorldMapView.TipsWithPicView"
	package.loaded[lua_path] = nil
	require(lua_path)
	local vType = tostring(dict.type)
	local view = TipsWithPicView:create(vType)
	PopupViewController:call("addPopupView", view)
end

function guiCommonLocal.onOpen_OccupyMailPopupView(dict)
	local lua_path = "game.Mail.OccupyMailPopupView"
	package.loaded[lua_path] = nil
	local mailUid = dict:objectForKey("mailUid")
	mailUid = tolua.cast(mailUid, "CCString")
	mailUid = mailUid:getCString()
	local view = require(lua_path):create(mailUid)
	if nil ~= view then
		dict:setObject(view, "view")
	end
end

function guiCommonLocal.on_getFortressStageName( dict )
	if nil == dict then
		return
	end
	local stage = dict:valueForKey("stage"):intValue()
	require("game.fortress.FortressController")
	local name = FortressController.getInstance():getFortressStageName(stage)
	dict:setObject(CCString:create(name), "name")
	return
end

function guiCommonLocal.on_open_jubaoview( data )
	local uid = ""
	local name = ""
	if nil ~= data then
		uid = data.uid
		name = data.name
	end
	local view = myRequire("game.setting.ReportCheatingView").create(name, uid)
	PopupViewController:call("addPopupView", view)
end

function guiCommonLocal.on_open_NDaysView( ... )
	local view = myRequire("game.activity.ndays.NDaysQuestView").create()
	PopupViewController:call("addPopupInView", view)
end

function guiCommonLocal.on_isInNewThroneBattle( dict )
	if nil == dict then
		return
	end
	require("game.fortress.FortressController")
	local stage = FortressController.getInstance():getCurStage()
	if stage == 8 then
		dict:setObject(CCString:create("1"), "ret")
	else
		dict:setObject(CCString:create("0"), "ret")
	end
	return
end

function guiCommonLocal.on_canJoinWKActivity( dict )
	if nil == dict then
		return 
	end
	if FortressController.getInstance():canJoinWKActivity() then
		dict:setObject(CCString:create("1"), "ret")
	else
		dict:setObject(CCString:create("0"), "ret")
	end
	return
end

function guiCommonLocal.on_open_UseSkillPopUpView( ... )
	MyPrint("on_open_UseSkillPopUpView")
	-- local view = myRequire("game.general.UseSkillPopUpView").create()
	-- PopupViewController:call("addPopupView", view)
	local view = nil
	if CCCommonUtilsForLua:isFunOpenByKey("new_activeskill_panel_switch") then
		view = myRequire("game.CommonPopup.NewActiveSkillView").create()
	else
		view = myRequire("game.CommonPopup.ActiveSkillView").create()
	end
	PopupViewController:call("addPopupView", view)
end

function guiCommonLocal.on_getHealEff( dict )
	if nil == dict then
		return 
	end
	local eff = FortressController.getInstance().m_healEff
	dict:setObject(CCString:create(tostring(eff)), "ret")
	return
end

function guiCommonLocal.on_getMaxAllot( dict )
	if nil == dict then
		return 
	end
	local max = FortressController.getInstance().m_maxAllot
	dict:setObject(CCString:create(tostring(max)), "ret")
	return
end

function guiCommonLocal.on_getOpenLevel( dict )
	if nil == dict then
		return
	end
	local level = FortressController.getInstance().openLevel
	dict:setObject(CCString:create(tostring(level)), "ret")
	return
end

function guiCommonLocal.on_open_FortressSellView( dict )
	local stage = FortressController.getInstance():getCurStage()
	if stage <= 2 then
		myRequire("game.CommonPopup.ActivityViewPlus")
		local view = ActivityViewPlus.create("57155")
		PopupViewController:call("addPopupView", view)
	else
		local view = myRequire("game.fortress.FortressSellView").create()
		PopupViewController:call("addPopupInView", view)
	end
end

function guiCommonLocal.onOpen_ExploreMailPopupView(dict)
	local lua_path = "game.Mail.ExploreMailPopupView"
	package.loaded[lua_path] = nil
	local mailUid = dict:objectForKey("mailUid")
	mailUid = tolua.cast(mailUid, "CCString")
	mailUid = mailUid:getCString()
	local view = require(lua_path):create(mailUid)
	if nil ~= view then
		dict:setObject(view, "view")
	end
end

function guiCommonLocal.on_get_res_new_battle_point( dict )
	if nil == dict then
		return
	end
	local obj = ActivityController:call("getActObj", "57158")
	if nil == obj then
		return
	end
	local point = obj.centerPoint
	dict:setObject(CCString:create(tostring(point)), "point")
end

function guiCommonLocal.onOpen_AnnounceMailPopupView(dict)
	local lua_path = "game.Mail.AnnounceMailPopupView"
	package.loaded[lua_path] = nil
	local mailUid = dict:objectForKey("mailUid")
	mailUid = tolua.cast(mailUid, "CCString")
	mailUid = mailUid:getCString()
	local view = require(lua_path):create(mailUid)
	if nil ~= view then
		dict:setObject(view, "view")
	end
end

function guiCommonLocal.onOpen_DetectMailPopupView(dict)
	local lua_path = "game.Mail.DetectMailPopupView"
	--package.loaded[lua_path] = nil
	local mailUid = dict:objectForKey("mailUid")
	mailUid = tolua.cast(mailUid, "CCString")
	mailUid = mailUid:getCString()
	local view = Drequire(lua_path):create(mailUid)
	if nil ~= view then
		dict:setObject(view, "view")
	end
end

function guiCommonLocal.onOpen_CivFortressRobMailPopupView(dict)
   local lua_path = "game.Mail.CivFortressRobMailPopupView"
    --package.loaded[lua_path] = nil
    local mailUid = dict:objectForKey("mailUid")
    mailUid = tolua.cast(mailUid, "CCString")
    mailUid = mailUid:getCString()
    dump(mailUid,"Drequire(lua_path):create(mailUid)0000")
    local view = Drequire(lua_path):create(mailUid)
    dump(view,"Drequire(lua_path):create(mailUid)")
    if nil ~= view then
       dict:setObject(view, "view")
    end
end


function guiCommonLocal.onOpen_InnerSettingView()
	local lua_path = "game.setting.InnerSettingView"
	-- package.loaded[lua_path] = nil
	local view = Drequire(lua_path):create()
	PopupViewController:call("addPopupInView", view)
end

function guiCommonLocal.onOpen_DragonList_New(dict)
	local DragonList_New = myRequire("game.NewDragon.DragonList_New")
	local view = DragonList_New:create(dict)
	PopupViewController:call("addPopupInView", view)
end

function guiCommonLocal.onOpen_DragonPreview_New(dict)
	local DragonPreview_New = Drequire("game.NewDragon.DragonPreview_New")
	local view = DragonPreview_New:create(dict)
	PopupViewController:call("addPopupInView", view)
end
------------------------------------------------------------------
-- all function *MUST* defined forward!!!
-- 增加的一个事件映射表。
local g_fireEventTable = 
{
	-- system
	["purge_controller"] = guiCommonLocal.onPurge_Controller,
	["lua_cmd_back"] = guiCommonLocal.on_lua_cmd_back, 
	-- 队列相关
	["end_CD_queue"] = guiCommonLocal.on_end_CD_queue,
	["end_finish_queue"] = guiCommonLocal.on_end_finish_queue,
	["end_cancel_queue"] = guiCommonLocal.on_end_cancel_queue,
	-- open ui
	["openAllianceSignHelpView"] = guiCommonLocal.openAllianceSignHelpView,
	["open_LuaCityDefenseView"] = guiCommonLocal.onOpen_LuaCityDefenseView,
	["open_UpstarView"] = guiCommonLocal.onOpen_UpstarView,
	["open_GeneralTreasureBoxView"] = guiCommonLocal.onOpen_GeneralTreasureBoxView,
	["open_GeneralTreasureBoxView_from_luckyday"] = guiCommonLocal.on_open_GeneralTreasureBoxView_from_luckyday,
	["open_VipTreasureBoxView"] = guiCommonLocal.onOpen_VipTreasureBoxView,
	["open_VipTreasureBoxShareView"] = guiCommonLocal.onOpen_VipTreasureBoxShareView,
	["open_BigSellView"] = guiCommonLocal.onOpen_BigSellView,
	["open_GoldExchangeView"] = guiCommonLocal.onOpen_GoldExchangeView,
	["open_ActivityBankView"] = guiCommonLocal.onOpen_ActivityBankView,
	["open_ActivityGoldBox"] = guiCommonLocal.onOpen_ActivityGoldBox,
	["open_GoldBoxEndRank"] = guiCommonLocal.onOpen_GoldBoxEndRank,
	["open_ConsumeActivityView"] = guiCommonLocal.onOpen_ConsumeActivityView,
	["open_NuetralShop"] = guiCommonLocal.onOpen_NuetralShop,
	["open_ActivityView"] = guiCommonLocal.on_open_ActivityView,
	["open_ActivityViewPlus"] = guiCommonLocal.on_open_ActivityViewPlus,
	["open_HighTechBookView"] = guiCommonLocal.on_open_HighTechBookView,
	["open_wish_act_view"] = guiCommonLocal.on_open_wish_act_view,
	["open_ShieldUnLockPage"] = guiCommonLocal.onOpen_ShieldUnLockPage,
	["open_LanguageChoosePage"] = guiCommonLocal.onOpen_LanguageChoosePage,
    ["open_SocialActivityPage"] = guiCommonLocal.onOpen_SocialActivityPage,
    ["open_ChangeServerPage"] = guiCommonLocal.onOpen_ChangeServerPage,
    ["onOpen_SelectAccountView"] = guiCommonLocal.onOpen_SelectAccountView,
    ["onOpen_ElexSelectAccountView"] = guiCommonLocal.onOpen_ElexSelectAccountView,
    ["use_item_to_other"] = guiCommonLocal.on_use_item_to_other,-- 对他人使用物品
    ["open_SelectNetView"] = guiCommonLocal.onOpen_SelectNetView,
    ["open_MerchantView"] = guiCommonLocal.onOpen_MerchantView,
    ["open_EquipLongjingView"] = guiCommonLocal.onOpen_EquipLongjingView,
    ["open_MainCityView"] = guiCommonLocal.onOpen_MainCityView,
    ["open_PintuView"] = guiCommonLocal.on_open_PintuView,
    ["open_LuckyBagView"] = guiCommonLocal.on_open_LuckyBagView,
    ["open_AllRankListPopUpView"] = guiCommonLocal.onOpen_AllRankListPopUpView,
    ["open_GeneralSkillListPopUpView"] = guiCommonLocal.onOpen_GeneralSkillListPopUpView,
    ["open_SacrificePopUpView"] = guiCommonLocal.onOpen_SacrificePopUpView,
    ["open_ArmedStateView"] = guiCommonLocal.onOpen_ArmedStateView,
    ["open_armed_item_shop_enter_view"] = guiCommonLocal.on_open_armed_item_shop_enter_view,
    ["open_AvatarView"] = guiCommonLocal.on_open_AvatarView,
	["Open_DPlinkActivityNoteView"] = guiCommonLocal.onOpen_DPlinkActivityNoteView,
	
--------------SHP专用，嘿嘿，避免冲突 Start----------------------
	["open_QuestMainView"] = guiCommonLocal.open_QuestMainView,
	["open_TreasureView"] = guiCommonLocal.open_TreasureView,
	["open_FriendsView"] = guiCommonLocal.open_FriendsView,
	["open_AchievementView"] = guiCommonLocal.open_AchievementView,
	["open_GiveFlowerView"] = guiCommonLocal.open_GiveFlowerView,
	["open_PlayerFlowerView"] = guiCommonLocal.open_PlayerFlowerView,
	["open_ChangeNickNameView"] = guiCommonLocal.open_ChangeNickNameView,
	["open_DailyActiveView"] = guiCommonLocal.open_DailyActiveView,
	["open_AssociationEntryView"] = guiCommonLocal.open_AssociationEntryView,
	["open_ToolCreateView"] = guiCommonLocal.open_ToolCreateView,
	["open_ItemStatusView"] = guiCommonLocal.open_ItemStatusView,
	["open_UseItemStatusView"] = guiCommonLocal.open_UseItemStatusView,
	["open_UseToolView"] = guiCommonLocal.open_UseToolView,
	["open_UseResToolView"] = guiCommonLocal.open_UseResToolView,
	["open_KnightListView"] = guiCommonLocal.open_KnightListView,
	["open_BedgeComposeView"] = guiCommonLocal.open_BedgeComposeView,
	["open_AllianceScienceView"] = guiCommonLocal.open_AllianceScienceView,
	["open_AllianceScienceDonateView"] = guiCommonLocal.open_AllianceScienceDonateView,
	["open_AllianceHelpView"] = guiCommonLocal.open_AllianceHelpView,
	["isManualShowInMainCity"] = guiCommonLocal.isManualShowInMainCity,
	["isManualVisible"] = guiCommonLocal.isManualVisible,
	["open_Manual"] = guiCommonLocal.open_Manual,
	["open_DeviceAccountView"] = guiCommonLocal.open_DeviceAccountView,
	["open_SearchView"] = guiCommonLocal.open_SearchView,
	["openDailyActivityView"] = guiCommonLocal.openDailyActivityView,

	--------荣耀6相关---------
	["Glory6IsFunOpenByKey"] = guiCommonLocal.Glory6IsFunOpenByKey,
	["isGloryNeedUnlock"] = guiCommonLocal.isGloryNeedUnlock,
	["openGlory6UnlockView"] = guiCommonLocal.openGlory6UnlockView,
	["openGlory6StrengthenView"] = guiCommonLocal.openGlory6StrengthenView,
	["openGlory6NewArmyTrainView"] = guiCommonLocal.openGlory6NewArmyTrainView,
	["openGlory6NewArmyCureView"] = guiCommonLocal.openGlory6NewArmyCureView,
	["Glory6CancelCure"] = guiCommonLocal.Glory6CancelCure,
	["Glory6CureComplete"] = guiCommonLocal.Glory6CureComplete,
	["Glory6UpdateWeakInClient"] = guiCommonLocal.Glory6UpdateWeakInClient,
	["Glory6FinishCureNewArmy"] = guiCommonLocal.Glory6FinishCureNewArmy,
	["Glory6GetTotalCure"] = guiCommonLocal.Glory6GetTotalCure,
	["Glory6GetWeakArmyMsg"] = guiCommonLocal.Glory6GetWeakArmyMsg,
	["Glory6GetNewArmsTotalUpkeep"] = guiCommonLocal.Glory6GetNewArmsTotalUpkeep,
	["openGlory6IntroductionView"] = guiCommonLocal.openGlory6IntroductionView,
--------------SHP专用，嘿嘿，避免冲突 End----------------------

--------------ZT专用，嘿嘿，避免冲突 Start----------------------
	["open_LuaLiBaoController"] = guiCommonLocal.onOpen_LuaLiBaoController,
	["push_insertNewLibao"] = guiCommonLocal.onPush_insertNewLibao,
	["push_GiftPopCount"] = guiCommonLocal.onPush_GiftPopCount,
	["push_initLibao"] = guiCommonLocal.onPush_initLibao,
	["onOpen_SubscribeView"] = guiCommonLocal.open_SubscribeView,
	["onOpen_randomLibao"] = guiCommonLocal.open_randomLibao,
	["push_ComponentEvent"] = guiCommonLocal.onPush_ComponentEvent,
	["onOpen_SevenDayPayView"] = guiCommonLocal.onOpen_SevenDayPayView,

	-- ["onPushServerAction"] = guiCommonLocal.onPushServerAction,
	["onRefreshLibaoItemData"] = guiCommonLocal.onRefresh_LibaoItemData,
	["onUpdateLibaoItemData"] = guiCommonLocal.onUpdate_LibaoItemData,
	["onDeleteLibaoItemData"] = guiCommonLocal.onDelete_LibaoItemData,
	["activityShowEnterView"] = guiCommonLocal.activityShowEnterView,
	["onNewRefreshExchangeData"] = guiCommonLocal.onNewRefreshExchangeData,

	["onCreateGoldExchangeAdView"] = guiCommonLocal.onCreateGoldExchangeAdView,

	["onFireRepayEvent"] = guiCommonLocal.onFireRepayEvent,

	["onShareCommonMsg"] = guiCommonLocal.onShareCommonMsg,
	["monthCardOrders"] = guiCommonLocal.monthCardOrders,

	["showLiBaoView"] = guiCommonLocal.showLiBaoView,

	["showVipDetailView"] = guiCommonLocal.showVipDetailView,

	["open_GroupActivityView"] = guiCommonLocal.open_GroupActivityView,

	["onFireToolEvent"] = guiCommonLocal.onFireToolEvent,
	["openFallsLibaoView"] = guiCommonLocal.openFallsLibaoView,

	["openFavoriteListView"] = guiCommonLocal.openFavoriteListView,
	["favoriteListMsg"] = guiCommonLocal.favoriteListMsg,

	["openAllianceDailyPlublishView"] = guiCommonLocal.openAllianceDailyPlublishView,

	["openQuickEquipView"] = guiCommonLocal.openQuickEquipView,
	["onUseHeroSkill"] = guiCommonLocal.onUseHeroSkill,
--------------ZT专用，嘿嘿，避免冲突 End----------------------
	-- 配置数据初始化
	["initConfigData"] = guiCommonLocal.onInitConfigData,
	-- 初始化数据 注意 这个消息会被多次收到 因为消息拆分的缘故
	["init_data"] = guiCommonLocal.on_init_data,
	-- 初始化要进入游戏的数据（以后和非解析网络数据的处理都放到这里）
	["init_preEnterGame_data"] = guiCommonLocal.on_init_preEnterGame_data,
	-- 初始化完成后的静态lua处理
	["data_init_end"] = guiCommonLocal.onData_init_end,
	-- 主城相关
	["ImperialScene_init"] = guiCommonLocal.on_ImperialScene_init,
	["show_avatar_ground"] = guiCommonLocal.on_show_avatar_ground,
	["isLeftSceneOpened"] = guiCommonLocal.on_isLeftSceneOpened,
	-- 世界相关
	["world_createCity"] = guiCommonLocal.on_world_createCity,
	["world_releaseCity"] = guiCommonLocal.on_world_releaseCity,
	-- 主ui
	["int_UIComponent_in_lua"] = guiCommonLocal.on_int_UIComponent_in_lua,
	["UI_monster_pro_touched"] = guiCommonLocal.on_UI_monster_pro_touched,
	-- 告知lua是不是debug
	["set_lua_debug_flag"] = guiCommonLocal.on_set_lua_debug_flag,
	-- 套装
	["createSuitStoneView"] = guiCommonLocal.on_createSuitStoneView,
	["open_StoneSelectView"] = guiCommonLocal.on_open_StoneSelectView,
	["get_put_stone_id"] = guiCommonLocal.on_get_put_stone_id,
	["suit_detailview_onenter"] = guiCommonLocal.on_suit_detailview_onenter,
	["suit_detailview_onexit"] = guiCommonLocal.on_suit_detailview_onexit,
	["forge_suit_equip_with_stone"] = guiCommonLocal.on_forge_suit_equip_with_stone,
	--英雄相关
	["open_HeroSkillView"] = guiCommonLocal.onOpen_HeroSkillView,
	["open_HeroGarrisonView"] = guiCommonLocal.onOpen_HeroGarrisonView,
	["open_HeroMainView"] = guiCommonLocal.onOpen_HeroMainView,
	["open_HeroGraveView"] = guiCommonLocal.onOpen_HeroGraveView,
	["open_HeroPrisonView"] = guiCommonLocal.onOpen_HeroPrisonView,
	["open_NewHeroListView"] = guiCommonLocal.onOpen_NewHeroListView,
	["open_NewHeroCleanView"] = guiCommonLocal.onOpen_NewHeroCleanView,
	-- 龙相关
	["open_DragonEffectView"] = guiCommonLocal.onOpen_DragonEffectView,
	["open_DragonSkillView"] = guiCommonLocal.onOpen_DragonSkillView,
	["open_DragonPreviewView"] = guiCommonLocal.onOpen_DragonPreviewView,
	["open_UseSkillPopUpView"] = guiCommonLocal.on_open_UseSkillPopUpView,
	-- -- refresh
	-- ["refresh_ShieldUnLockPage"] = guiCommonLocal.onRefresh_ShieldUnLockPage,
	-- 巨龙对战
	["open_DragonBattleListView"] = guiCommonLocal.onOpen_DragonBattleListView,
	-- 巨龙OB战报
	["open_DragonOBReportView"] = guiCommonLocal.onOpen_DragonOBReportView,
	-- 背包点击 
	["type_zero_tool_click"] = guiCommonLocal.on_type_zero_tool_click,
	["toolUseBtnClick"] = guiCommonLocal.on_toolUseBtnClick,
	["toolAllUseBtnClick"] = guiCommonLocal.on_toolAllUseBtnClick,
	-- 活动相关
	["objForLua_getCurActivityStageAndLeftTime"] = guiCommonLocal.on_objForLua_getCurActivityStageAndLeftTime,
	["objForLua_getGameTickStr"] = guiCommonLocal.on_objForLua_getGameTickStr,
	["objForLua_requestActivityDetail"] = guiCommonLocal.on_objForLua_requestActivityDetail,
	["createActLuaObj"] = guiCommonLocal.on_createActLuaObj,
	["open_ActivityUI"] = guiCommonLocal.on_open_ActivityUI,
	-- monsterpro
	["get_act_monster_pro"] = guiCommonLocal.on_get_act_monster_pro,
	["get_res_new_battle_point"] = guiCommonLocal.on_get_res_new_battle_point,
	-- 召回是否开启
	["check_isRecallOpen"] = guiCommonLocal.on_check_isRecallOpen,
	-- 是否应该谈召回界面
	["check_isShouldShowRecallPop"] = guiCommonLocal.on_check_isShouldShowRecallPop,
	-- 打开召回界面 
	["open_RecallView"] = guiCommonLocal.on_open_RecallView,
	-- 打开召唤着放置界面
	["open_ProtectorPlaceNoticeView"] = guiCommonLocal.on_open_ProtectorPlaceNoticeView,
	-- 创建召唤着的边界
	["createDefensorBounder"] = guiCommonLocal.on_createDefensorBounder,
	-- 新远征
	["getKingThroneQianChengCnt"] = guiCommonLocal.on_getKingThroneQianChengCnt,
	["checkServerCanJoin"] = guiCommonLocal.on_checkServerCanJoin,
	["getKingThroneServerId"] = guiCommonLocal.on_getKingThroneServerId,
	["getFortressStageName"] = guiCommonLocal.on_getFortressStageName,
	["isInNewThroneBattle"] = guiCommonLocal.on_isInNewThroneBattle,
	["canJoinWKActivity"] = guiCommonLocal.on_canJoinWKActivity,
	["getHealEff"] = guiCommonLocal.on_getHealEff,
	["getMaxAllot"] = guiCommonLocal.on_getMaxAllot,
	["getOpenLevel"] = guiCommonLocal.on_getOpenLevel,
	["open_FortressSellView"] = guiCommonLocal.on_open_FortressSellView,
	--  跳转
	["jumpToTarget"] = guiCommonLocal.on_jumpToTarget,
	["isSpeEffNumConditionOk"] = guiCommonLocal.on_isSpeEffNumConditionOk,
	["onClickFlySystem"] = guiCommonLocal.on_onClickFlySystem,
	-- 活动相关资源名字获取
	["act_obj_getDyResName"] = guiCommonLocal.on_act_obj_getDyResName,
	-- 活动小图标 广告图 frame获取
	["activity_getAdFrame"] = guiCommonLocal.on_activity_getAdFrame,
	["activity_getIconFrame"] = guiCommonLocal.on_activity_getIconFrame,
	-- 打开n日目标界面
	["open_NDaysView"] = guiCommonLocal.on_open_NDaysView,
	--魔镜
	["open_MirroSelectView"] = guiCommonLocal.onOpen_MirroSelectView,
	--中立地带选择矿区弹出框
	["open_NeurtalSelectPopUpView"] = guiCommonLocal.onOpen_NeurtalSelectPopUpView,
	--中立地带积分排行榜
	["open_WorldMineRankView"] = guiCommonLocal.onOpen_WorldMineRankView,
	--王国远征任务
	["open_KingdomThroneQuestView"] = guiCommonLocal.onOpen_KingdomThroneQuestView,
	--博客
	["open_BlogView"] = guiCommonLocal.onOpen_BlogView,
	--城外商队兑换
	["open_MerchantExchangeView"] = guiCommonLocal.onOpen_MerchantExchangeView,
	--背包兑换
	["open_BagExchangeView"] = guiCommonLocal.onOpen_BagExchangeView,
	--通用获得更多途径面板
	["open_ItemGetMethodView"] = guiCommonLocal.onOpen_ItemGetMethodView,
	--游戏内更新公告面板
	["open_UpdateAnnounceView"] = guiCommonLocal.onOpen_UpdateAnnounceView,
	--军队界面
	["open_NewTroopsView"] = guiCommonLocal.onOpen_NewTroopsView,
	["open_SoldierMoreInfoView"] = guiCommonLocal.onOpen_SoldierMoreInfoView,
	["open_SoldierInfoView"] = guiCommonLocal.onOpen_SoldierInfoView,
	-- 打开道具合成界面
	["open_ComposeMaterialView"] = guiCommonLocal.on_open_ComposeMaterialView,
	-- 使用道具
	["retUseTool"] = guiCommonLocal.on_retUseTool,
	
	-- 获取使用体力 
	["getUsePower"] = guiCommonLocal.on_getUsePower,
	--通用改名面板
	["open_CommonChangeNameView"] = guiCommonLocal.onOpen_CommonChangeNameView,
	--新版新手签到奖励面板
	["open_NewPlayerSignInRewardView"] = guiCommonLocal.onOpen_NewPlayerSignInRewardView,
	--中立地带缩略图说明面板
	["open_NeutralLandMinimapIntroView"] = guiCommonLocal.onOpen_NeutralLandMinimapIntroView,
	-- 打开举报面板
	["open_jubaoview"] = guiCommonLocal.on_open_jubaoview,

	--世界里查找资源田面板
	["open_FindResTileView"] = guiCommonLocal.onOpen_FindResTileView,
	--银行功能
	["open_BankMainView"] = guiCommonLocal.onOpen_BankMainView,
	--世界资源田等玩法介绍
	["open_TipsWithPicView"] = guiCommonLocal.onOpen_TipsWithPicView,
	--占领邮件
	["open_OccupMailPopupview"] = guiCommonLocal.onOpen_OccupyMailPopupView,
	--遗迹探索邮件
	["open_ExploreMailPopupView"] = guiCommonLocal.onOpen_ExploreMailPopupView,
	--更新公告邮件
	["open_AnnounceMailPopupView"] = guiCommonLocal.onOpen_AnnounceMailPopupView,
	--侦查邮件
	["open_DetectMailPopupView"] = guiCommonLocal.onOpen_DetectMailPopupView,
    --文明堡垒 掠夺邮件
    ["open_CivFortressRobMailPopupView"] = guiCommonLocal.onOpen_CivFortressRobMailPopupView,
	--设置面板
	["open_InnerSettingView"] = guiCommonLocal.onOpen_InnerSettingView,
	--龙系统新UI
	["open_DragonList_New"] = guiCommonLocal.onOpen_DragonList_New,
	["open_DragonPreview_New"] = guiCommonLocal.onOpen_DragonPreview_New,
}


function onFireEvent(eventID, data, newKey)
	-- dump(data, "onFireEvent: " .. eventID.." newKey is: "..tostring(newKey))
	if g_fireEventTable[eventID] then
		g_fireEventTable[eventID](data, newKey)
	end

	if nil ~= onFireEvent2 then
		onFireEvent2(eventID, data, newKey)
	end

	if nil ~= onFireDynamicEvent then
		onFireDynamicEvent(eventID, data)
	end

end
