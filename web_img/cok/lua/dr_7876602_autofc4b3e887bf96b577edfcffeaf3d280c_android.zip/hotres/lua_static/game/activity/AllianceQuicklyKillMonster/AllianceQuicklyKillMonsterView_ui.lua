----------------------------
-- Author: Elex
-- Date: 2019-06-24 Monday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local AllianceQuicklyKillMonsterView_ui = class("AllianceQuicklyKillMonsterView_ui")

--#ui propertys


--#function
function AllianceQuicklyKillMonsterView_ui:create(owner, viewType, paramTable)
	local ret = AllianceQuicklyKillMonsterView_ui.new()
	CustomUtility:DoRes(0, true)
	CustomUtility:LoadUi("AllianceQuicklyKillMonsterView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function AllianceQuicklyKillMonsterView_ui:initLang()
	LabelSmoker:setText(self.m_tipsEffect, "182206")
	LabelSmoker:setText(self.m_tipsLabel, "182189")
	LabelSmoker:setText(self.m_rankGlobal, "182079")
	LabelSmoker:setText(self.m_personalScore1, "182205")
	LabelSmoker:setText(self.m_allianceScore2, "182204")
	LabelSmoker:setText(self.m_pLabelTTF96, "182107")
	LabelSmoker:setText(self.m_leftBtnLabel1, "102161")
	LabelSmoker:setText(self.m_rightBtnLabel1, "138026")
	LabelSmoker:setText(self.m_leftBtnLabel, "182074")
	LabelSmoker:setText(self.m_midBtnLabel, "140459")
	LabelSmoker:setText(self.m_rightBtnLabel, "140460")
	LabelSmoker:setText(self.m_titleTxt, "182188")
end

function AllianceQuicklyKillMonsterView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function AllianceQuicklyKillMonsterView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function AllianceQuicklyKillMonsterView_ui:onAddEffectClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onAddEffectClick", pSender, event)
end

function AllianceQuicklyKillMonsterView_ui:onClickBtnInfo(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnInfo", pSender, event)
end

function AllianceQuicklyKillMonsterView_ui:onClickCountry(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickCountry", pSender, event)
end

function AllianceQuicklyKillMonsterView_ui:onClickBtnPlayer(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnPlayer", pSender, event)
end

function AllianceQuicklyKillMonsterView_ui:onClickBtnActive(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnActive", pSender, event)
end

function AllianceQuicklyKillMonsterView_ui:onClickBtnALL(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnALL", pSender, event)
end

function AllianceQuicklyKillMonsterView_ui:onClickBtnLocal(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnLocal", pSender, event)
end

return AllianceQuicklyKillMonsterView_ui

