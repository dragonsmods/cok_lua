

ToNewServerController = class("ToNewServerController")

_toNewServerController = _toNewServerController or nil

local KingReturnLevelController = class("KingReturnLevelController")
local KingReturnLoginController = class("KingReturnLoginController")
local KingReturnConsumeController = class("KingReturnConsumeController")
local KingReturnRechargeController = class("KingReturnRechargeController")
local KingReturnDiscountController = class("KingReturnDiscountController")
local KingReturnMissionController = class("KingReturnMissionController")
local KingReturnFriendMissionController = class("KingReturnFriendMissionController")
function ToNewServerController.isSpecialKey (str)
	return '$k_return_starttime' == str or '$k_return_juesegold' == str or '$k_return_leichong' == str
		or '$k_return_leixiao' == str or '$k_return_newold' == str or '$k_return_exp' == str or '$k_return_vip' == str
end

local ACTIVE_DAY = 14
local MAX_DISPLAY_DAY = 8
NEWBIETASK_STARTTIME_KEY = 'ToNewServer.starttime'

function ToNewServerController:ctor ()
	MyPrint('ToNewServerController:ctor')
	self.numDay = 5
	self.startTime = 0
	self.endTime = 0
	self.returnGold = 0
	self.returnExp = 0
	self.returnVipPoint = 0
	self.hasReceivedData = false
	self.taskDataArr = {}
	self.rechargeStartTime = 0 -- 充值活动开始时间，用于判断是否启用
	self.consumeStartTime = 0 -- 累消活动开始时间，用于判断是否启用

	self.oldServerData = {} --留在本服的三档奖励内容之一
	self.newServerData = {} --去新服返回的奖励内容
	self.itemId = 214317--回归用户美元道具ID

	self.status = -1
	self.chooseEndTime = 0
	self.inviteTimes = -1
	
	self.levelCtl = KingReturnLevelController.new(self)
	self.loginCtl = KingReturnLoginController.new(self)
	self.consumeCtl = KingReturnConsumeController.new(self)
	self.rechargeCtl = KingReturnRechargeController.new(self)
	self.discountCtl = KingReturnDiscountController.new(self)
	self.missionCtl = KingReturnMissionController.new(self)
    self.friendMissionCtl = KingReturnFriendMissionController.new(self)
	self.tipCountTbl = {}
	self:checkGiftDown()
	local group = LocalController:call("shared"):call("DBXMLManager"):call("getGroupByKey", "kingreturn")
	if not group then return end
	local cfgs = dictToLuaTable(group)
	dump(cfgs, "item_kingreturn")
	for k, taskCfg in pairs(cfgs) do
		local activityType = tonumber(taskCfg.num)
		if not self.taskDataArr[activityType] then
			self.taskDataArr[activityType] = {tasks = {}}
		end
		local task = {}
		task.task_id = tonumber(taskCfg.id)
		task.claimed = false
		task.target_num = tonumber(taskCfg.target)
		task.finish_num = 0
		task.rewardId = taskCfg.reward
		self.taskDataArr[activityType].tasks[tostring(task.task_id)] = task
	end
	for k,v in pairs(self.taskDataArr) do
		dump(v, 'ToNewServerController:ctor self.taskDataArr ' .. k)
	end
	self.chatInitFinish = false
	self.hasSendTalk = false
	registerScriptObserver(self, self.chatInitFinishHandler, "chat_init_finish")
end

function ToNewServerController:chatInitFinishHandler()
	self.chatInitFinish = true
	self:sendChatTalk()
end

function ToNewServerController:requestData ()
	self:requestTaskData()

	-- 请求礼包信息
	-- LiBaoController.getInstance():getExchangeDataRefersh(83)
end

function ToNewServerController.getInstance ()
	if not _toNewServerController then
		_toNewServerController = ToNewServerController.new()
	end
	return _toNewServerController
end

function ToNewServerController.purge()
	if _toNewServerController then
		unregisterScriptObserver(_toNewServerController, "chat_init_finish")
		_toNewServerController = nil
	end
end

function ToNewServerController:setStatus (status, chooseEndTime)
	-- 0(未输入Key), 1为本服幸运回归玩家，2为新服幸运回归玩家(已输入Key)，3为本服召回被封玩家，4为满足条件玩家，5为新服幸运回归活动开启玩家
	self.status = status
	self.chooseEndTime = chooseEndTime -- 结束时间

	if self.status == 1 or self.status == 5 then
		local luckyReturnItem = CCCommonUtilsForLua:call("getPropByIdGroup", "data_config", "king_return", "k1")
		if luckyReturnItem ~= "" then self.itemId = atoi(luckyReturnItem) end
	else
		local activePlayerItem = CCCommonUtilsForLua:call("getPropByIdGroup", "data_config", "king_return", "k2")
		if activePlayerItem ~= "" then self.itemId = atoi(activePlayerItem) end
	end

	--老玩家第一次回归后，通知后台发送聊天祝贺
	if self.status and self.chooseEndTime and self.status == 4 then
		myRequire("game.activity.toNewServer.ToNewServerCmd")('message'):send()
	end
end

function ToNewServerController:getStatus()
	return self.status
end

function ToNewServerController:setInitTime(time)
	self.m_initTime = (tonumber(time) or 0) / 1000
end

function ToNewServerController:setInviteTimes(inviteTimes)
	self.inviteTimes = inviteTimes
	self:sendChatTalk()
end

function ToNewServerController:sendChatTalk()
	Dprint("self.hasSendTalk, self.chatInitFinish, self.inviteTimes, self.status", self.hasSendTalk, self.chatInitFinish, self.inviteTimes, self.status)
	if self.hasSendTalk == false and self.chatInitFinish and self.inviteTimes == 0 and (self.status == 1 or self.status == 5) then
		--回归玩家首次登陆发送消息到国家频道
		--4250186=亲爱的朋友们：\n我是{0}，好久不见！期待之后和各位并肩作战，让我们一起称霸全球！\n {1}
		local playerInfo = GlobalData:call("getPlayerInfo")
    	if not playerInfo:call("isInAlliance") then
			local dialogId = "4250186"
			local param = {
				{
					type = 0,
					text = playerInfo:getProperty("name"),
					-- textColor = "0:0:255"
				},
				{
					type = 2,
					dialog= "115912",
					textColor = "0:0:255"
				}
			}

			local uid = playerInfo:getProperty("uid")
			local chat = require("game.controller.ChatSharedController")
			chat.onSharedChatDialog(chat.ChannelMsgType.CHANNEL_TYPE_COUNTRY, dialogId, param, "LuckyReturnWantAlliance", uid)
		end
		myRequire("game.activity.toNewServer.ToNewServerCmd")('wantAlliance'):send()
		self.hasSendTalk = true
	end
end

function ToNewServerController:initConfig(dict )
	local params = dict:objectForKey("k_return")
	if params then 
		local data = dictToLuaTable(params)
		self.m_missionDayDescStr = ""
		if data.k10 then
			ACTIVE_DAY = tonumber(data.k10)
		end
        if data.k14 then
            self.m_missionDayDescStr = data.k14
        end
        self.m_dayMissionNeedCount = 0
        if data.k16 then
        	self.m_dayMissionNeedCount = tonumber(data.k16)
        end
        self.m_shareUrl = ""
        if data.k17 then
        	self.m_shareUrl = data.k17
		end
    end

    local params = dict:objectForKey("k_return_pay_setting")
    if params then 
		local data = dictToLuaTable(params)
		dump(data, "k_return_pay_setting data  is:")
		MonthCardController.getInstance():setKingReturnCardType(data.k1)
		local tbl = string.split(data.k3, ";")	-- 单笔充值开启天数
		self.m_singlePayDayList = {}
		for _, dayNum in pairs(tbl) do
			local curNum = tonumber(dayNum)
			if curNum then
				self.m_singlePayDayList[curNum] = true
			end
		end
		dump(self.m_singlePayDayList, "k_return_pay_setting self.m_singlePayDayList  is:")
    end
end


function ToNewServerController:refreshActivityTbl ()
	--discount：是兑换礼包
	--TODO
	-- local tbl = {
	-- 	{ctrl = self.friendMissionCtl, beSelect = false, key = 'friendMission'},
	-- 	{ctrl = self.missionCtl, beSelect = false, key = 'mission'},
	-- 	-- {ctrl = self.consumeCtl, beSelect = false, key = 'consume'},
	-- 	-- {ctrl = self.rechargeCtl, beSelect = false, key = 'recharge'},
	-- 	{ctrl = self.loginCtl, beSelect = false, key = 'login'},
	-- 	{ctrl = self.discountCtl, beSelect = false, key = 'discount'},
	-- 	-- {ctrl = self.levelCtl, beSelect = false, key = 'level'},    
	-- }
	-- self.ctlTbl = {}
	-- local idx = 1
	-- local recruitOpen = require("game.FestivalActivities.FestivalActivitiesController").getInstance():isRecruitActivityOpen()
	-- for k,v in pairs(tbl) do
	-- 	v.index = idx
	-- 	if 'login' == v.key then
	-- 		if 1 == self.status then
	-- 			table.insert(self.ctlTbl, v)
	-- 			idx = idx + 1
	-- 		end
	-- 	elseif 'level' == v.key then
	-- 		if 5 == self.status then
	-- 			table.insert(self.ctlTbl, v)
	-- 			idx = idx + 1
	-- 		end
	-- 	elseif 'consume' == v.key then
	-- 		MyPrint('ToNewServerController:refreshActivityTbl consume', self.consumeStartTime, getTimeStamp())
	-- 		if self.consumeStartTime <= getTimeStamp() then
	-- 			table.insert(self.ctlTbl, v)
	-- 			idx = idx + 1
	-- 		end
	-- 	elseif 'recharge' == v.key then
	-- 		MyPrint('ToNewServerController:refreshActivityTbl recharge', self.rechargeStartTime, getTimeStamp())
	-- 		if self.rechargeStartTime <= getTimeStamp() then
	-- 			table.insert(self.ctlTbl, v)
	-- 			idx = idx + 1
	-- 		end
	-- 	elseif 'discount' == v.key then -- 所有玩家可见 礼包（discount）
	-- 		table.insert(self.ctlTbl, v)
	-- 		idx = idx + 1
	-- 	elseif 1 == self.status and 'friendMission' == v.key and recruitOpen then
	--         table.insert(self.ctlTbl, v)
	-- 		idx = idx + 1
	-- 	elseif (1 == self.status or 5 == self.status) and "mission" == v.key then -- 回归玩家可见
	-- 		table.insert(self.ctlTbl, v)
	-- 		idx = idx + 1
	-- 	end
	-- end
	self.ctlTbl = {}
	local tbl = {
		{
			-- ctrl = self.friendMissionCtl, 
			beSelect = false, 
			key = 'friendMission', 
			getCtrlFunc = function(data)
				if self.status == 1 then
					local recruitOpen = require("game.FestivalActivities.FestivalActivitiesController").getInstance():isRecruitActivityOpen()
					if recruitOpen then
						-- self.friendMissionCtl = KingReturnFriendMissionController.new(self)
						return self.friendMissionCtl
					end
				end
				return nil
			end
		},
		{
			-- ctrl = self.missionCtl, 
			beSelect = false, 
			key = 'mission',
			getCtrlFunc = function()
				if (1 == self.status or 5 == self.status) then
					-- self.missionCtl = KingReturnMissionController.new(self)
					return self.missionCtl
				end
				return nil
			end
		},
		{
			beSelect = false, 
			key = 'loginActive',
			getCtrlFunc = function()
				if 1 == self.status then
					if CCCommonUtilsForLua:isFunOpenByKey("k_return_pay_ui") then
						local ctrl = Drequire("game.activity.toNewServer.ReturnLoginActivity.KingReturnLoginActivityController").getInstance(self)
						return ctrl
					end
				end
				return nil
			end
		},
		{
			-- ctrl = self.loginCtl, 
			beSelect = false, 
			key = 'login',
			getCtrlFunc = function()
				if 1 == self.status then
					-- self.loginCtl = KingReturnLoginController.new(self)
					if not CCCommonUtilsForLua:isFunOpenByKey("k_return_pay_ui") then
						return self.loginCtl
					end
				end
				return nil
			end
		},
		{
			-- 显示福利，和login的是反向开关。
			beSelect = false, 
			key = 'loginLibao',
			getCtrlFunc = function()
				if 1 == self.status then
					if CCCommonUtilsForLua:isFunOpenByKey("k_return_pay_ui") then
						local ctrl = require("game.activity.toNewServer.ReturnLoginLibao.KingReturnLoginLibaoController").getInstance(self)
						return ctrl
					end
				end
				return nil
			end
		},
		{
			-- 回归礼包
			-- ctrl = self.discountCtl, 
			beSelect = false, 
			key = 'discount',
			getCtrlFunc = function()
				-- self.discountCtl = KingReturnDiscountController.new(self)
				return self.discountCtl
			end
		}, 
	}
	self.ctlTbl = {}
	local idx = 1
	
	for k,v in pairs(tbl) do
		-- 判断是否显示逻辑，显示返回ctrl，不然为nil, 为兼容旧的，所以ctrl还是得存住
		local ctrl = v.getCtrlFunc()
		if ctrl then
			local tmp = {}
			tmp.beSelect = v.beSelect
			tmp.key = v.key
			local index = #self.ctlTbl + 1
			tmp.index = index
			tmp.ctrl = ctrl
			self.ctlTbl[index] = tmp
		end
	end
	dump(self.ctlTbl, "self.ctlTbl is: ")
end

function ToNewServerController:getAvailableActivityTbl ()
	return self.ctlTbl
end

function ToNewServerController:setCellCurrentTipCount (idx, tipCount)
	self.tipCountTbl[idx] = tipCount
end

function ToNewServerController.hasTipCount ()
    -- dump(tipCountTbl, "ToNewServerController.hasTipCount")
    for k,v in pairs(self.tipCountTbl) do 
        if v ~= nil and v > 0 then 
            return true
        end
    end
    return false
end

function ToNewServerController:checkGiftDown()
	local xmlData = CCCommonUtilsForLua:getGroupByKey("lucky_return_exchange")
	local oldLiBaoFileName = "LiBao_war_resource_z2,LiBao_baoxiangwangzi,LiBao_emergency_z1,LiBao_research_stone_z2,LiBao_build_speedup_max_z3,"
	local curLanguage = LocalController:call("getLanguageFileName")	
	if curLanguage == "zh_CN" then
        curLanguage = "CN"
    elseif curLanguage == "zh_TW" then
        curLanguage = "TW"
    else
        curLanguage = string.upper(curLanguage)
	end
	-- dump(curLanguage,"hxq curLanguage is")
	local function checkLibaoFile(fileName,md5, beSame)
		-- android和IOS的md5相同时为老资源，无需判断
		if not beSame then
			local md5s = string.split(md5,"|") or {}
			if #md5s >= 2 then
				for k,v in pairs(md5s) do
					local vec = string.split(v,";")
					local language = vec[1]
					if string.find(language,curLanguage) or language == curLanguage then
						md5 = vec[2]
						fileName = fileName.."_"..language
						-- dump("hxq find right language!!!!!")
						break
					end
				end
			else
				local defaultMD5 = string.split(md5s[1],";")
				if #defaultMD5 >= 2 then
					fileName = fileName.."_default"
					md5 = defaultMD5[2]
				end
			end
			--新资源安卓压缩包
			if not string.find(oldLiBaoFileName, fileName) then
				if isAndroid() then
					fileName = fileName.."_a"
				end
			end
		end
		-- dump(fileName,"hxqqqq fileName is")
		-- dump(md5,"hxqqqq md5 iiiiii is")
		if LiBaoController:getInstance():call("checkGiftFilesOk", fileName,md5,"3") == false then
			LuaController:call("luaUpdateNewResource", fileName, md5, 3)
		end
	end
	for k,v in pairs(xmlData or {}) do
		local _fileName = ""
		local _md5 = ""
		_fileName = v.picture
		local oldFileName = v.picture	
        if isIOS() then
			_md5 = v.md5
		else
			_md5 = v.androidmd5			
		end
		local beSame = v.md5 == v.androidmd5

		if _fileName and _fileName ~= "" and _md5 and _md5 ~= "" then
			checkLibaoFile(_fileName,_md5, beSame)			
		end
    end
end

--以前登录具备该活动条件玩家会收到来自触发器的推送，现在不要了，pushKingReturnState最多只会推送一次，就是去新服的玩家升级后触发了该条件，后台推一次，，，，，就一次，以后这里不推，换做活动中心里加字段推送了
function ToNewServerController:handlePushMessage (params)
	-- local params = dictToLuaTable(params)
	-- if not params then
	-- 	MyPrint("XYLUA ERROR:ToNewServerController:handlePushMessage parse data error")
	-- 	return
	-- end
	-- dump(params, 'ToNewServerController:handlePushMessage')
	-- local cmd = params.command
	-- if 'info' == cmd then
	-- 	self:refreshFromData(params)
	-- elseif 'update' == cmd then
	-- 	self:onUpdateTask(params)
	-- elseif 'claim' == cmd then
	-- 	self:onRetClaimReward(params)
	-- end
end

function ToNewServerController:pushKingReturnState( data )
	if data.lucky_return then
		self.status = tonumber(data.lucky_return)
	end
	if data.kingReturnStartTime then
		self.startTime = tonumber(data.kingReturnStartTime) / 1000		
		self.endTime = (self.startTime) + ACTIVE_DAY * 86400
	end
end

function ToNewServerController:getTotalTaskNum ()
    local group = LocalController:call("shared"):call("DBXMLManager"):call("getGroupByKey", "kingreturn")
    local cfgs = dictToLuaTable(group)
    local n = 0
    for k,v in pairs(cfgs) do
    	-- dump(v, 'item_kingreturn')
    	n = n+1
    end
    -- MyPrint('getTotalTaskNum', type(cfgs))
    return n
end

function ToNewServerController:requestTaskData ()
    myRequire('game.activity.toNewServer.ToNewServerCmd')('info'):send()   
		-- self:refreshFromData(dict) -- test
end

-- type 1/old 2/new
function ToNewServerController:choose (type)
	self.chooseType = type
	Drequire('game.activity.toNewServer.ToNewServerCmd')('luckyReturn', type):send()
	if 2 == type then
		local gameUid = cc.UserDefault:getInstance():getStringForKey('game_uid', '')
		cc.UserDefault:getInstance():setStringForKey('king_return_old_uid', gameUid)
		cc.UserDefault:getInstance():flush()
	end
	-- self:onChooseRet({token = 'test_token'}) -- test
end

function ToNewServerController:onChooseRet (params)
	if 1 == self.chooseType then -- old
		CCSafeNotificationCenter:postNotification('ToNewServerChooseView:onChooseRet')
		self:setStatus(1)
		CCSafeNotificationCenter:postNotification('DailyActivityView.refreshList')
		return
	elseif 2 == self.chooseType then
		local key = params.token
		cc.UserDefault:getInstance():setStringForKey('king_return_token', key)
		cc.UserDefault:getInstance():flush()
		local view = Drequire("game.activity.toNewServer.KingReturnCopyKeyView"):create(key)
		-- PopupViewController:call("addPopupInView", view)
		PopupViewController:call("addPopupView", view)
	end
	-- 重置 幸运回归 的引导数据
	cc.UserDefault:getInstance():setBoolForKey("show_lucky_return_guide", true)
	cc.UserDefault:getInstance():setBoolForKey("show_lucky_return_entrance", false)
	cc.UserDefault:getInstance():flush()
end

function ToNewServerController:activate (key)
	local oldUid = cc.UserDefault:getInstance():getStringForKey('king_return_old_uid', '')
	local param = {}
	param.key = key
	param.oldUid = oldUid
	Drequire('game.activity.toNewServer.ToNewServerCmd')('activate', param):send()	
end

function ToNewServerController:onActivateRet (params)
	params = dictToLuaTable(params)
	if 'success' == params.cmd then
		cc.UserDefault:getInstance():setStringForKey('king_return_old_uid', nil)
		cc.UserDefault:getInstance():setStringForKey('king_return_token', nil)
		cc.UserDefault:getInstance():flush()
		CCSafeNotificationCenter:postNotification('KingReturnPasteKeyView:onActivateRet')
		CCCommonUtilsForLua:call('flyHint', '', '', getLang('130088'))
	end
end

function ToNewServerController:setActStartTimeAndEndTime( startTime )
	if startTime then

		self.startTime = tonumber(startTime) / 1000		
		self.endTime = (self.startTime) + ACTIVE_DAY * 86400
	end
end

function ToNewServerController:refreshFromData (params)
	dump(params, 'ToNewServerController:refreshFromData')
	local rawData = params.vars
	self.returnGold = tonumber(rawData['$k_return_juesegold'])
	self.returnExp = tonumber(rawData['$k_return_juese_exp'])
	self.returnVipPoint = tonumber(rawData['$k_return_juese_vip'])
	self.rechargeStartTime = tonumber(rawData['$k_return_leichong']) * 0.001 -- 充值活动开始时间，用于判断是否启用
	self.consumeStartTime = tonumber(rawData['$k_return_leixiao']) * 0.001 -- 累消活动开始时间，用于判断是否启用

	if 2 == self.status then
		-- 回归选择新服的玩家，在线时触发了活动条件（当前条件为升级到>6级，且之前已激活），后端会推送消息
		-- 这种情况玩家登陆时不会收的lucky_return字段，这里手动更新状态
		self:setStatus(5)
	end
end

function ToNewServerController:updateTaskFromRaw (raw, taskId, kingreturnCfgs)
	MyPrint('ToNewServerController:updateTaskFromRaw', taskId)
	local task = {}
	task.task_id = taskId
	task.claimed = tonumber(raw['$k_return_' .. taskId .. '_reward']) > 0
	task.target_num = tonumber(raw['$k_return_' .. taskId .. '_max'])
	task.finish_num = tonumber(raw['$k_return_' .. taskId .. '_process'])
	if not kingreturnCfgs then
	    local group = LocalController:call("shared"):call("DBXMLManager"):call("getGroupByKey", "kingreturn")
    	kingreturnCfgs = dictToLuaTable(group)
    end
	local taskCfg = kingreturnCfgs[tostring(taskId)]
	if taskCfg then
		task.rewardId = taskCfg.reward
		local typeIdx = tonumber(taskCfg.num)
		if not self.taskDataArr[typeIdx] then
			self.taskDataArr[typeIdx] = {tasks={}}
		end
		local found = false
		for k, v in pairs(self.taskDataArr[typeIdx].tasks) do
			if v.task_id == task.task_id then
				self.taskDataArr[typeIdx].tasks[k] = task
				found = true
				break
			end
		end
		if not found then
			table.insert(self.taskDataArr[typeIdx].tasks, task)
		end
	end
end

function ToNewServerController:canClaimReward ()
	for day, v1 in pairs(self.taskDataArr) do
		if not self:isOpen(day) then -- day is not open
			break
		end
		for k2, task in pairs(v1.tasks) do
			if task.finish_num >= task.target_num and not task.claimed then
				return true
			end
		end
	end
	return false
end

function ToNewServerController:claimReward (taskId)
    myRequire("game.activity.toNewServer.ToNewServerCmd")('claim', taskId):send()

	-- GameController:call("getInstance"):call("showWaitInterface")
end

function ToNewServerController:getDataByTaskId (taskId)
	taskId = tostring(taskId)
	for day, dayData in pairs(self.taskDataArr) do
		for k, task in pairs(dayData.tasks) do
			if task.task_id == taskId then
				return task
			end
		end
	end
end

--[[
	function ToNewServerController:onUpdateTask (params)
		local rawData = params.vars
		dump(rawData, 'ToNewServerController:onUpdateTask')
		local taskId
		for k, v in pairs(rawData) do
			if not ToNewServerController.isSpecialKey(k) then
				local strs = string.split(k, '_')
				if 3 == #strs then
					taskId = strs[2]
					return
				end
			end
		end
		if not taskId then return end

		self:updateTaskFromRaw(rawData, taskId)

		-- then, send event to UI
	    CCSafeNotificationCenter:call("postNotification", "ToNewServer.update", CCInteger:create(taskId))
	end
	--]]

	--[[
	function ToNewServerController:onRetClaimReward (params)
		local rawData = params.vars
		dump(rawData, 'ToNewServerController:onRetClaimReward')
		
		local taskId
		for k, v in pairs(rawData) do
			if not ToNewServerController.isSpecialKey(k) then
				local strs = string.split(k, '_')
				if 4 == #strs then
					taskId = strs[3]
					break
				end
			end
		end
		if not taskId then return end

		-- 1st, update data
		local alreadyClaimed = false
		local found = false
		for day, dayData in pairs(self.taskDataArr) do
			for k, v in pairs(dayData.tasks) do
				if v.task_id == taskId then
					if v.claimed then
						alreadyClaimed = false
					else
						v.claimed = true
					end
					found = true
					break
				end
			end
			if found then break end
		end
		-- if alreadyClaimed then return end

	    local group = LocalController:call("shared"):call("DBXMLManager"):call("getGroupByKey", "kingreturn")
	    local cfgs = dictToLuaTable(group)
		local taskCfg = cfgs[tostring(taskId)]
		local rewardId = taskCfg.reward
		local rwd = GlobalData:call("getCachedRewardData", rewardId)
		local rwdData = arrayToLuaTable(rwd)
		-- GameController:call("getInstance"):call("removeWaitInterface")

		local arr = {}
		for k, v in pairs(rwdData) do
			local value = v.value
			dump(value, 'value')
			obj = {}
		    obj.itemId = value.id
		    obj.rewardAdd = value.num
		    arr[k] =  obj
		end
		arr[3] = nil

	    -- GCMRewardController:call("getInstance"):call("retReward2", luaTableToArray(arr), true)
	    -- GCMRewardController:call("getInstance"):call("retReward2", arr, false)
	    -- GCMRewardController:call("getInstance"):call("retReward", luaTableToDict(arr))
		-- GCMRewardController:call("flyToolReward", luaTableToArray(arr))

		-- then, send event to UI
	    CCSafeNotificationCenter:call("postNotification", "toNewServer.claimed", CCInteger:create(taskId))
	end
--]]

function ToNewServerController:sendGetRewardDetail ()
    local group = LocalController:call("shared"):call("DBXMLManager"):call("getGroupByKey", "kingreturn")
    local cfgs = dictToLuaTable(group)
	local rewardIdsToQuery = {}
	for k1, v1 in pairs(self.taskDataArr) do
		for k2, v2 in pairs(v1.tasks) do
			local taskCfg = cfgs[tostring(v2.task_id)]
			if taskCfg then
				table.insert(rewardIdsToQuery, taskCfg.reward)
			end
		end
	end
	dump(rewardIdsToQuery, "ToNewServerController:sendGetRewardDetail")
	local rewardIds = {}
	for k,v in pairs(rewardIdsToQuery) do
		local reward_id = tostring(v)
		local rwd = GlobalData:call("getCachedRewardData", reward_id)
		self.rwdData = arrayToLuaTable(rwd)
		if #self.rwdData == 0 then 
			table.insert(rewardIds, reward_id)
			-- GlobalData:call("checkAndRequestRewardData", reward_id)
		end
	end
    GlobalData:call("shared"):call("requestMultiRewardData", rewardIds)

	dump(rewardIds, 'ToNewServerController:sendGetRewardDetail')
	-- GlobalData:call("requestMultiRewardData", rewardIds)
end

function ToNewServerController:claimReward (taskId)
    myRequire('game.activity.toNewServer.ToNewServerCmd')('claim', taskId):send()
end

function ToNewServerController:buy (taskId)
end

function ToNewServerController:setOldServerData( dict )
	local dataTbl = dictToLuaTable(dict)
	dump(dataTbl,"hxq setOldServerData is")
	local rewardIds = dataTbl.params.rewards
	self.oldServerData = {rewards = rewardIds}
	GlobalData:call("shared"):call("requestMultiRewardData", rewardIds)
end

function ToNewServerController:setNewServerData( dict )
	local dataTbl = dictToLuaTable(dict)
	dump(dataTbl,"hxq setNewServerData is")
	exp = dataTbl.params.extraExp
	gold = dataTbl.params.extraGold
	vip = dataTbl.params.extraVIPScore
	self.newServerData = {extraExp = exp ,extraGold = gold,extraVIPScore = vip}
end

function ToNewServerController:startNewAccount(isOld)
	myRequire('game.activity.toNewServer.ToNewServerCmd')('newAccount',isOld):send()
end

function ToNewServerController:getDailyData(  )
	myRequire('game.activity.toNewServer.ToNewServerCmd')('GetDailyData'):send()
end

function ToNewServerController:getDailyBonus( dayNum )
	myRequire('game.activity.toNewServer.ToNewServerCmd')('GetDailyBonus',dayNum):send()
end

function ToNewServerController:getMissionData()
	myRequire('game.activity.toNewServer.ToNewServerCmd')("GetMissionData"):send()
end

function ToNewServerController:getMissionData_v2()
	myRequire('game.activity.toNewServer.ToNewServerCmd')("GetMissionData_v2"):send()
end

function ToNewServerController:getFriendMissionData()
	local festivalCtl = require("game.FestivalActivities.FestivalActivitiesController").getInstance()
	local open, festivalId, actId = festivalCtl:isRecruitActivityOpen()
	if open then
		myRequire('game.activity.toNewServer.ToNewServerCmd')("GetFriendMissionData", actId):send()
	end
end

function ToNewServerController:getMissionBonus(taskId, isFriendMission)
	local festivalCtl = require("game.FestivalActivities.FestivalActivitiesController").getInstance()
	local open, festivalId, actId = festivalCtl:isRecruitActivityOpen()
	if isFriendMission and open then
		myRequire('game.activity.toNewServer.ToNewServerCmd')('GetFriendMissionBonus',actId, taskId):send()
	else
		myRequire('game.activity.toNewServer.ToNewServerCmd')('GetMissionBonus', taskId):send()
	end
end

function ToNewServerController.getConloginReward()
	myRequire('game.activity.toNewServer.ToNewServerCmd')("GetConloginReward"):send()
end

function ToNewServerController.getOfflineReward()
	myRequire('game.activity.toNewServer.ToNewServerCmd')("GetOfflineReward"):send()
end

function ToNewServerController.getOfflineData()
	myRequire('game.activity.toNewServer.ToNewServerCmd')("GetOfflineData"):send()
end

local ICON_SCALE = 1.2
------------------

function KingReturnLevelController:ctor (ctl)
	self.ctl = ctl
	self.tipsNum = 0
end

function KingReturnLevelController:getTipsCount ()
	return self.tipsNum
end

function KingReturnLevelController:getObjIcon ()
    local spr = getSafeSprite("icon_king_return_role_new.png", "Ativity_iconLogo_1.png")
    CCCommonUtilsForLua:call("setSpriteMaxSize", spr, 116, true)
    return spr
end

function KingReturnLevelController:getObjName ()
	return _lang('176189') -- 角色继承
end

function KingReturnLevelController:createView (viewSize)
    local view = Drequire("game.activity.toNewServer.KingReturnLevelView"):create(viewSize, self)
    return view
end

function KingReturnLevelController:getData ()
	return self.ctl.taskDataArr[1]
end

------------------

function KingReturnLoginController:ctor (ctl)
	self.ctl = ctl
	self.tipsNum = 0
end

function KingReturnLoginController:getTipsCount ()
	return self.tipsNum
end

function KingReturnLoginController:getObjIcon()
    local spr = getSafeSprite("icon_king_return_login_new.png", "Ativity_iconLogo_1.png")
    CCCommonUtilsForLua:call("setSpriteMaxSize", spr, 116, true)
    return spr
end

function KingReturnLoginController:getObjName ()
	return _lang('4250137') -- 限时福利
end

function KingReturnLoginController:createView (viewSize)
    local view = Drequire("game.activity.toNewServer.KingReturnLoginView"):create(viewSize, self)
    return view
end

function KingReturnLoginController:getData ()
	return self.ctl.taskDataArr[2]
end

--废弃----------------累计消费------------

function KingReturnConsumeController:ctor (ctl)
	self.ctl = ctl
end

function KingReturnConsumeController:getTipsCount ()
	return 0
end

function KingReturnConsumeController:getObjIcon()
    local spr = getSafeSprite("king_return_consume.png", "Ativity_iconLogo_1.png")
    CCCommonUtilsForLua:call("setSpriteMaxSize", spr, 116, true)
    return spr
end

function KingReturnConsumeController:getObjName ()
	return _lang('176204') -- 累计消费
end

function KingReturnConsumeController:createView (viewSize)
    local view = Drequire("game.activity.toNewServer.KingReturnConsumeView"):create(viewSize, self)
    return view
end

function KingReturnConsumeController:getData ()
	return self.ctl.taskDataArr[4]
end

--废弃------------------累计充值---------

function KingReturnRechargeController:ctor (ctl)
	self.ctl = ctl
end

function KingReturnRechargeController:getTipsCount ()
	return 0
end

function KingReturnRechargeController:getObjIcon()
    local spr = getSafeSprite("king_return_recharge.png", "Ativity_iconLogo_1.png")
    CCCommonUtilsForLua:call("setSpriteMaxSize", spr, 116, true)
    return spr
end

function KingReturnRechargeController:getObjName ()
	return _lang('176207') -- 累计充值
end

function KingReturnRechargeController:createView (viewSize)
    local view = Drequire("game.activity.toNewServer.KingReturnRechargeView"):create(viewSize, self)
    return view
end

function KingReturnRechargeController:getData ()
	return self.ctl.taskDataArr[3]
end

---------------免费礼包（实际是一堆reward）
function KingReturnDiscountController:ctor (ctl)
	self.ctl = ctl
	self.tipsNum = 0
end

function KingReturnDiscountController:getTipsCount ()
	return self.tipsNum
end

function KingReturnDiscountController:getObjIcon()
    local spr = getSafeSprite("icon_king_return_libao_new.png", "Ativity_iconLogo_1.png")
    CCCommonUtilsForLua:call("setSpriteMaxSize", spr, 116, true)
    return spr
end

function KingReturnDiscountController:getObjName ()
	return getLang("4249652")-- 回归礼包
end

function KingReturnDiscountController:createView (viewSize)
    -- local view = Drequire("game.activity.toNewServer.KingReturnDiscountView"):create(viewSize, self)
    -- return view
    local view = Drequire("game.activity.toNewServer.ReturnOfKing_V2.KingReturnActRewardView"):create(viewSize, self)
    return view
end

function KingReturnDiscountController:getData ()
	return self.ctl.taskDataArr[5]
end

function KingReturnDiscountController:getRewardData( )
	return self.rewardData
end

function KingReturnDiscountController:getRewardLeftTimesData(  )
	return self.leftTimesData
end

--请求免费礼包领取状态
function KingReturnDiscountController:requestRewardState( )
	--如果是登录上来第一次打开界面，会请求相关的数据信息
	if self.rewardData == nil then
		myRequire("game.activity.toNewServer.ToNewServerCmd")('reward'):send()
	end
end
--记录礼包领取状态
function KingReturnDiscountController:setRewardState( dict )
	local tbl = dictToLuaTable(dict)
	dump(tbl, "sdfsfsderewre")
	local params = tbl.params

	if self.rewardData == nil then
		self.rewardData = {}
	end
	self.leftTimesData = {}

	if params.rewardIds then
		local rwdData = string.split(params.rewardIds,";")
		for i=1, #rwdData  do
			if rwdData[i] ~= nil then
				self.rewardData[rwdData[i]] =  1
			end
		end
		-- dump(params.infoDic,"hxq params.infoDic is")
		if params.infoDic then
			for i=1, #params.infoDic do
				if params.infoDic[i] ~= nil then
					self.rewardData[params.infoDic[i]] =  1
				end
			end
		end
	elseif params.leftTimes then
		local tmpVec = string.split(params.leftTimes, "|")
		for k,v in pairs(tmpVec) do 
			local tmpVec2 = string.split(v, ";")
			if #tmpVec2 == 2 then 
				local rwdId = tmpVec2[1]
				local left = tonumber(tmpVec2[2])
				self.leftTimesData[rwdId] = left
			end
		end
		dump(self.leftTimesData, "werwerwer")
	end
	CCSafeNotificationCenter:call("postNotification", "KingReturnActRewardView.refreshView")

end

--请求兑换礼包
function KingReturnDiscountController:requestGetReward( itemId )
	myRequire("game.activity.toNewServer.ToNewServerCmd")('buy',itemId):send()
end
---------------------------王者归来任务------------
function KingReturnMissionController:ctor (ctl)
	self.ctl = ctl
	self.tipsNum = 0
end

function KingReturnMissionController:getTipsCount ()
	return self.tipsNum
end

function KingReturnMissionController:getObjIcon()
    local spr = getSafeSprite("icon_king_return_task_new.png", "Ativity_iconLogo_1.png")
    CCCommonUtilsForLua:call("setSpriteMaxSize", spr, 116, true)
    return spr
end

function KingReturnMissionController:getObjName ()
	return _lang('4249651') -- 回归任务
end

function KingReturnMissionController:createView (viewSize)
	if CCCommonUtilsForLua:isFunOpenByKey("k_return_fixedquest") then
		local view = Drequire("game.activity.toNewServer.KingReturnMissionView_new"):create(viewSize, self)
	    return view
	else
	    local view = Drequire("game.activity.toNewServer.KingReturnMissionView"):create(viewSize, self)
	    return view
	end
end

function KingReturnMissionController:getData ()
	return self.ctl.taskDataArr[5]
end
---------------------------战友任务------------
function KingReturnFriendMissionController:ctor (ctl)
	self.ctl = ctl
	self.tipsNum = 0
end

function KingReturnFriendMissionController:getTipsCount ()
	return self.tipsNum
end

function KingReturnFriendMissionController:getObjIcon()
    local spr = getSafeSprite("icon_king_return_task_new.png", "Ativity_iconLogo_1.png")
    CCCommonUtilsForLua:call("setSpriteMaxSize", spr, 116, true)
    return spr
end

function KingReturnFriendMissionController:getObjName ()
	return _lang('4250074') -- 战友任务
end

function KingReturnFriendMissionController:createView (viewSize)
	local view = Drequire("game.activity.toNewServer.KingReturnFriendMissionView"):create(viewSize, self)
    return view
end

function KingReturnFriendMissionController:getData ()
	return self.ctl.taskDataArr[5]
end
