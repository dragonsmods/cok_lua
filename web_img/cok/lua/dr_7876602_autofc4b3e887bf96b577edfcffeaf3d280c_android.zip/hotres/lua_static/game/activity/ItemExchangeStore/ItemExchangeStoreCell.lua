local ItemExchangeStoreCell = class("ItemExchangeStoreCell",
    function()
        return cc.Layer:create()
    end
)

local LibaoCommonFunc = Drequire("game.LiBao.LibaoCommonFunc")

ItemExchangeStoreCell.__index = ItemExchangeStoreCell

function ItemExchangeStoreCell:create(idx)
    local ret = ItemExchangeStoreCell.new()
    Drequire("game.activity.ItemExchangeStore.ItemExchangeStoreCell_ui"):create(ret)
    registerTouchHandler(ret)
    ret:setTouchEnabled(true)
    ret:setSwallowsTouches(false)

    CCCommonUtilsForLua:setButtonTitle(ret.ui.m_okBtn, getLang("150332"))

    return ret
end

function ItemExchangeStoreCell:refreshCell(info , idx)    
    dump("ItemExchangeStoreCell:refreshCell 11111 ")
    self.m_info = info

    -- local hasLbl = self.ui["m_lLabel"..idx]
    -- hasLbl:setString(hasNum)
    -- local needLbl = self.ui["m_rLabel"..idx]
    -- needLbl:setString("/"..needNum)
    -- if hasNum >= needNum then

    -- end
    local data = info.data
    local needItemId = data.m_value_item
    local itemType = self:refreshIcon(needItemId, 1)
    self.itemType = itemType
    if itemType == 1 then
        -- 装备
    else
        -- 物品
    end

    local curNum = self:getItemNums()
    local needNum = tonumber(data.m_value_item_num)
    self.ui.m_lLabel1:setString(curNum.."/"..needNum)
    if curNum < needNum then
        self.ui.m_lLabel1:setColor(cc.c3b(255, 0, 0))
    else
        self.ui.m_lLabel1:setColor(cc.c3b(0, 255, 0))
    end

    self.ui.m_lLabel2:setString("X1")

    local itemId = data.m_item_id
    self:refreshIcon(itemId, 2)

    local canBuyNum = data:getBuyCount()
    data.canBuyNum = canBuyNum
    local hasBuyNum = data.m_totalBuy
    data.hasBuyNum = hasBuyNum
    if data.m_buy_times > 0 then
        self.ui.m_exchagneNum:setVisible(true)
        self.ui.m_exchagneNum:setString(getLang("113070", data.m_buy_times - hasBuyNum, data.m_buy_times))
    else
        self.ui.m_exchagneNum:setVisible(false)
    end

    local m_buy_times = data.m_buy_times
    -- if m_buy_times > 0 then
    --     if  hasBuyNum >= m_buy_times then
    --         self.ui.m_okBtn:setEnabled(false)
    --     else
    --         self.ui.m_okBtn:setEnabled(true)
    --     end
    -- else
    --     self.ui.m_okBtn:setEnabled(true)
    -- end
    local canBuy = false
    if curNum >= needNum and 
        (m_buy_times == 0 or hasBuyNum < m_buy_times) 
        then
        self.ui.m_okBtn:setEnabled(true)
    else
        self.ui.m_okBtn:setEnabled(false)
    end
end

function ItemExchangeStoreCell:refreshIcon(itemId, idx)
    local iconNode = self.ui["m_iconNode"..idx]
    iconNode:removeAllChildren()
    if iconNode == nil then
        return -1
    end

    itemId = tostring(itemId)
    local itemData = {
        itemId = itemId,
        -- num = needNum,
    }
    local site = CCCommonUtilsForLua:getPropById(itemId, "material1")
    if site ~= "" then
        -- 装备
        itemData.type = 1
    else
        -- 道具
        itemData.type = 0
    end
    dump(site, "needItemId ["..itemId.."] site is : ")
    local LibaoCommonFunc = Drequire("game.LiBao.LibaoCommonFunc")
    LibaoCommonFunc.createDataItemTouchNode({
                itemData = itemData,
                iconNode = iconNode,
                iconSize = 130,
                numLabel = nil,
                -- beTouch = true,   默认可以触摸
                touchParentNode = self.m_info.parent,
                })

    return itemData.type
end

function ItemExchangeStoreCell:getItemNums()
    local info = self.m_info
    local shopData = info.data
    local count = 0
    if self.itemType == 1 then
        -- 装备数量
        local ret = EquipmentController:getMyEquipsByEquipIdNotOn(tostring(shopData.m_value_item))
        return #ret
    else
        local comumeItemID = tonumber(shopData.m_value_item)
        local tinfo = ToolController:call("getToolInfoForLua", comumeItemID)
        if tinfo == nil then
            return
        end
        count = tinfo:call("getCNT")
    end

    return count
end

function ItemExchangeStoreCell:onButton2Click()
    local info = self.m_info
    local shopData = info.data
    -- self.ui.m_okBtn:setEnabled(false)

    if  shopData.m_totalBuy - shopData.m_buy_times >= 0 then
        return
    end

    local comumeItemID = tonumber(shopData.m_value_item)
    local price = tonumber(shopData.m_value_item_num)
    local count = self:getItemNums()
    local maxBuyMoney = math.max(1, math.floor(count / price))

    local StoreBuyConfirmDialogForLua = Drequire("game.CommonPopup.StoreBuyConfirmDialogForLua")
    local params = {}
    params.itemId = shopData.m_item_id
    params.maxNum = (shopData.canBuyNum > 0) and (shopData.canBuyNum) or 20000
    params.maxNum = math.min(params.maxNum, maxBuyMoney)
    params.hasNum = count
    params.messagePosted = "ItemExchange_BuyConfirm"
    params.priceType = comumeItemID
    params.singlePoint = price
    params.moneyIcon = CCCommonUtilsForLua:call("getIcon", tostring(shopData.m_value_item))
    params.id = shopData.m_id

    local view = StoreBuyConfirmDialogForLua:create(params)
    PopupViewController:addPopupView(view)
end

return ItemExchangeStoreCell


