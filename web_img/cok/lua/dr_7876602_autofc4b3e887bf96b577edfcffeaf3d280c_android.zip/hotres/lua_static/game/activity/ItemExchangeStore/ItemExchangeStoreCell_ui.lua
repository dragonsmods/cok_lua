----------------------------
-- Author: Elex
-- Date: 2017-11-09 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local ItemExchangeStoreCell_ui = class("ItemExchangeStoreCell_ui")

--#ui propertys


--#function
function ItemExchangeStoreCell_ui:create(owner, viewType)
	local ret = ItemExchangeStoreCell_ui.new()
	CustomUtility:DoRes(8, true)
	CustomUtility:LoadUi("ItemExchangeStoreCell.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function ItemExchangeStoreCell_ui:initLang()
end

function ItemExchangeStoreCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function ItemExchangeStoreCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function ItemExchangeStoreCell_ui:onButton2Click(pSender, event)
	ButtonSmoker:forwardFunction(self, "onButton2Click", pSender, event)
end

return ItemExchangeStoreCell_ui

