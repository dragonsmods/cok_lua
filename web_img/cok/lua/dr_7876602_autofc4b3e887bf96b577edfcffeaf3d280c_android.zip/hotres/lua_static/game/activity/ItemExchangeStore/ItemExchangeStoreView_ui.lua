----------------------------
-- Author: Elex
-- Date: 2017-11-08 Wednesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local ItemExchangeStoreView_ui = class("ItemExchangeStoreView_ui")

--#ui propertys


--#function
function ItemExchangeStoreView_ui:create(owner, viewType)
	local ret = ItemExchangeStoreView_ui.new()
	CustomUtility:LoadUi("ItemExchangeStoreView.ccbi", ret, owner, true, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then		owner:initTableViewByOwner()
	else		ret:initTableView()	end	return ret
end

function ItemExchangeStoreView_ui:initLang()
end

function ItemExchangeStoreView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function ItemExchangeStoreView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function ItemExchangeStoreView_ui:onTipBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onTipBtnClick", pSender, event)
end

function ItemExchangeStoreView_ui:initTableView()
	TableViewSmoker:createView(self, "m_listTableView", "game.activity.ItemExchangeStore.ItemExchangeStoreCell", 1, 10, "ItemExchangeStoreCell")
end

function ItemExchangeStoreView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return ItemExchangeStoreView_ui

