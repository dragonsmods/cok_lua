--世界地图上的捐兵建筑
local COSDoanteSoldireTowerUnders = class("COSDoanteSoldireTowerUnders", function (  )
    return cc.Layer:create()
end)

local CASTLE_TAG = 1
local SOLDIRE_TAG = 2

function COSDoanteSoldireTowerUnders:ctor(cityInfo)
    local function onNodeEvent( event )
		if event == "enter" then
			self:onEnter()
	    elseif event == "exit" then
			self:onExit()
	    end
	end
    self:registerScriptHandler(onNodeEvent)
    self:initView(cityInfo)
end

function COSDoanteSoldireTowerUnders:initView(cityInfo)
    CCLoadSprite:call("loadDynamicResourceByName", "COSAct_face")
    --数据
    local pos = cityInfo:call("GetPositionInMap")
    -- dump(pos,"hxq pos is ")
    if pos.x >= 462000 then
        self.pos_dir = 1
    else
        self.pos_dir = 0
    end
    self.soldireNode = cc.Node:create()
    self.castleNode = cc.Node:create()
    self:addChild(self.soldireNode)
    self:addChild(self.castleNode)
    self:createCastleAni()
end

function COSDoanteSoldireTowerUnders:createCastleAni()     
    --1.状态
    --2.位置
    local state = 1 --0:dj / 1:gj
    --王座后侧:E  /王座上方:S   
    local direction = "E"
    local utils = cc.FileUtils:getInstance()
    local wpath = utils:getWritablePath()
    local dpath = wpath .. "dresource/"
    local json = dpath .. "COSDonateSoldireTower.json"
    local atlas = dpath .. "sk_COSDonateSoldireTower.atlas"
    if self.pos_dir ~= 0 then
        direction = "S"
    end
    if cc.FileUtils:getInstance():isFileExist(json) == true and cc.FileUtils:getInstance():isFileExist(atlas) == true then 
        local animationObj = IFSkeletonAnimation:call("create", json, atlas)
        if animationObj then 
            animationObj:setToSetupPose()
			animationObj:setAnimation(0, direction.."_dj", true) --初始状态都是待机
            -- animationObj:setPosition(cc.p(0,-100))
            animationObj:setTag(CASTLE_TAG)
            self.castleNode:addChild(animationObj)            
        end
    end
end

--士兵，火炮
function COSDoanteSoldireTowerUnders:showBattleAni()  
    self.soldireNode:stopAllActions()
    self.soldireNode:removeAllChildren()
    local castleAni = self.castleNode:getChildByTag(CASTLE_TAG)
    if castleAni then
        local direction = "E"
        if self.pos_dir ~= 0 then
            direction = "S"
        end
        castleAni:setAnimation(0,direction.."_dj",true)   
    end
    local function setCastleAni()        
        if castleAni then
            local direction = "E"
            if self.pos_dir ~= 0 then
                direction = "S"
            end
            castleAni:setAnimation(0,direction.."_gj",true)
        end
    end
    
    local function createSoldire()
        self.soldireNode:removeAllChildren()
        local dir = "SW_"
        local pos = ccp(0,0)
        local rota = -20
        if self.pos_dir ~= 0 then
            dir = "W_"
            pos = ccp(200,30)
            rota = -20
        end
        local flipX = self.pos_dir == 0 and true or false
        local armyList = FictitiousMarchArmy:call("create",false,false,dir,flipX)               
        tolua.cast(armyList, "cc.Node")
        armyList:setScale(0.75)
        armyList:setTag(25)
        armyList:setRotation(rota)               
        self.soldireNode:addChild(armyList)
        self.soldireNode:setPosition(pos)                
    end
    local function soldireAttack()
        local soldire = self.soldireNode:getChildByTag(25)                
        if soldire then
            tolua.cast(soldire, "cc.Node")            
            -- local rota = self.pos_dir == 0 and 75 or 0
            -- soldire:setRotation(rota)
            tolua.cast(soldire, "FictitiousMarchArmy")
            soldire:call("armyAttackAndDisappear",8)
        end
    end 
    local endPos = self.pos_dir == 0 and ccp(160,-100) or ccp(-50,-100)
    local move_to = cc.MoveTo:create(2.0,endPos)
    local delay = cc.DelayTime:create(8)
    local func0 = cc.CallFunc:create(setCastleAni)          
    local func1 = cc.CallFunc:create(createSoldire)
    local func2 = cc.CallFunc:create(soldireAttack)
    local func3 = cc.CallFunc:create(function() 
        if castleAni then
            local direction = "E"
            if self.pos_dir ~= 0 then
                direction = "S"
            end
            castleAni:setAnimation(0,direction.."_dj",true)
        end
    end)
    local seq = cc.Sequence:create(func0,func1,move_to,func2,delay,func3)    
    self.soldireNode:runAction(seq)    
end

function COSDoanteSoldireTowerUnders:refreshView(data)
    self:showBattleAni()
end

function addCOSDoanteSoldireTowerUnders( index )
    dump(index,"hxq addCOSDoanteSoldireTowerUnders index is ")
	local world = WorldMapView:call("instance")
    if nil == world then
        return nil
    end
    local cityInfo = WorldController:call("getCityInfoByIndex", index)
    if nil == cityInfo then
        return nil
    end
    if cityInfo:getProperty("luaType") ~= WorldCityType.DonateSoldire then
        return nil
    end
    local pos = cityInfo:call("GetPositionInMap")    
    local ret = CCArray:create()
    local under = COSDoanteSoldireTowerUnders.new(cityInfo )
    under:setTag(index)
    under:setPosition(cc.p(pos.x, pos.y))
    ret:addObject(under)
    world:call("getCityBatchNode"):addChild(under, index)    
    return ret
end

function COSDoanteSoldireTowerUnders:onEnter()

    dump("hxq COSDoanteSoldireTowerUnders:onEnter()")
    registerScriptObserver(self,self.refreshView,"msg.COSDataChange.refreshView")
    -- --测试
    -- if self.entery ~= nil then
    --     self.entery = nil
    -- end      
    -- self.entry = tonumber(self:getScheduler():scheduleScriptFunc(function(dt) self:updateTime(dt) end, 12, false))
end

function COSDoanteSoldireTowerUnders:onExit()
    unregisterScriptObserver(self,"msg.COSDataChange.refreshView")
    -- if self.entry then
	-- 	self:getScheduler():unscheduleScriptEntry(self.entry)
	-- 	self.entry = nil
    -- end 
end

--ceshi
function COSDoanteSoldireTowerUnders:updateTime(dt)
    self:showBattleAni()
end
return COSDoanteSoldireTowerUnders