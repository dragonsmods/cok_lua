local AllianceQuicklyKillMonsterView = class("AllianceQuicklyKillMonsterView",
function ( )
    return ArcPopupBaseView:call("create", 5)
end)

AllianceQuicklyKillMonsterView.__index = AllianceQuicklyKillMonsterView

-- local AllianceQuicklyKillMonsterActivityId = "57405"
function AllianceQuicklyKillMonsterView:create()
    local view = AllianceQuicklyKillMonsterView.new()
    CCLoadSprite:call("loadDynamicResourceByName", "AllServerRank_face")
    Drequire("game.activity.AllianceQuicklyKillMonster.AllianceQuicklyKillMonsterView_ui"):create(view)
    if view:initView() then
        return view
    end
end

function AllianceQuicklyKillMonsterView:ctor()
    self.ctl = Drequire("game.activity.AllianceQuicklyKillMonster.AllianceQuicklyKillMonsterController").new()
end

function AllianceQuicklyKillMonsterView:initView()
    local mlv = FunBuildController:call("getMainCityLv")
    if tonumber(mlv) < 10 then
        LuaController:flyHint("", "", getLang("182212"))
        return false
    end
    -- local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
    -- local isInAlliance = playerInfo:call("isInAlliance")
    -- if not isInAlliance then
    --     LuaController:flyHint("", "", getLang("182207"))
    --     return false
    -- end
    registerNodeEventHandler(self)

    self.ctl:reqQuicklyKillMonsterInfo()
    CCLoadSprite:call("loadDynamicResourceByName", "COSAct_face")  
    -- self.NpcPos = self.ctl.NpcPosition
    local viewSize = self:getContentSize()
    local realSize = cc.Director:getInstance():getIFWinSize()
    local base_height = 852
    if CCCommonUtilsForLua:isIosAndroidPad() then
        base_height = 2048                
    end
    local dis_height = realSize.height - base_height    
    if dis_height > 0 then
        --节点适配调整
        self.ui.m_loardInfoNode:setPositionY(self.ui.m_loardInfoNode:getPositionY() + dis_height)
        
        local bgSize = self.ui.m_bgSpr:getContentSize()        
        self.ui.m_bgSpr:setContentSize(cc.size(bgSize.width,bgSize.height + dis_height))

        self.ui.m_upCellNode:setPositionY(self.ui.m_upCellNode:getPositionY() + dis_height)

        local listNodeSize = self.ui.m_listNode:getContentSize()
        self.ui.m_listNode:setContentSize(cc.size(listNodeSize.width,listNodeSize.height + dis_height))

        self.ui.m_rankOneHeadNode:setPositionY(self.ui.m_rankOneHeadNode:getPositionY() + dis_height)
        
        local nodeSize = self.ui.m_countryRankListNode:getContentSize()
        self.ui.m_countryRankListNode:setContentSize(cc.size(nodeSize.width,nodeSize.height + dis_height))
        self.ui.m_ServerRankNode:setPositionY(self.ui.m_ServerRankNode:getPositionY() + dis_height)

        -- nodeSize = self.ui.m_playerRankListNode:getContentSize()
        -- self.ui.m_playerRankListNode:setContentSize(cc.size(nodeSize.width,nodeSize.height + dis_height))        
    end
    self.ui.m_bgSpr:setContentSize(realSize)
    self.ui.m_AdViewNode:setVisible(true)
    --限时活动
    local scrollView = cc.ScrollView:create()
    scrollView:setViewSize(self.ui.m_listNode:getContentSize())
    scrollView:ignoreAnchorPointForPosition(true)
    scrollView:setDirection(1)
    scrollView:setClippingToBounds(true)
    scrollView:setBounceable(true)
    scrollView:setTouchEnabled(true)
    self.ui.m_listNode:addChild(scrollView)
    self.m_actScrollView = scrollView
    
    --服务器排行
    local scrollView2 = cc.ScrollView:create()
    scrollView2:setViewSize(self.ui.m_countryRankListNode:getContentSize())
    scrollView2:ignoreAnchorPointForPosition(true)
    scrollView2:setDirection(1)
    scrollView2:setClippingToBounds(true)
    scrollView2:setBounceable(true)
    scrollView2:setTouchEnabled(true)
    self.ui.m_countryRankListNode:addChild(scrollView2)
    self.m_countryRankScrollView = scrollView2

    -- --玩家排行
    -- local scrollView3 = cc.ScrollView:create()
    -- scrollView3:setViewSize(self.ui.m_playerRankListNode:getContentSize())
    -- scrollView3:ignoreAnchorPointForPosition(true)
    -- scrollView3:setDirection(1)
    -- scrollView3:setClippingToBounds(true)
    -- scrollView3:setBounceable(true)
    -- scrollView3:setTouchEnabled(true)
    -- self.ui.m_playerRankListNode:addChild(scrollView3)
    -- self.m_playerRankScrollView = scrollView3

    self.btn_index = 1
    self:setButtonState()
    self.ui.m_rankNode:setVisible(false)
    self.ui.m_rankBGNode:setVisible(false)
    self.ui.m_playerRankListNode:setVisible(false)
    self.ui.m_countryRankListNode:setVisible(false) 
    self.ui.m_ServerRankNode:setVisible(true)  
    self.ui.m_btnCountry:setEnabled(false)
    self.ui.m_btnPlayer:setEnabled(false)
    self.ui.m_titleTxt:setString(getLang("182188")) -- 天罗地网

    self:registerListener()
    return true
end

function AllianceQuicklyKillMonsterView:onEnter()
    -- registerScriptObserver(self,self.getRankInfo,"msg.CommonRankAct.getRankInfo")
    self:onEnterFrame(0)
	if self.entry then
		self:getScheduler():unscheduleScriptEntry(self.entry)
	end
	self.entry = tonumber(self:getScheduler():scheduleScriptFunc(function(dt)
		self:onEnterFrame(dt)
	end, 1, false))   
end

function AllianceQuicklyKillMonsterView:onExit()
    -- unregisterScriptObserver(self,"msg.CommonRankAct.getRankInfo")
    self:getScheduler():unscheduleScriptEntry(self.entry)
end

function AllianceQuicklyKillMonsterView:onCleanup()
	self:unregisterListener()
end

function AllianceQuicklyKillMonsterView:registerListener()
    registerScriptObserver(self, self.refreshView,"msg.AllianceQuicklyKillMonsterView.refreshView")
    registerScriptObserver(self, self.requestBuffCount, MSG_REFREASH_TOOL_DATA)
    registerScriptObserver(self, self.refreshItemEffectTimesView, "msg.AllianceQuicklyKillMonsterView.refreshBuffCount")
end

function AllianceQuicklyKillMonsterView:unregisterListener()
    unregisterScriptObserver(self, "msg.AllianceQuicklyKillMonsterView.refreshView")
    unregisterScriptObserver(self, MSG_REFREASH_TOOL_DATA)
    unregisterScriptObserver(self, "msg.AllianceQuicklyKillMonsterView.refreshBuffCount")
end

function AllianceQuicklyKillMonsterView:onEnterFrame(dt)
    --m_timeLabel
    if self.ctl:getStateOpen() == 0 then
        self.ui.m_timeLabel:setString("")
        return
    elseif self.ctl:getStateOpen() == 2 then
        self.ui.m_timeLabel:setString(getLang("168108"))
        return
    elseif self.ctl:getStateOpen() == 3 then
        self.ui.m_timeLabel:setString(getLang("176075"))
        return
    end
    local endAt = self.ctl:activityEndAt()
    if endAt and endAt > 0 then
        local nowtime = getTimeStamp()
        local eT = endAt / 1000
        local lessTime = eT - nowtime
        if lessTime >= 0 then
            self.ui.m_timeLabel:setString(CC_SECTOA(lessTime))
        else
            self.ui.m_timeLabel:setString(getLang("4249604"))
            if self.entry then
                self:getScheduler():unscheduleScriptEntry(self.entry)
            end
        end
    else
        self.ui.m_timeLabel:setString("")
    end
end

function AllianceQuicklyKillMonsterView:refreshView()
    self:setViewCells()
    self:setLoardInfoCell()
    self:refreshItemEffectTimesView()
    self:onEnterFrame(0)
end

--数据封装完毕，加载排行榜各组件
function AllianceQuicklyKillMonsterView:setViewCells()
    --限时活动
    -- local cellTbl = {
    --     --积分获取列表
    --     "RankActMethodCell",
    --     --活动积分宝箱列表
    --     "RankActScoreCell",
    -- }

    local actMethodInfo = self.ctl:getActMethodInfo()
    local actScoreInfo = self.ctl:getActScoreInfo()
    local cellTbl = {
        Drequire("game.CommonPopup.RankActComponent.RankActMethodCell"):create(viewSize, actMethodInfo),
        Drequire("game.CommonPopup.RankActComponent.RankActScoreCell"):create(viewSize, actScoreInfo),
    }
 
    -- self.RankActDataController:setDataByKey("methodData",methodData)
    -- self.RankActDataController:setDataByKey("totalScoreData",totalScoreData)

    local viewSize = self:getContentSize()
    local curY = 0
    local filePath = "game.CommonPopup.RankActComponent."
    for index = 1,#cellTbl do
        self.m_actScrollView:removeChildByTag(index)        
        local cell = cellTbl[index] -- Drequire(filePath..cellTbl[index]):create(viewSize)
        cell:setPositionY(curY)
        curY = curY + cell:getContentSize().height
        cell:setTag(index)
        self.m_actScrollView:addChild(cell)
    end
    self.m_actScrollView:setContentSize(cc.size(viewSize.width,curY))
    self.m_actScrollView:setContentOffset(ccp(0,self.ui.m_listNode:getContentSize().height - curY))

    local allServerFirstInfo = self.ctl:getAllServerFirstInfo()
    dump(allServerFirstInfo, "allServerFirstInfo")
    --headNodeCell
    local HeadNodeCell = Drequire(filePath.."RankActKingHeadCell"):create(viewSize, allServerFirstInfo)
    self.ui.m_rankOneHeadNode:removeChildByTag(25)
    self.ui.m_rankOneHeadNode:addChild(HeadNodeCell,2000,25)

end

function AllianceQuicklyKillMonsterView:setButtonState()
    for index = 1,3 do
        if index ~= self.btn_index then
            self.ui['m_btn'..index]:setEnabled(true)
        end
    end
    self.ui['m_btn'..self.btn_index]:setEnabled(false)
end

--限时活动
function AllianceQuicklyKillMonsterView:onClickBtnActive( )
    self.btn_index = 1
    self:setButtonState()
    self.ui.m_activityNode:setVisible(true)
    self.ui.m_rankNode:setVisible(false)
    self.ui.m_rankBGNode:setVisible(false)
    self.ui.m_playerRankListNode:setVisible(false)
    self.ui.m_countryRankListNode:setVisible(false)    
end

--全服
function AllianceQuicklyKillMonsterView:onClickBtnALL( )
    self.rankServerType = "full_server"
    self:onClickCountry()
	self.btn_index = 2
    self:setButtonState()
    self.ui.m_activityNode:setVisible(false)
    self.ui.m_rankNode:setVisible(true)
    self.ui.m_rankBGNode:setVisible(true)
    self.ui.m_playerRankListNode:setVisible(false)
    self.ui.m_countryRankListNode:setVisible(true)  
    self.ui.m_ServerRankNode:setVisible(true)   
end

--本服
function AllianceQuicklyKillMonsterView:onClickBtnLocal( )
    self.rankServerType = "my_server"
    self:onClickCountry()
    -- CCSafeNotificationCenter:call("postNotification", "msg.RankActPlayerRankListCell.close")
    --玩家排行
    -- local viewType = 1
    -- local filePath = "game.CommonPopup.RankActComponent."
    -- local rankActPlayerRankListCell = Drequire(filePath.."RankActPlayerRankListCell"):create(viewType,self:getContentSize())
    -- rankActPlayerRankListCell:setTag(25)        
    -- self.m_playerRankScrollView:addChild(rankActPlayerRankListCell)
    
    -- local nodeSize = self.ui.m_playerRankListNode:getContentSize()    
    -- local offsetY = nodeSize.height - self:getContentSize().height
    -- self.m_playerRankScrollView:setContentSize(self:getContentSize())
    -- self.m_playerRankScrollView:setContentOffset(ccp(0,offsetY))

	self.btn_index = 3
    self:setButtonState()
    self.ui.m_activityNode:setVisible(false)
    self.ui.m_rankNode:setVisible(true)
    self.ui.m_rankBGNode:setVisible(true)
    self.ui.m_playerRankListNode:setVisible(false)
    self.ui.m_countryRankListNode:setVisible(true)
    self.ui.m_ServerRankNode:setVisible(true) 
end

-- 联盟排行
function AllianceQuicklyKillMonsterView:onClickCountry()
    self.ui.m_btnPlayer:setEnabled(true)
    self.ui.m_btnCountry:setEnabled(false)
    -- CCSafeNotificationCenter:call("postNotification", "msg.RankActPlayerRankListCell.close")
    -- CCSafeNotificationCenter:call("postNotification", "msg.RankActCountryRankListCell.close")
    -- --服务器排行
    -- local filePath = "game.CommonPopup.RankActComponent."
    -- local rankActCountryRankListCell = Drequire(filePath.."RankActCountryRankListCell"):create(self:getContentSize())
    
    local rankType = "monster_hunter_alliance"
    local rankGroup = 1
    if self.rankServerType == "full_server" then
        rankGroup = 2
    end
    local params = {
        type = rankType,
        viewType = rankGroup,
        viewSize = self:getContentSize(),
        pageSize = 20,
    }
    if self.rankView then
        self.rankView:removeFromParent()
    end
    self.rankView = Drequire("game.CommonPopup.commonRank.CommonRankView"):create(params)
    -- self.m_countryRankScrollView:removeChildByTag(1111)
    self.m_countryRankScrollView:addChild(self.rankView)
    -- rankView:setTag(1111)    
    local nodeSize = self.ui.m_countryRankListNode:getContentSize()    
    local offsetY = nodeSize.height - self:getContentSize().height
    self.m_countryRankScrollView:setContentSize(self:getContentSize())
    self.m_countryRankScrollView:setContentOffset(ccp(0,offsetY)) 


end

-- 个人排行
function AllianceQuicklyKillMonsterView:onClickBtnPlayer()
    self.ui.m_btnPlayer:setEnabled(false)
    self.ui.m_btnCountry:setEnabled(true)
    -- CCSafeNotificationCenter:call("postNotification", "msg.RankActCountryRankListCell.close")
    -- CCSafeNotificationCenter:call("postNotification", "msg.RankActPlayerRankListCell.close")
    -- --全服玩家排行    
    -- local viewType = 2
    -- local filePath = "game.CommonPopup.RankActComponent."
    -- local rankActPlayerRankListCell = Drequire(filePath.."RankActPlayerRankListCell"):create(viewType,self:getContentSize())  
    
    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")

    local selfId = playerInfo:getProperty("uid")
    local rankType = "monster_hunter_personal"
    local rankGroup = 1
    if self.rankServerType == "full_server" then
        rankGroup = 2
        if playerInfo:call("isInAlliance") then
            selfId = playerInfo:call("getAllianceId")
        else
            selfId = nil
        end
    end
    local params = {
        type = rankType,
        viewType = rankGroup,
        viewSize = self:getContentSize(),
        pageSize = 20,
        selfId = selfId
    }
    if self.rankView then
        self.rankView:removeFromParent()
    end
    self.rankView = Drequire("game.CommonPopup.commonRank.CommonRankView"):create(params)     
    -- self.m_countryRankScrollView:removeChildByTag(2222)
    self.m_countryRankScrollView:addChild(self.rankView)
    -- rankView:setTag(2222)
    local nodeSize = self.ui.m_countryRankListNode:getContentSize()    
    local offsetY = nodeSize.height - self:getContentSize().height
    self.m_countryRankScrollView:setContentSize(self:getContentSize())
    self.m_countryRankScrollView:setContentOffset(ccp(0,offsetY))

end


function AllianceQuicklyKillMonsterView:onClickBtnInfo( )
    -- local view = Drequire("game.activity.CallOfSoldiresAct.COSDonateSoldireInfoView"):create()
    -- PopupViewController:addPopupView(view)
    --数据来源
    -- local actId = "57405"
	local view = Drequire('game.CommonPopup.RankActComponent.RankActInfoView').create(self.ctl:getActivityId())
    PopupViewController:addPopupView(view)
    
end

function AllianceQuicklyKillMonsterView:onAddEffectClick()
    local params = {
        more = true,
        moreText = "105086"
    }
    local view = Drequire("game.CommonPopup.UseToolView"):create(USE_TOOL_KILL_MONSTER_EFFECT, luaToDict(params), "182238")
    PopupViewController:addPopupInView(view)
    -- if self:hasItemsAddEffect() then
        
    -- else
    --     local TO_BUY_ADD_EFFECT_ITEM_ID = ""
    --     self.addEftItemId = self.addEftItemId or TO_BUY_ADD_EFFECT_ITEM_ID
    --     local ItemGetMethodView = Drequire("game.CommonPopup.ItemGetMethodView")
    --     PopupViewController:call("addPopupView", ItemGetMethodView:create(self.addEftItemId))
    -- end
end

-- function AllianceQuicklyKillMonsterView:hasItemsAddEffect()
--     local CONTROL_CONFIG_ID = "30435112"
--     local res = false
-- 	local xmlItemIds = CCCommonUtilsForLua:getGroupByKey("control") --读取单次造兵加成道具的id{}

-- 	if xmlItemIds and xmlItemIds[CONTROL_CONFIG_ID] then
-- 		local toolIds = xmlItemIds[CONTROL_CONFIG_ID].k1
-- 		toolIds = string.split(toolIds,";")
-- 		if #toolIds > 0 then
-- 			self.addEftItemId = toolIds[1]
-- 		end
-- 		for k,v in pairs(toolIds or {}) do
-- 			local info = ToolController:call("getToolInfoByIdForLua", tonumber(v))
-- 			if info and (info:call("getCNT") > 0) then
-- 				res = true
-- 				break
-- 			end
-- 		end
-- 	end
-- 	return res
-- end

--设置玩家信息Node: m_loardInfoNode
function AllianceQuicklyKillMonsterView:setLoardInfoCell()
    --头像设置
    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	local info_pic      = playerInfo:getProperty("pic")
	local info_picVer   = playerInfo:getProperty("picVer")
	local info_uid      = playerInfo:getProperty("uid")
	local info_picfraId = playerInfo:getProperty("picfraId")
    local headIcon = CCCommonUtilsForLua:call("makeUserHeadIcon", info_uid, info_pic, info_picfraId, info_picVer, 95)
    self.ui.m_nodeHead:removeAllChildren()
    self.ui.m_nodeHead:addChild(headIcon)
    
    --信息设置    
    -- 全服排名
    local _globalRank = self.ctl:myRankOfFullServer()
    if _globalRank <= 0 then
        self.ui.m_rankGlobal:setString(getLang("138014"))	--182079=全服排名	138014=当前没有排名		
    else
        self.ui.m_rankGlobal:setString(getLang("182079")..": ".. CC_CMDITOAL(_globalRank))--182079=全服排名
    end

    -- 本服排名
    local _localRank = self.ctl:myRankOfMyServer()
    if _localRank <= 0 then
        self.ui.m_rankLocal:setString(getLang("138014"))	--182080=本服排名	138014=当前没有排名	
    else		
        self.ui.m_rankLocal:setString(getLang("182080")..": ".. CC_CMDITOAL(_localRank))--182080=本服排名
    end

    -- 本期个人总积分
    local score = self.ctl:myTotalScore()
    self.ui.m_valuePowerSelf:setString(CC_CMDITOAL(score))  

    -- 联盟杀怪总积分
    score = self.ctl:allianceScore()
    if not score then
        self.ui.m_valuePowerAlliance:setString("-")
    else
        self.ui.m_valuePowerAlliance:setString(CC_CMDITOAL(score))  
    end

end

function AllianceQuicklyKillMonsterView:refreshItemEffectTimesView()
    if self.ctl:getAddEffectTimes() > 0 then
        self.ui.m_tipsEffect:setString(getLang("182237", self.ctl:getAddEffectTimes()))
    else
        self.ui.m_tipsEffect:setString(getLang("182236"))
    end
end

function AllianceQuicklyKillMonsterView:requestBuffCount()
    self.ctl:requestBuffCount()
end


return AllianceQuicklyKillMonsterView