--[[ 
    广告控制类
    2019.6.10   Awen
 ]]

 local LuaAdController = class("LuaAdController")

 AD_TYPE = {
    HERO_DRAW_NORMAL = 1    --普通英雄招募
    ,HERO_DRAW_SENIOR = 2    --高级英雄招募
    ,MAGIC_DRAW_NORMAL = 3   --普通魔法抽卡
    ,MAGIC_DRAW_SENIOR = 4  --高级魔法抽卡
    ,CIVI_CRYSTAL = 5 --文明结晶
    -- ,BUILDING = 6 --建造加速
    -- ,SOLDIER_FORCE = 7 --步兵
    -- ,SOLDIER_RIDE = 8 --骑兵
    -- ,SOLDIER_BOW = 9 --弓兵
    -- ,SOLDIER_CAR = 10 --车
    -- ,HOSPITAL = 11 --医院
    -- ,SCIENCE = 12 --科研
   
 }

--[[  
##队列加速暂时搁置
--广告队列加速
local CheckQueueType = 
{
    TYPE_BUILDING = 0,--建筑0
    TYPE_FORCE = 1,--步兵
    TYPE_HOSPITAL = 3, --医院
    TYPE_SCIENCE = 6, --科技
    TYPE_RIDE_SOLDIER = 8, --骑8
    TYPE_BOW_SOLDIER = 9,  --弓9
    TYPE_CAR_SOLDIER =10,  --车10
}
--队列加速映射广告类型
local QueueType2AdType = {
    [CheckQueueType.TYPE_BUILDING] = AD_TYPE.BUILDING, --建筑加速
    [CheckQueueType.TYPE_FORCE] = AD_TYPE.SOLDIER_FORCE,--步兵
    [CheckQueueType.TYPE_RIDE_SOLDIER] = AD_TYPE.SOLDIER_RIDE,--骑兵
    [CheckQueueType.TYPE_BOW_SOLDIER] = AD_TYPE.SOLDIER_BOW,--弓兵
    [CheckQueueType.TYPE_CAR_SOLDIER] = AD_TYPE.SOLDIER_CAR,
    [CheckQueueType.TYPE_HOSPITAL] = AD_TYPE.HOSPITAL,--医院
    [CheckQueueType.TYPE_SCIENCE] = AD_TYPE.SCIENCE, --科研
} ]]

 --处理回调
 local CALL_BACK = {
     [AD_TYPE.HERO_DRAW_NORMAL] =  function(params)
        HeroLuckDrawController:reqLuckDrawByAd(AD_TYPE.HERO_DRAW_NORMAL)
     end
     ,[AD_TYPE.HERO_DRAW_SENIOR] = function(params)
        HeroLuckDrawController:reqLuckDrawByAd(AD_TYPE.HERO_DRAW_SENIOR)
     end
     ,[AD_TYPE.MAGIC_DRAW_NORMAL] =  function(params)
        MagicLuckDrawController:reqLuckDrawByAd(AD_TYPE.MAGIC_DRAW_NORMAL)
     end
     ,[AD_TYPE.MAGIC_DRAW_SENIOR] = function(params)
        MagicLuckDrawController:reqLuckDrawByAd(AD_TYPE.MAGIC_DRAW_SENIOR)
     end
     ,[AD_TYPE.CIVI_CRYSTAL] = function(params)
        CCSafeNotificationCenter:postNotification("msg.adClose.refresh")
     end
 }
 ---------------------------------------------------- 
 --[[ 
     获取广告基础数据
  ]]
local AdDataCmd = class("AdDataCmd", LuaCommandBase)
function AdDataCmd.req(types)
    Dprint("AdDataCmd.create", types)
    local ret = AdDataCmd.new()
    ret:initWithName("newgeneral.getdata")
    ret:putParam("videoStr", CCString:create(types))
    ret:send()
end

function AdDataCmd:handleReceive(dict)
    local flag, params = self:parseMsg(dict)
    Dprint("AdDataCmd:handleReceive | parse flag=", flag)
    if (type(flag) == "boolean") then
        return flag
    end
    
    dump(flag, "AdDataCmd:handleReceive -->")
    LuaAdController.getInstance():refreshData(flag)
    return true
end
 
 
 ---------------------------------------------------- 
local _instance = nil
function LuaAdController.getInstance()
    if _instance == nil then
        _instance = LuaAdController.new()
    end
    return _instance
end

-- 接收CPP调用
function LuaAdController:fireEventRef(newKey, dict)
    Dprint("LuaAdController:fireEventRef", newKey)
    if newKey == "init" then
        self:initAd()
    elseif newKey == "callback" then
        local _type = dict:valueForKey('type'):intValue()
        self:callback(_type)
    elseif newKey == "checkState" then
        self:checkShowState(dict)
    elseif newKey == "playVideo" then
        self:checkAndPlay(dict)
    end
end
 
-- 是否开启
function LuaAdController:isOpen()
    return self.v_isInitAd and CCCommonUtilsForLua:isFunOpenByKey("google_video")
end

-- 初始化广告
function LuaAdController:initAd( )
    Dprint('LuaAdController:initAd')
    if CCCommonUtilsForLua:isFunOpenByKey("google_video") then
        local _analyticID = GlobalData:call("shared"):getProperty("analyticID")
        local _config = CCCommonUtilsForLua:call("getPropByIdGroup","data_config","google_ad_sdk2","k1")
        if _config then
            self.v_isInitAd = false
            self.v_showReward = 0
            for k,v in ipairs(string.split(_config, ';') or {}) do
                if _analyticID == v then
                    self.v_isInitAd = true
                    break
                end
            end

            if self.v_isInitAd then
                local _aid, _uid = nil, nil
                if isIOS() then
                    _aid = CCCommonUtilsForLua:call("getPropByIdGroup","data_config","google_ad_sdk2","k7")
                    _uid = CCCommonUtilsForLua:call("getPropByIdGroup","data_config","google_ad_sdk2","k3")
                else
                    _aid = CCCommonUtilsForLua:call("getPropByIdGroup","data_config","google_ad_sdk2","k8")
                    _uid = CCCommonUtilsForLua:call("getPropByIdGroup","data_config","google_ad_sdk2","k4")
                end
                AdVideoController:call("getInstance"):call("initAd", _aid, _uid)
            end
            Dprint('LuaAdController:initAd = ', _analyticID, self.v_isInitAd)
        end
        -- self:getAllADTypeData()
    end
end

-- 获取数据
function LuaAdController:getData( typeList )
    Dprint('LuaAdController:getData', self:isOpen())
    if self:isOpen() and typeList then
        local _types = ''
        for k,v in ipairs(typeList) do 
            _types = _types .. v
            if k < #typeList then
                _types = _types .. ';'
            end
        end
        self.v_showReward = 0

        AdDataCmd.req(_types)
    end
end

-- 设置数据
function LuaAdController:refreshData( data )
    if data then
        self.v_nextAd = cc.UserDefault:getInstance():getIntegerForKey("AdVideo_nextAd", 0)
        self.v_data = self.v_data or {}
        for _,v in pairs(data.arr or {}) do
            self.v_data[tonumber(v.type)] = {
                cur = tonumber(v.hasWatchTimes) or 0,
                max = tonumber(v.maxTimes) or 0,
                open = tonumber(v.videoOpen) or 0,
                rewardId = v.rewardId or nil
            }
        end

        -- dump(self.v_data, 'LuaAdController:refreshData')
        CCSafeNotificationCenter:postNotification("LuaAdController:refreshData")
    end
end

function LuaAdController:setData( data )
    dump(data, 'LuaAdController:setData')
    if data then
        if data.videoHasWatch then
            self.v_data[tonumber(data.type)].cur = tonumber(data.videoHasWatch) or 0
            self.v_showReward = 1
            LogController:postEventLog("LuaAdController", {tag='reward'})
        end
        if data.videoMaxTimes then
            self.v_data[tonumber(data.type)].max = tonumber(data.videoMaxTimes) or 0
        end
    end
end

-- 是否能播放视频
function LuaAdController:isCanPlay()
    local _isCan = AdVideoController:call("getInstance"):call("isCanPlay")
    LogController:postEventLog("LuaAdController", {tag='isShow',isCan=_isCan})
    return _isCan
end

function LuaAdController:getDataByTypes( type1, type2 )
    type1 = tonumber(type1) or 0
    type2 = tonumber(type2) or 0
    local _data1, _data2 = nil, nil
    if self:isOpen() and self.v_data then
        if self.v_data[type1] then
            _data1 = self.v_data[type1]
        end
        if self.v_data[type2] then
            _data2 = self.v_data[type2]
        end
    end
    return _data1, _data2
end

-- 下次可播放视频的时间戳
function LuaAdController:getNextAdStamp()
    return self.v_nextAd or 0
end

-- 播放视频广告
function LuaAdController:playVideo( type )
    if self:isOpen() then
        -- if AdVideoController:call("getInstance"):call("isCanPlay") then
            AdVideoController:call("getInstance"):call("playAd", type)

            self.v_showReward = 0
            -- 计算CD
            local _cd = tonumber(CCCommonUtilsForLua:call("getPropByIdGroup","data_config","google_ad_sdk2","k6")) or 60
            self.v_nextAd = _cd + getTimeStamp()
            cc.UserDefault:getInstance():setIntegerForKey("AdVideo_nextAd", self.v_nextAd);
            Dprint("LuaAdController:playVideo next", self.v_nextAd)
            LogController:postEventLog("LuaAdController", {tag='play'})
        -- else
        --     -- 10010015=视频准备中，请稍后再试
        --     LuaController:flyHint("", "", getLang('10010015'))
        -- end
    end
end

-- 视频播放完成回调
function LuaAdController:callback( type )
    local scheduler = cc.Director:getInstance():getScheduler()
    if self.m_entryId then  
        scheduler:unscheduleScriptEntry(self.m_entryId)              
        self.m_entryId = nil
    end
    Dprint("LuaAdController:callback", type)
    local function callBack()
        if CALL_BACK[type] then
            CALL_BACK[type]()
        end
        scheduler:unscheduleScriptEntry(self.m_entryId)
        self.m_entryId = nil
    end
    self.m_entryId = scheduler:scheduleScriptFunc(function() callBack() end, 0.5, false)
    LogController:postEventLog("LuaAdController", {tag='callback',type=type})
end
 
--获取当前所有类型的广告状态
function LuaAdController:getAllADTypeData()
    local params = {}
    for k,v in pairs(AD_TYPE) do
        table.insert(params,v)
    end
    self:getData(params)
end

-- --检查是否满足广告首弹前提(取消)
-- function LuaAdController:checkPopUpCondiction()     
--     for _,checkType in pairs(CheckQueueType) do
--         local qid = QueueController:call("getMinTimeQidByType", checkType)
--         local allQueuesInfo = GlobalData:call("shared"):getProperty("allQueuesInfo")
--         local qInfo = allQueuesInfo[qid]     
--         if qid ~= QID_MAX and qInfo ~= nil then

--             break
--         end 
--     end
-- end

--根据type检查是否满足广告展示状态
function LuaAdController:checkShowState(dict)
    local res = false
    if not self:isCanPlay() then return res end
    local type = dict:valueForKey("type"):intValue()
    local data = self:getDataByTypes(type)
    if data.open == 1 and data.cur < data.max then
        dict:setObject(CCInteger:create(1),"state")
        dict:setObject(CCInteger:create(data.cur),"curTime")
        dict:setObject(CCInteger:create(data.max),"maxTime")        
        res = true
    end
    return res
end
--提供给c的播放视频调用
function LuaAdController:checkAndPlay(dict)
    local type = dict:valueForKey("type"):intValue()
    if self:checkShowState(type) then
        self:playVideo(type)
        local cdTime = self:getNextAdStamp()
        dict:setObject(CCString:create(tostring(cdTime)),"nextAdStamp")        
    end
end
return LuaAdController