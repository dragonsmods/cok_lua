--观看广告奖励道具,该界面设计只能显示一条奖励信息
local ADRwdShowView = class("ADRwdShowView",PopupBaseView)
local LuaAdController = require("game.controller.LuaAdController").getInstance()
function ADRwdShowView:create(params)
    local view = ADRwdShowView.new()
    Drequire("game.CommonPopup.ADRwdShowView_ui"):create(view)
    if view:initView(params) then
        return view
    end
end

function ADRwdShowView:initView(params)
    self.rewardId = params.rewardId
    self:setRewardItems()
    self.ui.m_btnOk:setVisible(false)
    self.ui.m_btnAd:setVisible(true) 
    self.ui.m_btnAd:setPositionX(0)   
    self.curTime = params.curTime
    self.maxTime = params.maxTime
    self.nextAdStamp = params.nextAdStamp
    self.type = params.type
    local now = getTimeStamp()
    if self.curTime<self.maxTime and now >= self.nextAdStamp then
        self.ui.m_btnAd:setEnabled(true)
    else        
        self.ui.m_btnAd:setEnabled(false)        
    end
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnAd, getLang("137702"))
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnOk, getLang("152562"))

    return true
end

function ADRwdShowView:setRewardItems()
    local rwd = GlobalData:call("getCachedRewardData", self.rewardId)
    local rwdData = arrayToLuaTable(rwd)
    local function createGoodsIcon(itemId,num,type)        
        local node = cc.Node:create()
        local spr_bg = CCLoadSprite:createSprite("BG_zhuangbeikuang_bai.png")
        node:addChild(spr_bg)
        local goodsNode = cc.Node:create()
        node:addChild(goodsNode)
        local itemData = {}
        if type == "14" then
            itemData.type = 1 --装备
        else
            itemData.type = 0 --道具
        end
		itemData.itemId = itemId
		itemData.desScale = 1
		itemData.num = num
        LibaoCommonFunc.createItemInfoShow(itemData, goodsNode, 92, nil, nil, num, true)
            
        local label_spr = CCLoadSprite:createSprite("frame_03.png")
        label_spr:setFlipX(true)   
        label_spr:setAnchorPoint(ccp(1,0))
        label_spr:setPosition(ccp(45,-45))
        CCCommonUtilsForLua:setSpriteMaxSize(label_spr, 110, false)
        node:addChild(label_spr)

        local label1 = CCLabelIF:call("create","")
        label1:call("setString",tostring(num))
        label1:call("setFontSize",20)
        label1:setAnchorPoint(ccp(1,0))
        label1:setPosition(ccp(43,-45))
        node:addChild(label1)
        return node
    end
    if #rwdData == 0 then
        GlobalData:call("requestRewardData", self.rewardId)
    else
        self.ui.m_picNode:removeAllChildren()
        local info = rwdData[1]
        local itemId = info.value.id
        local num = info.value.num
        local type = info.type
        local node = createGoodsIcon(itemId,num,type)
        self.ui.m_picNode:addChild(node) 
        if tonumber(itemId) < 10 then
            nameStr = CCCommonUtilsForLua:call("getResourceNameByType", tonumber(goodsId))
        else
            nameStr = getLang(CCCommonUtilsForLua:call("getPropById", goodsId, "name"))
        end        
        self.ui.m_nameLabel:setString(nameStr)  
        local tinfo = ToolController:call("getToolInfoByIdForLua",tonumber(itemId))
        if tinfo then
            self.ui.m_desLabel:setString(getLang(tinfo:getProperty("des")));   
        end
    end
end

function ADRwdShowView:onEnter()
    if self.entry then
		self:getScheduler():unscheduleScriptEntry(self.entry)
    end
    if self.nextAdStamp > getTimeStamp() then
        self.ui.m_btnAd:setPositionX(150)
        self.ui.m_btnOk:setVisible(true)   
        self.ui.m_btnOk:setEnabled(false)          
        self.entry = tonumber(self:getScheduler():scheduleScriptFunc(function(dt)
            self:onEnterFrame(dt)
        end, 1, false)) 
    end   
    local function onGetRewardDetailBack(ref)
		local rewardId = ""
		if ref then rewardId = ref:getCString() end
        if rewardId == self.rewardId then
            self:setRewardItems()
        end
	end
	local handler = self:registerHandler(onGetRewardDetailBack)
    CCSafeNotificationCenter:registerScriptObserver(self, handler, "MSG_GET_REWARD_DETAIL_BACK")    
    registerScriptObserver(self,self.onCloseButtonClick,"msg.getAdReward.refresh")
    registerScriptObserver(self,self.refreshButton,"msg.adClose.refresh")
end

function ADRwdShowView:onExit()
    CCSafeNotificationCenter:unregisterScriptObserver(self, "MSG_GET_REWARD_DETAIL_BACK")
    if self.entry then
        self:getScheduler():unscheduleScriptEntry(self.entry)
    end
    unregisterScriptObserver(self,"msg.adClose.refresh")
    unregisterScriptObserver(self,"msg.getAdReward.refresh")
end

function ADRwdShowView:refreshButton()
    self.ui.m_btnOk:setVisible(true)
    self.ui.m_btnAd:setVisible(false) 
    self.ui.m_btnOk:setPositionX(0)
    self.ui.m_btnOk:setEnabled(true)
end

function ADRwdShowView:onEnterFrame( dt )
    local now = getTimeStamp()
    local lessTime = self.nextAdStamp - now
    if lessTime > 0 then
        CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnAd, format_time(lessTime)) -- 140473=领主ID已隐藏
    else       
        self.ui.m_btnAd:setEnabled(self.curTime < self.maxTime) 
        self:getScheduler():unscheduleScriptEntry(self.entry)
        CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnAd,string.format('%d/%d', self.maxTime - self.curTime, self.maxTime))
    end
end

function ADRwdShowView:onCloseButtonClick()
    self:call("closeSelf")
end

function ADRwdShowView:onClickOkBtn()
    Drequire("game.command.LuaAdCommand"):reqADGoods(AD_TYPE.CIVI_CRYSTAL)
    self.ui.m_btnOk:setEnabled(false)
end

function ADRwdShowView:onClickAdBtn()
	LuaAdController:playVideo(self.type)
end

return ADRwdShowView