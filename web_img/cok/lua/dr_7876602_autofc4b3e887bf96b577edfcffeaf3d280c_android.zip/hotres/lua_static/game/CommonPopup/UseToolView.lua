local UseToolView = class("UseToolView",
	function()
		return PopupBaseView:create() 
	end
)
UseToolView.__index = UseToolView

local UseToolCell = class("UseToolCell",
	function()
		return cc.Layer:create() 
	end
)
UseToolCell.__index = UseToolCell

function UseToolView:create(_type, dict, title)
	local view = UseToolView.new()
	if (view:initView(_type, dict, title)) then return view end
end

function UseToolView:initView(_type, dict, title)
	if (self:init(true, 0)) then
		self:setIsHDPanel(true)
		CCLoadSprite:call("loadDynamicResourceByType", CCLoadSpriteType_GOODS)

		self.m_type = _type
		self.m_dict = dict
		if self.m_dict then self.m_dict:retain() end
		
		self.m_curList = {}

		local proxy = cc.CCBProxy:create()
		local ccbUri = "UseToolView_lua.ccbi"
		local node = CCBReaderLoad(ccbUri, proxy, self)
		local nodeSize = node:getContentSize()
		self:setContentSize(nodeSize)

		local function onNodeEvent(event)
			if event == "enter" then
				self:onEnter()
			elseif event == "exit" then
				self:onExit()
			elseif event == "cleanup" then
				self:onCleanup()
 			end
		end
		self:registerScriptHandler(onNodeEvent)
		self:addChild(node)

		local winSize = cc.Director:sharedDirector():getIFWinSize()
		CCCommonUtilsForLua:call("makeBatchBG", self.m_bgNode, winSize, ccp(0.5, 1), 1)

		local addHeight = self:getExtendHeight()
		local oldWidth = self.m_infoList:getContentSize().width
		local oldHeight = self.m_infoList:getContentSize().height

		self.m_numTTF:setVisible(false)

		local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
		local resourceInfo = GlobalData:call("shared"):getProperty("resourceInfo")
		
		if (self.m_type == USE_TOOL_LOTTERY1) then
			self.m_numTTF:setVisible(true)
			local lChip = resourceInfo:getProperty("lChip")
			local name = getLang("111101") .. ":" .. CC_CMDITOAL(lChip)
			self.m_numTTF:setString(name)
		elseif (self.m_type == USE_TOOL_LOTTERY2) then
			self.m_numTTF:setVisible(true)
			local lDiamond = resourceInfo:getProperty("lDiamond")
			local name = getLang("111102") .. ":" .. CC_CMDITOAL(lDiamond)
			self.m_numTTF:setString(name)
		elseif (self.m_type == USE_TOOL_VIP_ACTIVITY) then
			local worldTime = GlobalData:call("getWorldTime")
			local dTime = playerInfo:getProperty("vipEndTime") - worldTime
			if (dTime > 0) then
				self.m_numTTF:setVisible(true)
				self.m_numTTF:setString(getLang("108659") .. format_time(dTime))
				self:scheduleUpdate()
			else
				self.m_numTTF:setVisible(false)
				oldHeight = oldHeight + 20
			end
		elseif (self.m_type == USE_TOOL_VIP_PIC) then
			self:refreshVipPoint()
		elseif (self.m_type == USE_TOOL_STAMINA) then
			self.m_numTTF:setVisible(true)
			local stamina = WorldController:call("getInstance"):getProperty("currentStamine")
			if CCCommonUtilsForLua:isFunOpenByKey("stamina_value_prop") then
				local total = CCCommonUtilsForLua:call("getFinalStamineMax")
				self.m_numTTF:setString(getLang("137566", tostring(stamina)) .. "   " .. getLang("5502245") .. ":" .. tostring(total))
			else
				self.m_numTTF:setString(getLang("137566", tostring(stamina)))
			end
		elseif (self.m_type == USE_TOOL_WISH) then
			local info = GlobalData:call("shared"):getProperty("sacrificeInfo")
			self.m_numTTF:setVisible(true)

			local leftFree = info:call("getLeftFreeCount")
			if (leftFree < 0) then leftFree = 0 end

			local des = getLang("102324") .. ":" .. CC_CMDITOA(leftFree)
			self.m_numTTF:setString(des)
		elseif (self.m_type == USE_TOOL_EXP) then	--[awen-lvliang]
			oldHeight = oldHeight - 10
		elseif(self.m_type == USE_TOOL_MAKE_TRAP_EFFECT) then
		--  展示的礼包

	    local show_type = 231	 
	    local itemList = LiBaoController.getInstance():getExchangeListByShowType(show_type)
	    if #itemList > 0 then
	    	self.m_adBaseNode:setVisible(true)
	        local advNode = require("game.LiBao.LuaGoldExchangeAdView").new(show_type, true)
	        if (advNode) then
	            self.m_adBaseNode:addChild(advNode, 1)
	            advNode:setPositionX(320)	
                oldHeight = oldHeight - self.m_adBaseNode:getContentSize().height*0.8               
	        end
	    end


		else
			oldHeight = oldHeight + 20
		end

		self.m_infoList:setPositionY(self.m_infoList:getPositionY() - addHeight)
		self.m_infoList:setContentSize(cc.size(oldWidth, oldHeight + addHeight))

		if (title == "") then
			if (self.m_type == USE_TOOL_MARCH_CANCEL) then
				self:setTitleName(getLang("104039")) --//104039=行军召回
			elseif (self.m_type == USE_TOOL_MARCH_CANCEL_RALLY) then
				self:setTitleName(getLang("115191")) --//115191=解散
			else
				self:setTitleName(getLang("104903")) --//104903=加速
			end
		else
			self:setTitleName(getLang(title))
		end

		self.m_tableView = cc.TableView:create(self.m_infoList:getContentSize())
		self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
		self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
		self.m_tableView:setDelegate()
		self.m_tableView:registerScriptHandler(function(tab, idx) return self:cellSizeForTable(tab, idx) end, cc.TABLECELL_SIZE_FOR_INDEX)
		self.m_tableView:registerScriptHandler(function(tab, idx) return self:tableCellAtIndex(tab, idx) end, cc.TABLECELL_SIZE_AT_INDEX)
		self.m_tableView:registerScriptHandler(function(tab) return self:numberOfCellsInTableView(tab) end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
		self.m_infoList:addChild(self.m_tableView)

		return true
	end

	return false
end

function UseToolView:scheduleUpdate()
	if self.entry then
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
	end
	self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(function(dt) self:onTimer(dt) end, 1, false)
end

function UseToolView:unscheduleUpdate()
	if self.entry then
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
		self.entry = nil
	end
end

function UseToolView:onTimer(dt)
	if (self.m_type == USE_TOOL_VIP_ACTIVITY) then
		local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
		local worldTime = GlobalData:call("getWorldTime")
		local dTime = playerInfo:getProperty("vipEndTime") - worldTime
		if (dTime > 0) then
			self.m_numTTF:setVisible(true)
			self.m_numTTF:setString(getLang("108659") .. format_time(dTime))
		else
			self.m_numTTF:setVisible(false)
			self:unscheduleUpdate()
		end
	end
end

function UseToolView:updateInfo()
	self.m_curList = {}

	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	local reslists = ToolController:call("getInstance"):getProperty("m_typeTools")
	--dump(reslists, "m_typeTools")

	if (self.m_type == USE_TOOL_CITY_MOVE) then
		local info = ToolController:call("getToolInfoByIdForLua", 200005) --//获取新手迁城道具
		local cnt = info:call("getCNT")
		if cnt > 0 then self.m_curList[#self.m_curList + 1] = 200005 end
		self.m_curList[#self.m_curList + 1] = 200002
	elseif (self.m_type == USE_TOOL_MARCH_CANCEL) then
		self.m_curList[#self.m_curList + 1] = 200004
	elseif (self.m_type == USE_TOOL_MARCH_CANCEL_RALLY) then
		self.m_curList[#self.m_curList + 1] = 200006 --高级行军召回
	elseif (self.m_type == USE_TOOL_CHANGE_NAME) then
		self.m_curList[#self.m_curList + 1] = 200021
	elseif (self.m_type == USE_TOOL_MATE_BOX) then
		self.m_curList[#self.m_curList + 1] = 200603
	elseif (self.m_type == USE_TOOL_CHANGE_PIC) then
		self.m_curList[#self.m_curList + 1] = 200026
	elseif (self.m_type == USE_TOOL_VIP_PIC) then
		local reslist = reslists[3]
		for i = 1, #reslist do
			local info = ToolController:call("getToolInfoByIdForLua", reslist[i])
			if (info:getProperty("type2") == 11) then
				local SVIPLevel = playerInfo:getProperty("SVIPLevel")
				if (SVIPLevel > 0) then
					local itemId = info:getProperty("itemId")
					local isSvipPointId = VipUtil:call("isSvipPointId", itemId)
					local isVipPointId = VipUtil:call("isVipPointId", itemId)
					if (isSvipPointId or isVipPointId) then
						if (info:call("getCNT") > 0) then
							self.m_curList[#self.m_curList + 1] = itemId
						elseif (info:getProperty("price") > 0) then
							self.m_curList[#self.m_curList + 1] = itemId
						end
					end
				else
					local itemId = info:getProperty("itemId")
					local isVipPointId = VipUtil:call("isVipPointId", itemId)
					if (isVipPointId) then
						local cnt = info:call("getCNT")
						if (cnt > 0) then
							self.m_curList[#self.m_curList + 1] = itemId
						elseif (info:getProperty("price") > 0) then
							self.m_curList[#self.m_curList + 1] = itemId
						end
					end
				end
			end
		end
	elseif (self.m_type == USE_TOOL_VIP_ACTIVITY) then	
		local reslist = reslists[3]
		for i = 1, #reslist do
			local info = ToolController:call("getToolInfoByIdForLua", reslist[i])
			local type2 = info:getProperty("type2")
			if (type2 == 12) then
				local SVIPLevel = playerInfo:getProperty("SVIPLevel")
				if (SVIPLevel > 0) then
					local itemId = info:getProperty("itemId")
					local isSvipTimeId = VipUtil:call("isSvipTimeId", itemId)
					local isVipTimeId = VipUtil:call("isVipTimeId", itemId)
					if (isSvipTimeId or isVipTimeId) then
						if (info:call("getCNT") > 0) then
							self.m_curList[#self.m_curList + 1] = itemId
						elseif (info:getProperty("price") > 0) then
							self.m_curList[#self.m_curList + 1] = itemId
						end
					end
				else
					local itemId = info:getProperty("itemId")
					local isVipTimeId = VipUtil:call("isVipTimeId", itemId)
					if (isVipTimeId) then
						if (info:call("getCNT") > 0) then
							self.m_curList[#self.m_curList + 1] = itemId
						elseif (info:getProperty("price") > 0) then
							self.m_curList[#self.m_curList + 1] = itemId
						end
					end
				end
			end
		end
	elseif (self.m_type == USE_TOOL_LOTTERY1) then
		local reslist = reslists[3]
		for i = 1, #reslist do
			local info = ToolController:call("getToolInfoByIdForLua", reslist[i])
			local type2 = info:getProperty("type2")
			if (type2 == 15) then
				local itemId = info:getProperty("itemId")
				if (info:call("getCNT") > 0) then
					self.m_curList[#self.m_curList + 1] = itemId
				elseif (info:getProperty("price") > 0) then
					self.m_curList[#self.m_curList + 1] = itemId
				end
			end
		end
	elseif (self.m_type == USE_TOOL_LOTTERY2) then
		local reslist = reslists[3]
		for i = 1, #reslist do
			local info = ToolController:call("getToolInfoByIdForLua", reslist[i])
			local type2 = info:getProperty("type2")
			if (type2 == 16) then
				local itemId = info:getProperty("itemId")
				if (info:call("getCNT") > 0) then
					self.m_curList[#self.m_curList + 1] = itemId
				elseif (info:getProperty("price") > 0) then
					self.m_curList[#self.m_curList + 1] = itemId
				end
			end
		end
	elseif (self.m_type == USE_TOOL_allianceDaily_addSend) then
		self.m_curList[#self.m_curList + 1] = 200052  --工会日常任务发布
	elseif (self.m_type == USE_TOOL_allianceDaily_addRefresh) then
		self.m_curList[#self.m_curList + 1] = 200051  --工会日常任务刷新
	elseif (self.m_type == USE_TOOL_STAMINA) then  --精力的使用及购买
		local reslist = reslists[3]
		if CCCommonUtilsForLua:isFunOpenByKey("stamina_value_prop") then
			self.m_curList[#self.m_curList + 1] = 000000  --体力道具增加titlecell
		end
		for i = 1, #reslist do
			local info = ToolController:call("getToolInfoByIdForLua", reslist[i])
			local type2 = info:getProperty("type2")
			if (type2 == 13) then
				local itemId = info:getProperty("itemId")
				local goodid = tonumber(itemId)
				if (info:call("getCNT") > 0) then
					self.m_curList[#self.m_curList + 1] = itemId
				elseif (info:getProperty("price") > 0) then
					self.m_curList[#self.m_curList + 1] = itemId
				elseif (goodid == 200381) then
					self.m_curList[#self.m_curList + 1] = itemId
				end
			end
		end
		-- 体力上限道具
		if CCCommonUtilsForLua:isFunOpenByKey("stamina_value_prop") then
			self.m_curList[#self.m_curList + 1] = 111111  --体力道具增加titlecell
			self.m_curList[#self.m_curList + 1] = 214931
		end
	elseif (self.m_type == USE_TOOL_WISH) then
		self.m_curList[#self.m_curList + 1] = 200031
	elseif (self.m_type == USE_TOOL_EXP) then	--[awen-lvliang]使用领主经验道具
		local mapSG = GlobalData:call("shared"):getProperty("generals")
		if mapSG then
	    	local info = table.firstvalue(mapSG)
	    	if info then
				-- 等级
				self.m_level:setVisible(true)
				self.m_level:setString(getLang('161006')..':'..tostring(info:getProperty('level') or 1))

				-- 经验
		    	self.m_exp:setVisible(true)
				self.m_exp:setString(getLang('139091', info:getProperty("currExp"), info:getProperty("maxExp")))
			end
		end

		local reslist = reslists[3]
		local reslist57 = reslists[57] --type==57，对应新的“领主经验道具”
		if reslist57 and (#reslist57 > 0) then 
			for k,v in pairs(reslist57) do 
				reslist[#reslist+1] = v
			end
		end

		for i = 1, #reslist do
			local info = ToolController:call("getToolInfoByIdForLua", reslist[i])
			local _type = info:getProperty("type")
			local type2 = info:getProperty("type2")
			local para3 = info:getProperty("para3")
			if ((_type==3 or _type==57) and type2 == 14 and para3 == '') then
				local itemId = info:getProperty("itemId")
				local goodid = tonumber(itemId)
				if (info:call("getCNT") > 0) then
					self.m_curList[#self.m_curList + 1] = itemId
				end
			end
		end
		-- 排序：para2字段值从小到大排列
		if #self.m_curList > 1 then
			function sortByPara2(a,b)
				local infoA = ToolController:call("getToolInfoByIdForLua", a)
				local infoB = ToolController:call("getToolInfoByIdForLua", b)
				if infoA and infoB then
					local para2A = infoA:getProperty('para2')
					local para2B = infoB:getProperty('para2')
					if para2A and para2B then
						return tonumber(para2A) < tonumber(para2B)
					end
				end
		        return false
		    end
		    table.sort(self.m_curList, sortByPara2)
		end
	elseif (self.m_type == USE_TOOL_SHUIJING) then
		local reslist = reslists[3]
		for i = 1, #reslist do
			local info = ToolController:call("getToolInfoByIdForLua", reslist[i])
			local _type = info:getProperty("type") --type="3" type2="17"
			local type2 = info:getProperty("type2")
			if _type==3 and type2== 17 then
				local itemId = info:getProperty("itemId")
				-- dump(itemId,"hanxiao12345 itemId is")
				local goodid = tonumber(itemId)
				if (info:call("getCNT") > 0) then
					self.m_curList[#self.m_curList + 1] = itemId
				end
			end
		end
		if #self.m_curList < 1 and self.m_labelNoItems then
			self.m_labelNoItems:setString(getLang('138525'))
		end
	elseif (self.m_type == USE_TOOL_PRODUCTSOLDIEREFT1 or self.m_type == USE_TOOL_PRODUCTSOLDIEREFT2) then
		local m_xmlEftToolIds = CCCommonUtilsForLua:getGroupByKey("control") --读取单次造兵加成道具的id{}
		if nil ~= m_xmlEftToolIds then
			local toolIds
			local special
			if self.m_type == USE_TOOL_PRODUCTSOLDIEREFT1 then
				toolIds = m_xmlEftToolIds["30435111"].k1
			else
				toolIds = m_xmlEftToolIds["30435111"].k2
			end
			toolIds = string.split(toolIds,";")
            
			
            if(CCCommonUtilsForLua:isFunOpenByKey("soilders_additon_upper_limit") and self.m_type == USE_TOOL_PRODUCTSOLDIEREFT1) then

            	local function isValueInTable( table ,value )
            		for k,v in pairs(table) do            			
            			if tonumber(v) == value then
            				return true
            			end
            		end
            		return false
            	end

            	 local specialIDsXml = CCCommonUtilsForLua:call("getPropByIdGroup","data_config", "32230301", "k1")
            	 if specialIDsXml then
            	 	 local specialIDs = string.split(specialIDsXml,";") or {}
            	 	 	
                     for k,v in pairs(toolIds or {}) do

				         local info = ToolController:call("getToolInfoByIdForLua", tonumber(v))				        
				         if info and (info:call("getCNT") > 0 or isValueInTable(specialIDs,tonumber(v))) then
				         	self.m_curList[#self.m_curList + 1] = tonumber(v)				         	
				          end
				      end
            	 end    	
            	

            else

            	for k,v in pairs(toolIds or {}) do
				   local info = ToolController:call("getToolInfoByIdForLua", tonumber(v))
					if info and info:call("getCNT") > 0 then					
						self.m_curList[#self.m_curList + 1] = tonumber(v)
					 end
				end
			end      

			
		end
	elseif (self.m_type == USE_TOOL_KILL_MONSTER_EFFECT ) then
		local CONTROL_CONFIG_ID = "30435112"
		local xmlItemIds = CCCommonUtilsForLua:getGroupByKey("control") --读取单次造兵加成道具的id{}
		dump(xmlItemIds, "UseToolView:xmlItemIds")
		if xmlItemIds and xmlItemIds[CONTROL_CONFIG_ID] then
			local toolIds = xmlItemIds[CONTROL_CONFIG_ID].k1
			toolIds = string.split(toolIds,";")
			for k,v in pairs(toolIds or {}) do
				-- local info = ToolController:call("getToolInfoByIdForLua", tonumber(v))
				-- if info and (info:call("getCNT") > 0) then
				-- 	self.m_curList[#self.m_curList + 1] = tonumber(v)
				-- end
				self.m_curList[#self.m_curList + 1] = tonumber(v)
			end
		end
		-- dump(self.m_curList, "UseToolView:self.m_curList")
	else if CCCommonUtilsForLua:call("isFunOpenByKey", "fun_trap_6_show") and self.m_type == USE_TOOL_MAKE_TRAP_EFFECT then
		 local data = CCCommonUtilsForLua:call("getPropByIdGroup","control", "30435111", "k4")
		 if not data then return end



         local dataIDs = string.split(data,";") or {}

          dump(dataIDs,"fun_trap_6_show----data")
	     for k,v in pairs (dataIDs) do
			    local info = ToolController:call("getToolInfoByIdForLua", tonumber(v))
				if info and info:call("getCNT") > 0 then					
					self.m_curList[#self.m_curList + 1] = tonumber(v)
				 end
		  end
	end
end



	self.m_tableView:reloadData()
end


function UseToolView:refreshVipPoint()
	self.m_numTTF:setVisible(true)
	
	local points = 0
	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	local SVIPLevel = playerInfo:getProperty("SVIPLevel")
	local svipShop_level = playerInfo:getProperty("svipShop_level")
	if SVIPLevel == 10 and svipShop_level > 0 then
		-- svip商店已经开启，此处显示为 svip点数
		points = playerInfo:getProperty("SVIPPoint") - VipUtil:call("getMaxSpoint")
	elseif (SVIPLevel > 0) then
		points = playerInfo:getProperty("SVIPPoint")
	else
		points = playerInfo:getProperty("vipPoints")
	end

	self.m_numTTF:setString(getLang("103010") .. CC_CMDITOA(points))
end

function UseToolView:refreshData(pObj)
	local offset = self.m_tableView:getContentOffset()
	local containerSize = self.m_tableView:getContainer():getContentSize()
	if (self.m_type == USE_TOOL_VIP_ACTIVITY or self.m_type == USE_TOOL_VIP_PIC) then
		local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
		if (self.m_type == USE_TOOL_VIP_PIC) then
			self:refreshVipPoint()
		else
			self:unscheduleUpdate()

			local worldTime = GlobalData:call("getWorldTime")
			local vipEndTime = playerInfo:getProperty("vipEndTime")
			local dTime = vipEndTime - worldTime
			if (dTime > 0) then
				self.m_numTTF:setVisible(true)
				self.m_numTTF:setString(getLang("108659") .. format_time(dTime))
				self:scheduleUpdate()
			else
				self.m_numTTF:setVisible(false)
			end
		end

		self:updateInfo()
	elseif (self.m_type == USE_TOOL_LOTTERY1 or self.m_type == USE_TOOL_LOTTERY2) then
		self:updateInfo()

		local resourceInfo = GlobalData:call("shared"):getProperty("resourceInfo")
		local lChip = resourceInfo:getProperty("lChip")
		local lDiamond = resourceInfo:getProperty("lDiamond")
		local num = (self.m_type == USE_TOOL_LOTTERY1) and lChip or lDiamond
		local name = (self.m_type == USE_TOOL_LOTTERY1) and getLang("111101") or getLang("111102")
		name = name .. ":" .. CC_CMDITOAL(num)
		self.m_numTTF:setString(name)
	elseif (self.m_type == USE_TOOL_STAMINA) then
		self.m_numTTF:setVisible(true)

		local stamina = WorldController:call("getInstance"):getProperty("currentStamine")
		if CCCommonUtilsForLua:isFunOpenByKey("stamina_value_prop") then
			local total = CCCommonUtilsForLua:call("getFinalStamineMax")
			self.m_numTTF:setString(getLang("137566", tostring(stamina)) .. "   " .. getLang("5502245") .. ":" .. tostring(total))
		else
			self.m_numTTF:setString(getLang("137566", tostring(stamina)))
		end
		self:updateInfo()
	elseif (self.m_type == USE_TOOL_WISH) then
		local info = GlobalData:call("shared"):getProperty("sacrificeInfo")
		self.m_numTTF:setVisible(true)
		local leftFree = info:call("getLeftFreeCount")
		if (leftFree < 0) then leftFree = 0 end
		local des = getLang("102324") .. ":" .. CC_CMDITOA(leftFree)
		self.m_numTTF:setString(des)
		self:updateInfo()
	elseif (self.m_type == USE_TOOL_EXP) then	--[awen-lvliang]刷新领主经验道具
		self:updateInfo()
		if #self.m_curList < 1 and self.m_labelNoItems then
			self.m_labelNoItems:setString(getLang('E100313'))	-- E100313=您暂时尚未拥有任何“领主经验”道具
		end
	elseif (self.m_type == USE_TOOL_SHUIJING) then
		self:updateInfo()
		if #self.m_curList < 1 and self.m_labelNoItems then
			self.m_labelNoItems:setString(getLang('138525'))
		end
	elseif (self.m_type == USE_TOOL_PRODUCTSOLDIEREFT1) then
		self:updateInfo()
	elseif (self.m_type == USE_TOOL_PRODUCTSOLDIEREFT2) then
		self:updateInfo()
	elseif (self.m_type == USE_TOOL_MAKE_TRAP_EFFECT) then 
		self:updateInfo()
	elseif (self.m_type == USE_TOOL_KILL_MONSTER_EFFECT) then 
		self:updateInfo()
	end

	local containerSize1 = self.m_tableView:getContainer():getContentSize()
	offset.y = offset.y - (containerSize1.height - containerSize.height)
	self.m_tableView:setContentOffset(offset)
end

function UseToolView:onEnter()
	local show_type = 4
	if self.m_type and self.m_type == USE_TOOL_SHUIJING then
		show_type = 10
		local dict = CCDictionary:create() 
    	dict:setObject(CCString:create("1"), 'switch')
		CCSafeNotificationCenter:call("postNotification","UIButtonLongjing_switch",dict)
	end
	--【Awen】杀戮战场隐藏金币
	Dprint("UseToolView:onEnter", CCCommonUtilsForLua:isFunOpenByKey("war_trial_on"), GlobalData:call("shared"):getProperty("serverType"))
	if CCCommonUtilsForLua:isFunOpenByKey("war_trial_on") then
		local _serverType = GlobalData:call("shared"):getProperty("serverType")
		if _serverType == ServerType.SERVER_ANCESTRAL or _serverType == ServerType.SERVER_ANCESTRAL_TEST then
			show_type = 0
		end
	end
	UIComponent:call("showPopupView", show_type)
	self:updateInfo()

	local function callback1(pObj) self:refreshData(pObj) end
	local function callback2(pObj) self:refreshData(pObj) end
	local handler1 = self:registerHandler(callback1)
	local handler2 = self:registerHandler(callback2)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, MSG_REFREASH_TOOL_DATA)
	CCSafeNotificationCenter:registerScriptObserver(self, handler2, MSG_TOOL_CHANGE)
end

function UseToolView:onExit()
	if self.m_type and self.m_type == USE_TOOL_SHUIJING then
		local dict = CCDictionary:create() 
    	dict:setObject(CCString:create("0"), 'switch')
		CCSafeNotificationCenter:call("postNotification","UIButtonLongjing_switch",dict)
	end
	self:unscheduleUpdate()
	CCSafeNotificationCenter:unregisterScriptObserver(self, MSG_REFREASH_TOOL_DATA)
	CCSafeNotificationCenter:unregisterScriptObserver(self, MSG_TOOL_CHANGE)
end

function UseToolView:onCleanup()
	if self.m_dict then self.m_dict:release() end
	self = nil
end

function UseToolView:cellSizeForTable(tab, idx)
	if self.m_curList[idx + 1] == 000000 or self.m_curList[idx + 1] == 111111 then
		if (CCCommonUtilsForLua:isIosAndroidPad()) then
			return 1476, 140
		else
			return 600, 60
		end
	else
		if (CCCommonUtilsForLua:isIosAndroidPad()) then
			return 1476, 285
		else
			return 600, 145
		end
	end
end

function UseToolView:tableCellAtIndex(tab, idx)
	if (idx >= #self.m_curList) then return end

	local cell = tab:dequeueCell()
	if (cell) then
		local node = cell:getChildByTag(666)
		if node then node:setData(self.m_curList[idx + 1], self.m_type, self.m_dict) end
	else
		local node = UseToolCell:create(self.m_curList[idx + 1], self.m_type, self.m_dict, self.m_infoList)
		node:setTag(666)
		cell = cc.TableViewCell:create()
		cell:addChild(node)
	end

	return cell
end

function UseToolView:numberOfCellsInTableView(tab)
	return #self.m_curList or 0
end


---------------------------UseToolCell----------------------------

function UseToolCell:create(itemId, _type, dict, listNode)
	local node = UseToolCell.new()
	if (node:initNode(itemId, _type, dict, listNode)) then return node end
end

function UseToolCell:initNode(itemId, _type, dict, listNode)
	local proxy = cc.CCBProxy:create()
	local ccbUri = "UseToolCell_lua.ccbi"
	local node = CCBReaderLoad(ccbUri, proxy, self)
	self:addChild(node)
	self.m_listNode = listNode
	self.m_waitInterface = nil
	self:setData(itemId, _type, dict)
	return true
end

function UseToolCell:setData(itemId, _type, dict)
	if (self.m_waitInterface) then
		self.m_waitInterface:call("remove")
		self.m_waitInterface = nil
	end

	self.m_itemId = itemId
	self.m_type = _type
	self.m_dict = dict
	self.m_shop_id = 0
	self.showDialog = nil
	if self.m_itemId == 200381 then
		self.m_shop_id = 1000086
	end

	if self.m_itemId == 000000 or self.m_itemId == 111111 then
		self.m_mainNode:setVisible(false)
		self.m_titleNode:setVisible(true)
		if self.m_itemId == 000000 then
			self.m_titleLabel:setString(getLang("155067"))
		elseif self.m_itemId == 111111 then
			self.m_titleLabel:setString(getLang("5502245"))
		end
	else
		self.m_mainNode:setVisible(true)
		self.m_titleNode:setVisible(false)
		local toolInfo = ToolController:call("getToolInfoByIdForLua", itemId)

		self.m_price = toolInfo:getProperty("price")
		self.m_nameLabel:setString(toolInfo:call("getName"))
		self.m_desLabel:setString(getLang(toolInfo:getProperty("des")))
		-- 体力上限道具特写
		if self.m_itemId == 214931 and tonumber(GlobalData:call("shared"):getProperty("worldConfig"):getProperty("stamineMax")) >= (tonumber(toolInfo:getProperty("para2"))+100) then
			local toolInfo2 = ToolController:call("getToolInfoByIdForLua", 214932)
			self.m_desLabel:setString(getLang(toolInfo2:getProperty("des")))
		end
		self.m_numLabel:setString(CC_CMDITOA(toolInfo:call("getCNT")))

		self.m_picNode:removeAllChildren()
		CCCommonUtilsForLua:createGoodsIcon(toolInfo:getProperty("itemId"), self.m_picNode, cc.size(80, 80))

		self.m_inBtnGoldNum:setString(CC_CMDITOA(self.m_price))
		CCCommonUtilsForLua:setButtonTitle(self.m_useBtn, getLang("102137"))
		self.m_btnMsgLabel:setString(getLang("104906"))

		local count = toolInfo:call("getCNT")
		--【Awen】杀戮战场隐藏金币
		local _serverType = GlobalData:call("shared"):getProperty("serverType")
		if CCCommonUtilsForLua:isFunOpenByKey("war_trial_on") and (_serverType == ServerType.SERVER_ANCESTRAL or _serverType == ServerType.SERVER_ANCESTRAL_TEST) then
			self.m_buyNode:setVisible(false)
			self.m_buyBtn:setEnabled(false)
			self.m_useBtn:setVisible(true)
			self.m_useBtn:setEnabled(count > 0)
		else
			if (count > 0) then
				self.m_buyNode:setVisible(false)
				self.m_buyBtn:setEnabled(false)
				self.m_useBtn:setVisible(true)
				self.m_useBtn:setEnabled(true)
			else
				self.m_buyNode:setVisible(true)
				self.m_buyBtn:setEnabled(true)
				self.m_useBtn:setVisible(false)
				self.m_useBtn:setEnabled(false)
			end	
		end

		if (self.m_type == USE_TOOL_WISH) then
			local sinfo = GlobalData:call("shared"):getProperty("sacrificeInfo")
			self.m_buyNode:setVisible(false)
			self.m_buyBtn:setEnabled(false)
			self.m_useBtn:setVisible(true)
			self.m_useBtn:setEnabled(true)
			self.m_desLabel:setString(getLang("104542"))

			if (toolInfo:call("getCNT") <= 0) then
				CCCommonUtilsForLua:call("setButtonSprite", self.m_useBtn, "Btn_grey.png")
			else
				if (sinfo:call("canPray")) then
					local cntforsacrifice = GlobalData:call("shared"):getProperty("cntforsacrifice")
					if (cntforsacrifice <= 0) then
						CCCommonUtilsForLua:call("setButtonSprite", self.m_useBtn, "Btn_grey.png")
					else
						CCCommonUtilsForLua:call("setButtonSprite", self.m_useBtn, "btn_yellow.png")
					end
				else
					CCCommonUtilsForLua:call("setButtonSprite", self.m_useBtn, "Btn_grey.png")
				end
			end
		end

		if dict then
			local tbl = dictToLuaTable(dict)
			if tbl and tbl.more and count <= 0 then
				local moreText = tbl.moreText or "105086"
				
				self.m_buyNode:setVisible(false)
				self.m_buyBtn:setEnabled(false)
				self.m_useBtn:setVisible(true)
				self.m_useBtn:setEnabled(true)
				CCCommonUtilsForLua:setButtonTitle(self.m_useBtn, getLang(moreText))
			end
		end

		if self.m_itemId == 214931 then  --体力上限特写
			self.m_buyNode:setVisible(false)
			self.m_buyBtn:setEnabled(false)
			self.m_useBtn:setVisible(true)
			self.m_useBtn:setEnabled(true)
			if count <= 0 then
				CCCommonUtilsForLua:setButtonTitle(self.m_useBtn, getLang("105086"))
			end
		end

		if self.m_shop_id ~= 0 and count == 0 then
			local shopData = ToolController:getShopItemData(tostring(self.m_shop_id))
			if shopData then
				local canBuyNum = shopData:getBuyCount()
				local hasBuyNum = shopData.m_todayBuy
				self.m_numLabel:setString(CC_CMDITOA(hasBuyNum).."/"..CC_CMDITOA(shopData.m_buy_times_daily))
				self.m_buyNode:setVisible(true)	
				self.m_useBtn:setVisible(false)
				self.m_useBtn:setEnabled(false)
				-- self.m_moreBtn:setVisible(false)
				self.m_inBtnGoldNum:setString(shopData.m_price)
				self.m_price = tonumber(shopData.m_price)
				self.m_shopData = shopData
				self.m_buyMaxNum = canBuyNum
				-- dump(self.m_buyMaxNum, "self.m_buyMaxNum is: ")
				if self.m_buyMaxNum > 0 then
					self.m_buyBtn:setEnabled(true)
				else
					self.m_buyBtn:setEnabled(false)
				end
			else
				-- 无商店数据，显示获取更多
				self.m_numLabel:setString("0")
				self.m_buyNode:setVisible(false)	
				self.m_useBtn:setVisible(false)
				-- self.m_moreBtn:setVisible(true)
				-- CCCommonUtilsForLua:call("setButtonTitle", self.m_moreBtn, getLang("102153"))
			end
		end      
      
        if(CCCommonUtilsForLua:isFunOpenByKey("soilders_additon_upper_limit") and self.m_type == USE_TOOL_PRODUCTSOLDIEREFT1 ) then
             local specialIDsXml = CCCommonUtilsForLua:call("getPropByIdGroup","data_config", "32230301", "k1")
             if specialIDsXml then
            	 local specialIDs = string.split(specialIDsXml,";") or {}
                   for k,v in pairs(specialIDs) do
                   	   if self.m_itemId == tonumber(v) then	                   	       
	                      
	                       if count <= 0 then                     	  
	                       	   self.m_buyNode:setVisible(false)
								self.m_buyBtn:setEnabled(false)
								self.m_useBtn:setVisible(true)
								self.m_useBtn:setEnabled(true)
	                          CCCommonUtilsForLua:setButtonTitle(self.m_useBtn, getLang("550008"))
	                       end 
	                      break

                   	   end
                   end
              end
        
        end

		 
	end
end

function UseToolCell:onClickUseBtn()
	if (self.m_waitInterface) then return end

    if(CCCommonUtilsForLua:isFunOpenByKey("soilders_additon_upper_limit") and self.m_type == USE_TOOL_PRODUCTSOLDIEREFT1 ) then

    	 
         local specialIDsXml = CCCommonUtilsForLua:call("getPropByIdGroup","data_config", "32230301", "k1")
         if not  specialIDsXml then  return  end
         
    	 local specialIDs = string.split(specialIDsXml,";") or {}
           for k,v in pairs(specialIDs) do
            	if self.m_itemId == tonumber(v) then                      
                       
	           		local info = ToolController:call("getToolInfoByIdForLua", tonumber(v))
	                if not info then return end 
	                       
	                if  info:call("getCNT") > 0  then 	                             	  
	           	      self:onUseTool()
	                else
	                  --跳转获取道具途径
	                  local ItemGetMethodView = Drequire("game.CommonPopup.ItemGetMethodView")
	                  PopupViewController:call("addPopupView", ItemGetMethodView:create(tonumber(v)))
	                end
	               return 
             	end                
           end

           self:onUseTool()
          
    else
    	dump("制造陷阱-----")
    	 self:onUseTool()
    end
   

	
end

function UseToolCell:onYes1(pObj)
	local num = 1
	if (pObj) then
		local cInt = tolua.cast(pObj, "CCInteger")
		if cInt then num = cInt:getValue() end
	end
	self.m_itemBuyCount = num
	self.m_waitInterface = GameController:call("showWaitInterface1", self.m_listNode)
	local listSize = self.m_listNode:getContentSize()
	self.m_waitInterface:setPosition(listSize.width / 2, listSize.height / 2)
	
	local function callback() self:onUseTool1() end
	local callfunc = cc.CallFunc:create(callback)
	ToolController:call("buyTool", self.m_itemId, self.m_itemBuyCount, callfunc, 0, true, false, "UseToolView")
	CCSafeNotificationCenter:call("postNotification", "buy.confirm.ok.without.tween")	
end

function UseToolCell:onUseTool1()
	if (self:getParent() == nil) then return end
	if (self.m_waitInterface) then
		self.m_waitInterface:call("remove")
		self.m_waitInterface = nil
	end
	if (self.m_itemBuyCount > 0) then
		if (self.m_type == USE_TOOL_VIP_PIC or self.m_type == USE_TOOL_LOTTERY1 or self.m_type == USE_TOOL_LOTTERY2) then
			
			local ret = ToolController:call("useTool", self.m_itemId, self.m_itemBuyCount, true)
			if ret then
				self.m_waitInterface = GameController:call("showWaitInterface1", self.m_listNode)
				local listSize = self.m_listNode:getContentSize()
				self.m_waitInterface:setPosition(listSize.width / 2, listSize.height / 2)	
			end
		end
	end
end

function UseToolCell:onYes()
	self.m_waitInterface = GameController:call("showWaitInterface1", self.m_listNode)
	local listSize = self.m_listNode:getContentSize()
	self.m_waitInterface:setPosition(listSize.width / 2, listSize.height / 2)

	local function callback() self:onUseTool() end
	local callfunc = cc.CallFunc:create(callback)
	if self.m_shop_id ~= 0 then
	    ToolController:call("shopBuyTool",tostring(self.m_shop_id),1, self.m_price, callfunc)
	else
		ToolController:call("buyTool", self.m_itemId, 1, callfunc, 0, true, false, "UseToolView")
	end
end

function UseToolCell:onUseTool()
	if (self:getParent() == nil) then return end
	if (self.m_waitInterface) then
		self.m_waitInterface:call("remove")
		self.m_waitInterface = nil
	end

	local toolInfo = ToolController:call("getToolInfoByIdForLua", self.m_itemId)
	if (self.m_dict) then
		local uuid = toolInfo:getProperty("uuid")
		self.m_dict:setObject(CCString:create(uuid), "goodsId")
	end

	if (self.m_type == USE_TOOL_CITY_MOVE) then
		WorldMapView:call("afterCityMove", self.m_dict)
		ToolController:call("useTool", self.m_itemId)
		PopupViewController:call("goBackPopupView")
		return
	elseif (self.m_type == USE_TOOL_MARCH_CANCEL or self.m_type == USE_TOOL_MARCH_CANCEL_RALLY) then
		WorldMapView:call("afterMarchCancel", self.m_dict)
		ToolController:call("useTool", self.m_itemId)
		PopupViewController:call("goBackPopupView")
		return
	elseif (self.m_type == USE_TOOL_CHANGE_NAME) then
		local nickName = self.m_dict:valueForKey("nickName"):getCString()
		ToolController:call("useItemChnageName", self.m_itemId, nickName)
		return
	elseif (self.m_type == USE_TOOL_CHANGE_PIC) then
		local pic = self.m_dict:valueForKey("pic"):getCString()
		ToolController:call("useItemChnagePic", self.m_itemId, pic)
		PopupViewController:call("goBackPopupView")
		return
	elseif (self.m_type == USE_TOOL_MATE_BOX) then
		self.m_waitInterface = GameController:call("showWaitInterface1", self.m_listNode)
		local listSize = self.m_listNode:getContentSize()
		self.m_waitInterface:setPosition(listSize.width / 2, listSize.height / 2)
		ToolController:call("useTool", self.m_itemId, 1, true)
		return
	elseif (self.m_type == USE_TOOL_VIP_PIC or self.m_type == USE_TOOL_VIP_ACTIVITY 
			or self.m_type == USE_TOOL_LOTTERY1 or self.m_type == USE_TOOL_LOTTERY2) then
		if (toolInfo:call("getCNT") == 1) then
			self.m_waitInterface = GameController:call("showWaitInterface1", self.m_listNode)
			local listSize = self.m_listNode:getContentSize()
			self.m_waitInterface:setPosition(listSize.width / 2, listSize.height / 2)
			ToolController:call("useTool", self.m_itemId, 1, true)
		else
			local opFrom = "0"
			if self.m_type == USE_TOOL_VIP_PIC 
				and CCCommonUtilsForLua:isFunOpenByKey("svip_shop") 
				and GlobalData:call("shared"):getProperty("playerInfo"):getProperty("svipShop_level") > 0
				then
				opFrom = "27"
			end
			local dict = CCDictionary:create()
			dict:setObject(CCString:create("ToolNumSelectView"), "name")
	 		dict:setObject(CCString:create(tostring(self.m_itemId)), "itemId")
	 		dict:setObject(CCString:create(opFrom), "opFrom")
	 		dict:setObject(CCString:create(""), "targetId")
	 		LuaController:call("openPopViewInLua", dict)
		end

		return
	elseif (self.m_type == USE_TOOL_allianceDaily_addSend) then
		ToolController:call("useTool", self.m_itemId, 1, true)
		return
	elseif (self.m_type == USE_TOOL_allianceDaily_addRefresh) then
		ToolController:call("useTool", self.m_itemId, 1, true)
		return
	elseif (self.m_type == USE_TOOL_STAMINA) then
		if self.m_itemId == 214931 and toolInfo:call("getCNT") <= 0 then
			YesNoDialog:call("show", getLang("173303"))
			return
		end
		if (toolInfo:call("getCNT") == 1) then
			self.m_waitInterface = GameController:call("showWaitInterface1", self.m_listNode)
			local listSize = self.m_listNode:getContentSize()
			self.m_waitInterface:setPosition(listSize.width / 2, listSize.height / 2)
			ToolController:call("useTool", self.m_itemId, 1, true)
		else
			if (toolInfo:getProperty("itemId") == 200380 or toolInfo:getProperty("itemId") == 214931) then --10体力可批量使用
				local dict = CCDictionary:create()
				dict:setObject(CCString:create("ToolNumSelectView"), "name")
		 		dict:setObject(CCString:create(tostring(self.m_itemId)), "itemId")
		 		dict:setObject(CCString:create("0"), "opFrom")
		 		dict:setObject(CCString:create(""), "targetId")
		 		LuaController:call("openPopViewInLua", dict)
			 else --50、100体力不可批量使用
		 		ToolController:call("useTool", self.m_itemId, 1, true)
			end
		end

		return
	elseif (self.m_type == USE_TOOL_WISH) then
		local sinfo = GlobalData:call("shared"):getProperty("sacrificeInfo")
		if (toolInfo:call("getCNT") <= 0) then
			--// 104541=您现在没有祝福道具可以使用
			CCCommonUtilsForLua:call("flyHint", "", "", getLang("104541"))
		else
			if (sinfo:call("canPray")) then
				local cntforsacrifice = GlobalData:call("shared"):getProperty("cntforsacrifice")
				if (cntforsacrifice <= 0) then
					--// 104543=领主大人，您今天已经使用了足够多的祝福道具，无法再继续使用了。请明天再使用吧
					CCCommonUtilsForLua:call("flyHint", "", "", getLang("104543"))
				else
					local dict = CCDictionary:create()
					dict:setObject(CCString:create("ToolNumSelectView"), "name")
			 		dict:setObject(CCString:create(tostring(self.m_itemId)), "itemId")
			 		dict:setObject(CCString:create("0"), "opFrom")
			 		dict:setObject(CCString:create(""), "targetId")
			 		LuaController:call("openPopViewInLua", dict)
			 	end
			else
				--// 104929=领主大人，你今天已经许愿太多次了，无法使用该道具！
				CCCommonUtilsForLua:call("flyHint", "", "", getLang("104929"))
			end
		end
	elseif (self.m_type == USE_TOOL_EXP) then		--[awen-lvliang]使用领主经验道具
		if (toolInfo:call("getCNT") == 1) then
			ToolController:call("useTool", self.m_itemId, 1, true)
		else
			local dict = CCDictionary:create()
			dict:setObject(CCString:create("ToolNumSelectView"), "name")
	 		dict:setObject(CCString:create(tostring(self.m_itemId)), "itemId")
	 		dict:setObject(CCString:create("0"), "opFrom")
	 		dict:setObject(CCString:create(""), "targetId")
	 		LuaController:call("openPopViewInLua", dict)
		end
	elseif (self.m_type == USE_TOOL_SHUIJING) then		--使用龙晶宝箱道具
		if (toolInfo:call("getCNT") == 1) then
			ToolController:call("useTool", self.m_itemId, 1, true)
		else
			local dict = CCDictionary:create()
			dict:setObject(CCString:create("ToolNumSelectView"), "name")
	 		dict:setObject(CCString:create(tostring(self.m_itemId)), "itemId")
	 		dict:setObject(CCString:create("0"), "opFrom")
	 		dict:setObject(CCString:create(""), "targetId")
	 		LuaController:call("openPopViewInLua", dict)
		end
	elseif (self.m_type == USE_TOOL_PRODUCTSOLDIEREFT1 
		or self.m_type == USE_TOOL_PRODUCTSOLDIEREFT2 
		or self.m_type == USE_TOOL_MAKE_TRAP_EFFECT ) then
		dump(self.m_itemId,"USE_TOOL_MAKE_TRAP_EFFECT---")

		if (toolInfo:call("getCNT") == 1) then
			ToolController:call("useTool", self.m_itemId, 1, true)
		else
			local dict = CCDictionary:create()
			dict:setObject(CCString:create("ToolNumSelectView"), "name")
	 		dict:setObject(CCString:create(tostring(self.m_itemId)), "itemId")
	 		dict:setObject(CCString:create("0"), "opFrom")
	 		dict:setObject(CCString:create(""), "targetId")
	 		LuaController:call("openPopViewInLua", dict)
	 	end
	elseif (self.m_type == USE_TOOL_KILL_MONSTER_EFFECT  ) then
		dump(self.m_itemId, "USE_TOOL_KILL_MONSTER_EFFECT---")

		if (toolInfo:call("getCNT") <= 0) then
			--跳转获取道具途径
			local ItemGetMethodView = Drequire("game.CommonPopup.ItemGetMethodView")
			PopupViewController:call("addPopupView", ItemGetMethodView:create(tostring(self.m_itemId)))
		elseif (toolInfo:call("getCNT") == 1) then
			ToolController:call("useTool", self.m_itemId, 1, true)
		else
			local dict = CCDictionary:create()
			dict:setObject(CCString:create("ToolNumSelectView"), "name")
	 		dict:setObject(CCString:create(tostring(self.m_itemId)), "itemId")
	 		dict:setObject(CCString:create("0"), "opFrom")
	 		dict:setObject(CCString:create(""), "targetId")
	 		LuaController:call("openPopViewInLua", dict)
	 	end
	else
		return
	end
end

function UseToolCell:onClickBuyBtn()
	if self.m_waitInterface then return end

	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	if (self.m_type == USE_TOOL_VIP_PIC) then --+VIP点数
		if (not CCCommonUtilsForLua:isFunOpenByKey("svip_shop") and VipUtil:call("isSvipPointId", self.m_itemId)) then
			local SVIPPoint = playerInfo:getProperty("SVIPPoint")
			local maxSpoint = VipUtil:call("getMaxSpoint")
			if (SVIPPoint >= maxSpoint) then
				YesNoDialog:call("show", getLang("103105")) --//103105=您的SVIP已经达到最高级，无需继续购买！
				return
			end
		end			
	end

	if (self.m_type == USE_TOOL_MARCH_CANCEL or self.m_type == USE_TOOL_MARCH_CANCEL_RALLY) then
		local info = ToolController:call("getToolInfoByIdForLua", self.m_itemId)
		if (info:call("getCNT") > 0) then
			self:onYes()
		else
			local function callback() self:onYes() end
			local callfunc = cc.CallFunc:create(callback)
			local price = info:getProperty("price")
			YesNoDialog:call("showButtonAndGold", getLang("104919"), callfunc, getLang("104906"), price)
		end
	elseif (self.m_type == USE_TOOL_VIP_PIC or self.m_type == USE_TOOL_LOTTERY1 or self.m_type == USE_TOOL_LOTTERY2) then
		local info = ToolController:call("getToolInfoByIdForLua", self.m_itemId)
		local p = self.m_picNode:convertToWorldSpace(ccp(-55, -55))
		local url = CCCommonUtilsForLua:call("getIcon", tostring(info:getProperty("itemId")))
		local title = info:call("getName")
		local des = getLang(info:getProperty("des"))
		local price = info:getProperty("price")
		local color = info:getProperty("color")
		local function onYes(pObj) self:onYes1(pObj) end
		local handler = self:registerHandler(onYes)	
		local dialog = StoreBuyConfirmDialog:call("showForLua2", url, title, des, price, color, handler, p, WorldResourceType.Gold)
		if (dialog) then
			local gold = playerInfo:getProperty("gold")
			local maxNum = math.floor(gold / price)
			maxNum = math.max(1, maxNum)

			local itemId = info:getProperty("itemId")
			if self.m_type == USE_TOOL_VIP_PIC then
				local beSvipShop = CCCommonUtilsForLua:isFunOpenByKey("svip_shop")
				local isVipPointId = VipUtil:call("isVipPointId", itemId)
				if beSvipShop and playerInfo:getProperty("SVIPPoint") >= VipUtil:call("getMaxSpoint") then
					-- 已满经验，且开启了svip商店功能，则不限制数量
				else
					if (isVipPointId) then -- vip点数
						local addPoints = atoi(info:call("getPara"))
						local vipPoints = playerInfo:getProperty("vipPoints")
						local point = VipUtil:call("getMaxPoint") - vipPoints
						if (point > 0) then
							local maxBuy = math.floor(point / addPoints)
							if (point % addPoints > 0) then
								maxBuy = maxBuy + 1
							end
							maxNum = math.min(maxBuy, maxNum)
						else
							maxNum = 1
						end
					end

					local isSvipPointId = VipUtil:call("isSvipPointId", itemId)
					if (isSvipPointId) then -- vip点数
						local addPoints = atoi(info:call("getPara"))
						local SVIPPoint = playerInfo:getProperty("SVIPPoint")
						local point = VipUtil:call("getMaxSpoint") - SVIPPoint
						if (point > 0) then
							local maxBuy = math.floor(point / addPoints)
							if (point % addPoints > 0) then
								maxBuy = maxBuy + 1
							end
							maxNum = math.min(maxBuy, maxNum)
						else
							maxNum = 1
						end
					end 
				end
			end

			if ((itemId >= 200700 and itemId <= 200707) or (itemId >= 200710 and itemId <= 200719)) then --龙币 铜币购买最大值
				local para1 = atoi(CCCommonUtilsForLua:call("getPropById", tostring(itemId), "para1"))
				if (para1 > 0) then maxNum = math.min(para1, maxNum) end
			end
			dialog:call("showSliderBar", maxNum) 
		end
	elseif (self.m_type == USE_TOOL_VIP_ACTIVITY or self.m_type == USE_TOOL_allianceDaily_addRefresh) then
		local info = ToolController:call("getToolInfoByIdForLua", self.m_itemId)
		local function callback() self:onYes() end
		local callfunc = cc.CallFunc:create(callback)
		local price = info:getProperty("price")
		YesNoDialog:call("showButtonAndGold", getLang("104919"), callfunc, getLang("104906"), price)
	elseif (self.m_type == USE_TOOL_allianceDaily_addSend) then
		local instance = AllianceDailyController:call("getInstance")
		local itemPublishUseCount = instance:getProperty("itemPublishUseCount")
		local maxPublishItemUseCount = instance:getProperty("maxPublishItemUseCount")
		if (itemPublishUseCount >= maxPublishItemUseCount) then
			YesNoDialog:call("show", getLang("134033")) --今日发布任务次数已经达到上限
			return
		end

		local info = ToolController:call("getToolInfoByIdForLua", self.m_itemId)
		local function callback() self:onYes() end
		local callfunc = cc.CallFunc:create(callback)
		local price = info:getProperty("price")
		YesNoDialog:call("showButtonAndGold", getLang("104919"), callfunc, getLang("104906"), price)
	else
		self:onYes()
	end
end

return UseToolView
