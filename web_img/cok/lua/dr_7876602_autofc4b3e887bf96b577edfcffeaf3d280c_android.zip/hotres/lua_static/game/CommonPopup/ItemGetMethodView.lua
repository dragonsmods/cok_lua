local ItemGetMethodView = class("ItemGetMethodView", function()
        return PopupBaseView:create()
    end
)
ItemGetMethodView.__index = ItemGetMethodView

local ItemGetType = 
{
  GoldExchange = 1, --礼包
  DragonTower = 2, --龙塔
  Activity = 3, --活动中心
  Merchant = 4, --旅行商人
  Store = 5, --商城
  DragonExplore = 6, --龙游历
  HeroBuyFragment = 7,  -- 英雄碎片购买
  JumpToBuild = 8,    -- 跳转建筑物
  OpenDailyActivity = 9,  -- 打开日常任务界面
  JumpToWorld = 10, -- 跳转世界
  OpenHeroTowerHomeView = 11, -- 龙试炼界面
  DragonBag = 12, -- 龙背包
  AllianceTreasure = 13, -- 联盟宝藏
  AllianceQuest = 14, -- 联盟任务
  StoreBagView = 15, -- 背包
  ActivityView = 16, -- 打开活动界面
  AllianceShop = 17,
  KingdomLiBao = 18, --国王礼包
  HeroGetRolate = 19, -- 英雄转盘
  CivPrestage = 20,  -- 文明声望
  CivShop = 21,
  HeroRecruit = 22,--英雄招募
  ShuiJingBox = 23, --水晶宝箱
  ItemExchange = 24, -- 道具兑换
  TreasureShop = 25, --秘境商店
  AuctionHouse = 26, --拍卖行
  MagicDrawView = 27, --魔法屋
  MakexxxReqHelp = 28, --活动中的制作xxx“求助” 
  JumpToWorldResource = 29, -- 查找世界资源点 走IFFindResTileCmd消息，默认为查找世界上奇迹资源，其余为自带参数
  JumpToForge = 30, -- 装备锻造
  CrystalRoulette = 31, -- 水晶转盘
  JumpToRepay = 32, -- 累计充值
  HeroRecruitActivity = 33,--英雄招募活动（限时招募）
  AllianceBoss = 34, --联盟Boss
  AvatarStoreFragment = 35, --【Awen】装扮商城碎片页签
  AvatarStoreDiamond = 36,  --【Awen】装扮商城钻石页签
  TournamentAddNum = 37,  --【tw】竞技场增加次数道具
}

local ItemGetMethod_Cell_Height = 80
local ItemGetMethod_Cell_Width = 560
local FestalActMakexxxCtl = require("game.FestivalActivities.FestivalActivitiesMakexxxController").getInstance()
local deltaPosY = 20
local originPosY = 35
------------------------------------------ ItemGetMethodCell Start --------------------------------------------
local ItemGetMethodCell = class("ItemGetMethodCell", function()
    return cc.Node:create()
end)

-- sourceType 跳转来源，1: 龙语界面跳转，
function ItemGetMethodCell:create(data, param, fromView, sourceType,parent_view)
    local ret = ItemGetMethodCell.new()
    if ret:init(data, param, fromView, sourceType,parent_view) == false then
        return nil
    end
    return ret 
end

function ItemGetMethodCell:init(data, param, fromView, sourceType,parent_view)
    MyPrint("ItemGetMethodCell:init ", param)
	--初始化界面
	MyPrint("ItemGetMethodCell init start")
	local proxy = cc.CCBProxy:create()
	local ccbiURL = ""
	ccbiURL = "ccbi/ItemGetMethodCell.ccbi"
  	local nodeccb = CCBReaderLoad(ccbiURL,proxy, self)
	if nodeccb == nil then
		MyPrint("ItemGetMethodCell loadccb error")
		return false
	end

	self:setContentSize(nodeccb:getContentSize())
	self:addChild(nodeccb)
    registerNodeEventHandler(self)

    self.m_data = data
	self.m_itemId = data.id
    self.m_param = param
    self.m_fromView = fromView
    self.m_sourceType = sourceType
    self.parent_view = parent_view
    MyPrint("self.m_itemId", self.m_itemId)
	local pic = CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", self.m_itemId, "icon")..".png"
	local spr = CCLoadSprite:call("createSprite", pic)
    local getType = tonumber(CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", self.m_itemId, "type"))

    if getType == ItemGetType.ActivityView then
        local actId = CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", self.m_itemId, "para1")
        -- MyPrint("actId", actId)
        local obj = ActivityController:call("getActObj", actId)
        -- MyPrint("obj", obj)
        if nil ~= obj and obj:getIconFrame() ~= nil then
            -- MyPrint("frame not nil")
            spr = cc.Sprite:createWithSpriteFrame(obj:getIconFrame())
        end
    end

    CCCommonUtilsForLua:call("setSpriteMaxSize",spr,80,true)
	self.m_picNode:removeAllChildren()
	self.m_picNode:addChild(spr)

    local desc = CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", self.m_itemId, "desc")
    local t = string.split(desc, ";")
    local param0 = t[1]
    local param1 = t[2]
    local param2 = t[3]
    local param3 = t[4]
	self.m_titleTxt:setString(getLang(param0, param1, param2, param3))
	CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("164952"))

    if getType == 0 then
        local itemId = CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", self.m_itemId, "para1")
        local toolInfo = ToolController:call("getToolInfoForLua", tonumber(itemId))
        if toolInfo == nil then
            self.m_titleTxt:setString("")
            MyPrint("HeroUseItemView getToolInfo fail with itemId "..tostring(self.m_itemId))
        else
            local count = toolInfo:call("getCNT")
            desc = CCCommonUtilsForLua:call("getPropById", tostring(itemId), "name")--50体力
            self.m_titleTxt:setString(getLang(desc) .. "    x" .. count)
            CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("169631"))
            if count <= 0 then
                self.m_getBtn:setEnabled(false)
            else
                self.m_getBtn:setEnabled(true)
            end
        end
    end

    -- 特殊处理 ItemGetType.ActivityView
    if getType == ItemGetType.ActivityView then
        local actId = CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", self.m_itemId, "para1")
        local obj = ActivityController:call("getActObj", actId)
        if obj then
            CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("164952")) -- 164952=前往
            self.m_getBtn:setEnabled(true)
        else
            CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("101465")) -- 101465=未开启
            self.m_getBtn:setEnabled(false)
        end
    elseif getType == ItemGetType.JumpToRepay then
        require("game.LiBao.Repay.RepayController")
        if RepayController.getInstance():isBegin() then
            CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("164952")) -- 164952=前往
            self.m_getBtn:setEnabled(true)
        else
            CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("101465")) -- 101465=未开启
            self.m_getBtn:setEnabled(false)
        end
        
    elseif getType == ItemGetType.HeroRecruitActivity then -- 英雄限时招募
        local heroName = CCCommonUtilsForLua:getPropById(self.m_param, "title")
        self.m_titleTxt:setString(getLang(param0, param1, param2, param3) .. ":" .. getLang(heroName))
        self.txt_timeDesc:setString(getLang("103073"))-- 103073=敬请期待
        -- endTime
        self.m_countEndTime = 0
        local xmlData = CCCommonUtilsForLua:getGroupByKey("general_draw")
        if xmlData then
            local endTime = 0
            for k,v in pairs(xmlData) do
                if v.activity_type and v.activity_type == "1" and tonumber(v.item_id) == tonumber(self.m_param) then
                    endTime = tonumber(v.end_time)
                    break
                end
            end
            if endTime > 0 then -- 倒计时
                self.m_countEndTime = endTime / 1000
            end
        end
        self:addCountDownUpdater(true)
    elseif getType == ItemGetType.AllianceBoss then
        if CCCommonUtilsForLua:isFunOpenByKey("allianceboss_open") then
            CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("164952")) -- 164952=前往
            self.m_getBtn:setEnabled(true)
        else
            CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("101465")) -- 101465=未开启
            self.m_getBtn:setEnabled(false)
        end
    elseif getType == ItemGetType.TournamentAddNum then
        CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("102137"))
        local isEnable = TournamentControllerInst:hasEnoughAddItem(1)
        self.m_getBtn:setEnabled(isEnable)
    end

    self:addHelpTime()
	return true
end

function ItemGetMethodCell:updateHelpTime(dt)
    if self:isHelpItem() then 
        if self:isCanReqHelp() then
            self:addHelpTimeUpdater(false)
            self.nodeHelpTime:setVisible(false)
            CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("4249715"))
        else
            if not self.nodeHelpTime:isVisible() then 
                self.nodeHelpTime:setVisible(true)
                CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, "")
            end
            local lastReqHelpTime = cc.UserDefault:getInstance():getIntegerForKey(gtblTimeoutKey.makeXXXReqHelp, 0)
            local worldTime = getWorldTime()
            local difTime = worldTime - lastReqHelpTime
            self.m_timeLabel:setString(format_time(FestalActMakexxxCtl.minReqHelpIntervalTime - difTime))
        end
    end
end

function ItemGetMethodCell:addCountDownUpdater(flag)
    Dprint("addCountDownUpdater ", flag, self.m_countEndTime)
    if self.m_entryCountDownId then 
        self:getScheduler():unscheduleScriptEntry(self.m_entryCountDownId)
        self.m_entryCountDownId = nil
    end
    if not flag then
        self.m_countEndTime = 0
    end
    local difTime = self.m_countEndTime - getTimeStamp()
    if difTime > 0 then -- 倒计时
        self.node_updateCountDown:setVisible(true)
        self.m_titleTxt:setPositionY(self.m_titleTxt:getPositionY() + deltaPosY)
        self.m_entryCountDownId = self:getScheduler():scheduleScriptFunc(function(dt) self:updateCountDown(dt) end, 1.0, false)
    end
    self:updateCountDown(0)
end

function ItemGetMethodCell:updateCountDown( dt )
    local difTime = self.m_countEndTime - getTimeStamp()
    Dprint("updateCountDown difTime", difTime ,format_time(difTime))
    if difTime > 0 then -- 倒计时
        self.txt_timeCountDown:setString(format_time(difTime))
    else
        self.txt_timeDesc:setVisible(true)
        self.m_getBtn:setVisible(false)
        self.node_updateCountDown:setVisible(false)
        self.m_titleTxt:setPositionY(originPosY)
    end
end

function ItemGetMethodCell:isCanReqHelp()
    return getTimeoutForKey(gtblTimeoutKey.makeXXXReqHelp, FestalActMakexxxCtl.minReqHelpIntervalTime)
end

function ItemGetMethodCell:onEnter()
    if self:isHelpItem() then 
        if self:isCanReqHelp() then 
            self:addHelpTimeUpdater(false)
            CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("4249715"))
        else
            CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, "")
            self:addHelpTimeUpdater(true)
        end
    end
end

function ItemGetMethodCell:onExit()
    self:addHelpTimeUpdater(false)
    self:addCountDownUpdater(false)
end

function ItemGetMethodCell:addHelpTimeUpdater(bAdd)
    if self.m_entryId then 
        self:getScheduler():unscheduleScriptEntry(self.m_entryId)
        self.m_entryId = nil
    end
    if bAdd then 
        self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:updateHelpTime(dt) end, 1.0, false)
        self:updateHelpTime()
    end
end

function ItemGetMethodCell:addHelpTime()
    if self:isHelpItem() then 
        if self.nodeHelpTime then 
            self.nodeHelpTime:removeAllChildren()
        else
            self.nodeHelpTime = cc.Node:create()
            self.m_getBtn:addChild(self.nodeHelpTime)
            local size = self.m_getBtn:getContentSize()
            self.nodeHelpTime:setPosition(size.width/2, size.height/2)
        end
        local label = cc.Label:createWithSystemFont(itmeName, "Helvetica", 22, cc.size(0.0,0))
        self.nodeHelpTime:addChild(label)
        self.m_timeLabel = label
    end
end

--活动中的“求助”
function ItemGetMethodCell:isHelpItem()
    return (self.m_data.type == tostring(ItemGetType.MakexxxReqHelp)) and (self.m_data.para1 == "208")
end

function ItemGetMethodCell:onClickGet()
    local flag = PopupViewController:call("isLastLevel4PopupView")
    self:onClickGetExtra()
    -- 当前弹出框为半屏幕弹出框
    -- 最后打开的弹出框为全屏弹出框
    if flag and (not PopupViewController:call("isLastLevel4PopupView")) then
        -- 移除所有半屏弹出框
        PopupViewController:call("removeLevel4PopupView")
    end
end

--main: 0, 1
--sub: 1,2,3,4,5
function ItemGetMethodCell:openBagViewEx(main,sub)
    MyPrint(main,sub,self.m_itemId,"main,sub+++")
    main = main or 0
    sub = sub or 5
    LuaController:call("openBagView", main)
    local para1 = CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", self.m_itemId, "para1")
    dump(para1,"para1+++")
    if para1 and para1 ~= "" then 
        sub = para1
    end
    MyPrint(self.m_data.itemIdWanted, para1, "itemIdWanted+++")
    local dict = CCDictionary:create() 
    dict:setObject(CCString:create(tostring(main)), 'main')
    dict:setObject(CCString:create(tostring(sub)), 'sub')
    dict:setObject(CCString:create(self.m_data.itemIdWanted), 'highLightItem')
    CCSafeNotificationCenter:postNotification("MSG_CHANGE_BAG_VIEW", dict)
end 

function ItemGetMethodCell:onClickGetExtra()
    MyPrint("ItemGetMethodCell:onClickGet ", self.m_itemId)
    local getType = tonumber(CCCommonUtilsForLua:call("getPropById", self.m_itemId, "type"))
    local popViewName = ""
    local beCloseSelf = false
    if getType == ItemGetType.GoldExchange then
        popViewName = "GoldExchangeView_NEW";
    elseif getType == ItemGetType.DragonTower then
        local buildId = FunBuildController:call("getMaxLvBuildByType", 432000)
        if buildId == 0 then
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("169042"))
            return
        end

        PopupViewController:call("removeAllPopupView")
        FunBuildController:call("moveToBuildByBuildType", 432000)
    elseif getType == ItemGetType.Activity then
        PopupViewController:call("removeAllPopupView")
        ActivityController:call("openActivityView")
    elseif getType == ItemGetType.Merchant then
        local mainCityLv = FunBuildController:call("getMainCityLv")
        if mainCityLv < 6 then
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("169042"))
            return
        end

        popViewName = "MerchantView"
    elseif getType == ItemGetType.Store then
        self.parent_view:closeSelf()
        -- PopupViewController:call("removeAllPopupView")
        -- LuaController:call("openBagView", 1)
        self:openBagViewEx(1,nil)
        return
    elseif getType == ItemGetType.DragonExplore then
        if CCCommonUtilsForLua:isFunOpenByKey("dragon_lua") then
            PopupViewController:call("removeAllPopupView")
            local dragonInfo = DragonController:call("getActiveDragonInfo")
            if dragonInfo == nil then
                return
            end
            if CCCommonUtilsForLua:isFunOpenByKey("dragon_new_ui_switch") then
                local view = Drequire("game.NewDragon.NewDragon_V2.DragonListNewView"):create()			
                PopupViewController:call("addPopupInView", view)
                if nil ~= view then					
                    view:openDragonViewByUuid(dragonInfo:call("getUuid"),dragonInfo:call("getBaseId"))
                end
            else
                local DragonCave_New = Drequire("game.NewDragon.DragonCave_New")
                local view = DragonCave_New:create({uuid = dragonInfo:call("getUuid")})
                PopupViewController:call("addPopupInView", view)
            end          
            return
        else
            popViewName = "DragonIntimacyView"
        end
    elseif getType == ItemGetType.HeroBuyFragment then
        MyPrint("self.m_param ", self.m_param)
        -- 参数有两种类型
        -- 1.纯数值 heroId
        -- 2.表结构 {heroId, needNum}
        local param1 = nil
        local param2 = nil
        if type(self.m_param) == "table" then
            param1 = self.m_param.heroId
            param2 = self.m_param.needNum
        else 
            param1 = self.m_param
        end
        PopupViewController:call("removeLastPopupView")
        package.loaded["game.hero.HeroBuyFragmentView"] = nil
        local HeroBuyFragmentView = require("game.hero.HeroBuyFragmentView")
        local useItemView = HeroBuyFragmentView:create(param1, param2)
        PopupViewController:addPopupInView(useItemView)
    elseif getType == ItemGetType.JumpToBuild then
        local data = self.m_data
        PopupViewController:call("removeAllPopupView")
        local speBuild = false
        if data.para2 == "1" then
            speBuild = true
        end
        FunBuildController:call("moveToBuildByBuildType", tonumber(data.para1), speBuild)
    elseif getType == ItemGetType.OpenDailyActivity then
        PopupViewController:call("removeAllPopupView")
        if CCCommonUtilsForLua:isFunOpenByKey("new_daily_active_switch") then
            local view = Drequire("game.NewDailyActive.NewDailyActiveFrameView"):create()
            PopupViewController:addPopupInView(view)
        else
            local view = Drequire("game.Tavern.DailyActiveView"):create()
            PopupViewController:addPopupInView(view)
        end

    elseif getType == ItemGetType.JumpToWorld then
        local itemId = self.itemId

        local function findBuild()
            local buildType = CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", tostring(itemId), "para1")
            if buildType and buildType ~= "" then
                local level = CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", tostring(itemId), "para2")
                if not level or level == "" then
                    local key = "FindResTile_";
                    key = key..CC_ITOA(buildType);
                    level = cc.UserDefault:getInstance():getIntegerForKey(key, 1);
                end
                local cmd = Drequire("game.command.IFFindResTileCmd").create(tonumber(buildType), tonumber(level or 1))
                cmd:send()
            end
        end

        PopupViewController:call("removeAllPopupView")
        -- 世界 
        if SceneController:call("getCurrentSceneId") ~= 11 then
            require("game.CommonPopup.CommonEventController"):once("msgSceneChangeFinish", function () 
                if SceneController:call("getCurrentSceneId") == 11 then
                    findBuild()
                end
            end)
            SceneController:call("gotoScene", 11)
        else
            findBuild()
        end
    elseif getType == ItemGetType.OpenHeroTowerHomeView then
        if CCCommonUtilsForLua.isHeroChallengeOpen(  ) then
            popViewName = "HeroTowerHomeView"
        else
            -- 169042=该功能暂未开启，敬请期待
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("169042"))
        end
    elseif getType == ItemGetType.DragonBag then
        if CCCommonUtilsForLua:call("isFunOpenByKey", "dragon_friendship") then
            PopupViewController:call("removeLastPopupView")
            popViewName = "DragonBagView"
        else
            -- 169042=该功能暂未开启，敬请期待
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("169042"))
        end
    elseif getType == ItemGetType.AllianceTreasure then
        if CCCommonUtilsForLua:call("isKuaFu") then
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("102531"))
            return
        end

        local mycitylv = FunBuildController:call("getMainCityLv")
        local limit = AllianceDailyController:call("getInstance"):getProperty("conditionPublishLevel")
        if limit and mycitylv < limit then
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("134068", tostring(limit)))
            return
        end
        beCloseSelf = true
        popViewName = "AllianceDailyPublishView"
    elseif getType == ItemGetType.AllianceQuest then
        beCloseSelf = true
        popViewName = "AllianceQuestView"
    elseif getType == ItemGetType.StoreBagView then
        -- PopupViewController:call("removeAllPopupView")
        beCloseSelf = true
        -- LuaController:call("openBagView", 0)
        self:openBagViewEx(0,nil)
    elseif getType == ItemGetType.ActivityView then
        local actId = CCCommonUtilsForLua:call("getPropById", tostring(self.m_itemId), "para1")
        local obj = ActivityController:call("getActObj", actId)
        if nil == obj then
            -- 176074=活动暂未开启
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("176074"))
        else
            beCloseSelf = true
            -- PopupViewController:call("removeAllPopupView")
            -- ActivityController:call("shouActUIById", actId)
            ActivityController.getInstance():shouActUIById(actId)
        end
    elseif getType == ItemGetType.AllianceShop then
        local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
        local hasAlliance = playerInfo:call("isInAlliance")
        if hasAlliance then
            beCloseSelf = true;
            popViewName = "AllianceShopView"
        else
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("132360"))
        end
    elseif getType == ItemGetType.KingdomLiBao then
        PopupViewController:call("removeAllPopupView")
        local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
        local serverId = playerInfo:getProperty("selfServerId")
        local dict = CCDictionary:create()
        dict:setObject(CCString:create("KingsGiftView"), "name")
        dict:setObject(CCString:create(tostring(serverId)), "serverId")
        LuaController:call("openPopViewInLua", dict)
        return
    elseif getType == ItemGetType.HeroGetRolate then
        if CCCommonUtilsForLua:isFunOpenByKey("hero_roulette") then
            PopupViewController:call("removeAllPopupView")
            local prlvPath = "game.hero.NewUI.HeroGetRotateView"
            local view = Drequire(prlvPath)
            PopupViewController:call("addPopupInView", view:create("89699","hero_type"))
        end
    elseif getType == 0 then    
        local itemId = tonumber(CCCommonUtilsForLua:call("getPropById", tostring(self.m_itemId), "para1"))
        if itemId == 200380 or itemId == 213739 then
            local dict = CCDictionary:create()
            dict:setObject(CCString:create("ToolNumSelectView"), "name")
            dict:setObject(CCString:create(tostring(itemId)), "itemId")
            dict:setObject(CCString:create(tostring(0)), "opFrom")
            dict:setObject(CCString:create(""), "targetId")
            LuaController:call("openPopViewInLua", dict)
        else
            ToolController:call("useTool", itemId, 1, true, false)
        end
    elseif getType == ItemGetType.CivPrestage then
        PopupViewController:call("removeAllPopupView")
        local CivilizationDonateView = Drequire("game.civilization.prestige.CivilizationDonateView")
        local view = CivilizationDonateView:create()
        PopupViewController:addPopupInView(view, true)
        return
    elseif getType == ItemGetType.CivShop then
        PopupViewController:call("removeAllPopupView")
        local view = myRequire("game.civilization.prestige.CivilizationShopView").create()
        PopupViewController:addPopupInView(view)
        return
    elseif getType == ItemGetType.HeroRecruit or getType == ItemGetType.HeroRecruitActivity then
        -- PopupViewController:call("removeAllPopupView")
        self.parent_view:closeSelf()
        local view = Drequire("game.hero.LuckDraw.HeroLuckDrawView").create()
        PopupViewController:addPopupInView(view)
        return 
    elseif getType == ItemGetType.ShuiJingBox then
        -- dump("hanxiao12345 in open ShuiJingBox")
        LogController:call("getInstance"):call("postEventLog", "shuijing")

        local dict = CCDictionary:create()
        dict:setObject(CCString:create(USE_TOOL_SHUIJING), "type")
        dict:setObject(CCString:create("138523"), "title")        
        CCSafeNotificationCenter:call("postNotification", "ItemGetMethodView_closeself")
        local view = Drequire("game.CommonPopup.UseToolView"):create(USE_TOOL_SHUIJING, dict, "138523")
        PopupViewController:addPopupInView(view)
        return
    elseif getType == ItemGetType.ItemExchange then
        local lua_path = "game.store.BagExchangeView"
        package.loaded[lua_path] = nil
        require(lua_path)
        local itemId = CCCommonUtilsForLua:call("getPropById", self.m_itemId, "para1")
        MyPrint("go to more for itemid = ",itemId ,"and self = ",self.parent_view)
        local  view  = BagExchangeView:create(itemId)
        if view == nil then 
            MyPrint("BagExchangeView is nil ")
        end
        PopupViewController:addPopupInView(view)
        PopupViewController:call("removePopupView",self.parent_view)
        PopupViewController:call("removePopupView",self.m_fromView)
        return
    elseif getType == ItemGetType.TreasureShop then
        if CCCommonUtilsForLua:isFunOpenByKey("treasure_fam_on_1") then
            CCSafeNotificationCenter:call("postNotification", "ItemGetMethodView_closeself")
            TreasureFamManager:getTreasureFamInfo()
            local view = Drequire("game.TreasureFam.TreasureFamShopView"):create()
            PopupViewController:addPopupInView(view)
        else
            LuaController:flyHint("", "", getLang("E100008"))
        end
        return
    elseif getType == ItemGetType.AuctionHouse then
        if not CCCommonUtilsForLua:isFunOpenByKey("auction") then
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("169042"))  --活动未开启
            return
        end
        local cross = GlobalData:call("getPlayerInfo"):getProperty("crossFightSrcServerId")
        if cross and cross ~= -1 then
            if cross then dump(cross,"cross+++") end
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("9440926"))   --跨服状态,不能开启拍卖行           
            return 
        end
        --先获取数据，活动不开启，inActivity=0
        CCSafeNotificationCenter:call("postNotification", "ItemGetMethodView_closeself")
        AuctionHouseController:pullAuctionHouseViewData()
        return
    elseif getType == ItemGetType.MagicDrawView then
        CCSafeNotificationCenter:call("postNotification", "ItemGetMethodView_closeself")
        if CCCommonUtilsForLua:isFunOpenByKey("magic_skill") then
            local poolIndex = atoi(CCCommonUtilsForLua:call("getPropById", tostring(self.m_itemId), "para1"))
            local cardIndex = atoi(CCCommonUtilsForLua:call("getPropById", tostring(self.m_itemId), "para2"))
            local view = Drequire("game.magic.LuckDraw.MagicLuckDrawView"):create(cardIndex, poolIndex)
            PopupViewController:call("addPopupInView", view)
        end
        return
    elseif getType == ItemGetType.MakexxxReqHelp then 
        if self:isHelpItem() then
            if self:isCanReqHelp() then 
                self:addHelpTimeUpdater(false)
                setTimeoutForKey(gtblTimeoutKey.makeXXXReqHelp,false)
                self.parent_view:closeSelf()
                CCSafeNotificationCenter:call("postNotification", MSG_MAKE_XXX_REQ_HELP)
                LuaController:flyHint("", "", getLang("4249724")) -- 4249724=求助成功，在联盟聊天中查看
            else
                LuaController:flyHint("", "", getLang("4249726"))
            end
        end
    elseif getType == ItemGetType.JumpToWorldResource then
        PopupViewController:call("removeAllPopupView")
        if self.m_param == nil then
            self.m_param = {}
        end
        local cmd = Drequire("game.command.IFFindResTileCmd").create(self.m_param.buildType or 9, self.m_param.level or 1)
        cmd:send()
        return
    elseif getType == ItemGetType.JumpToForge then
        local vipView = Drequire("game.equipment.NewEquip.NewEquipMainView"):create()
        PopupViewController:addPopupInView(vipView)
    elseif getType == ItemGetType.CrystalRoulette then 
        local view = Drequire("game.hero.NewUI.HeroGetRotateView"):create("89698","crystal_type")
        PopupViewController:call("addPopupInView", view) 
        self.parent_view:closeSelf()
    elseif getType == ItemGetType.JumpToRepay then
        require("game.LiBao.Repay.RepayController")
        if RepayController.getInstance():isBegin() then
            RepayController.getInstance():fireEvent("RepayViewCreate")
            self.parent_view:closeSelf()
        end
    elseif getType == ItemGetType.AllianceBoss then
        PopupViewController:call("addPopupInView", myRequire("game.allianceBoss.AllianceBossView").create())
        self.parent_view:closeSelf()
    elseif getType == ItemGetType.AvatarStoreFragment then  --【Awen】装扮商城碎片页签
        PopupViewController:call("removeAllPopupView")
        local AvatarViewEx = Drequire("game.avatar.AvatarViewEx")
		local view = AvatarViewEx.create(AvatarType_MysteryPiece)
		PopupViewController:call("addPopupInView", view)
        self.parent_view:closeSelf()
    elseif getType == ItemGetType.AvatarStoreDiamond then   --【Awen】装扮商城钻石页签
        PopupViewController:call("removeAllPopupView")
        local AvatarViewEx = Drequire("game.avatar.AvatarViewEx")
		local view = AvatarViewEx.create(AvatarType_Diamond)
		PopupViewController:call("addPopupInView", view)
        self.parent_view:closeSelf()
    elseif getType == ItemGetType.TournamentAddNum then
        TournamentControllerInst:requestAddFightNum()
    end

    if popViewName ~= "" then
        if beCloseSelf then
            self.parent_view:closeSelf()
        else
            if self.m_fromView == "DragonInfo_New" then
                PopupViewController:call("removeLastPopupView")
            else
                PopupViewController:call("removeAllPopupView")
            end
        end
        local dict = CCDictionary:create()
        dict:setObject(CCString:create(popViewName), "name")
        LuaController:call("openPopViewInLua", dict)
    end


    if self.m_sourceType and tostring(self.m_sourceType) ~= "" then 
        local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
        local uid = playerInfo:getProperty("uid")

        LogController:postEventLog("itmeGetMethodShow_leaveTo", {time = getWorldTime(), UID=uid, sourceType = self.m_sourceType, btnId=getType})
    end

end
------------------------------------------ ItemGetMethodCell End --------------------------------------------

------------------------------------------ ItemGetMethodView Start --------------------------------------------

function ItemGetMethodView:create(itemId, param, fromView)
	local view = ItemGetMethodView.new()
	if view:initView(itemId, param, fromView) == false then
		return nil
	end
    LiBaoController.getInstance():markViewNeedDel(view)
  	return view
end

function ItemGetMethodView:initView(itemId, param, fromView)
    MyPrint("ItemGetMethodView:initView--> ", itemId, param)
	  if self:init(true, 0) == false then
		    MyPrint("ItemGetMethodView init error")
    	  return false
    end

    self:setHDPanelFlag(true)
    self.param = param
    self.fromView = fromView
    CCLoadSprite:call("doResourceByCommonIndex", 101, true)
    local m_bIsPad = CCCommonUtilsForLua:isIosAndroidPad()
    local  proxy = cc.CCBProxy:create()
    local ccbiURL = ""
    ccbiURL = "ccbi/ItemGetMethodView.ccbi"
    self.m_bIsPad = m_bIsPad
    local nodeccb = CCBReaderLoad(ccbiURL,proxy, self)
    if nodeccb == nil then
        MyPrint("ItemGetMethodView loadccb error")
        return false
    end

    local baseScale = 1
    if m_bIsPad then
        nodeccb:setScale(2.0)
        baseScale = 2
    end
    self:setContentSize(cc.Director:getInstance():getIFWinSize())
  	self:addChild(nodeccb)

  	self.m_itemId = tostring(itemId)
  	self.m_getMethodId = ""
  	-- 读前台表获取数据
  	local tempData = CCCommonUtilsForLua:getGroupByKey("staff_get")
    if tempData == nil then
        return false
    end

    local staffGetMethodData = CCCommonUtilsForLua:getGroupByKey("staff_get_method")
    if staffGetMethodData == nil then
        return false
    end
    local staffData = nil
  	for k,v in pairs(tempData) do
        if v.item_id == nil then 
            dump(v,"nil id tempData")
        end
        if v.item_id ~= nil and string.find(v.item_id, self.m_itemId) ~= nil then
    		self.m_getMethodId = k
            staffData = v
    	end
  	end

  	if self.m_getMethodId == "" then
        MyPrint("ItemGetMethodView:find no itemId with "..self.m_itemId)
    		return false
  	end

    self.m_staffData = staffData

  	local method = CCCommonUtilsForLua:call("getPropByIdGroup","staff_get", self.m_getMethodId, "method")

  	local data = string.split(method, "|")
  	self.m_data = data
    self.m_titleTxt:setString(getLang("164951"))
  	local scrollView = cc.ScrollView:create()
    local goldItemShowType = nil
    local goldItemShowTypeTbl = {}
    local staffGet = false
    self.staffGet = false
    local beHasMethod = false   -- 是否有跳转方式
    if scrollView ~= nil then

        local height = 0
        local mainNode = cc.Node:create();
        local beHeroRoulette = CCCommonUtilsForLua:isFunOpenByKey("hero_roulette")
        for i,v in ipairs(self.m_data) do
            local methodData = staffGetMethodData[v]
            if methodData then
                methodData.itemIdWanted = self.m_itemId
                if methodData.type == "1" and methodData.para1 then
                    goldItemShowTypeTbl[#goldItemShowTypeTbl + 1] = methodData.para1
                else
                    -- 传给函数的参数处理
                    if not beHeroRoulette and tonumber(CCCommonUtilsForLua:call("getPropByIdGroup","staff_get_method", tostring(methodData.id), "type")) == ItemGetType.HeroGetRolate then
                   
                    else
                        local cell = ItemGetMethodCell:create(methodData, self.param, self.fromView, self.m_staffData.statistics,self)
                        mainNode:addChild(cell)
                        height = height + ItemGetMethod_Cell_Height
                        cell:setPosition(cc.p(0, 0 - height))
                        staffGet = true
                    end
                    beHasMethod = true
                end
            end
        end
        local list = self.m_infoList
        if #goldItemShowTypeTbl == 0 then 
            list = self.m_infoList
        end
        local cH = list:getContentSize().height
        scrollView:setViewSize(list:getContentSize())
        scrollView:setPosition(cc.p(0,0))
        scrollView:setScale(1.0)
        scrollView:ignoreAnchorPointForPosition(true)
        scrollView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
        scrollView:addChild(mainNode);
        mainNode:setPosition(cc.p(0, height))
        scrollView:setContentSize(CCSize(ItemGetMethod_Cell_Width,height))
        scrollView:setContentOffset(CCPoint(0, cH - height))
        list:addChild(scrollView)
        if cH > height then
            scrollView:setTouchEnabled(false)
        end
    end
    -- dump(goldItemShowType,"goldItemShowType+++")
    for _, v in pairs(goldItemShowTypeTbl) do
        local result = LiBaoController.getInstance():checkHasGoldItemByShowType(v)
        if result == false then
            dump(v, "warnning, no libao for this type+++")
        else
            if goldItemShowType then
                goldItemShowType = goldItemShowType .. "|" .. v
            else
                goldItemShowType = v
            end
        end
    end

    if beHasMethod == false and not goldItemShowType then
        -- 添加一个没有跳转数据的保护
        dump("error, method and type both nil, are you kidding+++")
        return false
    end

    -- dump(goldItemShowType,"goldItemShowType2+++")
    self.goldItemShowIndex = 1
    local defaultShowType = nil
    if goldItemShowType then
        local path = "game.LiBao.LuaGoldExchangeAdView"
        local advNode = Drequire(path).new(goldItemShowType, nil, nil, nil, {getMethodItemId = self.m_itemId})
        self.m_advNode:addChild(advNode)
        self.m_advNode:setScale(0.77)
        defaultShowType = advNode:getShowType(self.goldItemShowIndex)
    end

    LogController:postEventLog(LOG_ITEM_GET_METHOD_SHOW, {
                show_type = goldItemShowType or -1,
                itemId = self.m_itemId,
                })
    self.m_descTxt:setString(getLang(staffData.desc))

    local height = 0
    -- 显示逻辑整理
    if goldItemShowType then
        self.m_middleNode:setVisible(true)
        height = 456
    else
       -- self.m_middleNode:setVisible(false)
       self.m_descTxt:setPositionY(self.m_descTxt:getPositionY() + height)
        -- 针对单显示获取途径的地方，增大显示区域
        local offset = 140
        self.m_sprinteMoreItemsBg3:setVisible(true)
        height = height + offset
        self.m_middleNode:setVisible(false)
        self.m_descTxt:setPositionY(self.m_descTxt:getPositionY() + offset)
        local viewSize = self.m_infoList:getContentSize()
        local newSize = cc.size(viewSize.width, viewSize.height + offset+20)
        self.m_infoList:setContentSize(newSize)

        local contentSize = scrollView:getContentSize()
        scrollView:setViewSize(newSize)
        scrollView:setContentOffset(CCPoint(0, newSize.height - contentSize.height))
        self.m_infoList:addChild(scrollView)

        if newSize.height > contentSize.height then
            scrollView:setTouchEnabled(false)
        else
            scrollView:setTouchEnabled(true)
        end
    end
    -- staffGet = false
    MyPrint("ItemGetMethodView:initView staffGet is "..tostring(staffGet))
    if staffGet then
        height = height + 284
    else
        self.m_lineL2Node:setVisible(false)
        self.m_lineR2Node:setVisible(false)
    end
    self.m_bottomNode:setPositionY(0-height)
    self.m_touchNode:setContentSize(cc.size(self.m_touchNode:getContentSize().width, height))
    self.m_baseNode:setPositionY(self:getContentSize().height/2 + height/2)

    self:adjustToDefault(height)
    self.ccbNode = nodeccb
    local function onNodeEvent(event)
      	if event == "enter" then
      		  self:onEnter()
      	elseif event == "exit" then
      		  self:onExit()
      	end
    end
  	self.ccbNode:registerScriptHandler(onNodeEvent)

  	function onTouch(eventType, x, y)  
        if eventType == "began" then  
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)  
        else  
            return self:onTouchEnded(x, y)  
        end
    end
    self.m_touchLayer:setTouchEnabled(true)
    self.m_touchLayer:registerScriptTouchHandler(onTouch)
    
    -- local touchif = tolua.cast(self,"cc.CCIFTouchNode")
    -- if touchif ~= nil then
    --     local dic1 = CCDictionary:create()
    --     dic1:setObject(CCBool:create(true),"1")
    --     touchif:comFunc("setTouchEnabled", dic1)

    --     MyPrint("ItemGetMethodView:registerScriptTouchHandler")
    --     touchif:registerScriptTouchHandler(onTouch)
    -- end
    
    dump("ItemGetMethodView add more items+++")
    self.m_closeBtn:setEnabled(false)
    self.oldBottomNodePosY = self.m_bottomNode:getPositionY()
    self.staffGet = staffGet --是否有其他方式获取道具
    self.goldItemShowType = goldItemShowType
    self.m_spriteMoreItemsBot:setVisible(false)
    -- self.m_sprinteMoreItemsBg1:setVisible(false)
    -- self.m_sprinteMoreItemsBg2:setVisible(false)
    self:addLiBaoMoreItems(true, defaultShowType)
    return true
end

--如果高度是0，则调整为默认只显示一张图
function ItemGetMethodView:adjustToDefault(height)
    if height ~= 0 then 
       return
    end
    dump(height, "ItemGetMethodView:adjustToDefault+++")
    local path = "game.LiBao.LuaGoldExchangeAdView"
    local advNode = Drequire(path).new(nil,nil,true)
    self.m_advNode:addChild(advNode)
    self.m_advNode:setScale(0.77)
    self.m_lineL2Node:setVisible(false)
    self.m_lineR2Node:setVisible(false)
    self.m_middleNode:setVisible(true)

    local newHeight = 456
    self.m_bottomNode:setPositionY(0-newHeight)
    self.m_touchNode:setContentSize(cc.size(self.m_touchNode:getContentSize().width, newHeight))
    self.m_baseNode:setPositionY(self:getContentSize().height/2 + newHeight/2)
end

--添加套餐信息
local LibaoGroupShowView = require("game.LiBao.LibaoGroupShowView")
function ItemGetMethodView:addLiBaoMoreItems(bCheck, goldItemShowType)
    -- dump("addLiBaoMoreItems542+++")
    if not CCCommonUtilsForLua:isFunOpenByKey("option_package_show") then
        dump("option_package_show off+++") 
        return 
    end
    goldItemShowType = goldItemShowType or self.lastUpdateGoldItemShowType
    local index = self.goldItemShowIndex
    dump(goldItemShowType, "ItemGetMethodView:addLiBaoMoreItems+++"..index)
    if bCheck then
        if self.lastUpdateGoldItemShowType and self.lastUpdateIndex 
            and (self.lastUpdateGoldItemShowType == goldItemShowType) and (self.lastUpdateIndex == index) then 
            dump("ignore update+++")
            return
        end
    end
    self.lastUpdateGoldItemShowType = goldItemShowType
    self.lastUpdateIndex = index
    self.m_spriteMoreItemsBot:setVisible(false)
    self.m_infoListMoreItems:removeAllChildren()
    self.m_bottomNode:setPositionY(self.oldBottomNodePosY)
    if not goldItemShowType or not index then 
        dump("no goldItemShowType+++")
        return
    end

    self.groupDataTbl = {}
    if goldItemShowType then 
        local tbl = LiBaoController.getInstance():getCurLiBaoMapInLua(goldItemShowType)
        -- dump(tbl, "ItemGetMethodView:addLiBaoMoreItems2+++")
        if (not tbl) or (#tbl < 1) or (#tbl < index) then 
            dump(index,"no li bao more items+++")
            return
        end
        self.groupDataTbl = tbl[index]
        self.moreItemsData = LibaoCommonFunc.getGoldItemList(tbl[index], true)
        -- dump(self.moreItemsData,"moreItemsData+++",10)
    end
    -- dump(self.groupDataTbl,"what items you want,you choose+++",10)
    if (not self.moreItemsData) or #(self.moreItemsData) < 1 then 
        dump("self.moreItemsData is empty+++")
        return
    end
    self.moreItemsDataTblData = {}
    for k,v in pairs(self.moreItemsData) do 
        if v.groupItemList then
            self.moreItemsDataTblData[#self.moreItemsDataTblData+1]=v
        else
            local more = {}
            more.groupItemList = {}
            table.insert(more.groupItemList, v)
            self.moreItemsDataTblData[#self.moreItemsDataTblData+1]=more
        end
    end
    if #self.moreItemsDataTblData == 0 then 
        dump("error:no data in more items?+++")
        return
    end

    -- dump(self.moreItemsDataTblData,"what item you will get in this single libao+++",10)
    local size = self.m_infoListMoreItems:getContentSize()
    local addHeight = 0
    local hasMoreGrpLiBao = self.groupDataTbl.options and self.groupDataTbl.options ~= ""
    if self.staffGet then 
        addHeight = 875 --有获取方式+礼包套餐
        local itemHeightAdded = 0
        if not hasMoreGrpLiBao then --没有“更多可选套餐”
            itemHeightAdded = 50 
        end
        self.m_bottomNode:setPositionY(-addHeight)
        self.m_infoListMoreItems:setContentSize(cc.size(size.width, 85+itemHeightAdded))
        self.m_spriteMoreItemsBot:setVisible(true)
        self.m_sprinteMoreItemsBg1:setVisible(true)
        self.m_sprinteMoreItemsBg2:setVisible(true)
        self.m_sprinteMoreItemsBg3:setVisible(true)
    else 
        addHeight = 665 --只有礼包套餐
        self.m_infoListMoreItems:setContentSize(cc.size(size.width, 150))
        self.m_infoListMoreItems:setPositionY(0)
        self.m_lineL2Node:setVisible(true)
        self.m_lineR2Node:setVisible(true)
        self.m_sprinteMoreItemsBg1:setVisible(false)
        self.m_sprinteMoreItemsBg2:setVisible(false)
        self.m_sprinteMoreItemsBg3:setVisible(false)
        self.m_bottomNode:setPositionY(-addHeight)
    end
    self.m_baseNode:setPositionY(self:getContentSize().height/2 + addHeight/2)
    self.m_touchNode:setContentSize(cc.size(self.m_touchNode:getContentSize().width, addHeight))

    local mainNode = cc.Node:create()
    local scrollView = cc.ScrollView:create()
    size = self.m_infoListMoreItems:getContentSize()
    scrollView:setViewSize(size)
    scrollView:setPosition(cc.p(0,0))
    scrollView:setScale(1.0)
    scrollView:setAnchorPoint(0,0)
    scrollView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
    -- addTestColor(scrollView)

    local  height = 0
    for k,itemData in pairs(self.moreItemsDataTblData) do 
        local cell = LibaoGroupShowView.new({
            itemData = itemData,
            cellWidth = 580,
            cellHeight = 70,
            showType = 0,
            parentNode = mainNode
        })
        cell:setAnchorPoint(0.5,1)
        mainNode:addChild(cell)
        cell:setScale(0.8)
        height = height + cell.cellHeight * 0.8
        cell:setPosition(cc.p(size.width/2, 0-height))
    end
    
    scrollView:addChild(mainNode)
    mainNode:setPosition(cc.p(0, height))
    scrollView:setContentSize(CCSize(ItemGetMethod_Cell_Width,height))
    scrollView:setContentOffset(CCPoint(0, size.height - height))
    self.m_infoListMoreItems:addChild(scrollView)
    -- addTestColor(self.m_infoListMoreItems, 200)

    -- 更多组合按钮
    if hasMoreGrpLiBao then 
        local groupMoreBtn = LibaoGroupShowView.createGetMoreGroupBtn(0)    
        groupMoreBtn:setAnchorPoint(0.5,1)
        groupMoreBtn:setEnabled(true)
        groupMoreBtn:addHandleOfControlEvent(
            function(eventName,sender)
                local path = "game.LiBao.LibaoGroupMoreListView"
                local groupMoreView = Drequire(path):create(self.groupDataTbl)
                PopupViewController:addPopupView(groupMoreView)
            end, CCControlEventTouchUpInside)
        CCCommonUtilsForLua:call("setButtonTitle", groupMoreBtn, getLang("9450001"))
        self.m_infoListMoreItems:addChild(groupMoreBtn)
        groupMoreBtn:setScale(0.7)
        groupMoreBtn:setPosition(size.width/2, size.height+45)
    end
    if #(self.moreItemsData) == 1 and self.staffGet then
        scrollView:setTouchEnabled(false)
    else
        scrollView:setTouchEnabled(true)
    end
end

--刷新礼包套餐信息
function ItemGetMethodView:onRefreshLiBaoMoreItems(param)
    dump(self.goldItemShowType,"ItemGetMethodView:onRefreshLiBaoMoreItems+++")
    local show_type = ""
    if param then
        local tbl = dictToLuaTable(param)
        -- dump(tbl,"param is+++")
        if tbl and tbl.index then 
            self.goldItemShowIndex = tonumber(tbl.index)
            show_type = tbl.show_type
            -- dump(tbl.index,"recv update_li_bao_more_items_in_get_method_view+++")
        end
    end
    self:addLiBaoMoreItems(true, show_type)
end

function ItemGetMethodView:onGoldExchangeShowRefresh(  )
    dump("ItemGetMethodView:onGoldExchangeShowRefresh+++")
    self:addLiBaoMoreItems(false)
end

function ItemGetMethodView:onEnter()
    registerScriptObserver(self,self.closeSelf,"ItemGetMethodView_closeself")
    registerScriptObserver(self, self.refreshView, "ItemGetMethodView_use_refresh")
    registerScriptObserver(self, self.refreshView, "msg_refreash_tool_data")
    registerScriptObserver(self, self.onRefreshLiBaoMoreItems, "update_li_bao_more_items_in_get_method_view")
    registerScriptObserver(self, self.onGoldExchangeShowRefresh, GOLDEXCHANGE_SHOW_REFRESH)
end

function ItemGetMethodView:onExit()
    unregisterScriptObserver(self,"ItemGetMethodView_closeself")
    unregisterScriptObserver(self, "msg_refreash_tool_data")
    unregisterScriptObserver(self, "ItemGetMethodView_use_refresh")
    unregisterScriptObserver(self, "update_li_bao_more_items_in_get_method_view")
    unregisterScriptObserver(self, GOLDEXCHANGE_SHOW_REFRESH)
end

function ItemGetMethodView:onTouchBegan(x, y)
    self.touchType = 0
    if touchInside(self.m_touchNode, x, y) == false then
        self.touchType = 1
        return true
    end
    return false
end

function ItemGetMethodView:onTouchMoved(x, y)
end

function ItemGetMethodView:onTouchEnded(x, y)
  	if self.touchType == 1 and touchInside(self.m_touchNode, x, y) == false then
    		MyPrint("ItemGetMethodView:onTouchEnded touchInside m_touchNode")
            tolua.cast(self, "PopupBaseView")
    		self:call("closeSelf")
            LiBaoController.getInstance():setIsNeedRemoveMarkView(false)
  	end
end

function ItemGetMethodView:closeSelf( ... )
    -- body
    tolua.cast(self, "PopupBaseView")
    self:call("closeSelf")
end

function ItemGetMethodView:onClickClose()
end

function ItemGetMethodView:refreshView(  )
    if self.m_infoList then
        self.m_infoList:removeAllChildren(true)
    end
    local staffGetMethodData = CCCommonUtilsForLua:getGroupByKey("staff_get_method")
    if staffGetMethodData == nil then
        return false
    end
    local scrollView = cc.ScrollView:create()
    local goldItemShowType = nil
    local staffGet = false
    if scrollView ~= nil then
        scrollView:setViewSize(self.m_infoList:getContentSize())
        scrollView:setPosition(cc.p(0,0))
        scrollView:setScale(1.0)
        scrollView:ignoreAnchorPointForPosition(true)
        scrollView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)

            local cH = self.m_infoList:getContentSize().height
        local height = 0
        local mainNode = cc.Node:create();
       local beHeroRoulette = CCCommonUtilsForLua:isFunOpenByKey("hero_roulette")
        for i,v in ipairs(self.m_data) do
            local methodData = staffGetMethodData[v]
            if methodData then
                if methodData.type == "1" and methodData.para1 then
                    goldItemShowType = methodData.para1
                else
                    -- 传给函数的参数处理
                    if not beHeroRoulette 
                        and tonumber(CCCommonUtilsForLua:call("getPropByIdGroup","staff_get_method", tostring(methodData.id), "type")) == ItemGetType.HeroGetRolate 
                        then
                    else
                        local cell = ItemGetMethodCell:create(methodData, self.param, self.fromView, self.m_staffData.statistics)
                        mainNode:addChild(cell)
                        height = height + ItemGetMethod_Cell_Height
                        cell:setPosition(cc.p(0, 0 - height))
                        staffGet = true
                    end
                end
            end
        end

        scrollView:addChild(mainNode);
        mainNode:setPosition(cc.p(0, height))
        scrollView:setContentSize(CCSize(ItemGetMethod_Cell_Width,height))
        scrollView:setContentOffset(CCPoint(0, cH - height))
        self.m_infoList:addChild(scrollView)

        if cH > height then
            scrollView:setTouchEnabled(false)
        end
    end
    self.staffGet = staffGet
    self:addLiBaoMoreItems(true)
end
return ItemGetMethodView







