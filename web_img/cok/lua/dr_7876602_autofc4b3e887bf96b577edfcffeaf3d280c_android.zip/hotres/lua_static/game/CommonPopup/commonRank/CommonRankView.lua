--[[ 
------------------------------通用排行榜界面------------------------------
配置:
排名奖励配置actType2XML
栏目标题配置: columnTile
标题配置:actId2Title
cell配置
headRankNode配置

@params:
	type:排行榜活动类型，不同活动排行榜拥有不同的type类型，与后端约定好 比如:typeTest
	viewType:1:本服玩家排行  2:全服玩家排行
	viewSize:界面尺寸大小
	pageSize:页面请求cell数量的限制，默认20个
	self_id: 个人排名传uid,其他的再定
 ]]
local CommonRankView = class("CommonRankView",
    function ()
        return cc.Layer:create()
    end)

CommonRankView.__index = CommonRankView
local cellHeight = 92	

--奖励配置
local actType2XML = {
	['typeTest'] = "consume_soldier_rank|20902000;20902001", --"20902000"个人本服排名奖励   "20902001"--个人全服排名奖励
	['monster_hunter_personal'] = "monster_hunter_rank|20942000;20942001", --"20902000"个人本服排名奖励   "20902001"--个人全服排名奖励
	['monster_hunter_alliance'] = "monster_hunter_rank|20942002;20942003;", --"20902000"个人本服排名奖励   "20902001"--个人全服排名奖励
	['general'] = "general_rank|35011001;35011002", -- 招募之神分期奖励
	['ladder'] = "ladder_rank|-1", -- 竞技场特殊奖励逻辑
}

-- 栏目标题配置
local columnTile = {
	['typeTest'] = "108101;182091;102139", -- 108101=领主 182091=本期积分 102139=奖励
	['general'] = "108101;182091;102139", -- 108101=领主 182091=本期积分 102139=奖励
	['ladder'] = "108101;620073;102139", -- 108101=领主 620073=玩家杯数 102139=奖励
}

--title配置
local actId2Title = {
	['typeTest'] = "182181;182183;182185",
	['monster_hunter_personal'] = "182194;182196",
	['monster_hunter_alliance'] = "182198;182200",
	['general'] = "350245;350245;350245",
	['ladder'] = "350245;350245;350245",
}

-- tips配置
local tipsTile = {
	['typeTest'] = "221125", -- 221125 每小时刷新一次
	['general'] = "221125", -- 221125 每小时刷新一次
	['ladder'] = "620074", -- 620074 每10分钟刷新一次
}

-- rewardTips 配置
local rewardTips = {
	['typeTest'] = "221122", -- 221122=活动结束后，奖励通过邮件发放
	['general'] = "221122", -- 221122=活动结束后，奖励通过邮件发放
	['ladder'] = "620082", -- 620082=您每天必须手动领取排名奖励
}

--cell配置
local actType2CellFile = {
	['typeTest'] = {path="game.CommonPopup.commonRank.CommonRankPlayerTblCell",fileName = "CommonRankPlayerTblCell"},
	['monster_hunter_personal'] = {path="game.CommonPopup.commonRank.CommonRankPlayerTblCell",fileName = "CommonRankPlayerTblCell"},
	['monster_hunter_alliance'] = {path="game.CommonPopup.commonRank.CommonRankAllianceTblCell",fileName = "CommonRankPlayerTblCell"},
	['general'] = {path="game.CommonPopup.commonRank.CommonRankPlayerTblCell",fileName = "CommonRankPlayerTblCell"},
	['ladder'] = {path="game.CommonPopup.commonRank.CommonRankPlayerTblCell",fileName = "CommonRankPlayerTblCell"},
}

--headRankNode配置
local actType2RankNode = {
	['typeTest'] = "game.CommonPopup.commonRank.CommonRank3PlayerNode",
	['monster_hunter_personal'] = "game.CommonPopup.commonRank.CommonRank3PlayerNode",
	['monster_hunter_alliance'] = "game.CommonPopup.commonRank.CommonRank3AllianceNode",
	['general'] = "game.CommonPopup.commonRank.CommonRank3PlayerNode",
	['ladder'] = "game.CommonPopup.commonRank.CommonRank3PlayerNode",
}

-- type,m_viewType,viewSize,pageSize,self_id
function CommonRankView:create(params)
    local view = CommonRankView.new(params)
    Drequire("game.CommonPopup.commonRank.CommonRankView_ui"):create(view,0,params.viewSize)
    if view:initView(params) then
        return view
    end
end

function CommonRankView:ctor(params)
	self.m_params = params
	self.m_type = self.m_params.type
	self.m_viewType = self.m_params.viewType or 1	
	self.m_pageSize = self.m_params.pageSize or 20
	self.group = (self.m_viewType == 1 and "local" or "group")
	self.m_params["group"] = self.group
end

function CommonRankView:initView(params)
    CCLoadSprite:call("loadDynamicResourceByName", "AllServerRank_face")
    local function TouchEvent(eventType,x,y)
        if eventType == "began" then  
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)  
        else  
            return self:onTouchEnded(x, y)  
        end
    end
    self.ui.m_touchLayer:setTouchEnabled(true)
    self.ui.m_touchLayer:registerScriptTouchHandler(TouchEvent)
    self.ui.m_touchLayer:setSwallowsTouches(true)    
	self.m_pageIndex = 0
	self.ctl = require("game.CommonPopup.commonRank.CommonRankController").new(self.m_type)

	local titleInfo = string.split(columnTile[self.m_type],";")	
	local dialogId1 = titleInfo[1] or "108101" -- 108101=领主
	local dialogId2 = titleInfo[2] or "182091" -- 182091=本期积分
	local dialogId3 = titleInfo[3] or "102139" -- 102139=奖励
	self.ui.m_tNameLabel:setString(getLang(dialogId1)) 
	self.ui.m_tPowerLabel:setString(getLang(dialogId2)) 
	self.ui.m_tServerLabel:setString(getLang(dialogId3)) 

	local tipsId = tipsTile[self.m_type]
	self.ui.m_tipsLabel:setString(getLang(tipsId)) -- 每10分钟刷新一次

	self.m_leftTime = 0
	self:updateUI()

	self.m_curMaxRank = 0 -- 当前最大的排名
	self.m_isSearching = false -- 是否在查找排名
	self.m_searchingRank = 0 -- 要查找的排名
    self:reqData()
    return true
end

--请求界面信息
function CommonRankView:reqData()
	self.m_params["page"] = self.m_pageIndex
	self.ctl:reqData(self.m_params)
end

function CommonRankView:onEnter()
    CCSafeNotificationCenter:call("postNotification", "msg.CommonRankView.close")
    self:onEnterFrame(0)
	if self.entry then
		self:getScheduler():unscheduleScriptEntry(self.entry)
	end
	self.entry = tonumber(self:getScheduler():scheduleScriptFunc(function(dt)
		self:onEnterFrame(dt)
	end, 1, false))

    registerScriptObserver(self,self.getPlayerRankData,"msg.CommonRankView.getLocalPlayerRank")
    registerScriptObserver(self,self.rankDataFail,"CommonRankView.rankDataFail")
    local function onGetRewardDetailBack(ref)
		local rewardId = ""
		if ref then rewardId = ref:getCString() end
		if self.m_requestingRewardIdTab and #self.m_requestingRewardIdTab > 0 then
			for i = 1, #self.m_requestingRewardIdTab do
				if rewardId == self.m_requestingRewardIdTab[i] then
					table.remove(self.m_requestingRewardIdTab, i)
					break
				end
			end
			if #self.m_requestingRewardIdTab == 0 then
				GameController:call("removeWaitInterface")
				self:getRewardDataAndOpenView()
			end
		end
	end
	local handler = self:registerHandler(onGetRewardDetailBack)
	CCSafeNotificationCenter:registerScriptObserver(self, handler, "MSG_GET_REWARD_DETAIL_BACK")
	registerScriptObserver(self,self.closeSelf,"msg.CommonRankView.close")
	
end

function CommonRankView:onExit()
    self:getScheduler():unscheduleScriptEntry(self.entry)
    unregisterScriptObserver(self,"msg.CommonRankView.getLocalPlayerRank")
	unregisterScriptObserver(self,"CommonRankView.rankDataFail")
	unregisterScriptObserver(self,"msg.CommonRankView.close")
    CCSafeNotificationCenter:unregisterScriptObserver(self, "MSG_GET_REWARD_DETAIL_BACK")  
end

function CommonRankView:closeSelf()
	self:removeFromParent()
end

function CommonRankView:getPlayerRankData(params)
    local tbl = self.ctl:getRankDataByGroup(self.group)
	dump(tbl, "hxq CommonRankView:rankDataSuccess", 10)
	self.m_leftTime = 0
	if tbl.endTime then
		local leftTime = (tbl.endTime / 1000) - LuaController:call("getWorldTime")
		if leftTime > 0 then
			self.m_leftTime = leftTime
		end
	end
	self:updateUI()

	local rankMap = {}
	if tbl.rank then
		rankMap = tbl.rank
	elseif tbl.pagerank then
		rankMap = tbl.pagerank
	elseif self.m_pageIndex == 0 then
		LuaController:flyHint("", "", getLang("138130")) -- 138130=暂无记录
	end

	if rankMap and #rankMap > 0 then
		table.sort(rankMap, function(a, b)
			return tonumber(a.rank or 0) < tonumber(b.rank or 0)
		end)
	end

	-- 计算我的排名
	local myRankMap = nil
	self.myRank = 0

	local myRankIndex = 0
	if tbl.selfrank and #tbl.selfrank >0 then
		myRankMap = tbl.selfrank
		self.myRank = tonumber(myRankMap.rank)
		for i, v in ipairs(rankMap) do
			if v.uid == myRankMap.uid then
				myRankIndex = i
				break
			end
		end
	end

	if self.m_pageIndex == 0 then
		-- 初始化界面
		if not myRankMap or (1 <= myRankIndex and myRankIndex <= 3) then
			self:initTableViewByOwner(true)

		else
			self:initTableViewByOwner(false)

			local myRankNode = Drequire(actType2CellFile[self.m_type].path):create()
			self.ui.m_myRankNode:addChild(myRankNode)
			myRankMap.callback = function(x) self:onRewardButtonClick(tonumber(x)) end
			myRankMap.dataType = 0 -- 排名数据
			myRankMap.showSearch = true
			myRankMap.searchCallback = function(x) self:searchRankInfo(tonumber(x)) end
			myRankNode:refreshCell(myRankMap)

		end

		-- 前三名初始化
		local len = 3
		if #rankMap < 3 then
			len = #rankMap
		end

		for i = 1, len do
			self.ui["m_rankNode" .. i]:removeAllChildren()
		end

		for i = 1, len do
			local rankNode = Drequire(actType2RankNode[self.m_type]):create(i,rankMap[i],self)
			self.ui["m_rankNode" .. i]:addChild(rankNode)
		end

		for i = 1, len do
			table.remove(rankMap, 1)
		end
	else
		table.remove(rankMap, myRankIndex)
	end

	self.m_rankMap = self.m_rankMap or {}
	local flag = 1
	if #self.m_rankMap >= 1 then
		table.remove(self.m_rankMap, #self.m_rankMap)
		flag = 0
	end

	if #rankMap > 0 then
		-- 为 cell 添加查看奖品的回调
		for i = 1, #rankMap do
			rankMap[i].callback = function(x) self:onRewardButtonClick(tonumber(x)) end
			rankMap[i].dataType = 0 -- 排名数据
			self.m_rankMap[#self.m_rankMap + 1] = rankMap[i]
		end
	end

	self.totalPageNum = tonumber(tbl.pagenum or self.totalPageNum)
	if self.m_pageIndex + 1 < self.totalPageNum then
		self.m_rankMap[#self.m_rankMap + 1] = {dataType = 1, getMoreRank = function()
			self:reqData()
		end} -- 获取更多
	else
		self.m_rankMap[#self.m_rankMap + 1] = {dataType = 2} -- 没有更多数据
		if self.m_isSearching then
			self.m_searchingRank = self.m_curMaxRank
		end
	end

	local offset = self.ui.m_listTableView:getContentOffset()
	self.ui:setTableViewDataSource("m_listTableView", self.m_rankMap)
	offset.y = offset.y - cellHeight * (#rankMap + flag)
	self.ui.m_listTableView:setContentOffset(offset)

	-- 增加页数
	self.m_pageIndex = self.m_pageIndex + 1

	self.m_curMaxRank = #self.m_rankMap + 3 - 1
	if self.m_isSearching then
		if self.m_searchingRank <= self.m_curMaxRank then
			GameController:call("getInstance"):call("removeWaitInterface")
			self.m_isSearching = false
			self:jumpToSearchingRank(self.m_searchingRank)
		else
			self:reqData()
		end
	else
		GameController:call("getInstance"):call("removeWaitInterface")
	end
end

function CommonRankView:rankDataFail(params)
    if self.m_isSearching then
		self.m_isSearching = false
		self:jumpToSearchingRank(self.m_curMaxRank)
	end
end

function CommonRankView:initTableViewByOwner(flag)
	local listSize = self.ui.m_listNode:getContentSize()
	if flag then
		listSize.height = listSize.height + cellHeight
	end
	self.ui.m_listTableView:setContentSize(listSize)
	Drequire("Editor.TableViewSmoker"):createView(self.ui, "m_listTableView", actType2CellFile[self.m_type].path, 1, 10, actType2CellFile[self.m_type].fileName)
end

function CommonRankView:onEnterFrame(dt)
	if self.m_leftTime > 0 then
		self.m_leftTime = self.m_leftTime - dt
		self:updateUI()
	end
end

function CommonRankView:updateUI()
	if self.m_leftTime > 0 then
		self.ui.m_timeLabel:setString(getLang("182043", CC_SECTOA(self.m_leftTime)))	--182043={0}后发放奖励
	else
		self.ui.m_timeLabel:setString("")
	end
end
function CommonRankView:onTouchBegan( x,y )
    if self:isVisible(true) and isTouchInside(self.ui.m_touchLayer,x,y) then
        return true
    end
end

function CommonRankView:onTouchMoved(x,y)
end

function CommonRankView:onTouchEnded( x,y )
    -- body
end

function CommonRankView:onRewardButtonClick(idx)
	self.m_idx = idx
	local xmlInfo = string.split(actType2XML[self.m_type],"|") or {}
	if xmlInfo[1] ~= "" and xmlInfo[2] == "-1" then -- 特殊奖励
		if xmlInfo[1] == "ladder_rank" then
			self:getLadderRankRewardData(xmlInfo[1])
		end
	else
		self:getRewardDataWithCheck()
	end
end

-- 解析奖励
function CommonRankView:parseRewardId()
	if not self.m_rewardIdTab then
		self.m_rewardIdTab = {}
		local equipRewardId = ""		
		local xmlName
		local xmlInfo = string.split(actType2XML[self.m_type],"|") or {}		
		if xmlInfo[1] ~= "" then
			xmlName = xmlInfo[1]
			local rwdIds = string.split(xmlInfo[2],";") or {}
			if self.m_viewType == 1 then
				equipRewardId = rwdIds[1] or "20902000" --"20902000"个人本服排名奖励
			else
				equipRewardId = rwdIds[2] or "20902001" --"20902001"--个人全服排名奖励
			end
			-- 招募之神周期不同奖励不同（后续有其他周期性排行也可用）
			equipRewardId = self.ctl:getPhaseRewardId(self.m_type, self.m_viewType, equipRewardId)
		else
			xmlName = "consume_soldier_rank"
		end

		local reward = CCCommonUtilsForLua:call("getPropByIdGroup", xmlName, equipRewardId, "reward")
		local rwdTab = string.split(reward, "|")
		for i = 1, #rwdTab do
			local rwdItem = string.split(rwdTab[i], ";")
			if #rwdItem >= 2 then
				local rwdIdx = string.split(rwdItem[1], "-")
				if #rwdIdx >= 2 then
					self.m_rewardIdTab[i] = {left = tonumber(rwdIdx[1]), right = tonumber(rwdIdx[2]), rewardId = rwdItem[2]}
				elseif #rwdIdx >= 1 then
					self.m_rewardIdTab[i] = {left = tonumber(rwdIdx[1]), right = tonumber(rwdIdx[1]), rewardId = rwdItem[2]}
				end
			end
		end
	end
end

-- 检查奖励数据
function CommonRankView:checkRewardData()
	self:parseRewardId()

	self.m_requestingRewardIdTab = {}
	for i = 1, #self.m_rewardIdTab do
		local rwd = GlobalData:call("getCachedRewardData", self.m_rewardIdTab[i].rewardId)
		local rwdData = arrayToLuaTable(rwd)
		if #rwdData == 0 then
			self.m_requestingRewardIdTab[#self.m_requestingRewardIdTab + 1] = self.m_rewardIdTab[i].rewardId
		end
	end
end

-- 获取奖励数据（没有时向服务器请求）
function CommonRankView:getRewardDataWithCheck()
	self:checkRewardData()

	if #self.m_requestingRewardIdTab == 0 then
		self:getRewardDataAndOpenView()
	else
		GameController:call("getInstance"):call("showWaitInterface")
		for i = 1, #self.m_requestingRewardIdTab do
			GlobalData:call("requestRewardData", self.m_requestingRewardIdTab[i])
		end
	end
end

-- 获取奖励数据并打开奖励界面
function CommonRankView:getRewardDataAndOpenView()
	local myRank = self.myRank or 0
	local idx = self.m_idx or 1
	local found = false
	local index = 0
	local rewardTab = {}
	if myRank > 0 then
		for i = 1, #(self.m_rewardIdTab or {}) do
			local left = self.m_rewardIdTab[i].left
			local right = self.m_rewardIdTab[i].right
			if left <= myRank and myRank <= right then
				if idx == myRank then
					found = true
					index = #rewardTab
				end

				local titleStr = getLang("221120") .. " (" .. getLang("170008") .. ": " .. myRank .. ")"
				rewardTab[#rewardTab + 1] = {type = 1000, label = titleStr}
				local rwd = GlobalData:call("getCachedRewardData", self.m_rewardIdTab[i].rewardId)
				local rwdData = arrayToLuaTable(rwd)
				for _, v in pairs(rwdData) do
					rewardTab[#rewardTab + 1] = v
				end
				break
			end
		end
	end
	for i = 1, #(self.m_rewardIdTab or {}) do
		local left = self.m_rewardIdTab[i].left
		local right = self.m_rewardIdTab[i].right
		if not found then
			if left <= idx and idx <= right then
				found = true
				index = #rewardTab
			end
		end

		local titleStr = ""
		if left ~= right then
			titleStr = getLang("221119", tostring(left), tostring(right))
		else
			titleStr = getLang("221121", tostring(left))
		end
		rewardTab[#rewardTab + 1] = {type = 1000, label = titleStr}
		local rwd = GlobalData:call("getCachedRewardData", self.m_rewardIdTab[i].rewardId)
		local rwdData = arrayToLuaTable(rwd)
		for _, v in pairs(rwdData) do
			rewardTab[#rewardTab + 1] = v
		end
	end
	local titleName
	local titleInfo = string.split(actId2Title[self.m_type],";")	
	local dialogId
	if self.m_viewType == 1 then		
		dialogId = titleInfo[1] or "140460"
		titleName = getLang(dialogId) 		--140460=本服
	else
		dialogId = titleInfo[2] or "140459"
		titleName = getLang(dialogId) 		--140459=全服
	end
	local tipsDes = getLang(rewardTips[self.m_type])
	self:showRewardView(rewardTab, index, titleName, tipsDes)
end

function CommonRankView:showRewardView(rewardTab, index, titleName, tipsDes)
	local view = Drequire("game.equipment.EquipRank.EquipmentRewardView"):create(rewardTab, index, titleName, tipsDes)
	PopupViewController:call("addPopupView", view)
end

function CommonRankView:onSearchButtonClick(pSender, event)
	function callback(index)
		self:searchRankInfo(tonumber(index))
	end
	local view = Drequire("game.CommonPopup.CommonInputView"):create(getLang("221129"), callback)
	PopupViewController:call("addPopupView", view)
end

function CommonRankView:searchRankInfo(idx)
	local maxRank = 5000
    local _data = self.ctl:getRankDataByGroup(self.group)
	
	if _data then
		if self.m_viewType == 1 then
			maxRank = tonumber(_data.maxLocalRank) or 5000
		else
			maxRank = tonumber(_data.maxGlobalRank) or 5000
		end
	end
	if idx <= 3 then
		idx = 3 + 1
	elseif idx > maxRank then
		idx = maxRank
	end
	if idx <= self.m_curMaxRank then
		self:jumpToSearchingRank(idx)
	else
		self.m_isSearching = true
		self.m_searchingRank = idx
		self:reqData()
	end
end

function CommonRankView:jumpToSearchingRank(idx)
	local minOffsetY = self.ui.m_listNode:getContentSize().height - self.ui.m_listTableView:getContentSize().height
	local maxOffsetY = self.ui.m_listNode:getContentSize().height
	local offsetY = minOffsetY + (idx - 3 - 1) * cellHeight
	if offsetY < minOffsetY then
		offsetY = minOffsetY
	elseif offsetY > maxOffsetY then
		offsetY = maxOffsetY
	end
	self.ui.m_listTableView:setContentOffset(cc.p(0, offsetY))
end

-- 招募之神的历届排名begin
function CommonRankView:setPhaseButtonVisible(isVisible)
	self.ui.m_phaseNode:setVisible(isVisible)
end

function CommonRankView:onPhaseButtonClick()
	local view = Drequire("game.rank.PlayerRankListView"):create(13)
	PopupViewController:addPopupInView(view)
end
-- 招募之神的历届排名end

function CommonRankView:getLadderRankRewardData(xmlGroup)

	local xmlData = CCCommonUtilsForLua:getGroupByKey(xmlGroup)
	local myRank = self.myRank or 0
	local idx = self.m_idx or 1
	local rewardTab = {}
	local rankData = {}
	local rankBegin = 1
	local rankEnd = idx + 5
	if idx - 5 > 0 then
		rankBegin = idx - 5
	end

	for i = rankBegin, rankEnd do
		for k,v in pairs(xmlData) do
			if tonumber(v.ranking) then
				if tonumber(v.ranking) == i then
					local data = {
						ranking = i,
						type = v.type,
						value = v.value,
					}
					rankData[#rankData + 1] = data
				end
			else
				local rankItem = string.split(v.ranking, ";")
				local left = tonumber(rankItem[1])
				local right = tonumber(rankItem[2])
				if i >= left and i <= right then
					local data = {
						ranking = i,
						type = v.type,
						value = v.value,
					}
					rankData[#rankData + 1] = data
				end
			end
		end
	end
	
	local index = 0
	local rewardTab = {}	
	if myRank > 0 then
		for i = 1, #(rankData or {}) do
			local ranking = rankData[i].ranking
			if myRank == ranking then
				-- index = #rewardTab
				local titleStr = getLang("221120") .. " (" .. getLang("170008") .. ": " .. myRank .. ")"
				rewardTab[#rewardTab + 1] = {type = 1000, label = titleStr}
				local rewardData = {type = -1000, value = {}}
				rewardData["value"]["num"] = TournamentControllerInst:applyRankingMethod(rankData[i])
				-- if rankData[i].type == "1" then -- 公式计算
				-- 	-- 公式：1/（名次)^0.3 *10000+500
				-- 	rewardData["value"]["num"] = math.floor(10000 / math.pow(tonumber(rankData[i].ranking), 0.3) + 500)
				-- else
				-- 	rewardData["value"]["num"] = tonumber(rankData[i].value)
				-- end
				rewardTab[#rewardTab + 1] = rewardData
				break
			end
		end
	end
	for i = 1, #(rankData or {}) do
		local ranking = rankData[i].ranking
		if ranking == idx then
			index = #rewardTab
		end
		
		local titleStr = getLang("221121", tostring(ranking))
		rewardTab[#rewardTab + 1] = {type = 1000, label = titleStr}
		local rewardData = {type = -1000, value = {}}
		rewardData["value"]["num"] = TournamentControllerInst:applyRankingMethod(rankData[i])
		-- if rankData[i].type == "1" then -- 公式计算
		-- 	-- 公式：1/（名次)^0.3 *10000+500
		-- 	rewardData["value"]["num"] = math.floor(10000 / math.pow(tonumber(rankData[i].ranking), 0.3) + 500)
		-- else
		-- 	rewardData["value"]["num"] = tonumber(rankData[i].value)
		-- end
		rewardTab[#rewardTab + 1] = rewardData
	end
	local titleName = getLang("350245")
	local tipsDes = getLang(rewardTips[self.m_type])
	self:showRewardView(rewardTab,index,titleName,tipsDes)
end

function CommonRankView:onRewardButton1Click()
	self:onRewardButtonClick(1)
end
function CommonRankView:onRewardButton2Click()
	self:onRewardButtonClick(2)
end
function CommonRankView:onRewardButton3Click()
	self:onRewardButtonClick(3)
end

return CommonRankView