-------------
--主界面添加按钮须知：
--初始化：在UiCompoentLuaLayer:onEnter依次添加初始化方法
--坐标：根据左上角位置或者左下角位置，在self:updateRightUpPos()或者self:updateDownLeftPos()中，累加offsetY
--如果需要判断isfunopenbykey的情况，要在self:initData()初始化
-------------
local KING_COMPENSATE_BATTLE = "push.battle.compensate"
local KING_COMPENSATE_CLAIM = "compensate.claim"

local DailyActivityManager = require("game.dailyActivity.DailyActivityManager")
require("game.fortress.FortressController")

local UiCompoentLuaLayer = class("UiCompoentLuaLayer", function()
        return CCLayer:create()
    end
)   --创建一个UiCompoentLuaLayer类

local IconWidth = 90
local IconHeight = 80
local IconOffset = 15

UiCompoentLuaLayer.dctrl = nil

-- needReload 当其为true用于新加函数的动态加载使用
local needReload = false  --false是否重新加载
-- 通用icon添加函数，无需注册onEnter和onExit
-- iconType 1 右上，2左下向上排列, 3左下向右排列, 4,其余位置, 5 （野外）左下向上排列
-- iconName 对应的lua文件必须继承node，使用create函数创建，使用touchEvent接收点击事件， 若每秒更新，则实现update函数，
-- 当场景切换需要显隐控制时需要实现onSceneChanged函数

local iconListFileTbl = {
    {iconName = "game.UIComponent.GoldActivityBoxIcon", iconType = 1},
    --【Awen】已与贾琳&张旭沟通，将日常玩法去掉 
    -- {iconName = "game.UIComponent.TimePackageNodeIcon", iconType = 2, guide = "LUA_UI_dailyactivity"}, -- 日常玩法
    {iconName = "game.UIComponent.CrossServerActivityIcon", iconType = 2}, -- 跨服活动
    {iconName = "game.UIComponent.SubscribeNodeIcon", iconType = 2}, -- 订阅
    {iconName = "game.UIComponent.LuckyReturnNodeIcon", iconType = 2}, -- 幸运回归
    {iconName = "game.UIComponent.ReturnOfTheKingIcon", iconType = 2},--王者归来
	{iconName = "game.UIComponent.ActivityPageListIcon", iconType = 1},
	{iconName = "game.UIComponent.WelfareIntegrateIcon", iconType = 1, guide = "LUA_UI_WelfareIntegrateIcon"},
    {iconName = "game.UIComponent.LuckyDayNodeIcon", iconType = 3},
	{iconName = "game.UIComponent.TalentPointTip", iconType = 4}, 
    {iconName = "game.UIComponent.DragonBattleRecordIcon", iconType = 1},
    {iconName = "game.UIComponent.DragonBattleDataIcon", iconType = 1},
    {iconName = "game.UIComponent.FeedBackNodeIcon", iconType = 2},
    {iconName = "game.UIComponent.FourthAnniversaryIcon", iconType = 1}, -- 四周年活动入口
    {iconName = "game.UIComponent.MidAutumnFestivalIcon", iconType = 1}, -- 中秋节活动入口
    {iconName = "game.FestivalActivities.FestivalActivitiesIcon", iconType = 1}, -- 节日活动入口
    {iconName = "game.UIComponent.AllianceBossIcon", iconType = 5}, -- 联盟boss
    {iconName = "game.UIComponent.ChangeServerNodeIcon", iconType = 2}, -- 付费转服
    {iconName = "game.UIComponent.CalendarNodeIcon", iconType = 1}, --活动日历
    {iconName = "game.activity.RunningRingAct.RunningRingActIcon", iconType = 3}, -- 跑环任务图标
    {iconName = "game.UIComponent.NewMergeActivityNodeIcon", iconType = 3}, -- 新合服活动
    {iconName = "game.UIComponent.FestivalActivitiesBattlePassNodeIcon", iconType = 1}, --新 battlepass
    {iconName = "game.activity.ActivityPage.CrossServerPayInfoListIcon", iconType = 1}, --跨服充值列表
    {iconName = "game.CommonPopup.AuctionHouse.AuctionHouseNodeIcon", iconType = 3}, -- 拍卖失败提示图标
    {iconName = "game.UIComponent.GodzillaNodeIcon", iconType = 1}, --哥斯拉战友招募入口
    {iconName = "game.dragonWarmUpBattle.DragonWarmUpIcon.lua",iconType = 1},--巨龙演武场任务宝箱
    {iconName = "game.UIComponent.DragonBattleObMvpIcon",iconType = 1},--巨龙战场OB mvp界面icon
    {iconName = "game.UIComponent.WorldBossComingIcon", iconType = 5}, -- 世界boss来袭

    --[[不要删除这块注释,以开关控制功能icon]]
    -- {iconName = "game.UIComponent.ThemeMonthIcon", iconType = 4} --主题月图标
    --[[end 不要删除这块注释,以开关控制功能icon]]

}

function UiCompoentLuaLayer:create(dict) 
	local view = UiCompoentLuaLayer.new()
	if view:initView(dict) == false then
		return nil
	end

  	return view
end

function UiCompoentLuaLayer:initView(dict)
	local  proxy = cc.CCBProxy:create()

	local function onNodeEvent(event)
		if event == "enter" then
			self:onEnter()
		elseif event == "exit" then
			self:onExit()
		end
	end
  	self:registerScriptHandler(onNodeEvent)

  	function onTouch(eventType, x, y)  
        if eventType == "began" then  
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)  
        else  
            return self:onTouchEnded(x, y)  
        end
    end
    self:registerScriptTouchHandler(onTouch)

    self:setTouchEnabled(true)
    self:setSwallowsTouches(true)
    self.initTime = 0
    local parentNode = dict:objectForKey("node")
    local size = parentNode:getContentSize()
    self:setContentSize(size)
    -- local layer = cc.LayerColor:create(cc.c4b(127, 127, 127, 127), size.width, size.height)
    -- self:addChild(layer)
    self.m_UIQuestNode = dict:objectForKey("m_UIQuestNode")
    self.contentSize = size

    -- 世界左下的按钮的占位Node，用于左下幸运日在进入世界界面后，与搜索等按钮重叠的问题
    self.m_worldFaveNode = cc.Node:create()
    self:addChild(self.m_worldFaveNode)
    self.m_worldFaveNode:setContentSize(cc.size(IconWidth, IconHeight))
    self.m_worldFaveNode:setVisible(false)
    self.m_worldFaveNode:setPosition(cc.p(IconWidth*0.5, IconHeight*0.5))
    self.m_worldFaveNode:setAnchorPoint(cc.p(0.5, 0.5))

    -- activityPanel
    -- self:resetActivityPanelNode()

	-- 这里的章节要在2级显示，但是原有都是4级才开启的，所以这里新增一个同坐标系的node，特殊处理下
    -- 初始化章节node
    local m_chapterBaseNode = dict:objectForKey("m_chapterBaseNode")
    self.m_chapterBaseNode = tolua.cast(m_chapterBaseNode, "cc.Node")

    -- 幸运日时间显示

    self.hasEnter = false

    -- 章节任务ICON显示标记
    self.isChapterShow = true

    --世界杯只显示战斗记录按钮
    self.showAllBtn = true
    self.onlyShowDBRecord = false
   
    --全球赛隐藏
    if (require("game.dragonWorldCup.DragonWorldCupManager").isDragonGlobalServer()) or GlobalData:call("shared"):getProperty("obing") then
    	self.onlyShowDBRecord = true
        self.showAllBtn = false
    end

    --防沉迷数据。
    self.dctrl = DataController
    self.iconListDataTbl = {}

    --是否在国王援助后创建过行军队列、瞭望塔数据以及闪屏
    self.m_isKingCompensateSetting = false

    self.m_isLocked = false
	-- local function laFunc( dictTable, dict )
 --    	MyPrint("IS LOCKING!!!!!  111 dictTable.locked", dictTable.locked)
	-- 	if tonumber(dictTable.locked) == 1 then
	-- 		MyPrint("IS LOCKING!!!!!   222")
	-- 		self.m_isLocked = true
	-- 		local view = Drequire("game.UsernameLock.UserLockedView"):create()
	-- 		PopupViewController:call("removeAllPopupView")
	-- 		PopupViewController:addPopupView(view)
	-- 	end
	-- end

 --    local dict = CCDictionary:create()
	-- local cmd = Drequire("game.command.UsernameLockCmd").create("accountLock.getUnlockView", dict, laFunc)
	-- cmd:sendAndRelease()
    if GlobalData:call("getPlayerInfo"):getProperty("officer") == "216000" then -- 国王上线提示
        local cmd = Drequire("game.command.KingNotifyCmd").create()
        cmd:send()

        --国王登陆提示 自己看到
        require("game.flyHint.FlyHintManager").getManager():addKingLoginTip()
    end
    self.reqData_lock = false

    if require("game.dragonBattle.DragonBattleOBController").getInstance():isNewOBOpen() then
        local newOBNode = UIComponent:call("getInstance"):getProperty("m_newOBNode")
        local mainUIComponent = newOBNode:getParent()
        self.upNode = Drequire("game.dragonBattle.DragonBattleOBUpNode"):create()
        newOBNode:addChild(self.upNode)

        self.downNode = Drequire("game.dragonBattle.DragonBattleOBDownNode"):create()
        newOBNode:addChild(self.downNode)
    end

    return true
end

function UiCompoentLuaLayer:ShowUserLockedView()
    if self.m_isLocked == false then
        local function laFunc( dictTable, dict )
            MyPrint("IS LOCKING!!!!!  111 dictTable.locked", dictTable.locked)
            if tonumber(dictTable.locked) == 1 then
                MyPrint("IS LOCKING!!!!!   222")
                self.m_isLocked = true
                local view = Drequire("game.UsernameLock.UserLockedView"):create()
                view:setRemainTime(dictTable.expireTime)
                PopupViewController:call("removeAllPopupView")
                PopupViewController:addPopupView(view)
            end
        end

        self.m_isLocked = true
        local dict = CCDictionary:create()
        local cmd = Drequire("game.command.UsernameLockCmd").create("accountLock.getUnlockView", dict, laFunc)
        cmd:sendAndRelease()
        MyPrint("IS LOCKING!!!!!   fubin")
    end
end

function UiCompoentLuaLayer:addTestColor(node, color)
	-- if not color then
	-- 	color = 127
	-- end
 --    local layer = cc.LayerColor:create(cc.c4b(color, color, color, 127), IconWidth, IconHeight)
 --    node:addChild(layer, -1)
end
function UiCompoentLuaLayer:initData()
    if self.showAllBtn then
    	-- self:resetKingReturnNode()  --王者归来入口

        self:reset_kingdomJiJie_Node()
    end
end

function UiCompoentLuaLayer:firstPopupBlog()
    local lua_path = "game.blog.BlogView"
    package.loaded[lua_path] = nil
    require(lua_path)
    PopupViewController:addPopupInView(BlogView:create(true))
end

function UiCompoentLuaLayer:refreshChapgerNode(visiable_force)
    local _isUiOpen = FunBuildController:call("getInstance"):call("IsHaveRecordeByKey", "ui_chapter")
    MyPrint("UiCompoentLuaLayer refreshChapterNode", visiable_force, _isUiOpen)
	if self.m_chapterNode ~= nil and _isUiOpen then
		local open = ChapterController:getInstance():isChapterOpen()
        MyPrint("UiCompoentLuaLayer refreshChapterNode open", open)
        if self.sceneId == SCENE_ID_MAIN and open and self.isChapterShow then
            self.m_chapterNode:setVisible(true)
            self.m_chapterTaskNode:setVisible(true)
            --老账号不开启章节任务
            if visiable_force ~= nil  then
                self.m_chapterNode:setVisible(visiable_force)
                self.m_chapterTaskNode:setVisible(visiable_force)
            end
		else
			self.m_chapterNode:setVisible(false)
			self.m_chapterTaskNode:setVisible(false)
		end
	end
end

--弃用，测试以后再删
function UiCompoentLuaLayer:refreshKingReturn ()  --刷新王者归来
	if self.m_kingReturnNode then

		--[[ 旧的逻辑是UI上的王者归来ICON提供的是激活码界面，而且是来新服2个小时内显示，激活后 本地的king_return_old_uid 和 king_return_token都清空
        现在我们依然清空，因为服务器上需要记录下状态
        显示：增加新的或条件-->活动中心里有该活动 && 取消俩小时限制
        此时点击icon会做出判断：俩小时内未激活，跳到激活界面/  否则还显示则说明活动中心有该活动，点击后跳转到王者归来界面
        local ctl = ToNewServerController.getInstance()
		local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
		local now = getTimeStamp()
		local registerTime = playerInfo:getProperty("registerTime")
		if now - registerTime > 7200 or 0 ~= ctl.status then -- 注册两小时内激活
			self.m_kingReturnNode:setVisible(false)
			return
		end
        local oldUid = cc.UserDefault:getInstance():getStringForKey('king_return_old_uid', '')
        if self.sceneId == SCENE_ID_MAIN and CCCommonUtilsForLua:isFunOpenByKey("k_return") and '' ~= oldUid then
         self.m_kingReturnNode:setVisible(true)
        else
         self.m_kingReturnNode:setVisible(false)
        end
        --]]
        local isActOpen = false
        if ActivityController.getInstance():isActivityOpen("57242") then            
            local isSpeAct, endTime = DailyActivityManager.getSpecialActivityEndtime('57242')
            if endTime > 0 then
                isActOpen = true
            end
        end
        local oldUid = cc.UserDefault:getInstance():getStringForKey('king_return_old_uid', '')
        if '' == oldUid and not isActOpen then
            self.m_kingReturnNode:setVisible(false)
            return
        end

	end
end

function UiCompoentLuaLayer:onEnter()
	dump(" UiCompoentLuaLayer:onEnter() ~~~~~~~~~~~~~~")
    self.hasEnter = true
    if self.showAllBtn then
    	self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:update(dt) end, 1, false)

    	-- 礼包变动通知
    	local function goldActivitBox( ref )

    		self:resetActivityPanelNode()		

        end
        local t = tolua.cast(self, "cc.Node")
        local handler = t:registerHandler(goldActivitBox)
    	CCSafeNotificationCenter:registerScriptObserver(self, handler, GOLDEXCHANGE_LIST_CHANGE)
    	
    	goldActivitBox(nil)

    	local MSG_ACTIVITY_INIT = "msg.activity.init"
    	local function setActivityPanel(ref)
    		self:resetActivityPanelNode()
        end
        local t = tolua.cast(self, "cc.Node")
        local handler = t:registerHandler(setActivityPanel)
    	CCSafeNotificationCenter:registerScriptObserver(self, handler, MSG_ACTIVITY_INIT)
    	registerScriptObserver(self, self.resetActivityPanelNode, MSG_REPAY_INFO_INIT)

    	self:resetActivityPanelNode()

        local function onFirstPopupBlog(ref)
            self:firstPopupBlog()
        end
        local handler = self:registerHandler(onFirstPopupBlog)
        CCSafeNotificationCenter:registerScriptObserver(self, handler, "blogView_firstPopup")

        local function onChapterInfo(ref)
            self:refreshChapterInfo()
        end
        local handler = self:registerHandler(onChapterInfo)
        CCSafeNotificationCenter:registerScriptObserver(self, handler, "chapterInfo_refresh")

        dump("registerHandler  ~~~~~~~~ ")
    	local function onPayFinished( ref )
    		local itemId = ref:getCString()
    		local itemData = LiBaoController.getInstance():getGoldExchangeItemById(itemId)
    		local itemShowType = "0"
    		if itemData and itemData.type == "3" and itemData.show_type ~= "" then
    			itemShowType = itemData.show_type
    		end
    		dump(itemShowType, "onPayFinished itemShowType ")
    		LiBaoController.getInstance():getExchangeDataRefersh(itemShowType)
        end
        local t = tolua.cast(self, "cc.Node")
        local handler = t:registerHandler(onPayFinished)
        CCSafeNotificationCenter:registerScriptObserver(self, handler, PAYMENT_COMMAND_RETURN)

        -- 国王的援军
        self:createKingCompensate()

        registerScriptObserver(self, self.resetKingCompensate, KING_COMPENSATE_BATTLE)
        registerScriptObserver(self, self.resetKingCompensateSetting, KING_COMPENSATE_CLAIM)

        -- 合服入口
        self:createMergeServer()

        --章节按钮
    	self:createChapterNode()

    	self:update()

    	self:resetTimeLimitBuffNode()

    	self:resetNewKingdomWarNode()

    	registerScriptObserver(self, self.towardAfterGiftReward, "toward_after_giftReward")

    	registerScriptObserver(self, self.civLevelUp, "Civilization_group_level_up")
        registerScriptObserver(self, self.showActivityPageView, "MSG_show_activity_page_view")
        registerScriptObserver(self, self.onKillMonsterBuff, "MSG_kill_monster_buff")
        registerScriptObserver(self, self.animChapter, "UiCompoentLuaLayer:animChapter")
        registerScriptObserver(self, self.animHideChapter, "UiCompoentLuaLayer:animHideChapter")
        registerScriptObserver(self, self.showPortalTips, "msg.UiCompoentLuaLayer.addDoorUINode")
        registerScriptObserver(self, self.triggerSceneChange, GUIDE_INDEX_CHANGE)
        
        local function onFlyGold(dict)
            local gold = dict:valueForKey("gold"):getCString()
            if gold ~= "" then
                GlobalData:call("shared"):getProperty("playerInfo"):setProperty("gold", tonumber(gold))
                CCSafeNotificationCenter:postNotification("city_resources_update")
                self:showGoldFly()
            end
        end
        local handler2 = self:registerHandler(onFlyGold)
        CCSafeNotificationCenter:registerScriptObserver(self, handler2, "MSG_show_gold_fly")

    	self.entry = tonumber(self:getScheduler():scheduleScriptFunc(function (  ) self:onEnterFrame() end, 1.0, false))
    end
    registerScriptObserver(self, self.onMSGScreenShot, "MSG_ScreenShot")

    UiCompoentControoller.tryAddThemeMonthIcon(iconListFileTbl)
    self:reLoadIconTbl()
    
    if not self.reqData_lock then
        self:AFLoginGMReqData()
    end

    dump(XEvtTimer, "UiCompoentLuaLayer:onEnter")
    XEvtTimer:on("msgSceneChangeFinish", function()
        self:onCheckShowWorldBossComingAni()
    end)
end

function UiCompoentLuaLayer:onExit()
	dump(" UiCompoentLuaLayer:onExit() ~~~~~~~~~~~~~~")

    self.hasEnter = false;
    if self.showAllBtn then
    	self.m_timePackageInit = false
    	self:getScheduler():unscheduleScriptEntry(self.m_entryId)

    	CCSafeNotificationCenter:unregisterScriptObserver(self, GOLDEXCHANGE_LIST_CHANGE)
        CCSafeNotificationCenter:unregisterScriptObserver(self, PAYMENT_COMMAND_RETURN)
    	CCSafeNotificationCenter:unregisterScriptObserver(self, MSG_ACTIVITY_INIT)
    	unregisterScriptObserver(self, KING_COMPENSATE_BATTLE)
    	unregisterScriptObserver(self, MSG_REPAY_INFO_INIT)
    	unregisterScriptObserver(self, "Civilization_group_level_up")
        unregisterScriptObserver(self, "blogView_firstPopup")
        unregisterScriptObserver(self, "chapterInfo_refresh")
        unregisterScriptObserver(self, "MSG_show_activity_page_view")
        CCSafeNotificationCenter:unregisterScriptObserver(self, "MSG_show_gold_fly")
        unregisterScriptObserver(self, KING_COMPENSATE_CLAIM)
        unregisterScriptObserver(self, "MSG_kill_monster_buff")
        unregisterScriptObserver(self, GUIDE_INDEX_CHANGE)
    	self:getScheduler():unscheduleScriptEntry(self.entry)
    end
    unregisterScriptObserver(self, "MSG_ScreenShot")
    unregisterScriptObserver(self, "UiCompoentLuaLayer:animChapter")
    unregisterScriptObserver(self, "UiCompoentLuaLayer:animHideChapter")
    unregisterScriptObserver(self, "msg.UiCompoentLuaLayer.addDoorUINode")

    UiCompoentControoller.exit()

    XEvtTimer:off("msgSceneChangeFinish")
end

function UiCompoentLuaLayer:triggerSceneChange(ref)
    local ref = tolua.cast(ref, "CCString")
    if ref then 
        local postStr = ref:getCString()
        if postStr == "UI_world_back" then
            self.triggerMark = true
            self.triggerMarkTime = 0
            
        end
    end
end

--触发器时间阀值
local TriggerThreshold = 3.0
function UiCompoentLuaLayer:updateTrigger(dt)
    if self.triggerMark then
        self.triggerMarkTime = self.triggerMarkTime + dt
        if self.triggerMarkTime > TriggerThreshold then
            TriggerEventUtils.startSceneChange()
            self.triggerMark = false
        end
    end
end

function UiCompoentLuaLayer:doAddShareLayer()
    dump(self.screenShotParams,"UiCompoentLuaLayerdoAddShareLayer:+++")
    local params = self.screenShotParams
    local sLayer = Drequire("game.CommonPopup.ShareLayer"):create(params)
    local uiLayer = SceneController:call("getCurrentLayerByLevel", LEVEL_MAX-1)
    MyPrint("sLayer,uiLayer:",sLayer,uiLayer)
    if sLayer and uiLayer then 
        dump("add sLayer2+++")
        sLayer:setZOrder(99999999)
        uiLayer:addChild(sLayer)
    end
end

function UiCompoentLuaLayer:onMSGScreenShot(ref)
    dump(ref, "UiCompoentLuaLayer:onMSGScreenShot+++")
    if not CCCommonUtilsForLua:isFunOpenByKey("share_image") or isCrossServerNow() then
        return
    end
    if ref then 
        local params = dictToLuaTable(ref) 
        dump(params,"params+++")
        params.imgFilePath = params.imageLocalPath
        self.screenShotParams = params
        self:doAddShareLayer()
    end
end

function UiCompoentLuaLayer:onKillMonsterBuff(ref)
    dump(ref, "UiCompoentLuaLayer:onKillMonsterBuff+++")
    if not CCCommonUtilsForLua:isFunOpenByKey("samuraikill_monster") or isCrossServerNow() then
        return
    end
    if ref then
        local params = dictToLuaTable(ref) 
        dump(params,"UiCompoentLuaLayer:onKillMonsterBuff params+++")
        self.m_killMonsterBuff = tonumber(params.buffEffect)
        self.m_killMonsterStartTime = tonumber(params.buffStartTime)/1000
        self.m_killMonsterEndTime = tonumber(params.buffEndTime)/1000
    end
    if self.m_killMonsterBuff and self.m_killMonsterStartTime and self.m_killMonsterEndTime then
        if DynamicResourceController2:call("checkDynamicResource", "SamuraiShodown_face") == false then return end
        if self.m_killMonsterBuffNode then self.m_killMonsterBuffNode:removeFromParent() end
        self.m_killMonsterBuffNode = cc.Node:create()
        local path = "Font_Samurai_" .. self.m_killMonsterBuff .. ".png"
        local spr = CCLoadSprite:createSprite(path)
        local sprGray = CCLoadSprite:createSprite(path)
        CCCommonUtilsForLua:call("setSpriteGray", sprGray, true)
        self.m_killMonsterBuffNode:setContentSize(spr:getContentSize())
        self.m_killMonsterClipNode = CCClipNode:call("create", self.m_killMonsterBuffNode:getContentSize().width, self.m_killMonsterBuffNode:getContentSize().height)
        self.m_killMonsterClipNode = tolua.cast(self.m_killMonsterClipNode, "cc.Node")
        self.m_killMonsterClipNode:setAnchorPoint(cc.p(0, 0.5))
        sprGray:setAnchorPoint(cc.p(0, 0.5))
        spr:setAnchorPoint(cc.p(0, 0))
        self.m_killMonsterTouchNode = cc.Node:create()
        self.m_killMonsterTouchNode:setAnchorPoint(cc.p(0, 0.5))
        self.m_killMonsterTouchNode:setContentSize(spr:getContentSize())
        self.m_killMonsterBuffNode:addChild(sprGray)
        self.m_killMonsterBuffNode:addChild(self.m_killMonsterClipNode)
        self.m_killMonsterBuffNode:addChild(self.m_killMonsterTouchNode)
        self.m_killMonsterClipNode:addChild(spr)
        self:addChild(self.m_killMonsterBuffNode)
        if CCCommonUtilsForLua:call("isIosAndroidPad") then
            self.m_killMonsterBuffNode:setPosition(self.contentSize.width -680, self.contentSize.height)
        else
            self.m_killMonsterBuffNode:setPosition(self.contentSize.width -550, self.contentSize.height)
        end
    end
end

function UiCompoentLuaLayer:reLoadIconTbl()
	-- dump(self.iconListDataTbl, "UiCompoentLuaLayer:reLoadIconTbl is: ")
	for i, icon in pairs(self.iconListDataTbl or {}) do
		icon:removeFromParent()
	end
	self.iconListDataTbl = {}
	local iconSize = cc.size(IconWidth, IconHeight)
	local contentSize = self.contentSize
	dump("UiCompoentLuaLayer:reLoadIconTbl 11111")
	if needReload then
		dump("UiCompoentLuaLayer:reLoadIconTbl 222222 ")
		local reloadNode = cc.Node:create()
		reloadNode:setContentSize(iconSize)
		local label = cc.Label:createWithSystemFont("重新加载", "Helvetica", 20, cc.size(0.0,0))
    	local bg = CCLoadSprite:createSprite("icon_BG.png")
    	reloadNode:addChild(bg)
    	bg:setScale(0.7)
    	bg:setPosition(cc.p(40, 40))
    	reloadNode:addChild(label)
    	label:setPosition(cc.p(40, 40))

		self:addChild(reloadNode)
		reloadNode.iconType = 1
		reloadNode.iconName = "testNode"
	    reloadNode:setAnchorPoint(cc.p(0.5, 0.5))
		reloadNode.touchEvent = function()
			self:reLoadIconTbl()
		end
		self.iconListDataTbl[#self.iconListDataTbl + 1] = reloadNode
	end
	for i, fileData in pairs(iconListFileTbl) do
        local view = nil
        if self.showAllBtn or (self.onlyShowDBRecord and (fileData.iconName == "game.UIComponent.DragonBattleRecordIcon"
                or fileData.iconName == "game.UIComponent.DragonBattleDataIcon"
                or fileData.iconName == "game.UIComponent.DragonBattleObMvpIcon") ) then
            Dprint("fileData.iconName", fileData.iconName)
            view = Drequire(fileData.iconName).create(iconSize, contentSize)
        end

		if view then
			registerNodeEventHandler(view)
			MyPrint('UiCompoentLuaLayer:reLoadIconTbl icon', fileData.iconName)
			self:addChild(view)
			view.iconType = fileData.iconType
			view.iconName = fileData.iconName
            view.guide = fileData.guide
		    -- self:setPosition(cc.p(IconWidth*0.5, IconHeight*0.5))
		    view:setAnchorPoint(cc.p(0.5, 0.5))
			self.iconListDataTbl[#self.iconListDataTbl + 1] = view
		else
			dump(fileData, "iconListFileTbl file  create error")
		end
	end
	dump(self.iconListDataTbl, "UiCompoentLuaLayer:reLoadIconTbl 111111111111111111: ")
    if self.showAllBtn then
	   self:updateDownLeftPos()
    end
	self:updateRightUpPos()
end

function UiCompoentLuaLayer:onTouchBegan(x, y)
    self.v_chapterCount = 0
	if self.hasEnter == false then
		return
	end
    self.curTouchExtActId = nil
	local popupViewNum = PopupViewController:call("getInstance"):call("getCurrViewCount")
	if popupViewNum > 0 then
		return false
	end

	if self:isVisible(true) == false then
		if self.m_chapterNode and self.m_chapterNode:isVisible() and touchInside(self.m_chapterNode ,x,y) then
			self.touchType = 12
			return true
        elseif self.m_chapterTaskNode and self.m_chapterTaskNode:isVisible() and touchInside(self.m_chapterTaskBg ,x,y) then
            self.touchType = 13
            return true
		else
			return false
		end
	end

    if self.onlyShowDBRecord then
        for i, icon in pairs(self.iconListDataTbl) do
            if icon:isVisible() and touchInside(icon, x, y) then
                self.touchType = 1000 + i
                return true
            end
        end
        return
    end

	if self.m_activityPanelNode:isVisible() and touchInside(self.m_activityPanelNode, x, y) then
		self.touchType = 3
		return true
	elseif self.m_kingCompensateNode:isVisible() and touchInside(self.m_kingCompensateNode, x, y) then
		self.touchType = 8
		return true
	elseif self.m_mergeServerNode and self.m_mergeServerNode:isVisible() and touchInside(self.m_mergeServerNode, x, y) then
		self.touchType = 9
		return true
    elseif self.m_kingdomJiJie_node and self.m_kingdomJiJie_node:isVisible() and touchInside(self.m_kingdomJiJie_node, x, y) then
        self.touchType = 23
        return true
	elseif self.m_chapterNode and self.m_chapterNode:isVisible() and touchInside(self.m_chapterNode ,x,y) then
		self.touchType = 12
		return true
    elseif self.m_chapterTaskNode and self.m_chapterTaskNode:isVisible() and touchInside(self.m_chapterTaskBg ,x,y) then
        self.touchType = 13        
        return true
    elseif self.m_killMonsterTouchNode and self.m_killMonsterTouchNode:isVisible() and touchInside(self.m_killMonsterTouchNode, x, y) then
        self.touchType = 33
        if self.m_killMonsterBuff == 1 then
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("134072", getLang("101502")))
        else
            local now = getTimeStamp()
            local time = format_time(self.m_killMonsterEndTime-now)
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("134072", time))
        end
        return true
	elseif self.m_timeLimitBuffBg and self.m_timeLimitBuffBg:isVisible() and touchInside(self.m_timeLimitBuffBg, x, y) then
    	self.touchType = 15
    	return true
	elseif self.m_newKingdomWarBg2 and self.m_newKingdomWarNode:isVisible() and touchInside(self.m_newKingdomWarBg2, x, y) then
		self.touchType = 18
        return true
	-- elseif self.m_kingReturnNode and self.m_kingReturnNode:isVisible() and touchInside(self.m_kingReturnNode, x, y) then
	-- 	self.touchType = 19
	-- 	return true
    else
    	-- 通用按钮触摸,已占用1000+
		for i, icon in pairs(self.iconListDataTbl) do
			if icon:isVisible() and touchInside(icon, x, y) then
				self.touchType = 1000 + i
				return true
			end
		end
	end
end


------onTouchBegan-------

function UiCompoentLuaLayer:onTouchMoved(x, y)
	-- dump(" UiCompoentLuaLayer:onTouchMoved() ~~~~~~~~~~~~~~BBBBBBBBBBBB")
end




--------------onTouchEnded------------
function UiCompoentLuaLayer:onTouchEnded(x, y)
	-- dump(" UiCompoentLuaLayer:onTouchEnded() ~~~~~~~~~~~~~~CCCCCCCCCCCCC")
	MyPrint("UiCompoentLuaLayer:onTouchEnded", self.touchType)
    if self.touchType ~= 12 and self.touchType ~= 13 and GuideController:call("getCurGuideID") == '3919800' then
        GuideController:call("next")
    end
	if self.touchType == 3 and touchInside(self.m_activityPanelNode, x, y) then
        self:showActivityPageView()
        LogController:postEventLog("UiCompoentLuaLayer_clicked", {TIME=getWorldTime()})

	elseif self.touchType == 8 and touchInside(self.m_kingCompensateNode, x, y) then
		LogController:call("getInstance"):call("postEventLog", "kingReward")
        -- FBUtilies::addEventToFaceBook("kinReward");                 
        if CCCommonUtilsForLua:isFunOpenByKey("consume_soldier_defend") then
            COSDataController.getInstance():reqKingRwdData()
            -- local view = Drequire("game.activity.CallOfSoldiresAct.COSKingRewardView"):create()
            -- PopupViewController:addPopupView(view)
        else
            local dict = CCDictionary:create()
            dict:setObject(CCString:create("KingRewardPopUpView"), "name")
            LuaController:call("openPopViewInLua", dict)
        end
            
        -- PopupViewController::getInstance()->addPopupView(KingRewardPopUpView::create());
    elseif self.touchType == 9 and self.m_mergeServerNode and touchInside(self.m_mergeServerNode, x, y) then
    	local lua_path = "game.MergeServer.MergeServerView"
    	package.loaded[lua_path] = nil
    	local view = require(lua_path):create()
    	PopupViewController:addPopupInView(view)

    elseif self.touchType == 23 and self.m_kingdomJiJie_node and touchInside(self.m_kingdomJiJie_node, x, y) then
        if UiCompoentControoller.kingdomBattleTeamUid ~= "" then
            local dict = CCDictionary:create()
            dict:setObject(CCString:create("AllianceWarDetailView"), "name")
            dict:setObject(CCString:create("1"), "specialMass")
            dict:setObject(CCString:create(tostring(UiCompoentControoller.kingdomBattleTeamUid)), "teamUuid")
            LuaController:call("openPopViewInLua", dict)
        end

    elseif self.touchType == 12 and self.m_chapterNode and touchInside(self.m_chapterNode,x,y) then
        ChapterController.getInstance():openChapterView()
    elseif self.touchType == 13 and self.m_chapterTaskNode and touchInside(self.m_chapterTaskBg ,x,y) then
        ChapterController.getInstance():openChapterView()
	elseif self.touchType == 15 and self.m_timeLimitBuffBg and touchInside(self.m_timeLimitBuffBg,x,y)then
    	--王国限时增益
    	local view = Drequire("game.TimeLimitBuff.TimeLimitBuffView").create()
    	PopupViewController:addPopupView(view)
    elseif self.touchType == 18 and self.m_newKingdomWarBg2 and touchInside(self.m_newKingdomWarBg2, x, y) then
    	local serverType = GlobalData:call("shared"):getProperty("serverType")
    	if (serverType == ServerType.SERVER_DESPOT or serverType == ServerType.SERVER_EMPIRE) then
    		local view = Drequire("game.crossThrone.CrossThroneOccupyRankView"):create()
    		PopupViewController:addPopupInView(view)
    	else
    		if CCCommonUtilsForLua:isFunOpenByKey("new_wonder_v2") then 
    			local view = Drequire("game.NewKingdomWar.NewKingdomWarView_v2").create()
    			PopupViewController:addPopupInView(view)
    		else
				local view = Drequire("game.NewKingdomWar.NewKingdomWarView").create()
				PopupViewController:addPopupInView(view)
			end
		end
    -- elseif self.touchType == 19 and self.m_kingReturnNode and touchInside(self.m_kingReturnNode, x, y) then
    --     --没有激活
    --     if self.kingReturnState == 0 then
    -- 	    local view = Drequire('game.activity.toNewServer.KingReturnPasteKeyView')
    -- 	    PopupViewController:call("addPopupView", view:create())
    --     --已激活，则打开王者归来
    --     else
    --         local view = Drequire("game.activity.toNewServer.KingReturnView"):create()
    --         PopupViewController:addPopupInView(view)
    --     end      
    else
    	-- 通用按钮触摸,已占用1000+
    	if self.touchType and self.touchType > 1000 then
    		local index = self.touchType - 1000
    		local curIcon = self.iconListDataTbl[index]
    		if curIcon and touchInside(curIcon, x, y) then
    			if curIcon.touchEvent then
    				curIcon:touchEvent()
    				return
    			end
    		end
    	end
	end
    self.curTouchExtActId = nil
    print("UiCompoentLuaLayer:Touch End "..tostring(self.touchType))
end
------------onTouchEnded-----------

function UiCompoentLuaLayer:showActivityPageView( )
    dump("UiCompoentLuaLayer:showActivityPageView+++")
    LogController:call("getInstance"):call("postEventLog", "store_activity")
    local pageIds = ActivityController:call("getSortedActivityPageIds")
    if nil ~= pageIds and pageIds:count() > 1 then
        local lua_path = "game.activity.ActivityPage.ActivityPageView"
        local view = Drequire(lua_path):create()
        PopupViewController:addPopupView(view)
    else
        self.m_activityPanelNode:getChildByTag(999):call("onTouchFunc")
    end
end


function UiCompoentLuaLayer:onSceneChanged(sceneId)
	dump(" UiCompoentLuaLayer:onSceneChanged( sceneId is: "..sceneId)
	self.sceneId = sceneId
	if sceneId == SCENE_ID_WORLD then
		self.m_worldFaveNode:setVisible(true)
		if self.m_mergeServerNode then
			self.m_mergeServerNode:setVisible(false)
		end

        if self.m_kingdomJiJie_node then 
            self.m_kingdomJiJie_node:setVisible(false)
        end

		if self.m_chapterNode ~= nil then
			print("m_chapterNode is visible")
			self.m_chapterNode:setVisible(false)
		end
        
		if self.m_chapterTaskNode ~= nil then
            print("m_chapterNode is visible")
            self.m_chapterTaskNode:setVisible(false)
        end
	else
		self.m_worldFaveNode:setVisible(false)
        self:createMergeServer()
        local _dict = CCDictionary:create()       
        COSDataController.getInstance():sendPushLimitInfo(_dict)
        -- if self.m_kingdomJiJie_node then 
        --     self.m_kingdomJiJie_node:setVisible(true)
        -- end
	end

	for i, icon in pairs(self.iconListDataTbl) do
		if icon.onSceneChanged then
			icon:onSceneChanged(sceneId)
		end
	end
    local transDoorNode = self:getChildByTag(2525)
    if transDoorNode then
        transDoorNode:checkShow()
    end
	self:resetKingCompensate()
    self:refreshChapgerNode()
    
    require("game.flyHint.FlyHintManager").getManager():onSceneChanged()

    -- self:onCheckShowWorldBossComingAni(sceneId)
end

function UiCompoentLuaLayer:update(t)
	if self:isVisible(true) then
		for i, icon in pairs(self.iconListDataTbl) do
			-- dump(icon.iconName, " icon listName is: ")
			if icon.updateEvent then
				icon:updateEvent()
			end
		end

		self:updateRightUpPos()
		self:updateDownLeftPos()

        if self.m_kingdomJiJie_node and self.sceneId and self.sceneId==SCENE_ID_MAIN then
            if UiCompoentControoller.kingdomBattleTeamEndTime > 0 or self.m_kingdomJiJie_node:isVisible() then
                local now = GlobalData:call("getTimeStamp")
                local lastTime = UiCompoentControoller.kingdomBattleTeamEndTime - now
                if lastTime > 0 then
                    self.m_kingdomJiJie_node:setVisible(true)
                    self.m_kingdomJiJie_timeLabel:setString(format_time(lastTime))
                else
                    self.m_kingdomJiJie_node:setVisible(false)
                    UiCompoentControoller.kingdomBattleTeamEndTime = 0
                end
            end
        end

        if self.m_killMonsterBuff and self.m_killMonsterEndTime and self.m_killMonsterStartTime and self.m_killMonsterBuffNode then
            if DynamicResourceController2:call("checkDynamicResource", "SamuraiShodown_face") == true then
                local now = getTimeStamp()
                if self.m_killMonsterBuff == 1 then
                    self.m_killMonsterClipNode:setContentSize(cc.size(self.m_killMonsterBuffNode:getContentSize().width, self.m_killMonsterBuffNode:getContentSize().height))
                else
                    if now < self.m_killMonsterEndTime then
                        local scale = (self.m_killMonsterEndTime-now)/(self.m_killMonsterEndTime-self.m_killMonsterStartTime)
                        self.m_killMonsterClipNode:setContentSize(cc.size(self.m_killMonsterBuffNode:getContentSize().width * scale, self.m_killMonsterBuffNode:getContentSize().height))
                    else
                        self.m_killMonsterClipNode:setContentSize(cc.size(self.m_killMonsterBuffNode:getContentSize().width, self.m_killMonsterBuffNode:getContentSize().height))
                        self.m_killMonsterBuff = 1
                        self.m_killMonsterStartTime = -1
                        self.m_killMonsterEndTime = -1
                        self:onKillMonsterBuff()
                    end
                end
            end
        end
	else
		if self.m_chapterNode and self.m_chapterNode:isVisible() then
    		local offsetY = IconHeight + IconOffset
			local posY = IconHeight*0.5
		    if not self.m_UIQuestNode:isVisible() then
		    	posY = posY - offsetY
		    end
			self.m_chapterNode:setPositionY(posY)
            self.m_chapterNode:setPositionX(IconWidth*0.5)
            self.m_chapterTaskNode:setPositionY(posY - IconHeight*0.5)
            self.m_chapterTaskNode:setPositionX(IconWidth*0.5 + 120)
		end
	end
    self:updateChapterGuide()    
    self.initTime = self.initTime+1
    DailyActivityManager.updateSpecialActivityEndtime()
    self:updateTrigger(t)
end

-- 左下逻辑
function UiCompoentLuaLayer:updateDownLeftPos()
	local count = 0
	local pos = IconWidth*0.5
	local posY = IconHeight*0.5
    local offset = IconWidth + IconOffset
    local offsetY = IconHeight + IconOffset
    if not self.m_UIQuestNode:isVisible() then
    	posY = posY - offsetY
    end
    local initPosY = posY
    local initPosX = pos

    self.m_downLeftNodeNum = 0

    --新版任务系统
    if self.m_chapterNode and ChapterController:getInstance():isChapterOpen() then
        self.m_chapterNode:setPositionY(posY )
        self.m_chapterNode:setPositionX(initPosX )
        self.m_chapterTaskNode:setPositionY(posY - IconHeight*0.5)
        self.m_chapterTaskNode:setPositionX(initPosX + 120)
        posY = posY + offsetY
        initPosY = initPosY + offsetY
        self.m_downLeftNodeNum = self.m_downLeftNodeNum + 1
    end

    if self.m_kingdomJiJie_node and self.m_kingdomJiJie_node:isVisible() then
        self.m_kingdomJiJie_node:setPositionY(posY)
        self.m_kingdomJiJie_node:setPositionX(initPosX)
        posY = posY + offset
        self.m_downLeftNodeNum = self.m_downLeftNodeNum + 1
    end

	--kingReturn
	-- if self.m_kingReturnNode then
	-- 	self:refreshKingReturn()
	-- 	if self.m_kingReturnNode:isVisible() then -- and self.m_downLeftNodeNum < 3
	-- 		self.m_kingReturnNode:setPositionY(posY)
	-- 		posY = posY + offsetY
	-- 		self.m_kingReturnNode:setPositionX(initPosX)	
	-- 	end
	-- end

	-- 国王的援助
	if self.m_kingCompensateNode and self.m_kingCompensateNode:isVisible() then
		self.m_kingCompensateNode:setPositionY(posY)
		posY = posY + offsetY
	end

	-- 合服申请
	if self.m_mergeServerNode and self.m_mergeServerNode:isVisible() then
		self.m_mergeServerNode:setPositionY(posY)
		posY = posY + offsetY
	end

	for i, icon in pairs(self.iconListDataTbl) do
		if icon.iconType == 2 and icon:isVisible() then
			icon:setPosition(cc.p(initPosX, posY))
			posY = posY + offsetY
		end
	end

    pos = pos + offset
	-- 横向数据
	if self.m_worldFaveNode:isVisible() then
		self.m_worldFaveNode:setPosition(cc.p(pos, initPosY))
		pos = pos + offset
	end

	for i, icon in pairs(self.iconListDataTbl) do
		if icon.iconType == 3 and icon:isVisible() then
			icon:setPosition(cc.p(pos, initPosY))
			pos = pos + offset
		end
	end
    
    if SceneController:call("getCurrentSceneId") == SCENE_ID_WORLD then
        if CCCommonUtilsForLua:isIosAndroidPad() then -- ipad适配
            posY = 350
        else
            posY = 300
        end
        for i, icon in pairs(self.iconListDataTbl) do
            if icon.iconType == 5 and icon:isVisible() then
                icon:setPosition(cc.p(initPosX, posY))
                posY = posY + offsetY
            end
        end
    end
end

-- 右上逻辑
function UiCompoentLuaLayer:updateRightUpPos()
	local count = 0;
	local pos = self.contentSize.height - IconHeight*0.5;
    local offset = IconHeight+IconOffset;
    local initPosX = self.contentSize.width - IconWidth*0.5

	-- 纵向部分
    for i, icon in pairs(self.iconListDataTbl) do
        if icon.iconType == 1 and icon:isVisible() then
            icon:setPosition(cc.p(initPosX, pos))
            pos = pos - offset
        end
    end
	if self.m_activityPanelNode ~= nil then
		if self.m_activityPanelNode:isVisible() then
			self.m_activityPanelNode:setPositionY(pos)
			pos = pos - offset
		end
	end
end

--王者归来入口
--弃用，测试以后再删
function UiCompoentLuaLayer:resetKingReturnNode ()
	local oldUid = cc.UserDefault:getInstance():getStringForKey('king_return_old_uid', '')
	MyPrint('UiCompoentLuaLayer:resetKingReturnNode', oldUid)
    local isActOpen = false
    if ActivityController.getInstance():isActivityOpen("57242") then            
        local isSpeAct, endTime = DailyActivityManager.getSpecialActivityEndtime('57242')
        if endTime > 0 then
            isActOpen = true
        end
    end 

    if self.m_kingReturnNode or not CCCommonUtilsForLua:isFunOpenByKey("k_return") then
        return
    end
    --olduid 和 活动中心 有其一就显示
	if '' == oldUid and not isActOpen then
		return
	end

	local ctl = ToNewServerController.getInstance()
	-- local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	-- local now = getTimeStamp()
	-- local registerTime = playerInfo:getProperty("registerTime")
	-- MyPrint('UiCompoentLuaLayer:resetKingReturnNode getTimeStamp', now)
	-- MyPrint('UiCompoentLuaLayer:resetKingReturnNode registerTime', registerTime)
	MyPrint('UiCompoentLuaLayer:resetKingReturnNode chooseEndTime', ctl.chooseEndTime)

    --测试 俩小时内激活才能开启以后的活动
	-- if now - registerTime > 7200 or 0 ~= ctl.status then -- 注册两小时内激活
	-- 	return
	-- end
    if  0 == ctl.status then -- 前往新服后未激活
        self.kingReturnState = 0 --未激活状态
    else
        self.kingReturnState = ctl.status
        --判断有没有该活动
        --57241 幸运回归
        --57242 王者归来
        if not isActOpen then
            return
        end
    end

    if not self.m_kingReturnNode then
		self.m_kingReturnNode = cc.Node:create()
	end
    if self.m_kingReturnNode then
    	self.m_kingReturnNode:setContentSize(cc.size(IconWidth, IconHeight))
	    self:addChild(self.m_kingReturnNode)
	    self.m_kingReturnNode:setPosition(cc.p(IconWidth*0.5, IconHeight*0.5))
	    self.m_kingReturnNode:setAnchorPoint(cc.p(0.5, 0.5))

		self.kingReturnSpr = CCLoadSprite:createSprite("icon_king_return.png")
		if self.kingReturnSpr then
			CCCommonUtilsForLua:setSpriteMaxSize(self.kingReturnSpr, IconWidth * 0.9, true)			
			self.m_kingReturnNode:addChild(self.kingReturnSpr)
			self.kingReturnSpr:setPosition(cc.p(IconWidth*0.5, IconHeight*0.5))
		end
		--words
		local sprBg = CCLoadSprite:call("createSprite", "shengdianBoard_03.png")
		if sprBg then
			-- sprBg:setScaleX(1.5)
			sprBg:setPosition(cc.p(IconWidth*0.5, 10))
			self.m_kingReturnNode:addChild(sprBg)
		end

		local label = cc.Label:createWithSystemFont(getLang("176188"), "Helvetica", 16, cc.size(0.0,0))
		if label then
	   		label:setColor(cc.c3b(255, 250, 230))
	   		label:setPosition(sprBg:getPosition())
	   		self.m_kingReturnNode:addChild(label)
	   	end
		self.m_downLeftNodeNum = 990
    end
end

---------------------------------- activityPanel ----------------------------------
function UiCompoentLuaLayer:resetActivityPanelNode()
	if CCCommonUtilsForLua:isFunOpenByKey("ActivityPageList_New") then
		return
	end
    if not self.m_activityPanelNode then
	    self.m_activityPanelNode = cc.Node:create()
	    self.m_activityPanelNode:setContentSize(cc.size(IconWidth, IconHeight))
	    self:addChild(self.m_activityPanelNode)
    	self.m_activityPanelNode:setPosition(cc.p(self.contentSize.width - IconWidth*0.5, self.contentSize.height - IconHeight));
	    self.m_activityPanelNode:setAnchorPoint(cc.p(0.5, 0.5));
	    self.m_activityPanelNode:setVisible(false)
    	self:addTestColor(self.m_activityPanelNode)
	end

	self.m_activityPanelNode:removeAllChildren()
	self.m_activityPanelNode:setVisible(false)
	local pageIds = ActivityController:call("getSortedActivityPageIds")
	if nil ~= pageIds and pageIds:count() > 0 then
		local activityPanel = ActivityBox_v2:call("create")
		if activityPanel then
			self.m_activityPanelNode:addChild(activityPanel)
			activityPanel:setPosition(cc.p(IconWidth*0.5, 0))
			activityPanel:setTag(999)
			self.m_activityPanelNode:setVisible(true)
		end
	end
end

function UiCompoentLuaLayer:openActivityView(id)
    dump(id, "UiCompoentLuaLayer:openActivityView+++")
    local pageId = nil
    if id < 0 then --pageId使用负数表示
        pageId = tostring(-id)
        dump(pageId,"pageId+++")
    else
        actId = tostring(id)
        dump(actId,"actId+++")
    end
    if pageId and pageId == "9012501" then
        require("game.LiBao.Repay.RepayController")
        if RepayController.getInstance():isBegin() then
            RepayController.getInstance():fireEvent("RepayViewCreate")
        end
    else
        ActivityController.getInstance():shouActUIById(actId)
    end
end

-----------------------------------章节按钮-----------------------------------
function  UiCompoentLuaLayer:createChapterNode()
	if not self.m_chapterBaseNode then
		return
	end

	MyPrint(__FUNC__())
    -- 章节任务
    self.m_chapterTaskNode = cc.Node:create()
	self.m_chapterBaseNode:addChild(self.m_chapterTaskNode)
    self.m_chapterTaskNode:setVisible(false)
    self.m_chapterTaskNode:setPosition(cc.p(IconWidth*0.5 + 120, IconWidth - IconHeight*0.5))
    self.m_chapterTaskBg = CCLoadSprite:call("createSprite", "new_title_bg.png")
    if self.m_chapterTaskBg then
        self.m_chapterTaskNode:addChild(self.m_chapterTaskBg)
        self.m_chapterTaskBg:setPosition(cc.p(-10, IconHeight*0.5))

        self.m_chapterTaskLabel = cc.Label:createWithSystemFont("", "Helvetica", 20, cc.size(0, 0))
        self.m_chapterTaskLabel:setPosition(cc.p(-60, IconHeight*0.5))
        self.m_chapterTaskLabel:setAnchorPoint(cc.p(0, 0.5))
        self.m_chapterTaskLabel:setColor(cc.c3b(236, 220, 170))
        self.m_chapterTaskLabel:setHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
        self.m_chapterTaskLabel:setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
        self.m_chapterTaskNode:addChild(self.m_chapterTaskLabel)
    end    

	self.m_chapterNode = cc.Node:create()
	self.m_chapterNode:setContentSize(cc.size(IconWidth, IconHeight))
	self.m_chapterBaseNode:addChild(self.m_chapterNode)

	self.m_chapterNode:setPosition(cc.p(IconWidth*0.5, IconHeight*0.5));
    self.m_chapterNode:setAnchorPoint(cc.p(0.5, 0.5))
   	self.m_chapterNode:setVisible(false)
   	self.m_chapterNode:setPositionY(IconWidth)
    callItSelfCallFunc(LuaController, "doResourceByCommonIndex", 3, true)
    callItSelfCallFunc(LuaController, "doResourceByCommonIndex", 504, true)
    local _iconBg = CCLoadSprite:call("createSprite", "princessTalkBg.png")
    if _iconBg then
        self.m_chapterNode:addChild(_iconBg)
        _iconBg:setPosition(cc.p(IconWidth*0.5 , IconHeight*0.5))
    end
	local icon = CCLoadSprite:call("createSprite", "story_icon.png")
	if icon then
		self.m_chapterNode:addChild(icon)
		local size = icon:getContentSize()
		icon:setPosition(cc.p(IconWidth*0.5 , IconHeight*0.5))
		MyPrint("icon size width = ",size.width)
	end
    self.m_chapterGreenBallNode = cc.Node:create()
    local greenBall = CCLoadSprite:call("createSprite", "info_green.png")
    self.m_chapterGreenBallNode:addChild(greenBall)
    self.m_chapterLabel = cc.Label:createWithSystemFont("9", "Helvetica", 20, cc.size(0.0,0))
    self.m_chapterLabel:setColor(cc.c3b(255, 250, 230))
    self.m_chapterGreenBallNode:addChild(self.m_chapterLabel)
    self.m_chapterGreenBallNode:setPosition(cc.p(70, 60))
    self.m_chapterNode:addChild(self.m_chapterGreenBallNode)
    self.m_chapterGreenBallNode:setVisible(false)
    self.v_chapterCount = 0
	MyPrint("UiCompoentLuaLayer:createChapterNode")
end

-- 章节任务图标和任务条动画
function UiCompoentLuaLayer:animChapter(  )
    Dprint("UiCompoentLuaLayer:animChapter")

    FunBuildController:call("SendRecordeToServer", 'ui_chapter')
    self.isChapterShow = true
    self.m_chapterNode:setVisible(self.isChapterShow)

    local _scale0 = cc.ScaleTo:create(0, 0, 1)
    local _show = cc.Show:create()
    local _scale1 = cc.ScaleTo:create(0.5, 1, 1)
    local _delay = cc.DelayTime:create(1)
    local function callback()
        GuideController:call("next")
    end
    local _callback = cc.CallFunc:create(callback)
    local _seq = cc.Sequence:create(_scale0, _show, _scale1, _delay, _callback)
    self.m_chapterTaskNode:runAction(_seq)
end

function UiCompoentLuaLayer:animHideChapter(  )
    Dprint("UiCompoentLuaLayer:animHideChapter")

    FunBuildController:call("SendRecordeToServer", 'ui_hide_chapter')
    self.isChapterShow = false
    self.m_chapterNode:setVisible(self.isChapterShow)
    
    local _scale0 = cc.ScaleTo:create(0, 1, 1)
    local _show = cc.Show:create()
    local _scale1 = cc.ScaleTo:create(0.5, 0, 1)
    local _hide = cc.Hide:create()
    local _delay = cc.DelayTime:create(1)
    local function callback()
        self.m_chapterNode:setVisible(false)
        GuideController:call("next")
    end
    local _callback = cc.CallFunc:create(callback)
    local _seq = cc.Sequence:create(_scale0, _show, _scale1, _hide, _delay, _callback)
    self.m_chapterTaskNode:runAction(_seq)
end

function  UiCompoentLuaLayer:refreshChapterInfo()
    if not self.m_chapterBaseNode then
        return
    end
    local now = ChapterController:getInstance().m_completeCnt
    if now > 0 then
        self.m_chapterGreenBallNode:setVisible(true)
        self.m_chapterLabel:setString(tostring(now))
    else
        self.m_chapterGreenBallNode:setVisible(false)
    end
    self.m_chapterTaskLabel:setString(ChapterController:getInstance():getChapterProString())
end

-- 无任何操作超过5秒指向章节按钮
function UiCompoentLuaLayer:updateChapterGuide()
    -- Dprint("UiCompoentLuaLayer:updateChapterGuide", ChapterController:getInstance():isChapterOpen(), 
    --     self.m_chapterNode:isVisible(), GuideController:call("getCurGuideID"), self.v_chapterCount)
    if SceneController:call("getCurrentSceneId")==SCENE_ID_MAIN and ChapterController:getInstance():isChapterOpen() and self.m_chapterNode:isVisible() then
        local _chapterSection = tonumber(ChapterController:getInstance().index) or 0
        if _chapterSection < 5 and GuideController:call("getCurGuideID") == '' and PopupViewController:call("getCurrentPopupView")==nil then
            self.v_chapterCount = self.v_chapterCount + 1
            local _guideId = '3919800'
            if self.v_chapterRestCount == nil then
                self.v_chapterRestCount = atoi(CCCommonUtilsForLua:call("getPropByIdGroup","guide",_guideId,"para1"))
            end
            if self.v_chapterCount > self.v_chapterRestCount then
                self.v_chapterCount = 0
                GuideController:call("setGuide", _guideId)
            end
        end
    end
end
---------------------------------- 国王的援军 ----------------------------------
function UiCompoentLuaLayer:createKingCompensate()
	if not self.m_kingCompensateNode then
	    self.m_kingCompensateNode = cc.Node:create()
	    self.m_kingCompensateNode:setContentSize(cc.size(IconWidth, IconHeight))
	    self:addChild(self.m_kingCompensateNode)
    	self.m_kingCompensateNode:setPosition(cc.p(IconWidth*0.5, IconHeight*0.5));
	    self.m_kingCompensateNode:setAnchorPoint(cc.p(0.5, 0.5));
    	self:addTestColor(self.m_kingCompensateNode)

    	local baseNode = cc.Node:create()
    	self.m_kingCompensateNode:addChild(baseNode)
    	baseNode:setPosition(cc.p(IconWidth*0.5, IconHeight*0.5 - 10))

    	local rectBg = CCLoadSprite:createSprite("Btn_shoucang.png")
    	baseNode:addChild(rectBg)
    	local spr = CCLoadSprite:createSprite("princessIcon.png")
    	baseNode:addChild(spr)
    	spr:setScale(0.8)
    	spr:setPosition(cc.p(1, 10))

        local rt0 = cc.RotateTo:create(0.01, 0)
        local rt1 = cc.RotateBy:create(0.1, 15)
        local rt2 = cc.RotateBy:create(0.1, -30)
        local rt3 = cc.RotateBy:create(0.1, 22)
        local rt4 = cc.RotateBy:create(0.1, -14)
        local rt5 = cc.RotateBy:create(0.1, 7)
        local dt = cc.DelayTime:create(2)
        local seq = cc.Sequence:create(rt0, rt1, rt2, rt3, rt4, rt5, dt, NULL)
        baseNode:runAction(cc.RepeatForever:create(seq))
	end

	self:resetKingCompensate()
end
function UiCompoentLuaLayer:resetKingCompensateSetting()
    self.m_isKingCompensateSetting = false
end

function UiCompoentLuaLayer:resetKingCompensate()
	if self.m_kingCompensateNode then
		self.m_kingCompensateNode:setVisible(false)
        local t = GlobalData:call("shared")
        local s = t:getProperty("KingCompensateCount")
        if s > 0 then
            --内城首弹
            if self.sceneId == SCENE_ID_MAIN then
                self.m_kingCompensateNode:setVisible(true)
                -- 国王的援助 首次弹出
                local King_Reinforcement = cc.UserDefault:getInstance():getStringForKey("King_Reinforcement", "")
                if King_Reinforcement == "" then
                    cc.UserDefault:getInstance():setStringForKey("King_Reinforcement", "1")
                    cc.UserDefault:getInstance():flush()
                    local dict = CCDictionary:create()
                    dict:setObject(CCString:create("KingRewardPopUpView"), "name")
                    LuaController:call("openPopViewInLua", dict)
                end
            end
            --行军路线 + 瞭望塔信息警告 + 闪屏警报
            if ImperialSceneLuaManager.getInstance().m_kingCompensateTbl then
                dump(ImperialSceneLuaManager.getInstance().m_kingCompensateTbl )
            end
            if not self.m_isKingCompensateSetting 
                and ImperialSceneLuaManager.getInstance().m_kingCompensateTbl 
                and ImperialSceneLuaManager.getInstance().m_kingCompensateTbl.rewardTime 
                and tonumber(ImperialSceneLuaManager.getInstance().m_kingCompensateTbl.rewardTime) > GlobalData:call("getTimeStamp") * 1000 then
                self:createMarchLine()
                self.m_isKingCompensateSetting = true
            end
        end
	end
end

function UiCompoentLuaLayer:createMarchLine(  )
    -- 创建队列
    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
    local serverId = playerInfo:getProperty("selfServerId")

    local marchInfo = {
        ["uuid"] = tostring(ThroneId),
        ["sp"] = tostring(WorldController:call("getIndexByPoint", ccp(600, 600))),
        ["dp"] = tostring(WorldController:call("getInstance"):call("getSelfCityIndex")),
        ["st"] = tostring(ImperialSceneLuaManager.getInstance().m_kingCompensateTbl.time),
        ["et"] = tostring(ImperialSceneLuaManager.getInstance().m_kingCompensateTbl.rewardTime),
        ["mType"] = tostring(MarchMethodType.MethodDeal),
        ["tType"] = tostring(WorldCityType.CityTile),
        ["oType"] = tostring(PlayerType.PlayerKing),
        ["sType"] = tostring(MarchStateType.StateMarch),
        ["o"] = getLang("110037"),-- 110037=国王 
        ["color"] = tostring(0),
        ["ouid"] = playerInfo:getProperty("uid"),
    }
    dump(marchInfo, "marchInfomarchInfo")
    local dict = luaToDict(marchInfo)
    local arr = CCArray:create()
    arr:addObject(dict)
    WorldController:call("initMarchInfo", arr, serverId)

    --创建敌人信息
    -- "reward"     = "wood,0,3585060|stone,0,60210|iron,0,209250|food,0,2565540|goods,200208,5|goods,200204,2"
    local tradInfo = {}
    local tempArrTbl = string.split(ImperialSceneLuaManager.getInstance().m_kingCompensateTbl.reward, "|")
    for i,v in ipairs(tempArrTbl) do
        local temprewardtbl = string.split(v, ",")
        if temprewardtbl and #temprewardtbl == 3 then
            local t = -1
            local rewardshow = temprewardtbl[1]
            if (rewardshow == "wood") then
                t = RewardTypeConfig.R_WOOD
            elseif (rewardshow == "food") then
                t = RewardTypeConfig.R_FOOD
            elseif (rewardshow == "iron") then
                t = RewardTypeConfig.R_IRON
            elseif (rewardshow == "stone") then
                t = RewardTypeConfig.R_STONE
            elseif (rewardshow == "goods") then
                t = temprewardtbl[2]
            end

            local tempTbl = {
                ["t"] = tostring(t),
                ["v"] = tostring(temprewardtbl[3]),
            }
            tradInfo[i] = tempTbl
        end
    end
    local enemyInfo = {
        ["uuid"] = tostring(ThroneId),
        ["uid"] = tostring(ThroneId),
        ["arrivalTime"] = tostring(ImperialSceneLuaManager.getInstance().m_kingCompensateTbl.rewardTime),
        ["createTime"] = tostring(ImperialSceneLuaManager.getInstance().m_kingCompensateTbl.time),
        ["name"] = getLang("110037"),-- 110037=国王 
        ["xy"] = tostring(WorldController:call("getIndexByPoint", ccp(600, 600))),
        ["defXy"] = tostring(WorldController:call("getInstance"):call("getSelfCityIndex")),
        ["super"] = "0",
        ["defType"] = "1", --WorldCityType.CityTile,
        ["type"] = "3", --MarchMethodType.MethodDeal,
        ["pic"] = "g044",
        ["serverId"] = tostring(serverId),
        ["tradeRes"] = tradInfo,
    }
    dump(enemyInfo, "enemyInfoenemyInfo")
    local enemyDict = luaToDict(enemyInfo)
    EnemyInfoController:call("pushEnemyData", enemyDict)

    -- 警报
    CCSafeNotificationCenter:postNotification("screenAlarm_hide")
    local alartTbl = {}
    alartTbl["fadeTime"] = "1"
    alartTbl["fadeType"] = "green"
    Drequire("game.UIComponent.ScreenAlarmView"):create(alartTbl)
end

---------------------------------- 合服入口 ----------------------------------
function UiCompoentLuaLayer:createMergeServer()
	if not self.m_mergeServerNode then
		self.m_mergeServerNode = cc.Node:create()
		self.m_mergeServerNode:setContentSize(cc.size(IconWidth, IconHeight))
	    self:addChild(self.m_mergeServerNode)
    	self.m_mergeServerNode:setPosition(cc.p(IconWidth*0.5, IconHeight*0.5));
	    self.m_mergeServerNode:setAnchorPoint(cc.p(0.5, 0.5));

	    local spr = CCLoadSprite:call("createSprite", "mergeServerIcon.png")
    	self.m_mergeServerNode:addChild(spr)
    	-- spr:setScale(0.8)
    	spr:setPosition(cc.p(IconWidth*0.5, IconHeight*0.5))

    	for i = 0, 1 do
			local particle = ParticleController:call("createParticle", "CombineServer_"..i)
			if particle then
				self.m_mergeServerNode:addChild(particle)
				particle:setPosition(spr:getPosition())
			end
		end

		local sprBg = CCLoadSprite:call("createSprite", "shengdianBoard_03.png")
		sprBg:setScaleX(1.5)
		sprBg:setPosition(cc.p(IconWidth*0.5, 10))
		self.m_mergeServerNode:addChild(sprBg)

		local label = cc.Label:createWithSystemFont(getLang("167051"), "Helvetica", 20, cc.size(0.0,0))
   		label:setColor(cc.c3b(255, 250, 230))
   		label:setPosition(sprBg:getPosition())
   		self.m_mergeServerNode:addChild(label)
    end
    self.m_mergeServerNode:setVisible(false)
    if getMergeServerState(false) then
    	self.m_mergeServerNode:setVisible(true)
    end
end
---------------------------------- 合服入口 ----------------------------------

function UiCompoentLuaLayer:towardAfterGiftReward(Ref)
	local towardType = Ref:getValue()
	dump("towardType is: "..towardType)
	if towardType == 1 then
		local lua_path = "game.activity.GoldCoinCarnival.Activity_GoldCoinCarnival"
	    local view = Drequire(lua_path):create("57161", 1)
	    if view then
	    	PopupViewController:addPopupView(view)
    	end
    end
end

---------------------------------- 王国限时增益Begin -------------------------------
function UiCompoentLuaLayer:resetTimeLimitBuffNode()
	-- MyPrint("UiCompoentLuaLayer:resetTimeLimitBuffNode")

	self.m_timeLimitBuffNode = cc.Node:create()
	self.m_timeLimitBuffNode:setContentSize(cc.size(90, 90))
	self:addChild(self.m_timeLimitBuffNode)
	self.m_timeLimitBuffNode:setPosition(self.contentSize.width - 500 , self.contentSize.height )
	self.m_timeLimitBuffBg = CCLoadSprite:call("createScale9Sprite", "new_iconBg.png")
	self.m_timeLimitBuffNode:addChild(self.m_timeLimitBuffBg)
	self.m_timeLimitBuffNode:setScale(0.6)
	self.m_timeLimitBuffAniNode = cc.Node:create()
	self:addChild(self.m_timeLimitBuffAniNode)
	self.m_timeLimitBuffAniNode:setPosition(self.contentSize.width - 500 , self.contentSize.height )
	local utils = cc.FileUtils:getInstance()
	local wpath = utils:getWritablePath()
	local dpath = wpath .. "dresource/"
	local json = dpath .. "skeleton.json"
	local atlas = dpath .. "sk_TimeLimitBuffCell_face.atlas"
	local aniName = "animation"

	if cc.FileUtils:getInstance():isFileExist(json) == false and cc.FileUtils:getInstance():isFileExist(atlas) == false then 
		return
	end
	
	self.animationObj = IFSkeletonAnimation:call("create", json, atlas)
	
	if self.animationObj then 
		self.animationObj:setPosition(0,-30)
		self.m_timeLimitBuffAniNode:addChild(self.animationObj)
		self.animationObj:setAnimation(0, tostring(aniName), false)
	end
	self.m_timeLimitBuffNode:setVisible(false)
	self.m_timeLimitBuffAniNode:setVisible(false)
end

function UiCompoentLuaLayer:onEnterFrame( )
	local TimeLimitBuffManager = require("game.TimeLimitBuff.TimeLimitBuffManager").new()
	if TimeLimitBuffManager:checkEnableState() then 
		self.m_timeLimitBuffNode:setVisible(true)
		self.m_timeLimitBuffAniNode:setVisible(true)
	else
		self.m_timeLimitBuffNode:setVisible(false)
		self.m_timeLimitBuffAniNode:setVisible(false)
	end
	local aniName = "animation"
	if self.animationObj then 
		self.animationObj:setAnimation(0, tostring(aniName), false)
	end
	local state = WorldController:call("getInstance"):call("getKingActivityStateByType", 0)
	-- MyPrint("KINGDOM WAR STATE!!", state)
	local serverType = GlobalData:call("shared"):getProperty("serverType")
	if SceneController:call("getCurrentSceneId") == 11 and state == 3 and (serverType == ServerType.SERVER_NORMAL or serverType == ServerType.SERVER_TEST or serverType == ServerType.SERVER_INNER_TEST) and (GlobalData:call("shared"):getProperty("crossThroneObTag") == false) and (CCCommonUtilsForLua:isFunOpenByKey("wonder_rule_new") or CCCommonUtilsForLua:isFunOpenByKey("new_wonder_v2")) then
		self.m_newKingdomWarNode:setVisible(true)
	else
		self.m_newKingdomWarNode:setVisible(false)
	end
	--local worldActivityInfo = WorldController:call("getInstance"):getProperty("m_worldActivity")
	-- dump(worldActivityInfo, "worldActivityInfo~~~~~~")
	--跨服王战
	if (serverType == ServerType.SERVER_DESPOT or serverType == ServerType.SERVER_EMPIRE) then
		if SceneController:call("getCurrentSceneId") == 11 and state == 3 then
			self.m_newKingdomWarNode:setVisible(true)
		else
			self.m_newKingdomWarNode:setVisible(false)
		end
	end
end


function UiCompoentLuaLayer:civLevelUp()
	dump("UiCompoentLuaLayer:civLevelUp ~~~~~")
	CivilizationController:fireCommonEvent("openCivilizationUpgradeView")
end

---------------------------------- 王国限时增益End -------------------------------
---------------------------------- 小王战 Begin ---------------------------------
function UiCompoentLuaLayer:resetNewKingdomWarNode()
	MyPrint("UiCompoentLuaLayer:resetNewKingdomWarNode")
	self.m_newKingdomWarNode = cc.Node:create()
	self.m_newKingdomWarNode:setContentSize(cc.size(90, 90))
	self:addChild(self.m_newKingdomWarNode)
	self.m_newKingdomWarNode:setPosition(self.contentSize.width - 300 , self.contentSize.height )
	self.m_newKingdomWarBg2 = CCLoadSprite:call("createScale9Sprite", "new_iconBg.png")
	local path = "World/World_2.plist"
	CCLoadSprite:call("doLoadResource", path)

	local serverType = GlobalData:call("shared"):getProperty("serverType")
	local resDown = DynamicResourceController2:call("checkDynamicResource", "crossThrone_face")
	local ctManager = require("game.crossThrone.CrossThroneManager")
	local icon = "icon_216000.png"
	if (serverType == ServerType.SERVER_DESPOT and resDown) then
		icon = ctManager:getThroneTypePic(DESPOT_BATTLE)
		CCLoadSprite:call("loadDynamicResourceByName", "crossThrone_face")
	elseif (serverType == ServerType.SERVER_EMPIRE and resDown) then
		icon = ctManager:getThroneTypePic(EMPIRE_BATTLE)
		CCLoadSprite:call("loadDynamicResourceByName", "crossThrone_face")
	else 
		icon = "icon_216000.png"
	end
	self.m_newKingdomWarBg = CCLoadSprite:createSprite(icon)
	self.m_newKingdomWarNode:addChild(self.m_newKingdomWarBg2)
	-- self.m_newKingdomWarBg2:setScale(0.8)
	self.m_newKingdomWarNode:addChild(self.m_newKingdomWarBg)
	self.m_newKingdomWarNode:setScale(0.6)
	
	self.m_newKingdomWarNode:setVisible(false)

	-- self.m_newKingdomWarTimeLabel = cc.Label:create()
	-- local worldActivityInfo = WorldController:call("getInstance"):getProperty("m_worldActivity")
	-- dump(worldActivityInfo, "worldActivityInfo~~~~~~")
	-- self.m_newKingdomWarTimeLabel:setString(format_time())
	
end
---------------------------------- 小王战 End -----------------------------------

function UiCompoentLuaLayer:getGuideNodeByKey( key )
	Dprint('UiCompoentLuaLayer:getGuideNodeByKey', key)
    if self.initTime < 4 then
        return nil
    end
    if key == 'LUA_UI_chapter' and self.m_chapterNode then -- and self.m_chapterNode:isVisible()
        local function callBack()
            GuideController:call("next")
        end
        GuideController:call("setCallback", cc.CallFunc:create(callBack))
        return self.m_chapterNode
    elseif key == 'LUA_UI_chapterRest' and self.m_chapterNode then
        return self.m_chapterNode
    elseif key == "LUA_UI_chapterTips" and self.m_chapterTaskNode then
        local function callBack()
            GuideController:call("next")
        end
        GuideController:call("setCallback", cc.CallFunc:create(callBack))
        return self.m_chapterTaskNode
    elseif key == "LUA_UI_activityPanel" and self.m_activityPanelNode then
        return self.m_activityPanelNode
    end

    if self.iconListDataTbl then
        for i, v in pairs(self.iconListDataTbl) do
            if v.guide == key then
                return v
            end
        end
    end
	return nil
end

---------------------------------- 王国集结提示Node Start ----------------------------------
function UiCompoentLuaLayer:reset_kingdomJiJie_Node()
    MyPrint("UiCompoentLuaLayer:reset_kingdomJiJie_Node")
    if not self.m_kingdomJiJie_node then
        self.m_kingdomJiJie_node = cc.Node:create()
        self.m_kingdomJiJie_node:setContentSize(cc.size(IconWidth, IconHeight))
        self:addChild(self.m_kingdomJiJie_node)
        self.m_kingdomJiJie_node:setPosition(cc.p(IconWidth*0.5, IconHeight*0.5));
        self.m_kingdomJiJie_node:setAnchorPoint(cc.p(0.5, 0.5));

        local bg = CCLoadSprite:createSprite("icon_BG.png")
        self.m_kingdomJiJie_node:addChild(bg)
        bg:setPosition(cc.p(IconWidth*0.5, IconHeight*0.5))
        bg:setScale(0.63)

        local iconSpr = CCLoadSprite:createSprite("allianceWar.png")
        if iconSpr then
            self.m_kingdomJiJie_node:addChild(iconSpr)
            iconSpr:setPosition(cc.p(IconWidth*0.5, IconHeight*0.5))
            CCCommonUtilsForLua:setSpriteMaxSize(iconSpr, 70, true)
        end

        local timeNode = cc.Node:create()
        self.m_kingdomJiJie_node:addChild(timeNode)
        timeNode:setPosition(cc.p(IconWidth*0.5, 0))
        local bg = CCLoadSprite:call("createScale9Sprite", "technology_11.png")
        bg:setContentSize(cc.size(136, 24))
        timeNode:addChild(bg)
        local label = cc.Label:createWithSystemFont("", "Helvetica", 18, cc.size(0.0,0))
        self.m_kingdomJiJie_timeLabel = label
        timeNode:addChild(label)

        self.m_kingdomJiJie_node:setVisible(false)
    else
        return
    end
end

--飞金币动画
function UiCompoentLuaLayer:showGoldFly()
    self:removeChildByTag(66666)
    local realSize = cc.Director:getInstance():getWinSize()
    local wid = self.contentSize.width
    local height = self.contentSize.height 
    local endPos = ccp(wid-30,height+100)
   
    local startPoint =ccp(wid/2,height/2)

    local randFunc = math.random

    local toX = endPos.x
    local toY = endPos.y
    local m_flyX = startPoint.x
    local m_flyY = startPoint.y   
    local endPoint = cc.p(endPos.x, endPos.y)

    for i=0,20,1 do
        local pNode = CCNode:create()
        pNode:setPosition(startPoint)
        local angle = cc.pGetAngle(startPoint, endPoint)
        local angle2 = math.abs(angle)
        local ball = CCLoadSprite:createSprite("GoldCoin_1.png")
        pNode:addChild(ball,1000)
        local sc1 = cc.Sequence:create(cc.DelayTime:create(0.5),cc.ScaleTo:create(1, 0.3))
        local sc2 = cc.Sequence:create(cc.DelayTime:create(0.5),cc.FadeOut:create(1))
        local swp = cc.Spawn:create(sc2,sc1)
        ball:runAction(swp)

        local beziercofig = {}
        local rand = randFunc(1,100)
        if (rand%2==0) then
            beziercofig[1] = cc.p(m_flyX+randFunc(30,60),m_flyY)
            beziercofig[2] = cc.p(toX+randFunc(30,60),toY)
        else
            beziercofig[1] = cc.p(m_flyX-randFunc(30,60),m_flyY)
            beziercofig[2] = cc.p(toX-randFunc(30,60),toY)
        end
        if (angle2<15) then
            angle = 0
        else
            angle = 90-angle
        end
        local useFactor = (toY - m_flyY) / 400.0
        useFactor = math.max(useFactor, 1)

        local useTime = 0.5 + i * 0.08
        beziercofig[3] = endPoint
        local forward = cc.BezierTo:create(useTime, beziercofig)
        forward = tolua.cast(forward, "cc.ActionInterval")
        local s1 = cc.Sequence:create(forward ,cc.DelayTime:create(0.05))
        local s2 = cc.Sequence:create(cc.RotateTo:create(useTime*0.7, angle))
        local sp = cc.Spawn:create(s1,s2)
        pNode:runAction(sp)
        self:addChild(pNode)
        pNode:setTag(66666)
    end
end

--登陆游戏后客户端主动向服务器拉取数据
function UiCompoentLuaLayer:AFLoginGMReqData()
    self.reqData_lock = true
    --阵法数据
    if CCCommonUtilsForLua:isFunOpenByKey("aormation") then        
        TacticalDepController.getInstance():reqData()
    end
    --联盟求援
    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
    if CCCommonUtilsForLua:isFunOpenByKey("alliance_help") and playerInfo:call("isInAlliance") and not isCrossServerNow() then
        require("game.alliance.AllianceAFHController").getInstance():reqPlayerAFHData()
    end
    --巨龙演武场
    if CCCommonUtilsForLua:isFunOpenByKey("wa_arms_drill_field") then
        DragonWarmUpManager:reqBattleLimitInfo()
    end
end

--传送门开启后的UI显示
function UiCompoentLuaLayer:showPortalTips()
    local node = Drequire("game.FestivalActivities.kingdomTrans.KingdomTransUINode"):create()
    if node then
        self:removeChildByTag(2525)
        self:addChild(node)
        node:setTag(2525)
        local size = self:getContentSize()
        node:setPosition(ccp(size.width/2,size.height))
    end
end

function UiCompoentLuaLayer:onCheckShowWorldBossComingAni()
    local view = Drequire("game.UIComponent.WorldBossComingAniView"):create()
    -- PopupViewController:addPopupView(view)
    if view then
        self:addChild(view)
    end
end

return UiCompoentLuaLayer





