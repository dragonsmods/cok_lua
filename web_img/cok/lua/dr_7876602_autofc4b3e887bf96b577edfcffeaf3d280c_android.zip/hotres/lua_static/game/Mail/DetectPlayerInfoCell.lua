local DetectPlayerInfoCell = class("DetectPlayerInfoCell", function()
    return cc.Layer:create()
end)

DetectPlayerInfoCell.__index = DetectPlayerInfoCell
function DetectPlayerInfoCell:create(mailUid, clickArea)
    local ret = DetectPlayerInfoCell.new()
    if ret:init(mailUid, clickArea) == false then
    	return nil
    end
    return ret
end

function DetectPlayerInfoCell:init(mailUid, clickArea)
    self.m_mailUid = mailUid
    self.m_clickArea = clickArea
    local mailInfo = MailController:call("getMailInfoByMailUid", self.m_mailUid)
    if mailInfo == nil then
        MyPrint("DetectMailPopupView:init get mail info fail")
        return false
    end

	--初始化界面
	MyPrint("DetectPlayerInfoCell init start")
	local proxy = cc.CCBProxy:create()
	local ccbiURL = ""
	ccbiURL = "ccbi/NEW_DetectPlayerCell.ccbi"
    if CCCommonUtilsForLua:isIosAndroidPad() then
        ccbiURL = "hdccbi/NEW_DetectPlayerCell.ccbi"
    end
  	local nodeccb = CCBReaderLoad(ccbiURL,proxy, self)
	if nodeccb == nil then
		MyPrint("DetectPlayerInfoCell loadccb error")
		return false
	end

	self:setContentSize(nodeccb:getContentSize())
	self:addChild(nodeccb)
    registerTouchHandler(self)
    self:setTouchEnabled(true)

	self:refreshView()
	return true
end

function DetectPlayerInfoCell:refreshView()
    MyPrint("DetectPlayerInfoCell:refreshView")
    local mailInfo = MailController:call("getMailInfoByMailUid", self.m_mailUid)
    if mailInfo == nil then
        MyPrint("DetectPlayerInfoCell:refreshView get mail info fail")
        self:showFail()
        return
    end

    local pointType = mailInfo:getProperty("pointType")
    local detectReport = mailInfo:getProperty("detectReport")
    if detectReport == nil then
        MyPrint("DetectPlayerInfoCell:refreshView detectReport is nil")
        self:showFail()
        return
    end

    local user = detectReport:objectForKey("user")
    if user == nil then
        MyPrint("DetectPlayerInfoCell:refreshView user is nil")
        self:showFail()
        return
    end

    if user:objectForKey("serverType") then
        mailInfo:setProperty("serverType", tonumber(user:valueForKey("serverType"):getCString()))
    end

    local pic = ""
    if pointType == WorldCityType.Throne or pointType == WorldCityType.Trebuchet or 
        pointType == WorldCityType.Tile_allianceArea or pointType == WorldCityType.tile_flagsbuilding or
        pointType == WorldCityType.tile_Cannon or pointType == WorldCityType.KingdomMiracle
        or pointType ==  WorldCityType.tile_hospital
    then
        pic = "Mail_darksoil.png"
    else
        pic = "Mail_zhencha_succeed.png"
    end

    self.m_battlePicNode:removeAllChildren()
    local spr = CCLoadSprite:call("createSprite", pic)
    self.m_battlePicNode:addChild(spr)
    MyPrint("DetectPlayerInfoCell "..tostring(user:valueForKey("noDef"):intValue()))
    if user:objectForKey("noDef") and user:valueForKey("noDef"):intValue() == 1 then --联盟建筑无防守者
        local picPath = ""
        if pointType == WorldCityType.Tile_allianceArea then
            picPath = "territory_building_lv0.png"
        elseif pointType == WorldCityType.tile_flagsbuilding then
            picPath = "alliance_flag.png"
        elseif pointType == WorldCityType.tile_Cannon then
            picPath = "alliance_cannon.png"
        elseif pointType == WorldCityType.tile_hospital then
            picPath = "territory_hospital0.png"
        end

        local picCircleSpr = PicCircleSprite:call("create", picPath, -1, "")
        self.m_playHeadNode:addChild(picCircleSpr)

        local nameStr = ""
        if user:objectForKey("abbr") and user:valueForKey("abbr"):getCString() ~= "" then
            nameStr = nameStr.."("..user:valueForKey("abbr"):getCString()..")"
        end
        local nameTemp = ""
        if user:objectForKey("name") then
            nameTemp = user:valueForKey("name"):getCString()
        end

        if nameTemp ~= "" then
            nameStr = nameStr..nameTemp
        else
            if pointType == WorldCityType.Tile_allianceArea then
                if user:objectForKey("count") then
                    nameStr = nameStr..getLang("115312", user:valueForKey("count"):getCString())
                else
                    nameStr = nameStr..getLang("115312", "1")
                end
            elseif pointType == WorldCityType.tile_flagsbuilding then
                nameStr = nameStr..getLang("115534")
            elseif pointType == WorldCityType.tile_Cannon then
                nameStr = nameStr..getLang("164147")
            elseif pointtype == WorldCityType.tile_hospital then
                nameStr = nameStr..getLang("4501000")
            end
        end

        self.m_playName:setString(nameStr)
    else
        local picPath = user:valueForKey("pic"):getCString()
        local picVer = tonumber(user:valueForKey("picVer"):getCString())
        local uid = user:valueForKey("uid"):getCString()
        if pointType == WorldCityType.Barbarian then
            local barbarianId = detectReport:valueForKey("barbarionConfigId"):getCString()
            picPath = CCCommonUtilsForLua:call("getPropById", barbarianId, "head")..".png"
        end
        local picCircleSpr = PicCircleSprite:call("create", picPath, picVer, uid)
        self.m_playHeadNode:addChild(picCircleSpr)

        local nameStr = user:valueForKey("name"):getCString()
        local abbr = user:valueForKey("abbr"):getCString()
        if abbr ~= "" then
            nameStr = "("..abbr..")"..nameStr
        end

        if pointType == WorldCityType.Barbarian then
            local barbarianId = detectReport:valueForKey("barbarionConfigId"):getCString()
            nameStr = CCCommonUtilsForLua:call("getNameById", barbarianId)
        end
        if user:objectForKey("lv") then
            local level = user:valueForKey("lv"):getCString()
            nameStr = nameStr.." Lv."..level
        end
        self.m_playName:setString(nameStr)
    end

    if user:objectForKey("pointId") then
        local pos = tonumber(user:valueForKey("pointId"):getCString())
        local pt = WorldController:call("getPointByIndex", pos)
        if mailInfo:getProperty("serverType") >= ServerType.SERVER_BATTLE_FIELD then
            local mapType = WorldController:call("getMapTypeByServerType", mailInfo:getProperty("serverType"))
            pt = WorldController:call("getPointByMapTypeAndIndex", pos, mapType)
        end

        local posStr = "X:"..tostring(pt.x).." ".."Y:"..tostring(pt.y)
        self.m_playPoint:setString(posStr)
    end

    self.m_failNode:setVisible(false)
end

function DetectPlayerInfoCell:showFail()
    self.m_palyInfoNode:setVisible(false)
    self.m_failText:setString(getLang("114005"))
end

function DetectPlayerInfoCell:onTouchBegan(x, y)
    self.m_startX = x
    self.m_startY = y
    if touchInside(self.m_posBG, x, y) and touchInside(self.m_clickArea, x , y) then
        return true
    else
        return false
    end
end

function DetectPlayerInfoCell:onTouchMoved(x, y)
end

function DetectPlayerInfoCell:onTouchEnded(x, y)
    if math.abs(x - self.m_startX) > 20 or math.abs(y - self.m_startY) > 20 then
        return
    end
    if touchInside(self.m_posBG, x, y) and touchInside(self.m_clickArea, x , y) then
        local mailInfo = MailController:call("getMailInfoByMailUid", self.m_mailUid)
        if mailInfo == nil then
            return
        end

        local pointType = mailInfo:getProperty("pointType")
        local detectReport = mailInfo:getProperty("detectReport")
        if detectReport == nil then
            return
        end

        local user = detectReport:objectForKey("user")
        if user == nil then
            return
        end

        MailController:call("stopReturnToChat")
        local pos = tonumber(user:valueForKey("pointId"):getCString())
        WorldController:call("getInstance"):setProperty("openTargetIndex", pos) 
        local pt = WorldController:call("getPointByIndex", pos)
        if mailInfo:getProperty("serverType") >= ServerType.SERVER_BATTLE_FIELD then
            local mapType = WorldController:call("getMapTypeByServerType", mailInfo:getProperty("serverType"))
            pt = WorldController:call("getPointByMapTypeAndIndex", pos, mapType)
            if GlobalData:call("shared"):getProperty("serverType") < ServerType.SERVER_BATTLE_FIELD then
                YesNoDialog:show(getLang("140195"), nil)
            end
        end

        if user:objectForKey("serverId") then
            GlobalData:call("shared"):getProperty("playerInfo"):setProperty("currentServerId", user:valueForKey("serverId"):intValue())
        end

        local sceneId = SceneController:call("getCurrentSceneId")
        if sceneId == 11 then
            WorldMapView:call("instance"):call("gotoTilePoint", pt)
        else
            local index = WorldController:call("getIndexByPoint", pt)
            SceneController:call("gotoScene", 11, false, true, index)
        end

        PopupViewController:call("forceClearAll", true)
    end
end

return DetectPlayerInfoCell
