--[[
	部队控制类
	2018.5.28	Awen
]]

ArmyController = ArmyController or {}

local CMD_GETDATA = 'soldierStren.getStrenView'
local CMD_UP = 'soldierStren.stren'
-------------------------------------------- 升级界面数据 --------------------------------------------
local ArmyUpgradeCmd = class("ArmyUpgradeCmd", LuaCommandBase)
function ArmyUpgradeCmd.create(sourceArmyId, targetArmyId, trainNum, isGoldCleanCD)
    Dprint("ArmyUpgradeCmd.create")
    local ret = ArmyUpgradeCmd.new()
    ret:initWithName("army.upgrade")
    ret:putParam("sourceArmyId", CCString:create(tostring(sourceArmyId)))
    ret:putParam("targetArmyId", CCString:create(tostring(targetArmyId)))
    ret:putParam("trainNum", CCInteger:create(tonumber(trainNum)))
    ret:putParam("isGoldCleanCD", CCBool:create(isGoldCleanCD))

    ret.m_armyId = targetArmyId
    ret.m_sourceId = sourceArmyId
    ret.isGoldCleanCD = isGoldCleanCD
    ret.m_num = trainNum
    return ret
end

function ArmyUpgradeCmd:handleReceive(dict)
   local tbl = dictToLuaTable(dict)   
    local cmdname = dict:valueForKey("cmd"):getCString()
    if cmdname ~= "army.upgrade" then
        return
    end
    local params = dict:objectForKey("params")
    if nil == params then
        Dprint("ArmyUpgradeCmd:handleReceive params is nil")
        return
    end
    params = tolua.cast(params, "CCDictionary")
    local tbl = dictToLuaTable(params)   
    if nil ~= tbl.errorCode and tbl.errorCode ~= "" then
        LuaController:flyHint("", "", getLang(tbl.errorCode))
        return
    end

    -- 处理数据
	local armylist = GlobalData:call("shared"):getProperty("armyList") 
	if armylist[self.m_armyId] == nil then return true end
	if armylist[self.m_sourceId] == nil then return true end
	local armyInfo = armylist[self.m_armyId]
	local sourceInfo = armylist[self.m_sourceId]

	if self.isGoldCleanCD then
		local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
		if params:objectForKey("errorCode") ~= nil then
			local errorCode = params:valueForKey("errorCode"):getCString()
			MyPrint("ArmyUpgradeCmd:handleReceive ... errorCode .. " .. errorCode)
			if (CCCommonUtilsForLua:call("isAllowShowHandleRecieveErrorDialog", errorCode)) then
				CCCommonUtilsForLua:call("flyText", getLang(errorCode))
			end
			--如果失败，把加的减回去
			local armyPower = playerInfo:getProperty("armyPower")
			local addPower = playerInfo:getProperty("addPower")
			playerInfo:setProperty("armyPower", armyPower - addPower)
		else	
			--兵数量
			local free = params:valueForKey("free"):intValue()
			armyInfo:setProperty("free", free)
			armyInfo:setProperty("finishTime", 0)

			local sourceFree = params:valueForKey("sourceFreeArmyNum"):intValue()
			sourceInfo:setProperty("free", sourceFree)
			sourceInfo:setProperty("finishTime", 0)

			-- 添加主界面收兵通知
			local icon = armyInfo:call("getBodyIcon")
			local name = armyInfo:call("getName")
			if CCSpriteFrameCache:sharedSpriteFrameCache():spriteFrameByName(icon) then
				local index = math.floor(self.m_armyId / 100) - 1070 + 200
				CCLoadSprite:call("doResourceByCommonIndex", index, true)
				CCCommonUtilsForLua:call("flyHint", icon, getLang("103673"), getLang("103674", name))
				CCLoadSprite:call("doResourceByCommonIndex", index, false)
			else
				CCCommonUtilsForLua:call("flyHint", getLang("103673"), getLang("103674", name))
			end

			--金币
			if (params:objectForKey("gold")) then
				local tmpInt = params:objectForKey("gold"):intValue()
				UIComponent:call("updateGold", tmpInt)
			end

			-- 资源
			local resourceInfo = GlobalData:call("shared"):getProperty("resourceInfo")
			resourceInfo:call("setResourceData", params)

			--post消息
			CCSafeNotificationCenter:postNotification(ARMY_NUM_CHANGE)
			CCSafeNotificationCenter:postNotification(MSG_UPDATE_ARMY_DATA)
			CCSafeNotificationCenter:postNotification(MSG_QUICK_TROOPS_HARVEST)
		end
		-- 战力增量重置
		playerInfo:setProperty("addPower", 0)
	else
		--金币
		if (params:objectForKey("gold")) then
			local tmpInt = params:objectForKey("gold"):intValue()
			UIComponent:call("updateGold", tmpInt)
		end

		-- 资源
		local resourceInfo = GlobalData:call("shared"):getProperty("resourceInfo")
		resourceInfo:call("setResourceData", params)

		--兵数量
		params:setObject(CCString:create(tostring(self.m_num)), "train")
		armyInfo:call("setFinishiTime", params)

		local sourceFree = params:valueForKey("sourceFreeArmyNum"):intValue()
		sourceInfo:setProperty("free", sourceFree)
		
		--队列
		local queue = params:objectForKey("queue")
		QueueController:call("addQueueInfo", queue)
	end
	
    CCSafeNotificationCenter:postNotification("ArmyUpgrade_back", params)
end

-------------------------------------------- 获取升级界面数据 --------------------------------------------
local ArmyUpgradeGetDataCmd = class("ArmyUpgradeGetDataCmd", LuaCommandBase)
function ArmyUpgradeGetDataCmd.create(sourceArmyId)
    Dprint("ArmyUpgradeGetDataCmd.create")
    local ret = ArmyUpgradeGetDataCmd.new()
    ret:initWithName("army.upgradeInfo")
    ret:putParam("sourceArmyId", CCString:create(tostring(sourceArmyId)))
    return ret
end

function ArmyUpgradeGetDataCmd:handleReceive(dict)
   local tbl = dictToLuaTable(dict)   
    dump(tbl,'ArmyUpgradeGetDataCmd:handleReceive')
    local cmdname = dict:valueForKey("cmd"):getCString()
    if cmdname ~= "army.upgradeInfo" then
        return
    end
    local params = dict:objectForKey("params")
    if nil == params then
        Dprint("ArmyUpgradeGetDataCmd:handleReceive params is nil")
        return
    end
    params = tolua.cast(params, "CCDictionary")
    local tbl = dictToLuaTable(params)   
    if nil ~= tbl.errorCode and tbl.errorCode ~= "" then
        LuaController:flyHint("", "", getLang(tbl.errorCode))
    end

    CCSafeNotificationCenter:postNotification("ArmyUpgrade_getInfo_back", params)
end


-------------------------------------------- 获取强化界面数据 --------------------------------------------
local ArmyUpGetDataCmd = class("ArmyUpGetDataCmd", LuaCommandBase)
function ArmyUpGetDataCmd.create()
    Dprint("ArmyUpGetDataCmd.create")
    local ret = ArmyUpGetDataCmd.new()
    ret:initWithName(CMD_GETDATA)
    return ret
end

function ArmyUpGetDataCmd:handleReceive(dict)
   local tbl = dictToLuaTable(dict)   
    dump(tbl,'ArmyUpGetDataCmd:handleReceive')
    local cmdname = dict:valueForKey("cmd"):getCString()
    if cmdname ~= CMD_GETDATA then
        return
    end
    local params = dict:objectForKey("params")
    if nil == params then
        Dprint("ArmyUpGetDataCmd:handleReceive params is nil")
        return
    end
    params = tolua.cast(params, "CCDictionary")
    local tbl = dictToLuaTable(params)   
    if nil ~= tbl.errorCode and tbl.errorCode ~= "" then
        LuaController:flyHint("", "", getLang(tbl.errorCode))
        return
    end

    ArmyController:ackOpenUiData(tbl)
end
-------------------------------------------- 强化 --------------------------------------------
local ArmyUpCmd = class("ArmyUpCmd", LuaCommandBase)
function ArmyUpCmd:create(armyType)
    Dprint("ArmyUpCmd.create",armyType)
    local ret = ArmyUpCmd.new()
    ret:initWithName(CMD_UP)
    ret:putParam("armyType", CCInteger:create(armyType))
    self._armyType = armyType
    return ret
end

function ArmyUpCmd:handleReceive(dict)
   local tbl = dictToLuaTable(dict)   
    dump(tbl,'ArmyUpCmd:handleReceive')
    local cmdname = dict:valueForKey("cmd"):getCString()
    if cmdname ~= CMD_UP then
        return
    end
    local params = dict:objectForKey("params")
    if nil == params then
        Dprint("ArmyUpCmd:handleReceive params is nil")
        return
    end
    params = tolua.cast(params, "CCDictionary")
    local tbl = dictToLuaTable(params)   
    if nil ~= tbl.errorCode and tbl.errorCode ~= "" then
        LuaController:flyHint("", "", getLang(tbl.errorCode))
        return
    end

    ArmyController:ackArmyUp(self._armyType, tbl)
end


-------------------------------------------- ArmyController --------------------------------------------
-- 请求基础数据
function ArmyController:reqOpenUiData(  )
	if self._mainCityLimit and self._mainCityLimit <= FunBuildController:call("getMainCityLv") then
		local cmd = ArmyUpGetDataCmd.create()
		cmd:send()
	end
end

-- 处理基础数据
function ArmyController:ackOpenUiData( data )
	dump(data, 'ArmyController:ackOpenUiData')
	if data then
		for k,v in pairs(data.array) do
			dump(v.strenArray, 'ArmyController:ackOpenUiData 1')
			local armyType = tonumber(v.armyType)
			if self._dataBase[armyType] then
				self._dataOther[armyType].totalExp = tonumber(v.exp) or 0
				self._dataOther[armyType].upTimes = tonumber(v.strenTimes) or 0

				for _,v1 in pairs(self._dataBase[armyType]) do
					for i=1,#v.strenArray do
						if v1.skillId==v.strenArray[i].id then
							v1.curLv = tonumber(v.strenArray[i].level)
							v1.oldLv = v1.curLv
						end
					end
				end
				
				dump(self._dataBase, 'ArmyController:ackOpenUiData _dataBase')
				dump(self._dataOther, 'ArmyController:ackOpenUiData _dataOther')

				CCSafeNotificationCenter:call("postNotification", "ArmyUpCell.refresh")	
			end
		end

		self._cacheData = true
	end
end

--是否有缓存后台数据
function ArmyController:cacheData()
	return self._cacheData
end

-- 请求强化
function ArmyController:reqArmyUp( armyType )
	local cmd = ArmyUpCmd:create(armyType)
	cmd:send()
end

-- 处理强化
function ArmyController:ackArmyUp( armyType,data )
	dump(data, 'ArmyController:ackArmyUp  '..armyType)
	if data then
		self._dataOther[armyType].totalExp = tonumber(data.exp) or 0
		self._dataOther[armyType].upTimes = tonumber(data.strenTimes) or 0

		self._dataOther[armyType].crit = data.crit
		self._dataOther[armyType].critMult = data.critMult

		if data.id and data.level then
			local pos = 0
			for k,v in pairs(self._dataBase[armyType]) do
				Dprint('ArmyController:ackArmyUp  ',v.skillId,data.id)
				if v.skillId==data.id then
					pos = k
					v.oldLv = v.curLv
					v.curLv = tonumber(data.level)
					break
				end
			end
		
			self._effectTable = {}
			for k,v in pairs(data.soldStrEffs) do
				self._effectTable[v.effectId] = tonumber(v.effect) or 0
			end
			dump(self._dataBase, 'ArmyController:ackArmyUp _dataBase pos='..pos)
			dump(self._effectTable, 'ArmyController:ackArmyUp _effectTable pos='..pos)
			CCSafeNotificationCenter:call("postNotification", "ArmyUpView.setIsAnim", CCInteger:create(1))
			CCSafeNotificationCenter:call("postNotification", "ArmyUpCell.animArmyUp", CCInteger:create(pos))
		else
			CCSafeNotificationCenter:call("postNotification", "ArmyUpCell.refresh")	
		end
	end
end

-- 配置item值
function ArmyController:initConfig( dict )
	self:initData()

	Dprint('ArmyController:initConfig 1')
	if dict == nil then
		return
	end

	-- dump(dictToLuaTable(dict),'ArmyController:initConfig. afdasf')
	local dataConfig = dict:objectForKey("dataConfig")
    if dataConfig then
        dataConfig = tolua.cast(dataConfig, "CCDictionary")
        if dataConfig then
			local army_up = dataConfig:objectForKey('army_up')
			if army_up then
				local data = dictToLuaTable(army_up)
				if data then
					dump(data, 'ArmyController:initConfig 2')
					self._mainCityLimit = tonumber(data.k4)	or 0	-- k4=主城限制等级
					self._trueCritTime = tonumber(data.k2) or 0		-- 必暴击次数
				end
			end

			-- 升级
			local amryUpgrade = dataConfig:objectForKey('army_upgrade')
			if amryUpgrade then
				local data = dictToLuaTable(amryUpgrade)
				dump(data , "cjy data ")
				if data and data.k1 and data.k2 and data.k3 then
					self.m_timeUpgradeMulty = data.k1
					self.m_resourceUpgradeMulty = data.k2
					self.m_fineIronUpgradeMulty = data.k3	
				end
			end
		end
	end	
	local playerInfo = dict:objectForKey('playerInfo')
	if playerInfo then
		local data = tolua.cast(playerInfo, "CCDictionary")
		if data then
			data = dictToLuaTable(data)
			if data then
				if data.soldStrEffs then
					self._effectTable = {}
					for k,v in pairs(data.soldStrEffs) do
						self._effectTable[v.effectId] = tonumber(v.effect) or 0
					end
					dump(self._effectTable, 'ArmyController:initConfig _effectTable')
				end
			end
		end
	end

	local ancient_army_list = dict:objectForKey("ancient_army_list")
	if ancient_army_list then
		ancient_army_list = tolua.cast(ancient_army_list, "CCArray")

		ancient_army_list = arrayToLuaTable(ancient_army_list)
		dump(ancient_army_list, "ancient_army_list")

		self.ancient_army_list = { }
		for k, v in ipairs(ancient_army_list) do
			self.ancient_army_list[v.armyId] = atoi(v.num)
		end
	end

	self._cacheData = false
end

function ArmyController:getTrueCritTime()
	return self._trueCritTime or 10
end

function ArmyController:initData(  )
	Dprint('ArmyController:initData')
	-- -------------------------------- base
	self._dataBase = {}
	local tableBase = CCCommonUtilsForLua:getGroupByKey("army_up_base")
	for k,v in pairs(tableBase) do
		local armyType = tonumber(v.army)
		if self._dataBase[armyType]==nil then
			self._dataBase[armyType] = {}
		end
		if v.position then
			position = tonumber(v.position)
			self._dataBase[armyType][position] = {skillId=v.id, maxLv=tonumber(v.level_max), curLv=0, on=v.on, rate=tonumber(v.rate), icon=v.icon, dialog_all=v.dialog_all, dialog_rate=v.dialog_rate, effect=v.effect}
		end
	end
	-- dump(self._dataBase, 'ArmyController:initData _dataBase')


	-- -------------------------------- effect
	self._dataEffect = {}
	local tableEffect = CCCommonUtilsForLua:getGroupByKey("army_up_effect")
	-- dump(tableEffect, 'ArmyController:initData tableEffect')
	for k,v in pairs(tableEffect) do
		if self._dataEffect[v.skill_id]==nil then
			self._dataEffect[v.skill_id] = {}
		end
		if v.level then
			self._dataEffect[v.skill_id][tonumber(v.level)] = {effect=v.effect}
		end
	end
	-- dump(self._dataEffect, 'ArmyController:initData _dataEffect')


	-- -------------------------------- reward
	self._dataReward = {}
	local tableReward = CCCommonUtilsForLua:getGroupByKey("army_up_reward")
	-- dump(tableReward, 'ArmyController:initData tableReward')
	for k,v in pairs(tableReward) do
		local armyType = tonumber(v.army)
		if self._dataReward[armyType]==nil then
			self._dataReward[armyType] = {}
		end 

		table.insert(self._dataReward[armyType], {minLv=tonumber(v.total_start), maxLv=tonumber(v.total_end), effect=v.effect, dialog=v.effect_dialog})
	end
	-- dump(self._dataReward, 'ArmyController:initData _dataReward before ')
	for k,v in pairs(self._dataReward) do
		table.sort(self._dataReward[k], function (a, b)
        	return a.minLv < b.minLv
        end)
	end
	-- dump(self._dataReward, 'ArmyController:initData _dataReward after ')


	-- -------------------------------- whole
	self._dataWhole = {}
	local tableWhole = CCCommonUtilsForLua:getGroupByKey("army_up_whole")
	-- dump(tableWhole, 'ArmyController:initData tableWhole')
	for k,v in pairs(tableWhole) do
		if v.level_sum then
			self._dataWhole[tonumber(v.level_sum)] = {exp=tonumber(v.exp), cost=v.cost, step=tonumber(v.step), roll=v.roll}
		end
	end
	-- dump(self._dataWhole, 'ArmyController:initData _dataWhole')	

	-- -------------------------------- whole
	self._dataOther = {}

	-- 其他数据初始化
	for k,v in pairs(self._dataBase) do
		self._dataOther[k] = {
			totalExp=0, 	-- 当前总经验
			upTimes=0,		-- 强化次数	
			crit=false,		-- 是否暴击，true-是，false-否
			critMult=0		-- 暴击倍率
		}
	end
	-- dump(self._dataOther, 'ArmyController:initData _dataOther')	
end

-- 获取作用号对应的效果值
function ArmyController:getEffectValueByNum( num )
	if num == nil or num < 0 then 
		Dprint('[error]ArmyController:getEffectValueByNum :num is nil or < 0 | ', num)
		return 0
	end

	if CCCommonUtilsForLua:isFunOpenByKey('army_up') then
		if self._effectTable then
			local value = self._effectTable[tostring(num)] or 0
			-- Dprint('ArmyController:getEffectValueByNum',num,value)
			return value
		end
	end
	
	return 0
end

-- 获取base数据
function ArmyController:getDataBase( armyType )
	if self._dataBase then
		return self._dataBase[armyType]
	end

	return nil
end
--[[
	获取按钮图标名称
	max: 最大个数
]] 
function ArmyController:getIconName( armyType, max )
	-- self:initData()
	Dprint('ArmyController:getIconName', armyType, max)
	local icons = {}

	for i=1,max do
		if self._dataBase[armyType][i - 1] and self._dataBase[armyType][i - 1].icon and self._dataBase[armyType][i - 1].on=='1' then
			table.insert(icons, self._dataBase[armyType][i - 1].icon..'.png')
		else
			table.insert(icons, 'img_lock.png')
		end
	end

	return icons
end

-- 获取中间图名称，用当前兵种解锁的最高等级兵种图
function ArmyController:getPicName( buildId )
	local buildingKey = FunBuildController:call("getMaxLvBuildByType", buildId)
	-- Dprint('ArmyController:getPicName', buildId, buildingKey)
	local buildInfo = FunBuildController:call("getFunbuildForLua", buildingKey)
	local armies = buildInfo:getProperty("open_arms")
	local armyIds = ArmyController:call("getInstance"):call("getCreateSoldierIds",armies, false)


	local buildingStarLv = buildInfo:getProperty("starNum")
	local buildingLevel = buildInfo:getProperty("level") + buildingStarLv
	local pos = 0
	local maxOpenLevel = 0
	for index = #armyIds,1, -1 do
		local curIds = armyIds[index]
		local armyList = GlobalData:call("shared"):getProperty("armyList")
		local ainfo = armyList[curIds]
		local getLockLevel = ainfo:getProperty("unlockLevel")
		if buildingLevel >= getLockLevel and getLockLevel >= maxOpenLevel then
			pos = index
			maxOpenLevel = getLockLevel
		end
	end
	
	if buildingKey > 1000 then
		local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
		local key = playerInfo:getProperty("uid").."_"..CC_ITOA(math.floor(buildingKey/1000))
		local defSoldier = CCUserDefault:sharedUserDefault():getStringForKey(key, "")

		if defSoldier ~= "" then
			local i = #armyIds
			while i > 1 do
				if defSoldier == armyIds[i] then
					pos = i

				end
				i = i - 1
			end
			if pos <= 0 then
				pos = 1
			end
		end
	end
	local armyId = armyIds[pos]


	local info = GlobalData:call("getArmyInfoById", armyId)
	return tostring(info:call("getBodyIcon"))
end

-- 获取总等级
function ArmyController:getTotalLv( armyType )
	if self._dataBase[armyType] then
		local totalCurLv = 0
		local totalMaxLv = 0
		for k,v in pairs(self._dataBase[armyType]) do
			totalCurLv = totalCurLv + v.curLv
			totalMaxLv = totalMaxLv + v.maxLv
		end
		if totalCurLv<totalMaxLv then
			return totalCurLv,totalCurLv+1
		end
		return totalCurLv,totalMaxLv
	end
	return 0,1
end


-- 获取奖励信息
function ArmyController:getReward( armyType,totalCurLv )
	if self._dataReward[armyType] then
		dump(self._dataReward[armyType], 'ArmyController:getReward '..armyType)
		for _,v in pairs(self._dataReward[armyType]) do
			if totalCurLv<v.minLv then
				return v.dialog,v.minLv
			end
		end
	end

	return nil
end

-- 获取对应等级的effect数组
function ArmyController:getRewardEffect( armyType,totalCurLv )
	if self._dataReward[armyType] then
		-- dump(self._dataReward[armyType], 'ArmyController:getReward '..armyType)
		for _,v in pairs(self._dataReward[armyType]) do
			if totalCurLv>=v.minLv and totalCurLv<=v.maxLv then
				local data = {}
				local list = string.split(v.effect, '|')
				if list then
					for _,v in ipairs(list) do
						local item = string.split(v, ';')
						if item and #item==2 then
							data[item[1]] = item[2]
						end
					end
				end
				return data
			end
		end
	end

	return nil
end

-- 获取作用号dialog
function ArmyController:getEffect( skillId,curLv )
	Dprint('ArmyController:getEffect',skillId,curLv)
	if self._dataEffect then
		return self._dataEffect[skillId][curLv]
	end

	return nil
end

-- 获取经验和花费
function ArmyController:getExpCost( armyType,totalCurLv )
	if self._dataWhole and self._dataWhole[totalCurLv] and self._dataOther and self._dataOther[armyType] then
		local totalExp = self._dataOther[armyType].totalExp
		local cost = self._dataWhole[totalCurLv].cost
		local costExtra = self._dataOther[armyType].upTimes*self._dataWhole[totalCurLv].step
		return totalExp,self._dataWhole[totalCurLv].exp,cost,costExtra, self._dataOther[armyType].upTimes
	end

	return nil
end


-- 获取暴击
function ArmyController:getCritData( armyType )
	if self._dataOther and self._dataOther[armyType] then
		return self._dataOther[armyType].crit,self._dataOther[armyType].critMult
	end
	return nil
end

-- 清空暴击数据
function ArmyController:resetCritData( armyType )
	if self._dataOther and self._dataOther[armyType] then
		self._dataOther[armyType].crit = false
		self._dataOther[armyType].critMult = 0
	end
end

-- 处理C++调用
function ArmyController:fireEventRef( key, data )
	Dprint('ArmyController:fireEventRef', key)
	
	if key=='hasGem' then	--是否有宝石
		if self._dataWhole then
			for k,v in pairs(self._dataWhole) do
				if v and v.cost then
					local list = string.split(v.cost, ';')
					if list and #list==2 then
						local toolInfo = ToolController:call("getToolInfoByIdForLua", tonumber(list[1]))
						if toolInfo:call("getCNT")>0 then
							data:setObject(CCString:create("1"), "state")
						end
						return
					end
				end
			end
		end
	elseif key == "isOpen" then	--是否显示按钮
		local mainCityLv = FunBuildController:call("getMainCityLv")
		if self._mainCityLimit and mainCityLv >= self._mainCityLimit then
			data:setObject(CCString:create("1"), "state")
		end

	elseif key=='openUI' then	--打开界面
		data = dictToLuaTable(data)
		dump(data, 'ArmyController:onArmyUp')
		local mainCityLv = FunBuildController:call("getMainCityLv")
		Dprint('ArmyController:fireEventRef mainCityLv', mainCityLv, self._mainCityLimit)
		if self._mainCityLimit and mainCityLv < self._mainCityLimit then
			-- 101603=城堡等级达到{0}解锁该功能
			CCCommonUtilsForLua:call("flyHint", "", "", getLang("101603",self._mainCityLimit))
		else
			local view = Drequire("game.army.ArmyUpView").create(data.buildType)
    		PopupViewController:call("addPopupInView", view)
		end

	end
end

function ArmyController:getUpgradeInfo( armyId )
	local cmd = ArmyUpgradeGetDataCmd.create(armyId)
	cmd:send()
end

function ArmyController:armyUpgrade( sourceId, targetId, soldierNum, isClean )
	local cmd = ArmyUpgradeCmd.create(sourceId, targetId, soldierNum, isClean)
	cmd:send()
end

function ArmyController:syncAncientArmy(data)
	if self.ancient_army_list then
		if self.ancient_army_list[data.armyId] then
			self.ancient_army_list[data.armyId] = self.ancient_army_list[data.armyId] + atoi(data.changeNum)
		end
	end
end

function ArmyController:getArmyNumByMix(mixType)
	local num = 0
	for armyId, count in pairs(self.ancient_army_list or { } ) do
		local mix_numtype = CCCommonUtilsForLua:call("getPropByIdGroup", "arms", armyId, "mix_numtype")
		if mix_numtype == mixType then
			num = num + count
		end
	end

	return num
end

function ArmyController:purge()
	self._dataWhole = nil
	self._dataOther = nil
	self._dataBase = nil
	self._dataReward = nil
	self._dataEffect = nil
	self._effectTable = nil
	self._cacheData = nil
end

return ArmyController