FindResTileViewCCB = FindResTileViewCCB or {}
ccb["FindResTileViewCCB"] = FindResTileViewCCB

local CC_ITOA = tostring
local ccud = cc.UserDefault:getInstance()

FindResTileView = class("FindResTileView", function() return PopupBaseView:call("create") end)
FindResTileView.__index = FindResTileView

local searchType = {
    WOOD                = 0,
    FOOD                = 1,
    IRON                = 2,
    STONE               = 3,
    GOLD                = 4,
    MONSTER             = 5,
    MONSTER_ORDINARY    = 6, -- 普通怪
    MONSTER_ACTIVITY    = 7, -- 活动怪
    CAMP                = 8, -- 营地
    MIRACLE_TRASURE     = 9, -- 奇迹宝藏
}

function FindResTileView:create()
    local ret = FindResTileView.new()
    if ret:initView() == false then
      return nil
    end
    return ret
end

function FindResTileView:initView()
    if (self:init(true,0) == false) then
        return false;
    end

    self:setHDPanelFlag(true);
    CCLoadSprite:call("doResourceByCommonIndex",101, true);

    local proxy = cc.CCBProxy:create()
    local ccbiUrl = "FindResTileView_lua.ccbi"
    local tmpCCB = CCBReaderLoad(ccbiUrl, proxy, self)
    self:addChild(tmpCCB)
    self:setContentSize(CCDirector:sharedDirector():getIFWinSize())
    self:call("setModelLayerOpacity",0)

    self.animationManager = ccb["FindResTileViewCCB"]["mAnimationManager"]
    self.m_scrollView = CCScrollView:create(cc.size(self.m_infoList:getContentSize().width+10, self.m_infoList:getContentSize().height+10))
    self.m_scrollView:setDirection(kCCScrollViewDirectionHorizontal);
    self.m_scrollView:setTouchEnabled(true)
    self.m_scrollView:setPosition(ccp(-15,0))
    self.m_infoList:addChild(self.m_scrollView)

    self.m_mosterLv = 30
    local serverOpenTime = GlobalData:call("shared"):getProperty("serverOpenTime")
    local gap = GlobalData:call("shared"):call("getTimeStamp") - serverOpenTime
    gap = gap/3600
    gap = gap/24
    for i = 9450, 9474 do
        local day = tonumber(CCCommonUtilsForLua:call("getPropById", tostring(i), "day"))
        local level = tonumber(CCCommonUtilsForLua:call("getPropById", tostring(i), "level"))
        if day then
            if gap < day then
                self.m_mosterLv = level
                break
            end
        end
    end

    local worldConfig           = GlobalData:call("shared"):getProperty("worldConfig")
    self.city_barracks_maxLevel  = worldConfig:getProperty("city_barracks_maxLevel")

    self.m_buildType = ccud:getIntegerForKey("FindResTile_Type", 6)
    self.m_canClose = true
    self.m_rect = CCLoadSprite:call("createSprite","tips_kuang_xuan.png")
    self.m_rect:setAnchorPoint(ccp(0,0))
    CCCommonUtilsForLua:call("setSpriteMaxSize", self.m_rect, 130, true)
    self.m_scrollView:addChild(self.m_rect)

    self.m_sprVec = {}
    self.m_mosterSelNode = cc.Node:create()
    self.m_mosterSelNode:setVisible(false)
    self.m_otherNode = {}
    self.m_showMonster = false
    self.m_extWidth = 0

    self.iconArr = {
        {icon = "w_res_wood.png",       type = searchType.WOOD},
        {icon = "w_res_food.png",       type = searchType.FOOD},
        {icon = "w_res_iron.png",       type = searchType.IRON},
        {icon = "w_res_stone.png",      type = searchType.STONE},
        {icon = "yingdi.png",           type = searchType.CAMP},
        {icon = "qijibaozang.png",      type = searchType.MIRACLE_TRASURE},
        {icon = "w_res_gold.png",       type = searchType.GOLD},
        {icon = "w_res_monster.png",    type = searchType.MONSTER},
    }


    local cnt = #self.iconArr
    local cellW = 100
    for i = 0, cnt - 1 do
        local iconStr = self.iconArr[i+1].icon

        local node = cc.Node:create()
        node:setPosition(ccp((i+1)*cellW+10, 0+15))       

        local bg = CCLoadSprite:call("createSprite","circle_bg_l.png")
        CCCommonUtilsForLua:call("setSpriteMaxSize", bg, 100, true)
        bg:setAnchorPoint(ccp(0, 0))
        self.m_sprVec[i] = bg
        -- bg:setPosition(ccp((i+1)*cellW+10, 0+15))
        if self.iconArr[i + 1].type == searchType.MONSTER then
            node:setPosition(ccp(10,15))

            node:addChild(self.m_mosterSelNode)
            self.m_mosterSelNode:setPosition(ccp(100,0))
            local mbg1 = CCLoadSprite:call("createSprite","circle_bg_l.png")
            CCCommonUtilsForLua:call("setSpriteMaxSize", mbg1, 40, true)
            mbg1:setAnchorPoint(ccp(0, 0))
            mbg1:setPosition(ccp(10,0))
            self.m_mosterSelNode:addChild(mbg1)
            self.m_selBg1 = mbg1

            local mIcon1 = CCLoadSprite:call("createSprite","green_yes.png")
            CCCommonUtilsForLua:call("setSpriteMaxSize", mIcon1, 40, true)
            mIcon1:setAnchorPoint(ccp(0, 0))
            mIcon1:setPosition(ccp(15,5))
            self.m_mosterSelNode:addChild(mIcon1)
            self.m_selIcon1 = mIcon1

            local mLabel1 = cc.Label:createWithSystemFont(getLang("149701"), "Helvetica", 22, cc.size(0,0)) -- 149701=普通
            mLabel1:setColor(cc.c3b(81, 50, 2))
            mLabel1:setPosition(ccp(55,20))
            mLabel1:setAnchorPoint(ccp(0,0.5))
            self.m_mosterSelNode:addChild(mLabel1)
            local w1 = mLabel1:getContentSize().width
            self.m_extWidth = w1

            local mbg2 = CCLoadSprite:call("createSprite","circle_bg_l.png")
            CCCommonUtilsForLua:call("setSpriteMaxSize", mbg2, 40, true)
            mbg2:setAnchorPoint(ccp(0, 0))
            mbg2:setPosition(ccp(10,50))
            self.m_mosterSelNode:addChild(mbg2)
            self.m_selBg2 = mbg2

            local mIcon2 = CCLoadSprite:call("createSprite","green_yes.png")
            CCCommonUtilsForLua:call("setSpriteMaxSize", mIcon2, 40, true)
            mIcon2:setAnchorPoint(ccp(0, 0))
            mIcon2:setPosition(ccp(15,55))
            self.m_mosterSelNode:addChild(mIcon2)
            self.m_selIcon2 = mIcon2

            local mLabel2 = cc.Label:createWithSystemFont(getLang("149700"), "Helvetica", 22, cc.size(0,0)) -- 149700=特殊
            mLabel2:setColor(cc.c3b(81, 50, 2))
            mLabel2:setPosition(ccp(55,70))
            mLabel2:setAnchorPoint(ccp(0,0.5))
            self.m_mosterSelNode:addChild(mLabel2)
            local w2 = mLabel2:getContentSize().width

            if w1<w2 then
                self.m_extWidth = w2
            end

            self.m_extWidth = self.m_extWidth + 60
        else
            self.m_otherNode[#self.m_otherNode+1] = node
        end
        node:addChild(bg)
        
        local buildIcon = CCLoadSprite:call("createSprite",iconStr)
        CCCommonUtilsForLua:call("setSpriteMaxSize", buildIcon, 100, true)

        buildIcon:setPosition(ccp(bg:getPositionX()+50, bg:getPositionY()+60))
        node:addChild(buildIcon)

        self.m_scrollView:addChild(node)
    end
    self.m_dataCount = cnt
    self.m_scrollView:setContentSize(cc.size(cellW*self.m_dataCount + 10, self.m_infoList:getContentSize().height))
    
    -- 设定偏移
    local offNum = 0
    local lastFindType = ccud:getIntegerForKey("FindResTile_Type", 6)
    if lastFindType == 7 then
        offNum = 0
    else
        offNum = lastFindType + 1
    end
    local function getTableOffset(num)
        local width = 0
        for i = 1, num do
            width = width + cellW
        end
        return width
    end
    local function checkOffsetRange(tableView)
        local curPos = tableView:getContentOffset()
        local minPos = tableView:minContainerOffset()
        local maxPos = tableView:maxContainerOffset()
        if curPos.x < minPos.x or curPos.y < minPos.y then
           tableView:setContentOffset(minPos)
        end
        if curPos.x > maxPos.x or curPos.y > maxPos.y then
           tableView:setContentOffset(maxPos)
        end
    end

    -- 设定上方点数偏移
    if offNum > 1 then
        local offsetWidth = getTableOffset(offNum)
        local offset = self.m_scrollView:getContentOffset()
        self.m_scrollView:setContentOffset(cc.p(offset.x - offsetWidth, offset.y))
        checkOffsetRange(self.m_scrollView)
    end

    self:initSliderBar()

    self.m_info1Label:setString(getLang("102203"))
    self.m_info4Label:setString(getLang("113232"))
    local w1 = self.m_info4Label:getContentSize().width --*self.m_info4Label:getOriginScaleX()
    local w2 = self.m_findIcon:getContentSize().width --*self.m_findIcon:getScaleX()
    local ptX = (w1+w2)/2 - w1
    self.m_info4Label:setPositionX(ptX)
    self.m_findIcon:setPositionX(ptX)
    
    local maxSearchCount = WorldController:call("getInstance"):getProperty("maxSearchCount")
    local resSearchCount = WorldController:call("getInstance"):getProperty("resSearchCount")
    local lastCnt = maxSearchCount - resSearchCount
    if lastCnt > 0 then
        self.m_info2Label:setString(getLang("113227", CC_ITOA(lastCnt)))
    else
        self.m_info2Label:setString(getLang("113227", CC_ITOA(0)))
    end
    
    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
    local vipEndTime = playerInfo:getProperty("vipEndTime")
    local curTime = GlobalData:call("shared"):call("getWorldTime")
    if CCCommonUtilsForLua:call("isFunOpenByKey", "find_vip") and vipEndTime > curTime then
        self.m_info2Label:setString(getLang("113230"))
    end
    
    local tmp = CCCommonUtilsForLua:call("getVersionName")
    if tmp == "2.6.0" then
        ccud:setBoolForKey("FindResTileOpen", false);
        ccud:flush();
    end

    local function touchHandle( eventType, x, y )
        if eventType == "began" then
            return self:onTouchBegan(x, y)
        elseif eventType == "moved" then

        else
            self:onTouchEnded(x, y)
        end
    end
    self:registerScriptTouchHandler(touchHandle)

    local function onNodeEvent( event )
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        elseif event == "cleanup" then
            self:onCleanUp()
        end
    end
    self:registerScriptHandler(onNodeEvent)
    
    return true;
end

function FindResTileView:initSliderBar()
    self.m_curLv = 1
    self.m_maxCount = 7;
    local str3 = "/";
    self.m_info3Label:setString(str3..CC_ITOA(self.m_maxCount));
    self.m_invalidSliderMove = false;

    local m_sliderBg = CCLoadSprite:call("createScale9Sprite","huadongtiao3.png");
    m_sliderBg:setInsetBottom(5);
    m_sliderBg:setInsetLeft(5);
    m_sliderBg:setInsetRight(5);
    m_sliderBg:setInsetTop(5);
    m_sliderBg:setAnchorPoint(ccp(0.5,0.5));
    m_sliderBg:setPosition(ccp(280/2, 25));
    m_sliderBg:setContentSize(cc.size(280,18));
    
    local bgSp = CCLoadSprite:call("createSprite","huadongtiao4.png");
    bgSp:setVisible(false);
    local proSp = CCLoadSprite:call("createSprite","huadongtiao4.png");
    local thuSp = CCLoadSprite:call("createSprite","huadongtiao1.png");
    
    self.m_trainSlider = CCSliderBar:call("createSlider",m_sliderBg, proSp, thuSp);
    self.m_trainSlider:setMinimumValue(0.0);
    self.m_trainSlider:setMaximumValue(1.0);
    self.m_trainSlider:call("setProgressScaleX",280/proSp:getContentSize().width);
    self.m_trainSlider:setTag(1);
    self.m_trainSlider:call("setLimitMoveValueEx",25);

    local function valueChanged(pSender)
        self:sliderCallBack()
    end
    self.m_trainSlider:addHandleOfControlEvent(valueChanged, CCControlEventValueChanged)
    self.m_sliderNode:addChild(self.m_trainSlider, 1);

    local editSize = self.m_useEditNode:getContentSize();
    local editpic = CCLoadSprite:call("createScale9Sprite","frame_3.png");
    editpic:setContentSize(editSize);
    editpic:setInsetBottom(1);
    editpic:setInsetTop(1);
    editpic:setInsetRight(1);
    editpic:setInsetLeft(1);
    self.m_editBox = CCEditBox:create(editSize,editpic);
    self.m_editBox:setInputMode(cc.EDITBOX_INPUT_MODE_NUMERIC);
    self.m_editBox:setText("0");
    self.m_editBox:setMaxLength(12);
    self.m_editBox:setReturnType(cc.KEYBOARD_RETURNTYPE_DONE);
    self.m_editBox:setPosition(ccp(editSize.width/2, editSize.height/2));
    self.m_useEditNode:addChild(self.m_editBox);

    local function editCB (strEventName,pSender)
        if tostring(pSender) == "began" then
            --光标进入，选中全部内容
            -- print("self.m_editOpen = true")
            self.m_editOpen = true
        elseif tostring(pSender) == "ended" then
            -- 当编辑框失去焦点并且键盘消失的时候被调用
        elseif tostring(pSender) == "return" then
            -- 当用户点击编辑框的键盘以外的区域，或者键盘的Return按钮被点击时所调用
            self:editBoxReturn(self.m_editBox:getText())         
        elseif tostring(pSender) == "changed" then
            -- 输入内容改变时调用
            self:editBoxTextChanged(self.m_editBox:getText())     
        end
    end
    self.m_editBox:registerScriptEditBoxHandler(editCB) --输入框的事件，主要有光标移进去，光标移出来，以及输入内容改变等
end

function FindResTileView:onEnter()
    self:call("setTouchEnabled",true)
    self:SetUpdateSliderValue()

    self.m_canClose = false
    local callback = function()
        if GuideController:call("isInTutorial") then
            GuideController:call("next")

            --【Awen】如果是搜索怪引导，强制选择怪物及配置的等级
            if CCCommonUtilsForLua:isFunOpenByKey("new_story_guide") then
                local _guideId = GuideController:call("getCurGuideID")
                local _guideArea = CCCommonUtilsForLua:call("getPropByIdGroup","guide",_guideId,"area")
                Dprint("FindResTileView:onEnter", _guideId, _guideArea)
                if _guideArea == 'LUA_search_monster' then
                    local _para = CCCommonUtilsForLua:call("getPropByIdGroup","guide",_guideId,"para1")
                    _para = tonumber(_para) or 1
                    self.m_buildType = 7
                    -- local key = "FindResTile_"..CC_ITOA(self.m_buildType)
                    local key = self:getStoreKey()
                    local value = ccud:setIntegerForKey(key, _para);
                    if self.m_showMonster then
                        self:SetUpdateSliderValue(true)
                    else
                        self:SetUpdateSliderValue()
                    end
                    self.m_selIcon1:setVisible(true)
                    self.m_selIcon2:setVisible(false)
                    self.m_scrollView:setContentOffset(cc.p(0, 0))
                end
            end
        end
        self:onAniFadeInEnd()
    end
    self.animationManager:setAnimationCompletedCallback(callback)
    self.animationManager:runAnimationsForSequenceNamed("fadeIn")
end

function FindResTileView:onExit()
    self:call("setTouchEnabled",false);
end

function FindResTileView:onCleanUp()
    CCLoadSprite:call("doResourceByCommonIndex",101, false);
end


function FindResTileView:SetUpdateSliderValue(unchangeMonster)
    self.m_maxCount = 9;

    local selectType = self.iconArr[self.m_buildType+1].type
    if selectType == searchType.GOLD then--金矿
        self.m_maxCount = 7
    elseif selectType == searchType.MONSTER then--怪
        self.m_maxCount = self.m_mosterLv;
    elseif selectType == searchType.CAMP then
        self.m_maxCount = self.city_barracks_maxLevel;
    elseif selectType == searchType.MIRACLE_TRASURE then
        self.m_maxCount = 1
    end

    local  str3 = "/";
    self.m_info3Label:setString(str3..CC_ITOA(self.m_maxCount))

    if self.m_buildType < self.m_dataCount and self.m_buildType>=0 then
        local node = self.m_sprVec[self.m_buildType]:getParent()
        self.m_rect:setPosition(ccp(node:getPositionX()-15, node:getPositionY()-15))
    end
    
    if selectType == searchType.MONSTER and unchangeMonster==nil then self:onChangeMonsterNode() end
    
    -- local key = "FindResTile_";
    -- key = key..CC_ITOA(self.m_buildType);
    self:setSliderAndEdit()
end

function FindResTileView:setSliderAndEdit()
    local key = self:getStoreKey()
    local value = ccud:getIntegerForKey(key, 1);
    if value > self.m_maxCount then
        self.m_curLv = self.m_maxCount
    else
        self.m_curLv = value
    end
    self.m_trainSlider:setValue(self.m_curLv / self.m_maxCount)
    self.m_editBox:setText(CC_ITOA(self.m_curLv))
end

function FindResTileView:getStoreKey()
    local key = "FindResTile_";
    key = key..CC_ITOA(self.m_buildType);
    local buildType = self.iconArr[self.m_buildType+1].type
    if buildType == searchType.MONSTER then
        if self.m_selIcon1:isVisible() and not self.m_selIcon2:isVisible() then
            key = key.."_1"
        elseif not self.m_selIcon1:isVisible() and self.m_selIcon2:isVisible() then
            key = key.."_2"
        end
    end
    return key
end

function FindResTileView:onFindBtnClick()
    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
    local vipEndTime = playerInfo:getProperty("vipEndTime")
    local curTime = GlobalData:call("shared"):call("getWorldTime")
    if CCCommonUtilsForLua:call("isFunOpenByKey", "find_vip") and vipEndTime > curTime then
        -- local key = "FindResTile_";
        -- key = key..CC_ITOA(self.m_buildType);
        local key = self:getStoreKey()
        ccud:setIntegerForKey(key, self.m_curLv);
        ccud:setIntegerForKey("FindResTile_Type", self.m_buildType)

        local buildType =  self.iconArr[self.m_buildType+1].type
        if buildType == searchType.MONSTER then
            if self.m_selIcon1:isVisible() and not self.m_selIcon2:isVisible() then
                buildType = searchType.MONSTER_ORDINARY
                ccud:setIntegerForKey("FindResTile_monster", buildType)
            elseif not self.m_selIcon1:isVisible() and self.m_selIcon2:isVisible() then
                buildType = searchType.MONSTER_ACTIVITY
                ccud:setIntegerForKey("FindResTile_monster", buildType)
            end
        end

        ccud:flush()
        local curLv = self.m_curLv
        local cmd = Drequire("game.command.IFFindResTileCmd").create(buildType, curLv)
        cmd:send()

        self:call("closeSelf")
    else
        local maxSearchCount = WorldController:call("getInstance"):getProperty("maxSearchCount")
        local resSearchCount = WorldController:call("getInstance"):getProperty("resSearchCount")
        local lastCnt = maxSearchCount - resSearchCount
        if lastCnt > 0 then  
            -- local key = "FindResTile_";
            -- key = key..CC_ITOA(self.m_buildType);
            local key = self:getStoreKey()
            ccud:setIntegerForKey(key, self.m_curLv);
            ccud:setIntegerForKey("FindResTile_Type", self.m_buildType)
            
            local buildType = self.iconArr[self.m_buildType+1].type
            if buildType == searchType.MONSTER then
                if self.m_selIcon1:isVisible() and not self.m_selIcon2:isVisible() then
                    buildType = searchType.MONSTER_ORDINARY
                    ccud:setIntegerForKey("FindResTile_monster", buildType);
                elseif not self.m_selIcon1:isVisible() and self.m_selIcon2:isVisible() then
                    buildType = searchType.MONSTER_ACTIVITY
                    ccud:setIntegerForKey("FindResTile_monster", buildType);
                end
            end
            ccud:flush()
            local curLv = self.m_curLv
            local cmd = Drequire("game.command.IFFindResTileCmd").create(buildType, curLv)
            cmd:send()
            self:call("closeSelf")
        else
            if CCCommonUtilsForLua:call("isFunOpenByKey", "find_vip") then
                CCCommonUtilsForLua:call("flyHint", "", "", getLang("113228"))
            else
                CCCommonUtilsForLua:call("flyHint", "", "", getLang("113231"))
            end
        end
    end
end

function FindResTileView:editBoxTextChanged(text)
    local temp = ""
    for s in string.gmatch(text, "%d") do
        temp = temp .. s
    end
    if temp == "" then
        temp = "0"
    end
    local a = tonumber(temp);
    local aaaa = CC_CMDITOA(a);
    self.m_editBox:setText(aaaa);
end

function FindResTileView:editBoxReturn()
    local numStr = self.m_editBox:getText();
    numStr = string.gsub(numStr, ",", "");
    local num = tonumber(numStr);
    num = math.ceil(num-0.5)
    if(num > self.m_maxCount)then
        num = self.m_maxCount;
    end
    if(num < 1) then
        num = 1;
    end
    self.m_curLv = num
    self.m_trainSlider:setValue(num / self.m_maxCount);
end

function FindResTileView:sliderCallBack(sender, even)
    if (self.m_invalidSliderMove) then
        self.m_invalidSliderMove = false
        return
    end
    self.m_curLv = self.m_trainSlider:getValue() * self.m_maxCount
    self.m_curLv = math.ceil(self.m_curLv-0.5)
    if(self.m_curLv > self.m_maxCount)then
        self.m_curLv = self.m_maxCount;
    end
    if(self.m_curLv < 1) then
        self.m_curLv = 1;
    end
    self.m_editBox:setText(CC_ITOA(self.m_curLv))
    self.m_invalidSliderMove = true
    self.m_trainSlider:setValue(self.m_curLv * 1.0 / self.m_maxCount)
end

function FindResTileView:onTouchBegan(x, y)
    self.startX = x
    self.startY = y
    return true
end

function FindResTileView:onTouchEnded(x, y)
    if (isTouchInside(self.m_touchNode, x, y)) then
        local moveX = x - self.startX
        if math.abs(moveX) < 20 then
            for i = 0, self.m_dataCount - 1 do
                if (isTouchInside(self.m_sprVec[i], x, y)) then
                    local node = self.m_sprVec[i]:getParent()
                    self.m_rect:setPosition(ccp(node:getPositionX()-15, node:getPositionY()-15))
                    self.m_buildType = i
                    self:SetUpdateSliderValue()
                    break;
                end
            end
            if (isTouchInside(self.m_selBg1, x, y)) then
                self.m_selIcon1:setVisible( not self.m_selIcon1:isVisible() )
                self.m_selIcon2:setVisible(false)
                self:setSliderAndEdit()
            end

            if (isTouchInside(self.m_selBg2, x, y)) then
                self.m_selIcon2:setVisible( not self.m_selIcon2:isVisible() )
                self.m_selIcon1:setVisible(false)
                self:setSliderAndEdit()
            end
        end
    elseif self.m_canClose == true then
        if not isTouchTriggered(x, y, cc.p(self.startX, self.startY)) then
            return
        end
        self.m_canClose = false;
        local callback = function()
            self:onAniFadeOutEnd()
        end
        self.animationManager:setAnimationCompletedCallback(callback)
        self.animationManager:runAnimationsForSequenceNamed("fadeOut")
    end
end

function FindResTileView:onAddClick()
    local value = self.m_curLv + 1
    if (self.m_maxCount < value) then
        return
    else
        self.m_curLv = math.ceil(value-0.5)
        self.m_trainSlider:setValue(1.0 * self.m_curLv / self.m_maxCount);
        self.m_editBox:setText(CC_ITOA(self.m_curLv))
    end
end

function FindResTileView:onReduceClick()
    local value = self.m_curLv - 1
    if (1 > value) then
        return
    else
        self.m_curLv = math.ceil(value-0.5)
        self.m_trainSlider:setValue(1.0 * self.m_curLv / self.m_maxCount);
        self.m_editBox:setText(CC_ITOA(self.m_curLv));
    end
end

function FindResTileView:onAniFadeInEnd()
    self.m_canClose = true
    self.animationManager:setAnimationCompletedCallback(nil)
end
function FindResTileView:onAniFadeOutEnd()
    self.m_canClose = true
    self:call("closeSelf")
end

function FindResTileView:onChangeMonsterNode()
    self.m_showMonster = not self.m_showMonster
    local offx = self.m_extWidth
    if self.m_showMonster then
        self.m_mosterSelNode:setVisible(true)
        self.m_scrollView:setContentSize(cc.size(100*self.m_dataCount+10+offx, self.m_infoList:getContentSize().height+10))
        self.m_scrollView:setTouchEnabled(true)
        local monsterT = ccud:getIntegerForKey("FindResTile_monster", 5);
        if monsterT == 6 then
            self.m_selIcon1:setVisible(true)
            self.m_selIcon2:setVisible(false)
        elseif monsterT == 7 then
            self.m_selIcon1:setVisible(false)
            self.m_selIcon2:setVisible(true)
        end
    else
        self.m_mosterSelNode:setVisible(false)
        offx = -offx
        self.m_scrollView:setContentSize(cc.size(100*self.m_dataCount+10, self.m_infoList:getContentSize().height+10))
        self.m_scrollView:setTouchEnabled(true)
    end

    for i,v in ipairs(self.m_otherNode) do
        v:setPositionX(v:getPositionX()+offx)
    end

    if self.m_buildType < self.m_dataCount and self.m_buildType>=0 then
        local node = self.m_sprVec[self.m_buildType]:getParent()
        self.m_rect:setPosition(ccp(node:getPositionX()-15, node:getPositionY()-15))
    end

end

function FindResTileView:getGuideNode( key )
    Dprint("FindResTileView:getGuideNode", key)
    if key == 'LUA_UI_searchBtn' or key == 'LUA_search_monster' then
        local function callBack()
            self:onFindBtnClick()
            GuideController:call("next")
        end
        GuideController:call("setCallback", cc.CallFunc:create(callBack))
        return self.m_findBtn
    end
    return nil
end
return FindResTileView
