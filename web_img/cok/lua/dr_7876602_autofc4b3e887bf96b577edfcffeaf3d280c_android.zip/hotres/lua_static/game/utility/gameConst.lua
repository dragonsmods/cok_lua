require("game.utility.gameConst2")

RACE_TYPE_LONG_YI = 0 
RACE_TYPE_WEI_JING = 1 
RACE_TYPE_DA_HE = 2 
RACE_TYPE_HUA_XIA = 3 

GOODS_ICON_TAG = 99
GOODS_BG_TAG = 100
GOODS_NUM_BG_TAG = 101
GOODS_NUM_LBL_TAG = 102
GOODS_COMBINE_ICON_TAG = 103

MSG_PAY_FAILED = "pay_failed"
PAYMENT_COMMAND_RETURN = "pay_return"
MSG_REFREASH_TOOL_DATA = "msg_refreash_tool_data"
MSG_CITY_RESOURCES_UPDATE = "city_resources_update"
GOLDEXCHANGE_ADVERTISING_SCROLL = "goldexchange.advertising.scroll"
GOLDEXCHANGE_ADVERTISING_STOP_SCROLL = "goldexchange.advertising.stop.scroll"
GOLDEXCHANGE_LIST_CHANGE = "GoldExchange.Change"
GOLDEXCHANGE_GROUP_LIST_CHANGE = "GoldExchange.group.Change"
MAG_TOOLNUMSELVIEW_CALLBACK = "msg.toolnumselview.callback"
GUIDE_INDEX_CHANGE = "guide_index_change"
BEDGE_COMPOSE_MSG = "bedge.compose.msg"
MSG_BEDGE_UPDATE = "msg.bedge.update"
GOLDEXCHANGE_SHOW_COMMAND = "exchange.info"
msg_lua_pack_down = "msg_lua_pack_down"
GOLDEXCHANGE_SHOW_REFRESH = "goldexchange.show.refresh"
MSG_COLLECT_SOLDIER_ADD_POWER = "msg_collect_soldier_add_power"
MSG_DYNAMIC_DOWNLOAD_FINISH = "msg.dynamic.download.finish"
ARMY_NUM_CHANGE = "armyNumChange"
MSG_UPDATE_ARMY_DATA = "msg_update_army_data"
MSG_QUICK_TROOPS_HARVEST = "msg_quick_troops_harvest"
MSG_TROOPS_CHANGE = "msg_troops_change"
MSG_QUICK_TROOPS = "msg_quick_troops"
MSG_QUEUE_REMOVE = "msg_queue_remove"
MSG_QUEUE_ADD = "msg_queue_add"
MSG_DRAGON_REFRESH_VIEW = "msg_dragon_refresh_view"
MSG_GET_REWARD_DETAIL_BACK = "MSG_GET_REWARD_DETAIL_BACK"

WORLD_DEFAULT_HD_SCALE = 1.4
DOWN_HEIGHT = 105
Cocos_iPhoneXBottomSpace = 30
-- 打点宏
LOG_MONTH_CARD = "logMonthCard"  -- 点击进入月卡界面打点

WorldResourceType = {
    Wood = 0, 		-- 木材
    Stone = 1,		-- 秘银
    Iron = 2,		-- 铁
    Food = 3,		-- 粮食
    Silver = 4,    	-- 钢矿
    Gold = 5,
    Chip = 6,    	-- 铜矿
    Diamond = 7,    	-- 龙矿
    LongJing = 8,    	-- 龙晶
    YinBi = 9,     	-- 银币
    WorldResource_Max = 10,
    DragonFood = 20,
    
    Sandstone = 21,        	-- 砂岩
    Carbite = 22,          	-- 金刚石
    Marble = 23,           	-- 大理石
    Granite = 24,          	-- 花岗岩
    Limestone = 25,        	-- 石灰石
    
    DragonGold = 26,
    svipPoint = 27,         -- svip点数，适用于商店    
    newNeutralScore = 28,         -- 矿脉积分   
    AncestralScore = 29,    --【Awen】先祖战场积分
    CivCrystal = 30,        --【Awen】文明堡垒-文明结晶
    CivStone = 31,          --【Awen】文明堡垒-科研石
    CivIron = 32,           --【Awen】文明堡垒-精铁
    FineIron = 211508,
}

WorldCityType = {
    OriginTile = 0
    ,CityTile = 1
    ,CampTile = 2 --扎营地
    ,ResourceTile = 3 -- 3 资源
    ,KingTile = 4 -- 4 遗迹
    ,BattleTile = 5 ---- 5 塔
    ,MonsterTile = 6 ---- 6 地宫
    ,MonsterRange = 7 
    ,CityRange = 8 ---- 8 玩家周边
    ,FieldMonster = 9 -- -- 9 野怪
    ,Throne = 10 -- --王座
    ,ThroneRange = 11 ----王座周边
    ,Trebuchet = 12 -- --投石机
    ,TrebuchetRange = 13 --投石机周边
    ,Tile_allianceArea = 14--联盟堡垒
    ,ActBossTile = 15--活动怪物boss
    ,Tile_allianceRange = 16--联盟领地周边
    ,ActBossTileRange = 17
    ,tile_superMine = 18--联盟超级矿
    ,tile_superMineRange = 19
    ,tile_tower = 20--联盟箭塔
    ,tile_wareHouse = 21--联盟仓库
    ,tile_wareHouseRange = 22
    ,tile_banner = 23--联盟国旗
    -- ----- dragon building
    ,Crystal = 24 --24水晶
    ,Crystal_Range = 25 --25水晶周边
    ,Armory = 26 --26军械库
    ,Armory_Range = 27 --27军械库周边
    ,TrainingField = 28 --28训练场
    ,TrainingField_Range = 29 --29训练场周边
    ,SupplyPoint = 30 --30供给点
    ,BessingTower = 31 --31祝福塔
    ,MedicalTower = 32 --32医疗塔
    ,DragonTower = 33 --33龙塔
    ,Barracks = 34 --34兵营 骑士大厅
    ,Barracks_Range = 35 --35兵营周边
    ,TransferPoint = 36--36传送点
    ,Resource_new = 37 --37 活动资源点
    ,Resource_newRang = 38--38 range
    ,Little_Crystal = 41-- 小水晶点
    ,Alliance_Tree = 42 -- 42 联盟树
    ,Alliance_TreeRange = 43 --43 联盟树周边
    ,Barbarian = 44--44野蛮人城堡
    ,Barbarian_Range = 45--45野蛮人城堡周边
    ,tile_flagsbuilding = 46--旗帜建筑物
    ,tile_Cannon = 47 --联盟大炮
    ,tile_winTower = 48 --胜利之塔
    ,tile_HpWorldBoss = 49 --世界boss信息地块
    ,tile_HpWorldBossRange = 50 --boss周边
    ,Basttile = 51         --51 巴士底狱
    , AllianceTrapTile = 52 -- 联盟陷阱
    , ResourceBattleTile = 53 -- 资源战地格
    ,KingdomMiracle = 54 -- 奇迹
    ,KingdomMiracleRange = 55 -- 奇迹周边
    ,KingdomAttBuilding = 56 -- 王国攻击建筑
    ,KingdomAttBuildingRange = 57 -- 王国攻击建筑周边
    ,KingdomDefBuilding = 58 -- 王国防御建筑
    ,KingdomDefBuildingRange = 59 -- 王国防御建筑
    ,NeutralLand_Resource = 60 -- 中立地带稀有资源
    ,NeutralLand_Tower = 61 -- 中立地带哨塔
    ,DEFENSOR = 62 -- 守护者 
    ,NewResourceBattleTile = 63 -- 新资源战地格
    , Totem = 64  -- 图腾
    , TotemRange = 65 -- 图腾周边

    , Civilization_castle = 68 -- 文明堡垒
    , Civilization_castle_Range = 69 -- 文明堡垒周边
    , tile_hospital = 70 --  联盟医院

    , city_barracks = 77 -- 营地
    , tile_civi_miracle = 78 --文明奇迹
    , tile_civi_miracle_range = 79 --文明奇迹周边
    , crossthrone_blessing_tower = 80 --大王战祝福塔
    , crossthrone_blessing_tower_range = 81 --大王战祝福塔周边
    , crossthrone_curse_tower = 82 --大王战诅咒塔
    , crossthrone_curse_tower_range = 83 --大王战诅咒塔周边
    , FOUR_FIELD_MONSTER = 85       --【Awen】4格普通野怪 85
    , FOUR_FIELD_MONSTER_RANGE = 86 --【Awen】4格普通野怪周边 86
    , SakuraTree = 93 -- 樱花树 93
    ,DonateSoldire = 94 --士兵消耗捐兵建筑
    ,DonateSoldireRang = 95--士兵消耗捐兵建筑

    , SNK_Portal = 84 --SNK活动的传送门
    , void_portal = 89 --虚空战场传送门
    , void_throne = 91 -- 虚空战场王座 
    , expedition_super_mine = 96 --远征超级矿 96
    , expedition_super_mine_range = 97 --远征超级矿周边 97
    , expedition_super_mine_sub = 98 --远征超级矿辅矿 98
    , expedition_super_mine_sub_range = 99 --远征超级矿辅矿周边 99
    , hero_maintheme_scout = 105 --英雄主题月 异国旅人侦查点 105
    , hero_maintheme_monster = 106 --英雄主题月 异国旅人怪物点 106
    , hero_maintheme_resource = 107 --英雄主题月 异国旅人采集点 107

    , kingdomTransPortal = 108 --王国传送门
    , kingdomTransPortalRange = 109 --王国传送门周边
    , kingdomTransBarracks = 110 --王国传送门兵营
    --以下是lua预留类型
    ,LuaItemTile = 1000 --1000 for lua use -- add by js 占位 2*2
    ,LuaItemTile_Range = 1001 -- 1001
    ,LuaItemTile1 = 1002 --1002 for lua use -- add by js 占位 1*1
    ,LuaNewTile = 1003 -- add at 2016.11.21 占地格大小根据服务器返回值
    ,LuaNewTile_Range = 1004
}

BatchTagType =
{
    defaultTag = 0
    ,LevelTag = 1
    ,FireTag = 2
    ,ProtectTag = 3
    ,ResourceProtectTag = 4
    ,SmokeTag = 5
    ,CityMoveInTag = 6
    ,CityMoveOutTag = 7
    ,ShengdanNameBg = 8
    ,NameTag = 9
    ,NameTag1 = 10
    ,NameTag2 = 11
    ,EdgyTag = 12
    ,EdgyTag1 = 13
    ,WorldBorder = 14
    ,WorldBorder1 = 15
    ,CityTag = 16
    ,CityMoveInViewTag = 17
    ,MonsterAttack = 18
    ,MonsterAttack1 = 19
    ,MonsterDead = 20
    ,MonsterDead1 = 21
    ,MonsterBreath = 22
    ,MonsterAppear = 23
    ,Rock = 24
    ,Rock1 = 25
    ,Rock2 = 26
    ,Rock3 = 27
    ,WarFire = 28
    ,MonsterBreath1 = 29
    ,MonsterProBG1 = 30
    ,AllianceFlag = 31
    ,Shadow = 32
    ,MonsterTalkText = 33
    ,MonsterTalkLine = 34
    ,AllianceParticle = 35
    ,MonsterAttackParticle = 36
    ,TrebuchetWait = 37
    ,TrebuchetAttack = 38
    ,OfficerTagBG = 39
    ,OfficerTag = 40
    ,OfficerTagParticle = 41
    ,WarBuildTextTag1 = 42
    ,WarBuildTextTag2 = 43
    ,WarBuildTextTag3 = 44
    ,WarBuildStateBG = 45
    ,ThroneProtectParticle = 46
    ,Partical_fieldMonster = 47
    ,Partical_AAreaBuild = 48
    ,Partical_mapMask = 49
    ,AllianceTerritoryParticle = 50
    ,CSProtectTag = 51
    ,TreasureMapCDBarBG = 52
    ,Rs_Spreading = 53
    ,Rs_Flying = 54
    ,Rs_fadein = 55
    ,Rs_fadeout = 56
    ,CityStar = 57
    ,Partical_castleWing = 58
    ,Partical_castleWing2 = 59
    ,Partical_castleWing3 = 60
    ,Partical_castleWing4 = 61
    ,Partical_castleWing5 = 62
    ,CityCustomTag = 63
    ,DragonTowerParticleTag = 64
    ,ScoutBgTag = 65
    ,ScoutTag = 66
    ,CrossThroneAttackerNormalTag = 67
    ,CrossThroneAttackerFireTag = 68
    ,SendHeartTag = 69
    ,Partical_AlTerritorySkill = 70 --联盟领地技能特效
    ,Partical_AllianceTree = 71    --联盟树特效
    ,Partical_AllianceCannonFire = 72  --被攻击点粒子
    ,Partical_AllianceCannonStart = 73  --攻击点粒子
    ,Partical_AllianceCannonFly = 74    --粒子弹道轨迹
    ,Partical_CannonToCityImpact = 75   --粒子城堡撞击
    ,SendTroubleTag = 76    -- 捣乱活动
    ,WorldBossHPBG = 77  --世界boss血值背景图
    ,WorldBossHP = 78    --世界boss血值
    ,WorldBossDJ = 79    --待机状态
    ,WorldBossGJ = 80    --攻击状态
    ,WorldBossSW = 81    --死亡状态
    ,WorldBossOver = 82  --静止死亡状态
    ,WorldBossEff = 83   --boss特效
    ,Partical_AllianceTrap = 84   --联盟陷阱特效
    ,Partical_AllianceTrapMark = 85   --联盟堡垒，有陷阱标记特效
    ,ResBattleMultiBg = 86 -- 当前倍数的底图

}


RewardTypeConfig = {
    R_WOOD = 0,
    R_STONE = 1,
    R_IRON = 2,
    R_FOOD = 3,
    R_SILVER = 4,
    R_GOLD = 5,
    R_EXP = 6,
    R_GOODS = 7,
    R_GENERAL = 8,
    R_POWER = 9,
    R_HONOR = 10,
    R_ALLIANCE_POINT = 11,
    R_CHIP = 12,
    R_DIAMOND = 13,
    R_EQUIP = 14,
    R_DRAGONFOOD = 15,
    R_DRAGONGOLD = 16,
    R_EFFECT = 17,
    R_WIN_POINT = 18,
    R_CRYSTAL = 19, --水晶 19
    R_YINBI = 20,   --银币 20
    R_MILITARYPOINT = 21, --军衔点数 21
    R_SANDSTONE = 22,
    R_CARBITE = 23,
    R_MARBLE = 24,
    R_GRANITE = 25,
    R_LIMESTONE = 26,
    R_MILITARYHONOR = 27,  --军衔荣誉 27
    R_HEROEXP = 28,
    R_DRAGON_MODEL = 29,   --如需添加奖励类型，需要在R_DRAGON_MODEL之前添加并与后台值相对应
    R_DRAGON_RING = 30,     --R_DRAGON_MODEL和R_DRAGON_RING是实物奖励只有在前台用到
    R_PRESTIGE = 31,    --声望(声望总类型）
    R_NULL = 32,    --占位 无用
    R_CIVIZILATION_POINT  = 33, --文明积分
    R_CIVIZILATION_CRYSTAL = 34,    --文明结晶
    R_CIVIZILATION_CRYSTAL_ROB_ADD = 35,    --额外获取文明结晶
    
    R_CIVIZILATION_DRAGON = 101,    --龙族文明声望 (声望子类型）
    R_CIVIZILATION_VIKING = 102,    --维京文明声望 (声望子类型）
    R_CIVIZILATION_JAPAN  = 103,    --日本文明声望 (声望子类型）
    R_PRESTIGE_MINE = 104,  -- 当前文明声望 (声望子类型）
    R_PRESTIGE_OTHER = 105, -- 其他文明声望 (声望子类型）
}

QuestState = {
    ACCEPT = 0,
    COMPLETE = 1,
    REWARD = 2,
}

ServerType =
{
    SERVER_NORMAL = 0,-- 普通服
    SERVER_TEST = 1,-- 测试服
    SERVER_BATTLE_FIELD = 2,-- 远古战场服务器
    SERVER_DRAGON_BATTLE = 3,-- 巨龙战役服务器
    SERVER_BATTLE_FIELD_TEST = 4,-- 远古战场测试服
    SERVER_DRAGON_BATTLE_TEST = 5,-- 巨龙战役测试服
    SERVER_INNER_TEST = 6,-- 内网测试服
    SERVER_DRAGON_PLAYOFF = 7,-- 巨龙季后赛服务器
    SERVER_DRAGON_PLAYOFF_TEST = 8,-- 巨龙季后赛测试服
    SERVER_NEUTRAL_LAND = 9,-- 中立地带服务器
    SERVER_NEUTRAL_LAND_TEST = 10,-- 中立地带测试服
    SERVER_ARENA = 11,-- 竞技场服务器
    SERVER_ARENA_TEST = 12,-- 竞技场测试服
    SERVER_DRAGON_BATTLE_GLOBAL = 13, --巨龙战役全球对抗赛服务器 13
    SERVER_DRAGON_BATTLE_GLOBAL_TEST = 14, --巨龙战役全球对抗赛服务器 14
    SERVER_DESPOT = 15, --霸王争夺服 15
    SERVER_DESPOT_TEST = 16, --霸王争夺测试服 16
    SERVER_EMPIRE = 17, --帝王争夺服 17
    SERVER_EMPIRE_TEST = 18, --帝王争夺测试服 18
    SERVER_ANCESTRAL = 19,        --【Awen】先祖战场 19
    SERVER_ANCESTRAL_TEST = 20,   --【Awen】先祖战场测试服 20
}

TouchPriority =
{
    Touch_Default = 1, --//默认touch优先级
    Touch_Popup_Item = 2, --//嵌入面板内元素touch优先级
    Touch_Popup = 3, --//嵌入面板touch优先级
    Touch_Imperial_City = 4, --//主城建筑touch优先级
}

GridType =
{
    NEUTRALLY = 1004
    , STOP = 1005
    , SPACE = 1006
}

FUN_BUILD_HOSPITAL = 411000 -- 医疗帐篷
FUN_BUILD_WORKSHOP = 430000 -- 制作材料工坊
FUN_BUILD_HALLOFHERO = 433000 -- 英雄殿堂建筑类型
FUN_BUILD_HIGHTECH = 436000 --高级科技建筑
FUN_BUILD_BANK = 438000 --新版银行
FUN_BUILD_NEWARMY = 439000 --荣耀6新兵营
FUN_BUILD_NEWARMY_IMPROVE = 440000 --新兵种强化所
FUN_BUILD_NEWARMY_CURE = 441000 --新兵种虚弱庇护营
FUN_BUILD_NEUTRAL_SHOP = 442000 --积分商店
FUN_BUILD_FORTRESS = 443000 -- 文明堡垒
FUN_BUILD_ARTILLERY = 444000 -- 大炮建筑

FUN_BUILD_MAIN_CITY_ID = 400000000
FUN_BUILD_HALLOFHERO_ID = 433000058 -- 英雄殿堂建筑id
FUN_BUILD_FORGE = 429000 --铁匠铺

--【Awen】文明堡垒分城建筑
FUN_CIV_BUILD_MAIN      = 8200000   --文明堡垒-主城
FUN_CIV_BUILD_CRYSTAL   = 8201000   --文明堡垒-结晶工坊
FUN_CIV_BUILD_IRON      = 8202000   --文明堡垒-精铁工坊
FUN_CIV_BUILD_STONE     = 8203000   --文明堡垒-科研工坊
FUN_CIV_BUILD_WALL      = 8204000   --文明堡垒-城墙

FUN_CIV_BUILD_MAIN_ID   = 820000100

FUN_BUILD_NORMAL        = 0
FUN_BUILD_LOCK          = 1
FUN_BUILD_ULOCK         = 2
FUN_BUILD_CREATE        = 3
FUN_BUILD_UPING         = 4
FUN_BUILD_CHANGE        = 5
FUN_BUILD_UPING_END     = 6
FUN_BUILD_NOT_OPEN      = 7
FUN_BUILD_INIT          = 8
FUN_BUILD_CREATE_ERROR  = 9
FUN_BUILD_UPING_ERROR   = 10
FUN_BUILD_NORMAL_ERROR  = 11
FUN_BUILD_DESTROY       = 12
FUN_BUILD_DESTROY_END   = 13
FUN_BUILD_CANCEL_CREATE = 14
FUN_BUILD_CANCEL_OTH    = 15
FUN_BUILD_CANOPEN       = 16

ImperialData = 
{
    Race1SceneInitWidth = 326,
    Race2SceneInitWidth = 688,
    Race3SceneInitWidth = 760,
    HeroSceneWidth = 780,
    Race1HeroSceneWidth = 1108,
    Race2HeroSceneWidth = 1456,
    Race3HeroSceneWidth = 1410,
    LeftSceneWidth = 3432,
    RightSceneWidth = 3560,
    TopSceneHeight = 2694,
    BottomSceneHeight = 250,
}

--和QueueInfo.h里面定义保持一致 
QueueType = 
{
    TYPE_BUILDING = 0,   --建筑0
    TYPE_HOSPITAL = 3, --医院
    TYPE_SCIENCE = 6, --科技
    TYPE_FORGE = 11, --锻造
    TYPE_MATE = 12, --造材料
    TYPE_HIGHTECH = 16, --研究高级科技
    TYPE_OCCUPY_RESOURCE = 19, --占领资源
    TYPE_OCCUPY_MAZE = 20, --占领迷宫
    TYPE_OCCUPY_CAMP = 21, --帐篷
    TYPE_ARMY_MASS = 22, --集结中
    TYPE_OCCUPY_ALLIANCE = 23, --协助防守
    TYPE_BUILDING_TERRITORY = 24, --修造领地
    TYPE_REPAIR_TERRITORY = 25, --修理领地
    TYPE_STATION_TERRITORY = 26, --驻守领地
    TYPE_DESTROY_TERRITORY = 27, --摧毁领地
    TYPE_OCCUPY_TERRITORY_RESOURCE = 28, --占领超级矿
    TYPE_OCCUPY_LITTLECRYSTAL = 29,
    TYPE_OCCUPY_DEFENSOR = 30, --占领守护者

    TYPE_ALLIANCE_HOSPITAL = 32, -- 联盟医院
    TYPE_CIV_FORTRESS = 35, --【Awen】文明堡垒分城建造/升级 35
    TYPE_AORMATION = 36, --阵法研习
}

QID_MAX = 32767

MarchStateType =
{
    StateMarch = 0,
    StateOccupy = 1,
    StateReturn = 2,
}

ItemSpdMenu = 
{
    ItemSpdMenu_ALL = 1, --——城建，造兵，科技，造陷阱，治疗
    ItemSpdMenu_Troop = 2,  --——行军
    ItemSpdMenu_Soldier = 3, --——造兵
    ItemSpdMenu_Heal = 4, -- 治疗
    ItemSpdMenu_Trap = 5, -- 造陷阱
    ItemSpdMenu_Science = 6, -- 科技
    ItemSpdMenu_City = 7, -- 城建
    ItemSpdMenu_DuanZao = 8, --锻造
    ItemSpdMenu_Alliance = 9,
    ItemSpdMenu_Mate = 10, --造材料
    ItemSpdMenu_HighTech = 11, --新科技
    ItemSpdMenu_JieLv = 12, --戒律大厅
    ItemSpdMenu_Civ_City = 13,  --【Awen】文明堡垒分城城建
    ItemSpdMenu_Tactical=14, --阵法研习
    ItemSpdMenu_RaceScience = 19,--【Awen】先祖之魂，与队列类型一致
}

CCLoadSpriteType = 
{
    CCLoadSpriteType_NONE = 0,  --小白点
    CCLoadSpriteType_DEFAULT = 1,
    CCLoadSpriteType_GOODS = 2,
    CCLoadSpriteType_AVATARICON = 3,
    CCLoadSpriteType_EQUIP = 4,
    CCLoadSpriteType_MONSTER = 5,
    CCLoadSpriteType_MAP = 6,
    CCLoadSpriteType_MONSTERLAYERBUST = 7,
    CCLoadSpriteType_MONSTERLAYERLITTLE = 8,
    CCLoadSpriteType_HEAD_ICON = 9,
    CCLoadSpriteType_HEAD_ICON_BUST = 10,
    CCLoadSpriteType_HEAD_ICON_MIDDLE = 11,
    CCLoadSpriteType_ACTIVITY_RES = 12,
    CCLoadSpriteType_SCIENCE = 13,
    CCLoadSpriteType_RESOURCE = 14,
    CCLoadSpriteType_QUEST = 15,
    CCLoadSpriteType_WORLDCITY = 16,
    CCLoadSpriteType_COUNTRY_ICON = 17,
}

OpenPanelType = {
    GOLD_PANEL = 0, 
    GOLD_PANEL_SUCCESS = 1,
    GOLD_BUTTON = 2, 
    GENERAL_OPEN = 3, 
    UPGRADE_OK = 4,
    UPGRADE_ADD = 5,
    ADD_TALENT = 6,
    RECHARGE_ACT = 7,
    MAIL_OPEN = 8,
    POINT_ACTIVITY_OPEN = 9,
    FB_SHARE_FEED = 17,
    FB_INVITE_FRIEND = 18
}

SPE_BUILD_EXCHANGE_UI     = 9990019
SPE_BUILD_PRESTIGE        = 9990027    -- 声望入口

LEVEL_SCENE      =  0
LEVEL_MINIMAP      =  1
LEVEL_POPUP_IN   =  2
LEVEL_GUI        =  3
LEVEL_POPUP      =  4
LEVEL_TIP        =  5
LEVEL_CONTROL    =  6
LEVEL_WORLD_UI   =  7
LEVEL_GUIDE      =  8
LEVEL_POP_TOUCH      =  9
LEVEL_SCENE_TRANSITION  = 10
LEVEL_MAX         = 11
SCENE_ID_LOADING       =  0
SCENE_ID_MAIN          =  1
SCENE_ID_BATTLE        =  2
SCENE_ID_CROP          =  3
SCENE_ID_WOOD          =  4
SCENE_ID_PVE           =  5
SCENE_ID_GUI           =  6
SCENE_ID_IRON          =  7
SCENE_ID_BARRACKS      =  8
SCENE_ID_MARKET        =  9
SCENE_ID_IMPERIAL       = 10
SCENE_ID_WORLD          = 11
SCENE_ID_BATTLE2          = 12
SCENE_ID_DRAGON           = 13

MSG_REPAY_INFO_INIT     = "repay.info.init"

SocialShareTriggerType = {
    eSocialShareTrigger_Null = 0,
    eSocialShareTrigger_AlianceHelp = 1,
    eSocialShareTrigger_DragonTowerResult = 1000,
    eSocialShareTrigger_OldPlayerRecall = 2000,
    eSocialShareTrigger_DragonBattle = 3000
}

TriggerEventPromotionType = {
    eTriggerEventPromotion_FirstPay = 0,
    eTriggerEventPromotion_CastleLevel = 1,
    eTriggerEventPromotion_KeepSignIn = 2,
    eTriggerEventPromotion_AllianceHelp = 3,
    eTriggerEventPromotion_PayAction = 4,
    eTriggerEventPromotion_CompletedRegist = 5,
    eTriggerEventPromotion_HireWorker = 6,
    eTriggerEventPromotion_Shopping = 7,
    eTriggerEventPromotion_Share = 8,
    eTriggerEventPromotion_ClickOnGold = 9,
    eTriggerEventPromotion_ClickOnGift = 10,
    eTriggerEventPromotion_SecondDayLogin = 11,
};

TileButtonState = { -- 世界地块按钮状态
    ButtonNone = -1,
    ButtonTeleport = 0,
    ButtonOccupy = 1,
    ButtonProfile = 2,
    ButtonScout = 3,
    ButtonMarch = 4,
    ButtonViewTroop = 5,
    ButtonGoHome = 6,
    ButtonRally = 7,
    ButtonEnterCity = 8,
    ButtonSupport = 9,
    ButtonResourceHelp = 10,
    ButtonInformation = 11,
    ButtonExplore = 12,
    ButtonInvite = 13,
    ButtonGoto = 14,
    ButtonSpeedUp = 15,     -- 行军加速
    ButtonRecall = 16,
    ButtonRalliedTroops = 17,
    ButtonMyKing = 18,
    AppointOfficals = 19,
    ButtonAddEffect = 20,
    ButtonAllianceAct = 21,
    ButtonWorldInviteTeleport = 22,
    ButtonBuilding = 23,
    ButtonStation = 24,
    ButtonRepair = 25,
    ButtonPlace = 26,
    ButtonGather = 27,
    ButttonTreasureMapSPD = 28,
    ButtonStorage = 29,
    ButtonRetreat = 30,
    ButtonFunction = 31,
    ButtonMarkLine = 32,
    ButtonOrderIcon = 33,
    ButtonTransKingdom = 34,
    ButtonKingdomWarRank = 35,
    ButtonSimplifyModelOn = 36,
    ButtonSimplifyModelOff = 37,
    ButtonFengShou = 38,
    ButtonSkill = 39,
    ButtonAlDonate = 40,
    ButtonCannon = 41,
    ButtonMass = 42, -- 捣乱
    ButtonBeautify = 43, -- 美化
    ButtonMassHelp = 44, -- 捣乱活动里面的帮助
    ButtonUpgrade = 45, -- 世界中联盟建筑升级按钮
    ButtonBossAttack = 46, -- 世界Boss攻打
    ButtonBossRank = 47, -- 世界boss攻打排名
    ButtonBossReward = 48, -- 世界Boss攻打奖励
    ButtonFisk = 49, -- 国库
    ButtonKingdomRally = 50, -- 王国集结
    ButtonPatrol = 51, -- 巡视
    ButtonNpcItem = 52 , -- 访问npc野怪
    ButtonBossCostItem = 53  , -- npcboss 攻击
    ButtonBattleMail = 54 , -- 邮件
    ButtonTreat = 55,
    ButtonAllianceShield = 56 , -- 盟友开罩
    ButtonArtilleryAttack = 57 , --大炮攻击
    ButtonHospitalInjured = 58 , -- 伤兵概况
    ButtonBarracks_Reward = 59, -- 奖励
    ButtonordLord         = 60, -- 领主详情
    ButtonSacrifice       = 61, -- 文明奇迹献祭
    ButtonStarMap         = 62, -- 文明奇迹星盘
    ButtonBuild           = 63, -- 文明堡垒建造
    ButtonVoidPortal      = 65, -- 虚空战场虚空之门
    ButtonVoidMap         = 66, -- 虚空战场虚空地图
    ButtonVoidBattlefield = 67, -- 虚空战场虚空战场
    ButtonCivilizationTimeLimit = 68,  -- 文明堡垒限时活动
    ButtonCOSSoldireInfo = 69, --士兵消耗活动部队详情
    ButtonCOSDonateSoldire = 70, --士兵消耗活动捐兵
    ButtonCOSMainView = 71, --士兵消耗活动主界面
    ButtonExpeditionDetail = 72, --远征超级矿详情
    ButtonKingdomTransPortal = 73, --王国传送门
    ButtonKingdomTransBarrack = 74, --王国英雄
    ButtonKingdomTransBattle = 75, --战争准备
    ButtonGrave = 1001 -- 墓地
};

ActivityStage = 
{
    ActivityStage_Running = 1, --  进行中
    ActivityStage_Comming = 2, --  即将进行
    ActivityStage_Preparing = 3, -- 准备中 或者  已经结束
}


PlayerType = { -- 玩家类型
    PlayerNone = -1,
    PlayerSelf = 0, -- 玩家自己
    PlayerAlliance = 1, -- 盟友
    PlayerOther = 2, -- 其他
    PlayerKing = 3, -- 王座
}

MapType = { -- 地图类型
    DEFAULT_MAP = 0,
    NORMAL_MAP = 1, -- 正常地图
    SERVERFIGHT_MAP = 2, -- 远征
    DRAGON_MAP = 3, -- 巨龙
    NEUTRALLAND_MAP = 4, -- 中立地带
    ARENA_MAP = 5, -- 竞技场
    DESPOT_MAP = 6, --霸主战
    EMPIRE_MAP = 7, --帝王战
    ANCESTRAL_MAP = 8,   --【Awen】先祖战场
};

SoilderDetailType = { -- 兵种类型 1步兵,2抢兵,3骑兵,4骑射,5弓,6弩,7投石,8冲车,100箭塔,101陷阱
    Infantry = 1,--步兵
    Pikeman = 2,--枪兵
    Cavalry = 3,--骑兵
    CavalryArcher = 4,--骑射
    Archer = 5,--弓
    Crossbowman = 6,--弩
    Catapult = 7,--投石
    BatteringRam = 8,--冲车
    ArrowTower = 100,--箭塔
    Fort = 101,--陷阱
}

spEventType = { -- spine动画事件类型
    SP_ANIMATION_START = 0,
    SP_ANIMATION_END = 1,
    SP_ANIMATION_COMPLETE = 2,
    SP_ANIMATION_EVENT = 3,
}

FlyHintType = {
    FLY_HINT_LOGIN = 0,
    FLY_HINT_KING = 1,
    FLY_HINT_SYSTEM = 2,
    FLY_HINT_ALLIANCE_INVITE = 3,
    FLY_HINT_SHAKEALLIANCE = 4,
    FLY_HINT_WAR = 5,
    FLY_HINT_SERVER_STOP = 6,--为停服维护中进入游戏提示
    FLY_HINT_NORMAL = 7,--正常提示
    FLY_HINT_ACHIEVEMENT = 8,--成就提示
}

MailType = {
    MAIL_SELF_SEND = 0,
    MAIL_USER = 1,
    MAIL_SYSTEM = 2,
    MAIL_SERVICE = 3,
    MAIL_BATTLE_REPORT = 4,
    MAIL_RESOURCE = 5,
    MAIL_DETECT = 6, -- 被侦查
    MAIL_GENERAL_TRAIN = 7,
    MAIL_DETECT_REPORT = 8, -- 侦查
    MAIL_ENCAMP = 9,
    MAIL_FRESHER = 10,
    MAIL_WOUNDED = 11,
    MAIL_DIGONG = 12,
    ALL_SERVICE = 13,
    WORLD_NEW_EXPLORE = 14,
    MAIL_SYSNOTICE = 15,
    MAIL_SYSUPDATE = 16,
    MAIL_ALLIANCEINVITE = 17,
    MAIL_ATTACKMONSTER = 18,
    WORLD_MONSTER_SPECIAL = 19,
    MAIL_Alliance_ALL = 20,
    MAIL_RESOURCE_HELP = 21,
    MAIL_PERSONAL = 22,
    MAIL_MOD_PERSONAL = 23,
    MAIL_MOD_SEND = 24,
    MAIL_ALLIANCEAPPLY = 25,
    MAIL_INVITE_TELEPORT = 26,
    MAIL_ALLIANCE_KICKOUT = 27,
    MAIL_GIFT = 28,
    MAIL_DONATE = 29,
    MAIL_WORLD_BOSS = 30,
    CHAT_ROOM = 31,
    MAIL_ACTIVITY = 32,
    MAIL_REFUSE_ALL_APPLY = 33, -- 拒绝申请加入联盟
    MAIL_ALLIANCE_PACKAGE = 34, -- 联盟礼包
    MAIL_ALLIANCE_RANKCHANGE = 35, -- 联盟等级变化邮件
    MAIL_ALLIANCE_OFFICER = 36, -- 联盟官职
    MAIL_AUDIO_SELF_SEND = 37, -- 自己发的聊天语音
    MAIL_AUDIO_OTHER_SEND = 38, -- 别人发的聊天语音
    MAIL_MOD_AUDIO_SELF_SEND = 39, -- 自己发的MOD聊天语音
    MAIL_MOD_AUDIO_OTHER_SEND = 40, -- mod发的MOD聊天语音
    CHAT_ROOM_AUDIO = 41, -- 聊天室语音
    MAIL_NEW_WORLD_BOSS = 42,
    MAIL_DRIFTING_SELF_SEND = 43, -- 漂流瓶自己的消息
    MAIL_DRIFTING_OTHER_SEND = 44, -- 漂流瓶别人的消息
    MAIL_EXPRESSION_USER_SELF_SEND = 45, -- 个人邮件自己发的表情
    MAIL_EXPRESSION_USER_OTHER_SEND = 46, -- 个人邮件别人发的表情
    CHATROOM_EXPRESSION = 47, -- 聊天室发的表情
}

---------------------
AvatarType_None = 0
AvatarType_Diamond = 98 --//钻石购买的
AvatarType_MysteryPiece = 99 -- //神秘礼盒碎片购买的
AvatarType_Castle = 100 --//城堡皮肤 包括内城和外城
AvatarType_March = 101 --// 队列：行军皮肤
AvatarType_Ground = 102  --// 主城地表皮肤
AvatarType_ChatBg = 103 --// 聊天气泡
AvatarType_Nameplate = 104 --// 铭牌
AvatarType_CastleBubble = 105 --// 城堡上冒气泡
AvatarType_Protect = 106 --// 保护罩
AvatarType_HEHEHE = 107 -- 被莫名其妙占着了
AvatarType_CastleEffect = 108 --// 城堡上冒特效  和 105很像
AvatarType_Wings = 109  --// 翅膀
AvatarType_Civ = 110  --// 文明
AvatarType_CivFort = 114  --// 文明堡垒皮肤
AvatarType_HeadFrame = 115 -- // 头像框
AvatarType_Aura = 116 -- // 光环
AvatarType_HeroSkin = 117 --英雄出征皮肤
AvatarType_ActivityEffect = 118 --活动特效
AvatarType_Coin = 119 -- //金币购买的
AvatarType_Item = 199
AvatarType_MAX = 201


AvatarType_Coin_New = 1     --// 金币
AvatarType_Diamond_New = 2  --// 钻石
AvatarType_Goods_New = 3    --// 道具兑换
---------------------

MarchMethodType = {
    MethodBattle = 0,
    MethodScout = 1,
    MethodBarrack = 2,
    MethodDeal = 3,
    MethodRally = 4,
    MethodUnion = 5,
    MethodFieldMonster = 6,
    MethodYuanSolider = 7,
    MethodHeiqishi = 8,
    MethodWarehouse = 9,
    MethodChristmasMarch = 10,
    MethodBarbarian = 11,        -- 野蛮人城堡行军,
    MethodTerritoryWarehouseDonate = 12,         --  捐献联盟物资行军,
    MethodForMass = 13,      --  捣乱行军,
    MethodWorldBoss = 14,        -- 世界boss,
    KingdomTeamBattle = 15,          -- 王国集结-（集结进攻奇迹）  15,
    KingdomTeamAssembly = 16,        -- 参与王国集结   16,
    MethodNpcWorldBoss = 17,         -- npc世界 boss,
    ArenaTeamBattle = 18,        -- 竞技场组队集结 18,
    ArenaTeamAssembly = 19,      -- 竞技场参与组队集结 19,
    AllianceBossMethodType = 20,         --  联盟boss,
    CIVILIZATION_DEF = 21,       -- 21文明堡垒驻守行军  与服务器保持命名一致,
    CIVILIZATION_AID = 22,       -- 22文明堡垒援助行军,
    CIVILIZATION_ATTACK = 23,        -- 23文明堡垒攻击行军
    CivFortress2March = 27,     -- 文明堡垒分城驻守、援助、攻击
    NewWorldBossReward = 28, --新世界boss领奖出征
    HeroThemeScout = 33, --异国旅人侦查
    HeroThemeMonster = 34, --异国旅人侦查
    HeroThemeCollect = 35, --异国旅人采集
}

AllServerRankType =
{
    KILL = 0,                            -- 全服杀敌榜
    LORD_POWER = 1,                      -- 全服领主角色战力榜
    TRAIN_POWER = 2,                     -- 全服领主训练部队战力榜
    ATTACK_WIN = 3,                      -- 全服领主进攻胜利次数榜
    DEFEND_WIN = 4,                      -- 全服领主防御胜利次数榜
    PLAY_POWER = 5,                      -- 全服战力榜
    AVATAR_SUM_EXP = 6,                  -- 全服图鉴点数
    KILL_RAISE = 7,                      -- 全服杀敌提升榜
    LORD_POWER_RAISE = 8,                -- 全服领主角色战力提升榜
    TRAIN_POWER_RAISE = 9,               -- 全服领主训练部队战力提升榜
    ATTACK_WIN_RAISE = 10,               -- 全服领主进攻胜利次数提升榜
    DEFEND_WIN_RAISE = 11,               -- 全服领主防御胜利次数提升榜
    PLAY_POWER_RAISE = 12,               -- 全服战力提升榜
    AVATAR_SUM_EXP_RAISE = 13,           -- 全服图鉴点数提升榜
}


AuctionType =
{
    RES         = 1, --资源
    SPEED_UP    = 2, --加速
    GAIN        = 3, --增益
    OTHER       = 4, --其他
}

BOX_UN_COMPLETE = 0
BOX_COMPLETE = 1
BOX_GET_REWARD = 2

USE_TOOL_CITY_MOVE = "city.move"
USE_TOOL_MARCH_CANCEL = "march.cancel"
USE_TOOL_MARCH_CANCEL_RALLY = "march.cancel.rally" --高级行军召回
MSG_TOOL_CHANGE = "msg.tool.change"
MSG_ITME_STATUS_TIME_CHANGE = "msg.item.status.time.change"
MSG_AVATAR_ITEM_USE = "MSG_AVATAR_ITEM_USE"
USE_TOOL_CHANGE_NAME = "change.nickName"
USE_TOOL_CHANGE_PIC = "change.pic"
USE_TOOL_VIP_PIC = "use.vip"
USE_TOOL_VIP_ACTIVITY = "use.vip.activity"
USE_TOOL_MATE_BOX = "use.mate.box"
MSG_TOOL_HOT_GET_RETURN = "msg.tool.hotget.return"
MSG_TOOL_MERCHANTE_LEAVE = "msg.tool.merchante.leave"
USE_TOOL_LOTTERY1 = "lottery.buy1"
USE_TOOL_LOTTERY2 = "lottery.buy2"
MSG_TOOL_FUSE = "msg_tool_fuse"
USE_TOOL_allianceDaily_addSend = "allianceDaily.addSend"
USE_TOOL_allianceDaily_addRefresh = "allianceDaily.addRefresh"
USE_TOOL_STAMINA = "use.stamina.tool"
USE_TOOL_WISH = "use.tool.wish"
USE_TOOL_EXP = "use.tool.exp"       --[awen-lvliang]使用领主经验道具
USE_TOOL_SHUIJING = "use.tool.shuijing" --使用水晶宝箱
USE_TOOL_PRODUCTSOLDIEREFT1 = "use.tool.productionSoldierEft1" --使用普通士兵单次造兵加成道具
USE_TOOL_PRODUCTSOLDIEREFT2 = "use.tool.productionSoldierEft2" --使用P6士兵单次造兵加成道具
USE_TOOL_MAKE_TRAP_EFFECT = "use.tool.make.trap" --X及陷阱单次制造数量加成
USE_TOOL_KILL_MONSTER_EFFECT = "use.tool.kill.monster" --下次杀怪加成道具

SettingListPlayerId = "240020"
ThroneId = "240021" -- 王座id
SPECIAL_MONTH_CARD_ID_QJS = "763000" --奇迹石月卡
SCIENCE_SECEND_QUEUE = "80007" --科技二队列

AAreaState = {
    Astate_None = -1,
    Astate_Building = 0, --建造中
    Astate_BeforeBuild = 1, --未出兵建造
    Astate_Garrison = 2, --已驻防
    Astate_UnGarrison = 3, --未驻防
    Astate_Damaged = 4, --破损-未采集
    Astate_FixIng = 5, --修理中
    Astate_Destroy = 6, --被摧毁中-采集中
    Astate_Donate = 7, --捐献状态
}

HFVIEWPORT_VIEW_TAG = 68686868

CityType = {
    CityMain = 1,       --主城
    CityCivFortress = 2,--文明堡垒分城
}

MONTHCARD_EXP_TYPE = 6868
