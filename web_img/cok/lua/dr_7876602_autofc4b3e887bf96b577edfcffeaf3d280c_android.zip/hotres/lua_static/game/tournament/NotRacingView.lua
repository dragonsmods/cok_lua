local NotRacingView = class("NotRacingView", function()
    return PopupBaseView:create()
end)

local TournamentControllerInst = TournamentControllerInst

function NotRacingView:ctor()
end
   

function NotRacingView:create(tour_stage,data)
	
    local view = NotRacingView.new()
    Drequire("game.tournament.NotRacingView_ui"):create(view, 0)
    if view:initView(tour_stage,data) then return view end
end

function NotRacingView:onEnter()
	-- self.ui.m_notiTime:onEnterOuter()
	-- self.ui.m_notiTime:onEnter()
	self.m_cdLabel:onEnter()
end

function NotRacingView:closeSelf(  )
	PopupViewController:call("removePopupView", self)
end

function NotRacingView:onExit()
  	self.m_cdLabel:onExit()
end

function NotRacingView:initView(tour_stage,data)
	self.m_curStage = tour_stage
	self.m_curData = data

	

	-- local cdLabel = Drequire("utils.cdLabel")
	-- local clll = cdLabel.create(self.ui.m_notiTime)
	self.m_cdLabel = utils.attachCDForLabel(self.ui.m_notiTime,{{func=function (  )
		local next_stage = tour_stage_num + 1
		if next_stage == self:getStageConfig().JingJiQi then
			self:closeSelf()
		end
		TournamentControllerInst:requestLadderInfo()
	end}})
	self:refreshViewByStage(tour_stage,data)


	
	-- self:runAction(utils.getDelayAction(1,function (  )
	-- 	TournamentControllerInst:requestLadderInfo()
	-- end))
    return true
end

function NotRacingView:refreshViewByStage( tour_stage,data )
	local tour_stage_num = tonumber(tour_stage)

	-- self.ui.m_mainTitle:setString(TournamentControllerInst:getTextStr(tour_stage))
	self:setContentTxt(tour_stage,data)
	self:setBox(tour_stage)

	self.m_cdLabel:reset(tonumber(data.nextTime))

	-- local cdLabel = Drequire("utils.cdLabel")
	-- local clll = cdLabel.create(self.ui.m_notiTime)

	-- local timeNow = utils.timeNow()
	-- self.ui.m_notiTime:resetCD(timeNow + 10000)
end

function NotRacingView:setContentTxt( tour_stage,data )
	dump(data,"NotRacingView:setContentTxt")
	local textArr = self:findTxtArr(tour_stage)
	local txtStr = TournamentControllerInst:getTextStr(tour_stage)
	assert(#textArr == #txtStr)
	textArr[1]:setString(txtStr[1])
	textArr[2]:setString(txtStr[2])

	local tour_stage_num = tonumber(tour_stage)
	local stringTbl = TournamentControllerInst:getStringTbl()

	if tour_stage_num == self:getStageConfig().Match then
		textArr[3]:setString(txtStr[3])
	elseif tour_stage_num == self:getStageConfig().Prepare then
		assert(not string.isNilOrEmpty(data.group))
		local t_arr = string.split(data.group,";")
		for i,v in ipairs(t_arr) do
			t_arr[i] = '#'..v
		end
		local str1 = table.concat(t_arr,"\n")
		textArr[3]:setString(str1)
	elseif tour_stage_num == self:getStageConfig().Calculate then
		local t_arr = {
			getLang(stringTbl.ShangYiSaiji) ,
			getLang(stringTbl.ZuiGaoDuanWei) .. TournamentControllerInst:getTitle(data.maxGrade),
			getLang(stringTbl.ZuiGaoBeiShu) .. data.maxCup ,
			getLang(stringTbl.ZuiGaoPaiMing) .. string.readbleStr(data.maxRank,{"-1"},{getLang("default")}) ,
			data.privilege == "0" and "" or (getLang(stringTbl.TeQuanTianShu) .. data.privilege)
		}


		local str1 = table.concat(t_arr,"\n")
		textArr[3]:setString(str1)
	elseif tour_stage_num == self:getStageConfig().Blank then
		local t_arr = {
			getLang(stringTbl.ShangYiSaiji) ,
			getLang(stringTbl.ZuiGaoDuanWei) .. TournamentControllerInst:getTitle(data.maxGrade),
			getLang(stringTbl.ZuiGaoBeiShu) .. data.maxCup ,
			getLang(stringTbl.ZuiGaoPaiMing) .. string.readbleStr(data.maxRank,{"-1"},{getLang("default")}) ,
			data.privilege == "0" and "" or (getLang(stringTbl.TeQuanTianShu) .. data.privilege),
			"",
			"",
			getLang(stringTbl.XiayiSaiji) ,
			getLang(stringTbl.QiShiDuanwei) .. TournamentControllerInst:getTitle(data.nextGrade) ,
			getLang(stringTbl.QiShiBeiShu) .. data.nextCup ,
		}


		local str1 = table.concat(t_arr,"\n")
		textArr[3]:setString(str1)
	end

	--button
	local btns = {
		{self.ui.m_ruleBtn,stringTbl.GuiZeShuoming},
		{self.ui.m_seasonReward,stringTbl.SaiJiJiangLi},
		{self.ui.m_fightLvlBtn,stringTbl.JiNeng},
	}

	for i,v in ipairs(btns) do
		CCCommonUtilsForLua:setButtonTitle(v[1], getLang(v[2]))
	end

	-- for i,v in ipairs(textArr) do
	-- 	v:setString(txtStr[i])
	-- end
end

function NotRacingView:getStageConfig(  )
	if not self.m_tourStageCfg then
		self.m_tourStageCfg = TournamentControllerInst:getStageConfig()
	end
	return self.m_tourStageCfg
end

function NotRacingView:findTxtArr( tour_stage )
	local c_idx = tour_stage == self:getStageConfig().Prepare and 2 or 1
	for i=1,2 do
		self.ui["m_ctxt" .. i]:setVisible(i == c_idx)
	end
	local curContentTxt = self.ui["m_ctxt" .. c_idx]
	assert(self.ui.m_notiDesc,'no self.ui.m_notiDesc')
	assert(self.ui.m_titleTxt,'no self.ui.m_titleTxt')
	assert(curContentTxt,"m_ctxt" .. c_idx)
	return {self.ui.m_notiDesc,self.ui.m_titleTxt,curContentTxt}
end

function NotRacingView:setBox( tour_stage )
	local isVisi = tour_stage == self:getStageConfig().Calculate
	local isAnimate = false
	if isVisi then

	end
	utils.setBox(self.ui.m_boxNode,isVisi,isAnimate)
end

function NotRacingView:onClickRule(pSender, event)
	TournamentControllerInst:showRaceInterduce()
end

function NotRacingView:onClickSeasonReward(pSender, event)
	TournamentControllerInst:showRankRewardPreview(2)
end

function NotRacingView:onClickFightLevel(pSender, event)
end

return NotRacingView