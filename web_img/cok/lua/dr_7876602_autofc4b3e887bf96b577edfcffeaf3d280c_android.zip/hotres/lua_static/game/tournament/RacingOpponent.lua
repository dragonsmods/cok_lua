local RacingOpponent = class("RacingOpponent", cc.Layer)

function RacingOpponent:ctor()
end
   

function RacingOpponent:create(data)
    local view = RacingOpponent.new()
    Drequire("game.tournament.RacingOpponent_ui"):create(view, 0)
    if view:initView(data) then return view end
end

function RacingOpponent:onEnter()
	self.m_uid = utils.getSelfUid()
	
end

function RacingOpponent:closeSelf(  )
	PopupViewController:call("removePopupView", self)
end

function RacingOpponent:onExit()
end

function RacingOpponent:onCleanup()
  	TournamentControllerInst:getLadderFightEvent():remove(self.onFightResp,self)
	TournamentControllerInst:getLadderRefreshEvent():remove(self.onRefreshResp,self)
	TournamentControllerInst:getAddFightNumEvent():remove(self.onAddFightNumResp,self)
end

function RacingOpponent:initView(data)
	self.m_serverData = data

	TournamentControllerInst:getLadderFightEvent():add(self.onFightResp,self)
	TournamentControllerInst:getLadderRefreshEvent():add(self.onRefreshResp,self)
	TournamentControllerInst:getAddFightNumEvent():add(self.onAddFightNumResp,self)

	local stringTbl = TournamentControllerInst:getStringTbl()
	local staticTextArr = {
		-- {self.ui.m_text1,stringTbl.HouGuanBi},
		{self.ui.m_text3,stringTbl.ShuaXingCD},
		{self.ui.m_text5,stringTbl.TiaoZhanShuoMing},
		{self.ui.m_text6,stringTbl.TiaoZhanCiShu},
		{self.ui.m_text8,stringTbl.TiaoZhanCD},
	}

	local dynTextArr = {
		-- {self.ui.m_text2},
		-- {self.ui.m_text4},
		{self.ui.m_text7},
		{self.ui.m_text9},
	}

	local buttonTextArr = {
		{self.ui.m_refreshBtn,stringTbl.ShuaXing},
	}

	for _,v in ipairs(staticTextArr) do
		v[1]:setString(getLang(v[2],v[3],v[4]))
	end

	for _,v in ipairs(buttonTextArr) do
		CCCommonUtilsForLua:setButtonTitle(v[1], getLang(v[2]))
	end

	for _,v in ipairs(dynTextArr) do
		v[1]:setString(tostring(100))
	end

	self.ui.m_contentTable:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)

	self:refreshByData(data)

	utils.adaptTableSize(self.ui.m_contentTable,self.ui.m_topFlag)

	-- m_text4
	self.m_inRefreshCd = true
	self.m_inChallengeCd = true
	local leftTime = math.max(0,tonumber(data.nextFlush) / 1000 - utils.timeNow())
	utils.attachCDForLabel(self.ui.m_text4,leftTime,{{func = function (  )
		cclog("m_inRefreshCd end")
		self.m_inRefreshCd = nil
	end}})

	local leftTime = math.max(0,tonumber(data.nextFight) / 1000 - utils.timeNow())
	dump(leftTime,"leftTime...")
	self.ui.m_text9.m_log = true
	utils.attachCDForLabel(self.ui.m_text9,leftTime,{{func = function (  )
		cclog("m_inChallengeCd end")
		self.m_inChallengeCd = nil
	end}})

	self.m_curFightNum = {tonumber(data.myFight),tonumber(data.maxFight)}
	self:refreshFightNum()
	-- self:registerTouchFuncs()
	-- assert(false)
	self:runAction(utils.getDelayAction(2,function (  )

		local name = TroopsController:call("getInstance"):call("getFormatStrByIndex", 20)
		cclog("TroopsController:call here %s",name)
	end))
    return true
end

function RacingOpponent:refreshFightNum(  )
	if not table.isNilOrEmpty(self.m_curFightNum) then
		self.ui.m_text7:setString(string.format("%s/%s",self.m_curFightNum[2] - self.m_curFightNum[1],self.m_curFightNum[2]))
	end
end

function RacingOpponent:hasEnoughFightNum(  )
	if self.m_curFightNum then
		return self.m_curFightNum[1] < self.m_curFightNum[2]
	end
	return false
end

function RacingOpponent:refreshByData( data )
	local opponentData = TournamentControllerInst:getOpponentData(data)
	self:attachSelfIns(opponentData)
	self.ui:setTableViewDataSource("m_contentTable", opponentData)
end

function RacingOpponent:accessChallengeCd( var )
	if var ~= nil then
		self.m_inChallengeCd = var
	end
	return self.m_inChallengeCd
end

function RacingOpponent:attachSelfIns( opponentData )
	for _,v in ipairs(opponentData) do
		v.uiIns = self
	end
end

function RacingOpponent:onFightResp( res )
	dump(res,"RacingOpponent:onFightResp( res )")
	local isWin = res.winUid == self.m_uid

	local msg = isWin and getLang("140067") or getLang("140068")
	CCCommonUtilsForLua:call("flyHint", "", "", msg)

	local leftTime = math.max(0,tonumber(res.nextFight) / 1000 - utils.timeNow())
	self.ui.m_text9:reset(leftTime)

	if not table.isNilOrEmpty(self.m_curFightNum) then
		self.m_curFightNum[1] = math.numInRange(self.m_curFightNum[1] + 1,0,self.m_curFightNum[2])
		self:refreshFightNum()
	end


	if isWin then
		self:refreshByData(res)
	end
end

function RacingOpponent:onRefreshResp( res )
	dump(res,"RacingOpponent:onRefreshResp")
	self:refreshByData(res)

	local leftTime = math.max(0,tonumber(res.nextFight) / 1000 - utils.timeNow())
	self.ui.m_text9:reset(leftTime)

	-- local isWin = res.winUid == self.m_uid
	-- local msg = isWin and "you win" or "you loss"
	-- CCCommonUtilsForLua:call("flyHint", "", "", msg)
end


function RacingOpponent:onRefreshClick(pSender, event)
	-- if self.m_inRefreshCd then
	-- 	CCCommonUtilsForLua:call("flyHint", "", "", "refresh cd...")
	-- 	return
	-- end

	self.m_inRefreshCd = true
	TournamentControllerInst:requestRefresh()
end

function RacingOpponent:onAddClick(pSender, event)
	if self.m_curFightNum and self.m_curFightNum[1] == 0 then
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("620114"))
	else
		local have_num = TournamentControllerInst:getAddNumItemNum()
		cclog("have_num %s",have_num)
		TournamentControllerInst:showItemGetMethodView()
		-- TournamentControllerInst:requestAddFightNum()
	end
end

function RacingOpponent:onAddFightNumResp( res )
	dump(res,"RacingOpponent:onAddFightNumResp")
	self.m_curFightNum = {tonumber(res.myFight),tonumber(res.maxFight)}
	self:refreshFightNum()
end

-- function RacingOpponent:onTouchBegan( x,y )
-- 	if not isTouchInside(self.ui.m_bg,x,y) then
-- 		return true
-- 	end
-- 	return false
-- end

-- function RacingOpponent:onTouchMoved(x, y)

-- end

-- function RacingOpponent:onTouchEnded( x,y )
-- 	if not isTouchInside(self.ui.m_bg,x,y) then
-- 		self:closeSelf()
-- 	end
-- end

return RacingOpponent