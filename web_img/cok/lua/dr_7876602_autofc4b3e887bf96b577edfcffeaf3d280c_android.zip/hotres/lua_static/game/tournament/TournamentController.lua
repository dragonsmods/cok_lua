local TournamentController = class("TournamentController")
--[[
]]

--[[
"LadderInfoCmd:handleReceive" = {
    "cmd"    = "ladder.info"
    "params" = {
        "_cok_"      : "147167000054",
        "addingTime" : "1560147250",
        "curCoin"    : "1200",
        "curCup"     : "1200",
        "curGrade"   : "1:2",
        "curRank"    : "-1"
        "infoDic"    : {
        },
        "matchers"   : {
            1 = *MAX NESTING*
        },
        "maxFight"   : "8",
        "myFight"    : "0",
        "nextFight"  : "60000",
        "nextFlush"  : "600000",
        "nextTime"   : "1562169600",
        "status"     : "3"
    }
}

"LadderFightCmd:handleReceive" = {
    "cmd"    = "ladder.info"
    "params" = {
        "_cok_"      = "164248000088"
        "addingTime" = "1560164484"
        "curCoin"    = "1290"
        "curCup"     = "1290"
        "curGrade"   = "1:2"
        "curRank"    = "-1"
        "infoDic" = {
        }
        "matchers" = {
            1 = *MAX NESTING*
        }
        "maxFight"   = "8"
        "myFight"    = "0"
        "nextFight"  = "1560164340006"
        "nextFlush"  = "600000"
        "nextTime"   = "1562169600"
        "status"     = "3"
    }
}

]]

local RefreshSelfKeys = {
    "curCoin",
    "curCup" ,
    "curGrade",
    "curRank",
    "maxFight",
    "myFight" ,
    "phaseId",
    "startTime",
    "additem",
    "additemuse",
}

local StringTbl = {
    ResPackage                 = "Tournament_face",--动态资源包
    FunOpen                    = "ladder_switch",--功能入口开关
    JingJiChang                = "620026",--竞技场
    GeRenXingXi                = "620051",--个人信息
    TiaoChanDuiShou            = "620052",--挑战对手
    PaiHangBang                = "620053",--排行榜
    PiPeiQi                    = "620027",--匹配期
    ZhunBeiQi                  = "620028",--准备期
    JingJiQi                   = "620029",--竞技期
    JieSuanQi                  = "620030",--结算期
    XiuZhanQi                  = "620031",--休战期
    -- HuangJinSanJie             = "default",--黄金三阶
    JingJiPaiMing              = "620044",--竞技排名
    JingJiBi                   = "620045",--竞技币
    JiangLi                    = "3200031",--奖励
    PaiMingJiangLiXiangQing    = "620081",--排名奖励详情
    MeiRiPaiMingLingJiang      = "620047",--每日排名领奖
    SaiJiJiangLi               = "620039",--赛季奖励
    JunXianJiNeng              = "620040",--军衔技能
    JingJiShangDian            = "620048",--竞技商店
    RiZhi                      = "620049",--日志
    BuZhiFangShou              = "620050",--布置防守部队

    HouGuanBi                  = "default",--... 后关闭功能
    ShuaXingCD                 = "620058",--刷新cd
    ShuaXing                   = "175402",--刷新
    TiaoZhanShuoMing           = "620059",--挑战说明
    TiaoZhanCiShu              = "620060",--挑战次数
    TiaoZhanCD                 = "620062",--挑战CD

    MeiRiYuLan                 = "620047",--每天排名预览
    SaiJiYuLan                 = "620039",--赛季排名预览

    JunXianDaoJu               = "default",--军衔道具
    StartTitle                 = "620001",--开始段位

    PaiMing                    = "620055",--排名
    BeiShu                     = "620056",--杯数
    DuiWu                      = "620057",--队伍数量
    TiaoZhan                   = "137531",--挑战

    JingGongRiZi               = "620067",--进攻日志
    FangShouRiZi               = "620068",--防守日志
    ChengBao                   = "620064",--城堡
    ShengLi                    = "620065",--我方胜利，获得
    ShiBai                     = "620066",--我方失败，损失
    ChaKanZhanBao              = "620063",--查看战报
    NingDeMingCi               = "620044",--您的名次
    LingJiang                  = "107516",--领奖
    JiHuo                      = "146314",--激活
    TeQuanEWai                 = "620054",--特权额外奖励
    ZhanDou                    = "175224",--战斗
    ShangYiSaiji               = "620033",--上一赛季您的成绩：
    ZuiGaoDuanWei              = "620034",--最高段位：
    ZuiGaoBeiShu               = "620035",--最高杯数
    ZuiGaoPaiMing              = "620036",--最高排名
    TeQuanTianShu              = "620037",--剩余特权天数

    XiayiSaiji                 = "620107",--下一赛季
    QiShiDuanwei               = "620108",--起始段位
    QiShiBeiShu                = "620109",--起始杯数

    NoRaceSkill                = "620110",--未获得技能时显示
    GuiZeShuoming              = "620038",--规则说明
    JiNeng                     = "620040",--技能
    Hou_Paiming                = "620111",--后开始排名
    Hou_Kaiqi                  = "620112",--后，排行榜开启

}

local TournamentStage = utils.toNumberEnum({
    {"Match",1}, --
    {"Prepare"},
    {"Competition"},
    {"Calculate"},
    {"Blank"},
})

local RankRewardType = utils.toNumberEnum({
    {"DailyRank",1}, --
    {"SeasonRank"},
})

local MsgConfig = {
    LadderInfo = {"ladder.info","tournament.local.ladder.info"},
    LadderFight = {"ladder.fight","tournament.local.ladder.fight"},
    LadderRefresh = {"ladder.refresh","tournament.local.ladder.refresh"},
    LadderReport = {"ladder.report","tournament.local.ladder.report"},
    AddFightNum = {"ladder.addFightNum","tournament.local.ladder.addFightNum"},
    LadderDailyGetReward = {"ladder.rankReward","tournament.local.ladder.rankReward"},
    SkillInfo = {"ladder.skillInfo","tournament.local.ladder.skillInfo"},
    ArmyPreview = {"ladder.preview","tournament.local.ladder.preview"},
}

local info_meta = {
    __index = function ( t,k )
        return rawget(t,k) or rawget(t,'o' .. string.headCharToUp(k))
    end
}

local Use_Fake = false


local _instance = nil
function TournamentController.getInstance()
    if _instance == nil then
        _instance = TournamentController.new()
        guiCommonGlobal.controllerAutoPurge(_instance)
    end
    return _instance
end

function TournamentController:ctor()
    self.m_onLadderInfoEvent =      utils.getEventClass():new()
    self.m_onLadderFightEvent =     utils.getEventClass():new()
    self.m_onLadderRefreshEvent =   utils.getEventClass():new()
    self.m_onLadderReportEvent =    utils.getEventClass():new()
    self.m_onAddFightNumEvent =     utils.getEventClass():new()
    self.m_onLadderDailyGetRewardEvent =     utils.getEventClass():new()
    self.m_onSkillGotEvent =     utils.getEventClass():new()
    self.m_onArmyPreviewEvent = utils.getEventClass():new()

    self.m_onLadderInfoEvent:add(self.onLadderInfo,self)
    -- CCLoadSprite:call("loadDynamicResourceByName", StringTbl.ResPackage)
    -- registerScriptObserver(self, self.onLadderInfo, MsgConfig.LadderInfo[2])
    self:reset()
    self.buffMap = {}
end

function TournamentController:isOpen(  )
    if self.m_openFlag then
        return self.m_openFlag
    end

    self.m_openFlag = CCCommonUtilsForLua:isFunOpenByKey(StringTbl.FunOpen)
    return self.m_openFlag
end

function TournamentController:getLadderInfoEvent(  )
    return self.m_onLadderInfoEvent
end

function TournamentController:getLadderFightEvent(  )
    return self.m_onLadderFightEvent
end

function TournamentController:getLadderRefreshEvent(  )
    return self.m_onLadderRefreshEvent
end

function TournamentController:getLadderReportEvent(  )
    return self.m_onLadderReportEvent
end

function TournamentController:getAddFightNumEvent(  )
    return self.m_onAddFightNumEvent
end

function TournamentController:getLadderDailyGetRewardEvent(  )
    return self.m_onLadderDailyGetRewardEvent
end

function TournamentController:getSkillGotEvent(  )
    return self.m_onSkillGotEvent
end

function TournamentController:reset(  )

end

function TournamentController:purge()
    _instance = nil
end

function TournamentController:getStageConfig(  )
    return TournamentStage
end

function TournamentController:getTextStr( tour_stage )
    assert(tour_stage)

    local stage_title = self.m_stage_title
    if not stage_title then
        stage_title = {
            {getLang(StringTbl.PiPeiQi),    getLang(StringTbl.PiPeiQi),     getLang(StringTbl.PiPeiShuoMing)},
            {getLang(StringTbl.ZhunBeiQi),  getLang(StringTbl.ZhunBeiQi),   getLang("default")},
            {getLang(StringTbl.JingJiQi),   getLang(StringTbl.JingJiQi),    getLang("default")},
            {getLang(StringTbl.JieSuanQi),  getLang(StringTbl.JieSuanQi),   getLang("default")},
            {getLang(StringTbl.XiuZhanQi),  getLang(StringTbl.XiuZhanQi),   getLang("default")}
        }
        self.m_stage_title = stage_title
    end
    return stage_title[tonumber(tour_stage)]
end

function TournamentController:getStringTbl(  )
    return StringTbl
end

function TournamentController:getTitle( titleStr )
    local t_arr = string.split(titleStr,":")
    local titleNames = self.m_titleNames
    if not titleNames then
        titleNames = {}

        local start_title = tonumber( StringTbl.StartTitle)
        for i=1,25 do
            local ti = math.floor( (i - 1) / 5) + 1
            local ti2 = (i - 1) % 5 + 1
            local tn = start_title + i - 1
            titleNames[ti] = titleNames[ti] or {}
            table.insert(titleNames[ti],getLang(tostring(tn)))
        end
        self.m_titleNames = titleNames
    end
    for i,v in ipairs(t_arr) do
        t_arr[i] = tonumber(v)
    end
    return titleNames[t_arr[1]][t_arr[2]]
end


function TournamentController:getRewardPreviewData( tType )
    if self.m_previewData and self.m_previewData[tType] then
        return self.m_previewData[tType]
    end
    self.m_previewData = self.m_previewData or {}

    local table_name = tType == RankRewardType.DailyRank and "ladder_rank" or "ladder_process"
    local t = CCCommonUtilsForLua:getGroupByKey(table_name)
    assert(not table.isNilOrEmpty(t),"no data of ".. table_name)

    self.m_previewData[tType] = table.map2arr(t)
    return self.m_previewData[tType]
end

function TournamentController:getRewardSetById( rewardId )
    if self.m_rewardSet and self.m_rewardSet[rewardId] then
        return self.m_rewardSet[rewardId]
    end
    self.m_rewardSet = self.m_rewardSet or {}
    self.m_rewardSet[rewardId] = CCCommonUtilsForLua:getGroupByKey("reward")
    assert(not table.isNilOrEmpty(self.m_rewardSet[rewardId]))
    return self.m_rewardSet[rewardId]
end

function TournamentController:getNameEx( info )
    local cross_id = info.crossFightSrcServerId
    local cross_str = (not cross_id or cross_id == "-1") and "" or "# "..cross_id

    local alli = string.isNilOrEmpty(info.abbr) and "" or string.format("[%s]",info.abbr)
    local name_ex = string.format("%s%s %s",alli,info.name,cross_str)
    return name_ex
end

function TournamentController:makeHead( info,tHeadBg,iconSize )
    if table.isNilOrEmpty(info) then
        info = info or {}
        local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")

        info.pic = playerInfo:getProperty("pic")
        info.picVer = playerInfo:getProperty("picVer")
        info.uid = playerInfo:getProperty("uid")
        info.picfraId = playerInfo:getProperty("picfraId")
    end
    iconSize = iconSize or 95
    local headIcon = CCCommonUtilsForLua:call("makeUserHeadIcon", info.uid, info.pic, info.picfraId, info.picVer, iconSize)               
    local tHeadBg_size = tHeadBg:getContentSize()
    tHeadBg:addChild(headIcon)
    headIcon:setPosition(cc.p(tHeadBg_size.width/2,tHeadBg_size.height/2))
    return headIcon
end

--[[
    refresh 处理
]]

function TournamentController:refreshRaceData( res )
    self.m_curRaceData = self.m_curRaceData or {}
    for _,key in ipairs(RefreshSelfKeys) do
        if res[key] then
            self.m_curRaceData[key] = res[key]
        end
    end
    dump(self.m_curRaceData,"refreshRaceData")
end

--[[
    消息处理
]]

----------------------LadderInfoCmd------------------------------------------
local LadderInfoCmd = class("LadderInfoCmd", LuaCommandBase)
function LadderInfoCmd:ctor()
    self.super.ctor(self, MsgConfig.LadderInfo[1])
end

function LadderInfoCmd:handleReceive(dict)
    local cmdname = dict:valueForKey("cmd"):getCString()
    if cmdname ~= MsgConfig.LadderInfo[1] then
        return false
    end
    local rawData = dictToLuaTable(dict)
    dump(rawData.params, 'LadderInfoCmd:handleReceive')
    -- GameController:call("getInstance"):call("removeWaitInterface")

    local params = dict:objectForKey("params")
    if nil == params then
        return true
    end

    if params:objectForKey("errorCode") ~= nil then
        local errorCode = params:valueForKey("errorCode"):getCString()
        CCCommonUtilsForLua:call("flyHint", "", "", getLang(errorCode))
        return true
    end
    
    TournamentController.getInstance():refreshRaceData(rawData.params)
    TournamentController.getInstance().m_onLadderInfoEvent:emit(rawData.params)
    
    return true
end

----------------------LadderFightCmd------------------------------------------
local LadderFightCmd = class("LadderFightCmd", LuaCommandBase)
function LadderFightCmd.create(uuid)
    cclog("LadderFightCmd.create(%s)",uuid)
    local ret = LadderFightCmd.new()
    ret:initWithName(MsgConfig.LadderFight[1])
    ret:putParam("matcher",CCString:create(uuid))
    return ret
end

function LadderFightCmd:handleReceive(dict)
    local cmdname = dict:valueForKey("cmd"):getCString()
    if cmdname ~= MsgConfig.LadderFight[1] then
        return false
    end
    local rawData = dictToLuaTable(dict)
    dump(rawData, 'LadderFightCmd:handleReceive')

    local params = dict:objectForKey("params")
    if nil == params then
        return true
    end

    if params:objectForKey("errorCode") ~= nil then
        local errorCode = params:valueForKey("errorCode"):getCString()
        CCCommonUtilsForLua:call("flyHint", "", "", getLang(errorCode))
        return true
    end
    
    TournamentController.getInstance():refreshRaceData(rawData.params)
    TournamentController.getInstance().m_onLadderFightEvent:emit(rawData.params)
    return true
end

----------------------LadderRefreshCmd------------------------------------------
local LadderRefreshCmd = class("LadderRefreshCmd", LuaCommandBase)
function LadderRefreshCmd.create()
    cclog("LadderRefreshCmd.create")
    local ret = LadderRefreshCmd.new()
    ret:initWithName(MsgConfig.LadderRefresh[1])
    return ret
end

function LadderRefreshCmd:handleReceive(dict)
    local cmdname = dict:valueForKey("cmd"):getCString()
    if cmdname ~= MsgConfig.LadderRefresh[1] then
        return false
    end
    local rawData = dictToLuaTable(dict)
    dump(rawData, 'LadderRefreshCmd:handleReceive')

    local params = dict:objectForKey("params")
    if nil == params then
        return true
    end

    if params:objectForKey("errorCode") ~= nil then
        local errorCode = params:valueForKey("errorCode"):getCString()
        CCCommonUtilsForLua:call("flyHint", "", "", getLang(errorCode))
        return true
    end
    
    TournamentController.getInstance():refreshRaceData(rawData.params)
    TournamentController.getInstance().m_onLadderRefreshEvent:emit(rawData.params)
    return true
end

----------------------LadderReportCmd------------------------------------------
local LadderReportCmd = class("LadderReportCmd", LuaCommandBase)
function LadderReportCmd.create()
    cclog("LadderReportCmd.create()")
    local ret = LadderReportCmd.new()
    ret:initWithName(MsgConfig.LadderReport[1])
    return ret
end

function LadderReportCmd:handleReceive(dict)
    local cmdname = dict:valueForKey("cmd"):getCString()
    if cmdname ~= MsgConfig.LadderReport[1] then
        return false
    end
    local rawData = dictToLuaTable(dict)
    dump(rawData, 'LadderReportCmd:handleReceive')

    local params = dict:objectForKey("params")
    if nil == params then
        return true
    end

    if params:objectForKey("errorCode") ~= nil then
        local errorCode = params:valueForKey("errorCode"):getCString()
        CCCommonUtilsForLua:call("flyHint", "", "", getLang(errorCode))
        return true
    end


    for _,v in ipairs(rawData.params.ary) do
        setmetatable(v,info_meta)
    end
    
    dump("TournamentController.getInstance().m_onLadderReportEvent:emit")
    TournamentController.getInstance().m_onLadderReportEvent:emit(rawData.params)
    return true
end

----------------------AddFightNumCmd------------------------------------------
local AddFightNumCmd = class("AddFightNumCmd", LuaCommandBase)
function AddFightNumCmd.create(uuid)
    cclog("AddFightNumCmd.create(%s)",uuid)
    local ret = AddFightNumCmd.new()
    ret:initWithName(MsgConfig.AddFightNum[1])
    ret:putParam("matcher",CCString:create(uuid))
    return ret
end

function AddFightNumCmd:handleReceive(dict)
    local cmdname = dict:valueForKey("cmd"):getCString()
    if cmdname ~= MsgConfig.AddFightNum[1] then
        return false
    end
    local rawData = dictToLuaTable(dict)
    dump(rawData, 'AddFightNumCmd:handleReceive')

    local params = dict:objectForKey("params")
    if nil == params then
        return true
    end

    if params:objectForKey("errorCode") ~= nil then
        local errorCode = params:valueForKey("errorCode"):getCString()
        CCCommonUtilsForLua:call("flyHint", "", "", getLang(errorCode))
        return true
    end
    
    TournamentController.getInstance():refreshRaceData(rawData.params)
    TournamentController.getInstance().m_onAddFightNumEvent:emit(rawData.params)
    return true
end

----------------------SkillInfoCmd--------------------------------
local SkillInfoCmd = class("SkillInfoCmd", LuaCommandBase)
function SkillInfoCmd.create()
    local ret = SkillInfoCmd.new()
    ret:initWithName("ladder.skillInfo")
    return ret
end

function SkillInfoCmd:handleReceive(dict)
    local tbl, params = self:parseMsg(dict, true)
    if type(tbl) == "boolean" then return tbl end
    dump(tbl, "SkillInfoCmd")
    local tIns = TournamentController.getInstance()
    if tbl.skillGot then 
        tIns:setGotSkill(tbl.skillGot) 
    end
    CCSafeNotificationCenter:postNotification("ladder_skill_change", params)

    TournamentController.getInstance().m_onSkillGotEvent:emit(tIns:getGotSkill())
    return true
end

----------------------SkillBuyCmd--------------------------------
local SkillBuyCmd = class("SkillBuyCmd", LuaCommandBase)
function SkillBuyCmd.create(skillId)
    local ret = SkillBuyCmd.new()
    ret:initWithName("ladder.skillBuy")
    ret:putParam("skillId", CCString:create(tostring(skillId)))
    return ret
end

function SkillBuyCmd:handleReceive(dict)
    local tbl, params = self:parseMsg(dict, true)
    if type(tbl) == "boolean" then return tbl end
    dump(tbl, "SkillBuyCmd")
    local tIns = TournamentController.getInstance()
    if tbl.skillGot then tIns:setGotSkill(tbl.skillGot) end
    CCSafeNotificationCenter:postNotification("ladder_skill_change", params)
    dump(tIns:getGotSkill(),"emit getGotSkill form SkillBuyCmd")
    TournamentController.getInstance():refreshRaceData(tbl)
    TournamentController.getInstance().m_onSkillGotEvent:emit(tIns:getGotSkill())
    return true
end


----------------------LadderDailyGetRewardCmd------------------------------------------
local LadderDailyGetRewardCmd = class("LadderDailyGetRewardCmd", LuaCommandBase)
function LadderDailyGetRewardCmd.create()
    cclog("LadderDailyGetRewardCmd.create")
    local ret = LadderDailyGetRewardCmd.new()
    ret:initWithName(MsgConfig.LadderDailyGetReward[1])
    return ret
end

function LadderDailyGetRewardCmd:handleReceive(dict)
    local cmdname = dict:valueForKey("cmd"):getCString()
    if cmdname ~= MsgConfig.LadderDailyGetReward[1] then
        return false
    end
    local rawData = dictToLuaTable(dict)
    dump(rawData, 'LadderDailyGetRewardCmd:handleReceive')

    local params = dict:objectForKey("params")
    if nil == params then
        return true
    end

    if params:objectForKey("errorCode") ~= nil then
        local errorCode = params:valueForKey("errorCode"):getCString()
        CCCommonUtilsForLua:call("flyHint", "", "", getLang(errorCode))
        return true
    end
    
    TournamentController.getInstance():refreshRaceData(rawData.params)
    TournamentController.getInstance().m_onLadderDailyGetRewardEvent:emit(rawData.params)
    return true
end

----------------------ArmyPreviewCmd------------------------------------------
local ArmyPreviewCmd = class("ArmyPreviewCmd", LuaCommandBase)
function ArmyPreviewCmd.create()
    cclog("ArmyPreviewCmd.create")
    local ret = ArmyPreviewCmd.new()
    ret:initWithName(MsgConfig.ArmyPreview[1])
    return ret
end

function ArmyPreviewCmd:handleReceive(dict)
    local cmdname = dict:valueForKey("cmd"):getCString()
    if cmdname ~= MsgConfig.ArmyPreview[1] then
        return false
    end
    local rawData = dictToLuaTable(dict)
    dump(rawData, 'ArmyPreviewCmd:handleReceive')

    local params = dict:objectForKey("params")
    if nil == params then
        return true
    end

    if params:objectForKey("errorCode") ~= nil then
        local errorCode = params:valueForKey("errorCode"):getCString()
        CCCommonUtilsForLua:call("flyHint", "", "", getLang(errorCode))
        return true
    end
    
    TournamentController.getInstance():pushDataToTroopCtrl(rawData.params)
    return true
end

--[[
]]


function TournamentController:getOpenFlag(  )
    return true
end

function TournamentController:getNowStage(  )
    return TournamentStage.Match
end

function TournamentController:getAddNumItemId(  )
    if self.m_addNumId then
        return self.m_addNumId
    end
    local id = self:getCurrentRaceData("additem") or "200002"
    cclog("getAddNumItemId ... %s",id)
    assert(id)
    assert(tonumber(id))
    self.m_addNumId = tonumber(id)
    return self.m_addNumId
end

function TournamentController:getAddNumItemNum(  )
    local id = self:getAddNumItemId()
    assert(id)
    local tinfo = ToolController:call("getToolInfoByIdForLua", tonumber(id))
    return tinfo and tinfo:call("getCNT") or 0,tinfo
end

-- function TournamentController:request( msg )
-- end

function TournamentController:getRacingTabTitle(  )
    local s = self.m_tabTitleStr
    if not s then
        s = {StringTbl.GeRenXingXi,StringTbl.TiaoChanDuiShou,StringTbl.PaiHangBang}
        self.m_tabTitleStr = s
    end
    return s
end

--[[
    request
]]

function TournamentController:requestLadderInfo(  )
    if not Use_Fake then
        LadderInfoCmd.new():send()
    else

        local tbl = utils.jsonDecode([[
            {
            "_cok_"      : "147167000054",
            "addingTime" : "1560147250",
            "curCoin"    : "1200",
            "curCup"     : "1200 fake data",
            "curGrade"   : "1:2",
            "curRank"    : "-1",
            "infoDic"    : {
            },
            "matchers"   : {
                
            },
            "maxFight"   : "8",
            "myFight"    : "0",
            "nextFight"  : "60000",
            "nextFlush"  : "600000",
            "nextTime"   : "1562169600",
            "status"     : "3"
            }
            ]])
        self:refreshRaceData(tbl)
        TournamentController.getInstance().m_onLadderInfoEvent:emit(tbl)
    end
end

function TournamentController:requestFight( uuid )
    LadderFightCmd.create(uuid):send()
end

function TournamentController:requestRefresh(  )
    LadderRefreshCmd.create():send()
end

function TournamentController:requestReport(  )
    LadderReportCmd.create():send()
end

function TournamentController:requestAddFightNum(  )
    AddFightNumCmd.create():send()

    -- if self:hasEnoughAddItem(1) then
    --     AddFightNumCmd.create():send()
    -- else
    --     self:showItemGetMethodView()
    -- end
end

function TournamentController:hasEnoughAddItem( needNum )
    local tinfo = ToolController:call("getToolInfoForLua", self:getAddNumItemId())
    if nil == tinfo then
        return false
    end

    needNum = needNum or 0
    local curNum = tinfo:call("getCNT") or 0
    return curNum >= needNum, curNum
end

function TournamentController:showItemGetMethodView(  )
    cclog("showItemGetMethodView,,,")
    local ItemGetMethodView = Drequire("game.CommonPopup.ItemGetMethodView")
    PopupViewController:call("addPopupView", ItemGetMethodView:create(self:getAddNumItemId()))
end

function TournamentController:requestSkill()
    SkillInfoCmd.create():send()
end

function TournamentController:buySkill( skillId )
    SkillBuyCmd.create(skillId):send()
end

function TournamentController:requestArmyPreview(  )
    if self.m_hadPushedToTroopCtrl then
        return
    end
    ArmyPreviewCmd.create():send()
end

function TournamentController:requestGetDailyReward(  )
    LadderDailyGetRewardCmd.create():send()
end

function TournamentController:getOpponentData( params )
    local matchers = params.matchers
    return matchers
end

function TournamentController:onLadderInfo( dictTable )
    cclog("TournamentController:onLadderInfo %s",dictTable.status)
    if dictTable.status == "3" then
        self:showInRacingView(1,dictTable)
    else
        self:showNotRacingView(tonumber(dictTable.status),dictTable)
    end

end

--[[
    get data methods
]]
function TournamentController:getCurrentRaceData( key )
    if key then
        return self.m_curRaceData and self.m_curRaceData[key]
    end
    return self.m_curRaceData
end

function TournamentController:getMyRank(  )
    return self:getCurrentRaceData("curRank")
end

function TournamentController:getMyCoins(  )
    return self:getCurrentRaceData("curCoin") or "0"
end

function TournamentController:getRankRewardByRank( rank_th )
    assert(rank_th)
    if rank_th <= 0 then
        return 0
    end
    local l_data = self:getRewardPreviewData(RankRewardType.DailyRank)
    local find_data = table.find(l_data,function ( cur )
        local st,et = string.find(cur.ranking, "%d+;%d+")
        if et and st then
            if rank_th >= st and rank_th <= et then
                return true
            end
        else
            return rank_th == tonumber(cur.ranking)
        end
    end)

    return self:applyRankingMethod(find_data)
    -- if find_data then
    --     if find_data.type == "1" then -- 公式计算
    --         -- 公式：1/（名次)^0.3 *10000+500
    --         return math.floor(10000 / math.pow(tonumber(find_data.ranking), 0.3) + 500)
    --     else
    --         return tonumber(find_data.value)
    --     end
    -- else
    --     return 0
    -- end
end

function TournamentController:applyRankingMethod( find_data )
    if find_data then
        if find_data.type == "1" then -- 公式计算
            -- 公式：1/（名次)^0.3 *10000+500
            return math.floor(100000 / math.pow(tonumber(find_data.ranking), 0.27) + 4000)
        else
            return tonumber(find_data.value)
        end
    else
        return 0
    end
end

function TournamentController:getMyRankReward(  )
    local myRank = self:getCurrentRaceData("curRank") or 0
    myRank = tonumber(myRank)
    return self:getRankRewardByRank(myRank)
end

function TournamentController:getRaceStoreItems( itemType )
    local itemData = self.m_raceStoreItems
    if not itemData then
        itemData = {CCCommonUtilsForLua:getGroupByKey("ladder_gamble_mall"),CCCommonUtilsForLua:getGroupByKey("ladder_wr_skil")}
        assert(not table.isNilOrEmpty(itemData[1]),"no ladder_gamble_mall")
        assert(not table.isNilOrEmpty(itemData[2]),"no ladder_wr_skil")

        self.m_raceStoreItems = itemData
    end
    
    return itemData[itemType or 1]
end

function TournamentController:getLadderWrSkillById( skillId )
    local info = self:getRaceStoreItems(2)
    dump(info,"self:getRaceStoreItems(2)")
    assert(info[skillId],"no skill in ladder_wr_skil " .. skillId)
    return info[skillId]
end

function TournamentController:getExchangeStroeIns(  )
    self.m_curShopIns = self.m_curShopIns or Drequire("game.shop.ShopMallController").new(103)
    return self.m_curShopIns
end

function TournamentController:isRankTimeAvalible(  )
    if LUA_DEBUG == 1 then
        return true
    end
    local startTime = tonumber( self:getCurrentRaceData("startTime") or "0")
    local timeNow = utils.timeNow()

    if startTime == 0 then
        return false,utils.trimTimeStampToZero(timeNow) + 86400
    end

    startTime = startTime / 1000
    local timeNow = utils.timeNow()
    return (startTime + 86400) < timeNow , startTime + 86400 - timeNow
end

function TournamentController:pushDataToTroopCtrl( params )
    if params then
        local dict
        local cvt_keys = {
            {"aormationId","aormationId"},
            {"dragonUid","dragonFormation"},
            {"generalId","heroFormation"},
        }

        for _,v in ipairs(cvt_keys) do
            local paramId = params[v[1]]
            if paramId then
                dict = dict or CCDictionary:create()
                dict:setObject(CCString:create(paramId),v[2])
            end
        end

        local soliders = params.soliders
        if not table.isNilOrEmpty(soliders) then
            local r = {}
            for k,v in pairs(soliders) do
                table.insert(r,k .. ',' .. v)
            end
            soliders = table.concat(r,'|')
            dict = dict or CCDictionary:create()
            dict:setObject(CCString:create(soliders),"formation")
        end

        if dict then
            cclog("do pushDataToTroopCtrl")
            local defaultValues = {
                {"","customName"},
                {"20","index1"},
                {"0","numType"}
            }

            for _,v in ipairs(defaultValues) do
                dict:setObject(CCString:create(v[1]),v[2])
            end

            local array = CCArray:create()
            dict = tolua.cast(dict, "cc.Ref")
            array:addObject(dict)

            local dic1 = CCDictionary:create()
            dic1:setObject(array, "army_formation")

            self.m_hadPushedToTroopCtrl = true
            TroopsController:call("getInstance"):call("initFormatData", dic1)
        end

    end
end

--[[
    ui

    {"Match",1}, --
    {"Prepare"},
    {"Competition"},
    {"Calculate"},
    {"Blank"},
]]

-- local test_arr = {
--     {TournamentStage.Match,utils.jsonDecode([[{
--     "_cok_"      : "517382000034",
--     "addingTime" : "1560517401",
--     "curCoin"    : "6290",
--     "group"      : "42;142;2",
--     "infoDic"    : {},
--     "nextTime"   : "1560520955",
--     "phaseId"    : "5885402",
--     "status"     : "2"
-- }]])},
--     {TournamentStage.Prepare,utils.jsonDecode([[{
--     "_cok_"      : "517382000034",
--     "addingTime" : "1560517401",
--     "curCoin"    : "6290",
--     "group"      : "42;142;2",
--     "infoDic"    : {},
--     "nextTime"   : "1560520955",
--     "phaseId"    : "5885402",
--     "status"     : "2"
-- }]])},
--     {TournamentStage.Calculate,utils.jsonDecode([[{
--     "_cok_"      : "517571000054",
--     "addingTime" : "1560517657",
--     "cup"        : "1000",
--     "curCoin"    : "6290",
--     "infoDic"    : {},
--     "maxCup"     : "0",
--     "maxGrade"   : "1:1",
--     "maxRank"    : "-1",
--     "nextTime"   : "1560521149",
--     "phaseId"    : "5885401",
--     "privilege"  : "0",
--     "status"     : "4"
-- }]])},
--     {TournamentStage.Blank,utils.jsonDecode([[{
--     "_cok_"      : "517571000076",
--     "addingTime" : "1560517712",
--     "curCoin"    : "6290",
--     "infoDic"    : {},
--     "maxCup"     : "0",
--     "maxGrade"   : "1:1",
--     "maxRank"    : "-1",
--     "nextCup"    : "1000",
--     "nextGrade"  : "1:1",
--     "nextTime"   : "1560521299",
--     "phaseId"    : "5885401",
--     "privilege"  : "0",
--     "status"     : "5"
-- }]])}
-- }

-- local test_ct = 0

function TournamentController:setRank( label,rank )
    local hasRankNow = tonumber(rank or 0) > 0
    if hasRankNow then
        label:setString(rank)
    else
        return utils.attachCDForLabel(label,utils.getNextDaySecs(),nil,nil," ".. getLang(StringTbl.Hou_Kaiqi))
    end
end

function TournamentController:setInracingView( tIns )
    self.m_curOpenInRacingView = tIns
end

function TournamentController:showNotRacingView( tour_stage,res )
    -- test_ct = test_ct % (#test_arr) + 1
    -- local temp = test_arr[test_ct]
    -- tour_stage = temp[1]
    -- res = temp[2]
    local view = Drequire("game.tournament.NotRacingView"):create(tour_stage,res)
    PopupViewController:addPopupInView(view)
end

function TournamentController:showInRacingView( switchIdx,data )
    local view = Drequire("game.tournament.InRacingView"):create(switchIdx,data)
    PopupViewController:addPopupInView(view)
end

function TournamentController:showRacingExchange( switchIdx )
    local view = Drequire("game.tournament.RacingExchange"):create(switchIdx)
    PopupViewController:addPopupInView(view)
end

function TournamentController:showRacingBattleLog( switchIdx,data )
    switchIdx = switchIdx or 1
    local view = Drequire("game.tournament.RacingBattleLog"):create(switchIdx,data)
    PopupViewController:addPopupInView(view)
end

function TournamentController:showRacingChangeSoldier(  )
    local dict = CCDictionary:create()
    dict:setObject(CCString:create("MarchFormationView"), "name")
    dict:setObject(CCString:create("20"), "index")
    LuaController:call("openPopViewInLua", dict)
end

function TournamentController:showRacingSkill(  )
    local view = Drequire("game.tournament.RacingSkillView"):create()
    PopupViewController:addPopupView(view)
end

function TournamentController:showRaceInterduce(  )
    local view = Drequire("game.tournament.RaceInterduce"):create()
    PopupViewController:addPopupView(view)
end

function TournamentController:showDailyRankReward(  )
    local view = Drequire("game.tournament.RacingDailyRankReward"):create()
    PopupViewController:addPopupView(view)
end

function TournamentController:showRankRewardPreview( rewardType )
    if rewardType == RankRewardType.SeasonRank then
        local data = {type=rewardType,data=self:getRewardPreviewData(rewardType)}
        local view = Drequire("game.tournament.RacingRankRewardPreview"):create(data)
        PopupViewController:addPopupView(view)
    else
        if self.m_curOpenInRacingView then
            self.m_curOpenInRacingView:showDailyRankReward()
        end
    end
end

function TournamentController:showRaceBattle( uuid )
    local view = Drequire("game.tournament.RacingBattle"):create(uuid)
    PopupViewController:addPopupView(view)
end

--[[
    npc 处理
]]
function TournamentController:createNpc()
    if self:isOpen() then
        return Drequire("game.tournament.TournamentNpc"):create()
    end
end

-- 获取npc的坐标和缩放倍数
function TournamentController:getNpcData()

    local race_npc_pos = self.m_race_npc_pos
    if not race_npc_pos then
        race_npc_pos = {}
        self.m_race_npc_pos = race_npc_pos
        race_npc_pos[RACE_TYPE_LONG_YI]     = {3300,298}
        race_npc_pos[RACE_TYPE_WEI_JING]    = {3045,213}
        race_npc_pos[RACE_TYPE_DA_HE]       = {3360,150}
        race_npc_pos[RACE_TYPE_HUA_XIA]     = {3374,178}
    end

    local _raceType = CCCommonUtilsForLua:call("RACETYPE")
    local _x,_y = unpack(race_npc_pos[_raceType])

    dump(race_npc_pos,"race_npc_pos is ")
    local _xmlScale = 1
    local _scale = tonumber(_xmlScale) or 1

    local _dynamicRes = "Tournament_face"
    return {x = _x, y = _y, scale = _scale, dynamicRes = _dynamicRes}
end

--login.other同步buff
function TournamentController:initData(dict)
    if dict == nil then return end
	local ladderSkill = dict:objectForKey("ladderSkill")
	if ladderSkill then
        local skillBuffArr = ladderSkill:objectForKey("skillBuffArr")
        if skillBuffArr then
            local buffArr = arrayToLuaTable(skillBuffArr)
            self:updateBuffMap(buffArr)
        end
	end
end

--更新buff池
function TournamentController:updateBuffMap(buffArr)
    self.buffMap = {}
    for _, buff in ipairs(buffArr) do
        self.buffMap[buff.effectKey] = atoi(buff.effectValue)
    end
end

function TournamentController:getGroupTblById(groupId)
    if nil == self.m_xmlTbl then
        self.m_xmlTbl = {}
        local skillTbl = CCCommonUtilsForLua:getGroupByKey("ladder_wr_skil")
        for k, v in ipairs4ScatteredT(skillTbl) do
            if nil == self.m_xmlTbl[tonumber(v.group)] then
                self.m_xmlTbl[tonumber(v.group)] = {}
            end
            self.m_xmlTbl[tonumber(v.group)][tonumber(v.level)] = v
        end
    end
    return self.m_xmlTbl[tonumber(groupId)]
end

function TournamentController:setGotSkill(gotSkills)
    dump(gotSkills,"TournamentController:setGotSkill(gotSkills)")
    self.gotSkills = {}
    local tempTbl = string.split(gotSkills, "|")
    for k,v in pairs(tempTbl) do
        local tempGotTbl = string.split(v, ";")
        self.gotSkills[tempGotTbl[2]] = tempGotTbl[1]
    end
end

function TournamentController:getGotSkill()
    return self.gotSkills or {}
end

--获取buff作用号
function TournamentController:getEffectValueByNum(num)
    return atoi(self.buffMap[tostring(num)])
end

return TournamentController