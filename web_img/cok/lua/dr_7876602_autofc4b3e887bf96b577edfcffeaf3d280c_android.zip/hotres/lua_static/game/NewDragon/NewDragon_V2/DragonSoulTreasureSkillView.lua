local DragonSoulTreasureSkillView = class("DragonSoulTreasureSkillView", cc.Layer)




function DragonSoulTreasureSkillView:ctor()
   CCLoadSprite:call("loadDynamicResourceByName", "dragonCave")
   CCLoadSprite:call("loadDynamicResourceByName", "dragonCave1")
   CCLoadSprite:call("loadDynamicResourceByName", "DragonSoulTreasure_face")
	
	  Drequire("game.NewDragon.NewDragon_V2.DragonSoulTreasureSkillView_ui"):create(self, 0)
	
    self.controller =  require("game.NewDragon.NewDragon_V2.DragonSoulTreasureCtr").getInstance()
   
  
	
end

function DragonSoulTreasureSkillView:create()

	local node = DragonSoulTreasureSkillView.new()
	if node:initNode() then return node end
end

function DragonSoulTreasureSkillView:initNode( )
 
  local function touchHandle( eventtype, x, y )
  	dump(eventtype,"eventtype----")
    if eventtype == "began" then
      return self:onTouchBegan(x, y)  
    elseif(eventtype == "ended")  then
     return self:onTouchEnded(x, y)
    end
    	
  end

  self:registerScriptTouchHandler(touchHandle)
  self:setTouchEnabled(true)	   
   self:setSwallowsTouches(true)
   
	dump(self.controller:getAllskillList(),"self.controller.getAllskillList-------")
   self.ui:setTableViewDataSource("m_tableview",  self.controller:getAllskillList())
  
      
	return true
end


function DragonSoulTreasureSkillView:onTouchBegan(x, y)
	if  touchInside(self, x, y) then
		self.startPoint = cc.p(x,y)
		return true
	end
end

function DragonSoulTreasureSkillView:onTouchEnded(x,y)
	if not touchInside(self.ui.m_tableview, x, y) and  (not touchInside(self.ui.m_tableview, self.startPoint.x, self.startPoint.y) )then
		self:removeFromParent()
	end
end




function DragonSoulTreasureSkillView:onEnter( )
	--self:setTitleName(getLang("139377"))
  
  
end

function DragonSoulTreasureSkillView:onExit( )
	

  
end



return DragonSoulTreasureSkillView