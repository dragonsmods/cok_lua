local DragonSoulTreasureView = class("DragonSoulTreasureView", function()
 return PopupBaseView:create() 
end)

DragonSoulTreasureView.__index = DragonSoulTreasureView


function DragonSoulTreasureView:ctor()
   CCLoadSprite:call("loadDynamicResourceByName", "dragonCave")
   CCLoadSprite:call("loadDynamicResourceByName", "dragonCave1")
   CCLoadSprite:call("loadDynamicResourceByName", "DragonSoulTreasure_face")
	
	Drequire("game.NewDragon.NewDragon_V2.DragonSoulTreasureView_ui"):create(self, 1)
	
    self.controller =  require("game.NewDragon.NewDragon_V2.DragonSoulTreasureCtr").getInstance()
   
    self.animationTime = 0
    self.count = 2
	
end

function DragonSoulTreasureView:create()

	local node = DragonSoulTreasureView.new()
	if node:initNode() then return node end
end

function DragonSoulTreasureView:initNode( )	
	
    
      self.controller:reqData()
      self.ui.m_titleTxt:setString(getLang("139377"))
     --
	for i=1,self.controller.IETM_NUM do

		 local cell = Drequire("game.NewDragon.NewDragon_V2.DragonSoulTreasureViewCell"):create(i)
          self.ui.m_nodeitems:addChild(cell)
          cell:setTag(i)
          local cellSize = cell:getContentSize()
          local x =  cellSize.width * ((i-1)%5)
          local y =   self.ui.m_nodeitems:getContentSize().height - (cellSize.height * math.floor((i-1)/5+1))
          cell:setPosition(cc.p(x,y))

	   
	end
   self.time = {0.16,0.3,1,1.23,1.38,1.58}

    local isPad = CCCommonUtilsForLua:isIosAndroidPad() 
    if isPad then
      self.ui.m_sprBgUp:setVisible(false)
      self.ui.m_nodeBg:setScale(0.82)
       self.ui.m_nodeitems:setScale(0.82)
    end

   if CCCommonUtilsForLua:call("checkBeIphoneX") then 
   
        self.ui.m_nodeMain:setPositionY(135)  
    end

   
      
	return true
end

function DragonSoulTreasureView:playGigAction(dict)
	local data = dictToLuaTable(dict)
	local index = data.index

   if self.entry  then
          self:getScheduler():unscheduleScriptEntry(self.entry)
         self.entry = nil
    end

    self.ui.m_sprAnimation:setVisible(true)
    self.ui.m_sprAnimation:setZOrder(999)

     local sf = CCSpriteFrameCache:sharedSpriteFrameCache():spriteFrameByName("DragonSoulTreasureBroken_1.png")
     if sf then
     	self.ui.m_sprAnimation:setSpriteFrame(sf)
     end
   local child =  self.ui.m_nodeitems:getChildByTag(index)
  
   if child then   	 
   	  local childSize = child:getContentSize()
   	  self.ui.m_sprAnimation:setPosition(cc.p(child:getPositionX() + childSize.width/2,child:getPositionY() + childSize.height/2))
   end
  
    self.entry = tonumber(self:getScheduler():scheduleScriptFunc(function(dt)
     
    self:onAnimation(dt)
      
	
	end, 0.1, false))   

end

function DragonSoulTreasureView:onAnimation( dt )
	
	self.animationTime = self.animationTime  + dt
	if self.count == 6 then
		self.animationTime = 0
		self.count=2
		self.ui.m_sprAnimation:setVisible(false)

	      if self.entry then
           self:getScheduler():unscheduleScriptEntry(self.entry)
            self.entry = nil
        end
       
       
	end

    if  self.animationTime  >= self.time[self.count] then
    	
    		Dprint("self.count-----",self.count,self.time[self.count])
    	 local sf = CCSpriteFrameCache:sharedSpriteFrameCache():spriteFrameByName("DragonSoulTreasureBroken_"..self.count..".png")
          if sf then
          	self.ui.m_sprAnimation:setSpriteFrame(sf)
    		self.count = self.count+1
           
          end
    end
	
end




function DragonSoulTreasureView:refreshUI( )
	 self.ui.m_getFreeButton:setEnabled(true)
	 dump(self.controller.gotList,"self.controller.gotList")

     local  costStr =   self.controller.resetCost == 0 and getLang("139381") or self.controller.resetCost
	 self.ui.m_lbPay:setString(costStr)
	  self.ui.m_lbGragonSoul:setString(self.controller.soulNum)
     self.ui:setTableViewDataSource("m_TableView",  self.controller.skillList)
  
end


function DragonSoulTreasureView:onClickBtnReset( )

  local  function confirmFunc( )
      self.ui.m_getFreeButton:setEnabled(false)
     self.controller:reqResetData()
  end

  local func = cc.CallFunc:create(confirmFunc)
  YesNoDialog:call("showButtonAndGold", getLang("134032"), func, getLang("110031"), self.controller.resetCost)
	
      
    
  
end



function DragonSoulTreasureView:onClickBuyBtn()
	local view = Drequire("game.CommonPopup.ItemGetMethodView"):create("215607")
    PopupViewController:call("addPopupView", view)
  
  
end
---龙技能展示
function DragonSoulTreasureView:onClickBtnReward( ... )

    local view = Drequire("game.NewDragon.NewDragon_V2.DragonSoulTreasureSkillView"):create()
    self:addChild(view)
  
end


function DragonSoulTreasureView:onEnter( )
    -- dump("DragonSoulTreasureView:onEnter ~~~~~~~~")
	--self:setTitleName(getLang("139377"))
    registerScriptObserver(self, self.refreshUI, "DragonSoulTreasureView_refresh")
    registerScriptObserver(self, self.playGigAction, "DragonSoulTreasureView_playGigAction")   
    registerScriptObserver(self, self.updateSoulNum, PAYMENT_COMMAND_RETURN)
  
end

function DragonSoulTreasureView:onExit( )
    -- dump("DragonSoulTreasureView:onExit ~~~~~~~~")
	  unregisterScriptObserver(self, "DragonSoulTreasureView_refresh")
	  unregisterScriptObserver(self, "DragonSoulTreasureView_playGigAction")
    unregisterScriptObserver(self, PAYMENT_COMMAND_RETURN)
	  if self.entry  then
	  	    self:getScheduler():unscheduleScriptEntry(self.entry)
         self.entry = nil
	  end  
end

function DragonSoulTreasureView:updateSoulNum()
    -- dump("DragonSoulTreasureView:updateSoulNum ~~~~~~~~")
    self.controller:updateSoulNum()
    self:refreshUI()
end


return DragonSoulTreasureView