local DragonSoulTreasureSkillCell = class("DragonSoulTreasureSkillCell",function()
     return CCTableViewCell:new()
     end)


function DragonSoulTreasureSkillCell:ctor()
	
	  Drequire("game.NewDragon.NewDragon_V2.DragonSoulTreasureSkillCell_ui"):create(self, 0)
	
    self.controller =  require("game.NewDragon.NewDragon_V2.DragonSoulTreasureCtr").getInstance()
   
   
	
end

function DragonSoulTreasureSkillCell:create()

	local node = DragonSoulTreasureSkillCell.new(index)
	if node:initNode() then return node end
end

function DragonSoulTreasureSkillCell:initNode( )	
    
    
         
      
	return true
end




function DragonSoulTreasureSkillCell:refreshCell(info,idx)
    if not info then
       return 
    end
     for i=1,4 do
        if  self.ui["m_nodeitem"..i] then
            self.ui["m_nodeitem"..i]:setVisible(info[i] ~= nil)

        end     

     end

     for i=1,#info do
         if self.ui["m_itemNode"..i] then
            self.ui["m_itemNode"..i]:removeAllChildren()
            self.controller:createDragonSkillInfoShow(info[i], 110, self.ui["m_itemNode"..i],true)
         end
     end
end
     
  






function DragonSoulTreasureSkillCell:onEnter( )
	
   registerScriptObserver(self, self.refreshCell, "DragonSoulTreasureView_refresh")
  
end

function DragonSoulTreasureSkillCell:onExit( )
	 unregisterScriptObserver(self, "DragonSoulTreasureView_refresh")

  
end



return DragonSoulTreasureSkillCell