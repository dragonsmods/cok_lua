local NewDragonSkillChangeCell_New = class("NewDragonSkillChangeCell_New", function()
        return cc.Layer:create()
    end
)
NewDragonSkillChangeCell_New.__index = NewDragonSkillChangeCell_New

local Drequire = Drequire
------------------------------------------ NewDragonSkillChangeCell_New Start --------------------------------------------

function NewDragonSkillChangeCell_New:create(idx)
	local view = NewDragonSkillChangeCell_New.new()
    Drequire("game.NewDragon.NewDragonSkillChangeCell_New_ui"):create(view)
	if view:initView() == false then
		return nil
	end
  	return view
end

function NewDragonSkillChangeCell_New:initView()
    MyPrint("NewDragonSkillChangeCell_New:initView")
    registerTouchHandler(self)
    self:setTouchEnabled(true)
    return true
end

function NewDragonSkillChangeCell_New:refreshCell(info, idx)
    self.uuid = info.uuid
    self.dragonUuid = info.dragonUuid
    self.rootView = info.rootView
    self.specialCnt = info.specialCnt
    self.parent = info.parent
    -- self.m_switch = true
    -- dump(info,"NewDragonSkillChangeCell_New")
    local skillInfo = DragonController:call("getDragonSkillInfoByUuid", info.uuid)
    if skillInfo == nil then
        return
    end

    self.clickArea = info.clickArea
    local skillItemId = skillInfo:call("getItemId")
    MyPrint("NewDragonSkillChangeCell_New:setData skillItemId is "..tostring(skillItemId))
    local pic = CCCommonUtilsForLua:call("getIcon", skillItemId)
    local sf = CCLoadSprite:call("getSF", pic)
    if sf == nil then
        pic = "dragon_skill_1.png"
    end

    local spr = CCLoadSprite:call("createSprite", pic)
    CCCommonUtilsForLua:call("setSpriteMaxSize", spr, 70, true)
    local quality = CCCommonUtilsForLua:call("getPropById", skillItemId, "quality")
    local colorBg = CCCommonUtilsForLua:call("getToolCircleBgByColor", tonumber(quality))
    local sprBg = CCLoadSprite:call("createSprite", colorBg)
    CCCommonUtilsForLua:call("setSpriteMaxSize", sprBg, 70, true)
    self.ui.m_picNode:removeAllChildren()
    self.ui.m_picNode:addChild(sprBg)
    self.ui.m_picNode:addChild(spr)
    self.skillName = CCCommonUtilsForLua:call("getNameById", skillItemId)
    local str = self.skillName.." Lv."..tostring(skillInfo:call("getLevel")).."\n"
    local descDialog = CCCommonUtilsForLua:call("getPropById", skillItemId, "desc")
    local descNum = DragonController:getDragonSkillDescValue(skillItemId, skillInfo:call("getLevel"), true, true)
     
    str = str..getLang(descDialog, tostring(descNum))
    self.ui.m_desLabel:setString(str)
    local cost = CCCommonUtilsForLua:call("getPropById", skillItemId, "learn_gold")
    self.ui.m_goldLabel:setString(cost)
    if GlobalData:call("shared"):getProperty("playerInfo"):getProperty("gold") < tonumber(cost) then
        CCCommonUtilsForLua:call("setSpriteGray", self.ui.m_replace, true)
    else
        CCCommonUtilsForLua:call("setSpriteGray", self.ui.m_replace, false)
    end
end

-- function NewDragonSkillChangeCell_New:switchChange( params )
--     local tbl = dictToLuaTable(params)
--     Dprint('abcddde NewDragonSkillChangeCell_New:switchChange',tbl.type)
--     if tonumber(tbl.type) == 1 then 
--         self.m_switch = false
--     elseif tonumber(tbl.type) == 2 then
--         self.m_switch = true
--     end
-- end

function NewDragonSkillChangeCell_New:onEnter()
    -- registerScriptObserver(self, self.switchChange, "on_click_upgrade_switch")
    -- registerScriptObserver(self, self.switchChange, "on_click_skill_change_switch")
end

function NewDragonSkillChangeCell_New:onExit()
    -- unregisterScriptObserver(self, "on_click_upgrade_switch")
    -- unregisterScriptObserver(self, "on_click_skill_change_switch")
end

function NewDragonSkillChangeCell_New:onTouchBegan(x, y)
    if touchInside(self.clickArea, x, y) and touchInside(self.ui.m_replace, x, y) and self.parent and self.parent:isVisible() then
        return true
    end
end

function NewDragonSkillChangeCell_New:onTouchMoved(x, y)
end

function NewDragonSkillChangeCell_New:onTouchEnded(x, y)   
    if touchInside(self.clickArea, x, y) and touchInside(self.ui.m_replace, x, y) and self.parent and self.parent:isVisible() then
        local dragonInfo = DragonController:call("getDragonInfoByUuid", self.dragonUuid)
        if dragonInfo == nil then
            return
        end
        local dragonLevel = dragonInfo:call("getLevel")
        local skillInfo = DragonController:call("getDragonSkillInfoByUuid", self.uuid )
        if skillInfo == nil then
            return
        end
        local skillId = skillInfo:call("getItemId")        
        local skillType = tonumber(CCCommonUtilsForLua:call("getPropByIdGroup","dragon_skill", skillId, "type"))
        if skillType == 2 then -- 特殊技能不能更换
            LuaController:flyHint("", "", getLang("164828"))
            return
        end

        local index = skillInfo:call("getIndex")
        local special = skillInfo:call("getSpecialFlag")
        local skillQuality = skillInfo:call("getQuality")
        local skillUnlockLevel = DragonController:call("getDragonSkillUnlockLevel", self.dragonUuid, index)
        if dragonLevel < skillUnlockLevel then
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("164832"))
            return
        end

        local cost = CCCommonUtilsForLua:call("getPropByIdGroup","dragon_skill", skillId, "learn_gold")
        if GlobalData:call("shared"):getProperty("playerInfo"):getProperty("gold") < tonumber(cost) then
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("104912"))
            return
        end


        local curInfo = DragonController:call("getDragonSkillInfoByUuid", self.uuid)
        local curQuality = curInfo:call("getQuality")

        local curSpecial = curInfo:call("getSpecialFlag")
        -- 判断特殊技能是否达到数量上限
        if self.specialCnt > 0 and curSpecial == 1 and special ~= 1 then
            LuaController:flyHint("", "", getLang("164830"))
            return
        end

        local function fun()
            self.rootView.replaceSkill = self.uuid
            DragonController:call("replaceDragonSkill", self.rootView.curSkill, self.uuid, self.dragonUuid)
        end
        local sourceSkillName = self.rootView.skillName
        local targetSkillName = self.skillName
        local dia = YesNoDialog:call("showButtonAndGold", getLang("4200156",targetSkillName,sourceSkillName), cc.CallFunc:create(fun),getLang("4200157"),tonumber(cost))
    end
end

return NewDragonSkillChangeCell_New







