----------------------------
-- Author: Elex
-- Date: 2019-06-21 Friday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local DragonSoulTreasureView_ui = class("DragonSoulTreasureView_ui")

--#ui propertys


--#function
function DragonSoulTreasureView_ui:create(owner, viewType, paramTable)
	local ret = DragonSoulTreasureView_ui.new()
	CustomUtility:LoadUi("DragonSoulTreasureView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function DragonSoulTreasureView_ui:initLang()
	LabelSmoker:setText(self.m_title2, "139380")
	LabelSmoker:setText(self.m_lbReset, "139379")
	LabelSmoker:setText(self.m_lbPay, "139380")
end

function DragonSoulTreasureView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function DragonSoulTreasureView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function DragonSoulTreasureView_ui:onClickBuyBtn(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBuyBtn", pSender, event)
end

function DragonSoulTreasureView_ui:onClickBtnReset(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnReset", pSender, event)
end

function DragonSoulTreasureView_ui:onClickBtnReward(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnReward", pSender, event)
end

function DragonSoulTreasureView_ui:initTableView()
	TableViewSmoker:createView(self, "m_TableView", "game.NewDragon.NewDragon_V2.DragonSkillIconCell", 0, 6, "DragonSkillIconCell")
end

function DragonSoulTreasureView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return DragonSoulTreasureView_ui

