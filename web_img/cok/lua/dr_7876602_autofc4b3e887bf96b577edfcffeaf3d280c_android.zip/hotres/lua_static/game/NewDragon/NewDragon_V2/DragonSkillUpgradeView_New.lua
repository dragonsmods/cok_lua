local DragonSkillUpgradeView_New = class("DragonSkillUpgradeView_New", function ()
	return PopupBaseView:create()
end)

DragonSkillUpgradeView_New.__index = DragonSkillUpgradeView_New
local skillExpTable = CCCommonUtilsForLua:getGroupByKey("dragon_skill_exp")
local dragon_exp_tool_ID = 211316


--  _type:0——技能替换 1——升级——2强化
function DragonSkillUpgradeView_New:create(param,_type)
	local view = DragonSkillUpgradeView_New.new()
	Drequire("game.NewDragon.NewDragon_V2.DragonSkillUpgradeView_New_ui"):create(view)
	if view:initView(param,_type) then
		return view
	else
		return nil
	end
end


function DragonSkillUpgradeView_New:initView(param,_type)
    if _type == nil then _type = 0 end
    self.type = _type
    self.uuid = param.uuid
    self.parent = param.rootView
    self.curSkill = param.uuid
    self.dragonUuid = param.dragonUuid
    local skillInfo = DragonController:call("getDragonSkillInfoByUuid", self.uuid)
    if skillInfo == nil then
        return false
    end
    local strenExp = skillInfo:call("getStrenExp")
    self.expEatPro = 1.0
    local dataConfig = DragonController:call("getDragonDataConfig")
    if #dataConfig >= 13 then
        self.expEatPro = tonumber(dataConfig[13])
    end
    --龙同类型技能会互斥
    self.dragon_skill_exclusive = CCCommonUtilsForLua:isFunOpenByKey("dragon_skill_exclusive")
    --龙出征技能生效 龙技能和技能槽限制关系取消
    self.dragon_skill_new = CCCommonUtilsForLua:isFunOpenByKey("dragon_skill_new")
    --新版强化，界面微调整
    if self.type == 2 and self.dragon_skill_new then
        self.strenExpTbl = {}
        self.ui.m_tableUpgrade:setViewSize(CCSize(570,300))
        self.ui.m_tableUpgrade:setPositionY(self.ui.m_tableUpgrade:getPositionY()+70)
        self.haveSkillNum = 0 
        self.costSkillNum = 0
        self:createStrenExpData()       
    else
        self.ui.m_strengthNode:setVisible(false)
    end
    self.ui.btn_label:setString(getLang("102104"))
    self:refreshView()
    -- self:setSpecialExpToolsData()
	return true
end

--根据type类型初始化界面
function DragonSkillUpgradeView_New:refreshView( )
    self.selectSkillTbl={}--选择源技能列表
    self.selectToolTbl={}--选择经验道具列表
    self.materialTbl={} --cmd:升级目标技能要的uuid列表
    self.expToolTbl={}--cmd:升级目标技能选择的经验道具列表
    self.editLock = false --是否不能再增加技能
    self.currentLevel = 0 --保存当前显示等级
    self.currentExp = 0--保存当前显示Exp
    self.m_overExp = false
    self.m_willHaveExp = 0
    self.ui.m_willProgress:setScaleX(0)
    if self.replaceSkill then
        self.curSkill = self.replaceSkill
        self.uuid = self.replaceSkill
    end
    self.replaceSkill = nil
    self:refreshSkillInfo()
    if self.type ~= 0 then
        self:generateUpgradeData()    
        if self.type == 2 then
            self:setStrenLimitItem()
        end
    else
        self.ui.m_upgradeBtn:setPositionX(0)
        self.ui.btn_label:setPositionX(0)
        self.ui.n_quickBtn:setVisible(false)
        self:generateReplaceData()
    end    
end

--技能替换数据封装
function DragonSkillUpgradeView_New:generateReplaceData()
    self.ui.m_downNode:setVisible(false)
    self.ui.m_tableUpgrade:setVisible(false)
    self.ui.m_tableChange:setVisible(true)
    self.ui.m_ResLabel:setString(getLang("164861"))
	local dragonInfo = DragonController:call("getDragonInfoByUuid", self.dragonUuid)
    if dragonInfo == nil then
        return
    end

    local dragonBaseId = dragonInfo:call("getBaseId")
    local dragonSkillTable = string.split(dragonInfo:call("getSkill"), "|")
    local dragonSkillItemTable = {}
    local specialCnt = 0
    for i=1,#dragonSkillTable do
        local info = DragonController:call("getDragonSkillInfoByUuid", dragonSkillTable[i])
        if info ~= nil then
            local itemId = info:call("getItemId")
            local special = info:call("getSpecialFlag")
            if special == 1 then
                specialCnt = specialCnt + 1
            end
            table.insert(dragonSkillItemTable, itemId)
        end     
    end
    local data = {}
    local nowSkillid = ""
    local skillInfo = DragonController:call("getDragonSkillInfoByUuid", self.uuid)
    if skillInfo ~= nil then 
        nowSkillid =  skillInfo:call("getItemId")
    end
    local totalDragonSkill = DragonController:call("getDragonSkillTotalUuid")

    for i=1,#totalDragonSkill do
        local skillInfo = DragonController:call("getDragonSkillInfoByUuid", totalDragonSkill[i])
        if skillInfo ~= nil then
            local state = skillInfo:call("getState")
            local skillItemId = skillInfo:call("getItemId")

            local belongId = CCCommonUtilsForLua:call("getPropByIdGroup","dragon_skill", skillItemId, "skill_learn_object")
            local quality = tonumber(CCCommonUtilsForLua:call("getPropByIdGroup","dragon_skill", skillItemId, "quality"))
            local find = false
            local skill_type = CCCommonUtilsForLua:call("getPropByIdGroup","dragon_skill", skillItemId, "skill_type")
            local boost_id = ""
            for i=1,#dragonSkillItemTable do
                if dragonSkillItemTable[i] == skillItemId then
                    find = true
                    break
                end
            end
            if find == false or skillItemId == self.uuid then
                if DragonSkillState.Idle == tonumber(state) then
                    if belongId == "all" and self:checkCanReplaceByType(skill_type) then
                        table.insert(data, {uuid = totalDragonSkill[i], dragonUuid = self.dragonUuid ,quality = quality, clickArea = self.ui.m_tableChange, rootView = self, parent=self.ui.m_tableChange, specialCnt = specialCnt,boost_condition = boost_id})
                    else
                        if dragonBaseId ~= "" and string.find(belongId, dragonBaseId) ~= nil then
                            table.insert(data, {uuid = totalDragonSkill[i], dragonUuid = self.dragonUuid ,quality = quality, clickArea = self.ui.m_tableChange, rootView = self, parent=self.ui.m_tableChange,specialCnt = specialCnt,boost_condition = boost_id})
                        end
                    end
                end
            end
        end
    end
    if #data > 0 then
        function sort(a,b)
            return a.quality > b.quality
        end
        table.sort(data, sort)
        MyPrint("NewDragonSkillView:generateReplaceData set tableView data")
        self.ui:setTableViewDataSource("m_tableChange", data)
        self.ui.m_pNode40:setVisible(false)
        self.ui.m_pNode40:setVisible(false)
        self.ui.m_upgradeBtn:setVisible(true)
    else
        self.ui.m_tableChange:setVisible(false)
        self.ui.m_noSkillTip1:setString(getLang("165022"))
        self.ui.m_pNode40:setVisible(true)
        self.ui.m_upgradeBtn:setVisible(false)
    end
end

--检查该技能是否符合替换规则 true:可替换 false:不可替换
function DragonSkillUpgradeView_New:checkCanReplaceByType(skill_type)
    if nil == skill_type or skill_type == "" then
        return true
    end
    if not self.dragon_skill_exclusive then
        return true
    end

    if tonumber(skill_type) == 1 then
        return true
    end

    if nil ~= self.parent.skillTypeTbl[skill_type] then
        return not self.parent.skillTypeTbl[skill_type] == 1
    end
    return true
end


--刷新目标技能界面数据
function DragonSkillUpgradeView_New:refreshSkillInfo(skill_level)
    local dragonInfo = DragonController:call("getDragonInfoByUuid", self.dragonUuid)
    if dragonInfo == nil then
        return
    end
    local dragonLevel = dragonInfo:call("getLevel")

    local skillInfo = DragonController:call("getDragonSkillInfoByUuid", self.uuid)
    if skillInfo == nil then
        return
    end

    local tag = 1234
    local skillId = skillInfo:call("getItemId")
    local skillLevel = skillInfo:call("getLevel")
    local strenLevel = skillInfo:call("getStrenLevel")--强化等级
    if nil ~= skill_level then
        if self.type== 1 then
            skillLevel = skill_level
        elseif self.type == 2 then
            strenLevel = skill_level
        end
    end    
    self.skillName = getLang(CCCommonUtilsForLua:call("getPropByIdGroup","dragon_skill", skillId, "name"))
    local descDialog = CCCommonUtilsForLua:call("getPropByIdGroup","dragon_skill", skillId, "desc")
    local descNum = DragonController:getDragonSkillDescValue(skillId, skillLevel, true, true)
    local maxLevel = tonumber(CCCommonUtilsForLua:call("getPropByIdGroup", "dragon_skill", skillId, "maxlv"))
    self.skill_max_level = maxLevel
    local skill_max_stren_lv = tonumber(CCCommonUtilsForLua:call("getPropByIdGroup", "dragon_skill", skillId, "boost_level"))
    if self.type == 2 then
        self.skill_max_level = skill_max_stren_lv
    end
    local nextNum = DragonController:getDragonSkillDescValue(skillId, skillLevel + 1, true, true)
    local maxNum = DragonController:getDragonSkillDescValue(skillId, maxLevel, true, true)
    self.ui.m_skillName:setString(getLang(descDialog, tostring(descNum)))

    self.ui.m_label_base:removeChildByTag(tag)
    -- self.ui.m_skillAddDesc:setVisible(false)
    self.ui.m_levelLabel:setString("Lv."..skillLevel)

    local pic = CCCommonUtilsForLua:call("getIcon", skillId)
    local sf = CCLoadSprite:call("getSF", pic)
    if sf == nil then
        pic = "dragon_skill_1.png"
    end

    local spr = CCLoadSprite:call("createSprite", pic)
    CCCommonUtilsForLua:call("setSpriteMaxSize", spr, 129, true)
    local quality = CCCommonUtilsForLua:call("getPropById", skillId, "quality")
    local colorBg = CCCommonUtilsForLua:call("getToolCircleBgByColor", tonumber(quality))
    local sprBg = CCLoadSprite:call("createSprite", colorBg)
    CCCommonUtilsForLua:call("setSpriteMaxSize", sprBg, 135, true)
    self.ui.m_skillPicNode:removeAllChildren()
    self.ui.m_skillPicNode:addChild(sprBg)
    self.ui.m_skillPicNode:addChild(spr)
    local canStrength = false
    local can_strength = ""
    local strength_desc = ""

    local boost_level = CCCommonUtilsForLua:call("getPropByIdGroup","dragon_skill", skillId, "boost_level")    
    if self.type == 2 and boost_level ~= "" then        
        self.ui.btn_label:setString(getLang("5000030"))--强化
        local tmp = ""
        canStrength = true        
        if strenLevel > 0 and strenLevel <= tonumber(boost_level) then 
            tmp = " Lv"..strenLevel
            can_strength = "<c F9AD29ff>(".._lang_1("139247",tmp)..")"--139247=强化 +{0}
            --TODO
            if strenLevel == tonumber(boost_level) then
                canStrength = false                
            end

        elseif strenLevel == 0 then
            can_strength = "<c d70000ff>(".._lang("139246")..")"--139246=可强化 
        end
       
        local str_strengthen = ""


        local unLockIndex = 0
        local buffTbl = DragonActiveSkillManager.getInstance():processStrenBuff(skillId) or {}
        if #buffTbl ~= 0 then
            local currentBuff = buffTbl[strenLevel]
            local nextBuff = {}
            if strenLevel < #buffTbl then
                nextBuff = buffTbl[strenLevel+1]
            end
            local str_line = ""
            for k,v in pairs(currentBuff or {}) do                
                str_line = str_line.."<s 16><c 21a010ff >".. _lang_1(k,tostring(v)).."\n"            
            end
            for k,v in pairs(nextBuff) do
                str_line = str_line.."<s 16><c 21a010ff >"..getLang("4200013").. _lang_1(k,tostring(v)).."\n" 
            end
            strength_desc = strength_desc..str_line
        end
    end

    local ifhy_str = IFHyperlinkText:call("create",strength_desc,cc.size(450,0))
    if ifhy_str ~= nil then 
        self.ui.m_label_base:addChild(ifhy_str)
        ifhy_str:setAnchorPoint(cc.p(0.5,0.5))
        ifhy_str:setTag(tag)
    end
    --165135
    self.ui.m_skillNameNode:removeAllChildren()
    local str = "<s 20><c ffe6afff>"..self.skillName.." Lv."..tostring(skillLevel)..can_strength
    local index = skillInfo:call("getIndex")
    local skillUnlockLevel = DragonController:call("getDragonSkillUnlockLevel", self.dragonUuid, index)
    if dragonLevel < skillUnlockLevel then
        str = str.."<c d70000ff> ("..getLang("165135")..")"
    end
    local dateLabel = IFHyperlinkText:call("create",str,cc.size(400,0),true,false)
    dateLabel:setAnchorPoint(cc.p(0.5,0.5))
    self.ui.m_skillNameNode:addChild(dateLabel)

    local totalExp = 1
    --CCCommonUtilsForLua:call("getPropByIdGroup","dragon_skill", skillId, "quality")
    local quality = tonumber(CCCommonUtilsForLua:call("getPropByIdGroup","dragon_skill", skillId, "quality"))
    self.skill_quality = quality
    if self.type == 1 then
        for key,value in pairs(skillExpTable) do        
            if tonumber(value.quality) == quality and tonumber(value.level) == skillLevel then
                totalExp = tonumber(value.exp)
                break
            end
        end
    elseif self.type == 2 and canStrength then
        if self.dragon_skill_new then
            totalExp = self.strenExpTbl[strenLevel+1]
        else
            totalExp = 0
        end
    end
    self.ui.m_skillDescEx:setString("")
    if skillLevel < maxLevel then
        local str = getLang("164450", getLang(descDialog, tostring(nextNum)))
        str = str.."\n"..getLang("167020", getLang(descDialog, tostring(maxNum)))
        self.ui.m_skillDescEx:setString(str)        
        self.ui.m_upgradeBtn:setEnabled(true)
        self.ui.m_skillAllTIps:setVisible(false)
        self.ui.m_progressLabel:setColor(cc.c3b(255,255,255))
        self.ui.m_curProgress:setVisible(false)
        self.ui.m_willProgress:setVisible(true)
    elseif not canStrength or self.type ~= 2 then
        if self.m_willHaveExp > 0 then
            self.ui.m_upgradeBtn:setEnabled(true)
        else
            self.ui.m_upgradeBtn:setEnabled(false)
        end        
        self.ui.m_skillAllTIps:setString(getLang("164827"))
        self.ui.m_skillAllTIps:setVisible(true)
        self.ui.m_progressLabel:setString("(Max)")
        self.ui.m_curProgress:setVisible(true)
        self.ui.m_willProgress:setVisible(false)
        self.ui.m_progressLabel:setColor(cc.c3b(25,25,23))
        self.ui.m_label_base:setPosition(cc.p(150,0))
    end
    local pro = 0
    local willPro = 0
    local exp = skillInfo:call("getExp")
    if self.type == 2 then
        exp = skillInfo:call("getStrenExp")
    end
    local tempExp = exp + self.m_willHaveExp
    if nil ~= skill_level then
        tempExp = self.m_willHaveExp
    end
    if skillLevel >= maxLevel and self.type == 1 then        
        self.editLock = true
    elseif self.type == 2 and strenLevel == self.skill_max_level then
        self.editLock = true
    else
        self.editLock = false
    end

    if totalExp > 0 then
        pro = exp / totalExp
        willPro = (tempExp) / totalExp
    end
    pro = math.min(1, pro)
    willPro = math.min(1, willPro)

    self.currentLevel = skillLevel
    self.currentExp = tempExp
    -- self.ui.m_curProgress:setScaleX(pro)
    self.ui.m_willProgress:setScaleX(willPro)

    if skillLevel == maxLevel then
        if self.type ~= 2 then
            self.ui.m_progressLabel:setString("(Max)")
        else
            if self.dragon_skill_new and  canStrength then
                self.ui.m_progressLabel:setString(tostring(tempExp).."/"..tostring(totalExp))
            else
                self.ui.m_progressLabel:setString("(Max)")
            end
        end        
    else
        self.ui.m_progressLabel:setString(tostring(tempExp).."/"..tostring(totalExp))
    end
    
    if self.type == 2 and self.dragon_skill_new then
        self.ui.m_upgradeBtn:setEnabled(tempExp >= totalExp and self.haveSkillNum >= self.costSkillNum)        
        if strenLevel ~= self.skill_max_level then
            self.editLock = tempExp >= totalExp
        end
    end

    self.m_remainExp = totalExp - exp
    if boost_level ~= "" then 
        MyPrint("boost_level =",boost_level)
        -- self.ui.m_skillName:setString(_lang("139249"))
        -- self.ui.m_skillName:setVisible(true)
        -- self.ui.m_skillAddEx:setString(strength_desc)      
    end
end

--技能升级数据封装
function DragonSkillUpgradeView_New:generateUpgradeData()
    self.haveSkillNum = 0
    self.ui.m_tableUpgrade:setVisible(true)
    self.ui.m_tableChange:setVisible(false)
    local skillInfo = DragonController:call("getDragonSkillInfoByUuid", self.uuid)
    local nowSkillid = ""
    local strenLevel = 0
    if skillInfo ~= nil then
        local skillUuid = skillInfo:call("getUuid")
        local itemId = skillInfo:call("getItemId")

        local quality = tonumber(CCCommonUtilsForLua:call("getPropByIdGroup","dragon_skill", itemId, "quality"))
        local skillUuid = skillInfo:call("getUuid")
        local born = CCCommonUtilsForLua:call("getPropByIdGroup","dragon_skill", itemId, "born_dragon")
        local level = skillInfo:call("getLevel")
        strenLevel = skillInfo:call("getStrenLevel")
        nowSkillid = itemId
    end
    self.upgradeData = {}
    self.tmpTabSkillData = {}
    self.tabBastSkillUuid = {}
    local totalDragonSkill = DragonController:call("getDragonSkillTotalUuid")
    local needSkillId = self:getStrenCostSkillId()
    -- dump(needSkillId,"hxq needSkillId is ")
    for i=1,#totalDragonSkill do
        local skillInfo = DragonController:call("getDragonSkillInfoByUuid", totalDragonSkill[i])
        if skillInfo ~= nil then
            local state = skillInfo:call("getState")
            local itemId = skillInfo:call("getItemId")
            local quality = tonumber(CCCommonUtilsForLua:call("getPropByIdGroup","dragon_skill", itemId, "quality"))
            local skillUuid = skillInfo:call("getUuid")
            local isLock = skillInfo:call("getLock")
            local born = CCCommonUtilsForLua:call("getPropByIdGroup","dragon_skill", itemId, "born_dragon") 
            local level = skillInfo:call("getLevel")
            local totalExp = skillInfo:call("getTotalExp")
            local strenExp = skillInfo:call("getStrenTotalExp")
            totalExp = totalExp + strenExp
            local icon = CCCommonUtilsForLua:call("getPropByIdGroup","dragon_skill", itemId, "icon")..".png"
            local descDialog = CCCommonUtilsForLua:call("getPropByIdGroup","dragon_skill", itemId, "desc")
            local name = CCCommonUtilsForLua:call("getPropByIdGroup","dragon_skill", itemId, "name") 
            local boost_condition = CCCommonUtilsForLua:call("getPropByIdGroup","dragon_skill", itemId, "boost_condition")
            local boost_id = ""
            if itemId == needSkillId then
                -- dump(skillUuid,"hxq skillUuid is") 
                -- dump(state,"hxq state is ")
            end
            if skillUuid ~= self.uuid and DragonSkillState.Idle == tonumber(state) and born == "" then                
                --强化的时候需要消耗的技能
                if itemId == needSkillId then
                    self.haveSkillNum = self.haveSkillNum + 1
                end
                table.insert(self.upgradeData, {uuid = skillUuid, dragonUuid = self.dragonUuid ,quality = quality, rootView = self, itemId = itemId,lock = isLock, level = level,total_exp = totalExp,boost_condition = boost_id, selectNum = 0,exp_type=0,icon=icon,desc=descDialog,name=name})                
                if self.tmpTabSkillData[itemId] ~= nil then
                    if self.tmpTabSkillData[itemId].quality < quality then
                        self.tmpTabSkillData[itemId] = {quality = quality, level = level}
                    elseif self.tmpTabSkillData[itemId].quality == quality then
                        if self.tmpTabSkillData[itemId].level < level then
                            self.tmpTabSkillData[itemId] = {quality = quality, level = level}
                        elseif self.tmpTabSkillData[itemId].level == level then
                            --最好的技能有多个的时候怎么办？
                            self.tabBastSkillUuid[itemId] = self.tabBastSkillUuid[itemId]+1
                        end
                    end
                else
                    self.tmpTabSkillData[itemId] = {quality = quality, level = level}
                    self.tabBastSkillUuid[itemId] = 1
                end 
            end
        end
    end

    self:reSetData() --对相同等级，相同品质的技能书进行整合
    if CCCommonUtilsForLua:isFunOpenByKey("dragon_skill_arcane") then
        self:setSpecialExpToolsData() --添加背包中的经验道具
    end

    if #self.tableData > 0 then
        function sort(a,b)
            --经验道具最前
            if a.exp_type ~= b.exp_type then
                return a.exp_type > b.exp_type
            end

            --解锁在前
            if a.lock == b.lock then
                if a.quality == b.quality then
                    return a.level < b.level
                else
                    local qualityA = tonumber(a.quality) or 0
                    local qualityB = tonumber(b.quality) or 0
                    return qualityA < qualityB
                end
            else
                return a.lock == 0
            end            
        end
        table.sort(self.upgradeData, sort)
        table.sort(self.tableData,sort)
        self.ui:setTableViewDataSource("m_tableUpgrade",self.tableData)--self.upgradeData
        self.ui.m_pNode40:setVisible(false)
        self.ui.m_upgradeBtn:setVisible(true)
    else
        self.ui.m_tableChange:setVisible(false)
        self.ui.m_tableUpgrade:setVisible(false)

        self.ui.m_noSkillTip1:setString(getLang("165023"))
        self.ui.m_pNode40:setVisible(true)
        self.ui.m_downNode:setVisible(false)
    end
end

--更改源技能选择数量后计算预升级
function DragonSkillUpgradeView_New:selectSkillTools(_itemId,_level,_num,_type)
    local willGetExp = 0    
    --技能书  
    self.materialTbl = {}
    for k,v in pairs(self.selectSkillTbl or {}) do
        local m_Key = tostring(v.itemId)..";"..tostring(v.level)
        local uuids = self.uuidArr[m_Key] or {}--{{uuid,totalExp},{},{}}                      
        --先更新最大数量
        if _type == 0 then
            if v.itemId == _itemId and v.level == _level then
                v.count = math.min(_num,#uuids)
            end
        end
        
        for i,value in pairs(uuids) do
            if i>0 and i <= v.count then
                local addExp = tonumber(value[2]) * self.expEatPro        
                willGetExp = willGetExp + addExp
                table.insert(self.materialTbl,value[1])
            end
        end
    end

    --经验道具 
    self.expToolTbl = {}  
    for k,v in pairs(self.selectToolTbl) do  
        if _type == 1 then             
            local cnt = self.total_exp_tools[tostring(_itemId)].count or 0
            if v.itemId == _itemId then
                v.count = math.min(_num,cnt)                
            end
        end
        local addExp = v.exp * v.count * self.expEatPro
        willGetExp = willGetExp + addExp
        local uid = v.uuid
        local count = v.count
        local itemId = v.itemId
        local originCount = v.originCount
        if count > 0 then
            table.insert(self.expToolTbl,uid..":"..tostring(count))
        end
    end
   
    self.m_willHaveExp = willGetExp
    self:refreshExpAndProgress(_num)
end

--计算当前某一技能可以用于升级的最大数量 _type:0 技能书 1:道具
function DragonSkillUpgradeView_New:getCanUseSkillMaxNum(_itemId,_level,_num,_type)
    local total_max_exp = 0
    local total_current_exp = self.currentExp
    local res = 0
    --升级
    if self.type == 1 then
        for key,value in pairs(skillExpTable) do
            local xml_level = tonumber(value.level)
            if tonumber(value.quality) == self.skill_quality and xml_level < self.skill_max_level then
                local exp = tonumber(value.exp)
                total_max_exp = total_max_exp + exp
                if tonumber(value.level) < self.currentLevel then
                    total_current_exp = total_current_exp + exp
                end
            end
        end
    elseif self.type == 2 then
        local skillInfo = DragonController:call("getDragonSkillInfoByUuid", self.uuid)
        if skillInfo == nil then
            return
        end
        local strenLevel = skillInfo:call("getStrenLevel")--强化等级
        total_max_exp = self.strenExpTbl[strenLevel+1]
    end
    local surplus_exp = total_max_exp - total_current_exp
    if _type == 0 then
        local m_Key = tostring(_itemId)..";"..tostring(_level)
        local uuids = self.uuidArr[m_Key] or {}--{{uuid,totalExp},{},{}} 

        for index,info in pairs (uuids) do
            if surplus_exp < 0 then
                break
            else
                local addExp = tonumber(info[2]) * self.expEatPro
                surplus_exp = surplus_exp - addExp
                res = res + 1
            end
        end
    elseif _type == 1 then
        local tool_exp = -1
        for k,v in pairs(self.selectToolTbl) do            
            if v.itemId == _itemId then
                tool_exp = v.exp
                break
            end
        end
        if tool_exp == nil or tool_exp <= 0 then
            return 0
        end

        for i=0, _num do
            if surplus_exp < 0 then
                break
            else
                local addExp = tool_exp * self.expEatPro
                surplus_exp = surplus_exp - addExp
                res = res + 1
            end
        end
    end
    res = math.min(_num,res)
    return res
end

--刷新进度条等数据
function DragonSkillUpgradeView_New:refreshExpAndProgress(streng_num)
    local skillInfo = DragonController:call("getDragonSkillInfoByUuid", self.uuid)
    if skillInfo == nil then
        return
    end
    local skillId = skillInfo:call("getItemId")
    local skillLevel = skillInfo:call("getLevel")
    local strenLevel = skillInfo:call("getStrenLevel")
    local maxLevel = tonumber(CCCommonUtilsForLua:call("getPropByIdGroup", "dragon_skill", skillId, "maxlv"))
    local boost_level = tonumber(CCCommonUtilsForLua:call("getPropByIdGroup","dragon_skill", skillId, "boost_level"))
    local baseExp = skillInfo:call("getExp")
    if self.type == 2 then
        baseExp = skillInfo:call("getStrenExp")
    end
    local quality = tonumber(CCCommonUtilsForLua:call("getPropByIdGroup","dragon_skill", skillId, "quality"))
    local currentLv = 0 --预升级等级
    local limitLv = 0 --预升级上限
    if self.type == 1 then--普通升级
        currentLv = skillLevel
        limitLv = maxLevel
    elseif self.type == 2 then--强化
        if self.dragon_skill_new then
            currentLv = strenLevel
            limitLv = boost_level
        else
            currentLv = strenLevel + streng_num
            if currentLv <= boost_level then
                self:refreshSkillInfo(currentLv)                       
            end
            return
    
        end
    end

    --递归，技能吞噬预览
    local function getWillLvAndExp(nowLv,getExp)
        if nowLv >= limitLv then
            return nowLv,getExp
        end
        if self.type == 1 then
            for key,value in pairs(skillExpTable) do
                if tonumber(value.quality) == quality and tonumber(value.level) == nowLv then
                    if getExp > tonumber(value.exp) then
                        getExp = getExp - tonumber(value.exp)
                        nowLv = nowLv + 1
                        nowLv,getExp = getWillLvAndExp(nowLv,getExp)
                        break                    
                    end
                end
            end
        elseif self.type == 2 and self.dragon_skill_new  then            
            totalExp = self.strenExpTbl[nowLv+1]
            if getExp > totalExp then               
                return nowLv,getExp --= getWillLvAndExp(nowLv,getExp)        
            end
        end
        return nowLv,getExp
    end
    if currentLv < limitLv and self.m_willHaveExp > 0 then
        if currentLv == 0 and self.type == 1 then 
            currentLv = 1 
        end
        currentLv,self.m_willHaveExp = getWillLvAndExp(currentLv,self.m_willHaveExp + baseExp)
        self:refreshSkillInfo(currentLv)
    else
        self:refreshSkillInfo()
    end    
end

--升级按钮
function DragonSkillUpgradeView_New:onClickUpgrade()     
    if self.type == 1 or (not self.dragon_skill_new and self.type == 2 ) then
        if not CCCommonUtilsForLua:isFunOpenByKey("dragon_skill_arcane") then
            if #self.materialTbl < 1 then
                return
            end
            DragonController:call("upgradeDragonSkill", self.uuid, self.materialTbl)
        else
            if #self.materialTbl < 1 and #self.expToolTbl < 1 then
                return
            end
            DragonController:call("upgradeDragonSkillSP", self.uuid, self.materialTbl,self.expToolTbl)
        end
    --开关打开，强化走新协议
    else
        DragonController:call("strenDragonSkill", self.uuid, self.materialTbl,self.expToolTbl) 
    end
    CCSafeNotificationCenter:postNotification("msg.DragonSkillUpgradeCell_New.reset") 
end

--获取途径
function DragonSkillUpgradeView_New:onClickGetBtn( )
    local view = Drequire("game.CommonPopup.ItemGetMethodView"):create("DragonFlame")
    PopupViewController:call("addPopupView", view)
end

function DragonSkillUpgradeView_New:onEnter(  )
    registerScriptObserver(self, self.refreshView, "dragonSkill_refresh_view")
    
end

function DragonSkillUpgradeView_New:onExit()
    unregisterScriptObserver(self, "dragonSkill_refresh_view")
end

function DragonSkillUpgradeView_New:reSetData( ... )
    self.lockArrTbl={} --解锁/加锁表 key=itemId;level value="uuid;uuid;uuid..."
    self.tableData = {} --tableCell数据表
    self.uuidArr = {}
    self.selectSkillTbl = {}--选择吞噬材料表
    local tempData = {}
    --唯一识别id,itemId..;..level
    local m_Key
    --计数
    local count
    --强化 --如果是强化技能,只能吞噬指定的技能 boost_condition
    local skillInfo = DragonController:call("getDragonSkillInfoByUuid", self.uuid)
    if skillInfo ~= nil then 
        nowSkillid =  skillInfo:call("getItemId")
    end

    local boost_condition_idTbl = string.split(CCCommonUtilsForLua:call("getPropByIdGroup","dragon_skill", nowSkillid, "boost_condition"),";")
    --{uuid = skillUuid, exp_type=0,dragonUuid = self.dragonUuid ,quality = quality, rootView = self, itemId = itemId, level = level,boost_condition = boost_id, lock = lock}
    if self.dragon_skill_new then
        for k, v in pairs(self.upgradeData or {}) do
            local uuids = ""
            local itemId = v.itemId
            local level = v.level
            local isLock = v.lock
            m_Key = itemId..";"..tostring(level)            
            if tempData[m_Key] == nil then
                local _count = 1
                v.count = _count
                tempData[m_Key] = v
                self.lockArrTbl[m_Key] = v.uuid
                self.uuidArr[m_Key]={{v.uuid,v.total_exp}}
            else
                local data = tempData[m_Key]
                local _count = data.count + 1
                tempData[m_Key].count = _count
                if isLock == 1 then
                    tempData[m_Key].lock = isLock
                end
                self.lockArrTbl[m_Key] = self.lockArrTbl[m_Key]..";"..v.uuid
                table.insert( self.uuidArr[m_Key],{v.uuid,v.total_exp})
            end
        end
    else
        for k, v in pairs(self.upgradeData or {}) do
            --强化
            if self.type == 2 then  
                if boost_condition_idTbl == nil then
                    return
                end
                local itemId = v.itemId
                local level = v.level
                local isLock = v.lock
                for key,value in pairs(boost_condition_idTbl or {}) do
                    if itemId == value then
                        m_Key = itemId..";"..tostring(level)                    
                        if tempData[m_Key] == nil then
                            local _count = 1
                            v.count = _count
                            tempData[m_Key] = v
                            self.lockArrTbl[m_Key] = v.uuid
                            self.uuidArr[m_Key]={{v.uuid,v.total_exp}}   
                        else
                            local data = tempData[m_Key]
                            local _count = data.count + 1
                            tempData[m_Key].count = _count                     
                            if isLock == 1 then
                                tempData[m_Key].lock = isLock
                            end
                            self.lockArrTbl[m_Key] = self.lockArrTbl[m_Key]..";"..v.uuid
                            table.insert( self.uuidArr[m_Key],{v.uuid,v.total_exp})                       
                        end
                    end
                end
            --升级
            else
                local itemId = v.itemId
                local level = v.level
                local isLock = v.lock
                m_Key = itemId..";"..tostring(level)            
                if tempData[m_Key] == nil then
                    local _count = 1
                    v.count = _count
                    tempData[m_Key] = v
                    self.lockArrTbl[m_Key] = v.uuid
                    self.uuidArr[m_Key]={{v.uuid,v.total_exp}}
                else
                    local data = tempData[m_Key]
                    local _count = data.count + 1
                    tempData[m_Key].count = _count
                    if isLock == 1 then
                        tempData[m_Key].lock = isLock
                    end
                    self.lockArrTbl[m_Key] = self.lockArrTbl[m_Key]..";"..v.uuid
                    table.insert( self.uuidArr[m_Key],{v.uuid,v.total_exp})
                end
            end
        end     
    end

    for k,v in pairs(tempData or {}) do
        table.insert(self.tableData,v)
        table.insert(self.selectSkillTbl,{itemId=v.itemId,count=0,level=v.level}) --改表记录每个cell使用数量，默认为0
    end
end

--特殊经验道具直接放入可吞噬列表
function DragonSkillUpgradeView_New:setSpecialExpToolsData()
    self.total_exp_tools = {} --可供选择的经验道具列表
    self.selectToolTbl = {} --选择的经验道具列表{{itemId,count},{},{}}

    local function insertTblByToolId(itemId)
        local tinfo = ToolController:call("getToolInfoByIdForLua",itemId)
        if tinfo then
            local cnt = tinfo:call("getCNT")
            if cnt > 0 then
                local uid = tinfo:getProperty("uuid")
                local icon = tinfo:getProperty("icon")..".png"
                local des = tinfo:getProperty("des")
                local exp = tonumber(tinfo:getProperty("para2")) or 0
                local name = tinfo:call("getName")
                local level = tinfo:getProperty("limitLv")
                if exp > 0 then
                    self.total_exp_tools[tostring(itemId)]={exp_type=1,uuid=uid,itemId=itemId,count=cnt,dragonUuid = self.dragonUuid,name=name,desc=des,exp=exp,level = level,icon=icon,lock=0,quality=1,selectNum=0,rootView = self}
                end
            end
        end
    end
    --旧版龙焰密典 211316
    insertTblByToolId(211316)
 
    --新版龙经验道具
    local arr = ToolController:call("getToolIdsByType", ToolItemType.DragonExp_tType)
    local exp_tool_tbl = arrayToLuaTable(arr) or {}
    for k,v in pairs(exp_tool_tbl) do
         insertTblByToolId(tonumber(v)) 
    end

    for k, v in pairs(self.total_exp_tools) do
        table.insert(self.tableData,v)
        table.insert(self.selectToolTbl,{itemId=v.itemId,count=0,exp=v.exp,uuid=v.uuid,originCount=v.count}) --改表记录每个cell使用数量，默认为0
    end
    -- dump(total_exp_tools,"hxq total_exp_tools is ")

end

function DragonSkillUpgradeView_New:onClickBack(  )
	self:call("closeSelf")
end

--技能强化必备条件
function DragonSkillUpgradeView_New:setStrenLimitItem() 
    local skillInfo = DragonController:call("getDragonSkillInfoByUuid", self.uuid)
    local skillId = ""
    local strenLevel = 0
    if skillInfo ~= nil then
        local itemId = skillInfo:call("getItemId")
        strenLevel = skillInfo:call("getStrenLevel")
        skillId = itemId
    end
    self.ui.m_strPicNode:removeAllChildren() 
    self.ui.m_strTipsLabel:setString("")
    self.ui.m_strNumLabel:setString("")
    local res = {}
    local skillStr = CCCommonUtilsForLua:call("getPropByIdGroup","dragon_skill", skillId, "stren_cost_skill")
    --stren_cost_skill="4906101;1|4906101;1|4906101;2|4906101;2|4906101;3|4906101;3|4906101;4|4906101;4|4906101;5|4906101;5"
    if skillStr == "" then
        return {}
    end
    local tempTbl = string.split(skillStr,"|")
    for i=1,#tempTbl do
        local per_data = tempTbl[i] or ""
        local info = string.split(per_data,";")
        local skillId = info[1]
        local cost = info[2]
        res[#res+1] = {skillId = skillId, cost = cost}
    end
    if strenLevel+1 <= #res then
        local info = res[strenLevel+1]
        local needId = info.skillId
        local cost = tonumber(info.cost) or 0

        local pic = CCCommonUtilsForLua:call("getPropByIdGroup","dragon_skill", needId, "icon")..".png"
        local sf = CCLoadSprite:call("getSF", pic)
        if sf == nil then
            pic = "dragon_skill_1.png"
        end

        local spr = CCLoadSprite:call("createSprite", pic)
        CCCommonUtilsForLua:call("setSpriteMaxSize", spr, 65, true)        
        local quality = CCCommonUtilsForLua:call("getPropByIdGroup","dragon_skill", needId, "quality")
        local colorBg = CCCommonUtilsForLua:call("getToolCircleBgByColor", tonumber(quality))
        local sprBg = CCLoadSprite:call("createSprite", colorBg)
        CCCommonUtilsForLua:call("setSpriteMaxSize", sprBg, 65, true)
        --icon
        self.ui.m_strPicNode:addChild(sprBg)
        self.ui.m_strPicNode:addChild(spr)
        --name
        local name = CCCommonUtilsForLua:call("getPropByIdGroup","dragon_skill", needId, "name") 
        self.ui.m_strTipsLabel:setString(getLang(name))   

        --cost
        self.ui.m_strNumLabel:setString(tostring(cost).."/"..self.haveSkillNum)
        self.costSkillNum = cost
        if self.haveSkillNum < cost then
            self.ui.m_strNumLabel:setColor(cc.c3b(222,25,25))            
        else
            self.ui.m_strNumLabel:setColor(cc.c3b(25,222,25))
        end
    else
        self.ui.m_strengthNode:setVisible(false)
    end

end

--获取强化技能必需的技能
function DragonSkillUpgradeView_New:getStrenCostSkillId()
    local skillInfo = DragonController:call("getDragonSkillInfoByUuid", self.uuid)
    local skillId = ""
    local strenLevel = 0
    if skillInfo ~= nil then
        local itemId = skillInfo:call("getItemId")
        strenLevel = skillInfo:call("getStrenLevel")
        skillId = itemId
    end
    local res = {}
    local skillStr = CCCommonUtilsForLua:call("getPropByIdGroup","dragon_skill", skillId, "stren_cost_skill")
    if skillStr == "" then
        return {}
    end
    local tempTbl = string.split(skillStr,"|")
    if #tempTbl >= strenLevel+1 then
        local info = string.split(tempTbl[strenLevel+1],";")
        return info[1]
    end
end

--强化经验
function DragonSkillUpgradeView_New:createStrenExpData()
    local skillInfo = DragonController:call("getDragonSkillInfoByUuid", self.uuid)
    local skillId = ""
    local strenLevel = 0
    if skillInfo ~= nil then
        local itemId = skillInfo:call("getItemId")
        strenLevel = skillInfo:call("getStrenLevel")
        skillId = itemId
    end
    local res = {}
    local maxStrenLv = tonumber(CCCommonUtilsForLua:call("getPropByIdGroup","dragon_skill", skillId, "boost_level")) or 0
    local expStr = CCCommonUtilsForLua:call("getPropByIdGroup","dragon_skill", skillId, "stren_exp")
    --stren_exp="625;2081;5184;10313;17782;27870;40826;56882;76250;99134"
    local expTbl = string.split(expStr,";")
    for i=1,#expTbl do
        res[#res+1] = tonumber(expTbl[i])
    end
    self.strenExpTbl = res
end

function DragonSkillUpgradeView_New:onClickQuickLv()
   self:autoSetMaterial2LvUp() 
end

--材料一键全选
function DragonSkillUpgradeView_New:autoSetMaterial2LvUp()
    local skillInfo = DragonController:call("getDragonSkillInfoByUuid", self.uuid)
    
    local function reInitData()
        self.m_willHaveExp = 0
        self.currentExp = skillInfo:call("getExp")
        self.currentLevel = skillInfo:call("getLevel")
        for k,v in pairs(self.selectToolTbl) do
            v.count = 0
        end
        for k,v in pairs(self.selectSkillTbl) do
            v.count = 0
        end
        for k, v in pairs(self.tableData) do
            v.selectNum = 0
        end
    end
    reInitData()       
    if self.haveClick then                
        self.materialTbl = {}
        self.expToolTbl = {}      
        self:refreshExpAndProgress()  
        self.haveClick = false
    else
        self.haveClick = true
        for index, cellData in pairs(self.tableData) do  
            if self.editLock or self.currentLevel >= self.skill_max_level then
                break
            end             
            --清除之前的记录
            self:selectSkillTools(cellData.itemId,cellData.level,0,cellData.exp_type)
            if cellData.lock == 0 then                         
                local type = cellData.exp_type                
                local maxNum = cellData.count
                local num = self:getCanUseSkillMaxNum(cellData.itemId,cellData.level,maxNum,type) 
                cellData.selectNum = num                
                self:selectSkillTools(cellData.itemId,cellData.level,num,type)                 
            end
        end 
    end
    self.ui.m_tableUpgrade:reloadData()
end

return DragonSkillUpgradeView_New
