local KingdomTransHerosView = class("KingdomTransHerosView", function()
 return PopupBaseView:create() 
end)

local HeroManager = require("game.hero.HeroManager")

local default_ccb_ui = "game.FestivalActivities.kingdomTrans.KingdomTransHerosView_ui"

function KingdomTransHerosView:ctor( ccb_ui)
	ccb_ui = ccb_ui or default_ccb_ui
	Drequire(ccb_ui):create(self, 0)
	
	
    self.controller =  require("game.FestivalActivities.kingdomTrans.KingdomTransHerosViewController").getInstance()
    self.index = 1
    self.heroIds =   self.controller.heroIds
    --self.heroIds = {"53524","53500","53509"}


    self.beginX  = 0
     self.startX  = 0
	
end

function KingdomTransHerosView:create( ccb_ui)


	 CCLoadSprite:call("loadDynamicResourceByName", "HeroMainTheme_face")

	local node = KingdomTransHerosView.new(ccb_ui,heroID)
	if node:initNode() then return node end
end

function  KingdomTransHerosView:setJumpHeroId(heroID)
    local index = self.controller:getIndexByHeroid(heroID)
     self.index = index

     self:refreshUI(self.index)
end

function KingdomTransHerosView:initNode( )	
	self:createProgressClipNode()

    local function touchHandle( eventType, x, y )
        if eventType == "began" then                            
            
            return self:onTouchBegan(x, y)                  
                
          
        elseif eventType == "moved" then
        	 return self:onTouchMoved(x, y)
           
        else
        	 return self:onTouchEnded(x, y)
           
        end
    end
    self.ui.m_nodeTouch:registerScriptTouchHandler(touchHandle)
    self.ui.m_nodeTouch:setTouchEnabled(true)
     
     
   
  
   local isPad = CCCommonUtilsForLua:isIosAndroidPad() 
   self.scalePad = isPad == true and 2.4 or 1


   self:refreshUI(self.index)
         
      
	return true
end
function KingdomTransHerosView:onTouchBegan(  x, y )	
	-- body
	 if not  self.ui.m_nodeTouch:isVisible(true)   or not  touchInside( self.ui.m_nodeTouch, x, y) then                 
                
        return false                  
                
      end

      self.beginX = x
      self.startX = x



      return true

end
function KingdomTransHerosView:onTouchMoved(  x, y )
	-- body
	local dx = x -  self.beginX 
	self.ui.m_nodePic:setPositionX(x + dx/5)
	self.beginX = x

end

function KingdomTransHerosView:onTouchEnded(  x, y )
	-- body
	local dx = x -   self.startX

	local widthX = self.ui.m_nodeTouch:getContentSize().width
	Dprint("widthX-----",widthX,dx)
	if dx <  - widthX * self.scalePad / 4 and  self.index < #self.heroIds then  ---向左移动
		self.index = self.index +1
		 self:refreshUI(self.index)
	else if dx > widthX * self.scalePad / 4 and self.index > 1 then  ---向右移动
		self.index = self.index - 1
		 self:refreshUI(self.index)
		
	else
		--回到原位置
		self.ui.m_nodePic:setPositionX(self:getContentSize().width * self.scalePad/2)

	end
	end
end


function KingdomTransHerosView:updateHeroImage(index)
	Dprint("KingdomTransHerosView--",index,#self.heroIds)
        if index < 1 or index > #self.heroIds then
        	return
        end
        self.ui.m_nodePic:removeAllChildren()

        local winSize = self:getContentSize()

        local spriteHero =  HeroManager.createHeroBody(self.heroIds[index], winSize.height*self.scalePad, true)
        spriteHero:setAnchorPoint(0.5,0.5)
        self.ui.m_nodePic:addChild(spriteHero)
        --回到原位置
		self.ui.m_nodePic:setPositionX(winSize.width * self.scalePad/2)
        
	
        spriteHero:setOpacity(120)
        spriteHero:runAction(cc.FadeIn:create(0.3))
        Dprint('HeroMainView:updateHeroImage',self.heroIds[index], spriteHero:getPositionY())
       
        
        Dprint("spriteHero posx : ",spriteHero:getPositionX(),heroHeadPic)
        -- spriteHero:setAnchorPoint(cc.p(0.5, 0)) 

        ---背景图
         self.ui.m_nodePicbg:removeAllChildren()
         local heroid = self.heroIds[index]
         local heroInfo = self.controller.heroData[heroid]
         Dprint("heroInfo-----",self.heroIds[index],index)
         local heroPicBg = heroInfo.bg_pic..".png"
          local pf = CCLoadSprite:call("getSF",heroPicBg)
            if pf then
                local picBg = CCLoadSprite:call("createScale9Sprite", heroPicBg)
                self.ui.m_nodePicbg:addChild(picBg)
                local picSize = picBg:getContentSize()
                local scale = math.max(winSize.width / picSize.width, winSize.height / picSize.height)
                picBg:setScale(scale)
            end


          local  heroHeadBg = "BG_yingxiongdise_type_"..heroInfo.type..".png"
           local sp =  CCLoadSprite:call("getSF",heroHeadBg)
           if sp then
           	    local colorBg = CCLoadSprite:call("createScale9Sprite", heroHeadBg)
                self.ui.m_nodePicbg:addChild(colorBg)
                local size = colorBg:getContentSize()
                local scale = math.max(winSize.width / size.width, winSize.height / size.height)
                colorBg:setScale(scale)

           end
   
	
end


function KingdomTransHerosView:refreshUI(index)
  dump( self.heroIds,"refreshUI-----")
   self.controller:reqData("57402", self.heroIds[index])
	self:updateHeroImage(index)
	
    self.ui.m_sprLeft:setVisible(index > 1)

	self.ui.m_sprRight:setVisible(index < #self.heroIds ) 

  if  self.controller.isReqHeroDataFlag  then
        self:refreshServerUI()
  end

 


end

function KingdomTransHerosView:refreshServerUI()
    --    ---刷新界面
  local heroid = self.heroIds[self.index]
  local heroData =  self.controller.heroData[heroid]
   
  self.ui.m_lbOffer:setString(getLang(heroData.hero_dialog))
  self.ui.m_lbDialog:setString(getLang(heroData.dialog))

  self.ui.m_lbTalk:setString(getLang(heroData.hero_talk_dialog))
  
  --self.ui.m_lbEffect:setString(heroData.effectText)
  self.ui.m_lbHeroSkill:setString(getLang(heroData.friendShip))

  dump(heroData,"refreshServerUI-----")
 
  local progress = math.min( heroData.kingdomExp / heroData.kingdomMaxExp,1)
  self.ui.m_barPro:setScale(progress)
  self.ui.m_lbPro:setString(heroData.kingdomExp.."/"..heroData.kingdomMaxExp)


 ---  心  血条进度

    if progress > 0 then    
      
        self.clipNode:setContentSize(CCSize(self.clipNode:getContentSize().width, 204 * progress))
        self.intimacyParNode:setPositionY(self.clipNode:getContentSize().height)
        if self.clipNode:getContentSize().height >= 170 or self.clipNode:getContentSize().height < 30 then
            self.intimacyParNode:setVisible(false)
        else
            self.intimacyParNode:setVisible(true)
        end
    else
        self.clipNode:setContentSize(CCSize(self.clipNode:getContentSize().width, 0))
        self.intimacyParNode:setVisible(false)
    end  


    ---刷新  作用号  加成


    for i=1,#heroData.effectText do
        local label = cc.Label:createWithSystemFont(heroData.effectText[i], "Helvetica", 18, cc.size(0.0,0))
        self.ui.m_nodeEffect:addChild(label)
        label:setAnchorPoint(0.5, 0)
        label:setColor(cc3(232,119,41))
        label:setPosition(cc.p(0,label:getContentSize().height * (i-1) + 5 ))
     
    end


end


function KingdomTransHerosView:createProgressClipNode()
    if self.clipNode then
        self.clipNode:removeFromParent()
    end
    self.clipNode = nil
    self.clipNode = CCClipNode:call("create", 240, 204)
    self.clipNode = tolua.cast(self.clipNode, "cc.Node")
    self.clipNode:setAnchorPoint(cc.p(0.5, 0))
    self.clipNode:setContentSize(CCSize(self.clipNode:getContentSize().width, 0))
    self.ui.m_progress:addChild(self.clipNode)

    local spr = CCLoadSprite:call("createSprite", "dragonHeartFull.png")
    spr:setScale(1.5)
    spr:setAnchorPoint(cc.p(0.5, 0))
    spr:setPosition(cc.p(self.clipNode:getContentSize().width / 2, 0))
    self.clipNode:addChild(spr)

    self.intimacyParNode = cc.Node:create()
    local line = CCLoadSprite:call("createSprite", "dragonHeartLine.png")
    line:setAnchorPoint(cc.p(0.5, 1))
    self.intimacyParNode:addChild(line)
    for i=0,1 do
        local par = ParticleController:call("createParticle", "DragonHeartUI_"..tostring(i))
        self.intimacyParNode:addChild(par)
    end
    self.clipNode:addChild(self.intimacyParNode)
    self.intimacyParNode:setPosition(cc.p(self.clipNode:getContentSize().width / 2, 0))
end




function KingdomTransHerosView:onClickBtnRight( ... )
	if self.index < #self.heroIds then
		self.index = self.index + 1
      self:refreshUI(self.index)
		
	end

	 
    
end

function KingdomTransHerosView:onClickBtnLeft( ... )

	if self.index > 1 then
	   self.index = self.index - 1
      self:refreshUI(self.index)

	end
	
	
    
end

function  KingdomTransHerosView:onClickBtnDonate()

  local heroId = self.heroIds[self.index]
  local view = Drequire("game.FestivalActivities.kingdomTrans.KingdomTransDonateView"):create(heroId)
  PopupViewController:addPopupView(view)     
    

end

function KingdomTransHerosView:onEnter()
	self:setTitleName(getLang("650219"))
   registerScriptObserver(self, self.refreshServerUI, "KingdomTransHerosView_refresh")
   
end

function KingdomTransHerosView:onExit()	
   unregisterScriptObserver(self, "KingdomTransHerosView_refresh")
   
    
end




return KingdomTransHerosView
