local KingdomTransWarPrepareView = class("KingdomTransWarPrepareView", function()
 return PopupBaseView:create() 
end)


local default_ccb_ui = "game.FestivalActivities.kingdomTrans.KingdomTransWarPrepareView_ui"

function KingdomTransWarPrepareView:ctor( ccb_ui)
	ccb_ui = ccb_ui or default_ccb_ui
	Drequire(ccb_ui):create(self, 0)
	
	
    self.controller =  require("game.FestivalActivities.kingdomTrans.KingdomTransHerosViewController").getInstance()
 
	
end

function KingdomTransWarPrepareView:create( ccb_ui) 

	
	CCLoadSprite:call("loadDynamicResourceByName", "HeroMainTheme_face")

	local node = KingdomTransWarPrepareView.new(ccb_ui)
	if node:initNode() then return node end
end

function KingdomTransWarPrepareView:initNode( )	

       

    local isPad = CCCommonUtilsForLua:isIosAndroidPad() 
       self.scalePad = isPad == true and 2.4 or 1
   

   
     self.controller:reqWarPrepareTaskData("57402") 
    self.controller:reqWarPrepareKingData()
      
	return true
end




function KingdomTransWarPrepareView:refreshUI()


	self.ui.m_lbName:setString(self.controller.warPrepareKingData.kingName)
	self.ui.m_lbServer:setString(self.controller.warPrepareKingData.name)
	self.ui.m_lbTalk:setString(self.controller.warPrepareKingData.kmsg)
 
    self.ui.m_nodeCountry:removeAllChildren()
     self.ui.m_sprKing:removeAllChildren()

     local picSF = CCLoadSprite:call("getSF",self.controller.warPrepareKingData.pic)
     if picSF then
     	local pic = CCLoadSprite:call("createSprite", picSF)
         self.ui.m_sprKing:addChild(pic)
       
     end
     local kingflag = self.controller.warPrepareKingData.banner
     if kingflag == "" then
     	kingflag =  "UN.png"
     else
     	 if kingflag == "TW" then
                if CCCommonUtilsForLua:checkTaiWanFlag() then
                    kingflag = "CN"
                end
            elseif kingflag == "HK" then
                kingflag = CCCommonUtilsForLua:changeHKToChinaFlag(kingflag)
            end
            kingflag =  CCCommonUtilsForLua:call("changeChinaFlag",kingflag) 
            kingflag = kingflag .. ".png"
     end

     local flagSF = CCLoadSprite:call("getSF",skingflag)
     if flagSF then
     	local flag = CCLoadSprite:call("createSprite", flagSF)
         self.ui.m_nodeCountry:addChild(flag)   	   

     end


     self.ui:setTableViewDataSource("m_tableViewTask",  self.controller.warPrepareTaskData.serverTaskArray)

end

function KingdomTransWarPrepareView:onEnter()
	self:setTitleName(getLang("170201"))
   registerScriptObserver(self, self.refreshUI, "KingdomTransWarPrepareView_refresh")
   
end

function KingdomTransWarPrepareView:onExit()	
    unregisterScriptObserver(self, "KingdomTransWarPrepareView_refresh")
   
    
end
function KingdomTransWarPrepareView:onClickDetailBtn( ... )
     local view = Drequire("game.CommonPopup.RankActComponent.RankActDesView").create("57402")
     view:setTitle(getLang("182103"))
            PopupViewController:addPopupView(view)
    
end




return KingdomTransWarPrepareView
