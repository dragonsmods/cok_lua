----------------------------
-- Author: Elex
-- Date: 2019-06-20 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local KingdomTransWarPrepareViewCell_ui = class("KingdomTransWarPrepareViewCell_ui")

--#ui propertys


--#function
function KingdomTransWarPrepareViewCell_ui:create(owner, viewType, paramTable)
	local ret = KingdomTransWarPrepareViewCell_ui.new()
	CustomUtility:LoadUi("KingdomTransWarPrepareViewCell.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function KingdomTransWarPrepareViewCell_ui:initLang()
	LabelSmoker:setText(self.m_lbFinish, "160656")
	LabelSmoker:setText(self.m_lb1, "650222")
	LabelSmoker:setText(self.m_lbLock, "650223")
	LabelSmoker:setText(self.m_lb3, "110144")
	ButtonSmoker:setText(self.m_getButton, "164234")
end

function KingdomTransWarPrepareViewCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function KingdomTransWarPrepareViewCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function KingdomTransWarPrepareViewCell_ui:onGetButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onGetButtonClick", pSender, event)
end

return KingdomTransWarPrepareViewCell_ui

