----------------------------
-- Author: Elex
-- Date: 2019-06-20 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local KingdomTransDonateView_ui = class("KingdomTransDonateView_ui")

--#ui propertys


--#function
function KingdomTransDonateView_ui:create(owner, viewType, paramTable)
	local ret = KingdomTransDonateView_ui.new()
	CustomUtility:LoadUi("KingdomTransDonateView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function KingdomTransDonateView_ui:initLang()
	LabelSmoker:setText(self.m_titleTxt, "162011")
end

function KingdomTransDonateView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function KingdomTransDonateView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function KingdomTransDonateView_ui:onClickBtnBack(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnBack", pSender, event)
end

function KingdomTransDonateView_ui:onClickReward(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickReward", pSender, event)
end

function KingdomTransDonateView_ui:initTableView()
	TableViewSmoker:createView(self, "m_listTableView", "game.FestivalActivities.kingdomTrans.KingdomTransDonateViewCell", 1, 10, "KingdomTransDonateViewCell")
end

function KingdomTransDonateView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return KingdomTransDonateView_ui

