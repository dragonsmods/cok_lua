local KingdomTransDonateView = class("KingdomTransDonateView", function()
 return PopupBaseView:create() 
end)


local default_ccb_ui = "game.FestivalActivities.kingdomTrans.KingdomTransDonateView_ui"

function KingdomTransDonateView:ctor(heroId, ccb_ui)
	ccb_ui = ccb_ui or default_ccb_ui
	Drequire(ccb_ui):create(self, 0)
	
	
    self.controller =  require("game.FestivalActivities.kingdomTrans.KingdomTransHerosViewController").getInstance()
    self.heroId = heroId
	
end

function KingdomTransDonateView:create(heroId, ccb_ui) 

	
	 --CCLoadSprite:call("loadDynamicResourceByName", "57394_face")

	local node = KingdomTransDonateView.new(heroId,ccb_ui)
	if node:initNode() then return node end
end

function KingdomTransDonateView:initNode( )	  
       self:refreshUI()  
    
	return true
end




function KingdomTransDonateView:refreshUI()
   dump( self.controller:getDonateData(self.heroId),"KingdomTransDonateView-------")
      self.ui:setTableViewDataSource("m_listTableView",  self.controller:getDonateData(self.heroId))
      local text =  tonumber(self.controller.targetDonatePoints) < 0 and "max" or (self.controller.todayDonatePoints.."/"..self.controller.targetDonatePoints)
     
      self.ui.m_lbPro:setString(text)

      self.ui.m_btnGetReward:setEnabled(self.controller.todayDonatePoints >= self.controller.targetDonatePoints and self.controller.targetDonatePoints > 0)

      local progress = 0
      if self.controller.targetDonatePoints < 0 then
      	  progress = 1

      else
      	progress = math.min(1,self.controller.todayDonatePoints/self.controller.targetDonatePoints)   

      end
       

      self.ui.m_barPro:setScaleX(progress)

      local point = self.controller.targetDonatePoints - self.controller.todayDonatePoints < 0 and 0 or self.controller.targetDonatePoints - self.controller.todayDonatePoints
    
      self.ui.m_lbDesc:setString(getLang("650225",point))

end

function KingdomTransDonateView:onEnter()
	--self:setTitleName(getLang("350236"))
   registerScriptObserver(self, self.refreshUI, "KingdomTransDonateView_refresh")
   
end

function KingdomTransDonateView:onExit()	
    unregisterScriptObserver(self, "KingdomTransDonateView_refresh")
   
    
end
function KingdomTransDonateView:onClickReward( ... )

    self.controller:reqDonateGetReward("57402",1)
    
end

function KingdomTransDonateView:onClickBtnBack()
	self:removeFromParent()
end


return KingdomTransDonateView