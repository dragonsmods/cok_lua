----------------------------
-- Author: Elex
-- Date: 2019-06-20 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local KingdomTransDonateViewCell_ui = class("KingdomTransDonateViewCell_ui")

--#ui propertys


--#function
function KingdomTransDonateViewCell_ui:create(owner, viewType, paramTable)
	local ret = KingdomTransDonateViewCell_ui.new()
	CustomUtility:LoadUi("KingdomTransDonateViewCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function KingdomTransDonateViewCell_ui:initLang()
end

function KingdomTransDonateViewCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function KingdomTransDonateViewCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function KingdomTransDonateViewCell_ui:onClickUseBtn(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickUseBtn", pSender, event)
end

function KingdomTransDonateViewCell_ui:onClickMoreBtn(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickMoreBtn", pSender, event)
end

function KingdomTransDonateViewCell_ui:onClickBuyBtn(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBuyBtn", pSender, event)
end

return KingdomTransDonateViewCell_ui

