----------------------------
-- Author: Elex
-- Date: 2019-06-20 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local KingdomTransHerosView_ui = class("KingdomTransHerosView_ui")

--#ui propertys


--#function
function KingdomTransHerosView_ui:create(owner, viewType, paramTable)
	local ret = KingdomTransHerosView_ui.new()
	CustomUtility:DoRes(502, true)
	CustomUtility:DoRes(520, true)
	CustomUtility:LoadUi("KingdomTransHerosView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function KingdomTransHerosView_ui:initLang()
	LabelSmoker:setText(self.m_lbTalk, "350237")
	LabelSmoker:setText(self.m_lbOfferstr, "650224")
	LabelSmoker:setText(self.m_lbDialog, "350237")
	LabelSmoker:setText(self.m_lb1, "162011")
end

function KingdomTransHerosView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function KingdomTransHerosView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function KingdomTransHerosView_ui:onClickIntimacy(pSender, event)
	ButtonSmoker:openUiInScreen(self, "", pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickIntimacy", pSender, event)
end

function KingdomTransHerosView_ui:onClickBtnDonate(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnDonate", pSender, event)
end

function KingdomTransHerosView_ui:onClickBtnLeft(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnLeft", pSender, event)
end

function KingdomTransHerosView_ui:onClickBtnRight(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnRight", pSender, event)
end

return KingdomTransHerosView_ui

