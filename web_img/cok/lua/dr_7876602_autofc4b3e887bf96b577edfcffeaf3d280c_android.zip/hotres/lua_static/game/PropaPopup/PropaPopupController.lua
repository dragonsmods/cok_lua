local PropaPopupController = class("PropaPopupController")

local PropaPopupInstance = PropaPopupInstance or nil

--------------cmd start----------------
local TanChuangConfirmCmd = class("TanChuangConfirmCmd", LuaCommandBase)

function TanChuangConfirmCmd:create(id)
    local ret = TanChuangConfirmCmd.new()
	ret:initWithName("tanchuang.confirm")
	ret:putParam("tanchuangId",CCString:create(id))
    return ret
end

function TanChuangConfirmCmd:handleReceive(dict)
    local flag, params = self:parseMsg(dict, false)
    if type(flag) == "boolean" then return flag end

    return true
end
--------------cmd end----------------

local PopupType = 
{
    Static = 1,
    Dynamic = 2,
}

function PropaPopupController.getInstance()
    if PropaPopupInstance == nil then
        PropaPopupInstance = PropaPopupController.new()
    end

    return PropaPopupInstance
end

function PropaPopupController:ctor()
    self.popups = {}
    self.showPropa = false

    registerScriptObserver(self, self.next, "PropaPopupController:next")
end

local drr_name = "%s_face"

function PropaPopupController:initData(dict)
    if dict == nil then return end
	local tanchuang = dict:objectForKey("tanchuang")
	if tanchuang then
        local tanchuangArray = tanchuang:objectForKey("tanchuangArray")
        if tanchuangArray then
            local tanchuangArr = arrayToLuaTable(tanchuangArray)
            dump(tanchuangArr, "tanchuangArr")
            for _, res in ipairs(tanchuangArr) do
                local md5 = res.md5Android
                if isIOS() or isWindows() then
                    md5 = res.md5IOS
                end
                --下载资源
                local name = string.format(drr_name, res.tanchuangId)
                DynamicResourceController2:call("initFunPackResource", name, md5)
            end
        end
	end
end

function PropaPopupController:next()
    self.showPropa = false
    self:deQueue()
end

function PropaPopupController:enQueue(pData)
    if pData then  self.popups[#self.popups + 1] = pData end
    if self.showPropa == false then self:deQueue() end
end

function PropaPopupController:deQueue()
    --新手引导不弹
    --主场景并且没有打开页面才弹出
    --跨服战场不弹出
    if GuideController:call("isInTutorial") then return end
    if SceneController:call("getCurrentSceneId") ~= SCENE_ID_MAIN then return end
    if PopupViewController:call("getCurrViewCount") > 0 then return end
    if isCrossServerNow() then return end
    if #self.popups > 0 and self.showPropa == false then
        local pData = table.remove(self.popups, 1)
        local name = string.format(drr_name, pData.id)
        if DynamicResourceController2:call("checkDynamicResource", name) then
            self:showPopup(pData)
        else
            self:next()
        end
    end
end

function PropaPopupController:showPopup(pData)
    local popType = atoi(pData.type)
    
    local popupFile = "game.PropaPopup.PropaPopupStaticView"
    if popType == PopupType.Static then
        popupFile = "game.PropaPopup.PropaPopupStaticView"
    elseif popType == PopupType.Dynamic then
        popupFile = "game.PropaPopup.PropaPopupDynamicView"
    end
    local popup = Drequire(popupFile):create(pData)
    if popup then
        PopupViewController:addPopupView(popup)
        self.showPropa = true
    else
        self.showPropa = false
    end
end

function PropaPopupController:confirmPopup(id)
    local cmd = TanChuangConfirmCmd:create(id)
    cmd:send()
end

function PropaPopupController:purge()
    unregisterScriptObserver(self, "PropaPopupController:next")
    PropaPopupInstance = nil
end

return PropaPopupController