----------------------------
-- Author: Elex
-- Date: 2019-06-20 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local PropaPopupDynamicView_ui = class("PropaPopupDynamicView_ui")

--#ui propertys


--#function
function PropaPopupDynamicView_ui:create(owner, viewType, paramTable)
	local ret = PropaPopupDynamicView_ui.new()
	CustomUtility:LoadUi("PropaPopupDynamicView.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function PropaPopupDynamicView_ui:initLang()
end

function PropaPopupDynamicView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function PropaPopupDynamicView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function PropaPopupDynamicView_ui:onClickGoto(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickGoto", pSender, event)
end

return PropaPopupDynamicView_ui

