local PropaPopupStaticView = class("PropaPopupStaticView", PopupBaseView)

local picWidth = 350
local picHeight = 300

function PropaPopupStaticView:create(data)
    local view = PropaPopupStaticView.new(data)
    CCLoadSprite:call("loadDynamicResourceByName", "Common_209_face")
    Drequire("game.PropaPopup.PropaPopupStaticView_ui"):create(view, 1)
    if view:initView() then return view end
end

function PropaPopupStaticView:ctor(data)
    self.data = data
end

function PropaPopupStaticView:initView()
    local frame = CCSpriteFrameCache:sharedSpriteFrameCache():spriteFrameByName("propa_crown.png")
    if not frame then 
        Dprint("PropaPopupStaticView no propa_crown")
        return false 
    end
 
    CCLoadSprite:call("loadDynamicResourceByName", string.format("%s_face", self.data.id))

    self:setHDPanelFlag(true)

    if CCCommonUtilsForLua:isIosAndroidPad() then
        self.ui.nodeccb:setScale(2.0)
    end

    if self.data.title then
        self.ui.m_titleLabel:setString(getLang(self.data.title))
    end

    if self.data.btnTitle then
        CCCommonUtilsForLua:setButtonTitle(self.ui.m_gotoBtn, getLang(self.data.btnTitle))
    end

    if self.data.pic then
        local pic = CCLoadSprite:createSprite(self.data.pic .. ".png")
        pic:setPosition(picWidth / 2, picHeight / 2)
        local clipNode = CCClipNode:call("create", picWidth, picHeight)
        clipNode:setAnchorPoint(ccp(0.5, 0.5))
        clipNode:addChild(pic)
        self.ui.m_picNode:addChild(clipNode)
    end

    if self.data.content then
        local scrollView = cc.ScrollView:create()
        local viewSize = self.ui.m_dialogNode:getContentSize()
        scrollView:setViewSize(viewSize)
        scrollView:setPosition(cc.p(0,0))
        scrollView:setScale(1.0)
        scrollView:ignoreAnchorPointForPosition(true)
        scrollView:setDirection(1)
        scrollView:setClippingToBounds(true)
        scrollView:setBounceable(true)

        self.ui.m_dialogNode:addChild(scrollView)

        local msgLabel = cc.Label:createWithSystemFont(getLang(self.data.content), "Helvetica", 20, cc.size(viewSize.width, 0)) 
        msgLabel:setColor(cc.c3b(236, 220, 170))
        msgLabel:setAnchorPoint(cc.p(0, 0))
        msgLabel:setHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
        msgLabel:setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
        scrollView:addChild(msgLabel)
        local msgHeight = msgLabel:getContentSize().height
        if msgHeight <= viewSize.height then
            scrollView:setTouchEnabled(false)
        end
        scrollView:setContentSize(CCSize(viewSize.width, msgHeight))
        scrollView:setContentOffset(ccp(0, viewSize.height - msgHeight))
    end

    registerTouchHandler(self)
    self:setTouchEnabled(true)
    
    return true
end

function PropaPopupStaticView:onEnter()

end

function PropaPopupStaticView:onExit()
    self:confirmPopup()
    CCSafeNotificationCenter:postNotification("PropaPopupController:next")
end

function PropaPopupStaticView:onTouchBegan(x, y)
    if not isTouchInsideVis(self.ui.m_touchNode, x, y) then
        self.touchPoint = ccp(x, y)
        return true
    end
end

function PropaPopupStaticView:onTouchEnded(x, y)
    if ccpDistance(self.touchPoint, ccp(x, y)) > 10 then return end
    self:onClickClose()
end

function PropaPopupStaticView:onClickGoto()
    if self.data.goType then
        CCCommonUtilsForLua.jumpToTarget(atoi(self.data.goType), atoi(self.data.goParam))
    end
    self:call("closeSelf")
end

function PropaPopupStaticView:onClickClose()
    self:call("closeSelf")
end

function PropaPopupStaticView:confirmPopup()
    require("game.PropaPopup.PropaPopupController").getInstance():confirmPopup(self.data.id)
end

return PropaPopupStaticView