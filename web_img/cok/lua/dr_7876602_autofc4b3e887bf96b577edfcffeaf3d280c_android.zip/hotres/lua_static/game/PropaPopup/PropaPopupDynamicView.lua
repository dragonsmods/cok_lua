local PropaPopupDynamicView = class("PropaPopupDynamicView", PopupBaseView)

local dynamic_atlas_format = "sk_%s.atlas"
local dynamic_json_format = "sk_%s.json"

function PropaPopupDynamicView:create(data)
    local view = PropaPopupDynamicView.new(data)
    Drequire("game.PropaPopup.PropaPopupDynamicView_ui"):create(view, 1)
    if view:initView() then return view end
end

function PropaPopupDynamicView:ctor(data)
    self.data = data
end

function PropaPopupDynamicView:initView()
    self:setHDPanelFlag(true)

    if CCCommonUtilsForLua:isIosAndroidPad() then
        self.ui.nodeccb:setScale(2.0)
    end

    if self.data.title then
        self.ui.m_titleLabel:setString(getLang(self.data.title))
    end

    if self.data.btnTitle then
        CCCommonUtilsForLua:setButtonTitle(self.ui.m_gotoBtn, getLang(self.data.btnTitle))
    end

    if self.data.pic then
        local paras = splitString(self.data.pic, "|")
        if #paras > 0 then 
            local rootPath = CCFileUtils:sharedFileUtils():getWritablePath() .. "dresource/"
            local skin_file = rootPath .. string.format(dynamic_atlas_format , paras[1]) 
            local skin_json = rootPath .. string.format(dynamic_json_format, paras[1])
            if cc.FileUtils:getInstance():isFileExist(skin_file) 
                and cc.FileUtils:getInstance():isFileExist(skin_json) 
                then
                local animationObj = IFSkeletonAnimation:call("create", skin_json, skin_file)
                if animationObj then
                    animationObj:setAnimation(0, "animation", true)
                    animationObj:setPosition(atoi(paras[2]), atoi(paras[3]))
                    animationObj:setScale(paras[4] and atoi(paras[4]) or 1)
                    self.ui.m_picNode:addChild(animationObj)
                end
            end
        end
    end

    if self.data.content then
        local scrollView = cc.ScrollView:create()
        local viewSize = self.ui.m_dialogNode:getContentSize()
        scrollView:setViewSize(viewSize)
        scrollView:setPosition(cc.p(0,0))
        scrollView:setScale(1.0)
        scrollView:ignoreAnchorPointForPosition(true)
        scrollView:setDirection(1)
        scrollView:setClippingToBounds(true)
        scrollView:setBounceable(true)

        self.ui.m_dialogNode:addChild(scrollView)

        local msgLabel = cc.Label:createWithSystemFont(getLang(self.data.content), "Helvetica", 20, cc.size(viewSize.width, 0)) 
        msgLabel:setColor(cc.c3b(236, 220, 170))
        msgLabel:setAnchorPoint(cc.p(0, 0))
        msgLabel:setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
        scrollView:addChild(msgLabel)
        local msgHeight = msgLabel:getContentSize().height
        if msgHeight <= viewSize.height then
            scrollView:setTouchEnabled(false)
        end
        scrollView:setContentSize(CCSize(viewSize.width, msgHeight))
        scrollView:setContentOffset(ccp(0, viewSize.height - msgHeight))
    end

    registerTouchHandler(self)
    self:setTouchEnabled(true)
    
    return true
end

function PropaPopupDynamicView:onEnter()

end

function PropaPopupDynamicView:onExit()
    self:confirmPopup()
    CCSafeNotificationCenter:postNotification("PropaPopupController:next")
end

function PropaPopupDynamicView:onTouchBegan(x, y)
    if not isTouchInsideVis(self.ui.m_touchNode, x, y) then
        self.touchPoint = ccp(x, y)
        return true
    end
end

function PropaPopupDynamicView:onTouchEnded(x, y)
    if ccpDistance(self.touchPoint, ccp(x, y)) > 10 then return end
    self:onClickClose()
end

function PropaPopupDynamicView:onClickGoto()
    if self.data.goType then
        CCCommonUtilsForLua.jumpToTarget(atoi(self.data.goType))
    end
    
    self:call("closeSelf")
end

function PropaPopupDynamicView:onClickClose()
    self:call("closeSelf")
end

function PropaPopupDynamicView:confirmPopup()
    require("game.PropaPopup.PropaPopupController").getInstance():confirmPopup(self.data.id)
end

return PropaPopupDynamicView