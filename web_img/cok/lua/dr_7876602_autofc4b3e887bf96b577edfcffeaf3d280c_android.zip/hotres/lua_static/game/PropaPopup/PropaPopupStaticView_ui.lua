----------------------------
-- Author: Elex
-- Date: 2019-06-20 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local PropaPopupStaticView_ui = class("PropaPopupStaticView_ui")

--#ui propertys


--#function
function PropaPopupStaticView_ui:create(owner, viewType, paramTable)
	local ret = PropaPopupStaticView_ui.new()
	CustomUtility:DoRes(209, true)
	CustomUtility:LoadUi("PropaPopupStaticView.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function PropaPopupStaticView_ui:initLang()
end

function PropaPopupStaticView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function PropaPopupStaticView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function PropaPopupStaticView_ui:onClickGoto(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickGoto", pSender, event)
end

function PropaPopupStaticView_ui:onClickClose(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickClose", pSender, event)
end

return PropaPopupStaticView_ui

