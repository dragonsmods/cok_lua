local DragonWarmUpView = class("DragonWarmUpView",
	function()
		return PopupBaseView:create()
	end
)
DragonWarmUpView.__index = DragonWarmUpView

function DragonWarmUpView:create()
    local view = DragonWarmUpView.new()    
	Drequire("game.dragonWarmUpBattle.DragonWarmUpView_ui"):create(view, 0)
	if view:initView() then
		return view
	end
end

function DragonWarmUpView:initView()
	if self:init(true, 0) then
		self:setHDPanelFlag(true)        
        CCLoadSprite:call("loadDynamicResourceByName", "activity_ad")
		if (CCLoadSprite:call("loadDynamicResourceByName", "DragonBattle_warm_face")) then
			local ad_sf = CCLoadSprite:call("getSF", "BG_dragonWarmAD_2.png")		
			self.ui.m_dragonBg:setSpriteFrame(ad_sf)
			-- local sf = CCLoadSprite:call("getSF", "DragonBattle_BG_1.png")
			-- if sf then self.ui.m_fixbg:setSpriteFrame(sf) end
		end

		local serverType = GlobalData:call("shared"):getProperty("serverType")
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_signUpBtn, getLang("5200020"))
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_engageInfoBtn, getLang("140021"))

		if serverType == ServerType.SERVER_DRAGON_BATTLE then
			CCCommonUtilsForLua:setButtonTitle(self.ui.m_enterBattleBtn, getLang("140061"))
		else
			CCCommonUtilsForLua:setButtonTitle(self.ui.m_enterBattleBtn, getLang("140013"))
		end
		
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_helpBtn, getLang("133005"))
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_historyBtn, getLang("140007"))
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_manageBtn, getLang("140043"))

		local addHeight = self:call("getExtendHeight")
		MyPrint("addHeight", addHeight)
		if CCCommonUtilsForLua:isIosAndroidPad() then
			self.ui.m_topNode:setPositionY(self.ui.m_topNode:getPositionY() + 80)
			self.ui.m_titleNode:setPositionY(self.ui.m_titleNode:getPositionY() - 75)
			self.ui.m_detailsNode:setPositionY(self.ui.m_detailsNode:getPositionY() + 80)
			self.ui.m_selectInfoNode:setPositionY(self.ui.m_selectInfoNode:getPositionY() - 20)
			self.ui.m_infoNode:setPositionY(self.ui.m_infoNode:getPositionY() - 40)
			-- self.ui.m_zoneNode:setPositionY(self.ui.m_zoneNode:getPositionY() - 64)
		else
			--self.ui.m_detailsNode:setPositionY(self.ui.m_detailsNode:getPositionY() - 80)
		end
		self.ui.m_missLabel:setDimensions(470, 0)
		self:hideAllStageView()
		--test
		-- self:getTestData()
		-- self:getDataBack()
		self.reqBattleData = false
		DragonWarmUpManager:requestActivityData()			
		return true
	end

	return false
end

function DragonWarmUpView:getTestData()
	local now = LuaController:call("getTimeStamp")
	--测试数据
	local infoTable = {}
	--未开始阶段
	-- infoTable.state = 0
	
	--报名阶段
	-- infoTable.state = 1 --阶段
	-- infoTable.teamApplyState = "1" --联盟是否已报名
	-- infoTable.applyEndTime = now + 3600*2

	--匹配阶段
	local matchInfo = {}
	matchInfo.fightPower = "99999"
	matchInfo.abbr = "CN"
	matchInfo.name = "allianceName"
	matchInfo.icon = "Allance_flay"
	matchInfo.leader = "sensen"
	matchInfo.kingId = "1803"
	matchInfo.kingName = "kingName"
	matchInfo.wins = "0.5"
	matchInfo.curmember = "56"
	matchInfo.maxmember = "80"
	matchInfo.rankNum = "78"
	matchInfo.battleBeginTime = (now + 7200)*1000

	-- infoTable.state = 2
	-- infoTable.bye = "0" -- 内容是1，表示轮空了（报名轮空才有）
	-- infoTable.enemy = matchInfo --匹配到的对手信息
	-- infoTable.teamApplyState = "1" --联盟是否已报名
	-- infoTable.matchEndTime = (now + 3600)*1000 --匹配结束倒计时
	-- infoTable.battleBeginTime = (now + 7200)*1000 --比赛准确开始时间
     
	--比赛阶段
	-- infoTable.state = 3
	-- infoTable.enemy = matchInfo --匹配到的对手信息
	-- infoTable.bye = "0" -- 内容是1，表示轮空了（报名轮空才有）
	-- infoTable.nextApplyTime = now + 3600*3 --在战斗阶段会发，下次报名时间
	-- infoTable.teamApplyState = "1" --联盟是否已报名
	-- infoTable.matchEndTime = now + 3600 --匹配结束倒计时
	-- infoTable.battleBeginTime = now + 1000 --比赛准确开始时间
	-- infoTable.battleEndTime = now + 7200 --比赛结束时间
	-- infoTable.canFight = "1"	--是否可以出战（1可以0不可以，在玩家联盟选的时间的时候）

	-- infoTable.state = 5
	-- infoTable.endTime = (now+3600*24*2)*1000
	-- DragonWarmUpManager:parseWarmUpData(infoTable)

	-- self.warmUpInfo = DragonWarmUpManager:getWarmUpData()
	-- self.warmUpInfo.mainStage = 3
	-- self.warmUpInfo.subStage = 3
	-- self.warmUpInfo.applyState = true --未报名
	-- self.warmUpInfo.applyEndTime = now + 3600 --报名结束时间
	-- self.warmUpInfo.matchStartTime = now + 3600 --匹配开始时间
	-- self.warmUpInfo.managerTime = 60 --出战管理结束时间
	-- self.warmUpInfo.battleBeginTime = now -20 --比赛开始时间
	-- self.warmUpInfo.battleEndTime = now + 400 --比赛结束时间
	-- self.warmUpInfo.miss = false --轮空
	-- self.warmUpInfo.zone = "20000001" --zong，不需要
	-- self.warmUpInfo.seasonOver = false
	-- self.warmUpInfo.restState = false --休息阶段
end

function DragonWarmUpView:addLoadingAni()
	self:removeLoadingAni()

	self.m_loadingIcon = CCLoadSprite:call("createSprite", "loading_1.png")
	self.m_loadingIcon:setAnchorPoint(ccp(0.5, 0.5))

	local cSize = self.ui.m_listNode:getContentSize()
	self.m_loadingIcon:setPosition(ccp(cSize.width / 2, cSize.height / 2))

	local rotateAction = cc.RotateTo:create(0.5, 720)
	local rotateForever = cc.RepeatForever:create(rotateAction)
	self.m_loadingIcon:runAction(rotateForever)
	self.ui.m_listNode:addChild(self.m_loadingIcon, 1000000)
	self.ui.m_listNode:setVisible(true)
end

function DragonWarmUpView:removeLoadingAni()
	if (self.m_loadingIcon) then
		self.ui.m_listNode:removeChild(self.m_loadingIcon)
		self.m_loadingIcon = nil
	end
end

function DragonWarmUpView:getDataBack()
	MyPrint("hxq DragonWarmUpView:getDataBack")
	self.warmUpInfo = DragonWarmUpManager:getWarmUpData()
	self:refreshView()
end

function DragonWarmUpView:signupSuccess()
	self:removeLoadingAni()
	self.warmUpInfo = DragonWarmUpManager:getWarmUpData()
	self:refreshView()
end

function DragonWarmUpView:refreshView()
	self:unscheduleUpdate()
	self:scheduleUpdate()

	self:removeLoadingAni()
	MyPrint("hxq self.warmUpInfo.mainStage", self.warmUpInfo.mainStage, self.warmUpInfo.subStage)

	if self.warmUpInfo.seasonOver then --比赛结束
		self:showSeasonOverView()
	-- elseif self.warmUpInfo.subStage == DragonWarmSubStage.PreApply then --报名阶段且已报名
	-- 	self:showSignManagerStageView()	
	elseif self.warmUpInfo.miss then --轮空
		self:showMissStageView()		
	elseif self.warmUpInfo.mainStage == DragonWarmStage.SignUp then --报名阶段
		self:showSignUpStageView()
	elseif self.warmUpInfo.mainStage == DragonWarmStage.Apply then --匹配阶段
		self:showMatchView()
	elseif self.warmUpInfo.mainStage == DragonWarmStage.Battle then --比赛阶段		
		self:showBattleView()
	elseif self.warmUpInfo.mainStage == DragonWarmStage.Sleep then --休息阶段		
		self:showRestView()
	end
	self:onEnterFrame()

	--在测试服和wa_arms_drill_field_2这个开关开的环境下，不判段时间只根据canfight来控制进入战场的按钮
	-- local serverType = GlobalData:call("shared"):getProperty("serverType")
	-- if (serverType == ServerType.SERVER_INNER_TEST or serverType == ServerType.SERVER_TEST) and CCCommonUtilsForLua:isFunOpenByKey("wa_arms_drill_field_2") then
	-- 	self:unscheduleUpdate()
	-- 	self.ui.m_battleNode:setVisible(true)
	-- 	self.ui.m_enterBattleBtn:setEnabled(true)		
	-- end	
end

function DragonWarmUpView:onEnterFrame(dt)
	if self.warmUpInfo == nil then return end
	--轮空不刷新状态
	if self.warmUpInfo.miss == true then return end
	--赛季结束
	if self.warmUpInfo.seasonOver == true then return end

	local now = getTimeStamp()	
	if self.warmUpInfo.mainStage == DragonWarmStage.SignUp then
		local applyEndTime = self.warmUpInfo.applyEndTime
		local battleBeginTime = self.warmUpInfo.battleBeginTime
		local remainTime = applyEndTime - now
		local lessTime = battleBeginTime - now

		if self.warmUpInfo.subStage == DragonWarmSubStage.PreApply then			
			self.ui.m_signUpTimeNumLabel:setString(format_time(remainTime))			
		else		
			self.ui.m_signUpTimeNumLabel:setString(format_time(remainTime))	
		end
		if lessTime >= 0 then
			self.ui.m_textLabel1:setString(getLang("140164",format_time(lessTime)))			
		end
	elseif self.warmUpInfo.mainStage == DragonWarmStage.Apply then
		if not self.warmUpInfo.applyState then --未报名
			local remainTime = self.warmUpInfo.battleEndTime - now
			-- local remainTime = self.warmUpInfo.turnEndTime - now
			if remainTime > 0 then
				--您所在时段的比赛已结束，请等待本轮比赛完全结束后再进行下一轮比赛的时间选择{0}
				self.ui.m_missLabel:setString(getLang("5200139", format_time(remainTime)))
			else
				self.warmUpInfo.restState = false
				local matchRemainTime = self.warmUpInfo.matchEndTime - now
				self.ui.m_matchTimeLabel:setString(format_time(matchRemainTime))
			end
		elseif self.warmUpInfo.subStage == DragonWarmSubStage.None then --报名后匹配到之前
			-- local matchRemainTime = self.warmUpInfo.battleManagerEndTime - now			
			local matchRemainTime = self.warmUpInfo.matchEndTime - now
			self.ui.m_matchTimeLabel:setString(format_time(matchRemainTime))
		elseif self.warmUpInfo.subStage == DragonWarmSubStage.ApplySuc then
			local battleBeginTime = self.warmUpInfo.battleBeginTime
			local battleEndTime = self.warmUpInfo.battleEndTime
			if now < battleBeginTime then
				self.ui.m_signUpTimeLabel:setString(getLang("5200103"))
				self.ui.m_signUpTimeNumLabel:setString(format_time(battleBeginTime - now))
				self.ui.m_enterBattleBtn:setEnabled(false)				
			elseif (battleBeginTime <= now and now <= battleEndTime) then
				self.ui.m_signUpTimeLabel:setString(getLang("5200102"))
				self.ui.m_signUpTimeNumLabel:setString(format_time(battleEndTime - now))
				self.ui.m_enterBattleBtn:setEnabled(true)
				if self.reqBattleData == false then
					DragonWarmUpManager:requestActivityData()
					self.reqBattleData = true
				end
			elseif battleEndTime < now then
				self.ui.m_signUpTimeLabel2:setString(getLang("140338"))
				self.ui.m_enterBattleBtn:setEnabled(false)
			end
		end
	elseif self.warmUpInfo.mainStage == DragonWarmStage.Battle then
		local battleBeginTime = self.warmUpInfo.battleBeginTime --应该是比赛场次准确开始时间
		local battleEndTime = self.warmUpInfo.battleEndTime
		local nextApplyTime = (self.warmUpInfo.nextApplyTime == 0 and battleEndTime or self.warmUpInfo.nextApplyTime)
		if not self.warmUpInfo.applyState then --未报名
			local remainTime = nextApplyTime - now
			self.ui.m_signUpTimeLabel2:setString(getLang("140162", format_time(remainTime)))
		else			
			if battleBeginTime <= now and now <= battleEndTime then --比赛中
				local lessTime = battleEndTime - now
				self.ui.m_signUpTimeLabel2:setString(getLang("140060", format_time(lessTime)))
				self.ui.m_enterBattleBtn:setEnabled(true)				
			elseif battleBeginTime > now then
				local lessTime = battleBeginTime - now
				self.ui.m_signUpTimeLabel2:setString(getLang("140276", format_time(lessTime)))
				self.ui.m_enterBattleBtn:setEnabled(false)
			elseif battleEndTime < now then
				self.ui.m_signUpTimeLabel2:setString(getLang("140095"))
				self.ui.m_enterBattleBtn:setEnabled(false)
			end
		end
	elseif self.warmUpInfo.mainStage == DragonWarmStage.Sleep then
		local lessTime = self.warmUpInfo.restEndTime - now
		if lessTime > 0 then
			self.ui.m_missLabel:setString(getLang("140162",format_time(lessTime)))
		end
	end 	
end

--隐藏所有界面状态
function DragonWarmUpView:hideAllStageView()
	self.ui.m_signUpAndBattleNode:setVisible(false)
	self.ui.m_selectNode:setVisible(false)
	self.ui.m_listNode:setVisible(false)
	--self.ui.m_threeButton:setVisible(false)
end

--报名界面状态
function DragonWarmUpView:showSignUpStageView()
	self.ui.m_signUpNode:setVisible(true)
	self.ui.m_signUpAndBattleNode:setVisible(true)
	self.ui.m_zoneNode:setVisible(false)	
	self.ui.m_battleNode:setVisible(false)
	if self.warmUpInfo.applyState == false then				
		self.ui.m_selectNode:setVisible(false)		
		self.ui.m_signUpTimeLabel:setString(getLang("5200018"))
		self.ui.m_manageBtn:setVisible(false)
	else
		self.ui.m_textLabel:setString(getLang("9711051"))
		self.ui.m_signUpTimeLabel:setString(getLang("170130",""))
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_signUpBtn, getLang("140018"))--已报名
	end
end

--轮空界面
function DragonWarmUpView:showMissStageView()
	self:hideAllStageView()
	self.ui.m_missNode:setVisible(true)
	self.ui.m_missLabel:setString(getLang("140137"))
	self.ui.m_manageBtn:setVisible(false)
end

-- --报名阶段且已报名界面
-- function DragonWarmUpView:showSignManagerStageView()
-- 	-- body
-- 	self:hideAllStageView()
-- 	self.ui.m_selectNode:setVisible(true)	
-- 	self.ui.m_missNode:setVisible(false)
-- 	self.ui.m_manageBtn:setVisible(true)
-- 	self.ui.m_matchLabel:setString("匹配开始倒计时:")
-- end

--休息界面
function DragonWarmUpView:showRestView()
	self:hideAllStageView()
	self.ui.m_missNode:setVisible(true)
	self.ui.m_manageBtn:setVisible(false)
	self.ui.m_restTipsLabel:setString(getLang("9711090"))
end

--赛季结束页面
function DragonWarmUpView:showSeasonOverView()
	self.ui.m_missNode:setVisible(true)
	self.ui.m_missLabel:setString(getLang("140225"))
	self.ui.m_manageBtn:setVisible(false)
	self.ui.m_battleProgress:setVisible(false)
	self.ui.m_ruleDesBg:setVisible(false)	
end

--匹配界面状态
function DragonWarmUpView:showMatchView()
	self.ui.m_zoneNode:setVisible(false)
	self.ui.m_manageBtn:setVisible(false)
	if self.warmUpInfo.restState then
		self:showRestView()
	elseif self.warmUpInfo.subStage == DragonWarmSubStage.None then --未匹配到对手
		self.ui.m_selectNode:setVisible(true)	
		self.ui.m_matchLabel:setString(getLang("140008"))
		self.ui.m_zoneLabel:setString(getLang("9711051"))
		self.ui.m_zoneBg:setVisible(true)
	elseif self.warmUpInfo.subStage == DragonWarmSubStage.ApplySuc then --匹配到，时间显示比赛时间时间倒计时		
		self.ui.m_signUpAndBattleNode:setVisible(true)
		self.ui.m_selectNode:setVisible(false)
		self.ui.m_battleNode:setVisible(true)
		self.ui.m_signUpNode:setVisible(false)
		self.ui.m_enterBattleBtn:setVisible(false)
		self.ui.m_engageInfoBtn:setEnabled(true) --对阵信息
		self.ui.m_engageInfoBtn:setPositionX(0)
		self.ui.m_enterBattleBtn:setEnabled(true)
		self.ui.m_textLabel:setString(getLang("9711051"))
		-- self.ui.m_signUpTimeLabel:setString(getLang("5200103"))
	end 	
end

--比赛界面状态
function DragonWarmUpView:showBattleView()
	self.ui.m_manageBtn:setVisible(true)
	self.ui.m_signUpAndBattleNode:setVisible(true)
	self.ui.m_signUpNode:setVisible(false)
	if self.warmUpInfo.applyState  == false then --未报名
		self.ui.m_zoneLabel:setString("")
		self.ui.m_zoneBg:setVisible(false)
		self.ui.m_battleNode:setVisible(false)
	else		
		self.ui.m_zoneLabel:setString(getLang("140018"))
		self.ui.m_zoneBg:setVisible(true)		
		self.ui.m_battleNode:setVisible(true)
		self.ui.m_engageInfoBtn:setVisible(true)
		self.ui.m_enterBattleBtn:setVisible(true)
	end
end

function DragonWarmUpView:scheduleUpdate()
    local function updatefunc(dt) self:onEnterFrame(dt) end 
    self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(updatefunc, 1.0, false)
end

function DragonWarmUpView:unscheduleUpdate()
    if self.entry then
        cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
        self.entry = nil
    end
end

function DragonWarmUpView:onEnter()
	self:getDataBack()
	UIComponent:call("showPopupView", 1)
	self.ui.m_titleTxt:setString(getLang("9711050"))
	local function callback1() self:getDataBack() end
	local function callback2() self:signupSuccess() end
	local function callback3() self:refreshView() end
	local handler1 = self:registerHandler(callback1)
	local handler2 = self:registerHandler(callback2)
	local handler3 = self:registerHandler(callback3)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "msg.DragonWarmUpView.getDataBack")
	CCSafeNotificationCenter:registerScriptObserver(self, handler2, "dragon.worldcup.signup.back")
	CCSafeNotificationCenter:registerScriptObserver(self, handler3, "dragon.worldcup.signup.time.done")
end

function DragonWarmUpView:onExit()
	CCSafeNotificationCenter:unregisterScriptObserver(self, "msg.DragonWarmUpView.getDataBack")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "dragon.worldcup.signup.back")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "dragon.worldcup.signup.time.done")
	self:unscheduleUpdate()
end

--报名按钮
function DragonWarmUpView:onClickSignUpBtn()
	MyPrint("DragonWarmUpView:onClickSignUp")
	if self.warmUpInfo == nil then return end
	--状态判断
	if self.warmUpInfo.mainStage ~= DragonWarmStage.SignUp then return end
	if self.warmUpInfo.applyState == true then 
		--弹出报名时间
		local view = Drequire("game.dragonWarmUpBattle.DragonWarmUpTimeView"):create(canNot)
		PopupViewController:addPopupInView(view)
		return
	end

	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	if playerInfo:call("isInAlliance") then
		local allianceInfo = playerInfo:getProperty("allianceInfo")
		local rank = allianceInfo:getProperty("rank")
		if rank < 4 then
			YesNoDialog:show(getLang("E100119"))
			return
		end
	else
		YesNoDialog:show(getLang("E100119"))
		return
	end

	local canNot = DragonWarmUpManager:canNotModifyBattleList()
	local view = Drequire("game.dragonWarmUpBattle.DragonWarmUpTimeView"):create(canNot)
	PopupViewController:addPopupInView(view)
end

--对阵信息按钮
function DragonWarmUpView:onClickEngage()
	local lua_path = "game.dragonWarmUpBattle.DragonWarmUpEnemyView"
	package.loaded[lua_path] = nil
	local engageView = require(lua_path):create()
	PopupViewController:addPopupView(engageView)
end

--进入战场
function DragonWarmUpView:onClickEnter()
	local serverType = GlobalData:call("shared"):getProperty("serverType")
	if serverType == ServerType.SERVER_DRAGON_BATTLE then
		if DragonWarmUpManager:isInBattle() then
			local function callback() DragonWarmUpManager:leaveBattle() end
			YesNoDialog:show(getLang("140157"), callback)
		else
			DragonWarmUpManager:leaveBattle()
		end
		-- GameController:call("showWaitInterface1", self.ui.m_enterBattleBtn)
	else
		local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
		if playerInfo:call("isInAlliance") then
			local selfAllianceId = playerInfo:call("getAllianceId") 
			DragonWarmUpManager:enterDragonBattle(selfAllianceId)
		end
	end
end

--奖励查看按钮
function DragonWarmUpView:onClickHelp()
	local view = Drequire("game.dragonWarmUpBattle.DragonWarmUpRewardView"):create()
	PopupViewController:addPopupInView(view)
end

--FAQ按钮
function DragonWarmUpView:onTipBtnClick()
    local view = Drequire("commonView.commonTipsView"):create({
		text = getLang("9711076"),
	})
	PopupViewController:call("addPopupView", view)
end


--当前排名按钮
function DragonWarmUpView:onWarRankClick()
	local lua_path = "game.dragonWorldCup.DragonWorldCupRankView"
	package.loaded[lua_path] = nil
	local rankView = require(lua_path):create()
	PopupViewController:addPopupInView(rankView)
end

--出战管理按钮
function DragonWarmUpView:onClickManager()
	local view = Drequire("game.dragonWarmUpBattle.DragonWarmUpManagerView"):create(self.warmUpInfo.mainStage == DragonWarmStage.SignUp)
	PopupViewController:addPopupInView(view)	
end

return DragonWarmUpView
