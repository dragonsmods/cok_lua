----------------------------
-- Author: Elex
-- Date: 2019-06-24 Monday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local DragonWarmUpView_ui = class("DragonWarmUpView_ui")

--#ui propertys


--#function
function DragonWarmUpView_ui:create(owner, viewType, paramTable)
	local ret = DragonWarmUpView_ui.new()
	CustomUtility:DoRes(506, true)
	CustomUtility:DoRes(512, true)
	CustomUtility:LoadUi("DragonWarmUpView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function DragonWarmUpView_ui:initLang()
	LabelSmoker:setText(self.m_tileLabel, "3200002")
	LabelSmoker:setText(self.m_battleProgress, "9711052")
	LabelSmoker:setText(self.m_eventLabel, "9711051")
	LabelSmoker:setText(self.m_titleTxt, "9711050")
end

function DragonWarmUpView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function DragonWarmUpView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function DragonWarmUpView_ui:onWarRankClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onWarRankClick", pSender, event)
end

function DragonWarmUpView_ui:onClickHelp(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickHelp", pSender, event)
end

function DragonWarmUpView_ui:onClickEngage(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickEngage", pSender, event)
end

function DragonWarmUpView_ui:onClickEnter(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickEnter", pSender, event)
end

function DragonWarmUpView_ui:onClickSignUpBtn(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickSignUpBtn", pSender, event)
end

function DragonWarmUpView_ui:onTipBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onTipBtnClick", pSender, event)
end

function DragonWarmUpView_ui:onClickManager(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickManager", pSender, event)
end

return DragonWarmUpView_ui

