--报名界面，选择出战时间
local DragonWarmUpTimeView = class("DragonWarmUpTimeView",
	function()
		return PopupBaseView:create()
	end
)
DragonWarmUpTimeView.__index = DragonWarmUpTimeView

function DragonWarmUpTimeView:create(canNot)
    local view = DragonWarmUpTimeView.new()    
	Drequire("game.dragonWarmUpBattle.DragonWarmUpTimeView_ui"):create(view, 0)
	if view:initView(canNot) then
		return view
	end
end

function DragonWarmUpTimeView:initView(canNot)
	if self:init(true, 0) then 
        CCLoadSprite:call("loadDynamicResourceByName", "activity_ad")
		if (CCLoadSprite:call("loadDynamicResourceByName", "DragonBattle_warm_face")) then
			local ad_sf = CCLoadSprite:call("getSF", "BG_dragonWarmAD_2.png")		
			self.ui.m_dragonBg:setSpriteFrame(ad_sf)
		end
		local function TouchEvent(eventType,x,y)
			if eventType == "began" then  
				return self:onTouchBegan(x, y)  
			elseif eventType == "moved" then  
				return self:onTouchMoved(x, y)  
			else
				return self:onTouchEnded(x, y)  
			end
		end	
		local layer = cc.Layer:create()
		self:addChild(layer)
		layer:setTouchEnabled(true)
		layer:registerScriptTouchHandler(TouchEvent)
		layer:setSwallowsTouches(true)

		CCCommonUtilsForLua:setButtonTitle(self.ui.m_sureBtn, getLang("140020"))
        self.ui.m_sureBtn:setEnabled(false)
		local addHeight = self:call("getExtendHeight")	
		-- self.ui.m_bottomNode:setPositionY(self.ui.m_bottomNode:getPositionY()+addHeight)
		-- self.ui.m_tableView:setPositionY(self.ui.m_tableView:getPositionY()+ addHeight)
		local viewSize = self.ui.m_tableView:getViewSize()
		self.ui.m_tableView:setViewSize(cc.size(viewSize.width,viewSize.height + addHeight))		
		self:reqData()
		self.signUpInfo = {}
			
		return true
	end

	return false
end
--请求界面数据
function DragonWarmUpTimeView:reqData()
	DragonWarmUpManager:reqSignUpInfo()
end

function DragonWarmUpTimeView:onEnter()
	self:setTitleName(getLang("4249871"))
	registerScriptObserver(self,self.getDataBack,"msg.DragonWarmUpTimeView.getDataBack")
end

function DragonWarmUpTimeView:onExit()
	unregisterScriptObserver(self,"msg.DragonWarmUpTimeView.getDataBack")
end
function DragonWarmUpTimeView:onTouchBegan(x, y)
	if isTouchInside(self.ui.m_touchLayer, x, y) then
		if isTouchInside(self.ui.m_sureBtn, x, y) and self.ui.m_sureBtn:isEnabled() then
			self:onSureClick()
		end
		return true 
	end
	return false
end

function DragonWarmUpTimeView:onTouchMoved(x,y)

end

function DragonWarmUpTimeView:onTouchEnded(x, y)

end

function DragonWarmUpTimeView:getDataBack()
	self.signUpInfo = DragonWarmUpManager:getWarmUpSignInfo()
	self.applyState = self.signUpInfo.applyState
	self.data = self.signUpInfo.rooms
	self.index = self.signUpInfo.index
	for k,v in pairs(self.data or {}) do
		v.parent = self
		if self.applyState and tonumber(v.index) == self.index then
			v.selected = true
			v.state = "1"
		else
			v.selected = false
			v.state = "0"
		end		
		v.applyState = self.applyState
	end
	self.ui:setTableViewDataSource("m_tableView",self.data)
	local offsetY = 140*(self.index>=0 and self.index or 0)
	local curOffset = self.ui.m_tableView:getContentOffset()
	self.ui.m_tableView:setContentOffset(ccp(0,curOffset.y+offsetY))
end

function DragonWarmUpTimeView:clickSelect(index,selected)
	for k,v in pairs(self.data or {}) do
		if tonumber(v.index) == index then
			v.selected = selected			
		else
			v.selected = false
		end
	end
	self.index = index
	self.ui.m_sureBtn:setEnabled(selected)
	local offset = self.ui.m_tableView:getContentOffset()
	self.ui.m_tableView:reloadData()
	self.ui.m_tableView:setContentOffset(offset)
end

function DragonWarmUpTimeView:onSureClick()
	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	if playerInfo:call("isInAlliance") then
		local allianceInfo = playerInfo:getProperty("allianceInfo")
		local rank = allianceInfo:getProperty("rank")
		if rank < 4 then
			YesNoDialog:show(getLang("E100119"))
			return
		end
	else
		YesNoDialog:show(getLang("108105"))
		return
	end

	if not self.applyState then
		local showIndex = tonumber(self.index) + 1
		local desc = getLang("9711075", tostring(showIndex))
		local callback = function() 
			DragonWarmUpManager:sendSignUpCmd(self.index)
			self.ui.m_sureBtn:setEnabled(false)
		end
		local func = cc.CallFunc:create(callback)
		YesNoDialog:call("show", desc, func)		
	end
end

return DragonWarmUpTimeView