--hxq 任务列表通用显示文件
local integrateCommonTaskView = class("integrateCommonTaskView",
    function (  )
        return cc.Layer:create()
    end
)
integrateCommonTaskView.__index = integrateCommonTaskView

--任务主题
local TaskThemeNode = class("TaskThemeNode",
    function()
        return cc.Node:create()
    end
)

------------------------------领取奖励COMMAND-------------------------------------
local FinishTaskCommand = class("FinishTaskCommand",LuaCommandBase)
function FinishTaskCommand.create(CMDName,Func)
    local ret = FinishTaskCommand.new()
    if CMDName and CMDName ~= "" then
        ret:initWithName(tostring(CMDName))
        ret.callbackFun = Func
        return ret
    end
end

--value_type: 0/传String  1/传int型
function FinishTaskCommand:addExtParams(key,value,value_type)
    if nil == value_type then value_type = 0 end
    if value_type == 0 then
        self:putParam(tostring(key), CCString:create(tostring(value)))
    elseif value_type == 1 then
        self:putParam(tostring(key), CCInteger:create(tonumber(value)))
    end
end

function FinishTaskCommand:handleReceive(dict)
    dump("FinishTaskCommand:handle data+++")
    local tbl = self:parseMsg(dict)
    if type(tbl) == "boolean" then
        dump("error+++")
        return tbl
    end
    dump(tbl, "FinishTaskCommand:handleReceive+++ ", 10)
    CCSafeNotificationCenter:postNotification("msg.integrateCommonTaskView.finishTaskFunc",dict)
    return true
end
------------------------------领取奖励COMMAND-------------------------------------

--[[
    viewSize:装载该任务列表的Node尺寸,显示大小
    taskData:对应的任务列表数据
    {
        commandName = "", 领取奖励的协议，不同活动领取奖励的协议不同, 当前默认给服务器的参数是只有taskID,需要扩展可以分类别添加参数
        commandExtParamTbl = {},领奖协议附加参数
        taskXMLName = "", 任务表
        taskThemeName = "",任务主题表

        taskArr={
            [1]={taskId="",rewardId="",process=0,targetNum=100}
            ...
            
            taskId:在XML表中查询获取dialogID,和参数,themeId,index等
            来自服务器的数据 :rewardId, state是否已经领取过， process:当前积分, targetNum:目标积分 
            状态显示逻辑: process:当前积分 < targetNum:目标积分
        }
    }        
    type: 1/有分类标签   0/没有分类标签  默认没有(以后又有新需求再扩展)

    领取奖励以后会有消息通知，修改taskData值，装载该view的parentView,注册名为"msg.commonTaskView.finish"接收通知，刷新界面tipNum，不需要刷新其他显示可以不注册
]]
function integrateCommonTaskView:create(viewSize,taskData,type)
    dump("hxq integrateCommonTaskView:create......")
    local view = integrateCommonTaskView.new()
    Drequire("game.WelfareIntegrate.integrateCommon.integrateCommonTaskView_ui"):create(view,0,viewSize)
    if view:initView(taskData,type) then
        return view
    end
end


function integrateCommonTaskView:initView(taskData,type)
    if not self:checkParams(taskData) then
        return false
    end

    if nil == type then
        self.m_type = 0
    else
        self.m_type = type
    end
    if self.m_type == 0 then
        self.ui.m_themeNode:setPositionY(self.ui.m_themeNode:getPositionY()+60)
        local o_size = self.ui.m_listTableView:getViewSize()        
        self.ui.m_listTableView:setViewSize(cc.size(o_size.width,o_size.height+60))
        local pos_y = self.ui.m_listTableView:getPositionY()
    end

    local cellSizeForTable = function(tab, idx)
        return self:setCellSize(tab, idx)
    end
    self.ui.m_listTableView:registerScriptHandler(cellSizeForTable,cc.TABLECELL_SIZE_FOR_INDEX)
    self.theme_y = self.ui.m_themeNode:getPositionY()

    self.taskData = taskData --包含theme,cell数据
    self.m_commandName = self.taskData.commandName    
    self.m_commandExtParamTbl = self.taskData.commandExtParamTbl or {}--除了taskId以外的附加参数
    --任务列表和任务主题列表
    self.taskXMLName = self.taskData.taskXMLName --任务表 open_server_task
    self.taskThemeName = self.taskData.taskThemeName --任务主题表 open_server_theme

    self.taskIdParamName = taskData.taskIdParamName

    self.finishTaskId = ""
    self.themeTbl = {} --任务主题 key->index
    self.themeCount = 0
    self.selectIndex = 0
    self:setData()
    self:setTitleNode()

    return true
end

--检查一下传入的参数正确性
function integrateCommonTaskView:checkParams(taskData)
    local res = true
    if nil == taskData then
        dump("integrateCommonTaskView:checkParams taskData is nil")
        return false
    end
    if not taskData.commandName then
        dump("taskData.commandName is nil")
        res = false
    end

    if not taskData.taskArr then
        dump("taskData.taskArr is nil")
        res = false
    end
    return res
end

--封装数据
function integrateCommonTaskView:setData()
    local taskXmlData = CCCommonUtilsForLua:getGroupByKey(self.taskXMLName) --任务表
    --分主题
    local taskArr = self.taskData.taskArr
    local tempTbl={}
    local rewardTbl = {}
    for k,v in pairs(taskArr) do
        local id = v.taskId
        local process = tonumber(v.process)
        local targetNum = tonumber(v.targetNum)
        local info = taskXmlData[id]
        local rewardId = v.rewardId
        local state = tonumber(v.state)
        if rewardId then
            rewardTbl[rewardId] = rewardId
        end
        if info then
            info.process = process
            info.targetNum = targetNum
            info.rewardId = rewardId
            info.state = state
            info.parent = self
            if self.m_type == 1 then
                local themeId = info.themeid
                if tempTbl[themeId] == nil then
                    tempTbl[themeId] = {}
                    tempTbl[themeId].taskArr = {}
                end                
                table.insert( tempTbl[themeId].taskArr, info)
            else
                if nil == tempTbl.taskArr then
                    tempTbl.taskArr = {}
                end
                table.insert( tempTbl.taskArr, info)
            end
        else
            dump(id,"there is no taskID in 'open_server_task' :")
        end
    end

    self.themeCount = 0
    self.themeTbl = {}
    local function sortByIndex(a,b)
        return tonumber(a.index) < tonumber(b.index)
    end

    local function sortByState(a, b)
        if a.state and b.state and a.process and b.process and a.targetNum and b.targetNum then
            if tonumber(a.state) < tonumber(b.state) then
                return true
            elseif tonumber(a.state) > tonumber(b.state) then
                return false
            else
                if tonumber(b.process) >= tonumber(b.targetNum) then
                    return false
                elseif tonumber(a.process) >= tonumber(a.targetNum) then
                    return true
                elseif tonumber(a.index) < tonumber(b.index) then
                    return true
                else
                    return false
                end
            end
        else
            return sortByIndex(a, b)
        end
    end
    local sortFunc = sortByState
    
    if self.m_type == 1 then
        for k,v in pairs(tempTbl) do
            local key = k            
            local index = CCCommonUtilsForLua:getPropByIdGroup(self.taskThemeName, key, "index")
            local dialogId = CCCommonUtilsForLua:getPropByIdGroup(self.taskThemeName, key, "dialogid")
            v.themeId = key
            v.index = tonumber(index)
            v.dialogId = dialogId
            local taskArr = v.taskArr
            table.sort( taskArr, sortFunc )
            table.insert( self.themeTbl,v)
            self.themeCount = self.themeCount + 1
        end
    else
        local taskArr = tempTbl.taskArr
        table.sort( taskArr, sortFunc )
        table.insert( self.themeTbl,tempTbl)
    end

    table.sort( self.themeTbl, sortFunc)
    local rewardArr = {}
    for k,v in pairs(rewardTbl) do
        table.insert( rewardArr, v )
    end
    -- dump(rewardArr,"hxq rewardArr is ")
    GlobalData:call("shared"):call("requestMultiRewardData", rewardArr)
end

function integrateCommonTaskView:setTitleNode()
    if self.m_type ~= 1 then
        dump(self.themeTbl,"hxq self.themeTbl is ")
        local taskData = self.themeTbl[1].taskArr
        self.selectIndex = 1
        self.ui:setTableViewDataSource("m_listTableView",taskData)
        return 
    end

    if self.themeCount <= 1 then
        dump("error~~~~ check themeTbl")
        return
    end
    local node_width = 605/self.themeCount
    local node_height = 60
    -- if self.themeCount == 2 then
    --     node_height = 60
    -- elseif self.themeCount > 2 then
    --     node_height = 60
    --     -- self.ui.m_themeNode:setPositionY(self.theme_y + 10)     
    -- end
    local node_size = cc.size(node_width,node_height)
    self.ui.m_topNode:removeAllChildren()
    self.ui.m_topSprNode:removeAllChildren()
    local pos_x = 0

    --创建缝线
    local function createLineSpr()
        local spr = CCLoadSprite:createSprite("DEC_fengexian03.png")
        spr:setAnchorPoint(ccp(0.5,0.5))
        spr:setPosition(ccp(pos_x+1,node_height/2))
        if self.themeCount > 2 then
            spr:setScaleY(35/69)
            spr:setOpacity(255*0.2)
        end        
        self.ui.m_topSprNode:addChild(spr)
    end

    --创建themeNode
    for k, v in pairs(self.themeTbl) do
        v.size = node_size
        v.parent = self
        v.new_index = k
        local node = TaskThemeNode:create(v)
        self.ui.m_topNode:addChild(node)
        node:setPositionX(pos_x)
        node:setTag(k)
        node:onClickSelf(false)
        pos_x = pos_x + node_width

        if k ~= self.themeCount then --如果是最后一个，不加缝线
            createLineSpr()
        end
        
        if k == 1 then
            node:onClickSelf(true)
        end
    end
end

--根据reward数组大小来选择cell尺寸
function integrateCommonTaskView:setCellSize(tab, idx)
    local width = 640
    local height = 139
    local data = self.themeTbl[self.selectIndex]  
    local index = idx + 1
    if data and data.taskArr[index] then
        local rewardId = data.taskArr[index].rewardId
        local rwd = GlobalData:call("getCachedRewardData", rewardId)
        local rwdData = arrayToLuaTable(rwd)
        data.taskArr[index].rewardNum = #rwdData
        if #rwdData > 5 then
            height = 135 * 1.8
        end
    end
    return width,height
end

--点击任务主题
function integrateCommonTaskView:onClickTheme(index)
    for i=1,self.themeCount do
        if i ~= index then
            local themeNode = self.ui.m_topNode:getChildByTag(i)
            if themeNode then
                themeNode:onClickSelf(false) --必须是false
            end
        end
    end
    local data = self.themeTbl[index]
    if data then
        local taskArr = data.taskArr
        self.selectIndex = index 
        self.ui:setTableViewDataSource("m_listTableView",taskArr)
        CCSafeNotificationCenter:postNotification("msg.commonTaskView.finish")
    end
end

function integrateCommonTaskView:getRewardDataBack()
    dump("hxq integrateCommonTaskView:getRewardDataBack")
    --默认打开第一个任务主题
    local node = self.ui.m_topNode:getChildByTag(1)
    if node then      
        node:onClickSelf(true)
    end
end

function integrateCommonTaskView:onEnter()
    registerScriptObserver(self,self.finishTaskFunc,"msg.integrateCommonTaskView.finishTaskFunc")
    registerScriptObserver(self,self.getRewardDataBack,"MSG_GET_MULTY_REWARD_DETAIL_BACK")	
end

function integrateCommonTaskView:onExit()
    unregisterScriptObserver(self,"MSG_GET_MULTY_REWARD_DETAIL_BACK")
    unregisterScriptObserver(self,"msg.integrateCommonTaskView.finishTaskFunc")
end

function integrateCommonTaskView:sendFinishTask(taskId)
    dump(taskId,"hxq  sendFinishTask taskId is")
    if nil == taskId or taskId == "" then
        return
    end
    self.finishTaskId = taskId
    local cmd = FinishTaskCommand.create(self.m_commandName)
    dump(taskId,"hxq taskId is ")
    local paramName = self.taskIdParamName or "taskId"
    cmd:addExtParams(paramName,taskId,0)
    for k, v in pairs (self.m_commandExtParamTbl or {}) do
        local type = v.type
        local name = v.name
        local value = v.value
        cmd:addExtParams(name,value,tonumber(type))
    end
    cmd:send()
    if (GuideController:call("isInTutorial")) then
        GuideController:call("next")
    end
end

function integrateCommonTaskView:finishTaskFunc(dict)
    local tbl = dictToLuaTable(dict)
    if tbl.params and tbl.params.rewardArray then 
        local rewardArr = tbl.params.rewardArray
        GCMRewardController:call("getInstance"):call("retReward2", luaTableToArray(rewardArr), true)
    end
    --任务领取后匹配任务列表，修改状态
    local finish_state
    local function changeTaskStateById(_taskId)
        local res = false
        local taskData = self.themeTbl[self.selectIndex].taskArr
        for k,v in pairs(taskData) do
            if v.id == _taskId then
                dump("hxq change success ")
                v.state = 1
                finish_state = 1
                res = true
                break
            end
        end
        return res
    end
    local marchOK = false
    if self.finishTaskId ~= "" then
        marchOK = changeTaskStateById(self.finishTaskId)
    end
    --成功修改
    if marchOK then
        local offset = self.ui.m_listTableView:getContentOffset()
        self.ui.m_listTableView:reloadData()
        self.ui.m_listTableView:setContentOffset(offset)
        local dict = CCDictionary:create()
        dict:setObject(CCString:create(self.finishTaskId), 'taskId')
        if finish_state then
            dict:setObject(CCString:create(tostring(finish_state)), 'state')
        end
        CCSafeNotificationCenter:postNotification("msg.commonTaskView.finish",dict)
    end
    self.finishTaskId = "" --重置

end

--返回当前界面所有可领取的任务数量,此接口仅在setData完成之后才有调用意义
function integrateCommonTaskView:getTotalTipsNum()
    local res = 0
    for k, v in pairs(self.themeTbl) do
        local taskArr = v.taskArr
        if taskArr then
            for index, info in pairs(taskArr) do
                local state = info.state
                local process = info.process
                local targetNum = info.targetNum
                if state == 0 and process >= targetNum then
                    res = res + 1
                end
            end
        end
    end
    return res
end

--新手引导：返回列表第一个Cell的button
function integrateCommonTaskView:getGuideTargetNode()
    local cell = self.ui.m_listTableView:cellAtIndex(0)
    if cell then
        local button = cell.ui.m_getButton
        return button        
    end    
end

--info: index 主题顺序 ID:dialogID size:尺寸 parent
function TaskThemeNode:create(info)
    local node = TaskThemeNode.new()
    if node:initNode(info) then
        return node
    end
end

function TaskThemeNode:initNode(info)
    local name = info.dialogId
    self.index = info.new_index
    self.size = info.size
    self.parent = info.parent
    self.taskArr = info.taskArr   

    --创建button
    self.menuItem = cc.ControlButton:create()
	self.menuItem:setPreferredSize(self.size)
	self.menuItem:setBackgroundSpriteForState(CCLoadSprite:call("createScale9Sprite", "BTN_yeqian02.png"), CCControlStateNormal);
    self.menuItem:setBackgroundSpriteForState(CCLoadSprite:call("createScale9Sprite", "BTN_yeqian01.png"), CCControlStateHighlighted);
    self.menuItem:setBackgroundSpriteForState(CCLoadSprite:call("createScale9Sprite", "BTN_yeqian01.png"), CCControlStateDisabled);
    self.menuItem:setAnchorPoint(ccp(0,0))
    self.menuItem:setPosition(ccp(0,0))
	self:addChild(self.menuItem)
	self.menuItem:addHandleOfControlEvent(function(eventName, sender) self:onClickSelf(true) end, CCControlEventTouchUpInside)

    --创建name
    self.txt = CCLabelIF:call("create1", getLang(name))
    self.txt:call("setColor", cc.c3b(255, 255, 255))
    self.txt:call("setFontSize", 18)
    self.txt:call("setAnchorPoint",ccp(0.5, 0.5))
    self.txt:call("setDimensions", self.size.width, self.size.height)
    self.txt:setPosition(ccp(self.size.width/2,self.size.height/2))
    self:addChild(self.txt)
    self:changeTipsNum()
    local function onNodeEvent(event)
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(onNodeEvent)
    return true
end

function TaskThemeNode:changeTipsNum()
    self.tipNum = 0
    for k,v in pairs(self.taskArr) do
        local process = tonumber(v.process)
        local targetNum = tonumber(v.targetNum)
        local state = v.state
        if state == 0 and process >= targetNum then
            self.tipNum = self.tipNum + 1
        end
    end
    self:removeChildByTag(19)
    self:removeChildByTag(20)
    --创建tipNum
    if self.tipNum > 0 then
        local tipSpr = CCLoadSprite:createSprite("BG_tishidiban.png")
        tipSpr:setTag(19)
        tipSpr:setPosition(ccp(self.size.width-20, self.size.height-20))
        self:addChild(tipSpr)
        self.tipLabel = CCLabelIF:call("create1", tostring(self.tipNum))
        self.tipLabel:setPosition(ccp(self.size.width-20, self.size.height-18))
        self.tipLabel:call("setColor", cc.c3b(25, 25, 25))
        self.tipLabel:call("setFontSize", 18)
        self:addChild(self.tipLabel)
        self.tipLabel:setTag(20)
    end
end

function TaskThemeNode:onEnter()
    registerScriptObserver(self, self.changeTipsNum, "msg.commonTaskView.finish")
end

function TaskThemeNode:onExit()
    unregisterScriptObserver(self,"msg.commonTaskView.finish")
end

function TaskThemeNode:onClickSelf(isOnClick)
    if self.parent then
        if isOnClick then
            self.parent:onClickTheme(self.index)
            self.menuItem:setEnabled(false)
            self.txt:call("setColor", cc.c3b(255, 255, 255))
        else
            self.menuItem:setEnabled(true)
            self.txt:call("setColor", cc.c3b(147, 147, 147))
        end
    end
end

return integrateCommonTaskView