local WorldBossComingAniView =
	class(
	"WorldBossComingAniView",
	function()
		-- return PopupBaseView:create()
		return cc.Layer:create()
	end
)
WorldBossComingAniView.__index = WorldBossComingAniView

ccb["WorldBossComingAniView"] = WorldBossComingAniView or {}
-- dump(ccb, "WorldBossComingAniView.ccb")

function WorldBossComingAniView:create()
	dump("WorldBossComingAniView:create")
	local view = WorldBossComingAniView.new()
    CCLoadSprite:call('loadDynamicResourceByName', 'worldboss_coming_ani_face')
	Drequire("game.UIComponent.WorldBossComingAniView_ui"):create(view, 1)
	view.ctl = Drequire("game.UIComponent.WorldBossComingAniController").getInstance()

	if view:initView() == false then
		return nil
	end
	return view
end

function WorldBossComingAniView:initView()
	if not self:checkShow() then
		return false
	end
	return true
end

function WorldBossComingAniView:onEnter()
	self:setVisible(false)
    self.worldBossComingAniTimer = XEvtTimer:delayTimer(2.5, function()
		self.worldBossComingAniTimer = nil
		
		local info = self.ctl:getBossInfo()
		if info and info.positionindex and tonumber(info.positionindex) > 0 then
			self:setVisible(true)
			self:showAni()
			self.worldBossComingAniTimer = XEvtTimer:delayTimer(3, function()
				-- PopupViewController:call("removePopupView", self)
				self:removeFromParent()
				dump("WorldBossComingAniView:closeSelf")
			end)
		else
			self:removeFromParent()
		end
    end)
end

function WorldBossComingAniView:onExit()
	if self.worldBossComingAniTimer then
		XEvtTimer:cancelTimer(self.worldBossComingAniTimer)
	end
end

function WorldBossComingAniView:showAni()
	-- self.ui.m_root:setVisible(false)
	Dprint("WorldBossComingAniView:showAni")
	local mgr = ccb["WorldBossComingAniView"]["mAnimationManager"]
	mgr:runAnimationsForSequenceNamed("start")
end

function WorldBossComingAniView:onBtnClick()
	Dprint("WorldBossComingAniView:onBtnClick")
	self:gotoBoss()
end

function WorldBossComingAniView:gotoBoss()
    local bossInfo = self.ctl:getBossInfo()
    if bossInfo then
        local posIndex = bossInfo.positionindex
        if SceneController:call("getCurrentSceneId") == SCENE_ID_WORLD then
            local point = WorldController:call("getPointByIndex", tonumber(posIndex))
            WorldMapView:call("gotoTilePoint", point)
            WorldMapView:call("openTilePanel", pointIndex)
        else
            SceneController:call("gotoScene", SCENE_ID_WORLD, false, true, tonumber(posIndex))
        end
        PopupViewController:call("forceClearAll", true)
    end
end

function WorldBossComingAniView:checkShow()
    Dprint("WorldBossComingAniView:checkShow")
    if not CCCommonUtilsForLua:isFunOpenByKey("overlord_UIicon") then
        return false
    end
	if not CCLoadSprite:call("getSF", "worldboss_coming_ani_bg.png") then
		return false
	end
    local sceneId = SceneController:call("getCurrentSceneId")
	if sceneId ~= SCENE_ID_WORLD then
		return false
	end
	return true
end

return WorldBossComingAniView