local FestivalActivitiesBattlePassNodeIcon = class("FestivalActivitiesBattlePassNodeIcon", cc.Node)

function FestivalActivitiesBattlePassNodeIcon.create(nodeSize, contentSize)
    dump("FestivalActivitiesBattlePassNodeIcon.create-----------")
    local view = FestivalActivitiesBattlePassNodeIcon.new() --get Node
    if view:initView(nodeSize, contentSize) then --设置view的尺寸属性
        return view
    end

    return false
end

function FestivalActivitiesBattlePassNodeIcon:initView(nodeSize, contentSize) --view初始化函数
    dump("FestivalActivitiesBattlePassNodeIcon.initView-----------")
    CCLoadSprite:call("loadDynamicResourceByName", "57394_face")
    self:setContentSize(nodeSize)
    local bg = CCLoadSprite:createSprite("battlepassicon.png")
    local sf =  CCLoadSprite:call("getSF", "battlepassicon.png")
    if not sf then
        CCLoadSprite:call("doResourceByCommonIndex", 506, true)
        bg = CCLoadSprite:createSprite("ativity_icon_beiyong.png")
    end
 
    bg:setPosition(nodeSize.width * 0.5, nodeSize.height * 0.5)
    bg:setScale(0.9)
    local bg2 = CCLoadSprite:createSprite("new_iconBg.png")
    bg2:setScale(0.8)
    bg2:setPosition(cc.p(nodeSize.width / 2, nodeSize.height / 2))
    self:addChild(bg2)
    self:addChild(bg)


    -- 红点 begin

    self.m_redDotNode = cc.Node:create()
    self.m_redDotNode:setPosition(cc.p(72, 72))
    self:addChild(self.m_redDotNode, 1)

    local redDotSprite = CCLoadSprite:call("createSprite", "mail_unread_Icon.png")
    redDotSprite:setScale(0.5)
    self.m_redDotNode:addChild(redDotSprite)

    self.m_redDotLabel = cc.Label:createWithSystemFont("", "Helvetica", 14, cc.size(0, 0))
    self.m_redDotNode:addChild(self.m_redDotLabel)
  

    self.m_redDotNode:setVisible(false)
    -- 红点 end


    self:setVisible(false)
   
    self:checkVisible()

                                         
   
    return true
end


function FestivalActivitiesBattlePassNodeIcon:checkVisible()
    
    local sceneId = SceneController:call("getCurrentSceneId")
    local obj = ActivityController:call("getActObj", "57394")
    local nowtime = tonumber(GlobalData:call("getWorldTime"))
    
    if obj then
        local sT = tonumber(obj:getProperty("startTime"))
        local eT = tonumber(obj:getProperty("endTime"))
         
        if nowtime >= sT and nowtime < eT then
            if CCCommonUtilsForLua:call("isFunOpenByKey", "battlepass_new") and not isCrossServerNow()then
              
                self:setVisible(true)
                return true
                
            end
        end
    end
    return false

end
function FestivalActivitiesBattlePassNodeIcon:onEnter()
   registerScriptObserver(self, self.updateRedDot, "FestivalActivitiesBattlePassIconRedDot_refresh")
    registerScriptObserver(self, self.reqActivityData, "msg.activity.init")


end
function FestivalActivitiesBattlePassNodeIcon:onExit()
     unregisterScriptObserver(self, "FestivalActivitiesBattlePassIconRedDot_refresh")
       unregisterScriptObserver(self, "msg.activity.init")

   
end

function FestivalActivitiesBattlePassNodeIcon:reqActivityData( )

    if self:checkVisible() then

       local controller = require("game.activity.BattlePassNew.FestivalActivitiesBattlePassControllerNew").getInstance()
       controller:reqData("57394")


    end
end

function FestivalActivitiesBattlePassNodeIcon:resetLuckyDayNode()
end

function FestivalActivitiesBattlePassNodeIcon:updateRedDot(dict)
    local data = dictToLuaTable(dict)
    self.m_redDotNode:setVisible(tonumber(data.finishTaskNum)> 0)
    dump(data.finishTaskNum,"data.finishTaskNum---")
    self.m_redDotLabel:setString(data.finishTaskNum)
end
function FestivalActivitiesBattlePassNodeIcon:onSceneChanged(sceneId)
    self:checkVisible()
end

function FestivalActivitiesBattlePassNodeIcon:touchEvent()
    Dprint("FestivalActivitiesBattlePassNodeIcon:touchEvent")
    local view = Drequire("game.activity.BattlePassNew.FestivalActivitiesBattlePassView"):create("57394")
    PopupViewController:addPopupInView(view)
end

return FestivalActivitiesBattlePassNodeIcon
