local WorldBossComingAniController = class("WorldBossComingAniController")

local WORLDBOSS_ACT_ID = "57337"
local WORLDBOSS_TYPE = 16
local WORLDBOSS_ACT_ID_ELITE = "57338"
local WORLDBOSS_TYPE_ELITE = 17

_WorldBossComingAniController_Instance = nil
function WorldBossComingAniController.getInstance()
	if not _WorldBossComingAniController_Instance then
		_WorldBossComingAniController_Instance = WorldBossComingAniController.new()
	end
	return _WorldBossComingAniController_Instance
end

function WorldBossComingAniController:ctor()
	self:startRequestBossInfo()
end

function WorldBossComingAniController:getBossActId(type)
    return WORLDBOSS_ACT_ID
end

function WorldBossComingAniController:getBossType()
    return WORLDBOSS_TYPE
end

function WorldBossComingAniController:getEliteBossActId(type)
    return WORLDBOSS_ACT_ID_ELITE
end

function WorldBossComingAniController:getEliteBossType()
    return WORLDBOSS_TYPE_ELITE
end

function WorldBossComingAniController:getBossInfo()
	local arr = {
		{1, self:getBossType()},
		{1, self:getEliteBossType()},
		{2, self:getBossActId()},
		{2, self:getEliteBossActId()},
	}
	for _, v in ipairs(arr) do
		local ret = nil
		if v[1] == 1 then
			ret = self:getBossInfoByType(v[2])
		else
			ret = self:getBossInfoByActId(v[2])
		end
		if self:checkBossAliveOrWillAlive(ret) then
			return ret
		end
	end
end

function WorldBossComingAniController:getBossInfoByType(type)
	local boss = WorldBossController:call("getBossInfoByType", type)
	if boss then
		local bossInfo = boss:getProperty("m_bossInfo")
		if bossInfo then
			local ret = {
				bossType = type,
				state = tonumber(bossInfo:getProperty("m_BossState")),
                positionindex = tonumber(bossInfo:getProperty("m_BossIndex")),
				startTime = tonumber(bossInfo:getProperty("m_BossStartTime")),
				endTime = tonumber(bossInfo:getProperty("m_BossEndTime")),
			}
			-- dump(ret, "WorldBossComingAniController:getBossInfoByType:"..tostring(type))
			return ret
		end
	end
end

function WorldBossComingAniController:getBossInfoByActId(actId)
	local ret = nil
	local obj = ActivityController:call("getActObj", actId)
	if obj then
		ret = {
			bossActId = actId,
			state = -1,
			startTime = tonumber(obj:getProperty("startTime") or 0) * 1000,
			-- startTime = getTimeStamp() * 1000 + 5 * 60 * 1000,
			endTime = tonumber(obj:getProperty("endTime") or 0) * 1000,
		}
		-- dump(ret, "WorldBossComingAniController:getBossInfoByActId:"..tostring(actId))
		return ret
	end
end

function WorldBossComingAniController:checkBossAliveOrWillAlive(bossInfo)
	if bossInfo then
		if bossInfo.state == 1 or bossInfo.state == 2 then
			return true
		elseif bossInfo.startTime and bossInfo.startTime > 0 then
			local now = getTimeStamp()
			if now < bossInfo.startTime / 1000 and now + 1800 >= bossInfo.startTime / 1000 then
				return true
			end
		end
	end
	return false
end

function WorldBossComingAniController:startRequestBossInfo()
	WorldBossController:call("StartGetBossInfo", self:getBossType())
	WorldBossController:call("StartGetBossInfo", self:getEliteBossType())
end

return WorldBossComingAniController