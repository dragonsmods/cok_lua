require("game.allianceBoss.AllianceBossController")

local WorldBossComingIcon = class("WorldBossComingIcon", 
    function() return cc.Node:create() end
    )

function WorldBossComingIcon.create(nodeSize, contentSize)
    dump("WorldBossComingIcon.create-----------")
    CCLoadSprite:call("loadDynamicResourceByName", "worldboss_coming_ani_face")
    local view = WorldBossComingIcon.new() --get Node
    if view:initView(nodeSize, contentSize) then  --设置view的尺寸属性
        return view
    end

    return false
end

function WorldBossComingIcon:initView(nodeSize, contentSize)  --view初始化函数
    self.ctl = Drequire("game.UIComponent.WorldBossComingAniController").getInstance() 
    --require("game.UIComponent.WorldBossComingAniController")

    dump("WorldBossComingIcon.initView-----------")

    if not self:checkToAddView() then
        return false
    end

    self:setContentSize(nodeSize)
    -- 背景
    local bg = CCLoadSprite:createSprite("new_iconBg.png")
    bg:setPosition(nodeSize.width*0.5, nodeSize.height*0.5)
    bg:setScale(0.8)
    bg:setZOrder(-1000)

    --头像
   
    self.m_icon = getSafeSprite("worldboss_coming_icon.png", "dragonBattleBtn.png")
    self.m_icon:setPosition(nodeSize.width*0.5, nodeSize.height*0.5 + 10)
    self.m_icon:setScale(0.8)
    self:addChild(self.m_icon)
    self.m_icon:setZOrder(-999)

    --文字背景
    self.m_labelBg = CCLoadSprite:createSprite("frame_02png.png")
    self.m_labelBg:setAnchorPoint(cc.p(0.5, 0.5))
    self.m_labelBg:setScale(0.5)
    self.m_labelBg:setPosition(nodeSize.width*0.5, nodeSize.height*0.5 - 40)
    self:addChild(self.m_labelBg)

    --文字
    self.m_label = cc.Label:createWithSystemFont("", "Helvetica", 18, cc.size(0.0,0))
    self.m_label:setColor(cc.c3b(244, 203, 119))
    self.m_label:setPosition(nodeSize.width*0.5, nodeSize.height*0.5 - 40)

    self:addChild(bg)
    self:addChild(self.m_label)

    -- self:setVisible(false)
    self.m_maxCount = 20
    self.m_nowCount = 20
    
    self:updateView()

    return true
end

function WorldBossComingIcon:onEnter()
    if self.timerId then
        XEvtTimer:cancelTimer(self.timerId)
        self.timerId = nil
    end
    self.timerId = XEvtTimer:intervalTimer(0.5, function()
        self:refreshTimeCounter()
    end)
end

function WorldBossComingIcon:onExit()
    if self.timerId then
        XEvtTimer:cancelTimer(self.timerId)
        self.timerId = nil
    end
end

function WorldBossComingIcon:onSceneChanged()
    self:updateView()
end
function WorldBossComingIcon:updateView()
    self:setVisible(false)
    if SceneController:call("getCurrentSceneId") == SCENE_ID_WORLD then
        self.ctl:startRequestBossInfo()
        local bossInfo = self.ctl:getBossInfo()
		dump(bossInfo, "WorldBossComingIcon:getBossInfo")
        if bossInfo then
            self:setVisible(true)
        end
    end
end
function WorldBossComingIcon:refreshTimeCounter()
    local bossInfo = self.ctl:getBossInfo()
    if not bossInfo then
        self:setVisible(false)
    elseif self:isVisible() then
        local now = getTimeStamp()
        local startTime = tonumber(bossInfo.startTime) / 1000
        if now > startTime then
            -- self:updateView()
            self.m_labelBg:setVisible(false)
            self.m_label:setVisible(false)
        else
            if not self.m_label:isVisible() then
                self.m_labelBg:setVisible(true)
                self.m_label:setVisible(true)
            end
            local str = format_time(startTime - now)
            self.m_label:setString(str)
        end
    end
end

function WorldBossComingIcon:touchEvent()
    Dprint("WorldBossComingIcon:touchEvent")
    self:gotoBoss()
end

function WorldBossComingIcon:gotoBoss()
    local bossInfo = self.ctl:getBossInfo()
    if bossInfo and bossInfo.positionindex and tonumber(bossInfo.positionindex) > 0 then
        local posIndex = bossInfo.positionindex
        if SceneController:call("getCurrentSceneId") == SCENE_ID_WORLD then
            local point = WorldController:call("getPointByIndex", tonumber(posIndex))
            WorldMapView:call("gotoTilePoint", point)
            WorldMapView:call("openTilePanel", pointIndex)
        else
            SceneController:call("gotoScene", SCENE_ID_WORLD, false, true, tonumber(posIndex))
        end
        PopupViewController:call("forceClearAll", true)
    end
end

function WorldBossComingIcon:checkToAddView()
    if not CCCommonUtilsForLua:isFunOpenByKey("overlord_UIicon") then
        return false
    end
    local serverType = GlobalData:call("shared"):getProperty("serverType")
    if not GlobalData:call("shared"):getProperty("playerInfo"):call("isInSelfServer")
        or serverType == ServerType.SERVER_BATTLE_FIELD 
        or serverType == ServerType.SERVER_DRAGON_BATTLE 
        or serverType == ServerType.SERVER_DRAGON_BATTLE_GLOBAL 
        or serverType == ServerType.SERVER_DESPOT 
        or serverType == ServerType.SERVER_EMPIRE then
        --非本服，直接返回
        return false
    end
    return true
end

return WorldBossComingIcon
