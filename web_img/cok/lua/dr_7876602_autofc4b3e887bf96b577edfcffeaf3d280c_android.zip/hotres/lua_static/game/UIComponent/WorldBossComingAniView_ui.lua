----------------------------
-- Author: Elex
-- Date: 2019-06-17 Monday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local WorldBossComingAniView_ui = class("WorldBossComingAniView_ui")

--#ui propertys


--#function
function WorldBossComingAniView_ui:create(owner, viewType, paramTable)
	local ret = WorldBossComingAniView_ui.new()
	CustomUtility:DoRes(0, true)
	CustomUtility:LoadUi("WorldBossComingAniView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function WorldBossComingAniView_ui:initLang()
	LabelSmoker:setText(self.m_labelStart, "9711088")
end

function WorldBossComingAniView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function WorldBossComingAniView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function WorldBossComingAniView_ui:onBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBtnClick", pSender, event)
end

return WorldBossComingAniView_ui

