----------------------------
-- Author: Elex
-- Date: 2019-06-20 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local UseSpeedUpView_ui = class("UseSpeedUpView_ui")

--#ui propertys


--#function
function UseSpeedUpView_ui:create(owner, viewType, paramTable)
	local ret = UseSpeedUpView_ui.new()
	CustomUtility:LoadUi("UseSpeedUpView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function UseSpeedUpView_ui:initLang()
	LabelSmoker:setText(self.m_nameLabel, "102159")
	LabelSmoker:setText(self.m_label102358, "102358")
	LabelSmoker:setText(self.m_labelTTF67, "10010018")
	LabelSmoker:setText(self.txt_oneSpeed, "4249163")
	ButtonSmoker:setText(self.m_btnUse, "102137")
end

function UseSpeedUpView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function UseSpeedUpView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function UseSpeedUpView_ui:onClickBtnSub(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnSub", pSender, event)
end

function UseSpeedUpView_ui:onClickBtnAdd(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnAdd", pSender, event)
end

function UseSpeedUpView_ui:onClickBtnGold(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnGold", pSender, event)
end

function UseSpeedUpView_ui:onClickBtnUse(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnUse", pSender, event)
end

function UseSpeedUpView_ui:onClickBtnQuickFinish(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnQuickFinish", pSender, event)
end

return UseSpeedUpView_ui

