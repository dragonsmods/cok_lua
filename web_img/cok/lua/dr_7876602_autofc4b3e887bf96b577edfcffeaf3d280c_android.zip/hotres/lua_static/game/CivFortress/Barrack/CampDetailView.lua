---
--- Created by pengzhou.
--- DateTime: 2018/5/24 下午4:44
---

local CampDetailView = class("CampDetailView",
function()
    return PopupBaseView:create()
end)

function CampDetailView:create(info)
    local view = CampDetailView.new()
    Drequire("game.CivFortress.Barrack.CampDetailView_ui"):create(view, 0)
    if view:initView(info) == false then
        return nil
    end
    return view
end

function CampDetailView:initView(info)

    self.info = info
    callItSelfCallFunc(LuaController, "doResourceByCommonIndex", 3, true)
    CCLoadSprite:call("doResourceByCommonIndex", 204, true)
    if CCLoadSprite:call("loadDynamicResourceByName", "newHero") then
        CCLoadSprite:call("loadDynamicResourceByName", "newHero_head")
    end

    self:initTouchLayer()
    self:initNodeEvent()

    self:initConfig()
    self:initText()
    self:initList()
    self:initRewardList()


end

function CampDetailView:initList()
    self.scrollView = CCScrollView:create(self.ui.m_aListNode:getContentSize())
    self.scrollView:setDirection(kCCScrollViewDirectionVertical)
    self.scrollView:setPosition(cc.p(0,0))
    self.ui.m_aListNode:addChild(self.scrollView)

    self.totalH = 0
    --self.totalH = self.ui.m_aListNode:getContentSize().height
    local listWeight = self.ui.m_aListNode:getContentSize().width
    Dprint("@@ CampDetailView",self.totalH)

    if self.m_data then
        local height = 0
        for i, v in ipairs(self.m_data) do
            local cell = Drequire("game.CivFortress.Barrack.CampDetailArmyCell"):create()
            self.scrollView:addChild(cell)

            height = cell:getContentSize().height
            local x = 0
            if i % 2 == 0 then
                x = cell:getContentSize().width
            end
            local y =  math.floor((#self.m_data - i) / 2) + #self.m_data % 2
            y = y * height

            cell:setPosition(cc.p(x,y))
            cell:setData(v)
        end
        self.totalH = self.totalH + (math.floor(#self.m_data / 2) + #self.m_data % 2) * height
    end


    -- title
    local titleBar = Drequire("game.CivFortress.Barrack.CampDetailTitleCell"):create()
    titleBar:setTitle(getLang("108585"))
    self.scrollView:addChild(titleBar)
    titleBar:setPosition(cc.p(0,self.totalH))
    self.totalH = self.totalH + titleBar:getContentSize().height

    -- hero
    local hero = Drequire("game.CivFortress.Barrack.CampDetailHeroCell"):create()
    self.scrollView:addChild(hero)
    hero:setPosition(cc.p((listWeight - hero:getContentSize().width) / 2,self.totalH))
    self.totalH = self.totalH + hero:getContentSize().height
    hero:setData(self.hero, self.hero_level)

    --Dprint("@@",self.totalH, self.ui.m_aListNode:getContentSize().height)

    self.scrollView:setContentSize(cc.size(self.ui.m_aListNode:getContentSize().width,self.totalH));
    self.scrollView:setContentOffset(ccp(0, self.ui.m_aListNode:getContentSize().height - self.totalH));
end

function CampDetailView:initNodeEvent()
    local function onNodeEvent(event)
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(onNodeEvent)
end


function CampDetailView:onEnter()
    registerScriptObserver(self, self.refreshRewardList, MSG_GET_REWARD_DETAIL_BACK)
end

function CampDetailView:onExit()
    unregisterScriptObserver(self, MSG_GET_REWARD_DETAIL_BACK)
end

function CampDetailView:initConfig()
    self.id = self.info.campId
    self.npc     =   CCCommonUtilsForLua:getPropByIdGroup("camp_base",self.id, "npc")
    self.hero    =   CCCommonUtilsForLua:getPropByIdGroup("camp_base",self.id, "hero")
    self.hero_level         =   CCCommonUtilsForLua:getPropByIdGroup("camp_base",self.id, "hero_level")
    self.firstReward        =   CCCommonUtilsForLua:getPropByIdGroup("camp_base",self.id, "first_reward")

    --self.firstReward = "251594"
    --self.npc = "107006;2325;1|107007;2325;2|107006;2325;0|107007;2325;0|107006;2325;0|107007;2325;0|107006;2325;0|107007;2325;0"
    self.m_data =  string.split(self.npc,"|")
end

function CampDetailView:initRewardList()
    local rwd = GlobalData:call("getCachedRewardData", self.firstReward)
    local rwdData = arrayToLuaTable(rwd)
    if #rwdData == 0 then
        GlobalData:call("checkAndRequestRewardData", self.firstReward)
        self.m_needOpenRewardView = true
    else
        self:initFirstReward(rwdData)
    end
end

function CampDetailView:refreshRewardList(ref)
    if self.m_needOpenRewardView  then
        local rwd = GlobalData:call("getCachedRewardData", self.firstReward)
        local rwdData = arrayToLuaTable(rwd)
        if #rwdData > 0 then
            self.m_needOpenRewardView = false
            self:initFirstReward(rwdData)
        end
    end
end

-- 首胜奖励
function CampDetailView:initFirstReward(rwdData)
    --Dprint("@@ CampDetailView:initFirstReward")
    if rwdData and #rwdData > 0 then
        self.ui.m_listNode:removeAllChildren()
        for i, v in ipairs(rwdData) do
            local cell = Drequire("game.CivFortress.Barrack.CampIconCell"):create()
            cell:setData(v)

            local size = cell:getContentSize()
            local x = size.width * ((i - 1)%4)
            local y = size.height * (1 -(math.floor((i-1)/4)))

            cell:setPosition(cc.p(x,y))
            self.ui.m_listNode:addChild(cell)

            if i == 8 then -- 最多显示8个
                break
            end
        end
    end
end

function CampDetailView:initText()

    self.ui.m_titleLabel:setString(getLang("101528"))   -- 101528=守军详情
    self.ui.m_tagLabel:setString(getLang("103845"))     -- 103845=攻打奖励
    self.ui.m_allLabel:setString(getLang("108715"))     -- 108715=防守部队

    local armyNum = 0
    if self.m_data then
        for i, v in ipairs(self.m_data) do
            local num =  string.split(v,";")
            if #num >= 2 then
                armyNum = armyNum + tonumber(num[2])
            end
        end
    end
    --self.ui.m_allNumLabel:setString(tostring(armyNum))
    self.ui.m_allLabel:setString(getLang("108715") .. "  " .. armyNum)     -- 108715=防守部队

end

function CampDetailView:initTouchLayer()
    self.touchLayer = cc.Layer:create()
    self:addChild(self.touchLayer)

    local function touchHandle( eventType, x, y )
        if eventType == "began" then
            return self:onTouchBegan(x, y)
        elseif eventType == "moved" then
            self:onTouchMoved(x, y)
        else
            self:onTouchEnded(x, y)
        end
    end

    self.touchLayer:registerScriptTouchHandler(touchHandle)
    self.touchLayer:setTouchEnabled(true)
    self.touchLayer:setSwallowsTouches(false)
end

function CampDetailView:onTouchBegan(x, y)
    if not isTouchInside(self.ui.m_touchNode,x,y) then
        return true
    end

    return false
end

function CampDetailView:onTouchMoved(x, y)

end

function CampDetailView:onTouchEnded(x, y)
    if not isTouchInside(self.ui.m_touchNode,x,y) then
        PopupViewController:call("getInstance"):call("goBackPopupView")
    end
end

return CampDetailView