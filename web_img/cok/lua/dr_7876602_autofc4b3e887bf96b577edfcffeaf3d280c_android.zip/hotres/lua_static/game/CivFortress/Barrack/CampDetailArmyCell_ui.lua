----------------------------
-- Author: Elex
-- Date: 2018-05-27 Sunday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CampDetailArmyCell_ui = class("CampDetailArmyCell_ui")

--#ui propertys


--#function
function CampDetailArmyCell_ui:create(owner, viewType, paramTable)
	local ret = CampDetailArmyCell_ui.new()
	CustomUtility:LoadUi("CampDetailArmyCell.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CampDetailArmyCell_ui:initLang()
end

function CampDetailArmyCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CampDetailArmyCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return CampDetailArmyCell_ui

