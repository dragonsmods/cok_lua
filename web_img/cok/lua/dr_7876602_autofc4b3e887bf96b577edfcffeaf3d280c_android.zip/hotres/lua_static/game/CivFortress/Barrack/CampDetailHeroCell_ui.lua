----------------------------
-- Author: Elex
-- Date: 2018-05-27 Sunday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CampDetailHeroCell_ui = class("CampDetailHeroCell_ui")

--#ui propertys


--#function
function CampDetailHeroCell_ui:create(owner, viewType, paramTable)
	local ret = CampDetailHeroCell_ui.new()
	CustomUtility:LoadUi("CampDetailHeroCell.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CampDetailHeroCell_ui:initLang()
end

function CampDetailHeroCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CampDetailHeroCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return CampDetailHeroCell_ui

