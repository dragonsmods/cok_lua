---
--- Created by pengzhou.
--- DateTime: 2018/5/23 下午4:53
---

local CivBarracksAddUnders = class("CivBarracksAddUnders", function (  )
    return cc.Layer:create()
end)

function CivBarracksAddUnders:ctor(cityInfo,luaMap )

    --Dprint("@@ CivBarracksAddUnders:ctor",index)
    local spr = CCLoadSprite:call("createSprite", "yingdi.png")
    self:addChild(spr)


    -- if tonumber(luaMap.startOccupyTime) <= 0 then
    --     local heroBg    = CCLoadSprite:call("createSprite","res_btn.png")
    --     self:addChild(heroBg)
    --     heroBg:setPosition(cc.p(-10,80))

    --     local hero      =   CCCommonUtilsForLua:getPropByIdGroup("camp_base",luaMap.campId, "hero")
    --     local heroHead  =   CCCommonUtilsForLua:getPropById(hero, "pic")  ..  ".png";
    --     heroHead        =   CCLoadSprite:call("createSprite", heroHead)
    --     heroHead:setScale(0.4)
    --     heroHead:setPosition(cc.p(heroBg:getContentSize().width/2 , heroBg:getContentSize().height/2 + 4))
    --     heroBg:addChild(heroHead)
    -- end

end

function addCivBarracksUnders( index )
    --Dprint("@@ addCivBarracksUnders",index)
    local world = WorldMapView:call("instance")
    if nil == world then
        return nil
    end
    --Dprint("@@ addCivBarracksUnders 1")
    local cityInfo = WorldController:call("getCityInfoByIndex", index)
    if nil == cityInfo then
        return nil
    end
    --Dprint("@@ addCivBarracksUnders 2",cityInfo:getProperty("luaType") )
    if cityInfo:getProperty("luaType") ~= WorldCityType.city_barracks then
        return nil
    end
    local luaMap = cityInfo:call("getLuaMap")

    --Dprint("@@ addCivBarracksUnders 3")
    local pos = cityInfo:call("GetPositionInMap")
    local ret = CCArray:create()
    local under = CivBarracksAddUnders.new(cityInfo,luaMap)
    under:setTag(index)
    under:setPosition(cc.p(pos.x, pos.y))
    ret:addObject(under)
    world:call("getCityBatchNode"):addChild(under)

    if tonumber(luaMap.startOccupyTime) <= 0 then
        local heroNode = cc.Node:create()
        local heroBg    = CCLoadSprite:call("createSprite","res_btn.png")
        heroNode:addChild(heroBg)
        heroBg:setPosition(cc.p(-10,80))

        local hero      =   CCCommonUtilsForLua:getPropByIdGroup("camp_base",luaMap.campId, "hero")
        local heroHead  =   CCCommonUtilsForLua:getPropById(hero, "pic")  ..  ".png";
        heroHead        =   CCLoadSprite:call("createSprite", heroHead)
        heroHead:setScale(0.4)
        heroHead:setPosition(cc.p(heroBg:getContentSize().width/2 , heroBg:getContentSize().height/2 + 4))
        heroBg:addChild(heroHead)

        heroNode:setTag(index)
        heroNode:setPosition(cc.p(pos.x, pos.y))
        ret:addObject(heroNode)
        world:call("getBatchNode"):addChild(heroNode)
    end

    -- 等级
    world:call("addBatchItem", BatchTagType.LevelTag, index, CCString:create(1))

    local campLv = ""
    if luaMap.campId then
        campLv     =   CCCommonUtilsForLua:getPropByIdGroup("camp_base",luaMap.campId, "level")
    end

    local pos = cityInfo:call("GetPositionInMap")
    local lv = CCLabelBatch:call("create", campLv, world:call("getLabelNode"))
    if nil ~= lv then
        lv:setScale(0.6*0.8);
        lv:setSkewY(22.5);
        lv:setColor(cc.c3b(255, 235, 180))
        lv:setPosition(cc.p(pos.x + 30, pos.y - 25))
        ret:addObject(lv)
    end

    return ret

end

return CivBarracksAddUnders