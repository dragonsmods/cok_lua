----------------------------
-- Author: Elex
-- Date: 2017-12-13 Wednesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CivFortressInfoView_ui = class("CivFortressInfoView_ui")

--#ui propertys


--#function
function CivFortressInfoView_ui:create(owner, viewType)
	local ret = CivFortressInfoView_ui.new()
	CustomUtility:DoRes(500, true)
	CustomUtility:DoRes(504, true)
	CustomUtility:DoRes(7, true)
	CustomUtility:LoadUi("CivFortressInfoView.ccbi", ret, owner, true, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then		owner:initTableViewByOwner()
	else		ret:initTableView()	end	return ret
end

function CivFortressInfoView_ui:initLang()
end

function CivFortressInfoView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CivFortressInfoView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CivFortressInfoView_ui:onLvUpButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onLvUpButtonClick", pSender, event)
end

function CivFortressInfoView_ui:onGetButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onGetButtonClick", pSender, event)
end

function CivFortressInfoView_ui:onEnterButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onEnterButtonClick", pSender, event)
end

function CivFortressInfoView_ui:onMoveButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onMoveButtonClick", pSender, event)
end

function CivFortressInfoView_ui:onUpButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onUpButtonClick", pSender, event)
end

function CivFortressInfoView_ui:onCancelButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onCancelButtonClick", pSender, event)
end

function CivFortressInfoView_ui:onCancelRemoveButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onCancelRemoveButtonClick", pSender, event)
end

function CivFortressInfoView_ui:onTipBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onTipBtnClick", pSender, event)
end

function CivFortressInfoView_ui:initTableView()
	TableViewSmoker:createView(self, "m_listTableView", "game.CivFortress.CivFortressInfoCell", 1, 6, "CivFortreessInfoCell")
end

function CivFortressInfoView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return CivFortressInfoView_ui

