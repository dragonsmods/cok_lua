---
--- Created by pengzhou.
--- DateTime: 2018/5/23 下午3:50
---

local BarracksStatus = {
    wild_new        = 1,    -- 新营地
    wild_attack     = 2,    -- 已被攻打过
    occupy          = 3,    -- 被占领
}

local AddAttackCountItemId = 213739

CivBarracksWorldTile = class("CivBarracksWorldTile",function()
    return NewBaseTileLuaInfo:call("create")
end
)

function CivBarracksWorldTile.create( index )
    local ret = CivBarracksWorldTile.new()
    if ret:initView(index) == false then
        ret = nil
    end
    return ret
end


--- "@@ luaMap" = {
---     "campId"              = "30390001"
---     "flushTime"           = "1527753211904.0"
---     "lastCampIncomeTimes" = "4"
---     "resLevel"            = "2"
---     "startOccupyTime"     = "1527735910400.0"
---     "uid"                 = "14552000421"
--- }

function CivBarracksWorldTile:initView( index )
    Dprint("@@ CivBarracksWorldTile:initView".. tostring(index))
    self.cityIndex = index
    self:call("setCityIndex", index)

    if self:call("initTile", true) == false then
        return false
    end

    local cityInfo = self:call("getCityInfo")
    if nil == cityInfo then
        return false
    end
    self.m_cityInfo = cityInfo

    self.tileServerId = self.m_cityInfo:getProperty("tileServerId") -- 地块所属服务器ID
    self.inSelfServer = WorldController:call("isInSelfServer", self.tileServerId) -- 地块是否为当前服务器

    local luaMap = cityInfo:call("getLuaMap")
    --dump(luaMap,"@@ luaMap")
    self.m_luaMap = luaMap
    self:initNodeEvent()

    -- 刷新数据
    --CCSafeNotificationCenter:call("postNotification", "MSG_MAP_UPDATE_SINGLE", CCInteger:create(self.cityIndex))

    self:call("addToParent")
    self:refreshView()
    self:initText()
    return true
end

function CivBarracksWorldTile:initNodeEvent()
    local function onNodeEvent(event)
        Dprint("@@ onNodeEvent",event)
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(onNodeEvent)
end


function CivBarracksWorldTile:onEnter()
    Dprint("@@ CivBarracksWorldTile:onEnter ")
    registerScriptObserver(self, self.refreshDetail, "GET_WORLD_DETAIL_CMD_BACK")

    Dprint("@@ WorldDetailCommand send",self.m_cityInfo:getProperty("tileServerId"))
    local WorldDetailCommand = Drequire("game.command.WorldDetailCommand")
    local cmd = WorldDetailCommand:create(self.cityIndex, self.m_cityInfo:getProperty("tileServerId"))
    cmd:send()
end

function CivBarracksWorldTile:onExit()
    unregisterScriptObserver(self, "GET_WORLD_DETAIL_CMD_BACK")
end

function CivBarracksWorldTile:refreshDetail(ref)
    ref = dictToLuaTable(ref)
    if ref == nil then
        return
    end
    --dump(ref,"@@ CivBarracksWorldTile")
    if ref.lastAttackCampTimes then
        self.m_luaMap.lastAttackCampTimes = ref.lastAttackCampTimes
        self:call("setAllianceString", getLang("101702", tostring(ref.lastAttackCampTimes))) --101702=可获得营地收益次数:{0}
    end
end
function CivBarracksWorldTile:initText()
    self:call("setAllianceString", getLang("101702", tostring(self.m_luaMap.lastAttackCampTimes))) --101702=可获得营地收益次数:{0}
end

function CivBarracksWorldTile:refreshView()

    local status = BarracksStatus.wild_new

    local playerInfo = self.m_cityInfo:call("getPlayerInfo")
    --dump(playerInfo, "@@ refreshView")
    local type = playerInfo:getProperty("type")
    Dprint("@@ CivBarracksWorldTile:refreshView - ",type)

    WorldController:call("getInstance"):setProperty("m_alertStateFlag", 0)

    if tonumber(self.m_luaMap.startOccupyTime) <= 0 then
        status = BarracksStatus.wild_new
    elseif tonumber(self.m_luaMap.startOccupyTime) > 0 then
        if type == PlayerType.PlayerNone then
            status = BarracksStatus.wild_attack
        else
            status = BarracksStatus.occupy
        end
    end

    local function setCallBack(name, index, func, state)
        local function callback() func(self) end
        self:call("setButtonName", index, name)
        self:call("setButtonState", index, state)
        self:call("setButtonCallback", index, cc.CallFunc:create(callback))
    end


    if self.inSelfServer == false then
        self:call("setButtonCount", 1) -- 守军详情，占领收益， 攻击
        setCallBack(getLang("102271"), 1, self.Information, TileButtonState.ButtonInformation) -- 守军详情 102271=详情
    else
        if status == BarracksStatus.wild_new then
            self:call("setButtonCount", 3) -- 守军详情，占领收益， 攻击

            setCallBack(getLang("101517"), 1, self.Barracks_Reward, TileButtonState.ButtonBarracks_Reward) -- 占领收益 101517=占领奖励
            setCallBack(getLang("102271"), 2, self.Information, TileButtonState.ButtonInformation) -- 守军详情 102271=详情
            setCallBack(getLang("103600"), 3, self.March, TileButtonState.ButtonMarch) -- 攻击 103600=攻击

        elseif status == BarracksStatus.wild_attack then
            self:call("setButtonCount", 2) -- 守军详情，占领收益，占领

            setCallBack(getLang("101517"), 2, self.Barracks_Reward, TileButtonState.ButtonBarracks_Reward) -- 占领收益 101517=占领奖励
            --setCallBack(getLang("102271"), 2, self.Information, TileButtonState.ButtonInformation) -- 守军详情 102271=详情
            setCallBack(getLang("108720"), 3, self.March, TileButtonState.ButtonOccupy) -- 108720=占领

        elseif status == BarracksStatus.occupy then
            -- 自己占领
            if type == PlayerType.PlayerSelf then
                self:call("setButtonCount", 3)
                setCallBack(getLang("101517"), 1, self.Barracks_Reward, TileButtonState.ButtonBarracks_Reward) -- 占领收益 101517=占领奖励
                --setCallBack(getLang("108721"), 2, self.LordInfo, TileButtonState.ButtonordLord) -- 108721=领主详情
                setCallBack(getLang("108724"), 2, self.TroopView, TileButtonState.ButtonViewTroop) -- 108724=部队详情
                setCallBack(getLang("108572"), 3, self.GoHome, TileButtonState.ButtonGoHome) -- 108572=返回

            elseif type == PlayerType.PlayerAlliance then
                self:call("setButtonCount", 2)
                setCallBack(getLang("101517"), 2, self.Barracks_Reward, TileButtonState.ButtonBarracks_Reward) -- 占领收益 101517=占领奖励
                setCallBack(getLang("108721"), 3, self.LordInfo, TileButtonState.ButtonordLord) -- 108721=领主详情

            elseif type == PlayerType.PlayerOther then
                -- 敌方占领 领主详情，侦查，占领收益，攻击
                self:call("setButtonCount", 4)
                setCallBack(getLang("108721"), 2, self.LordInfo, TileButtonState.ButtonordLord) -- 108721=领主详情
                setCallBack(getLang("103600"), 3, self.MarchOtherPlayer, TileButtonState.ButtonMarch) -- 103600=攻击
                setCallBack(getLang("101517"), 4, self.Barracks_Reward, TileButtonState.ButtonBarracks_Reward) -- 101517=占领奖励
                setCallBack(getLang("108722"), 5, self.Scout, TileButtonState.ButtonScout) -- 108722=侦查
            end
        end
    end
    
end

-- 部队详情
function CivBarracksWorldTile:TroopView()
    WorldController:call("openViewTroopInfo",self.cityIndex)
    self:closeTile()
end

---- 占领
--function CivBarracksWorldTile:clickOccupy()
--    WorldController:call("openMarchDeploy", self.cityIndex, 0)
--    self:closeTile()
--end


function CivBarracksWorldTile:Barracks_Reward( )

    local playerInfo = self.m_cityInfo:call("getPlayerInfo")
    local type = playerInfo:getProperty("type")

    local view = Drequire("game.CivFortress.Barrack.CampMainView"):create(self.m_luaMap, type ~= PlayerType.PlayerNone)
    PopupViewController:addPopupView(view)
    self:closeTile()
end

function CivBarracksWorldTile:Information( )
    local view = Drequire("game.CivFortress.Barrack.CampDetailView"):create(self.m_luaMap)
    PopupViewController:addPopupView(view)
    self:closeTile()
end

function CivBarracksWorldTile:LordInfo()

    local dict = CCDictionary:create()
    dict:setObject(CCString:create("GeneralsPopupView"), "name")
    dict:setObject(CCString:create(self.m_luaMap.uid), "uid")
    LuaController:call("openPopViewInLua", dict)
    self:closeTile()
end

-- 侦查
function CivBarracksWorldTile:Scout()
    local current = WorldController:call("getCurrentMarchCount")
    local max = WorldController:call("getMaxMarchCount")

    if current >= max then
        WorldController:call("showMarchAlert", max)
    end

    local function doScout(  )
        WorldController:call("openScoutView", self.cityIndex)
    end

    local warningTips = ToolController:call("getBeforeBattleWarning")
    if warningTips ~= "" then
        YesNoDialog:call("show", warningTips, cc.CallFunc:create(doScout))
    else
        doScout()
    end
    self:closeTile()
end

function CivBarracksWorldTile:getMarchId(  )
    local marchUuid = ""
    local function func( marchInfo )
        if marchInfo:getProperty("stateType") == MarchStateType.StateMarch
                and marchInfo:getProperty("endPointIndex") == self.cityIndex
        then
            marchUuid = marchInfo:getProperty("uuid")
            return false
        end

        return true
    end
    local handler = self:registerHandler(func)
    WorldController:call("dumpMarchInfosForLua", handler)
    return marchUuid
end

function CivBarracksWorldTile:openItemGetView()
    local ItemGetMethodView = Drequire("game.CommonPopup.ItemGetMethodView")
    local view = ItemGetMethodView:create(tostring(AddAttackCountItemId))
    if view then
        PopupViewController:call("addPopupView", view)
    end
end

-- 部署部队占领
function CivBarracksWorldTile:openMarchDeploy4Occupy()
    local uuid = self:getMarchId()
    if uuid ~= "" then
        WorldController:call("getInstance"):setProperty("m_alertStateFlag", 1)
    else
        WorldController:call("getInstance"):setProperty("m_alertStateFlag", 0)
    end

    WorldController:call("openMarchDeploy", self.cityIndex, 0)
end

-- 部署部队攻击
function CivBarracksWorldTile:openMarchDeploy4Attack()
    WorldController:call("getInstance"):setProperty("m_alertStateFlag", 2)
    WorldController:call("openMarchDeploy", self.cityIndex, 0)
end

-- 攻击野怪,占领
function CivBarracksWorldTile:March()
    if atoi(self.m_luaMap.lastAttackCampTimes) < 1 then
        local function Confirm() self:openItemGetView() end
        local function Cancel() self:openMarchDeploy4Occupy() end
        YesNoDialog:call("showYesNoFun", getLang("101532"), cc.CallFunc:create(Confirm), getLang("confirm"), cc.CallFunc:create(Cancel), getLang("cancel_btn_label"))
    else
        self:openMarchDeploy4Occupy()
    end

    self:closeTile()
end

-- 攻击占领玩家
function CivBarracksWorldTile:MarchOtherPlayer( )
    if atoi(self.m_luaMap.lastAttackCampTimes) < 1 then
        local function Confirm() self:openItemGetView() end
        local function Cancel() self:openMarchDeploy4Attack() end
        YesNoDialog:call("showYesNoFun", getLang("101532"), cc.CallFunc:create(Confirm), getLang("confirm"), cc.CallFunc:create(Cancel), getLang("cancel_btn_label"))
    else
        self:openMarchDeploy4Attack()
    end

    self:closeTile()
end

function CivBarracksWorldTile:GoHome()
    local uuid = WorldController:call("getMyMarchUuidAtIndex", self.cityIndex)

    local dict = CCDictionary:create()
    dict:setObject(CCString:create(uuid), "marchId")
    local world = WorldMapView:call("instance")
    if nil == world then
        self:closeTile()
        return
    end
    world:call("afterMarchCancel", dict)
    self:closeTile()
end



function CivBarracksWorldTile:closeTile()
    self = tolua.cast(self, "NewBaseTileLuaInfo")
    self:call("closeThis")
end
