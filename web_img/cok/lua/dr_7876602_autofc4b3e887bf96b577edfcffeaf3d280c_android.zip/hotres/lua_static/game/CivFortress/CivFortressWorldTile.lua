CivFortressWorldTile = class("CivFortressWorldTile",function()
        return NewBaseTileLuaInfo:call("create")
    end
)

function CivFortressWorldTile.create( index )
	local ret = CivFortressWorldTile.new()
	if ret:initView(index) == false then
		ret = nil
	end
	return ret
end

function CivFortressWorldTile:initView( index )
	-- dump("CivFortressWorldTile:initView"..index)
    self.cityIndex = index
    self:call("setCityIndex", index)

    if self:call("initTile", true) == false then
        return false
    end

    local cityInfo = self:call("getCityInfo")
	if nil == cityInfo then
		return false
	end
	self.tileServerId = cityInfo:getProperty("tileServerId") -- 地块所属服务器ID
    self.inSelfServer = WorldController:call("isInSelfServer", self.tileServerId) -- 地块是否为当前服务器

	local luaMap = cityInfo:call("getLuaMap")
	if nil == luaMap then
		return false
	end
	luaMap.removeEndTime = (tonumber(luaMap.removeEndTime) or 0)/1000
	if luaMap.removeEndTime > 0 then
		luaMap.status = 3
	else
		luaMap.status = tonumber(luaMap.status)
	end
	self.m_luaMap = luaMap
	-- dump(self.m_luaMap, "CivFortressWorldTile:initView luaMap is:")
    -- 刷新数据
    CCSafeNotificationCenter:call("postNotification", "MSG_MAP_UPDATE_SINGLE", CCInteger:create(self.cityIndex))

    local function onNodeEvent(event)
        MyPrint("CivFortressWorldTile:onNodeEvent event is "..tostring(event))
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end

    self:registerScriptHandler(onNodeEvent)

    self:call("addToParent")
    self.m_allianceId = cityInfo:getProperty("allianceId")
    self:refreshView()
	return true
end

function CivFortressWorldTile:onEnter(  )
	MyPrint("CivFortressWorldTile:onEnter")
    local function dataBack(data)
    	self.m_luaMap = data
    end
    CivFortressController:getOtherCivFortressInfo(self.m_luaMap.uid, self.tileServerId, dataBack)
end

function CivFortressWorldTile:onExit(  )
end

function CivFortressWorldTile:refreshView(  )
	local luaMap = self.m_luaMap

    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
    local myUid = playerInfo:getProperty("uid")
    -- dump(luaMap, " refreshView luaMap is: ")
	-- "dataMap is: " = {
	    -- "beRobNum"       = "0"
	    -- "buildTime"      = "1503903350784.0"
	    -- "def"            = "1000"
	    -- "lastOutputTime" = "1503999950848.0"
	    -- "lastSettleTime" = "1503979896832.0"
	    -- "level"          = "2"
	    -- "output"         = "150"
	    -- "pointId"        = "378760"
	    -- "resourceNum"    = "5100"
	    -- "status"         = "2"
	    -- "uid"            = "44194353001266"
	-- }

	local function setCallBack(name, index, func, state)
        local function callback() func(self) end
		self:call("setButtonName", index, name)
        self:call("setButtonState", index, state)
        self:call("setButtonCallback", index, cc.CallFunc:create(callback))
	end

	if self.inSelfServer == false then
        self:call("setButtonCount", 1)
		setCallBack(getLang("115331"), 1, self.clickInformation, TileButtonState.ButtonEnterCity)
    else
    	if myUid == luaMap.uid then
	    	self.m_beSelf = true
	    	self.m_beMyAli = true

	    	local status = tonumber(luaMap.status)
	    	-- 玩家自己
	    	if status == 1 then
	    		-- 建造中
	    		self:call("setButtonCount", 3)
		    	setCallBack(getLang("115331"), 2, self.clickInformation, TileButtonState.ButtonEnterCity)

		    	setCallBack(getLang("104903"), 3, self.clickItemSpeed, TileButtonState.ButttonTreasureMapSPD)

		    	setCallBack(getLang("102121"), 1, self.clickCivFortressRemove, TileButtonState.ButtonMass)

			    self.m_buildTime = nil
			    local xmlData = CivFortressController:getCivFortressXmlData()
			    local fortressData = xmlData[tonumber(luaMap.level)]
			    if fortressData == nil then
			        dump(" not fortressData data")
			        return false
			    end
			    self.m_needTime = tonumber(fortressData.time)
			    self.m_buildTime = (tonumber(luaMap.buildTime) or 0)/1000
			    -- self.m_buildTime = (tonumber(luaMap.buildTime) or 0)/1000 + tonumber(fortressData.time)
		    elseif status == 3 then
		    	-- 拆除中
		    	self:call("setButtonCount", 2)
		    	setCallBack(getLang("115331"), 2, self.clickInformation, TileButtonState.ButtonEnterCity)
		    	setCallBack(getLang("310101"), 3, self.clickCancelRemove, TileButtonState.ButtonRepair)		-- 310101=取消拆除

	    	else

		    	if CCCommonUtilsForLua:isFunOpenByKey("civilization_fortress_v4_on") then
	                -- btnIcons.push_back("cityskin_status.png.png");
	                -- m_name4->setString(_lang("101482"));
	                self:call("setButtonCount", 4)
	                setCallBack(getLang("104953"), 4, self.clickStatus, TileButtonState.ButtonAddEffect)
			    	setCallBack(getLang("102121"), 5, self.clickCivFortressRemove, TileButtonState.ButtonMass)
	            else
	    			self:call("setButtonCount", 3)
			    	setCallBack(getLang("102121"), 1, self.clickCivFortressRemove, TileButtonState.ButtonMass)
	            end
		    	setCallBack(getLang("115331"), 2, self.clickInformation, TileButtonState.ButtonEnterCity)
		    	if self:checkHasMyTroop() then
		    		-- 返回
		    		setCallBack(getLang("169780"), 3, self.clickGoHome, TileButtonState.ButtonGoHome)
		    	else
		    		setCallBack(getLang("115333"), 3, self.clickZhuShou, TileButtonState.ButtonStation)
		    	end

	    	end
	    else
	    	self.m_beSelf = false
	    	local myAllianceId = playerInfo:call("getAllianceId")
	    	if myAllianceId ~= "" and self.m_allianceId == myAllianceId then
	    		self.m_beMyAli = true
				self:call("setButtonCount", 2)
		    	if self:checkHasMyTroop() then
		    		-- 返回
		    		setCallBack(getLang("169780"), 3, self.clickGoHome, TileButtonState.ButtonGoHome)
		    	else
		    		setCallBack(getLang("115333"), 3, self.clickZhuShou, TileButtonState.ButtonStation)
		    	end
		    	setCallBack(getLang("115331"), 2, self.clickInformation, TileButtonState.ButtonEnterCity)
		    else
		    	self.m_beMyAli = false
		    	if status == 1 then
		    		self:call("setButtonCount", 1)
			    	setCallBack(getLang("115331"), 1, self.clickInformation, TileButtonState.ButtonEnterCity)
		    	else
			    	self:call("setButtonCount", 4)
			    	setCallBack(getLang("115331"), 2, self.clickInformation, TileButtonState.ButtonEnterCity)
			    	setCallBack(getLang("108607"), 3, self.clickAttack, TileButtonState.ButtonMarch)
			    	setCallBack(getLang("108722"), 4, self.clickScout, TileButtonState.ButtonScout)
			    	setCallBack(getLang("108726"), 5, self.clickRally, TileButtonState.ButtonRally)
			    end
		    end
	    end
    end
    
end

function CivFortressWorldTile:checkHasMyTroop()
    local uuid1 = WorldController:call("getMyMarchUuidToIndex", self.cityIndex)
    local uuid2 = WorldController:call("getMyMarchUuidAtIndex", self.cityIndex)
    if uuid1 ~= "" or uuid2 ~= "" then
        return true
    end
    return false
end

-- 详情
function CivFortressWorldTile:clickInformation(  )
	-- dump("CivFortressWorldTile:clickInformation")
	local view = Drequire("game.CivFortress.CivFortressInfoView"):create(self.m_luaMap, self.tileServerId, self.cityIndex)
	PopupViewController:addPopupInView(view)
    self:closeTile()
end

-- 加速
function CivFortressWorldTile:clickItemSpeed(  )
	-- 暂未开放
	-- CCCommonUtilsForLua:setButtonTitle(self.ui.m_enterButton, getLang("146337")) -- 未开放
	-- dump("CivFortressWorldTile:clickItemSpeed")
	if self.m_buildTime then
		local offTime = self.m_buildTime
		PropSpeedupView:call("show", 7, 0, 0, 4, -1, self.m_needTime, offTime)
		self:closeTile()
	end
end

-- 拆除堡垒
function CivFortressWorldTile:clickCivFortressRemove(  )
	-- dump("CivFortressWorldTile:clickCivFortressRemove")
	local function remove()
		CivFortressController:removeCivFortress(self.cityIndex)
	    self:closeTile()
	end
	local warningTips = getLang("310040")
    YesNoDialog:call("show", warningTips, cc.CallFunc:create(remove))
end

function CivFortressWorldTile:clickCancelRemove()
	if self.m_luaMap.status == 3 then
		local offTime = self.m_luaMap.removeEndTime - getTimeStamp()
		if offTime > 0 then
            CivFortressController:cancelRemoveCivFortress()
		end
	end
	self:closeTile()
end

function CivFortressWorldTile:stateCheck(checkValue)
	local status = tonumber(self.m_luaMap.status)
	if checkValue then
		if status == checkValue then
			if status == 1 then
				LuaController:flyHint("", "", getLang("310008"))
			else
				LuaController:flyHint("", "", getLang("310099"))
			end
			return false
		end
		return true
	elseif status == 1 then
		LuaController:flyHint("", "", getLang("310008"))
		return false
	elseif status == 3 then
		LuaController:flyHint("", "", getLang("310099"))
		return false
	end

	return true
end

-- 驻守
function CivFortressWorldTile:clickZhuShou(  )
	-- dump("CivFortressWorldTile:clickZhuShou")
	if self:stateCheck() == false then
		return
	end
    -- CIVILIZATION_DEF 驻守堡垒

    local marchType = MarchMethodType.CIVILIZATION_AID
    local marchNum = 0
    if self.m_beSelf then
        marchType = MarchMethodType.CIVILIZATION_DEF
    else
    	-- 盟友援助部分计算
    	local maxNum = tonumber(self.m_luaMap.maxAidSoldierCount) or 0
    	if maxNum > 0 then
	    	local troopNum = 0
	        local myTroopNum = 0
	        local otherTroopNum = 0
	        for i, troops in pairs(self.m_luaMap.army or {}) do
	            if self.m_luaMap.uid ~= troops.uid then
	                otherTroopNum = otherTroopNum + tonumber(troops.totalTroops)
	                troopNum = troopNum + 1
	            end
	        end

	        local xmlData = CivFortressController:getCivFortressXmlData()
	        local curLevelData = xmlData[tonumber(self.m_luaMap.level)]
	        if curLevelData and curLevelData.garrison_quantity then
	            if troopNum >= tonumber(curLevelData.garrison_quantity) then
	            	LuaController:flyHint("", "", getLang("310050"))
	            	return
	            end
	        end

	        if otherTroopNum >= maxNum then
	        	LuaController:flyHint("", "", getLang("115598"))
	        	return
	        end
	        marchNum = maxNum - otherTroopNum
	    end
    end
    WorldController:call("openMarchDeploy", self.cityIndex, 1, marchNum, marchType)
    self:closeTile()
end

-- 返回
function CivFortressWorldTile:clickGoHome(  )
	-- dump("CivFortressWorldTile:clickGoHome")

 	local worldmap = WorldMapView:call("instance")
    if worldmap == nil then
        return nil
    end

    local marchUuid = WorldController:call("isSelfMarchAtCityIndex", self.cityIndex)
    if marchUuid ~= "" then
    	-- 已驻防
        local dict = CCDictionary:create()
        dict:setObject(CCString:create(marchUuid), "marchId")
        worldmap:call("afterMarchCancel", dict)
    	self:closeTile()
    	return
    else
    	-- 未驻防
    	local marchUuid = WorldController:call("getMyMarchUuidToIndex", self.cityIndex)
    	if marchUuid ~= "" then
	        local dict = CCDictionary:create()
	        dict:setObject(CCString:create(marchUuid), "marchId")

	            local view = require("game.CommonPopup.UseToolView"):create(USE_TOOL_MARCH_CANCEL, dict, "104039")
	            PopupViewController:addPopupInView(view)
	        self:closeTile()
	    end
    end

    -- 
end


-- 攻击
function CivFortressWorldTile:clickAttack()
	dump("CivFortressWorldTile:clickZhuShou")
	if self:stateCheck(1) == false then
		return
	end
	-- 暂未开放
	-- CCCommonUtilsForLua:setButtonTitle(self.ui.m_enterButton, getLang("146337")) -- 未开放
	local function march()
		local marchType = MarchMethodType.CIVILIZATION_ATTACK
        WorldController:call("openMarchDeploy", self.cityIndex, 1, 0, marchType)
    end
    local warningTips = ToolController:call("getBeforeBattleWarning")
    if warningTips ~= "" then
        YesNoDialog:call("show", warningTips, cc.CallFunc:create(march))
    else
        march()
    end
    self:closeTile()
end
-- 侦查
function CivFortressWorldTile:clickScout()
	if self:stateCheck(1) == false then
		return
	end
	local function scout()
        WorldController:call("openScoutView", self.cityIndex)
    end
    local warningTips = ToolController:call("getBeforeBattleWarning")
    if warningTips ~= "" then
        YesNoDialog:call("show", warningTips, cc.CallFunc:create(scout))
    else
        scout()
    end
    self:closeTile()
end

-- 集结
function CivFortressWorldTile:clickRally()
	if self:stateCheck(1) == false then
		return
	end
	local playerInfo = GlobalData:call("getPlayerInfo")
	if playerInfo == nil then
        MyPrint("NeutralTowerTilePopup:clickAllianceRally playerInfo is nil")
        return
    end

    if not playerInfo:call("isInAlliance") then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("115218"))
        self:closeTile()
        return
    end

    self.cityInfo = WorldController:call("getCityInfoByIndex", self.cityIndex)
    if self.cityInfo == nil then
        return
    end

    local function rally()
        AllianceManager:call("openAllianceMassView",self.cityIndex)
        self:closeTile()
    end
    local warningTips = ToolController:call("getBeforeBattleWarning")
    if warningTips ~= "" then
        YesNoDialog:call("show", warningTips, cc.CallFunc:create(rally))
    else
        rally()
    end
end

function CivFortressWorldTile:closeTile()
    self = tolua.cast(self, "NewBaseTileLuaInfo")
    self:call("closeThis")
end

function CivFortressWorldTile:clickStatus()
	local view = Drequire("game.CivFortress.CivFortressStatusView"):create()
	PopupViewController:addPopupInView(view)
end