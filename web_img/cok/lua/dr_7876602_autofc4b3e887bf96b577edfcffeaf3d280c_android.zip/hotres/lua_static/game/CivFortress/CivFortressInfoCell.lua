-------------------------------------------- CivFortressInfoCell Start --------------------------------------------
local CivFortressInfoCell = class("CivFortressInfoCell", function()
    return cc.Layer:create()
end)
local LibaoCommonFunc = Drequire("game.LiBao.LibaoCommonFunc")

function CivFortressInfoCell:create(idx)
    local ret = CivFortressInfoCell.new()
    Drequire("game.CivFortress.CivFortressInfoCell_ui"):create(ret)
    registerTouchHandler(ret)
    ret:setTouchEnabled(true)
    ret:setSwallowsTouches(true)
    return ret
end

function CivFortressInfoCell:refreshCell(info , idx)
    self.m_info = info
    dump(self.m_info, "CivFortressInfoCell:refreshCell info is: ")

    self.ui.m_bgNode:setPositionY(0)
    if info.type == 1 then
        self.ui.m_baseNode:setVisible(false)
        self.ui.m_tipsNode:setVisible(true)
        self:setContentSize(cc.size(640, 130))

        local function twoLblNear(lbl1, lbl2)
            local posX = 20 + lbl1:getContentSize().width + 6
            lbl2:setPositionX(posX)
        end

        local troopNum = 0
        local myTroopNum = 0
        local otherTroopNum = 0
        local myUid = GlobalDataCtr.getUuid()
        for i, troops in pairs(info.data.army or {}) do
            if info.data.uid == troops.uid then
                myTroopNum = tonumber(troops.totalTroops)
            else
                otherTroopNum = otherTroopNum + tonumber(troops.totalTroops)
                troopNum = troopNum + 1
            end
        end

        self.ui.m_troopName1:setString(getLang("310016"))       -- 310016=堡垒内驻守人数:
        local xmlData = CivFortressController:getCivFortressXmlData()
        local curLevelData = xmlData[tonumber(info.data.level)]
        if curLevelData == nil then
            self.ui.m_troopNum1:setString(troopNum)
        else
            self.ui.m_troopNum1:setString(troopNum.."/"..curLevelData.garrison_quantity)
        end

        local maxAidSoldierCount = tonumber(info.data.maxAidSoldierCount) or 0
        local maxMarchSoldierCount = tonumber(info.data.maxMarchSoldierCount) or 0
        self.ui.m_troopName2:setString(getLang("310034"))       -- 310034=驻守士兵数量:
        self.ui.m_troopNum2:setString(myTroopNum.."/"..tostring(maxMarchSoldierCount))

        self.ui.m_troopName3:setString(getLang("310035"))       -- 310035=堡援助士兵数量:
        self.ui.m_troopNum3:setString(otherTroopNum.."/"..tostring(maxAidSoldierCount))

        self.ui.m_troopName4:setString(getLang("310036"))       -- 310036=堡垒驻守士兵总数:
        self.ui.m_troopNum4:setString((myTroopNum + otherTroopNum).."/"..(maxAidSoldierCount+ maxMarchSoldierCount))

        for i = 1, 4 do
            twoLblNear(self.ui["m_troopName"..i], self.ui["m_troopNum"..i])
        end
    else
        self.ui.m_baseNode:setVisible(true)
        self.ui.m_tipsNode:setVisible(false)
        local m_data = info.data
        local head = m_data.pic..".png"
        if head == "" or head == "" then
        	head = "g044.png"
        end

        local uid = m_data.uid
        local picVer = tonumber(m_data.picVer)
        local headSpr = CCLoadSprite:call("createSprite", head, CCLoadSpriteType_HEAD_ICON)
        self.ui.m_headNode:removeAllChildren()
        CCCommonUtilsForLua:setSpriteMaxSize(headSpr, 95)
        self.ui.m_headNode:addChild(headSpr)
        if (CCCommonUtilsForLua:call("isUseCustomPic", picVer)) then
            self.m_headImgNode = HFHeadImgNode:call("create")
            local picUrl = CCCommonUtilsForLua:call("getCustomPicUrl", uid, picVer)
            self.m_headImgNode:call("initHeadImgUrl2", self.ui.m_headNode, picUrl, 1.0, 78, true)
        end

        self.ui.m_nameLabel:setString(m_data.name)
        self.ui.m_soldierLabel:setString(getLang("108557")..":"..m_data.totalTroops)

        local arrivalTime = tonumber(m_data.arrivalTime)
        if arrivalTime < getWorldTime() then
            self.hasBehero = true
            self.ui.m_statusTxt:setString(getLang("115351"))
        else
            self.hasBehero = false
            self.ui.m_statusTxt:setString(getLang("115346"))
        end
        self.hasInit = true

        self.ui.m_infoList:removeAllChildren()
        self.ui.m_baseNode:setPositionY(0)
        if info.isOpen == true then
            self.ui.m_arrow:setRotation(270)
            -- 数据全展开
            self.ui.m_renderBg:setVisible(true)
            self.ui.m_infoList:setVisible(true)
            self:addSoldierList()
        else
            self.ui.m_arrow:setRotation(180)
            self.ui.m_renderBg:setVisible(false)
            self.ui.m_infoList:setVisible(false)
            self:setContentSize(cc.size(640, 130))
        end
    end
end

function CivFortressInfoCell:addSoldierList()
    local cell = Drequire("game.CivFortress.YuanJunSoldierCell_lua")
    local i = 1
    local j = 1

    local function addNode(soldierNode)
        self.ui.m_infoList:addChild(soldierNode)
        soldierNode:setPosition(cc.p((i-1)*320, -100 * j))
        if i == 1 then
            i = 2
        else
            i = 1
            j = j + 1
        end
    end

    local info = self.m_info.data
    if info.petDragon then
        local view = cell:create(1, info.petDragon)
        addNode(view) 
    end

    if info.newGeneral then
        local view = cell:create(2, info.newGeneral)
        addNode(view)
    end

    for i, troop in pairs(info.soldiers) do
        local view = cell:create(3, troop, tonumber(info.raceType))
        addNode(view)
    end

    if i == 1 then
        j = j - 1
    end
    dump(j, "j is: ")
    self.ui.m_baseNode:setPositionY(j*100)
    self.ui.m_bgNode:setPositionY(j*100)
    self.ui.m_renderBg:setContentSize(cc.size(620, j * 100))    
    self:setContentSize(cc.size(640, 130+j*100))
end

function CivFortressInfoCell:onEnter()
    self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:update(dt) end, 1, false)
end

function CivFortressInfoCell:onExit()
    self:getScheduler():unscheduleScriptEntry(self.m_entryId)
end

function CivFortressInfoCell:update(dt)
    if self.m_info.type == 2 and self.hasBehero == false and self.hasInit == true then
        local arrivalTime = tonumber(self.m_info.data.arrivalTime)
        if arrivalTime < getWorldTime() then
            -- 等待刷新
            self.hasInit = false
        end
    end
end

function CivFortressInfoCell:onTouchBegan(x, y)
    self.touchType = nil
    if self.m_info.type == 2 and touchInside(self.ui.m_arrow, x, y) then
        self.touch_x = x
        self.touch_y = y
        self.touchType = 1
        return true
    end

    return false
end

function CivFortressInfoCell:onTouchMoved(x, y)
    if self.touchType == 1 and cc.pGetDistance(cc.p(self.touch_x, self.touch_y), cc.p(x,y)) > 20 then
        self.touchType = nil
    end
end

function CivFortressInfoCell:onTouchEnded(x, y)
    if self.touchType == 1 then
        self.m_info.isOpen = not self.m_info.isOpen
        self.m_info.touchOpen()
    end
end

-------------------------------------------- CivFortressInfoCell End --------------------------------------------

return CivFortressInfoCell