---
--- Created by pengzhou.
--- DateTime: 2018/5/24 下午4:19
---

local CampIconCell = class("CampIconCell", function()
    return cc.Layer:create()
end)

function CampIconCell:create(idx)
    local view = CampIconCell.new()
    Drequire("game.CivFortress.Barrack.CampIconCell_ui"):create(view, 0)
    return view
end

---     1 = {
---         "type"  = "7"
---         "value" = {
---             "id"  = "200065"
---             "num" = "1000"
---         }
---     }
function CampIconCell:refreshCell(info , idx)
    CCCommonUtilsForLua:createGoodsIcon(info.value.id, self.ui.m_iconNode, CCSizeMake(90, 90))
    self.ui.m_numLabel:setString(CC_CMDITOA(info.value.num))
end

function CampIconCell:setData(info)
    CCCommonUtilsForLua:createGoodsIcon(info.value.id, self.ui.m_iconNode, CCSizeMake(90, 90))
    self.ui.m_numLabel:setString(CC_CMDITOA(info.value.num))
end

return CampIconCell