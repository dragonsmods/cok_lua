----------------------------
-- Author: Elex
-- Date: 2018-05-28 Monday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CivFortressMoreView_ui = class("CivFortressMoreView_ui")

--#ui propertys


--#function
function CivFortressMoreView_ui:create(owner, viewType)
	local ret = CivFortressMoreView_ui.new()
	CustomUtility:LoadUi("CivFortressMoreView.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CivFortressMoreView_ui:initLang()
end

function CivFortressMoreView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CivFortressMoreView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CivFortressMoreView_ui:onTipBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onTipBtnClick", pSender, event)
end

function CivFortressMoreView_ui:onPlaceButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onPlaceButtonClick", pSender, event)
end

function CivFortressMoreView_ui:onMoreButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onMoreButtonClick", pSender, event)
end

function CivFortressMoreView_ui:onRemoveButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onRemoveButtonClick", pSender, event)
end

return CivFortressMoreView_ui

