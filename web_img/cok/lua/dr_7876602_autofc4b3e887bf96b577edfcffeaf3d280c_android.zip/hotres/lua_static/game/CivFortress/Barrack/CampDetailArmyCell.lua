---
--- Created by pengzhou.
--- DateTime: 2018/5/24 下午4:46
---

local CampDetailArmyCell = class("CampDetailArmyCell", function()
    return cc.Layer:create()
end)

function CampDetailArmyCell:create()
    local view = CampDetailArmyCell.new()
    Drequire("game.CivFortress.Barrack.CampDetailArmyCell_ui"):create(view, 0)
    return view
end

function CampDetailArmyCell:setData(army)
    self.m_data =  string.split(army,";")
    self.id = self.m_data[1]
    self.num = self.m_data[2]
    self.star = tonumber(self.m_data[1]) % 100 + 1
    local tittle  = CCCommonUtilsForLua:getPropByIdGroup("arms",self.id, "name")
    local picName = ArmyController:call("getArmyIconById", self.id)
    local headIcon = CCLoadSprite:call("createSprite", picName)
    --Dprint("@@",picName)
    CCCommonUtilsForLua:setSpriteMaxSize(headIcon, 85)
    headIcon:setAnchorPoint(cc.p(0.5, 0.5))
    self.ui.m_iconNode:removeAllChildren()
    self.ui.m_iconNode:addChild(headIcon)

    self.ui.m_aNameLabel:setString(getLang(tittle))
    self.ui.m_aNumLabel:setString(self.num)

    if tonumber(self.star) == 0 then
        self.star = 1
    end
    --
    local pic1 = CCCommonUtilsForLua:call("getRomanSprite", tonumber(self.star))
    self.ui.m_levelNode:addChild(pic1)


    -- 星级
    if self.m_data[3] and tonumber(self.m_data[3]) >= 1 then
        local starBg = CCLoadSprite:createSprite("soldier_star_lv.png")
        if starBg then
            local iconMaxSize = 30
            CCCommonUtilsForLua:call("setSpriteMaxSize", starBg, iconMaxSize, true)
            self.ui.m_pStar:addChild(starBg)
        end
        local starLabel = cc.LabelBMFont:create(self.m_data[3], "pve_fnt_boss.fnt")
        starLabel:setScale(0.3)
        self.ui.m_pStar:addChild(starLabel)
    end
end

function CampDetailArmyCell:getNum()
    return self.num
end

return CampDetailArmyCell