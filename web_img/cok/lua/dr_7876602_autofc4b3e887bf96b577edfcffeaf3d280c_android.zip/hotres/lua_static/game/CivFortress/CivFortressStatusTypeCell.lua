local CivFortressStatusTypeCell = class("CivFortressStatusTypeCell", function()
    return cc.Layer:create()
end)

CivFortressStatusTypeCellOwner = CivFortressStatusTypeCellOwner or {}
ccb["CivFortressStatusTypeCellOwner"] = CivFortressStatusTypeCellOwner

function CivFortressStatusTypeCell:create(idx)
    local ret = CivFortressStatusTypeCell.new()
    Drequire("game.CivFortress.CivFortressStatusTypeCell_ui"):create(ret)

    self.animationManager = ccb["CivFortressStatusTypeCellOwner"]["mAnimationManager"]
    -- dump(CivFortressStatusTypeCellOwner, "CivFortressStatusTypeCellOwner is: ")
    return ret
end

function CivFortressStatusTypeCell:refreshCell(info , idx)
    -- dump(info, "CivFortressStatusTypeCell:refreshCell info is:")
    self.m_info = info

    self.m_statusId = info.status
	self.m_type = info.type
	self.ui.m_iconNode:removeAllChildren()

	local typeNameS = getLang(info.name)
	local descS = getLang(info.description)
	self.ui.m_nameTxt:setString(typeNameS)
	self.ui.m_descTxt:setString(descS)
	-- 效果值label
	self.ui.m_valueTxt:setPositionX(self.ui.m_nameTxt:getContentSize().width + self.ui.m_nameTxt:getPositionX() + 5)

	local iconPath = info.icon .. ".png"
	local color = tonumber(info.color) or 0
	local colorBgPath = CCCommonUtilsForLua:call("getToolBgByColor", color)
	local iconBg = CCLoadSprite:call("createSprite", colorBgPath)
	local iconSpr = CCLoadSprite:call("createSprite", iconPath, CCLoadSpriteType_GOODS)

	CCCommonUtilsForLua:setSpriteMaxSize(iconBg, 92, true)
	CCCommonUtilsForLua:setSpriteMaxSize(iconSpr, 92, true)

	self.ui.m_iconNode:addChild(iconBg)
	self.ui.m_iconNode:addChild(iconSpr)

	if (self.ui.m_barNode:getChildByTag(100)) then self.ui.m_barNode:removeChildByTag(100) end

	self.animationManager:runAnimationsForSequenceNamed("loop")

	--加进度条头上的光效
	self.m_headParticleNode = cc.Node:create()
	for i = 1, 3 do
		local path = string.format("Loading_%d", i)
		local particle = ParticleController:call("createParticle", path)
		self.m_headParticleNode:addChild(particle)
	end

	self.ui.m_barNode:addChild(self.m_headParticleNode)
	self.m_headParticleNode:setTag(100)
	self.ui.m_valueTxt:setVisible(true)

	-- self:freshData()

	if self.entry then
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
		self.entry = nil
	end


	self.ui.m_mainNode:setPositionY(0)
	self.ui.m_barNode:setPositionY(40.2)
end

function CivFortressStatusTypeCell:onEnter()
	self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(function(dt) self:freshData(dt) end, 1, false)
	registerScriptObserver(self, self.resetTime, MSG_ITME_STATUS_TIME_CHANGE)
	self:freshData()
end

function CivFortressStatusTypeCell:onExit()
	CCSafeNotificationCenter:unregisterScriptObserver(self, MSG_ITME_STATUS_TIME_CHANGE)
	if self.entry then
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
		self.entry = nil
	end
end

function CivFortressStatusTypeCell:resetTime(pObj)
	local integer = tolua.cast(pObj, "CCInteger")
	-- dump("CivFortressStatusTypeCell:resetTime 11111111")
	-- if integer then
	-- 	local value = integer:getValue()
	-- 	dump(value, "integer:getValue() is:")
	-- end
	if (integer and integer:getValue() == self.m_type) then
		self:freshData()
	end
end

function CivFortressStatusTypeCell:freshData()
	self.m_time = 0

	local max = 0
	local items = ToolController:call("getInstance"):getProperty("m_statusItems")
	if (items[self.m_type]) then
		local item = items[self.m_type]
		local startTime = item:valueForKey("startTime"):doubleValue()
		local endTime = item:valueForKey("endTime"):doubleValue()
		local time = WorldController:call("getTime")
		self.m_time = (endTime - time) / 1000
		max = (endTime - startTime) / 1000
	end

		self.touchEnable = true
	if (self.m_time > 0) then
		self.ui.m_barNode:setVisible(true)
		max = math.max(max, 1)
		local len = self.m_time / max
		if (len > 1) then len = 1 end
		self.ui.m_progress:setScaleX(len)
		self.ui.m_timeTxt:setString(getLang("105805", format_time(self.m_time)))
		self.ui.m_receiveGlow:setVisible(true)

		local px = 0 --进度条头上的光效位置
		px = self.ui.m_progress:getPositionX() + (self.ui.m_progress:getContentSize().width * len)
		self.m_headParticleNode:setPositionX(px)
		if self.m_info.status == "510490" then
			local group = CCCommonUtilsForLua:call("getPropByIdGroup", "status", self.m_info.status, "group")
			local value = GlobalData:call("shared"):call("getEffectStateCntByGroup", group)
			if value > 0 then
				self.ui.m_valueTxt:setString("("..value..")")
				self.ui.m_valueTxt:setVisible(true)
				self.ui.m_barNode:setVisible(false)
			end
		else
			local tmp = string.split(self.m_info.action_number, "|")
			if #tmp > 1 then
				local action_number = tonumber(tmp[1])
				if action_number then
					local value = CCCommonUtilsForLua:call("getEffectValueByNum",action_number)
					if tmp[2] == "1" then
						value = value.."%"
					end
					self.ui.m_valueTxt:setString("("..value..")")
					self.ui.m_valueTxt:setVisible(true)
				end
			end
		end
	else
		self.ui.m_valueTxt:setVisible(false)
		self.ui.m_progress:setScaleX(0)
		self.ui.m_timeTxt:setString(getLang("105805", format_time(0)))
		self.ui.m_barNode:setVisible(false)
		self.ui.m_receiveGlow:setVisible(false)
		self.touchEnable = true

		if (self.m_type == 1) then
			local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
			local protectCDTime = playerInfo:getProperty("protectCDTime")
			local worldTime = GlobalData:call("getWorldTime")
			local newTime = GlobalData:call("renewTime", worldTime * 1000) / 1000
			local cdTime = protectCDTime - newTime
			if (cdTime > 0) then
				self.ui.m_timeCDTxt:setVisible(true)
				self.ui.m_timeCDTxt:setString(getLang("105164", CCCommonUtilsForLua:call("timeLeftToCountDown", cdTime)))
				-- self.touchEnable = false
				self.ui.m_CDBackLayer:setVisible(true)

				local txtSize = self.ui.m_timeCDTxt:getContentSize()
				self.ui.m_CDBackLayer:setContentSize(cc.size(txtSize.width + 10, txtSize.height))
			else
				self.ui.m_timeCDTxt:setVisible(false)
				self.ui.m_CDBackLayer:setVisible(false)
				if self.entry then 
					cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry) 
					self.entry = nil
				end
			end
		else
			if self.entry then 
				cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry) 
				self.entry = nil
			end
		end
	end
end

function CivFortressStatusTypeCell:getInfo()
	return self.m_info
end

return CivFortressStatusTypeCell