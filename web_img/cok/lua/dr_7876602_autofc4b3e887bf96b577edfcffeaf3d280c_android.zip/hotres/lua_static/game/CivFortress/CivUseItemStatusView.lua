local itemCellH1 = 145

local CivUseItemStatusView = class("CivUseItemStatusView",
	function()
		return PopupBaseView:create() 
	end
)
CivUseItemStatusView.__index = CivUseItemStatusView

local CivUseItemStatusCell = class("CivUseItemStatusCell",
	function()
		return cc.Layer:create()
	end
)
CivUseItemStatusCell.__index = CivUseItemStatusCell

function CivUseItemStatusView:create(_type, title, description, statusFlag, params)
	local view = CivUseItemStatusView.new()
	if (view:initView(_type, title, description, statusFlag, params)) then return view end
end

function CivUseItemStatusView:initView(_type, title, description, statusFlag, params)
	-- dump(params, "CivUseItemStatusView:initView params is: ")
	description = description or ""
	statusFlag = statusFlag or true
	self.m_params = params

	if (self:init(true, 0)) then
		self.m_type = _type
		self.m_title = title
		self.m_description = description
		self.m_endTime = 0
		self.m_statusFlag = statusFlag

		self:setIsHDPanel(true)
		CCLoadSprite:call("doResourceByCommonIndex", 504, true)

		local CustomUtility = Drequire("Editor.CustomUtility")
	    CustomUtility:LoadUi("CivilizationUseItemStatusView.ccbi", self, self, true, 0)
		-- local ccbUri = "CivilizationUseItemStatusView.ccbi"
		-- local proxy = cc.CCBProxy:create()
		-- local node = CCBReaderLoad(ccbUri, proxy, self)

		-- local function onNodeEvent(event)
		-- 	if event == "enter" then
		-- 		self:onEnter()
		-- 	elseif event == "exit" then
		-- 		self:onExit()
		-- 	elseif event == "cleanup" then
		-- 		self:onCleanup()
 	-- 		end
		-- end
		-- node:registerScriptHandler(onNodeEvent)
		-- self:addChild(node)

		-- local nodeSize = node:getContentSize()
		-- self:setContentSize(nodeSize)
		self:setTitleName(self.m_title)

		local oldBgHeight = self.m_viewBg:getContentSize().height
		self:call("changeBGHeight", self.m_viewBg)

		local newBgHeight = self.m_viewBg:getContentSize().height
		local addHeight = newBgHeight - oldBgHeight
		local oldWidth = self.m_infoList:getContentSize().width
		local oldHeight = self.m_infoList:getContentSize().height

		self.m_description = self.m_description .. " " --//下面的setString在英文中有可能自动删除最后一个字符原因不明
		self.m_descriptionText:setString(self.m_description)
		--getOriginScaleY
		local texH = self.m_descriptionText:getContentSize().height * self.m_descriptionText:getScaleY()
		self.m_descriptionText:setPositionY(self.m_descriptionText:getPositionY() -  texH / 2)
		

		if CCCommonUtilsForLua:isIosAndroidPad() then
			self.m_infoList:setPositionY(self.m_infoList:getPositionY() - 100 - texH)
			self.m_infoList:setContentSize(cc.size(oldWidth, oldHeight + texH))
		else
			self.m_infoList:setPositionY(self.m_infoList:getPositionY() - addHeight - 20)
			self.m_infoList:setContentSize(cc.size(oldWidth, oldHeight + addHeight - texH))
		end

		self.m_viewBg2_py = self.m_infoList:getPositionY() + self.m_infoList:getContentSize().height + 20
		self.m_viewBg2:setPositionY(self.m_viewBg2_py) --//350

		self.m_scrollView = cc.ScrollView:create()
		self.m_scrollView:setViewSize(self.m_infoList:getContentSize())
		self.m_scrollView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
		self.m_infoList:addChild(self.m_scrollView)

		self.m_listH = self.m_infoList:getContentSize().height

		if self.m_type == 1 then
			local ctManager = require("game.crossThrone.CrossThroneManager")
			self.useNewProtect, self.itemType = ctManager:useCrossThroneProtect()
			-- Dprint("self.itemType", self.itemType)
		else
			self.useNewProtect = false
		end
		
		local num, count, index = 0, 0, 0
		if (self.m_statusFlag == false) then
			local Items = ToolController:call("getInstance"):getProperty("m_durationItems")
			if (Items[self.m_type]) then
				num = 1
				count = 1
				local itemId = 0
				local dataList = ToolController:call("getInstance"):getProperty("m_allTools")
				for i = 1, #dataList do
					local tmpToolId = dataList[i]
					local info = ToolController:call("getToolInfoByIdForLua", tmpToolId)
					if (info:getProperty("type") == self.m_type) then
						itemId = info:getProperty("itemId")
						break
					end
				end

				local cell = CivUseItemStatusCell:create(itemId, "", 0)
				cell:setAnchorPoint(ccp(0.5, 0.5))
				cell:setPosition(ccp(0, index * itemCellH1))
				self.m_scrollView:addChild(cell)
			end

			-- 不知道是否能复用refreshData，故而得改俩份
		elseif self.m_params ~= nil and self.m_params.statusTbl then
			-- 暂时不支持皮肤
			count = #self.m_params.statusTbl
			for i, statusId in pairs(self.m_params.statusTbl) do
				local continue = false
				local itemId = tonumber(CCCommonUtilsForLua:call("getPropByIdGroup", "status", statusId, "itemId")) or 0
				local toolInfo = ToolController:call("getToolInfoByIdForLua", itemId)
            	local price = toolInfo:getProperty("price")
            	local cnt = toolInfo:call("getCNT")
            	local _type = toolInfo:getProperty("type")
				local _type2 = toolInfo:getProperty("type2")
				
				-- 文明堡垒限时活动特殊处理
				local statusMap = GlobalData:call("shared"):getProperty("statusMap")
				if statusMap[tonumber(statusId)] and statusMap[tonumber(statusId)] ~= 0 then
					self:setTimeItem(itemId)
				end

            	if (price <= 0 and cnt <= 0) then             
            		if (self.useNewProtect and _type == self.itemType) then
            			continue = false
            		elseif (not (_type == 4 and (_type2 == 17 or _type2 == 18 or _type2 == 251 or _type2 == 252 or _type2 == 253))) then
            			count = count - 1
            			continue = true
            		end
            		
            	end
            	if (continue == false) then
        			local cell = CivUseItemStatusCell:create(itemId, "", 0)
        			cell:setAnchorPoint(ccp(0.5, 0.5))
        			cell:setPosition(ccp(0, index * itemCellH1))
        			self.m_scrollView:addChild(cell)	
            	end

                if (continue == false) then index = index + 1 end
			end
		else
			local typeItems = ToolController:call("getInstance"):getProperty("m_typeItems")

			local array = typeItems[self.m_type]
			if (array) then MyPrint("array count", array:count()) end
			if (array and array:count() > 0) then
				num = array:count()
				count = num
				for i = 0, num - 1 do
					local continue = false
					local dictInfo = array:objectAtIndex(i)
					if (dictInfo:objectForKey("customskin")) then
						local cell = CivUseItemStatusCell:create(0, "customskin", 0)
						cell:setAnchorPoint(ccp(0.5, 0.5))
						cell:setPosition(ccp(0, index * itemCellH1))
						self.m_scrollView:addChild(cell)
					else
						local itemId = dictInfo:valueForKey("id"):intValue()
						--// 如果price=0的时候，只有你身上有这种道具的时候才显示。
                    	--// =4 表示是作用相关道具，=17 表示是龙韵石。龙韵石不受上述price=0的影响。
                    	local toolInfo = ToolController:call("getToolInfoByIdForLua", itemId)
                    	local price = toolInfo:getProperty("price")
                    	local cnt = toolInfo:call("getCNT")
                    	local _type = toolInfo:getProperty("type")
                		local _type2 = toolInfo:getProperty("type2")

                		--跨服王战不显示普通加速
						if (self.useNewProtect and _type == 4) then
	            			count = count - 1
							continue = true
	            		end

                    	if (price <= 0 and cnt <= 0) then             
                    		if (self.useNewProtect and _type == self.itemType) then
                    			continue = false
                    		elseif (not (_type == 4 and (_type2 == 17 or _type2 == 18 or _type2 == 251 or _type2 == 252 or _type2 == 253))) then
                    			count = count - 1
                    			continue = true
                    		end
                    		
                    	end
                    	if (continue == false) then
                			local cell = CivUseItemStatusCell:create(itemId, "", 0)
                			cell:setAnchorPoint(ccp(0.5, 0.5))
                			cell:setPosition(ccp(0, index * itemCellH1))
                			self.m_scrollView:addChild(cell)	
                    	end
                    end

                    if (continue == false) then index = index + 1 end
            	end
            end
        end
        local contentHeight = count * itemCellH1
        self.m_scrollView:setContentSize(cc.size(self.m_infoList:getContentSize().width, contentHeight))
        self.m_scrollView:setContentOffset(ccp(0, self.m_infoList:getContentSize().height - contentHeight))

        self.m_scrollH = contentHeight
        self.m_barSize = self.m_bar:getContentSize()

        --//加进度条头上的光效
        self.m_headParticleNode = cc.Node:create()
        for i = 1, 3 do
        	local path = string.format("Loading_%d", i)
        	local particle = ParticleController:call("createParticle", path)
        	self.m_headParticleNode:addChild(particle)
        end

        self.m_timeNode:addChild(self.m_headParticleNode)
        self.m_timeNode:setVisible(false)

		return true
	end

	return false
end

function CivUseItemStatusView:updateTime(dt)
	self.m_time = 0

	local tmpEndTime = 0
	local max = 0
	if (self.m_statusFlag) then
		local statuesItems = ToolController:call("getInstance"):getProperty("m_statusItems")
		local item = statuesItems[self.m_type]
		if (item) then
			local startTime = item:valueForKey("startTime"):doubleValue()
			local endTime = item:valueForKey("endTime"):doubleValue()
			local time = WorldController:call("getTime")
			self.m_time = (endTime - time) / 1000
			tmpEndTime = endTime / 1000
			max = (endTime - startTime) / 1000
			max = math.max(max, 1)
		end
	else
		local durationItems = ToolController:call("getInstance"):getProperty("m_durationItems")
		if (durationItems[self.m_type]) then
			local time = durationItems[self.m_type]
			if (#time == 2) then
				self.m_time = time[2] - GlobalData:call("getTimeStamp")
				max = time[2] - time[1]
			end
		end
	end

	if (self.m_time > 0) then
		local len = self.m_time / max
		self.m_barRight:setVisible(len > 0.99)
		if (len > 1) then len = 1 end
		self.m_bar:setScaleX(len)
		self.m_timeLabel:setString(getLang("105805", CC_SECTOA(self.m_time)))
		self.m_timeLabel:setVisible(true)

		if ((not self.m_timeNode:isVisible()) or (self.m_endTime ~= tmpEndTime)) then
			self.m_endTime = tmpEndTime
			self:refreshData()
		end

		if (self.m_infoList:getContentSize().height ~= self.m_listH) then
			self.m_infoList:setContentSize(cc.size(self.m_infoList:getContentSize().width, self.m_listH))
			self.m_scrollView:setContentOffset(ccp(0, self.m_infoList:getContentSize().height - self.m_scrollH))
			self.m_scrollView:setViewSize(self.m_infoList:getContentSize())
			self.m_viewBg2_py = self.m_infoList:getPositionY() + self.m_infoList:getContentSize().height + 20
			self.m_viewBg2:setPositionY(self.m_viewBg2_py)
		end

		self.m_timeNode:setVisible(true)

		local px = 0 --//进度条头上的光效位置
		px = self.m_bar:getPositionX() + (self.m_barSize.width * len)
		self.m_headParticleNode:setPositionX(px)
	else
		self.m_timeLabel:setString(getLang("105805", format_time(0)))
		if self.entry then 
			cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry) 
			self.entry = nil
		end

		self.m_infoList:setContentSize(cc.size(self.m_infoList:getContentSize().width, self.m_listH + 60))
		self.m_scrollView:setContentOffset(ccp(0, self.m_infoList:getContentSize().height - self.m_scrollH))
		self.m_scrollView:setViewSize(self.m_infoList:getContentSize())
		self.m_timeNode:setVisible(false)
		self.m_viewBg2_py = self.m_infoList:getPositionY() + self.m_infoList:getContentSize().height + 20
		self.m_viewBg2:setPositionY(self.m_viewBg2_py)
	end

	local texH = self.m_descriptionText:getContentSize().height * self.m_descriptionText:getScaleY()
	if (self.m_timeNode:isVisible()) then
		self.m_descriptionText:setPositionY(self.m_timeNode:getPositionY() - texH / 2 - 30)
	else
		self.m_descriptionText:setPositionY(self.m_timeNode:getPositionY() - texH / 2 + 100)
	end
end

function CivUseItemStatusView:refreshData()
	self.m_scrollView:getContainer():removeAllChildren()
	local num, count, index = 0, 0, 0

	if (self.m_statusFlag == false) then
		local durationItems = ToolController:call("getInstance"):getProperty("m_durationItems")
		if (durationItems[self.m_type]) then
			num = 1
			count = 1
			local itemId = 0
			local dataList = ToolController:call("getInstance"):getProperty("m_allTools")
			for i = 1, #dataList do
				local tmpToolId = dataList[i]
				local info = ToolController:call("getToolInfoByIdForLua", tmpToolId)
				if (info:getProperty("type") == self.m_type) then
					itemId = info:getProperty("itemId")
					break
				end
			end

			local cell = CivUseItemStatusCell:create(itemId, "", 0)
			cell:setAnchorPoint(ccp(0.5, 0.5))
			cell:setPosition(ccp(0, index * itemCellH1))
			self.m_scrollView:addChild(cell)
		end
	elseif self.m_params ~= nil and self.m_params.statusTbl then
			count = #self.m_params.statusTbl
			-- 暂时不支持皮肤
			for i, statusId in pairs(self.m_params.statusTbl) do
				local continue = false
				local itemId =  tonumber(CCCommonUtilsForLua:call("getPropByIdGroup", "status", statusId, "itemId")) or 0
				local toolInfo = ToolController:call("getToolInfoByIdForLua", itemId)
            	local price = toolInfo:getProperty("price")
            	local cnt = toolInfo:call("getCNT")
            	local _type = toolInfo:getProperty("type")
				local _type2 = toolInfo:getProperty("type2")
				
				-- 文明堡垒限时活动特殊处理
				local statusMap = GlobalData:call("shared"):getProperty("statusMap")
				if statusMap[tonumber(statusId)] and statusMap[tonumber(statusId)] ~= 0 then
					self:setTimeItem(itemId)
				end

            	if (price <= 0 and cnt <= 0) then             
            		if (self.useNewProtect and _type == self.itemType) then
            			continue = false
            		elseif (not (_type == 4 and (_type2 == 17 or _type2 == 18 or _type2 == 251 or _type2 == 252 or _type2 == 253))) then
            			count = count - 1
            			continue = true
            		end
            		
            	end
            	if (continue == false) then
        			local cell = CivUseItemStatusCell:create(itemId, "", 0)
        			cell:setAnchorPoint(ccp(0.5, 0.5))
        			cell:setPosition(ccp(0, index * itemCellH1))
        			self.m_scrollView:addChild(cell)	
            	end

                if (continue == false) then index = index + 1 end
			end
	else
		local typeItems = ToolController:call("getInstance"):getProperty("m_typeItems")
		local array = typeItems[self.m_type]
		if (array and array:count() > 0) then
			num = array:count()
			count = num
			for i = 0, num - 1 do
				local continue = false
				local dictInfo = array:objectAtIndex(i)
				if (dictInfo:objectForKey("customskin")) then
					local cell = CivUseItemStatusCell:create(0, "customskin", 0)
					cell:setAnchorPoint(ccp(0.5, 0.5))
					cell:setPosition(ccp(0, index * itemCellH1))
					self.m_scrollView:addChild(cell)
				else
					local itemId = dictInfo:valueForKey("id"):intValue()
					local city_buff = dictInfo:valueForKey("city_buff"):intValue()
					local toolInfo = ToolController:call("getToolInfoByIdForLua", itemId)
					local price = toolInfo:getProperty("price")
					local cnt = toolInfo:call("getCNT")
					local _type = toolInfo:getProperty("type")
					local _type2 = toolInfo:getProperty("type2")

					--跨服王战不显示普通加速
					if (self.useNewProtect and _type == 4) then
            			count = count - 1
						continue = true
            		end

					if (price <= 0 and cnt <= 0) then	
						if (self.useNewProtect and _type == self.itemType) then
                			continue = false
						elseif (not (_type == 4 and (type2 == 17 or type2 == 18))) then
							count = count - 1
							continue = true
						end				
					elseif (price > 0 and cnt <= 0 and city_buff ~= 1) then
						count = count - 1
						continue = true
					end

					if continue == false then
						local cell = CivUseItemStatusCell:create(itemId, "", 0)
						cell:setAnchorPoint(ccp(0.5, 0.5))
						cell:setPosition(ccp(0, index * itemCellH1))
						self.m_scrollView:addChild(cell)
					end
				end

				if continue == false then index = index + 1 end
			end
		end
	end

	local contentHeight = 0
	contentHeight = count * itemCellH1
	self.m_scrollView:setContentSize(cc.size(self.m_infoList:getContentSize().width, contentHeight))
	self.m_scrollView:setContentOffset(ccp(0, self.m_infoList:getContentSize().height - contentHeight))
end

function CivUseItemStatusView:resetTime(pObj)
	local integer = tolua.cast(pObj, "CCInteger")
	if (integer:getValue() == self.m_type) then
		self:updateTime()
		if self.entry then 
			cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry) 
			self.entry = nil
		end
		self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(function(dt) self:updateTime(dt) end, 1, false)
	end
end

function CivUseItemStatusView:updateListView(pObj)
	self:refreshData()
end

function CivUseItemStatusView:setTimeItem(itemId)
	local toolInfo = ToolController:call("getToolInfoByIdForLua", itemId)
	local name = toolInfo:call("getName")
	local des = getLang(toolInfo:getProperty("des"))
	local cnt = toolInfo:call("getCNT")

	self.m_nameLabel:setString(name)
	self.m_desLabel:setString(des)
	self.m_numLabel:setString(tostring(cnt))
	self.m_timeTitle:setString(getLang("182158"))
	CCCommonUtilsForLua:createGoodsIcon(toolInfo:getProperty("itemId"), self.m_picNode, cc.size(92, 92))
end

function CivUseItemStatusView:onEnter()
	if self.entry then 
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry) 
		self.entry = nil
	end
	self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(function(dt) self:updateTime(dt) end, 1, false)
	self:updateTime()

	local function callback1(pObj) self:resetTime(pObj) end
	local handler1 = self:registerHandler(callback1)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, MSG_ITME_STATUS_TIME_CHANGE)

	local function callback2(pObj) self:updateListView(pObj) end
	local handler2 = self:registerHandler(callback2)
	CCSafeNotificationCenter:registerScriptObserver(self, handler2, MSG_TOOL_CHANGE)
end

function CivUseItemStatusView:onExit()
	if self.entry then 
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry) 
		self.entry = nil
	end
	CCSafeNotificationCenter:unregisterScriptObserver(self, MSG_ITME_STATUS_TIME_CHANGE)
	CCSafeNotificationCenter:unregisterScriptObserver(self, MSG_TOOL_CHANGE)
end

function CivUseItemStatusView:onCleanup()
	self = nil
end


---------------------------------CivUseItemStatusCell--------------------------------
function CivUseItemStatusCell:create(itemId, objId, qid)
	local node = CivUseItemStatusCell.new()
	if (node:initNode(itemId, objId, qid)) then return node end
end

function CivUseItemStatusCell:initNode(itemId, objId, qid)
	local ccbUri = "CivilizationUseItemStatusCell.ccbi"
	local proxy = cc.CCBProxy:create()
	local node = CCBReaderLoad(ccbUri, proxy, self)

	local function onNodeEvent(event)
		if event == "enter" then
			self:onEnter()
		elseif event == "exit" then
			self:onExit()
		elseif event == "cleanup" then
			self:onCleanup()
			end
	end
	node:registerScriptHandler(onNodeEvent)
	self:addChild(node)

	self:setData(itemId, objId, qid)

	return true
end

function CivUseItemStatusCell:setData(itemId, objId, qid)
	self.m_itemId = itemId
	self.m_objId = objId
	self.m_qid = qid

	self.m_picNode:removeAllChildren()
	self.m_des2Label:setString("")

	if (self.m_itemId == 0) then
		if (objId == "customskin") then
			self.m_nameLabel:setString(getLang("101458"))
			self.m_desLabel:setString(getLang("101460"))
			self.m_numLabel:setString("")
			self.m_useBtn:setVisible(true)
			self.m_buyNode:setVisible(false)
			self.m_buyBtn:setEnabled(false)
			self.m_useBtn:setEnabled(true)
			CCCommonUtilsForLua:setButtonTitle(self.m_useBtn, getLang("108532"))
			local pic = CCLoadSprite:call("createSprite", "uncityskin_icon.png")
			self.m_picNode:addChild(pic)
		else
			self.m_numLabel:setString("")
			self.m_nameLabel:setString(getLang("103669"))
			self.m_des2Label:setString(getLang("103671"))
			self.m_buyNode:setVisible(false)
			CCCommonUtilsForLua:setButtonTitle(self.m_useBtn, getLang("103672"))
			CCCommonUtilsForLua:call("setButtonSprite", self.m_useBtn, "btn_green4.png")

			self.m_useBtn:setVisible(true)
			self.m_buyNode:setVisible(false)
			self.m_buyBtn:setEnabled(false)
			local curTime = GlobalData:call("getWorldTime")
			local queueInfos = GlobalData:call("shared"):getProperty("allQueuesInfo")
			local finishTime = queueInfos[self.m_qid]:getProperty("finishTime")
			local tmpTime = finishTime - curTime
			local freeSpdT = GlobalData:call("shared"):getProperty("freeSpdT")
			if (tmpTime < freeSpdT) then
				self.m_useBtn:setEnabled(true)
				self.m_desLabel:setString("")
			else
				self.m_lockNode:removeAllChildren()
				local picLock = CCLoadSprite:call("createSprite", "iron_lock.png")
				picLock:setScale(0.5)
				self.m_lockNode:addChild(picLock)
				self.m_useBtn:setEnabled(false)
				self.m_desLabel:setString(getLang("103670", format_time(tmpTime - freeSpdT)))
			end

			local pic = CCLoadSprite:call("createSprite", "iron_lock.png")
			self.m_picNode:addChild(pic)
		end
	else
		local toolInfo = ToolController:call("getToolInfoByIdForLua", itemId)
		local name = toolInfo:call("getName")
		local des = getLang(toolInfo:getProperty("des"))
		local cnt = toolInfo:call("getCNT")

		self.m_nameLabel:setString(name)
		self.m_desLabel:setString(des)
		self.m_numLabel:setString(tostring(cnt))

		self.m_price = toolInfo:getProperty("price")
		CCCommonUtilsForLua:createGoodsIcon(toolInfo:getProperty("itemId"), self.m_picNode, cc.size(92, 92))

		self.m_inBtnGoldNum:setString(CC_CMDITOA(self.m_price))
		CCCommonUtilsForLua:setButtonTitle(self.m_useBtn, getLang("102137"))
		self.m_btnMsgLabel:setString(getLang("104906"))

        local _type = toolInfo:getProperty("type")
        local _type2 = toolInfo:getProperty("type2")

		if (cnt > 0) then
			self.m_buyNode:setVisible(false)
            self.m_buyBtn:setEnabled(false)
            self.m_useBtn:setVisible(true)
            self.m_useBtn:setEnabled(true)
       	elseif ((_type == 49 or _type == 50) and _type2 == 1) then
			self.m_buyBtn:setEnabled(false)
			self.m_useBtn:setVisible(true)
			self.m_useBtn:setEnabled(true)
			CCCommonUtilsForLua:setButtonTitle(self.m_useBtn, getLang("105086"))
        else
        	self.m_buyNode:setVisible(true)
            self.m_buyBtn:setEnabled(true)
            self.m_useBtn:setVisible(false)
            self.m_useBtn:setEnabled(false)
        end

        if (_type == 4 and (_type2 == 17 or _type2 == 18 or _type2 == 251 or _type2 == 252 or _type2 == 253)) then
        	self.m_buyNode:setVisible(false)
        	self.m_buyBtn:setEnabled(false)
        	--self.m_desLabel:setFontSize(34)
        	if (cnt > 0) then
        		self.m_useBtn:setVisible(true)
        		self.m_useBtn:setEnabled(true)
        	else
        		self.m_btnGray:setVisible(true)
        		CCCommonUtilsForLua:setButtonTitle(self.m_btnGray, getLang("102137"))
        		self.m_useBtn:setVisible(true)
        		self.m_useBtn:setEnabled(false)
        	end
        end
	end

    self:checkCDShow()
end

function CivUseItemStatusCell:onEnter()
	if self.entry then 
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry) 
		self.entry = nil
	end
	self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(function(dt) self:onEnterFrame(dt) end, 1, false)
end

function CivUseItemStatusCell:onExit()
	if self.entry then 
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry) 
		self.entry = nil
	end
end

function CivUseItemStatusCell:onCleanup()
	--self = nil
end

function CivUseItemStatusCell:checkCDShow()
	local toolInfos = ToolController:call("getInstance"):getProperty("m_toolInfos")
	if (toolInfos[self.m_itemId] == nil) then
		self.m_picNode:removeChildByName("label")
		self.m_picNode:removeChildByName("cdbg")
		return
	end

	local toolInfo = toolInfos[self.m_itemId]
	local left = 0
	local cdTime = toolInfo:call("getCDTime")
	if (cdTime > 0) then
		local lastUseTime = toolInfo:call("getLastUseTime")
		left = lastUseTime + cdTime - GlobalData:call("getTimeStamp")
	end
	if (left > 0) then
		local bg = self.m_picNode:getChildByName("cdbg")
		if (not bg) then
			bg = cc.LayerColor:create(cc.c4b(0, 0, 0, 150))
			bg:setName("cdbg")
			bg:setAnchorPoint(ccp(0.5, 0.5))
			bg:ignoreAnchorPointForPosition(false)
			self.m_picNode:addChild(bg, 2)
		end

		local label = self.m_picNode:getChildByName("label")
		if (not label) then
			label = cc.Label:createWithSystemFont("", "Helvetica", 20)
			label:setName("label")
			label:setAnchorPoint(ccp(0.5, 0.5))
			label:setColor(cc.c3b(254, 251, 0))
			self.m_picNode:addChild(label, 3)
		end

		label:setString(format_time(left))
		bg:setContentSize(cc.size(label:getContentSize().width + 10, label:getContentSize().height))

		self.m_buyBtn:setEnabled(false)
		self.m_btnGray:setEnabled(false)
		self.m_useBtn:setEnabled(false)
	else
		self.m_picNode:removeChildByName("label")
		self.m_picNode:removeChildByName("cdbg")

		local _type = toolInfo:getProperty("type")
		local _type2 = toolInfo:getProperty("type2")
		local cnt = toolInfo:call("getCNT")
		if (cnt > 0) then
			self.m_buyBtn:setEnabled(false)
			self.m_useBtn:setVisible(true)
			self.m_useBtn:setEnabled(true)
		elseif ((_type == 49 or _type == 50) and _type2 == 1) then
			self.m_buyBtn:setEnabled(false)
			self.m_useBtn:setVisible(true)
			self.m_useBtn:setEnabled(true)
			CCCommonUtilsForLua:setButtonTitle(self.m_useBtn, getLang("105086"))
		else
			self.m_buyBtn:setEnabled(true)
			self.m_useBtn:setVisible(false)
			self.m_useBtn:setEnabled(false)
		end

	
		if (_type == 4 and (_type2 == 17 or _type2 == 18 or _type2 == 251 or _type2 == 252 or _type2 == 253)) then
			self.m_buyBtn:setEnabled(false)
			if (cnt > 0) then
				self.m_useBtn:setVisible(true)
				self.m_useBtn:setEnabled(true)
			else
				self.m_btnGray:setVisible(true)
				self.m_useBtn:setVisible(true)
				self.m_useBtn:setEnabled(false)
			end
		end
	end
	-- 文明堡垒限时活动特殊处理
	self.m_receiveGlow:setVisible(false)
	local xmlData = CCCommonUtilsForLua:getGroupByKey("civilization_buff")
	for k,v in pairs(xmlData) do
		if v.goods then
			local goodsList = string.split(v.goods, "|")
			for i = 1, #goodsList do
				if self.m_itemId == tonumber(goodsList[i]) then
					local statusMap = GlobalData:call("shared"):getProperty("statusMap")
					local status = string.split(v.status, "|")[i]
					if statusMap[tonumber(status)] and statusMap[tonumber(status)] ~= 0 then
						self.m_receiveGlow:setVisible(true)
					end
				end
			end
		end
	end
end

function CivUseItemStatusCell:onEnterFrame(dt)
	if (self.m_itemId == 0) then
		if (self.m_objId == "") then
			local curTime = GlobalData:call("getWorldTime")
			local queueInfos = GlobalData:call("shared"):getProperty("allQueuesInfo")
			local finishTime = queueInfos[self.m_qid]:getProperty("finishTime")
			local tmpTime = finishTime - curTime
			local freeSpdT = GlobalData:call("shared"):getProperty("freeSpdT")
			if (tmpTime <= freeSpdT) then
				self.m_desLabel:setString("")
				self.m_lockNode:removeAllChildren()
				self.m_useBtn:setEnabled(true)
			else
				self.m_desLabel:string(getLang("103670", format_time(tmpTime - freeSpdT)))
			end
			self.m_leftTimeLabel:setString("")
		end
	else
		local toolInfo = ToolController:call("getToolInfoByIdForLua", self.m_itemId)
		local limitTime = toolInfo:getProperty("limitTime")
		local cnt = toolInfo:call("getCNT")
		if (limitTime > 0 and cnt > 0) then
			local curTime = GlobalData:call("getTimeStamp")
			if (limitTime > curTime) then
				self.m_leftTimeLabel:setString(getLang("108802", format_time(limitTime - curTime)))
			else
				self.m_leftTimeLabel:setString("")
			end
		else
			self.m_leftTimeLabel:setString("")
		end
	end

	self:checkCDShow()
end

function CivUseItemStatusCell:onClickUseBtn()
	self.m_isByBuy = false
	if (self.m_itemId == 0 and self.m_objId == "customskin") then
		YesNoDialog:call("show", getLang("101459"), cc.CallFunc:create(function() self:sureToCancel() end))
	else
		local toolInfo = ToolController:call("getToolInfoByIdForLua", self.m_itemId)
		local _type = toolInfo:getProperty("type")
		local cnt = toolInfo:call("getCNT")
		if ((_type == 49 or _type == 50) and cnt <= 0) then
			local ItemGetMethodView = Drequire("game.CommonPopup.ItemGetMethodView")
			local view = ItemGetMethodView:create(self.m_itemId)
			PopupViewController:addPopupView(view)
		elseif (_type == 42) then
			if (FunBuildController:call("getGoodsDurationByItemType", _type)) then
				YesNoDialog:call("show", getLang("101432"), cc.CallFunc:create(function() self:onUseTool() end))
			else
				YesNoDialog:call("show", getLang("165046"), cc.CallFunc:create(function() self:onUseTool() end))
			end
		else
			self:onUseTool()
		end
	end
end

function CivUseItemStatusCell:sureToCancel()
	UIComponent:call("onPopupReturnClick", nil, 1)
end

function CivUseItemStatusCell:onYes()
	if (ToolController:call("isBuyUseOn")) then
		ToolController:call("buyUseTool", self.m_itemId, 1, nil, 0, false, "CivUseItemStatusView")
	else
		ToolController:call("buyTool", self.m_itemId, 1, cc.CallFunc:create(function() self:onUseTool() end), 0, true, false, "CivUseItemStatusView")		
	end
end

function CivUseItemStatusCell:onUseTool()
	if (self.m_itemId == 0 and self.m_objId == "customskin") then
		self:sureToCancel()
	else
		ToolController:call("useTool", self.m_itemId, 1, true, self.m_isByBuy)
	end
end

function CivUseItemStatusCell:onClickBuyBtn()
	self.m_isByBuy = false
	local info = ToolController:call("getToolInfoByIdForLua", self.m_itemId)
	local _type = info:getProperty("type")
	local _type2 = info:getProperty("type2")
	local cnt = info:call("getCNT")
	if (_type == 4 and (_type2 == 17 or _type2 == 18 or _type2 == 251 or _type2 == 252 or _type2 == 253) and cnt <= 0) then
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("160475"))
		return
	end

	if (_type == 4 and ToolController:call("checkUseStateTool", self.m_itemId, cc.CallFunc:create(function() self:onYes() end))) then
		self.m_isByBuy = true
	else
		local price = info:getProperty("price")
		local function callback() self:onYes() end
		YesNoDialog:call("showButtonAndGold", getLang("104919"), cc.CallFunc:create(callback), getLang("104906"), price)
	end
end

return CivUseItemStatusView