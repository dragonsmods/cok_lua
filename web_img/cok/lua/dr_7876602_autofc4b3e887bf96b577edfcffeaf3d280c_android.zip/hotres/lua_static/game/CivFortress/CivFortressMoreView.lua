local CivFortressMoreView = class("CivFortressMoreView",
    function()
        return ArcPopupBaseView:call("create", 1)
    end
)
CivFortressMoreView.__index = CivFortressMoreView
ccb["CivFortressMoreView"] = ccb["CivFortressMoreView"] or {}
function CivFortressMoreView:create(dict)
    local view = CivFortressMoreView.new()
    Drequire("game.CivFortress.CivFortressMoreView_ui"):create(view, 0)
    if view:initView(dict) then
        return view
    end
end

function CivFortressMoreView:initView(dict)
    local data = dictToLuaTable(dict)
    self.m_buildId = data.buildingKey or 443000072
    local size = self:getContentSize()
    -- dump(self.m_buildId, " self.m_buildId is: ")

    self.ui.m_nameLabel:setString(getLang("310000"))

    local buildInfo = FunBuildController:call("getFunbuildForLua", self.m_buildId)
    local buildType = buildInfo:getProperty("type")
    local buildLevel = buildInfo:getProperty("level")
    if building_Miracle_open and FunBuildController:call("checkOpenUpstar", buildType) then
        local MaxBuildLv = GlobalData:call("shared"):getProperty("MaxBuildLv")
        if buildLevel < MaxBuildLv then
            self.ui.m_flagLabel:setString(getLang(buildInfo:getProperty("description")))
        else
            self.ui.m_flagLabel:setString(getLang(buildInfo:getProperty("starDescription")))
        end
    else
        self.ui.m_flagLabel:setString(getLang(buildInfo:getProperty("description")))
    end

    local nextSize = self.ui.m_flagLabel:getContentSize()
    self.ui.m_flagScrollView:setContentSize(nextSize)
    -- if nextSize.height <= self.ui.m_flagScrollView:getViewSize().height then
    --     self.ui.m_flagScrollView:setTouchEnabled(false)
    -- end

    self.ui.m_lvLabel:setString("LV."..buildLevel)

    local listSize = self.ui.m_listScrollNode:getContentSize()
    self.ui.m_listScrollView:setContentSize(listSize)

    -- 310041=每天产量(满采集、X级士兵)
    -- 310003=每日可被掠夺数量:
    -- 310004=每日掠夺可获得奖励次数:
    -- 310005=放置所需资源:
    self.ui.m_tenMinLabel:setString(getLang("310041", CivFortressController.m_productOffTime))
    self.ui.m_dayLabel:setString(getLang("310003"))
    self.ui.m_timeLabel:setString(getLang("310004"))
    self.ui.m_resLabel:setString(getLang("310005"))
    
    local xmlData = CivFortressController:getCivFortressXmlData()
    -- dump(xmlData, " xmlData is: ")
    if xmlData[buildLevel] == nil then
        return false
    end
    self.m_xmlData = xmlData[buildLevel]

    local day_output = self.m_xmlData.day_output
    dump(CivFortressController.m_package_coupon, "CivFortressController.m_package_coupon is: ")
    if CivFortressController.m_package_coupon then
        day_output = self.m_xmlData.day_output_2
    end

    -- 310041=每天产量(满采集、X级士兵)
    self.ui.m_tenNumLabel:setString(tostring(day_output or "--"))


    local resourceInfo = GlobalData:call("shared"):getProperty("resourceInfo")
    local wood = resourceInfo:call("totalWood")

    if wood < self.m_xmlData.wood then
        self.ui.m_iconNumLabel1:setColor(cc.c3b(255, 0, 0))
    else
        self.ui.m_iconNumLabel1:setColor(cc.c3b(0, 255, 0))
    end
    self.ui.m_iconNumLabel1:setString(CC_ITOA_K(wood).."/"..tostring(self.m_xmlData.wood))

    if self.m_xmlData.iron > 0 then
        local iron = resourceInfo:call("totalIron")

        self.ui.m_resNode2:setVisible(true)
        self.ui.m_iconNumLabel2:setString(tostring(CC_ITOA_K(iron).."/"..self.m_xmlData.iron))
        if iron < self.m_xmlData.iron then
            self.ui.m_iconNumLabel2:setColor(cc.c3b(255, 0, 0))
        else
            self.ui.m_iconNumLabel2:setColor(cc.c3b(0, 255, 0))
        end
    else
        self.ui.m_resNode2:setVisible(false)
    end

    local score = CivilizationController:getCivilizationScore()
    self.ui.m_iconNumLabel3:setString(score.."/"..tostring(self.m_xmlData.integral))
    if score < self.m_xmlData.integral then
        self.ui.m_iconNumLabel3:setColor(cc.c3b(255, 0, 0))
    else
        self.ui.m_iconNumLabel3:setColor(cc.c3b(0, 255, 0))
    end
    
    self.ui.m_moreLabel:setString(getLang("102105"))
    self.ui.m_placeLabel:setString(getLang("111525"))--111525=放置

    self.ui.m_removeNode:setVisible(false)
    if CCCommonUtilsForLua:isIosAndroidPad() then
        self.ui.m_btnNode:setScale(0.9)
        self.ui.m_btnNode:setPositionY(self.ui.m_btnNode:getPositionY()+20)
    end
    return true
end

function CivFortressMoreView:initDetailLabel()
    if self.m_data.status == 0 then
        self.ui.m_placeLabel:setString(getLang("111525"))--111525=放置
        self.ui.m_stateLabel:setString(getLang("310006"))   -- 310006=文明堡垒可放置
    else
        self.ui.m_placeLabel:setString(getLang("115018"))--115018=查看
        self.ui.m_stateLabel:setString(getLang("310007"))   -- 310007=文明堡垒已放置
    end
    -- 每日可被掠夺数量:
    self.ui.m_dayNumLabel:setString(self.m_data.beRobNum .."/".. self.m_xmlData.plunder_number)
    if tonumber(self.m_data.beRobNum) >= tonumber(self.m_xmlData.plunder_number) then
        self.ui.m_dayNumLabel:setColor(cc.c3b(255, 0, 0))
    else
        self.ui.m_dayNumLabel:setColor(cc.c3b(255, 124, 10))
    end

    local addTimes = tonumber(self.m_data.itemAddCount) or 0
    local plunder_times = tonumber(self.m_xmlData.plunder_times) or 0
    if CivFortressController.m_package_coupon then
        plunder_times = tonumber(self.m_xmlData.plunder_times_2) or 0
    end
    -- 每日掠夺可获得奖励次数:
    self.ui.m_timeNumLabel:setString(self.m_data.robCount .."/".. plunder_times)
    if addTimes > 0 then
        self.ui.m_timeNumLabel2:setVisible(true)
        self.ui.m_timeNumLabel2:setPositionX(self.ui.m_timeNumLabel:getPositionX())
        self.ui.m_timeNumLabel2:setString("+"..addTimes)
    else
        self.ui.m_timeNumLabel2:setVisible(false)
    end

    if tonumber(self.m_data.robCount) >= (tonumber(plunder_times) + addTimes) then
        self.ui.m_timeNumLabel:setColor(cc.c3b(255, 0, 0))
    else
        self.ui.m_timeNumLabel:setColor(cc.c3b(255, 124, 10))
    end

    if self.m_data.status > 0 then
        self.ui.m_removeNode:setVisible(true)

        self.ui.m_removeButton:setEnabled(true)
        if self.m_data.status == 3 then
            -- 拆除中
            local offset = self.m_data.removeEndTime - getTimeStamp()
            if offset > 0 then
                if self.m_entryId == nil then
                    self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:update(dt) end, 1.0, false)
                end
                self.ui.m_stateLabel:setString(getLang("165427"))
                self.ui.m_removeLabel:setString(getLang("310100", format_time(offset)))
            else
                self.ui.m_removeButton:setEnabled(false)
            end
        else
            self.ui.m_removeLabel:setString(getLang("102121"))
        end
    else
        self.ui.m_removeNode:setVisible(false)
    end
end


function CivFortressMoreView:onEnter()
    -- 数据接收
    registerScriptObserver(self, self.onGetDataBack, CivFortressController.getInfoNotifyKey)
    CivFortressController:getCivFortressInfoCmd()

    CCSafeNotificationCenter:call("postNotification", "msg_main_scence_savePos")
    local layer = SceneController:call("getCurrentLayerByLevel", LEVEL_SCENE)
    if layer then
        layer:call("onMoveToBuildAndOpen", self.m_buildId, 1)
    end


end

function CivFortressMoreView:onExit()
    unregisterScriptObserver(self, CivFortressController.getInfoNotifyKey)
    if self.m_entryId then
        self:getScheduler():unscheduleScriptEntry(self.m_entryId)
    end
end

-- function CivFortressMoreView:update(dt)
-- end

function CivFortressMoreView:onTouchBegan(x, y)
    -- self.touchType = nil
    -- if not touchInside(self.ui.m_touchNode, x, y) then
    --     self.touchType = 1
    -- end
    return true
end

function CivFortressMoreView:onTouchMoved(x, y)

end

function CivFortressMoreView:onTouchEnded(x, y)
    -- if self.touchType == 1 and touchInside(self.ui.m_touchNode, x, y)==false then
    --     PopupViewController:call("removeLastPopupView")
    -- end
end

function CivFortressMoreView:onGetDataBack()
    local data = CivFortressController:getCivFortressInfo()
    dump(data, "CivFortressMoreView:onGetDataBack data is: ")
    if data == nil then
        return
    end
    self.m_data = data
    self:initDetailLabel()
    
end

function CivFortressMoreView:onPlaceButtonClick()
    if self.m_data.status == 0 then
        -- 放置
        CivFortressController:placeCivFortress()
    else
        CivFortressController:viewCivFortress()
    end
    -- LuaWorldController:setPlaceData({
    --     type = 1,
    --     })
end

function CivFortressMoreView:onMoreButtonClick()
    dump("CivFortressMoreView:onMoreButtonClic~~~~~~~~~")
    local view = BuildMoreInfoView:call("create", self.m_buildId)
    PopupViewController:call("addPopupView", view)
end

function CivFortressMoreView:onTipBtnClick()
    LuaController:call("showFAQ","45277")
end

function CivFortressMoreView:onRemoveButtonClick()
    dump("CivFortressMoreView:onRemoveButtonClick~~~~~~~~~")
    if self.m_data then
        if self.m_data.status ~= 3 then
            local function callBack()
                CivFortressController:removeCivFortress(self.cityIndex)
                self:call("closeSelf")
            end
            
            local dia = YesNoDialog:call("show", getLang("310040"), cc.CallFunc:create(callBack))
        else
            self.m_data.status = 2
            self.m_data.removeEndTime = 0
            CivFortressController:cancelRemoveCivFortress()
            self:call("closeSelf")
        end
    end
end

function CivFortressMoreView:update(dt)
    if self.m_data and self.m_data.status == 3 then
        local offset = self.m_data.removeEndTime - getTimeStamp()
        if offset > 0 then
            self.ui.m_removeLabel:setString(getLang("310100", format_time(offset)))
        end
    end
end

return CivFortressMoreView



