-------------------------------------------- YuanJunSoldierCell_lua Start --------------------------------------------
local YuanJunSoldierCell_lua = class("YuanJunSoldierCell_lua", function()
    return cc.Layer:create()
end)

function YuanJunSoldierCell_lua:create(type, data, raceType)
    local ret = YuanJunSoldierCell_lua.new()
    Drequire("game.CivFortress.YuanJunSoldierCell_lua_ui"):create(ret)
    if ret:initView(type, data, raceType) then
        return ret
    end
    return nil
end

function YuanJunSoldierCell_lua:initView(type, data, raceType)
    -- dump(data, )
    -- self.m_type = type
    self.ui.m_icon:removeAllChildren()
    if type == 1 then
        -- 龙
        local itemId = data.itemId
        local baseId = CCCommonUtilsForLua:call("getPropById", itemId, "base_id")
        local name = CCCommonUtilsForLua:call("getPropById", baseId, "name")
        self.ui.m_nameTxt:setString(getLang(name))

        local intimacy = tonumber(data.friendShip)
        local intimacyTotal = tonumber(CCCommonUtilsForLua:call("getPropById", itemId, "friendship"))
        local per = 0

        if intimacyTotal > 0 then
            per = intimacy * 100 / intimacyTotal;
        end
        local perStr = per.."%"
        self.ui.m_numTxt:setString(getLang("164330", perStr))

        local pic = CCCommonUtilsForLua:call("getPropById", baseId, "head_icon")..".png"
        local spr = CCLoadSprite:call("createSprite",pic)
        spr:setScale(0.7)
        self.ui.m_icon:addChild(spr)
        
        local lvStr = "Lv."..CCCommonUtilsForLua:call("getPropById", itemId, "level")
        self.ui.m_levelTxt:setString(lvStr)
    elseif type == 2 then
        -- 英雄
        local itemId = data.generalId
        local title = CCCommonUtilsForLua:call("getPropById", itemId, "title")
        local name = CCCommonUtilsForLua:call("getPropById", itemId, "name")
        self.ui.m_nameTxt:setString(getLang(title))
        self.ui.m_numTxt:setString(getLang(name))

        local spr = HeroManager.createHeroHead(itemId)
        spr:setScale(0.6)
        spr:setPositionY(-40)
        self.ui.m_icon:addChild(spr)

        local lvStr = "Lv."..data.level
        self.ui.m_levelTxt:setString(lvStr)
    elseif type == 3 then
        -- 士兵
        local armyId = data.armyId
        local name = ArmyController:call("getArmyNameById", armyId, raceType)
        local icon = ArmyController:call("getArmyIconById", armyId, raceType)
        local count = data.count

        self.ui.m_nameTxt:setString(name)
        self.ui.m_numTxt:setString(CC_CMDITOA(count))

        local star = tonumber(data.star)
        local pic = SoldierIconCell:call("create", icon, 88, armyId, true, star)
        if nil ~= pic then
            self.ui.m_icon:addChild(pic)
        end
        local num = CCCommonUtilsForLua:call("getPropById", armyId, "level")
        local pic1 = CCCommonUtilsForLua:call("getRomanSprite", tonumber(num))
        self.ui.m_icon:addChild(pic1)

    end

    return true
end

function YuanJunSoldierCell_lua:addSoldierList()
    
end

-------------------------------------------- YuanJunSoldierCell_lua End --------------------------------------------

return YuanJunSoldierCell_lua