local CivFortressUpgradeView = class("CivFortressUpgradeView",
    function()
        return PopupBaseView:create()
    end
)
CivFortressUpgradeView.__index = CivFortressUpgradeView
--------------------------------------- 消息部分逻辑 Start ---------------------------------------
local CivFortressUpCmd = class("CivFortressUpCmd", LuaCommandBase)
function CivFortressUpCmd.create(callBack)
    local ret = CivFortressUpCmd.new()
    ret._callBack = callBack
    ret:initWithName("civilizationCastle.upgrade")
    ret:putParam("point", CCInteger:create(676749))
    dump(" CivFortressUpCmd.create() ~~~~~~~~~~")
    return ret
end

function CivFortressUpCmd:handleReceive(dict)
    -- dump(" CivFortressUpCmd.handleReceive() ~~~~~~~~~~")
    local tbl, params = self:parseMsg(dict)
    dump(tbl, "CivFortressUpCmd:handleReceiv is: ")
    if type(tbl) == "boolean" then
        if self._callBack then
            self._callBack(false)
        end
        return tbl
    end

    if self._callBack then
        self._callBack(true, tbl.level)
    end
    
    GlobalDataCtr.updateResourceInfo(tbl.resource or {})
    if tbl.civilizationScore then
        CivilizationController:setCivilizationScore(tonumber(tbl.civilizationScore))
    end
    CCSafeNotificationCenter:call("postNotification", "CivFortressLevelupBack", params)
    return true
end
--------------------------------------- 消息部分逻辑 Ended ---------------------------------------
function CivFortressUpgradeView:create(curLevel, maxLevel)
    local view = CivFortressUpgradeView.new()
    Drequire("game.CivFortress.CivFortressUpgradeView_ui"):create(view, 0)
    if view:initView(curLevel, maxLevel) then
        return view
    end
end

function CivFortressUpgradeView:initView(curLevel, maxLevel)
    self:registerTouchFuncs()
    self.m_curLevel = curLevel
    self.m_maxLevel = maxLevel

    -- dump(" CivFortressUpgradeView:initView(level: "..tostring(level))
    self.ui.m_title:setString(getLang("310102"))

    for i = 3, 4 do
        local baseNode = self.ui["m_upInfoNode"..i]
        baseNode:getChildByTag(8):setString(getLang("102153"))
    end
    
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_levelUpBtn, getLang("102104"))     -- 102104=升级

    self:initDataRes()
    return true
end


function CivFortressUpgradeView:onEnter()
    dump("CivFortressUpgradeView:onEnter is: ")
    -- 获取数据
    -- registerScriptObserver(self, self.levelUpgradeBack, "CivFortressLevelupBack")
end

function CivFortressUpgradeView:onExit()
    dump("CivFortressUpgradeView:onExit is: ")
    -- unregisterScriptObserver(self, "CivFortressLevelupBack")
end

function CivFortressUpgradeView:initDataRes()
    local xmlData = CivFortressController:getCivFortressXmlData()
    local curLevelData = xmlData[self.m_curLevel]
    local nextLevelData = xmlData[self.m_curLevel + 1]

    if curLevelData == nil or nextLevelData == nil then
        return false
    end

    self.ui.m_civForLevelLbl:setString("Lv."..self.m_curLevel)

    -- 310041=每天产量(满采集、X级士兵)
    local maxGather = getLang("310041", CivFortressController.m_productOffTime)..(nextLevelData.day_output or "--")
    self.ui.m_tipsLbl:setString(maxGather)

    -- 文明堡垒限制
    local baseNode = self.ui.m_upInfoNode1
    local icon = CivFortressController:getCivFortressFigure()
    icon:setScale(0.3)
    icon:setPosition(cc.p(10, -10))
    baseNode:getChildByTag(1):removeAllChildren():addChild(icon)
    baseNode:getChildByTag(2):setString(getLang("31000"))
    baseNode:getChildByTag(3):setString(getLang("102272", self.m_curLevel + 1))
    local beTrue = (self.m_curLevel + 1) <= self.m_maxLevel
    baseNode:getChildByTag(5):setVisible(beTrue)
    baseNode:getChildByTag(6):setVisible(not beTrue)

    self.woodNeed = nextLevelData.wood - curLevelData.wood
    self.ironNeed = nextLevelData.iron - curLevelData.iron
    self.integralNeed = nextLevelData.integral - curLevelData.integral


    local function setInfo(index, name, needRes, curRes, beMore)
        local baseNode = self.ui["m_upInfoNode"..index]
        baseNode:getChildByTag(2):setString(name)       -- 名称
        local curLbl = baseNode:getChildByTag(3)
        local needLbl = baseNode:getChildByTag(4)
        curLbl:setString(CC_ITOA_K(curRes))
        needLbl:setString("/"..CC_ITOA_K(needRes))
        baseNode:getChildByTag(7):setVisible(false)
        baseNode:getChildByTag(8):setVisible(false)
        if curRes >= needRes then
            curLbl:setColor(cc.c3b(84, 50, 3))
            baseNode:getChildByTag(5):setVisible(true)
            baseNode:getChildByTag(6):setVisible(false)
        else
            curLbl:setColor(cc.c3b(255, 0, 0))
            baseNode:getChildByTag(5):setVisible(false)
            baseNode:getChildByTag(6):setVisible(true)
            if beMore then
                baseNode:getChildByTag(7):setVisible(true)
                baseNode:getChildByTag(8):setVisible(true)
            end
        end
        needLbl:setPositionX(curLbl:getPositionX() + curLbl:getContentSize().width)
    end

    -- 文明积分
    setInfo(2, getLang("191040"), self.integralNeed, CivilizationController:getCivilizationScore(), false)  
    -- 木
    setInfo(3, getLang("102209"), self.woodNeed, CCCommonUtilsForLua:call("getCurResourceByType", WorldResourceType.Wood), true)
    -- 铁
    setInfo(4, getLang("102210"), self.ironNeed, CCCommonUtilsForLua:call("getCurResourceByType", WorldResourceType.Iron), true)
    
    self.ui.m_levelUpBtn:setEnabled(true)
end

-- function CivFortressUpgradeView:update(dt)
-- end

function CivFortressUpgradeView:onTouchBegan(x, y)
    self.touchType = nil
    if not touchInside(self.ui.m_sprBG, x, y) then
        self.touchType = 1
    elseif touchInside(self.ui.m_getMoreSpr3, x, y) then
        self.touchType = 3
    elseif touchInside(self.ui.m_getMoreSpr4, x, y) then
        self.touchType = 4
    end

    return true
end

function CivFortressUpgradeView:onTouchMoved(x, y)

end

function CivFortressUpgradeView:onTouchEnded(x, y)
    if self.touchType == 1 and touchInside(self.ui.m_sprBG, x, y)==false then
        PopupViewController:call("removeLastPopupView")
    elseif self.touchType == 3 and touchInside(self.ui.m_getMoreSpr3, x, y) then
        PopupViewController:call("removeLastPopupView")
        local view = require("game.CommonPopup.UseResToolView"):create(WorldResourceType.Wood)
        PopupViewController:addPopupInView(view)
    elseif self.touchType == 4 and touchInside(self.ui.m_getMoreSpr4, x, y) then
        PopupViewController:call("removeLastPopupView")
        local view = require("game.CommonPopup.UseResToolView"):create(WorldResourceType.Iron)
        PopupViewController:addPopupInView(view)
    end
end

function CivFortressUpgradeView:onLvUpButtonClick()
    -- PopupViewController:call("removeLastPopupView")
    if self.woodNeed > CCCommonUtilsForLua:call("getCurResourceByType", WorldResourceType.Wood) then
        PopupViewController:call("removeLastPopupView")
        local view = require("game.CommonPopup.UseResToolView"):create(WorldResourceType.Wood)
        PopupViewController:addPopupInView(view)
        return false
    elseif self.ironNeed > CCCommonUtilsForLua:call("getCurResourceByType", WorldResourceType.Iron) then
        PopupViewController:call("removeLastPopupView")
        local view = require("game.CommonPopup.UseResToolView"):create(WorldResourceType.Iron)
        PopupViewController:addPopupInView(view)
        return false
    elseif self.integralNeed > CivilizationController:getCivilizationScore() then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("310096"))
        return false
    end

    self.ui.m_levelUpBtn:setEnabled(false)
    local function callBack(result, level)
        self.ui.m_levelUpBtn:setEnabled(true)
        if result then
            self:levelUpgradeBack(level)
        end
    end

    local cmd = CivFortressUpCmd.create(callBack)
    cmd:send()
end

function CivFortressUpgradeView:levelUpgradeBack(level)
    -- dump(self.m_curLevel, "self.m_curLevel is: ")
    -- dump(self.m_maxLevel, "self.m_maxLevel is: ")
    -- dump(level, "CivFortressUpgradeView:levelUpBack level is: ")
    self.m_curLevel = tonumber(level) or self.m_curLevel
    CCCommonUtilsForLua:call("flyHint", "", "", getLang("164826"))
    if self.m_curLevel == self.m_maxLevel then
        PopupViewController:call("removeLastPopupView")
        return
    else
        self:initDataRes()
    end
end

--------------------------------------------- 月卡模块End ---------------------------------------------------------
return CivFortressUpgradeView



