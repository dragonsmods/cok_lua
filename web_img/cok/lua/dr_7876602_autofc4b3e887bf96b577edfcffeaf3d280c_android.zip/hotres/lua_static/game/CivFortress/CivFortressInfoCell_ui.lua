----------------------------
-- Author: Elex
-- Date: 2017-09-12 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CivFortressInfoCell_ui = class("CivFortressInfoCell_ui")

--#ui propertys


--#function
function CivFortressInfoCell_ui:create(owner, viewType)
	local ret = CivFortressInfoCell_ui.new()
	CustomUtility:DoRes(305, true)
	CustomUtility:LoadUi("CivFortreessInfoCell.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CivFortressInfoCell_ui:initLang()
end

function CivFortressInfoCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CivFortressInfoCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return CivFortressInfoCell_ui

