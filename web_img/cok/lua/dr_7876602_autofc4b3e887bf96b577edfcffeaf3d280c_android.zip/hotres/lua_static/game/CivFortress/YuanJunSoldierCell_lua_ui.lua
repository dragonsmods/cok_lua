----------------------------
-- Author: Elex
-- Date: 2017-09-11 Monday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local YuanJunSoldierCell_lua_ui = class("YuanJunSoldierCell_lua_ui")

--#ui propertys


--#function
function YuanJunSoldierCell_lua_ui:create(owner, viewType)
	local ret = YuanJunSoldierCell_lua_ui.new()
	CustomUtility:DoRes(204, true)
	CustomUtility:LoadUi("YuanJunSoldierCell_lua.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function YuanJunSoldierCell_lua_ui:initLang()
end

function YuanJunSoldierCell_lua_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function YuanJunSoldierCell_lua_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return YuanJunSoldierCell_lua_ui

