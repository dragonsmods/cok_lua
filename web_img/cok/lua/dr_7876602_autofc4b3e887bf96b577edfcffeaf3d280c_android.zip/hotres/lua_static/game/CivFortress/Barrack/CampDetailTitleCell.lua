---
--- Created by pengzhou.
--- DateTime: 2018/5/24 下午4:45
---

local CampDetailTitleCell = class("CampDetailTitleCell", function()
    return cc.Layer:create()
end)

function CampDetailTitleCell:create(idx)
    local view = CampDetailTitleCell.new()
    Drequire("game.CivFortress.Barrack.CampDetailTitleCell_ui"):create(view, 0)
    return view
end

function CampDetailTitleCell:setTitle(name)
    self.ui.m_tagLabel:setString(name)
end

return CampDetailTitleCell