---
--- Created by pengzhou.
--- DateTime: 2018/5/24 下午4:22
---

local CampMainView = class("CampMainView",
function()
    return PopupBaseView:create()
end)

function CampMainView:create(info, isOccupied)
    local view = CampMainView.new()
    Drequire("game.CivFortress.Barrack.CampMainView_ui"):create(view, 0)
    if view:initView(info, isOccupied) == false then
        return nil
    end
    return view
end

--- "@@ CampMainView" = {
---     "campId"              = "30390002"
---     "flushTime"           = "1527681253376.0"
---     "lastCampIncomeTimes" = "5"
---     "resLevel"            = "3"
---     "startOccupyTime"     = "1527667097600.0"
---     "uid"                 = "11732000421"
--- }

function CampMainView:initView(info, isOccupied)

    self.info = info
    self.isOccupied = isOccupied
    Dprint("@@ CampMainView", isOccupied)
    dump(info,"@@ CampMainView")
    self:initTouchLayer()
    self:initNodeEvent()

    self:initConfig()
    self:initRewardList()

    self:initText()

    local spr = CCLoadSprite:call("createSprite", "yingdi.png")
    CCCommonUtilsForLua:setSpriteMaxSize(spr, 150)
    self.ui.m_picNode:addChild(spr)

end

function CampMainView:initConfig()
    self.id = self.info.campId
    self.m_rewardId     =   CCCommonUtilsForLua:getPropByIdGroup("camp_base",self.id, "per_reward")
    self.m_perReward    =   CCCommonUtilsForLua:getPropByIdGroup("camp_base",self.id, "random_reward")
    self.m_time         =   CCCommonUtilsForLua:getPropByIdGroup("camp_base",self.id, "times")
    self.m_perTime      =   CCCommonUtilsForLua:getPropByIdGroup("camp_base",self.id, "perlevel_time")


    self.m_perTime = tonumber(self.m_perTime) * 60
    --Dprint("@@ CampMainView",self.m_rewardId,self.m_perReward)
end

function CampMainView:initText()

    self.ui.m_titleLabel:setString(getLang("101517")) -- 101517=占领奖励

    self.ui.m_desLabel11:setString(getLang("101519") .. "  " .. self.m_time) -- 101519=总奖励次数
    self.ui.m_desLabel21:setString(getLang("150272", tostring(self.info.lastCampIncomeTimes))) -- 150272=剩余奖励：{0}
    self.ui.m_desLabel31:setString(getLang("101522") .. "  " .. format_time(self.m_perTime)) -- 101522=单波奖励时间


    self.ui.m_nextLabel:setString(getLang("101523")) -- 101523=下次奖励
    self.ui.m_tagLabel1:setString(getLang("101525")) -- 101525=固定奖励
    self.ui.m_tagLabel2:setString(getLang("101526")) -- 101526=随机奖励

    self.ui.m_tipsLabel:setString(getLang("101527")) -- 101527=提示：驻守完全结束后才会发放奖励


    --- 进度
    local beginTime = tonumber(self.info.startOccupyTime)
    if beginTime > 0 and self.isOccupied then
        self.ui.m_proNode:setVisible(true)
        self.ui.m_noLabel:setVisible(false)

        self:refreshCollectTime()
        self.scheduleEntry = self:getScheduler():scheduleScriptFunc(function (dt)
            self:scheduleLogic(dt)
        end, 1.0, false)

    else
        self.ui.m_proNode:setVisible(false)
        self.ui.m_noLabel:setString(getLang("101524")) -- 101524=暂无进度
    end
end

function CampMainView:refreshCollectTime()
    local nowTime       = getTimeStamp()
    local beginTime     = tonumber(self.info.startOccupyTime)
    local endTime       = beginTime / 1000 + self.m_perTime * tonumber(self.info.lastCampIncomeTimes)

    local lastTime      = endTime - nowTime

    local giveGiftTime  = math.floor(lastTime / self.m_perTime)
    local perLastTime   = lastTime -  giveGiftTime * self.m_perTime
    if perLastTime > 0 then
        giveGiftTime = giveGiftTime + 1
    end

    self.ui.m_numLabel:setString(format_time(perLastTime))
    --Dprint("@@ refreshCollectTime", beginTime, nowTime)
    --Dprint("@@ refreshCollectTime",self.info.lastCampIncomeTimes, giveGiftTime, math.floor(giveGiftTime))

    self.ui.m_desLabel21:setString(getLang("150272", tostring(giveGiftTime))) -- 150272=剩余奖励：{0}
    self.ui.m_proSprite:setScaleX(1 - perLastTime / self.m_perTime)
end

function CampMainView:scheduleLogic(dt)
    self:refreshCollectTime()
end

function CampMainView:initRewardList()

    local rwd = GlobalData:call("getCachedRewardData", self.m_rewardId)
    local rwdData = arrayToLuaTable(rwd)
    if #rwdData == 0 then
        GlobalData:call("checkAndRequestRewardData", self.m_rewardId)
        self.m_needOpenRewardView = true
        Dprint("@@ initRewardList false",self.m_rewardId)
    else
        self.ui:setTableViewDataSource("m_listTableView1", rwdData)
    end


    local rwd = GlobalData:call("getCachedRewardData", self.m_perReward)
    local rwdData2 = arrayToLuaTable(rwd)
    if #rwdData2 == 0 then
        GlobalData:call("checkAndRequestRewardData", self.m_perReward)
        self.m_needOpenRewardView2 = true
        Dprint("@@ initRewardList false",self.m_perReward)
    else
        self.ui:setTableViewDataSource("m_listTableView2", rwdData2)
    end
end

function CampMainView:refreshRewardList()

    Dprint("@@ CampMainView initRewardList" ,self.m_rewardId,self.m_perReward)
    if self.m_needOpenRewardView  then
        local rwd = GlobalData:call("getCachedRewardData", self.m_rewardId)
        local rwdData = arrayToLuaTable(rwd)
        if #rwdData > 0 then
            self.ui:setTableViewDataSource("m_listTableView1", rwdData)
            self.m_needOpenRewardView = false
        end
    end

    if self.m_needOpenRewardView2  then
        local rwd = GlobalData:call("getCachedRewardData", self.m_perReward)
        local rwdData2 = arrayToLuaTable(rwd)
        if #rwdData2 > 0 then
            self.ui:setTableViewDataSource("m_listTableView2", rwdData2)
            self.m_needOpenRewardView2 = false
        end
    end
end

function CampMainView:initNodeEvent()
    local function onNodeEvent(event)
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(onNodeEvent)
end


function CampMainView:onEnter()
    registerScriptObserver(self, self.refreshRewardList, MSG_GET_REWARD_DETAIL_BACK)
end

function CampMainView:onExit()
    unregisterScriptObserver(self, MSG_GET_REWARD_DETAIL_BACK)

    if self.scheduleEntry then
        self:getScheduler():unscheduleScriptEntry(self.scheduleEntry)
        self.scheduleEntry = nil
    end
end


function CampMainView:initTouchLayer()
    self.touchLayer = cc.Layer:create()
    self:addChild(self.touchLayer)

    local function touchHandle( eventType, x, y )
        if eventType == "began" then
            return self:onTouchBegan(x, y)
        elseif eventType == "moved" then
            self:onTouchMoved(x, y)
        else
            self:onTouchEnded(x, y)
        end
    end

    self.touchLayer:registerScriptTouchHandler(touchHandle)
    self.touchLayer:setTouchEnabled(true)
    self.touchLayer:setSwallowsTouches(false)
end

function CampMainView:onTouchBegan(x, y)
    if not isTouchInside(self.ui.m_touchNode,x,y) then
        return true
    end

    return false
end

function CampMainView:onTouchMoved(x, y)

end

function CampMainView:onTouchEnded(x, y)
    if not isTouchInside(self.ui.m_touchNode,x,y) then
        PopupViewController:call("getInstance"):call("goBackPopupView")
    end
end

return CampMainView