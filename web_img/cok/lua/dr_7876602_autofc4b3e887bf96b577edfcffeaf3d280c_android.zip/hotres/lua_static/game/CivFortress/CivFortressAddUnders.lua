local CivFortressAddUnders = class("CivFortressAddUnders", function (  )
	return cc.Layer:create()
end)

function CivFortressAddUnders:ctor(cityInfo, dataMap, index )
    -- dump(dataMap, "CivFortressAddUnders ctor ~~~~~~~~")
	self.m_dataMap = dataMap
	self.m_index = index
	self.m_playerName = cityInfo:getProperty("playerName")
	self.m_leagueAsn = cityInfo:getProperty("leagueAsn")
	self.m_allianceId = cityInfo:getProperty("allianceId")
    self.tileServerId = cityInfo:getProperty("tileServerId") -- 地块所属服务器ID
	
	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	local myAllianceId = playerInfo:call("getAllianceId")
    local myUid = playerInfo:getProperty("uid")
	local beSelf = myUid == dataMap.uid 		-- 是否自己
	local beMyAli = self.m_allianceId == myAllianceId 		-- 是否自己的联盟

    self.m_beSelf = beSelf
    if beSelf then
        dataMap.lastSettleTime = (tonumber(dataMap.lastSettleTime) or 0)/1000
    end

    dataMap.removeEndTime = (tonumber(dataMap.removeEndTime) or 0)/1000
    if dataMap.removeEndTime > 0 then
        dataMap.status = 3
    else
        dataMap.status = tonumber(dataMap.status)
    end

    local tblParams={["civFortStatus"]=dataMap.civFortStatus}
	local sprNode, sprType = CivFortressController:getCivFortressFigureEx(tblParams)
    if not dataMap.civFortStatus or dataMap.civFortStatus == "0" then
        sprNode:setScale(1.4)
    end
	self:addChild(sprNode)

    -- 建造中
    if dataMap.status == 1 then
        local build = AAreaBuildCCB:call("create")
        build:call("setCCBName", "WordBuild")
        build:setPosition(cc.p(-20, 30))
        build:setTag(952)
        build:setScaleY(0.9)
        self:addChild(build)
    end

    --------------------------- 上方收入底板
    if dataMap.status ~= 1 then
        local upNode = cc.Node:create()
        self:addChild(upNode)
        self.m_upNode = upNode
        upNode:setPosition(cc.p(0, 20))
        local spr = CCLoadSprite:call("createSprite", "frame_02png.png")
    	spr:setScaleX(1.2)
    	spr:setScaleY(0.8)
    	upNode:addChild(spr)

    	-- 名字
    	local label = cc.Label:create()
        label:setAnchorPoint(cc.p(0.5, 0.5))
        label:setSystemFontSize(20)
        label:setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
        label:setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
        upNode:addChild(label)
        self.m_jieJingLabel = label

        local level = tonumber(dataMap.level)
        local xmlData = CivFortressController:getCivFortressXmlData()
        if xmlData[level] then
            self.maxJiejingNum = tonumber(xmlData[level].storage_ceiling)
            if CivFortressController.m_package_coupon then
                self.maxJiejingNum = tonumber(xmlData[level].storage_ceiling_2)
            end

        	local resNum = math.floor(dataMap.resourceNum).."/"..self.maxJiejingNum
        	upNode:setVisible(true)
        	label:setString(resNum)
        	if beSelf == false and tonumber(dataMap.beRobNum) >= (tonumber(xmlData[level].plunder_number) or 0) then
        		label:setColor(cc.c3b(255, 0, 0))
        	else
        		label:setColor(cc.c3b(0, 255, 0))
        	end

            local pic = CCLoadSprite:call("createSprite", "jiejing001.png")
            upNode:addChild(pic)
            pic:setPositionX(-20 - label:getContentSize().width * 0.5 )
            CCCommonUtilsForLua:setSpriteMaxSize(pic, 30, true)
        else
        	upNode:setVisible(false)
        end
    end

    --------------------------- 下方底板
    local downNode = cc.Node:create()
    self:addChild(downNode)
    downNode:setPosition(cc.p(0, -20))
    -- 名字底板
	local spr = CCLoadSprite:call("createSprite", "frame_02png.png")
	spr:setScaleX(1.2)
	spr:setScaleY(0.8)
	downNode:addChild(spr)

	-- 名字
	local label = cc.Label:create()
    label:setAnchorPoint(cc.p(0.5, 0.5))
    label:setSystemFontSize(20)
    -- label:setColor(cc.c3b(255, 234, 188))
    label:setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    label:setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
    downNode:addChild(label)
    self.label = label

    local text = getLang("310033", self.m_playerName)
    if self.m_allianceId ~= "" then
    	text = "("..self.m_leagueAsn..") "..text
    end
    self.m_playerName = text

    if dataMap.status == 1 then
    	text = text.."("..getLang("115305")..")"
    elseif dataMap.status == 3 then
        text = text.."("..getLang("165427")..")"
    end
    label:setString(text)

    -- 文字颜色怎么弄？
    if self.m_allianceId == myAllianceId then
    	-- 自己或者己方联盟
    	self.label:setColor(cc.c3b(0, 253, 255))
    else
    	self.label:setColor(cc.c3b(242, 237, 222))
    end

    local function onNodeEvent( event )
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(onNodeEvent)
    registerTouchHandler(self)
    self:setTouchEnabled(true)
    self:setSwallowsTouches(true)
    self.hasTouched = false

    -- dump("CivFortressAddUnders ctor ended ")
end

function CivFortressAddUnders:onEnter(  )
	-- dump("CivFortressAddUnders onEnter ~~~~~~~~ ended ") 
	-- self:onEnterFrame()
    if self.m_beSelf or self.m_dataMap.status == 3 then
        self.canReward = false
    	self.entry = self:getScheduler():scheduleScriptFunc(function(dt) self:update(dt) end, 1, false)
    end
    -- if self.m_beSelf then
    --     registerScriptObserver(self, self.removeNotify, "msg_civfortress_remove")
    -- end
    registerScriptObserver(self, self.updateSelf, "msg_civfortress_beAttack_update")
end

function CivFortressAddUnders:onExit(  )
	-- dump("CivFortressAddUnders onExit ~~~~~~~~~~~~ ended ") 
    unregisterScriptObserver(self, "msg_civfortress_beAttack_update")
    -- if self.m_beSelf then
    --     unregisterScriptObserver(self, "msg_civfortress_remove")
    -- end
	-- self:getScheduler():unscheduleScriptEntry(self.entry)

    if self.entry then
        self:getScheduler():unscheduleScriptEntry(self.entry)        
    end
end

function CivFortressAddUnders:update(dt)
    if self.m_beSelf and self.canReward == false then
        if self.m_dataMap.status == 2 then
            local offsetTime = 0
            if self.m_dataMap.lastSettleTime > 0 then
                offsetTime = self.m_dataMap.lastSettleTime + CivFortressController.m_productRewardTime - getTimeStamp()
            end
            if offsetTime <= 0 then
                if math.floor(tonumber(self.m_dataMap.resourceNum)) > 0 then
                    self.canReward = true
                    self:addshakedNode()
                end
            end
        end
    end

    local dataMap = self.m_dataMap
    if dataMap.status == 3 then
        local offset = dataMap.removeEndTime - getTimeStamp()
        if offset >= 0 then
            local text = self.m_playerName.."\n("..getLang("310100", format_time(offset))..")"
            self.label:setString(text)
        else
            dataMap.status = 0
            if self.beSelf then
                CivFortressController:syncRemoveData()
            end
            self:removeFromParent()

            CCSafeNotificationCenter:call("postNotification", "MSG_MAP_UPDATE_SINGLE", CCInteger:create(self.m_index))
            -- CCSafeNotificationCenter:call("postNotification", "MSG_MAP_UPDATE")
        end
    end
end

function CivFortressAddUnders:addshakedNode()
    if self.m_shakeNode == nil then
        self.m_shakeNode = cc.Node:create()
        self.m_shakeNode:setAnchorPoint(cc.p(0.5, 0))
        self.m_shakeNode:setContentSize(cc.size(100, 100))
        self.m_shakeNode:setPosition(cc.p(0, 110))
        self:addChild(self.m_shakeNode)

        local bg = CCLoadSprite:call("createSprite", "res_btn.png")
        self.m_shakeNode:addChild(bg)
        bg:setAnchorPoint(cc.p(0.5, 0))
        bg:setPosition(cc.p(50, 0))
        bg:setScale(1.4)

        local pic = CCLoadSprite:call("createSprite", "jiejing001.png")
        self.m_shakeNode:addChild(pic)
        pic:setAnchorPoint(cc.p(0.5, 0))
        pic:setPosition(cc.p(50, 25))
        pic:setScale(0.8)
        -- pic:setRotation(10)
        -- pic:setPositionX(-20 - label:getContentSize().width * 0.5 )
        -- CCCommonUtilsForLua:setSpriteMaxSize(pic, 30, true)
            
    end

    self.m_shakeNode:stopAllActions()

    local rt0 = cc.RotateTo:create(0.01, 0)
    local rt1 = cc.RotateTo:create(0.1, 15)
    local rt2 = cc.RotateTo:create(0.1, -30)
    local rt3 = cc.RotateTo:create(0.1, 22)
    local rt4 = cc.RotateTo:create(0.1, -14)
    local rt5 = cc.RotateTo:create(0.1, 7)
    local dt = cc.DelayTime:create(2)
    local seq = cc.Sequence:create(rt0, rt1, rt2, rt3, rt4, rt5, dt)
    self.m_shakeNode:runAction(cc.RepeatForever:create(seq))
end

function CivFortressAddUnders:removeshakedNode()
    if self.m_shakeNode then
        self.m_shakeNode:removeFromParent()
        self.m_shakeNode = nil
    end
    self.canReward = false
end

function CivFortressAddUnders:updateSelf(ref)
    if not ref then
        dump(ref, "CivFortressAddUnders:updateSelf ref")
        return
    end

    local point = ref:getValue()
    if not point then
        return
    end

    if point ~= tonumber(self.m_dataMap.pointId) then
        return
    end

    if self.hasQuit then
        return
    end

    local function dataBack(data)
        if data.status == 2 and self.m_jieJingLabel and self.maxJiejingNum then
            self.m_jieJingLabel:setString(math.floor(data.resourceNum).."/"..self.maxJiejingNum)
        end
        if data.def == "0" then
            self.hasQuit = true
            self:stopAllActions()
            local delay = cc.DelayTime:create(5)
            local fadeOutAction = cc.FadeOut:create(1)
            local function callback() self:removeFromParent() end
            local func = cc.CallFunc:create(callback)
            local seq = cc.Sequence:create(delay, fadeOutAction, func)
            self:runAction(seq)
        end
    end
    CivFortressController:getOtherCivFortressInfo(self.m_dataMap.uid, self.tileServerId, dataBack)
end

function CivFortressAddUnders:onEnterFrame(  )

end

function addCivFortressUnders( index )
	-- dump("local function addCivFortressUnders")
	local world = WorldMapView:call("instance")
	if nil == world then
		return nil
	end
	local cityInfo = WorldController:call("getCityInfoByIndex", index)
	if nil == cityInfo then
    	dump("cityInfo is nil ~~~")
		return nil
	end

	-- dump(cityInfo:getProperty("luaType"), "local function addCivFortressUnders 333333333333333 luaType is: ")
	if cityInfo:getProperty("luaType") ~= WorldCityType.Civilization_castle then
    	dump("cityInfo is nil ~~~")
		return nil
	end

	local dataMap = cityInfo:call("getLuaMap")
    if dataMap == nil then
    	dump("dataMap is nil ~~~")
    	return nil
    end
    -- dump(dataMap, "addCivFortressUnders dataMap is: ")

	local ret = CCArray:create()

	local pos = cityInfo:call("GetPositionInMap")
	local under = CivFortressAddUnders.new(cityInfo, dataMap, index)
	under:setTag(index)
	under:setPosition(cc.p(pos.x, pos.y))
	ret:addObject(under)
	world:call("getCityBatchNode"):addChild(under)

	return ret
end

function CivFortressAddUnders:onTouchBegan(x, y)
    self.m_touchType = -1
    if self.m_beSelf and self.canReward
        and self.m_shakeNode 
        and self.m_shakeNode:isVisible()
        and touchInside(self.m_shakeNode, x, y)
        and self.hasTouched == false
        then
        self.m_touchType = 1
        self.hasTouched = true
        return true
    end
end

function CivFortressAddUnders:onTouchEnded(x, y)
    if self.m_touchType == 1 
        and self.m_shakeNode  
        and touchInside(self.m_shakeNode, x, y)
        then
        local function callBack(data)
            -- dump("CivFortressInfoView is: ")
            local num = tonumber(data.gainCount)
            self.m_dataMap.lastSettleTime = (tonumber(data.lastSettleTime) or 0)/1000
            self.m_dataMap.resourceNum = 0
            CivFortressController.m_data.resourceNum = 0
            self:removeshakedNode()
            local reward = {
                {
                    type = "7",
                    value = {
                        itemId = CivFortressController.m_productId,
                        num = tostring(num),
                    },
                },
            }
            local rwdArr = luaToArray(reward)    
            PortActController:call("flyReward", rwdArr, false)
        end
        CivFortressController:settleCivFortress(callBack)
    end
end

-- 移除通知
-- function CivFortressAddUnders:removeNotify()
--     local newData = CivFortressController:getCivFortressInfo()
--     self.m_dataMap.status = newData.status
--     self.m_dataMap.removeEndTime = newData.removeEndTime
--     self:update()
-- end
return CivFortressAddUnders