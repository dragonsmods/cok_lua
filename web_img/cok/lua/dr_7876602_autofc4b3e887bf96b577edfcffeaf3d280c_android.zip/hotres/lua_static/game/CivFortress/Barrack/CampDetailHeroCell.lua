---
--- Created by pengzhou.
--- DateTime: 2018/5/24 下午4:46
---

local CampDetailHeroCell = class("CampDetailHeroCell", function()
    return cc.Layer:create()
end)

function CampDetailHeroCell:create()
    local view = CampDetailHeroCell.new()
    Drequire("game.CivFortress.Barrack.CampDetailHeroCell_ui"):create(view, 0)
    return view
end

function CampDetailHeroCell:setData(heroId , level)
    self.ui.m_lvLabel:setString(level)

    local name  = CCCommonUtilsForLua:getPropByIdGroup("general_base",heroId, "name")
    local picName = CCCommonUtilsForLua:getPropByIdGroup("general_base",heroId, "pic")..".png"
    --Dprint("@@ ",picName)
    local headIcon = CCLoadSprite:call("createSprite", picName)
    CCCommonUtilsForLua:setSpriteMaxSize(headIcon, 80)
    self.ui.m_headNode:removeAllChildren()
    self.ui.m_headNode:addChild(headIcon)

    self.ui.m_nameLabel:setString(getLang(name))
end

return CampDetailHeroCell