 local CivFortressStatusView = class("CivFortressStatusView",
	function()
		return PopupBaseView:create() 
	end
)
CivFortressStatusView.__index = CivFortressStatusView

function CivFortressStatusView:create()
    local view = CivFortressStatusView.new()
    Drequire("game.CivFortress.CivFortressStatusView_ui"):create(view, 0)
    if view:initView() then
        return view
    end
end


function CivFortressStatusView:initView()
	local viewSize = self:getContentSize()
	CCCommonUtilsForLua:call("makeBatchBG", self.ui.m_bgNode, viewSize, ccp(0, 0), 1)

	local xmlData = CCCommonUtilsForLua:getGroupByKey("civilization_buff")
	self.m_data = {}
	for key, data in pairs(xmlData) do
		local tmpStatus = string.split(data.status, "|")
		local statusType = tonumber(CCCommonUtilsForLua:call("getPropByIdGroup", "status", tmpStatus[1], "type2"))
		data.type = statusType
		data.statusTbl = tmpStatus
		self.m_data[#self.m_data + 1] = data
	end
	table.sort(self.m_data, function(a, b)
			return (tonumber(a.order) or 0 ) < (tonumber(b.order) or 0 )
		end)

	self.ui:setTableViewDataSource("m_pTableView1", self.m_data)

	self:registerTouchFuncs()
	return true
end

function CivFortressStatusView:onEnter()
	self:setTitleName(getLang("104953"))
end

function CivFortressStatusView:onExit()
	-- body
end

function CivFortressStatusView:onTouchBegan(x, y)
    return true
end

function CivFortressStatusView:onTouchMoved(x, y)
end

function CivFortressStatusView:onTouchEnded(x, y)
end
function CivFortressStatusView:updateInfo(dict)
	-- local miny = self.m_tableView:minContainerOffset().y
	-- local pos = self.m_tableView:getContentOffset()
	
	-- dump(self.m_statusIdItems, " status id items :")
	self.ui:setTableViewDataSource("m_pTableView1", self.m_statusIdItems)
	-- self.m_tableView:reloadData()

	-- local mincurry = self.m_tableView:minContainerOffset().y
	-- pos.y = pos.y - miny + mincurry
	-- self.m_tableView:setContentOffset(pos)
end

function CivFortressStatusView:tableCellTouched(tab, cell)
	if (cell and cell.touchEnable) then
		local info = cell:getInfo()
		local typeNameS = getLang(info.name)
		local description = getLang(info.tips)

		local flag = true
		local _type = info.type
		local params = {
			statusTbl = info.statusTbl
		}
		local view = Drequire("game.CommonPopup.UseItemStatusView"):create(_type, typeNameS, description, flag, params)
		PopupViewController:addPopupInView(view)
	end
end

return CivFortressStatusView