local CivFortressInfoView = class("CivFortressInfoView",
    function()
        return PopupBaseView:create()
    end
)
CivFortressInfoView.__index = CivFortressInfoView

-- local beInit = false
function CivFortressInfoView:create(dataMap, serverId, index)
    local view = CivFortressInfoView.new()
    Drequire("game.CivFortress.CivFortressInfoView_ui"):create(view, 1)
    if view:initView(dataMap, serverId, index) then
        return view
    end
end

function CivFortressInfoView:initView(dataMap, serverId, index)
    -- dump(dataMap, "CivFortressInfoView:initView+++")
    local world = WorldMapView:call("instance")
    if nil == world then
        return false
    end
    local cityInfo = WorldController:call("getCityInfoByIndex", index)
    if nil == cityInfo then
        dump("cityInfo is nil ~~~")
        return false
    end
    self.serverId = serverId
    local xmlData = CivFortressController:getCivFortressXmlData()
    local fortressData = xmlData[tonumber(dataMap.level)]
    if fortressData == nil then
        dump(" not fortressData data")
        return false
    end

    dataMap.status = tonumber(dataMap.status)
    dump(dataMap, "CivFortressInfoView initView dataMap is: ")
    self.m_dataMap = dataMap
    self.m_fortressData = fortressData
    self.cityIndex = index
    self.m_playerName = cityInfo:getProperty("playerName")
    self.m_leagueAsn = cityInfo:getProperty("leagueAsn")
    self.m_allianceId = cityInfo:getProperty("allianceId")

    -- self:setTitleName(getLang("310033", self.m_playerName))
    self.ui.m_titleTxt:setString(getLang("310033", self.m_playerName))
    local tblParams={["civFortStatus"]=dataMap.civFortStatus,["isUsedInfoView"]=true }
    local figureNode, sprType = CivFortressController:getCivFortressFigureEx(tblParams)
    self.ui.m_picNode:addChild(figureNode)
    figureNode:setPositionY(-100)

    self.ui.m_tipsLabel:setString(getLang("310017"))
    self.ui.m_minuteLabel1:setString(getLang("310002", CivFortressController.m_productOffTime))    -- 310002=每10分钟结晶产量:
    self.ui.m_allLabel1:setString(getLang("310013"))           -- 310013=堡垒内结晶数量:
    self.ui.m_timeLabel1:setString(getLang("310014"))         --310014=获取结晶剩余时间:
    self.ui.m_defenseLabel1:setString(getLang("310015"))       -- 310015=堡垒城防值:
    self.ui.m_peopleLabel1:setString(getLang("310032"))       -- 310032=可参与采集的士兵数:

    -- self.ui.m_levelLabel:setString("Lv."..dataMap.level)

    self.ui.m_upLabel:setString(getLang("building_clickbtn_speedup"))

    -- self.ui.m_getBtn:setVisible(false)
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_getBtn, getLang("138029"))     -- 领取
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_cancelButton, getLang("135002"))     -- 取消建造

    -- self:initBaseInfo()
    require "game.particle.ParticleFireAni"
    local par = ParticleFireAni:create()
    self.ui.m_fireNode1:addChild(par)
    local par = ParticleFireAni:create()
    self.ui.m_fireNode2:addChild(par)
    
    self.beSelf = false
    self.beMyAli = false
    self.ui.m_getBaseNode:setVisible(false)
    self.ui.m_enterButton:setVisible(false)
    self.ui.m_buttonNode2:setVisible(false)
    self.ui.m_levelUpNode:setVisible(false)
    self.ui.m_buttonNode3:setVisible(false)
    self.hasInit = false
    self.needGold = nil

    return true
end

function CivFortressInfoView:onEnter()
    self:getInfoData()
    registerScriptObserver(self, self.getSppedUpBack, "CivFortressSpeedupBack")
    registerScriptObserver(self, self.levelUpBack, "CivFortressLevelupBack")

    -- 获取数据
    self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:update(dt) end, 1.0, false)
end

function CivFortressInfoView:onExit()
    unregisterScriptObserver(self, "CivFortressSpeedupBack")
    unregisterScriptObserver(self, "CivFortressLevelupBack")

    self:getScheduler():unscheduleScriptEntry(self.m_entryId)
end

function CivFortressInfoView:getSppedUpBack()

end

function CivFortressInfoView:levelUpBack(dict)
    -- dump(dict, "CivFortressInfoView:levelUpBack dict is: ")
    if dict == nil or not self.beSelf then
        return
    end
    local tbl = dictToLuaTable(dict)
    -- dump(tbl, "CivFortressInfoView:levelUpBack tbl is: ")

    local data = self.m_dataMap
    data.level = tonumber(tbl.level)
    data.output = tonumber(tbl.output)
    local xmlData = CivFortressController:getCivFortressXmlData()
    local fortressData = xmlData[data.level]
    if fortressData == nil then
        dump(" not fortressData data")
        return false
    end
    self.m_fortressData = fortressData
    self:initBaseInfo()
    
end


function CivFortressInfoView:getInfoData()
    -- dump("getInfoData ~~~~~~~")
    local function dataBack(data)
        local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
        local myUid = playerInfo:getProperty("uid")
        -- dump(data, " CivFortressInfoView getinfoData")
        -- dump(myUid, " CivFortressInfoView getinfo myUid")
        if data.uid == myUid then
            -- 如果是自己的同步下数据
            self.beSelf = true
            CivFortressController.m_data = data
            self.beMyAli = true
        else
            self.beSelf = false
            local myAllianceId = playerInfo:call("getAllianceId")
            -- dump(myAllianceId, " CivFortressInfoView getinfo myAllianceId")
            if self.m_allianceId == myAllianceId then
                self.beMyAli = true
            else
                self.beMyAli = false
            end
        end
        self.hasInit = true
        self:getDataBack(data)
    end
    self.hasInit = false
    dump("CivFortressInfoView:getInfoData:fubin "..self.serverId)
    CivFortressController:getOtherCivFortressInfo(self.m_dataMap.uid, self.serverId, dataBack)
end

function CivFortressInfoView:updateBuildTime()
    if self.hasInit == false then
        return 
    end
    local data = self.m_dataMap
    if data.status == 1 then
        -- 建造中
        self.ui.m_ingNode:setVisible(true)
        self.ui.m_stateLabel:setVisible(false)
        self.ui.m_ingLabel1:setString(getLang("115305"))
        
        local buildTime = data.buildTime
        if buildTime > 0 then
            local endTime = buildTime
            local offset = endTime - getTimeStamp()
            self.ui.m_ingLabel2:setString(format_time(offset))

            local needGold = CCCommonUtilsForLua:call("getGoldByTime",offset)
            self.ui.m_goldNumLabel1:setString(needGold)

            self.needGold = needGold

        elseif self.hasInit == true then
            self:getInfoData()
        end
    elseif data.status == 2 then
        -- 已完成
        self.ui.m_ingNode:setVisible(false)
        self.ui.m_stateLabel:setVisible(true)
        if data.defArmy and data.defArmy ~= "" then
            self.ui.m_stateLabel:setString(getLang("310011"))
        else
            self.ui.m_stateLabel:setString(getLang("310012"))
        end

        -- 获取剩余时间
        local lastOutputTime = data.lastOutputTime

        if lastOutputTime > 0 then
            local endTime = lastOutputTime + (CivFortressController.m_productOffTime * 60)
            local offset = endTime - getTimeStamp()
            if offset > 0 then
                self.ui.m_timeLabel2:setString(format_time(offset))
            elseif self.hasInit == true then
                self:getInfoData()
            end
        end

        self:updateUserData()
    elseif data.status == 3 then
        -- 拆除中
        local offset = data.removeEndTime - getTimeStamp()
        if offset > 0 then
            self.ui.m_removeTime:setString(getLang("310100", format_time(offset)))
            -- self.ui.m_removeTime:setString("@孙博， 拆除时间: **.**.** ")
        else
            data.status = 0
            self:call("closeSelf")
        end
    end
end

function CivFortressInfoView:updateUserData( ... )
    if self.beSelf and self.m_dataMap.status == 2 then
        -- 自己
        self.ui.m_getBaseNode:setVisible(true)
        self.ui.m_getTimeLabel:setVisible(false)
        local offsetTime = 0
        local beEnabled = false
        local timeStamp = getTimeStamp()
        if self.m_dataMap.lastSettleTime > 0 then
            offsetTime = self.m_dataMap.lastSettleTime + CivFortressController.m_productRewardTime - timeStamp
        end
        
        if offsetTime <= 0 then
            offsetTime = 0
            if math.floor(tonumber(self.m_dataMap.resourceNum)) > 0 then
                self.ui.m_getBtn:setEnabled(true)
            else
                self.ui.m_getBtn:setEnabled(false)
            end
            CCCommonUtilsForLua:setButtonTitle(self.ui.m_getBtn, getLang("138029"))
        else
            self.ui.m_getTimeLabel:setVisible(true)
            self.ui.m_getBtn:setEnabled(false)
            CCCommonUtilsForLua:setButtonTitle(self.ui.m_getBtn, "")
        end
        self.ui.m_getTimeLabel:setString(format_time(offsetTime))

        self.ui.m_minuteLabel3:setString(getLang("310098")..format_time(timeStamp - self.m_dataMap.lastSettleTime))
    else
        self.ui.m_getBaseNode:setVisible(false)
    end
end

function CivFortressInfoView:initBaseInfo()
    local data = self.m_dataMap
    self:updateBuildTime()
    self.ui.m_levelLabel:setString("Lv."..data.level)
    -- self.ui.m_minuteLabel2:setString(data.output)       -- 每5分钟产出
    local output = string.format("%.2f", data.output)
    self.ui.m_minuteLabel2:setString(output)       -- 每5分钟产出
    if (CCCommonUtilsForLua:isFunOpenByKey("civilization_fortress_v3_on")) then
        self.ui.m_minuteLabel3:setVisible(true)
        self.ui.m_minuteLabel3:setPositionX(self.ui.m_minuteLabel2:getPositionX() + self.ui.m_minuteLabel2:getContentSize().width + 4)
    else
        self.ui.m_minuteLabel3:setVisible(false)
    end

    self.ui.m_defenseLabel2:setString(data.def)       -- 堡垒城防值
    local defNum = tonumber(data.def) or 0
    self.ui.m_defenseLabel2:setString(defNum.."/"..self.m_fortressData.value_f)    

    if self.beMyAli then
        local hisTroopNums = 0
        for i, troop in pairs(data.army or {}) do
            if troop.uid == data.uid then
                hisTroopNums = tonumber(troop.totalTroops)
                break
            end
        end
        local soldier_max = tonumber(self.m_fortressData.soldier_max)
        if hisTroopNums > soldier_max then
            hisTroopNums = soldier_max
        end
        self.ui.m_peopleLabel2:setString(hisTroopNums.."/"..self.m_fortressData.soldier_max)
    else
        self.ui.m_peopleLabel2:setString("******/"..self.m_fortressData.soldier_max)
    end

    local storage_ceiling = self.m_fortressData.storage_ceiling
    if CivFortressController.m_package_coupon then
        storage_ceiling = self.m_fortressData.storage_ceiling_2
    end
    self.ui.m_allLabel2:setString(math.floor(tonumber(self.m_dataMap.resourceNum)).."/"..storage_ceiling)         -- 当前产量
    self:updateUserData()

    self.ui.m_enterButton:setPositionX(0)
    self.ui.m_moveNode:setVisible(false)
    if self.beSelf then
        if data.status == 1 then
            self.ui.m_enterButton:setVisible(false)
            self.ui.m_buttonNode1:setVisible(false)
            self.ui.m_buttonNode2:setVisible(true)
            self.ui.m_buttonNode3:setVisible(false)
        elseif data.status == 2 then
            self.ui.m_enterButton:setVisible(true)
            self.ui.m_buttonNode1:setVisible(true)
            self.ui.m_buttonNode3:setVisible(false)
            if (CCCommonUtilsForLua:isFunOpenByKey("civilization_fortress_v3_on")) then
                self.ui.m_enterButton:setPositionX(-135)
                self.ui.m_moveNode:setVisible(true)
                self.ui.m_moveItemLbl:setString(getLang("139082"))
                -- CCCommonUtilsForLua:setButtonTitle(self.ui.m_moveButton, getLang("139082"))     -- 115333=驻守
                local icon = CCCommonUtilsForLua:getPropByIdGroup("goods", tostring(CivFortressController.m_productMoveId), "icon")
                self.ui.m_moveItemIcon:removeAllChildren()
                local spr = CCLoadSprite:call("createSprite", icon..".png")
                if spr then
                    self.ui.m_moveItemIcon:addChild(spr)
                    CCCommonUtilsForLua:setSpriteMaxSize(spr, 30, true)
                end
                -- dump(CivFortressController.m_productMoveId, "CivFortressController.m_productMoveId is: ")
                local tinfo = ToolController:call("getToolInfoForLua", tonumber(CivFortressController.m_productMoveId))
                local count = 0
                if tinfo then 
                    count = tinfo:call("getCNT")
                end
                self.ui.m_moveItemNums:setString("X"..tostring(count))
                if count > 0 then
                    self.ui.m_moveButton:setEnabled(true)
                else
                    self.ui.m_moveButton:setEnabled(false)
                end

                local m_info = FunBuildController:call("getInstance"):call("getFunbuildForLua", 443000072) --FunBuildInfo
                local m_info_level = m_info:getProperty("level")
                if m_info_level > data.level then
                    self.ui.m_levelUpNode:setVisible(true)
                end
            end
            self.ui.m_buttonNode2:setVisible(false)
            -- 是否有部队驻守
            local text = getLang("108572")  -- 108572=返回
            if not self:checkHasMyTroop() then
                text = getLang("115333")
            end
            CCCommonUtilsForLua:setButtonTitle(self.ui.m_enterButton, text)     -- 115333=驻守
        elseif data.status == 3 then
            -- 拆除中
            self.ui.m_buttonNode1:setVisible(false)
            self.ui.m_buttonNode2:setVisible(false)
            self.ui.m_buttonNode3:setVisible(true)

            -- self.ui.m_removeTime:
        end
    else
        self.ui.m_enterButton:setVisible(true)
        self.ui.m_buttonNode2:setVisible(false)
        self.ui.m_buttonNode3:setVisible(false)
        local text = getLang("108572")
        if self.beMyAli then
            -- 如果有无驻守部队
            if not self:checkHasMyTroop() then
                text = getLang("115333")
            end
        else
            if not self:checkHasMyTroop() then
                text = getLang("310009") -- 310009=掠夺
            end
        end
        CCCommonUtilsForLua:setButtonTitle(self.ui.m_enterButton, text)
    end

    local b_inSelfServer = WorldController:call("isInSelfServer", self.serverId)
    if b_inSelfServer == false then
        self.ui.m_buttonNode1:setVisible(false)
        self.ui.m_buttonNode2:setVisible(false)
        self.ui.m_buttonNode3:setVisible(false)
    end
end

function CivFortressInfoView:checkHasMyTroop()
    if self.beMyAli then
        -- return false
        local uuid1 = WorldController:call("getMyMarchUuidToIndex", self.cityIndex)
        local uuid2 = WorldController:call("getMyMarchUuidAtIndex", self.cityIndex)
        -- dump(uuid1, "uuid1 is: ")
        -- dump(uuid2, "uuid2 is: ")
        if uuid1 ~= "" or uuid2 ~= "" then
            return true
        end
    end

    return false
end

function CivFortressInfoView:update(dt)
    self:updateBuildTime()
end

function CivFortressInfoView:onTouchBegan(x, y)
    return true
end

function CivFortressInfoView:onTouchMoved(x, y)

end

function CivFortressInfoView:onTouchEnded(x, y)
    
end

function CivFortressInfoView:getDataBack(data)
    dump(data, "CivFortressInfoView:getDataBack(data) is: ")
    if data then
        self.m_dataMap = data
    end
    self:initBaseInfo()

    -- 整理队伍数据
    if self.beMyAli then
        self.ui.m_listNode:setVisible(true)
        self:initTableData()
    else
        self.ui.m_listNode:setVisible(false)
    end
end

-- 堡垒移动
function CivFortressInfoView:onMoveButtonClick()
    -- CivFortressController:fireCommonEvent("placeCivFortress")
    local tinfo = ToolController:call("getToolInfoForLua", tonumber(CivFortressController.m_productMoveId))
    if tinfo and tinfo:call("getCNT") > 0 then
        local cross = GlobalData:call("getPlayerInfo"):getProperty("crossFightSrcServerId")
        -- dump(self.m_dataMap, "self.m_dataMap is: ")
        if cross and cross == - 1 then
            local point = WorldController:call("getPointByIndex", tonumber(self.m_dataMap.pointId))
            LuaWorldController:setPlaceData({
                type = 2,
                tilePoint = point,
                })
        end
    end
end

-- 金币加速
function CivFortressInfoView:onUpButtonClick()
    if self.needGold == nil then
        return
    end

    local gold = GlobalDataCtr.getPlayerGold()
    if self.needGold > gold then
        LuaController:flyHint("", "", getLang("104912"))
        return
    end

    local function callBack()
        CivFortressController:speedUpCivFortress(1)
        self:call("closeSelf")
    end
    
    local dia = YesNoDialog:call("show", getLang("150657"), cc.CallFunc:create(callBack))
end

function CivFortressInfoView:onGetButtonClick()
    -- dump("CivFortressInfoView:onGetButtonClick 111111111111")
    local function callBack(data)
        -- dump("CivFortressInfoView is: ")
        local num = tonumber(data.gainCount)
        CivFortressController.m_data.resourceNum = 0
        local reward = {
            {
                type = "7",
                value = {
                    itemId = CivFortressController.m_productId,
                    num = tostring(num),
                },
            },
        }
        local rwdArr = luaToArray(reward)    
        PortActController:call("flyReward", rwdArr, false)
        local storage_ceiling = self.m_fortressData.storage_ceiling
        if CivFortressController.m_package_coupon then
            storage_ceiling = self.m_fortressData.storage_ceiling_2
        end
        self.ui.m_allLabel2:setString("0/"..storage_ceiling)         -- 当前产量
        self:updateUserData()
    end
    self.ui.m_getBtn:setEnabled(false)
    CivFortressController:settleCivFortress(callBack)
end

-- 驻守/返回/掠夺
function CivFortressInfoView:onEnterButtonClick()
    -- dump("CivFortressInfoView:onEnterButtonClick() ~~~~~")
    -- CIVILIZATION_DEF 驻守堡垒
    if self.m_dataMap.status == 3 then
        -- 拆除中
        return
    end
    if self.beMyAli then

        local marchUuid = WorldController:call("isSelfMarchAtCityIndex", self.cityIndex)
        if marchUuid ~= "" then
            -- 已驻防,返回
            local dict = CCDictionary:create()
            dict:setObject(CCString:create(marchUuid), "marchId")
            WorldMapView:call("afterMarchCancel", dict)
            self:call("closeSelf")
            return
        else
            -- 未驻防，
            local marchUuid = WorldController:call("getMyMarchUuidToIndex", self.cityIndex)
            if marchUuid ~= "" then
                -- 有行军，返回
                local dict = CCDictionary:create()
                dict:setObject(CCString:create(marchUuid), "marchId")
                    local view = require("game.CommonPopup.UseToolView"):create(USE_TOOL_MARCH_CANCEL, dict, "104039")
                    PopupViewController:addPopupInView(view)
            else
                -- 驻守
                local marchType = MarchMethodType.CIVILIZATION_AID
                if self.beSelf then
                    marchType = MarchMethodType.CIVILIZATION_DEF
                end
                WorldController:call("openMarchDeploy", self.cityIndex, 1, 0, marchType)
            end
        end
    else
        dump("CivFortressInfoView:onEnterButtonClick ~~~~~~111111")
        if self.m_dataMap.status == 1 then
            LuaController:flyHint("", "", getLang("310008"))
            return
        end
        -- 暂未开放
        -- CCCommonUtilsForLua:setButtonTitle(self.ui.m_enterButton, getLang("146337")) -- 未开放
        local function march()
            local marchType = MarchMethodType.CIVILIZATION_ATTACK
            WorldController:call("openMarchDeploy", self.cityIndex, 1, 0, marchType)
        end
        local warningTips = ToolController:call("getBeforeBattleWarning")
        if warningTips ~= "" then
            YesNoDialog:call("show", warningTips, cc.CallFunc:create(march))
        else
            march()
        end
    end
end

function CivFortressInfoView:onCancelButtonClick()
    dump("CivFortressInfoView:onCancelButtonClick() ~~~~~~~~")
    local function callBack()
        CivFortressController:removeCivFortress(self.cityIndex)
        self:call("closeSelf")
    end
    
    local dia = YesNoDialog:call("show", getLang("310040"), cc.CallFunc:create(callBack))
end

function CivFortressInfoView:getArmyData(data)
    local armyData = data.army
    dump(armyData, "armyData is: ", 10)
    self:initTableData()
end

function CivFortressInfoView:initTableData()
    local function reLoad()
        self:getInfoData()
    end
    local function touchOpen()
        self.ui:setTableViewDataSource("m_listTableView", self.m_armyData)
    end

    self.m_armyData = {}
    -- 组装数据，用于显示详情
    self.m_armyData[1] = {type = 1, data = self.m_dataMap}
    for i, troop in pairs(self.m_dataMap.army or {}) do
        self.m_armyData[#self.m_armyData + 1] = {
            type = 2,
            data = troop,
            isOpen = false,
            touchOpen = touchOpen,
        }
    end
    
    -- for i, data in pairs(self.m_armyData) do
    --     data.isOpen = false
    --     data.touchOpen = touchOpen
    -- end
    self.ui:setTableViewDataSource("m_listTableView", self.m_armyData)
end

function CivFortressInfoView:cellSizeForTable(tab, idx)
    local info = self.m_armyData[idx + 1]
    if info.type == 2 and info.isOpen then
        local data = info.data
        local num = #data.soldiers
        if data.petDragon then
            num = num + 1
        end

        if data.newGeneral then
            num = num + 1
        end
        return 640, math.ceil(num/2) * 100 + 130

    else
        return 640, 130
    end
end

function CivFortressInfoView:onTipBtnClick()
    LuaController:call("showFAQ","45277")
end

-- 堡垒升级
function CivFortressInfoView:onLvUpButtonClick()
    local data = self.m_dataMap
    if self.beSelf 
        and data.status == 2
        then

        local m_info = FunBuildController:call("getInstance"):call("getFunbuildForLua", 443000072) --FunBuildInfo
        local m_info_level = m_info:getProperty("level")
        if m_info_level > data.level then
            local view = Drequire("game.CivFortress.CivFortressUpgradeView"):create(data.level, m_info_level)
            PopupViewController:addPopupView(view)
        end
    end
end

-- 取消堡垒拆除
function CivFortressInfoView:onCancelRemoveButtonClick()
    if self.m_dataMap.status == 3 then
        local offsetTime = self.m_dataMap.removeEndTime - getTimeStamp()
        if offsetTime > 0 then
            self.m_dataMap.status = 2
            self.m_dataMap.removeEndTime = 0
            CivFortressController:cancelRemoveCivFortress()
            self:call("closeSelf")
        end
        -- CivFortressController:cancelRemoveCivFortress()
    end
end

--------------------------------------------- 模块End ---------------------------------------------------------
return CivFortressInfoView



