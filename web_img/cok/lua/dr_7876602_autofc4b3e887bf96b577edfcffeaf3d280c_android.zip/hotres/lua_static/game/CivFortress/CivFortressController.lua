local CivFortressController = class("CivFortressController")


--------------------------------------- 消息部分逻辑 Start ---------------------------------------
local GetCivFortressInfo = class("GetCivFortressInfo", LuaCommandBase)
function GetCivFortressInfo.create(callBack, targetUid)
    local ret = GetCivFortressInfo.new()
    ret:initWithName("civilizationCastle.info")
    ret._callBack = callBack
    if targetUid then
        ret:putParam("targetUid", CCString:create(targetUid))
    end
    -- ret:putParam("level", CCInteger:create(level))
    dump(" GetCivFortressInfo.create() ~~~~~~~~~~")
    return ret
end

function GetCivFortressInfo:handleReceive(dict)
    local tbl = self:parseMsg(dict)
    dump(tbl, " GetCivFortressInfo.handleReceive() ~~~~~~~~~~")
    if type(tbl) == "boolean" then
        return tbl
    end

    if self._callBack then
        self._callBack(tbl)
    end

    return true
end

-- 拉取其他人堡垒信息
local GetOtherCivFortressInfo = class("GetOtherCivFortressInfo", LuaCommandBase)
function GetOtherCivFortressInfo.create(targetUid, serverId, callBack)
    local ret = GetOtherCivFortressInfo.new()
    ret:initWithName("civilizationCastle.info")
    ret._callBack = callBack
    ret:putParam("targetUid", CCString:create(targetUid))
    ret:putParam("serverId", CCString:create(serverId))
    dump(" GetOtherCivFortressInfo.create() ~~~~~~~~~~")
    return ret
end

function GetOtherCivFortressInfo:handleReceive(dict)
    dump(" GetOtherCivFortressInfo.handleReceive() ~~~~~~~~~~")
    local tbl = self:parseMsg(dict)
    if type(tbl) == "boolean" then
        return tbl
    end

    if self._callBack then
        self._callBack(tbl)
    end

    return true
end

-- 放置堡垒
local setCivFortressPlace = class("setCivFortressPlace", LuaCommandBase)
function setCivFortressPlace.create(callBack, index)
    local ret = setCivFortressPlace.new()
    ret:initWithName("civilizationCastle.place")
    ret._callBack = callBack
    ret:putParam("pointId", CCInteger:create(index))
    dump(" setCivFortressPlace.create() ~~~~~~~~~~")
    return ret
end

function setCivFortressPlace:handleReceive(dict)
    dump(" setCivFortressPlace.handleReceive() ~~~~~~~~~~")
    local tbl = self:parseMsg(dict)
    if type(tbl) == "boolean" then
        return tbl
    end
    dump(tbl, "setCivFortressPlace data is: ")
    if self._callBack then
        self._callBack(tbl)
    end

    return true
end

-- 迁移堡垒
local setCivFortressMove = class("setCivFortressMove", LuaCommandBase)
function setCivFortressMove.create(callBack, index)
    local ret = setCivFortressMove.new()
    ret:initWithName("civilizationCastle.move")
    ret._callBack = callBack
    ret:putParam("pointId", CCInteger:create(index))
    dump(" setCivFortressMove.create() ~~~~~~~~~~")
    return ret
end

function setCivFortressMove:handleReceive(dict)
    local tbl = self:parseMsg(dict)
    if type(tbl) == "boolean" then
        return tbl
    end
    dump(tbl, "setCivFortressMove data is: ")
    if self._callBack then
        self._callBack(tbl)
    end

    return true
end

-- 移除堡垒
local setCivFortressRemove = class("setCivFortressRemove", LuaCommandBase)
function setCivFortressRemove.create(callBack)
    local ret = setCivFortressRemove.new()
    ret:initWithName("civilizationCastle.remove")
    ret._callBack = callBack
    -- ret:putParam("level", CCInteger:create(level))
    dump(" setCivFortressRemove.create() ~~~~~~~~~~")
    return ret
end

function setCivFortressRemove:handleReceive(dict)
    dump(" setCivFortressRemove.handleReceive() ~~~~~~~~~~")
    local tbl = self:parseMsg(dict)
    if type(tbl) == "boolean" then
        return tbl
    end
    dump(tbl, "setCivFortressRemove data is: ")
    if self._callBack then
        self._callBack(tbl)
    end

    return true
end

-- 取消移除堡垒
local setCivFortressCancelRemove = class("setCivFortressCancelRemove", LuaCommandBase)
function setCivFortressCancelRemove.create(callBack)
    local ret = setCivFortressCancelRemove.new()
    ret:initWithName("civilizationCastle.cancelRemove")
    ret._callBack = callBack
    -- ret:putParam("level", CCInteger:create(level))
    dump(" setCivFortressCancelRemove.create() ~~~~~~~~~~")
    return ret
end

function setCivFortressCancelRemove:handleReceive(dict)
    dump(" setCivFortressCancelRemove.handleReceive() ~~~~~~~~~~")
    local tbl = self:parseMsg(dict)
    if type(tbl) == "boolean" then
        return tbl
    end
    if self._callBack then
        self._callBack(tbl)
    end

    return true
end

-- 收获
local settleCivFortressInfo = class("settleCivFortressInfo", LuaCommandBase)
function settleCivFortressInfo.create(callBack, gainCount)
    local ret = settleCivFortressInfo.new()
    ret:initWithName("civilizationCastle.settle")
    ret._callBack = callBack
    if gainCount then
        ret:putParam("gainCount", CCInteger:create(gainCount))
    end
    dump(" settleCivFortressInfo.settle() ~~~~~~~~~~")
    return ret
end

function settleCivFortressInfo:handleReceive(dict)
    dump(" settleCivFortressInfo.handleReceive() ~~~~~~~~~~")
    local tbl = self:parseMsg(dict)
    if type(tbl) == "boolean" then
        return tbl
    end

    if self._callBack then
        self._callBack(tbl)
    end

    return true
end

-- 加速
local speedCivFortressInfo = class("speedCivFortressInfo", LuaCommandBase)
function speedCivFortressInfo.create(callBack, isGold, itemCount, itemUuid)
    local ret = speedCivFortressInfo.new()
    ret:initWithName("civilizationCastle.speedUp")
    ret._callBack = callBack
    isGold = isGold or 0
    ret:putParam("isGold", CCInteger:create(isGold))
    if isGold == 0 then
        ret:putParam("itemCount", CCInteger:create(itemCount))
        ret:putParam("itemUuid", CCString:create(itemUuid))
    end
    dump(" speedCivFortressInfo.speedUp() ~~~~~~~~~~")
    return ret
end

function speedCivFortressInfo:handleReceive(dict)
    dump(" speedCivFortressInfo.handleReceive() ~~~~~~~~~~")
    local tbl = self:parseMsg(dict)
    if type(tbl) == "boolean" then
        return tbl
    end

    if self._callBack then
        self._callBack(tbl)
    end

    return true
end
--------------------------------------- 消息部分逻辑 Ended ---------------------------------------

local function convertInfoData(data)
    data.status = tonumber(data.status)
    data.level = tonumber(data.level)
    data.lastOutputTime = (tonumber(data.lastOutputTime) or 0) / 1000
    data.buildTime = (tonumber(data.buildTime) or 0)/1000
    data.lastSettleTime = (tonumber(data.lastSettleTime) or 0)/1000
    data.removeEndTime = (tonumber(data.removeEndTime) or 0)/1000
    if data.removeEndTime > 0 then
        data.status = 3
    end
    return data
end

function CivFortressController:fireCommonEvent(newKey, data)
	if isFunOpenByKey("civilization_fortress_on") == false then
		return
	end
    if newKey == "openCivFortressMoreView" then
    	local view = Drequire("game.CivFortress.CivFortressMoreView"):create(data)
        PopupViewController:addPopupInView(view, false)
    elseif newKey == "getCivFortressStatus" then
        -- 获取堡垒状态
        if data then
            local status = self:getCivFortressStatus()
            dump(status, " getCivFortressStatus is: ")
            data:setObject(CCInteger:create(status), "status")
        end
    elseif newKey == "placeCivFortress" then
        -- 放置文明堡垒
        -- self:placeCivFortress()
        local cross = GlobalData:call("getPlayerInfo"):getProperty("crossFightSrcServerId")
        if cross and cross == - 1 then
            LuaWorldController:setPlaceData({
                type = 1,
                })
        else
            -- 跨服状态，无法查看或放置
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("137705"))
        end
    elseif newKey == "placeOrViewCivFortrss" then
        self:placeOrViewCivFortrss()
    elseif newKey == "speedUpCivFortress" then
        local tbl = dictToLuaTable(data)
        dump(tbl, "speedUpCivFortress data is: ")
        self:speedUpCivFortress(tbl.isGold, tbl.itemCount, tbl.itemUuid)
    elseif newKey == "getCivFortressFigure" then
        local node = self:getCivFortressFigure()
        if data then
            local node = self:getCivFortressFigure()
            data:setObject(node, "cifFortressFigure")
        end
    elseif newKey == "openCivFortressStatusView" then
        local view = Drequire("game.CivFortress.CivFortressStatusView"):create(data)
        PopupViewController:addPopupInView(view)
    elseif newKey=="getCivFortressIndex" then
        if data then
            local index = self:getCivFortressIndex()
            dump(index, "getCivFortressIndex is: ")
            data:setObject(CCInteger:create(index), "civFortressIndex")
        end
    end
end     

function CivFortressController:initConfigData(dict)
    -- 数据初始化逻辑地方
    local params = dict:objectForKey("civilization_fortress")
    if params then
        local data = dictToLuaTable(params)
        dump(data, "civilization_fortress initConfigData 11111111111")
        -- K1=产出物品id  K2=产出时间间隔（秒）  K3=结算时间间隔（秒）  K4=迁移道具
        -- "civilization_fortress" = {
        --     "k1" = "212069"
        --     "k2" = "1200"
        --     "k3" = "21600"
        --     "k4" = "212070"
        --     "k5" = "1;0.0005|2;0.000525|3;0.00055|4;0.000575|5;0.0006|6;0.000625|7;0.00065|8;0.000675|9;0.0007|10;0.000725|11;0.00075"
        -- end

        self.m_productId = data.k1
        self.m_productOffTime = math.floor(tonumber(data.k2)/60)
        self.m_productRewardTime = tonumber(data.k3)
        self.m_productMoveId = data.k4
    end
end

function CivFortressController:ctor()
    self.getInfoNotifyKey = "getCivFortressInfoNotifyKey"
end

function CivFortressController:initDataEnd()
	if isFunOpenByKey("civilization_fortress_on") == false then
        return
    end
    self.m_data = nil
    self.m_xmlData = nil
    self:getCivFortressInfoCmd()
end

function CivFortressController:getCivFortressInfoCmd()
	local function callBack(data)
		dump(data, "CivFortressController:getCivFortressInfoCmd data is: ")
		self.m_data = convertInfoData(data)
        self.m_package_coupon = data.isDouble == "1"
		CCSafeNotificationCenter:call("postNotification", self.getInfoNotifyKey)
	end
	local cmd = GetCivFortressInfo.create(callBack)
	cmd:send()
end

function CivFortressController:getCivFortressInfo()
    -- data = {
    --     "_cok_"          = "1885630198"
    --     "addingTime"     = "1503478677"
    --     "beRobNum"       = "0"       当前被掠夺过的资源量
    --     "def"            = "0"       -- 所有城防值
    --     "defArmy"        = ""        当前驻守的玩家信息（驻守会增加产出效率）
    --     "aidArmys"       = ""        当前援助的玩家信息
    --     "infoDic" = {
    --     }
    --     "lastOutputTime" = "0"       上次堡垒产出资源的时间
    --     "lastSettleTime" = "0"       上次结算资源的时间，结算时把堡垒中的资源加到玩家身上
    --     "level"          = "1"       当前文明堡垒等级（外部的，内部的建筑等级有建筑相关协议给出）
    --     "output"         = "100"     产出数量（每10分钟产出的数量，这个是根据驻守部队不同而不同的）
    --     "pointId"        = "0"
    --     "resourceNum"    = "0"       当前堡垒内有的资源量
    --     "robCount"       = "0"       当前掠夺过的次数
    --     "uid"            = "44194353001266"
    --     "status"         = "0" 联盟堡垒的状态：0没创建，1创建中，2创建完成,3删除中
    --     "buildTime"      = "0"   创建时间
    -- }
	return self.m_data
end

function CivFortressController:getCivFortressXmlData()
    if self.m_xmlData == nil then
        local xmlData = CCCommonUtilsForLua:getGroupByKey("civilization_fortress")
        local tbl = {}
        -- 再次同时建立id索引表
        for i, data in pairs(xmlData) do
            data.level = tonumber(data.level)
            data.wood = tonumber(data.wood)
            data.iron = tonumber(data.iron)
            data.integral = tonumber(data.integral)
            data.time = tonumber(data.time)
            -- data.integral = tonumber(data.integral)
            -- data.integral = tonumber(data.integral)
            tbl[data.level] = data
        end
        self.m_xmlData = tbl


    end
    return self.m_xmlData
end

function CivFortressController:getCivFortressStatus()
    if self.m_data and self.m_data.status then
        if self.m_data.status == 3 then
            local offset = self.m_data.removeEndTime - getTimeStamp()
            if offset <= 0 then
                self.m_data.status = 0
            end
        end
        return self.m_data.status
    end

    return 0
end

function CivFortressController:checkPlaceEnoughRes()
    if self.m_data == nil then
        return false
    end

    local m_info = FunBuildController:call("getInstance"):call("getFunbuildForLua", 443000072) --FunBuildInfo
    local m_info_level = m_info:getProperty("level")
    -- dump(m_info_level, "m_info_level is: ")
    local xmlData = self:getCivFortressXmlData()
    local data = xmlData[m_info_level or self.m_data.level]
    if data == nil then
        return false
    end

    if data.wood > CCCommonUtilsForLua:call("getCurResourceByType", WorldResourceType.Wood) then
        local view = require("game.CommonPopup.UseResToolView"):create(WorldResourceType.Wood)
        PopupViewController:addPopupInView(view)
        return false
    elseif data.iron > CCCommonUtilsForLua:call("getCurResourceByType", WorldResourceType.Iron) then
        local view = require("game.CommonPopup.UseResToolView"):create(WorldResourceType.Iron)
        PopupViewController:addPopupInView(view)
        return false
    elseif data.integral > CivilizationController:getCivilizationScore() then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("310096"))
        return false
    end

    return true
end

-- 放置堡垒
function CivFortressController:placeCivFortress()
    if self:checkPlaceEnoughRes() == false then
        -- CCCommonUtilsForLua:call("flyHint", "", "", getLang("E100002"))
        return
    end

    LuaWorldController:setPlaceData({
            type = 1,
            })
end

-- 查看堡垒坐标
function CivFortressController:viewCivFortress()
    local index = tonumber(self.m_data.pointId)
    if SceneController:call("getCurrentSceneId") == 11 then
        local point = WorldController:call("getPointByIndex", index)
        WorldMapView:call("gotoTilePoint", point)
    else
        SceneController:call("gotoScene", 11, false, true, index)
    end
    PopupViewController:call("forceClearAll", true)
end

function CivFortressController:getCivFortressIndex()
    if self.m_data and self.m_data.pointId then
        local index = tonumber(self.m_data.pointId)
        return index
    end
end

-- 放置 or 查看堡垒
function CivFortressController:placeOrViewCivFortrss()
    if self:getCivFortressStatus() == 0 then
    -- if true then
        -- 放置
        self:placeCivFortress()
        -- self:startPlaceCmd()
    else
        -- 查看
        self:viewCivFortress()
    end
end

function CivFortressController:startPlaceCmd(index)
    local function callBack(data)
        dump(data, "CivFortressController:startPlaceCmd")
        -- 更新资源
        GlobalDataCtr.updateResourceInfo(data.resource or {})
        if data.civilizationScore then
            CivilizationController:setCivilizationScore(tonumber(data.civilizationScore))
        end
        self.m_data.status = 1
        self.m_data.pointId = data.infoDic.pointId
        CCSafeNotificationCenter:call("postNotification", "MSG_MAP_UPDATE_SINGLE", CCInteger:create(self.m_placeIndex))
        self:getCivFortressInfoCmd()
    end
    self.m_placeIndex = index
    local cmd = setCivFortressPlace.create(callBack, index)
    cmd:send()
end
-- 迁移堡垒
function CivFortressController:startPlaceMoveCmd(index)
    local function callBack(data)
        dump(data, "CivFortressController:startPlaceMoveCmd")
        -- 更新资源
        -- GlobalDataCtr.updateResourceInfo(data.resource or {})
        -- if data.civilizationScore then
        --     CivilizationController:setCivilizationScore(tonumber(data.civilizationScore))
        -- end
        -- self.m_data.status = 1
        CCSafeNotificationCenter:call("postNotification", "MSG_MAP_UPDATE")
        -- CCSafeNotificationCenter:call("postNotification", "MSG_MAP_UPDATE_SINGLE", CCInteger:create(self.m_data.pointId))
        self.m_data.pointId = data.infoDic.pointId
        -- CCSafeNotificationCenter:call("postNotification", "MSG_MAP_UPDATE_SINGLE", CCInteger:create(self.m_placeIndex))
        self:getCivFortressInfoCmd()
    end
    self.m_placeIndex = index
    local cmd = setCivFortressMove.create(callBack, index)
    cmd:send()
end

-- " getConfig[face_ertongjie_out] is: " = {
--     "cz_state"    = "1"
--     "hideNative"  = "1"
--     "skeleton1"   = "face_ertongjie,sk_face_ertongjie,dj,128,80,1"
--     "skeletoncnt" = "1"
function CivFortressController:getAvatarConfigData(configName)
    local rootPath = CCFileUtils:sharedFileUtils():getWritablePath().."dresource/"
    local configFilePath = rootPath.."skinparticle/"..configName..".config"
    local configDataFile = io.open(configFilePath, "r")
    local config = {}
    if configDataFile then
        local configLineContent = configDataFile:read()
        while(configLineContent) do
            local tbl = string.split(configLineContent, "=")
            config[tbl[1]] = tbl[2]
            configLineContent = configDataFile:read()
        end
        io.close(configDataFile)
    else
        dump(configFilePath, "error, fail to open cfg file+++")
    end
    dump(config, " getConfig["..configName.."] is: ")
    if table_is_empty(config) then
        return nil
    end
    -- dump(config,"getAvatarConfigData+++",10)
    return config
end

function CivFortressController:isCivFortAvatarFunOpen( )
    local open = CCCommonUtilsForLua:isFunOpenByKey("fortress_avatar")
    return open
end

function CivFortressController:getCivFortressFigureEx( tblParams )
    dump(tblParams,"CivFortressController:getCivFortressFigureEx+++",10)
    -- local civFortStatus = "510945"
    local isFunOpen = self:isCivFortAvatarFunOpen() 
    local civFortStatus = tblParams.civFortStatus
    local isUsedInfoView = tblParams.isUsedInfoView --是否在CivFortressInfoView中使用
    if (not isFunOpen) or (not civFortStatus) or civFortStatus == "0" then 
        dump(isFunOpen,"error:11111110,isFunOpen+++")
        return self:getCivFortressFigure()
    end

    -- addPic="36|face_ertongjie_out"
    local addPic = CCCommonUtilsForLua:call("getPropById", civFortStatus, "addPic")
    local effectart = CCCommonUtilsForLua:call("getPropById", civFortStatus, "effectart")
    dump(addPic,"addPic")
    dump(effectart,"effectart")
    if not addPic or not effectart then
        dump("error:11111111")
        return self:getCivFortressFigure()
    end
    local tblCfg = string.split(addPic, "|")
    local configName = tblCfg[2]
    -- local configName = "face_fortress_out"

    if not tblCfg or not configName or configName == "" then 
        dump("error:111111113")
        return self:getCivFortressFigure()
    end

    local config = self:getAvatarConfigData(configName)
    if not config then
        dump("error:111111112")
        return self:getCivFortressFigure()
    end

    local sprNode = nil
    local nodeType = 0
    local mainScale, infoViewScale, infoViewPosX, infoViewPosY = nil,nil,nil
    if config["mainScale"] then 
        mainScale = tonumber(config["mainScale"]) 
    end
    if config["infoViewScale"] then 
        infoViewScale = tonumber(config["infoViewScale"]) 
    end
    if config["infoViewPosX"] then 
        infoViewPosX = tonumber(config["infoViewPosX"]) 
    end
    if config["infoViewPosY"] then 
        infoViewPosY = tonumber(config["infoViewPosY"]) 
    end
    local rootPath = CCFileUtils:sharedFileUtils():getWritablePath().."dresource/"
    if DynamicResourceController2:call("checkDynamicResource", effectart) then
        sprNode = cc.Node:create()
        local skeletoncnt = tonumber(config["skeletoncnt"]) or 0
        for i =1, skeletoncnt do
            local info = config["skeleton"..i] --skeleton1=face_fortress,sk_face_fortress,animation,125,75,1
            if info then
                local tbl = string.split(info, ",")
                if #tbl > 3 then
                    local skin_file = rootPath .. tbl[2].. ".atlas" 
                    local skin_json = rootPath .. "/skinparticle/"..tbl[1]..".json"
                    local animationObj = IFSkeletonAnimation:call("create", skin_json, skin_file)
                    if animationObj then
                        dump("success to create animation566+++")
                        local x = (tonumber(tbl[4]) or -20)
                        local y = (tonumber(tbl[5]) or -40)
                        animationObj:setAnimation(0, tbl[3], true)
                        animationObj:setContentSize(cc.size(9999, 9999))
                        animationObj:setPosition(cc.p(x, y))
                        sprNode:addChild(animationObj)
                        nodeType = 1
                    else
                        dump("fail to create IFSkeletonAnimation575+++")
                    end
                end
            end
        end

        local parcnt = tonumber(config["parcnt"]) or 0
        for i = 1, parcnt do
            local info = config["par"..i] --par1=zibaoshi1,300,270,1,0
            if info then
                local tbl = string.split(info, ",")
                local parPath = ""
                local particle = nil
                local path = rootPath.. "skinparticle/" .. tbl[1]
                particle = ParticleController:call("createParticleForLua", path)
                if particle then
                    particle:setPosition(cc.p(tbl[2], tbl[3]))
                    particle:setContentSize(cc.size(9999, 9999))
                    sprNode:addChild(particle)
                end
            end
        end

        if isUsedInfoView then
            if infoViewScale then 
                sprNode:setScale(infoViewScale)
            end
            if infoViewPosX and infoViewPosY then 
                sprNode:setPosition(cc.p(infoViewPosX, infoViewPosY))
            end
        else
            if mainScale then 
                dump(mainScale,"set main scale+++")
                sprNode:setScale(mainScale)
            end
        end
    end
    
    if sprNode == nil then
        loadLuaResource("Imperial/Imperial_22.plist")
        sprNode = CCLoadSprite:createSprite("pic443000_2.png")
        sprNode:setAnchorPoint(cc.p(0.5, 0))
        sprNode:setPosition(cc.p(-20, -40))
        nodeType = 2
    end

    if sprNode == nil then
        sprNode = cc.Node:create()
    end

    return sprNode, nodeType
end

function CivFortressController:getCivFortressFigure()
    local sprNode = nil
    local nodeType = 0
    if DynamicResourceController2:call("checkDynamicResource", "civFortress_face") then
        local rootPath = CCFileUtils:sharedFileUtils():getWritablePath().."dresource/"
        local skin_file = rootPath .. "sk_civ_fortress.atlas" 
        local skin_json = rootPath .."civ_fortress.json"
        local animationObj = IFSkeletonAnimation:call("create", skin_json, skin_file)
        if animationObj then
            animationObj:setAnimation(0, "zhuanghuo", true)
            animationObj:setContentSize(cc.size(9999, 9999))
            animationObj:setPosition(cc.p(-20, -40))
            sprNode = animationObj
            nodeType = 1
        end
    end
    
    if sprNode == nil then
        loadLuaResource("Imperial/Imperial_22.plist")
        sprNode = CCLoadSprite:createSprite("pic443000_2.png")
        -- dump(sprNode, "CivFortressController:getCivFortressFigure 333333333 sprNode is: ")
        sprNode:setAnchorPoint(cc.p(0.5, 0))
        sprNode:setPosition(cc.p(-20, -40))
        -- sprNode:setScale(1.4)
        nodeType = 2
    end

    if sprNode == nil then
        sprNode = cc.Node:create()
    end

    return sprNode, nodeType
end

function CivFortressController:getOtherCivFortressInfo(uid, serverId, _callBack)
    local function callBack(data)
        -- data.status = tonumber(data.status)
        -- data.level = tonumber(data.level)
        -- data.lastOutputTime = (tonumber(data.lastOutputTime) or 0) / 1000
        -- data.buildTime = (tonumber(data.buildTime) or 0)/1000
        data = convertInfoData(data)
        if _callBack then
            _callBack(data)
            _callBack = nil
        end
        self.m_package_coupon = data.isDouble == "1"
    end
    local cmd = GetOtherCivFortressInfo.create(uid, serverId, callBack)
    cmd:send()
end

function CivFortressController:settleCivFortress(_callBack, num)
    local function callBack(data)
        -- dump(data, "settleCivFortress callBack data is: ")
        -- 自己的数据处理
        self.m_data.resourceNum = 0
        self.m_data.lastSettleTime = (tonumber(data.lastSettleTime) or 0)/1000
        if _callBack then
            _callBack(data)
        end
        CCSafeNotificationCenter:call("postNotification", "MSG_MAP_UPDATE")
    end
    local cmd = settleCivFortressInfo.create(callBack)
    cmd:send()
end

function CivFortressController:syncRemoveData()
    if self.m_data.status == 3 then
        self.m_data.status = 0
        self.m_data.removeEndTime = 0
        self:getCivFortressInfoCmd()
    end
end

-- 拆除堡垒逻辑处理
function CivFortressController:removeCivFortress(index)
    local function callBack(data)
        self.m_data.status = 0
        self:getCivFortressInfoCmd()
        if CCCommonUtilsForLua:isFunOpenByKey("civilization_fortress_v3_on") then
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("165427"))
            self.m_data.status = 3
            self.m_data.removeEndTime = (tonumber(data.removeEndTime) or 0) / 1000
            -- CCSafeNotificationCenter:call("postNotification", "msg_civfortress_remove")
            CCSafeNotificationCenter:call("postNotification", "MSG_MAP_UPDATE_SINGLE", CCInteger:create(index))
        else
            CCSafeNotificationCenter:call("postNotification", "MSG_MAP_UPDATE")
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("310037")) 
        end
    end
    local cmd = setCivFortressRemove.create(callBack)
    cmd:send() 
end

-- 取消拆除堡垒逻辑处理
function CivFortressController:cancelRemoveCivFortress()
    -- self.m_data.status = 2
    -- self.m_data.removeEndTime = 0
    local function callBack(data)
        -- 如果有返回数据，则取消拆除
        self.m_data.status = 2
        self.m_data.removeEndTime = 0
        CCSafeNotificationCenter:call("postNotification", "MSG_MAP_UPDATE_SINGLE", CCInteger:create(tonumber(self.m_data.pointId)))
    end

    local cmd = setCivFortressCancelRemove.create(callBack)
    cmd:send() 
    

    -- 发送消息
    -- self:getCivFortressInfoCmd()
end

function CivFortressController:speedUpCivFortress(isGold, itemCount, itemUuid)
    local function callBack(data)
        -- dump(data, "CivFortressController:speedUpCivFortress data is: ")
        -- 需增加道具消耗逻辑
        self.m_data.buildTime = (tonumber(data.buildTime) or 0)/1000
        if self.m_data.buildTime < getTimeStamp() then
            self.m_data.status = 2
            CCSafeNotificationCenter:call("postNotification", "MSG_MAP_UPDATE")
        end
        if data.isGold == "0" and data.itemId and data.count then
            local tool = ToolController:call("getToolInfoByIdForLua", tonumber(data.itemId))
            if tool then tool:call("setCNT", tonumber(data.count)) end
        end
        local gold = tonumber(data.remainGold)
        if gold then
            GlobalDataCtr.setPlayerGold(gold)
        end
        local ref = CCString:create(tostring(self.m_data.buildTime))
        CCSafeNotificationCenter:call("postNotification", "CivFortressSpeedupBack", ref)
    end
    local cmd = speedCivFortressInfo.create(callBack, isGold, itemCount, itemUuid)
    cmd:send()
end

return CivFortressController




