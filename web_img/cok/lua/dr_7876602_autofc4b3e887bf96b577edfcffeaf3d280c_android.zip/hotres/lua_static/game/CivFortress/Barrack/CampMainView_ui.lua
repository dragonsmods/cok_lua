----------------------------
-- Author: Elex
-- Date: 2018-05-24 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CampMainView_ui = class("CampMainView_ui")

--#ui propertys


--#function
function CampMainView_ui:create(owner, viewType, paramTable)
	local ret = CampMainView_ui.new()
	CustomUtility:LoadUi("CampMainView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function CampMainView_ui:initLang()
end

function CampMainView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CampMainView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CampMainView_ui:initTableView()
	TableViewSmoker:createView(self, "m_listTableView1", "game.CivFortress.Barrack.CampIconCell", 0, 6, "CampIconCell")
	TableViewSmoker:createView(self, "m_listTableView2", "game.CivFortress.Barrack.CampIconCell", 0, 6, "CampIconCell")
end

function CampMainView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return CampMainView_ui

