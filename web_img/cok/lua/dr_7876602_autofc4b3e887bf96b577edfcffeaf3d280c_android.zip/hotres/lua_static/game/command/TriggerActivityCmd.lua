TriggerActivityCmd = class("TriggerActivityCmd", LuaCommandBase)

-- not override me !!!!!
function TriggerActivityCmd:handleReceive( dict )
	local cmdname = dict:valueForKey("cmd"):getCString()
	if cmdname ~= "trigger.activity" then
		return false
	end
	local params = dict:objectForKey("params")
	if nil == params then
		return true
	end
	if params:objectForKey("errorCode") then
		MyPrint("trigger activity errorCode!!! .. type .. " .. tostring(t) .. " errorCode .. " .. params:valueForKey("errorCode"):getCString())
		return true
	end
	local t = params:valueForKey("type"):intValue()
	if t ~= self.type then
		return false
	end

	MyPrint("trigger activity success!!! .. type ", t)
	return true
end


function TriggerActivityCmd:ctor( type )
	MyPrint("TriggerActivityCmd:ctor  type", type)
	LuaCommandBase.ctor(self, "trigger.activity")
	self.type = type
	self:putParam("type", CCInteger:create(type))
end


----------------------------------------------------------------
-- 41 请求刷新数据
TriggerRefreshEggsDataCmd = class("TriggerRefreshEggsDataCmd", TriggerActivityCmd)

function TriggerRefreshEggsDataCmd:ctor(  )
	MyPrint("TriggerRefreshEggsDataCmd:ctor")
	TriggerActivityCmd.ctor(self, 41)
end
----------------------------------------------------------------


----------------------------------------------------------------
-- 42 请求砸金蛋界面
TriggerGetBreakEggsDataCmd = class("TriggerGetBreakEggsDataCmd", TriggerActivityCmd)

function TriggerGetBreakEggsDataCmd:ctor(  )
	MyPrint("TriggerGetBreakEggsDataCmd:ctor")
	TriggerActivityCmd.ctor(self, 42)
end
----------------------------------------------------------------

----------------------------------------------------------------
-- 43 砸金蛋
--  * index|int|金蛋的位置 0开始
TriggerBreakEggCmd = class("TriggerBreakEggCmd", TriggerActivityCmd)

function TriggerBreakEggCmd:ctor( index )
	MyPrint("TriggerBreakEggCmd:ctor", index)
	TriggerActivityCmd.ctor(self, 43)
	self:putParam("index", CCInteger:create(tonumber(index)))
end
----------------------------------------------------------------


----------------------------------------------------------------
-- 44 集字领取消息
TriggerCharacterExchangeCmd = class("TriggerCharacterExchangeCmd", TriggerActivityCmd)

function TriggerCharacterExchangeCmd:ctor( para )
	MyPrint("TriggerCharacterExchangeCmd:ctor", para)
	TriggerActivityCmd.ctor(self, 44)
	self:putParam("para1", CCInteger:create(tonumber(para)))
end
----------------------------------------------------------------


----------------------------------------------------------------
-- 45 是对他人使用物品命令
TargetUseItemCmd = class("TargetUseItemCmd", TriggerActivityCmd)

function TargetUseItemCmd:ctor( uid, itemId )
	MyPrint("TargetUseItemCmd:ctor", uid, itemId)
	TriggerActivityCmd.ctor(self, 45)
	self:putParam("uid", CCString:create(tostring(uid)))
	self:putParam("item_id", CCString:create(tostring(itemId)))
end
----------------------------------------------------------------


----------------------------------------------------------------
-- 46 是许愿命令
WishActCmd = class("WishActCmd", TriggerActivityCmd)

function WishActCmd:ctor( typeIds )
	MyPrint("typeIds", typeIds)
	TriggerActivityCmd.ctor(self, 46)
	self:putParam("tableId", CCString:create(typeIds))
end
----------------------------------------------------------------


----------------------------------------------------------------
-- 47 是分享类型
ShareTriggerCmd = class("ShareTriggerCmd", TriggerActivityCmd)

function ShareTriggerCmd:ctor( action )
	MyPrint("action ", action)
	TriggerActivityCmd.ctor(self, 47)
	self:putParam("action", CCString:create(tostring(action)))
end
----------------------------------------------------------------


----------------------------------------------------------------
-- 49 是请求怪物进度消息
MonsterProCmd = class("MonsterProCmd", TriggerActivityCmd)

function MonsterProCmd:ctor( )
	MyPrint("MonsterProCmd:ctor ")
	TriggerActivityCmd.ctor(self, 49)
end
----------------------------------------------------------------


----------------------------------------------------------------
-- 50 召回活动 倒计时
CallFriendsCmd = class("CallFriendsCmd", TriggerActivityCmd)

function CallFriendsCmd:ctor( action)
	MyPrint("CallFriendsCmd:ctor ",action)
	TriggerActivityCmd.ctor(self, action)
end
----------------------------------------------------------------

----------------------------------------------------------------
-- 58 从主城切到世界地图
SceneChangeCmd = class("SceneChangeCmd", TriggerActivityCmd)

function SceneChangeCmd:ctor()
	MyPrint("SceneChangeCmd:ctor ")
	TriggerActivityCmd.ctor(self, 58)
end
----------------------------------------------------------------