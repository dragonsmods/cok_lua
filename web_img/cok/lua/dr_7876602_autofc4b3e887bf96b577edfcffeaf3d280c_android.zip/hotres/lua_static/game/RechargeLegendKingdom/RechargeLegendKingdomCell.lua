local RechargeLegendKingdomCell =
    class(
    "RechargeLegendKingdomCell",
    function()
        return cc.Layer:create()
    end
)

RechargeLegendKingdomCell.m_bgHeight = 130
local icon_size = 80

function RechargeLegendKingdomCell:create(idx)
    local ret = RechargeLegendKingdomCell.new()
    Drequire("game.RechargeLegendKingdom.RechargeLegendKingdomCell_ui"):create(ret)
    function onTouch(eventType, x, y)
        if eventType == "began" then
            return ret:onTouchBegan(x, y)
        elseif eventType == "moved" then
            return ret:onTouchMoved(x, y)
        else
            return ret:onTouchEnded(x, y)
        end
    end
    ret:setTouchEnabled(true)
    ret:registerScriptTouchHandler(onTouch)
    return ret
end

function RechargeLegendKingdomCell:refreshCell(info, idx)
    dump(info, "RechargeLegendKingdomCell:refreshCell+++", 10)
    if not info.type then
        return
    end
    self.ui.m_picNode:removeAllChildren()
    self.m_type = info.type
    self.m_level = info.level
    self.m_info = info
    if info.personal then self.m_personal = info.personal end
    if info.userCharge then self.m_userCharge = info.userCharge end
    if info.type == 1 or info.type == 2 then
        self.ui.node_reward:setVisible(true)
        self.ui.node_des:setVisible(false)
        local str = "9200741"
        if info.type == 2 then
            str = "9200756"
        end
        self.ui.m_sentLabel:setString(getLang("9200713"))
        self.ui.m_titleTxt:removeAllChildren()
        local current = info.current
        if tonumber(info.current) < tonumber(info.kingdom) then
            current = "<s 22><c ff0000ff>" .. current .. "<s 22><c ffde00ff>"
        end
        local lb = IFHyperlinkText:call("create","<s 22><c ffde00ff>" .. getLang(str, current, info.kingdom),self.ui.m_titleTxt:getContentSize(), false, false)
        lb:setAnchorPoint(cc.p(0,0))
        self.ui.m_titleTxt:addChild(lb)
        local pic = CCLoadSprite:call("createSprite", info.pic .. ".png")
        self.ui.m_picNode:addChild(pic)
        self.ui.btn_Charge:setEnabled(tonumber(info.current) >= tonumber(info.kingdom))
        if self.m_type == 1 then
            self.ui.btn_Charge:setVisible(tonumber(info.kingdom) > tonumber(info.rewardCharge))
        elseif self.m_type == 2 then
            self.ui.btn_Charge:setVisible(tonumber(info.kingdom) > tonumber(info.rewardNum))
        end
        self.ui.txt_btn:setVisible(true)
        self.ui.m_pTableViewRwd:removeAllChildren()
        local listReward = Drequire("game.CommonPopup.RewardTblView"):create(info.reward, 5)
        self.ui.m_pTableViewRwd:addChild(listReward)
    elseif info.type == 3 then
        self.ui.node_reward:setVisible(false)
        self.ui.node_des:setVisible(true)
    end
end

function RechargeLegendKingdomCell:onEnter()
end

function RechargeLegendKingdomCell:onExit()
end

function RechargeLegendKingdomCell:onClickChargeBtn()
    local function fun()
        local path = "game.LiBao.LibaoCommonPopupView"
        local view = Drequire(path):create()
        PopupViewController:addPopupView(view)
    end
    local dialog = YesNoDialog:call("show", getLang("9200750", getLang("920075" .. self.m_level)), cc.CallFunc:create(fun)) -- 9200750=尊敬的领主：个人档位达到{0}才能领取
    dialog:call("setYesButtonTitle", getLang("180042")) --180042=去充值
end

function RechargeLegendKingdomCell:onTouchBegan(x, y)
    if touchInside(self.ui.m_picTouch, x, y) then
        return true
    end
    return false
end

function RechargeLegendKingdomCell:onTouchEnded(x, y)
    if touchInside(self.ui.m_picTouch, x, y) then
        local contentDialog = tostring(9200744 + self.m_level)
        local content = getLang(contentDialog,self.m_info.personal)
        CCCommonUtilsForLua:call("flyText",  content)
    end
end

return RechargeLegendKingdomCell
