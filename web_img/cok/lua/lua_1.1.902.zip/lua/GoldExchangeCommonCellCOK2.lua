require "externCOK2"
require "CCBReaderLoadCOK2"
require "commonCOK2"

LiBaoCommonCell  = LiBaoCommonCell or {}
ccb["LiBaoCommonCell"] = LiBaoCommonCell

GoldExchangeCommonCell = class("GoldExchangeCommonCell",
	function()
        return cc.Layer:create() 
	end
)
GoldExchangeCommonCell.__index = GoldExchangeCommonCell
function GoldExchangeCommonCell:create(path,params)
	local node = GoldExchangeCommonCell.new()
	node:init(path,params)
	return node
end
function GoldExchangeCommonCell:init(path,params)
    self.rootPath = path
    self.data = params
    local  proxy = cc.CCBProxy:create()
    local ccbiUrl = self.rootPath .. "/ccbi/LiBaoCommonCell.ccbi"
	local  node  = CCBReaderLoad(ccbiUrl,proxy,LiBaoCommonCell)
    if(nil == node) then
        return
    end

    self:setContentSize(CCSize(175, 175))

   	print "(COK2_Cell)GoldExchangeCommonCell:init"
    local  layer = tolua.cast(node,"cc.Layer")
    if nil ~= LiBaoCommonCell["m_nameLabel"] then
        self.m_nameLabel = tolua.cast(LiBaoCommonCell["m_nameLabel"],"cc.Label")
        if nil ~= self.m_nameLabel then
            self.m_nameLabel:setString("")
        end
    end

    --print "1"
    if nil ~= LiBaoCommonCell["m_numLabel"] then
        self.m_numLabel = tolua.cast(LiBaoCommonCell["m_numLabel"],"cc.Label")
        if nil ~= self.m_numLabel then
            local numStr = string.format(self.data[2])
            self.m_numLabel:setString(numStr)
        end
    end

    if self.data[2]=="1" then
        if nil ~= LiBaoCommonCell["m_singleNode"] then
            self.m_singleNode = tolua.cast(LiBaoCommonCell["m_singleNode"],"cc.LayerColor")
            if nil ~= self.m_singleNode then
                print "m_singleNode-true"
                self.m_singleNode:setVisible(true)
            end
        end
        if nil ~= LiBaoCommonCell["m_multiNode"] then
            self.m_multiNode = tolua.cast(LiBaoCommonCell["m_multiNode"],"cc.LayerColor")
            if nil ~= self.m_multiNode then
                print "m_multiNode-false"
                self.m_multiNode:setVisible(false)
            end
        end
        if nil ~= LiBaoCommonCell["m_numNode"] then
            self.m_numNode = tolua.cast(LiBaoCommonCell["m_numNode"],"cc.LayerColor")
            if nil ~= self.m_numNode then
                print "m_numNode-false"
                self.m_numNode:setVisible(false)
            end
        end
    else
        if nil ~= LiBaoCommonCell["m_singleNode"] then
            self.m_singleNode = tolua.cast(LiBaoCommonCell["m_singleNode"],"cc.LayerColor")
            if nil ~= self.m_singleNode then
                print "m_singleNode-false"
                self.m_singleNode:setVisible(false)
            end
        end
        if nil ~= LiBaoCommonCell["m_multiNode"] then
            self.m_multiNode = tolua.cast(LiBaoCommonCell["m_numNode"],"cc.LayerColor")
            if nil ~= self.m_multiNode then
                print "m_multiNode-true"
                self.m_multiNode:setVisible(true)
            end
        end
        if nil ~= LiBaoCommonCell["m_numNode"] then
            self.m_numNode = tolua.cast(LiBaoCommonCell["m_multiNode"],"cc.LayerColor")
            if nil ~= self.m_numNode then
                print "m_numNode-true"
                self.m_numNode:setVisible(true)
            end
        end
    end
    
    --print "2"
    if nil ~= LiBaoCommonCell["m_iconNode"] then
    	self.m_iconNode = tolua.cast(LiBaoCommonCell["m_iconNode"],"cc.LayerColor")
        if nil ~= self.m_iconNode then
            LuaController:addItemIcon(self.m_iconNode,self.data[1],self.m_nameLabel)

            if self.data[2]=="1" then
                if nil ~= self.m_singleNode then
                    self.m_iconNode:setPosition(self.m_singleNode:getPosition())
                end
            else
                if nil ~= self.m_multiNode then
                    self.m_iconNode:setPosition(self.m_multiNode:getPosition())
                end
            end
            self.m_iconNode:setPositionX(self.m_iconNode:getPositionX()+14)
            self.m_iconNode:setPositionY(self.m_iconNode:getPositionY()+14)
            self.m_iconNode:setScale(1.4)
        end
    end
    self:addChild(node)
    local chechV = tostring(CCCommonUtilsForLua:getPropById("99020","k1"))
    if CCCommonUtilsForLua:checkVersion(chechV) == true then
        if CCCommonUtilsForLua:isFlip() then
            self:setFlip()
        end
    end
end

function GoldExchangeCommonCell:setFlip()
    if self.m_nameLabel ~= nil then
        self.m_nameLabel:setScaleX(-1)
    end
    if self.m_numLabel ~= nil then
        self.m_numLabel:setScaleX(-1)
    end
end