function loadLuaResource(path)
	--print "function loadLuaResource(path)"
	if (nil ~=path) then
		cc.SpriteFrameCache:getInstance():addSpriteFrames(path)
    end
end
function releaseLuaResource(path)
	--print "function releaseLuaResource(path)"
	
	if(nil ~= path) then
		local plistPath = path .. ".plist"
		print ("release plist: " .. plistPath)
		cc.SpriteFrameCache:getInstance():removeSpriteFramesFromFile(plistPath)
		local texturePath = path .. ".pvr.ccz"
		local texture  = cc.Director:getInstance():getTextureCache():getTextureForKey(texturePath)
        if(nil ~= texture) then
        	print ("release texture" .. texturePath)
            cc.Director:getInstance():getTextureCache():removeTextureForKey(texturePath)
        end
	end
end
function releaseLuaResourceForAndroid(path,res)
	--print "function releaseLuaResource(path)"
	
	if(nil ~= path) then
		local plistPath = path .. res .. ".plist"
		print ("release plist: " .. plistPath)
		cc.SpriteFrameCache:getInstance():removeSpriteFramesFromFile(plistPath)
		local texturePath = path .. "_alpha_" .. res .. "_alpha.pkm"
		local texture  = cc.Director:getInstance():getTextureCache():getTextureForKey(texturePath)
        if(nil ~= texture) then
        	print ("release texture" .. texturePath)
            cc.Director:getInstance():getTextureCache():removeTextureForKey(texturePath)
        end
        local texturePath1 = path .. "_alpha_" .. res .. ".pkm"
		local texture1  = cc.Director:getInstance():getTextureCache():getTextureForKey(texturePath1)
        if(nil ~= texture1) then
        	print ("release texture" .. texturePath1)
            cc.Director:getInstance():getTextureCache():removeTextureForKey(texturePath1)
        end
	end
end
function loadCommonResource(index,isLoad)
	--print "function loadCommonResource(index,isLoad)"
	LuaController:doResourceByCommonIndex(index,isLoad)
end