local localize={
	["JA"]=1, 
}
return localize
