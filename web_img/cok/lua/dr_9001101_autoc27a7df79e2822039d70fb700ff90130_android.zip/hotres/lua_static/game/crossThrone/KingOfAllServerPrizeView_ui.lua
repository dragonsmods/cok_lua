----------------------------
-- Author: Elex
-- Date: 2017-09-01 11:42:48
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local KingOfAllServerPrizeView_ui = class("KingOfAllServerPrizeView_ui")

--#ui propertys


--#function
function KingOfAllServerPrizeView_ui:create(owner, viewType)
	local ret = KingOfAllServerPrizeView_ui.new()
	CustomUtility:DoRes(100, true)
	CustomUtility:DoRes(305, true)
	CustomUtility:DoRes(310, true)
	CustomUtility:LoadUi("KingOfAllServerPrizeView.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function KingOfAllServerPrizeView_ui:initLang()
end

function KingOfAllServerPrizeView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function KingOfAllServerPrizeView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return KingOfAllServerPrizeView_ui

