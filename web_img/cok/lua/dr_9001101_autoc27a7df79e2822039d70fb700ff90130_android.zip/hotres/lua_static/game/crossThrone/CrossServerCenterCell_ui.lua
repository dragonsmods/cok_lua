----------------------------
-- Author: Elex
-- Date: 2018-12-20 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CrossServerCenterCell_ui = class("CrossServerCenterCell_ui")

--#ui propertys


--#function
function CrossServerCenterCell_ui:create(owner, viewType, paramTable)
	local ret = CrossServerCenterCell_ui.new()
	CustomUtility:DoRes(11, true)
	CustomUtility:LoadUi("CrossServerCenterCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CrossServerCenterCell_ui:initLang()
end

function CrossServerCenterCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CrossServerCenterCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CrossServerCenterCell_ui:onHelpButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onHelpButtonClick", pSender, event)
end

function CrossServerCenterCell_ui:onRewardButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onRewardButtonClick", pSender, event)
end

return CrossServerCenterCell_ui

