----------------------------
-- Author: Elex
-- Date: 2019-07-30 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local KingOfAllServerGiftBagSetView_ui = class("KingOfAllServerGiftBagSetView_ui")

--#ui propertys


--#function
function KingOfAllServerGiftBagSetView_ui:create(owner, viewType, paramTable)
	local ret = KingOfAllServerGiftBagSetView_ui.new()
	CustomUtility:LoadUi("KingOfAllServerAwardSetView.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function KingOfAllServerGiftBagSetView_ui:initLang()
end

function KingOfAllServerGiftBagSetView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function KingOfAllServerGiftBagSetView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function KingOfAllServerGiftBagSetView_ui:onOkBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onOkBtnClick", pSender, event)
end

return KingOfAllServerGiftBagSetView_ui

