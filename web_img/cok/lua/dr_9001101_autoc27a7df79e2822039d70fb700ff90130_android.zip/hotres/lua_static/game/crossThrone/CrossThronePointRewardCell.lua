local CrossThronePointRewardCell = class("CrossThronePointRewardCell", cc.TableViewCell)

function CrossThronePointRewardCell:create(rIdx, data)
	local cell = CrossThronePointRewardCell.new()
	Drequire("game.crossThrone.KingOfAllServerRewardCell2_ui"):create(cell, 0)
	--cell:refreshCell(rIdx, data)
	return cell
end

function CrossThronePointRewardCell:refreshCell(rIdx, data)
	self.rIdx = rIdx
	self.data = data

	local RewardType = RewardTypeConfig

	if type(self.data) == "number" then
		self.ui.m_titleNode:setVisible(true)
		self.ui.m_rewardNode:setVisible(false)
		self.ui.m_titleLabel:setString(getLang("165318", CC_CMDITOA(self.data)))
	else
		self.ui.m_titleNode:setVisible(false)
		self.ui.m_rewardNode:setVisible(true)

		self.ui.m_oddBg:setVisible(self.rIdx % 2 == 1)
		self.ui.m_evenBg:setVisible(self.rIdx % 2 == 0)

		local name, count, itemId = "", 0, 0
		local rwdType = atoi(data["type"])
		if rwdType == RewardType.R_GOODS or rwdType == RewardType.R_EQUIP then
			local valueDict= data["value"]
			itemId = atoi(valueDict["id"])
			count = atoi(valueDict["num"])
			name = RewardController:call("getInstance"):call("getNameByType", rwdType, itemId)
		else
			count = atoi(data["value"])
			name = RewardController:call("getInstance"):call("getNameByType", rwdType)
		end

		self.ui.m_iconNode:removeAllChildren()
		self.ui.m_nameLabel:setString(name)
		
		local str = " X" .. CC_CMDITOA(count)
		self.ui.m_numLabel:setString(str)
		
		if rwdType == RewardType.R_GOODS then
			local info = ToolController:call("getToolInfoByIdForLua", itemId)
			local pic = CCLoadSprite:createSprite(CCCommonUtilsForLua:call("getIcon", CC_ITOA(info:getProperty("itemId"))), CCLoadSpriteType.CCLoadSpriteType_GOODS)
			if pic ~= nil then
				local iconBg = CCLoadSprite:createSprite(CCCommonUtilsForLua:call("getToolBgByColor", info:getProperty("color")))
				CCCommonUtilsForLua:call("setSpriteMaxSize", iconBg, 50, true)
				self.ui.m_iconNode:addChild(iconBg)
				CCCommonUtilsForLua:call("setSpriteMaxSize", pic, 50, true)
				self.ui.m_iconNode:addChild(pic)
			end
			
		elseif rwdType == RewardType.R_EQUIP then
			
			local picStr = CCCommonUtilsForLua:call("getPropById", CC_ITOA(itemId), "icon")
			picStr = picStr .. ".png"
			local pic = CCLoadSprite:createSprite(picStr,CCLoadSpriteType.CCLoadSpriteType_EQUIP)
			if pic ~= nil then
				local colorStr = CCCommonUtilsForLua:call("getPropById", CC_ITOA(itemId), "color")
				local iconBg = CCLoadSprite:createSprite(CCCommonUtilsForLua:call("getToolBgByColor", atoi(colorStr)))
				CCCommonUtilsForLua:call("setSpriteMaxSize", iconBg, 50, true)
				self.ui.m_iconNode:addChild(iconBg)
				CCCommonUtilsForLua:call("setSpriteMaxSize", pic, 50, true)
				self.ui.m_iconNode:addChild(pic)
			end
			local name = CCCommonUtilsForLua:call("getPropById", CC_ITOA(itemId), "name")
			self.ui.m_nameLabel:setString(_lang(name))
		else
			local pic = CCLoadSprite:createSprite(CCCommonUtilsForLua:call("getResourceIconByType", rwdType), CCLoadSpriteType.CCLoadSpriteType_DEFAULT)
			if pic ~= nil then
				CCCommonUtilsForLua:call("setSpriteMaxSize",pic, 50, true)
				self.ui.m_iconNode:addChild(pic)
			end
		end
	end
end

return CrossThronePointRewardCell