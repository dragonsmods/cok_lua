local CrossThroneKingGiftView = class("CrossThroneKingGiftView",
	function()
		return PopupBaseView:create()
	end
)

local CrossThroneKingGiftCell = class("CrossThroneKingGiftCell",
	function()
		return cc.Layer:create()
	end
)


------------------------------CrossThroneKingGiftView------------------------------

function CrossThroneKingGiftView:create(dialogId, kingIsMine, kingData)
	local view = CrossThroneKingGiftView.new()
	Drequire("game.crossThrone.KingOfAllServerTitleView_ui"):create(view, 0)
	if view:initView(dialogId, kingIsMine, kingData) then
		return view
	end
end

function CrossThroneKingGiftView:initView(dialogId, kingIsMine, kingData)
	if self:init(true, 0) == false then
		return false
	end

	self:setHDPanelFlag(true)

	self.dialogId = dialogId
	self.kingIsMine = kingIsMine

	self.ipadLike = CCCommonUtilsForLua:isIosAndroidPad()
	if self.ipadLike then
		self.ui.m_topNode:setScale(2.4)
		self.ui.m_bellowNode:setScale(2.4)
	end

	self.ui.m_headNode:removeAllChildren()
	self.ui.m_kingNode:removeAllChildren()
	self.ui.m_listNode:removeAllChildren()

	dump(kingData, "kingData")
	if kingData.uid ~= "" then
		if (kingData.pic == "") then
			kingData.pic = "g044.png"
		else
			kingData.pic = kingData.pic .. ".png"
		end

		local icon = CCLoadSprite:call("createSprite", kingData.pic, CCLoadSpriteType.CCLoadSpriteType_HEAD_ICON)
		CCCommonUtilsForLua:setSpriteMaxSize(icon, 67, true)
		self.ui.m_headNode:addChild(icon)

		if (CCCommonUtilsForLua:call("isUseCustomPic", kingData.picVer)) then
			local headImgNode = HFHeadImgNode:call("create")

			local picUrl = CCCommonUtilsForLua:call("getCustomPicUrl", kingData.uid, kingData.picVer)
			headImgNode:call("initHeadImgUrl2", self.ui.m_headNode, picUrl, 1.0, 67, true)
		end
	else
		local icon = CCLoadSprite:call("createSprite", "despot_empty.png", CCLoadSpriteType.CCLoadSpriteType_HEAD_ICON)
		CCCommonUtilsForLua:setSpriteMaxSize(icon, 67, true)
		self.ui.m_headNode:addChild(icon)
	end

  	local addHeight = self:getExtendHeight()
	local oldSize = self.ui.m_listNode:getContentSize()
	self.ui.m_listNode:removeAllChildren()
	self.ui.m_listNode:setContentSize(cc.size(oldSize.width, oldSize.height + addHeight))
	Dprint("oldSize", oldSize.width, oldSize.height, addHeight)

	self.m_tableView = cc.TableView:create(self.ui.m_listNode:getContentSize())
	self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
	self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
	self.m_tableView:setDelegate()
	self.m_tableView:registerScriptHandler(function(tab, idx) return self:cellSizeForTable(tab, idx) end, cc.TABLECELL_SIZE_FOR_INDEX)
	self.m_tableView:registerScriptHandler(function(tab, idx) return self:tableCellAtIndex(tab, idx) end, cc.TABLECELL_SIZE_AT_INDEX)
	self.m_tableView:registerScriptHandler(function(tab) return self:numberOfCellsInTableView(tab) end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
	self.ui.m_listNode:addChild(self.m_tableView)

	local ctManager = require("game.crossThrone.CrossThroneManager")
	if ctManager:isDespotServer() then
		self.battleType = DESPOT_BATTLE
		if kingData.name ~= "" then
			self.ui.m_nameLabel:setString(getLang("138312") .. " " .. kingData.name)
		else
			--self.ui.m_headNode:setVisible(false)
			self.ui.m_nameLabel:setString(getLang("138329"))
		end
		self.ui.m_detailLabel:setString(getLang("138379"))
	else
		self.battleType = EMPIRE_BATTLE
		self.ui.m_detailLabel:setString(getLang("138362"))
	end

	local typePic = ctManager:getThroneTypePic(self.battleType)
	local icon = CCLoadSprite:call("createSprite", typePic, CCLoadSpriteType.CCLoadSpriteType_GOODS)
	self.ui.m_kingNode:addChild(icon)
	self.ui.m_kingNode:setScale(0.8)

	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	self.serverId = playerInfo:getProperty("currentServerId")

	Dprint("self.serverId", self.serverId)
	ctManager:requestGiftData(self.battleType, self.serverId, kingData.uid)

	local award_reward = splitString(ctManager:getDespotPropertyByKey("award_reward"), "|")
	local award_num = splitString(ctManager:getDespotPropertyByKey("award_num"), "|")
	local award_colour = splitString(ctManager:getDespotPropertyByKey("award_colour"), "|")
	local award_dec = splitString(ctManager:getDespotPropertyByKey("award_dec"), "|")
	local award_name = splitString(ctManager:getDespotPropertyByKey("award_name"), "|")
	local award_icon = splitString(ctManager:getDespotPropertyByKey("award_icon"), "|")

	self.m_data = {}
	self.rewardConfig = {}
	for index = 1, #award_reward do
		local rewardId = award_reward[index]
		self.m_data[#self.m_data + 1] = {
			["rewardId"] = rewardId,
			["player"] = {},
		}
		self.rewardConfig[rewardId] = {
			limit = award_num[index],
			color = award_colour[index],
			des = award_dec[index],
			name = award_name[index],
			icon = award_icon[index],
			id = rewardId,
		}
	end
	dump(self.rewardConfig, "self.rewardConfig")
	self.m_tableView:reloadData()

	return true
end

function CrossThroneKingGiftView:refreshView(param)
	if param == nil then return end

	local tbl = dictToLuaTable(param)
	dump(tbl, "CrossThroneKingGiftView refreshView")
	if tbl.reward then
		if sizen(tbl.reward) > 0 then
			for _, v in ipairs(tbl.reward) do
				for _, n in ipairs(self.m_data) do
					if n.rewardId == v.rewardId then
						n.player = v.player
					end
				end
			end
			self.m_tableView:reloadData()
		end
	end
end

function CrossThroneKingGiftView:cellSizeForTable(tabView, idx)
	return 640, 130
end

function CrossThroneKingGiftView:tableCellAtIndex(tabView, idx)
	if (idx >= #self.m_data) then return end

	local rewardId = self.m_data[idx + 1].rewardId
	local cell = tabView:dequeueCell()
	if cell then
		local node = cell:getChildByTag(666)
		node:setData(self.m_data[idx + 1], self.rewardConfig[rewardId], self.kingIsMine)
	else
		cell = cc.TableViewCell:create()
		local node = CrossThroneKingGiftCell:create(self.m_data[idx + 1], self.rewardConfig[rewardId], self.kingIsMine)
		node:setTag(666)
		cell:addChild(node)
	end
	
	return cell
end

function CrossThroneKingGiftView:numberOfCellsInTableView(tabView)
	return sizen(self.rewardConfig)
end

function CrossThroneKingGiftView:sendGiftSuccess(pObj)
	if pObj then
		local tbl = dictToLuaTable(pObj)
		local rewardId = tostring(tbl.infoDic.rewardId)
		for k, v in ipairs(self.m_data or {}) do
			if v.rewardId == rewardId then
				local player = {}
				player["kingdom"] = tbl.kingdom
				player["name"] = tbl.name
				player["pic"] = tbl.pic
				player["picVer"] = tbl.picVer
				player["uid"] = tbl.uid
				player["abbr"] = tbl.abbr
				self.m_data[k].player[#self.m_data[k].player + 1] = player
				break
			end
		end
		self.m_tableView:reloadData()
	end
end

function CrossThroneKingGiftView:onEnter( ... )
	self:setTitleName(getLang(self.dialogId))

	local function callback1(param) self:refreshView(param) end
	local handler1 = self:registerHandler(callback1)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "crossThrone.gift")

	local function callback2(pObj) self:sendGiftSuccess(pObj) end
	local handler2 = self:registerHandler(callback2)
	CCSafeNotificationCenter:registerScriptObserver(self, handler2, "crossthrone.sendGift")
end

function CrossThroneKingGiftView:onExit( ... )
	CCSafeNotificationCenter:unregisterScriptObserver(self, "crossThrone.gift")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "crossThrone.sendGift")
end

------------------------------CrossThroneKingGiftView------------------------------

function CrossThroneKingGiftCell:create(rewardData, rewardConfig, kingIsMine)
	local view = CrossThroneKingGiftCell.new()
	Drequire("game.crossThrone.KingOfAllServerAwardCell_ui"):create(view, 1)
	if view:initView(rewardData, rewardConfig, kingIsMine) then
		return view
	end
end

function CrossThroneKingGiftCell:initView(rewardData, rewardConfig, kingIsMine)
	self:setData(rewardData, rewardConfig, kingIsMine)

	local touchLayer = cc.Layer:create()
	self:addChild(touchLayer)

	local function touchHandle( eventType, x, y )
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		
		else
			self:onTouchEnded(x, y)
		end
	end
	touchLayer:registerScriptTouchHandler(touchHandle)
	touchLayer:setTouchEnabled(true)
	touchLayer:setSwallowsTouches(false)

	CCCommonUtilsForLua:setButtonTitle(self.ui.m_nameButton, getLang("138453"))

	return true
end

function CrossThroneKingGiftCell:setData(rewardData, rewardConfig, kingIsMine)
	self.rewardData = rewardData
	self.rewardId = rewardData.rewardId
	self.rewardConfig = rewardConfig
	self.kingIsMine = kingIsMine

	self.ui.m_nameLabel:setString(getLang(rewardConfig.name))
	self.ui.m_desLabel:setString(getLang(rewardConfig.des))

	local restNum = atoi(rewardConfig.limit) - sizen(self.rewardData.player or {})
	restNum = restNum > 0 and restNum or 0
	self.ui.m_numLabel:setString(getLang("139096", tostring(restNum)))

	--self.ui.m_colorNode:removeAllChildren()
	self.ui.m_iconNode:removeAllChildren()

	local colorpath = "tool_" .. rewardConfig.color .. ".png"
	self.ui.m_colorSprite:setSpriteFrame(CCLoadSprite:call("loadResource", colorpath))

	local icon = CCLoadSprite:call("createSprite", rewardConfig.icon .. ".png", CCLoadSpriteType.CCLoadSpriteType_GOODS)
	self.ui.m_iconNode:addChild(icon)
	CCCommonUtilsForLua:call("setSpriteMaxSize", icon, 94, true)

end

function CrossThroneKingGiftCell:onTouchBegan(x, y)
	if isTouchInside(self.ui.m_touchNode, x, y) then
		self.m_touchPoint = ccp(x, y)
		return true
	end
end

function CrossThroneKingGiftCell:onTouchEnded(x, y)
	if isTouchInside(self.ui.m_touchNode, x, y) then
		local distance = ccpDistance(self.m_touchPoint, ccp(x, y))
		if distance > 20 then return end
		
		local rewardView = Drequire("game.crossThrone.CrossThroneGiftDetailView"):create(self.rewardConfig)
		PopupViewController:addPopupView(rewardView)
	end
end

function CrossThroneKingGiftCell:onNameButtonClick()
	local sendGiftView = Drequire("game.crossThrone.CrossThroneSendGiftView"):create(self.rewardData, self.rewardConfig, self.kingIsMine)
	PopupViewController:addPopupView(sendGiftView)
end

return CrossThroneKingGiftView