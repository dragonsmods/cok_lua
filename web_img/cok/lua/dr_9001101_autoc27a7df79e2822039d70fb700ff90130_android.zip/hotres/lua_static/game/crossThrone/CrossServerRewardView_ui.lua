----------------------------
-- Author: Elex
-- Date: 2018-08-23 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CrossServerRewardView_ui = class("CrossServerRewardView_ui")

--#ui propertys


--#function
function CrossServerRewardView_ui:create(owner, viewType, paramTable)
	local ret = CrossServerRewardView_ui.new()
	CustomUtility:LoadUi("CrossServerRewardView.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function CrossServerRewardView_ui:initLang()
end

function CrossServerRewardView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CrossServerRewardView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CrossServerRewardView_ui:onCloseButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onCloseButtonClick", pSender, event)
end

function CrossServerRewardView_ui:initTableView()
	TableViewSmoker:createView(self, "m_listTableView", "game.crossThrone.CrossServerRewardCell", 1, 5, "CrossServerRewardCell")
end

function CrossServerRewardView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return CrossServerRewardView_ui

