----------------------------
-- Author: Elex
-- Date: 2017-08-21 20:26:33
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local KingOfAllServerBuffCell_ui = class("KingOfAllServerBuffCell_ui")

--#ui propertys


--#function
function KingOfAllServerBuffCell_ui:create(owner, viewType)
	local ret = KingOfAllServerBuffCell_ui.new()
	CustomUtility:LoadUi("KingOfAllServerBuffCell.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function KingOfAllServerBuffCell_ui:initLang()
end

function KingOfAllServerBuffCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function KingOfAllServerBuffCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return KingOfAllServerBuffCell_ui

