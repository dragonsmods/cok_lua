local CrossServerBattleManager = class("CrossServerBattleManager")

function CrossServerBattleManager:initData(dict)
	self.battleMap = dictToLuaTable(dict)

	self.configMap = { }
	local crossUIConfig = dictToLuaTable(LocalController:call("shared"):call("DBXMLManager"):call("getGroupByKey", "cross_battlefield_UI"))
	for _, data in pairs(crossUIConfig) do
		self.configMap[data.activity_id] = data.activity_type
	end
end

function CrossServerBattleManager:isInFight(actId)
	local activity_type = self.configMap and self.configMap[actId] or "0"
	return self.battleMap and self.battleMap[activity_type] == "fight" or false
end

--有没有正在战斗阶段的活动
function CrossServerBattleManager:showFightTip()
	local tomorrow = GlobalDataCtr.getTomorrowTime()
	local sign = CCUserDefault:sharedUserDefault():getIntegerForKey("cross_server_battle_tip", 0)

	if sign < tomorrow then
		for _, state in pairs(self.battleMap or {}) do
			if state == "fight" then
				return true
			end
		end
	end

	return false 
end

--明天提醒
function CrossServerBattleManager:signTomorrowTip()
	local tomorrow = GlobalDataCtr.getTomorrowTime()
	CCUserDefault:sharedUserDefault():setIntegerForKey("cross_server_battle_tip", tomorrow)
	CCUserDefault:sharedUserDefault():flush()
end

function CrossServerBattleManager:purge()
	self.battleMap = nil
	self.configMap = nil
end

return CrossServerBattleManager