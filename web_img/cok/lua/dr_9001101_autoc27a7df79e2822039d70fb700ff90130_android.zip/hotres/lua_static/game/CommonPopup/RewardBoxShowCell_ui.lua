----------------------------
-- Author: Elex
-- Date: 2019-08-16 Friday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local RewardBoxShowCell_ui = class("RewardBoxShowCell_ui")

--#ui propertys


--#function
function RewardBoxShowCell_ui:create(owner, viewType, paramTable)
	local ret = RewardBoxShowCell_ui.new()
	CustomUtility:LoadUi("RewardBoxShowCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function RewardBoxShowCell_ui:initLang()
end

function RewardBoxShowCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function RewardBoxShowCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return RewardBoxShowCell_ui

