----------------------------
-- Author: Elex
-- Date: 2021-04-22 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local InformationPreview_ui = class("InformationPreview_ui")

--#ui propertys


--#function
function InformationPreview_ui:create(owner, viewType, paramTable)
	local ret = InformationPreview_ui.new()
	CustomUtility:DoRes(4, true)
	CustomUtility:LoadUi("InformationPreview.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function InformationPreview_ui:initLang()
	ButtonSmoker:setText(self.m_saveSetBtn, "115035")
	ButtonSmoker:setText(self.m_resetBtn, "111732")
end

function InformationPreview_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function InformationPreview_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function InformationPreview_ui:onClickSaveSet(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickSaveSet", pSender, event)
end

function InformationPreview_ui:onClickReset(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickReset", pSender, event)
end

function InformationPreview_ui:initTableView()
	TableViewSmoker:createView(self, "m_infoTableView", "game.CommonPopup.OverView.PreviewRootCell", 1, 10, "InformationPreviewRootCell")
	TableViewSmoker:createView(self, "m_switchTblView", "game.CommonPopup.OverView.PreviewSelectCell", 1, 10, "InformationPreviewSelectCell")
end

function InformationPreview_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return InformationPreview_ui

