local knightInstance = KnightTitleController:call("getInstance")

local BedgeBagNode = class("BedgeBagNode",
	function()
		return cc.Node:create() 
	end
)
BedgeBagNode.__index = BedgeBagNode

local BedgeCell = class("BedgeCell",
	function()
		return cc.Layer:create() 
	end
)
BedgeCell.__index = BedgeCell

function BedgeBagNode:create(extH)
	local node = BedgeBagNode.new()
	if node:initNode(extH) then return node end
end

function BedgeBagNode:initNode(extH)
	local proxy = cc.CCBProxy:create()
	local ccbUri = "BedgeBag_lua.ccbi"
	local node = CCBReaderLoad(ccbUri, proxy, self)

	local function onNodeEvent(event)
		if event == "enter" then
			self:onEnter()
		elseif event == "exit" then
			self:onExit()
		elseif event == "cleanup" then
			self:onCleanup()
		end
	end
	node:registerScriptHandler(onNodeEvent)
	self:addChild(node)

	self.m_mainNode:setContentSize(cc.size(self.m_mainNode:getContentSize().width, extH))
	
	self.m_bedgeIdVec = {}

	local resLists = ToolController:call("getInstance"):getProperty("m_typeTools")
	local tmpVec = resLists[19]
	for i = 1, #tmpVec do
		if (sizen(LONGYU_IDS) > 0 and LONGYU_IDS[tostring(tmpVec[i])]) then
			self.m_bedgeIdVec[#self.m_bedgeIdVec + 1] = tmpVec[i]
		end
	end

 	local delegate = {}
    delegate.gridAtIndex = function(tab, idx) return self:gridAtIndex(tab, idx) end
    delegate.numberOfCellsInTableView = function(tab) return self:numberOfCellsInTableView(tab) end
    delegate.numberOfGridsInCell = function(tab) return self:numberOfGridsInCell(tab) end
    delegate.gridSizeForTable = function(tab, idx) return self:gridSizeForTable(tab, idx) end

    self.m_tableView = require("game.utility.TableViewMultiCol").new(self.m_mainNode:getContentSize())
    self.m_tableView:setDelegate(delegate)
   	self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
	self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
	self.m_mainNode:addChild(self.m_tableView)
	self.m_key = ""

	local touchLayer = cc.Layer:create()
	self:addChild(touchLayer)

	local function touchHandle( eventType, x, y )
		-- print("touchHandle", eventType, x, y)
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
			self:onTouchMoved(x, y)
		else
			self:onTouchEnded(x, y)
		end
	end
	touchLayer:registerScriptTouchHandler(touchHandle)
	touchLayer:setTouchEnabled(true)
	touchLayer:setSwallowsTouches(false)

	return true
end

function BedgeBagNode:getGuideNode(key)
	if (key == "Bedge_Sel") then
		local nodeVec = self.m_tableView:getContainer():getChildren()
		for i = 1, #nodeVec do
			local nodeSVec = nodeVec[i]:getChildren()
			for j = 1, #nodeSVec do
				local bCell = nodeSVec[j]
				local node = bCell:getChildByTag(666)
				if (node.m_bedgeId == 209861) then
					self.m_key = key
					if (CCCommonUtilsForLua:isIosAndroidPad()) then
						local nodeSize = node.m_guideNode:getContentSize()
						node.m_guideNode:setContentSize(cc.size(nodeSize.width * 2.4, nodeSize.height * 2.4))
					end
					return node.m_guideNode
				end
			end
		end
	end
end

function BedgeBagNode:onEnter()
	self.m_tableView:reloadData()
end

function BedgeBagNode:onExit()
	-- body
end

function BedgeBagNode:onCleanup()
	-- body
end

function BedgeBagNode:scheduleUpdate()
	local function updatefunc(dt) self:onShowBedgeInfo(dt) end 
	self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(updatefunc, 0.8, false)
end

function BedgeBagNode:unscheduleUpdate()
	if self.entry then
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
		self.entry = nil
	end
end

function BedgeBagNode:onTouchBegan(x, y)
	self.m_bMove = false
	self.m_willShowId = 0
	self.m_showBedgeType = 0
	self:unscheduleUpdate()
	self.m_touchPoint = ccp(x, y)

	if isTouchInside(self.m_mainNode, x, y) then
		local nodeVec = self.m_tableView:getContainer():getChildren()
		for i = 1, #nodeVec do
			local nodeSVec = nodeVec[i]:getChildren()
			for j = 1, #nodeSVec do
				local bCell = nodeSVec[j]
				local node = bCell:getChildByTag(666)
				local bedgeId = node:isTouchIn(x, y)
				if (bedgeId > 0) then
					self.m_showBedgeType = 1
					self.m_willShowId = bedgeId
					if (self.m_key ~= "Bedge_Sel") then
						self:scheduleUpdate()
					end
					break
				end
			end

			if (self.m_willShowId > 0) then break end
		end

		return true
	else
		return false
	end
end

function BedgeBagNode:onTouchMoved(x, y)
	if (math.abs(y - self.m_touchPoint.y) > 20) then 
		self.m_bMove = true
	end
end

function BedgeBagNode:onTouchEnded(x, y)
	self:unscheduleUpdate()

	if (self.m_key == "Bedge_Sel") then
		CCSafeNotificationCenter:postNotification(GUIDE_INDEX_CHANGE, CCString:create(self.m_key))
	end
	if (self.m_showBedgeType == 3) then return end
	self.m_showBedgeType = 2
	if (not B_CHANGE) then return end

	local nodeVec = self.m_tableView:getContainer():getChildren()
	for i = 1, #nodeVec do
		local nodeSVec = nodeVec[i]:getChildren()
		for j = 1, #nodeSVec do
			local bCell = nodeSVec[j]
			local node = bCell:getChildByTag(666)
			if (node:cellTouchEnded(x, y)) then
				break
			end
		end
	end
end

function BedgeBagNode:onShowBedgeInfo(dt)
	--[[只schedule一次]]
	self:unscheduleUpdate()

	if (self.m_bMove) then return end
	if (self.m_showBedgeType == 1) then
		self.m_showBedgeType = 3
		local view = require("game.CommonPopup.Knight.BedgeInfoPop"):create(self.m_willShowId)
		PopupViewController:addPopupView(view)
	end
end

function BedgeBagNode:gridSizeForTable(table, idx)
	if (CCCommonUtilsForLua:isIosAndroidPad()) then
		return 110 * 2.4, 120 * 2.4
	end
	return 110, 120
end

function BedgeBagNode:gridAtIndex(table, idx)
	if (idx >= #self.m_bedgeIdVec) then return end

	local bedgeId = self.m_bedgeIdVec[idx + 1]
	local cell = table:dequeueGrid()
	if (cell) then
		local node = cell:getChildByTag(666)
		if node then node:setData(bedgeId) end
	else
		cell = cc.TableViewCell:create()
		local node = BedgeCell:create(bedgeId)
		node:setTag(666)
		cell:addChild(node)
	end

	return cell
end

function BedgeBagNode:numberOfCellsInTableView(table)
	return math.ceil(#self.m_bedgeIdVec / 5)
end

function BedgeBagNode:numberOfGridsInCell(table)
	return 5
end

--------------------------BedgeCell-------------------------

function BedgeCell:create(bedgeId)
	local node = BedgeCell.new()
	if node:initNode(bedgeId) then return node end
end

function BedgeCell:initNode(bedgeId)
	local proxy = cc.CCBProxy:create()
	local ccbUri = "BedgeCell_lua.ccbi"
	local node = CCBReaderLoad(ccbUri, proxy, self)

	local function onNodeEvent(event)
		if event == "enter" then
			self:onEnter()
		elseif event == "exit" then
			self:onExit()
		elseif event == "cleanup" then
			self:onCleanup()
			end
	end
	node:registerScriptHandler(onNodeEvent)
	self:addChild(node)

	if (CCCommonUtilsForLua:isIosAndroidPad()) then
		node:setScale(2.4)
	end
	local nodeSize = node:getContentSize()
	self:setContentSize(nodeSize.width, 100)
	self.m_nameLabel:setColor(cc.c3b(235, 146, 0))
	self.m_guideNode = cc.Node:create()
	self.m_guideNode:setContentSize(self.m_markSpr:getContentSize())
	self.m_guideNode:setPosition(self.m_markSpr:getPosition())
	self.m_markSpr:getParent():addChild(self.m_guideNode)
	self:setData(bedgeId)
	self.m_markSpr:setVisible(false)

	return true
end

function BedgeCell:onEnter()
	local function callback1(pObj) self:retData(pObj) end
	local function callback2(pObj) self:selData(pObj) end
	local handler1 = self:registerHandler(callback1)
	local handler2 = self:registerHandler(callback2)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, MSG_BEDGE_UPDATE)
	CCSafeNotificationCenter:registerScriptObserver(self, handler2, BEDGE_COMPOSE_MSG)
end

function BedgeCell:onExit()
	CCSafeNotificationCenter:unregisterScriptObserver(self, MSG_BEDGE_UPDATE)
	CCSafeNotificationCenter:unregisterScriptObserver(self, BEDGE_COMPOSE_MSG)
end

function BedgeCell:onCleanup()
	--body
end

function BedgeCell:setData(bedgeId)
	self.m_bedgeId = bedgeId
	local info = ToolController:call("getToolInfoByIdForLua", self.m_bedgeId)
	local iconStr = CCCommonUtilsForLua:call("getIcon", tostring(self.m_bedgeId))

	local cnt = info:call("getCNT")
	local para4 = info:getProperty("para4")
	self.m_numLabel:setString(tostring(cnt))
	self.m_iconNode:removeAllChildren()
	self.m_icon = CCLoadSprite:call("createSprite", iconStr, CCLoadSpriteType_GOODS)
	CCCommonUtilsForLua:setSpriteMaxSize(self.m_icon, 90, true)
	self.m_iconNode:addChild(self.m_icon)
	self.m_nameLabel:setString(getLang(para4))
	--套餐内组合列表，闪烁动画
	self.m_icon:stopAllActions()
	local mateVec = KnightController.getInstance():getMateVec()
	if mateVec and #mateVec > 0 then
		for k,v in pairs(mateVec) do
			if tonumber(v) == tonumber(bedgeId) then
				local fadeIn = cc.FadeIn:create(0.5)
				local fadeOut = cc.FadeOut:create(0.5)
				local seq = cc.Sequence:create(fadeIn, fadeOut)
				local forever = cc.RepeatForever:create(seq)
				self.m_icon:runAction(forever)
				break
			end
		end
	end

	if (cnt <= 0) then
		self.m_numLabel:setString("")
		self.m_nameLabel:setColor(cc.c3b(166, 166, 166))
		CCCommonUtilsForLua:setSpriteGray(self.m_icon, true)
	else
		self.m_nameLabel:setColor(cc.c3b(235, 146, 0))
	end
end

function BedgeCell:retData(param)
	local oldNum = 0
	local oldNumStr = self.m_numLabel:getString()
	if (oldNumStr ~= "") then
		oldNum = atoi(oldNumStr)
	end

	local info = ToolController:call("getToolInfoByIdForLua", self.m_bedgeId)
	local cnt = info:call("getCNT")
	self.m_numLabel:setString(tostring(cnt))

	if (cnt <= 0) then
		self.m_numLabel:setString("")
		self.m_nameLabel:setColor(cc.c3b(166, 166, 166))
		CCCommonUtilsForLua:setSpriteGray(self.m_icon, true)
	else
		CCCommonUtilsForLua:setSpriteGray(self.m_icon, false)
		self.m_nameLabel:setColor(cc.c3b(235, 146, 0))
	end

	if (cnt > oldNum) then
		local flyStr = "+"
		flyStr = flyStr .. tostring(cnt - oldNum)
		CCCommonUtilsForLua:call("flyUiResText", flyStr, self.m_iconNode, ccp(0, 0), cc.c3b(0, 255, 0), 2, 23)
	elseif (cnt < oldNum) then
		local flyStr = ""
		flyStr = flyStr .. tostring(cnt - oldNum)
		CCCommonUtilsForLua:call("flyUiResText", flyStr, self.m_iconNode, ccp(0, 10), cc.c3b(255, 0, 0), 3, 23)
	end
end

function BedgeCell:selData(param)
	if (param) then
		local ccStr = tolua.cast(param, "CCString")
		if (ccStr) then
			local tmpbedgeId = ccStr:intValue()
			if (tmpbedgeId == self.m_bedgeId) then
				self.m_markSpr:setVisible(true)
			else
				self.m_markSpr:setVisible(false)
			end
		end
	else
		self.m_markSpr:setVisible(false)
	end
end

function BedgeCell:isTouchIn(x, y)
	if (isTouchInside(self.m_touchBg, x, y)) then
		return self.m_bedgeId
	end
	return -1
end

function BedgeCell:cellTouchEnded(x, y)
	if (isTouchInside(self.m_touchBg, x, y)) then
		if CCCommonUtilsForLua:isFunOpenByKey("dragon_words_new_combine") then -- 新融合功能
			local mateVec = KnightController.getInstance():getMateVec()
			if mateVec and #mateVec > 0 then
				for k,v in pairs(mateVec) do
					if tonumber(v) == tonumber(self.m_bedgeId) then
						CCSafeNotificationCenter:postNotification(BEDGE_COMPOSE_MSG, CCString:create(tostring(self.m_bedgeId)))
						return
					end
				end
				CCCommonUtilsForLua:call("flyHint", "", "", getLang("160474")) --160474=上古龙语首次激活，需消耗对应的龙韵石各1枚，再次激活不再消耗\n点击龙韵石符号放入龙韵石
				return
			end
			CCSafeNotificationCenter:postNotification(BEDGE_COMPOSE_MSG, CCString:create(tostring(self.m_bedgeId)))
			return
		end
		local info = ToolController:call("getToolInfoByIdForLua", self.m_bedgeId)
		local cnt = info:call("getCNT")
		local para2 = info:getProperty("para2")
		if (cnt <= 0) then
			CCCommonUtilsForLua:call("flyHint", "", "", getLang("160325")) --提示材料不足
			return true
		end
		MyPrint("para2", para2)
		if (BEDGE_TYPE == 1) then --合成
			if (para2 ~= "") then
				if (cnt <= 2) then
					local ret = knightInstance:call("GetUseBedgeById", self.m_bedgeId)
					if (ret > 0) then
						--local kid = knightInstance:getProperty("m_curKnightTitleId")
						local kid = knightInstance:call("getCurrentOnId")
						local kName = CCCommonUtilsForLua:call("getNameById", tostring(kid))
						local fInfo = getLang("160301", info:call("getName"), kName)
						CCCommonUtilsForLua:call("flyHint", "", "", fInfo) --现在激活中的龙语正在使用
						return true
					end
				end

				if (LONGYU_IDS[para2] == nil) then --未解锁的不会显示
					CCCommonUtilsForLua:call("flyHint", "", "", getLang("160329")) --等级不足未解锁
					return true
				end
			else
				CCCommonUtilsForLua:call("flyHint", "", "", getLang("160329")) --到达最大了 不能合成
				return true
			end
		elseif (BEDGE_TYPE == 2) then--分解
			if (cnt == 1) then
				local ret = knightInstance:call("GetUseBedgeById", self.m_bedgeId)
				if (ret > 0) then
					--local kid = knightInstance:getProperty("m_curKnightTitleId")
					local kid = knightInstance:call("getCurrentOnId")
					local kName = CCCommonUtilsForLua:call("getNameById", tostring(kid))
					local fInfo = getLang("160301", info:call("getName"), kName)
					CCCommonUtilsForLua:call("flyHint", "", "", fInfo) --现在激活中的龙语正在使用
					return true
				end
			end

			if (info:getProperty("para3") == "") then
				CCCommonUtilsForLua:call("flyHint", "", "", getLang("160328")) --最小不能分解
				return true
			end
		end

		CCSafeNotificationCenter:postNotification(BEDGE_COMPOSE_MSG, CCString:create(tostring(self.m_bedgeId)))
		return true
	else
		return false
	end
end

return BedgeBagNode
