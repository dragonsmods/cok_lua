--建筑建造
local Cell_Building = class("Cell_Building",Drequire("game.CommonPopup.OverView.Cell_Info.Cell_QueueFile"))
--建造队列1，2，3
local BUILD_QUEUE_1ST = 1101 --必有
local BUILD_QUEUE_2ND = 1102 --3级以上购买解锁
local BUILD_QUEUE_3RD = 1103 --备用，尚未实现

function Cell_Building:create(Id)
    local ret = Cell_Building.new(Id)
    if ret:initBaseById(Id) then
        return ret
    end
end

function Cell_Building:getCureQueueInfo()
    if not self:checkIsVisible() then
        return
    end
    local tempTbl = {}
    tempTbl[#tempTbl+1] = self:getSubTypeCellTbl(BUILD_QUEUE_1ST)
    tempTbl[#tempTbl+1] = self:getSubTypeCellTbl(BUILD_QUEUE_2ND)
    self.CellTbl.cellMeta=tempTbl
    return self.CellTbl

end

function Cell_Building:getSubTypeCellTbl(qid)
    local TYPE_BUILDING = 0 --建筑
    local res = {}
	local _state = self.Queue_ST_Init
	local _finishTime = -1
	local _totalTime = -1
	local _label = ""
	local _type = -1
    local _id = ""
    local _name = ""
    local _icon = ""
    local _visible = ""
    
    local qInfo = self.allQueuesInfos[qid]

    if qid ~= QID_MAX then
        _state,_finishTime,_totalTime = self:getQueueState(qInfo)
	else
		_state = self.Queue_ST_IDLE
		_finishTime = 0
		
	end

	if _state == self.Queue_ST_LOCK then
        _label = "2000442" --2000442=未解锁
    elseif _state == self.Queue_ST_IDLE then
        _label = "169606" --空闲中
    elseif _state == self.Queue_ST_WORK then
        _label = "2000438" --建筑升级中
    end
    if qid == BUILD_QUEUE_1ST then
        _id = "30711001"
    elseif qid == BUILD_QUEUE_2ND then
        _id = "30711002"
    end	


    if  _label ~= "" then
        _name,_icon,_visible = self:getNameIconVisibleBySubId(_id)        
		res = {id = _id, state = _state, param1 = _finishTime, param2 = _totalTime,label = _label,name = _name,icon = _icon,order = _order,cell = self}
    end
    if _visible == "1" then
        return res
    end
end

function Cell_Building:OnClickJump(_id,_state)

    local function condiction(info)
        local classType = info:getProperty("classType")
        local isBuildType =  classType == 0 or classType == 8
        local gotype = info:getProperty("gotype")
        local isBuildGoType = gotype == 1 or gotype == 2
        local order = info:getProperty("order")
        local state = info:getProperty("state")
        if (isBuildType == false) or  (order <= 0) or (state ~= 0) or (isBuildGoType == false) then
            return false
        else
            return true
        end
    end

    --检查下当前是否已安排建造任务,实现跳转
    local function getArcQuest()
        local currentAchList = QuestController:call("getInstance"):getProperty("currentAchList")
        local min_info
        for k, v in pairs(currentAchList) do
            if condiction(v) then
                if min_info == nil then
                    min_info = v
                elseif min_info:getProperty("order") > v:getProperty("order") then
                    min_info = v
                end
            end
        end
        --如果找到了
        if min_info then
            local itemId = min_info:getProperty("go")
            local gotype = min_info:getProperty("gotype")               
            if gotype == 2 then
                --已有建筑，直接跳转升级
                self:jumpByTypeAndTarget(1,itemId)
            elseif gotype == 1 then
                --去建造
                local scene
                local layer = SceneController:call("getCurrentLayerByLevel", LEVEL_SCENE)
                if layer then
                    scene = ImperialScene:call("getInstance")
                    itemId = scene:call("findCanBuildTile",itemId)
                end                    
                if scene and itemId ~= -1 then
                    --找到空闲坑
                    scene:call("onMoveToBuildAndPlay",itemId)
                else
                    --理应不出现的一种情况
                    CCCommonUtilsForLua:call("flyHint", "", "", getLang("102295"))
                end
            else
                CCCommonUtilsForLua:call("flyHint", "", "", getLang("102295"))
            end
        else
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("102295"))
        end
    end

    if _id == "30711001" then
        if _state == self.Queue_ST_WORK then
            local qInfo = self.allQueuesInfos[BUILD_QUEUE_1ST]
            local key = qInfo:getProperty("key")
            if key ~= "" then
                local targetId = math.floor( tonumber(key)/1000 )
                self:jumpByTypeAndTarget(1,targetId)
            end
        elseif _state == self.Queue_ST_IDLE then
            getArcQuest()
        end
    elseif _id == "30711002" then
        --购买第二队列回调
        local function onYesOpen()
            local baseTime = FunBuildController:call("getInstance"):getProperty("building_base_k8")
            QueueController:call("getInstance"):call("rentQueue",BUILD_QUEUE_2ND,baseTime ,true)
            local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
            local level = playerInfo:getProperty("level")
            FBUtiliesInLua:call("appEventHireWorker",self.mainCityLv,level)
            AppLibHelper:call("triggerEventPromotionForAdwords", eTriggerEventPromotion_HireWorker)
            local param = {cityLevel = self.mainCityLv, playerLevel = level}
            -- sendAdjustStatistic("RentQueue", param)
        end
        if _state == self.Queue_ST_LOCK then
            local gold = FunBuildController:call("getInstance"):getProperty("building_base_k9")
            YesNoDialog:call("showButtonAndGold", getLang("102296"), cc.CallFunc:create(onYesOpen), getLang("102174"), gold)
        elseif _state == self.Queue_ST_IDLE then
            getArcQuest()
        elseif _state == self.Queue_ST_WORK then
            local qInfo = self.allQueuesInfos[BUILD_QUEUE_2ND]
            local key = qInfo:getProperty("key")
            if key ~= "" then
                local targetId = math.floor( tonumber(key)/1000 )
                self:jumpByTypeAndTarget(1,targetId)
            end
        end
    end

end

return Cell_Building