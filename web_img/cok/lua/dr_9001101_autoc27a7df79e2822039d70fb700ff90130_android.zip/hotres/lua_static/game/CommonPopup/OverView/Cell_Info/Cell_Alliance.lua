--联盟
local Cell_Alliance = class("Cell_Alliance",Drequire("game.CommonPopup.OverView.Cell_Info.Cell_MainFile"))
function Cell_Alliance:create(Id)
    local ret = Cell_Alliance.new(Id)
    if ret:initBaseById(Id) then
        return ret
    end
end
function Cell_Alliance:getCellDataTbl()
    if not self:checkIsVisible() then
        return
    end
    local now = getTimeStamp()
    local _id = ""
    local _finishTime = -1
    local _state = -1
    local _label = ""
    local _name = ""
    local _icon = ""
    local _visible = ""
    local _cancelJump = false
    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
    local isInAlliance = playerInfo:call("isInAlliance")  
    if isInAlliance then
        local tempTbl = {}						
        local allianceInfo = playerInfo:getProperty("allianceInfo")
        --联盟帮助
        _id = '30711018'
        local helpcount = allianceInfo:getProperty("helpcount") --联盟可帮助次数
        if helpcount > 0 then
            --可帮助
            _state = self.Queue_ST_WORK
            _finishTime = helpcount
            -- _label = '4249641' --联盟帮助{0}次
            _label = self:getDialogByIdIndex(_id,1)
        else
            _cancelJump = true
            _state = self.Queue_ST_IDLE
            _finishTime = 0
            -- _label = '107079' --他不需要帮助
            _label = self:getDialogByIdIndex(_id,3)
        end
        _name,_icon,_visible = self:getNameIconVisibleBySubId(_id)
        local meta = { id = _id, name = _name,icon = _icon, order = _order, state = _state,param1 = _finishTime, label = _label, cancelJump = _cancelJump,cell = self}
        if _visible == "1" then
            table.insert(tempTbl, meta)
        end
        
        --今日剩余挖掘
        _id = "30711019"
        _cancelJump = false
        local allianceCtr = AllianceDailyController:call("getInstance")
        local m_sendCount = allianceCtr:getProperty("m_sendCount")
        local limit = allianceCtr:getProperty("conditionPublishLevel")
        if self.mainCityLv >= limit then
            if m_sendCount > 0 then --可以挖掘
                _state = self.Queue_ST_WORK
                _finishTime = m_sendCount
                _label = self:getDialogByIdIndex(_id,1)
            else
                _cancelJump = true
                _state = self.Queue_ST_IDLE
                _finishTime = m_sendCount
                _label = self:getDialogByIdIndex(_id,2)		
            end
        else
            _state = self.Queue_ST_LOCK
            _finishTime = -1
            _label = "2000442"
        end
        _name,_icon,_visible = self:getNameIconVisibleBySubId(_id)
        local meta2 = { id = _id, name = _name,icon = _icon, state = _state,param1 = _finishTime, label = _label,cancelJump = _cancelJump,cell = self}
        if _visible == "1" then
            table.insert(tempTbl, meta2)
        end			
        if #tempTbl > 0 then
            self.CellTbl.cellMeta=tempTbl
        end
        return self.CellTbl
    end
end

function Cell_Alliance:OnClickJump(_id,_state)
    if _id == "30711018" then
        local dict = CCDictionary:create()
        dict:setObject(CCString:create("AllianceHelpView"), "name")
        LuaController:call("openPopViewInLua", dict)
    elseif _id == "30711019" then
        if _state ~= self.Queue_ST_LOCK then
            local dict = CCDictionary:create()
            dict:setObject(CCString:create("AllianceDailyPublishView"), "name")
            LuaController:call("openPopViewInLua", dict)
        else
            local limit = AllianceDailyController:call("getInstance"):getProperty("conditionPublishLevel")
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("134068", tostring(limit)))
        end
    end
end

return Cell_Alliance