local CCFlagWaveSprite = class("CCFlagWaveSprite",function()
    return CCLoadSprite:createSprite()
end)
local isNewRender = isNewRender()
local vertShaderByteArray = "\n"..  
        "attribute vec4 a_position; \n" ..
        "attribute vec2 a_texCoord; \n" ..
        "attribute vec4 a_color; \n"..
        "#ifdef GL_ES  \n"..
        "varying lowp vec4 v_fragmentColor;\n"..
        "varying mediump vec2 v_texCoord;\n"..
        "#else                      \n" ..
        "varying vec4 v_fragmentColor; \n" ..
        "varying vec2 v_texCoord;  \n"..
        "#endif    \n"..
        "varying highp float v_time;    \n"..
        "uniform highp vec2 uniformTT;   \n"..
        "void main() \n"..
        "{\n" ..
        "v_time = fract(0.1 * CC_Time.g); \n"..
        "gl_Position = CC_PMatrix * (a_position + vec4(-(a_texCoord.x - uniformTT.x) * 20.0, -(a_texCoord.x - uniformTT.x) * 30.0 - (a_texCoord.x - uniformTT.x) * (a_texCoord.y - uniformTT.y) * 400.0, 0.0, 0.0));\n"..
        "v_fragmentColor = a_color;\n"..
        "v_texCoord = a_texCoord;\n"..
        "}"
 
local flagShaderByteArrayOthers = "#ifdef GL_ES \n" ..
    "precision mediump float; \n" ..
    "#endif \n" ..
    "varying vec4 v_fragmentColor; \n" ..
    "varying vec2 v_texCoord; \n" ..
    "varying highp float v_time;\n"..
    "uniform highp float sinWidth_L;\n"..
    "uniform highp float sinHeight_L; \n"..
    "uniform highp vec2 uniformTT; \n"..
    "void main(void) \n" ..
    "{ \n" ..
    "vec2 pos;\n"..
    "float time = v_time * 50.0;"..
    "time = mod(time, 360.0); \n" ..
    "pos.x = v_texCoord.x;\n"..
    "float s = cos(sinWidth_L *(v_texCoord.x) - time);\n"..
    "pos.y = v_texCoord.y + s * sinHeight_L * (v_texCoord.x - uniformTT.x) * 20.0;\n"..
    "gl_FragColor =  v_fragmentColor * texture2D(CC_Texture0, pos);"..
    "}"

local flagShaderByteArrayAndroid = "#ifdef GL_ES \n" ..
    "precision mediump float; \n" ..
    "#endif \n" ..
    "varying vec4 v_fragmentColor; \n" ..
    "varying vec2 v_texCoord; \n" ..
    "varying highp float v_time; \n"..
    "uniform highp float sinWidth_L; \n"..
    "uniform highp float sinHeight_L;\n"..
    "uniform highp vec2 uniformTT;\n"..
    "void main(void) \n" ..
    "{ \n" ..
    "vec2 pos;\n"..
    "float time = v_time * 100.0;\n"..
    "time = mod(time, 360.0);\n"..
    "pos.x = v_texCoord.x;\n"..
    "float s = cos(sinWidth_L *(v_texCoord.x) - time); \n"..
    "pos.y = v_texCoord.y + s * sinHeight_L * (v_texCoord.x - uniformTT.x) * 10.0; \n"..
    "vec4 color = texture2D(CC_Texture0, pos); \n"..
    "color.a = texture2D(CC_Texture1, pos).r; \n"..
    "gl_FragColor =  v_fragmentColor * color; \n"..
    "}"

function CCFlagWaveSprite:create(sf,quard_x,quard_y)
    local sprite = CCFlagWaveSprite.new()
    if sprite:initSpr(sf,quard_x,quard_y) then
        return sprite
    end
end

function CCFlagWaveSprite:initSpr(sf,quard_x,quard_y)
    if sf == nil then
        return false
    end
    self:setSpriteFrame(sf)
    self:initShader()
    self:setSpriteWave(quard_x,quard_y)
    return true
end

function CCFlagWaveSprite:initShader()
	if isNewRender then
		local flagShaderByteArray = isAndroid() and flagShaderByteArrayAndroid or flagShaderByteArrayOthers
		local Program = cc.Program:createWithByteArrays(vertShaderByteArray,flagShaderByteArray)
		cc.ProgramCache:getInstance():addGLProgram(Program, "flagWaveShader_lua")
	end
end

function CCFlagWaveSprite:setSpriteWave(quard_x,quard_y)
    local scaleX = self:getSpriteFrame():getRectInPixels().width / self:getTexture():getContentSizeInPixels().width
    local scaleY = self:getSpriteFrame():getRectInPixels().height / self:getTexture():getContentSizeInPixels().height
    local sinWidth = 7.0 / scaleX
    local sinHeight = scaleY * 0.12
    local r = self:getTextureRect()
    r.y = r.y - r.height * 0.1
    r.height = r.height * 1.2
    self:setTextureRect(r)
    if isNewRender then
        local p = cc.ProgramCache:getInstance():getGLProgram("flagWaveShader_lua")
        if p then    
            local Program = cc.ProgramState:create(p)
            Program:setUniformFloat("sinWidth_L",sinWidth)
            Program:setUniformFloat("sinHeight_L",sinHeight)
            quard_x = quard_x and quard_x or 0.685
            quard_y = quard_y and quard_y or 0.7
            local quad = ccp(quard_x,quard_y)            
            Program:setUniformVec2("uniformTT",quad)            
            self:setProgramState(Program)
        end        
    end
end

return CCFlagWaveSprite