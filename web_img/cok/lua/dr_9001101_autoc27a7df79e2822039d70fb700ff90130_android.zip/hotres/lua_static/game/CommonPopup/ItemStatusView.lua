 local ItemStatusView = class("ItemStatusView",
	function()
		return PopupBaseView:create() 
	end
)
ItemStatusView.__index = ItemStatusView

local ItemStatusTypeCell = class("ItemStatusTypeCell",
	function()
		return cc.Layer:create()
	end
)
ItemStatusTypeCell.__index = ItemStatusTypeCell
ItemStatusTypeCellOwner = ItemStatusTypeCellOwner or {}
ccb["ItemStatusTypeCellOwner"] = ItemStatusTypeCellOwner

local ArtilleryBuffType = 9999
local ArtilleryBuffTimeType = 66

function ItemStatusView:create(dict)
	local view = ItemStatusView.new()
	if (view:initView(dict)) then return view end
end

function ItemStatusView:ctor()
	--额外状态
	self.extraStatus = {}
end

function ItemStatusView:initView(dict)
	if (self:init(true, 0)) and FunOpenController:isUnlock("fun_cityBuff", true) then
		self:setIsHDPanel(true)	
		local entrance = nil 
		if dict then
			local tbl = dictToLuaTable(dict)
			entrance = tbl.entrance
			if(entrance == 1) then --参数是1，则需要根据match_show判断是否显示该项目
				self.filter_by_match_show=1 
	    	end
		end
		local winSize = getWinSize()
		CCCommonUtilsForLua:call("makeBatchBG", self, winSize, ccp(0, 0), 1)
		if CCCommonUtilsForLua:isFunOpenByKey("new_expedition_extra") then
			CCLoadSprite:call("loadDynamicResourceByName", "fortress_face")
		end
       
		local proxy = cc.CCBProxy:create()
		local ccbUri = "ItemStatusView02_lua.ccbi"
		local node = CCBReaderLoad(ccbUri, proxy, self)
		local size = node:getContentSize()
		self:setContentSize(size)
		CCCommonUtilsForLua:call("makeBatchBG", self.m_bgNode, winSize, ccp(0.5, 1), 1)

		CCLoadSprite:call("loadDynamicResourceByName", "artillery_face")

		local function onNodeEvent(event)
			if event == "enter" then
				self:onEnter()
			elseif event == "exit" then
				self:onExit()
			elseif event == "cleanup" then
				self:onCleanup()
 			end
		end
		node:registerScriptHandler(onNodeEvent)
		self:addChild(node)

		local addHeight = self:getExtendHeight()
		local listSize = self.m_infoList:getContentSize()
		self.m_infoList:setPositionY(self.m_infoList:getPositionY() - addHeight)
		self.m_infoList:setContentSize(cc.size(listSize.width, listSize.height + addHeight))

	 	self.m_tableView = cc.TableView:create(self.m_infoList:getContentSize())
		self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
		self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
		self.m_tableView:setDelegate()
		self.m_tableView:registerScriptHandler(function(tab, cell) self:tableCellTouched(tab, cell) end, cc.TABLECELL_TOUCHED)
		self.m_tableView:registerScriptHandler(function(tab, idx) return self:cellSizeForTable(tab, idx) end, cc.TABLECELL_SIZE_FOR_INDEX)
		self.m_tableView:registerScriptHandler(function(tab, idx) return self:tableCellAtIndex(tab, idx) end, cc.TABLECELL_SIZE_AT_INDEX)
		self.m_tableView:registerScriptHandler(function(tab) return self:numberOfCellsInTableView(tab) end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
		self.m_infoList:addChild(self.m_tableView)

		return true
	end

	return false
end

function ItemStatusView:updateLocalInfo()
	ToolController:call("getInstance"):setProperty("m_typeItems", {})
	self.m_statusIdItems = {}
	local serverType = GlobalData:call("shared"):getProperty("serverType")
	local forbidden_frozen = CCCommonUtilsForLua:isFunOpenByKey("forbidden_frozen")
	local statusItems = FunBuildController:call("getCityItemStatus")
	for index, buffId in ipairs(statusItems) do
		-- 战场不支持冰冻弹
		if buffId == "108870" then
			if forbidden_frozen == true and serverType ~= ServerType.SERVER_NORMAL then
				-- table.insert(self.m_statusIdItems, buffId)
			else
				table.insert(self.m_statusIdItems, buffId)
			end
		else
			table.insert(self.m_statusIdItems, buffId)
		end
	end
	if self.filter_by_match_show == 1 then --需要过滤，根据march_show判断是否显示该项目
		local tmpStatusIdItems={}
		for i,v in ipairs(self.m_statusIdItems) do
			local march_show = CCCommonUtilsForLua:getPropById(v, "march_show")
			if march_show == "1" then
				tmpStatusIdItems[#tmpStatusIdItems + 1]=v
			end
		end
		self.m_statusIdItems=tmpStatusIdItems
	end
end

function ItemStatusView:updateExtra(param)
	if param:objectForKey("extraStatus") then
		self.extraStatus = {}

		local extraStatus = arrayToLuaTable(param:objectForKey("extraStatus"))
		for _, status in ipairs(extraStatus) do
			self.extraStatus[status.id] = atoi(status.effect)
		end
	end
end

function ItemStatusView:updateInfo(dict)
	self:updateExtra(dict)
	self:updateLocalInfo()
	local miny = self.m_tableView:minContainerOffset().y
	local pos = self.m_tableView:getContentOffset()
	self.m_tableView:reloadData()

	local mincurry = self.m_tableView:minContainerOffset().y
	pos.y = pos.y - miny + mincurry
	self.m_tableView:setContentOffset(pos)
end

function ItemStatusView:cellSizeForTable(tab, idx)
	if (CCCommonUtilsForLua:isIosAndroidPad()) then
		return 1496, 300
	else
		return 610, 145
	end
end

function ItemStatusView:tableCellAtIndex(tab, idx)
	if (idx >= #self.m_statusIdItems) then return end

	local cell = tab:dequeueCell()
	if (cell) then
		local node = cell:getChildByTag(666)
		node:setData(self.m_statusIdItems[idx + 1], self.extraStatus)
	else
		local node = ItemStatusTypeCell:create(self.m_statusIdItems[idx + 1], self.extraStatus)
		node:setTag(666)
		cell = cc.TableViewCell:create()
		cell:addChild(node)
	end

	return cell
end

function ItemStatusView:numberOfCellsInTableView(tab)
	return #self.m_statusIdItems
end

function ItemStatusView:tableCellTouched(tab, cell)
	if (cell) then
		local node = cell:getChildByTag(666)
		if (node and node.touchEnable) then
			if (node.m_type == 0 or node.m_type == ArtilleryBuffType or node.m_showIndepend == 1) then 
				return 
			end

			local typeNameS = getLang(CCCommonUtilsForLua:call("getPropById", node.m_statusId, "name"))
			local description = getLang(CCCommonUtilsForLua:call("getPropById", node.m_statusId, "tips"))

			local flag = (node.m_timeType == 0) and true or false
			local _type = flag and node.m_type or node.m_timeType
			local view = Drequire("game.CommonPopup.UseItemStatusView"):create(_type, typeNameS, description, flag)
			--83  typeNameS is 最强王国获取活动积分增加  description is 提示：大幅提高您在最强王国活动中获取积分的效率 flag is tru
			PopupViewController:addPopupInView(view)
		end
	end
end

function ItemStatusView:onEnter()
	local cmd = require("game.command.ShowStatusItemCmd").create(nil)
	cmd:send()

	self:setTitleName(getLang("102282"))
	registerScriptObserver(self, self.updateInfo, "status.item.refresh")
end

function ItemStatusView:onExit()
	unregisterScriptObserver(self, "status.item.refresh")
end

function ItemStatusView:onCleanup()
	self = nil
end


---------------------------ItemStatusTypeCell-----------------------------

function ItemStatusTypeCell:create(statusId, extraStatus)
	local node = ItemStatusTypeCell.new()
	if (node:initNode(statusId, extraStatus)) then
		return node
	end
end

function ItemStatusTypeCell:initNode(statusId, extraStatus)
	CCLoadSprite:call("doResourceByCommonIndex", 504, true)

	self.m_statusId = statusId
	self.extraStatus = extraStatus

	local ccbUri = "ItemStatusTypeCell02_lua.ccbi"
	local proxy = cc.CCBProxy:create()
	local node = CCBReaderLoad(ccbUri, proxy, self)

	local function onNodeEvent(event)
		if event == "enter" then
			self:onEnter()
		elseif event == "exit" then
			self:onExit()
		elseif event == "cleanup" then
			self:onCleanup()
		end
	end
	node:registerScriptHandler(onNodeEvent)
	self:addChild(node)

	if (CCCommonUtilsForLua:isIosAndroidPad()) then
		self:setContentSize(cc.size(1496, 300))
	else
		self:setContentSize(cc.size(605, 145))
	end

	self.animationManager = ccb["ItemStatusTypeCellOwner"]["mAnimationManager"]
	self:setData(self.m_statusId, extraStatus)
	self:ignoreAnchorPointForPosition(true)
	self.touchEnable = true
	--self.m_timeType = 0
    return true
end

function ItemStatusTypeCell:onEnter()
	-- body
	local function callback() self:resetTime() end
	local handler = self:registerHandler(callback)
	CCSafeNotificationCenter:registerScriptObserver(self, handler, MSG_ITME_STATUS_TIME_CHANGE)
	self:freshData()
	if self.entry then
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
		self.entry = nil
	end
	self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(function(dt) self:freshData(dt) end, 1, false)

	registerScriptObserver(self, self.refreshBroken, "msg_fortress_point_data_back") 
end

function ItemStatusTypeCell:onExit()
	CCSafeNotificationCenter:unregisterScriptObserver(self, MSG_ITME_STATUS_TIME_CHANGE)
	if self.entry then
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
		self.entry = nil
	end
	unregisterScriptObserver(self, "msg_fortress_point_data_back")
	if self.entry1 then
		self:getScheduler():unscheduleScriptEntry(self.entry1)
		self.entry1 = nil
	 end   
end

function ItemStatusTypeCell:refreshBroken()
	local ctl = require("game.fortress.FortressController"):getInstance()
    if  not ctl:isWarriorOpen() then
		-- 远征阶段 而且是周六 勇士奖励任务  破罩时间
		return
	end
	self.m_nodeBroken:setVisible(false)
	if self.entry1 then
		self:getScheduler():unscheduleScriptEntry(self.entry1)
		self.entry1 = nil
	 end 
	if self.m_statusId ~= "108800" then return end
	if not ctl.endTime  then
		if not self.isRequest then
		   self.isRequest = true
		   ctl:startGetPointData()
		end
		return 
	end
    local function updateBrokenTime(dt)
		-- body
		local leftTime = ctl.endTime - getTimeStamp()
		if leftTime > 0 then
			self.m_lbtask:setString(getLang("52022017",CC_SECTOA(leftTime)))
		else
			-- body
			self.m_nodeBroken:setVisible(false)
			if self.entry1 then
				self:getScheduler():unscheduleScriptEntry(self.entry1)
				self.entry1 = nil
			 end   
		end
	end
	self.m_nodeBroken:setVisible(ctl.endTime > getTimeStamp())
	self.m_lbtaskDesc:setString(getLang("52022018"))
	self.m_barNode:setVisible(self.m_time > 0 and ctl.endTime <= getTimeStamp())
	if ctl.endTime > getTimeStamp() then
	    self.entry1 = tonumber(self:getScheduler():scheduleScriptFunc(function (  )
			updateBrokenTime(dt)
		 end, 1.0, false))
		 updateBrokenTime(0)
	end
end

function ItemStatusTypeCell:onCleanup()
	-- body
	--self = nil
end

function ItemStatusTypeCell:resetTime(pObj)
	local integer = tolua.cast(pObj, "CCInteger")
	if integer == nil then
		return
	end
	if (integer:getValue() == self.m_type) then
		self:freshData()
		if self.entry then 
			cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry) 
			self.entry = nil
		end
		self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(function(dt) self:freshData(dt) end, 1, false)
	end
end

function ItemStatusTypeCell:setData(statusId, extraStatus)
	self.m_statusId = statusId
	self.extraStatus = extraStatus

	self.m_type = atoi(CCCommonUtilsForLua:call("getPropById", self.m_statusId, "type"))
	self.m_timeType = atoi(CCCommonUtilsForLua:call("getPropById", self.m_statusId, "itemtype"))
	self.m_showIndepend = atoi(CCCommonUtilsForLua:call("getPropById", self.m_statusId, "independent_display"))
	self.m_iconNode:removeAllChildren()
	self.m_sprArrow:setVisible(true)

	local typeNameS = getLang(CCCommonUtilsForLua:call("getPropById", self.m_statusId, "name"))
	self.m_nameTxt:setString(typeNameS)
	self:resetDescText()
	
	if (self.m_type == 0 or self.m_type == ArtilleryBuffType or self.m_showIndepend == 1) then 
		self.m_sprArrow:setVisible(false) 
	end

	local iconPath = CCCommonUtilsForLua:call("getPropById", self.m_statusId, "icon") .. ".png"
	local color = atoi(CCCommonUtilsForLua:call("getPropById", self.m_statusId, "color"))
	local colorBgPath = CCCommonUtilsForLua:call("getToolBgByColor", color)
	local iconBg = CCLoadSprite:call("createSprite", colorBgPath)
	local iconSpr = CCLoadSprite:call("createSprite", iconPath, CCLoadSpriteType_GOODS)

	if (CCCommonUtilsForLua:isIosAndroidPad()) then
		CCCommonUtilsForLua:setSpriteMaxSize(iconBg, 140, true)
		CCCommonUtilsForLua:setSpriteMaxSize(iconSpr, 140, true)
	else
		CCCommonUtilsForLua:setSpriteMaxSize(iconBg, 92, true)
		CCCommonUtilsForLua:setSpriteMaxSize(iconSpr, 92, true)
	end

	self.m_iconNode:addChild(iconBg)
	self.m_iconNode:addChild(iconSpr)

	if (self.m_barNode:getChildByTag(100)) then self.m_barNode:removeChildByTag(100) end

	self.animationManager:runAnimationsForSequenceNamed("loop")

	--加进度条头上的光效
	self.m_headParticleNode = cc.Node:create()
	for i = 1, 3 do
		local path = string.format("Loading_%d", i)
		local particle = ParticleController:call("createParticle", path)
		self.m_headParticleNode:addChild(particle)
	end

	self.m_barNode:addChild(self.m_headParticleNode)
	self.m_headParticleNode:setTag(100)

	self:freshData()

	if self.entry then
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
		self.entry = nil
	end

	self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(function(dt) self:freshData(dt) end, 1, false)

	if (self.m_type == 16) then
		if (not CCCommonUtilsForLua:isIosAndroidPad()) then
			self.m_barNode:setPositionY(30)
		end
	else
		if (CCCommonUtilsForLua:isIosAndroidPad()) then
			self.m_cellBG:setPreferredSize(cc.size(1496, 300))
		else
			self.m_cellBG:setPreferredSize(cc.size(604, 145))
		end

		if (not CCCommonUtilsForLua:isIosAndroidPad()) then
			self.m_mainNode:setPositionY(0)
			self.m_barNode:setPositionY(40.2)
		end
	end
	self:refreshBroken()
end

function ItemStatusTypeCell:resetDescText()
	local descS = getLang(CCCommonUtilsForLua:call("getPropById", self.m_statusId, "description"))
	self.m_descTxt:setString(descS)
	self.m_descTxt:setVisible(true)

	--清除富文本
	local parent = self.m_descTxt:getParent()
	parent:removeChildByTag(666)
end

function ItemStatusTypeCell:updateExtra()
	local statusId = CCCommonUtilsForLua:call("getPropById", self.m_statusId, "status")
	local slots = splitString(statusId, "|")
	local statusId
	local effect = 0
	for _, sid in ipairs(slots) do
		if self.extraStatus[sid] then
			statusId = sid
			effect = atoi(self.extraStatus[sid])
			break
		end
	end

	if statusId then
		local dialog = require("game.controller.StatusController").getInstance():getExtraDialog(statusId)
		local numStr = string.format("%.1f", effect)
		-- self.m_descTxt:setString(getLang(dialog, numStr))

		local rich = utils.getLinkTextStr(getLang(dialog), numStr, 18, "C1A77CFF", "3DA4C6FF")
		replaceRichText(self.m_descTxt, rich, 666)
	else
		self:resetDescText()
	end
end

function ItemStatusTypeCell:freshData()
	self.m_time = 0
	self.m_timeCDTxt:setVisible(false)
	self.m_CDBackLayer:setVisible(false)

	local max = 0

	if (self.m_timeType == ArtilleryBuffTimeType) or self.m_showIndepend == 1 then
		local statusMap = GlobalData:call("shared"):getProperty("statusMap")
		local statusId = CCCommonUtilsForLua:call("getPropById", self.m_statusId, "status")
		local slots = splitString(statusId, "|")
		local nowTime = GlobalData:call("getWorldTime")
		for _, sid in ipairs(slots) do
			local endTime = atoi(statusMap[atoi(sid)])
			self.m_time = endTime - nowTime
			if self.m_time > 0 then break end
		end
	elseif (self.m_timeType == 0) then
		local items = ToolController:call("getInstance"):getProperty("m_statusItems")
		if (items[self.m_type]) then
			local item = items[self.m_type]
			local startTime = item:valueForKey("startTime"):doubleValue()
			local endTime = item:valueForKey("endTime"):doubleValue()
			local time = WorldController:call("getTime")
			self.m_time = (endTime - time) / 1000
			max = (endTime - startTime) / 1000
		end
	else
		local durationItems = ToolController:call("getInstance"):getProperty("m_durationItems")
		if (durationItems[self.m_timeType]) then
			local time = durationItems[self.m_timeType]
			if (#time == 2) then
				self.m_time = time[2] - GlobalData:call("getTimeStamp")
				max = time[2] - time[1]
			end
		end
	end

	if (self.m_time > 0) then
		self.m_barNode:setVisible(true)
		max = math.max(max, 1)
		local len = self.m_time / max
		if (len > 1) then len = 1 end
		self.m_progress:setScaleX(len)
		self.m_barRight:setVisible(len > 0.99) --右箭头
		self.m_timeTxt:setString(getLang("105805", format_time(self.m_time)))
		self.m_receiveGlow:setVisible(true)

		local px = 0 --进度条头上的光效位置
		px = self.m_progress:getPositionX() + (self.m_progress:getContentSize().width * len)
		self.m_headParticleNode:setPositionX(px)
		self:updateExtra()
	else
		self:resetDescText()
		self.m_progress:setScaleX(0)
		self.m_timeTxt:setString(getLang("105805", format_time(0)))
		self.m_barNode:setVisible(false)
		self.m_receiveGlow:setVisible(false)
		self.touchEnable = true

		if (self.m_type == 1) then
			local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
			local protectCDTime = playerInfo:getProperty("protectCDTime")
			local worldTime = GlobalData:call("getWorldTime")
			local newTime = GlobalData:call("renewTime", worldTime * 1000) / 1000
			local cdTime = protectCDTime - newTime
			if (cdTime > 0) then
				self.m_timeCDTxt:setVisible(true)
				self.m_timeCDTxt:setString(getLang("105164", CCCommonUtilsForLua:call("timeLeftToCountDown", cdTime)))
				self.touchEnable = false
				self.m_CDBackLayer:setVisible(true)

				local txtSize = self.m_timeCDTxt:getContentSize()
				self.m_CDBackLayer:setContentSize(cc.size(txtSize.width + 10, txtSize.height))
			else
				self.m_timeCDTxt:setVisible(false)
				self.m_CDBackLayer:setVisible(false)
				if self.entry then 
					cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry) 
					self.entry = nil
				end
			end
		else
			if self.entry then 
				cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry) 
				self.entry = nil
			end
		end
	end
end

return ItemStatusView