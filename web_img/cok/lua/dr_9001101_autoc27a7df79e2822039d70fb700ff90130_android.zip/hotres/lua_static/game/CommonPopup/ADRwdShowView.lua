--[[ 
    观看广告奖励道具,该界面设计只能显示一条奖励信息
 ]]
local ADRwdShowView = class("ADRwdShowView",PopupBaseView)
local LuaAdController = require("game.controller.LuaAdController").getInstance()

function ADRwdShowView:create(params)
    local view = ADRwdShowView.new()
    Drequire("game.CommonPopup.ADRwdShowView_ui"):create(view)
    if view:initView(params) then
        return view
    end
end

function ADRwdShowView:initView(params)
    dump(params, 'ADRwdShowView:initView')
    self.rewardId = params.rewardId
    self:setRewardItems()
    self.curTime = params.curTime
    self.maxTime = params.maxTime
    self.nextAdStamp = params.nextAdStamp
    self.type = params.type

    -- 获取倍率
    local _curMulti, _nextTime, _nextNum = LuaAdController:getMultiData(self.curTime, params.multiTimesAndNums)
    Dprint('ADRwdShowView:initView', _curMulti, _nextTime, _nextNum)
    self.v_curMulti = _curMulti
    if self.v_curMulti then
        CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnReward, getLang("152562")..' x'..self.v_curMulti)  --152562=立即领取
        CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnAd, getLang("137702")..' x'..self.v_curMulti)      --137702=免费领取
    elseif _nextTime and _nextNum then
        self.ui.m_labelDes:setString(getLang("660600", _nextTime, _nextNum))   --660600=再开启{0}次，可获得{1}倍奖励。
    end

    self.ui.m_btnReward:setVisible(false)
    self.ui.m_btnAd:setVisible(true) 
    self.ui.m_btnAd:setEnabled(self.curTime<self.maxTime and getTimeStamp() >= self.nextAdStamp)

    return true
end

function ADRwdShowView:setRewardItems()
    local rwd = GlobalData:call("getCachedRewardData", self.rewardId)
    local _rewardList = arrayToLuaTable(rwd)
    if #_rewardList == 0 then
        GlobalData:call("requestRewardData", self.rewardId)
    else
        local _scrollSize = self.ui.m_nodeRewards:getContentSize()
        local _scrollView = cc.ScrollView:create()
        _scrollView:setViewSize(_scrollSize)
        _scrollView:setDirection(kCCScrollViewDirectionHorizontal)
        self.ui.m_nodeRewards:addChild(_scrollView)
        
        for i,v in ipairs(_rewardList) do
            local _cell = Drequire("game.chapter.ChapterRewardIconCell"):create()
            local _cellSize = _cell:getContentSize()
            _cell:setPosition((i - 1) * (_cellSize.width + 20), 0)
            _cell:refreshCell(v, i)
            _scrollView:addChild(_cell)
        end
        local _contentWidth = (#_rewardList) * 120
        _scrollView:setContentSize(cc.size(_contentWidth, _scrollSize.height))
        if _contentWidth < _scrollSize.width then
            _scrollView:setContentOffset(cc.p((_scrollSize.width - _contentWidth) / 2, 0))
            _scrollView:setTouchEnabled(false)
        end
    end
end

function ADRwdShowView:onEnter()
    if self.entry then
		self:getScheduler():unscheduleScriptEntry(self.entry)
    end
    if self.nextAdStamp > getTimeStamp() then
        self.ui.m_btnReward:setVisible(false)
        self.ui.m_btnAd:setEnabled(false)       
        self:onEnterFrame()
        self.entry = tonumber(self:getScheduler():scheduleScriptFunc(function(dt) self:onEnterFrame() end, 1, false)) 
    end   

    local function onGetRewardDetailBack(ref)
		local rewardId = ""
		if ref then rewardId = ref:getCString() end
        if rewardId == self.rewardId then
            self:setRewardItems()
        end
	end
	local handler = self:registerHandler(onGetRewardDetailBack)
    CCSafeNotificationCenter:registerScriptObserver(self, handler, "MSG_GET_REWARD_DETAIL_BACK")    
    registerScriptObserver(self,self.onClickBtnClose,"msg.getAdReward.refresh")
    registerScriptObserver(self,self.refreshButton,"msg.adClose.refresh")
end

function ADRwdShowView:onExit()
    CCSafeNotificationCenter:unregisterScriptObserver(self, "MSG_GET_REWARD_DETAIL_BACK")
    if self.entry then
        self:getScheduler():unscheduleScriptEntry(self.entry)
    end
    unregisterScriptObserver(self,"msg.adClose.refresh")
    unregisterScriptObserver(self,"msg.getAdReward.refresh")
end

function ADRwdShowView:refreshButton()
    self.ui.m_btnReward:setVisible(true)
    self.ui.m_btnReward:setEnabled(true)
    self.ui.m_btnAd:setVisible(false) 
end

function ADRwdShowView:onEnterFrame( )
    local lessTime = self.nextAdStamp - getTimeStamp()
    if lessTime > 0 then
        CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnAd, format_time(lessTime)) -- 140473=领主ID已隐藏
    else       
        self.ui.m_btnAd:setEnabled(self.curTime < self.maxTime) 
        self:getScheduler():unscheduleScriptEntry(self.entry)
        if self.v_curMulti then
            CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnAd, getLang("137702")..' x'..self.v_curMulti)      --137702=免费领取
        else
            CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnAd, getLang("137702"))      --137702=免费领取
        end
    end
end

-- 点击关闭
function ADRwdShowView:onClickBtnClose()
    self:call("closeSelf")
end

-- 点击播放广告
function ADRwdShowView:onClickBtnAd()
	LuaAdController:playVideo(self.type)
    self:call("closeSelf")
end

-- 点击获取奖励
function ADRwdShowView:onClickBtnReward()
    Dprint('ADRwdShowView:onClickBtnReward', self.type)
    Drequire("game.command.LuaAdCommand"):reqADGoods(self.type)
    self.ui.m_btnReward:setEnabled(false)
end

return ADRwdShowView