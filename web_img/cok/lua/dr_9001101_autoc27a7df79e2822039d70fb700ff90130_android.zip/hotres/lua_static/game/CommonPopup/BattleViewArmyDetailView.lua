--[[
    2019-11-13
    出征军队详情界面
    BattleViewArmyDetailView 
]]

local BattleViewArmyDetailView = class("BattleViewArmyDetailView", PopupBaseView)

BattleViewArmyDetailView.__index = BattleViewArmyDetailView

function BattleViewArmyDetailView:ctor()
end
   
function BattleViewArmyDetailView:create(params)
    local view = BattleViewArmyDetailView.new()
    Drequire("game.CommonPopup.BattleViewArmyDetailView_ui"):create(view, 0)
    if view:initView(params) then
        return view 
    end
end

function BattleViewArmyDetailView:onEnter()
    UIComponent:call("showPopupView", 0)
	registerScriptObserver(self, self.updateTableView, MessageType.MSG_BATTLE_VIEW_BUFF)
end

function BattleViewArmyDetailView:initView()
    if CCCommonUtilsForLua:isIosAndroidPad() then
        self:setScale(2)
    end
    self.ui.m_titleLabel:setString(getLang("10200034")) -- 10200034=部队属性详情
    -- self:updateTableView()
    CCSafeNotificationCenter:postNotification(MessageType.MSG_SEND_BATTLE_VIEW_BUFF_CMD)
    return true
end

function BattleViewArmyDetailView:updateTableView()
    local params = require("game.controller.BattleViewActiveBuffController").getInstance():getBuffInfo()
    --[[
        "effectArray" = {
            1 = {
                "effectId" = "2906"
                "value"    = "1000000"
            }
        }
    ]]
    
    local effectArray = params["effectArray"] or {}
    local effectMap = {}
    for index, value in ipairs(effectArray) do
        if value ~= nil then
            for key, item_value in  pairs(value) do
                effectMap[key] = item_value
            end
        end
    end

    local dataTable = self:calculateEffectValue(effectMap)
    self.ui:setTableViewDataSource("m_tableView", dataTable)
end

function BattleViewArmyDetailView:calculateEffectValue(effectMap)
    local dataTable = {}
    local generalAttMap = GeneralManager:call("getInstance"):getProperty("GeneralAttMap")
    for key, effectCfg in pairs(generalAttMap or {}) do
        local effect_value = 0
        local effectStr = effectCfg:getProperty("effect")
        for index, str in ipairs(string.split(effectStr, "|") or {}) do
            local list = string.split(str, ";")
            if #list > 0 then
                local effIDStr = list[1]
                effect_value = effect_value + atoi(effectMap[effIDStr])
            end
        end

        if effect_value > 0 then
            local name = effectCfg:getProperty("name")
            if name ~= "" then
                table.insert(dataTable, {
                    name = name, 
                    value = effect_value,
                    order = effectCfg:getProperty("mail_order"),
                    type = effectCfg:getProperty("show"),  -- 0:百分比数值；其他:常规数值
                    mark = effectCfg:getProperty("buff"),  -- 1:”-“前缀；2:"+"前缀
                })
            end
        end
    end

    table.sort(dataTable, function (item1, item2) return item1.order < item2.order end)

    return dataTable
end

--tableview
function BattleViewArmyDetailView:cellSizeForTable(tab, idx)
    return 540, 40
end

function BattleViewArmyDetailView:tableCellTouched(tab, cell)
    -- 触摸

end


function BattleViewArmyDetailView:onExit()
    unregisterScriptObserver(self, MessageType.MSG_BATTLE_VIEW_BUFF)
end

function BattleViewArmyDetailView:onCleanup()

end


function BattleViewArmyDetailView:closeSelf()
	PopupViewController:call("removePopupView", self)
end

function BattleViewArmyDetailView:onCloseButtonClick()
    self:closeSelf()
end

return BattleViewArmyDetailView