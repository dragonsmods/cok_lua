----------------------------
-- Author: Elex
-- Date: 2021-05-21 Friday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local GoodsExchangeView_ui = class("GoodsExchangeView_ui")

--#ui propertys


--#function
function GoodsExchangeView_ui:create(owner, viewType, paramTable)
	local ret = GoodsExchangeView_ui.new()
	CustomUtility:LoadUi("GoodsExchangeView.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function GoodsExchangeView_ui:initLang()
	LabelSmoker:setText(self.m_titleLabel, "671810")
	LabelSmoker:setText(self.m_subTitle, "119026")
	ButtonSmoker:setText(self.m_okButton, "671811")
end

function GoodsExchangeView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function GoodsExchangeView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function GoodsExchangeView_ui:onCloseButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onCloseButtonClick", pSender, event)
end

function GoodsExchangeView_ui:onOKButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onOKButtonClick", pSender, event)
end

return GoodsExchangeView_ui

