----------------------------
-- Author: Elex
-- Date: 2017-12-20 Wednesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local SelectingCell_ui = class("SelectingCell_ui")

--#ui propertys


--#function
function SelectingCell_ui:create(owner, viewType)
	local ret = SelectingCell_ui.new()
	CustomUtility:LoadUi("SelectingCell.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function SelectingCell_ui:initLang()
end

function SelectingCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function SelectingCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function SelectingCell_ui:onBtnClicked(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBtnClicked", pSender, event)
end

return SelectingCell_ui

