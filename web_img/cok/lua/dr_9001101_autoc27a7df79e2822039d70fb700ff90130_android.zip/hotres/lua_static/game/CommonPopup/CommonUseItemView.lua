local CommonUseItemView = class("CommonUseItemView", PopupBaseView)

function CommonUseItemView:create(items)
    local view = CommonUseItemView.new(items)
    Drequire("game.CommonPopup.CommonUseItemView_ui"):create(view, 0)
    view:initView()
    return view
end

function CommonUseItemView:ctor(items)
    self.items = items
end

function CommonUseItemView:initView()
    self:setHDPanelFlag(true)
    if CCCommonUtilsForLua:call("isIosAndroidPad") then
        self.ui.nodeccb:setScale(2.0)
    end
    self.ui:setTableViewDataSource("m_listView", self.items)
    self.ui.m_titleTxt:setString(getLang("175776"))
    registerTouchHandler(self)
end

function CommonUseItemView:refreshView()
    local sourceData = {}
    for k, v in ipairs(self.items) do
        local tinfo = ToolController:call("getToolInfoForLua", atoi(v))
        if tinfo and tinfo:call("getCNT") > 0 then
            table.insert(sourceData, v)
        end
    end

    if #sourceData == 0 then
        self:call("closeSelf")
    else
        self.ui:setTableViewDataSource("m_listView", sourceData)
    end
end

function CommonUseItemView:onEnter()
    local function callback1() self:refreshView() end
    local handler1 = self:registerHandler(callback1)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "CommonUseItemView:refreshView")
end

function CommonUseItemView:onExit()
    CCSafeNotificationCenter:unregisterScriptObserver(self, "CommonUseItemView:refreshView")
end

function CommonUseItemView:onTouchBegan(x, y)
    if not isTouchInside(self.ui.m_bg, x, y) then
        self.touchPoint = ccp(x, y)
        return true
    end
end

function CommonUseItemView:onTouchEnded(x, y)
    if ccpDistance(self.touchPoint, ccp(x, y)) > 10 then return end
    self:call("closeSelf")
end

function CommonUseItemView:onCloseBtnClick()
    self:call("closeSelf")
end

return CommonUseItemView