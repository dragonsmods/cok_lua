--魔法屋 1:普通研习 2:高级研习
local Cell_Magic = class("Cell_Magic",Drequire("game.CommonPopup.OverView.Cell_Info.Cell_MainFile"))
local FUN_BUILD_SCIENE = 403000
function Cell_Magic:create(Id)
    local ret = Cell_Magic.new(Id)
    if ret:initBaseById(Id) then
        return ret
    end
end
function Cell_Magic:getCellDataTbl()
	if not self:checkIsVisible() then
        return
    end
    local _id = ""
	local _finishTime = -1
	local _targetTime = -1
    local _state = -1
    local _label = ""
    local _name = ""
    local _icon = ""
	local _visible = ""
	local _cancelJump = false
    local isOpen = CCCommonUtilsForLua:isFunOpenByKey("magic_skill") and MagicManager.m_magic_skill and (tonumber(MagicManager.m_magic_skill.k12) <= self.mainCityLv)
	local v_normalFreeTotalCount = MagicLuckDrawController.v_normalFreeTotalCount--普通免费研习总次数
	local v_normalFreeCurCount = MagicLuckDrawController.v_normalFreeCurCount --今日当前免费普通研习次数
	local v_normalFreeTotalTime = MagicLuckDrawController.v_normalFreeTotalTime --【普通】招募倒计时总时间
	local v_normalFreeTime = MagicLuckDrawController.v_normalFreeTime --【普通】招募免费倒计时
	
	local v_seniorFreeTotalCount = MagicLuckDrawController.v_seniorFreeTotalCount --高级免费研习总次数
	local v_seniorFreeCurCount = MagicLuckDrawController.v_seniorFreeCurCount --今日当前免费高级研习次数
	local v_seniorFreeTotalTime = MagicLuckDrawController.v_seniorFreeTotalTime -- 【高级】招募倒计时总时间
	local v_seniorFreeTime = MagicLuckDrawController.v_seniorFreeTime --【高级】招募免费倒计时

	local freeTotalCount = v_normalFreeTotalCount + v_seniorFreeTotalCount
	local freeCurCount = v_normalFreeCurCount + v_seniorFreeCurCount
	--有可普通免费研习
	_id = "30711030"
	local isLock = self:checkIsUnLock(FUN_BUILD_SCIENE)		
	if freeTotalCount > 0 and freeCurCount < freeTotalCount then
		local leftTimes = freeTotalCount - freeCurCount
		_state = self.Queue_ST_WORK
		_label = self:getDialogByIdIndex(_id,1)

		--如果有CD，则显示
		local now = getTimeStamp()
		local curWorldTime = getWorldTime()
		local disTime = curWorldTime - now
		if v_normalFreeTime > now then
			leftTimes = v_normalFreeTime + disTime
			_targetTime = v_normalFreeTotalTime
		end
		_finishTime = leftTimes

	else
		_cancelJump = true
		_state = self.Queue_ST_IDLE
		_finishTime = -1
		_label = self:getDialogByIdIndex(_id,3)
	end
	if not isLock then
		_state = self.Queue_ST_LOCK
		_finishTime = -1
		_label = "2000442"
	end
	
	_name,_icon,_visible = self:getNameIconVisibleBySubId(_id)
	local cellOne = { id = _id, name = _name,icon = _icon,state = _state,param1 = _finishTime, param2 = _targetTime, cancelJump = _cancelJump, label = _label,cell = self}
	if _visible == "1" and isOpen then
		self.CellTbl.cellMeta={cellOne}
	end
    return self.CellTbl  
end

function Cell_Magic:OnClickJump(_id,_state)
    if _id == "30711030" then
        if _state == self.Queue_ST_WORK or _state == self.Queue_ST_IDLE then            
            self:jumpByTypeAndTarget(1,FUN_BUILD_SCIENE)
        elseif _state == self.Queue_ST_LOCK then
            --未解锁,目前是跳过去,会提示建造该建筑
            self:jumpByTypeAndTarget(1,FUN_BUILD_SCIENE)
        end
    end
end

return Cell_Magic