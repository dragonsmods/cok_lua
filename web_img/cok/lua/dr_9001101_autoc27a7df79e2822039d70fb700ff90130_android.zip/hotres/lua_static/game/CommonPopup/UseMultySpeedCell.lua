local UseMultySpeedCell = class("UseMultySpeedCell", function()
    return cc.Layer:create()
end)

function UseMultySpeedCell:create(idx)
    local ret = UseMultySpeedCell.new()
    Drequire("game.CommonPopup.UseMultySpeedCell_ui"):create(ret, 0)
    return ret
end

function UseMultySpeedCell:refreshCell(info, idx)

   
    local icon = CCCommonUtilsForLua:call("getIcon", info.itemId)
    self.ui.img_spr:setSpriteFrame(CCLoadSprite:call("loadResource", icon))
    
    local color = math.tonumber(CCCommonUtilsForLua:call("getPropById", info.itemId, "color"))
    local bgPicName = CCCommonUtilsForLua:call("getToolBgByColor", color)
    self.ui.bgIcon:setSpriteFrame(CCLoadSprite:call("loadResource", bgPicName))

    local name = CCCommonUtilsForLua:call("getPropById", info.itemId, "name")-- para="1;1;28800"
    local name1 = string.split(name, "|")[1]
    local name2 = string.split(name, "|")[2]

    self.ui.m_iconLabel:setString(getLang(name1, getLang(name2)))

    local num = info.itemNum
    self.ui.m_numLabel:setString("x" .. num)

    --显示当前数量
    local tinfo = ToolController:call("getToolInfoByIdForLua", tonumber(info.itemId))
    if tinfo and tinfo:call("getCNT") > 0 then
        local cnt = tinfo:call("getCNT")
        self.ui.txt_goodsNum:setString(cnt)
    end


     if info.itemId == 0 or info.itemId == 6 then
        --免费加速
        local freeTime = info.timeCost/60
        self.ui.m_iconLabel:setString(freeTime..getLang("115133").." "..getLang("114207"))         
        self.ui.img_spr:setSpriteFrame(CCLoadSprite:call("loadResource", "free_icon.png"))
         self.ui.txt_goodsNum:setString(info.itemNum)
    end

end

function UseMultySpeedCell:onEnter(  )
    
end

function UseMultySpeedCell:onExit(  )
    
end

return UseMultySpeedCell
