----------------------------
-- Author: Elex
-- Date: 2017-11-21 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local AuctionHouseRecordView_ui = class("AuctionHouseRecordView_ui")

--#ui propertys


--#function
function AuctionHouseRecordView_ui:create(owner, viewType)
	local ret = AuctionHouseRecordView_ui.new()
	CustomUtility:LoadUi("AuctionHouseRecordView.ccbi", ret, owner, true, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then		owner:initTableViewByOwner()
	else		ret:initTableView()	end	return ret
end

function AuctionHouseRecordView_ui:initLang()
end

function AuctionHouseRecordView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function AuctionHouseRecordView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function AuctionHouseRecordView_ui:initTableView()
	TableViewSmoker:createView(self, "m_pTableView", "game.CommonPopup.AuctionHouse.AuctionHouseRecordCell", 1, 5, "AuctionHouseRecordCell")
end

function AuctionHouseRecordView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return AuctionHouseRecordView_ui

