----------------------------
-- Author: Elex
-- Date: 2019-04-11 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local RankActCountryRankTblCell_ui = class("RankActCountryRankTblCell_ui")

--#ui propertys


--#function
function RankActCountryRankTblCell_ui:create(owner, viewType, paramTable)
	local ret = RankActCountryRankTblCell_ui.new()
	CustomUtility:DoRes(10, true)
	CustomUtility:DoRes(11, true)
	CustomUtility:LoadUi("RankActCountryRankTblCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function RankActCountryRankTblCell_ui:initLang()
end

function RankActCountryRankTblCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function RankActCountryRankTblCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function RankActCountryRankTblCell_ui:onClickPicBtn(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickPicBtn", pSender, event)
end

function RankActCountryRankTblCell_ui:onClickSearchBtn(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickSearchBtn", pSender, event)
end

function RankActCountryRankTblCell_ui:onRewardButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onRewardButtonClick", pSender, event)
end

function RankActCountryRankTblCell_ui:onMoreButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onMoreButtonClick", pSender, event)
end

return RankActCountryRankTblCell_ui

