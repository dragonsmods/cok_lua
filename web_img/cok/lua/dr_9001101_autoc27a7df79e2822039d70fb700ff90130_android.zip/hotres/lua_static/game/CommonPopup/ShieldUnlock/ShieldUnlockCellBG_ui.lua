----------------------------
-- Author: Elex
-- Date: 2019-03-02 Saturday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local ShieldUnlockCellBG_ui = class("ShieldUnlockCellBG_ui")

--#ui propertys


--#function
function ShieldUnlockCellBG_ui:create(owner, viewType, paramTable)
	local ret = ShieldUnlockCellBG_ui.new()
	CustomUtility:LoadUi("ShieldUnlockCellBG.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function ShieldUnlockCellBG_ui:initLang()
end

function ShieldUnlockCellBG_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function ShieldUnlockCellBG_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function ShieldUnlockCellBG_ui:onUnBlockClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onUnBlockClick", pSender, event)
end

return ShieldUnlockCellBG_ui

