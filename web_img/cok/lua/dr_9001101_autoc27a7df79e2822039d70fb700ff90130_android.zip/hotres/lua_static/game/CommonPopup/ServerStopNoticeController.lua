--[[
    ServerStopNoticeController
    停服公告-Controller
]]

local _instance = nil
local ServerStopNoticeController = class("ServerStopNoticeController")

function ServerStopNoticeController.getInstance()
    if not _instance then
        _instance = ServerStopNoticeController.new()
    end

    return _instance
end

function ServerStopNoticeController:purge()
    _instance = nil
end

function ServerStopNoticeController:receiveNotice(params)
    --[[
        push.stop.server.notice
            noticeTitleDialog   string  公告题目Dialog
            noticeInfoDialog    string  公告内容
            noticeIconDialog    string  公告icon
            notice_data_dialog  array   公告填充，noticeInfoDialog中的替换内容
            endTime             string  结束时间  ms
    ]]
    self.m_notice = params
    if self.m_notice then
        self.m_notice.endTime = atoi(self.m_notice.endTime)/1000
    end
    CCSafeNotificationCenter:call("postNotification", "ServerStopNotice")
end

function ServerStopNoticeController:getValidNotice()
    if self.m_notice and self.m_notice.endTime and getTimeStamp() < self.m_notice.endTime then
        return self.m_notice
    end
end

return ServerStopNoticeController
