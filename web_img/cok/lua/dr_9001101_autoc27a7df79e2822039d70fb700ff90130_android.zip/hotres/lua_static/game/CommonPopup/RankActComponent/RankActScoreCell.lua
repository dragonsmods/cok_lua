--排行榜活动积分宝箱组件
local RankActScoreCell = class("RankActScoreCell",
function ()
    return cc.Layer:create()
end)

RankActScoreCell.__index = RankActScoreCell


function RankActScoreCell:create(viewSize, actInfo)
    local view = RankActScoreCell.new()
    Drequire("game.CommonPopup.RankActComponent.RankActScoreCell_ui"):create(view,0,viewSize)
    if view:initView(actInfo) then
        return view
    end
end

function RankActScoreCell:initView(actInfo)
    self.actInfo = actInfo
    self.ctl = require("game.CommonPopup.RankActComponent.RankActDataController").getInstance()
    CCLoadSprite:call("loadDynamicResourceByName", "TrainingTroop_face")
    -- dump(self.scoreData,"hxq self.scoreData is ")
    self.ui.m_labelCurOver:setVisible(false)
    self.ui.m_labelTotalOver:setVisible(false)  
    if self:getOpenState() == 1 then
        -- 当前奖励列表
        local str1, str2 = getLang("182119"), getLang("182120")
        self.scoreData = self:getActData() -- self.ctl:getDataBykey("totalScoreData")
        if self.scoreData.processTitle1 and self.scoreData.processTitle2 then
            str1, str2 = self.scoreData.processTitle1, self.scoreData.processTitle2
        end
        self.ui.m_scoreCur:setString(str1)
        self.ui.m_scoreTotal:setString(str2)

        self.ui.m_nodeRewardCur:removeAllChildren()    
        local _singleReward = self.scoreData.todayScoreData or {}
        if _singleReward and #_singleReward > 0 then
            local _view = Drequire("game.CommonPopup.CommonProgressView").create(_singleReward, 600)
            if _view then
                self.ui.m_nodeRewardCur:addChild(_view)
            end
        end

        local _allReward = self.scoreData.totalScoreData or {}
        self.ui.m_nodeRewardTotal:removeAllChildren()       
        if _allReward and #_allReward > 0 then
            local _view = Drequire("game.CommonPopup.CommonProgressView").create(_allReward, 600)
            if _view then
                self.ui.m_nodeRewardTotal:addChild(_view)
            end
        end
    else
        self.ui.m_labelCurOver:setVisible(true)
        self.ui.m_labelTotalOver:setVisible(true)
        if self:getOpenState() == 2 then
            self.ui.m_labelCurOver:setString(getLang("168108"))
            self.ui.m_labelTotalOver:setString(getLang("168108"))
        elseif self:getOpenState() == 3 then
            self.ui.m_labelCurOver:setString(getLang("176075"))
            self.ui.m_labelTotalOver:setString(getLang("176075"))
        end
    end

    return true
end

function RankActScoreCell:onEnter()
	self.v_scheduleId = nil
	self.v_scheduleId = self:getScheduler():scheduleScriptFunc(function(dt) self:updateTime() end, 1, false)
end

function RankActScoreCell:onExit()	
	if self.v_scheduleId then
		self:getScheduler():unscheduleScriptEntry(self.v_scheduleId)
	end
end

function RankActScoreCell:updateTime()    
    if tonumber(self:getOpenState()) ~= 1 then
        if self.v_scheduleId then
            self:getScheduler():unscheduleScriptEntry(self.v_scheduleId)
        end
        return
    end
    local _stamp = GlobalData:call("getTimeStamp")
    local _endTime1 = tonumber(self.scoreData.curEndTime) or 0
    local _time1 = _endTime1/1000 - _stamp
    if _time1 >= 0 then
        local _curTime = format_time(_time1)
        self.ui.m_remainTimeCur:setString(getLang("182084", _curTime))	--182084=剩余领奖时间：{0}
    end

    if self:hasAlliance() then
        local _endTime2 = tonumber(self.scoreData.totalEndTime) or 0
        local _time2 = _endTime2/1000 - _stamp
        if _time2 >= 0 then
            local _curTime = format_time(_time2)
            self.ui.m_remainTimeTotal:setString(getLang("182084", _curTime))	--182084=剩余领奖时间：{0}
        end
    else
        self.ui.m_remainTimeTotal:setString(getLang("137448"))
    end
end

function RankActScoreCell:onClickBtnCalendar( )
    local actId = self:getActId() -- self.ctl.actId
    local view = Drequire("game.CommonPopup.RankActComponent.RankActDesView").create(actId)
    PopupViewController:addPopupView(view)
end

function RankActScoreCell:getOpenState()
    if self.actInfo then
        return self.actInfo.openState or 1
    else
        return self.ctl.isOver
    end
end

function RankActScoreCell:getActId()

    if self.actInfo then
        return self.actInfo.actId
    else
        return self.ctl.actId
    end
end

function RankActScoreCell:getActData()
    if self.actInfo then
        return self.actInfo.data
    else
        return self.ctl:getDataBykey("totalScoreData")
    end
end

function RankActScoreCell:hasAlliance()
    if self.scoreData.totalScoreData and #self.scoreData.totalScoreData > 0 then
        return true
    else
        return false
    end
end

return RankActScoreCell