local MonthFundCell = class("MonthFundCell",
    function()
        return cc.Layer:create()
    end
)
MonthFundCell.__index = MonthFundCell

function MonthFundCell:create(idx)
    local ret = MonthFundCell.new()
    Drequire("game.CommonPopup.MonthFundView.MonthFundCell_ui"):create(ret)
    return ret
end

-- "MonthFundCell:refreshCell+++"
--     1 = {
--         "hot"   = "0"
--         "id"    = "212069"
--         "num"   = "16"
--         "order" = "16"
--     }
--     2 = {
--         "hot"   = "0"
--         "id"    = "212069"
--         "num"   = "17"
--         "order" = "17"
--     }
local cell_type_month_fund_show_reward = 1
local cell_type_integrate_show_reward = 2

function MonthFundCell:refreshCell(info , idx)
	-- dump(info,"MonthFundCell:refreshCell+++")
	if not info then 
		return
	end
	for k=1,5 do 
		local picNode = self.ui["m_pic"..k]
		local numLabel = self.ui["m_labelPoint"..k]
		local dayLable = self.ui["m_dayLabel"..k]
		local checkSpr = self.ui["m_spCheck"..k]
		local checkSprx = self.ui["m_spCheckx"..k]
		local spBg = self.ui["m_spBg"..k]
		local particalToday = self.ui["m_particleNode"..k]
        local hotParticle = self.ui["m_hotParticle"..k]
		if info[k] and picNode and numLabel and dayLable and checkSpr and checkSprx and spBg and particalToday and hotParticle then
			picNode:removeAllChildren() 
    		picNode:setVisible(true) 
			local itemData = { type = 0, itemId = info[k].id, num=info[k].num }
    		-- itemData, iconNode, iconSize, nameLabel, numLabel, nameWithNum, beTouch, touchParentNode
    		LibaoCommonFunc.createItemInfoShow(itemData, picNode, 75, nil, numLabel, nil, true)
    		dayLable:setString(_lang_1("9441872", info[k].order))	--9441872=第{0}天
    		if info[k].cellType == cell_type_month_fund_show_reward then 
    			checkSpr:setVisible(false)
    			checkSprx:setVisible(false)
    			particalToday:setVisible(false)

                hotParticle:removeAllChildren()
                if info[k].hot ~= "0" then 
                    for j=0,2 do
                        local particle = ParticleController:call("createParticle", "LordSuitY_"..tostring(j))
                        particle:setScale(1.05)
                        hotParticle:addChild(particle, -1)
                    end
                end
    		else 
    			--基金领奖
    			local function setSprGray(node, bGray)
    				local childTable = node:getChildren()
	    			if childTable and #childTable > 0 then 
		    			for i = 1,#childTable do
		    				if tolua.type(childTable[i]) == "cc.Sprite" then
		                		CCCommonUtilsForLua:call("setSpriteGray", childTable[i], bGray)
		    				end
		    			end
	    			end
    			end
    			setSprGray(picNode,info[k].passed)
    			local isToday = (info[k].father and info[k].father.nowDay == tonumber(info[k].order) )
    			if isToday and info[k].receive ~= "0" then
    				setSprGray(picNode, true)
    			end
    			particalToday:setVisible(isToday)
    			
    			if info[k].receive == "0" then 
    				checkSpr:setVisible(false)
    				checkSprx:setVisible(info[k].passed)
    			else
    				checkSpr:setVisible(true)
    				checkSprx:setVisible(false)
    			end

                hotParticle:removeAllChildren()
                if not info[k].passed and info[k].hot ~= "0" then 
                    for j=0,2 do
                        local particle = ParticleController:call("createParticle", "LordSuitY_"..tostring(j))
                        particle:setScale(1.05)
                        hotParticle:addChild(particle, -1)
                    end
                end
    			CCCommonUtilsForLua:call("setSpriteGray", self.ui.m_spBg, true)
    		end
    	else
    		if picNode then 
    			picNode:setVisible(false)
    		end
    	end
    end
end

function MonthFundCell:onEnter()

end

function MonthFundCell:onExit()

end


return MonthFundCell