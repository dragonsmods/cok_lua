----------------------------
-- Author: Elex
-- Date: 2019-09-11 Wednesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local ADRwdShowView_ui = class("ADRwdShowView_ui")

--#ui propertys


--#function
function ADRwdShowView_ui:create(owner, viewType, paramTable)
	local ret = ADRwdShowView_ui.new()
	CustomUtility:DoRes(502, true)
	CustomUtility:LoadUi("ADRwdShowView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function ADRwdShowView_ui:initLang()
	LabelSmoker:setText(self.m_labelDes2, "663556")
	LabelSmoker:setText(self.m_labelTitle, "660601")
	ButtonSmoker:setText(self.m_btnReward, "152562")
	ButtonSmoker:setText(self.m_btnAd, "137702")
end

function ADRwdShowView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function ADRwdShowView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function ADRwdShowView_ui:onClickBtnReward(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnReward", pSender, event)
end

function ADRwdShowView_ui:onClickBtnAd(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnAd", pSender, event)
end

function ADRwdShowView_ui:onClickBtnClose(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnClose", pSender, event)
end

return ADRwdShowView_ui

