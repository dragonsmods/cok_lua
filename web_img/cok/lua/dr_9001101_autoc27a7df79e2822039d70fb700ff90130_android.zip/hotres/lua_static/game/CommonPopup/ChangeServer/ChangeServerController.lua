local ChangeServerController = class("ChangeServerController")

--------------------------- 拉取初始信息 Start ---------------------------
local TransferInfoCmd = class("TransferInfoCmd", LuaCommandBase)
function TransferInfoCmd.create(callBack)
	local ret = TransferInfoCmd.new()
	ret:initWithName("transfer.info")
	ret._callBack = callBack
	return ret
end

function TransferInfoCmd:handleReceive(dict)
	local tbl, params = self:parseMsg(dict)
	if type(tbl) == "boolean" then
		return tbl
	end
	-- cd: int，转服cd时间戳（秒）
 --  limit：int，是否限制转服 0：不限制，1：限制
 --  times：int，已经转服的次数
 --  servers：[],目标服务器ID，数组类型
 	require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance():parseApplyData(tbl)
	-- if self._callBack then
	-- 	self._callBack(tbl)
	-- end
	CCSafeNotificationCenter:postNotification("ChangeServerView:getTransferData", params)
	return true
end
--------------------------- 拉取初始信息 End ---------------------------


--------------------------后台获取部分转服条件数据 Start-------------------
local TransferConditionCmd = class("TransferConditionCmd",LuaCommandBase)
function TransferConditionCmd.create(serverId, callBack)
	local ret = TransferConditionCmd.new()
	ret:initWithName("transfer.conditions")
	ret:putParam("serverId", CCInteger:create(serverId))
	ret._callBack = callBack
	return ret
end

function TransferConditionCmd:handleReceive( dict )
	local tbl = self:parseMsg(dict)
	-- dump(tbl,"hxq tbl is")
	if type(tbl) == "boolean" then
		Dprint("TransferConditionCmd:handleReceive tbl boolean")
		return
	end

	if self._callBack then
		self._callBack(tbl)
	end
	return
end

--------------------------后台获取部分转服条件数据 End-------------------


--------------------------- 拉取初始信息 Start ---------------------------
local TransferGoCmd = class("TransferGoCmd", LuaCommandBase)

function TransferGoCmd.create(serverId, itemId, callBack)
	local ret = TransferGoCmd.new()
	ret:initWithName("transfer.go")
	ret:putParam("serverId", CCInteger:create(serverId))
	ret:putParam("itemUUid", CCString:create(tostring(itemId)))
	ret._callBack = callBack
	return ret
end

function TransferGoCmd:handleReceive(dict)
	local tbl = self:parseMsg(dict)
	if type(tbl) == "boolean" then
		return tbl
	end
	-- cd: int，转服cd时间戳（秒）
 --  limit：int，是否限制转服 0：不限制，1：限制
 --  times：int，已经转服的次数
 --  servers:[],目标服务器ID，数组类型
	if self._callBack then
		self._callBack(tbl)
	end
	return true
end
-- 这个逻辑处理不太好~需要调整
function TransferGoCmd:errorCallBack(data)
	if self._callBack then
		self._callBack(data)
	end
end
--------------------------- 拉取初始信息 End ---------------------------

--------------------------- 请求清理邮件 Start ---------------------------
local TransferClearMailCmd = class("TransferClearMailCmd", LuaCommandBase)
function TransferClearMailCmd.create(callBack)
	local ret = TransferClearMailCmd.new()
	ret:initWithName("transfer.cleanmail")
	ret._callBack = callBack
	return ret
end

function TransferClearMailCmd:handleReceive(dict)
	local tbl = self:parseMsg(dict)
	if type(tbl) == "boolean" then
		return tbl
	end
	if self._callBack then
		self._callBack(tbl)
	end
	return true
end
--------------------------- 请求清理邮件 End ---------------------------

-------------------- 服务器所需转服道具数量 Start ------------------------
local TransferServerItemCmd = class("TransferServerItemCmd", LuaCommandBase)
function TransferServerItemCmd.create(serverId)
	local ret = TransferServerItemCmd.new()
	ret:initWithName("transfer.cost")
	ret:putParam("serverId", CCInteger:create(atoi(serverId)))
	return ret
end

function TransferServerItemCmd:handleReceive(dict)
	local tbl, params = self:parseMsg(dict)
	if type(tbl) == "boolean" then return tbl end
	CCSafeNotificationCenter:postNotification("ChangeServerView:getServerItem", params)
	return true
end
-------------------- 服务器所需转服道具数量 End ------------------------

--------------------------- 转服状态 S---------------------------
local TransferStateCmd = class("TransferStateCmd", LuaCommandBase)

function TransferStateCmd:create()
	local ret = TransferStateCmd.new()
	ret:initWithName("transfer.state")
	return ret
end

function TransferStateCmd:handleReceive(dict)
	local tbl, params = self:parseMsg(dict, true)
	if type(tbl) == "boolean" then
		return tbl
	end
	require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance():parseData(tbl)
	CCSafeNotificationCenter:postNotification("ChangeServerDescView:updateState", params)
	dump(tbl, "TransferStateCmd")

	return true
end	
--------------------------- 转服状态 E---------------------------

--------------------------- 联盟推荐 S---------------------------
local TransferAllianceCmd = class("TransferAllianceCmd", LuaCommandBase)

function TransferAllianceCmd:create(refresh, serverId, lan, token)
	local ret = TransferAllianceCmd.new()
	ret:initWithName("transfer.alliance")
	ret:putParam("refresh", CCBool:create(refresh))
	if serverId then
		ret:putParam("serverId", CCInteger:create(atoi(serverId)))
	end
	if lan then
		ret:putParam("lan", CCString:create(lan))
	end
	if token then
		ret:putParam("token", CCInteger:create(atoi(token)))
	end
	return ret
end

function TransferAllianceCmd:handleReceive(dict)
	local tbl, params = self:parseMsg(dict, true)
	if type(tbl) == "boolean" then
		return tbl
	end
	dump(tbl, "TransferAllianceCmd")
	require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance():parseData(tbl)
	CCSafeNotificationCenter:postNotification("AllianceRecruitNode:updateNode", params)
	return true
end	
--------------------------- 联盟推荐 E---------------------------

--------------------------- 申请记录 S---------------------------
local TransferApplyRecordCmd = class("TransferApplyRecordCmd", LuaCommandBase)

function TransferApplyRecordCmd:create()
	local ret = TransferApplyRecordCmd.new()
	ret:initWithName("transfer.applyRecord")
	return ret
end

function TransferApplyRecordCmd:handleReceive(dict)
	local tbl, params = self:parseMsg(dict, true)
	if type(tbl) == "boolean" then
		return tbl
	end
	dump(tbl, "TransferApplyRecordCmd")
	CCSafeNotificationCenter:postNotification("ApplyRecordNode:updateNode", params)
	return true
end	
--------------------------- 申请记录 E---------------------------

--------------------------- 联盟招募 S---------------------------
local TransferRecruitCmd = class("TransferRecruitCmd", LuaCommandBase)

function TransferRecruitCmd:create(paras)
	local ret = TransferRecruitCmd.new()
	ret:initWithName("transfer.recruit")
	ret:putParam("prefer", CCString:create(tostring(paras.prefer)))
	ret:putParam("recruit", CCInteger:create(atoi(paras.recruit)))
	ret:putParam("city", CCInteger:create(atoi(paras.city)))

	if paras.power then
		ret:putParam("power", CCString:create(tostring(paras.power)))
	end
	if paras.active then
		ret:putParam("active", CCString:create(tostring(paras.active)))
	end
	if paras.kill then
		ret:putParam("kill", CCString:create(tostring(paras.kill)))
	end

	ret:putParam("lan", CCString:create(tostring(paras.lan)))
	ret:putParam("announce", CCString:create(tostring(paras.announce)))
	ret:putParam("feature", CCString:create(tostring(paras.feature)))
	ret:putParam("description", CCString:create(tostring(paras.description)))

	return ret
end

function TransferRecruitCmd:handleReceive(dict)
	local tbl = self:parseMsg(dict, true)
	if type(tbl) == "boolean" then
		return tbl
	end
	dump(tbl, "TransferRecruitCmd")
	--173296=发布成功
	CCCommonUtilsForLua:call("flyHint", "", "", getLang("173296"))
	require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance():parseData(tbl)
	CCSafeNotificationCenter:postNotification("RecruitDetailView:close")

	return true
end	
--------------------------- 联盟推荐 E---------------------------

--------------------------- 申请加入 S---------------------------
local TransferApplyCmd = class("TransferApplyCmd", LuaCommandBase)

function TransferApplyCmd:create(allianceId)
	local ret = TransferApplyCmd.new()
	ret:initWithName("transfer.apply")
	ret:putParam("allianceId", CCString:create(tostring(allianceId)))
	return ret
end

function TransferApplyCmd:handleReceive(dict)
	local tbl = self:parseMsg(dict, true)
	if type(tbl) == "boolean" then
		return tbl
	end
	dump(tbl, "TransferApplyCmd")
	--173294=申请联盟成功
	CCCommonUtilsForLua:call("flyHint", "", "", getLang("173294"))
	CCSafeNotificationCenter:postNotification("AllianceDetailView:applySuccess")
	return true
end	
--------------------------- 申请加入 E---------------------------


-------------------同盟转服情况--------------------
local AllyTransferCmd = class("AllyTransferCmd", LuaCommandBase)

function AllyTransferCmd:create()
	local ret = AllyTransferCmd.new()
	ret:initWithName("transfer.allyInfo")
	return ret
end

function AllyTransferCmd:handleReceive(dict)
	local tbl, params = self:parseMsg(dict, true)
	if type(tbl) == "boolean" then
		return tbl
	end
	dump(tbl, "AllyTransferCmd")
	CCSafeNotificationCenter:postNotification("AllyApplyNode:updateNode", params)
	return true
end	
-------------------同盟转服情况--------------------

-------------------招募预览--------------------
local PreviewCmd = class("PreviewCmd", LuaCommandBase)

function PreviewCmd:create()
	local ret = PreviewCmd.new()
	ret:initWithName("transfer.preview")
	return ret
end

function PreviewCmd:handleReceive(dict)
	local tbl, params = self:parseMsg(dict, true)
	if type(tbl) == "boolean" then return tbl end
	dump(tbl, "PreviewCmd")
	CCSafeNotificationCenter:postNotification("RecruitDetailView:updateView", params)
	return true
end	
-------------------招募预览--------------------

-------------------隐匿/取消隐匿--------------------
local AnonymousCmd = class("AnonymousCmd", LuaCommandBase)

function AnonymousCmd:create(anonymous)
	local ret = AnonymousCmd.new()
	ret:initWithName("transfer.anonymous")
	ret:putParam("anonymous", CCBool:create(anonymous))
	return ret
end

function AnonymousCmd:handleReceive(dict)
	local tbl, params = self:parseMsg(dict, true)
	if type(tbl) == "boolean" then return tbl end
	dump(tbl, "AnonymousCmd")
	if tbl.infoDic then
		require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance():parseData(tbl.infoDic)
	end
	return true
end	
-------------------招募预览--------------------

------------------报名-----------------------
local ApplyServerCmd = class("ApplyServerCmd", LuaCommandBase)

function ApplyServerCmd:create(applyServer)
	local ret = ApplyServerCmd.new()
	ret:initWithName("transfer.enroll")
	ret:putParam("applyServer", CCInteger:create(atoi(applyServer)))
	return ret
end

function ApplyServerCmd:handleReceive(dict)
	local tbl, params = self:parseMsg(dict, true)
	if type(tbl) == "boolean" then return tbl end
	dump(tbl, "ApplyServerCmd")
	CCCommonUtilsForLua:call("flyHint", "", "", getLang("173350"))
	require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance():parseApplyData(tbl)
	return true
end	
------------------报名-----------------------

------------------取消报名-----------------------
local ApplyCancelCmd = class("ApplyCancelCmd", LuaCommandBase)

function ApplyCancelCmd:create()
	local ret = ApplyCancelCmd.new()
	ret:initWithName("transfer.cancel")
	return ret
end

function ApplyCancelCmd:handleReceive(dict)
	local tbl, params = self:parseMsg(dict, true)
	if type(tbl) == "boolean" then return tbl end
	dump(tbl, "ApplyCancelCmd")
	CCCommonUtilsForLua:call("flyHint", "", "", getLang("173351"))
	require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance():parseApplyData(tbl)
	return true
end	
------------------取消报名-----------------------

------------------申请排行-----------------------
local ApplyRankCmd = class("ApplyRankCmd", LuaCommandBase)

function ApplyRankCmd:create(applyServer)
	local ret = ApplyRankCmd.new()
	ret:initWithName("transfer.rank")
	ret:putParam("applyServer", CCInteger:create(atoi(applyServer)))
	return ret
end

function ApplyRankCmd:handleReceive(dict)
	local tbl, params = self:parseMsg(dict, true)
	if type(tbl) == "boolean" then return tbl end
	dump(tbl, "ApplyRankCmd")
	CCSafeNotificationCenter:postNotification("ApplyRankView:updateView", params)
	return true
end	
------------------取消报名-----------------------

local ChangeServerState = {
	Free = 1,
	Match = 2,
	Transfer = 3,
}

local changeServerInstance = nil
function ChangeServerController.getInstance()
	if changeServerInstance == nil then
		changeServerInstance = ChangeServerController.new()
	end
	return changeServerInstance
end

function ChangeServerController:ctor()
	self.packageLimits = "" --背包限制高价值道具
	self.groups = {} --分组服务器
	self.matchTime = 0 --匹配开始时间
	self.startTime = 0 --转服开始时间
	self.endTime = 0 --转服结束时间
	self.joinSign = false --是否成功加入跨服联盟
	self.publishSign = true --是否手动发动过联盟招募
	self.publishTime = 0 --下次可发布时间戳
	self.cdTime = 0 --可转服时间戳
	self.free = 0 --联盟空余位置
	self.thisLimit = 0 --本次活动可招人数
	self.active = "" --活跃度dialog
	self.preview = false --是否显示预览
	self.anonymous = false --是否匿名
	self.canPublish = false --是否能够发布招募
	--转服期报名
	self.applySt = -1 --开始报名时间
	self.applyEt = -1 --结束报名时间
	self.applyCt = -1 --资格确认时间
	self.applyServer = 0 --所报名服务器
	self.applyState = 0 --0未报名 1报名中 2报名成功 3无需报名
	self.applyLimit = -1 --所报服务器p6限制数
	self.applyCd = -1 --下次可申请时间戳
	self.power = -1 --玩家排行依据战力
	self.flyEndTime = 0 --转服结束时间
end

function ChangeServerController:initConfig( dict )
	if dict == nil then
		return
	end
	local params = dict:objectForKey("server_transfer")

    if params then
		local tbl = dictToLuaTable(params)
		self.packageLimits = tbl.k11 --背包限制高价值道具
	end
end

function ChangeServerController:initData(dict)
	if dict == nil then return end
	local params = dict:objectForKey("transfer_alliance")
	if params then
		local tbl = dictToLuaTable(params)
		self.matchTime = atoi(tbl.matchTime)
		self.endTime = atoi(tbl.endTime)
		self:showIconMainUI()
	end
end

function ChangeServerController:parseData(data)
	if data.matchTime then
		self.matchTime = atoi(data.matchTime)
	end

	if data.startTime then
		self.startTime = atoi(data.startTime)
	end

	if data.endTime then
		self.endTime = atoi(data.endTime)
	end

	if data.join then
		self.joinSign = (data.join == "1")
	end

	if data.publish then
		self.publishSign = (data.publish == "1")
	end

	if data.publishTime then
		self.publishTime = atoi(data.publishTime)
	end

	if data.cdTime then
		self.cdTime = atoi(data.cdTime)
	end

	if data.refreshTime then
		self.refreshTime = atoi(data.refreshTime)
	end

	if data.group then
		self.groups = splitString(data.group, ";")
	end

	if data.free then
		self.free = atoi(data.free)
	end

	if data.thisLimit then
		self.thisLimit = atoi(data.thisLimit)
	end

	if data.active then
		self.active = data.active
	end

	if data.preview then
		self.preview = (data.preview == "1")
	end

	if data.anonymous then
		self.anonymous = (data.anonymous == "1")
	end

	if data.canPublish then
		self.canPublish = (data.canPublish == "1")
	end
end

function ChangeServerController:parseApplyData(data)
	if data.applySt then
		self.applySt = atoi(data.applySt)
	end

	if data.applyEt then
		self.applyEt = atoi(data.applyEt)
	end

	if data.applyCt then
		self.applyCt = atoi(data.applyCt)
	end

	if data.applyServer then
		self.applyServer = atoi(data.applyServer)
	end

	if data.applyState then
		self.applyState = atoi(data.applyState)
	end

	if data.applyLimit then
		self.applyLimit = atoi(data.applyLimit)
	end

	if data.applyCd then
		self.applyCd = atoi(data.applyCd)
	end

	if data.power then
		self.power = atoi(data.power)
	end

	if data.endTime then
		self.flyEndTime = atoi(data.endTime)
	end
end

function ChangeServerController:purge()
	changeServerInstance = nil
end

function ChangeServerController:tryCreateIcon()
    UiCompoentControoller.getIconEvent():emit({icon_cfg = self:getIconConfig(), eventType = "create"})
end

function ChangeServerController:getIconConfig()
	return {iconName = "game.UIComponent.ChangeServerNodeIcon", iconType = 2, order = 2.09}
end

function ChangeServerController:tryDestroyIcon()
    UiCompoentControoller.getIconEvent():emit({icon_cfg = self:getIconConfig(), eventType = "destroy"})
end

function ChangeServerController:showIconMainUI()
	if isCrossServerNow() then return end
	
	local function spawn() self:tryCreateIcon() end
	local function destory() self:tryDestroyIcon() end

	local now = GlobalData:call("getTimeStamp")
	if now > self.matchTime and now < self.endTime then
		spawn()

		DataController.TimeEventController:addTimeListener({
			key = "ChangeServerTimer",
			time = self.endTime,
			_callBack = destory,
		})
	elseif now < self.matchTime then
		DataController.TimeEventController:addTimeListener({
			key = "ChangeServerTimer",
			time = self.matchTime,
			_callBack = spawn,
		})
	end
end

function ChangeServerController:joinSuccess(data)
	self.joinSign = true
end

function ChangeServerController:getInfo(callBack)
	local cmd = TransferInfoCmd.create(callBack)
	cmd:send()
end

--从服务器获取部分转服条件数据
function ChangeServerController:getServerConditionState(serverId, callBack)
	local cmd = TransferConditionCmd.create(serverId, callBack)
	cmd:send()
end


function ChangeServerController:transfer(serverId, itemId, callBack)
	local cmd = TransferGoCmd.create(serverId, itemId, callBack)
	cmd:send()
end

--请求清理邮件
function ChangeServerController:clearMails(callBack)
	local cmd = TransferClearMailCmd.create(callBack)
	cmd:send()
end

function ChangeServerController:getServerItem(serverId)
	local cmd = TransferServerItemCmd.create(serverId)
	cmd:send()
end

function ChangeServerController:getTransferState()
	local cmd = TransferStateCmd:create()
	cmd:send()
end

function ChangeServerController:getTransferAlliance(refresh, serverId, lan, token)
	local cmd = TransferAllianceCmd:create(refresh, serverId, lan, token)
	cmd:send()
end

function ChangeServerController:getTransferRecord()
	local cmd = TransferApplyRecordCmd:create()
	cmd:send()
end

function ChangeServerController:transferApply(allianceId)
	local cmd = TransferApplyCmd:create(allianceId)
	cmd:send()
end

function ChangeServerController:recruit(paras)
	local cmd = TransferRecruitCmd:create(paras)
	cmd:send()
end

function ChangeServerController:getAllyTransfer()
	local cmd = AllyTransferCmd:create()
	cmd:send()
end

function ChangeServerController:getPreview()
	local cmd = PreviewCmd:create()
	cmd:send()
end

function ChangeServerController:setAnonymous(anonymous)
	local cmd = AnonymousCmd:create(anonymous)
	cmd:send()
end

function ChangeServerController:apply(server)
	local cmd = ApplyServerCmd:create(server)
	cmd:send()
end

function ChangeServerController:applyCancel()
	local cmd = ApplyCancelCmd:create()
	cmd:send()
end

function ChangeServerController:getApplyRank(server)
	local cmd = ApplyRankCmd:create(server)
	cmd:send()
end

function ChangeServerController:getPackgeLimitList()
	return self.packageLimits
end

function ChangeServerController:getGroups()
	return self.groups
end

function ChangeServerController:getActive()
	return self.active
end

function ChangeServerController:getMatchTime()
	return self.matchTime
end

function ChangeServerController:getStartTime()
	return self.startTime
end

function ChangeServerController:getEndTime()
	return self.endTime
end

function ChangeServerController:showPreview()
	return self.canPublish and self.preview
end

function ChangeServerController:isAnonymous()
	return self.anonymous
end

function ChangeServerController:getRankName(rank)
	rank = atoi(rank)
    if rank == 1 then
		return getLang("173239")
    elseif rank < 4 then
        return getLang("173240")
    elseif rank < 11 then
        return getLang("173241")
    elseif rank < 21 then
        return getLang("173242")
    elseif rank < 51 then
        return getLang("173243")
    elseif rank < 101 then
        return getLang("173244")
    else
        return getLang("173245")
    end
end

function ChangeServerController:getRecruitLimit()
	return self.free < self.thisLimit and self.free or self.thisLimit
end

function ChangeServerController:showPublishReward()
	return self.canPublish and (self.publishSign == false)
end

function ChangeServerController:showTransferDirectly()
	return self.joinSign == true
end

function ChangeServerController:canPublishRecruit()
	local now = GlobalData:call("getTimeStamp")
	return now > self.publishTime
end

function ChangeServerController:getCanPublish()
	return self.canPublish
end

--获取服务器火热程度图标颜色
function ChangeServerController:getHotColor(state)
	if atoi(state) == 3 then
		return cc.c3b(250, 6, 26)
	elseif atoi(state) == 2 then
		return cc.c3b(208, 124, 68)
	else
		return cc.c3b(124, 187, 148)
	end
end

--是否在空闲状态
function ChangeServerController:isFreeState()
	local now = GlobalData:call("getTimeStamp")
	if now < self.matchTime or now > self.endTime then
		return true
	else
		return false
	end
end

--是否在匹配状态
function ChangeServerController:isMatchState()
	local now = GlobalData:call("getTimeStamp")
	if now >= self.matchTime and now <= self.startTime then
		return true
	else
		return false
	end
end

--是否在转服状态
function ChangeServerController:isTransferState()
	local now = GlobalData:call("getTimeStamp")
	if now >= self.startTime and now <= self.endTime then
		return true
	else
		return false
	end
end

--转服cd是否冷却
function ChangeServerController:getCanTransfer()
	local now = GlobalData:call("getTimeStamp")
	if now > self.cdTime then 
		return true
	else
		return false
	end
end

--是否转服报名期
function ChangeServerController:isTransferApply()
	local now = GlobalData:call("getTimeStamp")
	return self.applySt < now and now < self.applyEt
end

--是否是转服确认期
function ChangeServerController:isTransferConfirm()
	local now = GlobalData:call("getTimeStamp")
	return self.applyEt < now and now <= self.applyCt
end

--是否是转服期
function ChangeServerController:isTransferFly()
	local now = GlobalData:call("getTimeStamp")
	return self.applyCt < now and now < self.flyEndTime
end

return ChangeServerController