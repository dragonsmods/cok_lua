--积分规则列表
--传activityId
local RankActInfoView = class("RankActInfoView", function()
    return PopupBaseView:create()
end)
RankActInfoView.__index = RankActInfoView

function RankActInfoView.create(activityId)
	local view = RankActInfoView.new()
	Drequire("game.CommonPopup.RankActComponent.RankActInfoView_ui"):create(view, 0)

	if view:initView(activityId) == false then
		return nil
	end
  	return view
end

function RankActInfoView:initView(activityId)
	Dprint("RankActInfoView:initView")
    
	local function touchHandle( eventType, x, y )
        if eventType == "began" then
            return self:onTouchBegan(x, y)
        elseif eventType == "moved" then
        else
            self:onTouchEnded(x, y)
        end
    end
    self:registerScriptTouchHandler(touchHandle)
    local touchNode = tolua.cast(self, "cc.CCIFTouchNode")
    touchNode:call("setTouchEnabled", true)
    touchNode:call("setSwallowsTouches" , true)

    -- 数据
    local _xmlData = CCCommonUtilsForLua:getGroupByKey("time_event_rules")
    if _xmlData == nil then
        return false
    end
    local _data = {}
    for k,v in pairs(_xmlData) do
        if v.pos == activityId then
            v.activityId = activityId
            table.insert(_data, v)
        end
    end
    table.sort( _data, function(a, b)
        if a and b then
            local _aid = tonumber(a.id) or 0
            local _bid = tonumber(b.id) or 0
            return _aid < _bid
        end
        return false
    end)
    -- dump(_data, "RankActInfoView:initView")
	self.ui:setTableViewDataSource("m_tableView", _data)

	return true
end

-- 点击关闭
function RankActInfoView:onClickBtnClose(  )
	PopupViewController:call("removePopupView", self)
end

function RankActInfoView:onTouchBegan(x, y)
	self.touchBeganX = x
	self.touchBeganY = y
	return true
end

function RankActInfoView:onTouchEnded(x, y)
    if (not isTouchInside(self.ui.m_bg, self.touchBeganX, self.touchBeganY)) then
        self:onClickBtnClose()
	end
end

return RankActInfoView