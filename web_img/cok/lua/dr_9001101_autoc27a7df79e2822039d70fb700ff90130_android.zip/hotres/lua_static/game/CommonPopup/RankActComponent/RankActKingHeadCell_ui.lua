----------------------------
-- Author: Elex
-- Date: 2019-12-12 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local RankActKingHeadCell_ui = class("RankActKingHeadCell_ui")

--#ui propertys


--#function
function RankActKingHeadCell_ui:create(owner, viewType, paramTable)
	local ret = RankActKingHeadCell_ui.new()
	CustomUtility:DoRes(0, true)
	CustomUtility:LoadUi("RankActKingHeadCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function RankActKingHeadCell_ui:initLang()
	LabelSmoker:setText(self.m_closingLabel, "168108")
	LabelSmoker:setText(self.m_tipLabel, "182219")
	LabelSmoker:setText(self.m_lbNone, "168108")
end

function RankActKingHeadCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function RankActKingHeadCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function RankActKingHeadCell_ui:onClickHead(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickHead", pSender, event)
end

return RankActKingHeadCell_ui

