local CommonRankConfig = class("CommonRankConfig")

function CommonRankConfig:create(configId, rankName, tag)
    local obj = CommonRankConfig.new()
    obj.rankName = rankName
    obj.tag = tag
    obj:loadConfig(configId, "ranking_display")
    return obj
end

function CommonRankConfig:createWithParams(params, tag)
    local obj = CommonRankConfig.new()
    obj.tag = tag
    obj:fromOldParms(params)
    return obj
end

function CommonRankConfig:createWithMgr(configId, rankName, rankMgr)
    local obj = CommonRankConfig.new()
    obj.rankName = rankName
    obj.rankMgr = rankMgr
    obj.tag = tag
    obj:loadConfig(configId, "ranking_display")
    return obj
end

function CommonRankConfig:loadConfig(configId, configGroup)
    self.configData = CCCommonUtilsForLua:getPropDictByIdGroup(configGroup, configId)

    self.id = tostring(self.configData.id)
    self.groupType = tonumber(self.configData.rankType)
    self.allianceType = tonumber(self.configData.allianceType)
    self.rewardTbl = tostring(self.configData.rewardTbl)
    self.rewardId = tostring(self.configData.rewardId)
    self.rewardTitle = tostring(self.configData.rewardTitle)
    self.rewardTips = tostring(self.configData.rewardTips)
    self.columnTitle = tostring(self.configData.columnTitle)
    self.refreshDialog = tostring(self.configData.refreshDialog)
    self.rankEndDialog = tostring(self.configData.rankEndDialog)
    self.scoreDescDialog = tostring(self.configData.scoreDescDialog or "")
    self.anonymousOpen = tostring(self.configData.anonymousOpen or "0")
    self.rankTitleDialog = tostring(self.configData.rankTitleDialog or "")
    self.switchTextDialog = tostring(self.configData.switchTextDialog or "")

    self:checkSelfId()

    self.pageSize = 100
end

function CommonRankConfig:getRankCellNode()
    if self:getIsPubgPhase() then
        return {
            luaPath = "game.Battlefield.room.RankPlayerTabCell",
            ccbiName = "WorldCraftRankPlayerTblCell",
            luaTop3Path = "game.Battlefield.room.Rank3PlayerNode"
        }
    elseif self:getIsAlliance() then
        return {
            luaPath = "game.CommonPopup.commonRank.CommonRankAllianceTblCell",
            ccbiName = "CommonRankPlayerTblCell",
            luaTop3Path = "game.CommonPopup.commonRank.CommonRank3AllianceNode"
        }
    elseif self:getIsKingdom() then
        return {
            luaPath = "game.CommonPopup.commonRank.CommonRankKingdomTblCell",
            ccbiName = "CommonRankPlayerTblCell",
            luaTop3Path = "game.CommonPopup.commonRank.CommonRank3KingdomNode"
        }
    else
        return {
            luaPath = "game.CommonPopup.commonRank.CommonRankPlayerTblCell",
            ccbiName = "CommonRankPlayerTblCell",
            luaTop3Path = "game.CommonPopup.commonRank.CommonRank3PlayerNode"
        }
    end
end

--pubg段位排行
function CommonRankConfig:getIsPubgPhase()
    return self.rankName == "PubgPhaseRank"
end

function CommonRankConfig:getRankGroupType()
    if self.groupType == 1 then
        return "local"
    else
        return "group"
    end
end

function CommonRankConfig:getIsAlliance()
    if self.allianceType == 1 then
        return true
    else
        return false
    end
end

function CommonRankConfig:getIsKingdom()
    if self.allianceType == 2 then
        return true
    else
        return false
    end
end

function CommonRankConfig:getRankSelfId()
    return self.selfId
end

function CommonRankConfig:getRewardTbl()
    return self.rewardTbl
end

function CommonRankConfig:getRewardId()
    return self.rewardId
end

function CommonRankConfig:getPageSize()
    return self.pageSize
end

function CommonRankConfig:getRankName()
    return self.rankName
end

function CommonRankConfig:getColumnTitle()
    return self.columnTitle
end

function CommonRankConfig:getRefreshDialog()
    return self.refreshDialog
end

function CommonRankConfig:getRankEndDialog()
    return self.rankEndDialog
end

function CommonRankConfig:getTag()
    return self.tag
end

function CommonRankConfig:getRewardTitle()
    return self.rewardTitle
end

function CommonRankConfig:getRewardTips()
    return self.rewardTips
end

function CommonRankConfig:getScoreDescDialog()
    return self.scoreDescDialog
end

function CommonRankConfig:getRealProtocol()
    return self.realProtocol
end

function CommonRankConfig:getPhraseInfo()
    return self.phraseInfo
end

function CommonRankConfig:getCountry()
    return self.country
end

function CommonRankConfig:getRankTitleDialog()
    return self.rankTitleDialog
end

function CommonRankConfig:getSwitchTextDialog()
    return self.switchTextDialog
end

function CommonRankConfig:getReqParams(pageIndex)
    local params = {
        protocol = self:getRealProtocol(),
        page = pageIndex,
        type = self:getRankName(),
        group = self:getRankGroupType(),
        pageSize = self:getPageSize(),
        selfId = self:getRankSelfId(),
        country = self:getCountry(),
    }
    return params
end

function CommonRankConfig:checkSelfId()
    self.hasAnonymousPermission = false
    if self:getIsAlliance() then
        local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
        if playerInfo and playerInfo:call("isInAlliance") then
            self.selfId = playerInfo:call("getAllianceId")
            local allianceInfo = playerInfo:getProperty("allianceInfo")
            if allianceInfo then
                local rank = allianceInfo:getProperty("rank")
                if rank == 5 then -- r5是联盟盟主
                    self.hasAnonymousPermission = true
                end
            end
        end
    elseif self:getIsKingdom() then
        local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
        if playerInfo then
            self.selfId = playerInfo:getProperty("selfServerId")
        end
    else
        local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
        if playerInfo then
            self.selfId = playerInfo:getProperty("uid")
            self.hasAnonymousPermission = true
        end
    end
end

function CommonRankConfig:getAnonymousOpen()
    if self.anonymousOpen and self.anonymousOpen == "1" then
        return true
    else
        return false
    end
end

function CommonRankConfig:getHasAnonymousPermission()
    if not self:getAnonymousOpen() then
        return false
    else
        return self.hasAnonymousPermission
    end
end

function CommonRankConfig:fromOldParms(params)
    --奖励配置
    local actType2XML = {
        ["typeTest"] = "consume_soldier_rank|20902000;20902001", --"20902000"个人本服排名奖励   "20902001"--个人全服排名奖励
        ["monster_hunter_personal"] = "monster_hunter_rank|20942000;20942001", --"20902000"个人本服排名奖励   "20902001"--个人全服排名奖励
        ["monster_hunter_alliance"] = "monster_hunter_rank|20942002;20942003;", --"20902000"个人本服排名奖励   "20902001"--个人全服排名奖励
        ["general"] = "general_rank|35011002;35011001", -- 招募之神分期奖励
        ["ladder"] = "ladder_rank|-1;-1", -- 竞技场特殊奖励逻辑
        ["kingdom_task"] = "donate_server_process_rank|34051000;34051001", -- 捐献排行榜
        ["treasure_bowl"] = "basin_rank|19860000;19860000", -- 聚宝盆排行榜
        ["building"] = "building_rank|39001002;39001001", -- 城建排行榜
        ["red_envelope"] = "five_red_envolope_rank|33720139", --红包排行榜奖励
        ["real_country_power"] = "|;" --争霸排行榜
    }

    -- 栏目标题配置
    local columnTitle = {
        ["typeTest"] = "108101;182091;102139", -- 108101=领主 182091=本期积分 102139=奖励
        ["general"] = "108101;182091;102139", -- 108101=领主 182091=本期积分 102139=奖励
        ["monster_hunter_personal"] = "108101;182091;102139", -- 108101=领主 182091=本期积分 102139=奖励
        ["monster_hunter_alliance"] = "108102;182091;102139", -- 108101=领主 182091=本期积分 102139=奖励
        ["ladder"] = "108101;620073;102139", -- 108101=领主 620073=玩家杯数 102139=奖励
        ["kingdom_task"] = "108101;182091;102139", -- 108101=领主 182091=本期积分 102139=奖励
        ["treasure_bowl"] = "108101;182091;102139", -- 108101=领主 182091=本期积分 102139=奖励
        ["building"] = "108101;182091;102139", -- 108101=领主 182091=本期积分 102139=奖励
        ["red_envelope"] = "108101;182091;102139",
        ["real_country_power"] = "108101;151439;" --争霸排行榜  108101=领主 151439=战力
        --红包排行榜奖励
    }

    --title配置
    local actId2Title = {
        ["typeTest"] = "182181;182183;182185",
        ["monster_hunter_personal"] = "182194;182196",
        ["monster_hunter_alliance"] = "182198;182200",
        ["general"] = "350245;350245;350245",
        ["ladder"] = "350245;350245;350245",
        ["kingdom_task"] = "650265;650266",
        ["treasure_bowl"] = "650265;650266",
        ["building"] = "350245;350245;350245",
        ["red_envelope"] = "350245;350245;350245",
        ["real_country_power"] = "42600014;42600014" --争霸排行榜
        --红包排行榜奖励
    }

    -- tips配置
    local tipsTitle = {
        ["typeTest"] = "221125", -- 221125 每小时刷新一次
        ["monster_hunter_personal"] = "221125", -- 221125 每小时刷新一次
        ["monster_hunter_alliance"] = "221125", -- 221125 每小时刷新一次
        ["general"] = "660025;660024", -- 660024=每日刷新一次 660025=每小时刷新一次
        ["ladder"] = "221125", -- 221125 每小时刷新一次
        ["kingdom_task"] = "221125", -- 221125 每小时刷新一次
        ["treasure_bowl"] = "221125", -- 221125 每小时刷新一次
        ["building"] = "221125;195026", -- 221125 每小时刷新一次
        ["red_envelope"] = "221125",
        ["real_country_power"] = "" --争霸排行榜
        --红包排行榜奖励
    }

    -- rewardTips 配置
    local rewardTips = {
        ["typeTest"] = "221122", -- 221122=活动结束后，奖励通过邮件发放
        ["general"] = "221122", -- 221122=活动结束后，奖励通过邮件发放
        ["monster_hunter_personal"] = "221122", -- 221122=活动结束后，奖励通过邮件发放
        ["monster_hunter_alliance"] = "221122", -- 221122=活动结束后，奖励通过邮件发放
        ["ladder"] = "620082", -- 620082=您每天必须手动领取排名奖励
        ["kingdom_task"] = "650268;650267", -- 650268=传送门开启后，奖励通过邮件发放 -- 650267=活动结束后，奖励通过邮件发放
        ["treasure_bowl"] = "650267", --
        ["building"] = "195025",
        ["red_envelope"] = "221122",
        --红包排行榜奖励
    }

    --cell配置
    local actType2CellFile = {
        ["typeTest"] = {
            path = "game.CommonPopup.commonRank.CommonRankPlayerTblCell",
            fileName = "CommonRankPlayerTblCell"
        },
        ["monster_hunter_personal"] = {
            path = "game.CommonPopup.commonRank.CommonRankPlayerTblCell",
            fileName = "CommonRankPlayerTblCell"
        },
        ["monster_hunter_alliance"] = {
            path = "game.CommonPopup.commonRank.CommonRankAllianceTblCell",
            fileName = "CommonRankPlayerTblCell"
        },
        ["general"] = {
            path = "game.CommonPopup.commonRank.CommonRankPlayerTblCell",
            fileName = "CommonRankPlayerTblCell"
        },
        ["ladder"] = {
            path = "game.CommonPopup.commonRank.CommonRankPlayerTblCell",
            fileName = "CommonRankPlayerTblCell"
        },
        ["kingdom_task"] = {
            path = "game.CommonPopup.commonRank.CommonRankPlayerTblCell",
            fileName = "CommonRankPlayerTblCell"
        },
        ["treasure_bowl"] = {
            path = "game.CommonPopup.commonRank.CommonRankPlayerTblCell",
            fileName = "CommonRankPlayerTblCell"
        },
        ["building"] = {
            path = "game.CommonPopup.commonRank.CommonRankPlayerTblCell",
            fileName = "CommonRankPlayerTblCell"
        },
        ["red_envelope"] = {
            path = "game.CommonPopup.commonRank.CommonRankPlayerTblCell",
            fileName = "CommonRankPlayerTblCell"
        },
    }

    --headRankNode配置
    local actType2RankNode = {
        ["typeTest"] = "game.CommonPopup.commonRank.CommonRank3PlayerNode",
        ["monster_hunter_personal"] = "game.CommonPopup.commonRank.CommonRank3PlayerNode",
        ["monster_hunter_alliance"] = "game.CommonPopup.commonRank.CommonRank3AllianceNode",
        ["general"] = "game.CommonPopup.commonRank.CommonRank3PlayerNode",
        ["ladder"] = "game.CommonPopup.commonRank.CommonRank3PlayerNode",
        ["kingdom_task"] = "game.CommonPopup.commonRank.CommonRank3PlayerNode",
        ["treasure_bowl"] = "game.CommonPopup.commonRank.CommonRank3PlayerNode",
        ["building"] = "game.CommonPopup.commonRank.CommonRank3PlayerNode",
        ["red_envelope"] = {"game.CommonPopup.commonRank.CommonRank3PlayerNode"},
    }

    --排行榜倒计时已结束dialog
    local actType2RankEndDialog = {
        ["kingdom_task"] = "650296;650297"
    }

    self.realProtocol = params.protocol
    self.phraseInfo = params.phraseInfo
    self.rankName = params.type
    self.country = params.country

    self.groupType = tonumber(params.viewType or 1)

    self.allianceType = 0
    if self.rankName == "monster_hunter_alliance" then
        self.allianceType = 1
    end

    local arr = string.split(actType2XML[self.rankName], "|")
    self.rewardTbl = arr[1]

    local arr2 = string.split(arr[2], ";")
    self.rewardId = arr2[self.groupType]

    arr = string.split(actId2Title[self.rankName], ";")
    self.rewardTitle = arr[self.groupType]

    arr = string.split(rewardTips[self.rankName], ";")
    self.rewardTips = arr[self.groupType] or arr[1]

    self.columnTitle = columnTitle[self.rankName]

    arr = string.split(tipsTitle[self.rankName], ";")
    self.refreshDialog = arr[self.groupType] or arr[1]

    if actType2RankEndDialog[self.rankName] then
        arr = string.split(actType2RankEndDialog[self.rankName], ";")
        self.rankEndDialog = arr[self.groupType] or arr[1]
    end

    self.pageSize = params.pageSize or 100

    if params.selfId then
        self.selfId = params.selfId
    else
        self:checkSelfId()
    end

    self.anonymousOpen = "0"
end

return CommonRankConfig
