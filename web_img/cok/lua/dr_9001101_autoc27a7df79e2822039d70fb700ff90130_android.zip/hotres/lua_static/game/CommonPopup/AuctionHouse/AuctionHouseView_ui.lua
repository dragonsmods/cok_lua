----------------------------
-- Author: Elex
-- Date: 2017-12-12 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local AuctionHouseView_ui = class("AuctionHouseView_ui")

--#ui propertys


--#function
function AuctionHouseView_ui:create(owner, viewType)
	local ret = AuctionHouseView_ui.new()
	CustomUtility:DoRes(7, true)
	CustomUtility:LoadUi("AuctionHouseView.ccbi", ret, owner, true, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then		owner:initTableViewByOwner()
	else		ret:initTableView()	end	return ret
end

function AuctionHouseView_ui:initLang()
end

function AuctionHouseView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function AuctionHouseView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function AuctionHouseView_ui:onHelpButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onHelpButtonClick", pSender, event)
end

function AuctionHouseView_ui:onAcutionRecordClicked(pSender, event)
	ButtonSmoker:forwardFunction(self, "onAcutionRecordClicked", pSender, event)
end

function AuctionHouseView_ui:onPersonalRecordClicked(pSender, event)
	ButtonSmoker:forwardFunction(self, "onPersonalRecordClicked", pSender, event)
end

function AuctionHouseView_ui:onBtnGetMoneyBackClicked(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBtnGetMoneyBackClicked", pSender, event)
end

function AuctionHouseView_ui:onBtnAnymousAuctionClicked(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBtnAnymousAuctionClicked", pSender, event)
end

function AuctionHouseView_ui:initTableView()
	TableViewSmoker:createView(self, "m_pTableView", "game.CommonPopup.AuctionHouse.AuctionHouseCell", 1, 3, "AuctionHouseCell")
end

function AuctionHouseView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return AuctionHouseView_ui

