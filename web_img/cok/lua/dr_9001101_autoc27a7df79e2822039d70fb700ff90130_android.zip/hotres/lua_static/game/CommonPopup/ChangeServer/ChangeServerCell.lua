local ChangeServerCell = class("ChangeServerCell", cc.TableViewCell)

function ChangeServerCell:create()
    local ret = ChangeServerCell.new()
    ret:init()
    return ret
end

function ChangeServerCell:init()
    self:setContentSize(cc.size(640, 36))
    self.txt = cc.Label:createWithSystemFont("", "Helvetica", 18, cc.size(0, 0))
	self.txt:setColor(cc.c3b(184, 172, 132))
	self.txt:setAnchorPoint(cc.p(0, 0.5))
    self.txt:setPosition(18, 18)
    self:addChild(self.txt)
end

function ChangeServerCell:setData(info)
    local rankName = require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance():getRankName(info.rank)
    local alliName = "(" .. info.abbr .. ") " .. info.name
    --173238={0}服{1}，{2}正在招人
    local recruitStr = getLang("173238", info.serverId, rankName, alliName)
    self.txt:setString(recruitStr)
end

return ChangeServerCell