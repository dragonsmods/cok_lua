--强化所
local Cell_Srtength = class("Cell_Srtength",Drequire("game.CommonPopup.OverView.Cell_Info.Cell_MainFile"))
local FUN_BUILD_NEWARMY_IMPROVE = 440000 --新兵种强化所
function Cell_Srtength:create(Id)
    local ret = Cell_Srtength.new(Id)
    if ret:initBaseById(Id) then
        return ret
    end
end
function Cell_Srtength:getCellDataTbl()
    if not self:checkIsVisible() then
        return
    end
    local _id = ''
    local _finishTime = -1
    local _state = -1
    local _label = ""
    local _name = ""
    local _icon = ""
    local _visible = ""
	local ctl = PreviewController.getInstance()
    local serverTbl = ctl.serverDataTbl or {}
    _id = "30711025"
 
    local isLock = self:checkIsUnLock(FUN_BUILD_NEWARMY_IMPROVE)
    --今日已经强化的次数
    local todayStrengthenCount = tonumber(serverTbl.todayStrengthenCount) or 0
    if todayStrengthenCount > 0 then
        _state = self.Queue_ST_WORK
        _finishTime = todayStrengthenCount
        _label = self:getDialogByIdIndex(_id,2)
    else
        _state = self.Queue_ST_IDLE
        _finishTime = todayStrengthenCount
        _label = self:getDialogByIdIndex(_id,1)
    end
    if not isLock then
        _state = self.Queue_ST_LOCK
        _finishTime = -1
        _label = "2000442"
    end

    _name,_icon,_visible = self:getNameIconVisibleBySubId(_id)
    local cellOne = {id = _id, name = _name,icon = _icon, state = _state,param1 = _finishTime, label = _label,cell = self}
    if _visible == "1" then
        self.CellTbl.cellMeta={cellOne}
    end

    return self.CellTbl

end

function Cell_Srtength:OnClickJump(_id,_state)
    if _id == "30711025" then
        self:jumpByTypeAndTarget(1,FUN_BUILD_NEWARMY_IMPROVE)
    end

end

return Cell_Srtength