

local MIN_NAME_CHAR = 1
local MAX_NAME_CHAR = 16

local AuctionHouseInputAckView = class("AuctionHouseInputAckView",
	function()
		return PopupBaseView:create()
	end
)

function AuctionHouseInputAckView:create(ackType, cellData)
 local view = AuctionHouseInputAckView.new()
    Drequire("game.CommonPopup.AuctionHouse.AuctionHouseInputAckView_ui"):create(view, 0)
    if view:initView(ackType, cellData) then
        return view
    end
    return false
end

function AuctionHouseInputAckView:initView(ackType, cellData)
	self.ackType = ackType
	self.cellData = cellData
	local editSize = self.ui.m_InputNode:getContentSize()
	self.m_editBox = InputFieldMultiLine:call("create", editSize, "01_24.png", 30)
	self.nameMaxLen = MAX_NAME_CHAR
	self.m_editBox:call("setAddH", 5)
	self.m_editBox:call("setMaxChars", self.nameMaxLen)
	self.m_editBox:call("setLineNumber", 1)
	self.m_editBox:call("setFontColor", ccBLACK)	
	self.m_editBox:call("setSwallowsTouches", true)
	self.m_editBox:call("setMoveFlag", true)
	self.m_editBox:call("setcalCharLen", true)
	self.m_editBox:call("setOnlySingleLine", true)
	self.m_editBox:call("setPlaceHolder", getLang("105214"))
	tolua.cast(self.m_editBox, "InputFieldMultiLine"):call("setPlaceHolder", "")
	tolua.cast(self.m_editBox, "cc.Node"):setPosition(ccp(0, 0))
	tolua.cast(self.m_editBox, "cc.Node"):setAnchorPoint(ccp(0, 0))
	self.ui.m_InputNode:addChild(tolua.cast(self.m_editBox, "cc.Node"))

	self.touchLayer = cc.Layer:create()
	self:addChild(self.touchLayer)

	local function touchHandle( eventType, x, y )
		print("touchHandle", eventType, x, y)
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		
		else
			self:onTouchEnded(x, y)
		end
	end
	self.touchLayer:registerScriptTouchHandler(touchHandle)
	self.touchLayer:setTouchEnabled(true)
	self.touchLayer:setSwallowsTouches(false)

	-- dump(ackType, "auction house ack+++")
	if ackType == Auction_House_Ack_GetMoneyBack then 
		self.ui.m_pLabelTitle:setString(getLang("9440881")) --领取
		tolua.cast(self.m_editBox, "InputFieldMultiLine"):call("setText", AuctionHouseController:getGoldCountInAuction())
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_okBtn, getLang("9440881"))
	else
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_okBtn, getLang("9440882"))
		self.ui.m_pLabelTitle:setString(getLang("9440882")) --出价
	end

	return true
end

function AuctionHouseInputAckView:onEnter()
	registerScriptObserver(self, self.onRemoveAckView, AuctionRemoveAckView)
end

function AuctionHouseInputAckView:onExit()
	unregisterScriptObserver(self, AuctionRemoveAckView)
end

function AuctionHouseInputAckView:onRemoveAckView( )
	PopupViewController:call("removePopupView", self)
end

function AuctionHouseInputAckView:onTouchBegan(x, y)
	return true
end

function AuctionHouseInputAckView:onTouchEnded(x, y)
	if (self.ui.m_bg and isTouchInside(self.ui.m_bg, x, y)) then
		tolua.cast(self.m_editBox, "cc.Layer"):setTouchEnabled(true)
		return
	end
	if (not isTouchInside(self.m_bg, x, y)) then
		PopupViewController:call("removePopupView", self) 
	end
end

function AuctionHouseInputAckView:onOkBtnClick(pSender, event)
	dump("AuctionHouseInputAckView:onOkBtnClick+++")
	self.m_editBox = tolua.cast(self.m_editBox, "InputFieldMultiLine")
	local input = self.m_editBox:call("getText")
	if input==nil or input == "" or tonumber(input) == nil or tonumber(input) <= 0 then 
		LuaController:flyHint("", "", getLang("E000000"))
		return
	end

	local nNumInput = tonumber(input)
	local goldInAuction = tonumber(AuctionHouseController:getGoldCountInAuction())
	if self.ackType == Auction_House_Ack_GetMoneyBack then 
		-- if nNumInput > goldInAuction then 
		-- 	LuaController:flyHint("", "", getLang("9440953"))
		-- 	return 
		-- end
		-- dump("send auction cmd+++")
    	-- AuctionHouseController:getMoneyBack(nNumInput)
	elseif self.ackType == Auction_House_Ack_GivePrice then 
		-- dump(self.cellData,"ack+++")
		local totalGold = goldInAuction + GlobalDataCtr.getPlayerGold()
		if totalGold < nNumInput then 
			LuaController:flyHint("", "", getLang("111909")) --金币不足
			return
		end
		-- dump(self.cellData, "send give price cmd+++")
		AuctionHouseController:givePrice(self.cellData.uuid, tonumber(self.cellData.price), nNumInput, AuctionHouseController:getAnonmous())
	end
	self.m_editBox:call("closeIME")
	self:onRemoveAckView()
end


return AuctionHouseInputAckView


