

local AuctionHouseView = class("AuctionHouseView", 
	function()
    return PopupBaseView:create()
	end
	)
AuctionHouseView.__index =  AuctionHouseView

function AuctionHouseView:create()
 local view = AuctionHouseView.new()
    Drequire("game.CommonPopup.AuctionHouse.AuctionHouseView_ui"):create(view, 4)
    if view:initView() then
        return view
    end
    return false
end

function AuctionHouseView:initView()
	-- dump("AuctionHouseView:initView+++")
    AuctionHouseController:setAnonmous(0)
    self:setTitleName(getLang("9440888"))
    self.ui.m_pLabelBackMoney:setString(getLang("9440931"))
    self.ui.m_pLabelBackMoneyCount:setString("0")
	self.ui.m_pNodeIcon:removeAllChildren()
    self.ui.m_pLabelNotice:setVisible(false)
    self.ui.m_pLabelNotice:setString(getLang("9441233"))
    
	CCLoadSprite:call("loadDynamicResourceByName", "uicompoent_face")
    local iconName = "AuctionHouseBg.png"
    local spr = nil
    local icon = CCLoadSprite:call("getSF", iconName)
    if icon ~= nil then 
        spr = CCLoadSprite:call("createSprite",iconName)
    else
        -- dump("error:auction house bg icon is not found+++ "..iconName)
        spr = CCLoadSprite:call("createSprite","banner.png")
    end
    self.ui.m_pNodeIcon:addChild(spr)
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnAnomous, getLang("9440886"))
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnGet, getLang("9440881"))
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnPersonalRecord, getLang("9440885"))
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnAcutionRecord, getLang("9440884"))
    
    function onTouch(eventType, x, y)  
        if eventType == "began" then  
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)  
        else  
            return self:onTouchEnded(x, y)  
        end
    end
    self:setTouchEnabled(true)
    self:registerScriptTouchHandler(onTouch)

    return true
end

function AuctionHouseView:onEnter()
    -- dump("AuctionHouseView:onEnter+++") 
    UIComponent:call("showPopupView", 4)
    registerScriptObserver(self, self.onGetAuctionViewDataBack, AuctionGetViewDataBack)
    registerScriptObserver(self, self.onAuctionGivePriceDataBack, AuctionGivePriceDataBack)
    registerScriptObserver(self, self.onAuctionAddPriceDataBack, AuctionAddPriceDataBack)
    registerScriptObserver(self, self.onAuctionWithdrawDataBack, AuctionWithdrawDataBack)
    registerScriptObserver(self, self.onAuctionListViewDataChanged, AuctionListViewDataChanged)
    registerScriptObserver(self, self.onAuctionAckGrivePriceNow, AuctionAckGrivePriceNow)
end

function AuctionHouseView:onExit()
    unregisterScriptObserver(self, AuctionGetViewDataBack)
    unregisterScriptObserver(self, AuctionGivePriceDataBack)
    unregisterScriptObserver(self, AuctionAddPriceDataBack)
    unregisterScriptObserver(self, AuctionWithdrawDataBack)
    unregisterScriptObserver(self, AuctionListViewDataChanged)
    unregisterScriptObserver(self, AuctionAckGrivePriceNow)
end

function AuctionHouseView:onTouchBegan(x, y)
    return true
end

function AuctionHouseView:onTouchMoved(x, y)
end

function AuctionHouseView:onTouchEnded(x, y)
end

function AuctionHouseView:updateView()
    local goldInAuction = AuctionHouseController:getGoldCountInAuction()
    self.ui.m_pLabelBackMoneyCount:setString(CC_CMDITOA(goldInAuction))
    self.ui:setTableViewDataSource("m_pTableView", AuctionHouseController:getAuctionHouseViewData())

    local enableBtn = AuctionHouseController:isInActivity()
    self.ui.m_btnAnomous:setEnabled(enableBtn)
    self.ui.m_btnAcutionRecord:setEnabled(enableBtn)
    self.ui.m_btnPersonalRecord:setEnabled(enableBtn)
    self.ui.m_pLabelNotice:setVisible(not enableBtn)
    self.ui.m_btnGet:setEnabled(goldInAuction~="0") 
end

function AuctionHouseView:onAuctionAckGrivePriceNow( dict )
    -- dump("AuctionHouseView:onAuctionAckGrivePriceNow+++")
    if not dict or not AuctionHouseController.curAuctionCellInfo then 
        return
    end
    local tbl = dictToLuaTable(dict)
    -- dump(tbl,"tbl+++")
    -- dump(AuctionHouseController.curAuctionCellInfo,"cell info+++")
    local myPrice = tbl.num
    local uuid = AuctionHouseController.curAuctionCellInfo.uuid
    local price = tonumber(AuctionHouseController.curAuctionCellInfo.price)
    local ano = AuctionHouseController:getAnonmous()
    AuctionHouseController:addPrice(uuid, price, myPrice-price, ano)
    AuctionHouseController.curAuctionCellInfo = nil
end

function AuctionHouseView:onAuctionListViewDataChanged( )
    -- dump("AuctionHouseView:onAuctionListViewDataChanged+++")
    self.ui:setTableViewDataSource("m_pTableView", AuctionHouseController:getAuctionHouseViewData())
end

function AuctionHouseView:onGetAuctionViewDataBack( )
    -- dump("AuctionHouseView:onGetAuctionViewDataBack+++")
    self:updateView()
end

function AuctionHouseView:onAuctionGivePriceDataBack()
    -- dump("AuctionHouseView:onAuctionGivePriceDataBack+++")
    self:updateView()
end

function AuctionHouseView:onAuctionAddPriceDataBack(  )
    -- dump(allAuctionAddPriceCmdBackData, "AuctionHouseView:onAuctionAddPriceDataBack+++")
    self:updateView()
end

function AuctionHouseView:onAuctionWithdrawDataBack(  )
    -- dump(allAuctionAddPriceCmdBackData, "AuctionHouseView:onAuctionWithdrawDataBack+++")
    local goldInAuction = AuctionHouseController:getGoldCountInAuction()
    self.ui.m_pLabelBackMoneyCount:setString(CC_CMDITOA(goldInAuction))
end

function AuctionHouseView:onHelpButtonClick()
    LuaController:call("showFAQ","45284")
end

--拍卖行交易纪录
function AuctionHouseView:onAcutionRecordClicked()
	local view = Drequire("game.CommonPopup.AuctionHouse.AuctionHouseRecordView"):create(Auction_House_Record_All)
    PopupViewController:addPopupView(view)
end

--个人交易纪录
function AuctionHouseView:onPersonalRecordClicked()
	local view = Drequire("game.CommonPopup.AuctionHouse.AuctionHouseRecordView"):create(Auction_House_Record_Personal)
    PopupViewController:addPopupView(view)
end

--领取
function AuctionHouseView:onBtnGetMoneyBackClicked()
	-- local view = Drequire("game.CommonPopup.AuctionHouse.AuctionHouseInputAckView"):create(Auction_House_Ack_GetMoneyBack)
	-- PopupViewController:addPopupView(view)
    local goldInAuc = AuctionHouseController:getGoldCountInAuction()
    if goldInAuc==nil or goldInAuc == "" or tonumber(goldInAuc) == nil or tonumber(goldInAuc) <= 0 then 
        LuaController:flyHint("", "", getLang("E000000"))
        return
    end
    -- dump(goldInAuc,"send auction cmd+++")
    local nNumInput = tonumber(goldInAuc)
    AuctionHouseController:getMoneyBack(nNumInput)
end

--匿名拍卖
function AuctionHouseView:onBtnAnymousAuctionClicked()
    if AuctionHouseController:getAnonmous() == 0 then
        AuctionHouseController:setAnonmous(1)
        CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnAnomous, getLang("9440887"));
    else
        AuctionHouseController:setAnonmous(0)
        CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnAnomous, getLang("9440886"));
    end
end


return AuctionHouseView



