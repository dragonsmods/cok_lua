local ApplyRankView = class("ApplyRankView", PopupBaseView)

function ApplyRankView:create(serverId)
    local view = ApplyRankView.new(serverId)
    Drequire("game.CommonPopup.ChangeServer.ApplyRankView_ui"):create(view, 1)
    if view:initView() then return view end
end

function ApplyRankView:ctor(serverId)
    self.serverId = serverId
    self.ctrl = require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance()
end

function ApplyRankView:initView()
    self.ctrl:getApplyRank(self.serverId)
    self.ui.m_titleTxt:setString(getLang("173334"))
    self.ui.m_textTitle1:setString(getLang("173331"))
    self.ui.m_textTitle2:setString(getLang("173332"))
    self.ui.m_textTitle3:setString(getLang("173333"))
    return true
end

function ApplyRankView:updateView(ref)
    self.m_data = {}
    
    if ref then
        local data = dictToLuaTable(ref)
        self.m_data = data.rank or {}
        self.ui:setTableViewDataSource("m_listView", self.m_data)

        if data.interval then
            self.ui.m_intervalTxt:setString(getLang("173342", data.interval))
        end

        if self.ctrl.power then
            self.ui.m_powertTxt:setString(getLang("173343", CC_CMDITOA(self.ctrl.power)))
        end

        self.ui.m_timeTitleText:setString(getLang("173341", ""))
        if data.time then
            local mark = os.date("%H;%M", atoi(data.time))
            local solts = splitString(mark, ";")
            if #solts == 2 then
                self.ui.m_timeLeftText:setString(solts[1] .. ":" .. solts[2])
            end
        else
            self.ui.m_timeLeftText:setString("----")
        end

        if data.top then
            self.ui.m_topTxt:setString(getLang("173352", data.top))
        end
    end

    if #self.m_data == 0 then self.ui.m_noRankTxt:setString(getLang("170042")) end
end

function ApplyRankView:onEnter()
    registerScriptObserver(self, self.updateView, "ApplyRankView:updateView")
end

function ApplyRankView:onExit()
    unregisterScriptObserver(self, "ApplyRankView:updateView")
end

return ApplyRankView