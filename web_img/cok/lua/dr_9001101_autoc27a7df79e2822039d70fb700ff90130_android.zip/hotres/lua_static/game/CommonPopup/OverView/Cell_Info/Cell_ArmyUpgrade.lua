--士兵进阶(server)
local Cell_ArmyUpgrade = class("Cell_ArmyUpgrade",Drequire("game.CommonPopup.OverView.Cell_Info.Cell_MainFile"))
local FUN_BUILD_BARRACK1 = 423000	--兵营
local FUN_BUILD_BARRACK2 = 424000	--马厩
local FUN_BUILD_BARRACK3 = 425000	--靶场
local FUN_BUILD_BARRACK4 = 426000	--战车
local PreviewController = require("game.CommonPopup.OverView.PreviewController")

function Cell_ArmyUpgrade:create(Id)
    local ret = Cell_ArmyUpgrade.new(Id)
    if ret:initBaseById(Id) then
        return ret
    end
end
function Cell_ArmyUpgrade:getCellDataTbl()
    if not self:checkIsVisible() then
        return
    end
    local _id = ''
    local _finishTime = -1
    local _state = -1
    local _label = ""
    local _name = ""
    local _icon = ""
    local _visible = ""
    local bid = -1
	local ctl = PreviewController.getInstance()
    local armyArray = ctl.serverDataTbl.armyArray or {}
    local tempTbl = {}
    for k, v in pairs(armyArray) do
        local _label = ""
        local strenTimes = tonumber(v.strenTimes) or 0
        --步
        if v.armyType == "0" then
            _id = "30711026"
            bid = FUN_BUILD_BARRACK1
        --骑
        elseif v.armyType == "1" then
            _id = "30711027"
            bid = FUN_BUILD_BARRACK2
        --弓
        elseif v.armyType == "2" then
            _id = "30711028"
            bid = FUN_BUILD_BARRACK3
        --车
        elseif v.armyType == "3" then
            _id = "30711029"
            bid = FUN_BUILD_BARRACK4
        end
        if strenTimes > 0 then
            _label = self:getDialogByIdIndex(_id,2)
            _state = self.Queue_ST_WORK
        else
            _label = self:getDialogByIdIndex(_id,1)
            _state = self.Queue_ST_IDLE
        end
        --未解锁
        if not self:checkIsUnLock(bid) then
            _state = self.Queue_ST_LOCK
            _finishTime = -1
            _label = "2000442"
        end
        _name,_icon,_visible = self:getNameIconVisibleBySubId(_id)
        local meta = {id = _id, state = _state, param1 = strenTimes, name = _name, icon = _icon, label = _label,cell = self}
        if _visible == "1" then
            table.insert(tempTbl, meta)
        end
    end
    self.CellTbl.cellMeta=tempTbl

    return self.CellTbl

end

function Cell_ArmyUpgrade:OnClickJump(_id,_state)
    if _id == "30711026" then
        self:jumpByTypeAndTarget(1,FUN_BUILD_BARRACK1)
    elseif _id == "30711027" then
        self:jumpByTypeAndTarget(1,FUN_BUILD_BARRACK2)
    elseif _id == "30711028" then
        self:jumpByTypeAndTarget(1,FUN_BUILD_BARRACK3)
    elseif _id == "30711029" then
        self:jumpByTypeAndTarget(1,FUN_BUILD_BARRACK4)
    end

end

return Cell_ArmyUpgrade