require "game.controller.LuaActivityController"

WangLihongShareView = class("WangLihongShareView", function (  )
	return PopupBaseView:call("create")
end)

function WangLihongShareView:create(  )
	local ret = WangLihongShareView.new()
	if ret:initView() == false then
		ret = nil
	end
	return ret
end

function WangLihongShareView:initView(  )

	MyPrint("WangLihongShareView:initView")
	MyPrint(self)
	dump(self)
	if self:init(true, 0) == false then
		MyPrint("WangLihongShareView init error")
    	return false	
	end
	
	self:setHDPanelFlag(true)

	if DynamicResourceController2:call("checkDynamicResource", "activity_res") == false then
		return false
	end

	CCLoadSprite:call("loadDynamicResourceByName", "activity_res")

	self.musicpath = cc.FileUtils:getInstance():getWritablePath() .. "dresource/activity_music/wanglihong"
	if isIOS() then
		self.musicpath = self.musicpath .. ".aac"
	else
		self.musicpath = self.musicpath .. ".ogg"
	end

	if cc.FileUtils:getInstance():isFileExist(self.musicpath) == false then
		return false
	end
	-- cc.SimpleAudioEngine:getInstance():preloadMusic(self.musicpath)
	
	

	CCLoadSprite:call("doResourceByCommonIndex", 310, true)

	local isPad = CCCommonUtilsForLua:call("isIosAndroidPad")

	local winsize = cc.Director:getInstance():getIFWinSize()
	self:setContentSize(winsize)

	local proxy = cc.CCBProxy:create()
	local ccbiUrl = "WangLihongShareView.ccbi"
	local node = CCBReaderLoad(ccbiUrl, proxy, self)
    if nil == node then
        return false
    end

    if isPad then
    	self.m_mainNode:setScale(2)
    end

	self:addChild(node)

	-- 界面展示
	local height = 0
	local label = cc.Label:create()
	label:setString(getLang("151244"))
    label:setSystemFontSize(22)
    label:setColor(cc.c3b(255, 232, 161))
    label:setAnchorPoint(cc.p(0.5, 0))
    label:setDimensions(430, 0)
    label:setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    label:setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_BOTTOM)
    label:setPosition(cc.p(0, 0))
    self.m_labelNode:addChild(label)
    height = height + label:getContentSize().height

    local label = cc.Label:create()
	label:setString(getLang("151238"))
    label:setSystemFontSize(18)
    label:setColor(cc.c3b(255, 255, 255))
    label:setAnchorPoint(cc.p(0.5, 0))
    label:setDimensions(470, 0)
    label:setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    label:setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_BOTTOM)
    label:setPosition(cc.p(0, height))
    self.m_labelNode:addChild(label)

    local wanglihongdata = LuaActivityController.getInstance().wanglihongdata
    if wanglihongdata == nil  
    	or ActivityController:call("checkIsToday", LuaActivityController.getInstance().lastwanglihongrefreshtime) == false 
    	then
	    self.m_ListenBtn:setEnabled(false)
	    self.m_shareBtn:setEnabled(false)
	    LuaActivityController.getInstance():startGetWangLihongData()
	end

	-- 151230    抢先试听
	CCCommonUtilsForLua:call("setButtonTitle", self.m_ListenBtn, getLang("151230"))
	-- 151231    分享歌曲
	CCCommonUtilsForLua:call("setButtonTitle", self.m_shareBtn, getLang("151231"))

	local function onGetDataInitEnd( ref )
		self:onGetDataInitEnd(ref)
	end
	local handler1 = self:registerHandler(onGetDataInitEnd)

	local function onEnterFrame( dt )
		local lastlistenwanglihongtime = LuaActivityController.getInstance().lastlistenwanglihongtime
		local nowtime = LuaController:call("getTimeStamp")
		if nowtime - lastlistenwanglihongtime < WANGLIHONG_MUSIC_TIME_SPAN then
			self.m_ListenBtn:setEnabled(false)
			return
		end

		local wanglihongdata = LuaActivityController.getInstance().wanglihongdata
		if nil == wanglihongdata then
			self.m_ListenBtn:setEnabled(false)
		    return
		end

		self.m_ListenBtn:setEnabled(true)
	end


	local function onNodeEvent( event )
        if event == "enter" then
        	onEnterFrame(0)
        	self.entry = tonumber(self:getScheduler():scheduleScriptFunc(onEnterFrame, 1.0, false))
        	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "wanglihong_data_init")
        elseif event == "exit" then
        	self:getScheduler():unscheduleScriptEntry(self.entry)
        	CCSafeNotificationCenter:unregisterScriptObserver(self, "wanglihong_data_init")
        else
        end
    end
    self:registerScriptHandler(onNodeEvent)

    self.m_node1:removeAllChildren()
    local size = self.m_node1:getContentSize()
    local clipNode = tolua.cast(CCClipNode:call("create", size.width, size.height), "cc.Node")
    clipNode:setAnchorPoint(cc.p(0, 0))
    self.m_node1:addChild(clipNode)
    local spr = CCLoadSprite:call("createSprite", "wanglihong_music_bg.png")
    spr:setAnchorPoint(cc.p(0, 0))
    spr:setPosition(cc.p(-5, 0))
    clipNode:addChild(spr)

    self.touchLayer = cc.Layer:create()
	self:addChild(self.touchLayer)

	local function touchHandle( eventType, x, y )
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		else
			self:onTouchEnded(x, y)
		end
	end
	self.touchLayer:registerScriptTouchHandler(touchHandle)
	self.touchLayer:setTouchEnabled(true)
	self.touchLayer:setSwallowsTouches(false)

	return true
end

function WangLihongShareView:ctor(  )
	
end

function WangLihongShareView:onGetDataInitEnd( ref )
	MyPrint("WangLihongShareView:onGetDataInitEnd")
	local wanglihongdata = LuaActivityController.getInstance().wanglihongdata
	if nil == wanglihongdata then
		self.m_ListenBtn:setEnabled(false)
	    self.m_shareBtn:setEnabled(false)
	    return
	end

	self.m_ListenBtn:setEnabled(true)
	self.m_shareBtn:setEnabled(true)

end

function WangLihongShareView:onListenClick(  )
	MyPrint("WangLihongShareView:onListenClick")
	
	local wanglihongdata = LuaActivityController.getInstance().wanglihongdata
	if nil == wanglihongdata then
		return
	end

	if wanglihongdata.listened_times_today >= wanglihongdata.listen_total_times_today then
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("151245"))
		return
	end

	LuaActivityController.getInstance():startShitingWangLihong()
	self.m_ListenBtn:setEnabled(false)
	SoundController:call("sharedSound"):call("stopAllMusic")
	cc.SimpleAudioEngine:getInstance():playMusic(self.musicpath, false)
end

function WangLihongShareView:onShareClick(  )
	MyPrint("WangLihongShareView:onShareClick")

	local wanglihongdata = LuaActivityController.getInstance().wanglihongdata

	if nil == wanglihongdata then
		return 
	end

	if wanglihongdata.shared_times_today >= wanglihongdata.share_total_times_today then
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("151245"))
		return
	end

	if CCCommonUtilsForLua:call("fbIsLogin") == false then
		MyPrint("not login !!!!!")
		CCCommonUtilsForLua:call("fbLogin")
		return
	end

	LuaActivityController.getInstance():startFenxiangWangLihong()
	wanglihongdata.shared_times_today = wanglihongdata.shared_times_today + 1

	if CCCommonUtilsForLua:call("facebookPostMethod", "leehom") then
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("105552"))
	end

	-- local link = "https://fb.me/789290781112244?from_feed=ios_king"
	-- local name = "Clash Of Kings"
 --    local caption = getLang("107088")
 --    local linkDescription = getLang("107087")
 --    local pictureUrl = ""
 --    local ref = ""
 --    local shareDialog = ""
 --    CCCommonUtilsForLua:call("fbPublishFeedDialog", name,caption,linkDescription,link,pictureUrl,1,ref)

end

function WangLihongShareView:onTouchBegan( x, y )
	MyPrint("WangLihongShareView began", x, y)
	if isTouchInside(self.m_touchNode, x, y) then
		MyPrint("WangLihongShareView isTouchInside layer")
		return false
	end
	return true	
end

function WangLihongShareView:onTouchEnded( x, y )
	if isTouchInside(self.m_touchNode, x, y) then
		return
	end
	self:call("closeSelf")
end

