--[[ 
    试炼场排行榜
 ]]

 local TrainingRankView = class("TrainingRankView", function() return PopupBaseView:create() end)
 TrainingRankView.__index = TrainingRankView
 
 -- -------------------------------------------------------------
 function TrainingRankView.create()
    local view = TrainingRankView.new()
	Drequire("game.CommonPopup.TrainingRankView_ui"):create(view, 0)
    view:initView()
    return view
end

function TrainingRankView:initView()
    local params = {
        name = "TrialFieldV2",
        id = "52098290",
        viewSize = self.ui.m_nodeContent:getContentSize(),
    }
    local rankView = Drequire("game.CommonPopup.CommonRankRealTime.CommonRankRealTimeView"):create(params)
    if rankView then
        self.ui.m_nodeContent:addChild(rankView)
    end
end

function TrainingRankView:onEnter()
    self:setTitleName(getLang("52045020"))    --52045020=赛季闯关排行榜
end

function TrainingRankView:onExit()
end

return TrainingRankView