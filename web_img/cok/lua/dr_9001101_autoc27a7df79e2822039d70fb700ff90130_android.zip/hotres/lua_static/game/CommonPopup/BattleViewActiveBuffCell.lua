--[[
    2019-11-13
    出征增益信息单元
    BattleViewActiveBuffCell 
]]
local ArtilleryBuffType = 9999
local ArtilleryBuffTimeType = 66

local BattleViewActiveBuffCell = class("BattleViewActiveBuffCell", function()
    return cc.Layer:create()
end)


function BattleViewActiveBuffCell:create(idx)
    local view = BattleViewActiveBuffCell.new()
    Drequire("game.CommonPopup.BattleViewActiveBuffCell_ui"):create(view, 0)
    if view ~= nil then
        return view
    end 
end

function BattleViewActiveBuffCell:onEnter()

end

function BattleViewActiveBuffCell:refreshCell(cellInfo , idx)
    -- dump(idx, "BattleViewActiveBuffCell:refreshCell idx")
    -- dump(cellInfo, "BattleViewActiveBuffCell:refreshCell cellInfo")
    -- 停掉定时器
    if self.entry then 
        cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry) 
        self.entry = nil
    end 

    self.m_cellInfo = cellInfo
    self.m_endTime = 0
    if cellInfo ~= nil then
        -- 统一设置结束时间
        self.m_endTime = cellInfo.data.endTime and tonumber(cellInfo.data.endTime)/1000 or nil
        if self.m_endTime and self.m_endTime > 2147483647 then -- 时间特别大，表示永久，不显示结束时间 2^31-1
            self.m_endTime = nil
        end

        if self.m_endTime == nil then
            self.ui.m_timeLabel:setVisible(false)
        elseif self.m_endTime > 0 and getTimeStamp() < self.m_endTime then
            self.ui.m_timeLabel:setVisible(true)
            self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(function(dt) self:refreshTime(dt) end, 1, false)
            self:refreshTime()
        else
            self.ui.m_timeLabel:setVisible(true)
            self:refreshTime()
        end

        if cellInfo.type == "ToolInfo" then
            -- ToolInfo C++
            self:updateToolInfo(cellInfo)
        elseif cellInfo.type == "GeneralInfo" then
            -- GeneralInfo C++
            self:updateGeneralSkill(cellInfo)
        elseif cellInfo.type == "SkillInfo" then
            -- NewHeroActiveSkillInfo
            self:updateHeroSkill(cellInfo)
        elseif cellInfo.type == "DragonSkillInfo" then
            -- DragonActiveSkillInfo
            self:updateDragonSkill(cellInfo)
        end

        -- 显示不全时截断，点击显示Tips
        local desSize = self.ui.m_desLabel:getContentSize()
        if desSize.height > 72 then
            -- 高度超过160的，设置最大高度，且增加触摸事件弹出信息
            self.ui.m_desLabel:setDimensions(400, 72)
            local touchTipView = Drequire("commonView.commonTouchTipsView").new({
                showName = self.ui.m_nameLabel:getString(),
                showContent = self.ui.m_desLabel:getString(),
                iconNode = self,
                touchSize = self:getContentSize(),
                -- desScale = CCCommonUtilsForLua:isIosAndroidPad() and 2 or 1,
            })
            self:addChild(touchTipView, -1)
        end
    end
end

function BattleViewActiveBuffCell:updateToolInfo(cellInfo)
    local toolInfo = cellInfo.info
    local name = toolInfo:call("getName")
    local des = getLang(toolInfo:getProperty("des"))
    self.ui.m_nameLabel:setString(name)
    self.ui.m_desLabel:setString(des)

    self.ui.m_picNode:removeAllChildren()
    CCCommonUtilsForLua:createGoodsIcon(toolInfo:getProperty("itemId"), self.ui.m_picNode, cc.size(80, 80))
end

function BattleViewActiveBuffCell:updateGeneralSkill(cellInfo)
    local generalInfo = cellInfo.info
    if generalInfo then
        local pic = CCCommonUtilsForLua:call("getPropById", cellInfo.data.skillId, "icon") .. ".png"
        if CCLoadSprite:call("getSF", pic) == nil then
            pic = "dragon_skill_1.png"
        end
        local icon = CCLoadSprite:call("createSprite", pic)
        self.ui.m_picNode:removeAllChildren()
        self.ui.m_picNode:addChild(icon)

        self.ui.m_nameLabel:setString(getLang(CCCommonUtilsForLua:call("getPropById", cellInfo.data.skillId, "name")))

        local desc = ""
        local dialog = CCCommonUtilsForLua:call("getPropById", cellInfo.data.skillId, "description")
        local base = CCCommonUtilsForLua:call("getPropById", cellInfo.data.skillId, "base")
        local type = math.tonumber(CCCommonUtilsForLua:call("getPropById", cellInfo.data.skillId, "type"))
        local cdinfo = GeneralManager:call("getSkillCDInfoById", cellInfo.data.skillId)

        if cdinfo then
            local skillType = cdinfo:getProperty("type")
            if skillType == Alliance_CiviSkill_Type then
                local civiBase = require("game.allianceTerritory.civiMiracle.CiviMiracleManager").getSkillCiviBase(self.selectedId)
                if civiBase then base = civiBase end
            end
        end
        if type == 12 or type == 13 or type == 15 then
            desc = getLang(dialog, base)
        elseif type == 14 then
            local ta = string.split(base, "|")
            if #ta == 2 then
                desc = getLang(dialog, ta[1], ta[2])
            end
        else
            local GeneralManagerIns = require("game.general.GeneralManagerIns").getInstance()
            local dis_value = GeneralManagerIns:getSkillDisvalueById(cellInfo.data.skillId)
            if dis_value then
                local descPercent = CCCommonUtilsForLua:call("getPropById",  cellInfo.data.skillId, "desc_num_percent")
                if descPercent == "1" then
                    dis_value = dis_value.."%"
                end
                desc = getLang(dialog, dis_value)
            else
                desc = getLang(dialog)
            end
        end
        self.ui.m_desLabel:setString(desc)
    end
end

function BattleViewActiveBuffCell:updateHeroSkill(cellInfo)
    local skillInfo = cellInfo.info
    if skillInfo ~= nil  then
        local pic = skillInfo:getIconStr()
        if CCLoadSprite:call("getSF", pic) == nil then
            pic = "dragon_skill_1.png"
        end
        local icon = CCLoadSprite:call("createSprite", pic)
        self.ui.m_picNode:removeAllChildren()
        self.ui.m_picNode:addChild(icon)

        self.ui.m_nameLabel:setString(getLang(CCCommonUtilsForLua:call("getPropById", cellInfo.data.skillId, "name")))

        local info = HeroManager.getActiveSkillInfoById(cellInfo.data.skillId)
        if nil == info then
            return
        end
        -- local title = info:getName()
        local desc = info:getDesStr()
        -- self.ui.m_desLabel:setString(getLang(CCCommonUtilsForLua:call("getPropById", cellInfo.data.skillId, "description")))
        self.ui.m_desLabel:setString(desc)
    end
end

function BattleViewActiveBuffCell:updateDragonSkill(cellInfo)
    local pic = CCCommonUtilsForLua:call("getPropById", cellInfo.data.skillId, "icon") .. ".png"
    if CCLoadSprite:call("getSF", pic) == nil then
        pic = "dragon_skill_1.png"
    end
    local icon = CCLoadSprite:call("createSprite", pic)
    self.ui.m_picNode:removeAllChildren()
    self.ui.m_picNode:addChild(icon)

    self.ui.m_nameLabel:setString(getLang(CCCommonUtilsForLua:call("getPropById", cellInfo.data.skillId, "name")))

    local desc = ""
    if DragonActiveSkillManagerNew.getInstance():isNewSkillType(cellInfo.data.skillId) then
        desc = DragonActiveSkillManagerNew.getInstance():getDescInBook(cellInfo.data.skillId)
    else
        local data = DragonActiveSkillManager.getInstance():getDataById(cellInfo.data.skillId)
        if nil == data then
            return
        end
        -- _title = data:getName()
        desc = data:getDescriptionByLevel(data:getLevel())
    end
    self.ui.m_desLabel:setString(desc)
end

function BattleViewActiveBuffCell:refreshTime(dt)
    local left_time = self.m_endTime - getTimeStamp()
    -- dump(left_time, "left_time")
    if left_time > 0 then
        self.ui.m_timeLabel:setString(getLang("105805", format_time(math.max(0, left_time))))
    else
        -- 停掉定时器
        if self.entry then 
            cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry) 
            self.entry = nil
        end
        
        CCSafeNotificationCenter:postNotification(MessageType.MSG_SEND_BATTLE_VIEW_BUFF_CMD)
    end
end

function BattleViewActiveBuffCell:onExit()
	-- 停掉定时器
    if self.entry then 
        cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry) 
        self.entry = nil
    end 
end

return BattleViewActiveBuffCell