-- @Author:fenghaibin 
-- @Date: 2020-10-20
-- @Description: 通用多级概率展示窗口

-- 传入data为一个table
-- 每个数据项params:
-- {
--      title = getLang(strId, ...),        --每级概率说明标题
--      rwdData = {...},                    --每级概率数据，来自通过getCachedRewardData函数rewardId为参数
-- }
--
-- 其中：
-- rwdData =
-- {
--     {"value":{"id":"36004400","num":"1","rate":"4"},"type":"7"},
--     {"value":{"id":"211929","num":"1","rate":"20"},"type":"7"},
-- }
-- 注：数据中的rate为后端传来的权重值,type为RewardTypeConfig中对应配置

local commonMultiLevelRateView = class("commonMultiLevelRateView", PopupBaseView)
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
function commonMultiLevelRateView:create(data)
    local view = commonMultiLevelRateView.new()
    utils.getExtendClass( "Template_ui" ):create(view,"MysteryBoxRwdListView.ccbi",0,viewSize,true,
        {"onOkBtnClick"})
    if view:initView(data) then
        return view
    end
end

function commonMultiLevelRateView:initView(data)
    self.m_data = data
    self:registerTouchFuncs()
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnOk, getLang("101274"))
    self:initTableView()
    self:refreshView(data)
	return true
end

function commonMultiLevelRateView:initTableView()
	TableViewSmoker:createView(self.ui, 
		"m_tableNode", 
		"game.CommonPopup.commonMultiLevelRate.commonMultiLevelRateCell", 
		cc.SCROLLVIEW_DIRECTION_VERTICAL, 
		3, "commonMultiLevelRateCell")
end

function commonMultiLevelRateView:refreshView(data)
    self:setTableViewDataSource("m_tableNode", data)
end

function commonMultiLevelRateView:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self.ui, tvName, data)
end

function commonMultiLevelRateView:cellSizeForTable(tab, idx)
    local width, height = 640, 100
    local item_data = self.m_data[idx+1] and self.m_data[idx+1].rwdData
    local itemNum = item_data and #item_data
    height = height + itemNum * 74
    return width, height
end

function commonMultiLevelRateView:closeSelf()
    PopupViewController:call("removePopupView", self)
end

function commonMultiLevelRateView:onTouchBegan(x, y)
    self.touchType = nil
    if not touchInside(self.ui.m_sprBG, x, y) then
        self.touchType = 1
    end
    return true
end

function commonMultiLevelRateView:onTouchMoved(x, y)
end

function commonMultiLevelRateView:onTouchEnded(x, y)
    if self.touchType == 1 and touchInside(self.ui.m_sprBG, x, y)==false then
        self:closeSelf()
    end
end

function commonMultiLevelRateView:onOkBtnClick()
    self:closeSelf()
end

return commonMultiLevelRateView