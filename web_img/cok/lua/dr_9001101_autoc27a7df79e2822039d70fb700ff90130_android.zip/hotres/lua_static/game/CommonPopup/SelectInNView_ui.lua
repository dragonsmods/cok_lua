----------------------------
-- Author: Elex
-- Date: 2017-06-12 17:46:59
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local SelectInNView_ui = class("SelectInNView_ui")

--#ui propertys


--#function
function SelectInNView_ui:create(owner, viewType)
	local ret = SelectInNView_ui.new()
	CustomUtility:LoadUi("SelectInNView.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function SelectInNView_ui:initLang()
end

function SelectInNView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function SelectInNView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function SelectInNView_ui:onOkButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onOkButtonClick", pSender, event)
end

return SelectInNView_ui

