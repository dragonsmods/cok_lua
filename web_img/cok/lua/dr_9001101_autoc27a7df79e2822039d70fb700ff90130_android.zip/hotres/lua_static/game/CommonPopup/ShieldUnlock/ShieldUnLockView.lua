ShieldUnLockView = class("ShieldUnLockView", function() return PopupBaseView:comFunc("create",0) end)
ShieldUnLockView.__index = ShieldUnLockView
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
function ShieldUnLockView:create()
    local ret = ShieldUnLockView.new()
    Drequire("game.CommonPopup.ShieldUnlock.ShieldUnLockView_ui"):create(ret, 1)
    if ret:initView() == nil then
        return nil
    else
    	return ret
    end 
end

function ShieldUnLockView:initView()
	self:initData()
	tableView = self.ui.m_pTableView1
	self.ui:setTableViewDataSource("m_pTableView1",self.info_table)
	local arr = GlobalData:call("getChatShieldArray")
	return true
end

function ShieldUnLockView:initData()
	self.info_table={}
	if GlobalData:call("isChatShieldGetInfo") == true then
		local arr = GlobalData:call("getChatShieldArray",0)
		self.table_size = self:numberOfCellsInTableView()
		if self.table_size >=1 then
			self.ui.m_labelTips:setVisible(false)
			self:getChatShieldInfo()
		else
			self.ui.m_labelTips:setVisible(true)
			self.ui.m_labelTips:setString(getLang("161044"))
		end    	
  	else
    	ChatController:call("sendChatLockInfoCommand")
  	end
end

function ShieldUnLockView:onEnter()
    local function funcClaimRet(dict)
        self:onClickUnBlockBtn(dict)
    end
    local handlerClaimRet = self:registerHandler(funcClaimRet)	
	CCSafeNotificationCenter:registerScriptObserver(self, handlerClaimRet, "Shield_onClickUnBlockBtnMessage")

	local function fresh( )
		self:initData()
		self.ui:setTableViewDataSource("m_pTableView1",self.info_table)
	end
	local handler = self:registerHandler(fresh)
	CCSafeNotificationCenter:registerScriptObserver(self,handler,"msg.ShieldUnLockView.refreshView")
end

function ShieldUnLockView:onExit()
	CCSafeNotificationCenter:unregisterScriptObserver(self, "Shield_onClickUnBlockBtnMessage")
	CCSafeNotificationCenter:unregisterScriptObserver(self,"msg.ShieldUnLockView.refreshView")
end

function ShieldUnLockView:onClickUnBlockBtn(dict)
	--local srcPos = self.ui.m_pTableView1:getContentOffset()
	self:initData()
	--因为点击取消屏蔽按钮发送消息以后，后台处理时间太慢，获取到的数组信息仍然是之前的，所以这里加一个数据处理，找到删除项，然后依次前移，重设数据
	local uuid = dict:objectForKey("uuid"):getCString()
	local index = 1
	for k,v in pairs(self.info_table or {}) do
		self.info_table[k] = self.info_table[index]
		if v.uuid == uuid then
			self.info_table[k] = self.info_table[k+1]
			index = index+1
		end
		if k == #self.info_table then
			self.info_table[k] = nil
		end
		index = index + 1
	end
	self.ui:setTableViewDataSource("m_pTableView1",self.info_table)
	if #self.info_table >= 1 then
		self.ui.m_labelTips:setVisible(false)
	else
		self.ui.m_labelTips:setVisible(true)
		self.ui.m_labelTips:setString(getLang("161044"))
	end
	--self.ui.m_pTableView1:reloadData()
	-- dump(srcPos,"hanxiao srcPos is")
	--self.ui.m_pTableView1:setContentOffset(srcPos)
end

function ShieldUnLockView:getChatShieldInfo()
	local arr = GlobalData:call("getChatShieldArray")
	for i=0,self.table_size-1 do
		local info = tolua.cast(arr:objectAtIndex(i),"ShieldInfo")
		self:setDataToTable(info)
	end
end

function ShieldUnLockView:setDataToTable(info)
	local temp_info = {}
	local dict = CCDictionary:create()
	local picStr = info:getProperty("pic")
  	if picStr == "" then
    	picStr = "g044"
  	end
  	picStr = picStr..".png"
	if picStr ~= nil then
		temp_info["picStr"] = picStr
	end
	local picVer = tonumber(info:getProperty("picVer"))
	local uid = tostring(info:getProperty("uid"))
	local uuid = info:getProperty("uuid")
	local power = tonumber(info:getProperty("power"))
  	local name = info:getProperty("name")
  	temp_info["picVer"] = picVer
	temp_info["uid"] = uid
	temp_info["uuid"] = uuid
	temp_info["power"] = power
	temp_info["name"] = name
	if temp_info ~= nil then
		self.info_table[#self.info_table+1] = temp_info
	end
end

function ShieldUnLockView:numberOfCellsInTableView()
	local num = GlobalData:call("getChatShieldArray"):count()
  	return num
end

return ShieldUnLockView