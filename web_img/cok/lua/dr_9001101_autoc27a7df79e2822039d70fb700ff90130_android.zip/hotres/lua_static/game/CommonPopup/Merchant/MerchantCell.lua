--@author: mm
--@date: 2016-11-14

MerchantCellLuaCell = MerchantCellLuaCell or {}
ccb["MerchantCellLuaCell"] = MerchantCellLuaCell

--前置声明
local ms_path = "game.CommonPopup.Merchant.MerchantShining"
-- package.loaded[ms_path] = nil
local MerchantShining = Drequire(ms_path)

-- local getLang = getLang
-- local ToolController = ToolController
-- local EquipmentController = EquipmentController
-- local SceneController = SceneController
-- local CCCommonUtilsForLua = CCCommonUtilsForLua
-- local CC_CMDITOA = CC_CMDITOA
-- local CCLoadSprite = CCLoadSprite
-- local WorldResourceType = WorldResourceType
-- local tostring = tostring
local isTouchInside = touchInside
--local math = math
local CC_ITOA = tostring
--local print = print
local loprint = function(...)
    -- print(...)
end

--C常量
local LEVEL_TIP = 5
local Music_Sfx_click_button = "ui_confirm"
local MSG_BUY_CONFIRM_OK = "buy.confirm.ok"
local MSG_MERCHANTE_REFRESH_ANIMATION_FINISH = "merchante.refresh.animation.finish"

--merchant枚举
local MerchantToolType = {
    MerchantTool_RESOURCE = 0,
    MerchantTool_GOODS = 1,
    MerchantTool_EQUIP = 2,
}

--类定义
local MerchantCell = class("MerchantCell",
    function()
        return cc.LayerColor:create() --cc.c4b(255,0,0,255)
    end
)

--fields
MerchantCell.ccbNode = nil
MerchantCell.m_touchNode = nil
MerchantCell.m_isClick = false
MerchantCell.m_info1 = nil -- MerchantToolInfo
MerchantCell.m_index = 0
MerchantCell.m_shiningNode = nil -- MerchantShining
MerchantCell.m_clickInSide = false
MerchantCell.m_num = 0
MerchantCell.m_startPoint = {} --table

MerchantCell.m_entry_setLeft = -1
MerchantCell.m_bBuy = false
MerchantCell.m_bIsBuying = false
MerchantCell.m_bRefreshClick = false


--functions
function MerchantCell:create(index, touchNode)
    local cell = MerchantCell.new()
    if not cell:initView(index, touchNode) then
        return nil
    end
    return cell
end

function MerchantCell:initView(index, touchNode)
    local proxy = cc.CCBProxy:create()
    local ccbiURL = "MerchantCell_Lua.ccbi"
    local nodeccb = CCBReaderLoad(ccbiURL, proxy, self)
    if nodeccb == nil then
        print("MerchantCell loadccb error")
        return false
    end

    self.am = ccb["MerchantCellLuaCell"]["mAnimationManager"]
    self.ccbNode = nodeccb
    self:addChild(nodeccb)
    self:setContentSize(cc.size(606, 170))
    self:ignoreAnchorPointForPosition(true)

    self.m_lblSuper:setString(getLang("104933"))
    self.m_superNode:setVisible(false)
    self.m_touchNode = touchNode
    self:setDataIndex(index) --这就是self.m_index = index，很坑
    self:setData()
    self:animationCallback()

    local function onNodeEvent(event)
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(onNodeEvent)

    --触控系列
    local function onTouch(eventType, x, y)  
        if eventType == "began" then
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)  
        else  
            return self:onTouchEnded(x, y)  
        end
    end

    self:registerScriptTouchHandler(onTouch)

    return true
end

function MerchantCell:setData()
    self.m_isClick=false;
    self.m_costNode1:removeAllChildren()

    local tc = ToolController:call("getInstance")
    local miVec = tc:getProperty("m_toolMerchantInfos") --property is a table
    loprint("MerchantCell miVec | type=", type(miVec), ", value=", miVec, ", length=", #miVec, ", self.mindex=", self.m_index)

    -- for k, v in pairs(miVec) do
    --     if tonumber(k) == tonumber(self.m_index) then
    --         self.m_info1 = miVec[tonumber(self.m_index)]
    --     end
    --     loprint("miVec elements | k=", k, ", v=", v)
    -- end
    self.m_info1 = miVec[tonumber(self.m_index + 1)] --m_index还是0的索引，但是table是从1开始的！
    loprint("MerchantCell m_info1 type=", type(self.m_info1), " value=", self.m_info1)    

    self.m_desNode:setVisible(false)
    self.m_priceLabel1:setColor(cc.c3b(255,255,0))
    self.m_buyBtngraySpr1:setVisible(false)
    self.m_superNode:setVisible(false)
    self.m_picNode1:removeAllChildren()

    local showOldPrice = 0

    local mi_type = self.m_info1:getProperty("type")
    local mi_itemId = self.m_info1:getProperty("itemId")
    local mi_itemNum = self.m_info1:getProperty("itemNum")
    local mi_priceHot = self.m_info1:getProperty("priceHot")
    local mi_priceType = self.m_info1:getProperty("priceType")
    local mi_price = self.m_info1:getProperty("price")
    local mi_num = self.m_info1:getProperty("num")
    local mi_color = self.m_info1:getProperty("color")

-- //    if(m_info1->itemId < WorldResource_Max){
    if (mi_type == MerchantToolType.MerchantTool_RESOURCE) then
        self.m_nameLabel1:setString(CCCommonUtilsForLua:call("getResourceNameByType", mi_itemId) .. " ×" .. CC_CMDITOA(mi_itemNum))

        local pic = CCLoadSprite:call( "createSprite", CCCommonUtilsForLua:call("getResourceIconByType", mi_itemId) )
        -- loprint("MerchantCell: mi_itemId=", mi_itemId, " pic_res=", pic)
        if (pic) then
            local iconBg = CCLoadSprite:call( "createSprite", CCCommonUtilsForLua:call("getToolBgByColor", 0) ); --0=WHITE
            CCCommonUtilsForLua:call("setSpriteMaxSize", iconBg, 92, true)
            self.m_picNode1:addChild(iconBg);
            CCCommonUtilsForLua:call("setSpriteMaxSize", pic, 70, true)
            self.m_picNode1:addChild(pic);
        end
        showOldPrice = mi_priceHot

    elseif (mi_type == MerchantToolType.MerchantTool_GOODS) then
        local info = tc:call("getToolInfoByIdForLua", mi_itemId) --ToolInfo
        local info_name = info:call("getName")
        local info_itemId = info:getProperty("itemId")
        local info_price_hot = info:getProperty("price_hot")

        self.m_nameLabel1:setString(info_name .. " ×" .. CC_CMDITOA(mi_itemNum))
        CCCommonUtilsForLua:call("createGoodsIcon", info_itemId, self.m_picNode1, cc.size(92, 92))
--         //test code
-- //        m_info1->priceType = info.itemId;
--         //is hot
        if (mi_priceHot > 0) then
            showOldPrice = mi_priceHot
        else
            if (info_price_hot > 0 and mi_priceType == WorldResourceType.Gold) then
                showOldPrice = info_price_hot * mi_itemNum
            end
        end
    elseif (mi_type == MerchantToolType.MerchantTool_EQUIP) then
-- //        auto& eInfo = EquipmentController::getInstance()->EquipmentInfoMap[m_info1->itemId];
        local eInfo = EquipmentController:call("getInstance"):call("getEquipInfoById", mi_itemId) --EquipmentInfo
        if not eInfo then
            return
        end

        local ei_name = eInfo:call("getName")
        local ei_color = eInfo:call("getColor")

        local ename = getLang(ei_name) .. " ×" .. CC_CMDITOA(mi_itemNum)
        self.m_nameLabel1:setString(ename)
        local ebgPath = CCCommonUtilsForLua:call("getToolBgByColor", ei_color)

        local ebgIcon = CCLoadSprite:call("createSprite", ebgPath) -- Sprite
        CCCommonUtilsForLua:call("setSpriteMaxSize", ebgIcon, 92, true)
        self.m_picNode1:addChild(ebgIcon)
        local epicStr = CCCommonUtilsForLua:call("getIcon", tostring(mi_itemId))
        local eicon = CCLoadSprite:call("createSprite", epicStr, CCLoadSpriteType.CCLoadSpriteType_EQUIP)
        CCCommonUtilsForLua:call("setSpriteMaxSize", eicon, 87, true)
        self.m_picNode1:addChild(eicon)
        self.m_priceLabel1:setPositionY(self.m_costNode1:getPositionY())
        self.m_hotLineSpr1:setVisible(false)
        self.m_hotpriceLabel1:setVisible(false)
        showOldPrice = mi_priceHot
    end
    
    if (showOldPrice > 0) then
        self.m_priceLabel1:setPositionY(-self.m_hotpriceLabel1:getPositionY())
        self.m_hotpriceLabel1:setString(CC_ITOA_K(tonumber(showOldPrice)))
        self.m_hotLineSpr1:setVisible(true)
        self.m_hotpriceLabel1:setVisible(true)
    else
        self.m_priceLabel1:setPositionY(self.m_costNode1:getPositionY())
        self.m_hotLineSpr1:setVisible(false)
        self.m_hotpriceLabel1:setVisible(false)
    end

    if (mi_priceType < WorldResourceType.WorldResource_Max) then
        local str = CCCommonUtilsForLua:call("getResourceIconByType", mi_priceType)
        local costIcon = CCLoadSprite:call("createSprite", str)
        if(costIcon) then
            costIcon:setTag(100);
            self.m_costNode1:addChild(costIcon)
        end
    else
        local priceNode = CCNode:create()
        local priceSpr = CCLoadSprite:call("createSprite", "Items_icon_kuang2.png")
        priceNode:addChild(priceSpr)
        priceSpr:setScale(0.4)
        local priceSize = priceSpr:getContentSize()
        CCCommonUtilsForLua:call("createGoodsIcon", mi_priceType, priceNode, cc.size(35, 35))
        self.m_costNode1:addChild(priceNode)
    end
    
    self.m_priceLabel1:setString(CC_ITOA_K(tonumber(mi_price)));
    self:setLeftHot(false, mi_num)

    if (mi_color < 2 and self.m_shiningNode ~= nil) then
        self.m_shiningNode:removeAllChildren()
        self.m_shiningNode = nil
    elseif (mi_color > 1) then
        local color = {} --table
        local alpha --float
        local showEff --bool
        local mbt = tc:getProperty("merchantBestTool") --MerchantToolInfo
        local mbt_itemId = mbt:getProperty("itemId")
        local mbt_itemNum = mbt:getProperty("itemNum")
        local mbt_color = mbt:getProperty("color")

        if (mi_itemId == mbt_itemId and mi_itemNum == mbt_itemNum and mi_color == mbt_color) then
            color = cc.c3b(251, 183, 40)
            alpha = 255
            showEff = true
            self.m_superNode:setVisible(true)
        else
            if (1 == mi_color) then
                color = cc.c3b(93,219,68)
                alpha = 153
                showEff = false
            elseif (2 == mi_color) then
                color = cc.c3b(59,172,224)
                alpha = 204
                showEff = false
            else
                color = cc.c3b(138,62,251)
                alpha = 255
                showEff = true
                self.m_superNode:setVisible(true)
            end
        end

        if not self.m_shiningNode then
            local size = self:getContentSize()
            size.width = size.width + 30
            size.height = size.height + 40

            if ( CCCommonUtilsForLua:call("isIosAndroidPad") ) then
                size.width = size.width - 40
            end

            self.m_shiningNode = MerchantShining:create(color, size)
            self:addChild(self.m_shiningNode)
            self.m_shiningNode:setPosition(cc.p(size.width*0.5, size.height*0.5 - 18))
            self.m_shiningNode:setPositionX(318)
        else
            self.m_shiningNode:setShineColor(color)
        end

        loprint("MerchantCell:setData | m_shiningNode=", self.m_shiningNode, ", alpha=", alpha, " ,showEff=", showEff)
        self.m_shiningNode:setShineAlpha(alpha)
        self.m_shiningNode:showEff2(showEff)
-- //        m_shiningNode->startPlay(false);
-- //        m_shiningNode->setVisible(false);
    end
end

function MerchantCell:onEnter()
    -- self.super:onEnter()
    self:setTouchEnabled(true)
    self:setSwallowsTouches(false)
    -- self:setTouchMode(cc.TOUCHES_ONE_BY_ONE)
    -- //CCDirector::sharedDirector()->getTouchDispatcher()->addTargetedDelegate(this, Touch_Default, false);
    local tc = ToolController:call("getInstance")
    tc:setProperty("m_merchantCurrIndex", 0)
end

function MerchantCell:onExit()
    self:setTouchEnabled(false)
    -- self.super:onExit()
end


function MerchantCell:onTouchBegan(x, y)
    loprint("MerchantCell:onTouchBegan | x=",x,",y=",y)
    self.m_clickInSide = false
    self.m_num = 0
    if (isTouchInside(self.m_touchNode,x, y)) then
        self.m_clickInSide = true
        if (isTouchInside(self, x, y)) then
            self.m_startPoint = {["x"] = x, ["y"] = y}
            if (isTouchInside(self.m_picBG1, x, y)) then
-- //                this->schedule(schedule_selector(MerchantCell::setLeft),0.2);
                self:setLeft(0)
            elseif(isTouchInside(self.m_buyBtnSpr1, x, y)) then
                local mi_num = self.m_info1:getProperty("num")
                if (mi_num <= 0) then
                    return false
                else
                    self.m_buyBtnSpr1:setScale(1.2)
                end
            end
            return true
        end
    end
    return false
end

function MerchantCell:onTouchMoved(x, y)
    --
end

function MerchantCell:onTouchEnded(x, y)
    loprint("MerchantCell:onTouchEnded | x=",x,",y=",y)
    self.m_buyBtnSpr1:setScale(1.0)
    self.m_desNode:setVisible(false)

    if (self.m_entry_setLeft ~= -1) then
        self:getScheduler():unscheduleScriptEntry(self.m_entry_setLeft)
        self.m_entry_setLeft = -1
    end
    -- loprint("MerchantCell:onTouchEnded | p2")

    if (math.abs(x-self.m_startPoint.x) > 10 or math.abs(y-self.m_startPoint.y) > 10) then
        return
    end

    -- loprint("MerchantCell:onTouchEnded | p3")

    if (isTouchInside(self.m_buyBtnSpr1, x, y)) then
        -- loprint("MerchantCell:onTouchEnded | click")
        self:onClickBuyBtn1(nil, cc.Handler.CONTROL_TOUCH_DOWN)
    end

    -- loprint("MerchantCell:onTouchEnded | p4")

    local layer = SceneController:call("getInstance"):call("getCurrentLayerByLevel", LEVEL_TIP) --CCLayer
    layer:removeAllChildren()
end

function MerchantCell:setLeft(dt) --dt:float
    if (self.m_entry_setLeft ~= -1) then
        self:getScheduler():unscheduleScriptEntry(self.m_entry_setLeft)
        self.m_entry_setLeft = -1
    end
    self:setDesNode(self.m_info1, 0)
end

function MerchantCell:setDataIndex(index)
    self.m_index = index
end

function MerchantCell:setDesNode(minfo, index) --MerchantToolInfo, int
-- //    if(minfo->itemId<WorldResource_Max)
    local mi_type = self.m_info1:getProperty("type")
    if (mi_type == MerchantToolType.MerchantTool_RESOURCE) then
        return
    end

    local mi_itemId = self.m_info1:getProperty("itemId")
    local tc = ToolController:call("getInstance")

    self.m_desNode:setVisible(true)
    self.m_desNode:setPositionX(290)
    if (mi_type == MerchantToolType.MerchantTool_GOODS) then
        local info = tc:call("getToolInfoByIdForLua", minfo:getProperty("itemId")) --ToolInfo
        local info_type = info:getProperty("type") --int
        local info_para = info:call("getPara") --string
        local info_name = info:call("getName") --string

        if (info_type == 5 and string.len(info_para) > 0) then
            self.m_desNode:setVisible(false)
            local layer = SceneController:call("getInstance"):call("getCurrentLayerByLevel", LEVEL_TIP) --CCLayer
            if (layer:getChildrenCount() <= 0) then
                local tip = StoreMallCellTip:call("create", info_para, info_name)
                layer:addChild(tip)
                local x = self.m_startPoint.x; --float
                if (index == 1) then
                    x = 100
                end
                tip:setPosition(x, self.m_startPoint.y)
            end
        else
            self.m_desName:setString(info_name)
            local info_des = info:getProperty("des")
            self.m_desLabel:setString(getLang(info_des))
        end
    elseif (mi_type == MerchantToolType.MerchantTool_EQUIP) then
-- //        auto& eInfo = EquipmentController::getInstance()->EquipmentInfoMap[m_info1->itemId];
        local eInfo = EquipmentController:call("getInstance"):call("getEquipInfoById", mi_itemId) --EquipmentInfo
        if (eInfo) then
            local ename = getLang(eInfo:call("getName"))
            self.m_desName:setString(ename)
            self.m_desLabel:setString( getLang(eInfo:call("getDes")) )
        end
    end
end


function MerchantCell:onClickBuyBtn1(pSender, pCCControlEvent) --CCObject, Control::EventType
    -- if ( tc:call("getMerchante_animation") ) then
    --     return
    -- end

    loprint("MerchantCell:onClickBuyBtn1 m_clickInSide=", self.m_clickInSide, ", m_isClick=", m_isClick)
    
    if not self.m_clickInSide then
        return
    end

    if (self.m_isClick) then
        return
    end

    SoundController:call("sharedSound"):call("playEffects", Music_Sfx_click_button)
    local tc = ToolController:call("getInstance")

    self.m_isClick = true;
    self.m_bBuy = false;

    local mi_type = self.m_info1:getProperty("type")
    local mi_itemId = self.m_info1:getProperty("itemId")
    local mi_itemNum = self.m_info1:getProperty("itemNum")
    local mi_priceHot = self.m_info1:getProperty("priceHot")
    local mi_priceType = self.m_info1:getProperty("priceType")
    local mi_price = self.m_info1:getProperty("price")
    local mi_num = self.m_info1:getProperty("num")
    local mi_color = self.m_info1:getProperty("color")

    local dialog  = nil --StoreBuyConfirmDialog

    function luafunc()
        self:onBuyTool1(nil)
    end 
    local cafunc = cc.CallFunc:create(luafunc)

-- //    if(m_info1->itemId<WorldResource_Max){
    if (mi_type == MerchantToolType.MerchantTool_RESOURCE) then
        loprint("MerchantCell:onClickBuyBtn1 | dialog 1")

        dialog = StoreBuyConfirmDialog:call("showForLua", CCCommonUtilsForLua:call("getResourceIconByType", mi_itemId), self.m_nameLabel1:getString(), "", mi_price, -1, cafunc, self.m_picBG1:convertToWorldSpace(cc.p(0,0)), mi_priceType)

    elseif (mi_type == MerchantToolType.MerchantTool_GOODS) then
        loprint("MerchantCell:onClickBuyBtn1 | dialog 2")

        local info = tc:call("getToolInfoByIdForLua", mi_itemId) --ToolInfo
        local info_itemId = info:getProperty("itemId")
        local info_des = info:getProperty("des")
        local info_color = info:getProperty("color")

        dialog = StoreBuyConfirmDialog:call("showForLua", CCCommonUtilsForLua:call("getIcon", CC_ITOA(info_itemId)), self.m_nameLabel1:getString(), getLang(info_des), mi_price, info_color, cafunc, self.m_picBG1:convertToWorldSpace(cc.p(0,0)), mi_priceType)

    elseif (mi_type == MerchantToolType.MerchantTool_EQUIP) then
        loprint("MerchantCell:onClickBuyBtn1 | dialog 3")
-- //        auto& eInfo = EquipmentController::getInstance()->EquipmentInfoMap[m_info1->itemId];
        local eInfo = EquipmentController:call("getInstance"):call("getEquipInfoById", mi_itemId) --EquipmentInfo

        if (eInfo) then
            dialog = StoreBuyConfirmDialog:call("showForLua", CCCommonUtilsForLua:call("getIcon", CC_ITOA(eInfo:call("getEquipId"))), self.m_nameLabel1:getString(), getLang(eInfo:call("getDes")), mi_price, eInfo:call("getColor"), cafunc, self.m_picBG1:convertToWorldSpace(cc.p(0,0)), mi_priceType)
        end
    end
    
    if(dialog) then
        local luafunc_cb = function ()
            self:onCloseConfirm()
        end 
        local cafunc_cb = cc.CallFunc:create(luafunc_cb)
        loprint("MerchantCell:onClickBuyBtn1 | set dialog callback")
        dialog:call("setCloseCallback", cafunc_cb)
        dialog:call("setYesCallback", cafunc)
    end
end

function MerchantCell:onBuyTool1(ccObj)
    loprint("MerchantCell:onBuyTool1(ccObj) p1")
    if (self.m_bIsBuying) then
        return
    end

    self.m_bIsBuying = true
    local tc = ToolController:call("getInstance")
    -- local mcIndex = tc:getProperty("m_merchantCurrIndex")
    tc:setProperty("m_merchantCurrIndex", self.m_index + 1)

    local mi_itemId = self.m_info1:getProperty("itemId")
    local mi_itemNum = self.m_info1:getProperty("itemNum")
    local mi_priceType = self.m_info1:getProperty("priceType")
    local mi_price = self.m_info1:getProperty("price")

    local luafunc = function ()
        self:onRetBuyTool()
    end 
    local cafunc = cc.CallFunc:create(luafunc)

    tc:call("buyMerchantTool", CC_ITOA(mi_itemId), mi_itemNum, mi_price, mi_priceType, cafunc)
end

function MerchantCell:onRetBuyTool()
-- //    setLeftHot(false,m_info1->num);
    self.m_bBuy = true
    local tc = ToolController:call("getInstance")
    tc:setProperty("m_merchantCurrIndex", 0)
    CCSafeNotificationCenter:call("postNotification", MSG_BUY_CONFIRM_OK)
end

function MerchantCell:onCloseConfirm()
    self.m_isClick=false;
    if (self.m_bBuy == true) then
        self:playAnimation()
        self.m_bBuy=false
    else
        self:setData()
        self:animationCallback()
    end
    self.m_bIsBuying=false
end

function MerchantCell:changeData()
    loprint("MerchantCell:changeData()")
    self:setData()
end

function MerchantCell:playAnimation(bRefersh) --bool
    self.m_bRefreshClick = bRefersh
    if (self.m_shiningNode) then
        self.m_shiningNode:startPlay(false)
        self.m_shiningNode:setVisible(true)
    end

    local onPlayEnd = function ()
        self:animationCallback()
    end
    -- local callfunc = cc.CallFunc:create(onPlayEnd) --这里为何不使用callfunc呢。
    self.am:setAnimationCompletedCallback(onPlayEnd)
    self.am:runAnimationsForSequenceNamed("1")

    local delay = cc.DelayTime:create(0.5)
    local luafunc = function ()
        self:changeData()
    end 
    local cfunc = cc.CallFunc:create(luafunc)
    local seqAction = cc.Sequence:create(delay, cfunc)
    self:runAction(seqAction)
end

function MerchantCell:animationCallback()
    self.am:runAnimationsForSequenceNamed("0")

    if (self.m_shiningNode ~= nil) then
        self.m_shiningNode:setVisible(true)
        self.m_shiningNode:startPlay(true)

        loprint("MerchantCell:animationCallback m_shiningNode=", self.m_shiningNode, ", shiningVis=", self.m_shiningNode:isVisible())
    end

    if (self.m_bRefreshClick == true) then
        self.m_bRefreshClick = false
    end

    CCSafeNotificationCenter:call("postNotification", MSG_MERCHANTE_REFRESH_ANIMATION_FINISH)
end

function MerchantCell:setLeftHot(ishot, num) --bool/int C里面已经全注释，这里保留下备份。
-- //    if(ishot){
-- //        if(num>0){
-- //            m_hotgraySpr1->setVisible(false);
-- //            m_hotSpr1->setVisible(true);
-- //        }else{
-- //            m_hotgraySpr1->setVisible(true);
-- //            m_hotSpr1->setVisible(false);
-- //        }
-- //        m_hotdesText1->setString(_lang("101224"));
-- //        m_itemHotNode1->setVisible(true);
-- //    }else{
-- //        m_itemHotNode1->setVisible(false);
-- //    }
-- //    m_hotNum1Text->setString(CC_CMDITOA(num));
-- //    if(num>0){
-- //        m_buyBtngraySpr1->setVisible(false);
-- //        m_buyBtnSpr1->setVisible(true);
-- //        m_saleoutSpr1->setVisible(false);
-- //        m_hotNumSpr1->setVisible(true);
-- //        m_hotNumgraySpr1->setVisible(false);
-- //        m_nameLabel1->setColor(ccc3(194, 158, 116));
-- //        m_priceLabel1->setColor(ccc3(255,255,0));
-- //        m_hotpriceLabel1->setColor(ccc3(221,172,33));
-- //    }else{
-- //        m_buyBtngraySpr1->setVisible(true);
-- //        m_buyBtnSpr1->setVisible(false);
-- //        m_saleoutSpr1->setVisible(true);
-- //        m_hotNumSpr1->setVisible(false);
-- //        m_hotNumgraySpr1->setVisible(true);
-- //        m_nameLabel1->setColor(ccc3(156,156,156));
-- //        m_priceLabel1->setColor(ccc3(156,156,156));
-- //        m_hotpriceLabel1->setColor(ccc3(156,156,156));
-- //        auto pic = dynamic_cast<CCSprite*>(m_picNode1->getChildByTag(99));
-- //        if(pic){
-- //            pic->setColor(ccc3(90,85,81));
-- //        }
-- //        auto pic1 = dynamic_cast<CCSprite*>(m_picNode1->getChildByTag(100));
-- //        if(pic1){
-- //            pic1->setColor(ccc3(90,85,81));
-- //        }
-- //        CCSprite* costPic = dynamic_cast<CCSprite*>(m_costNode1->getChildByTag(100));
-- //        if(costPic){
-- //            costPic->setColor(ccc3(90,85,81));
-- //        }
-- //    }
end



return MerchantCell