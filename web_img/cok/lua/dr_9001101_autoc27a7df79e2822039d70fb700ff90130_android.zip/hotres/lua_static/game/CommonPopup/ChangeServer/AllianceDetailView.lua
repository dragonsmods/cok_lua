local AllianceDetailView = class("AllianceDetailView", PopupBaseView)

local itemDataId = 211094

local feature2color = {
    ["173216"] = cc.c3b(44, 61, 41),
    ["173217"] = cc.c3b(61, 53, 41),
    ["173218"] = cc.c3b(61, 39, 55),
    ["173219"] = cc.c3b(40, 51, 61),
}

function AllianceDetailView:create(info, applyCb)
    local view = AllianceDetailView.new(info, applyCb)
    Drequire("game.CommonPopup.ChangeServer.AllianceDetailView_ui"):create(view, 0)
    view:initView()
    return view
end

function AllianceDetailView:ctor(info, applyCb)
    self.info = info
    self.applyCb = applyCb
    self.meetCondition = true
end

function AllianceDetailView:initView()
    local viewSize = self.ui.m_listNode:getContentSize()
    self.scrollView = CCScrollView:create(viewSize)
    self.scrollView:setDirection(kCCScrollViewDirectionVertical)
    self.ui.m_listNode:addChild(self.scrollView)
    
    local contentSize = self.ui.m_detailNode:getContentSize()
    self.ui.m_detailNode:removeFromParent()
    self.ui.m_detailNode:setVisible(true)
    self.scrollView:addChild(self.ui.m_detailNode)
    self.scrollView:setContentOffset(ccp(0, viewSize.height - contentSize.height))
    self.scrollView:setContentSize(contentSize)

    CCCommonUtilsForLua:setButtonTitle(self.ui.m_joinBtn, getLang("173235"))

    self.ui.m_titleTxt:setString(getLang("102271"))

    local name = self.info.abbr .. "(" .. self.info.name .. ")"
    self.ui.m_nameTxt:setString(name)
    self.ui.m_leaderTxt:setString(getLang("115015", self.info.leader))
    self.ui.m_powerTxt:setString(CC_CMDITOA(self.info.alliancePower or 88888888))
    self.ui.m_membersTxt:setString("(" .. self.info.cur .. "/" .. self.info.max .. ")")
    self.ui.m_language:setString(getLang(self.info.lan))

    local flag = AllianceFlagPar:call("create", self.info.icon .. ".png")
    self.ui.m_flagNode:removeAllChildren()
    self.ui.m_flagNode:addChild(flag)

    self.ui.m_serverTxt:setString(getLang("173237"))
    self.ui.m_activeTxt:setString(getLang("173281"))
    self.ui.m_rankTxt:setString(getLang("173282"))
    self.ui.m_preferTxt:setString(getLang("173202"))
    self.ui.m_requireTxt:setString(getLang("173205"))
    self.ui.m_recruitTxt:setString(getLang("173203"))
    self.ui.m_announceTxt:setString(getLang("173210"))
    self.ui.m_itemTxt:setString(getLang("173289"))
    self.ui.m_featureTxt:setString(getLang("173214"))

    self.ui.m_serverNum:setString(self.info.serverId)
    self.ui.m_activeNum:setString(self.info.activeMem)
    local rankName = require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance():getRankName(self.info.rank)
    self.ui.m_rankNum:setString(rankName)
    self.ui.m_preferTxt1:setString(getLang(self.info.prefer))
    self.ui.m_recruitNumTxt:setString("(" .. self.info.rCur .. "/" .. self.info.rMax .. ")")
    self.ui.m_announceTxt1:setString(getLang(self.info.announce))

    --活跃度判断
    if atoi(self.info.activeMem) >= 30 then
        self.ui.m_pSalesBarActive:setScaleX(0.8)
        self.ui.m_activeDesc:setString(getLang("173283"))
    elseif atoi(self.info.activeMem) >= 15 then
        self.ui.m_pSalesBarActive:setScaleX(0.5)
        self.ui.m_activeDesc:setString(getLang("173287"))
    elseif atoi(self.info.activeMem) >= 1 then
        self.ui.m_pSalesBarActive:setScaleX(0.3)
        self.ui.m_activeDesc:setString(getLang("173288"))
    else
        self.ui.m_pSalesBarActive:setScaleX(0)
        self.ui.m_activeDesc:setString(getLang("173288"))
    end

    --联盟排行判断
    if atoi(self.info.rank) <= 10 then
        self.ui.m_pSalesBarRank:setScaleX(0.8)
        self.ui.m_rankDesc:setString(getLang("173286"))
    elseif atoi(self.info.rank) <= 50 then
        self.ui.m_pSalesBarRank:setScaleX(0.5)
        self.ui.m_rankDesc:setString(getLang("173287"))
    else
        self.ui.m_pSalesBarRank:setScaleX(0.3)
        self.ui.m_rankDesc:setString(getLang("173288"))
    end

    local color = require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance():getHotColor(self.info.serverState or 3)
    local redDot = CCLoadSprite:createSprite("mail_unread_Icon.png")
    redDot:setScale(0.5)
    self.ui.m_hotNode:removeAllChildren()
    self.ui.m_hotNode:addChild(redDot)

    local features = splitString(self.info.feature, ";")
    for index, feature in ipairs(features) do
        if self.ui["m_feature" .. index .. "Txt"] then
            self.ui["m_feature" .. index .. "Txt"]:setString(getLang(feature))
        end

        if self.ui["m_feature" .. index .. "Bg"] then
            self.ui["m_feature" .. index .. "Bg"]:setColor(feature2color[feature])
        end
    end

    local tinfo = ToolController:call("getToolInfoForLua", itemDataId)
    if tinfo then
        local cnt = tinfo:call("getCNT")
        self.ui.m_itemTxt1:setString(cnt .. "/" .. self.info.item)
        if cnt < atoi(self.info.item) then 
            self.itemNotSatisfy = true 
            if self.info.state == "0" or self.info.state == "3" then
                self.ui.m_itemTxt2:setString(getLang("173257"))
            end
        end
    end

    local playerInfo = GlobalData:call("getPlayerInfo")
    local mainCityLv = FunBuildController:call("getMainCityLv") + FunBuildController:call("getMainCityHonorLv") 
    self.ui.m_require1Txt:setString(getLang("173274", self.info.city))
    if mainCityLv < atoi(self.info.city) then 
        self.ui.m_require1Bg:setColor(cc.c3b(53, 53, 53))
        self.ui.m_require1Sp:setVisible(false)
        self.cityNotSatisfy = true
    else
        self.ui.m_require1Bg:setColor(cc.c3b(44, 61, 40))
        self.ui.m_require1Sp:setVisible(true)
    end

    local suit = false
    --三选一
    if self.info.power then
        self.ui.m_require2Txt:setString(getLang("173275", CC_ITOA_K(atoi(self.info.power))))
        local power = playerInfo:call("getTotalPower")
        if atoi(self.info.power) <= power then 
            suit = true
        else 
            self.powerNotSatisfy = true
        end 
    elseif self.info.active then
        self.ui.m_require2Txt:setString(getLang("173277", getLang(self.info.active)))
        local active = require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance():getActive()
        if atoi(active) <= atoi(self.info.active) then 
            suit = true
        else 
            self.activeNotSatisfy = true
        end
    elseif self.info.kill then
        local armyKill = playerInfo:getProperty("armyKill")
        if atoi(self.info.kill) <= armyKill then 
            suit = true
        else 
            self.killNotSatisfy = true
        end
        self.ui.m_require2Txt:setString(getLang("173276", CC_ITOA_K(atoi(self.info.kill))))
    end

    if suit then
        self.ui.m_require2Bg:setColor(cc.c3b(44, 61, 40))
        self.ui.m_require2Sp:setVisible(true)
    else
        self.ui.m_require2Bg:setColor(cc.c3b(53, 53, 53))
        self.ui.m_require2Sp:setVisible(false)
        self.meetCondition = false
    end

    --已经申请
    -- local hadApply = (self.info.state == "1")
    -- self.ui.m_joinBtn:setEnabled(self.meetCondition or hadApply)
    self.ui.m_joinBtn:setEnabled(true)

    local info = "<s 18><c dededeff>" .. getLang("173220") .. "  <c ecdcaaff> " .. self.info.description
    local size = self.ui.m_descNode:getContentSize()
	local richText = IFHyperlinkText:call("create", info, cc.size(size.width, 0), false, false)
    richText:setAnchorPoint(ccp(0, 1))
    richText:setPosition(0, size.height)
    richText:ignoreAnchorPointForPosition(false)
    self.ui.m_descNode:removeAllChildren()
    self.ui.m_descNode:addChild(richText)
end

function AllianceDetailView:onEnter()
    UIComponent:call("showPopupView", 1)
    registerScriptObserver(self, self.applySuccess, "AllianceDetailView:applySuccess")
end

function AllianceDetailView:onExit()
    unregisterScriptObserver(self, "AllianceDetailView:applySuccess")
end

function AllianceDetailView:onClickBtnTip()
    FaqHelper:call("showSingleFAQ", "45281")
end

function AllianceDetailView:getNotSatisfyTip()
    local notSatisfyTip = ""
    if self.itemNotSatisfy then notSatisfyTip = "173310" end
    if self.cityNotSatisfy then notSatisfyTip = "173306" end
    if self.powerNotSatisfy then notSatisfyTip = "173305" end
    if self.activeNotSatisfy then notSatisfyTip = "173307" end
    if self.killNotSatisfy then notSatisfyTip = "173319" end
    return notSatisfyTip
end

function AllianceDetailView:onClickJoin()
    --未申请
    if self.info.state == "0" or self.info.state == "3" then
        local notSatisfyTip = self:getNotSatisfyTip()
        if notSatisfyTip ~= "" then
            CCCommonUtilsForLua:call("flyHint", "", "", getLang(notSatisfyTip))
            return 
        end

        GameController:call("showWaitInterface1", self.m_joinBtn)
        require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance():transferApply(self.info.allianceId)
         
    else
        self:openChat()
    end
end

function AllianceDetailView:applySuccess()
    --已申请 移到
    self.info.state = "1"
    if self.applyCb then self.applyCb(self.info) end
    self:openChat()
end

function AllianceDetailView:openChat()
    --创建聊天室
    local attribute = self:getPlayerAttribute()
    local json = require("CommonLib.dkjson")
    local attributeJsonStr = json.encode(attribute)

    local dict = CCDictionary:create()
    self.info.leadersList = string.gsub(self.info.leadersList, ";", ",")
    dict:setObject(CCString:create(self.info.leadersList), "memberUids")
    dict:setObject(CCString:create(self.info.allianceId), "allianceId")
    dict:setObject(CCString:create(attributeJsonStr), "attributeJsonStr")
    dict:setObject(CCString:create("createJoinServiceGroupChat"), "name")
    LuaController:call("openPopViewInLua", dict)
end

function AllianceDetailView:getPlayerAttribute()
    local xmlData = CCCommonUtilsForLua:getGroupByKey("talent_lorddetails")
    local playerInfo = GlobalData:call("getPlayerInfo")
    local attribute = {}
    for k, v in ipairs4ScatteredT(xmlData) do
        local name = CCCommonUtilsForLua:call("getPropByIdGroup", "lordDetails", v.lordId, "name")
        local effect = CCCommonUtilsForLua:call("getPropByIdGroup", "lordDetails", v.lordId, "effect")
        local defaultShow = CCCommonUtilsForLua:call("getPropByIdGroup", "lordDetails", v.lordId, "defaultShow")
        local isFromServer = CCCommonUtilsForLua:call("getPropByIdGroup", "lordDetails", v.lordId, "isFromServer")
        local show = CCCommonUtilsForLua:call("getPropByIdGroup", "lordDetails", v.lordId, "show")
        local buff = CCCommonUtilsForLua:call("getPropByIdGroup", "lordDetails", v.lordId, "buff")
        
        local value = playerInfo:call("getAttributeByKey", effect)
        if value == -1 then
            value = 0
            local eSolts = splitString(effect, "|")
            local fSolts = splitString(isFromServer, "|")
            local match = (table.getn(eSolts) == table.getn(fSolts))
            for index, effectNum in ipairs(eSolts) do
                local t_value = 0
                effectNum = splitString(effectNum, ";")[1]
                
                if match and fSolts[index] == "1" then
                    t_value = getNeutralLandEffect(atoi(effectNum))
                elseif defaultShow == "1" then
                    t_value = CCCommonUtilsForLua:call("getIgnoreSpeEffectValueByNum", atoi(effectNum))
                else
                    t_value = CCCommonUtilsForLua:call("getEffectValueByNum", atoi(effectNum))
                end

                if effectNum == "417" then
                    value = value - t_value
                else
                    value = value + t_value
                end

                if v.lordId == "46397" then
                    Dprint("t_value", t_value, value, effectNum)
                end

                --针对行军上限，出征士兵数量
                if effectNum == "56" then
                    value = TroopsController:call("getMaxSoilder")
                    break
                end

                --针对行军部队总数
                if v.lordId == "46370" then
                    value = value + 1
                end
            end
        end
        local valStr = CC_CMDITOA(value)
        
        if show == "0" then valStr = string.format("%.f%%", value) end
        if value >= 0 then
            if buff == "1" then
                valStr = "-" .. valStr
            elseif buff == "2" then
                valStr = "+" .. valStr
            end
        end

        table.insert(attribute, {
            dialog = name,
            value = valStr,
        })
    end

    return attribute
end

function AllianceDetailView:onClickBtnAdd()
    local view = Drequire("game.CommonPopup.ItemGetMethodView"):create(itemDataId)
    PopupViewController:call("addPopupView", view)
end

return AllianceDetailView