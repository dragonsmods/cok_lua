----------------------------
-- Author: Elex
-- Date: 2019-06-28 Friday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local FirstKillRewardView_ui = class("FirstKillRewardView_ui")

--#ui propertys


--#function
function FirstKillRewardView_ui:create(owner, viewType, paramTable)
	local ret = FirstKillRewardView_ui.new()
	CustomUtility:DoRes(502, true)
	CustomUtility:LoadUi("FirstKillRewardView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function FirstKillRewardView_ui:initLang()
	LabelSmoker:setText(self.m_labelDesc, "103759")
	LabelSmoker:setText(self.m_pLabelTTF26, "167548")
	LabelSmoker:setText(self.m_labelTitle, "103758")
end

function FirstKillRewardView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function FirstKillRewardView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function FirstKillRewardView_ui:onClickBtnGet(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnGet", pSender, event)
end

function FirstKillRewardView_ui:initTableView()
	TableViewSmoker:createView(self, "m_tableView", "game.CommonPopup.FirstKillRewardCell", 0, 5, "FirstKillRewardCell")
end

function FirstKillRewardView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return FirstKillRewardView_ui

