--[[
    2019-11-19
    出征界面 士兵列表单元 C++转Lua
]]
local Music_Sfx_click_button = "ui_confirm"


local SoldierCell = class("SoldierCell", function()
	return cc.Layer:create()
end)

function SoldierCell:create(idx, statusId, view)
	local node = NewActiveSkillViewBuffCell.new()
	if (node:initNode(idx, statusId, view)) then
		return node
    end
    return nil
end

function SoldierCell:create(view, itemId, num, type, rally, maxForceNum, diyRally, battleType)
    local node = SoldierCell.new()
    if (node and node:initNode(view, itemId, num, type, rally, maxForceNum, diyRally, battleType)) then
        return node
    end
    return nil
end

function SoldierCell:initNode(view, itemId, num, type, rally, maxForceNum, diyRally, battleType)
    self.m_view = view
    local ret = true;
    local proxy = cc.CCBProxy:create()
    self.node = CCBReaderLoad("MarchSoldierCellForLua.ccbi", proxy, self)
    self:addChild(self.node)
    self:setContentSize(CCSize(640, 100))
    
    local m_sliderBg = CCLoadSprite:call("createScale9Sprite", "PRO_diban03.png")
    m_sliderBg:setInsetBottom(5)
    m_sliderBg:setInsetLeft(5)
    m_sliderBg:setInsetRight(5)
    m_sliderBg:setInsetTop(5)
    m_sliderBg:setAnchorPoint(ccp(0.5,0.5))
    m_sliderBg:setPosition(ccp(190/2,26))
    m_sliderBg:setContentSize(CCSize(190,26))
    
    local proSp = CCLoadSprite:call("createSprite", "PRO_lvse.png")
    proSp:setScaleY(4.5)
    local thuSp = CCLoadSprite:call("createSprite", "huadongtiao1.png")
    
    self.m_slider = CCSliderBar:call("createSlider", m_sliderBg, proSp, thuSp)
    self.m_slider:setProperty("isPrecies", true)
    self.m_slider:setMinimumValue(0.0)
    self.m_slider:setMaximumValue(1.0)
    self.m_slider:call("setProgressScaleX", 190/proSp:getContentSize().width)
    self.m_slider:setTag(1)
    self.m_slider:call("setLimitMoveValueEx", 25)
    -- self.m_slider:addTargetWithActionForControlEvents(this, cccontrol_selector(SoldierCell::valueChange), CCControlEventValueChanged)
    self.m_slider:addHandleOfControlEvent(function(pSender) self:valueChange(pSender) end, CCControlEventValueChanged)
    self.m_sliderNode:addChild(self.m_slider)
    

    -- [awen-junyu] 设置自定义集结状态
    self.m_diyRally = diyRally;
    self.m_battleType = battleType;

    local editSize = self.m_editNode:getContentSize()
    self.m_editBox = CCEditBox:create(editSize, CCLoadSprite:call("createScale9Sprite", "BG_tanchukuang02.png"))
    self.m_editBox:setInputMode(cc.EDITBOX_INPUT_MODE_NUMERIC)
    self.m_editBox:setText("0")
    -- self.m_editBox:setDelegate(this)
    self.m_editBox:setMaxLength(12)
    self.m_editBox:setReturnType(cc.KEYBOARD_RETURNTYPE_DONE)
    self.m_editBox:setPosition(ccp(editSize.width/2, editSize.height/2))
    self.m_editNode:addChild(self.m_editBox)

    local function editCB (strEventName, pSender)
        if tostring(pSender) == "began" then
            --光标进入，选中全部内容
            self:editBoxEditingDidBegin()
        elseif tostring(pSender) == "ended" then

        elseif tostring(pSender) == "return" then
            -- 当用户点击编辑框的键盘以外的区域，或者键盘的Return按钮被点击时所调用
            self:editBoxReturn()         
        elseif tostring(pSender) == "changed" then
            -- 输入内容改变时调用     
        end
    end
    self.m_editBox:registerScriptEditBoxHandler(editCB)

    dump("self:setData")
    self:setData(itemId, num, type, rally,maxForceNum)
    return ret
end

-- 开始编辑
function SoldierCell:editBoxEditingDidBegin(editBox)
    CCSafeNotificationCenter:postNotification("msg_close_challengePopView")
end

function SoldierCell:setData(itemId, num, type, rally, maxForceNum)
    if (itemId == "") then
        return
    end

    self.m_invalidSliderMove = true;
    self.m_soldierId = itemId;
    self.m_num = num;
    self.m_type = type;
    self.m_rally = rally;
    self.m_maxForceNum=maxForceNum;
    local name = CCCommonUtilsForLua:call("getNameById", self.m_soldierId)
    local picName = ArmyController:call("getInstance"):call("getArmyIconById", self.m_soldierId)
    self.m_cntNum = TroopsController:call("getInstance"):getProperty("m_tmpConfSoldiers")[self.m_soldierId] or 0
    self.m_slider:setEnabled(true)
    self.m_nameLabel:setString(name)
    
    self.m_picNode:removeAllChildren()
    
    self.m_iconPath = picName

    local star = ArmyController:call("getInstance"):call("getStarlvById", self.m_soldierId)
    local pic = SoldierIconCell:call("create", picName, 110, self.m_soldierId, true, star)

    self.m_picNode:addChild(pic)
    pic:setPositionY(-10)

    self.m_levelNode:removeAllChildren()
    local num1 = CCCommonUtilsForLua:getPropByIdGroup("arms", self.m_soldierId, "level")
    local pic1 = CCCommonUtilsForLua:call("getRomanSprite", tonumber(num1))
    self.m_levelNode:addChild(pic1)
    
    local pro = 0
    if (self.m_cntNum > 0) then
        pro = self.m_num / self.m_cntNum
    end
    self.m_slider:setValue(pro)

    -- [awen-junyu] 单兵种初始百分比
    if (self.m_diyRally > 0) then
        local rate = 100.0 * self.m_num / self.m_maxForceNum
        self.m_editBox:setText(string.format("%.2f%%", rate))    -- (CCString:createWithFormat("%.2f%%", rate)->getCString());
    else
        self.m_editBox:setText(CC_ITOA(self.m_num))
    end
    TroopsController:call("getInstance"):call("updateTmpBattleData", self.m_soldierId, self.m_num, self.m_soldierId, false);
end

function SoldierCell:refresh()
    local num = 0
    local battleInfos = TroopsController:call("getInstance"):getProperty("m_tmpBattleInfos")
    if (battleInfos[self.m_soldierId] ~= nil) then
        num = battleInfos[self.m_soldierId]
    end

    self:setData(self.m_soldierId, num, self.m_type, self.m_rally, self.m_maxForceNum)
end

function SoldierCell:valueChange(pSender, pCCControlEvent)
    if (self.m_invalidSliderMove) then
        self.m_invalidSliderMove = false
        return
    end

    if (self.m_cntNum <= 0) then
        return
    end

    local total = 0   -- 计算当前已选兵数 但是不包括当前兵种的
    -- map<string, int>::iterator it;
    
    -- 各种兵种总数
    local infantry_count = 0;
    local cavalry_count = 0;
    local archer_count = 0;
    local vehicle_count = 0;
    
    local battleInfos = TroopsController:call("getInstance"):getProperty("m_tmpBattleInfos")
    for key, value in pairs(battleInfos) do
        if (value > 0 and key ~= self.m_soldierId) then
            total = total + value
            
            local arm = CCCommonUtilsForLua:getPropById(key, "arm");
            local armType = tonumber(arm)
            -- 步兵
            if (armType == ArmEnumType.ARM_BU or armType == ArmEnumType.ARM_QIANG) then
                infantry_count = infantry_count + value
            end
            
            -- 骑兵
            if (armType == ArmEnumType.ARM_RIDE or armType == ArmEnumType.ARM_RIDE_SHE) then
                cavalry_count = cavalry_count + value
            end
            
            -- 弓兵
            if (armType == ArmEnumType.ARM_GONG or armType == ArmEnumType.ARM_NU) then
               archer_count = archer_count + value
            end

            -- 车兵
            if (armType == ArmEnumType.ARM_TOU_SHI_BING or armType == ArmEnumType.ARM_CHE) then
                vehicle_count = vehicle_count + value
            end
        end
    end

    local canSelNum = self.m_maxForceNum - total
    
    local arm = CCCommonUtilsForLua:getPropById(self.m_soldierId, "arm")
    local armType = tonumber(arm)
    
    canSelNum = math.max(canSelNum, 0)
    
    SoundController:call("playEffects", Music_Sfx_click_button)
    local value = self.m_slider:getValue()
    local curNum = math.round(value * self.m_cntNum)
    curNum = math.min(curNum, canSelNum)
    
    local retNum = TroopsController:call("getInstance"):call("updateTmpBattleData", self.m_soldierId, curNum, self.m_soldierId, false)
    
    TroopsController:call("getInstance"):call("makeLoadNumAll")

    local oldNum = tonumber(self.m_editBox:getText()) or 0
    
    -- [awen-junyu] 调节后单兵种百分比
    if (self.m_diyRally > 0) then
        local rateMax = 100.0 * canSelNum / self.m_maxForceNum
        local rate = 100.0 * retNum / self.m_maxForceNum
        self.m_editBox:setText(string.format("%.2f%%", math.min(rate, rateMax)))
    else
        self.m_editBox:setText(CC_ITOA(retNum))
    end

    if (oldNum == 0 and retNum > 0) then
        TroopsController:call("getInstance"):call("changeArrTime")
    elseif (oldNum > 0 and retNum == 0) then
        TroopsController:call("getInstance"):call("changeArrTime")
    end
    
    self.m_invalidSliderMove = true
    if (retNum >= 0) then
        self.m_slider:setValue(retNum / self.m_cntNum)
    else
        self.m_slider:setValue(0)
    end
end

function SoldierCell:onEnter()
    
end

function SoldierCell:onExit()
    
end


function SoldierCell:onSubClick(pSender, pCCControlEvent)
    CCSafeNotificationCenter:postNotification("msg_close_challengePopView")
    local change = 1
    if (self.m_view.m_soilder_perSet ~= 0) then
        change = math.floor(self.m_maxForceNum * self.m_view.m_soilder_perSet / 100)
    end
    local num = math.ceil(self.m_slider:getValue() * self.m_cntNum) - change
    if (num < 0) then
        num = 0;
    end
    self.m_slider:setValue(num / self.m_cntNum)
end

function SoldierCell:onAddClick(pSender, pCCControlEvent)
    CCSafeNotificationCenter:postNotification("msg_close_challengePopView")
    local change = 1
    if (self.m_view.m_soilder_perSet ~= 0) then
        change = math.floor(self.m_maxForceNum * self.m_view.m_soilder_perSet / 100)
    end
    local num = math.ceil(self.m_slider:getValue() * self.m_cntNum) + change
    if (num > self.m_cntNum) then
        num = self.m_cntNum
    end
    self.m_slider:setValue(num / self.m_cntNum)
end


function SoldierCell:editBoxReturn()
    -----------!!!!!!!!
    local value = tonumber(self.m_editBox:getText())
    
    -- [awen-junyu] 输入框变化
    if (self.m_diyRally > 0) then
        local f_value = tonumber(self.m_editBox:getText())
        value = f_value * self.m_maxForceNum / 100
    end
    
    if (value > self.m_cntNum) then
        value = self.m_cntNum
    elseif (value < 0) then
        value = 0
    end

    value = TroopsController:call("getInstance"):call("updateTmpBattleData", self.m_soldierId, value, self.m_soldierId, false)

    TroopsController:call("getInstance"):call("makeLoadNumAll")
    TroopsController:call("getInstance"):call("changeArrTime")
    
    if (self.m_cntNum > 0) then
        self.m_slider:setValue(value / self.m_cntNum)
    else
        self.m_slider:setValue(0.0)
    end
end

function SoldierCell:cellTouchEnded(pTouch)
    CCSafeNotificationCenter:postNotification("msg_close_challengePopView")
    local name = CCCommonUtilsForLua:call("getNameById", self.m_soldierId)
    local des = _lang(CCCommonUtilsForLua:getPropById(self.m_soldierId, "description"))
    -- PopupViewController::getInstance()->addPopupView(UnlockItemInfoView::create(name, des, self.m_iconPath))

    local dict = CCDictionary:create()
    dict:setObject(CCString:create("OpenUnlockItemInfoView"), "name")
    dict:setObject(CCString:create(name), "soldierName")
    dict:setObject(CCString:create(des), "description")
    dict:setObject(CCString:create(self.m_iconPath), "iconPath")
    LuaController:call("openPopViewInLua", dict)
end

return SoldierCell