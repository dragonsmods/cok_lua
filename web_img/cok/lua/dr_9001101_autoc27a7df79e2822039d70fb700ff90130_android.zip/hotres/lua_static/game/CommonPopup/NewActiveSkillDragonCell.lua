local NewActiveSkillDragonCell = class("NewActiveSkillDragonCell", function()
	return cc.TableViewCell:create()
end)

local CELL_WIDTH = 182		-- 单元格宽
local CELL_HEIGHT = 184		-- 单元格高

function NewActiveSkillDragonCell:ctor(idx, tid, view)

	self.idx = -1
	self.tid = {}
	self.view = view

	local proxy = cc.CCBProxy:create()
	local ccbiUrl = "ActiveSkill_v2_Cell1"
	self.node = CCBReaderLoad(ccbiUrl, proxy, self)
	self:addChild(self.node)

	self.touchLayer = cc.Layer:create()
	self:addChild(self.touchLayer)
	local function touchHandle(eventType, x, y)
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "ended" then
			self:onTouchEnded(x, y)
		end
	end
	self.touchLayer:registerScriptTouchHandler(touchHandle)
	self.touchLayer:setTouchEnabled(true)
	self.touchLayer:setSwallowsTouches(false)

	self.gridNode = cc.Node:create()
	self:addChild(self.gridNode)

	self.gridNodeTable = {}

	self:setData(idx, tid)
end

function NewActiveSkillDragonCell:onTouchBegan(x, y)
	if self.view.page == "dragon" and isTouchInside(self.m_dragonBgSprite, x, y) then
		return true
	end
	return false
end

function NewActiveSkillDragonCell:onTouchEnded(x, y)
	if isTouchInside(self.m_dragonBgSprite, x, y) then
		self.view:onTouchCell(self.idx)
	end

end

function NewActiveSkillDragonCell:setData(idx, tid)
	self.idx = idx
	self.tid = tid

	self.m_dragonNode:removeAllChildren()
	self.m_dNameLabel:setString("")
	if #self.tid > 0 then
		local born_dragon = CCCommonUtilsForLua:call("getPropById", self.tid[1], "born_dragon") 
		local dragon_icon_file = CCCommonUtilsForLua:call("getPropById", born_dragon, "head_icon") .. ".png"
		local dragon_icon = CCLoadSprite:call("createSprite", dragon_icon_file)
		local spriteFrame = dragon_icon:getSpriteFrame()
		local clip_node = IFRoundSprite:call("createWithSpriteFrame", spriteFrame, 100)
		clip_node:setScale(0.5)
		self.m_dragonNode:addChild(clip_node)


		local skillInfo = DragonActiveSkillManager.getInstance():getDataById(self.tid[1])
		if nil ~= skillInfo then
			local dragonInfo = skillInfo:getDragonInfo()
			if nil ~= dragonInfo then
				self.m_dNameLabel:setString(getLang(dragonInfo:call("getName")))
			end
		end
	end

	local state = self.view.dragonDataGroupState[idx].state
	if state == 1 then
		self.m_arrowSprite:setRotation(90)
		self.node:setPositionY(CELL_HEIGHT * math.ceil(#self.tid / 3))
		self.gridNode:setVisible(true)

		--self.gridNode:removeAllChildren()
		for i, v in ipairs(self.tid) do
			local grid = self.gridNodeTable[i]
			if grid == nil then
				grid = myRequire("game.CommonPopup.NewActiveSkillDragonGrid").new(v, self.view)
				self.gridNodeTable[i] = grid
				self.gridNode:addChild(grid)
			else
				grid:setData(v, self.view)
			end
			grid:setPosition(cc.p(CELL_WIDTH * ((i - 1) % 3), CELL_HEIGHT * (math.ceil(#self.tid / 3) - math.ceil(i / 3))))
		end
		for i, v in ipairs(self.gridNodeTable) do
			self.gridNodeTable[i]:setVisible(i <= #self.tid)
		end
	else
		self.m_arrowSprite:setRotation(0)
		self.node:setPositionY(0)
		--self.gridNode:removeAllChildren()
		self.gridNode:setVisible(false)
	end
	MyPrint("NewActiveSkillDragonCell:setData self.gridNode:getPositionY() = ", self.gridNode:getPositionY())
end

return NewActiveSkillDragonCell