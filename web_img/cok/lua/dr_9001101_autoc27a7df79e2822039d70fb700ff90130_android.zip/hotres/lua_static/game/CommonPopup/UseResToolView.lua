local newAdvTag = 9124
local MSG_BUY_CONFIRM_OK_WITHOUT_TWEEN = "buy.confirm.ok.without.tween"

local UseResToolView = class("UseResToolView", function() return PopupBaseView:create() end )
UseResToolView.__index = UseResToolView

local UseResToolCell = class("UseResToolCell", function() return cc.Layer:create() end )
UseResToolCell.__index = UseResToolCell

function UseResToolView:create(resType, showIndex)
	local view = UseResToolView.new()
	if (view:initView(resType, showIndex)) then return view end
end

function UseResToolView:initView(resType, showIndex)
	if (self:init(true, 0)) then
		self:setIsHDPanel(true)
		self.m_resType = resType
		self.m_showIndex = showIndex
		self.m_curList = {}
		self.m_showMethodTime = 0

		local proxy = cc.CCBProxy:create()
		local ccbUri = "UseResToolView_lua.ccbi"
		local node = CCBReaderLoad(ccbUri, proxy, self)

		local function onNodeEvent(event)
			if event == "enter" then
				self:onEnter()
			elseif event == "exit" then
				self:onExit()
			elseif event == "cleanup" then
				self:onCleanup()
 			end
		end
		node:registerScriptHandler(onNodeEvent)
		self:addChild(node)

		local nodeSize = node:getContentSize()
		self:setContentSize(nodeSize)

		local winSize = cc.Director:sharedDirector():getIFWinSize()
		-- CCCommonUtilsForLua:call("makeBatchBG", self.m_bgNode, winSize, ccp(0.5, 1), 1)

		local addHeight = self:getExtendHeight()
		-- self.m_infoList:setPositionY(self.m_infoList:getPositionY() + addHeight)

		local listSize = self.m_infoList:getContentSize()
		-- self.m_infoList:setContentSize(cc.size(listSize.width, listSize.height + addHeight))

		if (self.m_resType == WorldResourceType.Sandstone 
			or self.m_resType == WorldResourceType.Carbite
			or self.m_resType == WorldResourceType.Marble
			or self.m_resType == WorldResourceType.Granite
			or self.m_resType == WorldResourceType.Limestone) then
			self.m_alResourceNode:setVisible(true)
			self.m_resourceNode:setVisible(false)
			self.m_bindNode:setVisible(false)

			self.m_showMethodLimit = 1

			local h = self.m_bindNodeBg:getContentSize().height * self.m_bindNodeBg:getScaleY()
			-- self.m_bgTitle:setPositionY(self.m_bgTitle:getPositionY() + h)
			local listSize = self.m_infoList:getContentSize()
			self.m_infoList:setContentSize(cc.size(listSize.width, listSize.height + h))

			local funcOpen = CCCommonUtilsForLua:call("isFunOpenByKey", "alliance_building_resource25")
			if (not funcOpen) then
				self.m_al1Node:setPosition(self.m_woodNode:getPosition())
				self.m_al2Node:setPosition(self.m_foodNode:getPosition())
				self.m_al3Node:setPosition(self.m_ironNode:getPosition())
				self.m_al4Node:setPosition(self.m_stoneNode:getPosition())
				self.m_al5Node:setPosition(self.m_al5Node:getPositionX() + 1000, self.m_al5Node:getPositionY())

				self.m_sandBtn:setPreferredSize(self.m_woodBtn:getContentSize())
				self.m_carbiteBtn:setPreferredSize(self.m_foodBtn:getContentSize())
				self.m_marbleBtn:setPreferredSize(self.m_ironBtn:getContentSize())
				self.m_graniteBtn:setPreferredSize(self.m_stoneBtn:getContentSize())

				self.m_sandLine:setPositionX(-self.m_woodBtn:getContentSize().width/2)
				self.m_carbiteLine:setPositionX(-self.m_foodBtn:getContentSize().width/2)
				self.m_marbleLine:setPositionX(-self.m_ironBtn:getContentSize().width/2)
				self.m_graniteLine:setPositionX(-self.m_stoneBtn:getContentSize().width/2)
			end

			-- 添加联盟物资广告
			local _node = Drequire('utils.commonAdNode'):create(AD_TYPE.ALLIANCE_SUPPLIES)
			if _node then
				self.m_adParentNode:removeAllChildren()
				self.m_adParentNode:addChild(_node)
			end
		else
			self.m_alResourceNode:setVisible(false)
			self.m_resourceNode:setVisible(true)

			local bindOpen = GlobalData:call("shared"):getProperty("fun_bindRes_switch")
			if self.m_resType == WorldResourceType.Silver then
				bindOpen = false
			end
			self.m_bindNode:setVisible(bindOpen)
			if (not bindOpen) then
				local h = self.m_bindNodeBg:getContentSize().height * self.m_bindNodeBg:getScaleY()
				-- self.m_bgTitle:setPositionY(self.m_bgTitle:getPositionY() + h)
				local listSize = self.m_infoList:getContentSize()
				self.m_infoList:setContentSize(cc.size(listSize.width, listSize.height + h))
			end

			local mlv = FunBuildController:call("getMainCityLv")
			local building_base_k3 = FunBuildController:call("getInstance"):getProperty("building_base_k3")
			local building_base_k4 = FunBuildController:call("getInstance"):getProperty("building_base_k4")
			
			if (self.m_resType == 13 or self.m_resType == WorldResourceType.Silver) then
				self.m_ironBtn:setEnabled(false)
				self.m_stoneBtn:setEnabled(false)
				self.m_ironNode:setVisible(false)
				self.m_stoneBtn:setVisible(false)
				self.m_foodNode:setVisible(false)

				if self.m_resType == WorldResourceType.Silver then
					self.m_woodLine:setVisible(false)
					self.m_stoneNode:setVisible(false)
				end

				if (self.m_resType == 13) then
					local sf = CCLoadSprite:call("loadResource", "Ui_tili.png")
					self.m_itemIcon:initWithSpriteFrame(sf)
					self.m_itemIcon:setScale(0.65)
				else
					local url = CCCommonUtilsForLua:call("getResourceIconByType", WorldResourceType.Silver)
					local sf = CCLoadSprite:call("loadResource", url)
					self.m_itemIcon:initWithSpriteFrame(sf)
					self.m_itemIcon:setScale(0.5)
				end

				self.m_woodBtn:setPreferredSize(cc.size(640, 54))

				if (CCCommonUtilsForLua:isIosAndroidPad()) then
					self.m_itemIcon:setScale(1.35)
					if (self.m_resType == WorldResourceType.Silver) then
						self.m_itemIcon:setScale(1)
					end
					self.m_woodBtn:setPreferredSize(cc.size(1536, 108))
				end

				self.m_woodNode:setPositionX(0)
				self.m_woodBtn:setEnabled(false)
			elseif (mlv >= building_base_k3 and mlv >= building_base_k4) then

			elseif (mlv >= building_base_k3 or mlv >= building_base_k4) then
				if (mlv >= building_base_k3) then
					self.m_stoneBtn:setEnabled(false)
					self.m_stoneNode:setVisible(false)

					if (CCCommonUtilsForLua:isIosAndroidPad()) then
						self.m_ironNode:setPositionX(512)
						self.m_ironBtn:setPreferredSize(cc.size(512, 108))
					else
						self.m_ironNode:setPositionX(213)
						self.m_ironBtn:setPreferredSize(cc.size(213, 54))
					end
				else
					self.m_ironBtn:setEnabled(false)
					self.m_ironNode:setVisible(false)

					if (CCCommonUtilsForLua:isIosAndroidPad()) then
						self.m_stoneNode:setPositionX(512)
						self.m_stoneBtn:setPreferredSize(cc.size(512, 108))
					else
						self.m_stoneNode:setPositionX(213)
						self.m_stoneBtn:setPreferredSize(cc.size(213, 54))
					end
				end

				if (CCCommonUtilsForLua:isIosAndroidPad()) then
					self.m_woodBtn:setPreferredSize(cc.size(512, 108))
					self.m_foodBtn:setPreferredSize(cc.size(512, 108))
					self.m_woodNode:setPositionX(-512)
					self.m_foodNode:setPositionX(0)
				else
					self.m_woodBtn:setPreferredSize(cc.size(213, 54))
					self.m_foodBtn:setPreferredSize(cc.size(213, 54))
					self.m_woodNode:setPositionX(-213)
					self.m_foodNode:setPositionX(0)
				end
			else
				self.m_ironBtn:setEnabled(false)
				self.m_stoneBtn:setEnabled(false)
				self.m_ironNode:setVisible(false)
				self.m_stoneNode:setVisible(false)

				if (CCCommonUtilsForLua:isIosAndroidPad()) then
					self.m_woodBtn:setPreferredSize(cc.size(768, 108))
					self.m_foodBtn:setPreferredSize(cc.size(768, 108))
					self.m_woodNode:setPositionX(-384)
					self.m_foodNode:setPositionX(384)
				else
					self.m_woodBtn:setPreferredSize(cc.size(320, 54))
					self.m_foodBtn:setPreferredSize(cc.size(320, 54))
					self.m_woodNode:setPositionX(-160)
					self.m_foodNode:setPositionX(160)
				end
			end
			self.m_woodLine:setPositionX(-self.m_woodBtn:getPreferredSize().width / 2)
			self.m_foodLine:setPositionX(-self.m_foodBtn:getPreferredSize().width / 2)
			self.m_ironLine:setPositionX(-self.m_ironBtn:getPreferredSize().width / 2)
			self.m_stoneLine:setPositionX(-self.m_stoneBtn:getPreferredSize().width / 2)
		end

		-- [awen-lvliang]新手提示采集
		local mainCityLv = FunBuildController:call("getMainCityLv")
		local freshHintInRes = GlobalData:call('shared'):getProperty('freshHintInRes')
		if tonumber(mainCityLv) <= tonumber(freshHintInRes) then
			self.m_nodeGather:setVisible(true)	--
			self.m_labelGather:setString(getLang('160618'))	--160618=除使用道具获取资源外，您还可以前往世界采集资源田获得。
			local offset = 0
			if not self.m_bindNode:isVisible() then
				offset = 10
				self.m_nodeGather:setPositionY(self.m_bindNode:getPositionY() - offset)
			end
			local listSize = self.m_infoList:getContentSize()
			self.m_infoList:setContentSize(cc.size(listSize.width, listSize.height - self.m_nodeGather:getContentSize().height - offset))
		else
			self.m_nodeGather:setVisible(false)
		end

		self.m_tableView = cc.TableView:create(self.m_infoList:getContentSize())
		self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
		self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
		self.m_tableView:setDelegate()
		self.m_tableView:registerScriptHandler(function(tab, idx) return self:cellSizeForTable(tab, idx) end, cc.TABLECELL_SIZE_FOR_INDEX)
		self.m_tableView:registerScriptHandler(function(tab, idx) return self:tableCellAtIndex(tab, idx) end, cc.TABLECELL_SIZE_AT_INDEX)
		self.m_tableView:registerScriptHandler(function(tab) return self:numberOfCellsInTableView(tab) end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
		self.m_infoList:addChild(self.m_tableView)

		self:updateResInfo()
        -- self.m_bindResDesLabel:setString(getLang("139511"))	--139511=安全资源：
        -- self.m_normalResDesLabel:setString(getLang("139522")) --139522=普通资源：
        self.m_resDesc:setString(getLang("52054267"))
		self:updateInfo()
 
		return true
	end

	return false
end

function UseResToolView:updateInfo()
	self.m_woodBtn:setEnabled(true)
	self.m_stoneBtn:setEnabled(true)
	self.m_foodBtn:setEnabled(true)
	self.m_ironBtn:setEnabled(true)
	self.m_sandBtn:setEnabled(true)
	self.m_carbiteBtn:setEnabled(true)
	self.m_marbleBtn:setEnabled(true)
	self.m_graniteBtn:setEnabled(true)
	self.m_limeBtn:setEnabled(true)

	self.m_bindFoodIcon:setVisible(false)
	self.m_bindWoodIcon:setVisible(false)
	self.m_bindStoneIcon:setVisible(false)
	self.m_bindIronIcon:setVisible(false)

	self:updateBindResInfo()

	local t_cityLv = FunBuildController:call("getMainCityLv")
	self.m_curList = {}

	local resLists = ToolController:call("getInstance"):getProperty("m_typeTools")
	local resList = resLists[3]
	self.m_indexId = -1		-- 指示手指的itemID
	for i = 1, #resList do
		local info = ToolController:call("getToolInfoByIdForLua", resList[i])
		local type2 = info:getProperty("type2")
		if (type2 == self.m_resType) then
			local price = info:getProperty("price")
			local limitLv = info:getProperty("limitLv")
			local cnt = info:call("getCNT")
			local itemId = info:getProperty("itemId")
			if (price > 0 and limitLv <= t_cityLv) then
				self.m_curList[#self.m_curList + 1] = itemId
				if (self.m_showIndex and cnt > 0 and self.m_indexId < 0) then
					self.m_indexId = itemId
				end
			elseif (price <= 0 and cnt > 0) then
				self.m_curList[#self.m_curList + 1] = itemId
				if (self.m_showIndex and self.m_indexId < 0) then
					self.m_indexId = itemId
				end
			end
		end
	end

	self.m_msgLabel:setString("")
	if (#self.m_curList <= 0) then 
		self.m_msgLabel:setString(getLang("164121"))
		if not self.m_showMethodLimit or self.m_showMethodTime < self.m_showMethodLimit then
			local ItemGetMethodView = Drequire("game.CommonPopup.ItemGetMethodView")
			PopupViewController:call("addPopupView", ItemGetMethodView:create("209988"))
			self.m_showMethodTime = self.m_showMethodTime + 1
		end
	end

	if (CCCommonUtilsForLua:call("isFunOpenByKey", "split_window")) then
		--显示 advertising
		local show_type = 1
		if (self.m_resType == WorldResourceType.Food) then
			show_type = 4
		elseif (self.m_resType == WorldResourceType.Wood) then
			show_type = 5
		elseif (self.m_resType == WorldResourceType.Iron) then
			show_type = 6
		elseif (self.m_resType == WorldResourceType.Stone) then
			show_type = 7
		elseif (self.m_resType == WorldResourceType.Silver) then
			show_type = 219
		end

		local listSize = self.m_infoList:getContentSize()
		self.m_infoList:removeChildByTag(newAdvTag)
		self.m_tableView:setViewSize(listSize)
		
		local height = 124
		local isNew = false
		if isFunOpenByKey("Alliance_Supplies_pack_new") then
			if show_type == 1 then
				show_type = 297
				height = 500
				isNew = true
			end
		end
		if (LiBaoController:call("hasItemByShowType", tostring(show_type))) then
			if isNew then
				local advNode = Drequire("game.LiBao.LuaGoldExchangeAdView").new(show_type, show_type ~= 297, nil, nil, {ccbType = 1})
				if advNode then
					self.m_infoList:addChild(advNode, 1)
					advNode:setPosition(listSize.width / 2, listSize.height - height)
					self.m_tableView:setViewSize(cc.size(listSize.width, listSize.height - height))
					advNode:setTag(newAdvTag)
				end
			else
				local advNode = require("game.LiBao.LuaGoldExchangeAdView").new(show_type, true)
				if (advNode) then
					self.m_infoList:addChild(advNode, 1)

					if (CCCommonUtilsForLua:isIosAndroidPad()) then
						advNode:setPosition(listSize.width / 2, listSize.height - height * 2.4)
						self.m_tableView:setViewSize(cc.size(listSize.width, listSize.height - height * 2.4))
						advNode:setScale(2.4)
					else
						advNode:setPosition(listSize.width / 2, listSize.height - height)
						self.m_tableView:setViewSize(cc.size(listSize.width, listSize.height - height))
					end
					advNode:setTag(newAdvTag)
				end
			end
		end
	end

	self.m_tableView:reloadData()
	
	if self.m_resType == WorldResourceType.Food then
		self:showRedPoint()
	else
		self.m_labelNoEnough:setVisible(false)
	end
end

function UseResToolView:refreshData(pObj)
	local t_cityLv = FunBuildController:call("getMainCityLv")
	self.m_curList = {}
	self.m_indexId = -1		-- 指示手指的itemID
	local resLists = ToolController:call("getInstance"):getProperty("m_typeTools")
	local resList = resLists[3]
	for i = 1, #resList do
		local info = ToolController:call("getToolInfoByIdForLua", resList[i])
		local type2 = info:getProperty("type2")
		if (type2 == self.m_resType) then
			local price = info:getProperty("price")
			local limitLv = info:getProperty("limitLv")
			local cnt = info:call("getCNT")
			local itemId = info:getProperty("itemId")
			if (price > 0 and limitLv <= t_cityLv) then
				self.m_curList[#self.m_curList + 1] = itemId
				if (self.m_showIndex and cnt > 0 and self.m_indexId < 0) then
					self.m_indexId = itemId
				end
			elseif (price <= 0 and cnt > 0) then
				self.m_curList[#self.m_curList + 1] = itemId
				if (self.m_showIndex and self.m_indexId < 0) then
					self.m_indexId = itemId
				end
			end
		end
	end

	self.m_msgLabel:setString("")
	if (#self.m_curList <= 0) then
		self.m_msgLabel:setString(getLang("164121"))
		if not self.m_showMethodLimit or self.m_showMethodTime < self.m_showMethodLimit then
			local ItemGetMethodView = Drequire("game.CommonPopup.ItemGetMethodView")
			PopupViewController:call("addPopupView", ItemGetMethodView:create("209988"))
			self.m_showMethodTime = self.m_showMethodTime + 1
		end
	end

	local offset = self.m_tableView:getContentOffset()
	self.m_tableView:reloadData()
	local minContainerOffsety = self.m_tableView:minContainerOffset().y
	local maxContainerOffsety = self.m_tableView:maxContainerOffset().y
	offset.y = math.max(minContainerOffsety, math.min(maxContainerOffsety, offset.y))
	self.m_tableView:setContentOffset(offset)
	self:updateResInfo()
end

function UseResToolView:onEnter()
	self:setTitleName(getLang("104904"))	--104904=资源
	local function callback1(pObj) self:updateResInfo(pObj) end
	local function callback2(pObj) self:refreshData(pObj) end
	local handler1 = self:registerHandler(callback1)
	local handler2 = self:registerHandler(callback2)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, MSG_CITY_RESOURCES_UPDATE)
	CCSafeNotificationCenter:registerScriptObserver(self, handler2, MSG_REFREASH_TOOL_DATA)
end

function UseResToolView:onExit()
	CCSafeNotificationCenter:unregisterScriptObserver(self, MSG_CITY_RESOURCES_UPDATE)
	CCSafeNotificationCenter:unregisterScriptObserver(self, MSG_REFREASH_TOOL_DATA)
end

function UseResToolView:onCleanup()
	self = nil
end

function UseResToolView:updateBindResInfo()
	local resourceInfo = GlobalData:call("shared"):getProperty("resourceInfo")
	if (self.m_resType == WorldResourceType.Wood) then
		self.m_woodBtn:setEnabled(false)
		self.m_bindWoodIcon:setVisible(true)
        local total = resourceInfo:call("totalWood")
        local bind = resourceInfo:getProperty("lWood_bind")
        self:updateResBar(bind, total)
	elseif (self.m_resType == WorldResourceType.Stone) then
		self.m_stoneBtn:setEnabled(false)
        self.m_bindStoneIcon:setVisible(true)
        local total = resourceInfo:call("totalStone")
        local bind = resourceInfo:getProperty("lStone_bind")
        self:updateResBar(bind, total)
	elseif (self.m_resType == WorldResourceType.Food) then
		self.m_foodBtn:setEnabled(false)
        self.m_bindFoodIcon:setVisible(true)
        local total = resourceInfo:call("totalFood")
        local bind = resourceInfo:getProperty("lFood_bind")
        self:updateResBar(bind, total)
	elseif (self.m_resType == WorldResourceType.Iron) then
		self.m_ironBtn:setEnabled(false)
        self.m_bindIronIcon:setVisible(true)
        local total = resourceInfo:call("totalIron")
        local bind = resourceInfo:getProperty("lIron_bind")
        self:updateResBar(bind, total)
	elseif (self.m_resType == 13) then
		self.m_woodBtn:setEnabled(false)
		self.m_bindWoodIcon:setVisible(true)
		self.m_bindResLabel:setString(CC_ITOA_K(resourceInfo:getProperty("lWood_bind")))
	elseif (self.m_resType == WorldResourceType.Silver) then
		self.m_woodBtn:setEnabled(false)
	elseif (self.m_resType == WorldResourceType.Sandstone) then
		self.m_sandBtn:setEnabled(false)
	elseif (self.m_resType == WorldResourceType.Carbite) then
		self.m_carbiteBtn:setEnabled(false)
	elseif (self.m_resType == WorldResourceType.Marble) then
		self.m_marbleBtn:setEnabled(false)
	elseif (self.m_resType == WorldResourceType.Granite) then
		self.m_graniteBtn:setEnabled(false)
	elseif (self.m_resType == WorldResourceType.Limestone) then
		self.m_limeBtn:setEnabled(false)
	end
end

function UseResToolView:updateResBar(bind, total)
    self.m_bindResLabel:setString(getLang("139511")..CC_ITOA_K(bind))
    self.m_normalResLabel:setString(getLang("139522")..CC_ITOA_K(total - bind))

    if total > 0 then
        -- 资源 < 2%，固定显示2%的宽度
        local bindScale = bind / total
        if bind > 0 and bindScale < 0.02 then
            bindScale = 0.02
        elseif bind < total and bindScale > 0.98 then
            bindScale = 0.98
        end

        self.m_bindResBar:setVisible(true)
        self.m_normalResBar:setVisible(true)
        self.m_bindResBar:setScaleX(bindScale)
        self.m_normalResBar:setScaleX(1 - bindScale)
    else
        self.m_bindResBar:setVisible(false)
        self.m_normalResBar:setVisible(false)
    end
end

function UseResToolView:updateResInfo(pObj)
	local resourceInfo = GlobalData:call("shared"):getProperty("resourceInfo")

	self.m_woodLabel:setString(CC_ITOA_K(resourceInfo:call("totalWood")))
	self.m_stoneLabel:setString(CC_ITOA_K(resourceInfo:call("totalStone")))
	self.m_foodLabel:setString(CC_ITOA_K(resourceInfo:call("totalFood")))
	self.m_ironLabel:setString(CC_ITOA_K(resourceInfo:call("totalIron")))

	self.m_sandLabel:setString(CC_ITOA_K(resourceInfo:getProperty("sandstone")))
	self.m_carbiteLabel:setString(CC_ITOA_K(resourceInfo:getProperty("carbite")))
	self.m_marbleLabel:setString(CC_ITOA_K(resourceInfo:getProperty("marble")))
	self.m_graniteLabel:setString(CC_ITOA_K(resourceInfo:getProperty("granite")))
	self.m_limeLabel:setString(CC_ITOA_K(resourceInfo:getProperty("limestone")))

	self:updateBindResInfo()

	if (self.m_resType == 13) then
		local currt = WorldController:call("getInstance"):getProperty("currentStamine")
		local total = CCCommonUtilsForLua:call("getFinalStamineMax")
		self.m_woodLabel:setString(tostring(currt) .. "/" .. tostring(total))
	elseif (self.m_resType == WorldResourceType.Silver) then
		self.m_woodLabel:setString(CC_ITOA_K(resourceInfo:getProperty("lMoney")))
	elseif self.m_resType == WorldResourceType.Food then
		self:showRedPoint()
	end
end

function UseResToolView:showRedPoint()
	if isFunOpenByKey("food_alarm") and GlobalData:call("shared"):getProperty("isRefreshResHint") then
		local resourceInfo = GlobalData:call("shared"):getProperty("resourceInfo")
		if resourceInfo:call("totalFood") < ArmyController:call("getInstance"):call("getTotalUpKeep") then
			self.m_labelNoEnough:setVisible(true)
			self.m_labelNoEnough:setString(getLang("52034865"))--52034865=当前拥有粮食数量不足以部队口粮消耗，请及时补充
			if self.foodRedPoint then
				if self.foodRedPoint:isVisible() == false then
					self.foodRedPoint:setVisible(true)
				end
			else
				self.foodRedPoint = CCLoadSprite:createSprite("unlock_tipPt.png")
				local size = self.m_foodBtn:getPreferredSize()
				self.foodRedPoint:setPosition(ccp(size.width - 10, size.height - 10))
				self.m_foodBtn:addChild(self.foodRedPoint)
			end
		else
			if self.foodRedPoint and self.foodRedPoint:isVisible() then
				self.foodRedPoint:setVisible(false)
				self.m_labelNoEnough:setVisible(false)
			end
		end
	end
end

function UseResToolView:onClickWoodBtn()
	if (self.m_resType == WorldResourceType.Wood) then return end
	self.m_resType = WorldResourceType.Wood
	self:updateInfo()
end

function UseResToolView:onClickStoneBtn()
	if (self.m_resType == WorldResourceType.Stone) then return end
	self.m_resType = WorldResourceType.Stone
	self:updateInfo()
end

function UseResToolView:onClickFoodBtn()
	if (self.m_resType == WorldResourceType.Food) then return end
	self.m_resType = WorldResourceType.Food
	self:updateInfo()
end

function UseResToolView:onClickIronBtn()
	if (self.m_resType == WorldResourceType.Iron) then return end
	self.m_resType = WorldResourceType.Iron
	self:updateInfo()
end

function UseResToolView:onClickSandBtn()
	if (self.m_resType == WorldResourceType.Sandstone) then return end
	self.m_resType = WorldResourceType.Sandstone
	self:updateInfo()
end

function UseResToolView:onClickCarbiteBtn()
	if (self.m_resType == WorldResourceType.Carbite) then return end
	self.m_resType = WorldResourceType.Carbite
	self:updateInfo()
end

function UseResToolView:onClickMarbleBtn()
	if (self.m_resType == WorldResourceType.Marble) then return end
	self.m_resType = WorldResourceType.Marble
	self:updateInfo()
end

function UseResToolView:onClickGraniteBtn()
	if (self.m_resType == WorldResourceType.Granite) then return end
	self.m_resType = WorldResourceType.Granite
	self:updateInfo()
end

function UseResToolView:onClickLimeBtn()
	if (self.m_resType == WorldResourceType.Limestone) then return end
	self.m_resType = WorldResourceType.Limestone
	self:updateInfo()
end

function UseResToolView:onTipBtnClick()
	if (not isIOS()) then
		GlobalData:call("shared"):setProperty("isBind", true)
	end

	FaqHelper:call("showSingleFAQ", "45219")
end

function UseResToolView:cellSizeForTable(table, idx)
	if (CCCommonUtilsForLua:isIosAndroidPad()) then
		return 1536, 270
	end

	return 640, 140
end

function UseResToolView:tableCellAtIndex(table, idx)
	if (idx >= #self.m_curList) then return end

	local cell = table:dequeueCell()
	if (cell) then
		local node = cell:getChildByTag(666)
		node:setData(self.m_resType, self.m_curList[idx + 1], self.m_indexId)
	else
		cell = cc.TableViewCell:create()
		local node = UseResToolCell:create(self.m_resType, self.m_curList[idx + 1], self.m_infoList, self.m_indexId)
		node:setTag(666)
		cell:addChild(node)
	end

	return cell
end

function UseResToolView:numberOfCellsInTableView(table)
	return #self.m_curList or 0
end

--------------------------UseResToolCell-----------------------------

function UseResToolCell:create(resType, itemId, touchNode, indexId)
	local node = UseResToolCell.new()
	if (node:initNode(resType, itemId, touchNode, indexId)) then
		return node
	end
end

function UseResToolCell:initNode(resType, itemId, touchNode, indexId)
	local proxy = cc.CCBProxy:create()
	local ccbUri = "UseToolCell_lua.ccbi"
	local node = CCBReaderLoad(ccbUri, proxy, self)

	local function onNodeEvent(event)
		if event == "enter" then
			self:onEnter()
		elseif event == "exit" then
			self:onExit()
		elseif event == "cleanup" then
			self:onCleanup()
		end
	end
	node:registerScriptHandler(onNodeEvent)
	self:addChild(node)

	self.m_touchNode = touchNode
	self.m_buyBtn:setSwallowsTouches(false)
	self.m_useBtn:setSwallowsTouches(false)
	self.m_waitInterface = nil
	self:setData(resType, itemId, indexId)

	self.touchLayer = cc.Layer:create()
	self:addChild(self.touchLayer)

	local function touchHandle( eventType, x, y )
		print("touchHandle", eventType, x, y)
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		
		else
			self:onTouchEnded(x, y)
		end
	end
	self.touchLayer:registerScriptTouchHandler(touchHandle)
	self.touchLayer:setTouchEnabled(true)
	self.touchLayer:setSwallowsTouches(false)

	

	return true
end

function UseResToolCell:setData(resType, itemId, indexId)
	if (self.m_waitInterface) then
		self.m_waitInterface:call("remove")
		self.m_waitInterface = nil
	end

	self.m_itemId = itemId
	self.m_resType = resType
	self.m_des2Label:setString("")

	local toolInfo = ToolController:call("getToolInfoByIdForLua", itemId)
	local name = toolInfo:call("getName")
	local des = getLang(toolInfo:getProperty("des"))
	local cnt = toolInfo:call("getCNT")
	self.m_nameLabel:setString(name)
	self.m_desLabel:setString(des)
	self.m_numLabel:setString(tostring(cnt))

	self.m_price = toolInfo:getProperty("price")

	local itemId = toolInfo:getProperty("itemId")
	CCCommonUtilsForLua:call("createGoodsIcon", itemId, self.m_picNode, cc.size(98, 98))

	self.m_inBtnGoldNum:setString(CC_CMDITOA(self.m_price))
	CCCommonUtilsForLua:setButtonTitle(self.m_useBtn, getLang("102137"))
	self.m_btnMsgLabel:setString(getLang("104906"))

	if (cnt > 0) then
		self.m_buyNode:setVisible(false)
		self.m_buyBtn:setEnabled(false)
		self.m_useBtn:setVisible(true)
		self.m_useBtn:setEnabled(true)

		-- 加手指示
		if (indexId > 0 and indexId == itemId) then
			local spr = CCLoadSprite:createSprite('UI_hand.png')
			if spr then
				spr:setAnchorPoint(cc.p(0.5, 0.5))
				spr:setRotation(90)
				spr:setPosition(150, 20)
				local move1 = cc.MoveBy:create(0.5, cc.p(20, -20))
				local move2 = cc.MoveBy:create(0.5, cc.p(-20, 20))
				local seq = cc.Sequence:create(move1, move2)
				spr:runAction( cc.RepeatForever:create(seq) )
				spr:setTag(1)
				self.m_useBtn:removeChildByTag(1)
				self.m_useBtn:addChild(spr)
			end
		end
	else
		self.m_buyNode:setVisible(true)
		self.m_buyBtn:setEnabled(true)
		self.m_useBtn:setVisible(false)
		self.m_useBtn:setEnabled(false)
	end 
end

function UseResToolCell:onEnter()
	--self:setTouchEnabled(true)

	local function callback1(pObj) self:refreshData(pObj) end
	local function callback2(pObj) self:addWaitInterface(pObj) end
	local handler1 = self:registerHandler(callback1)
	local handler2 = self:registerHandler(callback2)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, MSG_TOOL_CHANGE)
	CCSafeNotificationCenter:registerScriptObserver(self, handler2, "addWaitInterface")

	UIComponent:call("showPopupView", 4)
end

function UseResToolCell:onExit()
	CCSafeNotificationCenter:unregisterScriptObserver(self, MSG_TOOL_CHANGE)
	CCSafeNotificationCenter:unregisterScriptObserver(self, "addWaitInterface")

	--self:setTouchEnabled(false)
end

function UseResToolCell:onCleanup()
	-- body
end

function UseResToolCell:onTouchBegan(x, y)
	if (isTouchInside(self.m_touchNode, x, y)) then
		self.m_touchPoint = ccp(x, y)
		return true
	end
	return false
end

function UseResToolCell:onTouchEnded(x, y)
	if (ccpDistance(ccp(x, y), self.m_touchPoint) < 50) then
		if (self.m_buyBtn:isEnabled() and isTouchInside(self.m_buyBtn, x, y)) then
			self:onClickBuyBtnByTouch()
		elseif (self.m_useBtn:isEnabled() and isTouchInside(self.m_useBtn, x, y)) then
			self:onClickUseBtnByTouch()
		end
	end
end

function UseResToolCell:refreshData(pObj)
	if (self.m_waitInterface) then
		self.m_waitInterface:call("remove")
		self.m_waitInterface = nil
	end
end

function UseResToolCell:addWaitInterface(pObj)
	self.m_waitInterface = GameController:call("showWaitInterface1", self.m_touchNode)
	local nodeSize = self.m_touchNode:getContentSize()
	self.m_waitInterface:setPosition(nodeSize.width / 2, nodeSize.height / 2)
end

function UseResToolCell:onClickUseBtnByTouch()
	self:onUseTool()
end

function UseResToolCell:onYes()
	local info = ToolController:call("getToolInfoByIdForLua", self.m_itemId)
	local itemId = toolInfo:getProperty("itemId")
	if (itemId == 200381) then --ITEM_ADD_STAMINE
		local currentStamine = WorldController:call("getInstance"):getProperty("currentStamine")
		local stamineMax = CCCommonUtilsForLua:call("getFinalStamineMax")
		if (currentStamine >= stamineMax) then
			CCCommonUtilsForLua:call("flyHint", "", "", getLang("103746"))
			return
		end
	end

	self:addWaitInterface()

	if (ToolController:call("isBuyUseOn")) then
		ToolController:call("buyUseTool", self.m_itemId, 1, nil, 0, false, "UseResToolView")
	else
		local function callback() self:onUseTool() end
		local callfunc = cc.CallFunc:create(callback)
		ToolController:call("buyTool", self.m_itemId, 1, callfunc, 0, true, false, "UseResToolView")
	end				
end

function UseResToolCell:onUseTool()
	if (not self:getParent()) then return end
	self:refreshData()

	local toolInfo = ToolController:call("getToolInfoByIdForLua", self.m_itemId)
	local itemId = toolInfo:getProperty("itemId")
	if (itemId == 200381) then --ITEM_ADD_STAMINE
		local currentStamine = WorldController:call("getInstance"):getProperty("currentStamine")
		local stamineMax = CCCommonUtilsForLua:call("getFinalStamineMax")
		if (currentStamine >= stamineMax) then
			CCCommonUtilsForLua:call("flyHint", "", "", getLang("103746"))
			return
		end
	end

	local cnt = toolInfo:call("getCNT")
	if (cnt == 1) then
		self:addWaitInterface()
		ToolController:call("useTool", self.m_itemId, 1, true)
	else
		local dict = CCDictionary:create()
		dict:setObject(CCString:create("ToolNumSelectView"), "name")
 		dict:setObject(CCString:create(tostring(self.m_itemId)), "itemId")
 		dict:setObject(CCString:create("0"), "opFrom")
 		dict:setObject(CCString:create(""), "targetId")
 		LuaController:call("openPopViewInLua", dict)
 	end

 	if (cnt <= 0) then
 		self.m_useBtn:setVisible(false)
 		self.m_useBtn:setEnabled(false)

 		local price = toolInfo:getProperty("price")
 		if (price > 0) then
 			self.m_buyNode:setVisible(true)
 			self.m_buyBtn:setEnabled(true)
 		else
 			CCSafeNotificationCenter:call("postNotification", MSG_REFREASH_TOOL_DATA)
 		end
 	end
end

function UseResToolCell:onClickBuyBtnByTouch()
	if self.m_waitInterface then return end

	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	local info = ToolController:call("getToolInfoByIdForLua", self.m_itemId)
	local p = self.m_picNode:convertToWorldSpace(ccp(-55, -55))
	local url = CCCommonUtilsForLua:call("getIcon", tostring(info:getProperty("itemId")))
	local title = info:call("getName")
	local des = getLang(info:getProperty("des"))
	local price = info:getProperty("price")
	local color = info:getProperty("color")
	local function onYes(pObj) self:onYes1(pObj) end
	local handler = self:registerHandler(onYes)	
	local dialog = StoreBuyConfirmDialog:call("showForLua2", url, title, des, price, color, handler, p, WorldResourceType.Gold)
	if (dialog) then
		local gold = playerInfo:getProperty("gold")
		local maxNum = math.floor(gold / price)
		maxNum = math.max(1, maxNum)
		dialog:call("showSliderBar", maxNum)
	end
end

function UseResToolCell:onYes1(pObj)
	local num = 1
	if (pObj) then
		local cInt = tolua.cast(pObj, "CCInteger")
		if (cInt) then
			num = cInt:getValue()
		end
	end

	self.m_itemBuyCount = num

	CCSafeNotificationCenter:call("postNotification", MSG_BUY_CONFIRM_OK_WITHOUT_TWEEN)

	local toolInfo = ToolController:call("getToolInfoByIdForLua", self.m_itemId)
	local itemId = toolInfo:getProperty("itemId")
	if (itemId == 200381) then --ITEM_ADD_STAMINE
		local currentStamine = WorldController:call("getInstance"):getProperty("currentStamine")
		local stamineMax = CCCommonUtilsForLua:call("getFinalStamineMax")
		if (currentStamine >= stamineMax) then
			CCCommonUtilsForLua:call("flyHint", "", "", getLang("103746"))
			return
		end
	end

	self:addWaitInterface()

	if (ToolController:call("isBuyUseOn") and toolInfo:call("getCNT") >= 0) then
		ToolController:call("buyUseTool", self.m_itemId, num, nil, 0, false, "UseResToolView")
	else
		local function callback() self:onUseTool1() end
		local callfunc = cc.CallFunc:create(callback)
		ToolController:call("buyTool", self.m_itemId, num, callfunc, 0, true, false, "UseResToolView")
	end		
end

function UseResToolCell:onUseTool1()
	if (not self:getParent()) then return end
	self:refreshData()

	if (self.m_itemBuyCount > 0) then
		local toolInfo = ToolController:call("getToolInfoByIdForLua", self.m_itemId)
		local itemId = toolInfo:getProperty("itemId")
		if (itemId == 200381) then --ITEM_ADD_STAMINE
			local currentStamine = WorldController:call("getInstance"):getProperty("currentStamine")
			local stamineMax = CCCommonUtilsForLua:call("getFinalStamineMax")

			if (currentStamine >= stamineMax) then
				CCCommonUtilsForLua:call("flyHint", "", "", getLang("103746"))
				return
			end
		end

		local cnt = toolInfo:call("getCNT")
		self.m_numLabel:setString(tostring(cnt))
		if (cnt == 1) then
			self:addWaitInterface()
			ToolController:call("useTool", self.m_itemId, self.m_itemBuyCount, true)
		elseif cnt > 0 then
			local dict = CCDictionary:create()
			dict:setObject(CCString:create("ToolNumSelectView"), "name")
	 		dict:setObject(CCString:create(tostring(self.m_itemId)), "itemId")
	 		dict:setObject(CCString:create("0"), "opFrom")
	 		dict:setObject(CCString:create(""), "targetId")
	 		LuaController:call("openPopViewInLua", dict)
	 	end

	 	if (cnt <= 0) then
	 		self.m_useBtn:setVisible(false)
	 		self.m_useBtn:setEnabled(false)

	 		local price = toolInfo:getProperty("price")
	 		if (price > 0) then
	 			self.m_buyNode:setVisible(true)
	 			self.m_buyBtn:setEnabled(true)
	 		else
	 			CCSafeNotificationCenter:call("postNotification", MSG_REFREASH_TOOL_DATA)
	 		end
	 	end
	end
end

return UseResToolView
