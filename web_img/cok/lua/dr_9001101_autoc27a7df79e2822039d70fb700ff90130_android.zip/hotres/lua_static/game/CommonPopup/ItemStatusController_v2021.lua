--[[
    ItemStatusController_v2021
    新手增益Controller
]]

local _instance = nil
local ItemStatusController_v2021 = class("ItemStatusController_v2021")

function ItemStatusController_v2021.getInstance()
    if not _instance then
        _instance = ItemStatusController_v2021.new()
    end

    return _instance
end

function ItemStatusController_v2021:purge()
	if _instance then
		_instance = nil 
	end
end

function ItemStatusController_v2021:ctor()

end

function ItemStatusController_v2021:initConfig(dataConfig)
    if dataConfig then
        local newPlayer = dataConfig:objectForKey("new_player")
        if newPlayer then
            self.m_endTime = newPlayer:valueForKey("k4"):intValue()
        end
    end
end

function ItemStatusController_v2021:getEndTime()
    if not self.m_buffShowEnd and self.m_endTime then
        self.m_buffShowEnd = self.m_endTime + PlayerInfoController:getRegTime()/1000
    end
    
    return self.m_buffShowEnd or 0
end

return ItemStatusController_v2021
