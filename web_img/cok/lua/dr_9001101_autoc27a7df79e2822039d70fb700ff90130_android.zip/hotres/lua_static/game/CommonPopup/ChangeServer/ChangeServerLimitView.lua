local ChangeServerLimitView = class("ChangeServerLimitView", PopupBaseView)

function ChangeServerLimitView:ctor()
	Drequire("game.CommonPopup.ChangeServer.ChangeServerLimitView_ui"):create(self, 1)
    self:initView()
end

function ChangeServerLimitView:initView()
    self.m_data = {}

    local xmlData = CCCommonUtilsForLua:getGroupByKey("server_transfer_limit")
    for k, v in ipairs4ScatteredT(xmlData) do
        table.insert(self.m_data, v)
    end

    local delegate = {}
    delegate.gridAtIndex = function(tab, idx) return self:gridAtIndex(tab, idx) end
    delegate.numberOfCellsInTableView = function(tab) return self:numberOfCellsInTableView(tab) end
    delegate.numberOfGridsInCell = function(tab) return self:numberOfGridsInCell(tab) end
    delegate.gridSizeForTable = function(tab, idx) return self:gridSizeForTable(tab, idx) end


    self.m_tableView = require("game.utility.TableViewMultiCol").new(self.ui.m_listNode:getContentSize())
    self.m_tableView:setDelegate(delegate)
    self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
    self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
    self.ui.m_listNode:addChild(self.m_tableView)
    self.m_tableView:reloadData()

    self.ui.m_titleLabel:setString(getLang("173349", ""))

    registerTouchHandler(self)
end

function ChangeServerLimitView:onEnter()
	
end

function ChangeServerLimitView:onExit()
	
end

function ChangeServerLimitView:gridAtIndex(tabView, idx)
	if idx >= #self.m_data then return end

	local cell = tabView:dequeueGrid()

	if cell then
		local node = cell:getChildByTag(666)
		if node then node:setData(self.m_data[idx + 1]) end
	else
	 	local node = Drequire("game.CommonPopup.ChangeServer.ChangeServerLimitCell").new(self.m_data[idx + 1])
		node:setTag(666)
		cell = cc.TableViewCell:create()
		cell:addChild(node)
	end

	return cell
end

function ChangeServerLimitView:numberOfCellsInTableView(tabView)
	return math.ceil(#self.m_data / 5)
end

function ChangeServerLimitView:numberOfGridsInCell()
	return 5
end

function ChangeServerLimitView:gridSizeForTable(tabView, idx)
	return 100, 68
end

function ChangeServerLimitView:onCloseButtonClick()
	PopupViewController:call("removePopupView", self)
end

function ChangeServerLimitView:onTouchBegan(x, y)
	self.touchPoint = ccp(x, y)
	return true
end

function ChangeServerLimitView:onTouchEnded(x, y)
	if ccpDistance(self.touchPoint, ccp(x, y)) > 20 then
		return
	end

	if not isTouchInside(self.ui.m_touchNode, x, y) then
		PopupViewController:call("removePopupView", self)
	end
end

return ChangeServerLimitView
