----------------------------
-- Author: Elex
-- Date: 2021-03-19 Friday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local MonthFundView_ui = class("MonthFundView_ui")

--#ui propertys


--#function
function MonthFundView_ui:create(owner, viewType, paramTable)
	local ret = MonthFundView_ui.new()
	CustomUtility:DoRes(7, true)
	CustomUtility:LoadUi("MonthFundView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function MonthFundView_ui:initLang()
end

function MonthFundView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function MonthFundView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function MonthFundView_ui:onBtn9Click(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBtn9Click", pSender, event)
end

function MonthFundView_ui:onBtn19Click(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBtn19Click", pSender, event)
end

function MonthFundView_ui:onBtn49Click(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBtn49Click", pSender, event)
end

function MonthFundView_ui:onBtn99Click(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBtn99Click", pSender, event)
end

function MonthFundView_ui:onHelpBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onHelpBtnClick", pSender, event)
end

function MonthFundView_ui:onBuyBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBuyBtnClick", pSender, event)
end

function MonthFundView_ui:initTableView()
	TableViewSmoker:createView(self, "m_tableView1", "game.CommonPopup.MonthFundView.MonthFundCell", 1, 10, "MonthFundCell")
end

function MonthFundView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return MonthFundView_ui

