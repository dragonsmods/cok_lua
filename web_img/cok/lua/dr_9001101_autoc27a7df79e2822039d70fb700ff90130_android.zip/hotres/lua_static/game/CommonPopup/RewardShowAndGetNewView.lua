--@Description: reward奖励领取展示
--@Params:rewardInfo的元表数据，标题文本;设置回调setCalllBack
--@Author: HanXiaoQiang
--@Date: 2018-05-14 16:02:40
--@LastEditTime: 2019-07-10 15:35:32
local RewardShowAndGetNewView = class("RewardShowAndGetNewView", function (  )
	return PopupBaseView:call("create")
end)

function RewardShowAndGetNewView.create( data, title )
	local ret = RewardShowAndGetNewView.new(data, title)
	Drequire("game.CommonPopup.RewardShowAndGetNewView_ui"):create(ret, 1)
	if ret:initSelf() == false then
		ret = nil
	end
	return ret
end

function RewardShowAndGetNewView:ctor( data, title )
	self.data = data
	self.titlestr = title
	self.callBack = nil
end

function RewardShowAndGetNewView:initSelf( )
    if nil == self.data then
    	return false
    end	
    CCCommonUtilsForLua:call("setButtonTitle", self.m_okBtn, getLang("confirm"))

	self.startTouchPt = cc.p(0, 0)
	self.touchLayer = cc.Layer:create()
	self:addChild(self.touchLayer)
	local function touchHandle( eventType, x, y )
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		else
			self:onTouchEnded(x, y)
		end
	end
	self.touchLayer:registerScriptTouchHandler(touchHandle)
	self.touchLayer:setTouchEnabled(true)
	self.touchLayer:setSwallowsTouches(false)
	self.ui.m_labelTitle:setString(self.titlestr)
	local tblData = {}
	local column = 5
	for i=1,#self.data,column do
		local cellData = {}
		for j=i,i+column-1 do
			if j <= #self.data then
				cellData[#cellData+1] = self.data[j]
			end
		end
		table.insert(tblData, cellData)
	end
	self.ui:setTableViewDataSource("m_tableView",tblData)
	--奖励较少时列表居中
	if #tblData <= 2 then
		self.ui.m_tableView:setTouchEnabled(false)
		self.ui.m_tableView:setPositionY(-123 + 50*(#tblData-3))
	end
    return true
end

function RewardShowAndGetNewView:setCalllBack( call )
	self.callBack = call
end

function RewardShowAndGetNewView:setButtonTitle( str )
	CCCommonUtilsForLua:call("setButtonTitle", self.m_okBtn, str)
end


function RewardShowAndGetNewView:onClickBtnGet(  )
	if nil ~= self.callBack then
		self.callBack()
	end
	self:call("closeSelf")
end


function RewardShowAndGetNewView:onTouchBegan( x, y )
	if isTouchInside(self.ui.m_nodeContent, x, y) then
		return false
	end
	return true
end

function RewardShowAndGetNewView:onTouchEnded( x, y )
	if isTouchInside(self.ui.m_nodeContent, x, y) then
		return
	end
	self:onClickBtnGet()
end

function RewardShowAndGetNewView:onCloseBtnClick(  )
	self:call("closeSelf")
end

return RewardShowAndGetNewView