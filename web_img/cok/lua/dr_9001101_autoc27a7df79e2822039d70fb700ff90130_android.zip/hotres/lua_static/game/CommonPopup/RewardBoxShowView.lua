local RewardBoxShowView = class("RewardBoxShowView",
	function()
		return PopupBaseView:create()
	end
)
RewardBoxShowView.__index = RewardBoxShowView

local RewardBoxShowCell = class("RewardBoxShowCell",
	function()
		return cc.TableViewCell:create()
		-- return cc.Layer:create()
	end
)
RewardBoxShowCell.__index = RewardBoxShowCell

function RewardBoxShowView:create(itemId)
	local view = RewardBoxShowView.new()
	Drequire("game.CommonPopup.RewardBoxShowView_ui"):create(view)
	if view:initView(itemId) then
		return view
	end
end

function RewardBoxShowView:initView(itemId)
	if self:init(true, 0) then
		dump(itemId, "RewardBoxShowView:initView itemId is: ")
		self:setHDPanelFlag(true)

		self.config = dictToLuaTable(LocalController:call("DBXMLManager"):call("getGroupByKey", "convert"))
		self.itemId = itemId
		self.itemInfo = ToolController:call("getToolInfoForLua", itemId)

		self.m_toolNum = self.itemInfo:call("getCNT")

		self.convertId = self.itemInfo:getProperty("para1")
		self.maxSelectNum = tonumber(CCCommonUtilsForLua:getPropByIdGroup("convert", self.convertId, "count"))

		self.rewardInfo = {}		
		local equipmentVec = string.split(CCCommonUtilsForLua:getPropByIdGroup("convert", self.convertId, "equipment"),"|")
		local goodsVec = string.split(CCCommonUtilsForLua:getPropByIdGroup("convert", self.convertId, "goods"),"|")
		local dragonSkillVec = string.split(CCCommonUtilsForLua:getPropByIdGroup("convert", self.convertId, "dragonSkill"),"|")
		local heroBadgeVec = string.split(CCCommonUtilsForLua:getPropByIdGroup("convert", self.convertId, "hero_badge"),"|")
		for k,v in pairs(equipmentVec) do 
			local tmpVec = string.split(v, ";")
			if #tmpVec == 2 then
				local index = #self.rewardInfo+1
				self.rewardInfo[index] = {id = index, toolId = tmpVec[1], num = tmpVec[2],name = "", icon = "", open = false, selected = false, count = 0,}
			end
		end
		for k,v in pairs(goodsVec) do 
			local tmpVec = string.split(v, ";")
			if #tmpVec == 2 then
				self.rewardInfo[#self.rewardInfo+1] = {id = index, toolId = tmpVec[1], num = tmpVec[2],name = "", icon = "", open = false, selected = false, count = 0,}
			end
		end
        if #dragonSkillVec > 0 then
        	 CCLoadSprite:call("loadDynamicResourceByName", "dragonCave")
             CCLoadSprite:call("loadDynamicResourceByName", "dragonCave1")
            for k,v in pairs(dragonSkillVec) do 
				local tmpVec = string.split(v, ";")
				if #tmpVec == 2 then
					self.rewardInfo[#self.rewardInfo+1] = {id = tmpVec[1], num = tmpVec[2], selected = false, open = false,itemType = 3}
				end
			end
		end
		-- R英雄信物
		local hasHeroBadge = false
		for k,v in pairs(heroBadgeVec) do
			local tmpVec = string.split(v, ";")
			if #tmpVec == 2 then
				hasHeroBadge = true
				self.rewardInfo[#self.rewardInfo+1] = {id = tmpVec[1], num = tmpVec[2], selected = false, open = false, itemType = 4}
			end
		end
		if hasHeroBadge then
			CCLoadSprite:call("loadDynamicResourceByName", "hero_badge_face")
		end

		--MyPrint("self.rewardInfo", #self.rewardInfo, #ids, rewardIds)
		if CCCommonUtilsForLua:isIosAndroidPad() then
			self.ui.nodeccb:setScale(2)
		end

		self.selectNum = 0
		self.selectQueue = {}
		self.selectCell = {}

		local desc = self.config[self.convertId] and self.config[self.convertId].desction or ""
		self.ui.m_titleLabel:setString(getLang(desc))

		-- self.ui.m_titleLabel:setString(getLang("175200"))
		-- self.ui.m_desLabel:setString(getLang(desc))
		-- self.ui.m_numLabel:setString(getLang("175201", tostring(self.selectNum), tostring(self.maxSelectNum)))

		local listSize = self.ui.m_listNode:getContentSize()
		self.m_tableView = cc.TableView:create(listSize)
		self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
		self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
		self.m_tableView:setAnchorPoint(ccp(0, 0))
		self.m_tableView:setDelegate()
		self.m_tableView:registerScriptHandler(function(tab) return self:scrollViewDidScroll(tab) end, cc.SCROLLVIEW_SCRIPT_SCROLL)
		self.m_tableView:registerScriptHandler(function(tab, idx) return self:cellSizeForTable(tab, idx) end, cc.TABLECELL_SIZE_FOR_INDEX)
		self.m_tableView:registerScriptHandler(function(tab, idx) return self:tableCellAtIndex(tab, idx) end, cc.TABLECELL_SIZE_AT_INDEX)
		self.m_tableView:registerScriptHandler(function(tab) return self:numberOfCellsInTableView(tab) end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
		self.ui.m_listNode:addChild(self.m_tableView)
		self.m_tableView:reloadData()

		local touchLayer = cc.Layer:create()
		self:addChild(touchLayer)

		local function touchHandle( eventType, x, y )
			if eventType == "began" then
				return self:onTouchBegan(x, y)
			elseif eventType == "moved" then
			
			else
				self:onTouchEnded(x, y)
			end
		end
		touchLayer:registerScriptTouchHandler(touchHandle)
		touchLayer:setTouchEnabled(true)
		touchLayer:setSwallowsTouches(false)

		return true
	end

	return false
end

function RewardBoxShowView:onTouchBegan(x, y)
	self.startPoint = ccp(x, y)
	return true
end

function RewardBoxShowView:onTouchEnded(x, y)
	if ccpDistance(self.startPoint, ccp(x, y)) > 30 then return end

	if not isTouchInside(self.ui.m_clickArea, x, y) then
		PopupViewController:call("removePopupView", self)
	end
end

function RewardBoxShowView:scrollViewDidScroll()
	local mindy = self.m_tableView:minContainerOffset().y
	local dy = self.m_tableView:getContentOffset().y
	if (dy < mindy) then
		self.m_tableView:setContentOffset(ccp(0, mindy))
	end
end

function RewardBoxShowView:cellSizeForTable(tab, idx)
	return 560, 90
end

function RewardBoxShowView:tableCellAtIndex(tab, idx)

	if (idx >= #self.rewardInfo) then
		return nil
	end

	local cell = tab:dequeueCell()
	local reward = self.rewardInfo[idx + 1]
	if (not reward) then
		return nil
	end
	if (cell) then
		cell:setData(reward)
	else
	
		cell = RewardBoxShowCell:create(reward, self)
	end

	-- local reward = self.rewardInfo[idx + 1]
	-- local node = RewardBoxShowCell:create(reward, self)
	-- node:setTag(666)

	-- local cell = cc.TableViewCell:create()
	-- cell:addChild(node)
	return cell
end

function RewardBoxShowView:numberOfCellsInTableView(tab)
	return type(self.rewardInfo) == "table" and #self.rewardInfo or 0
end

function RewardBoxShowView:onEnter()
	-- local function callback1(param) self:closeSelf(param) end
	-- local handler1 = self:registerHandler(callback1)
	-- CCSafeNotificationCenter:registerScriptObserver(self, handler1, MSG_REFREASH_TOOL_DATA)
end

function RewardBoxShowView:onExit()
	-- CCSafeNotificationCenter:unregisterScriptObserver(self, MSG_REFREASH_TOOL_DATA)
end

-----------------------RewardBoxShowCell-----------------------
function RewardBoxShowCell:create(rewardInfo, par)
	local cell = RewardBoxShowCell.new()
	Drequire("game.CommonPopup.RewardBoxShowCell_ui"):create(cell, 1)
	if cell:initCell(rewardInfo, par) then
		return cell
	end
end

function RewardBoxShowCell:initCell(rewardInfo, par)
	self.par = par
	self:setData(rewardInfo)

	local touchLayer = cc.Layer:create()
	self:addChild(touchLayer)

	local function touchHandle( eventType, x, y )
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		
		else
			self:onTouchEnded(x, y)
		end
	end
	touchLayer:registerScriptTouchHandler(touchHandle)
	touchLayer:setTouchEnabled(true)
	touchLayer:setSwallowsTouches(false)

	return true
end

function RewardBoxShowCell:setData(rewardInfo)
	self.rewardInfo = rewardInfo
	-- self.isBox = false

	self.ui.m_iconNode:removeChildByName('hero_badge')
	local name = getLang(rewardInfo.name)
	if self.rewardInfo.toolId ~= "0" then
		local toolInfo = ToolController:call("getToolInfoForLua", tonumber(self.rewardInfo.toolId))
		if toolInfo then
			name = toolInfo:call("getName")
			CCCommonUtilsForLua:call("createGoodsIcon", tonumber(self.rewardInfo.toolId), self.ui.m_iconNode, CCSizeMake(60, 60))
		else
			local eInfo = EquipmentController:call("getInstance"):call("getEquipInfoById", tonumber(self.rewardInfo.toolId)) --EquipmentInfo
			if eInfo then
				name = getLang(eInfo:call("getName"))

				local iconColor = CCCommonUtilsForLua:call("getToolBgByColor", tonumber(eInfo:call("getColor")))
				local iconColorFrame = CCLoadSprite:call("loadResource", iconColor)
				if iconColorFrame then self.ui.m_sprColor:setSpriteFrame(iconColorFrame) end
				CCCommonUtilsForLua:setSpriteMaxSize(self.ui.m_sprColor, 60, true)

				local icon = CCCommonUtilsForLua:call("getIcon", self.rewardInfo.toolId)
				local sf = CCLoadSprite:call("loadResource", icon)
				if sf then self.ui.m_iconSprite:setSpriteFrame(sf) end
			end
		end
	end


	if self.rewardInfo.itemType and self.rewardInfo.itemType == 3 then
		--龙技能
		name = getLang(tostring(CCCommonUtilsForLua:getPropById(self.rewardInfo.id, "name")))

		local icon = CCCommonUtilsForLua:getPropById(self.rewardInfo.id, "icon") .. ".png"
        local quality = CCCommonUtilsForLua:call("getPropById", self.rewardInfo.id, "quality")
        local colorBg = CCCommonUtilsForLua:call("getToolCircleBgByColor", tonumber(quality))  
		local iconColorFrame = CCLoadSprite:call("loadResource", colorBg)
		if iconColorFrame then self.ui.m_sprColor:setSpriteFrame(iconColorFrame) end
		CCCommonUtilsForLua:setSpriteMaxSize(self.ui.m_sprColor, 60, true)
		local sf = CCLoadSprite:call("loadResource", icon)
		if sf then self.ui.m_iconSprite:setSpriteFrame(sf) end

        local desc = CCCommonUtilsForLua:call("getPropById", self.rewardInfo.id, "desc_long")
        local descNum = tonumber(CCCommonUtilsForLua:call("getPropById",  self.rewardInfo.id, "desc_num"))
        local descNumMax = tonumber(CCCommonUtilsForLua:call("getPropById",  self.rewardInfo.id, "desc_num_max")) or 0
        --是否显示百分比
        local descPercent = tonumber(CCCommonUtilsForLua:call("getPropById",  self.rewardInfo.id, "desc_num_percent")) or 0     
        local percentStr = descPercent == 0 and "" or "%"       
        local content1 = getLang(desc, string.format("%.2f", descNum)..percentStr)
        local content2 = descNumMax ~= 0 and "(max"..string.format("%.2f", descNumMax)..percentStr..")" or ""
        desc = content1..content2

        --dump(desc,"self.rewardInfo-----")
		name = name .. "\n" .. desc
	elseif self.rewardInfo.itemType == 4 then
		-- R英雄信物
		local control = HeroBadgeController:getInstance()
		local configModel = control:getConfigModel()
		local config = configModel:getBadgeBaseByHeroBadgeGoodsId(self.rewardInfo.id)

		local HeroBadgeRewardItem = Drequire('game.hero.badge.HeroBadgeRewardItem')
		local item = HeroBadgeRewardItem:create()
		item:refreshCellById(self.rewardInfo.id, 0)
		item:setItemSize(60)
		self.ui.m_iconNode:addChild(item)
		item:setName('hero_badge')

		name = getLang(config.name)
		desc = getLang(config.desc)
		-- name = name .. "\n" .. desc
	end

	self.ui.m_boxNameLabel:setString(name)
	self.ui.m_boxNumLabel:setString("X"..self.rewardInfo.num)
end

function RewardBoxShowCell:onEnter()
end

function RewardBoxShowCell:onExit()
end

function RewardBoxShowCell:onTouchBegan(x, y)
	self.touchPoint = ccp(x, y)
	if isTouchInside(self.ui.m_bgSprite, x, y) and isTouchInside(self.par.ui.m_listNode, x, y) then 
		return true 
	end
	return false
end

function RewardBoxShowCell:onTouchEnded(x, y)
	if ccpDistance(self.touchPoint, ccp(x, y)) > 20 then return end
	if self.rewardInfo.toolId ~= "0" then
		local toolInfo = ToolController:call("getToolInfoForLua", tonumber(self.rewardInfo.toolId))
		if toolInfo then
			local type1 = toolInfo:getProperty("type")
			local para1 = toolInfo:getProperty("para1")
			dump("fubin:RewardBoxShowCell:type1--"..type1.."  para1.."..para1)
			if type1==46 and para1~="" then
				local view = Drequire("game.CommonPopup.RewardBoxShowView"):create(tonumber(self.rewardInfo.toolId))
				PopupViewController:addPopupView(view)
			end
		end
	end
	-- if isTouchInside(self.ui.m_yesBg, x, y) then 
	-- 	self:select()
	-- elseif isTouchInside(self.ui.m_bgSprite, x, y) then 
	-- 	self:open() 
	-- end
end

-----------------------RewardBoxShowCell-----------------------

return RewardBoxShowView