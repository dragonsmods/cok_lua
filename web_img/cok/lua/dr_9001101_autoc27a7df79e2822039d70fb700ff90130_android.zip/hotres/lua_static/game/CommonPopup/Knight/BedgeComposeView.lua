LONGYU_IDS = {}
BEDGE_TYPE = 1
B_CHANGE = true

local knightInstance = KnightTitleController:call("getInstance")
local userDefault = CCUserDefault:sharedUserDefault()
local bedgeViewOpen = false
local bedgeView
local mateIconHeight = 80

local BedgeComposeView = class("BedgeComposeView",
	function()
		return PopupBaseView:create() 
	end
)
BedgeComposeView.__index = BedgeComposeView

BedgeComposeViewOwner = BedgeComposeViewOwner or {}
ccb["BedgeComposeViewOwner"] = BedgeComposeViewOwner

function BedgeComposeView:create(_type)
	bedgeView = BedgeComposeView.new()
	if (bedgeView:initView(_type)) then return bedgeView end
end

function BedgeComposeView.getView()
	if bedgeViewOpen then return bedgeView end
end

function BedgeComposeView:getIsEnough()
	-- 是否有保护
	local needProtecNum = 0
	local mateVec = KnightController.getInstance():getMateVec()
	if mateVec and #mateVec > 0 then
		for k,v in pairs(mateVec) do
			needProtecNum = needProtecNum + self:getOneMateStoneNum(v, false)
		end
	end
	--当前激活的龙语
	local hasActivedNum = 0
	local knightTitleId = KnightTitleController:call("getInstance"):call("getCurrentOnId")
	local kInfo = KnightTitleController:call("getInstance"):call("getKnightInfoById", knightTitleId)
	if kInfo then
		local bedgeIdVec = kInfo:getProperty("mateVec")   	
		if bedgeIdVec and #bedgeIdVec > 0 then
			for k,v in pairs(bedgeIdVec) do
				local isSame = false
				if needProtecNum > 0 then
					for a,b in pairs(mateVec) do
						if b == v then
							isSame = true
							break
						end
					end
				end
				if not isSame then
					hasActivedNum = hasActivedNum + self:getOneMateStoneNum(v, false)
				end
			end
		end
	end
	--当前已有石头数量
	local needNum,haveNum = QuickEquipmentController.getInstance():calculateBedgeNum(mateVec)
	--当前需要石头
	local needOneMateNum = self:getOneMateStoneNum(self.m_bedgeId, true)
    --判断是否足够
	if needOneMateNum <= (haveNum - hasActivedNum - needProtecNum) then
		return true
	else
		return false
	end
end

function BedgeComposeView:getOneMateStoneNum( bedgeId , isCountNowCnt )
	local needOneMateNum = 0
	local toolInfo = ToolController:call("getToolInfoByIdForLua", bedgeId)
	if not toolInfo then
		return needOneMateNum
	end
	if isCountNowCnt then -- 当前合成目标
		local level = (tonumber(toolInfo:getProperty("para5")) or 0) - 1 -- 等级文本
	    if level > 0 then
	        needOneMateNum = math.pow(2,level) -- 换算成1级龙韵石的数量
	    else
	        needOneMateNum = 1
	    end
	    return needOneMateNum
	end
	local cnt = toolInfo:call("getCNT")
	if cnt > 0 then -- 受保护
	    local level = (tonumber(toolInfo:getProperty("para5")) or 0) - 1 -- 等级文本
	    if level > 0 then
	        needOneMateNum = math.pow(2,level) -- 换算成1级龙韵石的数量
	    else
	        needOneMateNum = 1
	    end
	end
    return needOneMateNum
end

function BedgeComposeView:initView(_type)
	BEDGE_TYPE = _type
	if (self:init(true, 0)) then
		self:setIsHDPanel(true)

		CCLoadSprite:call("doResourceByCommonIndex", 306, true)
		CCLoadSprite:call("doResourceByCommonIndex", 305, true)
		CCLoadSprite:call("doResourceByCommonIndex", 100, true)
		CCLoadSprite:call("doResourceByCommonIndex", 11, true)

		local tmpStr = knightInstance:getProperty("DrogenStoneIds")
		local tmpVec = splitString(tmpStr, ";")
		for i = 1, #tmpVec do
			LONGYU_IDS[tmpVec[i]] = 0
		end

		local proxy = cc.CCBProxy:create()
		local ccbUri = "BedgeComposeView_lua.ccbi"
		local node = CCBReaderLoad(ccbUri, proxy, self)

		local function onNodeEvent(event)
			if event == "enter" then
				self:onEnter()
			elseif event == "exit" then
				self:onExit()
			elseif event == "cleanup" then
				self:onCleanup()
 			end
		end
		node:registerScriptHandler(onNodeEvent)
		self:addChild(node)

		local nodeSize = node:getContentSize()
		self:setContentSize(nodeSize)
		self:setTitleName("")

		CCCommonUtilsForLua:setButtonTitle(self.m_tab1, getLang("160303"))
		CCCommonUtilsForLua:setButtonTitle(self.m_tab2, getLang("160304"))
		self.m_markLSpr:setVisible(false)
		self.m_markRSpr:setVisible(false)

		self.m_parPopVec = {}
		self.animationManager = ccb["BedgeComposeViewOwner"]["mAnimationManager"]
		self.m_popLayer = cc.Layer:create()
		self.m_midHNode:getParent():addChild(self.m_popLayer)
		self:changeBGHeight(self.m_buildBG)

		local extH = self:getExtendHeight()
		local winSize = cc.Director:sharedDirector():getIFWinSize()
		CCCommonUtilsForLua:call("makeBatchBG", self.m_bgNode, winSize, ccp(0.5, 1), 1)

		local bagExH = extH * 0.35
		MyPrint("BedgeComposeView:initView, bagExH.." .. bagExH .. ", " ..BEDGE_TYPE)

		local nH = self.m_rzhu:getContentSize().height + (extH - bagExH)
		self.m_lzhu:setScaleY(nH / self.m_lzhu:getContentSize().height)
		self.m_rzhu:setScaleY(self.m_lzhu:getScaleY())

		-- self.m_lNode:setPositionY(self.m_lNode:getPositionY() - (extH - bagExH) * 0.5)
		-- self.m_rNode:setPositionY(self.m_rNode:getPositionY() - (extH - bagExH) * 0.5)

		local lpx, lpy = self.m_lNode:getPosition()
		local linex, liney = self.m_lLine:getPosition()
		local spt = ccp(lpx + linex, lpy + liney)
		local eptx, epty = self.m_midHNode:getPosition()
		local angle = 90 - math.atan2(epty - spt.y, eptx - spt.x) / math.pi * 180
	 	local length = ccpDistance(spt, ccp(eptx, epty))
	 	local pro = length / self.m_lLine:getContentSize().height
	 	self.m_lLine:setRotation(angle)
	 	self.m_lLine:setScaleY(pro)
	 	self.m_rLine:setRotation(-angle)
	 	self.m_rLine:setScaleY(pro)

	 	if (BEDGE_TYPE == 1) then--合并
	 		self.m_tab1:setEnabled(false)
	 		self.m_tab2:setEnabled(true)
	 		CCCommonUtilsForLua:setButtonTitle(self.m_composeBtn, getLang("160303"))
	 	elseif (BEDGE_TYPE == 2) then
	 		self.m_tab1:setEnabled(true)
	 		self.m_tab2:setEnabled(false)
	 		CCCommonUtilsForLua:setButtonTitle(self.m_composeBtn, getLang("160304"))
	 	end

	 	self.m_bPlayEnd = true
	 	self.m_bPostEnd = true
	 	self.m_bedgeId = 0
	 	self.m_key = ""
	 	self.m_batchUseNum = 0

		self.m_rNode:setVisible(true)
		self.m_lNode:setVisible(true)
	 	if CCCommonUtilsForLua:isFunOpenByKey("dragon_words_new_combine") then
			self.m_rNode:setVisible(false)
			self.m_lNode:setVisible(false)
	 		if (CCCommonUtilsForLua:isIosAndroidPad()) then
		 		self.m_midNode:setPositionY(self.m_midNode:getPositionY() + mateIconHeight * 4)
		 		self.node_top:setPositionY(self.node_top:getPositionY() + mateIconHeight * 3)

				self.bedgeBage = myRequire("game.CommonPopup.Knight.BedgeBagNode"):create(self.m_bottomNode:getContentSize().height + mateIconHeight * 4)
				self.m_bagNode:addChild(self.bedgeBage)
	 		else
		 		self.m_midNode:setPositionY(self.m_midNode:getPositionY() + mateIconHeight * 2)
		 		self.node_top:setPositionY(self.node_top:getPositionY() + mateIconHeight)

				self.bedgeBage = myRequire("game.CommonPopup.Knight.BedgeBagNode"):create(self.m_bottomNode:getContentSize().height + mateIconHeight * 2)
				self.m_bagNode:addChild(self.bedgeBage)
			end
		else
			if (CCCommonUtilsForLua:isIosAndroidPad()) then
				self.bedgeBage = myRequire("game.CommonPopup.Knight.BedgeBagNode"):create(self.m_bottomNode:getContentSize().height)
				self.m_bagNode:addChild(self.bedgeBage)
			else
				self.bedgeBage = myRequire("game.CommonPopup.Knight.BedgeBagNode"):create(self.m_bottomNode:getContentSize().height)
				self.m_bagNode:addChild(self.bedgeBage)
			end
	 	end
	 	return true
	end

	return false
end

function BedgeComposeView:onEnter()
	local function callback1(pObj) self:setData(pObj) end
	local function callback2(pObj) self:retData(pObj) end
	local function callback3(pObj) self:banchUseCallBack(pObj) end
	local handler1 = self:registerHandler(callback1)
	local handler2 = self:registerHandler(callback2)
	local handler3 = self:registerHandler(callback3)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, BEDGE_COMPOSE_MSG)
	CCSafeNotificationCenter:registerScriptObserver(self, handler2, MSG_BEDGE_UPDATE)
	CCSafeNotificationCenter:registerScriptObserver(self, handler3, MAG_TOOLNUMSELVIEW_CALLBACK)

	UIComponent:call("showEquipOrBagBtn", 4)
	self:setData()

	local function callback() self:AnimationClose() end
	self.animationManager:setAnimationCompletedCallback(callback)
	self:setTitleName(getLang("160298")) -- 160298=龙韵石
	B_CHANGE = true
	bedgeViewOpen = true
end

function BedgeComposeView:onExit()
	CCSafeNotificationCenter:unregisterScriptObserver(self, BEDGE_COMPOSE_MSG)
	CCSafeNotificationCenter:unregisterScriptObserver(self, MSG_BEDGE_UPDATE)
	CCSafeNotificationCenter:unregisterScriptObserver(self, MAG_TOOLNUMSELVIEW_CALLBACK)

	UIComponent:call("showEquipOrBagBtn", 0)
	local tempMateTbl = {}
	KnightController.getInstance():setMateVec(tempMateTbl, "")
	bedgeViewOpen = false
end

function BedgeComposeView:onCleanup()
	self = nil
end

function BedgeComposeView:retData(pObj)
	self.m_bPostEnd = true

	local function callback1() self:playStartCrtParticle() end
	local fun1 = cc.CallFunc:create(callback1)
	local delay = cc.DelayTime:create(0.5)
	local function callback2() self:updateRetData() end
	local fun2 = cc.CallFunc:create(callback2)
	local sequenceAction = cc.Sequence:create(fun1, delay, fun2)
	self.m_midHNode:runAction(sequenceAction)

	if (self.m_bPostEnd and self.m_bPlayEnd) then
		B_CHANGE = true
	end

	local toolInfo = ToolController:call("getToolInfoByIdForLua", self.m_bedgeId)
	local cnt = toolInfo:call("getCNT")
	if (BEDGE_TYPE == 1) then
		if CCCommonUtilsForLua:isFunOpenByKey("dragon_words_new_combine") then -- 新融合功能
			self.m_batchUseNum = cnt
			self.m_numLabel:setString(self.m_batchUseNum)
		else
			if (self.m_batchUseNum > cnt) then
				self.m_batchUseNum = cnt
				if (self.m_batchUseNum % 2 == 1) then
					self.m_batchUseNum = self.m_batchUseNum - 1
				end
			end

			self.m_numLabel:setString(tostring(self.m_batchUseNum / 2))
			if CCCommonUtilsForLua:isFunOpenByKey("dragon_words_new_combine") then -- 新融合功能
				self.m_numLabel:setString(self.m_batchUseNum)
			end
		end
	else
		if (self.m_batchUseNum > cnt) then
			self.m_batchUseNum = cnt
		end

		self.m_numLabel:setString(tostring(self.m_batchUseNum))
	end
end

function BedgeComposeView:setData(pObj)
	if ((not self.m_bPostEnd) or (not self.m_bPlayEnd)) then return end

	if (pObj) then
		local ccStr = tolua.cast(pObj, "CCString")
		if (ccStr) then self.m_bedgeId = ccStr:intValue() end
	else
		self.m_composeBtn:setEnabled(false)
		return
	end

	self.m_s1BedgeNode:removeAllChildren()
	self.m_s2BedgeNode:removeAllChildren()
	self.m_pBedgeNode:removeAllChildren()
	self.m_pTitleLabel:setString("")
	self.m_s1TitleLabel:setString("")
	self.m_s2TitleLabel:setString("")
	self.m_numLabel:setString("")

	if (self.m_bedgeId == 0) then
		self.m_composeBtn:setEnabled(false)
		return
	end

	local hasUseNum = knightInstance:call("GetUseBedgeById", self.m_bedgeId)
	self.m_composeBtn:setEnabled(true)

	if (BEDGE_TYPE == 1) then --合并
		self.m_markLSpr:setVisible(true)
		self.m_markRSpr:setVisible(true)

		local toolInfo = ToolController:call("getToolInfoByIdForLua", self.m_bedgeId)
		local cnt = toolInfo:call("getCNT")

		local iconStr = CCCommonUtilsForLua:call("getIcon", tostring(self.m_bedgeId))
		local icon1 = CCLoadSprite:call("createSprite", iconStr, CCLoadSpriteType_GOODS)
		CCCommonUtilsForLua:setSpriteMaxSize(icon1, 75, true)
		icon1:setTag(0)
		self.m_s1BedgeNode:addChild(icon1)

		local icon2 = CCLoadSprite:call("createSprite", iconStr, CCLoadSpriteType_GOODS)
		CCCommonUtilsForLua:setSpriteMaxSize(icon2, 75, true)
		icon2:setTag(0)
		self.m_s2BedgeNode:addChild(icon2)

		if (cnt < 2) then
			icon2:setVisible(false)
			self.m_composeBtn:setEnabled(false)
			self.m_markRSpr:setVisible(false)
		end

		local para4 = toolInfo:getProperty("para4")
		self.m_s1TitleLabel:setString(getLang(para4))
		self.m_s2TitleLabel:setString(getLang(para4))

		
		if CCCommonUtilsForLua:isFunOpenByKey("dragon_words_new_combine") then -- 新融合功能
			self.m_pTitleLabel:setString(getLang(para4))

			local pIcon = CCLoadSprite:call("createSprite", iconStr, CCLoadSpriteType_GOODS)
			CCCommonUtilsForLua:setSpriteMaxSize(pIcon, 120, true)
			pIcon:setTag(0)
			self.m_pBedgeNode:addChild(pIcon)

			local fadeto1 = cc.FadeTo:create(0.5, 0)
			local fadeto2 = cc.FadeTo:create(0.5, 180)
			local sequence = cc.Sequence:create(fadeto1, fadeto2)
			pIcon:runAction(cc.RepeatForever:create(sequence))

			self.m_batchUseNum = cnt
			self.m_numLabel:setString(self.m_batchUseNum)
			Dprint("self.m_bedgeId ", self.m_bedgeId)
			if tostring(self.m_bedgeId) == "209861" then
				self.m_composeBtn:setEnabled(false)
			else
				self.m_composeBtn:setEnabled(true)
			end
		else
			if (userDefault:getBoolForKey("sel")) then
				self.m_batchUseNum = cnt - hasUseNum
				if (self.m_batchUseNum % 2 == 1) then
					self.m_batchUseNum = self.m_batchUseNum - 1
				end
			else
				self.m_batchUseNum = 2
				if (self.m_batchUseNum > (cnt - hasUseNum)) then
					self.m_batchUseNum = 0
				end

				userDefault:setBoolForKey("sel", true)
				userDefault:flush()
			end

			local para2 = toolInfo:getProperty("para2")
			local pInfo = ToolController:call("getToolInfoByIdForLua", atoi(para2))
			local para4 = pInfo:getProperty("para4")
			self.m_pTitleLabel:setString(getLang(para4))

			local pIconStr = CCCommonUtilsForLua:call("getIcon", para2)
			local pIcon = CCLoadSprite:call("createSprite", pIconStr, CCLoadSpriteType_GOODS)
			CCCommonUtilsForLua:setSpriteMaxSize(pIcon, 120, true)
			pIcon:setTag(0)
			self.m_pBedgeNode:addChild(pIcon)

			local fadeto1 = cc.FadeTo:create(0.5, 0)
			local fadeto2 = cc.FadeTo:create(0.5, 180)
			local sequence = cc.Sequence:create(fadeto1, fadeto2)
			pIcon:runAction(cc.RepeatForever:create(sequence))


			self.m_numLabel:setString(tostring(self.m_batchUseNum / 2))
		end
	elseif (BEDGE_TYPE == 2) then
		local toolInfo = ToolController:call("getToolInfoByIdForLua", self.m_bedgeId)
		local iconStr = CCCommonUtilsForLua:call("getIcon", tostring(self.m_bedgeId))
		local icon1 = CCLoadSprite:call("createSprite", iconStr, CCLoadSpriteType_GOODS)
		CCCommonUtilsForLua:setSpriteMaxSize(icon1, 120, true)
		icon1:setTag(0)
		self.m_pBedgeNode:addChild(icon1)

		local para4 = toolInfo:getProperty("para4")
		self.m_pTitleLabel:setString(getLang(para4))

		local para3 = toolInfo:getProperty("para3")
		local sInfo = ToolController:call("getToolInfoByIdForLua", atoi(para3))
		local sPara4 = sInfo:getProperty("para4")
		self.m_s1TitleLabel:setString(getLang(sPara4))
		self.m_s2TitleLabel:setString(getLang(sPara4))

		local cIconStr = CCCommonUtilsForLua:call("getIcon", para3)
		local cIcon1 = CCLoadSprite:call("createSprite", cIconStr, CCLoadSpriteType_GOODS)
		CCCommonUtilsForLua:setSpriteMaxSize(cIcon1, 75, true)
		cIcon1:setTag(0)
		self.m_s1BedgeNode:addChild(cIcon1)

		local cIcon2 = CCLoadSprite:call("createSprite", cIconStr, CCLoadSpriteType_GOODS)
		CCCommonUtilsForLua:setSpriteMaxSize(cIcon2, 75, true)
		cIcon2:setTag(0)
		self.m_s2BedgeNode:addChild(cIcon2)

		local fadeto1 = cc.FadeTo:create(0.5, 0)
		local fadeto2 = cc.FadeTo:create(0.5, 180)
		local sequence = cc.Sequence:create(fadeto1, fadeto2)
		cIcon1:runAction(cc.RepeatForever:create(sequence))

		local rfadeto1 = cc.FadeTo:create(0.5, 0)
		local rfadeto2 = cc.FadeTo:create(0.5, 180)
		local rsequence = cc.Sequence:create(rfadeto1, rfadeto2)
		cIcon2:runAction(cc.RepeatForever:create(rsequence))

		self.m_cr1Spr:setOpacity(225)
		self.m_cr1Spr:setColor(cc.c3b(255, 255, 255))
		self.m_cr2Spr:setOpacity(225)
		self.m_cr2Spr:setColor(cc.c3b(255, 255, 255))
		self.m_cr3Spr:setOpacity(225)
		self.m_cr3Spr:setColor(cc.c3b(255, 255, 255))
		self.m_cr4Spr:setOpacity(225)
		self.m_cr4Spr:setColor(cc.c3b(255, 255, 255))

		self.m_batchUseNum = 1
		self.m_numLabel:setString(tostring(self.m_batchUseNum))
	end
end

function BedgeComposeView:banchUseCallBack(pObj)
	if (pObj) then
		local ccStr = tolua.cast(pObj, "CCString")
		if (ccStr) then
			self.m_batchUseNum = ccStr:intValue()
		end
	end

	if (BEDGE_TYPE == 2) then
		self.m_numLabel:setString(tostring(self.m_batchUseNum))
	else
		self.m_numLabel:setString(tostring(self.m_batchUseNum / 2))
	end
	if CCCommonUtilsForLua:isFunOpenByKey("dragon_words_new_combine") then -- 新融合功能
		self.m_numLabel:setString(self.m_batchUseNum)
	end
	self:lastSend()
end

function BedgeComposeView:getGuideNode(key)
	if (key == "Bedge_Compose") then
		self.m_key = key
		if (CCCommonUtilsForLua:isIosAndroidPad()) then
			local node = cc.Node:create()
			local compBtnSize = self.m_composeBtn:getContentSize()
			node:setContentSize(cc.size(compBtnSize.width * 2.4, compBtnSize.height * 2.4))
			node:setAnchorPoint(ccp(0.5, 0.5))
			node:setPosition(self.m_composeBtn:getPosition())
			self.m_composeBtn:getParent():addChild(node)
			return node
		else
			return self.m_composeBtn
		end
	elseif (key == "Bedge_Sel") then
		self.m_key = key
		return self.bedgeBage:getGuideNode(key)
	elseif (key == "AC_back") then
		return UIComponent:call("getInstance"):getProperty("m_popupReturnBtn")
	end
end

function BedgeComposeView:onClickComposeBtn()
	Dprint("@@ ---- ",self.m_key)
	if (self.m_key == "Bedge_Compose") then
		self:lastSend()
	else
		self:onClickBatchBtn()
	end
end

function BedgeComposeView:lastSend()
	if (self.m_bedgeId == 0) then return end

	if CCCommonUtilsForLua:isFunOpenByKey("dragon_words_new_combine") then
		--提示石头不够，去购买
		if self:checkIsEnough() then
			knightInstance:call("startComposeBedge", self.m_bedgeId, 1, tostring(KnightController.getInstance():getMateId()))
		end
		return
	end
	local info = ToolController:call("getToolInfoByIdForLua", self.m_bedgeId)
	local cnt = info:call("getCNT")
	if (cnt <= 0) then
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("160325")) --提示材料不足
		return
	end

	if (BEDGE_TYPE == 1) then--合成
		if (cnt <= 2) then
			local ret = knightInstance:call("GetUseBedgeById", self.m_bedgeId)
			if (ret > 0) then
				--local kid = knightInstance:getProperty("m_curKnightTitleId")
				local kid = knightInstance:call("getCurrentOnId")
				local kName = CCCommonUtilsForLua:call("getNameById", tostring(kid))
				local fInfo = getLang("160301", info:call("getName"), kName) -- {0}正用于激活龙语：{1}\n需要先取消当前龙语的激活状态
				CCCommonUtilsForLua:call("flyHint", "", "", fInfo) --现在激活中的龙语正在使用
				return
			end
		end

		if (cnt < 2) then
			CCCommonUtilsForLua:call("flyHint", "", "", getLang("160325")) --提示材料不足
			return
		end

		local para2 = info:getProperty("para2")
		if (para2 ~= "") then
			if (LONGYU_IDS[para2] == nil) then --//未解锁的不会显示
				CCCommonUtilsForLua:call("flyHint", "", "", getLang("160329")) --等级不足未解锁
				return
			end
		else
			CCCommonUtilsForLua:call("flyHint", "", "", getLang("160329")) --到达最大了 不能合成
			return
		end
	elseif (BEDGE_TYPE == 2) then --分解
		if (cnt == 1) then
			local ret = knightInstance:call("GetUseBedgeById", self.m_bedgeId)
			if (ret > 0) then
				--local kid = knightInstance:getProperty("m_curKnightTitleId")
				local kid = knightInstance:call("getCurrentOnId")
				local kName = CCCommonUtilsForLua:call("getNameById", tostring(kid))
				local fInfo = getLang("160301", info:call("getName"), kName)
				CCCommonUtilsForLua:call("flyHint", "", "", fInfo) --现在激活中的龙语正在使用
				return
			end
		end

		if (info:getProperty("para3") == "") then
			CCCommonUtilsForLua:call("flyHint", "", "", getLang("160328")) --最小不能分解
			return
		end
	end

	if (self.m_key == "Bedge_Compose") then
		CCSafeNotificationCenter:postNotification(GUIDE_INDEX_CHANGE, CCString:create(self.m_key))
	end

	if (self.m_bPostEnd) then
		if (BEDGE_TYPE == 1) then
			self.m_bPostEnd = false
			B_CHANGE = false
			if (self.m_batchUseNum < 2) then
				self.m_batchUseNum = 2
			end

			if (self.m_batchUseNum % 2 == 1) then
				self.m_batchUseNum = self.m_batchUseNum - 1
			end

			knightInstance:call("startComposeBedge", self.m_bedgeId, self.m_batchUseNum)
			--AdjustII:ComposeTalisman
		    local param = {bedgeId = self.m_bedgeId, amount = self.m_batchUseNum}
		    sendAdjustStatistic("ComposeTalisman", param)
		elseif (BEDGE_TYPE == 2) then
			self.m_bPostEnd = false
			B_CHANGE = false
			if (self.m_batchUseNum < 1) then
				self.m_batchUseNum = 1
			end
			knightInstance:call("startDecBedge", self.m_bedgeId, self.m_batchUseNum)
			--AdjustII:DecomposeTalisman
		    local param = {bedgeId = self.m_bedgeId, amount = self.m_batchUseNum}
		    sendAdjustStatistic("DecomposeTalisman", param)
		end
	end

	if (self.m_bPlayEnd) then
		if (BEDGE_TYPE == 1) then
			self.m_bPlayEnd = false
			B_CHANGE = false
			self.animationManager:runAnimationsForSequenceNamed("compose")
		elseif (BEDGE_TYPE == 2) then
			self.m_bPlayEnd = false
			B_CHANGE = false
			self.animationManager:runAnimationsForSequenceNamed("uncompose")
		end
	end
end

function BedgeComposeView:checkIsEnough(  )
	--提示石头不够，去购买
	if not self:getIsEnough() then
		-- 前往获取龙韵石
		local itemId = 209861
        local ItemGetMethodView = Drequire("game.CommonPopup.ItemGetMethodView")
        local view = ItemGetMethodView:create(itemId)
		PopupViewController:call("addPopupView", view)
		return false
	end
	return true
end

function BedgeComposeView:onClickBatchBtn()
	if BEDGE_TYPE == 1 and FunOpenController:isUnlock("fun_dragonStoneSyn", true) == false then
		return
	end
	if BEDGE_TYPE == 2 and FunOpenController:isUnlock("fun_dragonStoneDis", true) == false then
		return
	end

	local isInTutorial = GuideController:call("isInTutorial")
	if ( (not isInTutorial) and (self.m_bedgeId > 0) ) then
		if CCCommonUtilsForLua:isFunOpenByKey("dragon_words_new_combine") then
			if self:checkIsEnough() then
				knightInstance:call("startComposeBedge", self.m_bedgeId, 1, tostring(KnightController.getInstance():getMateId()))
			end
			return
		end
		local info = ToolController:call("getToolInfoByIdForLua", self.m_bedgeId)
		local cnt = info:call("getCNT")
		if (cnt <= 0) then
			CCCommonUtilsForLua:call("flyHint", "", "", getLang("160325")) --提示材料不足
			return
		end

		if (BEDGE_TYPE == 1) then --合成
			if (cnt <= 2) then
				local ret = knightInstance:call("GetUseBedgeById", self.m_bedgeId)
				if (ret > 0) then
					--local kid = knightInstance:getProperty("m_curKnightTitleId")
					local kid = knightInstance:call("getCurrentOnId")
					local kName = CCCommonUtilsForLua:call("getNameById", tostring(kid))
					local fInfo = getLang("160301", info:call("getName"), kName)
					CCCommonUtilsForLua:call("flyHint", "", "", fInfo) --现在激活中的龙语正在使用
					return
				end
			end

			if (cnt < 2) then
				CCCommonUtilsForLua:call("flyHint", "", "", getLang("160325")) --提示材料不足
				return
			end

			local para2 = info:getProperty("para2")
			if (para2 ~= "") then
				if (LONGYU_IDS[para2] == nil) then --未解锁的不会显示
					CCCommonUtilsForLua:call("flyHint", "", "", getLang("160329")) --等级不足未解锁
					return
				end
			else
				CCCommonUtilsForLua:call("flyHint", "", "", getLang("160329")) --到达最大了 不能合成
				return
			end
		elseif (BEDGE_TYPE == 2) then--分解
			if (cnt == 1) then
				local ret = knightInstance:call("GetUseBedgeById", self.m_bedgeId)
				if (ret > 0) then
					--local kid = knightInstance:getProperty("m_curKnightTitleId")
					local kid = knightInstance:call("getCurrentOnId")
					local kName = CCCommonUtilsForLua:call("getNameById", tostring(kid))
					local fInfo = getLang("160301", info:call("getName"), kName)
					CCCommonUtilsForLua:call("flyHint", "", "", fInfo) --现在激活中的龙语正在使用
					return
				end
			end

			if (info:getProperty("para3") == "") then
				CCCommonUtilsForLua:call("flyHint", "", "", getLang("160328")) --最小不能分解
				return
			end
		end

		local opFrom = 0
		if (BEDGE_TYPE == 1) then
			opFrom = 21
		elseif (BEDGE_TYPE == 2) then
			opFrom = 22
		end

		local dict = CCDictionary:create()
		dict:setObject(CCString:create("ToolNumSelectView"), "name")
 		dict:setObject(CCString:create(tostring(self.m_bedgeId)), "itemId")
 		dict:setObject(CCString:create(tostring(opFrom)), "opFrom")
 		dict:setObject(CCString:create(""), "targetId")
 		LuaController:call("openPopViewInLua", dict)
 	end
end

function BedgeComposeView:AnimationClose()
	self.m_bPlayEnd = true
	if (self.m_bPostEnd and self.m_bPlayEnd) then
		B_CHANGE = true
	end
end

function BedgeComposeView:onClickTab1()
	BEDGE_TYPE = 1
	self.m_tab1:setEnabled(false)
	self.m_tab2:setEnabled(true)
	self.m_s1BedgeNode:removeAllChildren()
	self.m_s2BedgeNode:removeAllChildren()
	self.m_pBedgeNode:removeAllChildren()
	self.m_pTitleLabel:setString("")
	self.m_s1TitleLabel:setString("")
	self.m_s2TitleLabel:setString("")
	self.m_bedgeId = 0

	CCCommonUtilsForLua:setButtonTitle(self.m_composeBtn, getLang("160303"))
	CCSafeNotificationCenter:postNotification(BEDGE_COMPOSE_MSG, CCString:create(tostring(self.m_bedgeId)))
	
	self.m_markLSpr:setVisible(false)
	self.m_markRSpr:setVisible(false)

	self.m_cr1Spr:setOpacity(0)
	self.m_cr2Spr:setOpacity(0)
	self.m_cr3Spr:setOpacity(0)
	self.m_cr4Spr:setOpacity(0)
end

function BedgeComposeView:onClickTab2()
	BEDGE_TYPE = 2
	self.m_tab1:setEnabled(true)
	self.m_tab2:setEnabled(false)
	self.m_s1BedgeNode:removeAllChildren()
	self.m_s2BedgeNode:removeAllChildren()
	self.m_pBedgeNode:removeAllChildren()
	self.m_pTitleLabel:setString("")
	self.m_s1TitleLabel:setString("")
	self.m_s2TitleLabel:setString("")
	self.m_bedgeId = 0

	CCCommonUtilsForLua:setButtonTitle(self.m_composeBtn, getLang("160304"))
	CCSafeNotificationCenter:postNotification(BEDGE_COMPOSE_MSG, CCString:create(tostring(self.m_bedgeId)))
	
	self.m_markLSpr:setVisible(false)
	self.m_markRSpr:setVisible(false)
end

function BedgeComposeView:onHelpBtnClick()
	FaqHelper:call("showSingleFAQ", "45225")
end

function BedgeComposeView:addPopParticleToBatch(particle)
	local batchCount = #self.m_parPopVec
	while(batchCount > 0) 
	do
		local batch = self.m_parPopVec[batchCount]
		if (batch) then
			local batchBlend = batch:getBlendFunc()
			local particleBlend = particle:getBlendFunc()
			if (batchBlend.src == particleBlend.src
				and batchBlend.dst == particleBlend.dst) then
				batch:addChild(particle)
				return
			end
		end
		batchCount = batchCount - 1
	end

	local newBatch = ParticleController:call("createParticleBatch")
	self.m_popLayer:addChild(newBatch)
	newBatch:addChild(particle)
	self.m_parPopVec[#self.m_parPopVec + 1] = newBatch
end

function BedgeComposeView:removeParticle()
	self.m_popLayer:removeAllChildren()
	self.m_parPopVec = {}
end

function BedgeComposeView:playStartCrtParticle()
	self:removeParticle()

	local count = 4
	local tmpStart = "Crown_"
	for i = 1, count do
		if (BEDGE_TYPE == 1) then
			local particlel = ParticleController:call("createParticle", tmpStart .. i)
			particlel:setPosition(self.m_lNode:getPosition())
			self:addPopParticleToBatch(particlel)

			local particler = ParticleController:call("createParticle", tmpStart .. i)
			particler:setPosition(self.m_rNode:getPosition())
			self:addPopParticleToBatch(particler)
		else
			local particler = ParticleController:call("createParticle", tmpStart .. i)
			particler:setPosition(self.m_midHNode:getPosition())
			self:addPopParticleToBatch(particler)
		end
	end

	tmpStart = "CollectionIn_"
	count = 8
	for i = 1, count do
		if (BEDGE_TYPE == 1) then
			local particle = ParticleController:call("createParticle", tmpStart .. i)
			particle:setPosition(self.m_midHNode:getPosition())
			self:addPopParticleToBatch(particle)
		else
			local particlel = ParticleController:call("createParticle", tmpStart .. i)
			particlel:setPosition(self.m_lNode:getPosition())
			self:addPopParticleToBatch(particlel)

			local particler = ParticleController:call("createParticle", tmpStart .. i)
			particler:setPosition(self.m_rNode:getPosition())
			self:addPopParticleToBatch(particler)
		end
	end
end

function BedgeComposeView:updateRetData()
	self:removeParticle()

	--合成完成飘字特效
	if (BEDGE_TYPE == 1) then
		local info = ToolController:call("getToolInfoByIdForLua", self.m_bedgeId)
		local iconStr = CCCommonUtilsForLua:call("getIcon", tostring(self.m_bedgeId))
		local para2 = info:getProperty("para2")
		local pInfo = ToolController:call("getToolInfoByIdForLua", atoi(para2))

		local mateName = pInfo:call("getName")
		local flyStr = getLang("111663", mateName)
		CCCommonUtilsForLua:call("flyUiResText", flyStr, self.m_midHNode, ccp(0, 0), cc.c3b(235, 146, 0), 2, 23)

		local spr = tolua.cast(self.m_pBedgeNode:getChildByTag(0), "cc.Sprite")	
		if (spr) then
			spr:stopAllActions()
			spr:setOpacity(225)
		end

		local scaleto1 = cc.ScaleTo:create(0.3, 2)
		local scaleto2 = cc.ScaleTo:create(0.3, 1)
		local function callback() self:flyEndM() end
		local funcall = cc.CallFunc:create(callback)
		local sequence = cc.Sequence:create(scaleto1, scaleto2, funcall)
		self.m_pBedgeNode:runAction(sequence)
	elseif (BEDGE_TYPE == 2) then
		local info = ToolController:call("getToolInfoByIdForLua", self.m_bedgeId)
		local iconStr = CCCommonUtilsForLua:call("getIcon", tostring(self.m_bedgeId))
		local para3 = info:getProperty("para3")
		local sInfo = ToolController:call("getToolInfoByIdForLua", atoi(para3))
		local mateName = sInfo:call("getName")
		local flyStr = getLang("160375", mateName)
		CCCommonUtilsForLua:call("flyUiResText", flyStr, self.m_lNode, ccp(0, 0), cc.c3b(235, 146, 0), 2, 23)
		CCCommonUtilsForLua:call("flyUiResText", flyStr, self.m_rNode, ccp(0, 0), cc.c3b(235, 146, 0), 2, 23)

		local spr = tolua.cast(self.m_s1BedgeNode:getChildByTag(0), "cc.Sprite")	
		if (spr) then
			spr:stopAllActions()
			spr:setOpacity(225)
		end

		local scaleto1 = cc.ScaleTo:create(0.3, 2)
		local scaleto2 = cc.ScaleTo:create(0.3, 1)
		local function callback() self:flyEndL() end
		local funcall = cc.CallFunc:create(callback)
		local sequence = cc.Sequence:create(scaleto1, scaleto2, funcall)
		self.m_s1BedgeNode:runAction(sequence)

		local spr = tolua.cast(self.m_s2BedgeNode:getChildByTag(0), "cc.Sprite")	
		if (spr) then
			spr:stopAllActions()
			spr:setOpacity(225)
		end

		local scaleto1 = cc.ScaleTo:create(0.3, 2)
		local scaleto2 = cc.ScaleTo:create(0.3, 1)
		local function callback() self:flyEndR() end
		local funcall = cc.CallFunc:create(callback)
		local sequence = cc.Sequence:create(scaleto1, scaleto2, funcall)
		self.m_s2BedgeNode:runAction(sequence)
	end
end

function BedgeComposeView:flyEndM()
	local spr = tolua.cast(self.m_pBedgeNode:getChildByTag(0), "cc.Sprite")	
	if (spr) then
		local fadeto1 = cc.FadeTo:create(0.5, 0)
		local fadeto2 = cc.FadeTo:create(0.5, 180)
		local sequence = cc.Sequence:create(fadeto1, fadeto2)
		spr:runAction(cc.RepeatForever:create(sequence))
	end
end

function BedgeComposeView:flyEndL()
	local spr = tolua.cast(self.m_s1BedgeNode:getChildByTag(0), "cc.Sprite")	
	if (spr) then
		local fadeto1 = cc.FadeTo:create(0.5, 0)
		local fadeto2 = cc.FadeTo:create(0.5, 180)
		local sequence = cc.Sequence:create(fadeto1, fadeto2)
		spr:runAction(cc.RepeatForever:create(sequence))
	end
end

function BedgeComposeView:flyEndR()
	local spr = tolua.cast(self.m_s2BedgeNode:getChildByTag(0), "cc.Sprite")	
	if (spr) then
		local fadeto1 = cc.FadeTo:create(0.5, 0)
		local fadeto2 = cc.FadeTo:create(0.5, 180)
		local sequence = cc.Sequence:create(fadeto1, fadeto2)
		spr:runAction(cc.RepeatForever:create(sequence))
	end
end

return BedgeComposeView

