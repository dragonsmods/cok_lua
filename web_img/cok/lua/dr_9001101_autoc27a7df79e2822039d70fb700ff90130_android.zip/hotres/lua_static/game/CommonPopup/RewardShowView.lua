RewardShowView = class("RewardShowView", function (  )
	return PopupBaseView:call("create")
end)
RewardShowCell = class("RewardShowCell", function (  )
	return cc.TableViewCell:create()
end)

--增加参数newCCB,选择新的ccb界面 "RewardShowView_new"
function RewardShowView.createEx(params)
	local ret = RewardShowView.new(params.data, params.title, params.canReceive, params.callback,params.newCCB, params.tipsText)
	if ret:initSelf() == false then
		ret = nil
	end
	return ret
end

function RewardShowView.create( data, title, canReceive, callback )
	local ret = RewardShowView.new(data, title, canReceive, callback)
	if ret:initSelf() == false then
		ret = nil
	end
	return ret
end

function RewardShowView:ctor( data, title, canReceive, callback, newCCB,tipsText )
	self.data = data
	self.titlestr = title
	self.canReceive = canReceive or false
	self.callback = callback
	self.selectNewCCB = newCCB or false
	self.tipsText = tipsText
end

function RewardShowView:initSelf(  )
	MyPrint("RewardShowView:initSelf")
	if self:init(true, 0) == false then
		MyPrint("RewardShowView init error")
    	return false	
	end
	self:setHDPanelFlag(true)

	local winsize = cc.Director:getInstance():getIFWinSize()

	self:setContentSize(winsize)

	local proxy = cc.CCBProxy:create()
    local ccbiUrl = self.selectNewCCB and "RewardShowView_new" or "RewardShowView"
	local node = CCBReaderLoad(ccbiUrl, proxy, self)
    self:addChild(node)

    if CCCommonUtilsForLua:call("isIosAndroidPad") then
    	self.m_mainNode:setScale(2)
    end
    if nil == self.data then
    	return false
    end
	-- dump(self.data, "self.data")
	if self.tipsText and self.selectNewCCB then
		self.m_tipsLabel:setString(self.tipsText)
	end

	if self.canReceive then
    	self.m_receiveBtn:setVisible(true)
		CCCommonUtilsForLua:setButtonTitle(self.m_receiveBtn, getLang("101313"))
		if not self.selectNewCCB then
			self.m_listNode:setContentSize(cc.size(500, 600))
		end
    else
    	self.m_receiveBtn:setVisible(false)
    end

    self.m_tableView = cc.TableView:create(self.m_listNode:getContentSize())
	self.m_listNode:addChild(self.m_tableView)
	self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
	self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
	self.m_tableView:setDelegate()
	local function scrollViewDidScroll( view )
		return self:scrollViewDidScroll(view)
	end

	local function cellSizeForTable( view, idx )
		return self:cellSizeForTable(view, idx)
	end

	local function tableCellAtIndex( view, idx )
		return self:tableCellAtIndex(view, idx)
	end

	local function numberOfCellsInTableView( view )
		return self:numberOfCellsInTableView(view)
	end

	self.m_tableView:registerScriptHandler(scrollViewDidScroll,cc.SCROLLVIEW_SCRIPT_SCROLL)
	self.m_tableView:registerScriptHandler(cellSizeForTable,cc.TABLECELL_SIZE_FOR_INDEX)
	self.m_tableView:registerScriptHandler(tableCellAtIndex,cc.TABLECELL_SIZE_AT_INDEX)
	self.m_tableView:registerScriptHandler(numberOfCellsInTableView,cc.NUMBER_OF_CELLS_IN_TABLEVIEW)

	self.m_tableView:setAnchorPoint(cc.p(0, 0))
	self.m_tableView:reloadData()
	self.m_tableView:setContentOffset(cc.p(0, self.m_listNode:getContentSize().height - self.m_tableView:getContentSize().height))


	self.startTouchPt = cc.p(0, 0)
	self.touchLayer = cc.Layer:create()
	self:addChild(self.touchLayer)
	local function touchHandle( eventType, x, y )
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		else
			self:onTouchEnded(x, y)
		end
	end
	self.touchLayer:registerScriptTouchHandler(touchHandle)
	self.touchLayer:setTouchEnabled(true)
	self.touchLayer:setSwallowsTouches(false)


	self.m_titleLabel:setString(self.titlestr)

    return true
end

function RewardShowView:scrollViewDidScroll( view )
	
end

function RewardShowView:cellSizeForTable( view, idx )
	if self.selectNewCCB then
		return 490, 60
	else
		return 550, 60
	end
end

function RewardShowView:tableCellAtIndex( view, idx )
	idx = idx+1
    if idx > #self.data then
		return nil
    end
    local cell = view:dequeueCell()
    if cell ~= nil then 
		cell:setData(self.data[idx])
    else
        cell = RewardShowCell.new(self.data[idx])
    end
    return cell
end

function RewardShowView:numberOfCellsInTableView( view )
	return #self.data
end

function RewardShowView:onTouchBegan( x, y )
	if isTouchInside(self.m_touchNode, x, y) then
		return false
	end
	return true
end

function RewardShowView:onTouchEnded( x, y )
	if isTouchInside(self.m_touchNode, x, y) then
		return
	end
	self:call("closeSelf")
end

function RewardShowView:onCloseBtnClick(  )
	self:call("closeSelf")
end

function RewardShowView:onReveiveBtnClick()
	if self.callback then self.callback() end
	self:call("closeSelf")
end

function RewardShowCell:ctor( data )
	MyPrint("RewardShowCell:ctor")
	dump(data, "data")
	
	local proxy = cc.CCBProxy:create()
    local ccbiUrl = "RewardShowCell"
	local node = CCBReaderLoad(ccbiUrl, proxy, self)
    self:addChild(node)


    self:setData(data)

end

function RewardShowCell:setData( data )
	MyPrint("RewardShowCell:setData", data)
	dump(data, "data")
	if nil == data then
		return
	end
	self.m_iconNode:removeAllChildren()
	self.m_sprChestBg:setVisible(true)
	self.m_nameLabel:setHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
	self.m_nameLabel:setString("")
	self.m_cntLabel:setString("")

	local t = tonumber(data.type)

	-- 只显示label  类型是1000时
	if t == 1000 then
		self.m_nameLabel:setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
		self.m_sprChestBg:setVisible(false)
		if nil ~= data.label then
			self.m_nameLabel:setString(data.label)
		end
	elseif t == 7 or t == 14 then
		-- 道具 装备
		local value = data.value
	    if nil ~= value then
	    	local colorstr = CCCommonUtilsForLua:call("getToolBgByColor", tonumber(CCCommonUtilsForLua:call("getPropById", tostring(value.id), "color")) or 0)
	    	local colorSpr = CCLoadSprite:call("createSprite", colorstr)

	    	local icon = CCCommonUtilsForLua:call("getIcon", tostring(value.id))
		    local spr = CCLoadSprite:call("createSprite", icon)
		    spr:setAnchorPoint(cc.p(0.5, 0.5))
		    CCCommonUtilsForLua:call("setSpriteMaxSize", colorSpr, 48, true)
		    CCCommonUtilsForLua:call("setSpriteMaxSize", spr, 48, true)
		    self.m_iconNode:addChild(colorSpr)
		    self.m_iconNode:addChild(spr)
		    local dialog = CCCommonUtilsForLua:call("getPropById", tostring(value.id), "name")
		    self.m_nameLabel:setString(getLang(dialog))
		    if nil ~= value.num then
		    	self.m_cntLabel:setString(tostring(value.num))
		    end
	    end
	end
end

return RewardShowView