local NewActiveSkillViewBuffCell = class("NewActiveSkillViewBuffCell",
	function()
		return cc.Layer:create()
	end
)
NewActiveSkillViewBuffCell.__index = NewActiveSkillViewBuffCell
NewActiveSkillViewBuffCellOwner = NewActiveSkillViewBuffCellOwner or {}
ccb["NewActiveSkillViewBuffCellOwner"] = NewActiveSkillViewBuffCellOwner

local CELL_WIDTH = 610		-- 单元格宽
local CELL_HEIGHT = 145		-- 单元格高

local itemCellH1 = 120

local ArtilleryBuffType = 9999
local ArtilleryBuffTimeType = 66


---------------------------NewActiveSkillViewBuffCell-----------------------------

function NewActiveSkillViewBuffCell:create(idx, statusId, view)
	local node = NewActiveSkillViewBuffCell.new()
	if (node:initNode(idx, statusId, view)) then
		return node
	end
end

function NewActiveSkillViewBuffCell:initNode(idx, statusId, view)
	CCLoadSprite:call("doResourceByCommonIndex", 504, true)
	self.m_idx = idx
	self.m_statusId = statusId
	self.m_view = view
	self.tid = view.buffDataSubitemList[self.m_statusId]

	local ccbUri = "ActiveSkill_Buff_Cell.ccbi"
	local proxy = cc.CCBProxy:create()
	self.node = CCBReaderLoad(ccbUri, proxy, self)

	local function onNodeEvent(event)
		if event == "enter" then
			self:onEnter()
		elseif event == "exit" then
			self:onExit()
		elseif event == "cleanup" then
			self:onCleanup()
		end
	end
	self.node:registerScriptHandler(onNodeEvent)
	-- self.node:setTouchEnabled(true)
	-- self.node:setSwallowsTouches(false)
	self:addChild(self.node)

	-- if (CCCommonUtilsForLua:isIosAndroidPad()) then
	-- 	self:setContentSize(cc.size(1496, 240))
	-- else
	-- 	self:setContentSize(cc.size(605, 120))
	-- end

	self.animationManager = ccb["NewActiveSkillViewBuffCellOwner"]["mAnimationManager"]
	self:ignoreAnchorPointForPosition(true)
	self.touchEnable = true
	--self.m_timeType = 0

	self.gridNode = cc.Node:create()
	self:addChild(self.gridNode)

	self.gridNodeTable = {}

	self.m_scrollView = cc.ScrollView:create()
	self.m_scrollView:setViewSize(cc.size(540,300))
	self.m_scrollView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
	self.gridNode:addChild(self.m_scrollView)
	
	self:setData(self.m_idx, self.m_statusId, self.m_view)
	return true
end

function NewActiveSkillViewBuffCell:onEnter()
	-- body
	local function callback() self:resetTime() end
	local handler = self:registerHandler(callback)
	CCSafeNotificationCenter:registerScriptObserver(self, handler, MSG_ITME_STATUS_TIME_CHANGE)

	local function callback2(pObj) self:refreshBuffCellData() end
	local handler2 = self:registerHandler(callback2)
	CCSafeNotificationCenter:registerScriptObserver(self, handler2, MSG_REFREASH_TOOL_DATA)

	self:refreshBuffCellData()
	if self.entry then
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
		self.entry = nil
	end
	self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(function(dt) self:refreshBuffCellData(dt) end, 1, false)
end

function NewActiveSkillViewBuffCell:onExit()
	CCSafeNotificationCenter:unregisterScriptObserver(self, MSG_ITME_STATUS_TIME_CHANGE)
	CCSafeNotificationCenter:unregisterScriptObserver(self, MSG_REFREASH_TOOL_DATA)
	if self.entry then
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
		self.entry = nil
	end
end

function NewActiveSkillViewBuffCell:onCleanup()
	-- body
	--self = nil
end

function NewActiveSkillViewBuffCell:resetTime(pObj)
	local integer = tolua.cast(pObj, "CCInteger")
	if integer == nil then
		return
	end
	if (integer:getValue() == self.m_type) then
		self:refreshBuffCellData()
		if self.entry then 
			cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry) 
			self.entry = nil
		end
		self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(function(dt) self:refreshBuffCellData(dt) end, 1, false)
	end
end

function NewActiveSkillViewBuffCell:setData(idx, statusId, view)
	self.m_idx = idx
	self.m_statusId = statusId
	self.m_view = view
	self.tid = view.buffDataSubitemList[self.m_statusId]

	self.m_type = atoi(CCCommonUtilsForLua:call("getPropById", self.m_statusId, "type"))
	self.m_timeType = atoi(CCCommonUtilsForLua:call("getPropById", self.m_statusId, "itemtype"))
	self.m_showIndepend = atoi(CCCommonUtilsForLua:call("getPropById", self.m_statusId, "independent_display"))
	self.m_iconNode:removeAllChildren()
	self.m_sprArrow:setVisible(true)

	local typeNameS = getLang(CCCommonUtilsForLua:call("getPropById", self.m_statusId, "name"))
	self.m_nameTxt:setString(typeNameS)
	self:resetDescText()

	if (self.m_type == 0 or self.m_type == ArtilleryBuffType or self.m_showIndepend == 1) then 
		self.m_sprArrow:setVisible(false) 
	end

	local iconPath = CCCommonUtilsForLua:call("getPropById", self.m_statusId, "icon") .. ".png"
	local color = atoi(CCCommonUtilsForLua:call("getPropById", self.m_statusId, "color"))
	local colorBgPath = CCCommonUtilsForLua:call("getToolBgByColor", color)
	local iconBg = CCLoadSprite:call("createSprite", colorBgPath)
	local iconSpr = CCLoadSprite:call("createSprite", iconPath, CCLoadSpriteType_GOODS)

	-- if (CCCommonUtilsForLua:isIosAndroidPad()) then
	-- 	CCCommonUtilsForLua:setSpriteMaxSize(iconBg, 140, true)
	-- 	CCCommonUtilsForLua:setSpriteMaxSize(iconSpr, 140, true)
	-- else
	-- 	CCCommonUtilsForLua:setSpriteMaxSize(iconBg, 92, true)
	-- 	CCCommonUtilsForLua:setSpriteMaxSize(iconSpr, 92, true)
	-- end

	self.m_iconNode:addChild(iconBg)
	self.m_iconNode:addChild(iconSpr)

	if (self.m_barNode:getChildByTag(100)) then self.m_barNode:removeChildByTag(100) end

	self.animationManager:runAnimationsForSequenceNamed("loop")

	--加进度条头上的光效
	self.m_headParticleNode = cc.Node:create()
	for i = 1, 3 do
		local path = string.format("Loading_%d", i)
		local particle = ParticleController:call("createParticle", path)
		self.m_headParticleNode:addChild(particle)
	end

	self.m_barNode:addChild(self.m_headParticleNode)
	self.m_headParticleNode:setTag(100)

	self:refreshBuffCellData()

	if self.entry then
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
		self.entry = nil
	end

	-- self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(function(dt) self:refreshBuffCellData(dt) end, 1, false)

	-- if (self.m_type == 16) then
	-- 	if (not CCCommonUtilsForLua:isIosAndroidPad()) then
	-- 		self.m_barNode:setPositionY(30)
	-- 	end
	-- else
	-- 	if (CCCommonUtilsForLua:isIosAndroidPad()) then
	-- 		self.m_cellBG:setPreferredSize(cc.size(1496, 300))
	-- 	else
	-- 		self.m_cellBG:setPreferredSize(cc.size(604, 145))
	-- 	end

	-- 	if (not CCCommonUtilsForLua:isIosAndroidPad()) then
	-- 		self.m_mainNode:setPositionY(0)
	-- 		self.m_barNode:setPositionY(40.2)
	-- 	end
	-- end

	if self.m_view.buffDataGroupState[idx] then
		local state = self.m_view.buffDataGroupState[idx].state
		if state == 1 then
			self.m_sprArrow:setRotation(90)
			self.node:setPositionY(itemCellH1 * #self.tid)
			self.gridNode:setVisible(true)
			for i, v in ipairs(self.tid) do
				local grid = self.gridNodeTable[i]
				if grid == nil then
					grid =  Drequire("game.CommonPopup.NewActiveSkillViewBuffCellSubitem"):create(v["itemId"], v["objId"], v["qid"])
					self.gridNodeTable[i] = grid
					self.gridNode:addChild(grid)
				else
					grid:setData(v["itemId"], v["objId"], v["qid"])
				end
				local pos = cc.p(10, itemCellH1 * (#self.tid - i))
				grid:setPosition(pos)
			end
			for i, v in ipairs(self.gridNodeTable) do
				self.gridNodeTable[i]:setVisible(i <= #self.tid)
			end
		else
			self.m_sprArrow:setRotation(0)
			self.node:setPositionY(0)
			-- self.gridNode:removeAllChildren()
			self.gridNode:setVisible(false)
		end
	end
end

function NewActiveSkillViewBuffCell:resetDescText()
	local descS = getLang(CCCommonUtilsForLua:call("getPropById", self.m_statusId, "description"))
	self.m_descTxt:setString(descS)
	self.m_descTxt:setVisible(true)

	--清除富文本
	local parent = self.m_descTxt:getParent()
	parent:removeChildByTag(666)
end

function NewActiveSkillViewBuffCell:updateExtra()
	local statusId = CCCommonUtilsForLua:call("getPropById", self.m_statusId, "status")
	local slots = splitString(statusId, "|")
	local statusId
	local effect = 0
	for _, sid in ipairs(slots) do
		if self.m_view.extraStatus[sid] then
			statusId = sid
			effect = atoi(self.m_view.extraStatus[sid])
			break
		end
	end

	if statusId then
		local dialog = require("game.controller.StatusController").getInstance():getExtraDialog(statusId)
		local numStr = string.format("%.1f", effect)
		local rich = utils.getLinkTextStr(getLang(dialog), numStr, 18, "C1A77CFF", "3DA4C6FF")
		replaceRichText(self.m_descTxt, rich, 666)
	else
		self:resetDescText()
	end
end

function NewActiveSkillViewBuffCell:refreshBuffCellData()
	self.m_time = 0
	self.m_timeCDTxt:setVisible(false)
	self.m_CDBackLayer:setVisible(false)

	local max = 0

	if (self.m_timeType == ArtilleryBuffTimeType) or self.m_showIndepend == 1 then
		local statusMap = GlobalData:call("shared"):getProperty("statusMap")
		local statusId = CCCommonUtilsForLua:call("getPropById", self.m_statusId, "status")
		local slots = splitString(statusId, "|")
		local nowTime = GlobalData:call("getWorldTime")
		for _, sid in ipairs(slots) do
			local endTime = atoi(statusMap[atoi(sid)])
			self.m_time = endTime - nowTime
			if self.m_time > 0 then break end
		end
	elseif (self.m_timeType == 0) then
		local items = ToolController:call("getInstance"):getProperty("m_statusItems")
		if (items[self.m_type]) then
			local item = items[self.m_type]
			local startTime = item:valueForKey("startTime"):doubleValue()
			local endTime = item:valueForKey("endTime"):doubleValue()
			local time = WorldController:call("getTime")
			self.m_time = (endTime - time) / 1000
			max = (endTime - startTime) / 1000
		end
	else
		local durationItems = ToolController:call("getInstance"):getProperty("m_durationItems")
		if (durationItems[self.m_timeType]) then
			local time = durationItems[self.m_timeType]
			if (#time == 2) then
				self.m_time = time[2] - GlobalData:call("getTimeStamp")
				max = time[2] - time[1]
			end
		end
	end

	if (self.m_time > 0) then
		self.m_barNode:setVisible(true)
		max = math.max(max, 1)
		local len = self.m_time / max
		if (len > 1) then len = 1 end
		self.m_progress:setScaleX(len)
		self.m_barRight:setVisible(len > 0.99) --右箭头
		self.m_timeTxt:setString(getLang("105805", format_time(self.m_time)))
		self.m_receiveGlow:setVisible(true)

		local px = 0 --进度条头上的光效位置
		px = self.m_progress:getPositionX() + (self.m_progress:getContentSize().width * len)
		self.m_headParticleNode:setPositionX(px)
		self:updateExtra()
	else
		self:resetDescText()
		self.m_progress:setScaleX(0)
		self.m_timeTxt:setString(getLang("105805", format_time(0)))
		self.m_barNode:setVisible(false)
		self.m_receiveGlow:setVisible(false)

		self.touchEnable = true

		if (self.m_type == 1) then
			local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
			local protectCDTime = playerInfo:getProperty("protectCDTime")
			local worldTime = GlobalData:call("getWorldTime")
			local newTime = GlobalData:call("renewTime", worldTime * 1000) / 1000
			local cdTime = protectCDTime - newTime
			if (cdTime > 0) then
				self.m_timeCDTxt:setVisible(true)
				self.m_timeCDTxt:setString(getLang("105164", CCCommonUtilsForLua:call("timeLeftToCountDown", cdTime)))
				self.touchEnable = false
				self.m_CDBackLayer:setVisible(true)

				local txtSize = self.m_timeCDTxt:getContentSize()
				self.m_CDBackLayer:setContentSize(cc.size(txtSize.width + 10, txtSize.height))
			else
				self.m_timeCDTxt:setVisible(false)
				self.m_CDBackLayer:setVisible(false)
				if self.entry then 
					cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry) 
					self.entry = nil
				end
			end
		else
			if self.entry then 
				cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry) 
				self.entry = nil
			end
		end
	end

	--战争守护剩余时间小于配置值置红
	if self.m_type == 1 and CCCommonUtilsForLua:isFunOpenByKey("push_related_func") then
		if self.m_time > 0 and self.m_time < 24 * 60 * 60 then
			self.m_timeTxt:setColor(cc.c3b(255, 0, 0))
		else
			self.m_timeTxt:setColor(cc.c3b(255, 255, 255))
		end
	end
end

return NewActiveSkillViewBuffCell