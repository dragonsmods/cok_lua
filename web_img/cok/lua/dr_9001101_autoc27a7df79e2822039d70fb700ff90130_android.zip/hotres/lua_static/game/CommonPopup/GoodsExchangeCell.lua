--[[
    GoodsExchangeCell
]]

-- 转换重置方式
local ExchangeResetType = {
    UNKNOWN  = 0, -- 未知重置方式
    NONE     = 1, -- 不重置
    WEEK     = 2, -- 每周重置
    DAY      = 3, -- 每日重置
    ACTIVITY = 4, -- 活动重开重置
    MONTH    = 5, -- 每月重置
    YEAR     = 6, -- 每年重置
}

-- 对应ExchangeResetType
local ResetDialogArr = {
    [ExchangeResetType.UNKNOWN]   = "",
    [ExchangeResetType.NONE]      = "",
    [ExchangeResetType.WEEK]      = "671808", -- 本周剩余次数：
    [ExchangeResetType.DAY]       = "671807", -- 本日剩余次数：
    [ExchangeResetType.ACTIVITY]  = "",
    [ExchangeResetType.MONTH]     = "671809", -- 本月剩余次数：
    [ExchangeResetType.YEAR]      = "",
}

local GoodsExchangeCell = class("GoodsExchangeCell",function()
    return CCTableViewCell:new()
end)

function GoodsExchangeCell:create(param, parentView)
    local cell = GoodsExchangeCell.new()
    Drequire("game.CommonPopup.GoodsExchangeCell_ui"):create(cell, param.viewSize)
    if cell:initView(param, parentView) then
        return cell
    end
end

function GoodsExchangeCell:initView(param, parentView)
    self.m_goodsNodeArr = { self.ui.m_goodsNode_1, self.ui.m_goodsNode_2, self.ui.m_goodsNode_3, self.ui.m_goodsNode_4 }
    self.m_iconNodeArr  = { self.ui.m_iconNode_1,  self.ui.m_iconNode_2,  self.ui.m_iconNode_3,  self.ui.m_iconNode_4  }
    self.m_numLabelArr  = { self.ui.m_numLabel_1,  self.ui.m_numLabel_2,  self.ui.m_numLabel_3,  self.ui.m_numLabel_4  }

    self.m_parentView = parentView
    self:refreshCell(param)

    return true
end

function GoodsExchangeCell:refreshCell(param, idx)
    self.m_itemData = param.itemData
    local index = 0
    for index, value in ipairs(self.m_itemData.exchangeArr) do
        self.m_goodsNodeArr[index]:setVisible(true)
        self.m_iconNodeArr[index]:removeAllChildren()
        CCCommonUtilsForLua:call("createGoodsIcon", tonumber(value.itemId), self.m_iconNodeArr[index], CCSizeMake(95, 95))
        local tinfo = ToolController:call("getToolInfoForLua", tonumber(value.itemId))
        if tinfo then
            local count = tinfo:call("getCNT")
            self.m_numLabelArr[index]:setString(count .. "/" .. value.num)
            if count < value.num then
                self.m_numLabelArr[index]:setColor(cc.c3b(255, 0, 0))
            else
                self.m_numLabelArr[index]:setColor(cc.c3b(255, 255, 255))
            end
        end
    end
    
    for tempIndex = #self.m_itemData.exchangeArr + 1, #self.m_goodsNodeArr do
        self.m_goodsNodeArr[tempIndex]:setVisible(false)
    end

    local resetDialog = ResetDialogArr[self.m_itemData.resetType]
    if resetDialog and resetDialog ~= "" then
        self.ui.m_descLabel:setString(getLang(resetDialog, self.m_itemData.limit - self.m_itemData.nowCount))
    else
        self.ui.m_descLabel:setString("")
    end
end

function GoodsExchangeCell:refreshCount(dict)
    local param = dictToLuaTable(dict)
    if param.uuid == self.m_itemData.uuid then
        for index, value in ipairs(self.m_itemData.exchangeArr) do
            local tinfo = ToolController:call("getToolInfoForLua", tonumber(value.itemId))
            self.m_numLabelArr[index]:setString(tinfo:call("getCNT") .. "/" .. (value.num * param.count))
        end
    end
end

function GoodsExchangeCell:onEnter()
    registerScriptObserver(self, self.refreshCount, "GoodsExchangeCell:refreshCount")
end

function GoodsExchangeCell:onExit()
    unregisterScriptObserver(self, "GoodsExchangeCell:refreshCount")
end


return GoodsExchangeCell