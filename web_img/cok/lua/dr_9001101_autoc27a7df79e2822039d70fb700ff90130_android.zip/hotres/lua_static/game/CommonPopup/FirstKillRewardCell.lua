--[[ 
	首杀奖励领取单元格
	2019.6.28	Awen
 ]]

local FirstKillRewardCell = class("FirstKillRewardCell", function() return cc.Layer:create() end )

function FirstKillRewardCell:create()
	local view = FirstKillRewardCell.new()
	Drequire("game.CommonPopup.FirstKillRewardCell_ui"):create(view, 1)
	return view
end

function FirstKillRewardCell:refreshCell(info, idx)
	-- dump(info,"FirstKillRewardCell:refreshCell")
	LibaoCommonFunc.createRewardItemInfo(info, self.ui.m_nodeIcon, 80, nil, nil, nil, true)
	if info.value.rewardAdd then
		self.ui.m_labelCount:setString('x'..(info.value.rewardAdd))
	else
		self.ui.m_labelCount:setString('')
	end
end

return FirstKillRewardCell