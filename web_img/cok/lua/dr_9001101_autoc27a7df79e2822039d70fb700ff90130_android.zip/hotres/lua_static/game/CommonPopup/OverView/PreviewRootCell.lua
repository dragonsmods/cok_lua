local PreviewRootCell = class("PreviewRootCell",function ()
    return cc.TableViewCell:create()
end)

PreviewRootCell.__index = PreviewRootCell
local initHeight = 533
local Queue_ST_Init = -1 
local Queue_ST_IDLE = 0 --空闲
local Queue_ST_WORK = 1 --工作
local Queue_ST_LOCK = 2	--未解锁
function PreviewRootCell:create()
    local cell = PreviewRootCell.new()
    Drequire("game.CommonPopup.OverView.PreviewRootCell_ui"):create(cell)
    if cell:initCell() then
        return cell
    end
end

function PreviewRootCell:initCell()
    return true
end

function PreviewRootCell:refreshCell(info,idx)
    self.info = info
    self.parent = info.parent
    local height = self.parent.cellSizeTbl[idx+1]
    local dis = initHeight - height
    self.ui.m_titleNode:setPositionY(477 - dis)
    self.ui.m_bgNode:setContentSize(cc.size(464,height))
    self.ui.m_bgSpr:setContentSize(cc.size(464,height))
    self.key = info.key
    self.name = info.name
    self.icon = info.icon or ""
    self.ui.m_TitleText:setString(getLang(self.name))
    self:initCellVisible()
    self:setInfoShow()
    self:setProgress()
end

--初始化设置
function PreviewRootCell:initCellVisible( )
    for i=1,9 do
        self.ui["m_infoNode"..i]:setVisible(false)
        self.ui["m_lockSpr"..i]:setVisible(false)
        self.ui["m_proSpr"..i]:setScaleX(0.01)
        self.ui["m_progressNode"..i]:setVisible(false)  
        self.ui["m_infoNode"..i]:removeChildByTag(1010)
        self.ui["m_infoNode"..i]:removeChildByTag(1011)
    end
    self.ui.m_headPicNode:removeAllChildren()
    if self.icon ~= "" then
        local headSpr = CCLoadSprite:call("createSprite", self.icon..".png")
        self.ui.m_headPicNode:addChild(headSpr)
    --test    
    -- else
    --     local headSpr = CCLoadSprite:call("createSprite", "overview_icon1.png")
    --     self.ui.m_headPicNode:addChild(headSpr)
    end

end
--显示足够的子类别Node
function PreviewRootCell:setNodeShow( num )
    if num > 0 then
        for i=1,num do
            self.ui["m_infoNode"..i]:setVisible(true)
        end
    end
end

--设置每个cell的显示信息
function PreviewRootCell:setInfoShow()
    self.tblData = self.info.cellMeta or {}
    local num = #self.tblData
    self:setNodeShow(num)

    for index = num, 1 ,-1 do
        if index <= 9 then
            local subCellInfo = self.tblData[num-index+1]
            local label = subCellInfo.label
            local param1 = subCellInfo.param1
            local param2 = subCellInfo.param2
            local state = subCellInfo.state
            local marchIcon = subCellInfo.marchIcon or ""        
            self.ui["m_pControlButton"..index]:setVisible(true)
            --未解锁显示
            if state == Queue_ST_LOCK or state == Queue_ST_Init then                
                CCCommonUtilsForLua:call("setButtonSprite", self.ui["m_pControlButton"..index], "BTN_huianniu.png")
                self.ui["m_lockSpr"..index]:setVisible(true)
                self.ui["m_jumpSpr"..index]:setVisible(false)
            else
                CCCommonUtilsForLua:call("setButtonSprite", self.ui["m_pControlButton"..index], "BTN_lvanniu.png")                
                self.ui["m_lockSpr"..index]:setVisible(false)
                self.ui["m_jumpSpr"..index]:setVisible(true)
                --已完成且不显示跳转
                if nil ~= subCellInfo.cancelJump and subCellInfo.cancelJump == true then
                    self.ui["m_jumpSpr"..index]:setVisible(false)
                    self.ui["m_pControlButton"..index]:setVisible(false)
                end
            end
 
            --文本显示
            local txt = getLang(label)
            if self:checkHasPar(subCellInfo) then
                txt = getLang(label,tostring(param1))
            end
            if subCellInfo.id == "30711034" or subCellInfo.id == "30711033" then
                txt = getLang(label,tostring(param1),tostring(param2))
            end            
            txt = "<s18>"..txt
            local contentLabel = IFHyperlinkText:call("create",txt,cc.size(260,0), true, false)
            contentLabel:setAnchorPoint(ccp(0.5,0.5))
            self.ui["m_infoNode"..index]:addChild(contentLabel)
            self.ui["m_infoLabel"..index]:setString("")
            contentLabel:setTag(1010)
            contentLabel:setPosition(ccp(210.0,0))
            local icon = subCellInfo.icon

            --附加进度条上的图标
            if marchIcon ~= "" then
                local marchSpr = CCLoadSprite:call("createSprite", marchIcon)  
                self.ui["m_infoNode"..index]:addChild(marchSpr)
                marchSpr:setPosition(ccp(150,3))
                CCCommonUtilsForLua:call("setSpriteMaxSize", marchSpr, 40, true)
                marchSpr:setTag(1011)
            end

            --小图标
            if icon ~= "" then
                local frame = CCLoadSprite:call("getSF", icon..".png")
                if not frame then
                    frame = CCLoadSprite:call("getSF", "icon_chilun.png")
                end
                self.ui["m_iconSpr"..index]:setSpriteFrame(frame)
            else
                local frame = CCLoadSprite:call("getSF", "icon_chilun.png")
                self.ui["m_iconSpr"..index]:setSpriteFrame(frame)
            end            
        end     
    end    
end

--根据状态和类别来判断文本是否含参数
function PreviewRootCell:checkHasPar(info)
    local res = false
    local state = info.state
    if state == Queue_ST_IDLE or state == Queue_ST_LOCK then
        res = false
    elseif state == Queue_ST_WORK then
        res = true
    end
    return res
end

function PreviewRootCell:setProgress()
    local curWorldTime = getWorldTime()
    local function setProIndex(info,index)
        self.ui["m_progressNode"..index]:setVisible(true)
        if nil == info then
            return
        end
        local param1 = info.param1
        local param2 = info.param2   
        local lessTime = param1 - curWorldTime
        local IFHyperTxt = self.ui["m_infoNode"..index]:getChildByTag(1010)
        if lessTime >= 0 then                   
            self.ui["m_infoLabel"..index]:setString(CC_SECTOA(lessTime))
            local ids = 1- lessTime/param2
            if ids < 0 then ids = 0 end
            if ids > 1 then ids = 1 end
            self.ui["m_proSpr"..index]:setScaleX(ids)
            if IFHyperTxt then
                IFHyperTxt:removeFromParent()
            end
        elseif lessTime < 0 and lessTime >= -1 then
            self.ui["m_progressNode"..index]:setVisible(false)
            self.ui["m_infoLabel"..index]:setString("")
            self.parent:refreshView()           
        else            
            self.ui["m_progressNode"..index]:setVisible(false)
        end
    end

    if self.key and (self.key == '30710001' or self.key == '30710002' 
    or self.key == "30710003" or self.key == '30710014'
    or self.key == '30710015' or self.key == '30710005'
    or self.key == '30710004' or self.key == '30710007') then
        local index= 1
        local num = #self.tblData
        for index = num, 1, -1 do
            local info = self.tblData[num-index+1]
            setProIndex(info,index)            
        end
    end
end
function PreviewRootCell:updateTime(dt)
    self:setProgress()
end
function PreviewRootCell:onEnter()
    if self.entery ~= nil then
        self.entery = nil
    end
    self.entry = tonumber(self:getScheduler():scheduleScriptFunc(function(dt)
		self:updateTime(dt)
	end, 1, false))
end
function PreviewRootCell:onExit()
	if self.entry then
		self:getScheduler():unscheduleScriptEntry(self.entry)
		self.entry = nil
	end
end

--点击跳转处理
function PreviewRootCell:onClickByIndex(index)
    local num = #self.tblData
    if num >= index then        
        local cellInfo = self.tblData[num - index + 1]
        local _id = cellInfo.id
        local _state = cellInfo.state
        local CELL = cellInfo.cell
        if CELL then
            --跳转数据打点
            local now = getTimeStamp()
            local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
            local myUid = playerInfo:getProperty("uid")
            self.parent:onClickClose()
            CELL:OnClickJump(_id,_state)
        end
    end
end
function PreviewRootCell:onBtnClick9()
	self:onClickByIndex(9)
end
function PreviewRootCell:onBtnClick8()
	self:onClickByIndex(8)
end
function PreviewRootCell:onBtnClick7()
	self:onClickByIndex(7)
end
function PreviewRootCell:onBtnClick6()
	self:onClickByIndex(6)
end
function PreviewRootCell:onBtnClick5()
	self:onClickByIndex(5)
end
function PreviewRootCell:onBtnClick4()
	self:onClickByIndex(4)
end
function PreviewRootCell:onBtnClick3()
	self:onClickByIndex(3)
end
function PreviewRootCell:onBtnClick2()
	self:onClickByIndex(2)
end
function PreviewRootCell:onBtnClick1()
	self:onClickByIndex(1)
end

return PreviewRootCell