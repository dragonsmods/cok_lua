

local SelectingView = class("SelectingView", 
    function()
    return PopupBaseView:create()
    end
    )
SelectingView.__index =  SelectingView

function SelectingView:create(params)
    dump("SelectingView:create+++")
 local view = SelectingView.new()
    Drequire("game.CommonPopup.SelectingView.SelectingView_ui"):create(view, 0)
    if view:initView(params) then
        return view
    end
    return false
end

function SelectingView:initView(params)
    dump("SelectingView:initView+++")
    self.selectingViewController = Drequire("game.CommonPopup.SelectingView.SelectingViewController").new()
    self.initParams = params
    self.UpdataDataMsgTbl={}
    if params then 
        if params.title then 
            self.ui.m_pLabelTitle:setString(params.title)
        end
        if params.buttonTitle then 
            CCCommonUtilsForLua:setButtonTitle(self.ui.m_okBtn, params.buttonTitle)
        end
    end

    self.touchLayer = cc.Layer:create()
    self:addChild(self.touchLayer)
    local function touchHandle( eventType, x, y )
        print("touchHandle", eventType, x, y)
        if eventType == "began" then
            return self:onTouchBegan(x, y)
        elseif eventType == "moved" then
        
        else
            self:onTouchEnded(x, y)
        end
    end
    self.touchLayer:registerScriptTouchHandler(touchHandle)
    self.touchLayer:setTouchEnabled(true)
    self.touchLayer:setSwallowsTouches(false)
    return true
end

--添加数据更新的消息
function SelectingView:addUpdateDataMsg( msgId )
    if not msgId then 
        return 
    end
    if #(self.UpdataDataMsgTbl)>0 then 
        for k, v in pairs(self.UpdataDataMsgTbl) do 
            if v and v==msgId then 
                return
            end
        end
    end
    dump(msgId,"SelectingView:addUpdateDataMsg+++")
    table.insert(self.UpdataDataMsgTbl,msgId)
end

function SelectingView:onDataBack(data)
    if not data then 
        return
    end
    local tmp = arrayToLuaTable(data)
    if not tmp then 
        return 
    end
    -- dump(tmp, "SelectingView:onDataBack+++")
    for k,v in pairs(tmp) do 
        v.selectingViewController = self.selectingViewController
    end
    self.selectingViewController:updateViewData(tmp)
    self.ui:setTableViewDataSource("m_pTableView", tmp)
end

function SelectingView:onEnter()
    dump(self.UpdataDataMsgTbl, "SelectingView:onEnter+++")
    if #(self.UpdataDataMsgTbl)>0 then 
        for k, v in pairs(self.UpdataDataMsgTbl) do 
            if v then 
                dump(v, "SelectingView:registerScriptObserver+++")
                registerScriptObserver(self, self.onDataBack, v)
            end
        end
    end

    if self.initParams and self.initParams.pullViewDataFunc then
        self.initParams.pullViewDataFunc() --拉取数据
    end
end

function SelectingView:onExit()
    if #(self.UpdataDataMsgTbl)>0 then 
        for k, v in pairs(self.UpdataDataMsgTbl) do 
            if v then 
                dump(v, "SelectingView:unregisterScriptObserver+++")
                unregisterScriptObserver(self, v)
            end
        end
    end
end

function SelectingView:onOkBtnClick()
    dump(self.initParams, "SelectingView:onOkBtnClick+++")
    if self.initParams then 
        if self.initParams.okButtonCallbackFunc then 
            local params=self.selectingViewController:getCheckedData()
            self.initParams.okButtonCallbackFunc(params) 
        end
    end
    
end

function SelectingView:onTouchBegan(x, y)
    return true
end

function SelectingView:onTouchEnded(x, y)
    if (not isTouchInside(self.ui.m_bg, x, y)) then
        PopupViewController:call("removePopupView", self) 
    end
end

return SelectingView



