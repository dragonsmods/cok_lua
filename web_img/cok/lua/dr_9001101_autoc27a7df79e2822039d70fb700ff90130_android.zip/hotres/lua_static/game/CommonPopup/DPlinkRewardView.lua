
DPlinkRewardLuaView = DPlinkRewardLuaView or {}
ccb["DPlinkRewardLuaView"] = DPlinkRewardLuaView


--About DPlinkRewardCell -----
DPlinkRewardLuaCell = DPlinkRewardLuaCell or {}
ccb["DPlinkRewardLuaCell"] = DPlinkRewardLuaCell

local DPlinkRewardCell = class("DPlinkRewardCell",
    function()
        return cc.Layer:create() 
    end
)
DPlinkRewardCell.__index = DPlinkRewardCell

function  DPlinkRewardCell:create(itemId,num,type)
  local cell = DPlinkRewardCell:new()
  if cell:init(itemId,num,type) == false then
    MyPrint(" DPlinkRewardCell init Fail!!!")
    return nil
  end
  return cell
end

function DPlinkRewardCell:init(itemId,num,type)
     MyPrint(" itemId="..itemId.."; num="..num.." type="..type )
    local proxy = cc.CCBProxy:create()
    local ccbiUrl = "ccbi/DPlinkRewardCell.ccbi"
    local ccbNode = CCBReaderLoad(ccbiUrl, proxy, self)
    if nil == ccbNode then
        MyPrint("CCB Load error!!")
        return false
    end
    self:addChild(ccbNode)

    if self:onAssignCCBMemberVariable() ==false then
      MyPrint("----DPlinkRewardCell load CCB Fail!-----")
      return false
    end

    local pic  = CCCommonUtilsForLua:getPropById(tostring(itemId), "icon")..".png"
    local name = CCCommonUtilsForLua:getPropById(tostring(itemId), "name")
    local picSpr = CCLoadSprite:createSprite(pic)

    MyPrint("pic =" ..pic .."; name="..name)
    self.m_iconNode:addChild(picSpr)
    self.m_nameLabel:setString(getLang(name))
    self.m_numLabel:setString(""..num)

end

function DPlinkRewardCell:onAssignCCBMemberVariable()
  if nil ~= DPlinkRewardLuaCell["m_nameLabel"] then
    self.m_nameLabel = tolua.cast(DPlinkRewardLuaCell["m_nameLabel"],"cc.LabelIF")
  end
  if self.m_nameLabel == nil then
    MyPrint(" No match name :m_nameLabel!  ")
    return false
  end

  if nil ~= DPlinkRewardLuaCell["m_numLabel"] then
      self.m_numLabel = tolua.cast(DPlinkRewardLuaCell["m_numLabel"],"cc.LabelIF")
  end
  if self.m_numLabel == nil then
    MyPrint("No match name :m_numLabel !")
    return false
  end

  if nil ~= DPlinkRewardLuaCell["m_iconNode"] then
      self.m_iconNode = tolua.cast(DPlinkRewardLuaCell["m_iconNode"],"cc.Node")
  end
  if self.m_iconNode == nil then
    MyPrint("No match name :m_iconNode !")
    return false
  end
end
-----------------------------------------------------------------------------------------

local DPlinkRewardView = class("DPlinkRewardView",
    function()
        return PopupBaseView:call("create")
    end
)
DPlinkRewardView.__index = DPlinkRewardView

function DPlinkRewardView:create(rewards)
  MyPrint("-------call DPlinkRewardView:create -----")
  local view = DPlinkRewardView.new()
  if view:initView(rewards) == false then
    return nil
  end
  return view
end

function DPlinkRewardView:initView(rewards)
    if self:init(true, 0) == false then
      MyPrint("NewFunTipsView init error")
      return false  
    end
    math.randomseed(os.time())
    self:setHDPanelFlag(true)

    MyPrint("--- Loading resource ---")
    callItSelfCallFunc(LuaController, "doResourceByCommonIndex", 8, true)
    -- Loading dynamic resources

    local proxy = cc.CCBProxy:create()
    local ccbiUrl = "ccbi/DPlinkRewardView.ccbi"
    local ccbNode = CCBReaderLoad(ccbiUrl, proxy, self)
    if nil == ccbNode then
        MyPrint("CCB Load error!!")
        return false
    end
    self:addChild(ccbNode)

    if self:onAssignCCBMemberVariable() == false  then
      MyPrint(" CCB Memeber Variable bind error!!")
      return false
    end

    if CCCommonUtilsForLua:call("isIosAndroidPad") == true then
     ccbNode:setScale(2)
    end
    self:setContentSize(ccbNode:getContentSize());

    CCCommonUtilsForLua:setButtonTitle(self.m_okBtn,getLang("confirm"))
    self.m_scrollView = cc.ScrollView:create()
    self.m_scrollView:setViewSize(self.m_infoList:getContentSize())
    self.m_scrollView:setPosition(cc.p(0,0))
    self.m_scrollView:setScale(1.0)
    self.m_scrollView:ignoreAnchorPointForPosition(true)
    self.m_scrollView:setDirection(1)
    self.m_scrollView:setClippingToBounds(true)
    self.m_scrollView:setBounceable(true)

    dump(rewards, " ~~~~~ DPlinkRewardCell ~~~~~~~")
    
    local curY = 0
    local mainNode = cc.Node:create();
    for i=1,#rewards do

      MyPrint(" ~~~~~rewards id:" .. i )
        local type = rewards[i]["type"]
        local num  = rewards[i]["value"]["num"]
        local idx  = rewards[i]["value"]["id"]

        curY = curY +80
        local cell = DPlinkRewardCell:create(idx,num,type)
        mainNode:addChild(cell)
        cell:setPosition(cc.p(0, 0 - curY))
      
    end
    self.m_scrollView:addChild(mainNode)
    mainNode:setPosition(cc.p(0, curY))
    
    self.m_scrollView:setContentSize(CCSize(self.m_infoList:getContentSize().width,curY))
    self.m_scrollView:setContentOffset(CCPoint(0, self.m_infoList:getContentSize().height - curY))
    self.m_infoList:addChild(self.m_scrollView);

    return true
end

function DPlinkRewardView:onClickCollectBtn()
  self:call("closeSelf")
  MyPrint(" --call onClickCollectBtn!")

end

function DPlinkRewardView:onAssignCCBMemberVariable()
  if nil ~= DPlinkRewardLuaView["m_okBtn"] then
    self.m_okBtn = tolua.cast(DPlinkRewardLuaView["m_okBtn"],"ccui.Button")
  end
  if self.m_okBtn == nil then
    MyPrint(" No match name :m_okBtn!  ")
    return false
  end

  if nil ~= DPlinkRewardLuaView["m_infoList"] then
      self.m_infoList = tolua.cast(DPlinkRewardLuaView["m_infoList"],"cc.Node")
  end
  if self.m_infoList == nil then
    MyPrint("No match name :m_infoList !")
    return false
  end

  if nil ~= DPlinkRewardLuaView["m_goldNumText"] then
      self.m_goldNumText = tolua.cast(DPlinkRewardLuaView["m_goldNumText"],"cc.LabelIF")
  end
  if self.m_goldNumText == nil then
    MyPrint("No match name :m_goldNumText !")
    return false
  end

  if nil ~= DPlinkRewardLuaView["m_goldTitleText"] then
      self.m_goldTitleText = tolua.cast(DPlinkRewardLuaView["m_goldTitleText"],"cc.LabelIF")
  end
  if self.m_goldTitleText == nil then
    MyPrint("No match name :m_goldTitleText !")
    return false
  end

  if nil ~= DPlinkRewardLuaView["m_addTxt1"] then
      self.m_addTxt1 = tolua.cast(DPlinkRewardLuaView["m_addTxt1"],"cc.LabelIF")
  end
  if self.m_addTxt1 == nil then
    MyPrint("No match name :m_addTxt1 !")
    return false
  end

  if nil ~= DPlinkRewardLuaView["m_addTxt2"] then
      self.m_addTxt2 = tolua.cast(DPlinkRewardLuaView["m_addTxt2"],"cc.LabelIF")
  end
  if self.m_addTxt2 == nil then
    MyPrint("No match name :m_addTxt2 !")
    return false
  end

  if nil ~= DPlinkRewardLuaView["m_addTxt3"] then
      self.m_addTxt3 = tolua.cast(DPlinkRewardLuaView["m_addTxt3"],"cc.LabelIF")
  end
  if self.m_addTxt3 == nil then
    MyPrint("No match name :m_addTxt3 !")
    return false
  end

end

return DPlinkRewardView