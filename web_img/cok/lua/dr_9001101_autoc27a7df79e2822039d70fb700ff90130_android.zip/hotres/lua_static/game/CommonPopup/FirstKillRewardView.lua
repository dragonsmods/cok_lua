--[[ 
	首杀奖励领取界面
	2019.6.25	Awen
 ]]

local FirstKillRewardView = class("FirstKillRewardView", function() return PopupBaseView:create() end )
FirstKillRewardView.__index = FirstKillRewardView

function FirstKillRewardView.create(dict)
	local view = FirstKillRewardView.new()
	Drequire("game.CommonPopup.FirstKillRewardView_ui"):create(view,1)
	if view:initView(dict) then
		return view
	end
end

function FirstKillRewardView:initView(dict)
	self.v_data = dictToLuaTable(dict)
	if self.v_data == nil then
		-- print('FirstKillRewardView:initView [data is nil]')
		return
	end
	for i, v in ipairs(self.v_data.reward or {}) do
		dump(v, 'FirstKillRewardView:initView')
	end
	local function touchHandle( eventType, x, y )
        if eventType == "began" then
            return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
			return self:onTouchMoved(x, y)
        else
            self:onTouchEnded(x, y)
        end
    end
    self:registerScriptTouchHandler(touchHandle)
    local touchNode = tolua.cast(self, "cc.CCIFTouchNode")
    touchNode:call("setTouchEnabled", true)
    touchNode:call("setSwallowsTouches" , true)

	-- -------------------------
	local _monsterId = self.v_data.monsterId
	local _monsterLevel = atoi(CCCommonUtilsForLua:call("getPropByIdGroup","field_monster",_monsterId,"level"))
	if _monsterLevel < 30 then
		-- 103759=恭喜您首次战胜了Lv.{0}的怪物！现在可以挑战Lv.{1}的怪物！
		self.ui.m_labelDesc:setString(getLang("103759", CC_ITOA(_monsterLevel), CC_ITOA(_monsterLevel+1)))
	else
		-- 10010028=恭喜您首次战胜了Lv.{0}的怪物！
		self.ui.m_labelDesc:setString(getLang("10010028", CC_ITOA(_monsterLevel)))
	end

	if self.v_data.reward then
		self.ui:setTableViewDataSource("m_tableView", self.v_data.reward)
	end
	
	-- 初始化设置
	self.ui.m_labelTitle:setScale(5)
	self.ui.m_sprTitleLeft:setOpacity(0)
	self.ui.m_sprTitleRight:setOpacity(0)
	self.ui.m_nodeContent:setScaleY(0)

	self.v_canClose = false

	CCSafeNotificationCenter:postNotification("TroopInfoPanel::closeSelf")
	return true
end

function FirstKillRewardView:onEnter() 
	-- 标题动画
	local _titleSeq = cc.Sequence:create(cc.EaseSineIn:create(cc.ScaleTo:create(0.5, 1)))
	self.ui.m_labelTitle:runAction(_titleSeq)

	-- 标题左侧背景动画
	local _leftSeq = cc.Sequence:create(
		cc.DelayTime:create(0.2),
		cc.FadeIn:create(0.3)
	)
	self.ui.m_sprTitleLeft:runAction(_leftSeq)
	
	-- 标题右侧背景动画
	local _rightSeq = cc.Sequence:create(
		cc.DelayTime:create(0.2),
		cc.FadeIn:create(0.3)
	)
	self.ui.m_sprTitleRight:runAction(_rightSeq)

	-- 主内容动画
	local function callback()
		self.v_canClose = true
    end
	local _contentSeq = cc.Sequence:create(
		cc.DelayTime:create(0.5),
		cc.EaseSineIn:create(cc.ScaleTo:create(0.3, 1)),
		cc.CallFunc:create(callback)
	)
	self.ui.m_nodeContent:runAction(_contentSeq)
end

-- 点击领取
function FirstKillRewardView:onClickBtnGet()
	local _dict = CCDictionary:create()
    _dict:setObject(luaToArray(self.v_data.reward), "1")
    _dict:setObject(CCBool:create(true), "2")
	PortActController:comFunc("flyReward",_dict)
	
	PopupViewController:call("removeAllPopupView")
end

function FirstKillRewardView:onTouchBegan(x, y)
	Dprint('FirstKillRewardView:onTouchBegan')
	self.touchBeganX = x
	self.touchBeganY = y
	return true
end

function FirstKillRewardView:onTouchMoved(x, y)
end

function FirstKillRewardView:onTouchEnded(x, y)
	if self.v_canClose and (not isTouchInside(self.ui.m_nodeContent, self.touchBeganX, self.touchBeganY)) 
		and (not isTouchInside(self.ui.m_nodeContent, x, y))then
		self:onClickBtnGet()
	end
end

return FirstKillRewardView
