local CommonPopView = class("CommonPopView", function()
    return PopupBaseView:create()
end)
CommonPopView.__index = CommonPopView

local touchDelta = 100
------------------------------------------ CommonPopView：主界面 Start --------------------------------------------
function CommonPopView:create(info)
    local view = CommonPopView.new()
    Drequire("game.CommonPopup.CommonPopView_ui"):create(view, 0)
    if view:initView(info) == false then
        return nil
    end
    return view
end

function CommonPopView:initView(info)
    Dprint("CommonPopView:initView")
    registerTouchHandler(self)
    self:setTouchEnabled(true)

    if not info or not info.content or "" == info.content then
        Dprint("CommonPopView:initView data error")
        return false
    end

    self.m_info = info
    dump(self.m_info, "CommonPopView info")
    self:refreshView()

    return true
end

function CommonPopView:refreshView(  )
    -- content
    local ContentLabel = cc.Label:createWithSystemFont(self.m_info.content, "Helvetica", 18, cc.size(0.0,0))
    ContentLabel:setPosition(cc.p(0,0))
    ContentLabel:setAnchorPoint(cc.p(0, 0))
    ContentLabel:setSystemFontSize(22)
    ContentLabel:setColor(cc.c3b(222,222,2220))
    ContentLabel:setHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
    ContentLabel:setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_TOP)
    ContentLabel:setDimensions(self.ui.m_infoList:getContentSize().width, 0)
    if ContentLabel:getContentSize().height > self.ui.m_infoList:getContentSize().height then
        local scrollView = cc.ScrollView:create()
        if scrollView ~= nil then
            scrollView:setViewSize(self.ui.m_infoList:getContentSize())
            scrollView:setPosition(cc.p(0,0))
            scrollView:setScale(1.0)
            scrollView:ignoreAnchorPointForPosition(true)
            scrollView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
            self.ui.m_infoList:addChild(scrollView);
            local mainNode = cc.Node:create();
            scrollView:addChild(mainNode);
            mainNode:addChild(ContentLabel)
            mainNode:setPosition(cc.p(0, 0))
            scrollView:setContentSize(ContentLabel:getContentSize())
            scrollView:setContentOffset(CCPoint(0, self.ui.m_infoList:getContentSize().height - ContentLabel:getContentSize().height))
            scrollView:setTouchEnabled(true)
        end
    else
        ContentLabel:setAnchorPoint(cc.p(0.5, 0.5))
        ContentLabel:setPositionX(self.ui.m_infoList:getContentSize().width / 2)
        ContentLabel:setPositionY(self.ui.m_infoList:getContentSize().height / 2)
        self.ui.m_infoList:addChild(ContentLabel)
    end    

    --title
    if self.m_info.title then
        self.ui.m_titleText:setString(self.m_info.title)    
    end
end

function CommonPopView:onTouchBegan(x, y)
    self.touchType = 1
    self.m_startTouchPt = cc.p(x, y)
    return true
end

function CommonPopView:onTouchMoved(x, y)
    if self.touchType == 1 then
        if ccpSquareDistance(self.m_startTouchPt, cc.p(x, y)) > touchDelta then
            self.touchType = 0
        end
    end
end

function CommonPopView:onTouchEnded(x, y)
    if not isTouchInside(self.ui.m_clickArea, x, y) and self.touchType == 1 then
        self:closeSelf()
    end
end

function CommonPopView:onEnter()
    Dprint("CommonPopView:onEnter")
    UIComponent:call("showPopupView", 0)
    -- registerScriptObserver(self, self.refreshSkillViewData, "magic.skill.refresh")
end

function CommonPopView:onExit()
    Dprint("CommonPopView:onExit")
    -- CCSafeNotificationCenter:unregisterScriptObserver(self, "magic.skill.refresh")
end

return CommonPopView