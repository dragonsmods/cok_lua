TipsLongPopupView = class("TipsLongPopupView", function()
        return PopupBaseView:create()
    end
)
TipsLongPopupView.__index = TipsLongPopupView

------------------------------------------ TipsLongPopupView Start --------------------------------------------

function TipsLongPopupView:create(title,content)
    local view = TipsLongPopupView.new()
    if view:initView(title,content) == false then
        return nil
    end
    return view
end

function TipsLongPopupView:initView(title,content)
    if self:init(true, 0) == false then
        MyPrint("TipsLongPopupView init error")
        return false
    end
    MyPrint("TipsLongPopupView init")
    self:setHDPanelFlag(true)
    
    local  proxy = cc.CCBProxy:create()
    local ccbiURL = ""
    ccbiURL = "ccbi/TipsLongPopupView.ccbi"

    local nodeccb = CCBReaderLoad(ccbiURL,proxy, self)
    if nodeccb == nil then
        MyPrint("TipsLongPopupView loadccb error")
        return false
    end

    self.m_bIsPad = CCCommonUtilsForLua:isIosAndroidPad()
    if self.m_bIsPad then
        nodeccb:setScale(2.0)
    else
        nodeccb:setScale(1.0)
    end
    self:setContentSize(cc.Director:getInstance():getIFWinSize())
    self:addChild(nodeccb)
    nodeccb:setPositionY(nodeccb:getPositionY() + 100)

    self.ccbNode = nodeccb
    local function onNodeEvent(event)
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end
    self.ccbNode:registerScriptHandler(onNodeEvent)

    function onTouch(eventType, x, y)  
        if eventType == "began" then  
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)  
        else  
            return self:onTouchEnded(x, y)  
        end
    end
    local touchif = tolua.cast(self,"cc.CCIFTouchNode")
    if touchif ~= nil then
        local dic1 = CCDictionary:create()
        dic1:setObject(CCBool:create(true),"1")
        touchif:comFunc("setTouchEnabled", dic1)

        MyPrint("TipsLongPopupView:registerScriptTouchHandler")
        touchif:registerScriptTouchHandler(onTouch)
    end

    --UI
    self.m_labelTitle:setString(title)    
    local ContentLabel = cc.Label:createWithSystemFont(content, "Helvetica", 18, cc.size(0.0,0))
    ContentLabel:setPosition(cc.p(0,0))
    ContentLabel:setAnchorPoint(cc.p(0, 0))
    ContentLabel:setSystemFontSize(18)
    ContentLabel:setColor(cc.c3b(66,42,0))
    ContentLabel:setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    ContentLabel:setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_TOP)
    ContentLabel:setDimensions(self.m_listNode:getContentSize().width, 0)
    if ContentLabel:getContentSize().height > self.m_listNode:getContentSize().height then
        local scrollView = cc.ScrollView:create()
        if scrollView ~= nil then
            scrollView:setViewSize(self.m_listNode:getContentSize())
            scrollView:setPosition(cc.p(0,0))
            scrollView:setScale(1.0)
            scrollView:ignoreAnchorPointForPosition(true)
            scrollView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
            self.m_listNode:addChild(scrollView);
            local mainNode = cc.Node:create();
            scrollView:addChild(mainNode);
            mainNode:addChild(ContentLabel)
            mainNode:setPosition(cc.p(0, 0))
            scrollView:setContentSize(ContentLabel:getContentSize())
            scrollView:setContentOffset(CCPoint(0, self.m_listNode:getContentSize().height - ContentLabel:getContentSize().height))--cjytest
            scrollView:setTouchEnabled(true)
        end
    else
        ContentLabel:setAnchorPoint(cc.p(0.5, 0.5))
        ContentLabel:setPositionX(self.m_listNode:getContentSize().width / 2)
        ContentLabel:setPositionY(self.m_listNode:getContentSize().height / 2)
        self.m_listNode:addChild(ContentLabel)
    end    
    return true
end

function TipsLongPopupView:onEnter()

end

function TipsLongPopupView:onExit()
end

function TipsLongPopupView:onTouchBegan(x, y)
    return true
end

function TipsLongPopupView:onTouchMoved(x, y)
end

function TipsLongPopupView:onTouchEnded(x, y)
    if touchInside(self.m_clickArea, x, y) == false then
        MyPrint("TipsLongPopupView:onTouchEnded not touchInside m_touchNode")
        self:call("closeSelf")
    end
end

return TipsLongPopupView







