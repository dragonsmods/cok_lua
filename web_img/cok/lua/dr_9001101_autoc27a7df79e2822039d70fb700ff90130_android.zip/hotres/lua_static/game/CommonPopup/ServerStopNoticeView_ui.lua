----------------------------
-- Author: Elex
-- Date: 2021-01-05 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local ServerStopNoticeView_ui = class("ServerStopNoticeView_ui")

--#ui propertys


--#function
function ServerStopNoticeView_ui:create(owner, viewType, paramTable)
	local ret = ServerStopNoticeView_ui.new()
	CustomUtility:LoadUi("ServerStopNoticeView.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function ServerStopNoticeView_ui:initLang()
	ButtonSmoker:setText(self.m_knowBtn, "101189")
end

function ServerStopNoticeView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function ServerStopNoticeView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function ServerStopNoticeView_ui:onClickKnow(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickKnow", pSender, event)
end

return ServerStopNoticeView_ui

