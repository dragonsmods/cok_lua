--[[
	YesNo对话框
	2019.7.12	Awen
]]

local YesNoDialog2 = class("YesNoDialog2", function() return PopupBaseView:create() end)
YesNoDialog2.__index = YesNoDialog2

--------------------------------------------------------------------------
function YesNoDialog2.create(title, content, okCallback, params)
	local view = YesNoDialog2.new()
	Drequire("game.CommonPopup.YesNoDialog2_ui"):create(view, 0)

	view:initView(title, content, okCallback, params)
  	return view
end

function YesNoDialog2:initView(title, content, okCallback, params)
	-- dump(params, "YesNoDialog2:initView")
	local function touchHandle( eventType, x, y )
        if eventType == "began" then
            return self:onTouchBegan(x, y)
        elseif eventType == "moved" then
        else
            self:onTouchEnded(x, y)
        end
    end
    self:registerScriptTouchHandler(touchHandle)
    local touchNode = tolua.cast(self, "cc.CCIFTouchNode")
    touchNode:call("setTouchEnabled", true)
    touchNode:call("setSwallowsTouches" , true)

	self.v_okCallback = okCallback

	if params then
		self.m_params = params
		if params.oneBtnOK then
			self.ui.m_btnOK:setPositionX(0)
			self.ui.m_btnCancel:setVisible(false)
		end
	end

	-- 标题
	self.ui.m_labelTitle:setString(title)

	-- 内容
	self.ui.m_labelContent:setString(content)
	self:update()
end

function YesNoDialog2:update()
	if self.m_params 
		and self.m_params.contentEndTime
		and self.m_params.beUpdate
		then
		local offTime = self.m_params.contentEndTime - getTimeStamp()
		if offTime < 0 then
			offTime = 0
		end
		local content
		if self.m_params.contentWithTime then
			content = getLang(self.m_params.contentWithTime, format_time(offTime))
		elseif self.m_params.contentLinkTime then
			content = getLang(self.m_params.contentLinkTime) .. "\n" ..getLang("150889", format_time(offTime))
		end
		self.ui.m_labelContent:setString(content)
	end
end

-- 点击确定
function YesNoDialog2:onClickBtnOK()
	if self.v_okCallback then
		self.v_okCallback()
	end
	self:closeSelf()
end

-- 点击取消
function YesNoDialog2:onClickBtnCancel(  )
	self:closeSelf()
end

function YesNoDialog2:closeSelf(  )
	PopupViewController:call("removePopupView", self)
end


function YesNoDialog2:onTouchBegan(x, y)
	self.touchBeganX = x
	self.touchBeganY = y
	return true
end

function YesNoDialog2:onTouchEnded(x, y)
	if (not isTouchInside(self.ui.m_nodeBg, self.touchBeganX, self.touchBeganY)) then
		self:onClickBtnCancel()
	end
end

function YesNoDialog2:onEnter()
	-- dump("YesNoDialog2:onEnter")
	if self.m_params 
		and self.m_params.beUpdate 
		and self.m_params.contentEndTime
		then
	    self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:update(dt) end, 1, false)
	end
end

function YesNoDialog2:onExit()
	-- dump("YesNoDialog2:onExit")
	if self.m_entryId then
	    self:getScheduler():unscheduleScriptEntry(self.m_entryId)
	    self.m_entryId = nil
	end
end


return YesNoDialog2