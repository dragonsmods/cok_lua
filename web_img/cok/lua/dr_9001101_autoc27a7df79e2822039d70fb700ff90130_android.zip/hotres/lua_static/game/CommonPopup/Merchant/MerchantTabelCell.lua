--@author: mm
--@date: 2016-11-14

--前置声明
--local print = print
local loprint = function(...)
    -- print(...)
end

local mc_path = "game.CommonPopup.Merchant.MerchantCell"
-- package.loaded[mc_path] = nil
local MerchantCell = Drequire(mc_path)

--类定义
local MerchantTabelCell = class("MerchantTabelCell", 
    function()
        return CCTableViewCell:new()
    end
)

-- MerchantTabelCell.__index = MerchantTabelCell

--fields
MerchantTabelCell.mCell = nil -- MerchantCell

--functions
function MerchantTabelCell:create(index, touchNode) --(int, ccnode)
    local tbcell = MerchantTabelCell.new()
    if not tbcell:init(index, touchNode) then
        return nil
    end
    return tbcell
end

function MerchantTabelCell:init(index, touchNode) --(int, ccnode)
    local ret = true
    self.mCell = MerchantCell:create(index, touchNode)
    if (self.mCell ~= nil) then
        self:addChild(self.mCell)
    end
    return ret
end

function MerchantTabelCell:setData(index, bAnimate) -- (int, bool)
    if (self.mCell) then
        if not bAnimate then
            self.mCell:setDataIndex(index)
            self.mCell:setData()
            self.mCell:animationCallback()
        else
            self.mCell:setDataIndex(index)
            if (index>0) then
                local delay = cc.DelayTime:create(index*0.3)
                local luafunc = function ()
                    self:playAnimation()
                end 
                local cfunc = cc.CallFunc:create(luafunc)
                local seqAction = cc.Sequence:create(delay, cfunc)
                self.mCell:runAction(seqAction)
            else
                self:playAnimation()
            end
        end
    end
end

function MerchantTabelCell:playAnimation()
    if (self.mCell) then
        self.mCell:playAnimation(true)
    end
end

return MerchantTabelCell