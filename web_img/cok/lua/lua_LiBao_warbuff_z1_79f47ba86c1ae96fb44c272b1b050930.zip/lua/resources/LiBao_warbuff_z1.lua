cfg_table = {
	["layerX"] = -17,
	["layerY"] = -30,
	["layerScale"] = 1.4,
}