local localize={
	["CN"]=1, 
}
return localize
