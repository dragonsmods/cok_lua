----------------------------
-- Author: Elex
-- Date: 2020-08-05 Wednesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local AuctionHouseView_ui = class("AuctionHouseView_ui")

--#ui propertys


--#function
function AuctionHouseView_ui:create(owner, viewType, paramTable)
	local ret = AuctionHouseView_ui.new()
	CustomUtility:LoadUi("AuctionHouseView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function AuctionHouseView_ui:initLang()
end

function AuctionHouseView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function AuctionHouseView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function AuctionHouseView_ui:onTabEmpty(pSender, event)
	ButtonSmoker:forwardFunction(self, "onTabEmpty", pSender, event)
end

function AuctionHouseView_ui:onTabClick1(pSender, event)
	ButtonSmoker:forwardFunction(self, "onTabClick1", pSender, event)
end

function AuctionHouseView_ui:onTabClick2(pSender, event)
	ButtonSmoker:forwardFunction(self, "onTabClick2", pSender, event)
end

function AuctionHouseView_ui:onTabClick3(pSender, event)
	ButtonSmoker:forwardFunction(self, "onTabClick3", pSender, event)
end

function AuctionHouseView_ui:onTabClick4(pSender, event)
	ButtonSmoker:forwardFunction(self, "onTabClick4", pSender, event)
end

function AuctionHouseView_ui:onControlButton102(pSender, event)
	ButtonSmoker:forwardFunction(self, "onControlButton102", pSender, event)
end

function AuctionHouseView_ui:onAcutionRecordClicked(pSender, event)
	ButtonSmoker:forwardFunction(self, "onAcutionRecordClicked", pSender, event)
end

function AuctionHouseView_ui:onPersonalRecordClicked(pSender, event)
	ButtonSmoker:forwardFunction(self, "onPersonalRecordClicked", pSender, event)
end

function AuctionHouseView_ui:onAcutionHonorClicked(pSender, event)
	ButtonSmoker:forwardFunction(self, "onAcutionHonorClicked", pSender, event)
end

function AuctionHouseView_ui:onControlButton102(pSender, event)
	ButtonSmoker:forwardFunction(self, "onControlButton102", pSender, event)
end

function AuctionHouseView_ui:onBtnGetMoneyBackClicked(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBtnGetMoneyBackClicked", pSender, event)
end

function AuctionHouseView_ui:onBtnAnymousAuctionClicked(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBtnAnymousAuctionClicked", pSender, event)
end

function AuctionHouseView_ui:onHelpButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onHelpButtonClick", pSender, event)
end

function AuctionHouseView_ui:onSwitch1Click(pSender, event)
	ButtonSmoker:forwardFunction(self, "onSwitch1Click", pSender, event)
end

function AuctionHouseView_ui:onSwitch2Click(pSender, event)
	ButtonSmoker:forwardFunction(self, "onSwitch2Click", pSender, event)
end

function AuctionHouseView_ui:onClickBtnTip(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnTip", pSender, event)
end

function AuctionHouseView_ui:onControlButton102(pSender, event)
	ButtonSmoker:forwardFunction(self, "onControlButton102", pSender, event)
end

function AuctionHouseView_ui:onSupHelpButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onSupHelpButtonClick", pSender, event)
end

function AuctionHouseView_ui:onGivePriceClicked(pSender, event)
	ButtonSmoker:forwardFunction(self, "onGivePriceClicked", pSender, event)
end

function AuctionHouseView_ui:onAddPriceClicked(pSender, event)
	ButtonSmoker:forwardFunction(self, "onAddPriceClicked", pSender, event)
end

function AuctionHouseView_ui:initTableView()
	TableViewSmoker:createView(self, "m_pTableView4", "game.CommonPopup.AuctionHouse.AuctionHouseCell", 1, 2, "AuctionHouseCell")
	TableViewSmoker:createView(self, "m_pTableViewNew", "game.CommonPopup.AuctionHouse.AuctionHouseCell", 1, 2, "AuctionHouseCell")
	TableViewSmoker:createView(self, "m_pTableView", "game.CommonPopup.AuctionHouse.AuctionHouseCell", 1, 2, "AuctionHouseCell")
end

function AuctionHouseView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return AuctionHouseView_ui

