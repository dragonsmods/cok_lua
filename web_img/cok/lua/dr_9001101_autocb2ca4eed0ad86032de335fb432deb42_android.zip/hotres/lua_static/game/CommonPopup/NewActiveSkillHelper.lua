NewActiveSkillHelper = NewActiveSkillHelper or {}

NewUseSkillCommand = class("NewUseSkillCommand", LuaCommandBase)
NewCancelSkillCommand = class("NewCancelSkillCommand", LuaCommandBase)
NewUseSkillViewItemView = class("NewUseSkillViewItemView", function (  )
	return PopupBaseView:call("create")
end)
NewKingBiographySkillListCommand = class("NewKingBiographySkillListCommand", LuaCommandBase)

function NewUseSkillCommand:ctor( skillId)
	MyPrint("NewUseSkillCommand:ctor ", skillId)
	self.super.ctor(self, "skill.use")

	self:putParam("skillId", CCString:create(tostring(skillId)))

	self.cacheSkillId = skillId
	local ginfo = GlobalData:call("getSelfGeneralInfo")
	if ginfo then
		self:putParam("gUid", CCString:create(tostring(ginfo:getProperty("uuid"))))
	end
end

function NewUseSkillCommand:handleReceive( dict )
	local cmdname = dict:valueForKey("cmd"):getCString()
	if cmdname ~= "skill.use" then
		return false
	end
	MyPrint("NewUseSkillCommand:handleReceive")
	local params = dict:objectForKey("params")
	if nil == params then
		return true
	end
	params:setObject(CCString:create(self.cacheSkillId), "cacheSkillId")
	if params:objectForKey("errorCode") ~= nil then
		local errorCode = params:valueForKey("errorCode"):getCString()
		MyPrint("NewUseSkillCommand:handleReceive ... errorCode .. " .. errorCode)
		CCCommonUtilsForLua:call("flyText", getLang(errorCode))
		CCSafeNotificationCenter:call("postNotification", "msg_useskillcmd_fail", params)
		return true
	end

	local skillId = params:valueForKey("skillId"):getCString()
	if skillId == "" then
		return true
	end

	GeneralManager:call("updateOneSkillCDInfo", params)

	local effectState = params:objectForKey("effectState")
	if effectState and effectState:objectForKey("501051") then
		local protectTime = effectState:valueForKey("501051"):doubleValue()
		local playerInfo = GlobalData:call("getPlayerInfo")
		playerInfo:setProperty("resourceProtectTimeStamp", protectTime)
	end
	if params:objectForKey("use_item") then
		ToolController:call("pushAddTool", params:objectForKey("use_item"))
	end

	CCSafeNotificationCenter:call("postNotification", "msg_useskillcmd_success", params)
	return true
end


function NewCancelSkillCommand:ctor( skillId, itemId )
	self.super.ctor(self, "skill.del")

	self:putParam("skillId", CCString:create(tostring(skillId)))

	local ginfo = GlobalData:call("getSelfGeneralInfo")
	if ginfo then
		self:putParam("gUid", CCString:create(tostring(ginfo:getProperty("uuid"))))
	end
end

function NewCancelSkillCommand:handleReceive( dict )
	local cmdname = dict:valueForKey("cmd"):getCString()
	if cmdname ~= "skill.del" then
		return false
	end
	MyPrint("NewCancelSkillCommand:handleReceive")
	local params = dict:objectForKey("params")
	if nil == params then
		return true
	end
	if params:objectForKey("errorCode") ~= nil then
		local errorCode = params:valueForKey("errorCode"):getCString()
		MyPrint("NewUseSkillCommand:handleReceive ... errorCode .. " .. errorCode)
		CCCommonUtilsForLua:call("flyText", getLang(errorCode))
		return true
	end

	local skillId = params:valueForKey("skillId"):getCString()
	if skillId == "" then
		return true
	end

	GeneralManager:call("updateOneSkillCDInfo", params)

	CCSafeNotificationCenter:call("postNotification", "skill.del")
	CCSafeNotificationCenter:call("postNotification", "msg_cancelskillcmd_back", CCString:create(skillId))
	return true
end

function NewUseSkillViewItemView:ctor( id, father )
	self.id = id
	self.father = father
end

function NewUseSkillViewItemView.create( id, father )
	local ret = NewUseSkillViewItemView.new(id, father)
	if ret:initSelf() ~= true then
		ret = nil 
	end
	return ret
end

function NewUseSkillViewItemView:initSelf(  )
	self:init(true, 0)
	self:setHDPanelFlag(true)

	local winsize = cc.Director:getInstance():getIFWinSize()
	self:setContentSize(winsize)
	local proxy = cc.CCBProxy:create()
    local ccbiUrl = "UseSkillViewCCB_ttt.ccbi"
	local node = CCBReaderLoad(ccbiUrl, proxy, self)
	self:addChild(node)

	if CCCommonUtilsForLua:call("isIosAndroidPad") then
		self.m_mainNode:setScale(2)
	end

	self.touchLayer = cc.Layer:create()
	self:addChild(self.touchLayer)
	self.startTouchPt = cc.p(0, 0)
	local function touchHandle( eventType, x, y )
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		else
			self:onTouchEnded(x, y)
		end
	end
	self.touchLayer:registerScriptTouchHandler(touchHandle)
	self.touchLayer:setTouchEnabled(true)
	self.touchLayer:setSwallowsTouches(false)

	local function onNodeEvent( event )
		if event == "enter" then
			self:onEnter()
	    elseif event == "exit" then
	    	self:onExit()
	    end
	end
	self:registerScriptHandler(onNodeEvent)

	local cdinfo = GeneralManager:call("getSkillCDInfoById", self.id)
	local generalInfo = GlobalData:call("getSelfGeneralInfo")
	if nil == generalInfo then
		return false
	end

	self.m_skillName:setString(getLang(CCCommonUtilsForLua:call("getPropById", self.id, "name")))
	local dialog = CCCommonUtilsForLua:call("getPropById", self.id, "description")
	local base = CCCommonUtilsForLua:call("getPropById", self.id, "")
	local t = math.tonumber(CCCommonUtilsForLua:call("getPropById", self.id, "type"))
	if t == 12 or t == 13 or t == 15 then
		self.m_descTxt:setString(getLang(dialog, base))
	elseif t == 14 then
		local ta = string.split(base, "|")
		if #ta == 2 then
			self.m_descTxt:setString(getLang(dialog, ta[1], ta[2]))
		end
	else
		self.m_descTxt:setString(getLang(dialog))
	end

	local iconstr = CCCommonUtilsForLua:call("getPropById", self.id, "icon") .. ".png"
	local head = CCLoadSprite:call("createSprite", iconstr)
	self.m_head:addChild(head)

	CCCommonUtilsForLua:call("setButtonTitle", self.m_useBtn1, getLang("150765"))
	CCCommonUtilsForLua:call("setButtonTitle", self.m_useBtn2, getLang("150766"))
	self.m_skillEffectNode1:setVisible(false)
	self.m_skillEffectNode2:setVisible(false)

	if self.id == "612400" then
		CCCommonUtilsForLua:call("setButtonTitle", self.m_useBtn1, "")
		CCCommonUtilsForLua:call("setButtonTitle", self.m_useBtn2, "")

		self.m_skillEffectNode1:setVisible(true)
		self.m_skillEffectNode2:setVisible(true)

		self.m_skillUse1:setString(getLang("150765"))
		self.m_skillUse2:setString(getLang("150766"))
	elseif self.id == "602700" then --救援不显示使用道具按钮
		self.m_useBtn2:setVisible(false)
		self.m_useBtn1:setPositionX(self.m_useBtn:getPositionX())
	end

	return true
end

function NewUseSkillViewItemView:onTouchBegan( x, y )
	self.startTouchPt = cc.p(x, y)
	if isTouchInside(self.m_clickArea, x, y) == false then
		return true
	end
	return false
end

function NewUseSkillViewItemView:onTouchEnded( x, y )
	if isTouchInside(self.m_clickArea, x, y) then
		return
	end

	self:call("closeSelf")
end

function NewUseSkillViewItemView:onEnter(  )
	-- body
end

function NewUseSkillViewItemView:onExit(  )
	-- body
end

function NewUseSkillViewItemView:onUseClick1(  )
	local id = self.id
	local father = self.father
	self:call("closeSelf")
	if id == "612400" then
		father:addResourceFunction(false)
	else
		father.m_skillItemId = ""
		father:generalUseClick()
	end
end

function NewUseSkillViewItemView:onUseClick2(  )
	local id = self.id
	local father = self.father
	self:call("closeSelf")
	if id == "612400" then
		father:addResourceFunction(true)
	else
		father.m_skillItemId = CCCommonUtilsForLua:call("getPropById", id, "item")
		father:generalUseClick()
	end
end

--------------------------------------------

function NewKingBiographySkillListCommand:ctor()
	MyPrint("NewKingBiographySkillListCommand:ctor ", skillId)
	self.super.ctor(self, "kingdomBiography.skill")
end

function NewKingBiographySkillListCommand:handleReceive( dict )
	local tbl, params = self:parseMsg(dict)
	-- dump(tbl, "NewKingBiographySkillListCommand:handleReceive")
    if type(tbl) == "boolean" then
        return tbl
	end
	require("game.general.GeneralManagerIns").getInstance():updateExternSkill(tbl)
	CCSafeNotificationCenter:postNotification("ActiveSkillView.updateKingBiographySkill", params) 
	CCSafeNotificationCenter:postNotification(MessageType.MSG_BATTLE_ACTIVE_BUFF_TABLEVIEW)

    return true
end

--刚激活
local tag_use = 666
--持续中
local tag_active = 888

--增加技能使用特效
function NewActiveSkillHelper:addSkUseParticle(node)
	if not node then return end
	if node:getChildByTag(tag_use) then return end
	node:removeChildByTag(tag_active)

	local tagNode = cc.Node:create()
	tagNode:setTag(tag_use)

	local format = "particle/SkillIconGlowR_%d"
	for index = 1, 4 do
		local path = string.format(format, index)
		local particle = ParticleController:call("createParticleForLua", path)
		tagNode:addChild(particle)
	end
	node:addChild(tagNode)
end

--增加技能激活特效
function NewActiveSkillHelper:addSkAcParticle(node)
	if not node then return end
	if node:getChildByTag(tag_active) then return end
	node:removeChildByTag(tag_use)

	local tagNode = cc.Node:create()
	tagNode:setTag(tag_active)
	
	local format = "particle/HeroSkill_%d"
	for index = 0, 1 do
		local path = string.format(format, index)
		local particle = ParticleController:call("createParticleForLua", path)
		tagNode:addChild(particle)
	end
	node:addChild(tagNode)
end

--一键使用记录
function NewActiveSkillHelper:insertOnekeySkills(skills)
	-- if not self.onekeySkills then
	-- 	self.onekeySkills = self:getSkillByDefault()
	-- end

	--应策划需求 暂时关闭一键使用红点提示
	if true then return end

	self.onekeySkills = self.onekeySkills or {}
	
	for skillId, sType in pairs(skills) do
		self.onekeySkills[skillId] = sType
	end

	-- local redDotNum = sizen(self.onekeySkills)
	-- CCSafeNotificationCenter:postNotification("msg.skill.dot", CCInteger:create(redDotNum))
	-- self:saveOnekeySkills()
end

function NewActiveSkillHelper:saveOnekeySkills()
	if not self.onekeySkills then return end

	local t = {}
	for skillId, sType in pairs(self.onekeySkills) do
		table.insert(t, string.join(";", skillId, sType)) 
	end

	local mineUid = PlayerInfoController:getUid()
	local strKey = string.join("", "NewActiveSkillOneKey", mineUid)

	--重置接镖停留驿站设置
	cc.UserDefault:getInstance():setStringForKey(strKey, table.concat(t, "|"))
	cc.UserDefault:getInstance():flush()
end

function NewActiveSkillHelper:getSkillByDefault()
	local onekeySkills  = {}
	local mineUid = PlayerInfoController:getUid()
	local strKey = string.join("", "NewActiveSkillOneKey", mineUid)
	
	local skillStr = cc.UserDefault:getInstance():getStringForKey(strKey, "")
	local slots = splitString(skillStr, "|")
	for _, slot in ipairs(slots) do
		local data = splitString(slot, ";")
		onekeySkills[data[1]] = data[2]
	end

	return onekeySkills
end

function NewActiveSkillHelper:isSkillInRecord(skillId)
	-- if not self.onekeySkills then
	-- 	self.onekeySkills = self:getSkillByDefault()
	-- end
	self.onekeySkills = self.onekeySkills or {}

	return self.onekeySkills[skillId] and true or false
end

function NewActiveSkillHelper:clearSkillByType(sType)
	-- if not self.onekeySkills then
	-- 	self.onekeySkills = self:getSkillByDefault()
	-- end
	self.onekeySkills = self.onekeySkills or {}

	if sType then
		for skillId, _type in pairs(self.onekeySkills) do
			if atoi(_type) == atoi(sType) then
				self.onekeySkills[skillId] = nil
			end
		end 
	else
		self.onekeySkills = {}
	end

	-- local redDotNum = sizen(self.onekeySkills)
	-- CCSafeNotificationCenter:postNotification("msg.skill.dot", CCInteger:create(redDotNum))
	-- self:saveOnekeySkills()
end

function NewActiveSkillHelper:getSkillCountByType(sType)
	-- if not self.onekeySkills then
	-- 	self.onekeySkills = self:getSkillByDefault()
	-- end
	self.onekeySkills = self.onekeySkills or {}

	local count = 0
	for skillId, _type in pairs(self.onekeySkills) do
		if atoi(_type) == atoi(sType) or (not sType) then
			count = count + 1
		end
	end

	return count
end

return NewActiveSkillHelper