---------------------------信息 Start ---------------------------
NewMerchantInfoCmd = class("NewMerchantInfoCmd", LuaCommandBase)


function NewMerchantInfoCmd.create()
    local ret = NewMerchantInfoCmd.new()
    ret:initWithName("hot.item.v2.get")
    return ret
end

function NewMerchantInfoCmd:handleReceive(dict)
    GameController:call("getInstance"):call("removeWaitInterface")
    CCSafeNotificationCenter:postNotification("NewMerchant_Fail_CB",params)
    local flag, params = self:parseMsg(dict)
    Dprint("BalanceInputCmd:handleReceive | parse flag=", flag)
    if (type(flag) == "boolean") then
        return flag
    end
    ToolController:call("retMerchantItems", params)
    if (params:objectForKey("remainGold")) then
        local gold = params:valueForKey("remainGold"):doubleValue()
        local gd = GlobalData:call("shared")
        local playerInfo = gd:call("getPlayerInfo") 
        playerInfo:setProperty("gold", gold)
        CCSafeNotificationCenter:postNotification(MSG_CITY_RESOURCES_UPDATE)
    end
    CCSafeNotificationCenter:postNotification("NewMerchantInfo_CB",params)
    return true
end
--------------------------- 信息 End ---------------------------

---------------------------V2刷新 Start ---------------------------
NewMerchantRefreshCmd = class("NewMerchantRefreshCmd", LuaCommandBase)
function NewMerchantRefreshCmd.create()
    local ret = NewMerchantRefreshCmd.new()
    ret:initWithName("hot.item.refresh")
    return ret
end

function NewMerchantRefreshCmd:handleReceive(dict)
    GameController:call("getInstance"):call("removeWaitInterface")
    CCSafeNotificationCenter:postNotification("NewMerchant_Fail_CB",params)
    local flag, params = self:parseMsg(dict)
    Dprint("BalanceInputCmd:handleReceive | parse flag=", flag)
    if (type(flag) == "boolean") then
        return flag
    end
    ToolController:call("retMerchantItems", params)
    if (params:objectForKey("remainGold")) then
        local gold = params:valueForKey("remainGold"):doubleValue()
        local gd = GlobalData:call("shared")
        local playerInfo = gd:call("getPlayerInfo") --it's a table?
        playerInfo:setProperty("gold", gold)
        CCSafeNotificationCenter:postNotification(MSG_CITY_RESOURCES_UPDATE)
    end
    CCSafeNotificationCenter:postNotification("NewMerchantRefresh_CB",params)
    return true
end
--------------------------- 信息 End ---------------------------

---------------------------V3刷新 Start ---------------------------
NewMerchantV3RefreshCmd = class("NewMerchantV3RefreshCmd", LuaCommandBase)
function NewMerchantV3RefreshCmd.create()
    local ret = NewMerchantV3RefreshCmd.new()
    ret:initWithName("hot.item.refreshV3")
    return ret
end

function NewMerchantV3RefreshCmd:handleReceive(dict)
    GameController:call("getInstance"):call("removeWaitInterface")
    CCSafeNotificationCenter:postNotification("NewMerchant_Fail_CB",params)
    local flag, params = self:parseMsg(dict)
    Dprint("BalanceInputCmd:handleReceive | parse flag=", flag)
    if (type(flag) == "boolean") then
        return flag
    end
    ToolController:call("retMerchantItems", params)
    if (params:objectForKey("remainGold")) then
        local gold = params:valueForKey("remainGold"):doubleValue()
        local gd = GlobalData:call("shared")
        local playerInfo = gd:call("getPlayerInfo") --it's a table?
        playerInfo:setProperty("gold", gold)
        CCSafeNotificationCenter:postNotification(MSG_CITY_RESOURCES_UPDATE)
    end
    CCSafeNotificationCenter:postNotification("NewMerchantRefresh_CB",params)
    return true
end
--------------------------- 信息 End ---------------------------

---------------------------V3购买 Start ---------------------------
NewMerchantV3BuyCmd = class("NewMerchantV3BuyCmd", LuaCommandBase)
function NewMerchantV3BuyCmd.create(itemId, itemNum, price, priceType, Allnum)
    local ret = NewMerchantV3BuyCmd.new()
    ret:initWithName("hot.item.v3.buy")
    ret:putParam("itemId", CCString:create(tostring(itemId)))
    ret:putParam("itemNum", CCInteger:create(itemNum))
    ret:putParam("price", CCInteger:create(price))
    ret:putParam("priceType", CCInteger:create(priceType))
    ret:putParam("num", CCInteger:create(tonumber(Allnum)))
    return ret
end

function NewMerchantV3BuyCmd:handleReceive(dict)
    GameController:call("getInstance"):call("removeWaitInterface")
    CCSafeNotificationCenter:postNotification("NewMerchant_Fail_CB",params)
    local flag, params = self:parseMsg(dict)
    Dprint("BalanceInputCmd:handleReceive | parse flag=", flag)
    if (type(flag) == "boolean") then
        return flag
    end
    local tbl = dictToLuaTable(params)
    if (params:objectForKey("remainGold")) then
        local gold = params:valueForKey("remainGold"):doubleValue()
        local gd = GlobalData:call("shared")
        local playerInfo = gd:call("getPlayerInfo") --it's a table?
        playerInfo:setProperty("gold", gold)
    end
    if (params:objectForKey("remainCrystal")) then
        local remainCrystal = params:valueForKey("remainCrystal"):doubleValue()
        local gd = GlobalData:call("shared")
        local playerInfo = gd:call("getPlayerInfo") --it's a table?
        playerInfo:setProperty("longJing", remainCrystal)
    end
    if (params:objectForKey("resource")) then
        local resourceInfo = GlobalData:call("shared"):getProperty("resourceInfo")
        resourceInfo:call("setResourceData", params:objectForKey("resource"))
    end
    CCSafeNotificationCenter:postNotification(MSG_CITY_RESOURCES_UPDATE)
    CCSafeNotificationCenter:postNotification("NewMerchantRefreshView_CB",params)
    ToolController:call("getInstance"):call("retBuyMerchantTool", params)
    return true
end
--------------------------- 信息 End ---------------------------

---------------------------V2购买 Start ---------------------------
NewMerchantV2BuyCmd = class("NewMerchantV2BuyCmd", LuaCommandBase)
function NewMerchantV2BuyCmd.create(itemId, itemNum, price, priceType, Allnum)
    local ret = NewMerchantV2BuyCmd.new()
    ret:initWithName("hot.item.v2.buy")
    ret:putParam("itemId", CCString:create(tostring(itemId)))
    ret:putParam("itemNum", CCInteger:create(itemNum))
    ret:putParam("price", CCInteger:create(price))
    ret:putParam("priceType", CCInteger:create(priceType))
    ret:putParam("num", CCInteger:create(tonumber(Allnum)))
    return ret
end

function NewMerchantV2BuyCmd:handleReceive(dict)
    GameController:call("getInstance"):call("removeWaitInterface")
    CCSafeNotificationCenter:postNotification("NewMerchant_Fail_CB",params)
    local flag, params = self:parseMsg(dict)
    Dprint("BalanceInputCmd:handleReceive | parse flag=", flag)
    if (type(flag) == "boolean") then
        return flag
    end
    local tbl = dictToLuaTable(params)
    if (params:objectForKey("remainGold")) then
        local gold = params:valueForKey("remainGold"):doubleValue()
        local gd = GlobalData:call("shared")
        local playerInfo = gd:call("getPlayerInfo") --it's a table?
        playerInfo:setProperty("gold", gold)
    end
    if (params:objectForKey("remainCrystal")) then
        local remainCrystal = params:valueForKey("remainCrystal"):doubleValue()
        local gd = GlobalData:call("shared")
        local playerInfo = gd:call("getPlayerInfo") --it's a table?
        playerInfo:setProperty("longJing", remainCrystal)
    end
    if (params:objectForKey("resource")) then
        local resourceInfo = GlobalData:call("shared"):getProperty("resourceInfo")
        resourceInfo:call("setResourceData", params:objectForKey("resource"))
    end
    CCSafeNotificationCenter:postNotification(MSG_CITY_RESOURCES_UPDATE)
    CCSafeNotificationCenter:postNotification("NewMerchantRefreshView_CB",params)
    ToolController:call("getInstance"):call("retBuyMerchantTool", params)
    return true
end
--------------------------- 信息 End ---------------------------
