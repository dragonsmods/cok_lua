local itemCellH1 = 145

local NewActiveSkillViewBuffCellSubitem = class("NewActiveSkillViewBuffCellSubitem",
	function()
		return cc.Layer:create()
	end
)
NewActiveSkillViewBuffCellSubitem.__index = NewActiveSkillViewBuffCellSubitem

---------------------------------NewActiveSkillViewBuffCellSubitem--------------------------------
function NewActiveSkillViewBuffCellSubitem:create(itemId, objId, qid)
	local node = NewActiveSkillViewBuffCellSubitem.new()
	if (node:initNode(itemId, objId, qid)) then return node end
end

function NewActiveSkillViewBuffCellSubitem:initNode(itemId, objId, qid)
	local ccbUri = "ActivSkill_Buff_Cell_Subitem.ccbi"
	local proxy = cc.CCBProxy:create()
	local node = CCBReaderLoad(ccbUri, proxy, self)

	local function onNodeEvent(event)
		if event == "enter" then
			self:onEnter()
		elseif event == "exit" then
			self:onExit()
		elseif event == "cleanup" then
			self:onCleanup()
			end
	end
	node:registerScriptHandler(onNodeEvent)
	self:addChild(node)

	self:setData(itemId, objId, qid)

	return true
end

function NewActiveSkillViewBuffCellSubitem:setData(itemId, objId, qid)
	self.m_itemId = itemId
	self.m_objId = objId
	self.m_qid = qid

	self.m_picNode:removeAllChildren()
	self.m_des2Label:setString("")

	if (self.m_itemId == 0) then
		if (objId == "customskin") then
			self.m_nameLabel:setString(getLang("101458"))
			self.m_desLabel:setString(getLang("101460"))
			self.m_numLabel:setString("")
			self.m_useBtn:setVisible(true)
			self.m_buyNode:setVisible(false)
			self.m_buyBtn:setEnabled(false)
			self.m_useBtn:setEnabled(true)
			CCCommonUtilsForLua:setButtonTitle(self.m_useBtn, getLang("108532"))
			local pic = CCLoadSprite:call("createSprite", "uncityskin_icon.png")
			self.m_picNode:addChild(pic)
		else
			self.m_numLabel:setString("")
			self.m_nameLabel:setString(getLang("103669"))
			self.m_des2Label:setString(getLang("103671"))
			self.m_buyNode:setVisible(false)
			CCCommonUtilsForLua:setButtonTitle(self.m_useBtn, getLang("103672"))
			CCCommonUtilsForLua:call("setButtonSprite", self.m_useBtn, "btn_green4.png")

			self.m_useBtn:setVisible(true)
			self.m_buyNode:setVisible(false)
			self.m_buyBtn:setEnabled(false)
			local curTime = GlobalData:call("getWorldTime")
			-- local queueInfos = GlobalData:call("shared"):getProperty("allQueuesInfo")
			-- local finishTime = queueInfos[self.m_qid]:getProperty("finishTime")
			local finishTime = QueueController:call("shared"):call("getFinishTimeByKey", self.m_qid)
			local tmpTime = finishTime - curTime
			local freeSpdT = GlobalData:call("shared"):getProperty("freeSpdT")
			if (tmpTime < freeSpdT) then
				self.m_useBtn:setEnabled(true)
				self.m_desLabel:setString("")
			else
				self.m_lockNode:removeAllChildren()
				local picLock = CCLoadSprite:call("createSprite", "iron_lock.png")
				picLock:setScale(0.5)
				self.m_lockNode:addChild(picLock)
				self.m_useBtn:setEnabled(false)
				self.m_desLabel:setString(getLang("103670", format_time(tmpTime - freeSpdT)))
			end

			local pic = CCLoadSprite:call("createSprite", "iron_lock.png")
			self.m_picNode:addChild(pic)
		end
	else
		local toolInfo = ToolController:call("getToolInfoByIdForLua", itemId)
		local name = toolInfo:call("getName")
		local des = getLang(toolInfo:getProperty("des"))
		local cnt = toolInfo:call("getCNT")

		self.m_nameLabel:setString(name)
		self.m_desLabel:setString(des)
		self.m_numLabel:setString(tostring(cnt))

		self.m_price = toolInfo:getProperty("price")
		CCCommonUtilsForLua:createGoodsIcon(toolInfo:getProperty("itemId"), self.m_picNode, cc.size(92, 92))

		self.m_inBtnGoldNum:setString(CC_CMDITOA(self.m_price))
		CCCommonUtilsForLua:setButtonTitle(self.m_useBtn, getLang("102137"))
		self.m_btnMsgLabel:setString(getLang("104906"))

        local _type = toolInfo:getProperty("type")
        local _type2 = toolInfo:getProperty("type2")

		if (cnt > 0) then
			self.m_buyNode:setVisible(false)
            self.m_buyBtn:setEnabled(false)
            self.m_useBtn:setVisible(true)
            self.m_useBtn:setEnabled(true)
       	elseif ((_type == 49 or _type == 50) and _type2 == 1) then
			self.m_buyBtn:setEnabled(false)
			self.m_useBtn:setVisible(true)
			self.m_useBtn:setEnabled(true)
			CCCommonUtilsForLua:setButtonTitle(self.m_useBtn, getLang("105086"))
        else
        	self.m_buyNode:setVisible(true)
            self.m_buyBtn:setEnabled(true)
            self.m_useBtn:setVisible(false)
            self.m_useBtn:setEnabled(false)
        end

        if (_type == 4 and (_type2 == 17 or _type2 == 18)) then
        	self.m_buyNode:setVisible(false)
        	self.m_buyBtn:setEnabled(false)
        	--self.m_desLabel:setFontSize(34)
        	if (cnt > 0) then
        		self.m_useBtn:setVisible(true)
        		self.m_useBtn:setEnabled(true)
        	else
        		self.m_btnGray:setVisible(true)
        		CCCommonUtilsForLua:setButtonTitle(self.m_btnGray, getLang("102137"))
        		self.m_useBtn:setVisible(true)
        		self.m_useBtn:setEnabled(false)
        	end
        end
    end

    self:checkCDShow()
end

function NewActiveSkillViewBuffCellSubitem:onEnter()
	if self.entry then 
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry) 
		self.entry = nil
	end
	self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(function(dt) self:onEnterFrame(dt) end, 1, false)
end

function NewActiveSkillViewBuffCellSubitem:onExit()
	if self.entry then 
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry) 
		self.entry = nil
	end
end

function NewActiveSkillViewBuffCellSubitem:onCleanup()
	--self = nil
end

function NewActiveSkillViewBuffCellSubitem:checkCDShow()
	-- local toolInfos = ToolController:call("getInstance"):getProperty("m_toolInfos")
	-- if (toolInfos[self.m_itemId] == nil) then
	-- 	self.m_picNode:removeChildByName("label")
	-- 	self.m_picNode:removeChildByName("cdbg")
	-- 	return
	-- end

	local toolInfo = ToolController:call("getInstance"):call("getToolInfoForLua", self.m_itemId)
	if toolInfo == nil then
		self.m_picNode:removeChildByName("label")
		self.m_picNode:removeChildByName("cdbg")
		return
	end
	local left = 0
	local cdTime = toolInfo:call("getCDTime")
	if (cdTime > 0) then
		local lastUseTime = toolInfo:call("getLastUseTime")
		left = lastUseTime + cdTime - GlobalData:call("getTimeStamp")
	end
	if (left > 0) then
		local bg = self.m_picNode:getChildByName("cdbg")
		if (not bg) then
			bg = cc.LayerColor:create(cc.c4b(0, 0, 0, 150))
			bg:setName("cdbg")
			bg:setAnchorPoint(ccp(0.5, 0.5))
			bg:ignoreAnchorPointForPosition(false)
			self.m_picNode:addChild(bg, 2)
		end

		local label = self.m_picNode:getChildByName("label")
		if (not label) then
			label = cc.Label:createWithSystemFont("", "Helvetica", 20)
			label:setName("label")
			label:setAnchorPoint(ccp(0.5, 0.5))
			label:setColor(cc.c3b(254, 251, 0))
			self.m_picNode:addChild(label, 3)
		end

		label:setString(format_time(left))
		bg:setContentSize(cc.size(label:getContentSize().width + 10, label:getContentSize().height))

		self.m_buyBtn:setEnabled(false)
		self.m_btnGray:setEnabled(false)
		self.m_useBtn:setEnabled(false)
	else
		self.m_picNode:removeChildByName("label")
		self.m_picNode:removeChildByName("cdbg")

		local _type = toolInfo:getProperty("type")
		local _type2 = toolInfo:getProperty("type2")
		local cnt = toolInfo:call("getCNT")
		if (cnt > 0) then
			self.m_buyBtn:setEnabled(false)
			self.m_useBtn:setVisible(true)
			self.m_useBtn:setEnabled(true)
		elseif ((_type == 49 or _type == 50) and _type2 == 1) then
			self.m_buyBtn:setEnabled(false)
			self.m_useBtn:setVisible(true)
			self.m_useBtn:setEnabled(true)
			CCCommonUtilsForLua:setButtonTitle(self.m_useBtn, getLang("105086"))
		else
			self.m_buyBtn:setEnabled(true)
			self.m_useBtn:setVisible(false)
			self.m_useBtn:setEnabled(false)
		end

	
		if (_type == 4 and (_type2 == 17 or _type2 == 18)) then
			self.m_buyBtn:setEnabled(false)
			if (cnt > 0) then
				self.m_useBtn:setVisible(true)
				self.m_useBtn:setEnabled(true)
			else
				self.m_btnGray:setVisible(true)
				self.m_useBtn:setVisible(true)
				self.m_useBtn:setEnabled(false)
			end
		end
	end
end

function NewActiveSkillViewBuffCellSubitem:onEnterFrame(dt)
	if (self.m_itemId == 0) then
		if (self.m_objId == "") then
			local curTime = GlobalData:call("getWorldTime")
			-- local queueInfos = GlobalData:call("shared"):getProperty("allQueuesInfo")
			-- local finishTime = queueInfos[self.m_qid]:getProperty("finishTime")
			local finishTime = QueueController:call("shared"):call("getFinishTimeByKey", self.m_qid)
			local tmpTime = finishTime - curTime
			local freeSpdT = GlobalData:call("shared"):getProperty("freeSpdT")
			if (tmpTime <= freeSpdT) then
				self.m_desLabel:setString("")
				self.m_lockNode:removeAllChildren()
				self.m_useBtn:setEnabled(true)
			else
				self.m_desLabel:string(getLang("103670", format_time(tmpTime - freeSpdT)))
			end
			self.m_leftTimeLabel:setString("")
		end
	else
		local toolInfo = ToolController:call("getToolInfoByIdForLua", self.m_itemId)
		local limitTime = toolInfo:getProperty("limitTime")
		local cnt = toolInfo:call("getCNT")
		if (limitTime > 0 and cnt > 0) then
			local curTime = GlobalData:call("getTimeStamp")
			if (limitTime > curTime) then
				self.m_leftTimeLabel:setString(getLang("108802", format_time(limitTime - curTime)))
			else
				self.m_leftTimeLabel:setString("")
			end
		else
			self.m_leftTimeLabel:setString("")
		end
	end

	self:checkCDShow()
end

function NewActiveSkillViewBuffCellSubitem:onClickUseBtn()
	self.m_isByBuy = false
	if (self.m_itemId == 0 and self.m_objId == "customskin") then
		YesNoDialog:call("show", getLang("101459"), cc.CallFunc:create(function() self:sureToCancel() end))
	else
		local toolInfo = ToolController:call("getToolInfoByIdForLua", self.m_itemId)
		local _type = toolInfo:getProperty("type")
		local cnt = toolInfo:call("getCNT")
		if ((_type == 49 or _type == 50) and cnt <= 0) then
			local ItemGetMethodView = Drequire("game.CommonPopup.ItemGetMethodView")
			local view = ItemGetMethodView:create(self.m_itemId)
			PopupViewController:addPopupView(view)
		elseif (_type == 42) then
			if (FunBuildController:call("getGoodsDurationByItemType", _type)) then
				YesNoDialog:call("show", getLang("101432"), cc.CallFunc:create(function() self:onUseTool() end))
			else
				YesNoDialog:call("show", getLang("165046"), cc.CallFunc:create(function() self:onUseTool() end))
			end
		else
			self:onUseTool()
		end
	end
end

function NewActiveSkillViewBuffCellSubitem:sureToCancel()
	UIComponent:call("onPopupReturnClick", nil, 1)
end

function NewActiveSkillViewBuffCellSubitem:onYes()
	if (ToolController:call("isBuyUseOn")) then
		ToolController:call("buyUseTool", self.m_itemId, 1, nil, 0, false, "NewActiveSkillViewBuffCell")
	else
		ToolController:call("buyTool", self.m_itemId, 1, cc.CallFunc:create(function() self:onUseTool() end), 0, true, false, "NewActiveSkillViewBuffCell")		
	end
end

function NewActiveSkillViewBuffCellSubitem:onUseTool()
	if (self.m_itemId == 0 and self.m_objId == "customskin") then
		self:sureToCancel()
	else
		ToolController:call("useTool", self.m_itemId, 1, true, self.m_isByBuy)
		if CCCommonUtilsForLua:isFunOpenByKey("new_battle_view_lua") then
			CCSafeNotificationCenter:postNotification(MessageType.MSG_SEND_BATTLE_VIEW_BUFF_CMD)
		end
	end
end

function NewActiveSkillViewBuffCellSubitem:onClickBuyBtn()
	self.m_isByBuy = false
	local info = ToolController:call("getToolInfoByIdForLua", self.m_itemId)
	local _type = info:getProperty("type")
	local _type2 = info:getProperty("type2")
	local cnt = info:call("getCNT")
	if (_type == 4 and (_type2 == 17 or _type2 == 18) and cnt <= 0) then
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("160475"))
		return
	end

	if (_type == 4 and ToolController:call("checkUseStateTool", self.m_itemId, cc.CallFunc:create(function() self:onYes() end))) then
		self.m_isByBuy = true
	else
		local price = info:getProperty("price")
		local function callback() self:onYes() end
		YesNoDialog:call("showButtonAndGold", getLang("104919"), cc.CallFunc:create(callback), getLang("104906"), price)
	end
end


return NewActiveSkillViewBuffCellSubitem