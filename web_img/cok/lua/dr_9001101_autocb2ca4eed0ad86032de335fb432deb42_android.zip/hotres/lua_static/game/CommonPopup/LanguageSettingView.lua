local m_data,m_rootPath
local MAX_LANGAGE_COUNT = 22
local m_langName = {"English","Français","Deutsch","Pусский","한국어","ไทย","日本語","Português","Español","Türkçe","Indonesia","繁體中文","简体中文","Italiano","Polski","Nederlands","العربية","Română","فارسی","українська","Norsk","Tiếng Việt"}
local m_langCode = {"102913","102917","102919","102920","102921","102935","102928","102918","102916","102936","102941","102915","102914","102922","102931","102930","103052","115619","103055","102937","102929","102938"}
local m_langStatus = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}
local isPad = CCCommonUtilsForLua:comFunc("isIosAndroidPad",0):getValue()
local m_LanguageTranslationCell = nil
local m_transCellTable = {}
local m_curLanguageType = nil
local m_transCellHeight = nil

local LanguageIconCellHeight = 100
local LanguageIconCellNums = 3

LanguageSettingLuaView = LanguageSettingLuaView or {}
ccb["LanguageSettingLuaView"] = LanguageSettingLuaView

LanguageSettingView = class("LanguageSettingView",
    function()
        return PopupBaseView:comFunc("create",0)
    end
)
LanguageSettingView.__index = LanguageSettingView

function LanguageSettingView:create(table)
  local isByTranslate = (table["1"] == nil)
  local view = LanguageSettingView.new()
  if view:initView(isByTranslate) == false then
    return false
  end
  local dict = CCDictionary:create()
  dict:setObject(view,"1")
  PopupViewController:comFunc("addPopupInView",dict)
  return true
end

function LanguageSettingView:initView(isByTranslate)
  isPad = CCCommonUtilsForLua:comFunc("isIosAndroidPad",0):getValue()
  m_curLanguageType = LocalController:comFunc("getLanguageFileName",0):getCString()
  if m_curLanguageType == "zh_TW" then
    m_curLanguageType = "zh-Hant"
  elseif m_curLanguageType == "zh_CN" then
    m_curLanguageType = "zh-Hans"
  end
  local dict = CCDictionary:create()
  dict:setObject(CCBool:create(true),"1")
  if self:comFunc("init",dict):getValue() == false then
    --print("LanguageSettingView init error")
    return false
  end

  self.isClose = true
  dict:setObject(CCBool:create(true),"1")
  self:comFunc("setHDPanelFlag",dict)
  local  proxy = cc.CCBProxy:create()
  self:comFunc("onResolveCCBCCControlSelector",0)
  local ccbiURL = ""
  if isPad == false then
    ccbiURL = "ccbi/LanguageSettingView.ccbi"
  else
    ccbiURL = "hdccbi/LanguageSettingView.ccbi"
  end

  local nodeccb = CCBReaderLoad(ccbiURL,proxy,LanguageSettingLuaView)
  if nodeccb == nil then
     --print("LanguageSettingView loadccb error")
    return false
  end

  if nil ~= LanguageSettingLuaView["m_popupBG"] then
    self.m_popupBG = tolua.cast(LanguageSettingLuaView["m_popupBG"],"ccui.Scale9Sprite")
  end
  if nil == self.m_popupBG then
    --print("LanguageSettingView m_popupBG error")
    return false
  end
  if nil ~= LanguageSettingLuaView["m_bg"] then
    self.m_bg = tolua.cast(LanguageSettingLuaView["m_bg"],"ccui.Scale9Sprite")
  end
  if nil == self.m_bg then
    --print("LanguageSettingView m_bg error")
    return false
  end
  if nil ~= LanguageSettingLuaView["m_listContainer"] then
    self.m_listContainer = tolua.cast(LanguageSettingLuaView["m_listContainer"],"cc.Node")
  end
  if nil == self.m_listContainer then
    --print("LanguageSettingView m_listContainer error")
    return false
  end

  local screenSize = cc.Director:getInstance():getIFWinSize()
  local changeY = 0
  
  if isPad == true then
    self:setContentSize(cc.size(1536, 2048))
    changeY = screenSize.height - 2048
  else
    self:setContentSize(cc.size(640, 852))
    changeY = screenSize.height - 852
  end

  local preHg = self.m_popupBG:getContentSize().height
  dict:setObject(self.m_popupBG,"1")
  self:comFunc("changeBGHeight",dict)
  local dh = self.m_popupBG:getContentSize().height-preHg
  local tmpCSize = self.m_bg:getContentSize()
  self.m_bg:setContentSize(cc.size(tmpCSize.width,tmpCSize.height+dh))
  dict:setObject(self.m_bg,"1")
  self:comFunc("changeBGHeight",dict)
  tmpCSize = self.m_listContainer:getContentSize()
  self.m_listContainer:setContentSize(cc.size(tmpCSize.width,tmpCSize.height+dh))
  self:addChild(nodeccb)
  tmpCSize = self.m_listContainer:getContentSize()
  self.m_tableView = cc.TableView:create(tmpCSize)
  self.m_listContainer:addChild(self.m_tableView)
  self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
  self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
  self.m_tableView:setDelegate()
  self.m_tableView:registerScriptHandler(LanguageSettingView.scrollViewDidScroll,cc.SCROLLVIEW_SCRIPT_SCROLL)
  self.m_tableView:registerScriptHandler(LanguageSettingView.tableCellTouched,cc.TABLECELL_TOUCHED)
  self.m_tableView:registerScriptHandler(LanguageSettingView.cellSizeForTable,cc.TABLECELL_SIZE_FOR_INDEX)
  self.m_tableView:registerScriptHandler(LanguageSettingView.tableCellAtIndex,cc.TABLECELL_SIZE_AT_INDEX)
  self.m_tableView:registerScriptHandler(LanguageSettingView.numberOfCellsInTableView,cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
  self:setDataList()

  --print("viewsizeH: "..tmpCSize.height.." "..m_transCellHeight.." "..self.m_tableView:getContentSize().height.." "..dh)
  if isByTranslate then
    self.m_tableView:setContentOffset(CCPoint(0,(tmpCSize.height-m_transCellHeight)))
  end
  
  dict = CCDictionary:create()
  dict:setObject(CCString:create("102910"),"1")
  local str = LuaController:comFunc("getLang",dict)
  dict:setObject(str,"1")
  self:comFunc("setTitleName",dict)
  return true
end  

function LanguageSettingView:setDataList()
  m_data = {"1","2"}
  self.m_tableView:reloadData()
end

function LanguageSettingView:onResolveCCBCCControlSelector()

end

function LanguageSettingView.scrollViewDidScroll(view)

end

function LanguageSettingView.tableCellTouched(tab,cell)
    
end

function LanguageSettingView.cellSizeForTable(tab,idx)
  local idIndex = idx+1
  if m_data[idIndex]==nil then
    return 0,0
  end
  local dict = CCDictionary:create()
  local height = 353
  local indeY = -1
  if m_data[idIndex] == "1" then
    for index = 1,MAX_LANGAGE_COUNT do
      if m_langStatus[index] == 0 then
        indeY = indeY+1
        end
    end
    indeY= indeY/LanguageIconCellNums
    if indeY > 1 then
      height = height+(indeY)*LanguageIconCellHeight - 200
    end
  else
    dict:setObject(CCString:create("changeLanguage"),"1")
    local groupDict = dictToLuaTable(LocalController:comFunc("DBXMLManager",0):comFunc("getGroupByKey",dict))
    if nil ~= groupDict then
    	for key, value in pairs(groupDict) do 
        if value["open"] ~="1" and value["type"] ~= m_curLanguageType then
          indeY = indeY+1
        end
    	end
    end
    indeY = indeY/2
    if indeY >1 then
      height = height+(indeY-1)*120+120
    end
    if isPad then
      m_transCellHeight = height*2.4
    else
      m_transCellHeight = height
    end
  end
  
  if isPad == true then
    height = height*2.4
    return 1536,height
  end

  return 640, height
end

function LanguageSettingView.tableCellAtIndex(tab, idx)
  local idIndex = idx+1
    if idIndex > #m_data then
      return nil
    end
    local showIdx = tostring(idIndex)
    local cell = tab:dequeueCell()
    local node = nil
    if cell ~= nil then 
      node = cell:getChildByTag(100)
        if node ~= nil then
          node:setData(showIdx)
        end
    else
      node = LanguageSettingAndTranslationCell:create(showIdx)
      if node ~= nil then
        --print("tableCellAtIndex create cell ok"..idIndex)
        node:setTag(100)
        if isPad == true then
          node:setAnchorPoint(cc.p(0,0))
          node:setScale(2.4)
        end
        cell = cc.TableViewCell:new()
        cell:addChild(node)
      end
    end
    return cell
end

function LanguageSettingView.numberOfCellsInTableView(tab)
  return math.ceil(#m_data/1.0)
end

LanguageSettingAndTranslationLuaCell  = LanguageSettingAndTranslationLuaCell or {}
ccb["LanguageSettingAndTranslationLuaCell"] = LanguageSettingAndTranslationLuaCell

LanguageSettingAndTranslationCell = class("LanguageSettingAndTranslationCell",
    function()
        return cc.Layer:create() 
    end
)
LanguageSettingAndTranslationCell.__index = LanguageSettingAndTranslationCell

function LanguageSettingAndTranslationCell:create(str)
  local view = LanguageSettingAndTranslationCell.new()
  if view:initView(str) == true then
    return view
  end
  return nil
end

function LanguageSettingAndTranslationCell:initView(str)
  self.m_strSTC = str
  if self:init() == false then
    --print("LanguageSettingAndTranslationCell init error")
    return false
  end
  local  proxy = cc.CCBProxy:create()
  local ccbiURL = ""
  if isPad == false then
    ccbiURL = "ccbi/LanguageTranslationCell.ccbi"
  else
    ccbiURL = "hdccbi/LanguageTranslationCell.ccbi"
  end
  local nodeccb = CCBReaderLoad(ccbiURL,proxy,LanguageSettingAndTranslationLuaCell)
  if nodeccb == nil then
    --print("LanguageSettingAndTranslationCell ccbload error")
    return false
  end
  if false == self:onAssignCCBMemberVariable() then
    --print("LanguageSettingAndTranslationCell onAssignCCBMemberVariable error")
    return false
  end
  self:addChild(nodeccb)
  self:setContentSize(nodeccb:getContentSize())
  
  self.m_listData = {}
  self:setData(self.m_strSTC)
  return true
end

function LanguageSettingAndTranslationCell:onResolveCCBCCControlSelector()

end

function LanguageSettingAndTranslationCell:onAssignCCBMemberVariable()
  if nil ~= LanguageSettingAndTranslationLuaCell["m_translationTitle"] then
    self.m_translationTitle = tolua.cast(LanguageSettingAndTranslationLuaCell["m_translationTitle"],"cc.Label")
  end
  if nil == self.m_translationTitle then
    return false
  end

  if nil ~= LanguageSettingAndTranslationLuaCell["m_translationDes"] then
    self.m_translationDes = tolua.cast(LanguageSettingAndTranslationLuaCell["m_translationDes"],"cc.Label")
  end
  if nil == self.m_translationDes then
    return false
  end

  if nil ~= LanguageSettingAndTranslationLuaCell["m_listNode"] then
    self.m_listNode = tolua.cast(LanguageSettingAndTranslationLuaCell["m_listNode"],"cc.Node")
  end
  if nil == self.m_listNode then
    return false
  end
  
  if nil ~= LanguageSettingAndTranslationLuaCell["m_totalNode"] then
    self.m_totalNode = tolua.cast(LanguageSettingAndTranslationLuaCell["m_totalNode"],"cc.Node")
  end
  if nil == self.m_totalNode then
    return false
  end
  
  if nil ~= LanguageSettingAndTranslationLuaCell["m_listBG"] then
    self.m_listBG = tolua.cast(LanguageSettingAndTranslationLuaCell["m_listBG"],"ccui.Scale9Sprite")
  end
  if nil == self.m_listBG then
    return false
  end
  return true
end

--[[
function LanguageSettingAndTranslationCell:onEnter()
  -- CCTableViewCell::onEnter()
local touchif = tolua.cast(self,"cc.CCIFTouchNode")
  if touchif ~= nil then
      touchif:setTouchEnabled(true)
  end
end

function LanguageSettingAndTranslationCell:onExit()
  if self.isClose == false then
        return
  end
    
  local touchif = tolua.cast(self,"cc.CCIFTouchNode")
  if touchif ~= nil then
      touchif:setTouchEnabled(false)
  end
   -- CCTableViewCell::onExit() 
end
--]]
function LanguageSettingAndTranslationCell:setTranslarionCellClose(close)
  for index =1,#m_transCellTable do
    m_transCellTable[index]:setClose(close)
  end
end

function LanguageSettingAndTranslationCell:setData(str)
  local dict = CCDictionary:create()
  self.m_strSTC = str
  self.m_listNode:removeAllChildren(true)
  self.m_totalNode:setPositionY(109)
  self.m_listData = nil
  self.m_listData = {}
  
  local indexX = 0
  local indexY = 0
  
  if self.m_strSTC == "1" then
    -- 语言选择
      dict:setObject(CCString:create("102910"),"1")
      self.m_translationTitle:setString(LuaController:comFunc("getLang",dict):getCString())
      self.m_translationDes:setVisible(false)
      self.m_listNode:setPosition(-291,100)
      for index=1,MAX_LANGAGE_COUNT do
          if m_langStatus[index]==0 then
              local dictempty = CCDictionary:create()
              local dict = CCDictionary:create()
              dict:setObject(CCString:create(tostring(index)),"1")
              local lan = LocalController:comFunc("getLanguageType",dict):getCString()
              local bIsInsert = true
              if lan == "fa" then
                  local curAnalyticID = GlobalData:comFunc("shared",0):getProperty("analyticID")
                  if curAnalyticID == "market_global" then
                    bIsInsert = false
                  end
              end
              if bIsInsert == true then 
                  table.insert (self.m_listData,index)
              end
          end
      end
      for index =1,#self.m_listData do
          indexY = (index-1)/LanguageIconCellNums
          indexX = (index-1)%LanguageIconCellNums
          local node = LanguageSettingCell:create(self.m_listData[index])
          if node ~= nil then
              self.m_listNode:addChild(node)
              local nY = math.floor(indexY)
              node:setPosition(indexX*200 + 15, -nY*LanguageIconCellHeight)
          end
      end
      if indexY>1 then
          local listBgSize = self.m_listBG:getContentSize()
          self.m_listBG:setContentSize(cc.size(listBgSize.width,220+(indexY-1)*LanguageIconCellHeight))
          self.m_totalNode:setPositionY((indexY-1)*LanguageIconCellHeight)
      end
  elseif self.m_strSTC == "2" then
    self.m_translationDes:setVisible(true)
    dict:setObject(CCString:create("102912"),"1")
    self.m_translationDes:setString(LuaController:comFunc("getLang",dict):getCString())
    dict:setObject(CCString:create("102911"),"1")
    self.m_translationTitle:setString(LuaController:comFunc("getLang",dict):getCString())
    local nodeY = self.m_translationDes:getPositionY()-self.m_translationDes:getContentSize().height-120
    self.m_listNode:setPosition(-243,nodeY)
    
    local tableSwitch = {}
    tableSwitch["name"] = "132245"
    tableSwitch["type"] = "switch"
    table.insert (self.m_listData,tableSwitch)
    
    dict:setObject(CCString:create("changeLanguage"),"1")
    local groupDict = dictToLuaTable(LocalController:comFunc("DBXMLManager",0):comFunc("getGroupByKey",dict))
    if nil ~= groupDict then
    	for key, value in pairs(groupDict) do 
        if value["open"] ~= "1" and value["type"] ~= m_curLanguageType then
          table.insert (self.m_listData,value)
        end
    	end
    end
    m_LanguageTranslationCell = self
    m_transCellTable = nil
    m_transCellTable = {}
    for index =1,#self.m_listData do
      --print("LanguageTranslationCell create start "..index)
      local node = LanguageTranslationCell:create(self.m_listData[index])
      if node ~= nil then
        if index~=1 then
          table.insert (m_transCellTable,node)
        end
        self.m_listNode:addChild(node)
        
        if index == 1 then
        node:setPosition(0.5*379, 0)
        else
          local indexJ = index-1
          indexY = (indexJ-1)/2
          indexX = (indexJ-1)%2
          local nY = math.floor(indexY)
          node:setPosition(indexX*379, -nY*120-60)
        end
      end
    end
    if indexY>1 then
      local listBgSize = self.m_listBG:getContentSize()
      self.m_listBG:setContentSize(cc.size(listBgSize.width,listBgSize.height+(indexY-1)*120+120))
      self.m_totalNode:setPositionY(109.0+(indexY-1)*120+120)
    end
  end
end

function LanguageSettingAndTranslationCell:onTouchBegan(x, y)
    self.touchPos = cc.p(x,y)
    return false
end

function LanguageSettingAndTranslationCell:onTouchEnded(x, y)
  if cc.pGetDistance(self.touchPos,cc.p(x,y)) > 30 then
        return
    end
end

function LanguageSettingAndTranslationCell:onTouchMoved(x, y)

end

LanguageSettingLuaCell  = LanguageSettingLuaCell or {}
ccb["LanguageSettingLuaCell"] = LanguageSettingLuaCell

LanguageSettingCell = class("LanguageSettingCell",
    function()
        return cc.Layer:create() 
    end
)
LanguageSettingCell.__index = LanguageSettingCell

function LanguageSettingCell:create(id)
  local view = LanguageSettingCell.new()
  if view:initView(id) == true then
    return view
  end
  return nil
end

function LanguageSettingCell:initView(id)
    self.m_id = id
    if self:init() == false then
        return false
    end
    
    local viewSize = cc.size( 150, LanguageIconCellHeight)
    self:setContentSize(viewSize)
    
    local touchNode = cc.LayerColor:create()
    self:addChild(touchNode)
    touchNode:setContentSize(viewSize)

    local function touchHandle( eventtype, x, y )
        if eventtype == "began" then
            return self:onTouchBegan(x, y)  
        elseif eventtype == "moved" then
            return self:onTouchMoved(x, y)  
        else 
            return self:onTouchEnded(x, y)  
        end
    end
    touchNode:registerScriptTouchHandler(touchHandle)
    touchNode:setTouchEnabled(true)

    local baseNode = cc.Node:create()
    touchNode:addChild(baseNode)
    baseNode:setPosition(cc.p(viewSize.width * 0.5, viewSize.height * 0.5))

    local dict = CCDictionary:create()
    dict:setObject(CCString:create(tostring(id)),"1")
    self.m_languageType = LocalController:comFunc("getLanguageType",dict):getCString()
    self.m_languageCode = m_langCode[id]

    local picName = "UI_Sub_Tab.png"
    local nameColor = cc.c3b(255, 174, 71)
    local language = LocalController:comFunc("getLanguageFileName",dict):getCString()
    self.isCurLanguage = true
    if language ~= self.m_languageType then
        picName = "UI_Sub_Tab_Selected.png"
        nameColor = cc.c3b(255, 255, 255)
        self.isCurLanguage = false
    end
    local pic = CCLoadSprite:call("createSprite", picName)
    baseNode:addChild(pic)
    self.m_iconBG = pic

    local name = m_langName[self.m_id]
    local nameLabel = cc.Label:createWithSystemFont(name, "Helvetica", 20, cc.size(0.0,0))
    nameLabel:setColor(nameColor)
    baseNode:addChild(nameLabel)

    -- 添加背景图
    -- self.m_name:setSystemFontSize(20)
    -- self:setIconData(self.m_id)

    return true
end

function LanguageSettingCell:touchEvent()
  local language = LocalController:comFunc("getLanguageFileName",0):getCString()

  if language ~= self.m_languageType then
    -- cc.UserDefault:getInstance():setStringForKey("CLIENT_VERSION_FOR_LANG","")
    DynamicResourceController2:call("setCache", "CLIENT_VERSION_FOR_LANG", "")
    cc.UserDefault:getInstance():setStringForKey("preferred-language",self.m_languageType)
    cc.UserDefault:getInstance():setStringForKey("current-version-code","")
    cc.UserDefault:getInstance():flush()
    
    LocalController:comFunc("initLanguage",0)
    GameController:call("reloadGame")

    PopupViewController:comFunc("removeAllPopupView",0)
    --ChatController:comFunc("ChatServiceCocos2dx:ChangeLanguage",0)
    ChatController:call("useChatServiceCocos2dxForChangeLanguage")
  end
end

function LanguageSettingCell:onTouchBegan(x, y)
    if self.isCurLanguage then
        return false
    end
    self.touchPos = cc.p(x,y)
    if self:touchInside(self.m_iconBG,x,y) == true then
        return true
    end
    return false
end

function LanguageSettingCell:onTouchEnded(x, y)
    if cc.pGetDistance(self.touchPos,cc.p(x,y)) > 30 then
        return
    end

    local function confirmFun()
        self:touchEvent()
    end
    -- dict:setObject(CCString:create(tostring(self.m_languageCode)),"1")
    -- local lanstr = LuaController:comFunc("getLang",dict)
    -- dict:setObject(CCString:create("113996"),"1")
    -- dict:setObject(lanstr,"2")
    -- local tip = LuaController:comFunc("getLang1",dict)
    local dict = CCDictionary:create()
    local tip = getLang("113996", getLang(self.m_languageCode))

    local fun = cc.CallFunc:create(confirmFun)
    dict:setObject(CCString:create(tip),"1")
    dict:setObject(fun,"2")
    local dialog = TemporaryViewNoticController:comFunc("YesNoDialog:show",dict)
    dict:setObject(dialog,"1")
    TemporaryViewNoticController:comFunc("YesNoDialog:showCancelButton",dict)
end

function LanguageSettingCell:onTouchMoved(x, y)

end

--fixme 可以抽象
function LanguageSettingCell:touchInside(touchnode,x,y)
    if nil ~= touchnode:getParent() then
        local pos = touchnode:getParent():convertToNodeSpace(cc.p(x,y))
        local rect = touchnode:getBoundingBox()
        if cc.rectContainsPoint(rect,pos) == true then
            return true
        end
    end
    return false
end

LanguageTranslationSettingLuaCell  = LanguageTranslationSettingLuaCell or {}
ccb["LanguageTranslationSettingLuaCell"] = LanguageTranslationSettingLuaCell

LanguageTranslationCell = class("LanguageTranslationCell",
    function()
        return cc.Layer:create() 
    end
)
LanguageTranslationCell.__index = LanguageTranslationCell

function LanguageTranslationCell:create(dict)
  local view = LanguageTranslationCell.new()
  if view:initView(dict) == true then
    return view
  end
  return nil
end

function LanguageTranslationCell:initView(dict)
  self.m_dict = dict
  if self:init() == false then
    --print("LanguageTranslationCell init return false")
    return false
  end
  local  proxy = cc.CCBProxy:create()
  local ccbiURL = ""
  if isPad == false then
    ccbiURL = "ccbi/LanguageTranslationSettingCell.ccbi"
  else
    ccbiURL = "hdccbi/LanguageTranslationSettingCell.ccbi"
  end
  local nodeccb = CCBReaderLoad(ccbiURL,proxy,LanguageTranslationSettingLuaCell)
  if nodeccb == nil then
    --print("CCBReaderLoad error")
    return false
  end
  if false == self:onAssignCCBMemberVariable() then
    --print("onAssignCCBMemberVariable error")
    return false
  end
  local touchNode = cc.LayerColor:create()
  self:addChild(touchNode)
  touchNode:setContentSize(nodeccb:getContentSize())
  
  local function touchHandle( eventtype, x, y )
    if eventtype == "began" then
      return self:onTouchBegan(x, y)  
    elseif eventtype == "moved" then
      return self:onTouchMoved(x, y)  
    else 
      return self:onTouchEnded(x, y)  
    end
  end

  touchNode:registerScriptTouchHandler(touchHandle)
  touchNode:setTouchEnabled(true)
  
  touchNode:addChild(nodeccb)
  self:setContentSize(touchNode:getContentSize())
  
  self:setData(self.m_dict)
  return true
end

function LanguageTranslationCell:onResolveCCBCCControlSelector()

end

function LanguageTranslationCell:onAssignCCBMemberVariable()
  if nil ~= LanguageTranslationSettingLuaCell["m_nameText"] then
    self.m_nameText = tolua.cast(LanguageTranslationSettingLuaCell["m_nameText"],"cc.Label")
  end
  if nil == self.m_nameText then
    --print("onAssignCCBMemberVariable m_nameText  error")
    return false
  end

  if nil ~= LanguageTranslationSettingLuaCell["m_touchBtnOpenBg"] then
    self.m_touchBtnOpenBg = tolua.cast(LanguageTranslationSettingLuaCell["m_touchBtnOpenBg"],"cc.Sprite")
  end
  if nil == self.m_touchBtnOpenBg then
    --print("onAssignCCBMemberVariable m_touchBtnOpenBg  error")
    return false
  end

  if nil ~= LanguageTranslationSettingLuaCell["m_touchBtnCloseBg"] then
    self.m_touchBtnCloseBg = tolua.cast(LanguageTranslationSettingLuaCell["m_touchBtnCloseBg"],"cc.Sprite")
  end
  if nil == self.m_touchBtnCloseBg then
    --print("onAssignCCBMemberVariable m_touchBtnCloseBg  error")
    return false
  end
  
  if nil ~= LanguageTranslationSettingLuaCell["m_touchBtn"] then
    self.m_touchBtn = tolua.cast(LanguageTranslationSettingLuaCell["m_touchBtn"],"cc.Sprite")
  end
  if nil == self.m_touchBtn then
    --print("onAssignCCBMemberVariable m_touchBtn  error")
    return false
  end
  return true
end

function LanguageTranslationCell:touchEvent()
  local _type = self.m_dict["type"]
  local typeCacheKey = "auto_client_translate"
  local typeCache = cc.UserDefault:getInstance():getStringForKey(typeCacheKey)
  local bIsSwitchClose = typeCache == "0"
  if _type ~= "switch" then
    if bIsSwitchClose then
      return
    else
      typeCacheKey = "NewLanguageTranslation.set.".._type
      typeCache = cc.UserDefault:getInstance():getStringForKey(typeCacheKey)
    end
  else
     m_LanguageTranslationCell:setTranslarionCellClose(not bIsSwitchClose)
  end

  local curClose = false
  if string.len(typeCache) == 0 then
    if _type == m_curLanguageType then
      curClose = true
    end
  else
    if typeCache == "0" then
      curClose = true
    elseif typeCache == "1" then
      curClose = false
    end
  end
  --curClose true then open state ; curClose false then close state
  if curClose then
    cc.UserDefault:getInstance():setStringForKey(typeCacheKey,"1")
    self.m_touchBtnCloseBg:setVisible(false)
    self.m_touchBtnOpenBg:setVisible(true)
    self.m_touchBtn:setPositionX(62.5)
  else
    cc.UserDefault:getInstance():setStringForKey(typeCacheKey,"0")
    self.m_touchBtnCloseBg:setVisible(true)
    self.m_touchBtnOpenBg:setVisible(false)
    self.m_touchBtn:setPositionX(2)
  end
  --ChatController:comFunc("setDisableTranslateLang",0)
  ChatController:call("setDisableTranslateLang")
  if _type == "switch" then
    --local dict = CCDictionary:create()
    --dict:setObject(CCBool:create(bIsSwitchClose),"1") -- bIsSwitchClose true  setEnable(true)   bIsSwitchClose false setEnable(false)
    --ChatController:comFunc("setAutoTranslateEnable",dict)
    ChatController:call("setAutoTranslateEnable", bIsSwitchClose)
  end
  cc.UserDefault:getInstance():flush()
end

function LanguageTranslationCell:onTouchBegan(x, y)
    self.touchPos = cc.p(x,y)
    if self.m_touchBtnCloseBg ~= nil then
      if self.m_touchBtnCloseBg:isVisible() == true then
          if self:touchInside(self.m_touchBtnCloseBg,x,y) == true then
            return true
          end
      end
    end
    if self.m_touchBtnOpenBg ~= nil then
      if self.m_touchBtnOpenBg:isVisible() == true then
          if self:touchInside(self.m_touchBtnOpenBg,x,y) == true then
            return true
          end
      end
    end
    return false
end

function LanguageTranslationCell:onTouchEnded(x, y)
  if cc.pGetDistance(self.touchPos,cc.p(x,y)) > 30 then
        return
  end
  self:touchEvent()
end

function LanguageTranslationCell:onTouchMoved(x, y)

end

--fixme 可以抽象
function LanguageTranslationCell:touchInside(touchnode,x,y)
    if nil ~= touchnode:getParent() then
        local pos = touchnode:getParent():convertToNodeSpace(cc.p(x,y))
        local rect = touchnode:getBoundingBox()
        if cc.rectContainsPoint(rect,pos) == true then
            return true
        end
    end
    return false
end

function LanguageTranslationCell:setData(dict)
  local dict1 = CCDictionary:create()
  self.m_dict = dict
  local _name = self.m_dict["name"]
  local _type = self.m_dict["type"]
  dict1:setObject(CCString:create(_name),"1")
  self.m_nameText:setString(LuaController:comFunc("getLang",dict1):getCString())
  local typeCacheKey = "NewLanguageTranslation.set.".._type
  if _type == "switch" then
    typeCacheKey = "auto_client_translate"
  end
  local typeCache = cc.UserDefault:getInstance():getStringForKey(typeCacheKey)
  local close = false
  -- empty"":curLangage close,other open ; "0" all close ; "1" all open
  if string.len(typeCache) == 0 then
    if _type == m_curLanguageType then
      close = true
    end
  else
    if typeCache == "0" then
      close = true
    elseif typeCache == "1" then
      close = false
    end
  end
  if close  then
    self.m_touchBtnCloseBg:setVisible(true)
    self.m_touchBtnOpenBg:setVisible(false)
    self.m_touchBtn:setPositionX(2)
  else
    self.m_touchBtnCloseBg:setVisible(false)
    self.m_touchBtnOpenBg:setVisible(true)
    self.m_touchBtn:setPositionX(62.5)
  end
end

function LanguageTranslationCell:setClose(close)
  local _type = self.m_dict["type"]
  local typeCacheKey = "NewLanguageTranslation.set.".._type

  if close then
    cc.UserDefault:getInstance():setStringForKey(typeCacheKey,"0")
  else
    if _type == m_curLanguageType then
      close = true
    end
    cc.UserDefault:getInstance():setStringForKey(typeCacheKey,"")
  end
  cc.UserDefault:getInstance():flush()
  if close then
    self.m_touchBtnCloseBg:setVisible(true)
    self.m_touchBtnOpenBg:setVisible(false)
    self.m_touchBtn:setPositionX(2)
  else
    self.m_touchBtnCloseBg:setVisible(false)
    self.m_touchBtnOpenBg:setVisible(true)
    self.m_touchBtn:setPositionX(62.5)
  end
end
