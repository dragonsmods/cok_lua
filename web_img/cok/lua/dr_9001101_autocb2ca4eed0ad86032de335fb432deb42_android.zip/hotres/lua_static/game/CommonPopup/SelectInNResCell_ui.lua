----------------------------
-- Author: Elex
-- Date: 2017-06-12 17:29:21
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local SelectInNResCell_ui = class("SelectInNResCell_ui")

--#ui propertys


--#function
function SelectInNResCell_ui:create(owner, viewType)
	local ret = SelectInNResCell_ui.new()
	CustomUtility:LoadUi("SelectInNResCell.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function SelectInNResCell_ui:initLang()
end

function SelectInNResCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function SelectInNResCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return SelectInNResCell_ui

