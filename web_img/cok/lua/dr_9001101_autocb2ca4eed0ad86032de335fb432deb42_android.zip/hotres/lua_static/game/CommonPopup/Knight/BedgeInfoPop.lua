local BedgeInfoPop = class("BedgeInfoPop",
	function()
		return PopupBaseView:create() 
	end
)
BedgeInfoPop.__index = BedgeInfoPop

function BedgeInfoPop:create(itemId)
	local view = BedgeInfoPop.new()
	if (view:initView(itemId)) then return view end
end

function BedgeInfoPop:initView(itemId)
	if (self:init(true, 0)) then
		self:setIsHDPanel(true)

		CCLoadSprite:call("doResourceByCommonIndex", 11, true)

		local proxy = cc.CCBProxy:create()
		local ccbUri = "qiandaoTips_lua.ccbi"
		local node = CCBReaderLoad(ccbUri, proxy, self)

		self:addChild(node)

		local winSize = cc.Director:sharedDirector():getIFWinSize()
		self:setContentSize(winSize)

		self.m_itemId = itemId

		local toolInfo = ToolController:call("getToolInfoByIdForLua", self.m_itemId)

		local pic = CCCommonUtilsForLua:call("getIcon", tostring(self.m_itemId))
		local name = toolInfo:call("getName")
		local des = toolInfo:getProperty("des")
		local num = toolInfo:call("getCNT")

		local picSpr = CCLoadSprite:call("createSprite", pic)
		CCCommonUtilsForLua:setSpriteMaxSize(picSpr, 90, true)
		self.m_picNode:addChild(picSpr)
		if (num > 1) then
			name = name .. "   X" .. tostring(num)
		end
		self.m_nameLabel:setString(name)
		self.m_desLabel:setString(getLang(des))

		local touchLayer = cc.Layer:create()
		self:addChild(touchLayer)

		local function touchHandle( eventType, x, y )
			print("touchHandle", eventType, x, y)
			if eventType == "began" then
				return self:onTouchBegan(x, y)
			elseif eventType == "moved" then
			
			else
				self:onTouchEnded(x, y)
			end
		end
		touchLayer:registerScriptTouchHandler(touchHandle)
		touchLayer:setTouchEnabled(true)
		touchLayer:setSwallowsTouches(false)

		return true
	end

	return false
end

function BedgeInfoPop:onTouchBegan(x, y)
	return true
end

function BedgeInfoPop:onTouchEnded(x, y)
	if isTouchInside(self.m_touchNode, x, y) then
		return
	end
	PopupViewController:call("removePopupView", self)
end

return BedgeInfoPop