-- @Author: tangwen
-- @Date:   2019-12-03 21:34:44
-- @Last Modified by:   tangwen
-- @Last Modified time: 2019-12-16 15:51:58

-- 主界面按钮基类
local UiCompoentIcon = class("UiCompoentIcon", Drequire("game.UIComponent.CommonTouchScaleNode"))

function UiCompoentIcon.create(iconSize, contentSize)
    local view = UiCompoentIcon.new(iconSize)
    if view:initView(iconSize, contentSize) then
        return view
    end
end

function UiCompoentIcon:initView(iconSize, contentSize)
    return true
end

function UiCompoentIcon:onEnter()
end

function UiCompoentIcon:onExit()
end

function UiCompoentIcon:updateUI()
end

function UiCompoentIcon:touchEvent()
end

function UiCompoentIcon:onSceneChanged(sceneId)
end

function UiCompoentIcon:tryListenEvent( ... )
	
end

return UiCompoentIcon