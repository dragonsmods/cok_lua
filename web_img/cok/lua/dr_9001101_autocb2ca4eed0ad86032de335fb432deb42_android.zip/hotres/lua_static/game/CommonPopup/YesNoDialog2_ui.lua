----------------------------
-- Author: Elex
-- Date: 2019-07-12 Friday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local YesNoDialog2_ui = class("YesNoDialog2_ui")

--#ui propertys


--#function
function YesNoDialog2_ui:create(owner, viewType, paramTable)
	local ret = YesNoDialog2_ui.new()
	CustomUtility:DoRes(520, true)
	CustomUtility:LoadUi("YesNoDialog2.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function YesNoDialog2_ui:initLang()
	LabelSmoker:setText(self.m_labelContent, "5530003")
	ButtonSmoker:setText(self.m_btnCancel, "cancel_btn_label")
	ButtonSmoker:setText(self.m_btnOK, "confirm")
end

function YesNoDialog2_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function YesNoDialog2_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function YesNoDialog2_ui:onClickBtnCancel(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnCancel", pSender, event)
end

function YesNoDialog2_ui:onClickBtnOK(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnOK", pSender, event)
end

return YesNoDialog2_ui

