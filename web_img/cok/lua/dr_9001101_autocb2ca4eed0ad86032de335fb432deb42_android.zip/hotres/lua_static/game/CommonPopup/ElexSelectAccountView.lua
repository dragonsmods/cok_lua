--MM:2017.05.31 elex账号切换，采用与cn1初始化时一样的账号选择界面，此版比较粗糙，需要更换版式的话再找美术设计。

local ElexSelectAccountView = class("ElexSelectAccountView", function()
        return PopupBaseView:create()
    end
)
-- ElexSelectAccountView.__index = ElexSelectAccountView

------------------------------------------ HeroEffectCell Start --------------------------------------------
local ElexSelectAccountCell = class("ElexSelectAccountCell", function()
    return CCTableViewCell:new()
end)

function ElexSelectAccountCell:create(name,level, gameId)
    local ret = ElexSelectAccountCell.new()
    if ret:init(name,level,gameId) == false then
        return nil
    end
    return ret
end
local ServerListCellSize = CCSize(640, 100)
function ElexSelectAccountCell:init(name,level,gameid)
    --初始化界面
    local  proxy = cc.CCBProxy:create()
    local ccbiURL = ""
    ccbiURL = "ccbi/Lua_AccountCell.ccbi"
    self.m_bIsPad = m_bIsPad
    local nodeccb = CCBReaderLoad(ccbiURL,proxy, self)
    if nodeccb == nil then
    -- print("ElexSelectAccountCell loadccb error")
    return false
    end
    self:setContentSize(ServerListCellSize)
    self:addChild(nodeccb)

    if name == "" then
        name = "新建帐号"
    end
    self.m_name:setString(name);
    self.m_levelText:setString(level);

    self.gameid = gameid;


    return true
end



function ElexSelectAccountCell:onBtnClick()

MyPrint("zym ElexSelectAccountCell:onBtnClick")
local function confirmFunc()
    -- LogController:call("beginConnect", self.gameid)
    CCSafeNotificationCenter:postNotification("msg_select_elex_account", CCString:create(self.gameid))
    --view:call("closeSelf")
    -- PopupViewController:call("removeAllPopupView")
end
local dialog = YesNoDialog:show("确定选择这个帐号进入吗", confirmFunc)
dialog:call("showCancelButton");
end

------------------------------------------ HeroEffectCell End --------------------------------------------

------------------------------------------ HeroEffectView Start --------------------------------------------

function ElexSelectAccountView:create(param )
    local view = ElexSelectAccountView.new()
    if view:initView(param) == false then
        return nil
    end
    return view
end

function ElexSelectAccountView:initView(param)
    if self:init(true, 0) == false then
        MyPrint("ElexSelectAccountView init error")
        return false
    end
    MyPrint("zym ElexSelectAccountView:initView")  

    self:setHDPanelFlag(true)
    callItSelfCallFunc(LuaController, "doResourceByCommonIndex", 1, true)
    local m_bIsPad = CCCommonUtilsForLua:isIosAndroidPad()
    local  proxy = cc.CCBProxy:create()
    local ccbiURL = ""
    ccbiURL = "ccbi/ElexSelectAccountView_Lua.ccbi"
    self.m_bIsPad = m_bIsPad
    local nodeccb = CCBReaderLoad(ccbiURL,proxy, self)
    if nodeccb == nil then
        MyPrint("SelectAccount loadccb error")
        return false
    end

    if m_bIsPad then
        -- nodeccb:setScale(2.0)
        self.m_mainNode:setScale(2)
    end
    self:setContentSize(cc.Director:getInstance():getIFWinSize())
    self:addChild(nodeccb)

    local scrollView = cc.ScrollView:create()
    if scrollView ~= nil then
        scrollView:setViewSize(self.m_infoList:getContentSize())
        scrollView:setPosition(cc.p(0,0))
        scrollView:setScale(1.0)
        scrollView:ignoreAnchorPointForPosition(true)
        scrollView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)

        local cH = self.m_infoList:getContentSize().height
        local height = 0
        local mainNode = cc.Node:create();


        for i=0,param.count-1,1 do


            local cell = ElexSelectAccountCell:create(param["name"..i],param["level"..i], param["gameid"..i] )
            mainNode:addChild(cell)
            height = height + 80
            cell:setPosition(cc.p(0, 0 - height))

        end
 
        scrollView:addChild(mainNode);
        mainNode:setPosition(cc.p(0, height))
        scrollView:setContentSize(CCSize(620,height))
        scrollView:setContentOffset(CCPoint(0, cH - height))
        self.m_infoList:addChild(scrollView);
    end
    --self.m_titleTxt:setString(getLang("169636"))
 
    self.ccbNode = nodeccb
    local function onNodeEvent(event)
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end
    self.ccbNode:registerScriptHandler(onNodeEvent)

    registerTouchHandler(self)

    -- function onTouch(eventType, x, y)  
    --     if eventType == "began" then  
    --         return self:onTouchBegan(x, y)  
    --     elseif eventType == "moved" then  
    --         return self:onTouchMoved(x, y)  
    --     else  
    --         return self:onTouchEnded(x, y)  
    --     end
    -- end
    -- local touchif = tolua.cast(self,"cc.CCIFTouchNode")
    -- if touchif ~= nil then
    --     local dic1 = CCDictionary:create()
    --     dic1:setObject(CCBool:create(true),"1")
    --     touchif:comFunc("setTouchEnabled", dic1)

    --     MyPrint("ElexSelectAccountView:registerScriptTouchHandler")
    --     touchif:registerScriptTouchHandler(onTouch)
    -- end
    self.m_name:setString("角色名");
    self.m_levelText:setString("等级");
    self.m_title:setString("选择帐号");
    return true
end

function ElexSelectAccountView:onEnter()
    -- MyPrint("zym ElexSelectAccountView:onEnter touchInside m_touchNode")
end

function ElexSelectAccountView:onExit()
    -- MyPrint("zym ElexSelectAccountView:onExit touchInside m_touchNode")
end


function ElexSelectAccountView:onTipBtnClick()
    FaqHelper:call("showLoading",  "selectaccount");
end

function ElexSelectAccountView:onCloseBtnClick()
    self:closeSelf()
end

function ElexSelectAccountView:onTouchBegan(x, y)
    -- MyPrint("zym ElexSelectAccountView:onTouchBegan touchInside m_touchNode")
    return true
end

function ElexSelectAccountView:onTouchMoved(x, y)
    -- MyPrint("zym ElexSelectAccountView:onTouchMoved touchInside m_touchNode")
end

function ElexSelectAccountView:onTouchEnded(x, y)
    -- MyPrint("zym ElexSelectAccountView:onTouchEnded touchInside m_touchNode")
    --[[ if touchInside(self.m_touchNode, x, y) == false then
        MyPrint("ElexSelectAccountView:onTouchEnded touchInside m_touchNode")
        self:call("closeSelf")
    end
    --]]
end

return ElexSelectAccountView


