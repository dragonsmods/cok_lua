local CommonEventController = class("CommonEventController")

-- _CommonEventControllerInstance = _CommonEventControllerInstance or nil
-- function CommonEventController.instance()
--     if not _CommonEventControllerInstance then
--         _CommonEventControllerInstance = CommonEventController.new()
--     end
--     return _CommonEventControllerInstance
-- end

function CommonEventController:ctor(node)
    if not node then
        self.node = cc.Node:create()
        self.node:retain()
        self.lifeCircle = true
        self:listenToGetReward()
        local function onNodeEvent(event)
            if event == "cleanup" then
                self:onCleanup()
            end
        end
    
        self.node:registerScriptHandler(onNodeEvent)
    else
        self.node = node
    end
end

function CommonEventController:onCleanup()
    if self.lifeCircle then
        self:unlistenToGetReward()
        if self.node then
            self.node:autorelease()
            self.node = nil
        end
    end
end

function CommonEventController:post(evt, param)
    local dict = nil
    if param then
        dict = luaToDict({
            param = param
        })
    end
    if dict then
        CCSafeNotificationCenter:postNotification(evt, dict)
    else
        CCSafeNotificationCenter:postNotification(evt)
    end
end

function CommonEventController:on(evt, callback)
    local function handler(dict)
        Dprint("CommonEventController:triger evt="..evt)
        if type(callback) == "function" then
            local tbl = dictToLuaTable(dict)
            if tbl and tbl.param then
                callback(tbl.param)
            else
                callback()
            end
        end
    end
    CCSafeNotificationCenter:registerScriptObserver(self.node, self.node:registerHandler(handler), evt)
end

function CommonEventController:off(evt)
    CCSafeNotificationCenter:unregisterScriptObserver(self.node, evt)
end

function CommonEventController:once(evt, callback, timeout)
    local timer = nil
    self:on(evt, function(tbl)
        Dprint("CommonEventController:triger once evt="..evt)
        if timer then
            self:cancelTimer(timer)
            timer = nil
        end
        self:off(evt)
        if type(callback) == "function" then
            callback(tbl)
        end
    end)

    if timeout then
        timer = self:delayTimer(timeout, function()
            self:off(evt)
        end)
    end
end

function CommonEventController:intervalTimer(sec, callback)
    return self.node:getScheduler():scheduleScriptFunc(function(dt)
            if type(callback) == "function" then
                callback(dt)
            end
        end, sec, false)
end

function CommonEventController:delayTimer(sec, callback)
    local id = nil
    id = self.node:getScheduler():scheduleScriptFunc(function(dt)
            self:cancelTimer(id)
            if type(callback) == "function" then
                callback(dt)
            end
        end, sec, false)
    return id
end
function CommonEventController:cancelTimer(id)
    Dprint("CommonEventController:cancelTimer...")
    self.node:getScheduler():unscheduleScriptEntry(id)
end

function CommonEventController:asyncTasks(tasks, fn, everyTick, interrupt)
    if not fn or type(fn) ~= "function" then
        return 
    end
    dump(type(tasks), "CommonEventController:asyncTasks type(tasks)")
    if type(tasks) == "number" then
        local len = tasks
        tasks = {}
        for i = 1, len do
            tasks[i] = i
        end
    elseif type(tasks) ~= "table" then
        tasks = {tasks}
    end
    if not everyTick then
        everyTick = 0.1
    end

    local index = 1
    local len = #tasks

    local function execTasks(tick) 
        dump(tick, "CommonEventController:asyncTasks execTasks")
        while index <= len do
            if interrupt and interrupt() then
                break
            end
            local fromTime = self:getTodayMs()
            -- dump(fromTime, "CommonEventController:asyncTasks fromTime")
            fn(tasks[index])
            -- dump(index, "CommonEventController:asyncTasks index")
            index = index + 1
            local costTime = self:getTodayMs() - fromTime
            tick = tick - costTime
            dump(tick, "CommonEventController:asyncTasks tick")
            if costTime < 0 or tick <= 0 then
                self:delayTimer(0, function()
                    execTasks(everyTick)
                end)
                break
            end
        end
    end
    execTasks(everyTick)
end

function CommonEventController:getTodayMs()
    -- return GlobalData:call("getTimeStamp")
    return tonumber(GameController:call("getInstance"):call("millisecondNow")) / 1000
end

function CommonEventController:getRewardById(rwdId, callback)
    if rwdId then
        rwdId = tostring(rwdId)
        local rwd = GlobalData:call("getCachedRewardData", rwdId)
        local rwdData = arrayToLuaTable(rwd)
        if #rwdData == 0 then
            
            self:addRewardHandler(rwdId, callback)
     
            GlobalData:call("checkAndRequestRewardData", rwdId)
            Dprint("CommonEventController:getRewardById checkAndRequestRewardData:" .. rwdId)
        else
            callback(rwdData, rwdId)
        end
    else
        callback()
    end
    function cancel()
        -- self:cancelGetRewardById(rwdId)
        if rwdId then
            self:removeRewardHandler(rwdId, callback)
        end
    end

    return cancel
end

function CommonEventController:getRewardByIdOneByOne(rwdArr, callback)
    local cancelables = nil
    if rwdArr and #rwdArr > 0 then
        cancelables = {}

        local reqArr = {}
        for _, id in ipairs(rwdArr) do
            local rwdId = tostring(id)
            local rwd = GlobalData:call("getCachedRewardData", rwdId)
            local rwdData = arrayToLuaTable(rwd)
            if #rwdData == 0 then
                local cancelOne = self:addRewardHandler(rwdId, callback)
                table.insert(cancelables, cancelOne)

                table.insert(reqArr, rwdId)
            end
        end
        if #reqArr > 0 then
            GlobalData:call("shared"):call("requestMultiRewardData", reqArr)
        end
    end

    function cancel()
        -- self:cancelGetRewardByIdArray(rwdArr)
        for _, v in pairs(cancelables or {}) do
            v()
        end
        cancelables = nil
    end

    return cancel
end

function CommonEventController:getMultiReward(rwdArr, callback)
    local cancelables = nil
    if rwdArr and #rwdArr > 0 then
        cancelables = {}

        local hasMap = {}
        local function handler(rwdData, rwdId)
            if not hasMap[rwdId] then
                return
            end
            hasMap[rwdId] = 2
            local fin = true
            for _, v in pairs(hasMap) do
                if v == 1 then
                    fin = false
                    break
                end
            end
            if fin then
                callback()
            end
        end
        local reqArr = {}
        for _, id in ipairs(rwdArr) do
            local rwdId = tostring(id)
            local rwd = GlobalData:call("getCachedRewardData", rwdId)
            local rwdData = arrayToLuaTable(rwd)
            if #rwdData == 0 then
                hasMap[rwdId] = 1

                local cancelOne = self:addRewardHandler(rwdId, handler)
                table.insert(cancelables, cancelOne)

                table.insert(reqArr, rwdId)
            else
                hasMap[rwdId] = 2
            end
        end
        if #reqArr > 0 then
            GlobalData:call("shared"):call("requestMultiRewardData", reqArr)
        else
            callback()
        end
    else
        callback()
    end

    function cancel()
        -- self:cancelGetRewardByIdArray(rwdArr)
        for _, v in pairs(cancelables or {}) do
            v()
        end
        cancelables = nil
    end

    return cancel
end

function CommonEventController:addRewardHandler(rwdId, handler)
    if not rwdId or not handler then
        return
    end
    rwdId = tostring(rwdId)

    if not self.rwdMap then
        self.rwdMap = {}
    end
    if not self.rwdMap[rwdId] then
        self.rwdMap[rwdId] = {}
    end
    self.rwdMap[rwdId][handler] = true
end

function CommonEventController:removeRewardHandler(rwdId, handler)
    -- self.rwdMap[tostring(rwdId)] = nil
    if not self.rwdMap or not self.rwdMap[rwdId] then
        return
    end
    if self.rwdMap[rwdId][handler] then
        self.rwdMap[rwdId][handler] = nil
    end
end

function CommonEventController:listenToGetReward()
    local this = self
    local function handler(ref)
        local fetchId = ref:getCString()
        -- Dprint("CommonEventController:listenToGetReward:fetchId="..fetchId)
        
        if this.rwdMap and this.rwdMap[fetchId] then
            local cbs = {}
            for func, b in pairs(this.rwdMap[fetchId]) do
                if b then
                    table.insert(cbs, func)
                end
            end
            this.rwdMap[fetchId] = nil
            for _, cb in pairs(cbs) do
                this:getRewardById(fetchId, cb)
            end
        end
    end
    CCSafeNotificationCenter:registerScriptObserver(self.node, self.node:registerHandler(handler), MSG_GET_REWARD_DETAIL_BACK)
end
function CommonEventController:unlistenToGetReward()
    CCSafeNotificationCenter:unregisterScriptObserver(self, MSG_GET_REWARD_DETAIL_BACK)
end

function CommonEventController:createCounterTimer(countTo, callback)
    if not callback then
        return
    end
    function callback1()
        local last = countTo - getTimeStamp()
        callback(last)
    end
    callback1()
    return self:intervalTimer(0.5, callback1)
end

function CommonEventController:bindNode(node)
    return CommonEventController.new(node)
end

XEvtTimer = CommonEventController.new()
return XEvtTimer