--前三名展示
local CommonRank3KingdomNode =
    class(
    "CommonRank3KingdomNode",
    function()
        return cc.Node:create()
    end
)

--头部排行
local rankNumPicNames = {
    "Alliance_Ranking2.png",
    "Alliance_Ranking3.png",
    "Alliance_Ranking4.png"
}
--包箱
local rankBoxPicNames = {
    "common11baoxiangjin.png",
    "common11baoxianglan.png",
    "common11baoxianghui.png"
}
--背景
local nodeBGNames = {
    "BG_Ranking_01.png",
    "BG_Ranking_02.png",
    "BG_Ranking_03.png"
}
function CommonRank3KingdomNode:create(rank, info, parent)
    local node = CommonRank3KingdomNode.new()
    Drequire("game.CommonPopup.commonRank.CommonRank3PlayerNode_ui"):create(node)
    node:initNode(rank, info, parent)
    return node
end

function CommonRank3KingdomNode:initNode(rank, info, parent)
    -- dump(info,"hxq info is ")
    self.rank = rank
    self.info = info
    self.parent = parent
    local rankNumSprName = rankNumPicNames[rank]
    local sf = CCLoadSprite:call("getSF", rankNumSprName)
    if sf then
        self.ui.m_rankNumSpr:setSpriteFrame(sf)
    end

    local boxSprName = rankBoxPicNames[rank]
    sf = CCLoadSprite:call("getSF", boxSprName)
    if sf then
        self.ui.m_boxSpr:setSpriteFrame(sf)
    end

    local nodeBGName = nodeBGNames[rank]
    sf = CCLoadSprite:call("getSF", nodeBGName)
    if sf then
        self.ui.m_nodeBG:setSpriteFrame(sf)
    end

    self.ui["m_nameLabel"]:setString("")
    self.ui["m_powerLabel"]:setString("")
    self.ui["m_serverLabel"]:setString("")

    -- self.ui.m_userNameNode:setVisible(false)
    self:setNodeInfo()
end

function CommonRank3KingdomNode:setNodeInfo()
    if not self.info then
        self.ui.m_nameLabel:setString("")
        self.ui.m_powerLabel:setString("")
        self.ui.m_serverLabel:setString("")
    else
        local _score = tonumber(self.info.score) or 0
        self.ui["m_powerLabel"]:setString(CC_CMDITOAL(_score))

        local str = nil
        -- if self.info.hideKing == "1" or self.info.anonymous_state == 1 then  -- 玩家是否隐藏联盟
        if self:isHideKing() then
            str = getLang("9800069") -- 9800069=王国信息已隐藏
        else
            str = ""
            if self.info.name and self.info.name ~= "" then
                str = str .. self.info.name
            end
        end

        if str then
            self.ui["m_nameLabel"]:setString(str)
        end

        if self.info.kingName and self.info.kingName ~= "" then
            self.ui["m_serverLabel"]:setVisible(true)
            self.ui["m_serverLabel"]:setString(getLang("110025", self.info.kingName))
        else
            self.ui["m_serverLabel"]:setVisible(false)
        end

        self.ui["m_headNode"]:removeAllChildren()

        if not self:isHideKing() then
            local bPath = CCCommonUtilsForLua:call("getCountryIconByName", self.info.banner or "")
            local banner = CCLoadSprite:call("createSprite", bPath)
            CCCommonUtilsForLua:call("setSpriteMaxSize", banner, 68, true)
            self.ui.m_headNode:addChild(banner)
        end
    end
end

function CommonRank3KingdomNode:onClickPicBtn()
    if self:isHideKing() or not self.info then
        return
    end
    if self.parent and self.parent.openKingdomViewByRankInfo then
        self.parent:openKingdomViewByRankInfo(self.info)
    end
end

function CommonRank3KingdomNode:onRewardButtonClick()
    self.parent:onRewardButtonClick(self.rank)
end

function CommonRank3KingdomNode:isHideKing()
    local info = self.info
    if not info then
        return true
    end
    if not info.config or not info.config.getAnonymousOpen or not info.config:getAnonymousOpen() then
        return false
    end
    if info.hideKing == "1" or tonumber(info.anonymous_state) == 1 then
        return true
    end
    return false
end

return CommonRank3KingdomNode
