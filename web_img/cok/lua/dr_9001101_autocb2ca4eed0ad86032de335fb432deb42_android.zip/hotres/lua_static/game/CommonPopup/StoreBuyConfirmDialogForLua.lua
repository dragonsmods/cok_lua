------------------------------------------ StoreBuyConfirmDialogForLua Start --------------------------------------------
StoreBuyConfirmDialogForLua = class("StoreBuyConfirmDialogForLua", function() return PopupBaseView:call("create") end)
StoreBuyConfirmDialogForLua.__index = StoreBuyConfirmDialogForLua
function StoreBuyConfirmDialogForLua:create(params)
    local ret = StoreBuyConfirmDialogForLua.new()
    Drequire("game.CommonPopup.StoreBuyConfirmDialogForLua_ui"):create(ret, 1)
    if ret:initView(params) == false then
        return nil
    end
    return ret
end

function StoreBuyConfirmDialogForLua:initView(params)
	--data
	self.m_itemId = params.itemId
	self.m_maxNum = params.maxNum
	self.m_messagePosted = params.messagePosted
	self.m_singlePoint = params.singlePoint
	self.m_moneyIcon = params.moneyIcon
	self.m_id = params.id
	self.m_isShowSelect = 1
	self.m_priceType = WorldResourceType.Gold
	self.m_hasNum = params.hasNum
	self.m_iconNum = params.iconNum
	if params.priceType then
		self.m_priceType = params.priceType
	end
	if self.m_priceType < WorldResourceType.Wood then
		self.m_priceType = WorldResourceType.Wood
	end
	if params.index then
		self.m_index = params.index 
	end
	if params.isShowSelect then
		self.m_isShowSelect = tonumber(params.isShowSelect)
	end
	self.m_isNeedStore = 1
	if params.isNeedStore then
		self.m_isNeedStore = tonumber(params.isNeedStore)
	end
	if self.m_isShowSelect == 0 then
		self.ui.m_numNode:setVisible(false)
		self.ui.m_numNode:setPositionX(-99999)
	else
		self.ui.m_numNode:setVisible(true)
		self.ui.m_numNode:setPositionX(0)
	end
	self.m_isPriceEnough = true
	self.m_curNum = 1
	sliderMin = 1
	if self.m_maxNum <= 0 then
		self.m_maxNum = 0
		self.m_curNum = 0
		sliderMin = 0
		self.ui.m_useBtn:setEnabled(false)
	end
	self:initUI()

    local function touchHandle( eventType, x, y )
        if eventType == "began" then
            return self:onTouchBegan(x, y)
        elseif eventType == "moved" then
        else
            self:onTouchEnded(x, y)
        end
    end
    self:registerScriptTouchHandler(touchHandle)
    self:setTouchEnabled(true)
    return true;
end

function StoreBuyConfirmDialogForLua:initUI()
	self:initEditBox()
	--title
	self.ui.node_originCost:setVisible(false)

	if tonumber(self.m_itemId) <= WorldResourceType.Gold and tonumber(self.m_itemId) >= WorldResourceType.Wood then
		local iconName = CCCommonUtilsForLua:call("getResourceIconByType", tonumber(self.m_itemId))
        local pic = CCLoadSprite:call("createSprite", iconName)
        if (pic ~= nil) then
            local sptName = CCCommonUtilsForLua:call("getToolBgByColor", 0) -- 0 == WHITE
            local iconBg = CCLoadSprite:call("createSprite", sptName)
            CCCommonUtilsForLua:call("setSpriteMaxSize", iconBg, 130, true)
            self.ui.m_nodeIcon:addChild(iconBg)
            CCCommonUtilsForLua:call("setSpriteMaxSize", pic, 120, true)
            self.ui.m_nodeIcon:addChild(pic)
        end
        local name = CCCommonUtilsForLua:call("getResourceNameByType", tonumber(self.m_itemId)) 
		if self.m_isShowSelect == 1 then
			self.ui.m_lblTitle:setString(name)
		else
			self.ui.m_lblTitle:setString(name .. "  x" .. CC_CMDITOA(self.m_maxNum))
		end
	else
		local description = CCCommonUtilsForLua:getPropById(tostring(self.m_itemId), "description")
		local name = CCCommonUtilsForLua:getPropById(tostring(self.m_itemId), "name")

		local color = tonumber(CCCommonUtilsForLua:call("getPropById", self.m_itemId, "color"))
		if not color then
			color = atoi(CCCommonUtilsForLua:call("getPropByIdGroup", "dragon_skill", self.m_itemId, "quality"))
		end
		local colorstr = CCCommonUtilsForLua:call("getToolBgByColor", color)
		local colorSpr = CCLoadSprite:createSprite(colorstr)
		if colorSpr then
			CCCommonUtilsForLua:call("setSpriteMaxSize", colorSpr, 130, true)
			self.ui.m_nodeIcon:addChild(colorSpr)
		end

		local iconName = CCCommonUtilsForLua:call("getIcon", self.m_itemId)
		local icon = CCLoadSprite:call("createSprite", iconName, CCLoadSpriteType.CCLoadSpriteType_RESOURCE)
		if icon then
			self.ui.m_nodeIcon:addChild(icon)
			CCCommonUtilsForLua:call("setSpriteMaxSize", icon, 120, true)
		end
		if self.m_isShowSelect == 1 then
			self.ui.m_lblTitle:setString(getLang(name))
		else
			self.ui.m_lblTitle:setString(getLang(name) .. "  x" .. CC_CMDITOA(self.m_maxNum))
		end
		self.ui.m_titleLabel:setString(getLang(description))
	end
	
	local moneySpr = CCLoadSprite:createSprite(self.m_moneyIcon, CCLoadSpriteType.CCLoadSpriteType_GOODS)
	if moneySpr then
		self.ui.m_costNode:addChild(moneySpr)
		CCCommonUtilsForLua:call("setSpriteMaxSize", moneySpr, 45, true)
	end
	self.ui.m_infoLabel:setString(getLang("104919"))
	self:changeTitle(self.m_curNum)

	if self.ui.m_pNodeNum then
		self.ui.m_pNodeNum:setVisible(false)
		if self.m_iconNum then
			self.ui.m_pNodeNum:setVisible(true)
			self.ui.m_numTxt:setString("X" .. tostring(self.m_iconNum))
		end
	end
end

function StoreBuyConfirmDialogForLua:initEditBox(  )
	--文本框
	local img = CCLoadSprite:call("createScale9Sprite", "frame_text2.png")  
	img:setAnchorPoint(0.5, 0.5)
	self.m_editBox = cc.EditBox:create(self.ui.m_editNode:getContentSize(), img)  --输入框尺寸，背景图片
	self.m_editBox:setPosition(self.ui.m_editNode:getContentSize().width / 2,self.ui.m_editNode:getContentSize().height / 2)
	self.m_editBox:setAnchorPoint(cc.p(0.5,0.5))
	self.m_editBox:setFontSize(22)
	self.m_editBox:setFontColor(cc.c3b(255,255,255))
	self.m_editBox:setReturnType(cc.KEYBOARD_RETURNTYPE_DONE ) --输入键盘返回类型，done，send，go等
	self.m_editBox:setInputMode(cc.EDITBOX_INPUT_MODE_NUMERIC) 
	self.m_editBox:setPlaceHolder("1")
	if self.m_maxNum <= 0 then
		self.m_editBox:setPlaceHolder("0")
	end
	self.m_editLastTime = "0"--控制数字输出
	local function editCB (strEventName,pSender)
		if tostring(pSender) == "began" then
		elseif tostring(pSender) == "ended" then
		elseif tostring(pSender) == "return" then
			if self.m_editBox:getText() ~= nil then
				local num = tonumber(self.m_editBox:getText())
				num = math.max(math.min(num, self.m_maxNum), sliderMin)
				self.m_curNum = num
				self.m_controlSlider:setValue(self.m_curNum)
				self:changeTitle(self.m_curNum)
			end
		elseif tostring(pSender) == "changed" then
			if string.len(self.m_editBox:getText()) > 0 and tonumber(self.m_editBox:getText()) == nil then
				self.m_editBox:setText(self.m_editLastTime)
			end
			self.m_editLastTime = self.m_editBox:getText()
			if tonumber(self.m_editBox:getText()) ~= nil then
				local num = tonumber(self.m_editBox:getText())
				num = math.max(math.min(num, self.m_maxNum), sliderMin)
				self.m_curNum = num
				self.m_controlSlider:setValue(self.m_curNum)
				self:changeTitle(self.m_curNum)
			end
		end
	end
	self.m_editBox:registerScriptEditBoxHandler(editCB)
	self.ui.m_editNode:addChild(self.m_editBox)
	--滑动条
	local thunmImg = CCLoadSprite:createSprite("huadongtiao1.png")
	local progImg = CCLoadSprite:createSprite( "huadongtiao2.png") 
	local bgImg =  CCLoadSprite:createSprite( "huadongtiao3.png") 
	bgImg:setContentSize(self.ui.m_barNode:getContentSize())
	bgImg:setVisible(false)
	self.m_controlSlider = cc.ControlSlider:create(bgImg,progImg,thunmImg)
	self.m_controlSlider:setAnchorPoint(CCPoint(0.5,0.5))
	self.m_controlSlider:setPosition(CCPoint(self.ui.m_barNode:getContentSize().width / 2,self.ui.m_barNode:getContentSize().height / 2))
	self.m_controlSlider:setEnabled( true )
	self.m_controlSlider:setMinimumValue( 1 )
	self.m_controlSlider:setMaximumValue( tonumber(self.m_maxNum) )
	--注册
  	local function valueChanged(pSender)
	    if nil == pSender then
	        return
	    end           
	    local pControl = pSender
	    local changedInt = math.ceil(pControl:getValue())
	    self.m_editBox:setText(tostring(changedInt));
	    self.m_curNum = changedInt
		self:changeTitle(self.m_curNum)
	end
	self.m_controlSlider:addHandleOfControlEvent(valueChanged, 256) 
	self.ui.m_barNode:addChild(self.m_controlSlider)
end

function StoreBuyConfirmDialogForLua:onEnter()
end

function StoreBuyConfirmDialogForLua:onExit()
end

function StoreBuyConfirmDialogForLua:onTouchBegan(x, y)
	if x < 1 and y < 1 then
		return false
	end
	return true
end

function StoreBuyConfirmDialogForLua:onTouchMoved(x, y)
end

function StoreBuyConfirmDialogForLua:onTouchEnded(x, y)
	if touchInside(self.ui.m_touchNode, x, y) == false then
		self.m_editBox:unregisterScriptEditBoxHandler()
		self = tolua.cast(self, "PopupBaseView")
        self:call("closeSelf")		
	end
end

function StoreBuyConfirmDialogForLua:onUseClick()
	if self.m_isNeedStore == 1 then
		local pobj = CCDictionary:create()
		pobj:setObject(CCInteger:create(self.m_curNum), "count")
		pobj:setObject(CCString:create(self.m_id), "shopId")
		CCSafeNotificationCenter:postNotification(self.m_messagePosted,pobj)
	else
		if self.m_isPriceEnough then
			local pobj = CCDictionary:create()
			pobj:setObject(CCInteger:create(self.m_itemId), "itemId")
			pobj:setObject(CCString:create(self.m_maxNum), "maxNum")
			pobj:setObject(CCString:create(self.m_singlePoint), "singlePoint")
			pobj:setObject(CCString:create(self.m_priceType), "priceType")
			pobj:setObject(CCString:create(self.m_index), "index")
			CCSafeNotificationCenter:postNotification(self.m_messagePosted,pobj)
		else
			if self.m_priceType == WorldResourceType.Gold then
				YesNoDialog:call("gotoPayTips")
			elseif self.m_priceType >= WorldResourceType.Wood and self.m_priceType <= WorldResourceType.WorldResource_Max then
				CCCommonUtilsForLua:call("flyHint", "", "", getLang("E100002")) 
			else
				CCCommonUtilsForLua:call("flyHint", "", "", getLang("150334")) 
			end
		end
	end
	self.m_editBox:unregisterScriptEditBoxHandler()
	self = tolua.cast(self, "PopupBaseView")
    self:call("closeSelf")
end

function StoreBuyConfirmDialogForLua:onSubClick()
	local sliderValue = self.m_controlSlider:getValue() - 1
	sliderValue = math.max(sliderMin,sliderValue)
	self.m_curNum = sliderValue
	self.m_controlSlider:setValue(sliderValue)
	self:changeTitle(self.m_curNum)
end

function StoreBuyConfirmDialogForLua:onAddClick()
	local sliderValue = self.m_controlSlider:getValue() + 1
	sliderValue = math.min(self.m_maxNum,sliderValue)
	self.m_curNum = sliderValue
	self.m_controlSlider:setValue(sliderValue)
	self:changeTitle(self.m_curNum)
end

function StoreBuyConfirmDialogForLua:changeTitle( num )
	self.ui.m_costNum:setString(CC_CMDITOA(num * self.m_singlePoint))
	if self.m_hasNum then
		if self.m_hasNum < tonumber(self.m_singlePoint) then
			self.ui.m_costNum:setColor(cc.c3b(255, 0, 0))
        	self.m_isPriceEnough = false
		else
			self.m_isPriceEnough = true
        	self.ui.m_costNum:setColor(cc.c3b(255, 255, 0))
		end
	elseif(tonumber(self.m_priceType) < WorldResourceType.WorldResource_Max) then
        if (CCCommonUtilsForLua:call("isEnoughResourceByType", tonumber(self.m_priceType),self.m_singlePoint)) then
        	self.m_isPriceEnough = true
            self.ui.m_costNum:setColor(cc.c3b(255, 255, 0))
        else
        	self.m_isPriceEnough = false
            self.ui.m_costNum:setColor(cc.c3b(255, 0, 0))
        end
    else
        local itemInfo = ToolController:call("getToolInfoByIdForLua", tonumber(self.m_priceType))
        if itemInfo and itemInfo:call("getCNT") < tonumber(self.m_singlePoint) then
            self.ui.m_costNum:setColor(cc.c3b(255, 0, 0))
        	self.m_isPriceEnough = false
        else
        	self.m_isPriceEnough = true
        	self.ui.m_costNum:setColor(cc.c3b(255, 255, 0))
        end
    end
end

return StoreBuyConfirmDialogForLua