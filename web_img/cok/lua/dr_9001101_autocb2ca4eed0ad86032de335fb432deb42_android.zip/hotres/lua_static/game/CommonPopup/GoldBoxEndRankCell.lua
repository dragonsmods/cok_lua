local GoldBoxEndRankCell = class("GoldBoxEndRankCell", function()
    return cc.Layer:create()
end)

function GoldBoxEndRankCell:create(idx)
    local ret = GoldBoxEndRankCell.new()
    Drequire("game.CommonPopup.GoldBoxEndRankCell_ui"):create(ret, 0)
    return ret
end

function GoldBoxEndRankCell:refreshCell(info, idx)
    self.m_dataList = info
    self.ui.m_sprBG1:setVisible(false)
    self.ui.m_sprBG2:setVisible(false)
    self.ui.m_sprBG3:setVisible(false)
    self.ui.m_sprBG4:setVisible(false)
    self.ui.m_numspr2:setVisible(false)
    self.ui.m_numspr1:setVisible(false) 
    self.ui.m_numspr3:setVisible(false) 
    self.ui.m_numText:setVisible(false)  
    self.m_index = idx + 1

    if self.m_index == 1 then
        self.ui.m_numspr1:setVisible(true)
        self.ui.m_sprBG1:setVisible(true)
    elseif self.m_index == 2 then
        self.ui.m_numspr2:setVisible(true)
        self.ui.m_sprBG2:setVisible(true)
    elseif self.m_index == 3 then
        self.ui.m_numspr3:setVisible(true)
        self.ui.m_sprBG3:setVisible(true)
    elseif self.m_index >= 4 and self.m_index <= 30 then 
        self.ui.m_numText:setString(tostring(self.m_index))
        self.ui.m_numText:setVisible(true)     
    end
    if tostring(GlobalData:call("shared"):getProperty("playerInfo"):getProperty("uid")) == tostring(self.m_dataList.uid) then -- 是自己
        self.ui.m_sprBG4:setVisible(true)
    end
    
    if self.m_dataList.hideKing == "1" then
        self.ui.m_text1:setString(getLang("140473"))
        self.ui.m_text2:setString("")
    elseif self.m_dataList.hideKing == "0" then
        self.ui.m_text1:setString(self.m_dataList.name)
        self.ui.m_text2:setString(getLang("111895",self.m_dataList.kingId))
    end
    self.ui.m_text3:setString(self.m_dataList.count)
end

function GoldBoxEndRankCell:onEnter(  )
    
end

function GoldBoxEndRankCell:onExit(  )
    
end

return GoldBoxEndRankCell
