
local CommonProgressView = class("CommonProgressView", function (  )
	return cc.Node:create()
end)

local CommonProgressNode = class("CommonProgressNode", function (  )
	return cc.Node:create()
end)

--[[
	interval : 均匀长度 默认 100
	如需变长 请在data 中指定 interval 字段
]]

function CommonProgressView:ctor( data, listWidth, interval, maxwidth )
	self.data = data
	self.interval = interval or 100
	maxwidth = maxwidth or 640
	-- 设置滑动条长度
	self.m_listWidth = listWidth or 450
	if self.m_listWidth < 150 then
		self.m_listWidth = 150
	elseif self.m_listWidth > maxwidth then
		self.m_listWidth = maxwidth
	end
end

function CommonProgressView.create( data, listWidth, interval )
	local ret = CommonProgressView.new(data, listWidth, interval)
	if ret:initSelf() ~= true then
		ret = nil
	end
	return ret
end

function CommonProgressView:initSelf(  )
	if nil == self.data then
		return false
	end

	if #self.data == 0 then
		return false
	end

	local proxy = cc.CCBProxy:create()
    local ccbiUrl = "CommonProgressView"
	local node = CCBReaderLoad(ccbiUrl, proxy, self)
    if nil == node then
    	MyPrint("CommonProgressView node == nil !!!!!")
        return false
    end
    self:addChild(node)

    -- 调节滑动条长度
    self.m_progressBarLeft:setContentSize(cc.size(self.m_listWidth / 2, self.m_progressBarLeft:getContentSize().height))
    self.m_progressBarRight:setContentSize(cc.size(self.m_listWidth / 2, self.m_progressBarRight:getContentSize().height))
    self.m_listNode:setContentSize(cc.size(self.m_listWidth - 50, self.m_listNode:getContentSize().height))

	-- 基本信息描述滑动
    local scrollView = cc.ScrollView:create()
    local viewSize = self.m_listNode:getContentSize()
    scrollView:setViewSize(viewSize)
    scrollView:ignoreAnchorPointForPosition(true)
    scrollView:setPosition(cc.p(0,0))
    scrollView:setScale(1.0)
    scrollView:setDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL)
    self.m_listNode:addChild(scrollView)
    self.scrollView = scrollView
    local function scrollViewDidScroll( view )
        return self:scrollViewDidScroll(view)
    end
    scrollView:setDelegate()
    scrollView:registerScriptHandler(scrollViewDidScroll, cc.SCROLLVIEW_SCRIPT_SCROLL)

    self.m_mountNode:removeFromParent()
    self.scrollView:addChild(self.m_mountNode)
    self.m_mountNode:setPositionX(5)

    self:refreshPro()
	return true
end

function CommonProgressView:scrollViewDidScroll( view )
    local dx = self.scrollView:getContentOffset().x
    if (dx > 0) then
        self.scrollView:setContentOffset(cc.p(0, 0))
    end
end

local const_proLen = 100
function CommonProgressView:refreshPro(  )
	self.m_mountNode:removeAllChildren()
	local mark = 0
	local totalW = 0
	local local_proLen = self.interval or const_proLen
	local markLen = 0
	local tailLen = nil
	for i=1,#self.data do
		local tdata = self.data[i]
		-- dump(tdata,"tdata+++")
		local proLen = tdata.interval or local_proLen
		local node = CommonProgressNode.new(tdata,proLen)
		node:setPositionX(totalW)

		if i == #self.data - 2 and #self.data > 2 then
			tailLen = totalW
		end
		
		self.m_mountNode:addChild(node)
		if mark == 0 and node:shouldBeShow() then
			if i >= #self.data - 2 and #self.data > 2 then
				mark = #self.data - 2
				markLen = tailLen
			else
				mark = i
				markLen = totalW
			end
			
		end

		totalW = totalW + proLen
	end

	if mark == 0 then
		mark = 1
	end

	-- local totalW = #self.data * proLen
	totalW = totalW + self.m_mountNode:getPositionX() + 100

	self.scrollView:setContentSize(cc.size(totalW, self.m_listNode:getContentSize().height))
	-- self.scrollView:setContentOffset(cc.p(-proLen * (mark - 1), 0))
	self.scrollView:setContentOffset(cc.p(-markLen, 0))
end
---滚动到第一个可领奖的节点
function CommonProgressView:scrollToFirstCanRewardNode()
	local firstIndex = 0 --记录第一个可领奖宝箱的位置

	for i=1,#self.data do

		if self.data[i].state == "2" then
			--可领奖
            firstIndex = i
            break
		end
	end
	local local_proLen = self.interval or const_proLen
	local offset = math.max(-local_proLen * (firstIndex - 1),self.scrollView:getViewSize().width - self.scrollView:getContentSize().width)
    self.scrollView:setContentOffset(cc.p(offset, 0))
end

-----------------------------------------------------------------------------------------------
function CommonProgressNode:ctor( data,proLen )
	self.data = data
	proLen = proLen or 100
	local proxy = cc.CCBProxy:create()
    local ccbiUrl = "CommonProgressNode"
	local node = CCBReaderLoad(ccbiUrl, proxy, self)
    if nil == node then
    	MyPrint("CommonProgressNode node == nil !!!!!")
        return false
    end
    self:addChild(node)

    self:setLength(proLen)
    self:refreshView()

    local function onNodeEvent( event )
		if event == "enter" then
			self:onEnter()
	    elseif event == "exit" then
	    	self:onExit()
	    end
	end
	self:registerScriptHandler(onNodeEvent)

	self.startTouchPt = cc.p(0, 0)
	self.touchLayer = cc.Layer:create()
    local function touchHandle( eventType, x, y )
        if eventType == "began" then
            return self:onTouchBegan(x, y)
        elseif eventType == "moved" then
        else
            self:onTouchEnded(x, y)
        end
    end
    self.touchLayer:registerScriptTouchHandler(touchHandle)
    self.touchLayer:setTouchEnabled(true)
    self.touchLayer:setSwallowsTouches(false)
    self:addChild(self.touchLayer)
end

function CommonProgressNode:setLength( len )
	if len == self.curLength then
		return
	end
	self.curLength = len
	local ui_arr = self.m_extendUIArr
	if not ui_arr then
		ui_arr = {
			self.m_bar,
			self.m_rigthLine,
			self.m_boxNode,
			self.m_topLabel,
			self.spr_rose,
		}
		self.m_extendUIArr = ui_arr
	end

	local oriLen = self.m_oriLen
	if not oriLen then
		oriLen = ui_arr[2]:getPositionX()
		self.m_oriLen = oriLen
	end

	local dx = len - oriLen

	if dx == 0 then
		return
	end

	if not ui_arr[1].m_oriValue then
		ui_arr[1].m_oriValue = ui_arr[1]:getContentSize().width
	end

	--why 1/0.9 因为m_bar 的父结点 scalex 0.9
	ui_arr[1]:setContentSize(cc.size(ui_arr[1].m_oriValue + dx * (1/0.9),ui_arr[1]:getContentSize().height))

	for i=2,#ui_arr do
		if not ui_arr[i].m_oriValue then
			ui_arr[i].m_oriValue = ui_arr[i]:getPositionX()
		end

		ui_arr[i]:setPositionX(ui_arr[i].m_oriValue + dx)
	end
end

function CommonProgressNode:getType(  )
	return tonumber(self.data.type)
end

function CommonProgressNode:onEnter(  )
	local function onGetRwdDataBack( ref )
		if nil == ref then
			return
		end
		local reward = ref:getCString()
		if reward ~= self.data.reward then
			return
		end

		if self.m_callFromRefresh then
			self.m_callFromRefresh = false
			if not string.isNilOrEmpty(self.data.cornerItem) then
				local _tInfo = ToolController:call("getToolInfoByIdForLua", tonumber(self.data.cornerItem))
				self:refreshConnerIcon(_tInfo,self.data.cornerItem)
			end
			return
		end

		if self.isRequesting ~= true then
			return
		end

		self.isRequesting = false
		self:showRwdGetView()
	end
	
	local handler1 = self:registerHandler(onGetRwdDataBack)
	CCSafeNotificationCenter:call("registerScriptObserver", self, handler1, "MSG_GET_REWARD_DETAIL_BACK")

	self:tryReqReward()
end

function CommonProgressNode:onExit()
	CCSafeNotificationCenter:call("unregisterScriptObserver", self, "MSG_GET_REWARD_DETAIL_BACK")
end

function CommonProgressNode:addParticle( )
	-- 显示可领取特效
	local prefix = "Feedback_"
	local count = 4
	for i = 2, count do
		local particle = ParticleController:call("createParticle", prefix .. i)
		particle:setPositionType(1)
		particle:setContentSize(cc.size(1000, 1000))
		self.m_boxParNode:addChild(particle)
	end
	local particle2 = ParticleController:call("createParticle", "Feedback_1")
	particle2:setContentSize(cc.size(1000, 1000))
	particle2:setPositionType(1)
	self.m_boxParNode2:addChild(particle2)
end

local GRAY="0"
local OPEN="1"
local PURPLE="2"
local GRAY_AND_OPEN="3"
function CommonProgressNode:refreshView()
	local data = self.data --data.state: 0,不可领，灰色；1,已领取；2,可领取，金色
	local now = self.data.curPro
	
	if not now then
		dump("error: now is nil+++") 
		return 
	end
	now = tonumber(now)
	local bottom = tonumber(data.bottom)
	local top = tonumber(data.target)

	-- MyPrint("top+++++", top, data.maxPro)
	local strTop = data.disable_number_unit and tostring(top) or CC_ITOA_2K(top)
	strTop = data.displayDesc or  strTop --内容显示
	self.m_topLabel:setString(strTop)
	if bottom == 0 then
		self.m_bottomLabel:setString("0")
	end

	local overBottom = now - bottom
	overBottom = math.max(0, overBottom)
	local pro = overBottom / (top - bottom)
	pro = math.min(1, pro)
	pro = math.max(0, pro)
	-- MyPrint("pro ", pro)
	-- 在进度极小时, 也在进度条上显示一个可见的进度
	if bottom == 0 and now > 0 and pro < 0.05 then
		pro = 0.05
	end
	self.m_bar:setScaleX(pro)
	self.m_parNode:setPositionY(self.m_bar:getPositionY())

	self.m_parNode:setPositionX(self.m_bar:getPositionX() + self.curLength * pro)
	self.m_parNode:removeAllChildren()
	self.m_boxNode:setVisible(data.reward and data.reward ~= "")
	if pro >= 1 or now < bottom then
		self.m_parNode:setVisible(false)
	else
		self.m_parNode:setVisible(true)
		local beginColor = cc.c4b(0, 0, 0, 0)
		local endColor = cc.c4b(0, 0, 0, 0)
		for i = 1, 3 do
			local path = string.format("Loading_%d", i)
			local particle = ParticleController:call("createParticle", path)
			if (i == 1) then
				beginColor = cc.c4b(255 / 255, 200 / 255, 100 / 255, 100 / 255)
			elseif (i == 2) then
				beginColor = cc.c4b(255 / 255, 200 / 255, 0 / 255, 100 / 255)
			else
				beginColor = cc.c4b(255 / 255, 255 / 255, 255 / 255, 100 / 255)
			end

			particle:setStartColor(beginColor)
			particle:setEndColor(endColor)
			particle:setContentSize(cc.size(1000, 1000))
			self.m_parNode:addChild(particle)
		end
	end


	self.m_cornerNode:setVisible(false)
	if data.cornerStyle then
		if CCLoadSprite:call("getSF", "BG_tubiaokuang01.png") then
			self.m_spriteBg:setSpriteFrame(CCLoadSprite:call("loadResource", "BG_tubiaokuang01.png"))
			self.m_spriteBg:setScale(0.68)
		end
		self.m_boxOpen:setScale(0.72)
		self.m_boxClose:setScale(0.72)
		
		if data.cornerItem and data.cornerItem ~= "" then
			local _tInfo= ToolController:call("getToolInfoByIdForLua", tonumber(data.cornerItem))
			if _tInfo then
				self:refreshConnerIcon(_tInfo,data.cornerItem)
			end
		end

		local pos = self.m_boxNode:getPositionY()
		self.m_boxNode:setPositionY(pos + 18)
	else
		-- self.m_spriteBg:setSpriteFrame(CCLoadSprite:call("loadResource", "BG_yingxiongpinzhikuang_bai.png"))
		-- self.m_spriteBg:setScale(1)
		-- self.m_boxOpen:setScale(1)
		-- self.m_boxClose:setScale(1)
		-- self.m_cornerNode:setVisible(false)
	end

	self.m_boxParNode:removeAllChildren()
	self.m_boxParNode2:removeAllChildren()
	self.m_boxClose:setVisible(false)
	self.m_boxOpen:setVisible(false)

	if data.state == GRAY then
		self.m_boxClose:setVisible(true)
		CCCommonUtilsForLua:call("setSpriteGray", self.m_boxClose, true)
	elseif data.state == OPEN then
		self.m_boxOpen:setVisible(true)
	elseif data.state == PURPLE then
		self.m_boxClose:setVisible(true)
		if not data.dontGetRewardButShow then
			self:addParticle()
		end
		CCCommonUtilsForLua:call("setSpriteGray", self.m_boxClose, false)
	elseif data.state == GRAY_AND_OPEN then
		self.m_boxOpen:setVisible(true)
		CCCommonUtilsForLua:call("setSpriteGray", self.m_boxOpen, true)
	end
	if data.showType and data.showType == "16" then
		self.spr_rose:setVisible(true)
		self.spr_rose:setPositionX(self.m_topLabel:getPositionX() + self.m_topLabel:getContentSize().width / 2 + 5)
	else
		self.spr_rose:setVisible(false)
	end
    self.m_nodeSpecial:setVisible(data.specialItem and data.specialItem ~= "")
    if data.specialItem then
        self.m_nodeSpecial:removeAllChildren()
        local _tInfo= ToolController:call("getToolInfoByIdForLua", tonumber(data.specialItem))
        local pic = self:getConnerIcon(_tInfo,data.specialItem)
        local res_ready = CCLoadSprite:call("getSF", pic)
		if not res_ready then
			local goods_names = {"goods","goods_01","goods_02","goods_03"}
			for _,v in ipairs(goods_names) do
				CCLoadSprite:call("loadDynamicResourceByName", v)
			end
		end
		local spr = CCLoadSprite:call("createSprite",pic)
        self.m_nodeSpecial:addChild(spr)
        CCCommonUtilsForLua:call("setSpriteMaxSize", spr, 30, true)
    end

end

function CommonProgressNode:refreshConnerIcon( _tInfo,cornerItemId )
	if self.m_connerHadSet then
		return
	end

	local iconPic = self:getConnerIcon(_tInfo,cornerItemId)
	-- cclog("iconPic here is %s",iconPic)
	if iconPic ~= ".png" then
		self.m_connerHadSet = true
	end

	local res_ready = CCLoadSprite:call("getSF", iconPic)
	if not res_ready then
		local goods_names = {"goods","goods_01","goods_02","goods_03"}
		for _,v in ipairs(goods_names) do
			CCLoadSprite:call("loadDynamicResourceByName", v)
		end
	end

	res_ready = CCLoadSprite:call("getSF", iconPic)
	if res_ready then
		self.m_cornerNode:setVisible(true)
		self.m_cornerItemSprite:setSpriteFrame(CCLoadSprite:call("loadResource", iconPic))
		CCCommonUtilsForLua:call("setSpriteMaxSize", self.m_cornerItemSprite, 55, true)
	end
end

function CommonProgressNode:getConnerIcon( _tInfo,cornerItemId )
	local icon_str = _tInfo:getProperty("icon")

	repeat
		if not string.isNilOrEmpty(icon_str) then
			break
		end

		if not cornerItemId then
			break
		end

		local isDragonSkill = CCCommonUtilsForLua:isDragonSkill(tonumber(cornerItemId))

		if not isDragonSkill then
			break
		end

		local skillInfo = self:findConnerItemInfo(cornerItemId)
		if not skillInfo or not skillInfo.value then
			break
		end

		local t_icon = CCCommonUtilsForLua:call("getIcon", tostring(skillInfo.value.id))
		if string.isNilOrEmpty(t_icon) then
			break
		end

		return t_icon
	until true

	return icon_str..".png"
end

function CommonProgressNode:setIsSpecial( isSpecial )
	-- if isSpecial then
	-- 	self.m_box:setScale(1.1)
	-- else
	-- 	self.m_box:setScale(0.9)
	-- end
end

function CommonProgressNode:shouldBeShow(  )
	return false
end

function CommonProgressNode:onTouchBegan( x, y )
	if self:isVisible(true) == false then return false end

	self.startTouchPt = cc.p(x, y)

	if isTouchInside(self.m_touchNode, x, y) then
		return true
	end

	return false
end

function CommonProgressNode:onTouchEnded( x, y )
	dump("touch end+++")
	local dis = 10
	if CCCommonUtilsForLua:call("isIosAndroidPad") then
		dis = 20
	end
	if cc.pGetDistance(cc.p(x, y), self.startTouchPt) > dis then
		return 
	end

	if isTouchInside(self.m_touchNode, x, y) == false then
		return
	end

	-- dump(data, "data+++")
	local data = self.data
	if data.state == GRAY or data.state == OPEN or data.state == GRAY_AND_OPEN
		or data.state == PURPLE and data.dontGetRewardButShow then --显示奖励
		dump("check cached reward data+++")
		local data = self.data
		GlobalData:call("checkAndRequestRewardData", data.reward)
		local rwdData = GlobalData:call("getCachedRewardData", data.reward)
		if nil == rwdData then
			dump("no cached reward data+++")
			self.isRequesting = true
			return
		end
		-- dump(rwdData, "rwdData+++")
		self:showRwdGetView()
	-- elseif data.state == OPEN then              			
		-- LuaController:flyHint("", "", getLang("9200241")) 	
	elseif data.state == PURPLE then 
		-- 是否不可领奖
		if data.canReward and data.canReward == "0" and data.cantRewardTips then
			CCCommonUtilsForLua:call("flyHint", "", "", data.cantRewardTips)
		elseif data.getRewardFunc then 
			data.getRewardFunc() --领奖
			data.state = OPEN
			self.m_boxParNode:removeAllChildren()
			self.m_boxParNode2:removeAllChildren()
			self.m_boxClose:setVisible(false)
			self.m_boxOpen:setVisible(true)
		end
	end
end

function CommonProgressNode:findConnerItemInfo( cornerItemId )
	if not cornerItemId then
		return
	end
	local to_s = tostring(cornerItemId)

	local rwdData = self:getDataTable()
	if table.isNilOrEmpty(rwdData) then
		self.m_callFromRefresh = true
		return
	end

	local to_s = tostring(cornerItemId)
	local tv = table.find(rwdData,function ( cur )
		return cur.value and cur.value.id == to_s
	end)

	return tv
end

function CommonProgressNode:getDataTable(  )
	local rwdData = self.m_rwdData
	if not rwdData and self.data then
		rwdData = GlobalData:call("getCachedRewardData", self.data.reward)
		rwdData = arrayToLuaTable(rwdData)
		if not table.isNilOrEmpty(rwdData) then
			self.m_rwdData = rwdData
		else
			self.m_needRequstReward = true
		end
	end
	return rwdData
end

function CommonProgressNode:tryReqReward(  )
	if self.m_needRequstReward then
		self.m_needRequstReward = nil
		GlobalData:call("checkAndRequestRewardData", self.data.reward)
	end
end

function CommonProgressNode:showRwdGetView(  )
	MyPrint("CommonProgressNode:showRwdGetView+++")
	local rwdData = self:getDataTable()
	if not rwdData then
		return
	end

	local view = Drequire("commonView.RewardListShowView"):create({rewardId = self.data.reward, reward = rwdData, btnName = getLang("101274"), titleName = getLang("102139")})
	if not view then 
		return 
	end
	if self.data.hideRate == true then
		view:setRateBtnStatus(false)
	end
	PopupViewController:call("addPopupView", view)
end

return CommonProgressView

