SelectAccountView = class("SelectAccountView", function()
        return PopupBaseView:create()
    end
)
SelectAccountView.__index = SelectAccountView

local view = nil;

------------------------------------------ HeroEffectCell Start --------------------------------------------
local SelectAccountCell = class("SelectAccountCell", function()
    return CCTableViewCell:new()
end)

function SelectAccountCell:create(name,level, gameId)
    local ret = SelectAccountCell.new()
    if ret:init(name,level,gameId) == false then
    	return nil
    end
    return ret
end
local ServerListCellSize = CCSize(640, 100)
function SelectAccountCell:init(name,level,gameid)
	--初始化界面
    local  proxy = cc.CCBProxy:create()
    local ccbiURL = ""
    ccbiURL = "ccbi/Lua_AccountCell.ccbi"
    self.m_bIsPad = m_bIsPad
    local nodeccb = CCBReaderLoad(ccbiURL,proxy, self)
    if nodeccb == nil then
    -- print("SelectAccountCell loadccb error")
    return false
    end
    self:setContentSize(ServerListCellSize)
    self:addChild(nodeccb)

    if name == "" then
        name = "新建帐号"
    end
    self.m_name:setString(name);
    self.m_levelText:setString(level);

    self.gameid = gameid;


 	return true
end



function SelectAccountCell:onBtnClick()

MyPrint("zym SelectAccountCell:onBtnClick")
local function confirmFunc()
    LogController:call("beginConnect", self.gameid)
    --view:call("closeSelf")
PopupViewController:call("removeAllPopupView")
end
local dialog = YesNoDialog:show("确定选择这个帐号进入吗", confirmFunc)
dialog:call("showCancelButton");
end

------------------------------------------ HeroEffectCell End --------------------------------------------

------------------------------------------ HeroEffectView Start --------------------------------------------

function SelectAccountView:create(param )
	view = SelectAccountView.new()
	if view:initView(param) == false then
		return nil
	end
  	return view
end

function SelectAccountView:initView(param)
	if self:init(true, 0) == false then
		MyPrint("SelectAccountView init error")
    	return false
	end
    MyPrint("zym SelectAccountView:initView")

	self:setHDPanelFlag(true)
    callItSelfCallFunc(LuaController, "doResourceByCommonIndex", 1, true)
	local m_bIsPad = CCCommonUtilsForLua:isIosAndroidPad()
	local  proxy = cc.CCBProxy:create()
	local ccbiURL = ""
	ccbiURL = "ccbi/Lua_SelectAccount.ccbi"
  	self.m_bIsPad = m_bIsPad
  	local nodeccb = CCBReaderLoad(ccbiURL,proxy, self)
	if nodeccb == nil then
		MyPrint("SelectAccount loadccb error")
		return false
	end

	if m_bIsPad then
		nodeccb:setScale(2.0)
	end
	self:setContentSize(cc.Director:getInstance():getIFWinSize())
  	self:addChild(nodeccb)

  	local scrollView = cc.ScrollView:create()
    if scrollView ~= nil then
        scrollView:setViewSize(self.m_infoList:getContentSize())
        scrollView:setPosition(cc.p(0,0))
        scrollView:setScale(1.0)
        scrollView:ignoreAnchorPointForPosition(true)
        scrollView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)

		local cH = self.m_infoList:getContentSize().height
        local height = 0
        local mainNode = cc.Node:create();


        for i=0,param.count-1,1 do


            local cell = SelectAccountCell:create(param["name"..i],param["level"..i], param["gameid"..i] )
            mainNode:addChild(cell)
            height = height + 80
            cell:setPosition(cc.p(0, 0 - height))

        end
 
        scrollView:addChild(mainNode);
        mainNode:setPosition(cc.p(0, height))
        scrollView:setContentSize(CCSize(620,height))
        scrollView:setContentOffset(CCPoint(0, cH - height))
        self.m_infoList:addChild(scrollView);
    end
    --self.m_titleTxt:setString(getLang("169636"))
 
	self.ccbNode = nodeccb
	local function onNodeEvent(event)
		if event == "enter" then
			self:onEnter()
		elseif event == "exit" then
			self:onExit()
		end
	end
  	self.ccbNode:registerScriptHandler(onNodeEvent)

  	function onTouch(eventType, x, y)  
        if eventType == "began" then  
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)  
        else  
            return self:onTouchEnded(x, y)  
        end
    end
	local touchif = tolua.cast(self,"cc.CCIFTouchNode")
    if touchif ~= nil then
        local dic1 = CCDictionary:create()
        dic1:setObject(CCBool:create(true),"1")
        touchif:comFunc("setTouchEnabled", dic1)

        MyPrint("SelectAccountView:registerScriptTouchHandler")
        touchif:registerScriptTouchHandler(onTouch)
    end
    self.m_name:setString("角色名");
    self.m_levelText:setString("等级");
    self.m_title:setString("选择帐号");
    return true
end

function SelectAccountView:onEnter()
MyPrint("zym SelectAccountView:onEnter touchInside m_touchNode")
end

function SelectAccountView:onExit()
MyPrint("zym SelectAccountView:onExit touchInside m_touchNode")
end


function SelectAccountView:onTipBtnClick()

FaqHelper:call("showLoading",  "selectaccount");
end

function SelectAccountView:onTouchBegan(x, y)

MyPrint("zym SelectAccountView:onTouchBegan touchInside m_touchNode")
	return true
end

function SelectAccountView:onTouchMoved(x, y)
MyPrint("zym SelectAccountView:onTouchMoved touchInside m_touchNode")
end

function SelectAccountView:onTouchEnded(x, y)
MyPrint("zym SelectAccountView:onTouchEnded touchInside m_touchNode")
	--[[ if touchInside(self.m_touchNode, x, y) == false then
		MyPrint("SelectAccountView:onTouchEnded touchInside m_touchNode")
		self:call("closeSelf")
	end
    --]]
end

--return SelectAccountView







