--服务器排行TableViewCell
 local RankActCountryRankTblCell = class("RankActCountryRankTblCell",
	function() 
		return cc.Layer:create()
	end
)

function RankActCountryRankTblCell:create(idx)
	local view = RankActCountryRankTblCell.new()
	Drequire("game.CommonPopup.RankActComponent.RankActCountryRankTblCell_ui"):create(view, 0)
	return view
end

function RankActCountryRankTblCell:refreshCell(info, idx)
	self.ui.m_moreButton:setVisible(false)
	self.ui.m_moreButton:setEnabled(false)	
	self.m_info = info
	self.ui.m_rankNode:setVisible(false)
	self.ui.m_moreNode:setVisible(false)
	if self.m_info.dataType == 0 then
		self.ui.m_rankNode:setVisible(true)
		if not self.m_info.showSearch then
			self.ui.m_rankLabel:setPositionY(0)
			self.ui.m_searchBtn:setVisible(false)
		end

		self.ui.m_rankLabel:setString(info.rank)
		self.ui.m_numLabel:setString(CC_CMDITOAL(info.val))

		local str = info.name
		self.ui.m_pNameLabel:setString(str)
		self.ui.m_kingName:setString(info.king)

		local index =tonumber(info.uid)%6 + 1
		local picFrame = "server_"..index..".png"
		local sf = CCLoadSprite:call("getSF", picFrame)
		if sf then
			self.ui.m_cityPic:setSpriteFrame(sf)
		end
		local banner = info.banner
		-- dump(banner,"hxq banner is ")
		--大陆地区，看到台湾的，都成了大陆的国旗
		if banner == "TW" and CCCommonUtilsForLua:call("checkTaiWanFlag") then
			banner = "CN"
		elseif banner == "HK" then
			banner = CCCommonUtilsForLua:call("changeHKToChinaFlag",banner)
		end
		banner = CCCommonUtilsForLua:call("changeChinaFlag",banner)
		banner = banner..".png"
		local sf = CCLoadSprite:call("getSF", banner)
		if sf then
			local spr = CCFlagWaveSprite:call("create",sf)
			if spr then
				local polo = CCLoadSprite:createSprite("flag_banner.png")
				-- polo:setScale(3)
				polo:setPosition(ccp(-17,15))
				self.ui.m_bannerNode:addChild(polo)
				tolua.cast(spr, "cc.Sprite")
				spr:setScale(0.35)
				spr:setPositionY(25)
				self.ui.m_bannerNode:addChild(spr)
			end
		end
	else
		self.ui.m_moreNode:setVisible(true)
		if self.m_info.dataType == 1 then
			self.ui.m_moreTxt:setString(getLang("221126"))
		else -- if self.m_info.dataType == 2 then
			self.ui.m_moreTxt:setString(getLang("221127"))
		end
	end

end

function RankActCountryRankTblCell:onClickSearchBtn(pSender, event)
	if self.m_info.showSearch and self.m_info.searchCallback then
		self.m_info.searchCallback(tonumber(self.m_info.rank))
	end
end

function RankActCountryRankTblCell:onClickPicBtn(pSender, event)

end

function RankActCountryRankTblCell:onRewardButtonClick(pSender, event)
	if self.m_info.callback and self.m_info.rank then
		self.m_info.callback(tonumber(self.m_info.rank))
	end
end

function RankActCountryRankTblCell:onMoreButtonClick(pSender, event)
	if self.m_info.getMoreRank then
		self.m_info.getMoreRank()
	end
end

return RankActCountryRankTblCell