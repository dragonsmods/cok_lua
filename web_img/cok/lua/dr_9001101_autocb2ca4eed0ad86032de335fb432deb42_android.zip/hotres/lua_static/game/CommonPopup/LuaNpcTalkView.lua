LuaNpcTalkView = class("LuaNpcTalkView", function(  )
	return PopupBaseView:create()
end)

-- npctalkview用到的类型 与其它功能无关
LuaNpcTalkType = 
{
    Default = 0, -- 小公主
	Worker = 1,
	Citizen = 2,
    Head = 3,
    GuideWoman = 4, -- 阿加莎
}

function LuaNpcTalkView:ctor( dialogs, npctype )
    MyPrint("LuaNpcTalkView:ctor")
	self.m_dialogs = dialogs
    MyPrint(#self.m_dialogs)
	self.m_npctype = npctype or LuaNpcTalkType.Default
    self.btnCallBack = nil
    self.closeViewCallBack = nil
end

function LuaNpcTalkView:setButtonCallBack( callback )
    self.btnCallBack = callback
end

function LuaNpcTalkView:setButtonTitle(title)
    self.m_btn:setVisible(true)
    CCCommonUtilsForLua:call("setButtonTitle", self.m_btn, title)
end

function LuaNpcTalkView:setCloseCallBack(callback )
    self.closeViewCallBack = callback
end

function LuaNpcTalkView.create( dialogs, npctype )
	local ret = LuaNpcTalkView.new(dialogs, npctype)
	if ret:initView() == false then
		return nil
	end
	return ret
end

function LuaNpcTalkView:initView(  )
    MyPrint("LuaNpcTalkView:init")
    MyPrint(type(self.m_dialogs))
	if type(self.m_dialogs) ~= "table" then
		return false
	end
    MyPrint(#self.m_dialogs)
	if #self.m_dialogs == 0 then
		return false
	end
	if self:init(true, 0) == false then
		MyPrint("LuaNpcTalkView init error")
    	return false	
	end
	self:setHDPanelFlag(true)
	local winsize = cc.Director:getInstance():getIFWinSize()
	self:setContentSize(winsize)
	local proxy = cc.CCBProxy:create()
    local ccbiUrl = "ccbi/Lua_NpcTalkView.ccbi"
	local node = CCBReaderLoad(ccbiUrl, proxy, self)
    if nil == node then
        return false
    end
    if CCCommonUtilsForLua:call("isIosAndroidPad") == true then
    	self.m_mainNode:setScale(2.4)
    end

    self:addChild(node)

    self.m_btn:setVisible(false)

    self.m_iconNode:setPositionX(self.m_iconNode:getPositionX() - 300)
    self.m_txtNode:setPositionX(self.m_txtNode:getPositionX() + 300)
    self.m_leftArr:setVisible(true)
    self.m_upArr:setVisible(false)

    if self.m_npctype == LuaNpcTalkType.Worker then
        self.m_iconNode:removeAllChildren(true)
    	local spr = CCLoadSprite:createSprite("tiejiang_bust_icon.png")
    	spr:setAnchorPoint(cc.p(0, 0))
    	spr:setPositionX(0)
    	spr:setPositionY(34)
    	self.m_iconNode:addChild(spr)
        self.m_txtNode:setPositionY(self.m_txtNode:getPositionY() + 10)
    elseif self.m_npctype == LuaNpcTalkType.Citizen then
        self.m_iconNode:removeAllChildren(true)
        local spr = CCLoadSprite:createSprite("pingmin_bust_icon.png")
        spr:setAnchorPoint(cc.p(0, 0))
        spr:setPositionX(0)
        spr:setPositionY(34)
        self.m_iconNode:addChild(spr)
    elseif self.m_npctype == LuaNpcTalkType.GuideWoman then
        CCLoadSprite:call("doResourceByGeneralIndex", 100, true)
        self.m_iconNode:removeAllChildren(true)
        local sprName = SpecialDynamicResController:call("getInstance"):call("getSpecialImage", "guide_woman")..".png"
        local spr = CCLoadSprite:createSprite(sprName)
        spr:setAnchorPoint(cc.p(0, 0))
        spr:setPositionX(0)
        spr:setPositionY(-30)
        self.m_iconNode:addChild(spr)
    end
	
	local function onNodeEvent( event )
		if event == "enter" then
			self:onEnter()
	    elseif event == "exit" then
			self:onExit()
	    end
	end
	self:registerScriptHandler(onNodeEvent)

	self.touchLayer = cc.Layer:create()
	node:addChild(self.touchLayer, -1)

	local function touchHandle( eventType, x, y )
		if eventType == "began" then
			return self:onTouchBegan()
		elseif eventType == "moved" then
		else
			self:onTouchEnded()
		end
	end
	self.touchLayer:registerScriptTouchHandler(touchHandle)
	self.touchLayer:setTouchEnabled(true)
	self.touchLayer:setSwallowsTouches(true)

    self.animFinish = true
	self.m_bgSize = self.m_bg:getContentSize()
	self.idx = 1
	self:refreshWord()
	return true
end

function LuaNpcTalkView:onCloseClick()
    self:retain()
    self:call("closeSelf")
    if nil ~= self.closeViewCallBack then
        self.closeViewCallBack()
    end
    self:release()
end

function LuaNpcTalkView:refreshWord()
    if self.idx > #self.m_dialogs then
        self:onCloseClick()
        return
    end
    self.m_bg:setContentSize(self.m_bgSize)
    self.m_contentText:setPositionY(-10)
    self.m_contentText:setAnchorPoint(cc.p(0.5, 0.5))
    self.m_contentText:setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
    self.m_contentText:setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    self.m_contentText:setString(self.m_dialogs[self.idx])
    local exHt = self.m_contentText:getContentSize().height * self.m_contentText:getScaleY() - 100
    if CCCommonUtilsForLua:call("isIosAndroidPad") == true then
        exHt = exHt * 2
    end
    if exHt > 0 then
        self.m_bg:setContentSize(cc.size(self.m_bg:getContentSize().width, self.m_bg:getContentSize().height + exHt))
        self.m_contentText:setAnchorPoint(cc.p(0.5, 1))
        self.m_contentText:setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_TOP)
        self.m_contentText:setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
        self.m_contentText:setPositionY(40)
        self.m_nextNode:setPositionY(self.m_nextNode:getPositionY() - exHt)
    end
    self.idx = self.idx + 1
end

function LuaNpcTalkView:onEnter() 
    local moveby1 = cc.MoveBy:create(0.2, cc.p(300, 0))
    local moveby2 = cc.MoveBy:create(0.2, cc.p(-300, 0))
    self.m_iconNode:runAction(moveby1)
    self.m_txtNode:runAction(moveby2)
end

function LuaNpcTalkView:onExit()
    
end

function LuaNpcTalkView:onTouchBegan() 
    return true
end

function LuaNpcTalkView:onTouchEnded()
    self:wordAnim()
end

function LuaNpcTalkView:wordAnim()
    if (self.animFinish == true) then
        self.animFinish = false
        if (self.idx > #self.m_dialogs) then
            self:refreshWord()
        else 
        	local mb1 = cc.MoveBy:create(0.2, cc.p(500, 0))
        	local function viewRefreshWord()
        		self:refreshWord()
        	end
        	local callback =  cc.CallFunc:create(viewRefreshWord)
        	local delay = cc.DelayTime:create(0.2)
        	local mb2 = cc.MoveBy:create(0.2, cc.p(-500, 0))
        	self.m_txtNode:runAction(cc.Sequence:create(mb1, callback, delay, mb2))

        	local delay1 = cc.DelayTime:create(0.6)
        	local callback1 = cc.CallFunc:create(self.animCallBack)
        	self:runAction(cc.Sequence:create(delay1, callback1))
        end
    end
end

function LuaNpcTalkView:animCallBack()
    self.animFinish = true
end

function LuaNpcTalkView:onClickBtn(  )
    MyPrint("LuaNpcTalkView:onClickBtn")
    self:retain()
    MyPrint("closeSelf")
    self:call("closeSelf")
    MyPrint("self.btnCallBack", self.btnCallBack)
    if nil ~= self.btnCallBack then
        self.btnCallBack()
    end
    self:release()
end
