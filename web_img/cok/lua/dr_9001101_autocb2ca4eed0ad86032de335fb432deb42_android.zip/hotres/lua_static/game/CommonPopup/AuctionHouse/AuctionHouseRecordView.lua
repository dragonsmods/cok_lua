
local AuctionHouseRecordView = class("AuctionHouseRecordView", 
    function()
    return PopupBaseView:create()
    end
    )
AuctionHouseRecordView.__index =  AuctionHouseRecordView

function AuctionHouseRecordView:create(recordType, itemType)
 local view = AuctionHouseRecordView.new()
    Drequire("game.CommonPopup.AuctionHouse.AuctionHouseRecordView_ui"):create(view, 0)
    if view:initView(recordType, itemType) then
        return view
    end
    return false
end

function AuctionHouseRecordView:initView(recordType, itemType)
    dump(recordType,"AuctionHouseRecordView:initView+++")
    self.recordType = recordType
    self.itemType = itemType
    self.ui.m_pLabelTime:setString(getLang("9440898"))
    self.ui.m_pLabelPrice:setString(getLang("9440899"))

    if self.recordType == Auction_House_Record_Personal then
        self.ui.m_pLabelTitle:setString(getLang("9440885")) --个人交易纪录
    else
        self.ui.m_pLabelTitle:setString(getLang("9440884")) --交易纪录
    end

    self.touchLayer = cc.Layer:create()
    self:addChild(self.touchLayer)

    local function touchHandle( eventType, x, y )
        print("touchHandle", eventType, x, y)
        if eventType == "began" then
            return self:onTouchBegan(x, y)
        elseif eventType == "moved" then
        
        else
            self:onTouchEnded(x, y)
        end
    end
    self.touchLayer:registerScriptTouchHandler(touchHandle)
    self.touchLayer:setTouchEnabled(true)
    self.touchLayer:setSwallowsTouches(false)

    return true
end

function AuctionHouseRecordView:onEnter()
  registerScriptObserver(self, self.onGetAuctionRecordDataBack, AuctionGetRecordDataBack)
  AuctionHouseController:pullAuctionRecordData(self.recordType)
end

function AuctionHouseRecordView:onExit()
    unregisterScriptObserver(self, AuctionGetRecordDataBack)
end

function AuctionHouseRecordView:onGetAuctionRecordDataBack( )
    local data = AuctionHouseController:getAuctionRecordData()
    local showData = {}
    if self.itemType then
        for i, v in pairs(data) do
            if v.currType and v.currType == self.itemType then
                table.insert(showData, v)
            end
        end
    else
        showData = data
    end
    table.sort( showData,  function(a, b)
                         return tonumber(a.time) > tonumber(b.time)
                       end)
    self.ui:setTableViewDataSource("m_pTableView", showData)
end

function AuctionHouseRecordView:onTouchBegan(x, y)
    return true
end

function AuctionHouseRecordView:onTouchEnded(x, y)
    if (not isTouchInside(self.ui.m_bg, x, y)) then
        PopupViewController:call("removePopupView", self) 
    end
end

return AuctionHouseRecordView



