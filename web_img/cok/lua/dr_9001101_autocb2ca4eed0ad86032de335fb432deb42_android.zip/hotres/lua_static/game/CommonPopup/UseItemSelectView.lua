UseItemSelectView = class("UseItemSelectView", function()
        return PopupBaseView:create()
    end
)
UseItemSelectView.__index = UseItemSelectView
------------------------------------------ UseItemSelectView Start --------------------------------------------
local sliderMin = 1
function UseItemSelectView:create(params)
    local ret = UseItemSelectView.new()
    Drequire("game.CommonPopup.UseItemSelectView_ui"):create(ret, 1)
    if ret:initView(params) == false then
        return nil
    end
    return ret
end

function UseItemSelectView:initView(params)
	self.m_itemId = params.itemId
	self.m_maxNum = params.maxNum
	if params.messagePosted then
		self.m_messagePosted = params.messagePosted
	end
	if params.useTitle then
		self.m_useTitle = params.useTitle
	end
	if params.useButtonName then
		self.m_useButtonName = params.useButtonName
	end
	if params.showChange then
		self.m_showChange = params.showChange
	end
	if params.ackQuestionTip then 
		self.ackQuestionTip = params.ackQuestionTip --使用指定的确认提示信息
	end
	self.m_curNum = 1
	sliderMin = 1
	if self.m_maxNum <= 0 then
		self.m_maxNum = 0
		self.m_curNum = 0
		sliderMin = 0
		self.ui.m_useBtn:setEnabled(false)
	end

    local function touchHandle( eventType, x, y )
        if eventType == "began" then
            return self:onTouchBegan(x, y)
        elseif eventType == "moved" then
        else
            self:onTouchEnded(x, y)
        end
    end
    self:registerScriptTouchHandler(touchHandle)
    self:setTouchEnabled(true)

	self:initEdit()
    return true
end

function UseItemSelectView:initEdit()
	--文本框
	local img = CCLoadSprite:call("createScale9Sprite", "frame_text2.png")  
	img:setAnchorPoint(0.5, 0.5)
	self.m_editBox = cc.EditBox:create(self.ui.m_editNode:getContentSize(), img)  
	self.m_editBox:setPosition(self.ui.m_editNode:getContentSize().width / 2,self.ui.m_editNode:getContentSize().height / 2)
	self.m_editBox:setAnchorPoint(cc.p(0.5,0.5))
	self.m_editBox:setFontSize(22)
	self.m_editBox:setFontColor(cc.c3b(255,255,255))
	self.m_editBox:setReturnType(cc.KEYBOARD_RETURNTYPE_DONE ) 
	self.m_editBox:setInputMode(cc.EDITBOX_INPUT_MODE_NUMERIC) 
	self.m_editBox:setPlaceHolder("1")
	if self.m_maxNum <= 0 then
		self.m_editBox:setPlaceHolder("0")
	end
	self.m_editLastTime = "0"--控制数字输出
	local function editCB (strEventName,pSender)
		if tostring(pSender) == "began" then
		elseif tostring(pSender) == "ended" then
		elseif tostring(pSender) == "return" then
			if self.m_editBox:getText() ~= nil then
				local num = tonumber(self.m_editBox:getText())
				num = math.max(math.min(num, self.m_maxNum), sliderMin)
				self.m_curNum = num
				self.m_controlSlider:setValue(self.m_curNum)
				self:changeTitle(self.m_curNum)
			end
		elseif tostring(pSender) == "changed" then
			if string.len(self.m_editBox:getText()) > 0 and tonumber(self.m_editBox:getText()) == nil then
				self.m_editBox:setText(self.m_editLastTime)
			end
			self.m_editLastTime = self.m_editBox:getText()
			if tonumber(self.m_editBox:getText()) ~= nil then
				local num = tonumber(self.m_editBox:getText())
				num = math.max(math.min(num, self.m_maxNum), sliderMin)
				self.m_curNum = num
				self.m_controlSlider:setValue(self.m_curNum)
				self:changeTitle(self.m_curNum)
			end
		end
	end
	self.m_editBox:registerScriptEditBoxHandler(editCB) --输入框的事件，主要有光标移进去，光标移出来，以及输入内容改变等
	self.ui.m_editNode:addChild(self.m_editBox)
	--滑动条
	local thunmImg = CCLoadSprite:createSprite("huadongtiao1.png")
	local progImg = CCLoadSprite:createSprite( "huadongtiao2.png") 
	local bgImg =  CCLoadSprite:createSprite( "huadongtiao3.png") 
	bgImg:setContentSize(self.ui.m_barNode:getContentSize())
	bgImg:setVisible(false)
	self.m_controlSlider = cc.ControlSlider:create(bgImg,progImg,thunmImg)
	self.m_controlSlider:setAnchorPoint(CCPoint(0.5,0.5))
	self.m_controlSlider:setPosition(CCPoint(self.ui.m_barNode:getContentSize().width / 2,self.ui.m_barNode:getContentSize().height / 2))
	self.m_controlSlider:setEnabled( true )
	self.m_controlSlider:setMinimumValue( 1 )
	self.m_controlSlider:setMaximumValue( tonumber(self.m_maxNum) )
	--注册
  	local function valueChanged(pSender)
	    if nil == pSender then
	        return
	    end           
	    local pControl = pSender
	    local changedInt = math.ceil(pControl:getValue())
	    self.m_editBox:setText(tostring(changedInt));
	    self.m_curNum = changedInt
		self:changeTitle(self.m_curNum)
	end
	self.m_controlSlider:addHandleOfControlEvent(valueChanged, 256) 
	self.ui.m_barNode:addChild(self.m_controlSlider)
	--title
	self.m_name = CCCommonUtilsForLua:getPropById(tostring(self.m_itemId), "name")--{}经验
	if not self.m_useTitle then
		self.ui.m_infoLabel:setString(getLang("104955",getLang(self.m_name)))
	else
		self.ui.m_infoLabel:setString(getLang(self.m_useTitle,getLang(self.m_name)))
	end
	if self.ackQuestionTip then 
		self.ui.m_infoLabel:setString(self.ackQuestionTip)
	end
	self.ui.m_numMaxText:setString("/"..tostring(self.m_maxNum))
	if not self.m_useButtonName then
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_useBtn, getLang("169631"))
	else
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_useBtn, getLang(self.m_useButtonName))
	end
end

function UseItemSelectView:cmdCallBack()

end

function UseItemSelectView:onEnter()
end

function UseItemSelectView:onExit()
end

function UseItemSelectView:onTouchBegan(x, y)
	return true
end

function UseItemSelectView:onTouchMoved(x, y)
end

function UseItemSelectView:onTouchEnded(x, y)
	if touchInside(self.ui.m_touchNode, x, y) == false then
		self.m_editBox:unregisterScriptEditBoxHandler()
		self = tolua.cast(self, "PopupBaseView")
        self:call("closeSelf")		
	end
end

function UseItemSelectView:onUseClick()
	if self.m_messagePosted then
		local dict = CCDictionary:create()
		dict:setObject( CCString:create(self.m_itemId), "id")
		dict:setObject( CCInteger:create(self.m_curNum), "num")
		CCSafeNotificationCenter:postNotification(self.m_messagePosted, dict)
	end
	self.m_editBox:unregisterScriptEditBoxHandler()
	self = tolua.cast(self, "PopupBaseView")
	self:call("closeSelf")
end

function UseItemSelectView:onSubClick()
	local sliderValue = self.m_controlSlider:getValue() - 1
	sliderValue = math.max(sliderMin,sliderValue)
	self.m_curNum = sliderValue
	self.m_controlSlider:setValue(sliderValue)
	self:changeTitle(self.m_curNum)
end

function UseItemSelectView:onAddClick()
	local sliderValue = self.m_controlSlider:getValue() + 1
	sliderValue = math.min(self.m_maxNum,sliderValue)
	self.m_curNum = sliderValue
	self.m_controlSlider:setValue(sliderValue)
	self:changeTitle(self.m_curNum)
end

function UseItemSelectView:changeTitle( num )
	if self.m_showChange and self.m_showChange == "1" then
		-- self.ui.m_infoLabel:setString(getLang(self.m_useTitle , num * self.m_singlePoint))
	end
end
return UseItemSelectView
