

local AuctionHouseRecordCell = class("AuctionHouseRecordCell", function()
    return cc.Layer:create()
end)

function AuctionHouseRecordCell:create(idx)
    -- dump("AuctionHouseRecordCell:create+++")
    local ret = AuctionHouseRecordCell.new()
    Drequire("game.CommonPopup.AuctionHouse.AuctionHouseRecordCell_ui"):create(ret)
    return ret
end
AuctionHouseRecordCell.__index = AuctionHouseRecordCell

function AuctionHouseRecordCell:refreshCell(info , idx)
    dump(info, "AuctionHouseRecordCell+++")
    self.info = info
    self.ui.m_pNodeItemIcon:removeAllChildren()
    self.ui.m_pLabelPeopleName:setString("")

    --reward, iconNode, width, nameLabel, numLabel, nameWithNum, beTouch, touchParentNode)
    local item_cp = utils.getExtendClass( 'itemComponent' ):create(nil,self.info.itemType)
    local rwdType = item_cp:getRewardType()
    local spr = LibaoCommonFunc.createRewardItemInfo(
        {type=rwdType or "7", value={id=tostring(self.info.itemId),num=tostring(self.info.itemNum)} },
         self.ui.m_pNodeItemIcon, 77, nil, nil, true, true, nil)
    local nameIndex = CCCommonUtilsForLua:getPropById(tostring(self.info.itemId), "name")
    self.ui.m_pLabelItemName:setString(getLang(nameIndex))
    self.ui.m_pLabelAucTimeYear:setString(getDateTime(self.info.time,"%Y-%m-%d"))
    self.ui.m_pLabelAucTimeHour:setString(getDateTime(self.info.time,"%H:%M:%S"))
    self.ui.m_pLabelAucMoneyNum:setString(CC_CMDITOA(self.info.price))
    self.ui.m_labelNum:setString(self.info.itemNum)
    if AuctionHouseController:getReqRecordType() == Auction_House_Record_All then 
        if self.info.name == "" then 
            self.ui.m_pLabelPeopleName:setString(getLang("9440954"))
        else    
            self.ui.m_pLabelPeopleName:setString(self.info.name)
        end
    end 

    if info.currType then
        local sf = AuctionHouseController:getCurIcon(info.currType)
        self.ui.m_buyPriceIcon:setSpriteFrame(sf)
    end
end


return AuctionHouseRecordCell



