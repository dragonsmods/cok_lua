----------------------------
-- Author: Elex
-- Date: 2019-04-11 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local RankActInfoCell_ui = class("RankActInfoCell_ui")

--#ui propertys


--#function
function RankActInfoCell_ui:create(owner, viewType, paramTable)
	local ret = RankActInfoCell_ui.new()
	CustomUtility:LoadUi("RankActInfoCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function RankActInfoCell_ui:initLang()
	LabelSmoker:setText(self.m_btnLabel, "4514023")
end

function RankActInfoCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function RankActInfoCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function RankActInfoCell_ui:onClickBtn(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtn", pSender, event)
end

return RankActInfoCell_ui

