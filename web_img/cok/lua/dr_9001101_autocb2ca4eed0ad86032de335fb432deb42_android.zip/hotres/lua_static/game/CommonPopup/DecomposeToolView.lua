local DecomposeToolView = class("DecomposeToolView", function()
    return PopupBaseView:create()
end
)
local sliderMin = 1
----------------------------------分解协议-----------------------------------------
--[[ * @p|itemId|String|道具id
     * @p|itemNum|int|道具数量
     * @r|itemObj|Object|道具使用后的道具对象
     * @r|rewardArray|array|掉落数组 
]]
local DecomposeToolCmd = class("DecomposeToolCmd",LuaCommandBase)
function DecomposeToolCmd.req(itemId,itemNum)
    local ret = DecomposeToolCmd.new()    
    ret:initWithName("smeltGoods.decmReward")
    ret:putParam("itemId",CCString:create(itemId))
    ret:putParam("itemNum",CCInteger:create(itemNum))
    ret:send()
end
function DecomposeToolCmd:handleReceive(dict)
    local tbl = self:parseMsg(dict)
    if type(tbl)=='boolean' then
        return tbl
    end
    if tbl.itemObj then
        local toolId = tbl.itemObj.itemId
        local toolInfo = ToolController:call("getToolInfoForLua",tonumber(toolId))
        if toolInfo then
            local count = tonumber(tbl.itemObj.count) or 0
            toolInfo:call("setCNT",count)
        end
        CCSafeNotificationCenter:call("postNotification", MSG_REFREASH_TOOL_DATA)
    end
	local allRewards = {}
	if tbl.rewardArray then
		for k,v in pairs(tbl.rewardArray) do
			v.value.id = v.value.itemId
			allRewards[#allRewards+1] = v
		end
		Drequire("game.CommonPopup.RewardShowAndGetView")
		local view = RewardShowAndGetView.create(allRewards, getLang("160375"))
		if view then 
			PopupViewController:call("addPopupView", view) 
			local rwdArr = luaToArray(allRewards)
			local rwdInfo = RewardController:call("retReward", rwdArr)
			CCCommonUtilsForLua:call("flyHint", "", "", rwdInfo)
			CCSafeNotificationCenter:call("postNotification", MSG_REFREASH_TOOL_DATA)		
		end
	end	    
    return true
end
----------------------------------分解协议-----------------------------------------

function DecomposeToolView:create(dict)
    local view = DecomposeToolView.new()
    Drequire("game.CommonPopup.DecomposeToolView_ui"):create(view)
    if view:initView(dict) then
        return view
    end
end

function DecomposeToolView:initView(dict)
    local params = dictToLuaTable(dict)
    local function TouchEvent(eventType,x,y)
        if eventType == "began" then  
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)  
        else
            return self:onTouchEnded(x, y)  
        end
    end
    self.ui.m_touchLayer:setTouchEnabled(true)
    self.ui.m_touchLayer:registerScriptTouchHandler(TouchEvent)
    self.ui.m_touchLayer:setSwallowsTouches(true)
    self.m_itemId = params.itemId
    local toolInfo = ToolController:call("getToolInfoForLua",tonumber(self.m_itemId))
    self.m_maxNum = toolInfo == nil and 0 or toolInfo:call("getCNT")
    self.m_curNum = 1
    self:initUI()
    return true
end

function DecomposeToolView:onTouchBegan(x,y)
    self.onTouch = false
    if isTouchInside(self.ui.m_touchLayer,x,y) then
        self.onTouch = true
    end
    return true
end

function DecomposeToolView:onTouchMoved(x,y)

end

function DecomposeToolView:onTouchEnded(x,y)
    if not self.onTouch and not isTouchInside(self.ui.m_touchLayer,x,y) then
        self:closeSelf()
    end
end

function DecomposeToolView:initUI()
    --文本框
	local img = CCLoadSprite:call("createScale9Sprite", "frame_text2.png")  
	img:setAnchorPoint(0.5, 0.5)
	self.m_editBox = cc.EditBox:create(self.ui.m_editNode:getContentSize(), img)  --输入框尺寸，背景图片
	self.m_editBox:setPosition(self.ui.m_editNode:getContentSize().width / 2,self.ui.m_editNode:getContentSize().height / 2)
	self.m_editBox:setAnchorPoint(cc.p(0.5,0.5))
	self.m_editBox:setFontSize(22)
	self.m_editBox:setFontColor(cc.c3b(255,255,255))
	self.m_editBox:setReturnType(cc.KEYBOARD_RETURNTYPE_DONE ) --输入键盘返回类型，done，send，go等
    self.m_editBox:setInputMode(cc.EDITBOX_INPUT_MODE_NUMERIC) --输入模型，如整数类型，URL，电话号码等，会检测是否符合
    self.m_editBox:setPlaceHolder('1')
	if self.m_maxNum <= 0 then
		self.m_editBox:setPlaceHolder("0")
	end
	self.m_editLastTime = "0"--控制数字输出
	local function editCB (strEventName,pSender)
		if tostring(pSender) == "began" then
			-- sender:selectedAll() --光标进入，选中全部内容
		elseif tostring(pSender) == "ended" then
			-- 当编辑框失去焦点并且键盘消失的时候被调用
		elseif tostring(pSender) == "return" then
			-- 当用户点击编辑框的键盘以外的区域，或者键盘的Return按钮被点击时所调用			
			if self.m_editBox:getText() ~= nil then
				local num = tonumber(self.m_editBox:getText())
				num = math.max(math.min(num, self.m_maxNum), sliderMin)
				self.m_curNum = num
				self.m_controlSlider:setValue(self.m_curNum)
				self:changeTitle(self.m_curNum)
			end
		elseif tostring(pSender) == "changed" then
			if string.len(self.m_editBox:getText()) > 0 and tonumber(self.m_editBox:getText()) == nil then
				self.m_editBox:setText(self.m_editLastTime)
			end
			self.m_editLastTime = self.m_editBox:getText()
			-- 输入内容改变时调用		
			if tonumber(self.m_editBox:getText()) ~= nil then
				local num = tonumber(self.m_editBox:getText())
				num = math.max(math.min(num, self.m_maxNum), sliderMin)
				self.m_curNum = num
				self.m_controlSlider:setValue(self.m_curNum)
				self:changeTitle(self.m_curNum)
			end
		end
	end
	self.m_editBox:registerScriptEditBoxHandler(editCB) --输入框的事件，主要有光标移进去，光标移出来，以及输入内容改变等
	self.ui.m_editNode:addChild(self.m_editBox)
	-- self.m_editBox:setHACenter() --输入的内容锚点为中心
	--滑动条
	local thunmImg = CCLoadSprite:createSprite("ICON_huakuai.png")
	local progImg = CCLoadSprite:createSprite( "PRO_lvse.png") 
	local m_sliderBg = CCLoadSprite:call("createScale9Sprite", "prestige_jindutiao_bg2.png")
    m_sliderBg:setContentSize(self.ui.m_barNode:getContentSize())
    m_sliderBg:setVisible(false)
    progImg:setScaleY((self.ui.m_barNode:getContentSize().height - 6) / progImg:getContentSize().height)
	self.m_controlSlider = CCSliderBar:call("createSlider",m_sliderBg,progImg,thunmImg) 
	self.m_controlSlider:call("setProgressScaleX", 220 / progImg:getContentSize().width)
	self.m_controlSlider:setAnchorPoint(CCPoint(0.5,0.5))
	self.m_controlSlider:setPosition(CCPoint(self.ui.m_barNode:getContentSize().width / 2,self.ui.m_barNode:getContentSize().height / 2))
	self.m_controlSlider:setEnabled( true )
	self.m_controlSlider:setMinimumValue( 1 )
	self.m_controlSlider:setMaximumValue( tonumber(self.m_maxNum) )

	--注册
  	local function valueChanged(pSender)
	    if nil == pSender then
	        return
	    end           
	    local pControl = pSender
	    -- print("XXXXXXX:"..pControl:getValue())
	    local changedInt = math.ceil(pControl:getValue())
		if changedInt > self.m_maxNum then
			changedInt = self.m_maxNum
		end
	    self.m_editBox:setText(tostring(changedInt));
	    self.m_curNum = changedInt
		self:changeTitle(self.m_curNum)
	end
	self.m_controlSlider:addHandleOfControlEvent(valueChanged, 256) 
	self.ui.m_barNode:addChild(self.m_controlSlider)
	self.ui.m_infoLabel:setString(getLang("160482"))
	self.ui.m_numMaxText:setString("/"..tostring(self.m_maxNum))
	CCCommonUtilsForLua:setButtonTitle(self.m_btnMax, getLang("104776"))	--104776=最大
	if not self.m_useButtonName then
		CCCommonUtilsForLua:setButtonTitle(self.m_useBtn, getLang("169631"))
	else
		CCCommonUtilsForLua:setButtonTitle(self.m_useBtn, getLang(self.m_useButtonName))
	end
end

function DecomposeToolView:onClickBtnMax(  )
	self.m_curNum = self.m_maxNum
	self.m_controlSlider:setValue(self.m_curNum)
	self:changeTitle(self.m_curNum)
end

function DecomposeToolView:onUseClick()
	DecomposeToolCmd.req(self.m_itemId,self.m_curNum)
	self.m_editBox:unregisterScriptEditBoxHandler()
	self = tolua.cast(self, "PopupBaseView")
	self:call("closeSelf")
end

function DecomposeToolView:onSubClick()
	local sliderValue = self.m_controlSlider:getValue() - 1
	sliderValue = math.max(sliderMin,sliderValue)
	self.m_curNum = sliderValue
	self.m_controlSlider:setValue(sliderValue)
	self:changeTitle(self.m_curNum)
end

function DecomposeToolView:onAddClick()
	local sliderValue = self.m_controlSlider:getValue() + 1
	sliderValue = math.min(self.m_maxNum,sliderValue)
	self.m_curNum = sliderValue
	self.m_controlSlider:setValue(sliderValue)
	self:changeTitle(self.m_curNum)
end

function DecomposeToolView:changeTitle( num )
	-- self.ui.m_infoLabel:setString(num)
end

return DecomposeToolView