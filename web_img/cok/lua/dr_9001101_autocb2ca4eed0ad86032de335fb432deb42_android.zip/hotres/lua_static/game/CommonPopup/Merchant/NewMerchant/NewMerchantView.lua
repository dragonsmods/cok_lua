Drequire("game.CommonPopup.Merchant.NewMerchant.NewMerchantCommand")

local NewMerchantView = class("NewMerchantView",
    function()
        return PopupBaseView:create()
    end
)
NewMerchantView.__index = NewMerchantView

local TOOL_MERCHANT_REFRESH_COMMAND = "hot.item.refresh"
local MSG_CITY_RESOURCES_UPDATE = "city_resources_update"
local TOOL_MERCHANT_GET_COMMAND = "hot.item.v2.get"
local MSG_BUY_CONFIRM_OK = "buy.confirm.ok"

MerchantGoodsType = 
{
    Resource = 1, -- 1、资源
    Accelerate = 2, -- 2、加速
    Increase = 3, -- 3、增益
    Other = 4, -- 4、其他
}

function NewMerchantView:create()
	local view = NewMerchantView.new()
	Drequire("game.CommonPopup.Merchant.NewMerchant.NewMerchantView_ui"):create(view, 0)
	if view:initView() == false then
		return nil
	end
  	return view
end

function NewMerchantView:initView()
	local function touchHandle( eventType, x, y )
        if eventType == "began" then
            return self:onTouchBegan(x, y)
        elseif eventType == "moved" then
        else
            self:onTouchEnded(x, y)
        end
    end
    self.superItems = nil
    self.lastGoodsItemId = nil
    self.isHasBlingItem = nil
    self:registerScriptTouchHandler(touchHandle)
    local touchNode = tolua.cast(self, "cc.CCIFTouchNode")
    touchNode:call("setTouchEnabled", true)
    touchNode:call("setSwallowsTouches" , true)

    if GuideController:call("checkSubGuide", "3140100") then
        GuideController:call("triggerSubGuide", "3140100")
    end

    self.ui.m_lblInfo1:setString(getLang("104950"))
    self.ui.m_timeTitleText:setString(getLang("102164"))
    self.ui.m_NodeBestOriginPrice:setVisible(false)

    self.m_refreshTime = GlobalData:call("shared"):getProperty("tomorrow_time")
    self.m_originListData = {}
    self.m_bestItemId = 0
    self.buyItemTbl = {}
    self.m_bestItemTbl = {}
    self.m_newListData = {}
    self.m_isRefreshClicked = true
    self.m_isBuyCB = false
    self.m_refreshNewTime = 0
    self.m_data = {}
    self.m_isActivityEnd = true
    self.m_contentOffSet = cc.p(-9999, -9999)
    self.m_isSendingMessages = true
    local cmd = NewMerchantInfoCmd.create()
    cmd:send()
    self.m_waitInterface = nil
    self.m_getLeftTimeCount = 1
    self.m_refreshCostGold = 0
    --旅行商人界面背景高度适配
    local realSize = cc.Director:getInstance():getIFWinSize()
    local scaleY_num = realSize.height / 852
    self.ui.m_pSprite8:setScaleY(scaleY_num)
    return true
end

function NewMerchantView:onEnter()
    UIComponent:call("showPopupView", 7)
    registerScriptObserver(self, self.refreshView, "NewMerchantInfo_CB")
    registerScriptObserver(self, self.refreshViewCB, "NewMerchantRefresh_CB")
    registerScriptObserver(self, self.onCellBuyCB, "NewMerchantCell_Buy_CB")
    registerScriptObserver(self, self.onRetBuyTool, "NewMerchantRefreshView_CB")
    registerScriptObserver(self, self.onCellBuyCB, "NewMerchantSmallCell_Buy_CB")
    registerScriptObserver(self, self.removeWaitInterface, "NewMerchant_Fail_CB")
    self:setRandomUpdateTimer(true)
end

function NewMerchantView:addWaitInterface()
    local touchSize = self.ui.node_waitInterface:getContentSize()
    self.m_waitInterface = GameController:call("getInstance"):call("showWaitInterface1", self.ui.node_waitInterface)
    self.m_waitInterface:setPosition(ccp(touchSize.width / 2, touchSize.height / 2))
end

function NewMerchantView:removeWaitInterface( )
    if (self.m_waitInterface ~= nil) then
        self.m_waitInterface:call("remove")
        self.m_waitInterface = nil
    end
end

function NewMerchantView:onCellBuyCB( dict )

    self.m_contentOffSet = self.ui.m_newInfoList:getContentOffset()
    self.buyItemTbl = dictToLuaTable(dict)
    if self.buyItemTbl and self.buyItemTbl.itemId and self.buyItemTbl.maxNum and self.buyItemTbl.singlePoint and self.buyItemTbl.index and self.buyItemTbl.priceType then

        local nowVersionIsV3 = false
        if self.ui.m_newInfoList:getPositionX() == 0 and self.ui.m_originList:getPositionX() == -9999 then
            nowVersionIsV3 = true
        end
        if(tonumber(self.buyItemTbl.priceType) < WorldResourceType.WorldResource_Max) then
            if (CCCommonUtilsForLua:call("isEnoughResourceByType", tonumber(self.buyItemTbl.priceType),self.buyItemTbl.singlePoint)) then
                if nowVersionIsV3 then
                    local cmd = NewMerchantV3BuyCmd.create(CC_ITOA(self.buyItemTbl.itemId), tonumber(self.buyItemTbl.maxNum), tonumber(self.buyItemTbl.singlePoint), tonumber(self.buyItemTbl.priceType), 1)  
                    cmd:send() 
                    self:addWaitInterface() 
                else
                    local cmd = NewMerchantV2BuyCmd.create(CC_ITOA(self.buyItemTbl.itemId), tonumber(self.buyItemTbl.maxNum), tonumber(self.buyItemTbl.singlePoint), tonumber(self.buyItemTbl.priceType), 1)  
                    cmd:send()  
                    self:addWaitInterface()
                end
            else
                YesNoDialog:call("gotoPayTips")
            end
        else
            local isEnoughTool = true
            local itemInfo = ToolController:call("getToolInfoByIdForLua", tonumber(self.buyItemTbl.priceType))
            if itemInfo and itemInfo:call("getCNT") < tonumber(self.buyItemTbl.singlePoint) then
                CCCommonUtilsForLua:call("flyHint", "", "", getLang("150334"))
                return
            end
            if nowVersionIsV3 then
                local cmd = NewMerchantV3BuyCmd.create(CC_ITOA(self.buyItemTbl.itemId), tonumber(self.buyItemTbl.maxNum), tonumber(self.buyItemTbl.singlePoint), tonumber(self.buyItemTbl.priceType), 1 )  
                    cmd:send()  
                self:addWaitInterface()
            else
                local cmd = NewMerchantV2BuyCmd.create(CC_ITOA(self.buyItemTbl.itemId), tonumber(self.buyItemTbl.maxNum), tonumber(self.buyItemTbl.singlePoint), tonumber(self.buyItemTbl.priceType), 1)  
                    cmd:send()
                self:addWaitInterface()
            end
        end
           
    end
end

function NewMerchantView:onRetBuyTool(dict)
    self:removeWaitInterface()
    local tbl = dictToLuaTable(dict)
    
    if self.buyItemTbl and self.buyItemTbl.itemId and self.buyItemTbl.maxNum and self.buyItemTbl.singlePoint and self.buyItemTbl.priceType then
        --flyreward
        local array = CCArray:create()
        local arrdic = CCDictionary:create()
        local value = CCDictionary:create()
        local goodsName = ""
        if tonumber(self.buyItemTbl.itemId) <= WorldResourceType.WorldResource_Max and tonumber(self.buyItemTbl.itemId) >= WorldResourceType.Wood then
            -- value:setObject(CCString:create(tostring(self.buyItemTbl.maxNum)), "value")
            -- value = tolua.cast(value, "cc.Ref")
            arrdic:setObject(CCString:create(tostring(self.buyItemTbl.maxNum)), "value")
            arrdic:setObject(CCString:create(tostring(self.buyItemTbl.itemId)), "type")
            goodsName = CCCommonUtilsForLua:call("getResourceNameByType", tonumber(self.buyItemTbl.itemId)) 
        else
            value:setObject(CCString:create(tostring(self.buyItemTbl.itemId)), "id")
            value:setObject(CCString:create(tostring(self.buyItemTbl.maxNum)), "num")
            value = tolua.cast(value, "cc.Ref")
            arrdic:setObject(value, "value")
            arrdic:setObject(CCString:create("7"), "type")
            goodsName = getLang(CCCommonUtilsForLua:getPropById(tostring(self.buyItemTbl.itemId), "name"))

            if self:isEquipment(tostring(self.buyItemTbl.itemId)) then 
                local equipArr = dict:objectForKey("equip")
                if equipArr then
                    EquipmentController:call("addEquip", equipArr)
                end
            else
                local itemInfo = ToolController:call("getToolInfoByIdForLua", tonumber(self.buyItemTbl.itemId))
                if itemInfo then
                    itemInfo:call("setCNT", itemInfo:call("getCNT") + tonumber(self.buyItemTbl.maxNum) )
                end
            end
        end

        if tonumber(self.buyItemTbl.priceType) > WorldResourceType.WorldResource_Max then
            local itemInfo = ToolController:call("getToolInfoByIdForLua", tonumber(self.buyItemTbl.priceType))
            if itemInfo then
                itemInfo:call("setCNT", math.max(0, itemInfo:call("getCNT") - tonumber(self.buyItemTbl.singlePoint)))
            end
        end
        local tipsWords = goodsName .. " x" .. CC_CMDITOA(self.buyItemTbl.maxNum)
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("104918", tipsWords))

        arrdic = tolua.cast(arrdic, "cc.Ref")
        array:addObject(arrdic)
        
        PortActController:call("flyToolReward", array, false)
    end
    
    CCSafeNotificationCenter:call("postNotification", MSG_BUY_CONFIRM_OK)
    self:refreshView(dict)
end

function NewMerchantView:refreshViewCB( dict )
    self.m_isRefreshClicked = true
    self.m_contentOffSet = self.ui.m_newInfoList:getContentOffset()
    self:refreshView(dict)
end

-- "bestItem" = {
--     "color"     = "6"
--     "goodsId"   = "200370;3"
--     "price"     = "500"
--     "priceType" = "5"
--     "price_hot" = "0"
--     "type"      = "1"
-- }
function NewMerchantView:getSuperItems()
    self.superItems = self.superItems or self.m_data.bestItems
    dump(self.superItems, "superItems+++")
end

function NewMerchantView:setRandomBestItem()
    if self.superItems and #self.superItems > 0 and self.m_data then
        local superItemsCount = #self.superItems 
        if superItemsCount == 1 then 
            self.m_data.bestItem = self.superItems[1]
            dump(self.m_data.bestItem,"bestItem1+++")
            return 
        end
        math.randomseed(tostring(os.time()):reverse():sub(1, 6))
        local randomNum = math.random(1, superItemsCount)
        local goodsItemId = self.superItems[randomNum].goodsId
        while goodsItemId == self.lastGoodsItemId do 
            randomNum = math.random(1, superItemsCount)
            goodsItemId = self.superItems[randomNum].goodsId
        end
        self.lastGoodsItemId = goodsItemId
        self.m_data.bestItem = self.superItems[randomNum]
        dump(self.m_data.bestItem,"bestItem2+++")
    end
end

function NewMerchantView:setRandomUpdateTimer( bStart )
    if self.timerId then 
        self:getScheduler():unscheduleScriptEntry(self.timerId)
        self.timerId = nil
    end
    if bStart then 
        local function updateBestItems( dt )
            dump("updateBestItem+++")
            if self.superItems and #self.superItems > 1 then
                self:setRandomBestItem()
                self:updateBestItem()
            end
        end
        self.timerId = tonumber(self:getScheduler():scheduleScriptFunc(updateBestItems, 5, false))
    end
end

function NewMerchantView:isEquipment( itemId )
   local name = CCCommonUtilsForLua:call("getPropByIdGroup", "equipment", itemId, "name")
   if name and name ~= "" then 
        dump("is equipment+++")
        return true
   end
   return false
end

function NewMerchantView:createEquipmentIcon(eqItemId, iconNode)
    dump("NewMerchantView:createEquipmentIcon+++")
    local itemData = { type = 1, itemId = eqItemId, num = 1 }
    LibaoCommonFunc.createDataItemTouchNode({
                itemData = itemData,
                iconNode = iconNode,
                iconSize = 90,
                numLabel = nil,
                beTouch = false,       
                touchParentNode = nil   
                })
end

function NewMerchantView:updateBestItem( )
    --今日超值
    if self.m_data.bestItem and self.m_data.hotItem then
        self.m_bestItemTbl = self.m_data.bestItem
        self.ui.m_picNode1:removeAllChildren()
        self.ui.m_bestItemIconNode:removeAllChildren()
        if self.m_data.bestItem.goodsId and self.m_data.bestItem.color then 
            local bestTbl = string.split(self.m_data.bestItem.goodsId,";")
            if bestTbl and #bestTbl == 2 then
                local bestItemId = bestTbl[1]
                self.m_bestItemId = bestItemId
                if tonumber(bestItemId) <= WorldResourceType.WorldResource_Max and tonumber(bestItemId) >= WorldResourceType.Wood then
                    local iconName = CCCommonUtilsForLua:call("getResourceIconByType", bestItemId)
                    local pic = CCLoadSprite:call("createSprite", iconName)
                    if (pic ~= nil) then
                        local sptName = CCCommonUtilsForLua:call("getToolBgByColor", 0) -- 0 == WHITE
                        local iconBg = CCLoadSprite:call("createSprite", sptName)
                        CCCommonUtilsForLua:call("setSpriteMaxSize", iconBg, 90, true)
                        self.ui.m_picNode1:addChild(iconBg)
                        CCCommonUtilsForLua:call("setSpriteMaxSize", pic, 75, true)
                        self.ui.m_picNode1:addChild(pic)
                    end
                    local name = CCCommonUtilsForLua:call("getResourceNameByType", bestItemId) 
                    self.ui.m_bestName:setString(name)
                else
                    local name = CCCommonUtilsForLua:getPropById(bestItemId, "name")
                    self.ui.m_bestName:setString(getLang(name))
                    self.ui.m_desName:setString(getLang(name))
                    local desc = CCCommonUtilsForLua:getPropById(bestItemId, "description")
                    self.ui.m_desLabel:setString(getLang(desc))

                    if self:isEquipment(bestItemId) then
                        self:createEquipmentIcon(bestItemId, self.ui.m_picNode1)
                        self.ui.m_desLabel:setString(LibaoCommonFunc.getEquipDescById(bestItemId))
                    else
                        local spr = CCCommonUtilsForLua:call("createGoodsIcon", tonumber(bestItemId), self.ui.m_picNode1, CCSize(90, 90))
                    end
                end
                self.ui.m_lblItemNum1:setString("x"..bestTbl[2])
            end
        end
        if self.m_data.bestItem.priceType then
            local priceTypeNum = tonumber(self.m_data.bestItem.priceType)
            if priceTypeNum <= WorldResourceType.WorldResource_Max and priceTypeNum >= WorldResourceType.Wood then
                local priceTypeIcon = CCCommonUtilsForLua:call("getResourceIconByType", priceTypeNum)
                local priceTypeSpr = CCLoadSprite:createSprite(priceTypeIcon)
                self.ui.m_bestItemIconNode:addChild(priceTypeSpr)
                CCCommonUtilsForLua:call("setSpriteMaxSize", priceTypeSpr, 40, true)
            else
                local iconStr = CCCommonUtilsForLua:call("getIcon", tostring(priceTypeNum))
                local pic = CCLoadSprite:call("createSprite", iconStr)
                if pic then
                    self.ui.m_bestItemIconNode:addChild(pic)
                    CCCommonUtilsForLua:call("setSpriteMaxSize", pic, 40, true)
                end
            end
        end
        if self.m_data.bestItem.price then
            self.ui.m_bestNowPrice:setString(CC_CMDITOA(self.m_data.bestItem.price))
        end
        if self.m_data.bestItem.price_hot and tonumber(self.m_data.bestItem.price_hot) > 0 then
            self.ui.m_NodeBestOriginPrice:setVisible(true)
            self.ui.m_bestNowPrice:setPositionY(52)
            self.ui.m_bestOriginPrice:setString(CC_CMDITOA(self.m_data.bestItem.price_hot))
        else
            self.ui.m_bestNowPrice:setPositionY(28)
            self.ui.m_NodeBestOriginPrice:setVisible(false)
        end
    end
end

function NewMerchantView:refreshView( dict )
    self.m_isSendingMessages = false
    self.m_data = dictToLuaTable(dict)
    -- dump(self.m_data , "vjiowjioefjwaiojfe")
    if self.m_data then
        --刷新时间
        if CCCommonUtilsForLua:isFunOpenByKey("hotstore") and self.m_data.endTime then
            self.m_refreshNewTime = (self.m_data.endTime)
        end

        self:getSuperItems()
        self:setRandomBestItem()
        self:updateBestItem()
        
        if not self.m_isSendingMessages then
            self:makeSchedule(true)
        end
        --list
        if CCCommonUtilsForLua:isFunOpenByKey("hotstore") and not self.m_isActivityEnd then
            self:refreshNewList()
            self.ui.m_originList:setPositionX(-9999)
            self.ui.m_newInfoList:setPositionX(0)
        else
            self:refreshOriginList()
            self.ui.m_originList:setPositionX(0)
            self.ui.m_newInfoList:setPositionX(-9999)
            if self.m_originListData then
                self.ui:setTableViewDataSource("m_originList", self.m_originListData)
            end
        end
    end
end

function NewMerchantView:markBlingItems4NewList(  )
    self.isHasBlingItem = false
    local isBingFunOn = CCCommonUtilsForLua:isFunOpenByKey("merchant_bling_items")
    if not isBingFunOn or not self.m_newListData or #(self.m_newListData) < 1 then 
        return
    end
    for k, rowItem in pairs(self.m_newListData) do
        if rowItem then
            for k1, item1 in pairs(rowItem) do
                if item1 and item1.goods_flash and item1.goods_flash == "1" then
                    -- dump(item1,"bling_items++++")
                    self.isHasBlingItem = true
                    break
                end
            end
        end
    end
    -- dump(self.m_newListData, "self.m_newListData+++", 10)
end

function NewMerchantView:refreshNewList(  )
    self:refreshOriginList() 
    if self.m_originListData then
        self.m_newListData = {}
        local newResourceTbl = {}
        local newAccelerateTbl = {}
        local newIncreaseTbl = {}
        local newOtherTbl = {}
        for k,v in pairs(self.m_originListData) do
            v.index = k - 1
            if v.kind then
                if tonumber(v.kind) == MerchantGoodsType.Resource then
                    table.insert(newResourceTbl , v)
                elseif tonumber(v.kind) == MerchantGoodsType.Accelerate then
                    table.insert(newAccelerateTbl , v)
                elseif tonumber(v.kind) == MerchantGoodsType.Increase then
                    table.insert(newIncreaseTbl , v)
                elseif tonumber(v.kind) == MerchantGoodsType.Other then
                    table.insert(newOtherTbl , v)
                else
                    table.insert(newOtherTbl , v)
                end
            end
        end
        if newResourceTbl and newAccelerateTbl and newIncreaseTbl and newOtherTbl then
            table.insert(self.m_newListData, newResourceTbl)
            table.insert(self.m_newListData, newAccelerateTbl)
            table.insert(self.m_newListData, newIncreaseTbl)
            table.insert(self.m_newListData, newOtherTbl)

            if self.m_newListData then
                self:markBlingItems4NewList()
                self.ui:setTableViewDataSource("m_newInfoList", self.m_newListData)
                if self.m_contentOffSet.x ~= -9999 and self.m_contentOffSet.y ~= -9999 then
                    self.ui.m_newInfoList:setContentOffset(self.m_contentOffSet)
                end
            end
        end
    end
end

function NewMerchantView:refreshOriginList(  )
    --列表
    if self.m_originListData and self.m_data.remainGold and self.m_data.remainGold and self.m_data.remainCrystal then -- 购买刷新
        if self.m_data.hotItem.color and self.m_data.hotItem.itemId and self.m_data.hotItem.itemNum and self.m_data.hotItem.num and self.m_data.hotItem.price and self.m_data.hotItem.priceType and self.m_data.hotItem.price_hot and self.m_data.hotItem.type then

            if self.buyItemTbl and self.buyItemTbl.index and self.m_originListData[self.buyItemTbl.index + 1] then
                self.m_originListData[self.buyItemTbl.index + 1].color = self.m_data.hotItem.color
                self.m_originListData[self.buyItemTbl.index + 1].itemId = self.m_data.hotItem.itemId
                self.m_originListData[self.buyItemTbl.index + 1].itemNum = self.m_data.hotItem.itemNum
                self.m_originListData[self.buyItemTbl.index + 1].num = self.m_data.hotItem.num
                self.m_originListData[self.buyItemTbl.index + 1].price = self.m_data.hotItem.price
                self.m_originListData[self.buyItemTbl.index + 1].priceType = self.m_data.hotItem.priceType
                self.m_originListData[self.buyItemTbl.index + 1].price_hot = self.m_data.hotItem.price_hot
                self.m_originListData[self.buyItemTbl.index + 1].type = self.m_data.hotItem.type
                self.m_originListData[self.buyItemTbl.index + 1].goods_flash = self.m_data.hotItem.goods_flash
                self.m_originListData[self.buyItemTbl.index + 1].canPlay = 1
                --bestItem
                if self.m_bestItemTbl and self.m_bestItemTbl.goodsId then
                    self.m_originListData[self.buyItemTbl.index + 1].bestItem = self.m_bestItemTbl.goodsId
                end
                if tonumber(self.m_originListData[self.buyItemTbl.index + 1].itemId) == WorldResourceType.Wood then
                    self.m_originListData[self.buyItemTbl.index + 1].orderNum = 400
                elseif tonumber(self.m_originListData[self.buyItemTbl.index + 1].itemId) == WorldResourceType.Food then
                    self.m_originListData[self.buyItemTbl.index + 1].orderNum = 401
                elseif tonumber(self.m_originListData[self.buyItemTbl.index + 1].itemId) == WorldResourceType.Iron then
                    self.m_originListData[self.buyItemTbl.index + 1].orderNum = 402
                elseif tonumber(self.m_originListData[self.buyItemTbl.index + 1].itemId) == WorldResourceType.Stone then
                    self.m_originListData[self.buyItemTbl.index + 1].orderNum = 403
                elseif tonumber(self.m_originListData[self.buyItemTbl.index + 1].itemId) < WorldResourceType.WorldResource_Max then
                    self.m_originListData[self.buyItemTbl.index + 1].orderNum = 404
                else
                    local info = ToolController:call("getInstance"):call("getToolInfoByIdForLua",tonumber(self.m_originListData[self.buyItemTbl.index + 1].itemId))
                    if info:getProperty("orderNum") then
                        self.m_originListData[self.buyItemTbl.index + 1].orderNum = tonumber(info:getProperty("orderNum"))
                    else
                        self.m_originListData[self.buyItemTbl.index + 1].orderNum = 0
                    end
                end

                for i=1,#self.m_originListData do
                    if i ~= self.buyItemTbl.index + 1 then
                        self.m_originListData[i].canPlay = 0
                    end
                end
            end
        end
        self.buyItemTbl = {}
        --排序
    elseif self.m_isRefreshClicked then -- 刷新或者首次进入
        --刷新金币
        if self.m_data.goldCost and tonumber(self.m_data.goldCost) > 0 then
            self.m_refreshCostGold = tonumber(self.m_data.goldCost)
            self.ui.node_goldCost:setVisible(true)
            self.ui.m_lblTitleRefresh:setPositionX(-35)
            self.ui.m_lblTitleRefresh:setAnchorPoint(0.5, 0.5)
            self.ui.m_lblTitleRefresh:setString(getLang("104932"))
            self.ui.m_lblRefresh:setString(CC_CMDITOA(self.m_data.goldCost))
        else
            self.ui.m_lblTitleRefresh:setString(getLang("115062"))
            self.ui.m_lblTitleRefresh:setPositionX(0)
            self.ui.m_lblTitleRefresh:setAnchorPoint(0.5, 0.5)
            self.ui.node_goldCost:setVisible(false)
        end
        self.m_originListData = self.m_data.hotItem
        
        --添加动画播放控制
        for k,v in pairs(self.m_originListData) do
            v.canPlay = 1
            v.touchRect = self.ui.m_newInfoList
        end
        self.m_isRefreshClicked = false

        --bestItem
        if self.m_bestItemTbl and self.m_bestItemTbl.goodsId then
            for k,v in pairs(self.m_originListData) do
                v.bestItem = self.m_bestItemTbl.goodsId
            end
        end
        --排序
        for k,v in pairs(self.m_originListData) do
            if tonumber(v.itemId) == WorldResourceType.Wood then
                v.orderNum = 400
            elseif tonumber(v.itemId) == WorldResourceType.Food then
                v.orderNum = 401
            elseif tonumber(v.itemId) == WorldResourceType.Iron then
                v.orderNum = 402
            elseif tonumber(v.itemId) == WorldResourceType.Stone then
                v.orderNum = 403
            elseif tonumber(v.itemId) < WorldResourceType.WorldResource_Max then
                v.orderNum = 404
            else
                local info = ToolController:call("getInstance"):call("getToolInfoByIdForLua",tonumber(v.itemId))
                if info:getProperty("orderNum") then
                    v.orderNum = tonumber(info:getProperty("orderNum"))
                else
                    v.orderNum = 0
                end
            end
        end
        function sortByOrderNum( a,b )
            return tonumber(a.orderNum) < tonumber(b.orderNum)
        end
        table.sort(self.m_originListData,sortByOrderNum)
    end
end

function NewMerchantView:onExit()
    CCSafeNotificationCenter:unregisterScriptObserver(self, "NewMerchantInfo_CB") 
    CCSafeNotificationCenter:unregisterScriptObserver(self, "NewMerchantRefresh_CB") 
    CCSafeNotificationCenter:unregisterScriptObserver(self, "NewMerchantCell_Buy_CB") 
    CCSafeNotificationCenter:unregisterScriptObserver(self, "NewMerchantRefreshView_CB") 
    CCSafeNotificationCenter:unregisterScriptObserver(self, "NewMerchantSmallCell_Buy_CB") 
    CCSafeNotificationCenter:unregisterScriptObserver(self, "NewMerchant_Fail_CB") 
    self:makeSchedule(false)
    self:setRandomUpdateTimer(false)
end

function NewMerchantView:makeSchedule( flag )
    if flag then
        if self.m_entryId then
            self:getScheduler():unscheduleScriptEntry(self.m_entryId)
            self.m_entryId = nil
        end
        if not self.m_isSendingMessages then
            self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:update(dt) end, 1, false)
            self:update(0)
        end
    else
        if self.m_entryId then
            self:getScheduler():unscheduleScriptEntry(self.m_entryId)
            self.m_entryId = nil
        end
    end
end

function NewMerchantView:update(dt)
    local now = GlobalData:call("getTimeStamp")
    local leftTime = self.m_refreshTime - now
    if leftTime > 0 then
        self.ui.m_timeLeftText:setString(CC_SECTOA(leftTime))
    elseif self.m_getLeftTimeCount > 0 then
        GlobalData:call("shared"):setProperty("tomorrow_time", self.m_refreshTime + 86400)
        self.m_refreshTime = self.m_refreshTime + 86400
        --重新请求每日数据
        self.m_getLeftTimeCount = self.m_getLeftTimeCount - 1
        self.m_isSendingMessages = true
        self:makeSchedule(false)
        local cmd = NewMerchantInfoCmd.create()
        cmd:send()
        return
    end
    local leftNewTime = self.m_refreshNewTime / 1000 - now
    if leftNewTime > 0 then
        self.m_isActivityEnd = false
        local showTimeLimit = 7*24*3600 --7天以内显示剩余时间
        if  leftNewTime <= showTimeLimit then
            self.ui.m_activityTimeNode:setVisible(true)
            self.ui.m_activityTimeLeftText:setString(getLang("176014") .. CC_SECTOA(leftNewTime))
        end
    elseif CCCommonUtilsForLua:isFunOpenByKey("hotstore") and self.m_getLeftTimeCount > 0 and not self.m_isActivityEnd then
        --重新请求每日数据
        -- self.m_getLeftTimeCount = self.m_getLeftTimeCount - 1
        -- self.m_isSendingMessages = true
        -- self:makeSchedule(false)
        -- local cmd = NewMerchantInfoCmd.create()
        -- cmd:send()
        self.m_isActivityEnd = true
        self.ui.m_activityTimeNode:setVisible(false)
    end
end

function NewMerchantView:onTouchBegan( x, y )
    if isTouchInside(self.ui.spr_best, x, y) and tonumber(self.m_bestItemId) > WorldResourceType.WorldResource_Max then
        self.ui.m_desNode:setVisible(true)
    end
    return true
end

function NewMerchantView:onTouchEnded( x, y )
    self.ui.m_desNode:setVisible(false)
end

function NewMerchantView:onTipClick(  )
    local view = TipsView:call("create", getLang("176020"), 0)
    PopupViewController:addPopupView(view)
end

function NewMerchantView:onRefreshClick(  )
    local info = GlobalData:call("getPlayerInfo")
    local gold = info:getProperty("gold")
    if tonumber(self.m_refreshCostGold) > gold then     
        YesNoDialog:call("gotoPayTips")
        return
    end
    local function doRefresh()
        if CCCommonUtilsForLua:isFunOpenByKey("hotstore") and not self.m_isActivityEnd then
            local cmd = NewMerchantV3RefreshCmd.create()
            cmd:send()
        else
            local cmd = NewMerchantRefreshCmd.create()
            cmd:send()
        end
    end
    if self.isHasBlingItem then
        YesNoDialog:call("show", getLang("176398"), cc.CallFunc:create(doRefresh)) --176398=已刷出珍贵道具，您确定要继续刷新吗？
    else
        doRefresh()
    end
end

return NewMerchantView

