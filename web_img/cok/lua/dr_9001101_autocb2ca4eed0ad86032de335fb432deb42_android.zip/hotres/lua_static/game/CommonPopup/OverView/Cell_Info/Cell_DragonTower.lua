--龙塔试炼(server)
local Cell_DragonTower = class("Cell_DragonTower",Drequire("game.CommonPopup.OverView.Cell_Info.Cell_MainFile"))
local PreviewController = require("game.CommonPopup.OverView.PreviewController")

local FUN_BUILD_DRAGONTOWER = 432000 --龙塔
function Cell_DragonTower:create(Id)
    local ret = Cell_DragonTower.new(Id)
    if ret:initBaseById(Id) then
        return ret
    end
end
function Cell_DragonTower:getCellDataTbl()
    if not self:checkIsVisible() then
        return
    end
    local _id = ''
    local _finishTime = -1
    local _state = -1
    local _label = ""
    local _name = ""
    local _icon = ""
    local _visible = ""
    local _totalTime
	local ctl = PreviewController.getInstance()
    local serverTbl = ctl.serverDataTbl or {}
    local isLock = self:checkIsUnLock(FUN_BUILD_DRAGONTOWER)
    _id = "30711033"
    local currentLayer = tonumber(serverTbl.currentLayer) or 0
    local maxLayer = tonumber(serverTbl.maxLayer) or 0
    if currentLayer >= 1 then
        _state = self.Queue_ST_WORK
        _finishTime = currentLayer
        _totalTime = maxLayer
        _label = self:getDialogByIdIndex(_id,2)
    else
        _state = self.Queue_ST_IDLE
        _finishTime = currentLayer
        _totalTime = maxLayer
        _label = self:getDialogByIdIndex(_id,1)
    end
    if not isLock then
        _state = self.Queue_ST_LOCK
        _finishTime = -1
        _label = '2000442'
    end
    _name,_icon,_visible = self:getNameIconVisibleBySubId(_id)
    local cellOne = {id = _id, name = _name,icon = _icon, state = _state,param1 = _finishTime, param2=_totalTime,label = _label, cell = self}
    if _visible == "1" then
        self.CellTbl.cellMeta={cellOne}
    end
    return self.CellTbl

end

function Cell_DragonTower:OnClickJump(_id,_state)
    if _id == "30711033" then
        if _state == self.Queue_ST_WORK or _state == self.Queue_ST_IDLE then            
            self:jumpByTypeAndTarget(1,FUN_BUILD_DRAGONTOWER)
        elseif _state == self.Queue_ST_LOCK then
            --龙塔未解锁,目前是跳过去
            self:jumpByTypeAndTarget(1,FUN_BUILD_DRAGONTOWER)
        end
    end
end

return Cell_DragonTower