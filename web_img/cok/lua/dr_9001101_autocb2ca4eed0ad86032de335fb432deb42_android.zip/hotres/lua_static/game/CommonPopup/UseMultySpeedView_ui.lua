----------------------------
-- Author: Elex
-- Date: 2018-09-06 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local UseMultySpeedView_ui = class("UseMultySpeedView_ui")

--#ui propertys


--#function
function UseMultySpeedView_ui:create(owner, viewType, paramTable)
	local ret = UseMultySpeedView_ui.new()
	CustomUtility:LoadUi("UseMultySpeedView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function UseMultySpeedView_ui:initLang()
end

function UseMultySpeedView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function UseMultySpeedView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function UseMultySpeedView_ui:onOkButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onOkButtonClick", pSender, event)
end

function UseMultySpeedView_ui:onNoButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onNoButtonClick", pSender, event)
end

function UseMultySpeedView_ui:onCheckButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onCheckButtonClick", pSender, event)
end

function UseMultySpeedView_ui:onSetButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onSetButtonClick", pSender, event)
end

function UseMultySpeedView_ui:initTableView()
	TableViewSmoker:createView(self, "m_listTableView", "game.CommonPopup.UseMultySpeedCell", 1, 10, "UseMultySpeedCell")
end

function UseMultySpeedView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return UseMultySpeedView_ui

