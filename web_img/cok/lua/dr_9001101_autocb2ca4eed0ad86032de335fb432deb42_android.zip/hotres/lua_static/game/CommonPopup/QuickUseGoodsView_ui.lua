----------------------------
-- Author: Elex
-- Date: 2020-02-24 Monday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local QuickUseGoodsView_ui = class("QuickUseGoodsView_ui")

--#ui propertys


--#function
function QuickUseGoodsView_ui:create(owner, viewType, paramTable)
	local ret = QuickUseGoodsView_ui.new()
	CustomUtility:LoadUi("QuickUseGoodsView.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function QuickUseGoodsView_ui:initLang()
	LabelSmoker:setText(self.m_titleLabel, "175776")
	ButtonSmoker:setText(self.m_btnGold, "108532")
	ButtonSmoker:setText(self.m_btnUse, "102137")
end

function QuickUseGoodsView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function QuickUseGoodsView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function QuickUseGoodsView_ui:onCloseButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onCloseButtonClick", pSender, event)
end

function QuickUseGoodsView_ui:onClickBtnCancel(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnCancel", pSender, event)
end

function QuickUseGoodsView_ui:onClickBtnUse(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBtnUse", pSender, event)
end

function QuickUseGoodsView_ui:onClickBuyBtn(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBuyBtn", pSender, event)
end

return QuickUseGoodsView_ui

