local RewardShowAndGetNewCell = class("RewardShowAndGetNewCell", function() return cc.Layer:create() end )
local posTbl = {
    [1] = {ccp(210,0)},
    [2] = {ccp(125,0),ccp(305,0)},
    [3] = {ccp(95,0),ccp(210,0),ccp(325,0)},
    [4] = {ccp(40,0),ccp(155,0),ccp(260,0),ccp(355,0)},
    [5] = {ccp(0,0),ccp(105,0),ccp(210,0),ccp(315,0),ccp(420,0)}
}
function RewardShowAndGetNewCell:create()
	local view = RewardShowAndGetNewCell.new()
	Drequire("game.CommonPopup.RewardShowAndGetNewCell_ui"):create(view, 1)
	return view
end

function RewardShowAndGetNewCell:refreshCell(info, idx)
    for i=1,5 do
        self.ui["rwdNode"..i]:setVisible(false)
        self.ui["m_nodeIcon"..i]:removeAllChildren()
        self.ui["m_labelCount"..i]:setString("")
    end
    for i=1,#info do
        self.ui["rwdNode"..i]:setVisible(true)
        self.ui["rwdNode"..i]:setPosition(posTbl[#info][i])
        local itemInfo = info[i]
        LibaoCommonFunc.createRewardItemInfo(itemInfo, self.ui["m_nodeIcon"..i], 80, nil, nil, nil, true)
        local num = itemInfo.value.rewardAdd or itemInfo.value.num or itemInfo.value.count
	    self.ui["m_labelCount"..i]:setString('x'..num)
    end
end

return RewardShowAndGetNewCell