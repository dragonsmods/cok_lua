ToolNumSelectView = class("ToolNumSelectView", function()
        return PopupBaseView:create()
    end
)
ToolNumSelectView.__index = ToolNumSelectView
------------------------------------------ ToolNumSelectView Start --------------------------------------------
local sliderMin = 1
-- Hero状态
ToolType = 
{
    HeroExp = 1, -- 英雄经验
	HeroFragment = 2, -- 英雄碎片
	PrestigeDonate = 3, -- 文明声望捐献
	EquipmentPaper = 4, -- 锻造装备时图纸数量选择
	MagicSkill = 5, -- 魔法技能 经验升级
	AllianceBossDonate = 6, -- 联盟boss 捐献碎片
	Favorability = 7, --好感度积分捐献 异国旅人
	OpenBoxByKey = 8,	-- 用钥匙打开宝箱
	Flower = 9, --鲜花榜
	MysteryBox = 10, --神秘宝箱
    DragonSkill = 11, --龙技能道具
}
function ToolNumSelectView:createByData(data)
	local tinfo = ToolController:call("getToolInfoForLua", tonumber(data.id))
	if nil == tinfo then
		return 
	end

	local view = ToolNumSelectView.new()
	if view:initView(data.id, tinfo:call("getCNT")) == false then
		return nil
	end
	return view
end

function ToolNumSelectView:create(itemId, maxNum, target, useType, useTitle, useButtonName, showChanges, messagePosted, singlePoint, dragonUuid)
	local view = ToolNumSelectView.new()
	if view:initView(itemId, maxNum, target, useType, useTitle, useButtonName, showChanges, messagePosted, singlePoint, dragonUuid) == false then
		return nil
	end
  	return view
end

function ToolNumSelectView:initView(itemId, maxNum, target, useType, useTitle, useButtonName, showChanges, messagePosted, singlePoint, dragonUuid)
	if self:init(true, 0) == false then
		-- MyPrint("ToolNumSelectView init error")
    	return false
	end
	self:setHDPanelFlag(true)
	--ccb
	local m_bIsPad = CCCommonUtilsForLua:isIosAndroidPad()
	local proxy = cc.CCBProxy:create()
	local ccbiURL = ""
	ccbiURL = "ccbi/ToolNumSelectForLua.ccbi"
  	self.m_bIsPad = m_bIsPad
  	local nodeccb = CCBReaderLoad(ccbiURL,proxy, self)
	if nodeccb == nil then
		-- MyPrint("ToolNumSelectView loadccb error")
		return false
	end
	if m_bIsPad then
		nodeccb:setScale(2.0)
	end
	self:setContentSize(cc.Director:getInstance():getIFWinSize())
  	self:addChild(nodeccb)
	self.ccbNode = nodeccb
	--data
	self.m_itemId = itemId
	self.m_maxNum = maxNum
	self.m_target = target
	self.m_useType = useType
	self.m_useTitle = useTitle
	self.m_useButtonName = useButtonName
	self.m_showChanges = showChanges
	self.m_messagePosted = messagePosted
	self.m_singlePoint = singlePoint
	self.m_curNum = 1
    self.m_dragonUuid = dragonUuid
	sliderMin = 1
	if self.m_maxNum <= 0 then
		self.m_maxNum = 0
		self.m_curNum = 0
		sliderMin = 0
		self.m_useBtn:setEnabled(false)
		self.m_btnMax:setEnabled(false)
	end
	if self.m_useType == nil then
		local _itemType = CCCommonUtilsForLua:call("getPropByIdGroup","goods",tostring(self.m_itemId),"type")
		if _itemType == "78" then
			self.m_useType = ToolType.OpenBoxByKey
		end
	end
	local goodUuid = ""
	local toolInfo = ToolController:call("getToolInfoForLua", tonumber(self.m_itemId))
	if toolInfo == nil then
		MyPrint("ToolNumSelectView getToolInfo fail with itemId "..tostring(self.m_itemId))
	else
		goodUuid = toolInfo:getProperty("uuid")
	end
	self.m_goodUuid = goodUuid
	self:initUI()
	self:refreshView()
	--event
	local function onNodeEvent(event)
		if event == "enter" then
			self:onEnter()
		elseif event == "exit" then
			self:onExit()
		end
	end
  	self.ccbNode:registerScriptHandler(onNodeEvent)
  	function onTouch(eventType, x, y)  
        if eventType == "began" then  
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)  
        else  
            return self:onTouchEnded(x, y)  
        end
    end
	local touchif = tolua.cast(self,"cc.CCIFTouchNode")
    if touchif ~= nil then
        local dic1 = CCDictionary:create()
        dic1:setObject(CCBool:create(true),"1")
        touchif:comFunc("setTouchEnabled", dic1)
        -- MyPrint("ToolNumSelectView:registerScriptTouchHandler")
        touchif:registerScriptTouchHandler(onTouch)
    end
    return true
end

function ToolNumSelectView:initUI()
	--文本框
	local img = CCLoadSprite:call("createScale9Sprite", "frame_text2.png")  
	img:setAnchorPoint(0.5, 0.5)
	self.m_editBox = cc.EditBox:create(self.m_editNode:getContentSize(), img)  --输入框尺寸，背景图片
	self.m_editBox:setPosition(self.m_editNode:getContentSize().width / 2,self.m_editNode:getContentSize().height / 2)
	self.m_editBox:setAnchorPoint(cc.p(0.5,0.5))
	self.m_editBox:setFontSize(22)
	self.m_editBox:setFontColor(cc.c3b(255,255,255))
	self.m_editBox:setReturnType(cc.KEYBOARD_RETURNTYPE_DONE ) --输入键盘返回类型，done，send，go等
	self.m_editBox:setInputMode(cc.EDITBOX_INPUT_MODE_NUMERIC) --输入模型，如整数类型，URL，电话号码等，会检测是否符合
	self.num_dp = {} -- 使用动态规划优化思想，建立一个存解表
	-- self.m_editBox:setText("0")
	self.m_editBox:setPlaceHolder('1')
	if self.m_maxNum <= 0 then
		self.m_editBox:setPlaceHolder("0")
	end
	self.m_editLastTime = "0"--控制数字输出
	local function editCB (strEventName,pSender)
		if tostring(pSender) == "began" then
			-- sender:selectedAll() --光标进入，选中全部内容
		elseif tostring(pSender) == "ended" then
			-- 当编辑框失去焦点并且键盘消失的时候被调用
		elseif tostring(pSender) == "return" then
			-- 当用户点击编辑框的键盘以外的区域，或者键盘的Return按钮被点击时所调用			
			if self.m_editBox:getText() ~= nil then
				local num = tonumber(self.m_editBox:getText())
				num = math.max(math.min(num, self.m_maxNum), sliderMin)
				self.m_curNum = num
				self.m_controlSlider:setValue(self.m_curNum)
				self:changeTitle(self.m_curNum)
			end
		elseif tostring(pSender) == "changed" then
			if string.len(self.m_editBox:getText()) > 0 and tonumber(self.m_editBox:getText()) == nil then
				self.m_editBox:setText(self.m_editLastTime)
			end
			self.m_editLastTime = self.m_editBox:getText()
			-- 输入内容改变时调用		
			if tonumber(self.m_editBox:getText()) ~= nil then
				local num = tonumber(self.m_editBox:getText())
				num = math.max(math.min(num, self.m_maxNum), sliderMin)
				self.m_curNum = num
				self.m_controlSlider:setValue(self.m_curNum)
				self:changeTitle(self.m_curNum)
			end
		end
	end
	self.m_editBox:registerScriptEditBoxHandler(editCB) --输入框的事件，主要有光标移进去，光标移出来，以及输入内容改变等
	self.m_editNode:addChild(self.m_editBox)
	-- self.m_editBox:setHACenter() --输入的内容锚点为中心
	--滑动条
	local thunmImg = CCLoadSprite:createSprite("ICON_huakuai.png")
	local progImg = CCLoadSprite:createSprite( "PRO_lvse.png") 
	local m_sliderBg = CCLoadSprite:call("createScale9Sprite", "prestige_jindutiao_bg2.png")
    m_sliderBg:setContentSize(self.m_barNode:getContentSize())
    m_sliderBg:setVisible(false)
    progImg:setScaleY((self.m_barNode:getContentSize().height - 6) / progImg:getContentSize().height)
	self.m_controlSlider = CCSliderBar:call("createSlider",m_sliderBg,progImg,thunmImg) 
	self.m_controlSlider:call("setProgressScaleX", 220 / progImg:getContentSize().width)
	self.m_controlSlider:setAnchorPoint(CCPoint(0.5,0.5))
	self.m_controlSlider:setPosition(CCPoint(self.m_barNode:getContentSize().width / 2,self.m_barNode:getContentSize().height / 2))
	self.m_controlSlider:setEnabled( true )
	self.m_controlSlider:setMinimumValue( 1 )
	self.m_controlSlider:setMaximumValue( tonumber(self.m_maxNum) )
	--注册
  	local function valueChanged(pSender)
	    if nil == pSender then
	        return
	    end           
	    local pControl = pSender
	    -- print("XXXXXXX:"..pControl:getValue())
	    local changedInt = math.ceil(pControl:getValue())
		if changedInt > self.m_maxNum then
			changedInt = self.m_maxNum
		end
	    self.m_editBox:setText(tostring(changedInt));
	    self.m_curNum = changedInt
		self:changeTitle(self.m_curNum)
	end
	self.m_controlSlider:addHandleOfControlEvent(valueChanged, 256) 
	self.m_barNode:addChild(self.m_controlSlider)

	local _itemStr = tostring(self.m_itemId)
	--title
	if not self.m_useTitle then
		local para = CCCommonUtilsForLua:getPropById(_itemStr, "para")--100
		local name = CCCommonUtilsForLua:getPropById(_itemStr, "name")--{}经验
		name = getLang(name,para)
		self.m_infoLabel:setString(getLang("104955",name))
	else
		if self.m_useType == ToolType.EquipmentPaper then
			local name = CCCommonUtilsForLua:getPropById(_itemStr, "name")
			self.m_infoLabel:setString(getLang(self.m_useTitle, getLang(name)))
		elseif self.m_useType == ToolType.MagicSkill then
			self.m_infoLabel:setString(self.m_useTitle)
		elseif self.m_useType == ToolType.AllianceBossDonate then 
			self.m_infoLabel:setString(getLang(self.m_useTitle ,tonumber(self.m_target) + 1))
		else
			if self.m_showChanges and type(self.m_showChanges) == "number" then
				self:changeTitle(self.m_curNum)
			else
				self.m_infoLabel:setString(getLang(self.m_useTitle))
			end
		end
	end
	self.m_numMaxText:setString("/"..tostring(self.m_maxNum))
	-- CCCommonUtilsForLua:setButtonTitle(self.m_btnMax, getLang("180217")) --180217=一键使用  -- 2019-10-16 hyp 之前为 getLang("104776") --104776=最大
	CCCommonUtilsForLua:setButtonTitle(self.m_btnMax, getLang("571540", CC_ITOA(self.m_maxNum))); -- 571540=一键使用×{0}
	if self.m_useType == ToolType.OpenBoxByKey then
		local _useAll = CCCommonUtilsForLua:call("getPropByIdGroup","goods",_itemStr,"useall")
		if atoi(_useAll) == 0 then
			self.m_btnMax:setVisible(false)
			self.m_useBtn:setPositionX(0)
		end

		local _para2 = CCCommonUtilsForLua:call("getPropByIdGroup","goods",_itemStr,"para2")
		local _costConfig = string.split(_para2, ";")
		self.v_costItemId = _costConfig[1]
		self.v_costPrice = atoi(_costConfig[2])
		if #_costConfig >= 2 then
			self.m_nodeCost:setVisible(true)

			local tinfo = ToolController:call("getToolInfoForLua", tonumber(_costConfig[1]))
			if tinfo then
				self.v_itemCostMax = tinfo:call("getCNT")
				self.m_numCost:setString(self.v_itemCostMax)

				if self.v_itemCostMax <= 0 then
					self.m_editBox:setPlaceHolder("0")

					self.m_useBtn:setEnabled(false)
					self.m_btnMax:setEnabled(false)
				end
			end

			local _costIconName = CCCommonUtilsForLua:call("getPropByIdGroup","goods",_costConfig[1],"icon")
			_costIconName = string.format("%s.png", _costIconName)

			local _costFrame = CCLoadSprite:call("getSF", _costIconName)
			if _costFrame then
				self.m_iconCost1:setSpriteFrame(_costFrame)
				CCCommonUtilsForLua:call('setSpriteMaxSize', self.m_iconCost1, 40)
				
				local _costIcon2 = CCLoadSprite:createSprite(_costIconName)
				CCCommonUtilsForLua:call('setSpriteMaxSize', _costIcon2, 40)
				local _btnSize = self.m_useBtn:getContentSize()
				_costIcon2:setPosition(ccp(_btnSize.width/2 - 30, _btnSize.height/2))
				self.m_useBtn:addChild(_costIcon2)
			end

			CCCommonUtilsForLua:setButtonTitle(self.m_useBtn, _costConfig[2])
			self:refreshUseGoldOpen()
			self.m_goldDesc:setString(getLang('102198'))
		end
	else
		self.m_nodeCost:setVisible(false)
		if not self.m_useButtonName then
			CCCommonUtilsForLua:setButtonTitle(self.m_useBtn, getLang("169631"))
		else
			CCCommonUtilsForLua:setButtonTitle(self.m_useBtn, getLang(self.m_useButtonName))
		end
	end

	--检查是否需要调整为最大
	local usemax = CCCommonUtilsForLua:call("getPropByIdGroup","goods",tostring(self.m_itemId),"usemax")
	usemax = tonumber(usemax) or 0
	if usemax == 1 then
		self.m_controlSlider:setValue(self.m_maxNum)
	end
end

function ToolNumSelectView:refreshUseGoldOpen( )
	-- 开宝箱需要另一个道具，但是道具不足，可以用金币补
	local useNum = self.m_curNum
	self.m_useGoldBtn:setVisible(false)
	self.useGoldNum = 0
	if not self.v_costItemId then
		return
	end
	if self._goldNum == nil then
		self._goldNum = CCCommonUtilsForLua:call("getPropByIdGroup","goods",self.v_costItemId,"gold")
		self._goldNum = tonumber(self._goldNum) or 0
	end
	local goldNum = self._goldNum
	if goldNum<=0 then
		return
	end
	-- local tinfo_cost = ToolController:call("getToolInfoForLua", tonumber(self.v_costItemId))
	-- self.v_costPrice 每一个宝箱需要多少个钥匙 self.v_itemCostMax最大的钥匙数
	if self.v_costPrice*useNum <= self.v_itemCostMax then
		return
	end
	self.m_useGoldBtn:setVisible(true)
	self.m_useGoldBtn:setPosition(self.m_useBtn:getPosition())
	local needNum = self.v_costPrice*useNum - self.v_itemCostMax
	local needGold = needNum*goldNum
	--102326=花费：
	self.m_goldCost:setString(getLang('102326')..needGold)
	self.useGoldNum = needGold
end

function ToolNumSelectView:refreshView()
	
end

function ToolNumSelectView:cmdCallBack()

end

function ToolNumSelectView:onEnter()
	local function onRefresh( ref )
        self:cmdCallBack()
    end
    local t = tolua.cast(self, "cc.Node")
    local handler = t:registerHandler(onRefresh)
    CCSafeNotificationCenter:registerScriptObserver(self, handler, "hero_info_refresh")
end

function ToolNumSelectView:onExit()
    CCSafeNotificationCenter:unregisterScriptObserver(self, "hero_info_refresh")
end

function ToolNumSelectView:onTouchBegan(x, y)
	return true
end

function ToolNumSelectView:onTouchMoved(x, y)
end

function ToolNumSelectView:onTouchEnded(x, y)
	if touchInside(self.m_touchNode, x, y) == false then
		-- MyPrint("ToolNumSelectView:onTouchEnded touchInside m_clickArea")
		self.m_editBox:unregisterScriptEditBoxHandler()
		self = tolua.cast(self, "PopupBaseView")
        self:call("closeSelf")						
	elseif touchInside(self.m_subArea, x, y) then
		self:opeSub()
	elseif touchInside(self.m_addArea, x, y) then
		self:opeAdd()
	end
end

function ToolNumSelectView:opeSub()
	-- local num = self.m_curNum - 1
	-- num = math.max(num, 1)
	-- self.m_curNum = num
	-- MyPrint("ToolNumSelectView:opeSub m_curNum is "..tostring(self.m_curNum))
	-- self.m_editBox:setString(tostring(self.m_curNum))
end

function ToolNumSelectView:opeAdd()
	-- local num = self.m_curNum + 1
	-- num = math.min(num, self.m_maxNum)
	-- self.m_curNum = num
	-- MyPrint("ToolNumSelectView:opeSub m_curNum is "..tostring(self.m_curNum))
	-- self.m_editBox:setString(tostring(self.m_curNum))
end

function ToolNumSelectView:onClickBtnMax(  )
	self.m_curNum = self.m_maxNum
	self.m_controlSlider:setValue(self.m_curNum)
	self:changeTitle(self.m_curNum)

	-- 2019-10-15 hyp 选择最大值改为直接使用最大值的资源
	self:onUseClick()
end

function ToolNumSelectView:onUseClick()
	CCSafeNotificationCenter:call("postNotification","guide_index_change", CCString:create("NumSelect_Ok"))
	if self.m_useType == ToolType.HeroExp then
		local HeroManager = require("game.hero.HeroManager")
		HeroManager.addHeroExp(tonumber(self.m_target), tostring(self.m_goodUuid), tonumber(self.m_curNum))
		-- HeroManager.addHeroExp(tonumber(self.m_heroId), toolUuid, 1)
	elseif self.m_useType == ToolType.HeroFragment then
		-- local HeroManager = require("game.hero.HeroManager")
		-- HeroManager.buyHeroFragment(tonumber(self.m_target), tostring(self.m_goodUuid))
		-- self.m_editBox:unregisterScriptEditBoxHandler()
		-- self = tolua.cast(self, "PopupBaseView")
        -- self:call("closeSelf")	
    elseif self.m_useType == ToolType.PrestigeDonate then
    	local tinfo = ToolController:call("getToolInfoByIdForLua", self.m_itemId)
    	if tinfo ~= nil then
	    	local uuid = tinfo:getProperty("uuid")
			local pobj = CCDictionary:create()
			pobj:setObject(CCInteger:create(self.m_curNum), "count")
			pobj:setObject(CCString:create(uuid), "itemUUid")
			if self.m_messagePosted and self.m_messagePosted ~= "" then
	    		CCSafeNotificationCenter:postNotification(self.m_messagePosted,pobj)
	    	end
	    end
    elseif self.m_useType == ToolType.EquipmentPaper then
    	-- local sliderValue = self.m_controlSlider:getValue()
    	local dict = CCDictionary:create()
    	dict:setObject( CCString:create(self.m_itemId), "id")
    	dict:setObject( CCInteger:create(self.m_curNum), "num")
    	-- MyPrint("ToolNumSelectView:onUseClick", self.m_messagePosted, dict.id, dict.num)
    	CCSafeNotificationCenter:postNotification(self.m_messagePosted, dict)
	elseif self.m_useType == ToolType.MagicSkill then
		local dict = CCDictionary:create()
    	dict:setObject( CCInteger:create(self.m_curNum), "magicSkillSelectedNum")
    	CCSafeNotificationCenter:postNotification(self.m_messagePosted, dict)
	elseif self.m_useType == ToolType.AllianceBossDonate then
		local dict = CCDictionary:create()
    	dict:setObject( CCInteger:create(self.m_curNum), "selectedNum")
		CCSafeNotificationCenter:postNotification(self.m_messagePosted, dict)
	elseif self.m_useType == ToolType.Favorability or self.m_useType == ToolType.Flower then
		local dict = CCDictionary:create()
    	dict:setObject(CCString:create(self.m_itemId), "itemId")
    	dict:setObject(CCInteger:create(self.m_curNum), "count")
    	CCSafeNotificationCenter:postNotification(self.m_messagePosted, dict)
	elseif self.m_useType == ToolType.OpenBoxByKey then
		local isSend = true
		local useGold = self.useGoldNum>0
		if useGold then
			-- 判断金币够不够
			local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
			if playerInfo:getProperty("gold") < self.useGoldNum then
                YesNoDialog:call('gotoPayTips')
                isSend = false
            end
		end
		if isSend then
			ToolController:call("useTool", self.m_itemId, self.m_curNum, true)
		end
	elseif self.m_useType == ToolType.MysteryBox then
		-- ToolController:call("useTool", self.m_itemId, self.m_curNum, true)
		local MysteryBoxCtl = require("game.MysteryBox.MysteryBoxController"):getInstance()
		MysteryBoxCtl:reqUseItemData(self.m_itemId, self.m_curNum)
    elseif self.m_useType == ToolType.DragonSkill then
        ToolController:call("useTool", self.m_itemId, self.m_curNum, true, nil, "", self.m_dragonUuid)
	end
	self.m_editBox:unregisterScriptEditBoxHandler()
	self = tolua.cast(self, "PopupBaseView")
	self:call("closeSelf")
end

function ToolNumSelectView:onSubClick()
	--print("ToolNumSelectView:onSubClick")
	local sliderValue = self.m_controlSlider:getValue() - 1
	sliderValue = math.max(sliderMin,sliderValue)
	self.m_curNum = sliderValue
	self.m_controlSlider:setValue(sliderValue)
	self:changeTitle(self.m_curNum)
end

function ToolNumSelectView:onAddClick()
	--print("ToolNumSelectView:onAddClick")
	local sliderValue = self.m_controlSlider:getValue() + 1
	sliderValue = math.min(self.m_maxNum,sliderValue)
	self.m_curNum = sliderValue
	self.m_controlSlider:setValue(sliderValue)
	self:changeTitle(self.m_curNum)
end

function ToolNumSelectView:changeTitle( num )
	if self.m_useType == ToolType.EquipmentPaper then 
	elseif self.m_useType == ToolType.AllianceBossDonate then 
		if self.m_showChanges then
			local totalValue = tonumber(self.m_target) + num
			self.m_infoLabel:setString(getLang(self.m_useTitle ,totalValue))
		end
	elseif self.m_useType == ToolType.Favorability or self.m_useType == ToolType.Flower then
		self.m_infoLabel:setString(getLang(self.m_useTitle , num * self.m_singlePoint, self.m_showChanges))
	else
		if self.m_useType == ToolType.OpenBoxByKey then
			CCCommonUtilsForLua:setButtonTitle(self.m_useBtn, tostring(self.v_costPrice * num))
			self:refreshUseGoldOpen()
		end
		if self.m_showChanges and type(self.m_showChanges) == "number" then
			if CCCommonUtilsForLua:isFunOpenByKey("reputation_donate_adder_open") == true then				
				local totalValue = 0
				if self.num_dp[tostring(num)] == nil then
					totalValue = self:getCivilizationDonateValue(num)
				else
					totalValue = self.num_dp[tostring(num)] --从表self.num_dp 中获取
				end

				self.m_infoLabel:setString(getLang(self.m_useTitle , totalValue, self.m_showChanges))
			else
				self.m_infoLabel:setString(getLang(self.m_useTitle , num * self.m_singlePoint, self.m_showChanges))
			end
		end
	end

	if self.v_itemCostMax then
		self.m_useBtn:setEnabled(num <= self.v_itemCostMax)
		self.m_btnMax:setEnabled(num <= self.v_itemCostMax)
	end
end

--计算声望捐献加成新功能下的声望值
function ToolNumSelectView:getCivilizationDonateValue(num)
	local totalExp = 0
	local count = 0
	local donateLimit = tonumber(CivilizationController:getDonateLimit())
	local nowDonate = tonumber(CivilizationController:getNowDonate())
	local canDonateValue = donateLimit - nowDonate
	local xmlData = CivilizationController:getReputationDanateOnXMLData() --xmlData表数据
	local donateMaxLv = CivilizationController:getPlayerDonateMaxLv() --获取最大级
	local playerNowExp = CivilizationController:showPlayerDonateExp() --玩家目前的经验值
	local levelUpNeedExp = CivilizationController:getNextLevelNeedExp() - playerNowExp --下一级需要的经验
	local playerNowAddition = CivilizationController:getPlayerNowAddition() * 0.01 --玩家目前的等级对应加成

	local rate = 1 
	--local rate = CivilizationController:getDonateBookToExp() --声望之书转化经验等级的比率,目前为1:1

	local playerNowLevel = CivilizationController:showPlayerDonateLevel() --玩家目前的等级

	local tempExp = 0  --捐献的声望值

	local effectNum = 1 --后续版本取作用号
	--effectNum = CCCommonUtilsForLua:call("getEffectValueByNum",)/100;  
	
	if playerNowLevel >= donateMaxLv then 
		totalExp = num * self.m_singlePoint * (playerNowAddition+1) * effectNum
		--totalExp = math.floor(totalExp)
		local res = math.min(totalExp,canDonateValue)
		self.num_dp[tostring(num)] = res
		return res
	else
		while count < num and totalExp < canDonateValue do

			if self.m_singlePoint < levelUpNeedExp then

				local additionExp = self.m_singlePoint * (1+playerNowAddition) * effectNum

				levelUpNeedExp = levelUpNeedExp - self.m_singlePoint * rate

				totalExp = totalExp + additionExp 
				count = count + 1
			else   --这本书导致它升级了
				totalExp = totalExp + levelUpNeedExp * (1+playerNowAddition) * effectNum  --升级前需要的提升

				if playerNowLevel < donateMaxLv then
					playerNowLevel = playerNowLevel + 1
					playerNowAddition = tonumber(xmlData[playerNowLevel+1].Addition) * 0.01


					totalExp = totalExp + (self.m_singlePoint - levelUpNeedExp)*(1+playerNowAddition) * effectNum --升级后加成变化，剩余经验base的提升
					levelUpNeedExp = tonumber(xmlData[playerNowLevel+2].exp)
				else
					local leaveExp = self.m_singlePoint - levelUpNeedExp
					totalExp = totalExp + leaveExp *(1+playerNowAddition) * effectNum
					levelUpNeedExp = tonumber(xmlData[playerNowLevel+1].exp) - leaveExp
				end
				count = count + 1
			end			
		end
		totalExp = math.floor(totalExp)
		local res = math.min(totalExp,canDonateValue)
		self.num_dp[tostring(num)] = res
		return res	
	end	
end

function ToolNumSelectView:getGuideNode( key )
	if key == "NumSelect_Ok" then
		local function callBack()
			self:onUseClick()
		end
		GuideController:call("setCallback", cc.CallFunc:create(callBack))
		return self.m_useBtn
	end
	return nil
end

return ToolNumSelectView