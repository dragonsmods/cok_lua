----------------------------
-- Author: Elex
-- Date: 2018-11-29 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CommonUseItemCell_ui = class("CommonUseItemCell_ui")

--#ui propertys


--#function
function CommonUseItemCell_ui:create(owner, viewType, paramTable)
	local ret = CommonUseItemCell_ui.new()
	CustomUtility:LoadUi("CommonUseItemCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CommonUseItemCell_ui:initLang()
end

function CommonUseItemCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CommonUseItemCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CommonUseItemCell_ui:onUseBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onUseBtnClick", pSender, event)
end

return CommonUseItemCell_ui

