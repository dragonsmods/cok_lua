local VNAuditInfoTips = class("VNAuditInfoTips")

function VNAuditInfoTips.isOpen()
    -- do return true end
    if CCCommonUtilsForLua.isVietnam and CCCommonUtilsForLua:isVietnam() then
        return true
    end
    return false
end

function VNAuditInfoTips:create(parent)
    if VNAuditInfoTips.isOpen() then
        return VNAuditInfoTips.new(parent)
    end
end

function VNAuditInfoTips:ctor(parent)
    self.parent = parent
    local onLineTime = PlayerInfoController:getUserOnlineTime()
    -- dump(onLineTime, "onLineTime is: ")
    -- 登录时长是否超过180分钟
    self.beShowLineTip = onLineTime > 10800

    CCLoadSprite:call("doResourceByCommonIndex", 7, true)
end

function VNAuditInfoTips:onSceneChanged(sceneId)
    if self.vn18PlusSpr then
        self.vn18PlusSpr:removeFromParent()
        self.vn18PlusSpr = nil
    end

    if sceneId == SCENE_ID_WORLD or sceneId == SCENE_ID_MAIN then
        local picPath = "vn_18plus.png"
        local spr = CCLoadSprite:createSprite(picPath)

        local _x, _y = self.parent:getPosition() 
        local parentSize = self.parent:getContentSize()

        self.parent:addChild(spr)
        spr:setLocalZOrder(1000)
        spr:setAnchorPoint(ccp(0.5, 1))
        self.vn18PlusSpr = spr
        if sceneId == SCENE_ID_MAIN then
            local p = ccp(_x + parentSize.width * 0.5, _y + parentSize.height - 40)
            spr:setPosition(p)
        else
            local p = ccp(_x + parentSize.width * 0.5, _y + parentSize.height - 40)
            spr:setPosition(p)
        end
    else
    end
end

function VNAuditInfoTips:update(t)
    local function doFlyHint(_tip)
        local _worldTime = GlobalData:call("shared"):call("getWorldTime") 
        _worldTime = _worldTime * 1000
        _worldTime = GlobalData:call("shared"):call("renewTime", _worldTime)
        local _time = _worldTime + 1000 * 60
        
        CCCommonUtilsForLua:call("flySystemUpdateHint", _time, true, _tip, FlyHintType.FLY_HINT_NORMAL)
    end

    local now = getTimeStamp()
    if not self.nextFlyHintAt then
        if self.beShowLineTip then
            -- 超过80分钟
            self.nextFlyHintAt = now + 20
        else
            self.nextFlyHintAt = now + 60
        end
    else
        if self.nextFlyHintAt <= now then
            if self.beShowLineTip then
                doFlyHint(getLang("549998"))
                self.nextFlyHintAt = now + 40
                self.beShowLineTip = false
            else
                doFlyHint(getLang("549999"))
                self.nextFlyHintAt = now + 20 * 60
            end
            
        end
    end
end

return VNAuditInfoTips