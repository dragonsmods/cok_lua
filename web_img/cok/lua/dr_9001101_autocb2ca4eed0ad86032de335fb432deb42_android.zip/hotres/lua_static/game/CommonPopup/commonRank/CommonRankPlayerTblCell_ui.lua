----------------------------
-- Author: Elex
-- Date: 2021-03-31 Wednesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CommonRankPlayerTblCell_ui = class("CommonRankPlayerTblCell_ui")

--#ui propertys


--#function
function CommonRankPlayerTblCell_ui:create(owner, viewType, paramTable)
	local ret = CommonRankPlayerTblCell_ui.new()
	CustomUtility:DoRes(11, true)
	CustomUtility:LoadUi("CommonRankPlayerTblCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CommonRankPlayerTblCell_ui:initLang()
	LabelSmoker:setText(self.m_tipsLabel, "221125")
end

function CommonRankPlayerTblCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CommonRankPlayerTblCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CommonRankPlayerTblCell_ui:onClickSearchBtn(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickSearchBtn", pSender, event)
end

function CommonRankPlayerTblCell_ui:onClickPicBtn(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickPicBtn", pSender, event)
end

function CommonRankPlayerTblCell_ui:onRewardButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onRewardButtonClick", pSender, event)
end

function CommonRankPlayerTblCell_ui:onMoreButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onMoreButtonClick", pSender, event)
end

return CommonRankPlayerTblCell_ui

