
local AuctionHouseCell = class("AuctionHouseCell", function()
    return cc.Layer:create()
end)

function AuctionHouseCell:create(idx)
    -- dump("AuctionHouseCell:create+++")
    local ret = AuctionHouseCell.new()
    Drequire("game.CommonPopup.AuctionHouse.AuctionHouseCell_ui"):create(ret)
    return ret
end
AuctionHouseCell.__index = AuctionHouseCell


--"AuctionHouseCell:refreshCell+++" = {
--    "add"           = "250"
--    "color"         = "4"
--    "decision"      = "20000"
--    "endTime"       = "1525336200050"
--    "itemId"        = "212587"
--    "num"           = "10"
--    "price"         = "5000"
--    "selfAuctioned" = "0"
--    "uuid"          = "872316865c22482ba7b611c629d15992"
--}

function AuctionHouseCell:refreshCell(info , idx)
    -- dump(info, "AuctionHouseCell:refreshCell+++")
    self.info = info
    self.timeCount = 0
    self.ui.m_pLabelPrice:setString(getLang("176265")) --176265=当前价格
    self.ui.m_pLabelPriceNum:setString(self.info.price)
    self.ui.m_pLabelRaisePrice:setString(getLang("9440883"))
    self.ui.m_pLabelRaisePriceNum:setString(self.info.add)
    self.ui.m_pLabelOnePrice:setString(getLang("176257")) --176257=一口价
    self.ui.m_pLabelOnePriceNum:setString(self.info.decision) 
    self.ui.m_pNodeItemIcon:removeAllChildren()

    CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnTakePrice, getLang("176264"))   --176264=竞价
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnRaisePrice, getLang("176257"))  --176257=一口价

    local isDecisionGoods = (self.info.decision ~= "9999999") --是一口价的物品
    self.ui.m_btnRaisePrice:setVisible(isDecisionGoods)
    self.ui.m_pLabelOnePrice:setVisible(isDecisionGoods)
    self.ui.m_pLabelOnePriceNum:setVisible(isDecisionGoods)
    self.ui.m_iconOnePriceGold:setVisible(isDecisionGoods)

    self.ui.m_pNodeItemIcon:removeAllChildren()
    --reward, iconNode, width, nameLabel, numLabel, nameWithNum, beTouch, touchParentNode)
    local item_cp = utils.getExtendClass( 'itemComponent' ):create(nil,self.info.itemType)
    local rwdType = item_cp:getRewardType()
    local spr = LibaoCommonFunc.createRewardItemInfo(
        {type=rwdType or "7", value={id=tostring(self.info.itemId),num=tostring(self.info.num)} },
         self.ui.m_pNodeItemIcon, 100, nil, nil, true, true, nil)

    self.ui.m_labelNum:setString(CC_CMDITOA(self.info.num))
    local name = CCCommonUtilsForLua:getPropById(tostring(self.info.itemId), "name")
    self.ui.m_pLabelItemName:setString(getLang(name))
    if self.info.selfAuctioned == "0" then 
        self.ui.m_btnRaisePrice:setEnabled(true)
        self.ui.m_btnTakePrice:setEnabled(true)
    else
        self.ui.m_btnRaisePrice:setEnabled(false)
        self.ui.m_btnTakePrice:setEnabled(false)
    end

    if info.currType then
        self.m_currType = info.currType
        local sf = AuctionHouseController:getCurIcon(info.currType)
        self.ui.m_nowPriceIcon:setSpriteFrame(sf)
        self.ui.m_addPriceIcon:setSpriteFrame(sf)
        self.ui.m_iconOnePriceGold:setSpriteFrame(sf)
        if info.currType == "2" then
            self.ui.m_nowPriceIcon:setScale(0.35)
            self.ui.m_addPriceIcon:setScale(0.35)
            self.ui.m_iconOnePriceGold:setScale(0.35)
        else
            self.ui.m_nowPriceIcon:setScale(0.5)
            self.ui.m_addPriceIcon:setScale(0.5)
            self.ui.m_iconOnePriceGold:setScale(0.5)
        end
    end
end

function AuctionHouseCell:onEnter()
    self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:update(dt) end, 1, false)
    self:update(0)
end

function AuctionHouseCell:onExit()
    self:getScheduler():unscheduleScriptEntry(self.m_entryId)
end

function AuctionHouseCell:update(dt)
    local curTime = GlobalData:call("getTimeStamp")
    local endTime = self.info.endTime/1000
    if endTime - curTime >= 0 then 
        local time = format_time( endTime - curTime)
        self.ui.m_pLabelTime:setString(time)
    else
        if self.timeCount and self.timeCount >= 60*3 then
            self.timeCount = 0
        else
            if self.timeCount == 0 then
                dump("time is 00,pull data+++")
                AuctionHouseController:pullAuctionHouseViewData(false)
            end
            self.timeCount = self.timeCount+1
        end
    end
end

function AuctionHouseCell:isAuctionTimeOver(  )
    local curTime = GlobalData:call("getTimeStamp")
    local endTime = self.info.endTime/1000
    if endTime - curTime >= 0 then 
        return false
    end
    return true
end

--一口价
function AuctionHouseCell:onAddPriceClicked()
    -- dump("AuctionHouseCell:onAddPriceClicked+++")
    if self:isAuctionTimeOver() then 
        LuaController:flyHint("", "", getLang("9440925")) 
        return
    end

    local name = getLang(CCCommonUtilsForLua:getPropById(tostring(self.info.itemId), "name"))
    local tipInfo
    if self.m_currType and self.m_currType == "2" then
        local diamondInAuction = tonumber(AuctionHouseController:getDiamondCountInAuction())
        local item_cp = utils.getExtendClass("currencyComponent"):create(nil,self.m_currType)
        local totalDiamond = item_cp:getNum() + diamondInAuction
        if totalDiamond < tonumber(self.info.decision) then 
            LuaController:flyHint("", "", getLang("9900431")) --9900431=钻石不足
            -- local view = Drequire("game.CommonPopup.ItemGetMethodView"):create("500003")
            -- PopupViewController:call("addPopupView", view)
            return
        end
        tipInfo = getLang("9900435", self.info.decision, name) --9900435=您确定花费{0}钻石一口价购买{1}吗？
    else
        local totalGold = GlobalDataCtr.getPlayerGold()+tonumber(AuctionHouseController:getGoldCountInAuction())
        if totalGold < tonumber(self.info.decision) then 
            LuaController:flyHint("", "", getLang("111909")) --金币不足
            return
        end
        tipInfo = _lang_2("176267", self.info.decision, name) --176267=您确定花费{0}金币一口价购买{1}吗？
    end
    
    local function confirmFunc()
        AuctionHouseController:decisionPrice(self.info.uuid, AuctionHouseController:getAnonmous())
    end
    local dia = YesNoDialog:show(tipInfo, confirmFunc) 
end

--竞价
function AuctionHouseCell:onGivePriceClicked()
    AuctionHouseController.curAuctionCellInfo = nil
    AuctionHouseController.curGlobalAuctionCellInfo = nil
    if self:isAuctionTimeOver() then 
        LuaController:flyHint("", "", getLang("9440925")) 
        return
    end

    local minNum = 0
    local maxNum = 0
    local selectViewUseType = 0
    if self.m_currType and self.m_currType == "2" then
        selectViewUseType = 6
        local diamondInAuction = tonumber(AuctionHouseController:getDiamondCountInAuction())
        local item_cp = utils.getExtendClass("currencyComponent"):create(nil,self.m_currType)
        local totalDiamond = item_cp:getNum() + diamondInAuction
        minNum = tonumber(self.info.add) + tonumber(self.info.price)
        maxNum = totalDiamond
        if maxNum < minNum then 
            LuaController:flyHint("", "", getLang("9900431")) --9900431=钻石不足
            -- local view = Drequire("game.CommonPopup.ItemGetMethodView"):create("500003")
            -- PopupViewController:call("addPopupView", view)
            return
        end
    else
        selectViewUseType = 5
        local goldInAuction = tonumber(AuctionHouseController:getGoldCountInAuction())  
        local totalGold = goldInAuction + GlobalDataCtr.getPlayerGold()
        minNum = tonumber(self.info.add) + tonumber(self.info.price)
        maxNum = totalGold
        if maxNum < minNum then 
            LuaController:flyHint("", "", getLang("104912")) --104912=领主大人，您的金币不足，赶快去购买一些吧！
            return
        end
    end

    -- 176263=请输入您的竞拍加价！  
    -- 176264=竞价
    AuctionHouseController.curAuctionCellInfo = self.info
    local NewToolNumSelectView = Drequire("game.CommonPopup.NewToolNumSelectView")
    local view = NewToolNumSelectView:create(nil, minNum, maxNum, nil, selectViewUseType, "176263" , "176264" , nil , AuctionAckGrivePriceNow , nil)
    local name = CCCommonUtilsForLua:getPropById(tostring(self.info.itemId), "name")
    view.auctionGoodsName = getLang(name)
    PopupViewController:addPopupView(view)
end

return AuctionHouseCell



