----------------------------
-- Author: Elex
-- Date: 2019-11-20 Wednesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local RewardListRateView_ui = class("RewardListRateView_ui")

--#ui propertys


--#function
function RewardListRateView_ui:create(owner, viewType, paramTable)
	local ret = RewardListRateView_ui.new()
	CustomUtility:LoadUi("RewardListRateView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function RewardListRateView_ui:initLang()
end

function RewardListRateView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function RewardListRateView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function RewardListRateView_ui:onConfirmBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onConfirmBtnClick", pSender, event)
end

function RewardListRateView_ui:initTableView()
	TableViewSmoker:createView(self, "m_pTableView1", "game.CommonPopup.RewardListRateCell", 1, 6, "RewardListRateCell")
end

function RewardListRateView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return RewardListRateView_ui

