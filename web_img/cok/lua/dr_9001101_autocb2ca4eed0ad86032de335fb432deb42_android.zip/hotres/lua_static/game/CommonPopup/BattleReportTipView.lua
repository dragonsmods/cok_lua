--[[ 
	战报提示界面
	2019.6.28	Awen
 ]]

local BattleReportTipView = class("BattleReportTipView", function() return cc.Layer:create() end )
BattleReportTipView.__index = BattleReportTipView

function BattleReportTipView.create(dict)
	local view = BattleReportTipView.new()
	Drequire("game.CommonPopup.BattleReportTipView_ui"):create(view)
	if view:initView(dict) then
		return view
	end
end

function BattleReportTipView:initView(dict)
	Dprint('BattleReportTipView:initView')
	if dict == nil then
		return
	end

	local _node = dict:objectForKey("node")
	if _node then
		_node:removeAllChildren()
		_node:addChild(self)
		
		self.v_type = dict:valueForKey("type"):intValue()
		self.mailId = dict:valueForKey("mailId"):getCString()
		if self.v_type == 0 then	--打怪战斗结果
			-- 战斗结果
			local _result = dict:valueForKey("result"):intValue()
			
			-- 描述
			local _monsterId = dict:valueForKey("monsterId"):getCString()
			local _monsterName = CCCommonUtilsForLua:call("getNameById", _monsterId)
			local _monsterLevel = CCCommonUtilsForLua:call("getPropByIdGroup","field_monster",_monsterId,"level")

			if _result == 2 then
				self.ui.m_labelTitle:setString(getLang("105118"))	--105118=战斗失败
				self.ui.m_labelDesc:setString(getLang("10010027", _monsterName, _monsterLevel))	--10010027=我攻击了{0}Lv.{1}
			elseif _result == 4 then
				self.ui.m_labelTitle:setString(getLang("103786"))	--103786=战斗无效
			else
				self.ui.m_labelTitle:setString(getLang("105117"))	--105117=战斗胜利
				self.ui.m_labelDesc:setString(getLang("10010027", _monsterName, _monsterLevel))	--10010027=我攻击了{0}Lv.{1}
			end
		elseif self.v_type == 1 or self.v_type == 2 or self.v_type == 3 or self.v_type == 4 then --1.士兵援助到达 2.快捷战报  3.侦查 4.炮弹
			self.ui.m_labelTitle:setString(dict:valueForKey("title"):getCString())
			self.ui.m_labelDesc:setString(dict:valueForKey("desc"):getCString())
		end

		return true
	end
end

function BattleReportTipView:onEnter() 
	self.v_offsetX = self.ui.m_root:getContentSize().width
	self:runAction(
		cc.Sequence:create(
			cc.EaseSineIn:create(cc.MoveBy:create(0.5, cc.p(-self.v_offsetX, 0)))
		)
	)
	self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:onClickBtnClose() end, 5, false)
end

function BattleReportTipView:onExit()
	if self.m_entryId then
		self:getScheduler():unscheduleScriptEntry(self.m_entryId)
	end
end

-- 打开邮件
function BattleReportTipView:onClickBtnMail()
	-- Dprint('BattleReportTipView:onClickBtnMail', self.v_type)
	if self.v_type == 0 then	--打怪战斗结果
		local dict = CCDictionary:create()
		dict:setObject(CCString:create("OnshowSecondChannelList"), "name")
		dict:setObject(CCString:create(13), "type")
		LuaController:call("openPopViewInLua", dict)
	elseif self.v_type == 2 or self.v_type == 3 then	--快捷战报
		if self.mailId ~= "" then
			local mailInfo = MailController:call("getMailInfoByMailUid", self.mailId)
			if mailInfo then
				MailController:call("showMailPopupFromAnroid", mailInfo, 1)
				return
			end
		end
		local dict = CCDictionary:create()
		dict:setObject(CCString:create("OnshowSecondChannelList"), "name")
		dict:setObject(CCString:create(4), "type")
		LuaController:call("openPopViewInLua", dict)
	end
	
	self:onClickBtnClose()
end

-- 关闭
function BattleReportTipView:onClickBtnClose()
	Dprint('BattleReportTipView:onClickBtnClose')
    self:runAction(
		cc.Sequence:create(
			cc.EaseSineIn:create(cc.MoveBy:create(0.5, cc.p(self.v_offsetX, 0))),
			cc.RemoveSelf:create()
		)
	)
end

return BattleReportTipView
