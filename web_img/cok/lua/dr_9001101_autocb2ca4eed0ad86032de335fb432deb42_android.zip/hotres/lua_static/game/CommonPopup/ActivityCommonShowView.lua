require("game.CommonPopup.ActivityDetailBase")

ActivityCommonShowView = class("ActivityCommonShowView", ActivityDetailBase, ActivityShowCellViewDelegate)
ActivityCommonShowJumpCell = class("ActivityCommonShowJumpCell", function() return cc.Node:create() end)
ActivityCommonShowDoubleButton = class("ActivityCommonShowDoubleButton", function() return cc.Node:create() end)
ActivityCommonShowToolCell = class("ActivityCommonShowToolCell", ActivityShowCellModel)
ActivityPintuEnterCell = class("ActivityPintuEnterCell", ActivityShowCellModel)

function ActivityCommonShowView.create( id )
	local ret = ActivityCommonShowView.new(id)
	if ret:initSelf() == false then
		return nil
	end
	return ret
end

function ActivityCommonShowView:ctor( id )
	ActivityDetailBase.ctor(self, id)
end

function ActivityCommonShowView:initSelf(  )
	-- MyPrint("ActivityCommonShowView:initSelf")

	local obj = self:getObj()
	if nil == obj then
		return false
	end


	local proxy = cc.CCBProxy:create()
    local ccbiUrl = "ActivityCommonShowView"
    local node = CCBReaderLoad(ccbiUrl, proxy, self)
    self:addChild(node)

    
    self:fixBottomSpecial()

    self:initScrollView()

    local function onNodeEvent( event )
		if event == "enter" then
			self:onEnter()
	    elseif event == "exit" then
			self:onExit()
	    end
	end
	self:registerScriptHandler(onNodeEvent)

    -- MyPrint("ActivityCommonShowView:initSelf end")
    return true
end

function ActivityCommonShowView:fixBottomSpecial(  )
    local obj = self:getObj()
    local objType = obj:getProperty("type")
    local bvisible = false
    local objExchange = obj:getProperty("exchange")
    if (objType == 6) then
        CCCommonUtilsForLua:call("setButtonTitle", self.m_btn, getLang("150332"))
        if (objExchange == "1" or objExchange== "2" or objExchange == "10") then
            bvisible = true
        elseif objExchange == "11" then
            if CCCommonUtilsForLua:call("getLanguage") == "zh_TW" then
                bvisible = true
                CCCommonUtilsForLua:call("setButtonTitle", self.m_btn, getLang("151234"))
            end
        elseif objExchange == "12" then
            bvisible = true
            CCCommonUtilsForLua:call("setButtonTitle", self.m_btn, getLang("150932"))
            self.m_btn:setEnabled(false)
            local cmd = CallFriendsCmd.new(50)
            cmd:send()
        elseif objExchange == "14" then
            local doubleBtnCell = ActivityCommonShowDoubleButton.new()
            doubleBtnCell:setAnchorPoint(cc.p(0, 0))
            doubleBtnCell:setPosition(cc.p(0,0))
            self:addChild(doubleBtnCell)
        elseif objExchange == "15" then
            bvisible = true
            CCCommonUtilsForLua:call("setButtonTitle", self.m_btn, getLang("151877"))--151877  前往采集
        elseif objExchange == "16" then
            bvisible = true
            CCCommonUtilsForLua:call("setButtonTitle", self.m_btn, getLang("2000214") .. getLang("102009"))--2000214  前往 102009  急救帐篷
        end
    elseif objType == 58 then 
        bvisible = true 
        CCCommonUtilsForLua:call("setButtonTitle", self.m_btn, getLang("2000214"))
    end

    -- MyPrint("bvisible", bvisible)
    self.m_btn:setVisible(bvisible)

    -- 祈祷献祭活动
    if self.m_id == "57139" then
        -- package.loaded["game.activity.Sacrifice.ActivitySacrificeView"] = nil
        require("game.activity.Sacrifice.ActivitySacrificeView")
        if nil ~= ActivitySacrificeBtnCell then
            local cell = ActivitySacrificeBtnCell.new()
            self:addChild(cell)
        end
    end

    -- 卖iphone活动
    if self.m_id == "57141" then
        -- package.loaded["game.activity.iphone.ActivityIphoneCell"] = nil
        require("game.activity.iphone.ActivityIphoneCell")
        if nil ~= ActivityIphoneCell then
            local cell = ActivityIphoneCell.new()
            self:addChild(cell)
        end
    elseif self.m_id == "57156" then
        self.m_btn:setVisible(true)
        CCCommonUtilsForLua:call("setButtonTitle", self.m_btn, getLang("138113"))
    end

end

function ActivityCommonShowView:onEnter(  )
	self:onEnterFrame()
	self.entry = tonumber(self:getScheduler():scheduleScriptFunc(function (  )
		self:onEnterFrame()
	end, 1.0, false))

	local function onActivityDataCB( ref )
        -- MyPrint("onActivityDataCB")
        if ref == nil then
            return
        end
        -- dump(ref,"cjy onActivityDataCB")
        self:parseActivityInfo(ref)
    end
    local t = tolua.cast(self, "cc.Node")
    local handler = t:registerHandler(onActivityDataCB)
    CCSafeNotificationCenter:registerScriptObserver(self, handler, "activity_callback")
end

function ActivityCommonShowView:onExit( )
	self:getScheduler():unscheduleScriptEntry(self.entry)
    CCSafeNotificationCenter:unregisterScriptObserver(self, "activity_callback")
end

function ActivityCommonShowView:onClickBtn(  )
    -- MyPrint('ActivityCommonShowView:onClickBtn', self.m_id)
	local obj = self:getObj()
    if nil == obj then
        return
    end
    if self.m_id == "57156" then
        local HeroManager = require("game.hero.HeroManager")
        if HeroManager.jumpIntoPropertyXL then
            PopupViewController:call("removeLastPopupView")
            HeroManager.jumpIntoPropertyXL()
        end
        return
    end
    if self.m_id == "57235" then 
        PopupViewController:call("removeAllPopupView")

        local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
        local allianceInfo = playerInfo:getProperty("allianceInfo")

        local dict = CCDictionary:create()
        dict:setObject(CCString:create("AllianceInfoView"), "name")
        dict:setObject(allianceInfo, "info")
        dict:setObject(CCString:create("false"), "bRef")
        LuaController:call("openPopViewInLua", dict) 
        return
    end
    local objExchange = obj:getProperty("exchange")
    if (objExchange== "2") then
        PopupViewController:call("removeLastPopupView")
        local view = ActivityExcNewView:call("create", obj)
        PopupViewController:call("addPopupView", view)
    elseif (objExchange == "1") then
        PopupViewController:call("removeLastPopupView")
        local view = ActivityExcView:call("create", obj)
        PopupViewController:call("addPopupInView", view)
    elseif (objExchange == "10") then
        PopupViewController:call("removeLastPopupView")
        local view = ActivityVoteView:call("create")
        PopupViewController:call("addPopupInView", view)
    elseif (objExchange == "11") then

        -- E100091=领主大人，资源下载中，请稍后尝试操作。
        if DynamicResourceController2:call("checkDynamicResource", "activity_res") == false then
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("E100091"))
            return false
        end
        PopupViewController:call("removeLastPopupView")
        require "game.CommonPopup.WangLihongShareView"
		local view = WangLihongShareView:create()
        PopupViewController:call("addPopupView", view)
    elseif (objExchange == "12") then
        if CCCommonUtilsForLua:call("fbIsLogin") == false then
            MyPrint("not login !!!!!")
            CCCommonUtilsForLua:call("fbLogin")
            return
        end
        local link = ""
        if isAndroid() then
            -- link = "https://fb.me/789279541113368?from_feed=android_king"
            -- 都用ios的
            link = "https://fb.me/789290781112244?from_feed=ios_king"
        else
            link = "https://fb.me/789290781112244?from_feed=ios_king"
        end
        local str = getLang("151647")
        local pictureUrl = "http://cdn1.cok.eleximg.com/cok/mail/WEB/huigui.jpg"
        local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
        if playerInfo and playerInfo:call("getRegCountry") == "KR" then
            str = getLang("151648")
            pictureUrl = "http://cdn1.cok.eleximg.com/cok/mail/WEB/huigui_kr.jpg"
        elseif playerInfo and playerInfo:call("getRegCountry") == "MO" then
            str = getLang("151645")
        end
        CCCommonUtilsForLua:call("fbPublishFeedDialog", "Clash Of Kings", "Clash Of Kings", str, link, pictureUrl, 1)
        TriggerEventUtils.triggerShare("recall")
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("105552"))

        local cmd = CallFriendsCmd.new(50)
        cmd:send()

        self.m_btn:setEnabled(false)
    elseif objExchange == "15" then
        SceneController:call("gotoScene", SCENE_ID_WORLD)
    elseif objExchange == "16" then
        local buildId = FunBuildController:call("getMaxLvBuildByType", FUN_BUILD_HOSPITAL)
        if (buildId ~= 0) then
            PopupViewController:call("removeLastPopupView")
            local buildInfo = FunBuildController:call("getFunbuildForLua", buildId)
            local dict = CCDictionary:create()
            dict:setObject(buildInfo, "buildInfo")
            dict:setObject(CCString:create("BuildingHospitalPopUpView"), "name")
            LuaController:call("openPopViewInLua", dict)
        end
    end
end

function ActivityCommonShowView:onEnterFrame( )
	-- MyPrint("ActivityCommonShowView:onEnterFrame")
    local obj = self:getObj()
    if nil == obj then
        return 
    end

    if obj:getProperty("exchange") == "12" and obj:getProperty("type") == 6 and self.m_facebookEndTime then
        local now = LuaController:call("getTimeStamp")
        local updateTimeFormate = self.m_facebookEndTime - now
        updateTimeFormate = math.max(updateTimeFormate,0)
        if updateTimeFormate > 0 then --未到时间
            self.m_btn:setEnabled(false)
            CCCommonUtilsForLua:call("setButtonTitle", self.m_btn, getLang("150932").."\n"..format_time(updateTimeFormate))
        else
            self.m_btn:setEnabled(true)
            CCCommonUtilsForLua:call("setButtonTitle", self.m_btn, getLang("150932"))
        end
    end
end

function ActivityCommonShowView:parseActivityInfo(ref )
    if not ref then
        MyPrint("ref is nil")
        return
    end
    local tbl = dictToLuaTable(ref)   
    -- dump(tbl,"ActivityCommonShowView parseInfo tbl")
    if tbl.type and tonumber(tbl.type) == 51 then--微博
    elseif tbl.type and tonumber(tbl.type) == 52 then--微信
    else
        if tbl.state then
            self.m_facebookState = tbl.state
            MyPrint("self.m_facebookState",self.m_facebookState)
        end
        if tbl.endTime then
            self.m_facebookEndTime = math.ceil(tonumber(tbl.endTime) / 1000)
            MyPrint("self.m_facebookEndTime",self.m_facebookEndTime)
        end
    end
end

function ActivityCommonShowView:initScrollView(  )
	local obj = self:getObj()
    if nil == obj then
        return
    end

	local node = cc.Node:create()

	local cury = 0

    -- 描述
	local label = cc.Label:create()
	local mStory = ""
	if obj:getProperty("id") == "57091" then
        local luckyDay = CLuckdayController:call("getInstance")
        local left_time = CCCommonUtilsForLua:call("getPropById", "99027", "k7")
        local curTime = luckyDay:getProperty("m_getEffectTimes") 
        local totalTimes = luckyDay:getProperty("m_totalTimes") 
        local curAction = ""
        if (luckyDay:getProperty("m_iLuckyId") > 0) then
            local action = tonumber(CCCommonUtilsForLua:call("getPropById", tostring(luckyDay:getProperty("m_iLuckyId")), "action"))
            if (action > 0) then
                curAction = getLang(CCCommonUtilsForLua:call("getPropById", tostring(luckyDay:getProperty("m_iLuckyId")), "typename"))
            end
        end
        
        local effectLeftTime = tostring(totalTimes- curTime)
        mStory = _lang_4("9400543", tostring(totalTimes), left_time, curAction, effectLeftTime)
    elseif obj:getProperty("id") == "57177" then
        local myLimit = 0
        --荣耀
        local starNum = FunBuildController:call("getFunbuildForLua", FUN_BUILD_MAIN_CITY_ID):getProperty("starNum")  
        local mainCityLevel = FunBuildController:call("getMainCityLv")
        mainCityLevel = mainCityLevel + starNum
        local hospitalLimit = ActivityController:call("getInstance"):getProperty("hospitalLimit")
        local hospitalTbl = string.split(hospitalLimit , "|")
        if hospitalTbl and #hospitalTbl > 0 then
            for k,v in pairs(hospitalTbl) do
                local cityLevelTbl = string.split(v , ";")
                if cityLevelTbl and #cityLevelTbl > 1 then
                    if mainCityLevel == tonumber(cityLevelTbl[1]) then
                        myLimit = tonumber(cityLevelTbl[2])
                    end
                end
            end
        end
        --totalMax
        local treateMax = ArmyController:call("getInstance"):call("getMaxNumByType",2);
        if ActivityController:call("getInstance"):call("isInNewThroneBattle") then
            WorldController:call("getInstance"):setProperty("dragonPlayoffHospitalAddition",ActivityController:call("getHealEff"))
        end
        local treateAdd = WorldController:call("getInstance"):getProperty("dragonPlayoffHospitalAddition")
        if (treateAdd>0) then
            treateMax = (treateMax*treateAdd)/100;
        end
        treateMax = treateMax + myLimit
        mStory = getLang(obj:getProperty("story") , CC_CMDITOA(myLimit) , CC_CMDITOA(treateMax))
    elseif obj:getProperty("id") == "57176" then
        local effectValue = CCCommonUtilsForLua:call("getPropById", "1503012", "effectValue")
        local effectValueTbl = string.split(effectValue , ";")
        if effectValueTbl and #effectValueTbl >= 2 then
            local kingNameHospital = obj:getProperty("kingNameHospital")
            if not kingNameHospital then
                kingNameHospital = ""
            end
            mStory = getLang(obj:getProperty("story") , kingNameHospital , effectValueTbl[1] , effectValueTbl[2])
        end
    else
        mStory = getLang(obj:getProperty("story"))
    end
    label:setString(mStory)
    label:setSystemFontSize(18)
    label:setColor(cc.c3b(147, 122, 92))
    label:setDimensions(518, 0)
    label:setAnchorPoint(cc.p(0.5, 1))
    label:setPosition(cc.p(0, cury))
    label:setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    label:setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_TOP)
    node:addChild(label)
    cury = cury - label:getContentSize().height

    -- 空
    cury = cury - 10

    -- 奖励
    local rewardIds = obj:getProperty("rewardIds")
    if #rewardIds > 0 then
    	local view = ActivityShowCellView.new(self)
    	self.m_toolShowView = view
    	-- 150217=在奖励中有几率获得
		view:setTitle(getLang("150217"))
		view:reloadData()
		node:addChild(view)
		view:setAnchorPoint(cc.p(0.5, 1))
		view:setPosition(cc.p(0, cury))
		cury = cury - view:getContentSize().height

		cury = cury - 10
    end

    -- 某些类型活动特殊插入
    if obj:getProperty("exchange") == "13" then
        MyPrint("i am 13")
    	local view = ActivityShowCellView.new(self)
    	self.m_pintuEnter = view
        -- 105848    活动奖励
    	view:setTitle(getLang("105848"))
    	view:reloadData()
    	view:setAnchorPoint(cc.p(0.5, 1))
		view:setPosition(cc.p(0, cury))
		node:addChild(view)
		cury = cury - view:getContentSize().height
        MyPrint("cury ", cury)

		cury = cury - 10
    end

    -- 情人节 
    if self.m_id == "57136" then
        require("game.activity.love.ActivityLoveProNode")
        if nil ~= ActivityLoveProNode then
            local love = ActivityLoveProNode.new(self.m_id, self.m_listNode)
            cury = cury - love:getContentSize().height
            love:setPositionY(cury)
            love:setPositionX(0)
            node:addChild(love)
            cury = cury - 10
        end
    elseif self.m_id == "57091" then
        local Luckycell = Drequire("game.activity.LuckyDay.LuckyDayPayCell").create()
        if Luckycell then
            self:setShowHelpBtn(true)
            cury = cury - Luckycell:getContentSize().height
            Luckycell:setPositionY(cury)
            Luckycell:setPositionX(0)
            node:addChild(Luckycell)
            cury = cury - 10
        end
    end

    -- 跳转
    local desc_tips_str = CCCommonUtilsForLua:call("getPropById", self.m_id, "desc_tips")
    local desc_gotype = CCCommonUtilsForLua:call("getPropById", self.m_id, "desc_gotype")
    local goType = CCCommonUtilsForLua:call("getPropById", self.m_id, "gotype")
    local go = CCCommonUtilsForLua:call("getPropById", self.m_id, "go")
    desc_tips = string.split(desc_tips_str, ";")
    desc_gotype = string.split(desc_gotype, ";")
    goType = string.split(goType, ";")
    go = string.split(go, ";")
    if desc_tips_str ~= "" and #desc_tips == #desc_gotype and #desc_tips == #goType and #desc_tips == #go then
        for i=1,#desc_tips do
            -- function ActivityCommonShowJumpCell:ctor( des, btnLabel, goType, goItemId )
            local cell = ActivityCommonShowJumpCell.new(getLang(desc_tips[i]), getLang(desc_gotype[i]), tonumber(goType[i]), (go[i]))
            cell:setAnchorPoint(cc.p(0, 0))
            cell:setPositionX(-self.m_listNode:getContentSize().width * 0.5)
            cell:setPositionY(cury - cell:getContentSize().height)
            cell:setOutTouchNode(self.m_listNode)
            node:addChild(cell)
            cury = cury - cell:getContentSize().height
        end
    end

    local view = cc.ScrollView:create()
    view:setViewSize(self.m_listNode:getContentSize())
    if (math.abs(cury) < self.m_listNode:getContentSize().height) then
        node:setPositionY(self.m_listNode:getContentSize().height / 2.0 + math.abs(cury) / 2.0)
        cury = -self.m_listNode:getContentSize().height
    else 
        node:setPositionY(math.abs(cury))
    end
    view:setContentSize(cc.size(self.m_listNode:getContentSize().width, math.abs(cury)))
    view:addChild(node)
    node:setPositionX(view:getContentSize().width / 2)
    view:setContentOffset(cc.p(0, self.m_listNode:getContentSize().height - view:getContentSize().height))
    view:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
    view:setDelegate()
    local function scrollViewDidScroll(  )
        self:scrollViewDidScroll(view)
    end
    view:registerScriptHandler(scrollViewDidScroll, cc.SCROLLVIEW_SCRIPT_SCROLL)
    self.m_listNode:addChild(view)
end

function ActivityCommonShowView:scrollViewDidScroll(view)
    local mindy = view:minContainerOffset().y 
    local maxdy = view:maxContainerOffset().y 
    local dy = view:getContentOffset().y
    if (dy < mindy) then
        view:setContentOffset(cc.p(0, mindy))
    end
    if (dy > maxdy) then
        view:setContentOffset(cc.p(0, maxdy))
    end
end

-- 使用者必须重载
function ActivityCommonShowView:cellCount(view)
	if view == nil then
		return 0
	end
	local obj = self:getObj()
    if nil == obj then
        return 0
    end

	if view == self.m_toolShowView then
		local rewardIds = obj:getProperty("rewardIds")
		return #rewardIds
	end
	
	if view == self.m_pintuEnter then
		local gear = CCCommonUtilsForLua:call("getPropById", tostring(self.m_id), "gear1")
        if "" == gear then
            return 0
        end
        local t = string.split(gear, ";")
        return #t
	end

	return 0
end

function ActivityCommonShowView:createCellAtIdx(view, idx)
    -- MyPrint("ActivityCommonShowView:createCellAtIdx", view, idx)
	local obj = self:getObj()
	if nil == obj or nil == view then
		return nil
	end

	if view == self.m_toolShowView then
		local rewardIds = obj:getProperty("rewardIds")
		if idx > #rewardIds then
			return nil
		end

		local cell = ActivityCommonShowToolCell.new(rewardIds[idx], self.m_listNode)
		return cell
	end

    if view == self.m_pintuEnter then
        MyPrint("view == self.m_pintuEnter")
        local gear = CCCommonUtilsForLua:call("getPropById", tostring(self.m_id), "gear1")
        if "" == gear then
            return nil
        end

        local t = string.split(gear, ";")
        if idx > #t then
            return nil
        end

        return ActivityPintuEnterCell.new(t[idx], self.m_listNode)
    end

	return nil
end

-- 可重载
function ActivityCommonShowView:cellWidth( view )
    local obj = self:getObj()
    if nil == obj or nil == view then
        return nil
    end

    if view == self.m_toolShowView then
        return ActivityShowCellViewDelegate.cellWidth(self, view)
    end

    if view == self.m_pintuEnter then
        return 2 * ActivityShowCellViewDelegate.cellWidth(self, view)
    end

    return ActivityShowCellViewDelegate.cellWidth(self, view)
end

function ActivityCommonShowView:callHelp()
    if self.m_id == "57091" then
        YesNoDialog:show(getLang("9401239")) 
    end
end

function ActivityCommonShowJumpCell:ctor( des, btnLabel, goType, goItemId )
    MyPrint("ActivityCommonShowJumpCell:ctor", des, btnLabel, goType, goItemId )
    self.goType = tonumber(goType)
    self.goItemId = (goItemId)
    
    local proxy = cc.CCBProxy:create()
    local ccbiUrl = "ActivityCommonShowJumpCell"
    local node = CCBReaderLoad(ccbiUrl, proxy, self)
    self:addChild(node)
    self:setContentSize(node:getContentSize())

    self.m_desLabel:setString(des)
    self.m_btnLabel:setString(btnLabel)

    self.startTouchPt = cc.p(0, 0)
    local layer = cc.Layer:create()
    node:addChild(layer, -1)
    local function touchHandle( eventType, x, y )
        if eventType == "began" then
            return self:onTouchBegan(x, y)
        elseif eventType == "moved" then
        else
            self:onTouchEnded(x, y)
        end
    end
    layer:registerScriptTouchHandler(touchHandle)
    layer:setTouchEnabled(true)
    layer:setSwallowsTouches(false)
end

function ActivityCommonShowJumpCell:setOutTouchNode( node )
    self.m_outTouchNode = node
end

function ActivityCommonShowJumpCell:onTouchBegan( x,y )
    self.startTouchPt = cc.p(x, y)
    if nil == self.m_outTouchNode then
        return false
    end

    return isTouchInside(self.m_btnTouchNode, x, y)
end

function ActivityCommonShowJumpCell:onTouchEnded( x, y )
    MyPrint("ActivityCommonShowJumpCell:onTouchEnded")
    if isTouchInside(self.m_btnTouchNode, x, y) == false then
        return 
    end

    local dis = 10
    if CCCommonUtilsForLua:call("isIosAndroidPad") then
        dis = 20
    end
    if cc.pGetDistance(self.startTouchPt, cc.p(x, y)) > dis then
        return
    end

    self:retain()
    PopupViewController:call("removeAllPopupView")
    CCCommonUtilsForLua.jumpToTarget(self.goType, self.goItemId)
    self:release()
end


---------------------------ActivityCommonShowDoubleButton begin--------------------------
function ActivityCommonShowDoubleButton:ctor(  )    
    local proxy = cc.CCBProxy:create()
    local ccbiUrl = "ActivityCommonShowDoubleButton"
    local node = CCBReaderLoad(ccbiUrl, proxy, self)
    self:addChild(node)
    self:setContentSize(node:getContentSize())
    local layer = cc.Layer:create()
    node:addChild(layer, -1)
    local function onNodeEvent( event )
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(onNodeEvent)

    self.m_btnRight:setEnabled(false)
    self.m_btnLeft:setEnabled(false)
    CCCommonUtilsForLua:call("setButtonTitle", self.m_btnRight, getLang("150933"))--微博
    CCCommonUtilsForLua:call("setButtonTitle", self.m_btnLeft, getLang("150931"))--微信
    self.m_weiboEndTime = -1
    self.m_weixinEndTime = -1
    self.m_weiboState = -1
    self.m_weixinState = -1
    local cmd = CallFriendsCmd.new(51)--微博
    cmd:send()
    -- local cmd2 = CallFriendsCmd.new(52)--微信
    -- cmd2:send()
end

function ActivityCommonShowDoubleButton:onEnter(  )
    local function onActivityDataCB( ref )
        MyPrint("onActivityDataCB")
        if ref == nil then
            return
        end
        self:parseActivityInfo(ref)
    end
    local t = tolua.cast(self, "cc.Node")
    local handler = t:registerHandler(onActivityDataCB)
    CCSafeNotificationCenter:registerScriptObserver(self, handler, "activity_callback")

    local function onWeiboCB( ref )
        MyPrint("onWeiboCB")
        if ref == nil then
            return
        end
        ref = ref:getValue()
        self:onWeiboCB(ref)
    end
    local handler2 = t:registerHandler(onWeiboCB)
    CCSafeNotificationCenter:registerScriptObserver(self, handler2, "WeiBoFeedDialogResult")

    self:onEnterFrame()
    self.entry = tonumber(self:getScheduler():scheduleScriptFunc(function (  )
        self:onEnterFrame()
    end, 1.0, false))
end

function ActivityCommonShowDoubleButton:onWeiboCB( ref )--0微信\1微博 分享成功
    if ref and tonumber(ref) == 1 then
        TriggerEventUtils.triggerShare("recall_weibo")
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("101275"))
        local cmd = CallFriendsCmd.new(51)
        cmd:send()
        self.m_btnRight:setEnabled(false)
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("164541"))
    end
end
function ActivityCommonShowDoubleButton:parseActivityInfo(ref )
    if not ref then
        MyPrint("ref is nil")
        return
    end
    local tbl = dictToLuaTable(ref)   
    if tbl.type and tonumber(tbl.type) == 51 then--微博
        if tbl.state then
            self.m_weiboState = tonumber(tbl.state) 
        end
        if tbl.endTime then
            self.m_weiboEndTime = math.ceil(tonumber(tbl.endTime) / 1000)
        end
    elseif tbl.type and tonumber(tbl.type) == 52 then--微信
        if tbl.state then
            self.m_weixinState = tonumber(tbl.state)
        end
        if tbl.endTime then
            self.m_weixinEndTime = math.ceil(tonumber(tbl.endTime) / 1000)
        end
    else
        -- if tbl.state then
        --     self.m_facebookState = tbl.state
        --     MyPrint("self.m_facebookState",self.m_facebookState)
        -- end
        -- if tbl.endTime then
        --     self.m_facebookEndTime = math.ceil(tonumber(tbl.endTime) / 1000)
        --     MyPrint("self.m_facebookEndTime",self.m_facebookEndTime)
        -- end
    end
end
function ActivityCommonShowDoubleButton:onEnterFrame( dt )   
    local now = LuaController:call("getTimeStamp")
    if self.m_weiboEndTime > now and self.m_weiboState == 0 then
        local updateTimeFormate = self.m_weiboEndTime - now
        updateTimeFormate = math.max(updateTimeFormate,0)
        if updateTimeFormate > 0 then --未到时间
            self.m_btnRight:setEnabled(false)
            CCCommonUtilsForLua:call("setButtonTitle", self.m_btnRight, getLang("150933").."\n"..format_time(updateTimeFormate))
        end
    elseif self.m_weiboState == 1 then
        self.m_btnRight:setEnabled(true)
        CCCommonUtilsForLua:call("setButtonTitle", self.m_btnRight, getLang("150933"))
    end
    if self.m_weixinEndTime > now and self.m_weixinState == 0 then
        local updateTimeFormate = self.m_weixinEndTime - now
        updateTimeFormate = math.max(updateTimeFormate,0)
        if updateTimeFormate > 0 then --未到时间
            self.m_btnLeft:setEnabled(false)
            CCCommonUtilsForLua:call("setButtonTitle", self.m_btnLeft, getLang("150931").."\n"..format_time(updateTimeFormate))
        end
    elseif self.m_weixinState == 1 then
        self.m_btnLeft:setEnabled(true)
        CCCommonUtilsForLua:call("setButtonTitle", self.m_btnLeft, getLang("150931"))
    end
end

function ActivityCommonShowDoubleButton:onExit( )
    CCSafeNotificationCenter:unregisterScriptObserver(self, "activity_callback")
    CCSafeNotificationCenter:unregisterScriptObserver(self, "WeiBoFeedDialogResult")
    self:getScheduler():unscheduleScriptEntry(self.entry)
end

function ActivityCommonShowDoubleButton:onClickButtonLeft( )
    self:goShare(1)--weibo
end

function ActivityCommonShowDoubleButton:onClickButtonRight( )
    self:goShare(0)--weixin   
end
function ActivityCommonShowDoubleButton:goShare( type )
    MyPrint("goShare",type)
    if type == 0 then--weibo
        CCCommonUtilsForLua:call("shareWeiBo", "weibo", getLang("152005"), "http://share.elexapp.com/index/image?file=1484562190627.png", true)
        -- TriggerEventUtils.triggerShare("recall_weibo")
        -- CCCommonUtilsForLua:call("flyHint", "", "", getLang("101275"))
        -- local cmd = CallFriendsCmd.new(51)
        -- cmd:send()
        self.m_btnRight:setEnabled(false)
        self.m_weiboState = 0
    elseif type == 1 then--weixin
        CCCommonUtilsForLua:call("shareWeiXin", "weixin", getLang("152005"), "", 1)
        -- TriggerEventUtils.triggerShare("recall_weixin")
        -- CCCommonUtilsForLua:call("flyHint", "", "", getLang("101275"))
        -- local cmd = CallFriendsCmd.new(52)
        -- cmd:send()
        -- self.m_btnLeft:setEnabled(false)
    end
end

---------------------------ActivityCommonShowDoubleButton end--------------------------
--------------------------------------------ActivityCommonShowToolCell----------------------------------
--------------------------------------------ActivityCommonShowToolCell----------------------------------
--------------------------------------------ActivityCommonShowToolCell----------------------------------
function ActivityCommonShowToolCell:ctor( id, touchBoundNode )
	self.m_id = tonumber(id)
	self.m_touchBoundNode = touchBoundNode

	local iconStr = CCCommonUtilsForLua:call("getIcon", tostring(id))

	ActivityShowCellModel.ctor(self, nil, iconStr, nil)

	self.startTouchPt = cc.p(0, 0)
    local function touchHandle( eventType, x, y )
        if eventType == "began" then
            return self:onTouchBegan(x, y)
        elseif eventType == "moved" then
        else
            self:onTouchEnded(x, y)
        end
    end
    self:registerScriptTouchHandler(touchHandle)
    self:setTouchEnabled(true)
    self:setSwallowsTouches(false)
end

function ActivityCommonShowToolCell:onTouchBegan( x, y )
	self.startTouchPt = cc.p(x, y)
	self:removeChildByTag(123123)
	if isTouchInside(self.m_touchNode, x, y) and isTouchInside(self.m_touchBoundNode, x, y) then
		local name = CCCommonUtilsForLua:call("getNameById", tostring(self.m_id))
		local desc = CCCommonUtilsForLua:call("getPropById", tostring(self.m_id), "description")
		desc = getLang(desc)
		local node = CommonItemDescNode:call("create", name, desc)
		local size = node:getContentSize()
		local selfposx = self:getPositionX()
		node:setPositionX(0)
		if selfposx - size.width * 0.5 < -538 / 2 then
			node:setPositionX(-538 / 2 - (selfposx - size.width * 0.5))
		end
		if selfposx + size.width * 0.5 > 538 / 2 then
			node:setPositionX(538 / 2 - (selfposx + size.width * 0.5))
		end
		node:setPositionY(size.height * 0.5 + 50)
		node:setTag(123123)
		self:addChild(node)
		return true
	end
	return false
end

function ActivityCommonShowToolCell:onTouchEnded( x, y )
	self:removeChildByTag(123123)
end
--------------------------------------------ActivityCommonShowToolCell----------------------------------
--------------------------------------------ActivityCommonShowToolCell----------------------------------
--------------------------------------------ActivityCommonShowToolCell----------------------------------





--------------------------------------------ActivityPintuEnterCell----------------------------------
--------------------------------------------ActivityPintuEnterCell----------------------------------
--------------------------------------------ActivityPintuEnterCell----------------------------------
function ActivityPintuEnterCell:ctor( id, touchBoundNode )
    MyPrint("ActivityPintuEnterCell:ctor", id, touchBoundNode)
    self.m_id = tonumber(id)
    self.m_touchBoundNode = touchBoundNode

    local iconStr = CCCommonUtilsForLua:call("getIcon", tostring(id))

    ActivityShowCellModel.ctor(self, nil, iconStr, nil)
    self:setContentSize(cc.size(0, 0))
    self:setScale(2)

    self.startTouchPt = cc.p(0, 0)
    local function touchHandle( eventType, x, y )
        if eventType == "began" then
            return self:onTouchBegan(x, y)
        elseif eventType == "moved" then
        else
            self:onTouchEnded(x, y)
        end
    end
    self:registerScriptTouchHandler(touchHandle)
    self:setTouchEnabled(true)
    self:setSwallowsTouches(false)
end

function ActivityPintuEnterCell:onTouchBegan( x, y )
    self.startTouchPt = cc.p(x, y)
    if isTouchInside(self.m_touchNode, x, y) and isTouchInside(self.m_touchBoundNode, x, y) then
        return true
    end
    return false
end

function ActivityPintuEnterCell:onTouchEnded( x, y )
    if isTouchInside(self.m_touchNode, x, y) == false then
        return 
    end

    local dis = 10
    if CCCommonUtilsForLua:call("isIosAndroidPad") then
        dis = 20
    end
    if cc.pGetDistance(self.startTouchPt, cc.p(x, y)) > dis then
        return
    end

    require("game.CommonPopup.ActivityPintuView")
    local view = ActivityPintuView.create(self.m_id)
    if nil ~= view then
        PopupViewController:call("removeLastPopupView")
        PopupViewController:call("addPopupView", view)
    end
end
--------------------------------------------ActivityPintuEnterCell----------------------------------
--------------------------------------------ActivityPintuEnterCell----------------------------------
--------------------------------------------ActivityPintuEnterCell----------------------------------
