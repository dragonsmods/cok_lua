----------------------------
-- Author: Elex
-- Date: 2020-06-24 Wednesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CommonRank3PlayerNode_ui = class("CommonRank3PlayerNode_ui")

--#ui propertys


--#function
function CommonRank3PlayerNode_ui:create(owner, viewType, paramTable)
	local ret = CommonRank3PlayerNode_ui.new()
	CustomUtility:DoRes(0, true)
	CustomUtility:DoRes(11, true)
	CustomUtility:DoRes(7, true)
	CustomUtility:LoadUi("CommonRank3PlayerNode.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CommonRank3PlayerNode_ui:initLang()
end

function CommonRank3PlayerNode_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CommonRank3PlayerNode_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CommonRank3PlayerNode_ui:onClickPicBtn(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickPicBtn", pSender, event)
end

function CommonRank3PlayerNode_ui:onRewardButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onRewardButtonClick", pSender, event)
end

return CommonRank3PlayerNode_ui

