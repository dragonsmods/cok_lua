----------------------------
-- Author: Elex
-- Date: 2018-06-19 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local NewMerchantSmallCell_ui = class("NewMerchantSmallCell_ui")

--#ui propertys


--#function
function NewMerchantSmallCell_ui:create(owner, viewType, paramTable)
	local ret = NewMerchantSmallCell_ui.new()
	CustomUtility:DoRes(11, true)
	CustomUtility:DoRes(8, true)
	CustomUtility:LoadUi("NewMerchantSmallCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function NewMerchantSmallCell_ui:initLang()
end

function NewMerchantSmallCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function NewMerchantSmallCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function NewMerchantSmallCell_ui:onRefreshClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onRefreshClick", pSender, event)
end

return NewMerchantSmallCell_ui

