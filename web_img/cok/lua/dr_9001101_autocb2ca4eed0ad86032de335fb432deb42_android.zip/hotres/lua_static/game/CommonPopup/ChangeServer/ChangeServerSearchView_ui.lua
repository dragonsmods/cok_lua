----------------------------
-- Author: Elex
-- Date: 2019-03-26 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local ChangeServerSearchView_ui = class("ChangeServerSearchView_ui")

--#ui propertys


--#function
function ChangeServerSearchView_ui:create(owner, viewType, paramTable)
	local ret = ChangeServerSearchView_ui.new()
	CustomUtility:LoadUi("ChangeServerSearchView.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function ChangeServerSearchView_ui:initLang()
end

function ChangeServerSearchView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function ChangeServerSearchView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function ChangeServerSearchView_ui:onConfirmBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onConfirmBtnClick", pSender, event)
end

return ChangeServerSearchView_ui

