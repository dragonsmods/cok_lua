--描述对话框
local RankActDesView = class("RankActDesView", function()
    return PopupBaseView:create()
end)
RankActDesView.__index = RankActDesView

function RankActDesView.create(activityId)
	local view = RankActDesView.new()
	Drequire("game.CommonPopup.RankActComponent.RankActDesView_ui"):create(view, 0)

	if view:initView(activityId) == false then
		return nil
	end
  	return view
end

function RankActDesView:initView(activityId)
	Dprint("RankActDesView:initView")
	CCLoadSprite:call("doResourceByCommonIndex", 3, true)

	local function touchHandle( eventType, x, y )
        if eventType == "began" then
            return self:onTouchBegan(x, y)
        elseif eventType == "moved" then
        else
            self:onTouchEnded(x, y)
        end
    end
    self:registerScriptTouchHandler(touchHandle)
    local touchNode = tolua.cast(self, "cc.CCIFTouchNode")
    touchNode:call("setTouchEnabled", true)
    touchNode:call("setSwallowsTouches" , true)

    -- 数据
    local _xmlData = CCCommonUtilsForLua:getGroupByKey("time_event_des")
    if _xmlData == nil then
        return false
    end
    local _data = {}
    for k,v in pairs(_xmlData) do
        if v.pos == activityId then
            table.insert( _data, v )
        end
    end
    table.sort( _data, function(a, b)
        if a and b then
            local _aid = tonumber(a.id) or 0
            local _bid = tonumber(b.id) or 0
            return _aid < _bid
        end
        return false
    end)
    -- dump(_data, "RankActDesView:initView")
    self.ui.m_nodeList:removeAllChildren()
    local _scrollView = cc.ScrollView:create()
    local _viewSize = self.ui.m_nodeList:getContentSize()
    _scrollView:setViewSize(_viewSize)
    _scrollView:setPosition(CCPoint(0,0))
    _scrollView:setScale(1.0)
    _scrollView:ignoreAnchorPointForPosition(true)
    _scrollView:setDirection(1)
    _scrollView:setClippingToBounds(true)
    _scrollView:setBounceable(true)
    self.ui.m_nodeList:addChild(_scrollView)

    local _height = 0
    local _offsetX = 5  --x偏移
    local _txtWidth = _viewSize.width - _offsetX - _offsetX
    local _mainNode = cc.Node:create()
    for i,v in ipairs(_data) do
        local _fontSize = v.size
        local _fontColor = "<c " .. v.color .. ">"

        local _para1 = ""
        if v.para1 then
            local _paraList = string.split(v.para1, "|")
            if #_paraList == 3 then
                _para1 = "<c " .. _paraList[3] .. ">"
                if _paraList[2] == '0' then
                    _para1 = _para1 ..getLang(_paraList[1]) .. _fontColor
                else
                    _para1 = _para1 .._paraList[1] .. _fontColor
                end
            end
        end

        local _para2 = ""
        if v.para2 then
            local _paraList = string.split(v.para2, "|")
            if #_paraList == 3 then
                _para2 = "<c " .. _paraList[3] .. ">"
                if _paraList[2] == '0' then
                    _para2 = _para2 ..getLang(_paraList[1]) .. _fontColor
                else
                    _para2 = _para2 .._paraList[1] .. _fontColor
                end
            end
        end
        local _text = "<s "..v.size..">".._fontColor..getLang(v.des, _para1, _para2)

        local _richText = IFHyperlinkText:call("create", _text, cc.size(_txtWidth,0), true)
        local _richTextHeight = _richText:getContentSize().height
        
        local _nodeCell = cc.Node:create()
        local _y = (_richTextHeight + 20) / 2
        -- Dprint("RankActDesView:initView", _richTextHeight, _y, _text)
        if i % 2 == 0 then
            local _bg = CCLoadSprite:call("createScale9Sprite", "BG_danse03.png")
            _bg:setContentSize(cc.size(_viewSize.width, _richTextHeight + 20))
            _bg:setPositionY(_y)
            _nodeCell:addChild(_bg)
        end
        _richText:setPositionY(_y)
        _nodeCell:addChild(_richText)
        _mainNode:addChild(_nodeCell)
        _height = _height + _richText:getContentSize().height + 30
        _nodeCell:setPosition(cc.p(_offsetX + _txtWidth / 2, -_height))
    end

    _scrollView:addChild(_mainNode)
    _mainNode:setPosition(cc.p(0, _height))
    _mainNode:setAnchorPoint(cc.p(0, 1))
    _scrollView:setContentSize(cc.size(_viewSize.width, _height))
    _scrollView:setContentOffset(cc.p(0, _viewSize.height - _height))
	return true
end
function RankActDesView:setTitle( text )
    -- body
    self.ui.m_labelTitle:setString(text)
end

-- 点击关闭
function RankActDesView:onClickBtnClose(  )
	PopupViewController:call("removePopupView", self)
end

function RankActDesView:onTouchBegan(x, y)
	self.touchBeganX = x
	self.touchBeganY = y
	return true
end

function RankActDesView:onTouchEnded(x, y)
    if (not isTouchInside(self.ui.m_bg, self.touchBeganX, self.touchBeganY)) then
        self:onClickBtnClose()
	end
end

return RankActDesView