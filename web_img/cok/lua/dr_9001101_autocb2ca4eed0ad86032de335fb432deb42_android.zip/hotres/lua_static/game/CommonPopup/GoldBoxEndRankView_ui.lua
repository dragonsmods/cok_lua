----------------------------
-- Author: Elex
-- Date: 2017-12-20 Wednesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local GoldBoxEndRankView_ui = class("GoldBoxEndRankView_ui")

--#ui propertys


--#function
function GoldBoxEndRankView_ui:create(owner, viewType)
	local ret = GoldBoxEndRankView_ui.new()
	CustomUtility:LoadUi("GoldBoxEndRankView.ccbi", ret, owner, true, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then		owner:initTableViewByOwner()
	else		ret:initTableView()	end	return ret
end

function GoldBoxEndRankView_ui:initLang()
end

function GoldBoxEndRankView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function GoldBoxEndRankView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function GoldBoxEndRankView_ui:onClickRankBtn2(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickRankBtn2", pSender, event)
end

function GoldBoxEndRankView_ui:onClickRankBtn1(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickRankBtn1", pSender, event)
end

function GoldBoxEndRankView_ui:onclickHide(pSender, event)
	ButtonSmoker:forwardFunction(self, "onclickHide", pSender, event)
end

function GoldBoxEndRankView_ui:initTableView()
	TableViewSmoker:createView(self, "m_infoList", "game.CommonPopup.GoldBoxEndRankCell", 1, 10, "GoldBoxEndRankCell")
end

function GoldBoxEndRankView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return GoldBoxEndRankView_ui

