ItemShareCell = class("ItemShareCell",
	function()
		return cc.Layer:create()
	end
)
ItemShareCell.__index = ItemShareCell

function ItemShareCell:create(rewardType, dict)
	local view = ItemShareCell.new(dict)
	if view:initView(rewardType, dict) then
		return view
	end
	return nil
end

function ItemShareCell:initView(rewardType, dict)
	local ccbiUrl = "ItemShareCell"
	local proxy = cc.CCBProxy:create()
	local node = CCBReaderLoad(ccbiUrl, proxy, self)
	self:addChild(node)
	self:setContentSize(node:getContentSize())
	self:setData(rewardType, dict)
	return true
end

function ItemShareCell:setData(rewardType, dict)
	if rewardType == 0 then
		local _type = tonumber(dict.type)

		local bgIcon = ""
		local icon = ""
		if _type == 7 then
			local value = dict.value
			local itemId = tostring(value.id)
			local toolInfo = ToolController:call("getInstance"):call("getToolInfoByIdForLua", tonumber(itemId))

			bgIcon = CCCommonUtilsForLua:call("getToolBgByColor", toolInfo:getProperty("color"))
			icon = toolInfo:getProperty("icon") .. ".png"

			self.m_nameLabel:setString(toolInfo:call("getName"))
			self.m_numLabel:setString(tostring(value.num))
		else
			bgIcon = CCCommonUtilsForLua:call("getToolBgByColor", 4)
			icon = RewardController:call("getInstance"):call("getPicByType", _type, 0)

			local name = RewardController:call("getInstance"):call("getNameByType", _type)
			self.m_nameLabel:setString(name)
			self.m_numLabel:setString(tostring(dict.value))
		end

		self.m_iconNode:removeAllChildren()
		local bgIcon = CCLoadSprite:call("createSprite", bgIcon)
		local icon = CCLoadSprite:call("createSprite", icon)
		CCCommonUtilsForLua:call("setSpriteMaxSize", icon, 56, false)
		CCCommonUtilsForLua:call("setSpriteMaxSize", bgIcon, 56, false)
		self.m_iconNode:addChild(bgIcon)
		self.m_iconNode:addChild(icon)
	else
		self.m_iconNode:removeAllChildren()
		local icon = CCLoadSprite:call("createSprite", dict.icon .. ".png")
		CCCommonUtilsForLua:call("setSpriteMaxSize", icon, 56, false)
		self.m_iconNode:addChild(icon)

		self.m_nameLabel:setString(getLang(dict.name))
		self.m_numLabel:setString("1")
	end
end

return ItemShareCell