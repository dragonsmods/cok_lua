
--月基金奖励界面
local SuperClass = Drequire("commonView.RewardListShowView")

local MonthFundRewardView = class("MonthFundRewardView",SuperClass )

function MonthFundRewardView:initTableViewByOwner()
    local TableViewSmoker = Drequire("Editor.TableViewSmoker")
    TableViewSmoker:createView(self.ui, "m_pTableView1", "game.CommonPopup.MonthFundView.MonthFundRewardCell", 1, 5, "MonthFundRewardCell")
   
end

function MonthFundRewardView:create(param)
    local view = MonthFundRewardView.new()

    Drequire("game.CommonPopup.MonthFundView.MonthFundRewardView_ui"):create(view, 0)
    if view:initView(param) then
        return view
    end
end



return MonthFundRewardView



