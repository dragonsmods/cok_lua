
--月基金奖励cell
local SuperClass = Drequire("commonView.RewardListShowCell")
local MonthFundRewardCell = class("MonthFundRewardCell", SuperClass)
function MonthFundRewardCell:create(idx)
    local view = MonthFundRewardCell.new()
    Drequire("game.CommonPopup.MonthFundView.MonthFundRewardCell_ui"):create(view, 0)
    return view
end




return MonthFundRewardCell