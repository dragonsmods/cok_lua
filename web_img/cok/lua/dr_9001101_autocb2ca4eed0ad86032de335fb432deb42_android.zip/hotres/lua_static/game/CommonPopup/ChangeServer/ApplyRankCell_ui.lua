----------------------------
-- Author: Elex
-- Date: 2019-07-05 Friday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local ApplyRankCell_ui = class("ApplyRankCell_ui")

--#ui propertys


--#function
function ApplyRankCell_ui:create(owner, viewType, paramTable)
	local ret = ApplyRankCell_ui.new()
	CustomUtility:DoRes(7, true)
	CustomUtility:LoadUi("ApplyRankCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function ApplyRankCell_ui:initLang()
end

function ApplyRankCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function ApplyRankCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return ApplyRankCell_ui

