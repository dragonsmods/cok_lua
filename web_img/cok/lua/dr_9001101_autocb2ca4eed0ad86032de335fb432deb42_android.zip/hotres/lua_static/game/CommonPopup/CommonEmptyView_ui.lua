----------------------------
-- Author: Elex
-- Date: 2019-04-17 Wednesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CommonEmptyView_ui = class("CommonEmptyView_ui")

--#ui propertys


--#function
function CommonEmptyView_ui:create(owner, viewType, paramTable)
	local ret = CommonEmptyView_ui.new()
	CustomUtility:LoadUi("CommonEmptyView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CommonEmptyView_ui:initLang()
end

function CommonEmptyView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CommonEmptyView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CommonEmptyView_ui:onClickTip(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickTip", pSender, event)
end

return CommonEmptyView_ui

