-- @Author:fenghaibin 
-- @Date: 2020-10-20
-- @Description: 通用多级概率展示窗口CELL
local commonMultiLevelRateCell = class("commonMultiLevelRateCell", cc.TableViewCell)
local commonMultiLevelRateNode = class("commonMultiLevelRateNode", cc.Layer)
function commonMultiLevelRateCell:create(cellSize)
    local cell = commonMultiLevelRateCell.new()
    utils.getExtendClass( "Template_ui" ):create(cell,"commonMultiLevelRateCell.ccbi",0,cellSize,true)
    return cell
end

function commonMultiLevelRateCell:refreshCell( info, idx )
    if table.isNilOrEmpty(info) then
        return
    end
    self.m_info = info
    self.ui.m_headTitle:setString(info.title)
    local rwdData = info.rwdData
    local itemNum = rwdData and #rwdData or 0
    self.ui.m_subNode:setPositionY(100 + itemNum * 74)

    local sumRate = 0
    for index, reward in ipairs(rwdData) do
        if reward.value and reward.value.rate then
            sumRate = sumRate + atoi(reward.value.rate)
        end
    end
    for index, reward in ipairs(rwdData) do
        reward.sumRate = sumRate
    end

    self.ui.m_tableNode:removeAllChildren()
    for k,v in ipairs(rwdData) do
        -- local itemNode = Drequire('game.CommonPopup.RewardListRateCell').create()
        local itemNode = commonMultiLevelRateNode:create()
        itemNode:setPositionY(k * -74)
        self.ui.m_tableNode:addChild(itemNode)
        itemNode:refresh(v)
    end
end

function commonMultiLevelRateNode:create()
    local node = commonMultiLevelRateNode.new()
    utils.getExtendClass( "Template_ui" ):create(node,"commonMultiLevelRateNode.ccbi",0,nil,true,nil)
    return node
end

function commonMultiLevelRateNode:refresh( info )
    if table.isNilOrEmpty(info) then
        return
    end

    if atoi(info.type) == -1 then -- 不是道具类型
        self.ui.m_nameLabel:setString(getLang(info.value.id))
        self.ui.m_iconRoot:setVisible(false)
    else -- 道具类型
        self.ui.m_iconRoot:setVisible(true)
        LibaoCommonFunc.createRewardItemInfo(info, self.ui.m_iconNode, 55, self.ui.m_nameLabel, self.ui.m_numLabel, nil, true)
    end

    local rate = (atoi(info.value.rate) / atoi(info.sumRate)) * 100
    -- 增加自定义概率显示精度
    if info.value.precision then
        local formatStr = string.format("%%.%df", atoi(info.value.precision))
        self.ui.m_rateLabel:setString(string.format(formatStr, rate) .. "%")
    else
        self.ui.m_rateLabel:setString(string.format("%.4f", rate) .. "%")
    end

end

return commonMultiLevelRateCell