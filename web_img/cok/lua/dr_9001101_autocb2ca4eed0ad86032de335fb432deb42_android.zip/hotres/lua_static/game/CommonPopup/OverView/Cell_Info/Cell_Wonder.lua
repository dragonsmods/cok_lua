--奇迹石
local Cell_Wonder = class("Cell_Wonder",Drequire("game.CommonPopup.OverView.Cell_Info.Cell_MainFile"))
local PreviewController = require("game.CommonPopup.OverView.PreviewController")

function Cell_Wonder:create(Id)
    local ret = Cell_Wonder.new(Id)
    if ret:initBaseById(Id) then
        return ret
    end
end
function Cell_Wonder:getCellDataTbl()
    if not self:checkIsVisible() then
        return
    end
    local _id = '30711023'
    local _finishTime = -1
    local _state = -1
    local _label = ""
    local _name = ""
    local _icon = ""
    local _visible = ""
    local _cancelJump = false
	local ctl = PreviewController.getInstance()
    local serverTbl = ctl.serverDataTbl or {}
    --今日可采集的奇迹石数量
    local todayCanCollMirStoneNum = tonumber(serverTbl.todayCanCollMirStoneNum) or 0
    if todayCanCollMirStoneNum > 0 then
        _state = self.Queue_ST_WORK
        _finishTime = todayCanCollMirStoneNum
        _label = self:getDialogByIdIndex(_id,1)
    else
        _cancelJump = true
        _state = self.Queue_ST_IDLE
        _finishTime = todayCanCollMirStoneNum
        _label = self:getDialogByIdIndex(_id,3)
    end
    _name,_icon,_visible = self:getNameIconVisibleBySubId(_id)
    local cellOne = {id = _id, name = _name,icon = _icon, state = _state,param1 = _finishTime, label = _label, cancelJump = _cancelJump,cell = self}
    if _visible == "1" then
        self.CellTbl.cellMeta={cellOne}
    end
    return self.CellTbl

end

function Cell_Wonder:OnClickJump(_id,_state)
    if _id == "30711023" then
        self:jumpByTypeAndTarget(2)
    end
end

return Cell_Wonder