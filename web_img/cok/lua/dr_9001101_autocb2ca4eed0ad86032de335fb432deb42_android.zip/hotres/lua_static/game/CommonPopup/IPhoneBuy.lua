IPhoneBuyView = class("IPhoneBuyView", function()
        return PopupBaseView:create()
    end
)
IPhoneBuyView.__index = IPhoneBuyView

local view = nil;
local webVew = nil;
------------------------------------------ IPhoneBuyView Start --------------------------------------------

function IPhoneBuyView:create(param )
	view = IPhoneBuyView.new()
	if view:initView(param) == false then
		return nil
	end
  	return view
end

function IPhoneBuyView:initView(param)
	if self:init(true, 0) == false then
		MyPrint("IPhoneBuy init error")
    	return false
	end
    MyPrint("zym IPhoneBuy:initView")

	self:setHDPanelFlag(true)
    callItSelfCallFunc(LuaController, "doResourceByCommonIndex", 1, true)
	local m_bIsPad = CCCommonUtilsForLua:isIosAndroidPad()
	local  proxy = cc.CCBProxy:create()
	local ccbiURL = ""
	ccbiURL = "Lua_IPhoneBuy.ccbi"
  	self.m_bIsPad = m_bIsPad
  	local nodeccb = CCBReaderLoad(ccbiURL,proxy, self)
	if nodeccb == nil then
		MyPrint("IPhoneBuy loadccb error")
		return false
	end


local addHeight = self:call("getExtendHeight")
MyPrint("zym IPhoneBuy:initView:"..cc.Director:getInstance():getIFWinSize().width.."heih:"..cc.Director:getInstance():getIFWinSize().height.."ex:"..addHeight);
self:setContentSize(cc.Director:getInstance():getIFWinSize())
MyPrint("zym IPhoneBuy:initView:"..nodeccb:getAnchorPoint().x.."y:"..nodeccb:getAnchorPoint().y);
nodeccb:setAnchorPoint(cc.p(0,1))
--nodeccb:setPositionY(cc.Director:getInstance():getIFWinSize().height );
 --   self:setContentSize(nodeccb:getContentSize())
  	self:addChild(nodeccb)

MyPrint("zym IPhoneBuy:initView y:"..nodeccb:getPositionY().."newY:"..(cc.Director:getInstance():getIFWinSize().height-addHeight)/2);

if m_bIsPad ~= true then
  nodeccb:setPositionY( addHeight  );
end
 self.m_buildBG:setPreferredSize(cc.Director:getInstance():getIFWinSize())
--self.m_listQuest:setPositionY(self.m_listQuest:getPositionY() )
 self.m_listQuest:setContentSize(cc.size(self.m_listQuest:getContentSize().width, self.m_listQuest:getContentSize().height + addHeight))
--self.node_button:setPositionY(self.node_button:getPositionY() - addHeight)


	self.ccbNode = nodeccb
	local function onNodeEvent(event)
		if event == "enter" then
			self:onEnter()
		elseif event == "exit" then
			self:onExit()
		end
	end
  	self.ccbNode:registerScriptHandler(onNodeEvent)

  	function onTouch(eventType, x, y)  
        if eventType == "began" then  
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)  
        else  
            return self:onTouchEnded(x, y)  
        end
    end
	--[[ local touchif = tolua.cast(self,"cc.CCIFTouchNode")
    if touchif ~= nil then
        local dic1 = CCDictionary:create()
        dic1:setObject(CCBool:create(true),"1")
        touchif:comFunc("setTouchEnabled", dic1)

        MyPrint("SelectAccountView:registerScriptTouchHandler")
        touchif:registerScriptTouchHandler(onTouch)
    end
--]]
local uid =param["uid"];
local uuid = param["uuid"];
local sig = param["sig"];
local urlPath = param["path"];
local lang =param["lang"];
local pp ="http://morethan.cc/access/cokindex?uid="..uid.."&uuid="..uuid.."&sig="..sig.."&lang="..lang.."&time="..param["time"].."&token="..param["token"].."&ref="..urlPath;

MyPrint(pp);

  -- urlPath+"?uid="+uid + "&uuid=" +uuid+"&sig="sig;
  webVew = CCWebView:call("create",  cc.p(0,0), self.m_listQuest:getContentSize(), self.m_listQuest);
webVew:call("loadUrl",  pp);--"http://morethan.cc/template/wap/default/index-n.html");
--"urlPath.."?uid="..uid.."&uuid="..uuid.."&sig="..sig);



    self.m_titleTxt:setString(getLang("114040"));
    return true
end

function IPhoneBuyView:onEnter()
MyPrint("zym IPhoneBuyView:onEnter touchInside m_touchNode")
end

function IPhoneBuyView:onExit()
 webVew:call("setVisible", 0 );
MyPrint("zym IPhoneBuyView:onExit touchInside m_touchNode")
end


function IPhoneBuyView:onCloseClick()

--local m_webView = CCWebView:call("create",  cc.p(0,0), self.m_listQuest:getContentSize(), self.m_listQuest);
self = tolua.cast(self, "PopupBaseView")
self:call("closeSelf")
--self:call("closeSelf")
end

function IPhoneBuyView:onTouchBegan(x, y)

MyPrint("zym IPhoneBuyView:onTouchBegan touchInside m_touchNode")
	return true
end

function IPhoneBuyView:onTouchMoved(x, y)
MyPrint("zym IPhoneBuyView:onTouchMoved touchInside m_touchNode")
end

function IPhoneBuyView:onTouchEnded(x, y)
MyPrint("zym IPhoneBuyView:onTouchEnded touchInside m_touchNode")

end








