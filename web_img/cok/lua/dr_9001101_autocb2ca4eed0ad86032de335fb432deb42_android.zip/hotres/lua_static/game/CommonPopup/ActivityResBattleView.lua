
require("game.CommonPopup.ActivityDetailBase")

ActivityResBattleView = class("ActivityResBattleView", ActivityDetailBase, ActivityShowCellViewDelegate)
ResBattleShowCell = class("ResBattleShowCell", ActivityShowCellModel)

function ActivityResBattleView.create( id )
    MyPrint("ActivityResBattleView.create")
	local ret = ActivityResBattleView.new(id)
	if ret:initSelf() ~= true then
        MyPrint("not true !!!!!")
		ret = nil 
	end
    MyPrint("ActivityResBattleView.create end ", ret)
	return ret
end

function ActivityResBattleView:ctor( id )
	ActivityDetailBase.ctor(self, id)
end

function ActivityResBattleView:initSelf(  )
	MyPrint("ActivityResBattleView:initSelf")
	local obj = self:getObj()
	if nil == obj then
		return false
	end

	local proxy = cc.CCBProxy:create()
    local ccbiUrl = "ActivityResBattleView"
    local node = CCBReaderLoad(ccbiUrl, proxy, self)
    self:addChild(node)

    self.m_cutDownTipLabel:setColor(cc.c3b(147, 122, 92))

    CCCommonUtilsForLua:call("setButtonTitle", self.m_btn, getLang("153080"))
    local nowtime = LuaController:call("getWorldTime")
    if (nowtime >= obj:getProperty("startTime")  and nowtime < obj:getProperty("endTime")) then
    	-- 此时活动进行中
    	self.m_btn:setVisible(true)
    	self.m_cutDownTipLabel:setPositionY(175.0)
    	self.m_cutDownLabel:setPositionY(151.0)

    	self.m_listNode:setContentSize(cc.size(self.m_listNode:getContentSize().width, 175))
    	local str = getLang("153014") .. "\n"
    	local highestlv = ActivityController:call("getHighestLv")
        for i=1,highestlv do
         	str = str ..getLang("153039", tostring(i), tostring(ActivityController:call("getLeftCntByResLv", i))) .. "\n"
        end
        local labelwidgt = ActivityScrollLabelwidget.new(str, self.m_listNode:getContentSize())
		self.m_listNode:addChild(labelwidgt)

		local view = ActivityShowCellView.new(self)
		view:setTitle(getLang("153087"))
		view:reloadData()
		self.m_jumpNode:addChild(view)
        MyPrint("ActivityResBattleView:initSelf__1")
	else
		self.m_btn:setVisible(false)

        local para1 = "1"
        local para2 = tostring(ActivityController:call("getHighestLv"))
        local para3 = tostring(ActivityController:call("getFreshInterval"))
		local str = getLang("153013", para1, para2, para3)
		local labelwidgt = ActivityScrollLabelwidget.new(str, self.m_listNode:getContentSize())
		self.m_listNode:addChild(labelwidgt)
	end

	local function onNodeEvent( event )
		if event == "enter" then
			self:onEnter()
	    elseif event == "exit" then
			self:onExit()
	    end
	end
	self:registerScriptHandler(onNodeEvent)
    MyPrint("ActivityResBattleView:initSelf end")
    return true
end

function ActivityResBattleView:onClickBtn(  )
	MyPrint("ActivityResBattleView:onClickBtn")

    local idx = ActivityController:call("getBsetOneResPos")
    if idx == 0 then
        idx = WorldController:call("getIndexByPoint", WorldController:call("getInstance"):getProperty("selfPoint"))
    end

    local sceneId = SceneController:call("getCurrentSceneId")
    if sceneId == 11 then
        PopupViewController:call("forceClearAll", true)
        WorldMapView:call("instance"):call("onTouchMiniBtn")
    else
        if DynamicResourceController2:call("checkDynamicResource", "miniMapView") == true then
            AllianceManager:call("setGoToWorldType", 4)
        end
        SceneController:call("gotoScene", 11, false, true, tonumber(idx))
    end
end

-- 使用者必须重载
function ActivityResBattleView:cellCount(view)
	return 6
end

function ActivityResBattleView:createCellAtIdx(view, idx)
    MyPrint("ActivityResBattleView:createCellAtIdx", idx)
	local t = 0
	if idx == 1 then
		t = 0
	elseif idx == 2 then
		t = 1
	elseif idx == 3 then
		t = 2
	elseif idx == 4 then
		t = 3
	elseif idx == 5 then
		t = 100
	elseif idx == 6 then
		t = 200
	end

	return ResBattleShowCell.new(t)
end

function ActivityResBattleView:onEnterFrame(  )
	local obj = self:getObj()
    if nil == obj then
        return 
    end

    if obj:getProperty("type") == 28 then
        local nowTime = LuaController:call("getWorldTime")
        local maxRound = ActivityController:call("getMaxRound")
        local curRound = ActivityController:call("getCurRound")
        local curRdEndTime  = ActivityController:call("getCurRdEndTime")
        local actStartTime = obj:getProperty("startTime") 
        local actEndTime = obj:getProperty("endTime")
        local roundLastTime = ActivityController:call("getFreshInterval") * 60 * 60
        MyPrint("nowTime", nowTime)
        MyPrint("maxRound", maxRound)
        MyPrint("curRound", curRound)
        MyPrint("curRdEndTime", curRdEndTime)
        MyPrint("actStartTime", actStartTime)
        MyPrint("actEndTime", actEndTime)
        MyPrint("roundLastTime", roundLastTime)
        MyPrint("ActivityView:onEnterFrame1")
        if (nowTime < actStartTime) then
            -- // 活动还未开始
            -- // 150283    距离活动开始时间：{0}
            self.m_cutDownTipLabel:setString(getLang("150283", ""))
            self.m_cutDownLabel:setString(format_time(actStartTime - nowTime))
            return
        end
        MyPrint("ActivityView:onEnterFrame2")
        if (nowTime > actEndTime) then
            -- // 105800=活动准备中
            self.m_cutDownTipLabel:setString(getLang("105800"))
            self.m_cutDownLabel:setString("")
            return
        end
        MyPrint("ActivityView:onEnterFrame3")
        if (curRound == maxRound) then
            -- // 显示活动何时结束
            -- // 150284    距离活动结束时间：{0}
            self.m_cutDownTipLabel:setString(getLang("150284", ""))
            self.m_cutDownLabel:setString(format_time(actEndTime - nowTime))
            return
        end
        MyPrint("ActivityView:onEnterFrame4")
        if (nowTime <= curRdEndTime) then
            -- // 153037    距离下一次寸土必争活动的特殊资源田刷新还有
            self.m_cutDownTipLabel:setString(getLang("153037"))
            self.m_cutDownLabel:setString(format_time(curRdEndTime - nowTime))
            return
        end
        MyPrint("ActivityView:onEnterFrame5")
        if (nowTime > curRdEndTime) then
            if (roundLastTime == 0) then
                return
            end
            local passed = nowTime - curRdEndTime
            local passedRds = math.ceil(passed * 1.0 / roundLastTime)
            if (curRound + passedRds >= maxRound) then
                -- //此时显示距离活动结束的倒计时
                -- // 显示活动何时结束
                -- // 150284    距离活动结束时间：{0}
                self.m_cutDownTipLabel:setString(getLang("150284", ""))
                self.m_cutDownLabel:setString(format_time(actEndTime - nowTime))
            else 
                -- // 显示距离下轮活动的开启时间
                -- // 153037    距离下一次寸土必争活动的特殊资源田刷新还有
                self.m_cutDownTipLabel:setString(getLang("153037"))
                self.m_cutDownLabel:setString(format_time(passedRds * roundLastTime + curRdEndTime - nowTime))
            end
        end
        MyPrint("ActivityView:onEnterFrame6")
        return
    end
end

function ActivityResBattleView:onEnter(  )
	self:onEnterFrame()
	self.entry = tonumber(cc.Director:getInstance():getScheduler():scheduleScriptFunc(function() self:onEnterFrame() end, 0.5, false))
end

function ActivityResBattleView:onExit(  )
	cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
end







--------------------------------------------ResBattleShowCell----------------------------------
--------------------------------------------ResBattleShowCell----------------------------------
--------------------------------------------ResBattleShowCell----------------------------------

function ResBattleShowCell:ctor( t )
    
    CCLoadSprite:call("doResourceByWorldIndex", 4, true)

	self.m_type = t
	local iconStr = ResourceBattleTileBaseInfo:call("getBuildIconNameByType", self.m_type)
	local num = ActivityController:call("getLeftResCntByType", self.m_type)

	ActivityShowCellModel.ctor(self, nil, iconStr, num)

    if t < 4 then
        ActivityShowCellModel.setSprSize(self, 120)
    end

    self.startTouchPt = cc.p(0, 0)
    local function touchHandle( eventType, x, y )
        if eventType == "began" then
            return self:onTouchBegan(x, y)
        elseif eventType == "moved" then
        else
            self:onTouchEnded(x, y)
        end
    end
    self:registerScriptTouchHandler(touchHandle)
    self:setTouchEnabled(true)
    self:setSwallowsTouches(false)
end

function ResBattleShowCell:onTouchBegan( x, y )
	self.startTouchPt = cc.p(x, y)
	if isTouchInside(self.m_touchNode, x, y) then
		return true
	end
	return false
end

function ResBattleShowCell:onTouchEnded( x, y )
	if isTouchInside(self.m_touchNode, x, y) then
		local num = ActivityController:call("getLeftResCntByType", self.m_type)
		local pos = ActivityController:call("getOneResPosByType", self.m_type)
		if num > 0 and pos > 0 then
            if SceneController:call("getCurrentSceneId") == 11 then
                local point = WorldController:call("getPointByIndex", tonumber(pos))
                WorldMapView:call("gotoTilePoint", point)
            else
                SceneController:call("gotoScene", 11, false, true, tonumber(pos))
            end
	        PopupViewController:call("forceClearAll", true)
	    else
            -- 113229=现在世界上没有您想寻找的资源点或者怪物
	    	CCCommonUtilsForLua:call("flyHint", "", "", getLang("113229"))
	    end
	end
end







