--modify by yanwei
------------------------------------------ ItemGetMethodView Start --------------------------------------------
local ModifyLibaoMgrInst = require("game.LiBao.ModifyLibaoMgrV1").getInstance()
local ItemGetMethod_Cell_Height = 80
local ItemGetMethod_Cell_Width = 560

local ItemGetMethodView = class("ItemGetMethodView", function()
        return PopupBaseView:create()
    end
)
ItemGetMethodView.__index = ItemGetMethodView

function ItemGetMethodView:create(itemId, param, fromView)
	local view = ItemGetMethodView.new()
	if view:initView(itemId, param, fromView) == false then
		return nil
	end
    LiBaoController.getInstance():markViewNeedDel(view)
  	return view
end

function ItemGetMethodView:initView(itemId, param, fromView)
    MyPrint("ItemGetMethodView:initView--> ", itemId, param)
	if self:init(true, 0) == false then
		MyPrint("ItemGetMethodView init error")
    	return false
    end

    self.m_itemCountMap = {}
    self:setHDPanelFlag(true)
    self.param = param
    self.fromView = fromView
    CCLoadSprite:call("doResourceByCommonIndex", 101, true)
    local m_bIsPad = CCCommonUtilsForLua:isIosAndroidPad()
    local  proxy = cc.CCBProxy:create()
    local ccbiURL = ""
    ccbiURL = "ccbi/ItemGetMethodView.ccbi"
    self.m_bIsPad = m_bIsPad
    local nodeccb = CCBReaderLoad(ccbiURL,proxy, self)
    if nodeccb == nil then
        MyPrint("ItemGetMethodView loadccb error")
        return false
    end

    local baseScale = 1
    if m_bIsPad then
        nodeccb:setScale(2.0)
        baseScale = 2
    end
    local winSize = nodeccb:getContentSize()
    self:setContentSize(winSize)
  	self:addChild(nodeccb)

  	self.m_itemId = tostring(itemId)
  	self.m_getMethodId = ""
  	-- 读前台表获取数据
  	local tempData = CCCommonUtilsForLua:getGroupByKey("staff_get")
    if tempData == nil then
        return false
    end

    local staffGetMethodData = CCCommonUtilsForLua:getGroupByKey("staff_get_method")
    if staffGetMethodData == nil then
        return false
    end
    local staffData = nil
  	for k,v in pairs(tempData) do
        if v.item_id == nil then 
            dump(v,"nil id tempData")
        end
        if v.item_id ~= nil and string.find(v.item_id, self.m_itemId) ~= nil then
    		self.m_getMethodId = k
            staffData = v
    	end
  	end

  	if self.m_getMethodId == "" then
        MyPrint("ItemGetMethodView:find no itemId with "..self.m_itemId)
    		return false
  	end

    -- if CCCommonUtilsForLua:isFunOpenByKey("Item_GetMethod_New") then
    --     self.ItemGetMethodCell = Drequire("game.CommonPopup.ItemGetMethodCellNew")
    -- else
    --     self.ItemGetMethodCell = Drequire("game.CommonPopup.ItemGetMethodCell")
    -- end
    self.ItemGetMethodCell = Drequire("game.CommonPopup.ItemGetMethodCellNew")

    self.m_staffData = staffData

  	local method = CCCommonUtilsForLua:call("getPropByIdGroup","staff_get", self.m_getMethodId, "method")

  	local data = string.split(method, "|")
  	self.m_data = data
    self.m_titleTxt:setString(getLang("164951"))
  	local scrollView = cc.ScrollView:create()
    local goldItemShowType = nil
    local goldItemShowTypeTbl = {}
    local staffGet = false
    self.staffGet = false
    local beHasMethod = false   -- 是否有跳转方式
    if scrollView ~= nil then

        local height = 0
        local mainNode = cc.Node:create();
        for i,v in ipairs(self.m_data) do
            local methodData = staffGetMethodData[v]
            if methodData then
                methodData.itemIdWanted = self.m_itemId
                if methodData.type == "1" and methodData.para1 then
                    goldItemShowTypeTbl[#goldItemShowTypeTbl + 1] = methodData.para1
                else
                    -- 传给函数的参数处理
                    local ct,id = self:getItemCount(methodData)
                    if ct and id then
                        self.m_itemCountMap[id] = ct
                    end
                    local cell = self.ItemGetMethodCell:create(methodData, self.param, self.fromView, self.m_staffData.statistics,self)
                    mainNode:addChild(cell)
                    height = height + ItemGetMethod_Cell_Height
                    cell:setPosition(cc.p(0, 0 - height))
                    staffGet = true

                    beHasMethod = true
                end
            end
        end
        local list = self.m_infoList
        if #goldItemShowTypeTbl == 0 then 
            list = self.m_infoList
        end
        local cH = list:getContentSize().height
        scrollView:setViewSize(list:getContentSize())
        scrollView:setPosition(cc.p(0,0))
        scrollView:setScale(1.0)
        scrollView:ignoreAnchorPointForPosition(true)
        scrollView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
        scrollView:addChild(mainNode);
        mainNode:setPosition(cc.p(0, height))
        scrollView:setContentSize(CCSize(ItemGetMethod_Cell_Width,height))
        scrollView:setContentOffset(CCPoint(0, cH - height))
        list:addChild(scrollView)
        if cH > height then
            scrollView:setTouchEnabled(false)
        end
    end
    -- dump(goldItemShowType,"goldItemShowType+++")
    for _, v in pairs(goldItemShowTypeTbl) do
        local result = LiBaoController.getInstance():checkHasGoldItemByShowType(v)
        if result == false then
            dump(v, "warnning, no libao for this type+++")
        else
            if goldItemShowType then
                goldItemShowType = goldItemShowType .. "|" .. v
            else
                goldItemShowType = v
            end
        end
    end

    if beHasMethod == false and not goldItemShowType then
        -- 添加一个没有跳转数据的保护
        dump("error, method and type both nil, are you kidding+++")
        return false
    end

    -- dump(goldItemShowType,"goldItemShowType2+++")
    self.goldItemShowIndex = 1
    local defaultShowType = nil
    if goldItemShowType then
        local path = "game.LiBao.LuaGoldExchangeAdView" --上部中间可滑动的礼包
        local advNode = Drequire(path).new(goldItemShowType, nil, nil, nil, {getMethodItemId = self.m_itemId})
        self.m_advNode:addChild(advNode)
        self.m_advNode:setScale(0.77)
        defaultShowType = advNode:getShowType(self.goldItemShowIndex)
        self.m_middleAddNode = advNode
    end

    self.m_descTxt:setString(getLang(staffData.desc))

    local height = 0
    -- 显示逻辑整理
    if goldItemShowType then
        self.m_middleNode:setVisible(true)
        height = 456
    else
       -- self.m_middleNode:setVisible(false)
       self.m_descTxt:setPositionY(self.m_descTxt:getPositionY() + height)
        -- 针对单显示获取途径的地方，增大显示区域
        local offset = 140
        self.m_sprinteMoreItemsBg3:setVisible(true)
        height = height + offset
        self.m_middleNode:setVisible(false)
        self.m_descTxt:setPositionY(self.m_descTxt:getPositionY() + offset)
        local viewSize = self.m_infoList:getContentSize()
        local newSize = cc.size(viewSize.width, viewSize.height + offset+20)
        self.m_infoList:setContentSize(newSize)

        local contentSize = scrollView:getContentSize()
        scrollView:setViewSize(newSize)
        scrollView:setContentOffset(CCPoint(0, newSize.height - contentSize.height))
        self.m_infoList:addChild(scrollView)

        if newSize.height > contentSize.height then
            scrollView:setTouchEnabled(false)
        else
            scrollView:setTouchEnabled(true)
        end
    end
    -- staffGet = false
    MyPrint("ItemGetMethodView:initView staffGet is "..tostring(staffGet))
    if staffGet then
        height = height + 284
    else
        self.m_lineL2Node:setVisible(false)
        self.m_lineR2Node:setVisible(false)
    end
    self.m_bottomNode:setPositionY(0-height)
    self.m_touchNode:setContentSize(cc.size(self.m_touchNode:getContentSize().width, height))
    self.m_baseNode:setPositionY(self:getContentSize().height/2 + height/2)

    self:adjustToDefault(height)
    self.ccbNode = nodeccb
    local function onNodeEvent(event)
      	if event == "enter" then
      		  self:onEnter()
      	elseif event == "exit" then
      		  self:onExit()
      	end
    end
  	self.ccbNode:registerScriptHandler(onNodeEvent)

  	function onTouch(eventType, x, y)  
        if eventType == "began" then  
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)  
        else  
            return self:onTouchEnded(x, y)  
        end
    end
    self.m_touchLayer:setTouchEnabled(true)
    self.m_touchLayer:registerScriptTouchHandler(onTouch)
    
    -- local touchif = tolua.cast(self,"cc.CCIFTouchNode")
    -- if touchif ~= nil then
    --     local dic1 = CCDictionary:create()
    --     dic1:setObject(CCBool:create(true),"1")
    --     touchif:comFunc("setTouchEnabled", dic1)

    --     MyPrint("ItemGetMethodView:registerScriptTouchHandler")
    --     touchif:registerScriptTouchHandler(onTouch)
    -- end
    
    dump("ItemGetMethodView add more items+++")
    self.m_closeBtn:setEnabled(false)
    self.oldBottomNodePosY = self.m_bottomNode:getPositionY()
    self.staffGet = staffGet --是否有其他方式获取道具
    self.goldItemShowType = goldItemShowType
    self.m_spriteMoreItemsBot:setVisible(false)
    -- self.m_sprinteMoreItemsBg1:setVisible(false)
    -- self.m_sprinteMoreItemsBg2:setVisible(false)
    self:addLiBaoMoreItems(true, defaultShowType)

    ModifyLibaoMgrInst:tryListenPayBack()

    return true
end

--如果高度是0，则调整为默认只显示一张图
function ItemGetMethodView:adjustToDefault(height)
    if height ~= 0 then 
       return
    end
    dump(height, "ItemGetMethodView:adjustToDefault+++")
    local path = "game.LiBao.LuaGoldExchangeAdView"
    local advNode = Drequire(path).new(nil,nil,true)
    self.m_advNode:addChild(advNode)
    self.m_advNode:setScale(0.77)
    self.m_lineL2Node:setVisible(false)
    self.m_lineR2Node:setVisible(false)
    self.m_middleNode:setVisible(true)

    local newHeight = 456
    self.m_bottomNode:setPositionY(0-newHeight)
    self.m_touchNode:setContentSize(cc.size(self.m_touchNode:getContentSize().width, newHeight))
    self.m_baseNode:setPositionY(self:getContentSize().height/2 + newHeight/2)
end

--添加套餐信息
local LibaoGroupShowView = Drequire("game.LiBao.LibaoGroupShowView")
function ItemGetMethodView:addLiBaoMoreItems(bCheck, goldItemShowType)
    -- dump("addLiBaoMoreItems542+++")
    if not CCCommonUtilsForLua:isFunOpenByKey("option_package_show") then
        dump("option_package_show off+++") 
        return 
    end
    goldItemShowType = goldItemShowType or self.lastUpdateGoldItemShowType
    local index = self.goldItemShowIndex
    dump(goldItemShowType, "ItemGetMethodView:addLiBaoMoreItems+++"..index)
    if bCheck then
        if self.lastUpdateGoldItemShowType and self.lastUpdateIndex 
            and (self.lastUpdateGoldItemShowType == goldItemShowType) and (self.lastUpdateIndex == index) then 
            dump("ignore update+++")
            return
        end
    end
    self.lastUpdateGoldItemShowType = goldItemShowType
    self.lastUpdateIndex = index
    self.m_spriteMoreItemsBot:setVisible(false)
    self.m_infoListMoreItems:removeAllChildren()
    self.m_bottomNode:setPositionY(self.oldBottomNodePosY)
    if not goldItemShowType or not index then 
        dump("no goldItemShowType+++")
        return
    end

    self.groupDataTbl = {}
    local exItems = nil
    if goldItemShowType then 
        local tbl = ModifyLibaoMgrInst:getCurLiBaoMapInLua(goldItemShowType)
        -- LiBaoController.getInstance():getCurLiBaoMapInLua(goldItemShowType)
        -- dump(tbl, "ItemGetMethodView:addLiBaoMoreItems2+++")
        if (not tbl) or (#tbl < 1) or (#tbl < index) then 
            dump(index,"no li bao more items+++")
            return
        end

        local lastLibao = self.m_middleAddNode and self.m_middleAddNode.m_lastLibao and self.m_middleAddNode.m_lastLibao[1]
        local curLibao = lastLibao and ModifyLibaoMgrInst:tellIsSameGroup(lastLibao,tbl[index]) and lastLibao or tbl[index]
        self.groupDataTbl = curLibao
        local tFunc = ModifyLibaoMgrInst:getGoldItemListFunc()
        self.moreItemsData,exItems = tFunc(curLibao, true)
    end
    -- dump(self.groupDataTbl,"what items you want,you choose+++",10)
    if (not self.moreItemsData) or #(self.moreItemsData) < 1 then 
        dump("self.moreItemsData is empty+++")
        return
    end
    self.moreItemsDataTblData = {}
    for k,v in pairs(self.moreItemsData) do 
        if v.groupItemList then
            self.moreItemsDataTblData[#self.moreItemsDataTblData+1]=v
        else
            local more = {}
            more.groupItemList = {}
            table.insert(more.groupItemList, v)
            self.moreItemsDataTblData[#self.moreItemsDataTblData+1]=more
        end
    end
    if #self.moreItemsDataTblData == 0 then 
        dump("error:no data in more items?+++")
        return
    end

    -- dump(self.moreItemsDataTblData,"what item you will get in this single libao+++",10)
    local size = self.m_infoListMoreItems:getContentSize()
    local addHeight = 0
    local hasMoreGrpLiBao = self.groupDataTbl.options and self.groupDataTbl.options ~= ""
    if self.staffGet then 
        addHeight = 875 --有获取方式+礼包套餐
        local itemHeightAdded = 0
        if not hasMoreGrpLiBao then --没有“更多可选套餐”
            itemHeightAdded = 50 
        end
        self.m_bottomNode:setPositionY(-addHeight)
        self.m_infoListMoreItems:setContentSize(cc.size(size.width, 85+itemHeightAdded))
        self.m_spriteMoreItemsBot:setVisible(true)
        self.m_sprinteMoreItemsBg1:setVisible(true)
        self.m_sprinteMoreItemsBg2:setVisible(true)
        self.m_sprinteMoreItemsBg3:setVisible(true)
    else 
        addHeight = 665 --只有礼包套餐
        self.m_infoListMoreItems:setContentSize(cc.size(size.width, 150))
        self.m_infoListMoreItems:setPositionY(0)
        self.m_lineL2Node:setVisible(true)
        self.m_lineR2Node:setVisible(true)
        self.m_sprinteMoreItemsBg1:setVisible(false)
        self.m_sprinteMoreItemsBg2:setVisible(false)
        self.m_sprinteMoreItemsBg3:setVisible(false)
        self.m_bottomNode:setPositionY(-addHeight)
    end
    self.m_baseNode:setPositionY(self:getContentSize().height/2 + addHeight/2)
    self.m_touchNode:setContentSize(cc.size(self.m_touchNode:getContentSize().width, addHeight))

    local mainNode = cc.Node:create()
    local scrollView = cc.ScrollView:create()
    size = self.m_infoListMoreItems:getContentSize()
    scrollView:setViewSize(size)
    scrollView:setPosition(cc.p(0,0))
    scrollView:setScale(1.0)
    scrollView:setAnchorPoint(0,0)
    scrollView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
    -- addTestColor(scrollView)

    local  height = 0
    for k,itemData in pairs(self.moreItemsDataTblData) do 
        local cell = LibaoGroupShowView.new({
            itemData = itemData,
            cellWidth = 580,
            cellHeight = 70,
            showType = 0,
            parentNode = mainNode,
            notUseFactory = true
        })
        cell:setAnchorPoint(0.5,1)
        mainNode:addChild(cell)
        cell:setScale(0.8)
        height = height + cell.cellHeight * 0.8
        cell:setPosition(cc.p(size.width/2, 0-height))
    end
    
    scrollView:addChild(mainNode)
    mainNode:setPosition(cc.p(0, height))
    scrollView:setContentSize(CCSize(ItemGetMethod_Cell_Width,height))
    scrollView:setContentOffset(CCPoint(0, size.height - height))
    self.m_infoListMoreItems:addChild(scrollView)
    -- addTestColor(self.m_infoListMoreItems, 200)

    -- 更多组合按钮
    if hasMoreGrpLiBao then 
        local groupMoreBtn = LibaoGroupShowView.createGetMoreGroupBtn(0)    
        groupMoreBtn:setAnchorPoint(0.5,1)
        groupMoreBtn:setEnabled(true)
        groupMoreBtn:addHandleOfControlEvent(
            function(eventName,sender)
                local path = "game.LiBao.LibaoGroupMoreListView"
                local groupMoreView = Drequire(path):create(self.groupDataTbl)
                PopupViewController:addPopupView(groupMoreView)
            end, CCControlEventTouchUpInside)
        CCCommonUtilsForLua:call("setButtonTitle", groupMoreBtn, getLang("9450001"))
        self.m_infoListMoreItems:addChild(groupMoreBtn)
        groupMoreBtn:setScale(0.7)
        groupMoreBtn:setPosition(size.width/2, size.height+45)
    end
    if #(self.moreItemsData) == 1 and self.staffGet then
        scrollView:setTouchEnabled(false)
    else
        scrollView:setTouchEnabled(true)
    end
end

--刷新礼包套餐信息
function ItemGetMethodView:onRefreshLiBaoMoreItems(param)
    dump(self.goldItemShowType,"ItemGetMethodView:onRefreshLiBaoMoreItems+++")
    local show_type = ""
    if param then
        local tbl = dictToLuaTable(param)
        -- dump(tbl,"param is+++")
        if tbl and tbl.index then 
            self.goldItemShowIndex = tonumber(tbl.index)
            show_type = tbl.show_type
            -- dump(tbl.index,"recv update_li_bao_more_items_in_get_method_view+++")
        end
    end
    self:addLiBaoMoreItems(false, show_type)
end

function ItemGetMethodView:onGoldExchangeShowRefresh(  )
    self:addLiBaoMoreItems(false)
end

function ItemGetMethodView:onEnter()
    registerScriptObserver(self,self.closeSelf,"ItemGetMethodView_closeself")
    registerScriptObserver(self, self.refreshView, "ItemGetMethodView_use_refresh")
    registerScriptObserver(self, self.refreshView, "msg_refreash_tool_data")
    registerScriptObserver(self, self.onRefreshLiBaoMoreItems, "update_li_bao_more_items_in_get_method_view")
    registerScriptObserver(self, self.onGoldExchangeShowRefresh, GOLDEXCHANGE_SHOW_REFRESH)
end

function ItemGetMethodView:onExit()
    unregisterScriptObserver(self,"ItemGetMethodView_closeself")
    unregisterScriptObserver(self, "msg_refreash_tool_data")
    unregisterScriptObserver(self, "ItemGetMethodView_use_refresh")
    unregisterScriptObserver(self, "update_li_bao_more_items_in_get_method_view")
    unregisterScriptObserver(self, GOLDEXCHANGE_SHOW_REFRESH)
end

function ItemGetMethodView:onTouchBegan(x, y)
    self.touchType = 0
    if touchInside(self.m_touchNode, x, y) == false then
        self.touchType = 1
        return true
    end
    return false
end

function ItemGetMethodView:onTouchMoved(x, y)
end

function ItemGetMethodView:onTouchEnded(x, y)
  	if self.touchType == 1 and touchInside(self.m_touchNode, x, y) == false then
    		MyPrint("ItemGetMethodView:onTouchEnded touchInside m_touchNode")
            tolua.cast(self, "PopupBaseView")
    		self:call("closeSelf")
            LiBaoController.getInstance():setIsNeedRemoveMarkView(false)
  	end
end

function ItemGetMethodView:closeSelf( ... )
    -- body
    tolua.cast(self, "PopupBaseView")
    self:call("closeSelf")
end

function ItemGetMethodView:onClickClose()
end

function ItemGetMethodView:refreshView(  )
    if self.m_infoList then
        self.m_infoList:removeAllChildren(true)
    end
    local staffGetMethodData = CCCommonUtilsForLua:getGroupByKey("staff_get_method")
    if staffGetMethodData == nil then
        return false
    end
    local scrollView = cc.ScrollView:create()
    local goldItemShowType = nil
    local staffGet = false
    if scrollView ~= nil then
        scrollView:setViewSize(self.m_infoList:getContentSize())
        scrollView:setPosition(cc.p(0,0))
        scrollView:setScale(1.0)
        scrollView:ignoreAnchorPointForPosition(true)
        scrollView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)

        local cH = self.m_infoList:getContentSize().height
        local height = 0
        local mainNode = cc.Node:create();
        for i,v in ipairs(self.m_data) do
            local methodData = staffGetMethodData[v]
            if methodData then
                methodData.itemIdWanted = self.m_itemId
                if methodData.type == "1" and methodData.para1 then
                    goldItemShowType = methodData.para1
                else
                    -- 传给函数的参数处理
                    local use_when_get = self:can_use_when_get(methodData)
                    methodData.use_when_get = use_when_get
                    local cell = self.ItemGetMethodCell:create(methodData, self.param, self.fromView, self.m_staffData.statistics, self)
                    mainNode:addChild(cell)
                    local ct,id = self:getItemCount(methodData)
                    if ct and id then
                        self.m_itemCountMap[id] = ct
                    end

                    height = height + ItemGetMethod_Cell_Height
                    cell:setPosition(cc.p(0, 0 - height))
                    staffGet = true
                end
            end
        end

        scrollView:addChild(mainNode);
        mainNode:setPosition(cc.p(0, height))
        scrollView:setContentSize(CCSize(ItemGetMethod_Cell_Width,height))
        scrollView:setContentOffset(CCPoint(0, cH - height))
        self.m_infoList:addChild(scrollView)

        if cH > height then
            scrollView:setTouchEnabled(false)
        end
    end
    self.staffGet = staffGet
    self:addLiBaoMoreItems(true)
end

function ItemGetMethodView:can_use_when_get( methodData )
    
    local itemId = tonumber(methodData.para1)
    if not itemId then
        return
    end

    local toolInfo = ToolController:call("getToolInfoForLua", tonumber(itemId))
    if not toolInfo then
        return
    end

    local count = toolInfo:call("getCNT") or 0
    local prev_count = self.m_itemCountMap and self.m_itemCountMap[itemId] or 0
    if count > prev_count then
        -- 钻石直接使用
        if toolInfo:getProperty("icon") == "diamonds_box" then
            return true
        end

        -- 其它可直接使用物品
    end
end

function ItemGetMethodView:getItemCount( methodData )
    local itemId = tonumber(methodData.para1)
    if not itemId then
        return 0
    end
    local toolInfo = ToolController:call("getToolInfoForLua", tonumber(itemId))
    if not toolInfo then
        return 0
    end

    return toolInfo:call("getCNT") or 0,itemId
end

function ItemGetMethodView:handleEmpty( empty_notice_str )
    if self.m_middleAddNode then
        local showData = self.m_middleAddNode:getShowData()
        if not table.isNilOrEmpty(showData) then
            local is_empty = showData[1].id == -1
            self.m_adv_desc:setVisible(is_empty)
            self.m_infoListMoreItems:setVisible(not is_empty)
            if is_empty then
                self.m_adv_desc:setString(empty_notice_str)
            end
        end
    end
end

return ItemGetMethodView







