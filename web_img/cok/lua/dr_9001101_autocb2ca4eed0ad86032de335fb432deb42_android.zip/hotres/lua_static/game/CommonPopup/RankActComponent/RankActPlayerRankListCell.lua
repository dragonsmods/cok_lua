--玩家排名信息
local RankActPlayerRankListCell = class("RankActPlayerRankListCell",
    function ()
        return cc.Layer:create()
    end)

RankActPlayerRankListCell.__index = RankActPlayerRankListCell

local cellHeight = 92

--奖励配置
local actIdToXML = {
	['57370'] = "consume_soldier_rank|20902000;20902001;20902002", --"20902000"个人本服排名奖励   "20902001"--个人全服排名奖励
	["57563"] = "single_server_process_rank|34051000" --"20902000"个人本服排名奖励   "20902001"--个人全服排名奖励
}

--title配置
local actIdToTitle = {
	['57370'] = "182181;182183;182185",
	["57563"] = "650231"
}

function RankActPlayerRankListCell:create(viewType,viewSize)
    local view = RankActPlayerRankListCell.new()
    Drequire("game.CommonPopup.RankActComponent.RankActPlayerRankListCell_ui"):create(view,0,viewSize)
    if view:initView(viewType) then
        return view
    end
end

--type: 1:本服玩家排行  2:全服玩家排行
function RankActPlayerRankListCell:initView(type)
    CCLoadSprite:call("loadDynamicResourceByName", "AllServerRank_face")
    local function TouchEvent(eventType,x,y)
        if eventType == "began" then  
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)  
        else  
            return self:onTouchEnded(x, y)  
        end
    end
    self.ui.m_touchLayer:setTouchEnabled(true)
    self.ui.m_touchLayer:registerScriptTouchHandler(TouchEvent)
    self.ui.m_touchLayer:setSwallowsTouches(true)    
    self.m_type = type or 1
	self.m_pageIndex = 0
	self.ctl = require("game.CommonPopup.RankActComponent.RankActDataController").getInstance()
	self.actId = self.ctl.actId
	self.ui.m_tNameLabel:setString(getLang("108101")) -- 108101=领主
	self.ui.m_tPowerLabel:setString(getLang("182091")) -- 182091=本期积分
	self.ui.m_tServerLabel:setString(getLang("102139")) -- 102139=奖励

	self.m_leftTime = 0
	self:updateUI()

	self.m_curMaxRank = 0 -- 当前最大的排名
	self.m_isSearching = false -- 是否在查找排名
	self.m_searchingRank = 0 -- 要查找的排名
    self:reqData()
    return true
end
--请求界面信息
function RankActPlayerRankListCell:reqData()
	--override me
	--type: 0 服务器排行  1:本服玩家排行  2:全服玩家排行
	local params = CCDictionary:create()
	params:setObject(CCString:create(tostring(self.m_type)),"type")
	params:setObject(CCInteger:create(0),"pageOn")
	CCSafeNotificationCenter:postNotification("msg.CommonRankAct.getRankInfo",params)
end

function RankActPlayerRankListCell:onEnter()
    self:onEnterFrame(0)
	if self.entry then
		self:getScheduler():unscheduleScriptEntry(self.entry)
	end
	self.entry = tonumber(self:getScheduler():scheduleScriptFunc(function(dt)
		self:onEnterFrame(dt)
	end, 1, false))

    registerScriptObserver(self,self.getPlayerRankData,"msg.RankActPlayerRankListCell.getLocalPlayerRank")
    registerScriptObserver(self,self.rankDataFail,"RankActPlayerRankListCell.rankDataFail")
    local function onGetRewardDetailBack(ref)
		local rewardId = ""
		if ref then rewardId = ref:getCString() end
		if self.m_requestingRewardIdTab and #self.m_requestingRewardIdTab > 0 then
			for i = 1, #self.m_requestingRewardIdTab do
				if rewardId == self.m_requestingRewardIdTab[i] then
					table.remove(self.m_requestingRewardIdTab, i)
					break
				end
			end
			if #self.m_requestingRewardIdTab == 0 then
				GameController:call("removeWaitInterface")
				self:getRewardDataAndOpenView()
			end
		end
	end
	local handler = self:registerHandler(onGetRewardDetailBack)
	CCSafeNotificationCenter:registerScriptObserver(self, handler, "MSG_GET_REWARD_DETAIL_BACK")
	registerScriptObserver(self,self.closeSelf,"msg.RankActPlayerRankListCell.close")
	
end

function RankActPlayerRankListCell:onExit()
    self:getScheduler():unscheduleScriptEntry(self.entry)
    unregisterScriptObserver(self,"msg.RankActPlayerRankListCell.getLocalPlayerRank")
	unregisterScriptObserver(self,"RankActPlayerRankListCell.rankDataFail")
	unregisterScriptObserver(self,"msg.RankActPlayerRankListCell.close")
    CCSafeNotificationCenter:unregisterScriptObserver(self, "MSG_GET_REWARD_DETAIL_BACK")  
end

function RankActPlayerRankListCell:closeSelf()
	self:removeFromParent()
end

function RankActPlayerRankListCell:getPlayerRankData(params)
	
	if self.m_type == 1 then
		tab_key = "localPlayerRankData"
	else
		tab_key = "allPlayerRankData"
	end
    local tbl = self.ctl:getDataBykey(tab_key).playerRankData or {}
	-- dump(tbl, "hxq RankActPlayerRankListCell:rankDataSuccess")
	self.m_leftTime = 0
	if tbl.endTime then
		local leftTime = (tbl.endTime / 1000) - LuaController:call("getWorldTime")
		if leftTime > 0 then
			self.m_leftTime = leftTime
		end
	end
	self:updateUI()

	local rankMap = {}
	if tbl.rank then
		rankMap = tbl.rank
	elseif self.m_pageIndex == 0 then
		LuaController:flyHint("", "", getLang("138130")) -- 138130=暂无记录
	end

	-- 计算我的排名
	local myRankMap = nil
	self.myRank = 0

	local myRankIndex = 0
	if tbl.myRank then
		myRankMap = tbl.myRank
		self.myRank = tonumber(myRankMap.rank)
		for i, v in ipairs(rankMap) do
			if v.uid == myRankMap.uid then
				myRankIndex = i
				break
			end
		end
	end

	if self.m_pageIndex == 0 then
		-- 初始化界面
		if not myRankMap or (1 <= myRankIndex and myRankIndex <= 3) then
			self:initTableViewByOwner(true)

		else
			self:initTableViewByOwner(false)

			local myRankNode = Drequire("game.CommonPopup.RankActComponent.RankActPlayerRankTblCell"):create()
			self.ui.m_myRankNode:addChild(myRankNode)
			myRankMap.callback = function(x) self:onRewardButtonClick(tonumber(x)) end
			myRankMap.dataType = 0 -- 排名数据
			myRankMap.showSearch = true
			myRankMap.searchCallback = function(x) self:searchRankInfo(tonumber(x)) end
			myRankNode:refreshCell(myRankMap)

		end

		-- 前三名初始化
		local len = 3
		if #rankMap < 3 then
			len = #rankMap
		end

		for i = 1, 3 do
			self.ui["m_nameLabel" .. i]:setString("")
			self.ui["m_powerLabel" .. i]:setString("")
			self.ui["m_serverLabel" .. i]:setString("")
		end

		self._frontData = {}
		for i = 1, len do
			table.insert(self._frontData, rankMap[i])

			-- 玩家是否隐藏名字
			if rankMap[i].hideKing == "1" then
				self.ui["m_nameLabel" .. i]:setString(getLang("140473")) -- 140473=领主ID已隐藏
			else
				local str = rankMap[i].name
				if rankMap[i].allianceShortName and rankMap[i].allianceShortName ~= "" then
					str = "(" .. rankMap[i].allianceShortName .. ") " .. str
				end
				self.ui["m_nameLabel" .. i]:setString(str)
			end

			local _score = tonumber(rankMap[i].val) or 0
			self.ui["m_powerLabel" .. i]:setString(CC_CMDITOAL(rankMap[i].val))

			local str = nil
			if rankMap[i].hideKing == "1" then  -- 玩家是否隐藏联盟

			else
				str = getLang("138027") .. ": " -- 138027=王国
				if rankMap[i].serverId and rankMap[i].serverId ~= "" then
					str = str .. rankMap[i].serverId
				end
			end

			if str then
				self.ui["m_serverLabel" .. i]:setString(str)
			end

			self.ui["m_headNode" .. i]:removeAllChildren()

			local pic = rankMap[i].pic
			if not pic or pic == "0" then
				pic = "g044.png"
			else
				pic = pic .. ".png"
			end

			local head = CCLoadSprite:call("createSprite", pic)
			head:setScale(0.5)
			self.ui["m_headNode" .. i]:addChild(head)
			local picVer = tonumber(rankMap[i].picVer)
			local uid = rankMap[i].uid
			local m_headImgNode = HFHeadImgNode:call("create")
			if CCCommonUtilsForLua:call("isUseCustomPic", picVer) then
				local node = self.ui["m_headNode" .. i]
				if (CCCommonUtilsForLua:isIosAndroidPad()) then
					m_headImgNode:call("initHeadImgUrl2", node, CCCommonUtilsForLua:call("getCustomPicUrl", uid, picVer), 1.0, 68*2.4, true)
				else
					m_headImgNode:call("initHeadImgUrl2", node, CCCommonUtilsForLua:call("getCustomPicUrl", uid, picVer), 1.0, 68, true)
				end
			end		
		end

		for i = 1, len do
			table.remove(rankMap, 1)
		end
	else
		table.remove(rankMap, myRankIndex)
	end

	self.m_rankMap = self.m_rankMap or {}
	local flag = 1
	if #self.m_rankMap >= 1 then
		table.remove(self.m_rankMap, #self.m_rankMap)
		flag = 0
	end

	if #rankMap > 0 then
		-- 为 cell 添加查看奖品的回调
		for i = 1, #rankMap do
			rankMap[i].callback = function(x) self:onRewardButtonClick(tonumber(x)) end
			rankMap[i].dataType = 0 -- 排名数据
			self.m_rankMap[#self.m_rankMap + 1] = rankMap[i]
		end
		self.m_rankMap[#self.m_rankMap + 1] = {dataType = 1, getMoreRank = function()
			self:getRankData()
		end} -- 获取更多
	else
		self.m_rankMap[#self.m_rankMap + 1] = {dataType = 2} -- 没有更多数据
		if self.m_isSearching then
			self.m_searchingRank = self.m_curMaxRank
		end
	end

	local offset = self.ui.m_listTableView:getContentOffset()
	self.ui:setTableViewDataSource("m_listTableView", self.m_rankMap)
	offset.y = offset.y - cellHeight * (#rankMap + flag)
	self.ui.m_listTableView:setContentOffset(offset)

	-- 增加页数
	self.m_pageIndex = self.m_pageIndex + 1

	self.m_curMaxRank = #self.m_rankMap + 3 - 1
	if self.m_isSearching then
		if self.m_searchingRank <= self.m_curMaxRank then
			GameController:call("getInstance"):call("removeWaitInterface")
			self.m_isSearching = false
			self:jumpToSearchingRank(self.m_searchingRank)
		else
			self:getRankData()
		end
	else
		GameController:call("getInstance"):call("removeWaitInterface")
	end
end

function RankActPlayerRankListCell:rankDataFail(params)
    if self.m_isSearching then
		self.m_isSearching = false
		self:jumpToSearchingRank(self.m_curMaxRank)
	end
end

function RankActPlayerRankListCell:initTableViewByOwner(flag)
	local listSize = self.ui.m_listNode:getContentSize()
	if flag then
		listSize.height = listSize.height + cellHeight
	end
	self.ui.m_listTableView:setContentSize(listSize)
	Drequire("Editor.TableViewSmoker"):createView(self.ui, "m_listTableView", "game.CommonPopup.RankActComponent.RankActPlayerRankTblCell", 1, 10, "RankActPlayerRankTblCell")
end

function RankActPlayerRankListCell:onEnterFrame(dt)
	if self.m_leftTime > 0 then
		self.m_leftTime = self.m_leftTime - dt
		self:updateUI()
	end
end

function RankActPlayerRankListCell:updateUI()
	if self.m_leftTime > 0 then
		self.ui.m_timeLabel:setString(getLang("182043", CC_SECTOA(self.m_leftTime)))	--182043={0}后发放奖励
	else
		self.ui.m_timeLabel:setString("")
	end
end
function RankActPlayerRankListCell:onTouchBegan( x,y )
    if self:isVisible(true) and isTouchInside(self.ui.m_touchLayer,x,y) then
        return true
    end
end

function RankActPlayerRankListCell:onTouchMoved(x,y)
end

function RankActPlayerRankListCell:onTouchEnded( x,y )
    -- body
end

function RankActPlayerRankListCell:onClickPicBtn1(pSender, event)
	self:picClick(1)
end

function RankActPlayerRankListCell:onClickPicBtn2(pSender, event)
	self:picClick(2)
end

function RankActPlayerRankListCell:onClickPicBtn3(pSender, event)
	self:picClick(3)
end

function RankActPlayerRankListCell:picClick(idx)
	if self._frontData and self._frontData[idx] then
		local dict = CCDictionary:create()
		dict:setObject(CCString:create("GeneralsPopupView"), "name")
		dict:setObject(CCString:create(self._frontData[idx].uid), "uid")
		LuaController:call("openPopViewInLua", dict)
	end
end

function RankActPlayerRankListCell:onRewardButton1Click(pSender, event)
	self:onRewardButtonClick(1)
end

function RankActPlayerRankListCell:onRewardButton2Click(pSender, event)
	self:onRewardButtonClick(2)
end

function RankActPlayerRankListCell:onRewardButton3Click(pSender, event)
	self:onRewardButtonClick(3)
end

function RankActPlayerRankListCell:onRewardButtonClick(idx)
	self.m_idx = idx
	self:getRewardDataWithCheck()
end

-- 解析奖励
function RankActPlayerRankListCell:parseRewardId()
	if not self.m_rewardIdTab then
		self.m_rewardIdTab = {}
		local equipRewardId = ""		
		local xmlName
		local xmlInfo = string.split(actIdToXML[self.actId],"|") or {}		
		if xmlInfo[1] ~= "" then
			xmlName = xmlInfo[1]
			local rwdIds = string.split(xmlInfo[2],";") or {}
			if self.m_type == 1 then
				equipRewardId = rwdIds[1] or "20902000" --"20902000"个人本服排名奖励
			else
				equipRewardId = rwdIds[2] or "20902001" --"20902001"--个人全服排名奖励
			end
		else
			xmlName = "consume_soldier_rank"
		end

		local reward = CCCommonUtilsForLua:call("getPropByIdGroup", xmlName, equipRewardId, "reward")
		local rwdTab = string.split(reward, "|")
		for i = 1, #rwdTab do
			local rwdItem = string.split(rwdTab[i], ";")
			if #rwdItem >= 2 then
				local rwdIdx = string.split(rwdItem[1], "-")
				if #rwdIdx >= 2 then
					self.m_rewardIdTab[i] = {left = tonumber(rwdIdx[1]), right = tonumber(rwdIdx[2]), rewardId = rwdItem[2]}
				elseif #rwdIdx >= 1 then
					self.m_rewardIdTab[i] = {left = tonumber(rwdIdx[1]), right = tonumber(rwdIdx[1]), rewardId = rwdItem[2]}
				end
			end
		end
	end
end

-- 检查奖励数据
function RankActPlayerRankListCell:checkRewardData()
	self:parseRewardId()

	self.m_requestingRewardIdTab = {}
	for i = 1, #self.m_rewardIdTab do
		local rwd = GlobalData:call("getCachedRewardData", self.m_rewardIdTab[i].rewardId)
		local rwdData = arrayToLuaTable(rwd)
		if #rwdData == 0 then
			self.m_requestingRewardIdTab[#self.m_requestingRewardIdTab + 1] = self.m_rewardIdTab[i].rewardId
		end
	end
end

-- 获取奖励数据（没有时向服务器请求）
function RankActPlayerRankListCell:getRewardDataWithCheck()
	self:checkRewardData()

	if #self.m_requestingRewardIdTab == 0 then
		self:getRewardDataAndOpenView()
	else
		GameController:call("getInstance"):call("showWaitInterface")
		for i = 1, #self.m_requestingRewardIdTab do
			GlobalData:call("requestRewardData", self.m_requestingRewardIdTab[i])
		end
	end
end

-- 获取奖励数据并打开奖励界面
function RankActPlayerRankListCell:getRewardDataAndOpenView()
	local myRank = self.myRank or 0
	local idx = self.m_idx or 1
	local found = false
	local index = 0
	local rewardTab = {}
	if myRank > 0 then
		for i = 1, #(self.m_rewardIdTab or {}) do
			local left = self.m_rewardIdTab[i].left
			local right = self.m_rewardIdTab[i].right
			if left <= myRank and myRank <= right then
				if idx == myRank then
					found = true
					index = #rewardTab
				end

				local titleStr = getLang("221120") .. " (" .. getLang("170008") .. ": " .. myRank .. ")"
				rewardTab[#rewardTab + 1] = {type = 1000, label = titleStr}
				local rwd = GlobalData:call("getCachedRewardData", self.m_rewardIdTab[i].rewardId)
				local rwdData = arrayToLuaTable(rwd)
				for _, v in pairs(rwdData) do
					rewardTab[#rewardTab + 1] = v
				end
				break
			end
		end
	end
	for i = 1, #(self.m_rewardIdTab or {}) do
		local left = self.m_rewardIdTab[i].left
		local right = self.m_rewardIdTab[i].right
		if not found then
			if left <= idx and idx <= right then
				found = true
				index = #rewardTab
			end
		end

		local titleStr = ""
		if left ~= right then
			titleStr = getLang("221119", tostring(left), tostring(right))
		else
			titleStr = getLang("221121", tostring(left))
		end
		rewardTab[#rewardTab + 1] = {type = 1000, label = titleStr}
		local rwd = GlobalData:call("getCachedRewardData", self.m_rewardIdTab[i].rewardId)
		local rwdData = arrayToLuaTable(rwd)
		for _, v in pairs(rwdData) do
			rewardTab[#rewardTab + 1] = v
		end
	end
	local titleName
	local titleInfo = string.split(actIdToTitle[self.actId],";")	
	local dialogId
	if self.m_type == 1 then		
		dialogId = titleInfo[1] or "140460"
		titleName = getLang(dialogId) 		--140460=本服
	else
		dialogId = titleInfo[2] or "140459"
		titleName = getLang(dialogId) 		--140459=全服
	end
	local view = Drequire("game.equipment.EquipRank.EquipmentRewardView"):create(rewardTab, index, titleName)
	PopupViewController:call("addPopupView", view)
end

function RankActPlayerRankListCell:onSearchButtonClick(pSender, event)
	function callback(index)
		self:searchRankInfo(tonumber(index))
	end
	local view = Drequire("game.CommonPopup.CommonInputView"):create(getLang("221129"), callback)
	PopupViewController:call("addPopupView", view)
end

function RankActPlayerRankListCell:searchRankInfo(idx)
	local maxRank = 5000
	if self.m_type == 1 then
		tab_key = "localPlayerRankData"
	else
		tab_key = "allPlayerRankData"
	end
    local _data = self.ctl:getDataBykey(tab_key).playerRankData or {}
	
	if _data then
		if self.m_type == 1 then
			maxRank = tonumber(_data.maxLocalRank) or 5000
		else
			maxRank = tonumber(_data.maxGlobalRank) or 5000
		end
	end
	if idx <= 3 then
		idx = 3 + 1
	elseif idx > maxRank then
		idx = maxRank
	end
	if idx <= self.m_curMaxRank then
		self:jumpToSearchingRank(idx)
	else
		self.m_isSearching = true
		self.m_searchingRank = idx
		self:getRankData()
	end
end

--请求页面信息
function RankActPlayerRankListCell:getRankData()
	Dprint("hxq RankActCountryRankListCell:getRankData pageIndex = ", self.m_pageIndex)
    local params = CCDictionary:create() 
	params:setObject(CCString:create(tostring(self.m_type)),"type")
	params:setObject(CCInteger:create(self.m_pageIndex),"pageOn")
	CCSafeNotificationCenter:postNotification("msg.CommonRankAct.getRankInfo",params)
end

function RankActPlayerRankListCell:jumpToSearchingRank(idx)
	local minOffsetY = self.ui.m_listNode:getContentSize().height - self.ui.m_listTableView:getContentSize().height
	local maxOffsetY = self.ui.m_listNode:getContentSize().height
	local offsetY = minOffsetY + (idx - 3 - 1) * cellHeight
	if offsetY < minOffsetY then
		offsetY = minOffsetY
	elseif offsetY > maxOffsetY then
		offsetY = maxOffsetY
	end
	self.ui.m_listTableView:setContentOffset(cc.p(0, offsetY))
end

return RankActPlayerRankListCell