----------------------------
-- Author: Elex
-- Date: 2020-05-20 Wednesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CommonShareView_ui = class("CommonShareView_ui")

--#ui propertys


--#function
function CommonShareView_ui:create(owner, viewType, paramTable)
	local ret = CommonShareView_ui.new()
	CustomUtility:DoRes(6, true)
	CustomUtility:LoadUi("CommonShareView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CommonShareView_ui:initLang()
	LabelSmoker:setText(self.m_pLabelTTF75, "4100025")
	LabelSmoker:setText(self.m_pLabelTTF76, "140207")
	LabelSmoker:setText(self.m_popupTitleName, "107098")
end

function CommonShareView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CommonShareView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CommonShareView_ui:onVKClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onVKClick", pSender, event)
end

function CommonShareView_ui:onFbClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onFbClick", pSender, event)
end

function CommonShareView_ui:onWeixinChatClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onWeixinChatClick", pSender, event)
end

function CommonShareView_ui:onWeixinClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onWeixinClick", pSender, event)
end

function CommonShareView_ui:onWeiboClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onWeiboClick", pSender, event)
end

function CommonShareView_ui:onTwitterClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onTwitterClick", pSender, event)
end

function CommonShareView_ui:onFBMessengerClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onFBMessengerClick", pSender, event)
end

function CommonShareView_ui:onClickSavePNGBtn(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickSavePNGBtn", pSender, event)
end

function CommonShareView_ui:onPopupReturnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onPopupReturnClick", pSender, event)
end

return CommonShareView_ui

