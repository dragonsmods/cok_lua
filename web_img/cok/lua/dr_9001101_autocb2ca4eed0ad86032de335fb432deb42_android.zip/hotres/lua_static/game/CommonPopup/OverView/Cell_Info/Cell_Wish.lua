--许愿
local Cell_Wish = class("Cell_Wish",Drequire("game.CommonPopup.OverView.Cell_Info.Cell_MainFile"))
local FUN_BUILD_SACRIFICE = 428000 --许愿池

function Cell_Wish:create(Id)
    local ret = Cell_Wish.new(Id)
    if ret:initBaseById(Id) then
        return ret
    end
end
function Cell_Wish:getCellDataTbl()
    if not self:checkIsVisible() then
        return
    end
    local buildId = FunBuildController:call("getMaxLvBuildByType", FUN_BUILD_SACRIFICE)
    local _finishTime = 0
    local _id = '30711016'
    local _state = -1
    local _label = ""
    local _name = ""
    local _icon = ""
    local _visible = ""
    local _cancelJump = false
    if buildId > 0 then
        --许愿池已解锁
        local sacrificeInfo = GlobalData:call("shared"):getProperty("sacrificeInfo")
        if sacrificeInfo then           
            local canFreePray = sacrificeInfo:call("canFreePray")
            local mPrayCountFree = sacrificeInfo:getProperty("mPrayCountFree") --最大可免费许愿次数
            local mPrayCount = sacrificeInfo:getProperty("mPrayCount") --今日已经许愿次数
            if canFreePray then
                _finishTime = mPrayCountFree - mPrayCount --剩余免费次数
                _state = self.Queue_ST_WORK
                _label = self:getDialogByIdIndex(_id,1)
            else
                _cancelJump = true
                _finishTime = 0
                _state = self.Queue_ST_IDLE
                _label = self:getDialogByIdIndex(_id,3)
            end				
        end
    else
        _state = self.Queue_ST_LOCK
        _label = '2000442'--未解锁
    end
    _name,_icon,_visible = self:getNameIconVisibleBySubId(_id)
    local cellOne = { id = _id, name = _name,icon = _icon, state = _state,label = _label, param1 = _finishTime, cancelJump = _cancelJump, cell = self}
    if _visible == "1" then
        self.CellTbl.cellMeta={cellOne}
    end

    return self.CellTbl

end

function Cell_Wish:OnClickJump(_id,_state)
    if _id == "30711016" then
        if _state ~= self.Queue_ST_LOCK then
            self:jumpByTypeAndTarget(1,FUN_BUILD_SACRIFICE)
        else
            self:jumpByTypeAndTarget(1,FUN_BUILD_SACRIFICE)
        end
    end
end

return Cell_Wish