local CrossServerListView = class("CrossServerListView", 
	function() 
		return PopupBaseView:call("create") 
	end
)

function CrossServerListView:create()
    local view = CrossServerListView.new()
    Drequire("game.crossThrone.CrossServerListView_ui"):create(view, 0)
    if view:initView() then
        return view
    end
end

function CrossServerListView:initView( )
	self:setIsHDPanel(true)
	CCLoadSprite:call("loadDynamicResourceByName", "bank_new")

	local parent = self.ui.m_desScroll:getParent()
	local x, y = self.ui.m_desScroll:getPosition()
	local scrollView = cc.ScrollView:create()
	local viewSize = self.ui.m_desScroll:getContentSize()
    scrollView:setViewSize(viewSize)
    scrollView:setPosition(CCPoint(x, y))
    scrollView:setScale(1.0)
    scrollView:ignoreAnchorPointForPosition(true)
    scrollView:setDirection(1)
    scrollView:setBounceable(true)
    scrollView:setClippingToBounds(true)
    scrollView:setDelegate()
  	parent:addChild(scrollView)

	self.centerDataArr = {}
    local config = CCCommonUtilsForLua:getGroupByKey("cross_battlefield_UI")

    if CCCommonUtilsForLua:isFunOpenByKey("battlefield_UI_update") then
        -- table.insert(config, {activity_id = "57131", if_show = "1"})
        -- table.insert(config, {activity_id = "57085", if_show = "1"})
        -- table.insert(config, {activity_id = "57016", if_show = "1"})
        -- table.insert(config, {activity_id = "57193", if_show = "1"})
        -- table.insert(config, {activity_id = "57358", if_show = "1"})
        -- table.insert(config, {activity_id = "57399", if_show = "1"})

        for _, configData in pairs(config) do
            if configData.if_show == "1" and FunOpenController:isShow(string.format("act_%s", configData.activity_id)) then
                self:getDataByIdNew(configData)
            end
        end

        local csbManager = require("game.crossThrone.CrossServerBattleManager")

        table.sort(self.centerDataArr, function ( data1, data2 )
            local fight1 = csbManager:isInFight(data1.actId)
            local fight2 = csbManager:isInFight(data2.actId)
                
            if fight1 == true and fight2 == false then
                return false
            elseif fight1 == false and fight2 == true then
                return true
            else 
                local order1 = tonumber(data1.configData.order) or 1
                local order2 = tonumber(data2.configData.order) or 1
                return order1 < order2
            end
        end)
    else
        -- 进攻！边境矿脉！
        if FunOpenController:isShow("act_57131") then
            self:getDataById("57131")          -- 边境矿脉

            local obj57131 = ActivityController:call("getActObj", "57131")
            if obj57131 then
                obj57131:call("requestActivityDetail")
            end
        end
        -- 最强王国
        if FunOpenController:isShow("act_57155") then
            local obj = ActivityController:call("getActObj", "57155")
            if obj then
                self:getDataById("57155")      -- 17版王国远征
            else
                self:getDataById("57085")      -- 活动标注名字为新远征，感觉可能是相对14/15年的新远征，很老的活动
            end
        end
        -- 远古战场
        if FunOpenController:isShow("act_57007") then
            self:getDataById("57007")
        end
        -- 巨龙战役季后赛
        if FunOpenController:isShow("act_57070") then
            self:getDataById("57070")
        end
        -- 霸主争夺战 
        if FunOpenController:isShow("act_57193") then
            self:getDataById("57193")
        end
        -- 宝藏秘境
        if FunOpenController:isShow("act_57259") then
            self:getDataById("57259")
        end
        -- 杀戮战场
        self:getDataById("57284")
        -- 虚空战场
        self:getDataById("57358")
        -- 龙鼎之战
        self:getDataById("57399")

        -- 开关控制显示
        self:checkOpen()
        -- 杀戮战场
        local _obj57284 = ActivityController:call('getActObj', '57284')
        if _obj57284 then
            _obj57284:requestActivityDetail()
        end

        local _obj57193 = ActivityController:call('getActObj', '57193')
        if _obj57193 then
            _obj57193:requestActivityDetail()
        end
        
        local _obj57358 = ActivityController:call('getActObj', '57358')
        if _obj57358 then
            _obj57358:requestActivityDetail()
        end
        
        local _obj57399 = ActivityController:call('getActObj', '57399')
        if _obj57399 then
            _obj57399:requestActivityDetail()
        end

        local csbManager = require("game.crossThrone.CrossServerBattleManager")

        table.sort(self.centerDataArr, function ( data1, data2 )
            local fight1 = csbManager:isInFight(data1.actId)
            local fight2 = csbManager:isInFight(data2.actId)
                
            if fight1 == true and fight2 == false then
                return false
            elseif fight1 == false and fight2 == true then
                return true
            else 
                if data1.state ~= data2.state then
                    return data1.state > data2.state
                else
                    return data1.endTime > data2.endTime
                end
            end
        end)
    end

    local function getConfigData(actId)
    	for _, data in pairs(config) do
    		if data.activity_id == actId then
    			return data
    		end
    	end
	end
    for i,v in ipairs(self.centerDataArr) do
    	local cell = Drequire("game.crossThrone.CrossServerCenterCell"):create(v, getConfigData)
    	cell:setPosition(ccp(0, (i-1)*200))
    	scrollView:addChild(cell)
    end
    local totalHeight = #self.centerDataArr * 200
    scrollView:setContentSize(CCSize(viewSize.width, totalHeight))
    scrollView:setContentOffset(ccp(0, viewSize.height - totalHeight))
    self.m_scrollView = scrollView

    return true
end

function CrossServerListView:checkOpen()
    --神秘海域
    if CCCommonUtilsForLua:isFunOpenByKey("ek_war_main") and FunOpenController:isShow("act_57404") then
        self:getDataById("57404")

        local _obj57404 = ActivityController:call('getActObj', '57404')
        if _obj57404 then
            _obj57404:requestActivityDetail()
        end
    end
    --皇家角斗场
    if CCCommonUtilsForLua:isFunOpenByKey("ladder_switch") and FunOpenController:isShow("b_arena") then
        self:getDataById("57433")
        
        local _obj57433 = ActivityController:call("getActObj", "57433")
        if _obj57433 then
            _obj57433:requestActivityDetail()
        end 
    end
    -- 2019·梦天使大赛
    if CCCommonUtilsForLua:isFunOpenByKey("WorldCup_entrance") then
        self:getDataById("57451")
        
        local _obj57451 = ActivityController:call("getActObj", "57451")
        if _obj57451 then
            _obj57451:requestActivityDetail()
        end 
    end
    -- 商旅活动
    if CCCommonUtilsForLua:isFunOpenByKey("bodyguard") then
        self:getDataById("57473")
    end
    -- 联盟对决
    if CCCommonUtilsForLua:isFunOpenByKey("alliance_duel") then
        self:getDataById("57510")
         
        local _obj57510 = ActivityController:call("getActObj", "57510")
        if _obj57510 then
            _obj57510:requestActivityDetail()
        end 
    end
    -- CoK战队锦标赛
    if CCCommonUtilsForLua:isFunOpenByKey("wcb_on") then
        self:getDataById("57546")
        
        local _obj57451 = ActivityController:call("getActObj", "57546")
        if _obj57451 then
            _obj57451:requestActivityDetail()
        end 
    end
    -- 欢乐争霸
    if CCCommonUtilsForLua:isFunOpenByKey("wcb_free_on") and FunOpenController:isShow("act_57549") then
        self:getDataById("57549")
        
        local _obj57451 = ActivityController:call("getActObj", "57549")
        if _obj57451 then
            _obj57451:requestActivityDetail()
        end 
    end
    -- 巨龙战役
    if CCCommonUtilsForLua:isFunOpenByKey("dragon_S8") and FunOpenController:isShow("ui_dragons8") then
        self:getDataById("57016")           -- 巨龙战场
        local obj57016 = ActivityController:call("getActObj", "57016")
        if obj57016 then
            obj57016:call("requestActivityDetail")
        end
    end
    if CCCommonUtilsForLua:isFunOpenByKey("worldcup_S4") then
        self:getDataById("57160")           -- COK世界杯
        local obj57160 = ActivityController:call("getActObj", "57160")
        if obj57160 then
            obj57160:requestActivityDetail()
        end
    end
end

function CrossServerListView:onEnter(  )
	self:setTitleName(getLang("140318"))
	self.m_scrollView:setTouchEnabled(true)

	local function callback1(param) self:refreshView(param) end
	local handler1 = self:registerHandler(callback1)
	CCSafeNotificationCenter:call("registerScriptObserver", self, handler1, "MSG_DRAGON_PLAYOFF_TURNS_COMMAND_BACK")
	
	self:onEnterFrame(0)
	local function update(dt) self:onEnterFrame(dt) end 
	self.entry = tonumber(cc.Director:getInstance():getScheduler():scheduleScriptFunc(update, 1.0, false))
end

function CrossServerListView:onExit(  )
	self.m_scrollView:setTouchEnabled(false)
	CCSafeNotificationCenter:call("unregisterScriptObserver", self, "MSG_DRAGON_PLAYOFF_TURNS_COMMAND_BACK")
	cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
end

function CrossServerListView:getDataById( actId )
	local obj = ActivityController:call("getActObj", actId)
	local nowtime = tonumber(GlobalData:call("getWorldTime"))
    local endTime=0;
    local state=-1;
	local tbl= {}
    if nil ~= obj then
    	local stageObj = obj:call("getCurActivityStageAndLeftTime")
	    local case_cond = 99
	    if stageObj and stageObj.curStage then
	        case_cond = stageObj.curStage
	    end

    	local sT = tonumber(obj:getProperty("startTime"))
		local eT = tonumber(obj:getProperty("endTime"))
    	if nowtime >= sT  and nowtime < eT then
            endTime=eT
        elseif nowtime < sT then
            endTime=sT
        else
        	endTime=0
        end

        tbl.actId = actId
		tbl.state = case_cond
		tbl.endTime = endTime
		table.insert(self.centerDataArr, tbl)
	end

end

function CrossServerListView:getDataByIdNew( configData )
    local actId = configData.activity_id
    local obj = ActivityController:call("getActObj", actId)
    local nowtime = tonumber(GlobalData:call("getWorldTime"))
    local endTime=0;
    local state=-1;
    local tbl= {}
    if nil ~= obj then
        local stageObj = obj:call("getCurActivityStageAndLeftTime")
        local case_cond = 99
        if stageObj and stageObj.curStage then
            case_cond = stageObj.curStage
        end

        local sT = tonumber(obj:getProperty("startTime"))
        local eT = tonumber(obj:getProperty("endTime"))
        if nowtime >= sT  and nowtime < eT then
            endTime=eT
        elseif nowtime < sT then
            endTime=sT
        else
            endTime=0
        end

        tbl.actId = actId
        tbl.state = case_cond
        tbl.endTime = endTime
        tbl.configData = configData
        table.insert(self.centerDataArr, tbl)

        if obj.requestActivityDetail then
            obj:requestActivityDetail()
        else
            obj:call("requestActivityDetail")
        end
    end

end

function CrossServerListView:onEnterFrame(  )

end

function CrossServerListView:refreshView( params )
	local tbl = dictToLuaTable(params)
	dump(tbl, "CrossServerListView:refreshView tbl~~~")

	if tbl.state and tbl.turns then
		local state=tonumber(tbl.state) or 0
	    local turns=tonumber(tbl.turns) or 0
	    if state<2 or state>6 then
	    	local dict = CCDictionary:create()
	    	dict:setObject(CCString:create("DragonPlayoffView"), "name")
	    	LuaController:call("openPopViewInLua", dict)
	    else
	        if turns<4 then
	        	local dict = CCDictionary:create()
	    		dict:setObject(CCString:create("DragonPlayoffAgainstView"), "name")
	    		LuaController:call("openPopViewInLua", dict)
	        else
	        	local dict = CCDictionary:create()
	    		dict:setObject(CCString:create("DragonPlayoffKnockView"), "name")
	    		LuaController:call("openPopViewInLua", dict)
	        end
	    end
	end
    
end

return CrossServerListView