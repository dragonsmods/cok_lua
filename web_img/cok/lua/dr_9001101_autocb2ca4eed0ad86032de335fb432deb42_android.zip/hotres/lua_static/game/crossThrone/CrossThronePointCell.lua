-------------------------------------------- CrossThronePointCell Start --------------------------------------------
local CrossThronePointCell = class("CrossThronePointCell", cc.TableViewCell)

function CrossThronePointCell:create()
    local cell = CrossThronePointCell.new()
    Drequire("game.crossThrone.CrossThronePointCell_ui"):create(cell, 0)
    return cell
end

function CrossThronePointCell:refreshCell(info , idx)
	self.pointType = tonumber(info.pointType)
	self.boxIndex = idx + 1
	self.info = info

	self.ui.m_curPointLbl:setString(CC_CMDITOA(info.stageScore))
	self.ui.m_progress:setVisible(false)
	self.ui.m_progress:setScaleX(0)
	
	local delta = tonumber(info.curScore) - tonumber(info.beforeScore)
	local all = tonumber(info.stageScore) - tonumber(info.beforeScore)
	local scaleX = delta /  all 
	scaleX = math.min(math.max(scaleX , 0) , 1)
	self.ui.m_progress:setScaleX(scaleX)
	self.ui.m_progress:setVisible(true)

	if tonumber(info.state) == 1 then
		self.ui.m_rewardEmptySp:setVisible(true)
		self.ui.m_rewardSp:setVisible(false)
	else
		self.ui.m_rewardEmptySp:setVisible(false)
		self.ui.m_rewardSp:setVisible(true)
	end

	if CCLoadSprite:call("loadDynamicResourceByName", "crossThrone_entry") then
		local frame = CCLoadSprite:call("loadResource", "crossThroneBox01.png")
		self.ui.m_rewardSp:setSpriteFrame(frame)
		self.ui.m_rewardSp:setScale(1.0)
		
		local frame = CCLoadSprite:call("loadResource", "crossThroneBox02.png")
		self.ui.m_rewardEmptySp:setSpriteFrame(frame)
		
		if tonumber(info.curScore) >= tonumber(info.stageScore) and tonumber(info.state) == 0 then
			local frame = CCLoadSprite:call("loadResource", "crossThroneBox03.png")
			self.ui.m_rewardSp:setSpriteFrame(frame)
		end
	end
	
	self.ui.node_particle:removeAllChildren()
	if tonumber(info.curScore) >= tonumber(info.stageScore) and tonumber(info.state) == 0 then
		local particle2 = ParticleController:call("createParticle", "Feedback_1")
		particle2:setPositionType(1)
		self.ui.node_particle:addChild(particle2)
	end
end

function CrossThronePointCell:onEnter()

end

function CrossThronePointCell:onExit()

end

function CrossThronePointCell:onClickGetReward(  )
	-- if isCrossServerNow() then
	-- 	LuaController:flyHint("", "", getLang("140329"))
	-- 	return 
	-- end

	if tonumber(self.info.curScore) >= tonumber(self.info.stageScore) and tonumber(self.info.state) == 0 then
		require("game.crossThrone.CrossThroneManager"):getPointRwd(self.pointType, self.boxIndex)
	end
end

return CrossThronePointCell
-------------------------------------------- CrossThronePointCell End --------------------------------------------