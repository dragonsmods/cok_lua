local CrossThroneWorldView = class("CrossThroneWorldView",
	function()
		return PopupBaseView:create()
	end
)

local ZOOM_BOUND_LIMIT_PERCENT = 0.2
local ENTER_SIZE_EXTERN = 0.5

function CrossThroneWorldView:create()
	local view = CrossThroneWorldView.new()
	if view:initView() then
		return view
	end
end

function CrossThroneWorldView:initView()
	if self:init(true, 0) == false then
		return false
	end

	if DynamicResourceController2:call("checkDynamicResource", "crossThrone_face") == false then
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("E100091"))
		return false
	end

	self:setIsHDPanel(true)
	self:call("setOriginScale", true)
	self:call("setModelLayerDisplay", false)
	self:call("setSwallowsTouches", true)
	self:call("setNeedCheckUpperAllAtOneceListenner", true)
	self:setTouchEnabled(true)
	self:call("setViewSwallowTouch", false)

	local winSize = cc.Director:sharedDirector():getIFWinSize()
	self:setContentSize(winSize)

	CCLoadSprite:call("doResourceByWorldIndex", 2, true)
	CCLoadSprite:call("doResourceByCommonIndex", 10 , true)
	CCLoadSprite:call("loadDynamicResourceByName", "crossThrone_face")

	self.ipadLike = CCCommonUtilsForLua:isIosAndroidPad()
	self.despotCastles = {}

	self.content = cc.Node:create()
	self.content:setAnchorPoint(ccp(0.5, 0.5))
	self.content:ignoreAnchorPointForPosition(false)
	self.content:setPosition(winSize.width / 2, winSize.height / 2)
	self:addChild(self.content)

	local bg = CCLoadSprite:call("createSprite", "crossThroneWorldMap.png")
	local bgSize = bg:getContentSize()
	self.content:addChild(bg)
	bg:setTag(666)

	self.empireCastle = CCLoadSprite:call("createSprite", "crossThroneEmpire.png")
	self.empireCastle:setAnchorPoint(ccp(0.5, 0.5))
	self.empireCastle:setPosition(bgSize.width / 2, bgSize.height / 2 + 50)
	self.empireCastle:setScale(0.4)
	bg:addChild(self.empireCastle)

	local crossThroneManager = require("game.crossThrone.CrossThroneManager")
	--请求数据
	crossThroneManager:requestCrossThroneData()

	self.despotNum = crossThroneManager:getDespotNum()
	local x, y = self.empireCastle:getPosition()
	for i = 1, self.despotNum do
		local despotNode = cc.Node:create()
		local pic =  crossThroneManager:getDespotCastlePic(i)
		local offsetx, offsety = crossThroneManager:getDespotCoordinate(i) 
		local despotCastle = CCLoadSprite:call("createSprite", pic)
		despotCastle:setAnchorPoint(ccp(0.5, 0.5))
		despotCastle:setPosition(x + offsetx, y + offsety)
		despotCastle:setScale(0.6)
		despotNode:addChild(despotCastle)
		bg:addChild(despotNode)
		self.despotCastles[i] = despotCastle

		local enable = crossThroneManager:isDespotEnable(i)
		if enable then
			local despotTitleBg = CCLoadSprite:call("createScale9Sprite", "Prompt_9.png")
			despotTitleBg:setAnchorPoint(ccp(0.5, 0.5))
			despotTitleBg:setPosition(x + offsetx, y + offsety - 50)
			bg:addChild(despotTitleBg)

			local castleName = crossThroneManager:getDespotCastleName(i)
			local despotTitle = cc.Label:create()
			despotTitle:setString(castleName)
			despotTitle:setSystemFontSize(20)
			despotTitle:setColor(cc.c3b(255, 202, 94))
			despotTitle:setAnchorPoint(ccp(0.5, 0.5))
			despotTitle:setPosition(x + offsetx, y + offsety - 50)
			bg:addChild(despotTitle)

			local titleSize = despotTitle:getContentSize()
			Dprint("titleSize", titleSize.width, titleSize.height)
			despotTitleBg:setPreferredSize(cc.size( (titleSize.width + 80) * 2, (titleSize.height + 20) * 2))
			despotTitleBg:setScale(0.5)
		else
			CCCommonUtilsForLua:call("setSpriteGray", despotCastle, true)
		end
	end
	
	
	local scalex = winSize.width / bgSize.width
	local scaley = winSize.height / bgSize.height
	local minScale = scalex > scaley and scalex or scaley
	local maxScale = minScale > 1.25 and minScale or 1.25

	Dprint("winSize", winSize.width, winSize.height)
	Dprint("minScale, maxScale", minScale, maxScale)

	self.content:setScale(minScale + ENTER_SIZE_EXTERN)
	self.viewPort = HFViewport:call("create")
	self.viewPort:call("setViewPortTarget", self.content)
	self.viewPort:call("setZoomLimitationMin", minScale)
	self.viewPort:call("setZoomLimitationMax", maxScale)
	self.viewPort:call("setWorldBound", cc.rect(-bgSize.width / 2, -bgSize.height / 2, bgSize.width, bgSize.height))
	--self.viewPort:call("scrollTo", ccp(100, 0))
	--self.content:setPosition(bgSize.width / 2 - 131, 1024)
	self:addChild(self.viewPort)

	--HFViewPort setZoomLimitationMin和setZoomLimitationMax一样的时候缩放有问题,因为有个弹性缩放
	if self.ipadLike then
		self.viewPort:call("setAllowZoom", false)
		self.content:setScale(minScale)
	else
		local scaleTo = cc.ScaleTo:create(0.2, minScale)
		self.content:runAction(scaleTo)
	end

	self:addTitle()
	self:addReturnBtn()

	local touchLayer = cc.Layer:create()
	self:addChild(touchLayer)

	local function touchHandle( eventType, x, y )
		-- print("touchHandle", eventType, x, y)
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		
		else
			self:onTouchEnded(x, y)
		end
	end
	touchLayer:registerScriptTouchHandler(touchHandle)
	touchLayer:setTouchEnabled(true)
	touchLayer:setSwallowsTouches(false)

	registerNodeEventHandler(self)

	self:setTag(HFVIEWPORT_VIEW_TAG)

	return true
end

function CrossThroneWorldView:refreshView()
	local crossThroneManager = require("game.crossThrone.CrossThroneManager")

	local x, y = self.empireCastle:getPosition()
	for i = 1, self.despotNum do
		if crossThroneManager:isUserDespot(i) then
			local offsetx, offsety = crossThroneManager:getDespotCoordinate(i)
			local tip = CCLoadSprite:call("createSprite", "world_occupy_self.png") 
			tip:setPosition(ccp(x + offsetx, y + offsety + 66))
			tip:setScale(0.6)
			local bg = self.content:getChildByTag(666)
			if bg then
				bg:addChild(tip)
			end

			local timeStr, timeColor = crossThroneManager:getDespotStateTime(i)
			if timeStr and  timeColor then
				self.despotId = i

				self.stateTimeBg = CCLoadSprite:call("createScale9Sprite", "Prompt_9.png")
				self.stateTimeBg:setAnchorPoint(ccp(0.5, 0.5))
				self.stateTimeBg:setPosition(x + offsetx, y + offsety - 88)
				bg:addChild(self.stateTimeBg)

				self.stateTimeLabel = cc.Label:create()
				self.stateTimeLabel:setSystemFontSize(18)
				self.stateTimeLabel:setString(timeStr)
				self.stateTimeLabel:setColor(timeColor)
				self.stateTimeLabel:setPosition(x + offsetx, y + offsety - 88)
				bg:addChild(self.stateTimeLabel)

				local titleSize = self.stateTimeLabel:getContentSize()
				Dprint("titleSize", titleSize.width, titleSize.height)
				self.stateTimeBg:setPreferredSize(cc.size( (titleSize.width + 80) * 2, (titleSize.height + 20) * 2))
				self.stateTimeBg:setScale(0.4)

				if timeStr == "" then
					self.stateTimeBg:setVisible(false)
					self.stateTimeLabel:setVisible(false)
				else
					self.stateTimeBg:setVisible(true)
					self.stateTimeLabel:setVisible(true)
				end
			end

			break
		end
	end
end

function CrossThroneWorldView:onEnterFrame()
	if self.despotId then
		local crossThroneManager = require("game.crossThrone.CrossThroneManager")
		local timeStr = crossThroneManager:getDespotStateTime(self.despotId) 
		self.stateTimeLabel:setString(timeStr)

		local titleSize = self.stateTimeLabel:getContentSize()
		self.stateTimeBg:setPreferredSize(cc.size( (titleSize.width + 80) * 2, (titleSize.height + 20) * 2))
		self.stateTimeBg:setScale(0.4)

		if timeStr == "" then
			self.stateTimeBg:setVisible(false)
			self.stateTimeLabel:setVisible(false)
		else
			self.stateTimeBg:setVisible(true)
			self.stateTimeLabel:setVisible(true)
		end
	end
end

function CrossThroneWorldView:scheduleUpdate()
    local function updatefunc(dt) self:onEnterFrame(dt) end 
    self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(updatefunc, 1.0, false)
end

function CrossThroneWorldView:unscheduleUpdate()
    if self.entry then
        cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
        self.entry = nil
    end
end

function CrossThroneWorldView:onEnter( ... )
	UIComponent:call("showPopupView", 5)

	self:scheduleUpdate()
	local function callback1() self:refreshView() end
	local handler1 = self:registerHandler(callback1)
	CCSafeNotificationCenter:call("registerScriptObserver", self, handler1, "crossThrone.data")

	local eventDispatcher = cc.Director:sharedDirector():getEventDispatcher()
	
	local imscene = ImperialScene:call("getInstance")
	if imscene then
		imscene:call("setUnMoveScence", true)

		local viewPort = imscene:call("getHFViewport")
		if viewPort then
			eventDispatcher:pauseEventListenersForTarget(viewPort)
		end
	end

	local wrdScene = WorldMapView:call("instance")
	if wrdScene then
		wrdScene:call("setUnMoveScence", true)

		local viewPort = wrdScene:call("getHFViewport")
		if viewPort then
			eventDispatcher:pauseEventListenersForTarget(viewPort)
		end
	end
end

function CrossThroneWorldView:onExit( ... )
	self:unscheduleUpdate()
	CCSafeNotificationCenter:call("unregisterScriptObserver", self, "crossThrone.data")

	local eventDispatcher = cc.Director:sharedDirector():getEventDispatcher()
	
	local imscene = ImperialScene:call("getInstance")
	if imscene then
		imscene:call("setUnMoveScence", false)

		local viewPort = imscene:call("getHFViewport")
		if viewPort then
			eventDispatcher:resumeEventListenersForTarget(viewPort)
		end
	end

	local wrdScene = WorldMapView:call("instance")
	if wrdScene then
		wrdScene:call("setUnMoveScence", false)

		local viewPort = wrdScene:call("getHFViewport")
		if viewPort then
			eventDispatcher:resumeEventListenersForTarget(viewPort)
		end
	end
end

function CrossThroneWorldView:onTouchBegan(x, y)
	self.touchPoint = ccp(x, y)

	if isTouchInside(self.returnBtn, x, y) then
		return true
	end

	if isTouchInside(self.empireCastle, x, y) then
		return true
	end

	for i = 1, #self.despotCastles do
		local despotCastle = self.despotCastles[i]
		if isTouchInside(despotCastle, x, y) then
			return true
		end
	end

	return false
end

function CrossThroneWorldView:onTouchEnded(x, y)
	if ccpDistance(self.touchPoint, ccp(x, y)) > 20 then return end

	if isTouchInside(self.returnBtn, x, y) then
		SoundController:call("playEffects", Music_Sfx_click_button)
		PopupViewController:call("goBackPopupView")
		return
	end

	if isTouchInside(self.empireCastle, x, y) then
		Dprint("empireCastle is touched")
	end

	for i = 1, #self.despotCastles do
		local despotCastle = self.despotCastles[i]
		local enable = require("game.crossThrone.CrossThroneManager"):isDespotEnable(i)
		if isTouchInside(despotCastle, x, y) then
			if enable then
				local view = Drequire("game.crossThrone.CrossThronePopupView"):create(DESPOT_BATTLE, i)
				PopupViewController:addPopupView(view, false)
			else
				CCCommonUtilsForLua:call("flyHint", "", "", getLang("E100286"))
			end

			return
		end
	end

	if isTouchInside(self.empireCastle, x, y) then
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("E100287"))
	end
end

function CrossThroneWorldView:addTitle()
	local winSize = cc.Director:sharedDirector():getIFWinSize()
	local pos = ccp(winSize.width / 2, winSize.height - 40)
	if self.ipadLike then
		pos = ccp(winSize.width / 2, winSize.height - 80)
	end

	local sp1 = CCLoadSprite:call("createSprite", "UI-tishikuang.png")
	self:addChild(sp1)
	
	local sp2 = CCLoadSprite:call("createSprite", "UI-tishikuang.png")
	self:addChild(sp2)
	
	local sp3 = CCLoadSprite:call("createSprite", "UI-tishikuang.png")
	self:addChild(sp3)
	
	local sp4 = CCLoadSprite:call("createSprite", "UI-tishikuang.png")
	self:addChild(sp4)

	sp1:setPosition(pos)
	sp1:setFlipY(true)
	sp1:setFlipX(true)
	sp1:setAnchorPoint(ccp(1, 0))

	sp2:setPosition(pos)
	sp2:setFlipY(true)
	sp2:setAnchorPoint(ccp(0, 0))

	sp3:setPosition(pos)
	sp3:setFlipX(true)
	sp3:setAnchorPoint(ccp(1, 1))

	sp4:setPosition(pos)
	sp4:setAnchorPoint(ccp(0, 1))

	local title = cc.Label:create()
	title:setPosition(pos)
	title:setSystemFontSize(24)
	title:setColor(cc.c3b(220, 180, 90))
	title:setString(getLang("138301"))
	self:addChild(title)

	if self.ipadLike then
		title:setSystemFontSize(48)
	else
		sp1:setScale(0.45)
		sp2:setScale(0.45)
		sp3:setScale(0.45)
		sp4:setScale(0.45)
	end
end

function CrossThroneWorldView:addReturnBtn()
	self.returnBtn = CCLoadSprite:call("createSprite", "bnt_02.png")
	self:addChild(self.returnBtn)

	local btnSize = self.returnBtn:getContentSize()
	self.returnBtn:setPosition(btnSize.width / 2, 60)

	if self.ipadLike then
		self.returnBtn:setScale(2.0)
		self.returnBtn:setPosition(btnSize.width, 105)
	end

	local btnSp = CCLoadSprite:call("createSprite", "fanhui.png")
	btnSp:setPosition(self.returnBtn:getPosition())
	self:addChild(btnSp)

	if self.ipadLike then
		btnSp:setScale(2.0)
	end
end

return CrossThroneWorldView