----------------------------
-- Author: Elex
-- Date: 2017-09-14 15:37:51
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local KingOfAllServerBuffView_ui = class("KingOfAllServerBuffView_ui")

--#ui propertys


--#function
function KingOfAllServerBuffView_ui:create(owner, viewType)
	local ret = KingOfAllServerBuffView_ui.new()
	CustomUtility:LoadUi("KingOfAllServerBuffView.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function KingOfAllServerBuffView_ui:initLang()
end

function KingOfAllServerBuffView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function KingOfAllServerBuffView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return KingOfAllServerBuffView_ui

