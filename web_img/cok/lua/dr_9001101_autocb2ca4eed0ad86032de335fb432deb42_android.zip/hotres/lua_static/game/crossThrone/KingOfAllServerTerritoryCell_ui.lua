----------------------------
-- Author: Elex
-- Date: 2018-09-17 Monday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local KingOfAllServerTerritoryCell_ui = class("KingOfAllServerTerritoryCell_ui")

--#ui propertys


--#function
function KingOfAllServerTerritoryCell_ui:create(owner, viewType, paramTable)
	local ret = KingOfAllServerTerritoryCell_ui.new()
	CustomUtility:LoadUi("KingOfAllServerTerritoryCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function KingOfAllServerTerritoryCell_ui:initLang()
end

function KingOfAllServerTerritoryCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function KingOfAllServerTerritoryCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return KingOfAllServerTerritoryCell_ui

