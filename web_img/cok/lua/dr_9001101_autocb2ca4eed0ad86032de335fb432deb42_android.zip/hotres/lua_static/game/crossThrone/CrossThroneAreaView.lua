local CrossThroneAreaView = class("CrossThroneAreaView",
	function()
		return PopupBaseView:create()
	end
)

local CrossThroneAreaCell = class("CrossThroneAreaCell",
	function() 
		return cc.Layer:create() 
	end
)
CrossThroneAreaCell.__index = CrossThroneAreaCell

function CrossThroneAreaView:create(dialogId, battleType)
	local view = CrossThroneAreaView.new()
	Drequire("game.crossThrone.KingOfAllServerTerritoryView_ui"):create(view, 1)
	if view:initView(dialogId, battleType) then
		return view
	end
end

function CrossThroneAreaView:initView(dialogId, battleType)
	if self:init(true, 0) then
		self:setHDPanelFlag(true)
		--self:call("setModelLayerDisplay", false)
		self.ipadLike = CCCommonUtilsForLua:isIosAndroidPad()

		if self.ipadLike then
			self:setScale(2)
		end

		self.ctManager = require("game.crossThrone.CrossThroneManager")

		local area = ""
		if self.ctManager:isDespotServer() then
			area = self.ctManager:getDespotPropertyByKey("area")
		else

		end
		Dprint("area", area)

		if battleType == DESPOT_BATTLE then
			area = self.ctManager:getMyDespotArea()
		end

		self.m_data = {}

		local tbl = splitString(area, ";")
		for i = 1, #tbl do
			local areaStr = tbl[i]
			local areaVec = splitString(areaStr, "-")
			dump(areaVec, "areaVec")
			if #areaVec == 1 then
				self.m_data[#self.m_data + 1] = areaVec[1]
			elseif #areaVec == 2 then
				local begin = tonumber(areaVec[1])
				local endTo = tonumber(areaVec[2])
				for j = begin, endTo, 1 do
					self.m_data[#self.m_data + 1] = tostring(j)
				end
			end
		end


		local delegate = {}
	    delegate.gridAtIndex = function(tab, idx) return self:gridAtIndex(tab, idx) end
	    delegate.numberOfCellsInTableView = function(tab) return self:numberOfCellsInTableView(tab) end
	    delegate.numberOfGridsInCell = function(tab) return self:numberOfGridsInCell(tab) end
	    delegate.gridSizeForTable = function(tab, idx) return self:gridSizeForTable(tab, idx) end


	    self.m_tableView = require("game.utility.TableViewMultiCol").new(self.ui.m_listNode:getContentSize())
	    self.m_tableView:setDelegate(delegate)
	   	self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
		self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
		self.ui.m_listNode:addChild(self.m_tableView)
		self.m_tableView:reloadData()

		self.ui.m_titleLabel:setString(getLang(dialogId))

		local touchLayer = cc.Layer:create()
		self:addChild(touchLayer)

		local function touchHandle( eventType, x, y )
			if eventType == "began" then
				return self:onTouchBegan(x, y)
			elseif eventType == "moved" then
			
			else
				self:onTouchEnded(x, y)
			end
		end
		touchLayer:registerScriptTouchHandler(touchHandle)
		touchLayer:setTouchEnabled(true)
		touchLayer:setSwallowsTouches(false)

		return true
	end

	return false
end

function CrossThroneAreaView:onEnter()
	local function callback1(param) self:refreshView(param) end
	local handler1 = self:registerHandler(callback1)
	CCSafeNotificationCenter:call("registerScriptObserver", self, handler1, "crossThrone.honor")
end

function CrossThroneAreaView:onExit()
	CCSafeNotificationCenter:call("unregisterScriptObserver", self, "crossThrone.honor")
end

function CrossThroneAreaView:gridAtIndex(tabView, idx)
	if idx >= #self.m_data then return end

	local cell = tabView:dequeueGrid()

	if (cell) then
		local node = cell:getChildByTag(666)
		if node then node:setData(self.m_data[idx + 1]) end
	else
	 	local node = CrossThroneAreaCell:create(self.m_data[idx + 1])
		node:setTag(666)
		cell = cc.TableViewCell:create()
		cell:addChild(node)
	end

	return cell
end

function CrossThroneAreaView:numberOfCellsInTableView(tabView)
	return math.ceil(#self.m_data / 5)
end

function CrossThroneAreaView:numberOfGridsInCell()
	return 5
end

function CrossThroneAreaView:gridSizeForTable(tabView, idx)
	return 100, 40
end

function CrossThroneAreaView:onCloseButtonClick()
	PopupViewController:call("removePopupView", self)
end

function CrossThroneAreaView:onTouchBegan(x, y)
	self.touchPoint = ccp(x, y)
	return true
end

function CrossThroneAreaView:onTouchEnded(x, y)
	if ccpDistance(self.touchPoint, ccp(x, y)) > 20 then
		return
	end

	if not isTouchInside(self.ui.m_touchNode, x, y) then
		PopupViewController:call("removePopupView", self)
	end
end


-----------------------CrossThroneAreaCell-----------------------

function CrossThroneAreaCell:create(serverId)
	local view = CrossThroneAreaCell.new()
	require("game.crossThrone.KingOfAllServerTerritoryCell_ui"):create(view, 1)
	if view:initView(serverId) then
		return view
	end
end

function CrossThroneAreaCell:initView(serverId)
	self:setData(serverId)
	return true
end

function CrossThroneAreaCell:setData(serverId)
	self.serverId = serverId
	self.ui.m_serverLabel:setString("#" .. serverId)
end

-----------------------CrossThroneAreaCell-----------------------

return CrossThroneAreaView
