local CrossThroneBuffView = class("CrossThroneBuffView", 
	function()
		return PopupBaseView:create()
	end
)

local CrossThroneBuffCell = class("CrossThroneBuffCell",
	function()
		return cc.Layer:create()
	end
)

function CrossThroneBuffView:create(battleType)
	local view = CrossThroneBuffView.new()
	Drequire("game.crossThrone.KingOfAllServerBuffView_ui"):create(view, 0)
	if view:initView(battleType) then
		return view
	end
end

function CrossThroneBuffView:initView(battleType)
	if self:init(true, 0) == false then
		return false
	end

	self.battleType = battleType
	self:setIsHDPanel(true)

	local winSize = cc.Director:sharedDirector():getIFWinSize()
	if CCCommonUtilsForLua:isIosAndroidPad() then
		self.ui.m_topNode:setScale(2.4)
		self.ui.m_listNode:setScale(2.4)
	end

	CCLoadSprite:call("loadDynamicResourceByName", "crossThrone_face")

	local crossThroneManager = require("game.crossThrone.CrossThroneManager")
	
	if self.battleType == DESPOT_BATTLE then
		self.buffData = crossThroneManager:getDespotBuffData()	
	else
		self.buffData = crossThroneManager:getEmpireBuffData()
	end

	dump(self.buffData, "buffData")

	local addHeight = self:getExtendHeight()
	local oldSize = self.ui.m_listNode:getContentSize()
	self.ui.m_listNode:removeAllChildren()
	self.ui.m_listNode:setContentSize(cc.size(oldSize.width, oldSize.height + addHeight))
	Dprint("oldSize", oldSize.width, oldSize.height, addHeight)

	self.m_tableView = cc.TableView:create(self.ui.m_listNode:getContentSize())
	self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
	self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
	self.m_tableView:setDelegate()
	self.m_tableView:registerScriptHandler(function(tab, idx) return self:cellSizeForTable(tab, idx) end, cc.TABLECELL_SIZE_FOR_INDEX)
	self.m_tableView:registerScriptHandler(function(tab, idx) return self:tableCellAtIndex(tab, idx) end, cc.TABLECELL_SIZE_AT_INDEX)
	self.m_tableView:registerScriptHandler(function(tab) return self:numberOfCellsInTableView(tab) end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
	self.ui.m_listNode:addChild(self.m_tableView)

	return true
end

function CrossThroneBuffView:onEnter()
	if self.battleType == DESPOT_BATTLE then
		self:setTitleName(getLang("138334"))
	else
		self:setTitleName(getLang("138335"))
	end
	self.m_tableView:reloadData()
end

function CrossThroneBuffView:onExit( ... )
	-- body
end

function CrossThroneBuffView:cellSizeForTable(tabView, idx)
	return 640, 135
end

function CrossThroneBuffView:tableCellAtIndex(tabView, idx)
	if (idx >= sizen(self.buffData)) then return end

	local cell = tabView:dequeueCell()
	if cell then
		local node = cell:getChildByTag(666)
		node:setData(self.buffData[idx + 1])
	else
		cell = cc.TableViewCell:create()
		local node = CrossThroneBuffCell:create(self.buffData[idx + 1])
		node:setTag(666)
		cell:addChild(node)
	end
	
	return cell
end

function CrossThroneBuffView:numberOfCellsInTableView(tabView)
	return type(self.buffData == "table") and sizen(self.buffData) or 0
end



-------------------CrossThroneBuffCell-------------------------

function CrossThroneBuffCell:create(buffData)
	local view = CrossThroneBuffCell.new()
	Drequire("game.crossThrone.KingOfAllServerBuffCell_ui"):create(view, 1)
	if view:initNode(buffData) then
		return view
	end
end

function CrossThroneBuffCell:initNode(buffData)
	self:setData(buffData)
	return true
end

function CrossThroneBuffCell:setData(buffData)
	self.buffData = buffData

	self.ui.m_iconNode:removeAllChildren()

	local iconPath = buffData.icon .. ".png"
	local icon = CCLoadSprite:call("createSprite", iconPath, CCLoadSpriteType.CCLoadSpriteType_GOODS)
	self.ui.m_iconNode:addChild(icon)
	CCCommonUtilsForLua:call("setSpriteMaxSize", icon, 80, true)

	self.ui.m_nameLabel:setString(getLang(buffData.name))
	self.ui.m_detailLabel:setString(getLang(buffData.desc, buffData.param))
end

-------------------CrossThroneBuffCell-------------------------


return CrossThroneBuffView