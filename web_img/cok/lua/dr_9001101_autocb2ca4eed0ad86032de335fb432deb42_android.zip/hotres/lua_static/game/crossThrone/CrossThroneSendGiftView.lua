local CrossThroneSendGiftView = class("CrossThroneSendGiftView",
	function()
		return PopupBaseView:create()		
	end
)

local CrossThroneSendGiftCell = class("CrossThroneSendGiftCell",
	function()
		return cc.Layer:create()
	end
)

local MAX_CHAR_LEN = 50

function CrossThroneSendGiftView:create(rewardData, rewardConfig, kingIsMine)
	local view = CrossThroneSendGiftView.new()
	Drequire("game.crossThrone.KingOfAllServerGiftBagSetView_ui"):create(view, 1)
	if view:initView(rewardData, rewardConfig, kingIsMine) then
		return view
	end
end

function CrossThroneSendGiftView:initView(rewardData, rewardConfig, kingIsMine)
	if self:init(true, 0) == false then
		return false
	end

	self:setHDPanelFlag(true)
	self.ipadLike = CCCommonUtilsForLua:call("isIosAndroidPad")
	--self:call("setModelLayerDisplay", false)

	if self.ipadLike then
		self:setScale(2)
	end

	self.rewardData = rewardData
	self.rewardId = atoi(self.rewardData.rewardId)
	self.rewardConfig = rewardConfig
	self.kingIsMine = kingIsMine
	dump(self.rewardData, "CrossThroneSendGiftView")
	self.m_data = self.rewardData.player or {}

	self.ctManager = require("game.crossThrone.CrossThroneManager")

	if self.ctManager:isDespotServer() then
		self.battleType = DESPOT_BATTLE
	else
		self.battleType = EMPIRE_BATTLE
	end

	self.ui.m_listNode:removeAllChildren()
	self.m_tableView = cc.TableView:create(self.ui.m_listNode:getContentSize())
	self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
	self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
	self.m_tableView:setDelegate()
	self.m_tableView:registerScriptHandler(function(tab, idx) return self:cellSizeForTable(tab, idx) end, cc.TABLECELL_SIZE_FOR_INDEX)
	self.m_tableView:registerScriptHandler(function(tab, idx) return self:tableCellAtIndex(tab, idx) end, cc.TABLECELL_SIZE_AT_INDEX)
	self.m_tableView:registerScriptHandler(function(tab) return self:numberOfCellsInTableView(tab) end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
	self.ui.m_listNode:addChild(self.m_tableView)
	self.m_tableView:reloadData()

	self.ui.m_titleLabel:setString(getLang(rewardConfig.name))
	self.ui.m_desLabel1:setString(getLang(rewardConfig.des))
	self.ui.m_desLabel2:setString(getLang("138363"))

	self.ui.m_kingdomLabel:setString(getLang("138027"))
	self.ui.m_nameLabel:setString(getLang("170009")) 

 	-- 服务器输入框
    local editSize = self.ui.m_inputNode1:getContentSize()
    local editpic = CCLoadSprite:call("createScale9Sprite","01_24.png")
    editpic:setContentSize(editSize)
    editpic:setInsetBottom(10)
    editpic:setInsetTop(10)
    editpic:setInsetRight(10)
    editpic:setInsetLeft(10)
    self.m_serverEditBox = CCEditBox:create(editSize,editpic)
    self.m_serverEditBox:setInputMode(cc.EDITBOX_INPUT_MODE_NUMERIC)
    self.m_serverEditBox:setText(getLang(""))
    self.m_serverEditBox:setMaxLength(5)
    self.m_serverEditBox:setReturnType(cc.KEYBOARD_RETURNTYPE_DONE)
    self.m_serverEditBox:setPosition(ccp(editSize.width/2, editSize.height/2))
    self.m_serverEditBox:setFontColor(cc.c3b(34, 23, 7))
    self.m_serverEditBox:setFontSize(20)
    self.ui.m_inputNode1:addChild(self.m_serverEditBox)

    local function editCB (strEventName,pSender)
        if tostring(pSender) == "began" then
            --光标进入，选中全部内容
            -- print("self.m_editOpen = true")
            self.m_editOpen = true
        elseif tostring(pSender) == "ended" then
            -- 当编辑框失去焦点并且键盘消失的时候被调用
        elseif tostring(pSender) == "return" then
            -- 当用户点击编辑框的键盘以外的区域，或者键盘的Return按钮被点击时所调用
            --self:editBoxReturn(self.m_serverEditBox:getText())         
        elseif tostring(pSender) == "changed" then
            -- 输入内容改变时调用
            self:editBoxTextChanged(self.m_serverEditBox:getText())     
        end
    end
    self.m_serverEditBox:registerScriptEditBoxHandler(editCB) --输入框的事件，主要有光标移进去，光标移出来，以及输入内容改变等

	local editSize = self.ui.m_inputNode2:getContentSize()
	self.m_editNameBox = InputFieldMultiLine:call("create", editSize, "01_24.png", 27)
	self.m_editNameBox:call("setAddH", 5)
	self.m_editNameBox:call("setMaxChars", MAX_CHAR_LEN) 
	self.m_editNameBox:call("setLineNumber", 1)
	self.m_editNameBox:call("setFontColor", ccBLACK)	
	self.m_editNameBox:call("setSwallowsTouches", true)
	self.m_editNameBox:call("setMoveFlag", true)
	self.m_editNameBox:call("setcalCharLen", true)
	self.m_editNameBox:call("setOnlySingleLine", true)
	--self.m_editNameBox:call("setPlaceHolder", getLang("114056"))
	self.m_editNameBox:setPosition(ccp(0, 0))
	self.m_editNameBox:setAnchorPoint(ccp(0, 0))
	self.ui.m_inputNode2:addChild(self.m_editNameBox)

	local restNum = atoi(rewardConfig.limit) - sizen(rewardData.player or {})
	self.ui.m_okBtn:setEnabled(self.kingIsMine and restNum > 0)

	if self.kingIsMine == false then
		self.ui.m_middleNode:setVisible(false)
		self.ui.m_bottomNode:setPositionY(-182)
		self.ui.m_playerNode:setVisible(false)
		self.ui.m_okBtn:setVisible(false)

		local size = self.ui.m_touchNode:getContentSize()
		self.ui.m_touchNode:setContentSize(cc.size(size.width, size.height - 182))
	end

	if sizen(self.m_data) == 0 then
		self.ui.m_nobodyLabel:setString(getLang("138470"))
	end

	CCCommonUtilsForLua:setButtonTitle(self.ui.m_okBtn, getLang("confirm"))

	local touchLayer = cc.Layer:create()
	self:addChild(touchLayer)

	local function touchHandle( eventType, x, y )
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		
		else
			self:onTouchEnded(x, y)
		end
	end
	touchLayer:registerScriptTouchHandler(touchHandle)
	touchLayer:setTouchEnabled(true)
	touchLayer:setSwallowsTouches(false)

	return true
end

function CrossThroneSendGiftView:editBoxTextChanged(text)
	self.m_serverEditBox:setFontColor(cc.c3b(34, 23, 7))
    local temp = ""
    for s in string.gmatch(text, "%d") do
        temp = temp .. s
    end
    self.m_serverEditBox:setText(temp)
end

function CrossThroneSendGiftView:onInputFieldCloseEvent(param)
	
end

function CrossThroneSendGiftView:sendGiftSuccess(pObj)
	if pObj then
		PopupViewController:call("removePopupView", self)
	end
end

function CrossThroneSendGiftView:removeWaitInterface()
	if self.waitInterface then
		self.waitInterface:call("remove")
		self.waitInterface = nil
	end
end

function CrossThroneSendGiftView:onEnter( ... )
	local function callback1(pObj) self:onInputFieldCloseEvent(pObj) end
	local handler1 = self:registerHandler(callback1)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, INPUTFIELD_CLOSE_EVENT)

	local function callback2(pObj) self:sendGiftSuccess(pObj) end
	local handler2 = self:registerHandler(callback2)
	CCSafeNotificationCenter:registerScriptObserver(self, handler2, "crossthrone.sendGift")

	local function callback3() self:removeWaitInterface() end
	local handler3 = self:registerHandler(callback3)
	CCSafeNotificationCenter:call("registerScriptObserver", self, handler3, "crossThrone.removeWait")
end

function CrossThroneSendGiftView:onExit( ... )
	CCSafeNotificationCenter:unregisterScriptObserver(self, INPUTFIELD_CLOSE_EVENT)
	CCSafeNotificationCenter:unregisterScriptObserver(self, "crossthrone.sendGift")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "crossthrone.removeWait")
end

function CrossThroneSendGiftView:cellSizeForTable(tabView, idx)
	return 480, 24
end

function CrossThroneSendGiftView:tableCellAtIndex( tabView, idx )
	if (idx >= #self.m_data) then return end

	local cell = tabView:dequeueCell()
	if cell then
		local node = cell:getChildByTag(666)
		node:setData(self.m_data[idx + 1])
	else
		cell = cc.TableViewCell:create()
		local node = CrossThroneSendGiftCell:create(self.m_data[idx + 1])
		node:setTag(666)
		cell:addChild(node)
	end
	
	return cell
end

function CrossThroneSendGiftView:numberOfCellsInTableView(tabView)
	return #self.m_data
end

function CrossThroneSendGiftView:onOkBtnClick()
	self.m_editNameBox:call("closeIME")
	local serverId = tonumber(self.m_serverEditBox:getText()) or 0
	local name = self.m_editNameBox:call("getText")
	if serverId == 0 or name == "" then
		--CCCommonUtilsForLua:call("flyHint", "", "", getLang(""))
	else
		local function confirm( ... )
			self.waitInterface = GameController:call("showWaitInterface1", self.ui.m_okBtn)
			local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
			local currentServerId = playerInfo:getProperty("currentServerId")
			self.ctManager:giveGift2Someone(self.battleType, currentServerId, PERSONLY_GIFT, atoi(self.rewardId), serverId, name)
		end
		
		Dprint("self.battleType, self.rewardId, serverId, name", self.battleType, atoi(self.rewardId), serverId, name)
		YesNoDialog:show(getLang("138366", tostring(serverId), name, getLang(self.rewardConfig.name)), confirm)
	end
end

function CrossThroneSendGiftView:onTouchBegan(x, y)
	self.touchPoint = ccp(x, y)
	return true
end

function CrossThroneSendGiftView:onTouchEnded(x, y)
	if ccpDistance(self.touchPoint, ccp(x, y)) > 20 then
		return
	end

	if not isTouchInside(self.ui.m_touchNode, x, y) then
		PopupViewController:call("removePopupView", self)
	end
end

----------------------CrossThroneSendGiftCell----------------------

function CrossThroneSendGiftCell:create(playerData)
	local view = CrossThroneSendGiftCell.new()
	Drequire("game.crossThrone.KingOfAllServerAwardSetCell_ui"):create(view, 1)
	if view:initView(playerData) then
		return view
	end
end

function CrossThroneSendGiftCell:initView(playerData)
	self:setData(playerData)

	return true
end

function CrossThroneSendGiftCell:setData(playerData)
	self.playerData = playerData

	local nameStr = ""
	if playerData.kingdom ~= "" then
		nameStr = nameStr .. "#" .. playerData.kingdom
	end

	if playerData.abbr ~= "" then
		nameStr = nameStr .. "(" .. playerData.abbr .. ")"
	end

	nameStr = nameStr .. playerData.name

	self.ui.m_nameLabel:setString(nameStr)

end
----------------------CrossThroneSendGiftCell----------------------

return CrossThroneSendGiftView