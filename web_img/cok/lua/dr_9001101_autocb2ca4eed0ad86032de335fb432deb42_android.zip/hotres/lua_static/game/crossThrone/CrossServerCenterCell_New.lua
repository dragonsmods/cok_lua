local LibaoCommonFunc = require("game.LiBao.LibaoCommonFunc")

local CrossServerCenterCell_New = class("CrossServerCenterCell_New", function()
    return cc.Layer:create()
end)


local totalStars = 5

local Door_Color_Path = {
    [ActivityStage.ActivityStage_Running] = "BG_csm_door_pvp_dead",
    [ActivityStage.ActivityStage_Comming] = "BG_csm_door_pve",
    [ActivityStage.ActivityStage_Preparing] = "BG_csm_door_pvp_alive",
}

function CrossServerCenterCell_New:create(data)
    local ret = CrossServerCenterCell_New.new()
    Drequire("game.crossThrone.CrossServerCenterCell_New_ui"):create(ret)
    local function onTouch(eventType, x, y)  
        if eventType == "began" then  
            return ret:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return ret:onTouchMoved(x, y)  
        else  
            return ret:onTouchEnded(x, y)  
        end
    end
    ret:setTouchEnabled(true)
    ret:registerScriptTouchHandler(onTouch)
    ret:setSwallowsTouches(false)

    if ret:initData(data) then
        ret:refreshCell(data)
    end

    return ret
end

function CrossServerCenterCell_New:initData(data)
    self.m_id = data.actId
    self.m_configData = data.configData
    self._stage = 0
    self.eventObj = nil
    local obj = ActivityController:call("getInstance"):call("getActObj", self.m_id)
    if (not obj) then
        return false
    end
    self.eventObj = obj

    return true
end

function CrossServerCenterCell_New:refreshCell(info)
    local obj = self.eventObj
    self.ui.m_nameLabel:setString(obj:getProperty("name"))
    self.ui.m_iconNode:removeAllChildren()

    local sf = obj:getIconFrame()
    local iconSpr = nil
    if (sf) then
        iconSpr = cc.Sprite:createWithSpriteFrame(sf)
        self.ui.m_iconNode:addChild(iconSpr)
    else
        iconSpr = CCLoadSprite:createSprite("Ativity_iconLogo_1.png")
        self.ui.m_iconNode:addChild(iconSpr)
    end
    CCCommonUtilsForLua:call("setSpriteMaxSize", iconSpr, 94, true)

    self.ui.m_moreLabel:setString(getLang("102162"))

    self.ui.m_getLabel:setString(getLang("101303"))
    self.ui.m_getLabel:setVisible(true)
    self.ui.m_starLabel:setString(getLang("138573"))
    self.ui.m_starLabel:setVisible(true)
    self.ui.m_descNode:setVisible(false)
    self.ui.m_iconListNode:removeAllChildren()
    self.ui.m_iconListNode:setPositionX(self.ui.m_getLabel:getPositionX() + self.ui.m_getLabel:getContentSize().width + 20)
    self.ui.m_starListNode:removeAllChildren()
    self.ui.m_starListNode:setPositionX(self.ui.m_starLabel:getPositionX() + self.ui.m_starLabel:getContentSize().width)

    local configData = info.configData
    if configData then
        local stars = atoi(configData.reward_star)
        for index = 1, stars do
            local star = CCLoadSprite:createSprite("ICON_xingxing01.png")
            local particle1 = ParticleController:call("createParticle", "UIGlowLoop_1")
            local particle2 = ParticleController:call("createParticle", "UIGlowLoop_2")
            star:setPosition(index * 50, 15)
            particle1:setPosition(index * 50, 15)
            particle2:setPosition(index * 50, 15)
            self.ui.m_starListNode:addChild(star)
            self.ui.m_starListNode:addChild(particle1)
            self.ui.m_starListNode:addChild(particle2)
        end
        self.ui.m_starListNode:setScale(0.8)

        self.icon_dec = configData.icon_dec
        self.reward_star = configData.reward_star
        self.reward_show = configData.reward_show
        self.reward_dec = configData.reward_dec

        if configData.icon_BG and configData.type_icon then
            local x, y = self.ui.m_nameLabel:getPosition()
            
            local bgIcon = CCLoadSprite:createSprite(string.format("%s.png", configData.icon_BG))
            bgIcon:setScale(0.6)
            self.ui.m_typeNode:addChild(bgIcon)

            self.typeIcon = CCLoadSprite:createSprite(string.format("%s.png", configData.type_icon))
            self.ui.m_typeNode:addChild(self.typeIcon)
        end
    else
        self.ui.m_starLabel:setVisible(false)
        self.ui.m_moreNode:setVisible(false)
    end


    if self.iconlist_size == nil then 
        self.iconlist_size = self.ui.m_iconListNode:getContentSize()
    else
        self.ui.m_iconListNode:setContentSize( self.iconlist_size)
    end

    local rewardIds = obj:getProperty("rewardIds")
    local iconSize = 40
    if #rewardIds > 0 then
        for i = 1, 3 do
            if rewardIds[i] then
                local itemData = {
                    type = 0,
                    itemId = rewardIds[i],
                    num = 1
                }
                local icon_node = CCNode:create()
                LibaoCommonFunc.createItemInfoShow(itemData, icon_node, iconSize,nil,nil,nil,true,self.ui.m_iconListNode)
                self.ui.m_iconListNode:addChild(icon_node)
                icon_node:setPosition(cc.p((iconSize + 10) * (i - 1) + iconSize/2,iconSize/2))

                local bg = icon_node:getChildByTag(GOODS_BG_TAG)
                if bg then
                    local color = CCCommonUtilsForLua:call("getPropById", tostring(rewardIds[i]), "color")
                    local bgPath = getItemBgByColor(atoi(color))
                    bg:setSpriteFrame(CCLoadSprite:call("loadResource", bgPath))
                end

                local icon_bg = CCLoadSprite:call("createSprite", "BG_zhuangbeiwaikuang.png")
                icon_bg:setScale(0.48)
                icon_node:addChild(icon_bg)
            end
        end

        local displayCnt = (#rewardIds > 3) and 3 or #rewardIds
        self.ui.m_moreNode:setVisible(true)
        self.ui.m_moreNode:setPositionX(self.ui.m_iconListNode:getPositionX() + iconSize*displayCnt + displayCnt*10)
    else
        self.ui.m_moreNode:setVisible(false)
        self.ui.m_iconListNode:setContentSize(CCSize(0,0))
        self.ui.m_getLabel:setVisible(false)
    end

    if CCLoadSprite:call("loadDynamicResourceByName", "bank_new") then
        local BG_csm_title_1 = CCLoadSprite:createSprite("BG_csm_title_1.png")
        self.ui.m_decNode2:addChild(BG_csm_title_1)
        local BG_csm_title_2 = CCLoadSprite:createSprite("BG_csm_title_2.png")
        self.ui.m_decNode1:addChild(BG_csm_title_2)

        if require("game.crossThrone.CrossServerBattleManager"):isInFight(self.m_id) then 
            self:adBattleFireParticle() 
        end
    end
       
    self:update(0)

end

function CrossServerCenterCell_New:adBattleFireParticle()
    local sp = CCLoadSprite:createSprite("BG_csm_fire.png")
    --保护
    if sp:getContentSize().width > 10 then
        local x, y = self.ui.m_bg:getPosition()
        local size = self.ui.m_bg:getContentSize()
        local bg = CCLoadSprite:call("createScale9Sprite", "BG_csm_fire.png")
        bg:setContentSize(cc.size(size.width + 36, size.height + 36))
        bg:setPosition(x, y)
        self.ui.m_fireBgNode:addChild(bg)

        local path = cc.FileUtils:getInstance():getWritablePath() .. "dresource/CSBEffect/"
        local format = path .. "zcfire_%d"
        for index = 1, 16 do 
            if self.ui["m_fireNode" .. index] then
                local path = string.format(format , index)
                local par = ParticleController:call("createParticleForLua", path)
                self.ui["m_fireNode" .. index]:addChild(par)
            end
        end
    end
end

function CrossServerCenterCell_New:adDoorParticle()
    local childrenCount = self.ui.m_p2Node:getChildrenCount()
    Dprint("childrenCount", childrenCount)
    if childrenCount > 0 then return end

    if CCLoadSprite:call("loadDynamicResourceByName", "bank_new") then
        local particleTypeName = "xuanwo_1_"

        if ActivityStage.ActivityStage_Preparing == self._stage then
            particleTypeName = "xuanwo_1_"
        elseif ActivityStage.ActivityStage_Comming == self._stage then
            particleTypeName = "xuanwo_2_"
        elseif ActivityStage.ActivityStage_Running == self._stage then
            particleTypeName = "xuanwo_3_"
        end

        for i = 1, 2 do
            local particle = ParticleController:call("createParticle", particleTypeName .. i)
            self.ui.m_p1Node:addChild(particle)
        end
        local particle = ParticleController:call("createParticle", particleTypeName .. "6")
        self.ui.m_p2Node:addChild(particle)
    end
end

function CrossServerCenterCell_New:rmDoorParticle()
    self.ui.m_p1Node:removeAllChildren()
    self.ui.m_p2Node:removeAllChildren()
end

function CrossServerCenterCell_New:update(dt)
    local eventObj = ActivityController:call("getInstance"):call("getActObj", self.m_id)
	if eventObj == nil then return end

    local stageObj = eventObj:call("getCurActivityStageAndLeftTime")

    if stageObj and stageObj.curStage then
        --状态改变时切换状态
        if stageObj.curStage ~= self._stage then
            self:setStage(stageObj.curStage)
        end

        --有倒计时的状态更新倒计时
        local isPermanent = self.m_configData and self.m_configData.permanent
        if not(stageObj.curStage == ActivityStage.ActivityStage_Preparing) and not("1" == isPermanent) then
            self.ui.m_timeOverLabel:setString(eventObj:call("getGameTickStr"))
        end
    end
end

--[[
    根据活动状态布置ui
]]
function CrossServerCenterCell_New:setStage(stage)
    self._stage = stage

    local doorPath =  Door_Color_Path[stage] or  "BG_csm_door_pvp_dead"
    local doorSpr = CCLoadSprite:createSprite(doorPath .. ".png")
    self.ui.m_colorNode:removeAllChildren()
    self.ui.m_colorNode:addChild(doorSpr)

    local showParicle = false
    if (stage == ActivityStage.ActivityStage_Running) then
        showParicle = true
        local isPermanent = self.m_configData and self.m_configData.permanent
        if "1" == isPermanent then          --永久有效的活动显示
            self.ui.m_timeOverLabel:setString(getLang("663525"))
        end
        self.ui.m_timeOverLabel:setColor(cc.c3b(93,207,0))
    elseif (stage == ActivityStage.ActivityStage_Comming) then
        self.ui.m_timeOverLabel:setColor(cc.c3b(255,150,0))
    elseif (stage == ActivityStage.ActivityStage_Preparing) then
        CCCommonUtilsForLua:setSpriteGray(doorSpr, true)
        self.ui.m_timeOverLabel:setColor(cc.c3b(155,150,146))
        self.ui.m_timeOverLabel:setString(getLang("138564"))
    else
        self.ui.m_timeOverLabel:setColor(cc.c3b(93,207,0))
    end

    self.ui.m_pGreyLayer:setVisible(stage == ActivityStage.ActivityStage_Preparing)

    if showParicle then
        self:adDoorParticle()
    else
        self:rmDoorParticle()
    end
end

function CrossServerCenterCell_New:onEnter()
    self._scrollView = self:getParent():getParent()
    self.ui.m_touchlayer:setTouchEnabled(true)
    self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:update(dt) end, 1, false)
    self:update(0)
end

function CrossServerCenterCell_New:onExit()
    self.ui.m_touchlayer:setTouchEnabled(false)
    self:getScheduler():unscheduleScriptEntry(self.m_entryId)
end

function CrossServerCenterCell_New:delayShowDesc(desc, x, y)
    self.ui.m_descNode:setVisible(false)
    self.ui.m_descNode:stopAllActions()
    self.ui.m_desNameTxt:setString(getLang(desc))

    local delay = cc.DelayTime:create(0)
    local function show() self.ui.m_descNode:setVisible(true) end
    local func = cc.CallFunc:create(show)
    local seq = cc.Sequence:create(delay, func)
    self.ui.m_descNode:runAction(seq)
end

function CrossServerCenterCell_New:stopShowDesc()
    self.ui.m_descNode:stopAllActions()
    self.ui.m_descNode:setVisible(false)
end

function CrossServerCenterCell_New:onTouchBegan(x, y)
    self.m_startTouchPt = cc.p(x, y)
    if not self:isVisible(true) or (not isTouchInside(self.ui.m_touchlayer, x, y))
        or isTouchInside(self.ui.m_iconListNode,x,y) or (not isTouchInside(self._scrollView, x, y)) then 
        return false
    end

    self.showDesc = false
    if self.icon_dec and isTouchInside(self.typeIcon, x, y) then
        local margin = -57
        if CCCommonUtilsForLua:isIosAndroidPad() then
            margin = margin * 2.4
        end
        self:delayShowDesc(self.icon_dec, x, y + margin)
        self.showDesc = true
        return true
    end

    if self.reward_star and isTouchInside(self.ui.m_starListNode, x, y) then
        local margin = 77
        if CCCommonUtilsForLua:isIosAndroidPad() then
            margin = margin * 2.4
        end
        self:delayShowDesc("138574", x, y + margin)
        self.showDesc = true
        return true
    end

    if (self.ui.m_touchlayer and isTouchInside(self.ui.m_touchlayer, x, y)) then
        self:setScale(0.98)
        return true
    end
    return false
end

function CrossServerCenterCell_New:onTouchMoved(x, y)
    -- if self.showDesc then 
    --     self:stopShowDesc() 
    --     self.showDesc = false
    -- end
end

function CrossServerCenterCell_New:onTouchEnded(x, y)
	--0 中立地带  1：远征  2：巨龙  3：远古 4：巨龙季后赛 5：巨龙全球赛 7:秘境矿脉  8:先祖战场 9：虚空战场 11:八国国战
    self:setScale(1)

    if self.showDesc then 
        self:stopShowDesc() 
        return
    end

    local dis = 10
    if (cc.pGetDistance(self.m_startTouchPt, cc.p(x, y)) > dis) then
        return
    end
    if FunOpenController:isUnlock(string.format("act_%s", self.m_id), true) == false then
        return
    end
    -- 打开界面
    -- ActivityController.getInstance():shouActUIById(self.m_id)
    if self:checkGateOpen()==false then
    	YesNoDialog:show(getLang("E100329"))--E100329=该活动尚未开启，敬请期待
        return
    end


    local serverType = GlobalData:call("shared"):getProperty("serverType")
    local crossServerId = GlobalData:call("getPlayerInfo"):getProperty("crossFightSrcServerId")
    local selfServerId = GlobalData:call("getPlayerInfo"):getProperty("selfServerId")

    if self.m_id == "57131" then --0
    	if serverType ~= ServerType.SERVER_NEUTRAL_LAND and crossServerId>0 and crossServerId~=selfServerId then
    		YesNoDialog:show(getLang("140329"))
    	else
            ActivityController.getInstance():shouActUIById(self.m_id)
    	end
    elseif self.m_id == "57155" then --1
    	if serverType == ServerType.SERVER_DRAGON_BATTLE or serverType == ServerType.SERVER_BATTLE_FIELD
    	 or serverType == ServerType.SERVER_NEUTRAL_LAND or serverType == ServerType.SERVER_DRAGON_BATTLE_GLOBAL then
    		YesNoDialog:show(getLang("140329"))
    	else
			ActivityController.getInstance():shouActUIById(self.m_id)
    	end
    elseif self.m_id == "57016" then --2
    	if crossServerId>0 and crossServerId~=selfServerId then
    		YesNoDialog:show(getLang("140329"))
    	else
			local view = Drequire("game.dragonBattle.S8.DragonBattleS8EntranceView"):create()
            PopupViewController:addPopupInView(view)
    	end
    elseif self.m_id == "57007" then --3
    	if serverType ~= ServerType.SERVER_BATTLE_FIELD and crossServerId>0 and crossServerId~=selfServerId then
    		YesNoDialog:show(getLang("140329"))
    	else
			ActivityController.getInstance():shouActUIById(self.m_id)
    	end
    elseif self.m_id == "57070" then --4
    	if crossServerId>0 and crossServerId~=selfServerId then
    		YesNoDialog:show(getLang("140329"))
    	else
			local dict = CCDictionary:create()
			dict:setObject(CCString:create("DragonPlayoffTurnsCommand"), "name") --发送命令请求 不是打开面板
			LuaController:call("openPopViewInLua", dict)
    	end
    elseif self.m_id == "57160" then --5
    	if crossServerId>0 and crossServerId~=selfServerId then
    		YesNoDialog:show(getLang("140329"))
    	else
			ActivityController.getInstance():shouActUIById(self.m_id)
    	end
    elseif self.m_id == "57193" then --6
        ActivityController.getInstance():shouActUIById(self.m_id)
    elseif self.m_id == "57259" then --7
    	ActivityController.getInstance():shouActUIById(self.m_id)
    elseif self.m_id == "57284" then --8:先祖战场
        ActivityController.getInstance():shouActUIById(self.m_id)
    elseif self.m_id == "57358" then --9:虚空战场
        ActivityController.getInstance():shouActUIById(self.m_id)
    elseif self.m_id == "57399" then --10:巨龙
        ActivityController.getInstance():shouActUIById(self.m_id)
    elseif self.m_id == "57404" then --11:八国国战
        ActivityController.getInstance():shouActUIById(self.m_id)
    elseif self.m_id == "57433" then --12:皇家竞技场
        require("game.tournament.TournamentController").getInstance():openLadder()
    elseif self.m_id == "57451" then --13:女王世界杯
        ActivityController.getInstance():shouActUIById(self.m_id)
    else
        ActivityController.getInstance():shouActUIById(self.m_id)
    end
    
end

function CrossServerCenterCell_New:openCrossThrone()
    local ctManager = require("game.crossThrone.CrossThroneManager")
    if ctManager:isDespotServer() or ctManager:isEmpireServer() then
		ActivityController.getInstance():shouActUIById(self.m_id)
	else
		local view = Drequire("game.crossThrone.CrossThroneWorldView"):create()
		if view then
			PopupViewController:addPopupInView(view)
		end
	end
end

function CrossServerCenterCell_New:checkGateOpen()
	local ret = true
	if self.m_id == "57131" then --0
		ret = CCCommonUtilsForLua:isFunOpenByKey("neutral_server_main")
    elseif self.m_id == "57155" then --1
    	ret = true
    elseif self.m_id == "57016" then --2
        ret = ActivityController.getInstance():getProperty("dragonBattleState")< DragonBattleState.season_over 
        or ActivityController.getInstance():getProperty("dragonBattleState") >  DragonBattleState.season_sleep
    elseif self.m_id == "57007" then --3
    	ret = true
    elseif self.m_id == "57070" then --4
    	ret = CCCommonUtilsForLua:isFunOpenByKey("wap_switch")
    elseif self.m_id == "57160" then --5
    	ret = CCCommonUtilsForLua:isFunOpenByKey("worldcup_S4")
    -- elseif self.m_id == "57193" then --6
    -- 	ret = CCCommonUtilsForLua:isFunOpenByKey("overlord")
    elseif self.m_id == "57259" then --7
    	ret = CCCommonUtilsForLua:isFunOpenByKey("treasure_fam_on")
    elseif self.m_id == "57284" then --8:先祖战场
        ret = CCCommonUtilsForLua:isFunOpenByKey("war_trial_on") and (not CCCommonUtilsForLua:isFunOpenByKey("war_trial_close_for_deploy"))
    elseif self.m_id == "57358" then --9 虚空战场
        ret = true
    elseif self.m_id == "57404" then --11 八国国战
        ret = CCCommonUtilsForLua:isFunOpenByKey("ek_war_main")
    elseif self.m_id == "57399" then
        ret = CCCommonUtilsForLua:isFunOpenByKey("wa_arms_drill_field")
    elseif self.m_id == "57451" then --13 女王世界杯
        ret = CCCommonUtilsForLua:isFunOpenByKey("WorldCup_entrance")
    end
	return ret
end

function CrossServerCenterCell_New:onMoreClick(...)
    local view = Drequire("game.crossThrone.CrossServerRewardView"):create(self.reward_show, self.reward_dec, self.reward_star)
    if view then PopupViewController:addPopupView(view) end
end

return CrossServerCenterCell_New