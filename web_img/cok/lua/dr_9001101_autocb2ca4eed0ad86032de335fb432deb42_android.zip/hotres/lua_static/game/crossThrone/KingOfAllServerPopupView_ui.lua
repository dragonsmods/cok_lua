----------------------------
-- Author: Elex
-- Date: 2017-11-09 18:14:43
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local KingOfAllServerPopupView_ui = class("KingOfAllServerPopupView_ui")

--#ui propertys


--#function
function KingOfAllServerPopupView_ui:create(owner, viewType)
	local ret = KingOfAllServerPopupView_ui.new()
	CustomUtility:DoRes(310, true)
	CustomUtility:DoRes(7, true)
	CustomUtility:LoadUi("KingOfAllServerPopupView.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function KingOfAllServerPopupView_ui:initLang()
end

function KingOfAllServerPopupView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function KingOfAllServerPopupView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function KingOfAllServerPopupView_ui:onLookButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onLookButtonClick", pSender, event)
end

function KingOfAllServerPopupView_ui:onGoButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onGoButtonClick", pSender, event)
end

function KingOfAllServerPopupView_ui:onHelpBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onHelpBtnClick", pSender, event)
end

return KingOfAllServerPopupView_ui

