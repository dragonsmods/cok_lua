local CrossThroneTowerDetailsCell = class("CrossThroneTowerDetailsCell", cc.TableViewCell)

local cellFontSize = 22
local cellFontSizeSmall = 18
local cellFontXRight = 150
local cellFontXLeft = 80
local cellFontYHigh = 100
local cellFontYLow = 40
local smallCellHeight = 120
local smallCellOpenHeight = 0

function CrossThroneTowerDetailsCell:create()
    --初始化界面
    local cell = CrossThroneTowerDetailsCell.new()
    Drequire("game.crossThrone.KingOfAllServerBuildingCell_ui"):create(cell, 0)
    cell:initCell()
    return cell
end

function CrossThroneTowerDetailsCell:initCell()
    self.csManager = require("game.crossThrone.CrossThroneManager")
    self:setContentSize(self.ui.nodeccb:getContentSize())
    self.m_isOpen = false
    self.m_openNode = cc.Node:create()
    self:addChild(self.m_openNode)
end

function CrossThroneTowerDetailsCell:onEnter()
	self.entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:update(dt) end, 1.0, false)
    self:update(0)
end

function CrossThroneTowerDetailsCell:onExit()
    self:getScheduler():unscheduleScriptEntry(self.entryId)
end

function CrossThroneTowerDetailsCell:update( dt )
    if tonumber(self.m_cellInfo) == -1 then return end
    if not self.m_cellInfo then return end
    if self.m_cellInfo.arrivalTime then
        local arrivalTime = math.ceil(tonumber(self.m_cellInfo.arrivalTime) / 1000)
        local now = LuaController:call("getTimeStamp")
        local remainTime = arrivalTime - now
        if remainTime > 0 then
            local playerInfo = GlobalData:call("getPlayerInfo")
            local selfAllianceId = playerInfo:call("getAllianceId")
            if selfAllianceId == self.m_cellInfo.allianceId then
                local str = getLang("165276")
                str = str.."\n"..getLang("165278", format_time(remainTime))
                self.ui.m_statusTxt:setString(str)
                self.ui.m_statusTxt:setColor(cc.c3b(0,215,0))
            else
                local str = getLang("165277")
                str = str.."\n"..getLang("165278", format_time(remainTime))
                self.ui.m_statusTxt:setString(str)
                self.ui.m_statusTxt:setColor(cc.c3b(215,0,0))
            end
        elseif math.ceil(remainTime) == -1 then
            local playerInfo = GlobalData:call("getPlayerInfo")
            local currentServerId = playerInfo:getProperty("currentServerId")
			self.csManager:reqBuildData(currentServerId, self.cityIndex)
        end     
    end
end
function CrossThroneTowerDetailsCell:refresh(param, dataList, cityIndex, setHeightCb)
    MyPrint("CrossThroneTowerDetailsCell refresh")
    if self.m_openNode then
        self.m_openNode:removeAllChildren()
    end
    self.ui.m_moveNode:setVisible(true)
    self.ui.m_unUseNode:setVisible(false)
    self.ui.m_renderBg:setVisible(false)
    self.ui.m_statusTxt:setString("")

    self.m_cellInfo = param
    self.dataList = dataList
    self.cityIndex = cityIndex
    self.setHeightCb = setHeightCb

    if tonumber(param) == -1 then--加入行
        self.ui.m_moveNode:setVisible(false)
        self.ui.m_unUseNode:setVisible(true)
        self.ui.m_tipTxt:setString(getLang("138688"))
        return
    end

    if not self.m_cellInfo then return end

    local pic = self.m_cellInfo.pic
    if pic == "" or pic == "0" then pic = "g044" end
    pic = pic .. ".png"
    local spr = CCLoadSprite:call("createSprite", pic, 9)
    CCCommonUtilsForLua:call("setSpriteMaxSize", spr, 100, true)
    self.ui.m_icon:removeAllChildren()
    self.ui.m_icon:addChild(spr)
    local picVer = tonumber(self.m_cellInfo.picVer)
    local uid = self.m_cellInfo.uid
    if CCCommonUtilsForLua:call("isUseCustomPic", tonumber(picVer)) then
        local headImgNode = HFHeadImgNode:call("create")
        if headImgNode ~= nil then
            headImgNode:call("initHeadImgUrl2", self.ui.m_icon, CCCommonUtilsForLua:call("getCustomPicUrl", uid, tonumber(picVer)), 1.0, 100, true)
        end
    end

    self.ui.m_nameTxt:setString(self.m_cellInfo.name)
    self.ui.m_armyNum:setString(getLang("108557") .. ":" .. CC_CMDITOA(self.m_cellInfo.totalTroops))

    --是否打开、关闭状态
    self.ui.nodeccb:setPositionY(0)
    dump(self.m_cellInfo, "self.m_cellInfo")
    if self.m_cellInfo.isOpen == "0" then
        self.m_isOpen = false
        self.ui.m_arrow:setRotation(0)
    else
        self.m_isOpen = true
        self.ui.m_arrow:setRotation(90)
        self:refreshOpenCellData()
    end

    local playerInfo = GlobalData:call("getPlayerInfo")
    local selfAllianceId = playerInfo:call("getAllianceId")
    if selfAllianceId == self.m_cellInfo.allianceId then
        self.ui.m_statusTxt:setColor(cc.c3b(0,215,0))
    else
        self.ui.m_statusTxt:setColor(cc.c3b(215,0,0))
    end
  
    if self.m_cellInfo.arrivalTime then
        local arrivalTime = math.ceil(tonumber(self.m_cellInfo.arrivalTime) / 1000)
        local now = LuaController:call("getTimeStamp")
        if arrivalTime <= now then
            --进驻
            self.ui.m_statusTxt:setString(getLang("165279"))
        end
    end
end
function CrossThroneTowerDetailsCell:refreshOpenCellData( )
    self.ui.m_renderBg:setVisible(self.m_isOpen)
    self.ui.m_renderBg:removeAllChildren()
    local openCellNum = 0
    if self.m_openNode then
        self.m_openNode:removeAllChildren()
    end
    self.m_soldiers = self.m_cellInfo.soldiers
    self.m_genarals = self.m_cellInfo.newGeneral
    self.m_dragon = self.m_cellInfo.petDragon

    local winSize = cc.size(640, 852)

    if self.m_dragon then
        local node_dragon = cc.Node:create()
        self.m_openNode:addChild(node_dragon)
        local itemId = self.m_dragon.itemId
        local friendShip = self.m_dragon.friendShip
        if itemId and friendShip then
            friendShip = tonumber(friendShip)
            local baseId = CCCommonUtilsForLua:call("getPropById", itemId, "base_id")
            --name
            local name = getLang(CCCommonUtilsForLua:call("getPropById", baseId, "name"))
            local labelName = cc.Label:createWithSystemFont(name, "Helvetica", cellFontSize)
            node_dragon:addChild(labelName)
            labelName:setColor(cc.c3b(116, 64, 0))
            labelName:setAnchorPoint(cc.p(0,0.5))
            labelName:setPosition(cc.p(cellFontXRight,cellFontYHigh))
            --friendship
            local friendShipTotal = CCCommonUtilsForLua:call("getPropById", itemId, "friendship")
            MyPrint("friendShipTotal ",friendShipTotal)
            local per = math.floor(friendShip * 100 / friendShipTotal) 
            per = per.."%"
            per = getLang("164330",per)
            local labelFriendShip = cc.Label:createWithSystemFont(per, "Helvetica", cellFontSize)
            node_dragon:addChild(labelFriendShip)
            labelFriendShip:setColor(cc.c3b(116, 64, 0))
            labelFriendShip:setAnchorPoint(cc.p(0,0.5))
            labelFriendShip:setPosition(cc.p(cellFontXRight,cellFontYLow))
            --pic
            local pic = CCCommonUtilsForLua:call("getPropById", baseId, "head_icon")..".png"
            local iconSpr = CCLoadSprite:createSprite(pic)
            if iconSpr then
                local iconMaxSize = 90
                CCCommonUtilsForLua:call("setSpriteMaxSize", iconSpr, iconMaxSize, true)
                node_dragon:addChild(iconSpr)
                iconSpr:setPosition(cc.p(cellFontXLeft,(cellFontYLow + cellFontYHigh) / 2))
            end
            --level
            local level = "Lv."..CCCommonUtilsForLua:call("getPropById", itemId, "level")
            local labelLevel = cc.Label:createWithSystemFont(level, "Helvetica", cellFontSizeSmall)
            node_dragon:addChild(labelLevel)
            labelLevel:setColor(cc.c3b(116, 64, 0))
            labelLevel:setPosition(cc.p(cellFontXLeft,cellFontYLow))
        end        
        openCellNum = openCellNum +1
        if openCellNum % 2 == 0 then
            node_dragon:setPositionX(winSize.width / 2)
        end
        node_dragon:setPositionY(-math.ceil(openCellNum / 2) * smallCellHeight) 
    end

    if self.m_genarals then
        local node_general = cc.Node:create()
        self.m_openNode:addChild(node_general)
        local geneId = self.m_genarals.generalId
        local level = self.m_genarals.level

        local pic = CCCommonUtilsForLua:call("getPropById", geneId, "pic")..".png"
        MyPrint("pic ",pic)
        local cf = CCLoadSprite:call("getSF",pic)
        if cf == nil then
            pic = "hero_head_1.png"
        end
        local iconSpr = CCLoadSprite:createSprite(pic)
        if iconSpr then
            local iconMaxSize = 90
            CCCommonUtilsForLua:call("setSpriteMaxSize", iconSpr, iconMaxSize, true)
            node_general:addChild(iconSpr)
            iconSpr:setPosition(cc.p(cellFontXLeft,(cellFontYLow + cellFontYHigh) / 2 ))
        end
        if geneId then
            local title = getLang(CCCommonUtilsForLua:call("getPropById", geneId, "title"))
            local name = getLang(CCCommonUtilsForLua:call("getPropById", geneId, "name"))
            local labelTitle = cc.Label:createWithSystemFont(title, "Helvetica", cellFontSize)
            node_general:addChild(labelTitle)
            labelTitle:setAnchorPoint(cc.p(0,0.5))
            labelTitle:setColor(cc.c3b(116, 64, 0))
            labelTitle:setPosition(cc.p(cellFontXRight,cellFontYHigh))
            local labelName = cc.Label:createWithSystemFont(name, "Helvetica", cellFontSize)
            node_general:addChild(labelName)
            labelName:setAnchorPoint(cc.p(0,0.5))
            labelName:setColor(cc.c3b(116, 64, 0))
            labelName:setPosition(cc.p(cellFontXRight,cellFontYLow))
        end        
        if level then
            level = "Lv."..level
            local labelLevel = cc.Label:createWithSystemFont(level, "Helvetica", cellFontSizeSmall)
            node_general:addChild(labelLevel)
            labelLevel:setColor(cc.c3b(116, 64, 0))
            labelLevel:setPosition(cc.p(cellFontXLeft,cellFontYLow))
        end                
        openCellNum = openCellNum + 1
        if openCellNum % 2 == 0 then
            node_general:setPositionX(winSize.width / 2)
        end
        node_general:setPositionY(-math.ceil(openCellNum / 2) * smallCellHeight) 
    end

    if self.m_soldiers then
        for i,v in ipairs(self.m_soldiers) do
            local node_soldier = cc.Node:create()
            self.m_openNode:addChild(node_soldier)
            local armyId = self.m_soldiers[i].armyId
            local count = self.m_soldiers[i].count
            local star = self.m_soldiers[i].star

            --name
            local name = CCCommonUtilsForLua:call("getNameById", armyId)
            local labelName = cc.Label:createWithSystemFont(name, "Helvetica", cellFontSize)
            node_soldier:addChild(labelName)
            labelName:setAnchorPoint(cc.p(0,0.5))
            labelName:setColor(cc.c3b(116, 64, 0))
            labelName:setPosition(cc.p(cellFontXRight,cellFontYHigh))        

            --icon
            local armyIcon = ArmyController:call("getArmyIconById", armyId)
            local iconSpr = CCLoadSprite:createSprite(armyIcon)
            if iconSpr then
                local iconMaxSize = 120
                CCCommonUtilsForLua:call("setSpriteMaxSize", iconSpr, iconMaxSize, true)
                node_soldier:addChild(iconSpr)
                iconSpr:setPosition(cc.p(cellFontXLeft,(cellFontYLow + cellFontYHigh) / 2 - 10))
            end

            --count
            count = CC_CMDITOA(count)
            local labelCount = cc.Label:createWithSystemFont(count, "Helvetica", cellFontSize)
            node_soldier:addChild(labelCount)
            labelCount:setAnchorPoint(cc.p(0,0.5))
            labelCount:setColor(cc.c3b(116, 64, 0))
            labelCount:setPosition(cc.p(cellFontXRight,cellFontYLow))     

            --sodierRoman
            armyId = tostring(armyId)
            local num1 = CCCommonUtilsForLua:call("getPropById", armyId, "level")
            local romanSpr = CCCommonUtilsForLua:call("getRomanSprite", tonumber(num1))
            if romanSpr then
                local iconMaxSize = 40
                CCCommonUtilsForLua:call("setSpriteMaxSize", romanSpr, iconMaxSize, true)
                node_soldier:addChild(romanSpr)
                romanSpr:setPosition(cc.p(cellFontXLeft,cellFontYLow))
            end

            --star
            local playerInfo = GlobalData:call("getPlayerInfo")
            if playerInfo == nil then
                MyPrint("KingdomMiracleTile:refreshView playerInfo is nil")
                return
            end
            if playerInfo:getProperty("name") == self.m_cellInfo.name then
                star = ArmyController:call("getInstance"):call("getStarlvById",armyId)
                MyPrint("armystar: ",star)
            end
            if tonumber(star) >= 1 then
                local starBg = CCLoadSprite:createSprite("soldier_star_lv.png")
                if starBg then
                    local iconMaxSize = 30
                    CCCommonUtilsForLua:call("setSpriteMaxSize", starBg, iconMaxSize, true)
                    node_soldier:addChild(starBg)
                    starBg:setPosition(cc.p((cellFontXLeft + cellFontXRight) / 2,cellFontYHigh + 20))
                end   
                local starLabel = cc.LabelBMFont:create(star, "pve_fnt_boss.fnt")
                starLabel:setScale(0.3)
                starLabel:setPosition(starBg:getPosition())
                node_soldier:addChild(starLabel)
            end        
            openCellNum = openCellNum + 1
            if openCellNum % 2 == 0 then
                node_soldier:setPositionX(winSize.width / 2)
            end
            node_soldier:setPositionY(-math.ceil(openCellNum / 2) * smallCellHeight) 
        end
    end

    smallCellOpenHeight = math.ceil(openCellNum / 2) * smallCellHeight
    self.ui.m_renderBg:setContentSize(cc.size(self.ui.m_renderBg:getContentSize().width, smallCellOpenHeight))
    self.m_openNode:setPositionY(smallCellOpenHeight)
    self.ui.nodeccb:setPositionY(self.ui.nodeccb:getPositionY() + smallCellOpenHeight)
end

function CrossThroneTowerDetailsCell:touchCellCB( )
    if tonumber(self.m_cellInfo) == -1 then
        WorldController:call("openMarchDeploy", self.cityIndex, 0)
        return
    end
    self.m_isOpen = not self.m_isOpen
    for i,v in ipairs(self.dataList) do
        self.dataList[i].isOpen = "0"
    end
    self.ui.nodeccb:setPositionY(0)
    local openCellNum = 0
    if self.m_isOpen then
        self.m_cellInfo.isOpen = "1"
        if self.m_cellInfo.newGeneral then
            openCellNum = openCellNum + 1
        end
        if self.m_cellInfo.petDragon then
            openCellNum = openCellNum + 1
        end
        if self.m_cellInfo.soldiers then
            openCellNum = openCellNum + #self.m_cellInfo.soldiers
        end
    end
    smallCellOpenHeight = math.ceil(openCellNum / 2) * smallCellHeight
    self.setHeightCb(smallCellOpenHeight)
    self.ui.m_renderBg:setVisible(self.m_isOpen)
    CCSafeNotificationCenter:call("postNotification", "crossthrone.cellTouch")
end

return CrossThroneTowerDetailsCell