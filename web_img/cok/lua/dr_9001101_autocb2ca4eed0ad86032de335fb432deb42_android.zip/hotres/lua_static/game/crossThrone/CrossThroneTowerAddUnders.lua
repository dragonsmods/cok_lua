
local CrossThroneTowerAddUnders = class("CrossThroneTowerAddUnders", function (  )
    return cc.Node:create()
end)

function CrossThroneTowerAddUnders:ctor(cityInfo,luaMap )
    CCLoadSprite:call("loadDynamicResourceByName", "crossThrone_face")

    local buildingPic = CCCommonUtilsForLua:call("getPropByIdGroup", "overlord_building", tostring(luaMap.buildId), "building_pic")
    local building = CCLoadSprite:call("createSprite", buildingPic .. ".png")
    building:setPosition(-10, 70)
    self:addChild(building)
end

function addCrossThroneTowerUnders( index )
    local world = WorldMapView:call("instance")
    if nil == world then
        return nil
    end
    local cityInfo = WorldController:call("getCityInfoByIndex", index)
    if nil == cityInfo then
        return nil
    end
    if cityInfo:getProperty("luaType") ~= WorldCityType.crossthrone_blessing_tower and cityInfo:getProperty("luaType") ~= WorldCityType.crossthrone_curse_tower then
        return nil
    end

    local luaMap = cityInfo:call("getLuaMap")
    local pos = cityInfo:call("GetPositionInMap")
    local ret = CCArray:create()
    local under = CrossThroneTowerAddUnders.new(cityInfo, luaMap)
    under:setTag(index)
    under:setPosition(cc.p(pos.x, pos.y))
    ret:addObject(under)
    world:call("getCityBatchNode"):addChild(under, index)

    dump(luaMap, "CrossThroneTowerAddUnders luaMap")
    if nil ~= world.addDespotBuildSwitch then
        world:addDespotBuildSwitch(atoi(index), (luaMap.switch == "1"))
    end

    local WarTime = 3
    local fight_of_king = 0
    local state = WorldController:call("getInstance"):call("getKingActivityStateByType", fight_of_king)

     -- 添加文本
    if state == WarTime then
        local labelBatch = WorldMapView:call("getUnBatchLabelNode")
        if labelBatch then
            local buildName = CCCommonUtilsForLua:call("getPropByIdGroup", "overlord_building", tostring(luaMap.buildId), "name")
            local nameBgPic = "name_bg.png"
            local nameBg = CCLoadSprite:call("createSprite", nameBgPic)
            nameBg:setPositionY(-70)
            under:addChild(nameBg)

            local allianceName = cityInfo:getProperty("allianceName")
            local playerName = cityInfo:getProperty("playerName")

            local buildName = getLang(buildName)
            local nameLabel = cc.Label:createWithSystemFont(buildName, "Helvetica", 20, cc.size(0.0,0))
            nameLabel:setColor(cc.c3b(255, 0, 0))
            labelBatch:addChild(nameLabel, index)
            nameLabel:setPosition(pos.x, pos.y - 70)
            ret:addObject(nameLabel)

            local addY = -70
            if allianceName ~= "" then 
                addY = addY - 34

                local allianceBg = CCLoadSprite:call("createSprite", nameBgPic)
                allianceBg:setPositionY(addY)
                under:addChild(allianceBg)

                local allianceLabel = cc.Label:createWithSystemFont(allianceName, "Helvetica", 20, cc.size(0.0,0))
                allianceLabel:setColor(cc.c3b(255, 206, 132))
                labelBatch:addChild(allianceLabel, index)
                
                allianceLabel:setPosition(pos.x, pos.y + addY)
                ret:addObject(allianceLabel)
            end

            if playerName ~= "" then
                addY = addY - 34

                local playerBg = CCLoadSprite:call("createSprite", nameBgPic)
                playerBg:setPositionY(addY)
                under:addChild(playerBg)

                local playerLabel = cc.Label:createWithSystemFont(playerName, "Helvetica", 20, cc.size(0.0,0))
                playerLabel:setColor(cc.c3b(255, 206, 132))
                labelBatch:addChild(playerLabel, index)
                
                playerLabel:setPosition(pos.x, pos.y + addY)
                ret:addObject(playerLabel)
            end
        end
    else
        world:call("addBatchItem", BatchTagType.ProtectTag, index)
    end

    return ret
end

return CrossThroneTowerAddUnders