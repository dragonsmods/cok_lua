----------------------------
-- Author: Elex
-- Date: 2017-09-04 22:30:18
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local KingOfAllServerFunctionCell_ui = class("KingOfAllServerFunctionCell_ui")

--#ui propertys


--#function
function KingOfAllServerFunctionCell_ui:create(owner, viewType)
	local ret = KingOfAllServerFunctionCell_ui.new()
	CustomUtility:DoRes(310, true)
	CustomUtility:LoadUi("KingOfAllServerFunctionCell.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function KingOfAllServerFunctionCell_ui:initLang()
end

function KingOfAllServerFunctionCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function KingOfAllServerFunctionCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return KingOfAllServerFunctionCell_ui

