local CrossThroneEntryView = class("CrossThroneEntryView", PopupBaseView)

function CrossThroneEntryView:create()
	local view = CrossThroneEntryView.new()
	Drequire("game.crossThrone.KingOfAllServerView_ui"):create(view, 0)
	if view:initView() then
		return view
	end
end

function CrossThroneEntryView:initView()
	-- if CCCommonUtilsForLua:isFunOpenByKey("overlord") == false then
	-- 	CCCommonUtilsForLua:call("flyHint", "", "", getLang("102192"))
	-- 	return false
	-- end 

	CCLoadSprite:call("doResourceByCommonIndex", 105, true)
	
	local clipSize = self.ui.m_picNode:getContentSize()
    self.m_clipNode = CCClipNode:call("create", clipSize.width, clipSize.height)
    self.ui.m_picNode:addChild(self.m_clipNode)

    local bgPath = CCLoadSprite:call("loadDynamicResourceByName", "crossThrone_entry") and "crossThrone_ad.png" or "activity_ad_beiyong.png"
    local bg = CCLoadSprite:createSprite(bgPath)
    local bgSize = bg:getContentSize()
    bg:setAnchorPoint(ccp(0, 0))
    bg:setPosition((clipSize.width - bgSize.width) / 2, (clipSize.height - bgSize.height))
	self.m_clipNode:addChild(bg)
	
	self:setHDPanelFlag(true)

	self.ui.m_tileLabel:setString(getLang("138316"))
	self.ui.m_desLabel:setString(getLang("138319"))
	self.ui.m_ruleTxt:setString(getLang("138599"))
	self.ui.m_pointTxt:setString(getLang("165219"))
	self.ui.m_ruleNode:setVisible(true)
	self.ui.m_rewardNode:setVisible(false)

	CCCommonUtilsForLua:setButtonTitle(self.ui.m_thisButton, getLang("138318"))
	CCCommonUtilsForLua:setButtonTitle(self.ui.m_lookButton, getLang("138320"))

	local size = self.ui.m_desLabel:getContentSize()

	self.ui.m_desLabel:retain()
	self.ui.m_desLabel:removeFromParent()

	local listSize = self.ui.m_listNode:getContentSize()
	local lwing = CCLoadSprite:createSprite("DEC_choukataitou_1.png")
	local rwing = CCLoadSprite:createSprite("DEC_choukataitou_1.png")
	lwing:setAnchorPoint(ccp(1, 0.5))
	lwing:setPosition(listSize.width / 2, listSize.height / 2)
	lwing:setFlipX(true)
	lwing:setOpacity(84)
	rwing:setAnchorPoint(ccp(0, 0.5))
	rwing:setOpacity(84)
	rwing:setPosition(listSize.width / 2, listSize.height / 2)
	self.ui.m_listNode:addChild(lwing)
	self.ui.m_listNode:addChild(rwing)

	local scrollView = cc.ScrollView:create()
    scrollView:setViewSize(listSize)
    scrollView:setPosition(CCPoint(0,0))
    scrollView:setScale(1.0)
    scrollView:ignoreAnchorPointForPosition(true)
    scrollView:setDirection(1)
    scrollView:setBounceable(true)
    scrollView:setClippingToBounds(true)
    scrollView:setContentSize(size)
    scrollView:setContentOffset(ccp(0, listSize.height - size.height))
    local function scrollViewDidScroll() self:scrollViewDidScroll(scrollView) end
    scrollView:registerScriptHandler(scrollViewDidScroll, cc.SCROLLVIEW_SCRIPT_SCROLL)
    scrollView:setDelegate()
  	self.ui.m_listNode:addChild(scrollView)

	scrollView:addChild(self.ui.m_desLabel)
	self.ui.m_desLabel:setPosition(0, 0)
	self.ui.m_desLabel:release()

	self.ctManager = require("game.crossThrone.CrossThroneManager")
	if self.ctManager:isDespotServer() or self.ctManager:isEmpireServer() then
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_lookButton, getLang("140061"))
		CCCommonUtilsForLua:call("setButtonSprite", self.ui.m_lookButton, "BTN_hongse.png")
	end

	self:call("setSwallowsTouches", true)
	self:call("setModelLayerDisplay", true)

	return true
end

function CrossThroneEntryView:scrollViewDidScroll(view)
    local mindy = view:minContainerOffset().y 
    local maxdy = view:maxContainerOffset().y 
    local dy = view:getContentOffset().y
    if dy < mindy then view:setContentOffset(cc.p(0, mindy)) end
end

function CrossThroneEntryView:onEnter()
	UIComponent:call("showPopupView", 1)
	self:call("setModelLayerPosition", self.ui.m_topNode:getPosition())
	self:call("setModelLayerOpacity", 255)
	self.ui.m_titleTxt:setString(getLang("138316"))
end

function CrossThroneEntryView:onExit()
	-- body
end

function CrossThroneEntryView:showSelectSp(selectBtn)
	if selectBtn then 
		local x, y = selectBtn:getPosition()
		self.ui.m_btnSprite:setPosition(x, y)
	end
end

function CrossThroneEntryView:onBtnRuleClick( ... )
	self:showSelectSp(self.ui.m_ruleBtn)
	self.ui.m_ruleNode:setVisible(true)
	self.ui.m_rewardNode:setVisible(false)
end

function CrossThroneEntryView:onBtnPointClick( ... )
	if not CCCommonUtilsForLua:isFunOpenByKey("overlord_building_new") then
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("102192"), 3, -888)
		return
	end

	self:showSelectSp(self.ui.m_pointBtn)
	self.ui.m_ruleNode:setVisible(false)
	self.ui.m_rewardNode:setVisible(true)
	
	--没有奖励node创建一个
	if self.ui.m_rewardNode:getChildrenCount() == 0 then
		local viewSize = self.ui.m_rewardNode:getContentSize()
		local rewardPage =  Drequire("game.crossThrone.CrossThronePointRewardNode"):create(viewSize)
		self.ui.m_rewardNode:addChild(rewardPage)
	end
end

function CrossThroneEntryView:onThisButtonClick()
	local areaView = Drequire("game.crossThrone.CrossThroneAreaView"):create("138376", DESPOT_BATTLE)
	PopupViewController:addPopupView(areaView)
end

function CrossThroneEntryView:onLookButtonClick()
	if self.ctManager:isDespotServer() or self.ctManager:isEmpireServer() then
		local function confirm() self.ctManager:exitCrossThrone() end
		YesNoDialog:show(getLang("138388"), confirm)
	else
		local view = Drequire("game.crossThrone.CrossThroneWorldView"):create()
		if view then
			PopupViewController:addPopupInView(view)
		end
	end
end

function CrossThroneEntryView:onTipBtnClick()
	FaqHelper:call("showSingleFAQ", "45279")
end

return CrossThroneEntryView