cfg_table = {

	 ["spineOrder"] = 1,   -- 是否显示spine, 与spineHide不共存 值大小为显示顺序，大的最后显示

}