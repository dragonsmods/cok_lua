cfg_table = {
	["iconOrder"] = 2,  -- 是否显示图片  值大小为显示顺序，大的最后显示
}