----------------------------
-- Author: Elex
-- Date: 2017-10-16 Monday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CsmodStoreView_ui = class("CsmodStoreView_ui")

--#ui propertys


--#function
function CsmodStoreView_ui:create(owner, viewType)
	local ret = CsmodStoreView_ui.new()
	CustomUtility:LoadUi("CsmodStoreView.ccbi", ret, owner, true, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then		owner:initTableViewByOwner()
	else		ret:initTableView()	end	return ret
end

function CsmodStoreView_ui:initLang()
end

function CsmodStoreView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CsmodStoreView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CsmodStoreView_ui:onDefaultButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onDefaultButtonClick", pSender, event)
end

function CsmodStoreView_ui:onLuxuryButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onLuxuryButtonClick", pSender, event)
end

function CsmodStoreView_ui:onClickRecord(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickRecord", pSender, event)
end

function CsmodStoreView_ui:initTableView()
	TableViewSmoker:createView(self, "m_listTableView_Default", "game.activity.CsmodStore.CsmodStoreCell", 1, 10, "CsmodStoreCell")
	TableViewSmoker:createView(self, "m_listTableView_Luxury", "game.activity.CsmodStore.CsmodStoreCell", 1, 10, "CsmodStoreCell")
end

function CsmodStoreView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return CsmodStoreView_ui

