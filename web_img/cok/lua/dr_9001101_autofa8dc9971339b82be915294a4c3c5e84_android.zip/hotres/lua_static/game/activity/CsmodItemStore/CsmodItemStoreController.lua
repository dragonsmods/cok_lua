local CsmodItemStoreController = class("CsmodItemStoreController")

function CsmodItemStoreController:ctor()
end

function CsmodItemStoreController:getConfigData()
    if self.itemListTbl == nil then
        local itemListStr = CCCommonUtilsForLua:getPropById("99039", "k1")
        local tbl = {}
        local tmp = string.split(itemListStr, "|")
        for _, str in pairs(tmp) do
            if str ~= "" then
                local tmp1 = string.split(str, ";")
                local data = tbl[tmp1[1]] or {}
                data[#data + 1] = {
                    type = 0,
                    itemId = tmp1[2],
                    num = tonumber(tmp1[3]) or 0,
                }
                tbl[tmp1[1]] = data
            end
        end
        self.itemListTbl = tbl
    end
    return self.itemListTbl
end

function CsmodItemStoreController:getFunctionOn()
    if UiCompoentControoller.checkHasInitData() then
        if self.functionOnKeys == nil then
            self.functionOnKeys = CCCommonUtilsForLua:isFunOpenByKey("Csmod_item_mall")
        end
        return self.functionOnKeys
    else
        return CCCommonUtilsForLua:isFunOpenByKey("Csmod_item_mall")
    end
end

function CsmodItemStoreController:getActExtraItemData(goldKey)
    if not self:getFunctionOn()  then
        return nil
    end

    local getActObj = ActivityController:call("getActObj", "5718902")
    if not getActObj then return nil end

    local endTime = tonumber(getActObj:getProperty("endTime"))
    if endTime > 0 and getWorldTime() <= endTime then
        local data = self:getConfigData()
        if table_is_empty(data) then
            return nil
        end

        return data[goldKey]
    end

    return nil
end

return CsmodItemStoreController
