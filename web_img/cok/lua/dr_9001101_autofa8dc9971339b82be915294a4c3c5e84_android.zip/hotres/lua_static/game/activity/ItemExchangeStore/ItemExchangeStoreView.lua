local ItemExchangeStoreView = class("ItemExchangeStoreView",
    function()
        return PopupBaseView:create()
    end
)
ItemExchangeStoreView.__index = ItemExchangeStoreView

local ShopItemController = nil

function ItemExchangeStoreView:create()
    local view = ItemExchangeStoreView.new()
    local ret = Drequire("game.activity.ItemExchangeStore.ItemExchangeStoreView_ui"):create(view, 0)

    if view:initView() then
        return view
    end
end

function ItemExchangeStoreView:initView()

    local clipSize = self.ui.m_picNode:getContentSize()
    self.m_clipNode = CCClipNode:call("create", clipSize.width, clipSize.height)
    self.ui.m_picNode:addChild(self.m_clipNode)
    local act = ActivityController:call("getActObj", "57208")
    -- 活动图
    local spr = nil
    if act then
        local sf = act:getAdFrame()
        if sf ~= nil then
            spr = cc.Sprite:createWithSpriteFrame(sf)
        end
    end
    if spr == nil then
        spr = CCLoadSprite:call("createSprite", "activity_ad_beiyong.png")
    end
    if spr then
        spr:setPosition(cc.p(clipSize.width*0.5, clipSize.height*0.5 - 30))
        self.m_clipNode:addChild(spr)
    end
    self:registerTouchFuncs()
   return true
end


function ItemExchangeStoreView:onEnter()
    ShopItemController = Drequire("game.shop.ShopItemController").new(22)
    ShopItemController:getSellItem("22")

    self:setTitleName(getLang("9440831"))

    -- -- 获取数据
    registerScriptObserver(self, self.getDataBack, ShopItemController.m_getShopItemnotifyKey)
    registerScriptObserver(self, self.getBuyDataBack, ShopItemController.m_buyShopItemNotifyKey)
    registerScriptObserver(self, self.onConfirmBuy, "ItemExchange_BuyConfirm")
end

function ItemExchangeStoreView:onExit()
    -- self:getScheduler():unscheduleScriptEntry(self.m_entryId)

    unregisterScriptObserver(self, ShopItemController.m_getShopItemnotifyKey)
    unregisterScriptObserver(self, ShopItemController.m_buyShopItemNotifyKey)
    unregisterScriptObserver(self, "ItemExchange_BuyConfirm")
    ShopItemController = nil
end

function ItemExchangeStoreView:update(dt)
end

function ItemExchangeStoreView:onTouchBegan(x, y)
    return true
end

function ItemExchangeStoreView:onTouchMoved(x, y)

end

function ItemExchangeStoreView:onTouchEnded(x, y)
end

function ItemExchangeStoreView:getDataBack()
    local shopTbl = ShopItemController:getShopItemInfo()
    -- dump(shopTbl, "ItemExchangeStoreView:getDataBack() is: ")

    -- local 
    table.sort(shopTbl, function(a, b) return a.m_display < b.m_display end)
    local tbl = {}
    for i, item in pairs(shopTbl) do
        tbl[#tbl + 1] = {
            data = item, 
            parent = self.ui.m_listNode,
        }
    end
    self.ui:setTableViewDataSource("m_listTableView", tbl)
    self.m_shopTbl = tbl
end

function ItemExchangeStoreView:getBuyDataBack()
    local offset = self.ui.m_listTableView:getContentOffset()
    self:getDataBack()
    self.ui.m_listTableView:setContentOffset(offset)
end


function ItemExchangeStoreView:onConfirmBuy(dict)
    local tbl = dictToLuaTable(dict)
    if tbl.shopId and tbl.count then
        ShopItemController:buyShopItem(tostring(tbl.shopId), tonumber(tbl.count))
    end
end


return ItemExchangeStoreView



