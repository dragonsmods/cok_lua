local BlockFuncController = class("BlockFuncController")
-- 该类主要用于分帧处理函数

local _BlockFuncController = nil

function BlockFuncController.getInstance()
    if not _BlockFuncController then
        _BlockFuncController = BlockFuncController.new()
        guiCommonGlobal.controllerAutoPurge(_BlockFuncController)
    end
    return _BlockFuncController
end


function BlockFuncController:ctor()
	self.m_blockFucList = {}
	self.m_blockKeyTable = {}
	-- self:createScheduler()
end

function BlockFuncController:purge()
	self:destoryScheduler()
	_BlockFuncController = nil
end

function BlockFuncController:createScheduler()
	if self.m_entryId == nil then
		local scheduler = cc.Director:getInstance():getScheduler()
		self.m_entryId = scheduler:scheduleScriptFunc(function() 
			self:update() 
			end, 0.01, false)
	end
end

function BlockFuncController:destoryScheduler()
	if self.m_entryId then
		local scheduler = cc.Director:getInstance():getScheduler()
        scheduler:unscheduleScriptEntry(self.m_entryId)
		self.m_entryId = nil
	end
end

function BlockFuncController:update()
	local function finishBlock(blockTbl)
		if blockTbl.finishFunc then
			blockTbl.finishFunc()
		end
		if blockTbl.finishNotify then
			CCSafeNotificationCenter:call("postNotification", blockTbl.finishNotify)
		end
		self.m_blockKeyTable[blockTbl.key] = nil
		table.remove(self.m_blockFucList, 1)
	end
	local startTime = CCCommonUtilsForLua:call("getLocalTime")
	local timeOffset = 5
	local index = 1
	while (#self.m_blockFucList > 0) do
		local tbl = self.m_blockFucList[1]
		if tbl.tblData then
			if tbl.tblData[1] then
				tbl.callBack(tbl.tblData[1])
				table.remove(tbl.tblData, 1)
			end
			if #tbl.tblData <= 0 then
				finishBlock(tbl)
			end
		else
			tbl.callBack(tbl.soureData)
			finishBlock(tbl)
		end
		local curTime = CCCommonUtilsForLua:call("getLocalTime")
		if curTime - startTime > timeOffset then
			break
		end
	end

	if #self.m_blockFucList == 0 then
		self:destoryScheduler()
	end
end

-- key，回调的key，可能就用于打印吧。
-- callBack 回调函数
-- params 参数:，内容待定
function BlockFuncController:addBlockFunc(key, callBack, params)
	if self.m_blockKeyTable[key] then
		return
	end

	if callBack == nil then
		return
	end
	params = params or {}
	local tbl = {}
	tbl.key = key
	tbl.callBack = callBack
	tbl.soureData = params.soureData -- 单独数据,用于函数执行返回 和 tblData 互斥
	-- tbl.tblData = params.tblData -- 表数据，用于循环执行。每帧一条
	if params.tblData then
		local tmp = {}
		for k, v in pairs(params.tblData) do
			tmp[#tmp + 1] = v
		end
		tbl.tblData = tmp
	end

	tbl.finishFunc = params.finishFunc
	tbl.finishNotify = params.finishNotify

	self.m_blockFucList[#self.m_blockFucList + 1] = tbl
	self.m_blockKeyTable[key] = tbl

	self:createScheduler()
end


return BlockFuncController