require("game.command.TriggerActivityCmd")

-- 不同类型的push
local WishingTreePush = 8    --许愿树执行成功
local MessageAvatarActivate= 9 --推送状态消息
local MessageKillMonsterNum =17 --普通杀怪计数(当前数量，最大限定数量)客户端有进度条展示  -- 原本为10，先修改为17
local MessageKillMonsterNumTmp =10 --用于兼容旧版问题与幸运日冲突的问题
local CallFriendsTimeCount =11 --召回活动时间倒计时
local MessageSendReward = 12 --给客户端直接奖励发送reward
local MessageItemExchange=13 --兑换集齐字的奖励领取消息 表示已经兑换完成
local MessageReflushEggs=14 --刷新砸金蛋盘面 金蛋数据返回
local MessageReflushGold=15 --同步金币数量
local MessageNewServerAction=16 --新的一套数据结构，灵活的内容，params内还有一个type字段，标识消息类型
local MessageKillMonsterNum =17	--普通杀怪计数(当前数量，最大限定数量)客户端有进度条展示
local MessageSendAndShowReward = 18	--给客户端直接奖励发送reward 并且展示出来
	local MNSA_NewbieTask = 1 -- Message New Server Action
	local MNSA_ActivityWeek = 3	-- 周常活动
	local MNSA_KingReturn = 4 -- 王者归来

TriggerEventUtils = TriggerEventUtils or {}

-- 颤抖吧～～
function TriggerEventUtils.handleEvent( dict )
	MyPrint("TriggerEventUtils.handleEvent")
	if nil == dict then
		return
	end

	local t = dict:valueForKey("type"):intValue()
	local params = dict:objectForKey("params")
	if nil ~= params then
		params = tolua.cast(params, "CCDictionary")
	end
	MyPrint('TriggerEventUtils.handleEvent', t)

	if t == WishingTreePush then
		CCSafeNotificationCenter:call("postNotification", "msg_wish_act_tool_use_suc")
	elseif t == MessageAvatarActivate then
		AvatarController:call("handleActiveAvatar", params)
	elseif t == MessageKillMonsterNum 
		or t == MessageKillMonsterNumTmp
		then
		require ("game.controller.LuaActivityController")
		LuaActivityController.getInstance():onMonsterKillCntChange(params)
	elseif t == CallFriendsTimeCount then
		CCSafeNotificationCenter:call("postNotification", "activity_callback",params)
	elseif t == MessageSendReward then
		local rwdArr = params:objectForKey("reward_list")
		if nil ~= rwdArr then
			PortActController:call("flyReward", rwdArr, true)
		    local rwdInfo = RewardController:call("retReward", rwdArr)
		    CCCommonUtilsForLua:call("flyHint", "", "", rwdInfo)
		    CCSafeNotificationCenter:call("postNotification", MSG_REFREASH_TOOL_DATA)
		end
	elseif t == MessageItemExchange then
		CCSafeNotificationCenter:call("postNotification", "msg_couplets_exchange_end")
	elseif t == MessageReflushEggs then
		LuaActivityController.getInstance():retEggsData(params)
	elseif t == MessageReflushGold then
		local gold = params:valueForKey("gold"):intValue()
		local pPlayerinfo = GlobalData:call("getPlayerInfo")
		pPlayerinfo:setProperty("gold", gold)
	    CCSafeNotificationCenter:call("postNotification", "city_resources_update")
	elseif t == MessageNewServerAction then
		TriggerEventUtils.handleNewServerAction(params)
	elseif t == MessageSendAndShowReward then
		local rwdArr = params:objectForKey("reward_list")
		if nil ~= rwdArr then
			rwdArr = arrayToLuaTable(rwdArr)
			local view = Drequire("game.CommonPopup.RewardShowAndGetNewView").create(rwdArr, getLang("9200137"))
			if view then
				view:setCalllBack(function ()
					createTableFlyReward(rwdArr)
				end)
				PopupViewController:addPopupView(view)
			end
		end
	end
end

function TriggerEventUtils.handleNewServerAction (params)
	local type = params:objectForKey("type"):intValue()
	MyPrint('TriggerEventUtils.handleNewServerAction', type)
	if MNSA_NewbieTask == type then
		Drequire('game.newbieTask.NewbieTaskController')
		NewbieTaskController.getInstance():handlePushMessage(params)
	elseif MNSA_ActivityWeek == type then
		require('game.activity.week.ActivityWeekController')
		ActivityWeekController.getInstance():handlePushMessage(params)
	elseif MNSA_KingReturn == type then
		ToNewServerController.getInstance():handlePushMessage(params)
	end
end

-- 同屏玩家接收打雪球推送
function TriggerEventUtils.handleOverLap( dict )
	MyPrint("TriggerEventUtils.handleOverLap")
	if nil == dict then
		return
	end

	local index = dict:valueForKey("worldpointid"):intValue()
	local cityInfo = WorldController:call("getCityInfoByIndex", index)
	if nil == cityInfo then
		return
	end
	
	local playerInfo = cityInfo:call("getPlayerInfo")
	if nil == playerInfo then
		return
	end
	
	local overlap = dict:objectForKey("overlap")
	if nil == overlap then
		return
	end

	local count = overlap:valueForKey("count"):intValue()
	local sid = overlap:valueForKey("sid"):intValue()
	local set = overlap:valueForKey("set"):intValue()
	playerInfo:setProperty("overlapStatus", sid)
	playerInfo:setProperty("overlapCnt", count)
	playerInfo:setProperty("overlapEndTime", set)

	CCSafeNotificationCenter:call("postNotification", "MSG_RECREATE_MAP_CITY", CCInteger:create(index))

	local scene = WorldMapView:call("instance")
	if nil ~= scene and nil ~= scene.addOverLapPlusLabel then
		MyPrint("scene.addOverLapPlusLabel")
		scene:addOverLapPlusLabel(index)
	end
end

-- 同屏幕的玩家接收城堡外观推送
function TriggerEventUtils.handleWorldCityAvatar( dict )
	MyPrint("TriggerEventUtils.handleCityAvatar", dict)
	if nil == dict then
		return
	end

	local index = dict:valueForKey("worldpointid"):intValue()
	MyPrint("index", index)
	local cityInfo = WorldController:call("getCityInfoByIndex", index)
	MyPrint("cityInfo", cityInfo)
	if nil == cityInfo then
		return
	end
	local playerInfo = cityInfo:call("getPlayerInfo")
	MyPrint("playerInfo", playerInfo)
	if nil == playerInfo then
		return
	end 
	local status = dict:valueForKey("sid"):intValue()
	local endTime = dict:valueForKey("set"):intValue()
	MyPrint("endTime ", endTime)
	endTime = GlobalData:call("changeTime", endTime)
	MyPrint("endTime ", endTime)
	playerInfo:setProperty("status", status)
	playerInfo:setProperty("statusStamp", endTime)
	MyPrint("worldtime ", GlobalData:call("getWorldTime"))
	CCSafeNotificationCenter:call("postNotification", "MSG_RECREATE_MAP_CITY", CCInteger:create(index))
end

-- 获取trigger event
function TriggerEventUtils.getTriggerEvent(  )
	local t_ev = TriggerEventUtils.m_triggerEvent
	if not t_ev then
		t_ev = utils.getEventClass():new()
		TriggerEventUtils.m_triggerEvent = t_ev
	end
	return t_ev
end






---------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------
require("game.command.TriggerActivityCmd")

-- 对他人使用物品
function TriggerEventUtils.useItemToTarget( uid, itemId )
	MyPrint("uid, itemId", uid, itemId)
	if nil == uid or nil == itemId then
		return false
	end
	uid = tostring(uid)
	itemId = tostring(itemId)

	local cmd = TargetUseItemCmd.new(uid, itemId)
	cmd:send()

	return true
end

-- 分享触发 参数是分享的类型  分享许愿就是wishing
function TriggerEventUtils.triggerShare( action )
	if nil == action then
		return false
	end

	local cmd = ShareTriggerCmd.new(action)
	cmd:send()

	return true
end

-- 获取杀怪进度信息
function TriggerEventUtils.triggerMonsterProGet(  )
	local cmd = MonsterProCmd.new()
	cmd:send()
	return true
end

-- 刷新金蛋数据
function TriggerEventUtils.startRefreshEggData(  )
	local cmd = TriggerRefreshEggsDataCmd.new()
	cmd:send()

	return true
end

-- 请求金蛋数据
function TriggerEventUtils.startGetEggData(  )
	local cmd = TriggerGetBreakEggsDataCmd.new()
	cmd:send()

	return true
end

-- 砸金蛋
function TriggerEventUtils.startBreakEgg( idx )
	MyPrint("idx", idx)
	MyPrint("type(idx) ", type(idx))
	if nil == idx or type(idx) ~= "number" then
		return false
	end
	local cmd = TriggerBreakEggCmd.new(idx)
	cmd:send()

	return true
end

-- 春联兑换 参数是道具的para1
function TriggerEventUtils.startCharacterExchange( para1 )
	MyPrint("TriggerEventUtils.startCharacterExchange", para1)
	if nil == para1 or type(para1) ~= "string" then
		return false
	end

	local cmd = TriggerCharacterExchangeCmd.new(para1)
	cmd:send()

	return true
end


-- 世界切换到主城
function TriggerEventUtils.startSceneChange()
	local cmd = SceneChangeCmd.new()
	cmd:send()

	return true 
end

-- 登录游戏初始化结束
function TriggerEventUtils.loginFinish()
	local cmd = LoginFinishCmd.new()
	cmd:send()

	return true
end