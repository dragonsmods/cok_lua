-- @Author: tangwen
-- @Date:   2019-06-03 16:14:07
-- @Last Modified by:   tangwen
-- @Last Modified time: 2020-02-18 09:56:17

-- 场景管理类

local SceneMgr = class("SceneMgr")

local _instance = nil
function SceneMgr.getInstance()
    if _instance == nil then
        _instance = SceneMgr.new()
        guiCommonGlobal.controllerAutoPurge(_instance)
    end
    return _instance
end

function SceneMgr:purge(  )
    self.m_sceneChangeEv = nil
end

function SceneMgr:getSceneChangeEvent(  )
    local sceneChangeEv = self.m_sceneChangeEv
    if not sceneChangeEv then
        sceneChangeEv = utils.getEventClass():create()
        self.m_sceneChangeEv = sceneChangeEv
    end
    return sceneChangeEv
end

return SceneMgr