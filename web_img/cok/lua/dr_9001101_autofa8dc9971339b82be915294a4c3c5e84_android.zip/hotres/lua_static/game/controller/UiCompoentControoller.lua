UiCompoentControoller = {}

UiCompoentControoller.layer = nil

UiCompoentControoller.kingdomBattleTeamUid = ""
UiCompoentControoller.kingdomBattleTeamServerId = ""
UiCompoentControoller.kingdomBattleTeamEndTime = 0

function UiCompoentControoller.create(dict)
    if tolua.cast(UiCompoentControoller.layer, "layer") then
        UiCompoentControoller.layer:removeFromParent()
    end

    local UiCompoentLayer = require("game.CommonPopup.UiCompoentLuaLayer"):create(dict)
    if UiCompoentLayer then
        UiCompoentControoller.layer = UiCompoentLayer
        return UiCompoentLayer
    end
end

function UiCompoentControoller.exit()
    if UiCompoentControoller.layer then
        UiCompoentControoller.layer = nil
    end
end

function UiCompoentControoller.getCompoentLayer()
    if tolua.cast(UiCompoentControoller.layer, "cc.Layer") then
        return UiCompoentControoller.layer
    end
end

function UiCompoentControoller.setInitData()
    -- 用于数据是否初始化完成的判断
    UiCompoentControoller.hasInitData = true
    if UiCompoentControoller.layer and UiCompoentControoller.layer.initData then
        UiCompoentControoller.layer:initData()
    end
end

function UiCompoentControoller.checkHasInitData()
    return UiCompoentControoller.hasInitData
end

function UiCompoentControoller.purge()
    UiCompoentControoller.layer = nil
    UiCompoentControoller.hasInitData = false
end

function UiCompoentControoller.getGuideNodeByKey( key )
    if UiCompoentControoller.layer then
        return UiCompoentControoller.layer:getGuideNodeByKey( key )
    end
    return nil
end

function UiCompoentControoller.kingdomBattleTeam(dict)
    if dict then
        if dict.kingdomBattleTeamUid then
            UiCompoentControoller.kingdomBattleTeamUid = dict.kingdomBattleTeamUid
        end
        if dict.kingdomBattleTeamServerId then
            UiCompoentControoller.kingdomBattleTeamServerId = dict.kingdomBattleTeamServerId
        end
        if dict.kingdomBattleTeamEndTime then
            UiCompoentControoller.kingdomBattleTeamEndTime = tonumber(dict.kingdomBattleTeamEndTime)/1000
        end

        if UiCompoentControoller.kingdomBattleTeamEndTime > 0 then
            local _icon_cfg = {iconName = "game.UIComponent.KingdomMassNodeIcon", iconType = 2, order = 2.11} --王国集结
            UiCompoentControoller.getIconEvent():emit({icon_cfg = _icon_cfg, eventType = "create"})
        end
    end
end

function UiCompoentControoller.tryAddThemeMonthIcon( tbl )
    local r = ThemeMonthControllerInst:getIconComponent()
    if r then
        table.insert(tbl,r)
    end
end

function UiCompoentControoller.getIconEvent(  )
    local self = UiCompoentControoller

    local ev = self.m_iconEvent
    if not ev then
        ev = utils.getEventClass(  ):create()
        self.m_iconEvent = ev
    end

    return ev
end