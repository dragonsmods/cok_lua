

------------------请求获取每日首次分享奖励--------------------------
local FirstShareCmd = class("FirstShareCmd", LuaCommandBase)
function FirstShareCmd.create(uid, callBack)
    local ret = FirstShareCmd.new()
    -- ret:putParam("uid", CCString:create(uid))
    ret._callBack = callBack
    ret:initWithName("screenshotShare")
    return ret
end

function FirstShareCmd:handleReceive(dict)
    local tbl = self:parseMsg(dict)
    if type(tbl) == "boolean" then
        return tbl
    end
    if self._callBack then
        self._callBack(tbl)
    end
    return true
end


--------------------------------------------
ShareController = class("ShareController")

_shareControllerInstance = _shareControllerInstance or nil
function ShareController.getInstance()
    if _shareControllerInstance == nil then
        _shareControllerInstance = ShareController.new()
    end
    return _shareControllerInstance
end

function ShareController:ctor()
    self.isCanGetFirstShareReward = false
    self.imageShareSetAward = ""
end

-- "params2+++" = {
--     "imageShareSet"      = "0"
--     "imageShareSetAward" = "200200|5"
-- }
function ShareController:initConfigData(dict)
    if not dict then 
        return 
    end
    local params = dict:objectForKey("imageShare")
    if not params then 
        return 
    end

    local data = dictToLuaTable(params)
    if data then 
        self.isCanGetFirstShareReward = data.imageShareSet == "0"
        self.imageShareSetAward = data.imageShareSetAward or ""
    end
end

function ShareController:isCanGetReward()
    if CCCommonUtilsForLua:isFunOpenByKey("share_image") then
        return self.isCanGetFirstShareReward
    else
        return false
    end
end

function ShareController:getRewards()
   return self.imageShareSetAward --"211452|200"
end

function ShareController:reqFirstShareRewards()
    if not self.isCanGetFirstShareReward then 
        return 
    end
    cmd = FirstShareCmd.create(nil,nil)
    cmd:send()
    self.isCanGetFirstShareReward = false
end

return ShareController

