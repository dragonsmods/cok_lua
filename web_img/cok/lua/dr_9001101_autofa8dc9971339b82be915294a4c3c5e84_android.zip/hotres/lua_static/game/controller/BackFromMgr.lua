local BackFromMgr = class("BackFromMgr")

local _instance = nil
function BackFromMgr.getInstance()
    if _instance == nil then
        _instance = BackFromMgr.new()
        guiCommonGlobal.controllerAutoPurge(_instance)
    end
    return _instance
end

function BackFromMgr:ctor()
    self.m_recordMap = {}
end

function BackFromMgr:purge()
    self.m_recordMap = {}
end

function BackFromMgr:recordView( isRec, id, from )
    if string.isNilOrEmpty(id) then
        return
    end
    if isRec then
        self.m_recordMap[id] = from
    else
        self.m_recordMap[id] = nil
    end
end

function BackFromMgr:getRecord( id )
    return self.m_recordMap[id]
end

return BackFromMgr