-- @Author: tangwen
-- @Date:   2019-06-03 16:14:07
-- @Last Modified by:   tangwen
-- @Last Modified time: 2020-03-03 15:41:25

-- kpi 活动管理基类

local KpiActMgr = class("KpiActMgr")

-- ... 顺序
-- 1. 动态资源
-- 2. 开关名
function KpiActMgr:ctor(actId,...)
    self.m_actId = actId
    self.m_dynRes,self.m_switchName = ...
    self:reset()
end

function KpiActMgr:reset(  )
    self.m_openFlag = nil
    self.m_curData = nil
end

function KpiActMgr:purge()
    self:reset()

    if self.m_noticer then
        self.m_noticer:reset()
    end
end

function KpiActMgr:getResNoticer(  )
    local noticer = self.m_noticer
    if not noticer then
        noticer = utils.getExtendClass("resNotReadyNotice"):create()
        self.m_noticer = noticer
    end
    return noticer
end

function KpiActMgr:isOpen(  )
    if string.isNilOrEmpty(self.m_switchName) then
        return false
    end

    if self.m_openFlag then
        return self.m_openFlag
    end

    self.m_openFlag = CCCommonUtilsForLua:isFunOpenByKey(self.m_switchName)
    return self.m_openFlag
end

function KpiActMgr:getData(  )
    return self.m_curData
end

function KpiActMgr:makeResReadyById( id )
    if string.isNilOrEmpty(self.m_dynRes) then
        return
    end

    if string.isNilOrEmpty(id) or self.m_hadLoadedRes then
        return
    end
    local res = self.m_activityPage
    if not res then
        res = CCCommonUtilsForLua:getGroupByKey("activity_page")
        self.m_activityPage = res
    end
    local pageInfo = res[id]
    if not pageInfo then
        return
    end

    local actId = pageInfo.call_activity
    if not string.isNilOrEmpty(actId) and actId == self.m_actId then
        self.m_hadLoadedRes = true
        CCLoadSprite:call("loadDynamicResourceByName", self.m_dynRes)
        return true
    end
end

function KpiActMgr:getActControlType()
    local act_ctrl_type = self.m_act_ctrl_type
    if not act_ctrl_type then
        act_ctrl_type = 1
        local xml_page = ActivityController.getInstance():getActivityPageXml()
        for _,v in pairs(xml_page) do 
            if v.call_activity == self.m_actId and v.Control_Type then
                act_ctrl_type = tonumber(v.Control_Type)
            end
        end
        self.m_act_ctrl_type = act_ctrl_type
    end
    return act_ctrl_type
end

function KpiActMgr:getRedDotCount(  )
    return 0
end

function KpiActMgr:getActId(  )
    return self.m_actId
end

function KpiActMgr:getRedDotMgrIns(  )
end

function KpiActMgr:isResReady(  )
    if self.m_dynRes then
        return not not CCLoadSprite:call("loadDynamicResourceByName", self.m_dynRes)
    end
    return true
end

function KpiActMgr:getDynRes(  )
    return self.m_dynRes
end

function KpiActMgr:addDotAfterCheck(  )
    require("game.RedDotMgr.KpiActRedDotMgr").getInstance(self:getActControlType()):checkActHasRedDots({self:getActId()})
end

function KpiActMgr:removeDot( need_reset )
    local red_ins = require("game.RedDotMgr.KpiActRedDotMgr").getInstance(self:getActControlType())
    local dot_key = self:getActId()
    red_ins:removeDot(dot_key)
    if need_reset then
        red_ins:debugReset(dot_key)
    end
end

return KpiActMgr