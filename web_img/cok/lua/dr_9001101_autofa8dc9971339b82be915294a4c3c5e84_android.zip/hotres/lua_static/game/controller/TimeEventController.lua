local TimeEventController = class("TimeEventController")
-- 该类主要用于同一监控时间判断逻辑，避免每个都写一套自己的时间更新机制

local _TimeEventController = nil

function TimeEventController.getInstance()
    if not _TimeEventController then
        _TimeEventController = TimeEventController.new()
    end
    return _TimeEventController
end


function TimeEventController:ctor()
	self.m_entryId = nil
	self.m_eventList = {}
	self.m_eventTbl = {}
	self.m_lastEventTime = -1
end

function TimeEventController:purge()
	if self.m_entryId then
		local scheduler = cc.Director:getInstance():getScheduler()
        scheduler:unscheduleScriptEntry(self.m_entryId)
		self.m_entryId = nil
	end
	self.m_eventList = {}
	self.m_eventTbl = {}
	self.m_lastEventTime = -1
end

-- 增加时间监听信息，格式为：
-- timeInfo = {
-- 	key, 监听关键字，若重复，不可重复,若重复，则后者覆盖前者
-- 	time, 下次到时的时间，单位为秒
--  offTime 间隔时间
--  beRepeat 间隔时间用，判断是否持续循环
--  repeatTable = {} 传入每次间隔的时间 -- 暂未实现，感觉还没有需求
-- 	_callBack,	监听到时间后的回调函数，若为此种需要对应函数注意释放这个node。
-- 	notifyStr,	通知消息，
-- 	以上二者选其一即可,且不可再回调中继续添加时间监听
-- }
function TimeEventController:addTimeListener(timeInfo)
	if timeInfo.key == nil or timeInfo.key == "" then
		return
	elseif timeInfo._callBack == nil and timeInfo.notifyStr == nil then
		return
	end
	if timeInfo.offTime then
		-- 间隔时间的模式
		timeInfo.time = getTimeStamp() + tonumber(timeInfo.offTime)
		-- timeInfo.beRepeat = tonumber()
	else
		-- 终止时间
		timeInfo.time = tonumber(timeInfo.time)
		if timeInfo.time == nil then
			return
		end

		if timeInfo.time < getTimeStamp() then
			return
		end
	end

	local event = self.m_eventTbl[timeInfo.key]
	if event then
		for i, data in pairs(self.m_eventList) do
			if data.key == timeInfo.key then
				self.m_eventList[i] = timeInfo
				break
			end
		end
	else
		self.m_eventList[#self.m_eventList + 1] = timeInfo
	end
	self.m_eventTbl[timeInfo.key] = timeInfo
	self:orderEventList()
end

-- 这里如果多个函数同时释放，例如guicommon的purge函数，所以这个TimeEventController的purge放前面，先清空表，避免不停的创建释放schedule
function TimeEventController:removeTimeListener(timeKey)
	if self.m_eventTbl[timeKey] then
		self.m_eventTbl[timeKey] = nil

		for i, data in pairs(self.m_eventList) do
			if data.key == timeKey then
				table.remove(self.m_eventList, i)
				break
			end
		end
		self:reSchedule()
	end
end

function TimeEventController:orderEventList()
	if #self.m_eventList > 1 then
		table.sort(self.m_eventList, function(a, b)
				return a.time < b.time
			end)
	end

	-- 这边有个问题就是如果一阵内重复调用，会有一些浪费，不过暂时没有这种需求，后续再跟进
	self:reSchedule()
end

function TimeEventController:setEventRepeat(timeKey, beRepeat)
	local tbl = self.m_eventTbl[timeKey]
	if tbl then
		tbl.beRepeat = beRepeat
	end
end

function TimeEventController:reSchedule(beFore)
	local event = self.m_eventList[1]
	if beFore ~= true and self.m_lastEventTime > -1 then
		if event and event.time >= self.m_lastEventTime then
			return
		end
	end
	if self.m_entryId then
		local scheduler = cc.Director:getInstance():getScheduler()
        scheduler:unscheduleScriptEntry(self.m_entryId)
		self.m_entryId = nil
	end

	if event then
		local offset = event.time - getTimeStamp()
		local scheduler = cc.Director:getInstance():getScheduler()
        self.m_entryId = scheduler:scheduleScriptFunc(function() 
        	self:timeOverEvent() 
			end, offset+1, false)
		self.m_lastEventTime = event.time
	else
		self.m_lastEventTime = -1
	end
end

function TimeEventController:timeOverEvent()
	local nowTime = getTimeStamp()
	local delTbl = {}
	for i, event in ipairs(self.m_eventList) do
		if event.time <= nowTime then
			if event._callBack then
				event._callBack()
			end
			if event.notifyStr then
				CCSafeNotificationCenter:call("postNotification", event.notifyStr)
			end
			-- 将要删除的索引存储一下，遍历中无法删除
			if event.offTime and event.beRepeat == 1 then
				event.time = nowTime + event.offTime
			else
				delTbl[#delTbl + 1] = i
				self.m_eventTbl[event.key] = nil
			end
		else
			break
		end
	end

	table.removeByBat(self.m_eventList, delTbl)
	self:reSchedule(true)
end

return TimeEventController