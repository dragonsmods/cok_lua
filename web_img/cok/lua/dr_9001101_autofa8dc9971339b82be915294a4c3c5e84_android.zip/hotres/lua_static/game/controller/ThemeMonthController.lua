-- @Author: tangwen
-- @Date:   2019-05-24 16:16:06
-- @Last Modified by:   tangwen
-- @Last Modified time: 2019-05-30 18:21:53

local ThemeMonthController = class("ThemeMonthController")

local StringTbl = {
    theme_month = "theme_month", --开关
    ThemeMonth_face = "ThemeMonth_face",--资源合图
    flag_png = "thm_long_enter_001.png",--检查资源是否ok 标识图片
}

local Act_Keys = {
    "act_go"          ,
    "act_name"        ,
}

local Buff_Keys = {
    "buff_des"        ,
    "buff_effectId"   ,
    "buff_icon"       ,
    "buff_name"       ,
    "buff_sign"       ,
    "buff_value"      ,
    "buff_value_type" ,
}

--走配置
local TouchHandlers = {
    --群龙签到
    daily_sign = function ( info,self )
        PopupViewController:call("removeLastPopupView")
        
        local params = {}
        params.firstViewKey = "integrateSignIn"
        local view = Drequire("game.WelfareIntegrate.WelfareIntegrateMainView"):create(params)
        PopupViewController:addPopupInView(view)
    end

    --龙之祝福
    ,theme_buff = function ( info,self )
        local serverData = self.m_serverBlessData
        if serverData then
            self:enterBlessWithServerData(info)
        else
            self:requestMonthData(utils.handler(self,self.enterBlessWithServerData,info))
            -- CCCommonUtilsForLua:call("flyHint", "", "", getLang("114110"))
        end
    end

    --魔龙色子
    ,lucky_dice = function ( info,self )
        PopupViewController:call("removeLastPopupView")
    end

    --招募之神
    ,general_rank = function(info, self)
        if CCCommonUtilsForLua:isFunOpenByKey('general_rank') then
            PopupViewController:call("removeLastPopupView")
	        local view = Drequire("game.hero.NewUI_v2.HeroRecruitRankView"):create()
	        PopupViewController:addPopupInView(view)
        end        
    end
    ,building_rank = function(info, self)
        local cityLv = FunBuildController:call("getMainCityLv")
        if CCCommonUtilsForLua:isFunOpenByKey("building_rank")  then
            if cityLv < 15 then
                CCCommonUtilsForLua:call("flyHint", "", "", getLang("103869", "15"))
                return
            end
            PopupViewController:call("removeLastPopupView")
            local view = Drequire("game.buildExtension.buildRankAct.BuildRankMainView"):create()
            if view then
                PopupViewController:addPopupInView(view)
            end            
        end
    end

}

local _innerCmd = class("_innerCmd", LuaCommandBase)
function _innerCmd.create(callback)
    local ret = _innerCmd.new()
    ret:initWithName("kingdombuff.data")
    ret.callback = callback
    return ret

end

function _innerCmd:handleReceive(dict)
    local tbl = self:parseMsg(dict)
    if type(tbl) == "boolean" then
        return tbl
    end

    ThemeMonthController.getInstance().m_serverBlessData = tbl
    ThemeMonthController.getInstance().m_inReqBless = nil
    if self.callback then
        self.callback()
    end
    return true
end

local _instance = nil
function ThemeMonthController.getInstance()
    if _instance == nil then
        _instance = ThemeMonthController.new()
        guiCommonGlobal.controllerAutoPurge(_instance)
    end
    return _instance
end

function ThemeMonthController:requestMonthData( callback )
    if self.m_inReqBless then
        return
    end
    self.m_inReqBless = true
    _innerCmd.create(callback):send()
end

function ThemeMonthController:getStringTbl(  )
    return StringTbl
end

function ThemeMonthController:ctor()
    self:reset()
end

function ThemeMonthController:getOpenFlag(  )
    if self.m_openFlag then
        return self.m_openFlag
    end

    local data_flag = CCCommonUtilsForLua:isFunOpenByKey(StringTbl.theme_month)
    self.m_openFlag = data_flag
    return self.m_openFlag
end

function ThemeMonthController:isResReady(  )

    local res_flag = self.m_resOkFlag

    if res_flag then
        return res_flag
    end

    self:firstNeedDyRes()
    res_flag =  (nil ~= cc.SpriteFrameCache:getInstance():getSpriteFrame(StringTbl.flag_png))
    self.m_resOkFlag = res_flag
    return res_flag
end

function ThemeMonthController:transToNextMonth(  )
    self.m_curMonth = nil
    self.m_allActData = nil
    self.m_idsInOneMonth = nil
    self.m_themeInOneMonth = nil
    self.m_serverBlessData = nil
    self.m_inReqBless = nil
    self.m_monthDurationStr = nil
    self:resetUIFlags()
end

function ThemeMonthController:getCurMonth(  )
    if not self.m_curMonth then
        local now = GlobalData:call("getTimeStamp")
        self.m_curMonth = tonumber(os.date("!%m", now))
        local td = utils.getMonthDays(now)
        self.m_monthDurationStr = string.format("%s.01-%s.%s",self.m_curMonth,self.m_curMonth,td)
    end
    return self.m_curMonth
end

function ThemeMonthController:getCurMonthDurationStr(  )
    if not self.m_monthDurationStr then
        self:getCurMonth()
    end

    return self.m_monthDurationStr
end

function ThemeMonthController:getAllActData(  )
    if not self.m_allActData then
        self.m_allActData = CCCommonUtilsForLua:getGroupByKey(StringTbl.theme_month)
    end
    return self.m_allActData
end

function ThemeMonthController:getMonthActById( id )
    self:getAllActData()
    -- if not self.m_allActData then
    --     self.m_allActData = CCCommonUtilsForLua:getGroupByKey(StringTbl.theme_month)
    -- end
    id = type(id) == "string" and id or tostring(id)
    assert(self.m_allActData,"no theme_month in database.local.xml")
    assert(self.m_allActData[id], "no " .. id .. "in theme_month")
    return self.m_allActData[id]
end

function ThemeMonthController:getMonthActConfig( monthNum )
    monthNum = monthNum or self:getCurMonth()
    if not self.m_themeInOneMonth or not self.m_themeInOneMonth[monthNum] then
        -- local r = self.m_idsInOneMonth
        -- if not r then
        --     r = {"34012001","34012002","34012003","34012004"}
        --     self.m_idsInOneMonth = r
        -- end

        self.m_themeInOneMonth = self.m_themeInOneMonth or {}
        
        -- local t = {}
        -- for _,v in ipairs(r) do
        --     table.insert(t,self:getMonthActById(v))
        -- end
        -- local sm = tostring(monthNum)
        local t = table.find(self:getAllActData(),function ( cur )
            return tonumber(cur.month) == monthNum
        end)
        -- assert(t,"no moth data".. monthNum)
        self.m_themeInOneMonth[monthNum] = t
    end

    return self.m_themeInOneMonth[monthNum]
end

function ThemeMonthController:preRequestData( actName )
    -- if actName == "2000804" then
    --     self:requestMonthData()
    -- end
end

function ThemeMonthController:postHandleData( t )

    -- trim
    local trimIdx = {}
    for i,v in ipairs(t) do
        if v.act_name == "2000805" and not self:isSaiziOpen() then
            table.insert(trimIdx,i)
        end
    end

    table.removeByBat(t,trimIdx)

    --modify


end

function ThemeMonthController:getActsInOneTheme( monthNum )
    monthNum = monthNum or self:getCurMonth()
    if not self.m_actsInOneTheme or not self.m_actsInOneTheme[monthNum] then
        self.m_actsInOneTheme = self.m_actsInOneTheme or {}

        local dt = self:getMonthActConfig(monthNum)
        local t = {}
        for _,v in ipairs(Act_Keys) do
            local r = dt[v]
            if r then
                r_arr = string.split(r,';')
                for i1,v1 in ipairs(r_arr) do
                    t[i1] = t[i1] or {}
                    t[i1][v] = v1

                    if v == "act_name" then
                        self:preRequestData(v1)
                    end
                end
            end
        end

        self:postHandleData(t)

        self.m_actsInOneTheme[monthNum] = t
    end
    return self.m_actsInOneTheme[monthNum]
end

function ThemeMonthController:getBuffsInOneTheme( monthNum )
    monthNum = monthNum or self:getCurMonth()
    if not self.m_buffsInOneTheme or not self.m_buffsInOneTheme[monthNum] then
        self.m_buffsInOneTheme = self.m_buffsInOneTheme or {}

        local dt = self:getMonthActConfig(monthNum)
        local t = {}
        for _,v in ipairs(Buff_Keys) do
            local r = dt[v]
            if r then
                r_arr = string.split(r,'|')
                for i1,v1 in ipairs(r_arr) do
                    t[i1] = t[i1] or {}
                    t[i1][v] = v1
                end
            end
        end

        self.m_buffsInOneTheme[monthNum] = t
    end
    return self.m_buffsInOneTheme[monthNum]
end

function ThemeMonthController:getIconComponent(  )
    if self:getOpenFlag() then --取消资源限制 self:isResReady()
        return { iconName = "game.UIComponent.ThemeMonthIcon", iconType = 4 }
    end
end

function ThemeMonthController:getBless_Serverdata(  )
    return self.m_serverBlessData
end

function ThemeMonthController:showView( isShow )
    if self.m_isShowMainView then
        return
    end

    local view = Drequire("game.ThemeMonth.MonthMainView"):create()
    PopupViewController:addPopupView(view)
end

--走配置
function ThemeMonthController:getActBg( actName )
    local curData = self:getMonthActConfig()
    if not curData then
        return
    end
    local actNames = string.splitNSep(curData.act_name,";")
    local actIcons = string.splitNSep(curData.act_icon,";")
    for index=1,#actNames do
        if actNames[index] == actName then
            return actIcons[index]
        end
    end
    
end

function ThemeMonthController:firstNeedDyRes(  )
    local f1 = CCLoadSprite:call("loadDynamicResourceByName", StringTbl.ThemeMonth_face)
end

function ThemeMonthController:handleTouchAct( info,idx )
    if self.m_curTouchInfo == info then
        return
    end

    local tf = TouchHandlers[info.act_go]
    if tf then
        tf(info,self)
    end
end

function ThemeMonthController:resetUIFlags(  )
    self.m_isShowMainView = nil
    self.m_curTouchInfo = nil
end

function ThemeMonthController:resetTouchFlag(  )
    self.m_curTouchInfo = nil
end

function ThemeMonthController:checkBlessData( s_data,buff_data )
    if not s_data or not s_data.effectObject then
        return false
    end

    if table.isNilOrEmpty(buff_data) then
        return false
    end

    local buff_ids = {}

    for _,v in ipairs(buff_data) do
        local flag = true
        for _,buffKey in ipairs(Buff_Keys) do
            flag = flag and (not string.isNilOrEmpty(v[buffKey]))
            if not flag then
                return false
            end
        end

        table.insert(buff_ids,v.buff_effectId)
    end

    local s_ids = table.keys(s_data.effectObject)

    for _,v in ipairs(s_ids) do
        if not table.contains(buff_ids,v) then
            return false
        end
    end

    return true
end

function ThemeMonthController:enterBlessWithServerData( info )
    local buff_data = ThemeMonthControllerInst:getBuffsInOneTheme()
    local s_data = ThemeMonthControllerInst:getBless_Serverdata()

    if not self:checkBlessData(s_data,buff_data) then
        return
    end

    local view = Drequire("game.ThemeMonth.MonthDragonBlessView"):create(info)
    PopupViewController:addPopupView(view)
end

function ThemeMonthController:isSaiziOpen(  )
    local festivalCtl = require("game.FestivalActivities.FestivalActivitiesController").getInstance()
    return festivalCtl:isActivityOpenById("30437610")
end

function ThemeMonthController:reset(  )
    self.m_inReqBless = nil
    self:resetUIFlags()
    self.m_openFlag = nil
end


function ThemeMonthController:purge()
    self:reset()
end

return ThemeMonthController