--[[ 
    在线时长控制类
    @author: Awen
    @date: 2020-12-09
 ]]
local OnlineTimeController = class("OnlineTimeController")
local instance = instance or nil

function OnlineTimeController.getInstance()
    if not instance then 
        instance = OnlineTimeController.new() 
    end
    return instance
end

function OnlineTimeController:reqData()
    if self.awakeData then
        return
    end

    utils.requestServer("onlinetime.data", nil, nil, function ( tbl )
        self.onlineTime = (atoi(tbl.todayOnlineTime) + atoi(tbl.totalOnlineTime)) / 1000
        self.loginStamp = getTimeStamp()

        self:initData()
    end)
end

function OnlineTimeController:initData()
    if self.awakeData then
        return
    end

    local story_awaken = CCCommonUtilsForLua:getPropDictByIdGroup("data_config","story_awaken")
    local k1_list = string.splitNSep(story_awaken.k1, "|")
    local k2_list = string.splitNSep(story_awaken.k2, "|")
    local k3_list = string.splitNSep(story_awaken.k3, "|")
    local k4_list = string.splitNSep(story_awaken.k4, "|")
    self.awakeData = {}
    for i,v in ipairs(k1_list or {}) do
        self.awakeData[v] = {
            taskId = k2_list[i], 
            guideId = k3_list[i],
            online = atoi(k4_list[i]),
        }
    end
    self.awakeNoOperation = atoi(story_awaken.k5)
    self.awakeSleep = atoi(story_awaken.k6)

    -- 
    local story_reward = CCCommonUtilsForLua:getPropDictByIdGroup("data_config","story_reward")
    self.rewardData = {
        delay = atoi(story_reward.k1),
        guideId = story_reward.k4
    }
    self.rewardNoOperation = atoi(story_reward.k2)
    self.rewardSleep = atoi(story_reward.k3)
end

function OnlineTimeController:getAwakeConfig()
    if self.awakeData == nil or self.onlineTime == nil or self.loginStamp == nil then
        return nil
    end

	local chapter_index = ChapterController.getInstance().index
    local config = self.awakeData[chapter_index]
    if config then
        -- 指定任务已经完成
        if config.taskDone then
            return nil
        end

        local now = getTimeStamp()
        local totalTime = self.onlineTime + now - self.loginStamp
        -- 检查在线时长
        if totalTime > config.online then
            -- 检查间隔时间
            if config.sleep then
                if now - config.sleep < self:getAwakeSleep() then
                    return nil
                end
            end

            config.taskDone = ChapterController:getInstance():isTaskDone(config.taskId)
            if not config.taskDone then
                return config
            end
        end
    end
    
    return nil
end

function OnlineTimeController:getAwakeNoOperation()
    return self.awakeNoOperation
end

function OnlineTimeController:getAwakeSleep()
    return self.awakeSleep
end

function OnlineTimeController:getRewardConfig()
    if self.rewardData == nil then
        return nil
    end
    
    local now = getTimeStamp()
    -- 检查间隔时间
    if self.rewardData.sleep then
        if now - self.rewardData.sleep < self:getRewardSleep() then
            return nil
        end
    end

    if not self.rewardData.allTaskDone then
        local p,t = ChapterController:getInstance():getNormalTaskProgress()
        self.rewardData.allTaskDone = p >= t
    end
    if self.rewardData.allTaskDone then
        -- 记录完成时间点
        if self.rewardData.doneStamp == nil then
            self.rewardData.doneStamp = now
            return nil
        end

        if now - self.rewardData.doneStamp >= self.rewardData.delay then
            return self.rewardData
        end
    end

    return nil
end

function OnlineTimeController:getRewardNoOperation()
    return self.rewardNoOperation
end

function OnlineTimeController:getRewardSleep()
    return self.rewardSleep
end

function OnlineTimeController:resetAllTaskDoen()
    if self.rewardData then
        self.rewardData.allTaskDone = nil
    end
end

return OnlineTimeController