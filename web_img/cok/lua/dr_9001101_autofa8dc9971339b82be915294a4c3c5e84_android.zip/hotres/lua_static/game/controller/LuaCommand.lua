-- setup by lixiaoming

local cmdList = cmdList or {}


local LuaCommand = class("LuaCommand", LuaCommandBase)
function LuaCommand.create(commandKey,callBack)
	local ret = LuaCommand.new()
	cmdList[commandKey] = callBack
	ret:initWithName(commandKey,callBack)
	return ret
end

function LuaCommand:handleReceive(dict)
	local cmdname = dict:valueForKey("cmd"):getCString()
	local callBack = cmdList[cmdname]
	if callBack == nil then
		return false
	end
	local params = dict:objectForKey("params")
	if nil == params then
		return true
	end
	params = tolua.cast(params, "CCDictionary")
	local tbl = dictToLuaTable(params)
	if nil ~= tbl.errorCode and tbl.errorCode ~= "" then
		LuaController:flyHint("", "", getLang(tbl.errorCode))
		return true
	end
	callBack(params)
	cmdList[cmdname] = nil
	return true
end

return LuaCommand

