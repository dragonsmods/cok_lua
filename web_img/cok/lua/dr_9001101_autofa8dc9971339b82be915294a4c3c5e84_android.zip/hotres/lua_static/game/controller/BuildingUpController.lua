--[[
	建筑升级触发控制类
	2019.7.4	Awen
]]

BuildingUpController = class("BuildingUpController")

-- 接收CPP调用
function BuildingUpController:fireEventRef(newKey, dict)
    Dprint("BuildingUpController:fireEventRef", newKey)
    if newKey == "checkGuide" then
		if self:checkGuide(dict) then
			dict:setObject(CCString:create("1"), "state")
		end
	elseif newKey == "queryTime" then
		self:reqQueryTime(dict)
    end
end

function BuildingUpController:checkGuide(dict)
	if dict then
		local _data = dictToLuaTable(dict)
		-- dump(_data, 'BuildingUpController:checkGuide')
		if _data then
			local _config = CCCommonUtilsForLua:call("getPropByIdGroup","data_config", "building_up_guide", "k1")
        	local _configList = string.split(_config, ";")
			for i, v in ipairs(_configList or {}) do
				local _params = string.split(v, "|")
				if #_params == 3 and _params[1] == _data.buildid and _params[2] == _data.level then
					GuideController:call("setGuide", _params[3])
					return true
				end
			end
		end
	end
	return false
end

-- ------------------------------------
local QuertTime = class("QuertTime", LuaCommandBase)
function QuertTime.req(uuid, itemId)
	-- Dprint("QuertTime.req", uuid, itemId)
	local ret = QuertTime.new()
	ret:initWithName("build.queryTime")
	if uuid then
		ret:putParam("uuid", CCString:create(uuid))
	end
	if itemId then
		ret:putParam("itemId", CCString:create(itemId))
	end
    ret:send()
end

function QuertTime:handleReceive(dict)
    local flag, params = self:parseMsg(dict)
    if (type(flag) == "boolean") then
        return flag
    end

    -- dump(flag, 'QuertTime:handleReceive')
    CCSafeNotificationCenter:postNotification("ServerUpdateCostTime", params)
	return true
end

function BuildingUpController:reqQueryTime(dict)
	if dict then
		local data = dictToLuaTable(dict)
		if data then
			QuertTime.req(data.uuid, data.itemId)
		end
	end
end

return BuildingUpController