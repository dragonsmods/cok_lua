local ActBossController = class("ActBossController")
local ccud = cc.UserDefault:getInstance()

-- ActBossController.Msg_Type = {
--     MSG_UPDATE_ALLIANCE_WAR_CELL_DATA = "msg_update_alliance_war_cell_data",
--     MSG_GET_ALLIANCE_WAR_CELL_DATA = "msg.get.alliance.war.list"
-- }

local tip_tag = 335

local _instance = nil
function ActBossController.getInstance()
    if _instance == nil then
        _instance = ActBossController.new()

        assert(guiCommonGlobal.controllerAutoPurge,"!!!!!!!0000")
        guiCommonGlobal.controllerAutoPurge(_instance)
    end
    return _instance
end

--[[
    push.alliance.boss.attact | 26909000019, | 
    {"uid":"582436601001860","bossId":"902113","teamId":"14a67b4a746242d9be3d587f55a43624","name":"vi111","pic":"g026","picVer":1}
]]

function ActBossController:ctor()
    self:reset()
end

function ActBossController:fireEventRef( key, dict )
    Dprint('ActBossController:fireEvenntRef key='..key)
	if key == "openSettingDialog" then
        local view = Drequire("game.allianceBoss.ActBossSettingDialog").create()
        PopupViewController:addPopupView(view)
    elseif key == "checkScheduler" then
        self:checkScheduler(dictToLuaTable(dict))
    end
end

function ActBossController:reset(  )
    self.m_isShowing = false
    self.m_datas = {}
end

function ActBossController:refreshData( data )
    if not data then
        return
    end
    local autoTip, autoMarch = self:getSwitchData()
    -- dump(data, 'ActBossController:refreshData'..tostring(autoTip).."  "..tostring(autoMarch), 10)
    -- 自动弹提示
    if autoTip then
        table.insert(self.m_datas,data)
        self:tryShowNotifyUi()
    end
    -- 自动集结
    if autoMarch then
        self:scheduleMarch(data)
    end
end

function ActBossController:setPopShowFlag( isShow )
    self.m_isShowing = isShow
end

function ActBossController:tryHideNotifyUi(  )
    local tipLayer = SceneController:call("getCurrentLayerByLevel", LEVEL_TIP)
    if tipLayer then
        tipLayer:removeChildByTag(tip_tag)
    end
end

function ActBossController:tryShowNotifyUi(  )
    if self.m_isShowing then
        self:tryHideNotifyUi()
    end

    local data = table.remove(self.m_datas,1)
    if not data then
        return
    end

    self:setPopShowFlag(true)

    local tipLayer = SceneController:call("getCurrentLayerByLevel", LEVEL_TIP)
    if tipLayer then
        
        if tipLayer:getChildByTag(tip_tag) then
            tipLayer:removeChildByTag(tip_tag)
        end

        local hint = Drequire("game.allianceBoss.ActBossNotifyPopUp"):create(data)
        if hint then
            hint:setTag(tip_tag)
            tipLayer:addChild(hint)
        end
    end
end

function ActBossController:hasNextPushedData(  )
    return self.m_datas and next(self.m_datas)
end

function ActBossController:scheduleMarch(data)
    if self.m_entryId == nil then
        self.marchData = data
        local delay = tonumber(CCCommonUtilsForLua:call("getPropByIdGroup","data_config","monster_auto_join","k1")) or 20
        self.m_entryId = cc.Director:getInstance():getScheduler():scheduleScriptFunc(function() self:march() end, delay, false)
        LuaController:flyHint("","",getLang("5603107"))
    end
end

function ActBossController:checkScheduler(teamId)
    if self.m_entryId and self.marchData and self.marchData.teamId == teamId then
        self:cancelScheduler()
    end
end

function ActBossController:cancelScheduler()
    if self.m_entryId then
        cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.m_entryId)              
        self.m_entryId = nil
    end    
end

function ActBossController:march()
    self:cancelScheduler()

    local stamina = WorldController:call("getInstance"):getProperty("currentStamine")
    local bossDecr = GlobalData:call("shared"):getProperty("worldConfig"):getProperty("boss_decr")
    -- 判断体力是否足够
    if stamina >= bossDecr then
        local current = WorldController:call("getCurrentMarchCount")
        local max = WorldController:call("getMaxMarchCount")
        -- 判断是否有出征队列
        if current < max then
            for i = 1, 2 do
                local formatIndex = 100 + i

                local armys = {}
                local armyTotal = 0
                local solts1 = splitString(TroopsController:call("getFormatStrByIndex", formatIndex), "|")
                for _, data in ipairs(solts1) do
                    local solts2 = splitString(data, ",")
                    if #solts2 == 2 then
                        local armyId = solts2[1]
                        local armyNum = atoi(solts2[2])
                        local armyInfo = GlobalData:call("getArmyInfoById", armyId)
                        if armyInfo then
                            local free = armyInfo:getProperty("free")
                            if armyNum >= free then
                                armyNum = free
                            end
                            armyTotal = armyTotal + armyNum
                            armys[armyId] = armyNum
                        end
                    end
                end

                -- 有兵可派时，继续检查英雄、龙、阵法
                if armyTotal > 0 then
                    --英雄
                    local heroId = TroopsController:call("getFormatHeroIdByIndex", formatIndex)
                    if heroId ~= "" then
                        local data = HeroManager.getHeroInfoById(heroId)
                        if data then
                            local battle = atoi(data.battle)
                            local state = tonumber(data.state) or 1
                            if state ~= 1 or battle ~= 1 then
                                heroId = ""
                            end
                        end
                    end

                    --龙
                    local dragonUuid = TroopsController:call("getFormatDragonUUidByIndex", formatIndex)
                    if dragonUuid ~= "" then
                        local dragonInfo = DragonController:call("getDragonInfoByUuid", tostring(dragonUuid))
                        if dragonInfo then
                            if dragonInfo:call("getUseFlag") == 1 then
                                dragonUuid = ""
                            end

                            if dragonInfo:call("getInMarch") == false 
                                and dragonInfo:call("getObtain") == true
                                and dragonInfo:call("getState") == 3 then
                            else
                                dragonUuid = ""
                            end
                        end
                    end
                    
                    --阵法
                    local aormationId = TroopsController:call("getFormatAormationIdByindex", formatIndex)
                    if aormationId ~= "" then
                        local data = TacticalDepController.getInstance():getAormationData(aormationId)
                        if data then
                            if data.state ~= 0 then
                                aormationId = ""
                            end
                        end
                    end

                    -- 出征
                    local march_dict = CCDictionary:create()
                    march_dict:setObject(CCString:create(self.marchData.target_user_index), "index")
                    march_dict:setObject(CCString:create(tostring(MarchMethodType.MethodUnion)), "marchType")
                    march_dict:setObject(CCString:create(1), "ownerFlag")
                    march_dict:setObject(CCString:create(-1), "monsterIndex")
                    march_dict:setObject(CCArray:create(), "generals")
                    march_dict:setObject(CCString:create(-1), "wtIndex")
                    march_dict:setObject(CCString:create(self.marchData.teamId), "teamId")
                    march_dict:setObject(CCString:create(-1), "warehouse")
                    march_dict:setObject(CCString:create(0), "showPanel")
                    march_dict:setObject(CCString:create(0), "isSuperRally")
                    march_dict:setObject(CCString:create(0), "diyRally")
                    
                    local soldiers = CCDictionary:create()
                    for k,v in pairs(armys or {}) do
                        soldiers:setObject(CCInteger:create(v), k)
                    end
                    march_dict:setObject(soldiers, "army")

                    if heroId ~= "" then
                        march_dict:setObject(CCString:create(heroId), "generalId")
                    end

                    if dragonUuid ~= "" then
                        local dragonIndex = DragonController:call("getDragonIndexByUuid", dragonUuid)
                        march_dict:setObject(CCString:create(tostring(dragonIndex)), "dragonIndex")
                    else
                        march_dict:setObject(CCString:create(-1), "dragonIndex")
                    end

                    if aormationId ~= "" and aormationId ~= "0" then
                        march_dict:setObject(CCString:create(aormationId), "aormationId")
                    end
                    WorldController:call("getInstance"):call("sendWorldMarchCommand", march_dict)

                    -- 扣体力
                    stamina = stamina - bossDecr
                    WorldController:call("getInstance"):setProperty("currentStamine", stamina)
                    CCSafeNotificationCenter:call("postNotification", "msg_currentStamine")

                    -- 扣部队
                    for armyId, armyNum in pairs(armys or {}) do
                        local armyInfo = GlobalData:call("getArmyInfoById", armyId)
                        if armyInfo then
                            local free = armyInfo:getProperty("free")
                            local march = armyInfo:getProperty("march")
                            free = math.max(0, free - armyNum)
                            march = math.max(0, march + armyNum)
                            armyInfo:setProperty("free", free)
                            armyInfo:setProperty("march", march)
                        end
                    end

                    break
                end
            end
        end
    end

    self.marchData = nil
end

function ActBossController:getSwitchData()
    --杀戮战场集结UI提示复用年兽的
    local serverType = GlobalData:call("shared"):getProperty("serverType")
    if serverType == ServerType.SERVER_ANCESTRAL then
        return true, false, false
    end

    if self.autoTip == nil or self.autoMarch == nil or self.autoShield then
        -- self.autoTip 默认关闭
        self.autoTip = ccud:getBoolForKey(string.format("%s_ActBossAutoTip", PlayerInfoController:getUid()), false)
        self.autoMarch = ccud:getBoolForKey(string.format("%s_ActBossAutoMarch", PlayerInfoController:getUid()), false)
        self.autoShield = ccud:getBoolForKey(string.format("%s_ActBossAutoShield", PlayerInfoController:getUid()), false)
    end

    if self.autoMarch and getTimeStamp() >= self:getAutoMarchCD() then
        self.autoMarch = false
    end
    return self.autoTip, self.autoMarch, self.autoShield
end

function ActBossController:setSwitchData(value1, value2, value3)
    self.autoTip = value1
    self.autoMarch = value2
    self.autoShield = value3
    ccud:setBoolForKey(string.format("%s_ActBossAutoTip", PlayerInfoController:getUid()), value1)
    ccud:setBoolForKey(string.format("%s_ActBossAutoMarch", PlayerInfoController:getUid()), value2)
    ccud:setBoolForKey(string.format("%s_ActBossAutoShield", PlayerInfoController:getUid()), value3)
    ccud:flush()
end

function ActBossController:getAutoMarchCD()
    local cd = ccud:getIntegerForKey(string.format("%s_ActBossAutoMarchCD", PlayerInfoController:getUid()), 0)
    if cd <= 0 then
        self:resetAutoMarchCD()
    end
    return cd
end

function ActBossController:resetAutoMarchCD()
    local hour = tonumber(CCCommonUtilsForLua:call("getPropByIdGroup","data_config","monster_auto_join","k1")) or 8
    cd = getTimeStamp() + hour * 3600
    self:setAutoMarchCD(cd)
end

function ActBossController:setAutoMarchCD(cd)
    ccud:setIntegerForKey(string.format("%s_ActBossAutoMarchCD", PlayerInfoController:getUid()), atoi(cd))
    ccud:flush()
end

function ActBossController:getAutoShieldConfigNum()
    local k1 = CCCommonUtilsForLua:call("getPropByIdGroup","data_config","mass_troops_switch","k1")
    local defaultNum, maxNum = 0, 0
    if not string.isNilOrEmpty(k1) then
        local tbl = string.split(k1, "|")
        defaultNum = atoi(tbl[1])
        maxNum = atoi(tbl[2])
    end
    return defaultNum, maxNum
end

function ActBossController:getAutoShieldNum()
    return ccud:getIntegerForKey(string.format("%s_ActBossAutoShieldNum", PlayerInfoController:getUid()), 0)
end

function ActBossController:setAutoShieldNum(num)
    ccud:setIntegerForKey(string.format("%s_ActBossAutoShieldNum", PlayerInfoController:getUid()), atoi(num))
    ccud:flush()
end

function ActBossController:purge()
    self:reset()
    self:tryHideNotifyUi()
end


return ActBossController
