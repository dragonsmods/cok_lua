--[[
    新技能面板控制类
    2018.8.27   Awen
]]

-----------------------------[Commond]--------------------------
-- 技能收藏获取数据
local SkillsCollectionGetDataCmd = class("SkillsCollectionGetDataCmd", LuaCommandBase)
function SkillsCollectionGetDataCmd.req()
    local ret = SkillsCollectionGetDataCmd.new()
    ret:initWithName("skillscollection.data")
    ret:send()
end

function SkillsCollectionGetDataCmd:handleReceive(dict)
    local tbl = self:parseMsg(dict)
    if type(tbl)=='boolean' then
        return tbl
    end
    if tbl then
        NewActiveSkillController:ackCollectionData( tbl )
    end

    return true
end

-- ----------------------------------
-- 技能收藏/取消收藏
local SkillsCollectionCollectCmd = class("SkillsCollectionCollectCmd", LuaCommandBase)
function SkillsCollectionCollectCmd.req(skillid, skillType, isCollected)
    Dprint("SkillsCollectionCollectCmd.req",skillid, skillType, isCollected)
    local ret = SkillsCollectionCollectCmd.new()
    ret:initWithName("skillscollection.collect")
    ret:putParam("skillId", CCString:create(skillid))
    ret:putParam("skillType", CCInteger:create(skillType))
    ret:putParam("collect", CCInteger:create(isCollected))
    ret:send()
end

function SkillsCollectionCollectCmd:handleReceive(dict)
    local tbl = self:parseMsg(dict)
    if type(tbl)=='boolean' then
        return tbl
    end
    if tbl then
        NewActiveSkillController:ackChangeCollectState(tbl)
    end

    return true
end

-- ----------------------------------
-- 技能收藏一键使用
local SkillsCollectionBatchUseCmd = class("SkillsCollectionBatchUseCmd", LuaCommandBase)
function SkillsCollectionBatchUseCmd.req(skills)
    Dprint("SkillsCollectionBatchUseCmd.req")
    local ret = SkillsCollectionBatchUseCmd.new()
    ret:initWithName("skillscollection.batchuse")
    ret:putParam("skills", skills)
    ret:send()
end

function SkillsCollectionBatchUseCmd:handleReceive(dict)
    Dprint("SkillsCollectionBatchUseCmd:handleReceive", self.name)
    local cmdname = dict:valueForKey("cmd"):getCString()
	if cmdname ~= self.name then
		return false
	end
	local params = dict:objectForKey("params")
	if nil == params then
		return true
    end
    
    if params:objectForKey("errorCode") ~= nil then
		local errorCode = params:valueForKey("errorCode"):getCString()
		MyPrint("NewUseSkillCommand:handleReceive ... errorCode .. " .. errorCode)
		CCCommonUtilsForLua:call("flyText", getLang(errorCode))
		return true
	end


    NewActiveSkillController:ackOneKeyUse(params)
    return true
end
-------------------------------------------[NewActiveSkillController]------------------
NewActiveSkillController = NewActiveSkillController or {}

local SKILL_GENERAL = 0 --领主技能
local SKILL_DRAGON = 1  --龙技能
local SKILL_HERO = 2    --英雄技能

-- 配置item值
function NewActiveSkillController:initConfig( dataConfig )
    self.v_activeCnt = 0  --可使用技能数量

    if dataConfig then
        local _list = dataConfig:objectForKey('activity_skill_polish')
        if _list then
            local data = dictToLuaTable(_list)
            if data then
                self.v_maxCount = tonumber(data.k1)	or 0	-- k1=可收藏的最大值
                --清空helper技能数据
                require("game.CommonPopup.NewActiveSkillHelper"):clearSkillByType()
            end
        end
	end	
end

-- ----------------------------------
-- 获取技能收藏数据
function NewActiveSkillController.reqCollectionData()
    SkillsCollectionGetDataCmd.req()
end

-- 解析技能收藏数据
function NewActiveSkillController:ackCollectionData(data)
    if data and data.collected_skills then
        self.v_data = {}
        for k,v in pairs(data.collected_skills) do
            if v.skill_id ~= '' and v.collect_state == '1' then
                local _item = {
                    id = v.skill_id, 
                    type = tonumber(v.skill_type) or 0,
                    state = tonumber(v.collect_state) or 0
                }
                self.v_data[v.skill_id] = _item
            end
        end
        CCSafeNotificationCenter:postNotification("ActiveSkillView.updateUICallback")
    end
end

function NewActiveSkillController:getData(  )
    return self.v_data
end

-- 获得当前数量和最大数量
function NewActiveSkillController:getCount(  )
    if self.v_data then
        local _count = 0
        for k,v in pairs(self.v_data) do
            if v.state == 1 then
                _count = _count + 1
            end
        end
        return _count,self.v_maxCount
    end
    return 0,self.v_maxCount
end

-- 判断技能是否已收藏
-- 收藏状态 0未收藏，1已收藏
function NewActiveSkillController:isCollected(skillid)
    -- Dprint("NewActiveSkillController:isCollected", skillid)
    if self.v_data and self.v_data[skillid] then
        return self.v_data[skillid].state > 0
    end
    return false
end

-- ----------------------------------
-- 获取技能类型
-- skilltype：0是领主技能， 1是龙技能， 2是英雄技能
function NewActiveSkillController:getSkillType( page, skillid )
    local _skillType = -1
    if page == "general" then
        _skillType = SKILL_GENERAL
    elseif page == "dragon" then
        _skillType = SKILL_DRAGON
    elseif page == "hero" then
        _skillType = SKILL_HERO
    else
        if self.v_data and self.v_data[skillid] then
            _skillType = tonumber(self.v_data[skillid].skill_type) or SKILL_GENERAL
        end
    end
    return _skillType
end

-- 请求修改收藏状态
function NewActiveSkillController:reqChangeCollectState(page, skillid)
    Dprint("NewActiveSkillController:reqChangeCollectState",page, skillid)
    local _state = self:isCollected(skillid)
    local _skillType = self:getSkillType(page, skillid)
    local _newState = _state and 0 or 1
    if _newState > 0 then
        local _count, _maxCount = self:getCount()
        if _count >= _maxCount then
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("180215"))  --180215=收藏已达上限
            return
        end
    end
    SkillsCollectionCollectCmd.req(skillid, _skillType, _newState)
end

-- 解析修改收藏状态
function NewActiveSkillController:ackChangeCollectState(data)
    if data then
        if data.collect_state == '1' then
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("180213"))  -- 180213=添加收藏成功
        else
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("180214"))  -- 180214=取消收藏成功
        end
        local _state = tonumber(data.collect_state) or 0
        if self.v_data == nil then
            self.v_data = {}
        end
        if self.v_data[data.skill_id] == nil then
            local _item = {
                id = data.skill_id, 
                type = tonumber(data.skill_type) or 0,
                state = _state
            }
            self.v_data[data.skill_id] = _item
        else
            self.v_data[data.skill_id].state = _state
        end
        
        CCSafeNotificationCenter:postNotification("ActiveSkillView.updateCollectRate")
    end
end

-- ----------------------------------
-- 请求一键使用
function NewActiveSkillController:reqOneKeyUse()

    self.v_activeCnt = 0
    local _skills = CCArray:create()
    local _oneKeySkills = {}

    for k,v in pairs(self.v_data or {}) do
        if v.state == 1 then
            local _isActive = false --技能是否已激活
            local _isInCD = false   --技能是否处于CD状态
            local _canUse = false   --是否可以一键使用
            local _tableName = nil  --技能对应的表名
            local _id = nil         --龙则传龙id、英雄技能传英雄id、领主传guid
            if v.type == SKILL_GENERAL then--0是领主技能
                local _generalInfo = GlobalData:call("getSelfGeneralInfo")
                if _generalInfo then
                    _isActive = _generalInfo:call("checkHaveStudy", v.id, self.generalEnabledId)
                    if _isActive then
                        local _cdinfo = GeneralManager:call("getSkillCDInfoById", v.id)
                        
                        local _gapTime = 0
                        local _effectTime = 0
                        if _cdinfo and _cdinfo:getProperty("endTime") ~= 0 then
			                local _nowWorldTime = GlobalData:call("getWorldTime")
                            _gapTime = _cdinfo:getProperty("endTime") - _nowWorldTime
                            if _cdinfo:getProperty("effectEndTime") ~= 0 then
                                _effectTime = _cdinfo:getProperty("effectEndTime") - _nowWorldTime
                            end
                        end
                        _isInCD = _gapTime > 0 or _effectTime > 0
                        _tableName = 'sk'

                        local ginfo = GlobalData:call("getSelfGeneralInfo")
                        _id = tostring(ginfo:getProperty("uuid"))
                    end
                end
            elseif v.type == SKILL_DRAGON then--1是龙技能
                local _data = DragonActiveSkillManager.getInstance():getDataById(v.id)
                if _data then
                    _isActive = _data:getIsUnLocked()
                    if _isActive then
                        _isInCD = _data:isActive() or _data:isInCD()
                        _tableName = 'dragon_skill'
                        _id = CCCommonUtilsForLua:call("getPropByIdGroup", "dragon_skill", v.id, "born_dragon")
                    end
                end
            elseif v.type == SKILL_HERO then--2是英雄技能
                local _info = HeroManager.getActiveSkillInfoById(v.id)
                if _info then
                    _isActive = _info:isObtain()
                    if _isActive then
                        _isInCD = _info:isActive() or _info:isInCD()
                        _tableName = 'general_skill'
                        _id = _info:getHeroId()
                    end
                end
            end
            
            if (not _isInCD) then
                local _isUse = tonumber(CCCommonUtilsForLua:call("getPropByIdGroup", _tableName, v.id, "can_batch_use")) or 0
                _canUse = (_isUse == 1)
            
                Dprint("NewActiveSkillController:reqOneKeyUse id", v.id, v.type, _isActive, _isInCD, _tableName, _canUse)
                if _isActive then
                    self.v_activeCnt = self.v_activeCnt + 1
                    if _canUse then
                        local _dict = CCDictionary:create()
                        _dict:setObject(CCString:create(v.id), "skillId")
                        _dict:setObject(CCInteger:create(v.type), "skillType")
                        _dict:setObject(CCString:create(_id), "id")
                        _skills:addObject(_dict)

                        _oneKeySkills[v.id] = v.type
                    end
                end
            else
                Dprint("NewActiveSkillController:reqOneKeyUse id", v.id, v.type, _isActive, _isInCD)
            end
        end
    end

    if _skills:count() > 0 then
        SkillsCollectionBatchUseCmd.req(_skills)
        require("game.CommonPopup.NewActiveSkillHelper"):insertOnekeySkills(_oneKeySkills)
    else
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("180219"))  -- 180219=没有可使用的技能
    end
end

-- 解析一键使用
function NewActiveSkillController:ackOneKeyUse(params)
    if params:objectForKey("skillsArray") then
	    local _array = tolua.cast(params:objectForKey("skillsArray"), "CCArray")
        if _array then
            local _num = _array:count()
            for i = 0, _num - 1 do
                local _dict = tolua.cast(_array:objectAtIndex(i), "CCDictionary")
                if _dict then
                    _skillType = _dict:valueForKey("skill_type"):intValue()
                    if _skillType == SKILL_GENERAL then      --------------------------------------------------
                        local _skillId = _dict:valueForKey("skillId"):getCString()
                        _dict:setObject(CCString:create(_skillId), "cacheSkillId")
                        GeneralManager:call("updateOneSkillCDInfo", _dict)
                        local effectState = _dict:objectForKey("effectState")
                        if effectState and effectState:objectForKey("501051") then
                            local protectTime = effectState:valueForKey("501051"):doubleValue()
                            local playerInfo = GlobalData:call("getPlayerInfo")
                            playerInfo:setProperty("resourceProtectTimeStamp", protectTime)
                        end
                        if _dict:objectForKey("use_item") then
                            ToolController:call("pushAddTool", _dict:objectForKey("use_item"))
                        end
	                    CCSafeNotificationCenter:call("postNotification", "msg_useskillcmd_success", _dict)
                    elseif _skillType == SKILL_DRAGON then  --------------------------------------------------
			            DragonActiveSkillManager.getInstance():endUseSkill(_dict)
                    elseif _skillType == SKILL_HERO then    --------------------------------------------------
                        HeroManager.initHeroInfo(_dict)
                        CCSafeNotificationCenter:call("postNotification", "hero_info_refresh")

                        -- [awen] 需要特殊处理的技能
	                    local tbl = dictToLuaTable(_dict)
                        if tbl.infoDic then
                            if tbl.infoDic.skillId == '54096' then --54096：魔镜技能，使用后需要打开魔镜结果框
                                local lua_path = "game.mirro.MirroSelectView"
                                PopupViewController:addPopupView(Drequire(lua_path):create2(dict))
                            elseif tbl.infoDic.skillId == '54102' then --54102：圣光普照，使用后需要更新兵营和医院
                                if tbl.army then
                                    local armylist = GlobalData:call("shared"):getProperty("armyList")
                                    for k,v in pairs(tbl.army) do
                                        if armylist[v.id] then
                                            armylist[v.id]:setProperty("free", tonumber(v.free))
                                        else
                                            Dprint('[HeroUseSkillCmd:handleReceive] error not find armyid',v.id)
                                        end
                                    end
                                end

                                local treatList = GlobalData:call("shared"):getProperty("treatList")
                                if tbl.cureArmy then
                                    for k,v in pairs(tbl.cureArmy) do
                                        if treatList[v.id] then
                                            treatList[v.id]:setProperty("heal", tonumber(v.cureValue))
                                        else
                                            Dprint('[HeroUseSkillCmd:handleReceive] heal error not find treatList',v.id)
                                        end
                                    end
                                end			
                                if tbl.deadArmy then
                                    -- 先清空本地伤兵，再覆盖新数据
                                    for k,v in pairs(treatList) do
                                        if tonumber(v:getProperty("dead")) > 0 then
                                            v:setProperty("dead", 0)
                                        end
                                    end
                                    for k,v in pairs(tbl.deadArmy) do
                                        if treatList[v.id] then
                                            treatList[v.id]:setProperty("dead", tonumber(v.deadNum))
                                        else
                                            Dprint('[HeroUseSkillCmd:handleReceive] dead error not find treatList',v.id)
                                        end
                                    end
                                end

                                CCSafeNotificationCenter:postNotification("armyNumChange")
                                CCSafeNotificationCenter:postNotification("msg_troops_change")
                                CCSafeNotificationCenter:postNotification("go.to.healthing")

                                -- 完成本地队列
                                local qType = CCCommonUtilsForLua:call("getQueueTypeByBuildType", FUN_BUILD_HOSPITAL)
                                local qid = 0
                                if qType ~= -1 then
                                    qid = QueueController:call("getMinTimeQidByType", qType)

                                    local qInfos = GlobalData:call("shared"):getProperty("allQueuesInfo")
                                    local qInfo = qInfos[qid]
                                    if qInfo then
                                        qInfo:setProperty('finishTime', 0)
                                        qInfo:setProperty('startTime', 0)
                                        qInfo:setProperty('totalTime', 0)
                                        qInfo:setProperty('canHelp', false)
                                        qInfo:setProperty('key', '')
                                        
                                        CCSafeNotificationCenter:postNotification("msg_queue_remove")
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
    local _sucCount = params:valueForKey("successUseCount"):intValue()
    local _failCount = params:valueForKey("failedUseCount"):intValue()
    if _sucCount > 0 then
        -- 180220=成功使用了{0}个技能，有{1}个技能无法一键使用。
        YesNoDialog:call("show", getLang("180220", _sucCount, self.v_activeCnt - _sucCount))
        CCSafeNotificationCenter:postNotification("ActiveSkillView.updateUICallback")
    else
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("180219"))  -- 180219=没有可使用的技能
    end
end



return NewActiveSkillController