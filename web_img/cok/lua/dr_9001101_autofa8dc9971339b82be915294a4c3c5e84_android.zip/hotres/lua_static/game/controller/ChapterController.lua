--[[ 
    章节任务控制类
 ]]
ChapterController = class("ChapterController")
local _instance = nil
function ChapterController.getInstance()
    if _instance == nil then
        _instance = ChapterController.new();
    end
    return _instance;
end

function ChapterController:ctor()
    self.task_list   = {}
    self.m_base_task = nil --章节奖励服务器按照任务方式处理，整个章节是一个任务， 章节任务完成才算完成
    self.chapter_dict = nil
    self.m_isNeedRefresh = true
    self.m_StoryIsOver = true
    self.m_is_oldAccount = true
    self.m_completeCnt = 0
end

function ChapterController:purgeData( )
    _instance = nil
end

function ChapterController:praseData( dic )
    self.task_list = {}
    local param = dictToLuaTable(dic:objectForKey("params")) 
    if param.storyTaskList == nil then
        return 
    end
    
    self.index = param.section
    -- 拆分任务
    for id,task in pairs(param.storyTaskList) do 
        if task.type == '0' then    -- 章节任务
            self.m_base_taskid = task.id 
            self.m_base_task   = task
        else    -- 普通任务
            table.insert(self.task_list, task)
        end
        if task.state ~= '2' then
            self.m_StoryIsOver = false
        end
    end
    -- dump(self.task_list, "ChapterController:praseData "..tostring(self.m_StoryIsOver))
    -- 按id有小到大排序
    table.sort(self.task_list,function (a, b)
        local orderA = atoi(CCCommonUtilsForLua:call("getPropByIdGroup","story_setting",a.id,"order"))
        local orderB = atoi(CCCommonUtilsForLua:call("getPropByIdGroup","story_setting",b.id,"order"))
        if orderA == orderB then
            return atoi(a.id) < atoi(b.id)
        else
            return orderA < orderB
        end
    end)

    if UiCompoentControoller.getCompoentLayer() then
        UiCompoentControoller.getCompoentLayer():refreshChapgerNode(not self.m_StoryIsOver) 
    end

    -- 章节信息
    if self.chapter_dict == nil then
        self.chapter_dict = CCCommonUtilsForLua:getGroupByKey("story_group")
    end

    for k,v in pairs(self.chapter_dict ) do
       local group = tonumber(v.group) or 0
       local index = tonumber(self.index) or 0
       if group == index then
            self.m_base = v
       end
    end

    self.m_isNeedRefresh = false

    self.m_completeCnt = self:getCompeleteCnt()
    CCSafeNotificationCenter:postNotification("chapterInfo_refresh")

    cc.UserDefault:getInstance():setBoolForKey("isChapterOver", self.m_StoryIsOver)
    cc.UserDefault:getInstance():flush()
end

function ChapterController:pushTaskBylist( list )
    for id,task in pairs(list) do 
        if self.task_list[id] == nil then

            self.task_list[id] = task

        end
        if self.task_list[id].state ~= '2' then
            self.m_StoryIsOver = false
        end
    end

    if UiCompoentControoller.getCompoentLayer() then
        UiCompoentControoller.getCompoentLayer():refreshChapgerNode(not self.m_StoryIsOver) 
    end
end

function ChapterController:completeTask( task_id )
    for k,v in pairs(self.task_list) do 
        if tonumber(v.id) == tonumber(task_id) then
            v.state = '2' --标记已经完成
            self.m_completeCnt = self:getCompeleteCnt()
            CCSafeNotificationCenter:postNotification("chapterInfo_refresh")
            return
        end
    end
end

function ChapterController:setTaskStatus( is_need_refresh , dic )
    self.m_isNeedRefresh = is_need_refresh
    if dic then
        local param = dictToLuaTable(dic)
        self.m_completeCnt = tonumber(param["unGetRewardTaskNum"])
        CCSafeNotificationCenter:postNotification("chapterInfo_refresh")
    end
end

function ChapterController:sendGetChapterList( ... )
    --章节未开 不发送数据
    Dprint("ChapterController:sendGetChapterList")
    if CCCommonUtilsForLua:isFunOpenByKey("new_story_guide")  == false then 
        return 
    end 
    local command = require("game.command.ChapterRefreshCommand"):create()
    command:send()
end

function ChapterController:openChapterView()
    self:sendGetChapterList()
    local view = Drequire("game.chapter.ChapterViewEx"):create()
    PopupViewController:call("addPopupView", view)
end

-- 打开章节介绍界面
function ChapterController:openChapterIntroView( data )
    local view = Drequire("game.chapter.ChapterIntroView").create(data)
    PopupViewController:addPopupView(view)
end

function ChapterController:getFirstChapterData()
    local chapter_dict = CCCommonUtilsForLua:getGroupByKey("story_group")
    return chapter_dict["33130000"]
end

function ChapterController:setIsOldAccount(is_oldAccount )
    self.m_is_oldAccount = is_oldAccount
    if UiCompoentControoller.getCompoentLayer() then
        UiCompoentControoller.getCompoentLayer():refreshChapgerNode(not self.m_is_oldAccount) 
    end
end

function ChapterController:fireEventRef( key, dict )
    Dprint("ChapterController:fireEventRef", key)
    if key == "checkOver" then
        self.m_StoryIsOver = true
        for id,task in pairs(self.task_list) do 
            if task.state ~= '2' then
                self.m_StoryIsOver = false
                break
            end
        end

        if UiCompoentControoller.getCompoentLayer() then
            UiCompoentControoller.getCompoentLayer():refreshChapgerNode(not self.m_StoryIsOver) 
        end

        if self:isChapterOpen() then
            dict:setObject(CCString:create('1'), "state")
        end
	end
end

function ChapterController:isChapterOpen()
    if isFunOpenByKey("new_story_guide") and isFunOpenByKey("chapter_task_on") then
        return (not self.m_StoryIsOver)
    end
    return false
end

function ChapterController:isChapterLocked()
    local tip = ""
    local locked = true
    if self.m_base and self.m_base.mclevel then
        local mainCityLv = FunBuildController:call("getMainCityLv")
        if mainCityLv == 30 then
            mainCityLv = mainCityLv + FunBuildController:call("getMainCityHonorLv")
        end
        locked = mainCityLv < tonumber(self.m_base.mclevel)
        if locked then
            tip = getLang("9700463", tostring(self.m_base.mclevel))
        end
    end
    return locked,tip
end

function ChapterController:isTaskDone(taskid)
    if string.isNilOrEmpty(taskid) then
        return false
    end
    
    for _,v in ipairs(self.task_list) do 
        if v.id == taskid and v.state ~= '0' then --已经完成
            return true
        end
    end
    return false
end

function ChapterController:getChapterBase()
    return self.m_base
end

function ChapterController:getCHapterData( index )
    if self.chapter_dict == nil then
        self.chapter_dict = CCCommonUtilsForLua:getGroupByKey("story_group")
    end
    for k,v in pairs(self.chapter_dict ) do
       local group = tonumber(v.group) or 0
       local index = tonumber(index) or 0
       if group == index then
            return v
       end
    end
    return nil
end

-- 获取第一个未完成的任务信息
function ChapterController:getUnDoneTaskInfo()
    for k,v in pairs(self.task_list) do 
        if tonumber(v.state) == 0 then
            return v
        end
    end
    return nil
end

function ChapterController:getChapterProString(  )
    local str = ""
    if self.index then 
        local p,t = self:getNormalTaskProgress()
        local str = CCCommonUtilsForLua:call("getParamByGroupAndKey", "story_group", "group", tostring(self.index), "pic_title_dialog")
        Dprint(str, self.index, "getChapterProString+++")
        return getLang(str), p, t
    end
    return "", 0, 0
end

--【Awen】获取普通任务的进度
function ChapterController:getNormalTaskProgress(  )
    local _total = 0
    local _process = 0
    for k,v in pairs(self.task_list) do 
        _total = _total + 1
        if v.state ~= '0' then --已经完成
            _process = _process + 1
        end
    end
    return _process, _total
end

--2是已领取，1是已完成，0是未完成
function ChapterController:getProgress( ... )
    local total = #self.task_list
    local  now  = 0 
    for k,v in pairs(self.task_list) do 
        if  tonumber(v.state) == 1 then --已经完成
            now = now + 1
        end
    end
    return now ,total
end

function ChapterController:getCompeleteCnt()
    local now  = 0 
    for k,v in pairs(self.task_list) do 
        if tonumber(v.state) == 1 then --已经完成
            now = now + 1
        end
    end
    return now
end

function ChapterController:getBaseTaskId ()
    return self.m_base_taskid
end

function ChapterController:setReward( rewards)
    self.m_rwdData = rewards
end

function ChapterController:getRewards(id)
    local cmd = Drequire("game.command.DailyTaskBoxRewardCommand").create(id);
    cmd:send();
end 

function ChapterController:updateReward(rewards)
    local arr = arrayToLuaTable(rewards)
    require("game.chapter.ChapterView").refreshReward(arr)
end                                                    

-- -------------------------------------------------------
-- 全部领取
local GetAllRewardCmd = class("GetAllRewardCmd",LuaCommandBase)
local GetAllRewardCmdName = "story.task.batchreward"
function GetAllRewardCmd.req(taskIds)
    local ret = GetAllRewardCmd.new()
    ret:initWithName(GetAllRewardCmdName)
    ret:putParam("taskIds", CCString:create(taskIds))
    ret:send()
end

function GetAllRewardCmd:handleReceive(dict)
    if (dict:valueForKey("cmd"):getCString() ~= GetAllRewardCmdName) then
        return false
    end
    
    local params = dict:objectForKey("params")
    if params == nil then
        return true
    end
    if params:objectForKey("errorCode") ~= nil then
        local pStr = params:valueForKey("errorCode"):getCString()
        CCCommonUtilsForLua:call("flyText",_lang(pStr))
    else
        local arr = params:objectForKey("rewardArray")
        arr = arrayToLuaTable(arr)
        if arr then
            local _rewardArray = {}
            for k,v in pairs(arr) do
                for _, vv in pairs(v) do
                    table.insert(_rewardArray, vv)
                end
            end
            local _cArray = luaToArray(_rewardArray)
            PortActController:call("flyReward", _cArray, true)
            RewardController:call("retReward", _cArray)
        end
        CCSafeNotificationCenter:postNotification("MSG_GET_TASK_REWARD")
    end

    return true
end

function ChapterController:reqAllReward(taskList)
    local _taskIds = ''
    for i,v in ipairs(taskList) do
        _taskIds = _taskIds .. v
        if i < #taskList then
            _taskIds = _taskIds .. ';'
        end
    end
    GetAllRewardCmd.req(_taskIds)
end

return ChapterController