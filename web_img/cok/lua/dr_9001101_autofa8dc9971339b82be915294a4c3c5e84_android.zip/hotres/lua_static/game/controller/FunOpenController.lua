--[[
	功能开关控制类
	2019.6.20	Awen
]]

FunOpenController = class("FunOpenController")

-- k1-k5分别是礼包图标、日常奖励、活动图标、传送门、技能图标
-- k1="8" k2="5" k3="10" k4="15" k5="15"

FUN_ICON_UI_Gift			= "k1"		--【Awen】右上角礼包
FUN_ICON_UI_Welfare			= "k2"		--【Awen】右上角日常奖励
FUN_ICON_UI_Active			= "k3"		--【Awen】右侧活动
FUN_ICON_UI_CrossServer		= "k4"		--【Awen】左下角传送门图标
FUN_ICON_UI_Skill			= "k5"		--【Awen】右下角技能图标
FUN_ICON_UI_CITYBUFF		= "k6"		--【Awen】大本功能按钮：城市增益
FUN_ICON_UI_AVATAR			= "k7"		--【Awen】大本功能按钮：装扮
FUN_ICON_CIV_UNLOCK			= "k8"		--【Awen】选文明开启
FUN_PRINCESS				= "k9"		--【Awen】小公主开启等级

local FUN_CONFIG = {
	["9990002"]		= { -- 活动中心
		msg = "msg_init_activity_event",
		icon = "hd_center_2.png",
	},
	["9990004"]		= { -- 客服中心
		msg = "ImperialScene::createCustomerService",
		icon = "how-play.png",
	},
	["9990005"]		= { -- 酒馆
		msg = "ImperialScene::createTavern",
		icon = "club.png",
	},
	["9990012"]		= { -- 兄弟会
		msg = "ImperialScene::createHouseOfBrotherhood",
		icon = "picxiongdihui.png",
	},
	["9990021"]		= { -- 小公主
		msg = "initHero",
		json = "heroxiaogongzhu.json",
		atlas = "Imperial_32.atlas",
		animName = "xx",
	},
	["9990027"]		= { -- 文明圣殿
		msg = "ImperialScene::createPrestige",
		icon = "prestige.png",
	},
	["419000"]		= { -- 城墙
		icon = "pic419000_cm_2.png",
	},
	["430000"]		= { -- 作坊
		msg = "ImperialScene::createBuilding",
		icon = "pic430000_2_1.png",
	},
	["432000"]		= { -- 上古龙塔
		msg = "ImperialScene::createBuilding",
		icon = "pic432000_2.png",
	},
	["443000"]		= { -- 文明堡垒
		msg = "ImperialScene::createBuilding",
		icon = "pic443000_2.png",
	},
	["b_arena"]		= { -- 皇家角斗场
		msg = "TournamentNpc:updateUI",
		icon = "pictournament.png",
	},
	["act_57365"] 	= { -- 跑环小船
		msg = "ImperialScene:createFestivalActNpc",
		icon = "ICON_runningAct.png",
	},
	["ui_advideo"]	= { -- 主页视频广告入口
		msg = "LuaAdController:refreshData",
		icon = "item607.png",
	},
	["9990009"]		= { -- 码头
		msg = "ImperialScene::createPort",
		icon = "matou_fangzi.png",
	},
	["ui_worldcraft"]={ -- 世界争霸
		icon = "icon_craft.png",
		call = function()
			require("game.worldCraft.match.MatchController").getInstance():createUIIcon()
		end
	},
	["ui_dragons8"]	= { -- 巨龙战役
		icon = "DBSE_icon_enter.png",
		call = function()
			require("game.dragonBattle.S8.DragonBattleS8Controller").getInstance():createUIIcon()
		end
	},
	["act_57153"] 	= { -- 黄金宝箱
		json = "Npc_Angel_face.json",
		atlas = "sk_Npc_Angel_face.atlas",
		animName = "dj",
	},
	["ui_toprank"]	= { -- 雕像：排行榜
		icon = "ICON_ranking_jgsl.png",
	},
	["ui_throne"]	= {
		icon = "csa_icon_01.png",
	},
	["ui_lordHonor"]= {
		icon = "ICON_info_chengjiu.png",
	},
	["ui_lordBuff"] = {
		icon = "oneKeyBuffFight.png",
	},
	["ui_lordChgEquip"] = {
		icon = "ICON_info_shuaxin.png",
	},
	["ui_lordSkill"]= {
		icon = "ICON_info_tianfu.png",
	},
	["fun_vip"]= {
		post = "vip.refresh",
	},
	["fun_store"]= {
		post = "guide_ui_button_hide",
	},
	["fun_mail"]= {
		post = "guide_ui_button_hide",
	},
	["act_theme"]= {
		post = "msg.activity.init",
	}
}

-- 配置item值
function FunOpenController:initConfig( dict )
	self.v_data = dictToLuaTable(dict:objectForKey("icon_view"))
end

-- 接收CPP调用
function FunOpenController:fireEventRef(newKey, dict)
    Dprint("FunOpenController:fireEventRef", newKey)
    if newKey == "isOpen" then
		local _type = dict:valueForKey("type"):getCString()
		if self:isOpen(_type) then
			dict:setObject(CCString:create("1"), "state")
		end
	elseif newKey == "isOpen2" then
		local _type = dict:valueForKey("type"):getCString()
		if self:isOpen2(_type) then
			dict:setObject(CCString:create("1"), "state")
		end
	elseif newKey == "setData" then
		self.eraIndex = dict:valueForKey("eraIndex"):intValue()
	elseif newKey == "getData" then
		if self.v_data then
			local _keys = dict:valueForKey("keys"):getCString()
			for i, v in ipairs(string.split(_keys, ";") or {}) do
				if self.v_data[v] then
					dict:setObject(CCString:create(self.v_data[v]), v.."value")
				end
			end
		end
	elseif newKey == "isShow" then
		local _keys = dict:valueForKey("keys"):getCString()
		local _def = dict:valueForKey("def"):intValue() == 0
		for i, v in ipairs(string.split(_keys, ";") or {}) do
			if self:isShowAndDef(v, _def) then
				dict:setObject(CCString:create("1"), v.."value")
			end
		end
	elseif newKey == "isUnlock" then
		local _keys = dict:valueForKey("keys"):getCString()
		local _hint = dict:valueForKey("hint"):intValue() > 0
		for i, v in ipairs(string.split(_keys, ";") or {}) do
			if self:isUnlock(v, _hint) then
				dict:setObject(CCString:create("1"), v.."value")
			end
		end
	elseif newKey == "lockConfig" then
		local _keys = dict:valueForKey("keys"):getCString()
		for i, v in ipairs(string.split(_keys, ";") or {}) do
			local config = self:lockConfig(v, true)
			if string.isNilOrEmpty(config) == false then
				dict:setObject(CCString:create(config), v.."value")
			end
		end
	elseif newKey == "unlockLevel" then
		local _keys = dict:valueForKey("keys"):getCString()
		for i, v in ipairs(string.split(_keys, ";") or {}) do
			local buildId, buildLevel = self:unlockLevel(v, 0)
			if atoi(buildId) > 0 then
				dict:setObject(CCString:create(buildId), v.."buildId")
				dict:setObject(CCString:create(buildLevel), v.."buildLevel")
			end
		end
	elseif newKey == "check" then
		self:check()
	elseif newKey == "getGuideMonsterReward" then
		self:getGuideMonsterReward()
    end
end

function FunOpenController:isOpen(type)
	if CCCommonUtilsForLua:isFunOpenByKey("new_story_guide") then
		return self:isOpen2(type)
	end
	return true
end

function FunOpenController:isOpen2(type)
	-- dump(self.v_data, 'FunOpenController:isOpen '..type)
	if self.v_data then
		local _mainCityLv = self:getMainCityLv()
		local _limitCityLv = tonumber(self.v_data[type]) or 0
		return _mainCityLv >= _limitCityLv
	end
	return false
end

function FunOpenController:getLimitLv(type)
	return tonumber(self.v_data[type]) or 0
end

function FunOpenController:initData()
	if table.isNilOrEmpty(self.xmlData) then
		self.fo_functionopen = isFunOpenByKey("functionopen")

		self.xmlData = {}
		local data = CCCommonUtilsForLua:getGroupByKey("functionopen")
		for k,v in pairs(data or {}) do
			self.xmlData[v.FunctionString] = v
		end

		local serverOpenTimeForUser = GlobalData:call("shared"):getProperty("serverOpenTimeForUser")
		self.severOpenDays = math.floor(serverOpenTimeForUser / Seconds_Per_Day)
		local regTime = PlayerInfoController:getRegTime()
		self.regDays = math.floor(regTime / 1000 / Seconds_Per_Day)
	end
end

function FunOpenController:setBuildConfig()
	self:initData()
	if self.fo_functionopen then
		for k,v in pairs(self.xmlData or {}) do
			if v.Type == "1" then
				if v.unlockParams == nil then
					v.unlockParams = string.splitNSep(v.ShowParameter2, ":")
				end
				if #v.unlockParams >= 2 then
					local buildType = FunBuildController:call("getMaxLvBuildByType", atoi(k))
					if buildType > 0 then
						local buildInfo = FunBuildController:call("getFunbuildForLua", buildType)
						if buildInfo then
							buildInfo:setProperty("relationBuildId", atoi(v.unlockParams[1]))
							buildInfo:setProperty("open", atoi(v.unlockParams[2]))
						end
					end
				end
			end
		end
	end
end

function FunOpenController:check()
	self:initData()
	if self.fo_functionopen then
		for k,v in pairs(self.xmlData or {}) do
			if not v.show then
				if self:isShowWithConfig(v) then
					self:checkRefresh(k)
				end
			end
			
			if not v.unlock then
				if self:isUnlockWithConfig(v) then
					self:checkRefresh(k)
				end
			end
		end
	end
end

function FunOpenController:checkRefresh(id)
	if table.isNilOrEmpty(FUN_CONFIG[id]) == false then
		local msg = FUN_CONFIG[id].msg
		if string.isNilOrEmpty(msg) == false then
			CCSafeNotificationCenter:postNotification(msg, CCString:create(id))
		elseif FUN_CONFIG[id].call then
			FUN_CONFIG[id].call()
		end
	end
end

function FunOpenController:isShow(key)
	self:initData()
	if self.fo_functionopen and self.xmlData then
		local config = self.xmlData[key]
		if config then
			return self:isShowWithConfig(config)
		end
	end
	return true
end

function FunOpenController:isShowAndDef(key, default)
	self:initData()
	if self.fo_functionopen and self.xmlData then
		local config = self.xmlData[key]
		if config then
			return self:isShowWithConfig(config)
		end
	end
	return default
end

function FunOpenController:isShowWithConfig(config)
	if config then
		if not config.show then
			if config.ShowOption == "2" then		--判断主堡是否达成
				if config.showParams == nil then
					config.showParams = string.splitNSep(config.ShowParameter1, ":")
				end
				if #config.showParams >= 2 then
					local buildType = atoi(config.showParams[1])
					if buildType == FUN_BUILD_MAIN then
						config.show = self:getMainCityLv() >= atoi(config.showParams[2])
					else
						local buildLevel = FunBuildController:call("getBuildLvByType", buildType)
						config.show = buildLevel >= atoi(config.showParams[2])
					end
				end
			end
		end
		return config.show
	end
	return true
end

function FunOpenController:isUnlock(key, hint)
	self:initData()
	if self.fo_functionopen and self.xmlData then
		local config = self.xmlData[key]
		return self:isUnlockWithConfig(config, hint)
	end
	return true
end

function FunOpenController:isUnlockWithConfig(config, hint)
	if config then
		if not config.unlock then
			if config.UnlockOption == "2" then		--判断主堡是否达成
				if config.unlockParams == nil then
					config.unlockParams = string.splitNSep(config.ShowParameter2, ":")
				end

				if #config.unlockParams >= 2 then
					local buildType = atoi(config.unlockParams[1])
					if buildType == FUN_BUILD_MAIN then
						local unlockParams = atoi(config.unlockParams[2])
						config.unlock = self:getMainCityLv() >= unlockParams

						local dOption = false
						if string.isNilOrEmpty(config.andor) == false then
							if "1" == config.DayOption then	--开服天数
								dOption = self.severOpenDays >= atoi(config.DayParameter)
							elseif "2" == config.DayOption then	--注册天数
								dOption = self.regDays >= atoi(config.DayParameter)
							elseif "3" == config.DayOption then	--纪元等级
								dOption = self.eraIndex >= atoi(config.DayParameter)
							end
							if config.andor == "1" then	--and
								config.unlock = config.unlock and dOption
							elseif config.andor == "2" then	--or
								config.unlock = config.unlock or dOption
							end
						end
						if config.unlock == false and hint then
							if dOption == false and config.andor == "1" then
								if "1" == config.DayOption then
									-- 52187131=功能需要第{0}天才可以开启
									LuaController:flyHint("", "", getLang("52187131", config.DayParameter))
								elseif "2" == config.DayOption then
									-- 52187132=功能{0}天后才可以开启
									LuaController:flyHint("", "", getLang("52187132", atoi(config.DayParameter) - self.regDays))
								elseif "3" == config.DayOption then	--纪元等级
									LuaController:flyHint("", "", getLang("650223"))--650223=当前未解锁
								end
							else
								--101603=城堡等级达到{0}解锁该功能
								if unlockParams > 30 then
									local text = string.format("%s%d", getLang("160001"), unlockParams - 30)--160001=荣耀
									LuaController:flyHint("", "", getLang("101603", text))
								else
									LuaController:flyHint("", "", getLang("101603", config.unlockParams[2]))
								end
							end
						end
					else
						local buildLevel = FunBuildController:call("getBuildLvByType", buildType)
						config.unlock = buildLevel >= atoi(config.unlockParams[2])
					end
				end

			end
		end
		if config.unlock then
			config.show = true
		end
		return config.unlock
	end
	return true
end

function FunOpenController:unlockLevel(key, default)
	self:initData()
	if self.fo_functionopen and self.xmlData then
		local config = self.xmlData[key]
		if config then
			if config.UnlockOption == "2" then
				if config.unlockParams == nil then
					config.unlockParams = string.splitNSep(config.ShowParameter2, ":")
				end

				if #config.unlockParams >= 2 then
					return config.unlockParams[1], config.unlockParams[2]
				end
			end
		end
	end
	return default,default
end

function FunOpenController:lockConfig(key, isReplace)
	self:initData()
	if string.isNilOrEmpty(key) == false and self.fo_functionopen and self.xmlData then
		local id = atoi(key)
		if id > 10000000 then
			key = tostring(math.floor(id / 1000))
		end
		if self.xmlData[key] then
			if isReplace then
				return string.gsub(self.xmlData[key].ShowParameter2, ":", ";")
			else
				return self.xmlData[key].ShowParameter2
			end
		end
	end
	return ""
end

-- 获取引导怪奖励
function FunOpenController:getGuideMonsterReward()
	utils.requestServer( "newPlayer.gainAtkMonsterAward", nil, nil, function ( tbl )
		local rewardList = {}
		for _,v in ipairs(tbl.reward or {}) do
			for _,vv in ipairs(v or {}) do
				table.insert(rewardList, vv)
			end
		end
		if table.isNilOrEmpty(rewardList) == false then
			local rwdArr = luaToArray(rewardList)
			RewardController:call("retReward", rwdArr)
		end
	end )
end

function FunOpenController:setFunUnlock(data)
	self.funUnlock = data.functionId
	self:showFunUnlockDialog()
end

function FunOpenController:setEarLevel(data)
	if data.eraIndex then
		self.eraIndex = atoi(data.eraIndex)
	end
end

function FunOpenController:showFunUnlockDialog()
	if table.isNilOrEmpty(self.funUnlock) == false then
		local data = self.xmlData[self.funUnlock[1]]
		table.remove(self.funUnlock, 1)

		if data and data.ShowUnlockPlan == "1" then
			local view = Drequire("game.city.FunBuildUnlockDialog").create(data)
			if PopupViewController:call("getCurrViewCount") > 0 then
				PopupViewController:call("pushPop", view, true)
			else
				PopupViewController:addPopupView(view)
			end
		end
	end
end

function FunOpenController:getFunConfig(id)
	return FUN_CONFIG[id]
end

function FunOpenController:getFunConfigXml(id)
	return self.xmlData[id]
end

function FunOpenController:getMainCityLv()
	return FunBuildController:call("getMainCityLv") + FunBuildController:call("getMainCityHonorLv")
end

function FunOpenController:purge()
	self.fo_functionopen = nil
	self.xmlData = nil
	self.funUnlock = nil
	self.eraIndex = nil
	self.regDays = nil
	self.severOpenDays = nil
	self.v_data = nil
end

return FunOpenController