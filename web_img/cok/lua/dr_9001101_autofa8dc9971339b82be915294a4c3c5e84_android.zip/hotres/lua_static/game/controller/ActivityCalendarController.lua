local ActivityCalendarController = class("ActivityCalendarController")

local StringTbl = {
    calendar = "calendar", --表名
}

--各活动相关处理
local ChuliHandlers = {}

--条件判断处理
local InvalidHandlers = {}

local _instance = nil
function ActivityCalendarController.getInstance()
    if _instance == nil then
        _instance = ActivityCalendarController.new()
        guiCommonGlobal.controllerAutoPurge(_instance)
    end
    return _instance
end

function ActivityCalendarController:ctor()
    self:reset()
end

--[[
    [0 - 6 = 星期天 - 星期六]

    182096=星期一
    182097=星期二
    182098=星期三
    182099=星期四
    182100=星期五
    182101=星期六
    182102=星期日

    <ItemSpec id="5883401" activityId="57155" timeshow="10" nodisplay="0"/>
]]
function ActivityCalendarController:getWeekdayDesc( idx )
    local desc = self.m_descData
    if not desc then
        local t = {182102}
        for i=182096,182101 do
            table.insert(t,i)
        end
        desc = {}
        self.m_descData = desc
        for _,v in ipairs(t) do
            table.insert(desc,getLang(tostring(v)))
        end
    end
    return desc[math.numInRange(tonumber(idx),0,6)+1]
end

function ActivityCalendarController:getIconById( id )
    if not id or id == "-1" then
        return nil
    end

    local tMap = self.m_iconMap
    if not tMap then
        tMap = {}
        tMap["57000"] = "Ativity_iconLogo_1.png"
        tMap["57337"] = "Ativity_iconLogo_16.png"
        tMap["57338"] = "Ativity_iconLogo_17.png"
        tMap["57002"] = "Ativity_iconLogo_3.png"
        tMap["57155"] = "Ativity_iconLogo_18.png"
        tMap["57386"] = "Ativity_iconLogo_12.png"
        self.m_iconMap = tMap
    end

    return tMap[id] or "calendar_" .. id .. ".png"
end

function ActivityCalendarController:getNameById( actId )
    if not actId or actId == "-1" then
        return getLang("114110")
    end

    if actId == "57338" then
        return getLang("103961")
    end
    
    if actId == "57002" then
        return getLang("133003", getLang("4249831"))
    end 

    return getLang(CCCommonUtilsForLua:call("getPropByIdGroup", "activity_panel", actId, "name"))
end

function ActivityCalendarController:getColorOrder(  )
    return {3,2,1}
end

function ActivityCalendarController:getUISize(  )
    local res = self.m_sizeCfgs
    if not res then
        res = {
            unitWidth = 121,
            unitHeight = 110,
            enumHeight = 70,
        }
        self.m_sizeCfgs = res
    end

    return res
end

function ActivityCalendarController:getShowDays(  )
    if not self.m_showDays then
        self.m_showDays = 7
    end
    return self.m_showDays
end

function ActivityCalendarController:findActId( info, find_backward )
    if info then
        local showDays = self:getShowDays()
        if find_backward then
            for i=showDays,1,-1 do
                if info[i] ~= "-1" then
                    return info[i], i
                end
            end
        else
            for i=1,showDays do
                if info[i] ~= "-1" then
                    return info[i], i
                end
            end
        end
    end
    return "-1",nil
end

function ActivityCalendarController:showActivityDetailView( actId )
    if actId ~= "-1" then
        --跳转详情界面
        local view = Drequire("game.activity.calendar.CalendarActivityDetailView"):create(actId)
        PopupViewController:addPopupView(view)
    end
end

function ActivityCalendarController:getLocalData(  )
    if not self.m_localData then
        self.m_localData = CCCommonUtilsForLua:getGroupByKey(StringTbl.calendar)

        -- self.m_localData = utils.jsonDecode([[{"5883401":{"activityId":"57000","id":"5883401",
        -- "chuli":"nodisplay|1","timeshow":"10","colour":"3","cond":"castlelvl;31;101603"}}]])
    end
    return self.m_localData
end

function ActivityCalendarController:getChuliKey( chuli_str,cp_key )
    local s1 = string.split(chuli_str,"|")[1]
    return cp_key and (cp_key == s1 and s1 or nil) or s1
end

function ActivityCalendarController:getChuliValue( chuli_str )
    return string.split(chuli_str,"|")[2]
end

function ActivityCalendarController:handleCalendarData( tbl )
    local ld = self:getLocalData()
    dump(ld,"self:getLocalData()")
    if not table.isNilOrEmpty(ld) then
        local timeNow = utils.timeNow()
        local timeTrim = utils.trimTimeStampToZero(timeNow)

        local res = {}
        for _,v in pairs(ld) do
            local v_id = v.activityId
            local findv = table.find(tbl,function ( cur )
                return self:findActId(cur) ~= "-1"
            end)

            local jieduan_show = true

            --处理阶段是否显示
            if findv then
                local showCheck = v.chuli and self:getChuliKey(v.chuli,"nodisplay")
                if showCheck then
                    local checkFunc = ChuliHandlers[showCheck]
                    if checkFunc then
                        jieduan_show = checkFunc(self,self:getChuliValue(v.chuli),v)
                    end
                end
            end

            --处理别的chuli字段...

            --insert
            if findv and jieduan_show then
                local actId,idx = self:findActId(findv,true)
                assert(actId ~= "-1")
                local obj = ActivityController:call("getActObj", actId)
                if obj then
                    -- local sT = tonumber(obj:getProperty("startTime"))
                    local eT = tonumber(obj:getProperty("endTime")) -- + 10 * 86400
                    if eT > timeTrim + idx * 86400 then
                        findv.endTimeStr = utils.time2_m_d(eT)
                    end
                end
                assert(v.colour,'no colour in calendar id' .. v.id)
                findv.colour = v.colour

                local valid,info = utils.areConditionsValidDetail(v.cond)
                findv.invalid_info = (not valid and info) and self:parseInvalidInfo(info,v,findv) or nil
                table.insert(res,findv)
            end
        end

        dump(res,"handleCalendarData res")
        return res
    end

    return tbl
end

function ActivityCalendarController:parseInvalidInfo( infos,localData,actInfo )
    local res = {}
    for _,var in ipairs(infos) do
        local thd = InvalidHandlers[var.Type]
        if thd then
            table.insert(res,thd(self,var,localData,actInfo))
        end
    end
    return res
end

function ActivityCalendarController:reset(  )
    -- self.m_iconMap = nil
end


function ActivityCalendarController:purge()
    self:reset()
end

--[[
    各活动相关处理
]]
ChuliHandlers["nodisplay"] = function ( self, chuli_v_str, localData )
    if chuli_v_str == "0" then
        return true
    end

    --不显示阶段
    local nodisplay_arr = string.split(chuli_v_str,";")
    --现在阶段
    local now_jieduan = "0"
    if localData.activityId == "57155" then
        now_jieduan = tostring(FortressController.getInstance():getCurStage())
    end
    return not table.contains(nodisplay_arr,now_jieduan)
end


--[[
    条件不满足的提示
]]

InvalidHandlers["castlelvl"] = function ( self,info,localData,actInfo )
    return getLang(info.InvalidText,info.Value)
end

InvalidHandlers["battlestrength"] = function ( self,info,localData,actInfo )
    return getLang(info.InvalidText,info.Value)
end

InvalidHandlers["inalliance"] = function ( self,info,localData,actInfo )
    return getLang("default")
end

InvalidHandlers["participate"] = function ( self,info,localData,actInfo )
    return getLang("default")
end




return ActivityCalendarController