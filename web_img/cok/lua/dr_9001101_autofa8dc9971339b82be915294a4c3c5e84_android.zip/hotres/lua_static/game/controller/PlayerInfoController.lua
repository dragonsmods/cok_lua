----------------------------
-- 常用的playerInfo数据控制类接口
-- 目前已有的是:
-- PlayerInfoController:getCrystalGold()       取钻石数量
-- PlayerInfoController:getRedPackState()             取红包领取状态
-- PlayerInfoController:getPermitApprove()       取欧盟协议标志
-- PlayerInfoController:getRegCountry()         取注册地
-- PlayerInfoController:getUid()        取uid
-- PlayerInfoController:getServerType()        取服务器类型
-- PlayerInfoController:getGmFlag()     取GM标志
-- PlayerInfoController:getAllianceId()     取GM标志
-- PlayerInfoController:getSelfServerId()     本服severId
-- PlayerInfoController:getCurrentServerId()     当前服serverID 
-- PlayerInfoController:getCrossFightSrcServerId()     表示玩家是从哪个服跨服过来的。 -1 表示没有跨服， >=0表示现在处于跨服状态
----------------------------
local PlayerInfoController = class("PlayerInfoController")

function PlayerInfoController:ctor()
	CC_SYNTHESIZE(self, "crystal_gold", "CrystalGold", 0)
	CC_SYNTHESIZE(self, "redPackState", "RedPackState")
	CC_SYNTHESIZE(self, "permitApprove", "PermitApprove", 1)

	CC_SYNTHESIZE(self, "regCountry", "RegCountry", "")
	CC_SYNTHESIZE(self, "uid", "Uid", "")
	CC_SYNTHESIZE(self, "serverType", "ServerType", 0)
	CC_SYNTHESIZE(self, "gmFlag", "GmFlag", 0)
	CC_SYNTHESIZE(self, "allianceId", "AllianceId", "")
	CC_SYNTHESIZE(self, "selfServerId", "SelfServerId", -1)
	CC_SYNTHESIZE(self, "currentServerId", "CurrentServerId", -1)
	CC_SYNTHESIZE(self, "crossFightSrcServerId", "CrossFightSrcServerId", -1)
	self:init()
end

function PlayerInfoController:init()
	self.isEUMember = false
	self.ipCountry = ""
	self.regCountry = ""
	self.uid = ""
	self.permitApprove = 1
	self.m_onlineTime = 0
	self.serverType = 0
	self.gmFlag = 0
	self.allianceId = ""
	self.selfServerId = -1
	self.currentServerId = -1
	self.crossFightSrcServerId = -1
end

function PlayerInfoController:purge()
	self:init()
end

function PlayerInfoController:fireCommonEvent(newKey, dict)
	-- MyPrint("PlayerInfoController:fireCommonEvent", newKey, dict)
    if newKey == "initPlayerInfo" then
        self:initPlayerInfo(dict)
    elseif newKey == "getKeyValue" then
    	-- 为便于各种数据传输，统一返回string
    	local str = self:getKeyValue(dict)
    	if str and str ~= "" then
    		dict:setObject(CCString:create(str), "keyValue")
		end
	elseif newKey == "setSelfAllianceId" then
		local value = dict:getCString()
		self.allianceId = value
	elseif newKey == "setCurrentServerId" then
		local value = dict:getValue()
        self.currentServerId = tonumber(value)
    end
end

function PlayerInfoController:initPlayerInfo(dict)
	-- 此处传的是大数据量，不可直接转luatable,但是user可以转。单取变量数据多的时候，效率会更低
	-- dump("PlayerInfoController:initPlayerInfo+++")
	local userInfo = dict:objectForKey("user")
	if userInfo then
		-- self.crystal_gold = utils.getDictIntValue(userInfo, "crystalGold", 0)
		-- self.ipCountry = utils.getDictStringValue(userInfo, "ipCountry", "")
		-- self.permitApprove = utils.getDictIntValue(userInfo, "permit", 1)
		-- self.m_onlineTime = utils.getDictIntValue(userInfo, "onlineTime", 0) / 1000
		-- self.uid = utils.getDictStringValue(userInfo, "uid", "")
		-- self.regCountry = utils.getDictStringValue(userInfo, "regCountry", "")
		-- self.serverType = utils.getDictIntValue(userInfo, "serverType", 0)
		-- self.gmFlag = utils.getDictIntValue(userInfo, "gmFlag", 0)
	
		local tbl = dictToLuaTable(userInfo)
		self.crystal_gold = tonumber(tbl.crystalGold) or 0
		self.ipCountry = tbl.ipCountry or ""
		self.permitApprove = tonumber(tbl.permit) or 1
		self.m_onlineTime = (tonumber(tbl.onlineTime) or 0) / 1000
		self.uid = tbl.uid or ""
		self.regCountry = tbl.regCountry or ""
		self.serverType = tonumber(tbl.serverType) or 0
		self.gmFlag = tonumber(tbl.gmFlag) or 0
		self.selfServerId = tonumber(tbl.serverId) or -1
        self.crossFightSrcServerId = tonumber(tbl.crossFightSrcServerId) or -1
        self.regTime = atoi(tbl.regTime)
		local isGreen = atoi(tbl.greenServer) == 1
		GlobalDataCtr.setGreenServerCache(isGreen)
	end

	LibaoLocalizationController:initConfigData(dict)
end

function PlayerInfoController:getKeyValue(dict)
	local tbl = dictToLuaTable(dict)
	if tbl.key or not self[tbl.key] then
		return ""
	end
	return self[tbl.key]
end

function PlayerInfoController:checkEUMember()
	-- dump("PlayerInfoController checkEUMember")
	self.isEUMember = false
	if self.ipCountry == "" then
		return
	end
	local permit_choose_country = ImperialSceneLuaManager.getInstance().permit_choose_country
	if permit_choose_country == nil then
		return
	end

	local pos = string.find(permit_choose_country, self.ipCountry)
	if pos and pos > 0 then
		self.isEUMember = true
	end
	-- dump(self.isEUMember, "isEUMember is: ")
end

function PlayerInfoController:getUserOnlineTime()
	return self.m_onlineTime or 0
end

function PlayerInfoController:isInAlliance()
	return self.allianceId ~= ""
end

function PlayerInfoController:getRegTime()
    return self.regTime
end

return PlayerInfoController
