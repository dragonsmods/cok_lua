--[[ 
    物品奖励信息
    2019.11.27   Awen
 ]]

local ItemRewardController = class("ItemRewardController")
local _instance = _instance or nil

function ItemRewardController.getInstance()
    if not _instance then 
        _instance = ItemRewardController.new() 
    end
    return _instance
end

-- 处理C++调用
function ItemRewardController:fireEventRef( key, dict )
	Dprint('ItemRewardController:fireEvenntRef key='..key)
	if key == "ChestUseViewCell" then
        self:onChestUseViewCell(dict)
    
    elseif key == "RewardController" then
        self:onRewardController(dict)

    elseif key == "addGemArray" then
        require("game.equipment.gem.EquipmentGemController").getInstance():addGemArray(dict:objectForKey("data"))

	end
end

function ItemRewardController:onChestUseViewCell(dict)
    local _rewardType = dict:valueForKey("rewardType"):intValue()
    if _rewardType == RewardTypeConfig.R_EQUIPMENT_GEM then --装备宝石
        local _itemId = dict:valueForKey("itemId"):getCString()
        
        local _color = CCCommonUtilsForLua:call("getPropByIdGroup","gem",_itemId,"color")
        dict:setObject(CCString:create(_color), "color")

        local _icon = CCCommonUtilsForLua:call("getPropByIdGroup","gem",_itemId,"icon")
        dict:setObject(CCString:create(string.format("%s.png", _icon)), "icon")

        local _name = CCCommonUtilsForLua:call("getPropByIdGroup","gem",_itemId,"name")
        dict:setObject(CCString:create(_name), "name")
    elseif _rewardType == RewardTypeConfig.R_HERO_BADGE then
        -- R英雄信物
        local _itemId = dict:valueForKey("itemId"):getCString()
        local control = HeroBadgeController:getInstance()
        local configModel = control:getConfigModel()
        local config = configModel:getBadgeBaseById(_itemId)
        local _name = getLang(config.name)
        local rewardDict = dict:objectForKey('rewardDict')
        rewardDict = dictToLuaTable(rewardDict)
        heroBadge = rewardDict.value.heroBadge
        local iconNode = Drequire('game.hero.badge.HeroBadgeRewardItem'):create()
        iconNode:refreshCell(heroBadge)
        iconNode:setItemSize(40)
        iconNode:setTouchState(true)
        dict:setObject(CCString:create(_name), "name")
        dict:setObject(iconNode, "iconNode")
    end
end

function ItemRewardController:onRewardController(dict)
    local _rewardType = dict:valueForKey("rewardType"):intValue()
    if _rewardType == RewardTypeConfig.R_EQUIPMENT_GEM then --装备宝石
        require("game.equipment.gem.EquipmentGemController").getInstance():addGem(dict:objectForKey("data"))
    end
end

return ItemRewardController