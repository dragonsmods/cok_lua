StatusController = class("StatusController")
-- StatusXMLConfig = class("StatusXMLConfig")

-- function StatusXMLConfig:ctor( statusId )
-- 	self.statusId = statusId
-- end

-- function StatusXMLConfig:getStatusIcon( ... )
-- 	-- body
-- end

local _instance = nil

function StatusController.getInstance(  )
	if nil == _instance then
		_instance = StatusController.new()
	end
	return _instance
end

function StatusController:ctor(  )
	
end

function StatusController.purge(  )
	_instance = nil
end

-- 默认返回""
function StatusController:getStatusIcon( statusId )
	if nil == statusId then
		return ""
	end
end

-- 默认返回0
function StatusController:getStatusShowPos( statusId )
	if nil == statusId then
		return 0
	end
end

-- 默认返回0  不显示
function StatusController:getStatusShowType( statusId )
	if nil == statusId then
		return 0
	end
end

function StatusController:getStatusType( statusId )
	if nil == statusId then
		return 0
	end
end

function StatusController:getStatusEndTime( statusId )
	-- body
end

local ExtraStatusDialog = 
{
	["22606347"] = "10200603", --10200603=部队已经进行伪装！被侦察时显示{0}倍士兵数量
}

function StatusController:getExtraDialog(statusId)
	return ExtraStatusDialog[statusId]
end

return StatusController