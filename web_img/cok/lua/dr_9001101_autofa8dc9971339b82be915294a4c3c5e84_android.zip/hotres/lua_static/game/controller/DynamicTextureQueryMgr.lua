-- @Author: tangwen
-- @Date:   2019-06-03 16:14:07
-- @Last Modified by:   tangwen
-- @Last Modified time: 2019-12-17 19:29:57

-- 动态资源查询, 保证资源加载完成后推送ready事件
-- 同一时间内使用 一个计时器轮询资源是否加载好
-- 每个资源可以设置最大检查次数
-- 当前没有检查的资源 计时器停止

local DynamicTextureQueryMgr = class("DynamicTextureQueryMgr")

local _instance = nil
function DynamicTextureQueryMgr.getInstance()
    if _instance == nil then
        _instance = DynamicTextureQueryMgr.new()
        guiCommonGlobal.controllerAutoPurge(_instance)
    end
    return _instance
end

function DynamicTextureQueryMgr:ctor()
    self.m_res_arr = {}
end

function DynamicTextureQueryMgr:isSpriteResReady(spriteName)
    return not not CCLoadSprite:call("getSF", spriteName)
end

function DynamicTextureQueryMgr:query( spriteName, dynResName, maxQueryCnt )
    assert(spriteName,"spriteName is nil")
    assert(dynResName,"dynResName is nil")
    maxQueryCnt = maxQueryCnt or 120
    CCLoadSprite:call("loadDynamicResourceByName", dynResName)
    if self:isSpriteResReady(spriteName, dynResName) then
        self:getReadyEvent():emit(spriteName, dynResName)
    else
        self.m_res_arr = self.m_res_arr or {}
        local doInsert = table.insertUnique(self.m_res_arr,{spriteName, dynResName, maxQueryCnt}, function(cur)
            return spriteName == cur[1] and dynResName == cur[2]
        end)

        if doInsert then
            local condFunc = self:getCondFuc()
            if not condFunc:isInPolling() then
                condFunc:startCall(function (  )
                end,function (  )
                    for i=#(self.m_res_arr or {}),1,-1 do
                        local v = self.m_res_arr[i]
                        v[4] = (v[4] or 0) + 1
                        CCLoadSprite:call("loadDynamicResourceByName", v[2])
                        if self:isSpriteResReady(v[1]) then
                            local res = table.remove(self.m_res_arr,i)
                            self:getReadyEvent():emit(res[1], res[2])
                        elseif v[3] < v[4] then
                            table.remove(self.m_res_arr,i)
                        end
                    end

                    if table.isNilOrEmpty(self.m_res_arr) then
                        condFunc:setConditionSlot(1)
                    end
                end)
            end
        end
    end
end

function DynamicTextureQueryMgr:getCondFuc(  )
    local condFunc = self.m_condFunc__
    if not condFunc then
        condFunc = utils.getExtendClass("conditionFuncCommon"):create({false},5)
        self.m_condFunc__ = condFunc
    end
    return condFunc
end

function DynamicTextureQueryMgr:getReadyEvent(  )
    local sprReadyEv = self.m_sprReadyEv
	if not sprReadyEv then
	    sprReadyEv = utils.getEventClass(  ):create()
	    self.m_sprReadyEv = sprReadyEv
	end
	return sprReadyEv
end

function DynamicTextureQueryMgr:purge(  )
    self.m_res_arr = {}
    if self.m_condFunc__ then
        self.m_condFunc__:reset()
    end
end

return DynamicTextureQueryMgr