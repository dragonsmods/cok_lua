-- @Author: tangwen
-- @Date:   2019-06-03 16:14:07
-- @Last Modified by:   tangwen
-- @Last Modified time: 2019-12-17 19:29:57

-- 礼包充值白名单,位于些名单中的uid可以无限购买礼包次数

local WhiteListMgr = class("WhiteListMgr")

local _instance = nil
function WhiteListMgr.getInstance()
    if _instance == nil then
        _instance = WhiteListMgr.new()
        guiCommonGlobal.controllerAutoPurge(_instance)
    end
    return _instance
end

function WhiteListMgr:requestList(  )
    if not self.m_whiteList then
        utils.requestServer( "discountbuyexchange.vip_uids", nil, nil, function ( tbl )
            self.m_whiteList = string.split( tbl.vipUids, ';' )
        end )
    end
end

function WhiteListMgr:getList(  )
    return self.m_whiteList
end

function WhiteListMgr:isUidInList( uid )
    if not table.isNilOrEmpty( self.m_whiteList ) then
        uid = uid or utils.getSelfUid(  )
        return table.contains( self.m_whiteList, uid )
    end
    return false
end

function WhiteListMgr:purge(  )
    
end

return WhiteListMgr