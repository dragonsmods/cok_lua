--[[ 
    init完成后逐个请求数据
    @author: Awen
    @date: 2021-06-03
 ]]
local InitFinishController = class("InitFinishController")
local instance = instance or nil

function InitFinishController.getInstance()
    if not instance then 
        instance = InitFinishController.new() 
    end
    return instance
end

function InitFinishController:reqData()
    self.reqList = {}
    -- 装扮宝石
    if isFunOpenByKey("gem") then
        table.insert(self.reqList, {call = function()
            require("game.equipment.gem.EquipmentGemCommand").reqOpenDig(true)
        end})
    end        

    -- 英雄多卡池招募
    if isFunOpenByKey("general_draw_new") then
        table.insert(self.reqList, {call = function()
            require("game.hero.recruit.HeroRecruitController").getInstance():reqInfo()
        end})
    end

    -- 贤者之塔科技配置
    if isFunOpenByKey("new_sagetower_science_v1") then
        table.insert(self.reqList, {call = function()
            HighTechController.getInstance():reqScienceData()
        end})
    end        

    -- 永夜城前置引导
    if isFunOpenByKey("guide_night") and not isCrossServerNow() then
        table.insert(self.reqList, {call = function ()
            require("game.guide.LuaGuideController").getInstance():reqEternalNight()
        end})
    end
    ----------------------------------------
    local reqIndex = 0
    local scheduler = cc.Director:getInstance():getScheduler()
    self.entryId = scheduler:scheduleScriptFunc(function() 
        if reqIndex < #self.reqList then
            reqIndex = reqIndex + 1
            self.reqList[reqIndex].call()
        elseif self.entryId then
            scheduler:unscheduleScriptEntry(self.entryId)
            self.entryId = nil
        end
    end, 0.3, false)
end

return InitFinishController
