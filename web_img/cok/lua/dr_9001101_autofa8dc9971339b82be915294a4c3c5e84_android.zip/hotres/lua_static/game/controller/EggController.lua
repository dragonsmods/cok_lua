EggController = class("EggController")
local _instance = nil
function EggController.getInstance()
    if _instance == nil then
        _instance = EggController.new();
    end
    return _instance;
end

function EggController:ctor()
    self.m_total_list    = {}
    self.m_egg_node_list = {}
    self.egg_group       = nil
    self.m_box_reward    = {}
    self.m_max_score     = 0
    self.m_egg_step_list = {}
    self.m_buffer_idx_list = {}
    self.m_freeTime      = 0
    self.m_reward_count  = 0
    self.m_show_conform  = true 
end

function EggController:praseData( dic )
    self.m_egg_node_list = {}
    self.m_buffer_idx_list = {}
    local data  = dic:objectForKey("params") 
    local egg_data = data:objectForKey("list") 
    local lua_data = dictToLuaTable(data)
    self.m_total_list = arrayToLuaTable(egg_data)
    -- dump(self.m_total_list,"m_total_list")

    self.m_freeflush  = lua_data.freeflush
    self.m_scoreReward= lua_data.scoreReward
    local box_string  = lua_data.reward
    if lua_data.freetimes  ~= nil then 
        self.m_freeTime   = lua_data.freetimes
        MyPrint("self.m_freeTime",self.m_freeTime)
    end 

    if lua_data.goldflush ~= nil then 
        self.m_goldflush = lua_data.goldflush
    end

    if lua_data.score ~= nil then 
        self.m_score      = lua_data.score 
    end

    if lua_data.allscore ~= nil then 
        self.m_score      = lua_data.allscore 
    end
    if lua_data.costGold ~= nil then 
        self.m_cost_gold  = lua_data.costGold 
    end
    if lua_data.curDaytime ~= nil then 
        self.m_curDaytime = lua_data.curDaytime/1000
    else
        self.m_curDaytime = 0
    end
    self.m_typeEgg    = 0
    self.m_typeEgg_open = {}
    MyPrint("box_string ",box_string," and m_score ",self.m_score )
    local box_reward  = string.split(box_string,"|")
    if #self.m_box_reward == 0 then 
        for k,v in pairs(box_reward) do
            self.m_reward_count = self.m_reward_count + 1
            local tmp = string.split(tostring(v),";")
            -- dump(tmp," split tmp ")
            local key = tmp[1]
            local value = tmp[2]
            local dict = {}
            if value ~= nil  and tonumber(key) > self.m_max_score then
                self.m_max_score = tonumber(key) 
            end
            dict[key] = value
            table.insert(self.m_box_reward ,dict)
        end
    end
    self:countTypeEgg()
end

function EggController:setEggList(list)
    self.m_total_list = list
    self:countTypeEgg()
end

function EggController:initConfigData( dict )
     if dict == nil then
        return
    end

    local eggConfig = dict:objectForKey("golden_egg")
    if nil == eggConfig then
        return
    end
    self.m_config = dictToLuaTable(eggConfig)
    self.m_k3     = self.m_config.k3
    self.m_k5     = self.m_config.k5
    self.m_k10    = self.m_config.k10
    self.m_price_all = self.m_config.k3 * self.m_config.k5
    -- dump( self.m_config," egg_config")
end

function EggController:cacheStep( step )
    --"0;1;2;3;4;5;6;7;8;9;10;11;12;13;14;15;16;17;18;19;20;21;22;23;24;25;26;27;28;29"
    self.m_egg_step_list = string.split(step,";")
    -- dump(self.m_egg_step_list,"m_egg_step_list") 
end

function EggController:setNowScore(now_score )
    self.m_score = now_score
end

function EggController:countTypeEgg()
    self.m_typeEgg = 0
    self.m_typeEgg_open = {}
    for k,v in pairs(self.m_total_list) do 
        if tonumber(v.type) == 2 then 
            self.m_typeEgg = self.m_typeEgg + 1
        end
        if tonumber(v.state) == 2 and tonumber(v.type) == 2 then 
            -- self.m_typeEgg_open = self.m_typeEgg_open + 1
            self.m_typeEgg_open[k] = 1
        end
    end
end

function EggController:setEggOpenInList(index )
    if self.m_total_list[index] then 
        self.m_total_list[index].state = 1 
    end
end


function EggController:getTypeEggCount( ... )
    local left = self.m_typeEgg - self:getTypeEggOpenCount()
    if left < 0 then 
        left = 0
    end
    return left,self.m_typeEgg
end

function EggController:getTypeEggOpenCount(  )
    local total = 0
    for k,v in  pairs(self.m_typeEgg_open) do 
        if tonumber(v) == 1 then 
            total = total + 1
            MyPrint("total",total,"and getTypeEggOpenCount",v)
        end
    end
    -- dump(self.m_typeEgg_open,"self.getTypeEggOpenCount")
    return total 
end

function EggController:setOpenTypedEggAdd( added ,index)
    if added then 
        self.m_typeEgg_open[index] = 1
        -- dump(self.m_typeEgg_open,"setOpenTypedEggAdd") 
    end
end

function EggController:setFreeTimeRecord(  decrease )
    if decrease then
        MyPrint("self.m_freeTime",self.m_freeTime)
        self.m_freeTime = self.m_freeTime - 1
    end
end

function EggController:getCachedStep()
    return self.m_egg_step_list
end

function EggController:isEggIsOpen()
    if CCCommonUtilsForLua:isFunOpenByKey("golden_egg_open")  == true then 
        return  true
    end 
    return false
end

function EggController:openEggRhiexsView()
	MyPrint("EggController:openEggRhiexsView")
	if self:isEggIsOpen() == false then 
        return 
    end 
	local view = require("game.eggRhexis.EggRhexisView"):create()
	PopupViewController:call("addPopupInView", view)
end

function EggController:setLeftGold( left_gold )
    self.m_left_gold = left_gold
end
--免费刷新次数
function EggController:getFleeFlushTime(  )
   return self.m_freeflush
end

function EggController:sendGetEgglist(refresh_all)
	local command = require("game.command.EggGetListCmd"):create(refresh_all)
	command:send()
end

function EggController:isBoxRewardOpen( index )    
    local reward_record = string.split(self.m_scoreReward,";")
    -- dump(reward_record,"self.m_scoreReward")
    for k,v in pairs(reward_record) do 
        if index == tonumber(v) then 
            return true 
        end
    end
    return false
end
--免费次数
function EggController:setFreeTime( free_times )
    self.m_freeTime = free_times
end

function EggController:getFreeTime()
    if tonumber(self.m_freeTime) < 0 then 
        self.m_freeTime = 0
    end 
    return  tostring(self.m_freeTime)
end

function EggController:getGoldCost(  )
    return tostring(self.m_cost_gold)
end

function EggController:getFlushGold()
    return self.m_goldflush
end

function EggController:addEggCell( eggCell,index )
    -- local index = #self.m_egg_node_list 
    if self.m_egg_node_list[index] ~= nil then 
        self.m_egg_node_list[index] = eggCell
        return 
    end
    table.insert(self.m_egg_node_list,index,eggCell)
end
--积分奖励数据
function EggController:getBoxReward()
    return self.m_box_reward
end

function EggController:getScore()
    return self.m_score 
end
--最大积分
function EggController:getMaxScore()
    return self.m_max_score,self.m_reward_count
end

function EggController:getEggDataBy(type)
    if self.egg_group == nil then
        self.egg_group = CCCommonUtilsForLua:getGroupByKey("golden_egg_pic")
        -- dump(self.egg_group,"self.egg_group")
    end

    --type 服务器端给的数据从 0 开始 本地数据从1 开始 这里记录即可
    -- MyPrint("getEggDataBy type ",type)
    for k ,v in pairs(self.egg_group) do 
        if tonumber(v.index) == (type + 1)then 
            return v
        end 
    end
    return nil
end

function EggController:getEggCellByIndex(index)
    return self.m_egg_node_list[index]
end

function EggController:setCellByIndex( index ,cell )
    self.m_egg_node_list[index] = cell 
end



return EggController