function QueueController:endCDQueue( dict )
	if nil == dict or dict:objectForKey("errorCode") then
		return
	end
	MyPrint("QueueController:endCDQueue")
	local t = dict:valueForKey("type"):intValue()

	if t == QueueType.TYPE_HIGHTECH then
		HighTechController.getInstance():endCDSearch(dict)
	elseif t == QueueType.TYPE_MATE then
		EquipmentController:call("getInstance"):endCDCreateTool(dict)
	end
end

function QueueController:getQID( t )
	if nil == t then
		return 0
	end
	return self:call("getQID", tonumber(t))
end

function QueueController:endFinishQueue( dict )
	MyPrint("QueueController:endFinishQueue")
	if nil == dict or dict:objectForKey("errorCode") then
		return
	end

	local uuid = dict:valueForKey("uuid"):getCString()

	local queueInfo = self:call("getQueueInfoByUuid", uuid)
	if nil == queueInfo then
		return
	end

	local itemId = queueInfo:getProperty("itemId")
	local t = queueInfo:getProperty("type")

	if t == QueueType.TYPE_HIGHTECH then
		HighTechController.getInstance():endFinishSearch(itemId)
	end
end

function QueueController:endCancelQueue( dict )
	if nil == dict then
		return
	end

	local uuid = dict:valueForKey("uuid"):getCString()
	local t = dict:valueForKey("type"):intValue()
	local queueInfo = self:call("getQueueInfoByUuid", uuid)
	
	if t == QueueType.TYPE_HIGHTECH then
		HighTechController.getInstance():endCancelSearch(dict)
	end
end