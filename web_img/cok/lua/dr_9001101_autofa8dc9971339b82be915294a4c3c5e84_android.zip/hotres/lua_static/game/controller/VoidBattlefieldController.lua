VoidBattlefieldController = class("VoidBattlefieldController")

VoidBattlefieldTroopListType = {
    inOwnerCountry = 0,  -- 本服看所有派出的队伍
    inOtherCountryAtt = 1, -- 其他服攻击
    inOtherCountryDispatch = 2, -- 其他服派遣
}

local _instance = nil
function VoidBattlefieldController.getInstance()
    if _instance == nil then
        _instance = VoidBattlefieldController.new();
    end
    return _instance;
end

function VoidBattlefieldController:ctor()
    
end

function VoidBattlefieldController:getServerInfo(targetServerId)
    local tbl = {}
    local m_serverListMap = WorldController:call("getInstance"):getProperty("m_serverListMap")
    if m_serverListMap == nil then
        return tbl
    end
    -- dump(m_serverListMap, "m_serverListMap is: ", 10)
    for k, v in pairs(m_serverListMap) do
        local serverId = v:getProperty("serverId")
        if targetServerId == serverId then 
            local cityIconIndex = v:getProperty("cityIconIndex")
            local serverName = v:getProperty("serverName")
            local kingName = v:getProperty("kingName")
            tbl = {
                serverId = serverId,
                cityIconIndex = cityIconIndex,
                serverName = serverName,
                kingName = kingName,
            } 
            break
        end
	end
    return tbl
end

function VoidBattlefieldController:pushVoidBattlefieldVSInfo(data)
	dump(data,"VoidBattlefieldController:pushVoidBattlefieldVSInfo")
	if data then
		local view = Drequire("game.VoidBattlefield.VoidBattlefieldVSView"):create(data)
        PopupViewController:call("addPopupView", view)
	end
end



return VoidBattlefieldController