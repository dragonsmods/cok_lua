

local PmaHandlerMgr = {}

-- premulti alpha 基于这样的事实
-- (资源pma) + (blendFunc pma) = 显示ok
-- (资源nopma) + (blendFunc nopma) = 显示ok

-- (资源pma) + (blendFunc nopma) = 显示颜色变浅,偏暗
-- (资源no pma) + (blendFunc pma) = 显示颜色增强, 爆白

-- (资源pma+shader pma) + (blendFunc pma) = 显示颜色变浅

-- 这个表由 check_pma.py 脚本自动生成
-- *重要: 放入此两个表的资源, 指明image,texture 的premultialpha为false, 因此 draw 的时候使用的_blendFunc 为 ALPHA_NON_PREMULTIPLIED
-- None_pma_res is orderd 
local None_pma_res = {
    ["0"] = {
        "Imperial_0",
    },
    ["1"] = {
        "Imperial_0",
    },
    ["2"] = {
        "Imperial_0",
        "Imperial_21",
        "Imperial_24",
        "Imperial_25",
        "Imperial_26",
        "Imperial_27",
        "Imperial_29",
    },
    ["3"] = {
        "Imperial_0",
        "Imperial_21",
        "Imperial_23",
        "Imperial_24",
        "Imperial_25",
        "Imperial_26",
        "Imperial_27",
        "Imperial_29",
    },
    
    ["4"] = {
        "Imperial_21",
        "Imperial_23",
        "Imperial_24",
        "Imperial_25",
        "Imperial_26",
        "Imperial_29",
    },
    ["-1"] = {
        "AllianceDuel_1_face",
        "AllianceDuel_face",
        "COSAct_face",
        "Chapter_Story_1",
        "Chapter_Story_2",
        "Common_310",
        "Common_9",
        "GoldEgg",
        "GoldEggHammer",
        "GoldEggHammer",
        "KingdomChange1_face",
        "KingdomChange2_face",
        "KingdomChange3_face",
        "KingdomChange4_face",
        "KingdomChange5_face",
        "KingdomChange_face",
        "KnightActivity",
        "WorldCraft_building",
        "WorldCraft_face",
        "WorldCraft_room",
        "WorldCraft_rule",
        "World_1",
        "XueHuaZhuanChang_face",
        "bank_new",
        "craft_miniMap1",
        "craft_miniMap2",
        "mainCity3",
        "mainCity4",
        "tactical_face",
        "world_craft_map_1",
        "world_craft_map_4",
    },
}

local None_pma_res_ext = {

{resName="_alpha_scrollbk1_1.pkm",raceType="1"},
{resName="_alpha_scrollbk1_3.pkm",raceType="3"},
{resName="_alpha_Imperial_28.pkm",raceType="3"},

}

-- for _, v in ipairs(None_pma_res_ext) do
--     table.insert(None_pma_res,v)
-- end

local None_pma_res_norace = {{resName="_alpha_World_4.pkm"},{resName="_alpha_World_2.pkm"},{resName="_alpha_Common_3.pkm"},{resName="_alpha_Common_502.pkm"},{resName="_alpha_sk_AgathaGoddess_face_out1.pvr.ccz"},{resName="_alpha_sk_AgathaGoddess_face_out.pvr.ccz"},{resName="_alpha_sk_AgathaGoddess_face_out_gongji.pvr.ccz"},{resName="_alpha_sk_AgathaGoddess_face_out_gongji1.pvr.ccz"},{resName="_alpha_sk_flyship_face_out.pvr.ccz"},{resName="_alpha_sk_flyship_face_out_gongji.pvr.ccz"},{resName="_alpha_sk_halo_iceworld_face_front.pvr.ccz"}}

-- *重要: 此情况是基于 blendFunc为 ALPHA_PREMULTIPLIED下, 资源若处理pma, 则shader使用nonpma , 资源使用pma则shader使用nonpma
-- *重要: 这样就保证最终只进行一次pma处理
local DoHad_pma_res_android = {{resName="_alpha_Particle.pkm"}}
local DoNo_pma_res_android = {{resName="_alpha_sk_LiBao_king_z3_icon.pkm"},{resName="_alpha_sk_halo_iceworld_face_front.pkm"},{resName="_alpha_sk_AgathaGoddess_face_out_gongji1.pkm"},{resName="_alpha_sk_AgathaGoddess_face_out_gongji.pkm"},{resName="_alpha_sk_AgathaGoddess_face_out1.pkm"},{resName="_alpha_sk_AgathaGoddess_face_out.pkm"},{resName="_alpha_sk_Sky_Dragon_face.pkm"}}
local OldLibaoMd5Arrary = {
    16400, -- 老礼包烟花
    32784 -- 老礼包加速
}

local TooBrightArray = {
    "_alpha_sk_face_dermiterFarmer"
}

local function trimLibaoName(libao_name)
    local res,f = string.gsub(libao_name,"^_alpha_sk_LiBao_(.*)_default_a_icon.pkm$","%1")
    return res,f
end

local function getFileBaseName(url)
    return url:match("^_alpha_(.-)%..+$") or url:match("^(.-)%..+$") or url
end

-- none pma return 1 将会指明使用哪个blendFunc
function PmaHandlerMgr.check_pma_forblendfunc(resName)
    if not resName then
        return
    end

    local raceType = CCCommonUtilsForLua:call("RACETYPE")
    local raceTypeStr = tostring(raceType)
    local key = getFileBaseName(resName)
    local res = utils.binarySearch(None_pma_res[raceTypeStr] or {}, function ( cur )
        return key < cur and -1 or (key > cur and 1 or 0)
    end)

    if not res then
        res = utils.binarySearch(None_pma_res["-1"] or {}, function ( cur )
            return key < cur and -1 or (key > cur and 1 or 0)
        end)
    end

    if not res then
        res = table.find(None_pma_res_ext,function ( cur )
            return string.find(resName, cur.resName) and (cur.raceType == "-1" or cur.raceType == raceTypeStr)
        end)
    end

    if not res then
        res = table.find(None_pma_res_norace,function ( cur )
            return string.find(resName, cur.resName)
        end)
    end


    if res then
        return 1
    end

    return 0
end

-- has pma return 1 no pma return 2
-- not specify yet return 0
-- 将会指明使用哪个shader
function PmaHandlerMgr.check_pma_forshaderusage( resName )
    if not resName then
        return
    end

    local res = table.find(DoHad_pma_res_android,function ( cur )
        return string.find(resName, cur.resName)
    end )
    if res then
        return 1
    end

    -- 老礼包默认烟花动画没使用alpha 预乘
    if string.find(resName,"_alpha_sk_LiBao_") then
        local fileUtils = cc.FileUtils:getInstance()
        local file_path = string.format("%s%s%s",fileUtils:getWritablePath(),"lua/skeleton/android/",resName)
        local file_md5 = fileUtils:isFileExist(file_path) and fileUtils:getFileSize(file_path)
        if file_md5 and table.contains(OldLibaoMd5Arrary, file_md5) then
            return 2
        end
    end

    res = table.find(DoNo_pma_res_android,function ( cur )
        return string.find(resName, cur.resName)
    end )

    if res then
        return 2
    end

    -- for _, v in ipairs(TooBrightArray) do
    --     if string.find(resName, v) then
    --         return 2
    --     end
    -- end

    return 0
end

return PmaHandlerMgr