-- @Author: tangwen
-- @Date:   2019-06-03 16:14:07
-- @Last Modified by:   tangwen
-- @Last Modified time: 2020-02-18 09:56:17

-- 处于哪个跨服的判断管理类

local WhichServerMgr = class("WhichServerMgr")
local ServerType = ServerType
local ConditionHandler = {}

local _instance = nil
function WhichServerMgr.getInstance()
    if _instance == nil then
        _instance = WhichServerMgr.new()
        guiCommonGlobal.controllerAutoPurge(_instance)
    end
    return _instance
end

function WhichServerMgr:purge(  )
end

function WhichServerMgr:isInServer( serverType )
    local hd = ConditionHandler[serverType]
    return hd and hd(self,serverType)
end

function WhichServerMgr:getServerType(  )
    local serverType = GlobalData:call("shared"):getProperty("serverType")
    return serverType
end

-- 先祖战场/杀戮战场
ConditionHandler[ServerType.SERVER_ANCESTRAL] = function ( self,dst_serverType )
    if CCCommonUtilsForLua:isFunOpenByKey("war_trial_on") then
        local serverType = self:getServerType()
        return serverType == dst_serverType or serverType == ServerType.SERVER_ANCESTRAL_TEST
    end
end

-- 先祖战场/杀戮战场 测试服
ConditionHandler[ServerType.SERVER_ANCESTRAL_TEST] = function ( self,dst_serverType )
    if CCCommonUtilsForLua:isFunOpenByKey("war_trial_on") then
        local serverType = self:getServerType()
        return serverType == dst_serverType
    end
end

-- 神秘海域
ConditionHandler[ServerType.SERVER_NATIONALWAR] = function ( self,dst_serverType )
    return require("game.NationalWar.NationalWarController"):isInNationalServerMap()
end

-- 远征
ConditionHandler['YuanZheng'] = function ( self,dst_serverType )
    local serverType = self:getServerType()
    return (serverType == ServerType.SERVER_NORMAL or serverType == ServerType.SERVER_TEST) and isCrossServerNow()
end

-- 怀旧服
ConditionHandler['GreenServer'] = function ( self )
    return GlobalDataCtr.checkIsGreenServer and GlobalDataCtr.checkIsGreenServer() or false
end

return WhichServerMgr