function isUseMultySpeedOpen( multyType, needTime)
	Dprint("isUseMultySpeedOpen ", multyType, needTime)
	return ToolController:isUseMultySpeedOpen() and canMultyGoodsContainTime(multyType, needTime)
end

function canMultyGoodsContainTime( multyType, needTime )
	if needTime <= 3 then -- 对应服务器0秒，服务器会对这种0秒使用加速的提示道具不足，客户端拦截
		return false
	end
	local allTimeStr = ""
    local goodsParaStr = ""
    if not CCCommonUtilsForLua:isFunOpenByKey("use_multy_speed_v2") then
    	Dprint("canMultyGoodsContainTime use_multy_speed_v1use_multy_speed_v1")
        if multyType == 0 then
            allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Building
            goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Building
        elseif multyType == 1 then
            allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Science
            goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Science
        elseif multyType == 2 then
            allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Hightech
            goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Hightech
        elseif multyType == 3 then
            allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Hospital
            goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Hospital
        elseif multyType == 4 then
            allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Fort
            goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Fort
        elseif multyType == 5 then
            allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Soldier
            goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Soldier
        elseif multyType == 6 then
            allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_UpStar
            goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_UpStar
        elseif multyType == 7 then
            allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Glory6
			goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Glory6
		elseif multyType == 8 then
			allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Tactical
			goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Tactical
        elseif multyType == 9 then
            allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Forging
            goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Forging
        elseif multyType == 10 then
            allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_RaceScience
			goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_RaceScience 
		elseif multyType == 11 then
			allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Extension
			goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Extension
		elseif multyType == 12 then
			allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Armament
			goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Armament
		elseif multyType == 13 then
			allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_ArmyReform
			goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_ArmyReform

        end
    else
    	Dprint("canMultyGoodsContainTime use_multy_speed_v2use_multy_speed_v2")
        --queueType -- items
        local finalQueueType = ToolController:getfinalQueueType(multyType)
        local queueSpeed = CCCommonUtilsForLua:getGroupByKey("queueSpeed")
        for k,v in pairs(queueSpeed) do
            if tonumber(v.queueType) == finalQueueType then
                allTimeStr = v.items
                break
            end
        end
    end
    local tempTbl = string.split(allTimeStr, ";")-- 211525;211524;211523;200254;200253;200216;200252
    local goodsParaTbl = {}
    if "" ~= goodsParaStr then
	    goodsParaTbl = string.split(goodsParaStr, ";")
	end
    local allTime = 0
    for i,v in ipairs(tempTbl) do
        local tinfo = ToolController:call("getToolInfoByIdForLua", tonumber(v))
        if tinfo and tinfo:call("getCNT") > 0 then
            local cnt = tinfo:call("getCNT")
            local goodsType = CCCommonUtilsForLua:call("getPropByIdGroup", "goods", tostring(v), "type")
            local tempPara = CCCommonUtilsForLua:call("getPropByIdGroup", "goods", tostring(v), "para")-- 1;1;28800
            if cnt > 0 and tonumber(goodsType) == 2 and tempPara then 
                local paraTbl = string.split(tempPara, ";")
                if not paraTbl or #paraTbl ~= 3 then
                    -- 如果配置错误，直接返回
                    return false
                end
                -- 判断道具具体类型：”专有加速“或者”普通加速“
                local isParasContainType = false
                if CCCommonUtilsForLua:isFunOpenByKey("use_multy_speed_v2") then
                    isParasContainType = true
                else
                    for k,v in pairs(goodsParaTbl) do
                        if v == paraTbl[1] then -- 道具具体类型
                            isParasContainType = true
                            break
                        end
                    end
                end
                if isParasContainType then
                    allTime = allTime + tonumber(paraTbl[3]) * cnt
                end
            end
        end
    end

    if tonumber(needTime) > allTime then 
    	-- 无法覆盖
        Dprint("canMultyGoodsContainTime goods time is less than need time  ", allTime, needTime)
        return false
    else
        Dprint("canMultyGoodsContainTime !")
    	return true
    end
end

ToolController = ToolController or {}

local itemUesFuncMap = {}
local function jumpToKingBiographyView()
    require("game.activity.KingBiography.KingBiographyController").createKingBiographyView()
end
local function jumpToKingBiographyRotate()
    require("game.activity.KingBiography.KingBiographyController").createKingBiographyRotate()
end
local function OpenMysteryBoxUseView(itemData)
    require("game.MysteryBox.MysteryBoxController"):getInstance():OpenUseItemView(itemData)
end

RetGetSellItemMsg = "ret.get.sell.item.msg"

function ToolController:purge()
	self.m_SellItemInfoMap = nil
	self.m_AllSellItemInfo = nil
end

function ToolController:initInLua(  )
	MyPrint("ToolController:initInLua")
	local arr = self:call("getToolIdsByType", 43)
	self.stoneData = arrayToLuaTable(arr)
	-- dump(self.stoneData, "self.stoneData")
	registerScriptObserver(self, self.onToolChange, MSG_TOOL_CHANGE)

	itemUesFuncMap = {}
	itemUesFuncMap[76] = jumpToKingBiographyView
	itemUesFuncMap[75] = jumpToKingBiographyRotate
	itemUesFuncMap[87] = OpenMysteryBoxUseView
end

function ToolController:onToolChange( itemId )
	itemId = utils.getCCValue(itemId,"CCInteger")
	
	if itemId then
		local toolInfo = self:call("getToolInfoForLua",tonumber(itemId))
		if toolInfo then
			local lt = toolInfo:getProperty("limitTime")
			if lt and lt > 0 then
				local limitNotify = self.m_limitNotify
				if not limitNotify then
					limitNotify = CCCommonUtilsForLua:getGroupByKey("limit_item_notify")
					if not table.isNilOrEmpty(limitNotify) then
						local r = {}
						for k,v in pairs(limitNotify) do
							table.append(r,string.split(v.items,";"))
						end

						limitNotify = r
						self.m_limitNotify = limitNotify
					end
				end
				if not table.isNilOrEmpty(limitNotify) then
					local timeNow = utils.timeNow()
					local dt = lt - timeNow
					if dt > 0 and table.contains(limitNotify,tostring(itemId)) then
						local itemName = toolInfo:call("getName")
						local msg = getLang("9800044",itemName,CC_SECTOA(dt))
						CCCommonUtilsForLua:call("flyHint", "", "", msg)
					end
				end
			end
		end
	end
end

function ToolController:getStoneNext( itemId )
	if nil == itemId then
		return 0
	end
	local para1 = CCCommonUtilsForLua:call("getPropById", tostring(itemId), "para1")
	if "" == para1 then
		return 0
	end
	return tonumber(para1)
end

function ToolController:getStoneData(  )
	self.stoneData = self.stoneData or {}
	return self.stoneData
end

-- 找到对应等级的stonedata
function ToolController:getFitStoneDataByEquipLevel( level )
	MyPrint("getFitStoneDataByEquipLevel", level)
	local ret = {}

	if nil == level then
		return ret
 	end

 	level = tonumber(level)

	local data = self:getStoneData()

	for i=1,#data do
		local levelStr = CCCommonUtilsForLua:call("getPropById", tostring(data[i]), "para5")
		local t = string.split(levelStr, ";")
		if #t > 1 then
			local level1 = tonumber(t[1])
			local level2 = tonumber(t[2])
			if level >= level1 and level <= level2 then
				ret[#ret + 1] = data[i]
			end
		end
	end
	dump(ret, "ret")
	return ret
end


function ToolController:retUseTool(dict )
	-- body
end

function ToolController:fireToolEvent(newKey, dict)
	if newKey == "retGetSellItems" then
		self:retGetSellItems(dict)
	elseif newKey == "retShopBuyTool" then
		self:retShopBuyTool(dict)
	end
end

function ToolController:useToolInBag(itemData)
	local itemType = tonumber(itemData["itemType"])
	if itemUesFuncMap[itemType] then
		itemUesFuncMap[itemType](itemData)
		return true
	else
		return false
	end
end

local SellItemInfo = class("SellItemInfo")
function SellItemInfo:ctor(data)
	-- self.m_id = data.id
	self:update(data)
end

function SellItemInfo:update(data)
	self.m_id = data.id or ""
	self.m_item_id = data.item_id or ""
	self.m_page = data.page or ""
	self.m_onsale = tonumber(data.onsale) or 0   -- 是否上架
	self.m_sale_type = data.sale_type or ""
	self.m_beginTime = tonumber(data.beginTime) or 0    -- 0为无限制
	self.m_endTime = tonumber(data.endTime) or 0 		-- 0为无限制
	self.m_total_times = tonumber(data.total_times) or 0
	self.m_serverTotalBuy = tonumber(data.serverTotalBuy) or 0
	self.m_buy_times = tonumber(data.buy_times) or 0    -- 可购买总次数
	self.m_totalBuy = tonumber(data.totalBuy) or 0   	-- 总共购买次数
	local dvvv = string.split(data.buy_times_daily, "|")
	self.m_buy_times_daily = 0
	if #dvvv > 0 then
		self.m_buy_times_daily = tonumber(dvvv[1]) or 0 		--每日可购买次数 
	end
	-- self.m_buy_times_daily = tonumber(data.buy_times_daily) or 0     -- 每日可购买次数 
	self.m_todayBuy = tonumber(data.todayBuy) or 0 		-- 今日购买次数
	self.m_sale = data.sale or ""  					-- 是否促销
	self.m_value1_type = tonumber(data.value1_type) or 0   -- 货币类型 1:金币，2:联盟贡献, 3:国家贡献，4:荣誉 5:svip点数
	self.m_value2_type = tonumber(data.value2_type) or 0
	local vvv = string.split(data.value1, "|")
	self.m_value1 = 0
	if #vvv > 0 then
		self.m_value1 = tonumber(vvv[1]) or 0 		--货币价格
	end
	self.m_value2 = tonumber(data.value2) or 0
	self.m_value1_a = tonumber(data.value1_a) or 0 		-- 原价
	self.m_value2_a = tonumber(data.value2_a) or 0
	self.m_level = tonumber(data.level) or 0
	self.m_castle_level = tonumber(data.castle_level) or 0
	self.m_register = tonumber(data.register) or 0
	self.m_price = tonumber(data.price) or 0
	self.m_display = tonumber(data.display) or 0
	self.m_value_item = tonumber(data.value_item) or 0
	self.m_value_item_num = tonumber(data.value_item_num) or 0
	self.m_times_refresh = tonumber(data.times_refresh) or 0
	self.m_buy_times_refresh_count = tonumber(data.buy_times_refresh_count) or 0

	-- svip商店专用
	self.m_type2 = tonumber(data.type2) or 0    -- 0 普通物品，1、buff
	self.m_svip_shop_level = (data.svip_shop_level) or ""  -- 物品显示等级
	self.m_exp = tonumber(data.exp) or 0     -- 购买后可获得的经验
end

function SellItemInfo:getBuyCount()
	local count = 9999999
	
	-- 总购买次数
	if self.m_buy_times > 0 then
		local left = self.m_buy_times - self.m_totalBuy
		count = count <= left and count or left
	end
	
	if self.m_buy_times_daily > 0 then
		local left = self.m_buy_times_daily - self.m_todayBuy
		count = count <= left and count or left
	end

	return count
end

function SellItemInfo:resetDayChange()
	self.m_todayBuy = 0
end

function ToolController:startGetSellItems()
	ToolController:call("startGetSellItems")
end

-- 目前还未统一，先单独获取svip商店数据
function ToolController:retGetSellItems(array)
	-- if not self.m_SellItemInfoMap then
		self.m_SellItemInfoMap = {}
		self.m_AllSellItemInfo = {}
	-- end

	local list = arrayToLuaTable(array)
	-- dump(list, "ToolController:retGetSellItems ", 10)
	for key, data in pairs(list) do
		local sale_type = data.sale_type
		if sale_type == "13" 
			or sale_type == "17"
			or sale_type == "18"
			or sale_type == "10"
			then
			local tbl = self.m_SellItemInfoMap[sale_type] or {}
			local sellItem = SellItemInfo.new(data)
			tbl[#tbl + 1] = sellItem
			self.m_SellItemInfoMap[sale_type] = tbl
			self.m_AllSellItemInfo[sellItem.m_id] = sellItem
		end
	end

	CCSafeNotificationCenter:call("postNotification", RetGetSellItemMsg, CCBool:create(true))
end

function ToolController:resetSellTimesByDayChange()
	for _, sellItem in pairs(self.m_AllSellItemInfo or {}) do
		sellItem:resetDayChange()
	end
end

function ToolController:getSellItemsByScaleType(sale_type)
	sale_type = tostring(sale_type)
	return self.m_SellItemInfoMap and self.m_SellItemInfoMap[sale_type] or {}
end


function ToolController:retShopBuyTool(dict)
	if dict:objectForKey("m_id") then
		local m_id = dict:objectForKey("m_id"):getCString()
		local tbl = dictToLuaTable(dict)
		if self.m_AllSellItemInfo[m_id] then
			local sellItem = self.m_AllSellItemInfo[m_id]
			sellItem.m_todayBuy = tonumber(tbl.todayBuy)
			sellItem.m_totalBuy = tonumber(tbl.totalBuy)
			sellItem.m_serverTotalBuy = tonumber(tbl.serverTotalBuy)
		end
	end

end

function ToolController:getShopItemData(id)
	return self.m_AllSellItemInfo[id]
end

function ToolController:isUseMultySpeedOpen( )
	local isSwitchOpen = CCUserDefault:sharedUserDefault():getBoolForKey("ISetting_MultySpeed",true)

	local multyType = CCUserDefault:sharedUserDefault():getIntegerForKey("UseMultySpeedTimeStamp", 0)
	local isToday = ActivityController:call("checkIsToday", multyType)
	if CCCommonUtilsForLua:isFunOpenByKey("use_multy_speed") and isSwitchOpen and FunBuildController:call("getMainCityLv") >= ImperialSceneLuaManager.getInstance().use_multy_limit_level and not isToday then
		return true
	else
		return false
	end
end

function ToolController:getfinalQueueType( changeType )
	Dprint("getfinalQueueTypegetfinalQueueType")
    local finalQueueType = 0
    if changeType == 0 then
        finalQueueType = 0
    elseif changeType == 1 then
        finalQueueType = 6
    elseif changeType == 2 then
        finalQueueType = 16
    elseif changeType == 3 then
        finalQueueType = 3
    elseif changeType == 4 then
        finalQueueType = 2
    elseif changeType == 5 then
        finalQueueType = 1
    elseif changeType == 6 then
        finalQueueType = 0
    elseif changeType == 7 then
		finalQueueType = 17
	elseif changeType == 8 then
		finalQueueType = 36
	elseif changeType == 9 then		--锻造
		finalQueueType = 11
	elseif changeType == 10 then	--先祖之魂
		finalQueueType = 19
	elseif changeType == 11 then --扩建
		finalQueueType = 37
	elseif changeType == 12 then --军械库
		finalQueueType = QueueType.TYPE_ARMORY
	elseif changeType == 13 then --士兵改造
		finalQueueType = QueueType.TYPE_ARMY_REFORM
    end
    return finalQueueType
end

function ToolController:getToolCount(itemId)
	itemId = tonumber(itemId)
	if itemId == nil then
		return 0
	end
	local nums = 0
	local tinfo = ToolController:call("getToolInfoForLua", itemId)
	if tinfo then
		nums = tinfo:call("getCNT")
	end
	return nums
end

function ToolController:getUseItemEvent()
	local useItemEv = self.m_useItemEv
	if not useItemEv then
	    useItemEv = utils.getEventClass(  ):create()
	    self.m_useItemEv = useItemEv
	end
	return useItemEv
end
