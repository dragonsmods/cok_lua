-- 通用组队控制类，包含协议和数据处理
local CommonTeamController = class("CommonTeamController")
local _CommonTeamController_ = _CommonTeamController_ or nil

local CommonTeamCMD = {
    info = "crossteam.info",  --页面信息
    search = "crossteam.search", --搜索队伍
    page = "crossteam.page", --分页查询
    create = "crossteam.create", --创建队伍
    apply = "crossteam.apply", --申请队伍
    disapply = "crossteam.disapply", --撤销申请
    agree = "crossteam.agree", --同意申请
    disagree = "crossteam.disagree", --拒绝申请
    invite = "crossteam.invite", --邀请入队
    inviteYes = "crossteam.inviteYes", --同意邀请
    inviteNo = "crossteam.inviteNo", --拒绝邀请
    quit = "crossteam.quit", --退出组队
    transfer = "crossteam.transfer", --转让队长
    remove = "crossteam.remove", --移除队员
    rename = "crossteam.rename", --更改队名
    teaminfo = "crossteam.teaminfo", --队伍信息
    myapply = "crossteam.myapply", --我的申请
    myinvite = "crossteam.myinvite", --我的邀请
    dismiss = "crossteam.dismiss", --解散队伍
}

-----------------------1.页面信息-----------------------------
local CommonTeamInfoCommand = class("CommonTeamInfoCommand", LuaCommandBase)
function CommonTeamInfoCommand:create(params)
    local ret = CommonTeamInfoCommand.new()
    ret:initWithName(CommonTeamCMD.info)
    ret:putParam("tp", CCString:create(params.tp))
    return ret
end

function CommonTeamInfoCommand:handleReceive(dict)
	local tbl, params = self:parseMsg(dict, true)
    if (type(tbl) == "boolean") then
        return tbl
    end
    CCSafeNotificationCenter:postNotification("MsgCommonTeamInfoCommand", params)
    return true
end
-----------------------------------------------------------------

-----------------------2.搜索队伍-----------------------------
local CommonTeamSearchCommand = class("CommonTeamSearchCommand", LuaCommandBase)
function CommonTeamSearchCommand:create(params)
    local ret = CommonTeamSearchCommand.new()
    ret:initWithName(CommonTeamCMD.search)
    ret:putParam("tp", CCString:create(params.tp))
    ret:putParam("name", CCString:create(params.name))
    return ret
end

function CommonTeamSearchCommand:handleReceive(dict)
	local tbl, params = self:parseMsg(dict, true)
    if (type(tbl) == "boolean") then
        return tbl
    end
    CCSafeNotificationCenter:postNotification("MsgCommonTeamSearchCommand", params)
    return true
end
-----------------------------------------------------------------

-----------------------3.分页查询-----------------------------
local CommonTeamPageCommand = class("CommonTeamPageCommand", LuaCommandBase)
function CommonTeamPageCommand:create(params)
    local ret = CommonTeamPageCommand.new()
    ret:initWithName(CommonTeamCMD.page)
    ret:putParam("tp", CCString:create(params.tp))
    ret:putParam("page", CCInteger:create(tonumber(params.page)))
    return ret
end

function CommonTeamPageCommand:handleReceive(dict)
	local tbl, params = self:parseMsg(dict, true)
    if (type(tbl) == "boolean") then
        return tbl
    end
    CCSafeNotificationCenter:postNotification("MsgCommonTeamPageCommand", params)
    return true
end
-----------------------------------------------------------------

-----------------------4.创建队伍-----------------------------
local CommonTeamCreateCommand = class("CommonTeamCreateCommand", LuaCommandBase)
function CommonTeamCreateCommand:create(params)
    local ret = CommonTeamCreateCommand.new()
    ret:initWithName(CommonTeamCMD.create)
    ret:putParam("tp", CCString:create(params.tp))
    ret:putParam("name", CCString:create(params.name))
    return ret
end

function CommonTeamCreateCommand:handleReceive(dict)
	local tbl, params = self:parseMsg(dict, true)
    if (type(tbl) == "boolean") then
        return tbl
    end
    CCSafeNotificationCenter:postNotification("MsgCommonTeamCreateCommand", params)
    return true
end
-----------------------------------------------------------------

-----------------------5.申请队伍-----------------------------
local CommonTeamApplyCommand = class("CommonTeamApplyCommand", LuaCommandBase)
function CommonTeamApplyCommand:create(params)
    local ret = CommonTeamApplyCommand.new()
    ret:initWithName(CommonTeamCMD.apply)
    ret:putParam("tp", CCString:create(params.tp))
    ret:putParam("teamUUID", CCString:create(params.teamUUID))
    return ret
end

function CommonTeamApplyCommand:handleReceive(dict)
	local tbl, params = self:parseMsg(dict, true)
    if (type(tbl) == "boolean") then
        return tbl
    end
    CCSafeNotificationCenter:postNotification("MsgCommonTeamApplyCommand", params)
    return true
end
-----------------------------------------------------------------

-----------------------6.撤销申请-----------------------------
local CommonTeamDisapplyCommand = class("CommonTeamDisapplyCommand", LuaCommandBase)
function CommonTeamDisapplyCommand:create(params)
    local ret = CommonTeamDisapplyCommand.new()
    ret:initWithName(CommonTeamCMD.disapply)
    ret:putParam("tp", CCString:create(params.tp))
    ret:putParam("teamUUID", CCString:create(params.teamUUID))
    return ret
end

function CommonTeamDisapplyCommand:handleReceive(dict)
	local tbl, params = self:parseMsg(dict, true)
    if (type(tbl) == "boolean") then
        return tbl
    end
    CCSafeNotificationCenter:postNotification("MsgCommonTeamDisapplyCommand", params)
    return true
end
-----------------------------------------------------------------

-----------------------7.同意申请-----------------------------
local CommonTeamAgreeCommand = class("CommonTeamAgreeCommand", LuaCommandBase)
function CommonTeamAgreeCommand:create(params)
    local ret = CommonTeamAgreeCommand.new()
    ret:initWithName(CommonTeamCMD.agree)
    ret:putParam("tp", CCString:create(params.tp))
    ret:putParam("teamUUID", CCString:create(params.teamUUID))
    ret:putParam("agreeUid", CCString:create(params.agreeUid))
    return ret
end

function CommonTeamAgreeCommand:handleReceive(dict)
	local tbl, params = self:parseMsg(dict, true)
    if (type(tbl) == "boolean") then
        return tbl
    end
    CCSafeNotificationCenter:postNotification("MsgCommonTeamAgreeCommand", params)
    return true
end
-----------------------------------------------------------------

-----------------------8.拒绝申请-----------------------------
local CommonTeamDisagreeCommand = class("CommonTeamDisagreeCommand", LuaCommandBase)
function CommonTeamDisagreeCommand:create(params)
    local ret = CommonTeamDisagreeCommand.new()
    ret:initWithName(CommonTeamCMD.disagree)
    ret:putParam("tp", CCString:create(params.tp))
    ret:putParam("teamUUID", CCString:create(params.teamUUID))
    ret:putParam("disAgreeUid", CCString:create(params.disAgreeUid))
    return ret
end

function CommonTeamDisagreeCommand:handleReceive(dict)
	local tbl, params = self:parseMsg(dict, true)
    if (type(tbl) == "boolean") then
        return tbl
    end
    CCSafeNotificationCenter:postNotification("MsgCommonTeamDisagreeCommand", params)
    return true
end
-----------------------------------------------------------------

-----------------------9.邀请入队-----------------------------
local CommonTeamInviteCommand = class("CommonTeamInviteCommand", LuaCommandBase)
function CommonTeamInviteCommand:create(params)
    local ret = CommonTeamInviteCommand.new()
    ret:initWithName(CommonTeamCMD.invite)
    ret:putParam("tp", CCString:create(params.tp))
    ret:putParam("teamUUID", CCString:create(params.teamUUID))
    ret:putParam("inviteUid", CCString:create(params.inviteUid))
    ret:putParam("inviteSid", CCInteger:create(tonumber(params.inviteSid)))
    return ret
end

function CommonTeamInviteCommand:handleReceive(dict)
	local tbl, params = self:parseMsg(dict, true)
    if (type(tbl) == "boolean") then
        return tbl
    end
    CCSafeNotificationCenter:postNotification("MsgCommonTeamInviteCommand", params)
    return true
end
-----------------------------------------------------------------

-----------------------10.同意邀请-----------------------------
local CommonTeamInviteYesCommand = class("CommonTeamInviteYesCommand", LuaCommandBase)
function CommonTeamInviteYesCommand:create(params)
    local ret = CommonTeamInviteYesCommand.new()
    ret:initWithName(CommonTeamCMD.inviteYes)
    ret:putParam("tp", CCString:create(params.tp))
    ret:putParam("teamUUID", CCString:create(params.teamUUID))
    return ret
end

function CommonTeamInviteYesCommand:handleReceive(dict)
	local tbl, params = self:parseMsg(dict, true)
    if (type(tbl) == "boolean") then
        return tbl
    end
    CCSafeNotificationCenter:postNotification("MsgCommonTeamInviteYesCommand", params)
    return true
end
-----------------------------------------------------------------

-----------------------11.拒绝邀请-----------------------------
local CommonTeamInviteNoCommand = class("CommonTeamInviteNoCommand", LuaCommandBase)
function CommonTeamInviteNoCommand:create(params)
    local ret = CommonTeamInviteNoCommand.new()
    ret:initWithName(CommonTeamCMD.inviteNo)
    ret:putParam("tp", CCString:create(params.tp))
    ret:putParam("teamUUID", CCString:create(params.teamUUID))
    return ret
end

function CommonTeamInviteNoCommand:handleReceive(dict)
	local tbl, params = self:parseMsg(dict, true)
    if (type(tbl) == "boolean") then
        return tbl
    end
    CCSafeNotificationCenter:postNotification("MsgCommonTeamInviteNoCommand", params)
    return true
end
-----------------------------------------------------------------

-----------------------12.退出队伍-----------------------------
local CommonTeamQuitCommand = class("CommonTeamQuitCommand", LuaCommandBase)
function CommonTeamQuitCommand:create(params)
    local ret = CommonTeamQuitCommand.new()
    ret:initWithName(CommonTeamCMD.quit)
    ret:putParam("tp", CCString:create(params.tp))
    ret:putParam("teamUUID", CCString:create(params.teamUUID))
    return ret
end

function CommonTeamQuitCommand:handleReceive(dict)
	local tbl, params = self:parseMsg(dict, true)
    if (type(tbl) == "boolean") then
        return tbl
    end
    CCSafeNotificationCenter:postNotification("MsgCommonTeamQuitCommand", params)
    return true
end
-----------------------------------------------------------------

-----------------------13.转让队长-----------------------------
local CommonTeamTransferCommand = class("CommonTeamTransferCommand", LuaCommandBase)
function CommonTeamTransferCommand:create(params)
    local ret = CommonTeamTransferCommand.new()
    ret:initWithName(CommonTeamCMD.transfer)
    ret:putParam("tp", CCString:create(params.tp))
    ret:putParam("teamUUID", CCString:create(params.teamUUID))
    ret:putParam("transferUid", CCString:create(params.transferUid))
    return ret
end

function CommonTeamTransferCommand:handleReceive(dict)
	local tbl, params = self:parseMsg(dict, true)
    if (type(tbl) == "boolean") then
        return tbl
    end
    CCSafeNotificationCenter:postNotification("MsgCommonTeamTransferCommand", params)
    return true
end
-----------------------------------------------------------------

-----------------------14.移除队员-----------------------------
local CommonTeamRemoveCommand = class("CommonTeamRemoveCommand", LuaCommandBase)
function CommonTeamRemoveCommand:create(params)
    local ret = CommonTeamRemoveCommand.new()
    ret:initWithName(CommonTeamCMD.remove)
    ret:putParam("tp", CCString:create(params.tp))
    ret:putParam("teamUUID", CCString:create(params.teamUUID))
    ret:putParam("removeUid", CCString:create(params.removeUid))
    return ret
end

function CommonTeamRemoveCommand:handleReceive(dict)
	local tbl, params = self:parseMsg(dict, true)
    if (type(tbl) == "boolean") then
        return tbl
    end
    CCSafeNotificationCenter:postNotification("MsgCommonTeamRemoveCommand", params)
    return true
end
-----------------------------------------------------------------

-----------------------15.更改队名-----------------------------
local CommonTeamRenameCommand = class("CommonTeamRenameCommand", LuaCommandBase)
function CommonTeamRenameCommand:create(params)
    local ret = CommonTeamRenameCommand.new()
    ret:initWithName(CommonTeamCMD.rename)
    ret:putParam("tp", CCString:create(params.tp))
    ret:putParam("teamUUID", CCString:create(params.teamUUID))
    ret:putParam("newName", CCString:create(params.newName))
    return ret
end

function CommonTeamRenameCommand:handleReceive(dict)
	local tbl, params = self:parseMsg(dict, true)
    if (type(tbl) == "boolean") then
        return tbl
    end
    CCSafeNotificationCenter:postNotification("MsgCommonTeamRenameCommand", params)
    return true
end
-----------------------------------------------------------------

-----------------------16.队伍信息-----------------------------
local CommonTeamTeamInfoCommand = class("CommonTeamTeamInfoCommand", LuaCommandBase)
function CommonTeamTeamInfoCommand:create(params)
    local ret = CommonTeamTeamInfoCommand.new()
    ret:initWithName(CommonTeamCMD.teamInfo)
    ret:putParam("tp", CCString:create(params.tp))
    ret:putParam("teamUUID", CCString:create(params.teamUUID))
    return ret
end

function CommonTeamTeamInfoCommand:handleReceive(dict)
	local tbl, params = self:parseMsg(dict, true)
    if (type(tbl) == "boolean") then
        return tbl
    end
    CCSafeNotificationCenter:postNotification("MsgCommonTeamTeamInfoCommand", params)
    return true
end
-----------------------------------------------------------------

-----------------------17.我的申请-----------------------------
local CommonTeamMyapplyCommand = class("CommonTeamMyapplyCommand", LuaCommandBase)
function CommonTeamMyapplyCommand:create(params)
    local ret = CommonTeamMyapplyCommand.new()
    ret:initWithName(CommonTeamCMD.myapply)
    ret:putParam("tp", CCString:create(params.tp))
    return ret
end

function CommonTeamMyapplyCommand:handleReceive(dict)
	local tbl, params = self:parseMsg(dict, true)
    if (type(tbl) == "boolean") then
        return tbl
    end
    CCSafeNotificationCenter:postNotification("MsgCommonTeamMyapplyCommand", params)
    return true
end
-----------------------------------------------------------------

-----------------------18.我的邀请-----------------------------
local CommonTeamMyinvitedCommand = class("CommonTeamMyinvitedCommand", LuaCommandBase)
function CommonTeamMyinvitedCommand:create(params)
    local ret = CommonTeamMyinvitedCommand.new()
    ret:initWithName(CommonTeamCMD.myinvite)
    ret:putParam("tp", CCString:create(params.tp))
    return ret
end

function CommonTeamMyinvitedCommand:handleReceive(dict)
    local tbl, params = self:parseMsg(dict, true)
    if (type(tbl) == "boolean") then
        return tbl
    end
    CCSafeNotificationCenter:postNotification("MsgCommonTeamMyinvitedCommand", params)
    return true
end
-----------------------------------------------------------------

-----------------------19.解散队伍-----------------------------
local CommonTeamDismissCommand = class("CommonTeamDismissCommand", LuaCommandBase)
function CommonTeamDismissCommand:create(params)
    local ret = CommonTeamDismissCommand.new()
    ret:initWithName(CommonTeamCMD.dismiss)
    ret:putParam("tp", CCString:create(params.tp))
    ret:putParam("teamUUID", CCString:create(params.teamUUID))
    return ret
end

function CommonTeamDismissCommand:handleReceive(dict)
    local tbl, params = self:parseMsg(dict, true)
    if (type(tbl) == "boolean") then
        return tbl
    end
    CCSafeNotificationCenter:postNotification("MsgCommonTeamDismissCommand", params)
    return true
end
-----------------------------------------------------------------

-----------------------------------------------------------------
function CommonTeamController.getInstance()
    if not _CommonTeamController_ then
        _CommonTeamController_ = CommonTeamController.new()
    end
    return _CommonTeamController_
end

function CommonTeamController:ctor()
    
end

function CommonTeamController:purge()
    
end

function CommonTeamController:getCmdMsgStr(cmdType)
    return CommonTeamCMD[cmdType] or ""
end

function CommonTeamController:requestData(type, params)
    local CommonTeamCMDFile = {
        info = CommonTeamInfoCommand,
        search = CommonTeamSearchCommand,
        page = CommonTeamPageCommand,
        create = CommonTeamCreateCommand,
        apply = CommonTeamApplyCommand,
        disapply = CommonTeamDisapplyCommand,
        agree = CommonTeamAgreeCommand,
        disagree = CommonTeamDisagreeCommand,
        invite = CommonTeamInviteCommand,
        inviteYes = CommonTeamInviteYesCommand,
        inviteNo = CommonTeamInviteNoCommand,
        quit = CommonTeamQuitCommand,
        transfer = CommonTeamTransferCommand,
        remove = CommonTeamRemoveCommand,
        rename = CommonTeamRenameCommand,
        teaminfo = CommonTeamTeamInfoCommand,
        myapply = CommonTeamMyapplyCommand,
        myinvite = CommonTeamMyinvitedCommand,
        dismiss = CommonTeamDismissCommand,
    }
    local reqCmd = CommonTeamCMDFile[type]:create(params)
    if reqCmd ~= nil then
        reqCmd:send()
    end
end

function CommonTeamController:parseErrorMsg(tbl)
    if tbl.retCode then
        LuaController:flyHint("", "", getLang(tbl.retCode)) 
    end
end

return CommonTeamController
