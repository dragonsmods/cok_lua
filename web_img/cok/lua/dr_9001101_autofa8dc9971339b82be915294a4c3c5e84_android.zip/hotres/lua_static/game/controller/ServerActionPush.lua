local ServerActionPush = {}

function ServerActionPush.getServerPush(dataTable)
    
end

function ServerActionPush.getPushEffectUser(dataTable)
    local userUid = dataTable.effectUid
    local myUuid = GlobalDataCtr.getUuid()
    local userName = dataTable.effectUserName or ""
    if userUid == myUuid then
        dump("same uuid ")
    	local tips = getLang("9400629", userName)
        YesNoDialog:show(tips)
    else
        dump("un same uuid  ")
    	local tips = getLang("9400631", userName)
    	local function confirmFunc()
            PopupViewController:call("removeAllPopupView")
    		local view = SetAccountView:call("create")
            PopupViewController:call("addPopupInView", view)
    	end

    	local function cancelFunc( ... )
    		
    	end
        local view = YesNoDialog:show(tips, confirmFunc)
        YesNoDialog:showCancelButton(view)
        -- YesNoDialog:call("showYesNoFun", cc.CallFunc:create(confirmFunc), getLang("9400632"), cc.CallFunc:create(cancelFunc), getLang("9400633"), "")
    end
end

return ServerActionPush