--解析从网页分享链接进入游戏带入的数据
--[[  
    分享出去的链接格式要求：
        ?activityTag=...&lang=...&pf=...(必有参数)
    e.g. 
        一个完整的链接:http://cokplayer-sharecode.elexapp.com/sharecode/common/openlink?activityTag=reward&lang=zh_CN&pf=abc&code=efg&...
    三个必带参数
        activityTag为key值,这个key值需要(运维后台)刘鹏那里配上点击才有效
        lang为游戏语言
        pf为游戏平台
    自定义添加参数
        &key=value&key=vlaue
    链接点击后的跳转码：
        cok://clashofkings/keyValue?lang=...&pf=...&...
        keyValue为activityTag的value字面值

    调试方式：运行Xcode模拟器，切到safari,输入分享链接预览分享出去的内容，输入跳转码，切进游戏查看参数
]]


local CommonShareURLController = {}
--通过点击url切进游戏后如果需要弹出对应界面，在下面加首弹逻辑
function CommonShareURLController.checkOpenByUrl( )
    local str = GlobalData:call("shared"):getProperty("paramStrFromShareUrl")
	if str == "" then
		return false
	end
	local strTbl = string.split(str, "?")
	if strTbl[1] == "openwebactivitycenter" then
		local view = Drequire("game.activity.web.WebActivityView"):create(strTbl[2])
		PopupViewController:addPopupInView(view)
		GlobalData:call("shared"):setProperty("paramStrFromShareUrl", "")
		return true
	end
	return false
end

--根据key获取参数信息
--定一下格式: key为唯一key值, key与value用?隔开, value每个参数带上参数名称和参数值，&隔开
--key?code=3b85f13700dd90b1&lang=zh_CN&pf=weixin
function CommonShareURLController.getParamsByKey(key)
    local function parse(value)
        if value == "" then
            return {}
        end
        local paramTbl = {}
        local paramInfo = string.split(value,"&")
        for index, param in pairs(paramInfo or {}) do
            if param ~= "" then
                local _p = string.split(param,"=")
                local _key = _p[1]
                local _value = _p[2] or ""
                paramTbl[_key] = _value
            end
        end
        return paramTbl
    end
    local res = {}
    --test "hxqTest?code=3b85f13700dd90b1&lang=zh_CN&pf=weixin&abcdefg&aaaa"
    local str = GlobalData:call("shared"):getProperty("paramStrFromShareUrl")
	if str == "" then
		return res
	end
	local strTbl = string.split(str, "?")
    if strTbl[1] == key then
        res = parse(strTbl[2])
    end
    return res
end

return CommonShareURLController