-- @Author: tangwen
-- @Desc:   protobuffer 管理类
-- @Note:   None


local ProbufferMgr = class("ProbufferMgr")

local _instance = nil
function ProbufferMgr.getInstance()
    if _instance == nil then
        _instance = ProbufferMgr.new()
        guiCommonGlobal.controllerAutoPurge(_instance)
    end
    return _instance
end

function ProbufferMgr:ctor(  )
    self.m_cached_proto = {}
end

function ProbufferMgr:purge(  )
    self.m_cached_proto = {}
end

function ProbufferMgr:getCommandId(  )
	local tType = self.m_commandIds
	if not tType then
		tType = utils.toNumberEnum({
            -- 皮肤缩放功能
			{"SkinScaleDataUp",10101},
			{"SkinScaleResetUp"},
		}, 2)
		self.m_commandIds = tType
	end
	return tType
end

-- 查找包内的pb文件, 测试环境下会先查找可写路径下dresource内的pb文件 未找到返回nil
function ProbufferMgr:getPbPath( pb_name )
    local fileUtils = cc.FileUtils:getInstance()
    if LUA_DEBUG == 1 then
        local writable_path = string.join("",fileUtils:getWritablePath(),"dresource/",pb_name)
        if fileUtils:isFileExist(writable_path) then
            return writable_path
        end
    end

    local full_path = fileUtils:fullPathForFilename("pbs/" .. pb_name)
    if not string.isNilOrEmpty(full_path) then
        return full_path
    end

    return nil
end

function ProbufferMgr:tryRegistPb( pb_name )
    if LUA_DEBUG ~= 1 and self.m_cached_proto[pb_name] then
        return
    end

    local pb_path = self:getPbPath(pb_name)
    assert(pb_path,"cannot find pb file of " .. pb_name)
    local buffer = read_protobuf_file_c(pb_path)
    protobuf.register(buffer)
    self.m_cached_proto[pb_name] = true
end

function ProbufferMgr:getMessageBuffer( message_name, message_tbl, pb_name )
    self:tryRegistPb(pb_name)
    local buffer = protobuf.encode(message_name,message_tbl)
    assert(type(buffer) == "string","invalid message content match with " .. message_name)
    return buffer, string.len(buffer)
end

--[[
    -- 请求服务 message_down_name 默认为 替换message_name 中 Up => Down 的值 UserLoadUp => UserLoadDown
    require("game.controller.ProbufferMgr").getInstance():requestServerWithPb({      
        luckNum = {888},      
        userInfo = {      
            name = "cok",
            age = 18,
            weight = 150.6,
            high = 1.8,
        }      
    },"UserLoadUp",10001,"UserLoadDown")

    -- 收到服务器回复 推荐使用事件机制而不是回调, 以免回调函数调用时使用的node引用已经失效(如退出界面)
    -- 事件机制确保在onCleanup里 解除对事件的监听
    -- in your lua class
    -- 1. listen event
    require("game.controller.ProbufferMgr").getInstance():getRespEvent():add(self.onProtoResp,self)
    -- 2. unlisten event on cleanUp
    require("game.controller.ProbufferMgr").getInstance():getRespEvent():remove(self.onProtoResp,self)
    -- 3. 处理回复
    function YourLuaClass:onProtoResp( from, msgup, msgdown, tbl )
        if from ~= "request" then
            return
        end
        if msgup ~= "UserLoadUp" or msgdown ~= "UserLoadDown" then
            return
        end
        local state = tbl.state
        tbl.state = state
        local tbl_str = utils.lua_to_json(tbl)
        respText:setString(tbl_str)
    end
]]
function ProbufferMgr:requestServerWithPb(  message_tbl, message_name, commandId, message_down_name, call_back )
    commandId = commandId or 10001
    message_name = message_name or "UserLoadUp"
    message_down_name = message_down_name or string.gsub( message_name,"Up","Down" )
    assert(commandId % 2 == 1,"request commandId must be odd")
    local bodybuffer = self:getMessageBuffer(message_name, message_tbl, "logic.pb")
    local stringbuffer,slen = self:getMessageBuffer("Request", {   
        header = {
            commandId = commandId
        },
        content = bodybuffer
    },"common.pb")

    utils.requestServer("cok.proto",{{"pb",CCBytesArray:create(stringbuffer,slen)}},nil,function(tbl)
        if table.isNilOrEmpty(tbl) or not tbl.result then
            local errTxt = getLang("E000000") .. message_name
            LuaController:flyHint("", "", errTxt)
            return
        end
        local responseResult = self:handleResponse__(tbl,message_down_name,"logic.pb")
        if not responseResult then
            return
        end
        self:getRespEvent():emit("request",message_name,message_down_name,responseResult)
        if call_back then
            call_back(responseResult)
        end
    end)
end

function ProbufferMgr:handleResponse__(  tbl, message_name, pb_name )
    self:tryRegistPb("common.pb")
    self:tryRegistPb(pb_name)
    local responseResult = protobuf.decode("Response", tbl.result)
    assert(type(responseResult) == "table","invalid Response type")
    assert(not table.isNilOrEmpty(responseResult),"invalid Response")
    assert(responseResult.state,"invalid state code")
    assert(responseResult.header and responseResult.header.commandId and responseResult.header.commandId % 2 == 0,"response commandId must be even")
    
    if responseResult.state == 0 and responseResult.content then
        local responseContent = protobuf.decode(message_name, responseResult.content)
        responseResult.content = responseContent
    else
        cclog("Waring: cok.proto error state code %s",responseResult.state)
    end
    return responseResult
end

function ProbufferMgr:handlePushedMsg(  buffer_tbl, message_name, pb_name )
    message_name = message_name or "PushTest"
    pb_name = pb_name or "logic.pb"
    local pushResult = self:handleResponse__(buffer_tbl, message_name, pb_name)
    if not pushResult then
        return
    end
    self:getRespEvent():emit("push",message_name,message_name,pushResult)
end

-- emit 参数: 
-- para1: msg_type  [request, push]
-- para2: msg_up    proto 上行消息名
-- para3: msg_down  proto 下行消息名
-- para4: msg_data  proto 数据
function ProbufferMgr:getRespEvent(  )
    local respEv = self.m_respEv
    if not respEv then
        respEv = utils.getEventClass():create()
        self.m_respEv = respEv
    end
    return respEv
end

return ProbufferMgr