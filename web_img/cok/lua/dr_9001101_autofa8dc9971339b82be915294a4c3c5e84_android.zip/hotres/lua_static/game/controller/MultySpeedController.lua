--[[ 
    加速道具使用控制类
 ]]
MultySpeedController = class("MultySpeedController")
local _instance = nil
local UseSpeedTag = {
    Building = 0,       -- 建筑
    Science = 1,      -- 学院
    HighTech = 2,       -- 贤者
    Hospital = 3,       -- 医疗
    Fort = 4,     -- 陷阱
    Soldier = 5,       -- 造兵
    UpStar = 6,       -- 升星
    Glory6 = 7,       -- 荣6造兵
    Tactical = 8,     --阵法研习
    Forging = 9,      --锻造
    RaceScience = 10, --先祖之魂
    Extension = 11, --扩建
    Armament = 12,--军械制造
    ArmyReform = 13,--士兵改造
}
local SPECIALGOODSTBL = "specialGoodsTbl"
local COMMONGOODSTBL = "commonGoodsTbl"

function MultySpeedController.getInstance()
    if _instance == nil then
        _instance = MultySpeedController.new();
    end
    return _instance;
end

function MultySpeedController:ctor()
    self._noTips = false            --加速界面复选框是否选中
    self._commonConfirmed = false        --是否使用过通用加速
end

function MultySpeedController:resetStatus()
    self._noTips = false
    self._commonConfirmed = false
end

function MultySpeedController:setNoTips(flag)
    self._noTips = flag
end

function MultySpeedController:setCommonConfirmed(flag)
    self._commonConfirmed = flag
end

--[[
    立即使用加速道具
]]
function MultySpeedController:useMultSpeedImmediately(multySpeedType, time)
    if not self._noTips then
        return false
    elseif FunBuildController:call("getMainCityLv") >= ImperialSceneLuaManager.getInstance().use_multy_limit_level
        and canMultyGoodsContainTime(multySpeedType, tostring(time)) then
            
        local infos, containCommon = self:getWillUseSpeedToolData(multySpeedType, time)
        if containCommon and not self._commonConfirmed then
            return false
        end
        local dict = CCDictionary:create()
        dict:setObject(CCString:create("1"), "multySpeedType")

        local tempGoodsStr = ""
        local isFirstIn = true
        for k,v in pairs(infos) do
            if  v.itemId ~= 0 then
                if isFirstIn then
                   isFirstIn = false
                else
                    tempGoodsStr = tempGoodsStr .. "|"
                end
                tempGoodsStr = tempGoodsStr .. v.itemId .. ";" .. v.itemNum
            end
           
        end
        --dump(tempGoodsStr,"tempGoodsStr----")
        dict:setObject(CCString:create(tempGoodsStr), "tempGoodsStr")

        if multySpeedType == UseSpeedTag.Building then
            CCSafeNotificationCenter:postNotification("useMultySpeed_Building", dict)
        
        elseif multySpeedType == UseSpeedTag.UpStar then
            CCSafeNotificationCenter:postNotification("useMultySpeed_UpStar", dict)

        elseif multySpeedType == UseSpeedTag.Science then
            CCSafeNotificationCenter:postNotification("useMultySpeed_Science", dict)

        elseif multySpeedType == UseSpeedTag.HighTech then
            CCSafeNotificationCenter:postNotification("useMultySpeed_HighTech", dict)

        elseif multySpeedType == UseSpeedTag.Hospital then
            CCSafeNotificationCenter:postNotification("useMultySpeed_Hospital", dict)

        elseif multySpeedType == UseSpeedTag.Fort then
            CCSafeNotificationCenter:postNotification("useMultySpeed_Fort", dict)

        elseif multySpeedType == UseSpeedTag.Soldier then
            CCSafeNotificationCenter:postNotification("useMultySpeed_Soldier", dict)

        elseif multySpeedType == UseSpeedTag.Glory6 then
            CCSafeNotificationCenter:postNotification("useMultySpeed_Glory6", dict)

        elseif multySpeedType == UseSpeedTag.Tactical then
            CCSafeNotificationCenter:postNotification("useMultySpeed_Tactical", dict)

        elseif multySpeedType == UseSpeedTag.Forging then
            CCSafeNotificationCenter:postNotification("useMultySpeed_Forging", dict)

        elseif multySpeedType == UseSpeedTag.RaceScience then
            CCSafeNotificationCenter:postNotification("useMultySpeed_RaceScience", dict)
        elseif multySpeedType == UseSpeedTag.Extension then
            CCSafeNotificationCenter:postNotification("useMultySpeed_Extension", dict)
        elseif multySpeedType == UseSpeedTag.Armament then
            CCSafeNotificationCenter:postNotification("useMultySpeed_Armament", dict)
        elseif multySpeedType == UseSpeedTag.ArmyReform then
            CCSafeNotificationCenter:postNotification("useMultySpeed_ArmyReform", dict)
        end  

        return true
    end

    return false
end

function MultySpeedController:getWillUseSpeedToolData(multySpeedType, time)
    local tempComman, tempSpecial, tempFree, containCommon = self:getDecSpeedGoodsTbl(multySpeedType, time)

    -- 检查道具数量是否匹配
    if not self:checkItemNumEnough(tempSpecial) or not self:checkItemNumEnough(tempComman) then
        return {}
    end

    local info = {}
    if tempFree and #tempFree > 0 then
        for k,v in pairs(tempFree) do
            table.insert(info, v)
        end
    end
    if tempComman and #tempComman > 0 then
        for k,v in pairs(tempComman) do
            table.insert(info, v)
        end
    end
    if tempSpecial and #tempSpecial > 0 then
        for k,v in pairs(tempSpecial) do
            table.insert(info, v)
        end
    end

    return info, containCommon
end

function MultySpeedController:getDecSpeedGoodsTbl(multyType, needTime)
    Dprint(needTime, "cjy needTime")
    local containCommon = false
    -- 时间小于0
    if needTime <= 0 then
        Dprint("needTime is less than 0 ")
        return nil
    end

    local allTime ,allTimeTbl = self:getMultyGoodsContainTime(multyType)

     
       dump(allTimeTbl,"allTimeTbl-------")
    --找不到需要的加速道具
    if nil == allTimeTbl then
        Dprint("can not find goods with multyType ")
        return nil
    end
    -- 道具时间少于需要时间
    if needTime > allTime then 
        Dprint("goods time is less than need time  ", allTime, needTime)
        return nil

    elseif needTime == allTime then
        -- 全部覆盖
        return allTimeTbl[SPECIALGOODSTBL], allTimeTbl[COMMONGOODSTBL],allTimeTbl["free"]
    end

    local nowNeedTbl = {}
    local finalNeedTbl = nil

    --是否能使用免费道具
    local freetime = 0
    if allTimeTbl["free"] and  #allTimeTbl["free"] > 0 then
         for i,v in ipairs(allTimeTbl["free"]) do
             freetime = freetime + tonumber(v.timeCost) * tonumber(v.itemNum)
         end
    end     

    local specialAllTime = 0
    for k,v in pairs(allTimeTbl[SPECIALGOODSTBL]) do
        local tinfo = ToolController:call("getToolInfoByIdForLua", tonumber(v.itemId))
        if tinfo and tinfo:call("getCNT") > 0 then
            specialAllTime = specialAllTime + tonumber(v.timeCost) * tonumber(v.itemNum)
        end
    end
    -- 如果specialTbl足够，全部用特殊道具
    if needTime <= freetime then
        return {}, {},allTimeTbl["free"]  
    elseif needTime <= specialAllTime + freetime then
        nowNeedTbl = allTimeTbl[SPECIALGOODSTBL]
        needTime = needTime - freetime
    else
        -- 否则用普通道具
        containCommon = true
        nowNeedTbl = allTimeTbl[COMMONGOODSTBL]
        finalNeedTbl = allTimeTbl[SPECIALGOODSTBL]
        needTime = needTime - specialAllTime - freetime

    end

    --选出起始值
    local nowIndex = 0
    for k,v in pairs(nowNeedTbl) do
        --遍历时间，筛选数据
        if tonumber(v.timeCost) <= needTime then
            nowIndex = k
            break
        end
    end

    local maxIndex = #nowNeedTbl    
    local speedGoodsTbl = {}
    if nowIndex > 1 then
        --能找到中间的起始值，判断用低等加速是否满足条件
        local checkNum = 0
        for i=nowIndex,maxIndex do
            checkNum = checkNum + tonumber(nowNeedTbl[i].timeCost) * tonumber(nowNeedTbl[i].itemNum)
        end
        if checkNum < needTime then
            --取上限
            local lastGoodsTbl = nowNeedTbl[nowIndex - 1]
            return finalNeedTbl, self:getDecSpeedGoodsMapForOneSpecial(nowNeedTbl, speedGoodsTbl, tonumber(lastGoodsTbl.timeCost)),allTimeTbl["free"], containCommon
        end
    elseif nowIndex == 0 then
        -- 所需时间极小，直接取最后一个道具
        local lastGoodsTbl = nowNeedTbl[maxIndex]
        return finalNeedTbl, self:getDecSpeedGoodsMapForOneSpecial(nowNeedTbl, speedGoodsTbl, tonumber(lastGoodsTbl.timeCost)),allTimeTbl["free"], containCommon
    end

    -- 遍历填充speedGoodsTbl
    while needTime > 0 and nowIndex <= maxIndex do
        local nowTbl = nowNeedTbl[nowIndex]
        local goodsId = nowTbl.itemId
        local goodsNum = tonumber(nowTbl.itemNum)
        local goodsTimeCost = tonumber(nowTbl.timeCost)
        local needNum = math.floor(needTime / goodsTimeCost)
        -- 不能超过拥有的最大数量
        if needNum > goodsNum then
            needNum = goodsNum
        end
        if needNum > 0 then
            --填充数组
            local tempTbl = {}
            tempTbl["itemId"] = goodsId
            tempTbl["itemNum"] = needNum
            tempTbl["timeCost"] = goodsTimeCost
            table.insert(speedGoodsTbl, tempTbl)
            -- 更新道具个数
            nowTbl.itemNum = tonumber(nowTbl.itemNum) - needNum
            --更新时间
            needTime = needTime - goodsTimeCost * needNum
        end
        nowIndex = nowIndex + 1
    end

    if needTime <= 0 then
        --查找成功 返回
        return finalNeedTbl, speedGoodsTbl,allTimeTbl["free"], containCommon
    else
        --填装最后一个
        return finalNeedTbl, self:getDecSpeedGoodsMapForOneSpecial(nowNeedTbl, speedGoodsTbl, -1),allTimeTbl["free"], containCommon
    end
end

function MultySpeedController:getMultyGoodsContainTime(multyType)
    Dprint("MultySpeedController:getMultyGoodsContainTime", multyType, CCCommonUtilsForLua:isFunOpenByKey("use_multy_speed_v2"))
    local allTimeStr = ""
    local goodsParaStr = ""

    if multyType == 0 then
        allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Building
        goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Building
    elseif multyType == 1 then
        allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Science
        goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Science
    elseif multyType == 2 then
        allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Hightech
        goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Hightech
    elseif multyType == 3 then
        allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Hospital
        goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Hospital
    elseif multyType == 4 then
        allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Fort
        goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Fort
    elseif multyType == 5 then
        allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Soldier
        goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Soldier
    elseif multyType == 6 then
        allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_UpStar
        goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_UpStar
    elseif multyType == 7 then
        allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Glory6
        goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Glory6
    elseif multyType == 8 then
        allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Tactical
        goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Tactical
    elseif multyType == UseSpeedTag.Forging then
        allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Forging
        goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Forging
    elseif multyType == UseSpeedTag.RaceScience then
        allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_RaceScience
        goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_RaceScience  
    elseif multyType == UseSpeedTag.Extension then
        allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Extension
        goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Extension 
    elseif multyType == UseSpeedTag.Armament then
        allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Armament
        goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Armament
    elseif multyType == UseSpeedTag.ArmyReform then
        allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_ArmyReform
        goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_ArmyReform
    end

    local tempTbl = string.split(allTimeStr, ";")-- 211525;211524;211523;200254;200253;200216;200252

    if (multyType == 0 or multyType == 6) then
        --建筑有免费加速
        table.insert(tempTbl,0)
    end

    local goodsParaTbl = {}
    if goodsParaStr ~= "" then
        goodsParaTbl = string.split(goodsParaStr, ";")
    end
    local allTime = 0
    local commonGoodsTbl = {}
    local specialGoodsTbl = {}
    local freeGoodsTbl = {}
    local allGoodsTbl = {}
    for i,v in ipairs(tempTbl) do
        if tonumber(v) == 0 then
            --免费加速
        --填充table
            local tempAllTimeTbl = {}
            tempAllTimeTbl["itemId"] = 0
            tempAllTimeTbl["itemNum"] = 1
            tempAllTimeTbl["timeCost"] =  GlobalData:call("shared"):getProperty("freeSpdT") 
            table.insert(freeGoodsTbl, tempAllTimeTbl) 
            allTime = allTime + tempAllTimeTbl["timeCost"]        
            
        end
        local tinfo = ToolController:call("getToolInfoByIdForLua", tonumber(v))
        if tinfo and tinfo:call("getCNT") > 0 then
            local cnt = tinfo:call("getCNT")
            local goodsType = CCCommonUtilsForLua:call("getPropByIdGroup", "goods", tostring(v), "type")
            local tempPara = CCCommonUtilsForLua:call("getPropByIdGroup", "goods", tostring(v), "para")-- 1;1;28800
            if cnt > 0 and tonumber(goodsType) == 2 and tempPara then 
                local paraTbl = string.split(tempPara, ";")
                if not paraTbl or #paraTbl ~= 3 then
                    -- 如果配置错误，直接返回
                    return false
                end

                -- 判断道具具体类型：”专有加速“或者”普通加速“
                allTime = allTime + tonumber(paraTbl[3]) * cnt

                --填充table
                local tempAllTimeTbl = {}
                tempAllTimeTbl["itemId"] = v
                tempAllTimeTbl["itemNum"] = cnt
                tempAllTimeTbl["timeCost"] = paraTbl[3]
                tempAllTimeTbl["para1"] = paraTbl[1]
                if tonumber(paraTbl[1]) > 1 then
                    table.insert(specialGoodsTbl, tempAllTimeTbl)
                else
                    table.insert(commonGoodsTbl, tempAllTimeTbl)
                end
            end
        end
    end
    --排序规则：先按照时间降序排列，再按照具体加速类型降序排列，专有加速类型大于普通加速类型
    function sortById( a,b )
        return tonumber(a.timeCost) > tonumber(b.timeCost)
    end
    table.sort(specialGoodsTbl,sortById)
    table.sort(commonGoodsTbl,sortById)
    local allTimeTbl = {}
    allTimeTbl[SPECIALGOODSTBL] = specialGoodsTbl
    allTimeTbl[COMMONGOODSTBL] = commonGoodsTbl
    allTimeTbl["free"] = freeGoodsTbl

    Dprint("cjy allTime ", allTime)
    return allTime, allTimeTbl
end

function MultySpeedController:getDecSpeedGoodsMapForOneSpecial( allTimeTbl, speedGoodsTbl, needTime )
    if nil == allTimeTbl or #allTimeTbl <= 0 then
        return nil
    end
    local needTbl = {}
    if needTime == -1 then
        -- 不给定时间：代表所需时间无法被整除，取当前最小，并且需要重置allTimeTbl
        local allTimeTblNew = {}
        for k,v in pairs(allTimeTbl) do
            if tonumber(v.itemNum) > 0 then
                table.insert(allTimeTblNew, v)
            end
        end
        --取出最后一个可用的最小时间
        local lastTime = tonumber(allTimeTblNew[#allTimeTblNew].timeCost)
        for k,v in pairs(allTimeTblNew) do
            if tonumber(v.timeCost) == lastTime then
                needTbl = v
                break
            end
        end
    else
        -- 给定时间
        for k,v in pairs(allTimeTbl) do
            if tonumber(v.timeCost) == needTime and tonumber(v.itemNum) > 0 then
                --找到制定时间的加速道具，并且是优先”专属加速“
                needTbl = v
                break
            end
        end
    end
    if nil == needTbl then
        -- 未找到制定加速道具
        return nil
    end
    
    --找到制定时间的加速道具，并且是优先”专属加速“
    if #speedGoodsTbl <= 0 then
       needTbl.itemNum = 1
        table.insert(speedGoodsTbl, needTbl)
    else
        for i,v in ipairs(speedGoodsTbl) do
            if v.itemId == needTbl.itemId then
                v.itemNum = tonumber(v.itemNum) + 1
                return speedGoodsTbl
            end
        end
        needTbl.itemNum = 1
        table.insert(speedGoodsTbl, needTbl)
    end
    return speedGoodsTbl
end

function MultySpeedController:checkItemNumEnough( tbl )
    if nil ~= tbl and #tbl > 0 then
        for k,v in pairs(tbl) do
            local tinfo = ToolController:call("getToolInfoByIdForLua", tonumber(v.itemId))
            if tinfo and tinfo:call("getCNT") < v.itemNum then
                return false
            end
        end
    end
    return true
end

return MultySpeedController