StationTile = class("StationTile", function()
    return NewBaseTileLuaInfo:call("create")
end
)

function StationTile:create( index )
    local tile = StationTile.new(index)
    if tile:initView(index) then
        return tile
    end
end

function StationTile:ctor(index)
    self.cityIndex = index
end

function StationTile:initView( index )
    self:call("setCityIndex", index)
    if self:call("initTile", true) == false then return false  end

    local cityInfo = self:call("getCityInfo")
    if nil == cityInfo then return false end

    self.cityInfo = cityInfo
    self.luaMap = cityInfo:call("getLuaMap")
    -- dump(self.luaMap)

    self.dataBack = false
    registerNodeEventHandler(self)
    self:call("addToParent")
    self:refreshView()

    return true
end

function StationTile:onEnter()

end

function StationTile:onExit()
   
end

function StationTile:refreshView()
    local function setCallBack(name, index, func, state)
        local function callback() func(self) end
        self:call("setButtonName", index, name)
        self:call("setButtonState", index, state)
        self:call("setButtonCallback", index, cc.CallFunc:create(callback))
    end

    self:call("setButtonCount", 2)
     if CCCommonUtilsForLua:isFunOpenByKey("activity_visit_city") then
        self:call("setButtonCount", 3)
        setCallBack(getLang("681684"), 1, self.clickVisite, TileButtonState.ButtonBarracks_Reward)
    end
    setCallBack(getLang("41576003"), 3, self.information, TileButtonState.ButtonCommercial) -- 108730=说明
    setCallBack(getLang("41576038"), 2, self.scout, TileButtonState.ButtonScout) -- 108539=侦查   

   
end

function StationTile:information()
    if CCCommonUtilsForLua:isFunOpenByKey("bodyguard") then
        require("game.commercialDarts.CommercialController").getInstance():showPopView()
    else
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("102192"))
    end
    self:closeTile()
end

function StationTile:scout()
    if CCCommonUtilsForLua:isFunOpenByKey("bodyguard") then
        if not GlobalData:call("getPlayerInfo"):call("isInAlliance") then
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("133032"))
            self:closeTile()
            return
        end

        local index = atoi(self.luaMap.index)
        require("game.commercialDarts.CommercialController").getInstance():scout(index, nil, getLang(StationName[index]))
    else
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("102192"))
    end
    self:closeTile()
end
function StationTile:clickVisite()
     require('game.FestivalActivities.FestivalActVisiteSiteCtr').getInstance():popMapVisiteSitePopView(self.cityIndex)
end

-- function StationTile:receive()
--     SoundController:call("playEffects", Music_Sfx_click_button)
--     -- require("game.commercialDarts.CommercialController").getInstance():startCaravan()
--     -- self:closeTile()
--     local dict = CCDictionary:create()
--     dict:setObject(CCString:create("OpenBattleViewForCommercial"), "name")
--     dict:setObject(CCString:create("-168"), "type")
--     dict:setObject(CCString:create("41597001"), "id")
--     dict:setObject(CCString:create("COMMERCIAL_RECEIVE"), "key")
--     LuaController:call("openPopViewInLua", dict)
--     require("game.commercialDarts.CommercialController").getInstance():getMarchTime()

--     self:closeTile()
-- end

function StationTile:closeTile()
    self = tolua.cast(self, "NewBaseTileLuaInfo")
    
    self:call("closeThis")
end
