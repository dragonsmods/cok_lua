local CommercialMarchNode = class("CommercialMarchNode", cc.Layer)

local OriginSrc = -255
local AllDistance = 510
local StationDistance = 170

function CommercialMarchNode:create(parentSize, data)
    local node = CommercialMarchNode.new(data)
    Drequire("game.commercialDarts.CommercialMarchNode_ui"):create(node, 0, parentSize)
    if node:initNode() then return node end
end

function CommercialMarchNode:ctor(data)
    self.data = data
    self.maxColor = 0
    self.stationMap = {}
    self.ctrl = require("game.commercialDarts.CommercialController").getInstance()
end

function CommercialMarchNode:initNode()
    self:refreshNode()
    registerTouchHandler(self)
    self:setSwallowsTouches(false)

    return true
end

function CommercialMarchNode:refreshNode()
    self.reqData = false
    self:refreshPath()
    self:sortRefresh()
    self:refreshBtn()
    self:refreshMyCamel()
    self:refreshOtherCamel()
    self:refreshPrice()
    self:refreshLog()
    self:refreshItem()
end

function CommercialMarchNode:refreshBtn()
    if atoi(self.data.state) == DartsState.Rest then
        self.ui.m_refreshBtn:setEnabled(true)
        self.ui.m_continueBtn:setEnabled(true)
        self.ui.m_continueTime:setVisible(true)
        -- self.ui.m_continueBtn:setLabelAnchorPoint(ccp(0.5, 0.2))
        if GuideController:call("getCurrentId") == "41726006"
            or GuideController:call("getCurrentId") == "41726007" then
            GuideController:call("setGuide", "")
        end
    else
        self.ui.m_refreshBtn:setEnabled(false)
        self.ui.m_continueBtn:setEnabled(false)
        self.ui.m_continueTime:setVisible(false)
        -- self.ui.m_continueBtn:setLabelAnchorPoint(ccp(0.5, 0.5))
        if GuideController:call("getCurrentId") == "41726009" then
            GuideController:call("setGuide", "")
        end
    end

    --接镖页面引导在这里中断
    if GuideController:call("getCurrentId") == "41726004" 
        or GuideController:call("getCurrentId") == "41726005" then
        GuideController:call("setGuide", "")
    end

    if atoi(self.data.state) == DartsState.Receive then
        self.ui.m_jumpBtn:setVisible(false)
    end
end

function CommercialMarchNode:sortRefresh()
    if self.data.refresh then
        local function sort(c1, c2)
            local color1 = CCCommonUtilsForLua:call("getPropByIdGroup", "bodyguard_level", c1.configId, "color")
            local color2 = CCCommonUtilsForLua:call("getPropByIdGroup", "bodyguard_level", c2.configId, "color")
            return atoi(color2) < atoi(color1)
        end
        table.sort(self.data.refresh, sort)

        local rmIndex = 0
        for index, data in ipairs(self.data.refresh) do
            if atoi(data.prob) == 0 then
                rmIndex = index
                break
            end
        end
        table.remove(self.data.refresh, rmIndex)
    end
end

function CommercialMarchNode:refreshPath()
    local path = tonumber(self.data.path)
    if path then
        for index = 1, 4, 1 do
            if self.ui["m_proSp" .. index] then
                local romanSp = string.format("camel_roman%d_ui.png", path)
                local sf = CCLoadSprite:call("loadResource", romanSp)
                self.ui["m_proSp" .. index]:setSpriteFrame(sf)
                self.ui["m_proSp" .. index]:setScale(2)
                self.ui["m_proSp" .. index]:setTag(path)

                local stationX = self.ui["m_proSp" .. index]:getParent():getPositionX()
                self.stationMap[tostring(path)] = stationX

                path = path + 1
                if path > 4 then path = 1 end
            end
        end
    end
end

function CommercialMarchNode:refreshPrice()
    if atoi(self.data.state) == DartsState.Rest then
        local price = atoi(self.data.refreshCost)
        local rate = atoi(self.data.refreshRate)
        if rate > 0 then
            local cost = price * rate / 100
            self.ui.m_costText:setString(CC_CMDITOA(price))
            if price == cost then
                setLabelReduce(self.ui.m_costText, 0)
                self.ui.m_costCoinSp:setPositionX(18)
                self.ui.m_costText:setPositionX(55)
                self.ui.m_costText:setAnchorPoint(ccp(0.5, 0.5))
            else
                setLabelReduce(self.ui.m_costText, 1, CC_CMDITOA(cost), true)
            end
            self.ui.m_refreshBtn:setLabelAnchorPoint(ccp(0.5, 0.2))
            self.ui.m_costNode:setVisible(true)
            self.ui.m_freeNode:setVisible(false)
        else
            self.ui.m_refreshBtn:setLabelAnchorPoint(ccp(0.5, 0.5))
            self.ui.m_costNode:setVisible(false)
            self.ui.m_freeNode:setVisible(true)
        end
    else
        self.ui.m_freeNode:setVisible(false)
        self.ui.m_costNode:setVisible(false)
        self.ui.m_refreshBtn:setLabelAnchorPoint(ccp(0.5, 0.5))
    end
end

function CommercialMarchNode:refreshOtherCamel()
    local count = #self.data.refresh
    for index = 1, 4 do
        if index <= count then
            self.ui["m_cNode" .. index]:setVisible(true)

            local configId = self.data.refresh[index].configId
            local color = CCCommonUtilsForLua:call("getPropByIdGroup", "bodyguard_level", configId, "color")
            local path = string.format("cmr_color_%d.png", atoi(color))
            local sf = CCLoadSprite:call("loadResource", path)
            self.ui["m_propSp" .. index]:setSpriteFrame(sf)

            local bonus = CCCommonUtilsForLua:call("getPropByIdGroup", "bodyguard_level", configId, "extra_bonus")
            local bonusStr = string.format("%d%%", atoi(bonus) * 100)
            self.ui["m_growText" .. index]:setString(bonusStr)

            local star = CCCommonUtilsForLua:call("getPropByIdGroup", "bodyguard_level", configId, "star")
            local starNode = getStarNode(atoi(star), SCROLLVIEW_DIR_VERTICAL)
            starNode:setAnchorPoint(ccp(0, 0))
            starNode:setScale(0.4)
            self.ui["m_starNode" .. index]:removeAllChildren()
            self.ui["m_starNode" .. index]:addChild(starNode)

            local icon = CCCommonUtilsForLua:call("getPropByIdGroup", "bodyguard_level", configId, "icon")
            local camelPath = string.format("%s.png", icon)
            local sf = CCLoadSprite:call("loadResource", camelPath)
            self.ui["m_iconCamel" .. index]:setSpriteFrame(sf)

            local color = CCCommonUtilsForLua:call("getPropByIdGroup", "bodyguard_level", configId, "color")
            if atoi(color) > self.maxColor then
                self.maxColor = atoi(color)
            end
        else
            self.ui["m_cNode" .. index]:setVisible(false)
        end
    end
end

function CommercialMarchNode:refreshLuckAllReward()
    if self.data.is_lucky_time == "1" then
        local count = #self.data.refresh
        for index = 1, 4 do
            local luckyReward = self.data.refresh[index].luckyReward
            self:refreshLuckReward(index, luckyReward)
        end
    end
end

function CommercialMarchNode:refreshLuckReward(index, reward)
    local luckyNode = self.ui["m_luckyNode" .. index]
    if luckyNode then
        local rwd = GlobalData:call("getCachedRewardData", reward)
        local rwdData = arrayToLuaTable(rwd)

        local rwdCnt = #rwdData
        if rwdCnt == 0 then return end

        local rewardItems = {}
        for _, rwd in ipairs(rwdData) do
            if rwd.type == "7" then
                rwd.value.type = 0
                table.insert(rewardItems, rwd.value)
            elseif rwd.type == "14" then
                rwd.value.type = 1
                table.insert(rewardItems, rwd.value)
            end
        end
        
        luckyNode:removeAllChildren()

        local isPad = CCCommonUtilsForLua:isIosAndroidPad()
        local width = 0
        local itemWidth = 40
        for index, reward in ipairs(rewardItems) do
            local itemNode = cc.Node:create()
            local numBg = CCLoadSprite:createSprite("W_tongyongjianbian01.png")
            numBg:setColor(cc.c3b(0, 0, 0))
            numBg:setScale(0.6, 0.6)
            numBg:setFlipX(true)
            numBg:ignoreAnchorPointForPosition(true)
            numBg:setAnchorPoint(ccp(0, 0))
            numBg:setPosition(-itemWidth / 2, -itemWidth / 2)
            
            local numLabel = cc.Label:createWithSystemFont("", "Helvetica", 12, cc.size(0.0,0))
            numLabel:setAnchorPoint(ccp(1, 0))
            numLabel:setHorizontalAlignment(cc.TEXT_ALIGNMENT_RIGHT)
            numLabel:setPosition(itemWidth / 2, -itemWidth / 2)
            numLabel:ignoreAnchorPointForPosition(false)

            LibaoCommonFunc.createDataItemTouchNode(
                {
                    itemData = {
                                    type = reward.type,
                                    itemId = atoi(reward.id),
                                    num = atoi(reward.num),
                                    desScale = isPad and 1.8 or 1,
                                },
                    iconNode = itemNode,
                    iconSize = itemWidth - 4,
                    numLabel = numLabel,
                    beTouch = true,
                }
            )
            itemNode:setPosition((rwdCnt - index + 1) * itemWidth - 20, itemWidth / 2)
            itemNode:addChild(numBg)
            itemNode:addChild(numLabel)
            luckyNode:addChild(itemNode)
            width = width + itemWidth + 8
        end
    end
end

function CommercialMarchNode:addLuckParticle(node)
    if node then
        node:removeChildByTag(666)

        local parNode = cc.Node:create()
        parNode:setScale(0.5)
        parNode:setTag(666)
        node:addChild(parNode)

        for index = 0, 1 do
            local particle = ParticleController:call("createParticle", string.format("bag_%d", index))
            if particle then
                particle:setContentSize(cc.size(9999, 9999))
                parNode:addChild(particle)
            end
        end
    end
end

function CommercialMarchNode:refreshMyCamel()
    local x, y = self.ui.m_text7:getPosition()
    local size7 = self.ui.m_text7:getContentSize()
    self.ui.m_textNode7:setPositionX(x + size7.width + 18)
    self:onRewardGetback()

    if self.data.configId then
        local color = CCCommonUtilsForLua:call("getPropByIdGroup", "bodyguard_level", self.data.configId, "color")
        local path = string.format("cmr_color_%d.png", atoi(color))
        local icon = CCLoadSprite:createSprite(path)
        self.ui.m_textNode7:removeAllChildren()
        self.ui.m_textNode7:addChild(icon)
        CCCommonUtilsForLua:setSpriteMaxSize(icon, 40, true)

        local star = CCCommonUtilsForLua:call("getPropByIdGroup", "bodyguard_level", self.data.configId, "star")
        local starNode = getStarNode(atoi(star), SCROLLVIEW_DIR_HORIZONTAL)
        starNode:setAnchorPoint(ccp(0, 0))
        starNode:setScale(0.4)
        self.ui.m_starNode:removeAllChildren()
        self.ui.m_starNode:addChild(starNode)

        local starX = x + size7.width + 38
        self.ui.m_starNode:setPositionX(starX)

        local icon = CCCommonUtilsForLua:call("getPropByIdGroup", "bodyguard_level", self.data.configId, "icon")
        local camelPath = string.format("%s.png", icon)
        local sf = CCLoadSprite:call("loadResource", camelPath)
        self.ui.m_iconCamel:setSpriteFrame(sf)

        self.ui.m_itemNode:setPositionX(starX + atoi(star) * 20 + 25)
    end

    local prayRate = string.format("%d%%", atoi(self.data.prayRate) / 100)
    self.ui.m_text4:setString(prayRate)
    self.ui.m_text5:setString(self.data.prayTimes)

    if self.data.tmpPointId then
        local sf = CCLoadSprite:call("loadResource", "camel_stop.png")
        self.ui.m_dartsIcon:setSpriteFrame(sf)
    else
        local function createFrameAni(format, frameCount)
            local frameTable = {}
            for index = 1, frameCount do
                local frameName = string.format(format, index)
                table.insert(frameTable, CCLoadSprite:loadResource(frameName))
            end
            local delay = 1 / frameCount
            local frameAnimation = cc.Animation:createWithSpriteFrames(frameTable, delay)
            local frameAnimate = cc.Animate:create(frameAnimation)
            local frameRepeat = cc.RepeatForever:create(frameAnimate)
            return frameRepeat
        end

        local ani = createFrameAni("camel_frame_%d.png", 2)
        self.ui.m_dartsIcon:stopAllActions()
        self.ui.m_dartsIcon:runAction(ani)
    end
end

function CommercialMarchNode:refreshColor(param)
    local data = dictToLuaTable(param)
    local configId = data.configId
    local rewardId = data.rewardId
    self.data.refreshCost = atoi(data.refreshCost)
    self.data.refreshRate = atoi(data.refreshRate)
    self:refreshPrice()
    self:playRandomAni(configId)
end

function CommercialMarchNode:playRandomAni(configId)
    local pos = 1
    for index, camel in ipairs(self.data.refresh) do
        if camel.configId == configId then
            pos = index
            break
        end
    end

    local count = #self.data.refresh
    local times = 3
    local path = {}
    for index = 1, times do
        for jndex = 1, 4 do
            if jndex <= count then
                local x = self.ui["m_cNode" .. jndex]:getPositionX()
                table.insert(path, x)
                if index == times and jndex == pos then
                    break
                end
            end
        end
    end

    local function saveRefresh() self.ctrl:saveRefresh() end
    local function callback()
        self:refreshBtn()
        local beforeColor = CCCommonUtilsForLua:call("getPropByIdGroup", "bodyguard_level", self.data.configId, "color")
        local afterColor = CCCommonUtilsForLua:call("getPropByIdGroup", "bodyguard_level", configId, "color")

        if atoi(afterColor) > atoi(beforeColor) then
            local dialog = YesNoDialog:call("showYesNoFun", getLang("41576066"), cc.CallFunc:create(saveRefresh), getLang("115035"), nil, getLang("cancel_btn_label"))
            dialog:call("setEnforceShow", true)
        else
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("41576067"))
        end
    end

    local delayTime = cc.DelayTime:create(0.1)
    local index = 1
    local pathCount = #path
    local function move() 
        self.ui.m_selectSp:setPositionX(path[index])
        index = index + 1
        if index > pathCount then
            self.ui.m_selectSp:stopAllActions()
            callback()
        end
    end
    local callFunc = cc.CallFunc:create(move) 
    local seq = cc.Sequence:create(delayTime, callFunc)
    local forerver = cc.RepeatForever:create(seq)
    self.ui.m_selectSp:setVisible(true)
    self.ui.m_selectSp:stopAllActions()
    self.ui.m_selectSp:runAction(forerver)
end

function CommercialMarchNode:saveRefresh(param)
    local data = dictToLuaTable(param)
    self.data.configId = data.configId
    self.data.rewardId = data.rewardId
    self.data.luckyReward = data.luckyReward
    self:refreshMyCamel()
    self.data.refreshCost = atoi(data.refreshCost)
    self.data.refreshRate = atoi(data.refreshRate)
    self:refreshPrice()

    if data.operation then
        self.data.operations = self.data.operations or {}
        table.insert(self.data.operations, 1, data.operation)
        self:refreshLog()
    end
end

function CommercialMarchNode:improve(param)
    local data = dictToLuaTable(param)
    self.data.configId = data.configId
    self.data.rewardId = data.rewardId
    self.data.luckyReward = data.luckyReward
    self:refreshMyCamel()
end

function CommercialMarchNode:onRewardGetback()
    local rwd = GlobalData:call("getCachedRewardData", self.data.rewardId)
    local rwdData = arrayToLuaTable(rwd)

    local rwdCnt = #rwdData
    if rwdCnt == 0 then return end

    local baseRate = atoi(self.data.baseRate) / 100
    local rewardItems = {}
    for _, rwd in ipairs(rwdData) do
        if rwd.type == "7" then
            rwd.value.type = 0
            rwd.value.num = math.floor(atoi(rwd.value.num) * baseRate)
            table.insert(rewardItems, rwd.value)
        elseif rwd.type == "14" then
            rwd.value.type = 1
            table.insert(rewardItems, rwd.value)
        end
    end

    if self.data.luckyReward then
        local lrwd = GlobalData:call("getCachedRewardData", self.data.luckyReward)
        local lrwdData = arrayToLuaTable(lrwd)
        for _, rwd in ipairs(lrwdData) do
            if rwd.type == "7" then
                rwd.value.type = 0
                rwd.value.spe = 1
                table.insert(rewardItems, rwd.value)
            elseif rwd.type == "14" then
                rwd.value.type = 1
                rwd.value.spe = 1
                table.insert(rewardItems, rwd.value)
            end
        end
    end
    rwdCnt = #rewardItems

    self.ui.m_textNode8:removeAllChildren()

    local isPad = CCCommonUtilsForLua:isIosAndroidPad()
    local width = 0
    local itemWidth = 40
    for index, reward in ipairs(rewardItems) do
        local itemNode = cc.Node:create()
        self.ui.m_textNode8:addChild(itemNode)

        local numBg = CCLoadSprite:createSprite("W_tongyongjianbian01.png")
        numBg:setColor(cc.c3b(0, 0, 0))
        numBg:setScale(0.6, 0.6)
        numBg:ignoreAnchorPointForPosition(true)
        numBg:setAnchorPoint(ccp(0, 0))
        numBg:setPosition(-itemWidth / 2, -itemWidth / 2)
        
        local numLabel = cc.Label:createWithSystemFont("", "Helvetica", 12, cc.size(0.0,0))
        numLabel:setAnchorPoint(ccp(1, 0))
        numLabel:setHorizontalAlignment(cc.TEXT_ALIGNMENT_RIGHT)
        numLabel:setPosition(itemWidth / 2, -itemWidth / 2)
        numLabel:ignoreAnchorPointForPosition(false)

        LibaoCommonFunc.createDataItemTouchNode(
            {
                itemData = {
                                type = reward.type,
                                itemId = atoi(reward.id),
                                num = atoi(reward.num),
                                desScale = isPad and 1.8 or 1,
                            },
                iconNode = itemNode,
                iconSize = itemWidth - 4,
                numLabel = numLabel,
                beTouch = true,
            }
        )
        itemNode:setPosition((rwdCnt - index + 1) * itemWidth * -1, itemWidth / 2)
        itemNode:addChild(numBg)
        itemNode:addChild(numLabel)
        
        width = width + itemWidth + 8

        if reward.spe == 1 then
            self:addLuckParticle(itemNode)
        end
    end

    self.ui.m_text8:setPositionX(555 - width + itemWidth)
    self:refreshLuckAllReward()
end

function CommercialMarchNode:refreshLog()
    if self.data.operations then
        self.ui.m_dialogNode:removeAllChildren()

        local size = self.ui.m_dialogNode:getContentSize()
        local contentNode = cc.Node:create()

        local count = #self.data.operations
        local height = 0
        for index = count, 1, - 1 do
            local info = self.data.operations[index]
            local hms = CCCommonUtilsForLua:call("timeStampToHMS", atoi(info.time) / 1000)
            local str = getLang(info.dialogId, hms, unpack(info.params))
            local log = cc.Label:createWithSystemFont(str, "Helvetica", 18, cc.size(size.width - 20, 0))
            log:setAnchorPoint(ccp(0, 0))
            log:setHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
            log:setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_BOTTOM)
            log:setPosition(10, height)
            log:setColor(cc.c3b(132, 233, 170))
            contentNode:addChild(log)
            height = height + log:getContentSize().height
        end

        local scrollView = cc.ScrollView:create()
	    scrollView:setViewSize(size)
	    scrollView:setPosition(cc.p(0,0))
	    scrollView:setScale(1.0)
	    scrollView:ignoreAnchorPointForPosition(true)
	    scrollView:setDirection(1)
	    scrollView:setClippingToBounds(true)
	    scrollView:setBounceable(true)
        scrollView:addChild(contentNode)
	    self.ui.m_dialogNode:addChild(scrollView)
	    
	    if height <= size.height then
	        scrollView:setTouchEnabled(false)
	    end
	    scrollView:setContentSize(CCSize(size.width, height))
	    scrollView:setContentOffset(ccp(0, size.height - height))
    end
end

local function sort(item1, item2)
    local tInfo1 = ToolController:call("getToolInfoForLua", atoi(item1))
    local tInfo2 = ToolController:call("getToolInfoForLua", atoi(item2))
    if tInfo1 and tInfo2 then
        local cnt1 = tInfo1:call("getCNT")
        local cnt2 = tInfo2:call("getCNT")

        if cnt2 == 0 and cnt1 > 0 then
            return true
        else
            return false
        end
    else
        return false
    end
end

function CommercialMarchNode:refreshItem()
    local item = CCCommonUtilsForLua:call("getPropByIdGroup","data_config","commercial","k5")
    self.itemData = splitString(item, ";") or {}
    table.sort(self.itemData, sort)

    local showAni = false
    for _, itemId in ipairs(self.itemData) do
        local tInfo = ToolController:call("getToolInfoForLua", atoi(itemId))
        if tInfo and tInfo:call("getCNT") then
            showAni = true
            break
        end
    end

    if showAni then
        local scale_to = cc.ScaleTo:create(0.5, 0.6, 0.6)
        local scale_back = cc.ScaleTo:create(0.5, 0.5, 0.5)
        local seq = cc.Sequence:create(scale_to ,scale_back)
        local forerver = cc.RepeatForever:create(seq)
        self.ui.m_itemSp:stopAllActions()
        self.ui.m_itemSp:runAction(forerver)
    end
end

function CommercialMarchNode:onEnterFrame(dt)
    if self.reqData then return end
    
    if atoi(self.data.state) == DartsState.Receive then
        self.ui.m_dartsIcon:setVisible(false)
        self.ui.m_text1:setString(getLang("41576146"))
    end

    if self.data.endTime or self.data.obtainEndTime then
        local showDialog = "41576016"
        if atoi(self.data.state) == DartsState.Attack then
            showDialog = "41576053"
        elseif atoi(self.data.state) == DartsState.Transfer then
            showDialog = "41576075"
        elseif atoi(self.data.state) == DartsState.Repair then
            showDialog = "41576054"
        end

        local now = WorldController:call("getTime")
        local endTime = self.data.obtainEndTime and self.data.obtainEndTime or self.data.endTime
        local remain = math.floor((atoi(endTime) - now) / 1000)
        if remain > 0 then
            self.ui.m_text1:setString(getLang(showDialog, format_time(remain)))
            self.ui.m_continueTime:setString(getLang("41576168", format_time(remain)))
        else
            self.reqData = true
            self.ui.m_text1:setString(getLang(showDialog, format_time(0)))
            self.ui.m_continueTime:setString(getLang("41576168", format_time(0)))
            self.ctrl:reqMineData()
        end

        if atoi(self.data.state) == DartsState.Attack then
            self.ui.m_text1:setColor(cc.c3b(255, 35, 35))
        else
            self.ui.m_text1:setColor(cc.c3b(132, 233, 170))
        end

        local src = self.data.startStation
        local dst = self.data.targetStation
        if atoi(self.data.state) == DartsState.Rest then
            local stationX = self.stationMap[src]
            local move = stationX - OriginSrc
            local percent = move / AllDistance
            percent = math.max(percent, 0)
            percent = math.min(percent, 1)
            self.ui.m_progressBar:setScaleX(percent)
            self.ui.m_dartsIcon:setPositionX(stationX)

            local name = getLang(StationName[atoi(src)])
            self.ui.m_text1:setString(getLang("41576076", name)) 
        else
            local stationX = self.stationMap[src]
            local time = now
            if self.data.obtainStartTime then 
                time = atoi(self.data.obtainStartTime)
            end
            local pass = time - atoi(self.data.startTime) - atoi(self.data.stopTime)
            local per = pass / atoi(self.data.totalTime)
            per = math.max(per, 0)
            per = math.min(per, 1)
            local nowX = stationX + per * StationDistance
            local move = nowX - OriginSrc
            local percent = move / AllDistance
            percent = math.max(percent, 0)
            percent = math.min(percent, 1)
            self.ui.m_progressBar:setScaleX(percent)
            self.ui.m_dartsIcon:setPositionX(nowX)
        end
        self.ui.m_dartsIcon:setVisible(true)
    end
end

function CommercialMarchNode:onEnter()
    self:onEnterFrame(0)
    local function update(dt) self:onEnterFrame(dt) end
    self.entry = self:getScheduler():scheduleScriptFunc(update, 1, false)
    registerScriptObserver(self, self.refreshColor, "COMMERCIAL_REFRESH")
    registerScriptObserver(self, self.saveRefresh, "COMMERCIAL_SAVEREFRESH")
    registerScriptObserver(self, self.onRewardGetback, "MSG_GET_REWARD_DETAIL_BACK")
    registerScriptObserver(self, self.improve, "msg.escort.improve")
end

function CommercialMarchNode:onExit()
    self:getScheduler():unscheduleScriptEntry(self.entry)
    unregisterScriptObserver(self, "COMMERCIAL_REFRESH")
    unregisterScriptObserver(self, "COMMERCIAL_SAVEREFRESH")
    unregisterScriptObserver(self, "MSG_GET_REWARD_DETAIL_BACK")
    unregisterScriptObserver(self, "msg.escort.improve")
end

function CommercialMarchNode:onClickJump()
    if self.data.tmpPointId then
        local currentSceneId = SceneController:call("getCurrentSceneId")
        WorldController:call("getInstance"):setProperty("openTargetIndex", atoi(self.data.tmpPointId))
        if currentSceneId == SCENE_ID_WORLD then
            PopupViewController:call("removeAllPopupView")
            local point = WorldController:call("getPointByIndex", atoi(self.data.tmpPointId))
            WorldMapView:call("gotoTilePoint", point)
        else
            SceneController:call("gotoScene", SCENE_ID_WORLD, false, true, atoi(self.data.tmpPointId))
        end
    else
        self.ctrl:jumpCamel(self.data.uuid)
    end
end

function CommercialMarchNode:onClickPray()
    if atoi(self.data.state) == DartsState.Receive then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("41576069"))
    else
        if atoi(self.data.prayMax) > atoi(self.data.prayTimes) then
            self.ctrl:notifyChatShare(self.data.uuid, "CommercialChatPray", "41576046", self.data.prayTimes)
        else
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("41576126"))
        end
    end
end

function CommercialMarchNode:onClickMayday()
    if atoi(self.data.state) == DartsState.Attack then
        local occupier = ""
        if self.data.obtainInfo then
            occupier = self.data.obtainInfo.name
            local abbr = self.data.obtainInfo.abbr
            if abbr and abbr ~= "" then
                occupier = string.join("", "(", abbr, ") ", occupier)
            end
        end
        self.ctrl:notifyChatShare(self.data.uuid, "CommercialChatHelp", "41576226", occupier)
    else
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("41576068"))
    end
end

function CommercialMarchNode:onClickRefresh()
    local secondConfirm = false
    if GuideController:call("isInTutorial") then
        secondConfirm = false
        FunBuildController:call("SendRecordeToServer", "commercial_refresh")
        CCSafeNotificationCenter:call("postNotification", GUIDE_INDEX_CHANGE, CCString:create("commercial_refresh"))
    end

    local color = CCCommonUtilsForLua:call("getPropByIdGroup", "bodyguard_level", self.data.configId, "color")
    if atoi(color) >= self.maxColor then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("41576121"))
        return
    end

    local price = atoi(self.data.refreshCost)
    local rate = atoi(self.data.refreshRate) 
    local cost = price * rate / 100
    if cost > GlobalData:call("getPlayerInfo"):getProperty("gold") then
        YesNoDialog:call("gotoPayTips")
        return
    end

    local setKey = "CommercialTip" .. self.data.startStation
    if cost > 0 then
        secondConfirm = cc.UserDefault:getInstance():getBoolForKey(setKey, true)
    end

    local function confirm()
        if self.data.configId then
            self.ctrl:refreshCamel(self.data.configId)
            self.ui.m_refreshBtn:setEnabled(false)
            -- if cost > 0 then
            --     cc.UserDefault:getInstance():setBoolForKey(setKey, false)
            --     cc.UserDefault:getInstance():flush()
            -- end
        end
    end

    if secondConfirm then
        local params = {}
        params.callback = confirm
        params.title = getLang("41576174", CC_CMDITOA(cost))
        params.desc = getLang("41576246")
        params.gold = cost
        params.setKey = setKey
        -- YesNoDialog:show(getLang("41576174", tostring(cost)), confirm)
        local view = Drequire("game.CommonPopup.CommonSetTipView"):create(params)
        PopupViewController:addPopupView(view)
    else
        confirm()
    end
end

function CommercialMarchNode:onClickContinue()
    if self.data.uuid then
        self.ctrl:continueCamel(self.data.uuid)
        self.ctrl:jumpCamel(self.data.uuid)
    end
end

function CommercialMarchNode:getGuideNode(key)
    if key == "commercial_help" then
        return self.ui.m_maydayBtn
    elseif key == "commercial_bless" then
        return self.ui.m_prayBtn
    elseif key == "commercial_refresh" then
        return self.ui.m_refreshBtn
    end
end

function CommercialMarchNode:onTouchBegan(x, y)
    self.touchPoint = ccp(x, y)
    self.clickStation = 0
    self.clickItem = 0
    self.clickDarts = 0

    if isTouchInsideVis(self.ui.m_dartsIcon, x, y) then    
        self.clickDarts = 1
        return true
    end

    for index = 1, 4, 1 do
        if isTouchInsideVis(self.ui["m_proSp" .. index], x, y) then
            self.clickStation = self.ui["m_proSp" .. index]:getTag()
            return true
        end
    end

    if isTouchInsideVis(self.ui.m_itemSp, x, y) then
        self.clickItem = 1
        return true
    end

    if isTouchInsideVis(self.ui.m_listBg, x, y) then
        return false
    end

    return true 
end

function CommercialMarchNode:onTouchEnded(x, y)
    if ccpDistance(self.touchPoint, ccp(x, y)) > 10 then return end

    if self.clickItem > 0 then
        self:showItem()
    elseif self.clickStation > 0 then
        self:jumpStation(self.clickStation)
    elseif self.clickDarts > 0 then
        self:onClickJump()
    else
        self:hideItem()
    end
end

function CommercialMarchNode:showItem()
    self.ui.m_listBg:setVisible(true)
    self.ui.m_listView:setVisible(true)
    self.ui:setTableViewDataSource("m_listView", self.itemData)
end

function CommercialMarchNode:hideItem()
    self.ui.m_listBg:setVisible(false)
    self.ui.m_listView:setVisible(false)
end

function CommercialMarchNode:jumpStation(station)
    local point = self.ctrl:getStationPoint(atoi(station))
    if point then
        local currentSceneId = SceneController:call("getCurrentSceneId")
        WorldController:call("getInstance"):setProperty("openTargetIndex", point)
        if currentSceneId == SCENE_ID_WORLD then
            PopupViewController:call("removeAllPopupView")
            local mpoint = WorldController:call("getPointByIndex", point)
            WorldMapView:call("gotoTilePoint", mpoint)
        else
            SceneController:call("gotoScene", SCENE_ID_WORLD, false, true, point)
        end
    end
end

function CommercialMarchNode:onClickInfo()
    local view = Drequire("game.FestivalActivities.FestivalActivitiesExplainView"):create(getLang("41576193"))
    PopupViewController:call("addPopupView", view)
end

return CommercialMarchNode