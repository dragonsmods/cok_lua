local NormalQueueModel = class("NormalQueueModel", Drequire("game.commercialDarts.model.BaseQueueModel"))

function NormalQueueModel:parse(data)
    if data.uuid then
        self.uuid = data.uuid
    end
    
    --地图用
    if self.marchTag == 0 then
        self.marchTag = WorldController:call("getMarchTag")
    end

    --队列用
    if self.marchQid == 0 then
        self.marchQid = QueueController:call("getQID", QueueType.TYPE_MARCH) + self.marchTag
    end

    if data.startPoint then
        self.startPoint.x = atoi(data.startPoint.x)
        self.startPoint.y = atoi(data.startPoint.y)
    end

    if data.endPoint then
        self.endPoint.x = atoi(data.endPoint.x)
        self.endPoint.y = atoi(data.endPoint.y)
    end

    if data.startTime then 
        self.startTime = atoi(data.startTime) 
    end

    if data.endTime then
        self.endTime = atoi(data.endTime)
    end

    if data.marchType then self.marchType = atoi(data.marchType) end
    if data.ownerInfo then self.ownerInfo = data.ownerInfo end

    if data.attSkin then self.attSkin = atoi(data.attSkin) end
    if data.marchSkin then self.marchSkin = atoi(data.marchSkin) end

    if data.army then self.marchArmy = data.army end
    if data.dragonList then self.marchDragon = data.dragonList end
    if data.generalList then self.marchHero = data.generalList end
end

function NormalQueueModel:update(now, dt, followMarchId)
    local addFlag = false
    local timeLeft = self.endTime - now
    local t = 1 - timeLeft / (self.endTime - self.startTime)
    t = math.min(t, 1)
    t = math.max(t, 0)

    if not self.startPointMap and not self.endPointMap then
        self.startPointMap = WorldController:call("getViewPointByTilePoint", ccp(self.startPoint.x, self.startPoint.y))
        self.endPointMap = WorldController:call("getViewPointByTilePoint", ccp(self.endPoint.x, self.endPoint.y))
    end

    local marchLine = WorldMapView:call("getMarchLineByTag", self.marchTag)
    if not marchLine then 
        marchLine = self:createMarchLine() 
        addFlag = true
    end

    local marchNode = WorldMapView:call("getMarchNodeByTag", self.marchTag)
    if not marchNode then
        marchNode = self:createMarchNode()
        local xMove = (self.endPointMap.x - self.startPointMap.x) * t
        local yMove = (self.endPointMap.y - self.startPointMap.y) * t
        local posX = self.startPointMap.x + xMove
        local posY = self.startPointMap.y + yMove
        marchNode:setPosition(posX, posY)
        addFlag = true
    else
        if timeLeft > 0 then
            local x, y = marchNode:getPosition()
            local xSpeed = (self.endPointMap.x - x) / timeLeft
            local ySpeed = (self.endPointMap.y - y) / timeLeft
            local nx = x + xSpeed * dt * 1000
            local ny = y + ySpeed * dt * 1000
            marchNode:setPosition(nx, ny)
        end
    end

    if self.uuid == followMarchId then self:jumpToTarget(marchNode) end

    return addFlag
end

return NormalQueueModel