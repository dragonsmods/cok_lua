----------------------------
-- Author: Elex
-- Date: 2020-03-16 Monday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CommercialItemCell_ui = class("CommercialItemCell_ui")

--#ui propertys


--#function
function CommercialItemCell_ui:create(owner, viewType, paramTable)
	local ret = CommercialItemCell_ui.new()
	CustomUtility:LoadUi("CommercialItemCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CommercialItemCell_ui:initLang()
	ButtonSmoker:setText(self.m_useBtn, "108590")
end

function CommercialItemCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CommercialItemCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CommercialItemCell_ui:onUseBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onUseBtnClick", pSender, event)
end

return CommercialItemCell_ui

