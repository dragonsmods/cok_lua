----------------------------
-- Author: Elex
-- Date: 2020-04-02 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local AllServerNode_ui = class("AllServerNode_ui")

--#ui propertys


--#function
function AllServerNode_ui:create(owner, viewType, paramTable)
	local ret = AllServerNode_ui.new()
	CustomUtility:LoadUi("CommercialAllServerNode.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function AllServerNode_ui:initLang()
	ButtonSmoker:setText(self.m_serverBtn, "41576312")
	ButtonSmoker:setText(self.m_allianceBtn, "41576313")
	ButtonSmoker:setText(self.m_playerBtn, "41576314")
end

function AllServerNode_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function AllServerNode_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function AllServerNode_ui:onClickServer(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickServer", pSender, event)
end

function AllServerNode_ui:onClickAlliance(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickAlliance", pSender, event)
end

function AllServerNode_ui:onClickPlayer(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickPlayer", pSender, event)
end

return AllServerNode_ui

