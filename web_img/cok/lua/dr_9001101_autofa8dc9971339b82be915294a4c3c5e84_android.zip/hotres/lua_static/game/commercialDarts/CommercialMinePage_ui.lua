----------------------------
-- Author: Elex
-- Date: 2020-02-13 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local CommercialMinePage_ui = class("CommercialMinePage_ui")

--#ui propertys


--#function
function CommercialMinePage_ui:create(owner, viewType, paramTable)
	local ret = CommercialMinePage_ui.new()
	CustomUtility:DoRes(6, true)
	CustomUtility:DoRes(0, true)
	CustomUtility:LoadUi("CommercialMinePage.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function CommercialMinePage_ui:initLang()
	LabelSmoker:setText(self.m_titleText, "41576005")
	LabelSmoker:setText(self.m_text1, "41576006")
	LabelSmoker:setText(self.m_text5, "41576015")
	LabelSmoker:setText(self.m_pLabelTTF90, "41576114")
	LabelSmoker:setText(self.m_bookName, "41576114")
end

function CommercialMinePage_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function CommercialMinePage_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function CommercialMinePage_ui:onClickInfo(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickInfo", pSender, event)
end

function CommercialMinePage_ui:onClickInfo(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickInfo", pSender, event)
end

function CommercialMinePage_ui:onClickStore(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickStore", pSender, event)
end

function CommercialMinePage_ui:onClickBook(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBook", pSender, event)
end

return CommercialMinePage_ui

