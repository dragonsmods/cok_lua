local CommercialMinePage = class("CommercialMinePage", cc.Layer)

function CommercialMinePage:create(parentSize)
    local page = CommercialMinePage.new()
    Drequire("game.commercialDarts.CommercialMinePage_ui"):create(page, 0, parentSize)
    if page:initPage() then return page end
end

function CommercialMinePage:ctor()
    self.ctrl = require("game.commercialDarts.CommercialController").getInstance()
end

function CommercialMinePage:initPage()
    self.ctrl:reqMineData()

    self:initBook()
    self.descNode = CommonItemDescNode:call("create", "", "", false)
    self.descNode:setVisible(false)
    self:addChild(self.descNode)
    
    registerTouchHandler(self)
    return true
end

function CommercialMinePage:initBook()
    local isOpen = require("game.activity.KingBiography.KingBiographyController").isOpen()
    if isOpen then
        self.ui.m_bookBtn:setVisible(true)
        self.ui.m_bookName:setVisible(true)
        self.ui.m_bookName:setString(getLang("10010031"))
        CCCommonUtilsForLua:call("setButtonSprite", self.ui.m_bookBtn, "Icon_biography_mainUI.png")
    else
        self.ui.m_bookBtn:setVisible(false)
        self.ui.m_bookName:setVisible(false)
    end
end

function CommercialMinePage:continue()
    --继续运镖刷新页面
    self.ctrl:reqMineData()
end

function CommercialMinePage:refreshPage(dict)
    local parentSize = self.ui.m_listNode:getContentSize()
    
    local data = dictToLuaTable(dict)
    self:getAllReward(data)
    self:refreshMorale(data)

    if atoi(data.state) == DartsState.Null then
        self.ui.m_listNode:removeAllChildren()
        self.selectNode = Drequire("game.commercialDarts.CommercialSelectNode"):create(parentSize, data.receive, data.remainTimes)
        self.ui.m_listNode:addChild(self.selectNode)
    else
        if self.marchNode then
            self.marchNode.data = data
            self.marchNode:refreshNode()
        else
            self.marchNode = Drequire("game.commercialDarts.CommercialMarchNode"):create(parentSize, data)
            self.ui.m_listNode:addChild(self.marchNode)
        end
    end

    local path = self.ctrl:getPath(atoi(data.path))

    local rich2 = utils.getLinkTextStr(getLang("41576006"), path, 18, "978461FF", "ECDCAAFF")
    replaceRichText(self.ui.m_text2, rich2, 666)
    local rich3 = utils.getLinkTextStr(getLang("41576007"), data.remainTimes, 18, "978461FF", "ECDCAAFF") 
    replaceRichText(self.ui.m_text3, rich3, 888)

    local now = getTimeStamp()
    if data.speStartTime and data.speEndTime and self.ctrl.speEndTime < now then
        self.ctrl.speStartTime = atoi(data.speStartTime) / 1000
        self.ctrl.speEndTime = atoi(data.speEndTime) / 1000
    end

    self:onEnterFrame()
end

function CommercialMinePage:onEnterFrame(dt)
    local actObj = ActivityController:call("getActObj", "57473")
    if actObj then
        local tickStr = actObj:call("getGameTickStr")
        self.ui.m_timeText:setString(tickStr)
    else
        self.ui.m_timeText:setVisible(false)
    end

    local now = getTimeStamp()
    if self.ctrl.speStartTime < now and now < self.ctrl.speEndTime then
        local remain = self.ctrl.speEndTime - now
        local rich = utils.getLinkTextStr(getLang("41576232"), format_time(remain), 18, "978461FF", "ECDCAAFF")
        -- self.ui.m_text4:setString(getLang("41576189"))
        replaceRichText(self.ui.m_text4, rich, 1688)
    elseif now < self.ctrl.speStartTime then
        local remain = self.ctrl.speStartTime - now
        local rich = utils.getLinkTextStr(getLang("41576233"), format_time(remain), 18, "978461FF", "ECDCAAFF")
        -- self.ui.m_text4:setString(getLang("41576190"))
        replaceRichText(self.ui.m_text4, rich, 1688)
    else
        replaceRichText(self.ui.m_text4, "", 1688)
    end
end

function CommercialMinePage:getAllReward(data)
    local rewardT = {}
    if data.rewardId and data.rewardId ~= "" then
        table.insert(rewardT, data.rewardId)
    end

    if data.luckyReward and data.luckyReward ~= "" then
        table.insert(rewardT, data.luckyReward)
    end

    for _, one in ipairs(data.receive or {}) do
        if one.rewardId then
            table.insert(rewardT, one.rewardId)
        end
    end

    for _, one in ipairs(data.refresh or {}) do
        if one.rewardId then
            table.insert(rewardT, one.rewardId)
        end
        if one.luckyReward then
            table.insert(rewardT, one.luckyReward)
        end
    end

    GlobalData:call("requestMultiRewardData", rewardT)
end

--士气解锁
function CommercialMinePage:refreshMorale(data)
    if data.unlock_moral and data.unlock_moral.conditions
        and data.unlock_moral.conditions[1] then
        local now = atoi(data.unlock_moral.conditions[1].now)
        local need = atoi(data.unlock_moral.conditions[1].need)

        self.ui.m_moraleSp:setVisible(true)
        if now < need then
            CCCommonUtilsForLua:call("setSpriteHGray", self.ui.m_moraleSp, true)
            self.ui.m_moraleLockSp:setVisible(true)
            self.ui.m_moraleText:setString(getLang("41576138", tostring(now), tostring(need)))
        else
            CCCommonUtilsForLua:call("setSpriteHGray", self.ui.m_moraleSp, false)
            self.ui.m_moraleLockSp:setVisible(false)
            self.ui.m_moraleText:setString(getLang("41576140", tostring(now), tostring(need)))
        end
    else
        self.ui.m_moraleSp:setVisible(false)
        self.ui.m_moraleLockSp:setVisible(false)
    end
end

function CommercialMinePage:onEnter()
    self:onEnterFrame(0)
    local function update(dt) self:onEnterFrame(dt) end
    self.entry = self:getScheduler():scheduleScriptFunc(update, 1, false)
    registerScriptObserver(self, self.continue, "COMMERCIAL_CONTINUE")
    registerScriptObserver(self, self.refreshPage, "COMMERCIAL_MINE_PAGE")
end

function CommercialMinePage:onExit()
    self:getScheduler():unscheduleScriptEntry(self.entry)
    unregisterScriptObserver(self, "COMMERCIAL_CONTINUE")
    unregisterScriptObserver(self, "COMMERCIAL_MINE_PAGE")
end

function CommercialMinePage:onTouchBegan(x, y)
    if isTouchInsideVis(self.ui.m_moraleSp, x, y) then
        self.descNode:call("setItemNameAndContent", getLang("41576142"), getLang("41576139"))
        self.descNode:setVisible(true)
        local x, y = self.ui.m_moraleSp:getPosition()
        self.descNode:setPosition(x - 218, y)
        self.touchPoint = ccp(x, y)
        return true
    end
end

function CommercialMinePage:onTouchMoved(x, y)
    if ccpDistance(self.touchPoint, ccp(x, y)) > 10 then return end
    self.descNode:setVisible(false)
end

function CommercialMinePage:onTouchEnded(x, y)
    self.descNode:setVisible(false)
end

function CommercialMinePage:getGuideNode(key)
    if key == "commercial_pick" then
        if self.selectNode then
            return self.selectNode:getGuideNode(key)
        end
    else
        if self.marchNode then
            return self.marchNode:getGuideNode(key)
        end
    end
end

function CommercialMinePage:onClickStore()
    local view = Drequire("game.commercialDarts.CommercialStoreView"):create()
    PopupViewController:addPopupInView(view)
end

function CommercialMinePage:onClickBook()
    local view = Drequire("game.activity.KingBiography.KingBiographyBookView"):create(5)
    if view then
        PopupViewController:call("addPopupInView", view)
    end
end

function CommercialMinePage:onClickInfo()
    local view = Drequire("game.FestivalActivities.FestivalActivitiesExplainView"):create(getLang("41576231"))
    PopupViewController:call("addPopupView", view)
end

return CommercialMinePage
