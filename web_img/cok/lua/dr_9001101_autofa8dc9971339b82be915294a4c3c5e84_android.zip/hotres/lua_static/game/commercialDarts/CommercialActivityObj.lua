local CommercialActivityObj = class("CommercialActivityObj", function (	)
	return ActivityEventObjForLua:call("create")
end)

function CommercialActivityObj.create( params )
	local ret = CommercialActivityObj.new()
	if ret:init(params) == false then
		ret = nil
	end
	return ret
end

-- 可重载
function CommercialActivityObj:parse( params )
	ActivityEventObjForLua.parse(self, params)
end

function CommercialActivityObj:getCurActivityStageAndLeftTime( )
    return self:getNormalCurActivityStageAndLeftTime()
end

function CommercialActivityObj:getGameTickStr()
    self.ctrl = require("game.commercialDarts.CommercialController").getInstance()
    local speStartTime = self.ctrl.speStartTime
    local speEndTime = self.ctrl.speEndTime
    local startTime = atoi(self:getProperty("startTime"))
    local endTime = atoi(self:getProperty("endTime"))

    local now = getTimeStamp()
    local nowZone = getWorldTime()
    local remain = 0
    local showDialog = "41576001"
    if speStartTime <= now and now < speEndTime then
        showDialog = "41576002"
        remain = speEndTime - now
    elseif startTime < nowZone and nowZone < endTime then
        remain = endTime - nowZone
    end

    if remain > 0 then
        return getLang(showDialog, format_time(remain))
    else
        return self:getNormalGameTickStr()
    end
end

function CommercialActivityObj:requestActivityDetail( )
    
end

return CommercialActivityObj