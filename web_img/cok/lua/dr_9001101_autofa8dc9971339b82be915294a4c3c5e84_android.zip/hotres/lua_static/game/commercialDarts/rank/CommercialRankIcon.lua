local superClass = require("game.CommonPopup.UiCompoentIcon")
local CommercialRankIcon = class("CommercialRankIcon",superClass)

function CommercialRankIcon.create(iconSize, contentSize)
    local view = CommercialRankIcon.new()
    if view:initView(iconSize, contentSize) then
        return view
    end
end

function CommercialRankIcon:ctor()

end

function CommercialRankIcon:initView(iconSize, contentSize)
    self.m_iconSize = iconSize
    self:setContentSize(iconSize)
    self:setVisible(false)

    -- self.t_name = cc.LabelTTF:create("", "Helvetica", 18)
    -- self.t_name:setPosition(ccp(iconSize.width / 2,  2))
    -- self.t_name:setAnchorPoint(ccp(0.5, 0) )
    -- self:addChild(self.t_name, 2)
    -- utils.attachBgToLabel(self.t_name)
    registerNodeEventHandler(self)

    self:refreshUI()
    return true
end

function CommercialRankIcon:onEnterFrame(dt)
    
end

function CommercialRankIcon:onEnter()
    self:onEnterFrame(0)
    local function update(dt) self:onEnterFrame(dt) end
    self.entry = self:getScheduler():scheduleScriptFunc(update, 1, false)
end

function CommercialRankIcon:onExit()
    self:getScheduler():unscheduleScriptEntry(self.entry)
end

function CommercialRankIcon:getMgrIns(  )
    local mgrIns = self.m_mgrIns
    if not mgrIns then
        mgrIns = require("game.commercialDarts.CommercialController").getInstance()
        self.m_mgrIns = mgrIns
    end
    return mgrIns
end

function CommercialRankIcon:refreshUI()
    local bg = CCLoadSprite:createSprite("icon_BG.png")
    bg:setPosition(ccp(self.m_iconSize.width * 0.5, self.m_iconSize.height * 0.5))
    bg:setScale(0.63)
    self:addChild(bg)

    CCLoadSprite:call("loadDynamicResourceByName", "commercial_face")

    local icon = CCLoadSprite:createSprite("icon_camel_rank.png")
    icon:setPosition(ccp(self.m_iconSize.width * 0.5, self.m_iconSize.height * 0.5))
    self:addChild(icon)
    self:setVisible(true)
end

function CommercialRankIcon:touchEvent()
    self:getMgrIns():showRankView()
end

function CommercialRankIcon:onSceneChanged(sceneId)
    if sceneId == SCENE_ID_WORLD then
        self:setVisible(false)
    else
        self:setVisible(true)
    end
end

function CommercialRankIcon:onCleanup(  )

end

return CommercialRankIcon