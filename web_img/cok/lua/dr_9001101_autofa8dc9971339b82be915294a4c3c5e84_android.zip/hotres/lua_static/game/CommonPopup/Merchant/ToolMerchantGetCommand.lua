--@author: mm
--@date: 2016-11-14

--pre dec
local print = print
local math = math
local loprint = function(...)
    -- print(...)
end

local ToolMerchantGetCommand = class("ToolMerchantGetCommand", LuaCommandBase)

local TOOL_MERCHANT_GET_COMMAND = "hot.item.v2.get"
local MSG_CITY_RESOURCES_UPDATE = "city_resources_update"

function ToolMerchantGetCommand.create(callback)
    local ret = ToolMerchantGetCommand.new()
    ret:initWithName(TOOL_MERCHANT_GET_COMMAND)
    ret.cmdCallback = callback
    loprint("ToolMerchantGetCommand | create")
    --ret.callback=func
    return ret
end

function ToolMerchantGetCommand:handleReceive( dict )
    loprint("ToolMerchantGetCommand: handleReceive")

    local flag, params = self:parseMsg(dict)
    if (type(flag) == "boolean") then 
        return flag
    end

    ToolController:call("retMerchantItems", params)
    loprint("ToolMerchantGetCommand: params=", params)

    if (params:objectForKey("remainGold")) then
        local gold = params:valueForKey("remainGold"):doubleValue()
        local gd = GlobalData:call("shared")
        local playerInfo = gd:call("getPlayerInfo") --it's a table?
        playerInfo:setProperty("gold", gold)
        CCSafeNotificationCenter:postNotification(MSG_CITY_RESOURCES_UPDATE)
    end

    loprint("ToolMerchantGetCommand: p3, cmdCb =", self.cmdCallback)
    self.cmdCallback(params)
    self.cmdCallBack = nil

    return true --mm: c里面这是false，不知有没有问题。

    -- if params:objectForKey("errorCode") ~= nil then
    --     local errorCode = params:valueForKey("errorCode"):getCString()
    --     print("ToolMerchantGetCommand:handleReceive ... errorCode .. " .. errorCode)
    --     return true
    -- end
    -- return true
end

return ToolMerchantGetCommand

