--[[
	新技能面板：领主技能单元格
]]
require("game.controller.NewActiveSkillController")
local NewActiveSkillGeneralGrid = class("NewActiveSkillGeneralGrid", function()
	return cc.TableViewCell:create()
end)

function NewActiveSkillGeneralGrid:ctor(id, view)
	-- Dprint("NewActiveSkillGeneralGrid:ctor id = ", id)

	self.id = ""
	self.view = view

	local proxy = cc.CCBProxy:create()
	local ccbiUrl = "ActiveSkill_v2_Cell2"
	local node = CCBReaderLoad(ccbiUrl, proxy, self)
	self:addChild(node)

	local function onNodeEvent( event )
		if event == "enter" then
			self:onEnter()
		elseif event == "exit" then
			self:onExit()
		end
	end
	self:registerScriptHandler(onNodeEvent)

	self.touchLayer = cc.Layer:create()
	self:addChild(self.touchLayer)
	local function touchHandle(eventType, x, y)
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
			self:onTouchMoved(x, y)
		elseif eventType == "ended" then
			self:onTouchEnded(x, y)
		end
	end
	self.touchLayer:registerScriptTouchHandler(touchHandle)
	self.touchLayer:setTouchEnabled(true)
	self.touchLayer:setSwallowsTouches(false)

	self.m_sHeroNode:setVisible(false)
	self.m_nodeTime:setVisible(false)
	self.m_sprCollect:setVisible(false)
	
	self:setData(id)
end

function NewActiveSkillGeneralGrid:onEnter()
	self:onEnterFrame()
	self.entry = tonumber(self:getScheduler():scheduleScriptFunc(function()
		self:onEnterFrame()
	end, 0.9, false))
end

function NewActiveSkillGeneralGrid:onEnterFrame()
	self.m_nodeTime:setVisible(false)

	if self.view.page == "general" then
		local generalInfo = GlobalData:call("getSelfGeneralInfo")
		if generalInfo == nil then
			return
		end
		if generalInfo:call("checkHaveStudy", self.id, self.view.generalSeletedId) then
			local cdinfo = GeneralManager:call("getSkillCDInfoById", self.id)
			local nowWorldTime = GlobalData:call("getWorldTime")
			local gapTime = 0
			local effectTime = 0
			if cdinfo and cdinfo:getProperty("endTime") ~= 0 then
				gapTime = cdinfo:getProperty("endTime") - nowWorldTime
				if cdinfo:getProperty("effectEndTime") ~= 0 then
					effectTime = cdinfo:getProperty("effectEndTime") - nowWorldTime
				end
				if self.id == "602700" and gapTime < 0 then
					cdinfo:setProperty("stat", 0)
				end
			end
			if effectTime > 0 then
				self.m_timeLabel:setString(format_time(effectTime))
				self.m_nodeTime:setVisible(true)
				self.m_stateLabel:setString(getLang("169629"))
				self.m_nodeBtn:setVisible(false)
				require("game.CommonPopup.NewActiveSkillHelper"):addSkAcParticle(self.m_particleNode)
			elseif gapTime > 0 then
				self.m_timeLabel:setString(format_time(gapTime))
				self.m_nodeTime:setVisible(true)
				self.m_stateLabel:setString(getLang("169630"))
				self.m_particleNode:removeAllChildren()
				self.m_nodeBtn:setVisible(false)
			elseif (self.id == "602700" or self.id == "603100") and gapTime == 0 and cdinfo:getProperty("stat") == 1 then
				self.m_btnLook:setVisible(false)
				self.m_labelBtn:setString(getLang("108532"))	--108532=取消
			end
		end
		self:updateCollect()
	end
end

function NewActiveSkillGeneralGrid:onExit()
	if self.entry then
		self:getScheduler():unscheduleScriptEntry(self.entry)
	end
end

function NewActiveSkillGeneralGrid:onTouchBegan(x, y)
	self.v_touchBeganX = x
	self.v_touchBeganY = y
	if self.view.page == "general" and isTouchInside(self.m_skillTouchNode, x, y) then
		self.v_isMove = false
		return true
	end
	return false
end

function NewActiveSkillGeneralGrid:onTouchMoved(x, y)
	if self.view.page == "general" and isTouchInside(self.m_skillTouchNode, x, y) then
        if ccpSquareDistance(cc.p(self.v_touchBeganX, self.v_touchBeganY), cc.p(x, y)) > 50 then
			self.v_isMove = true
		end
	end
end

function NewActiveSkillGeneralGrid:onTouchEnded(x, y)
	if self.v_isMove==false and isTouchInside(self.m_skillTouchNode, x, y) then
		if self.id ~= self.view.selectedId then
			self.view:onTouchGrid(self)
		end
	end
end

function NewActiveSkillGeneralGrid:setData(id)
	-- Dprint("NewActiveSkillGeneralGrid:setData id = ", id, self.view.selectedId)
	self.id = id

	self.m_selcetSprite:setVisible(false)

	local showRedDot = require("game.CommonPopup.NewActiveSkillHelper"):isSkillInRecord(self.id)
	self.m_redDotSp:setVisible(showRedDot)
	self.m_particleNode:removeAllChildren()

	local generalInfo = GlobalData:call("getSelfGeneralInfo")
	if generalInfo then
		local pic = CCCommonUtilsForLua:call("getPropById", self.id, "icon") .. ".png"
		if CCLoadSprite:call("getSF",pic) == nil then
			pic = "dragon_skill_1.png"
		end
		local icon = CCLoadSprite:call("createSprite", pic)
		self.m_iconNode:removeAllChildren()
		self.m_iconNode:addChild(icon)

		-- 
		self.m_nodeBtn:setVisible(true)
		self.m_btnUse:setVisible(true)
		self.m_btnLook:setVisible(true)
		if generalInfo:call("checkHaveStudy", self.id, self.view.generalSeletedId) then	--该技能已激活
			self.m_selcetSprite:setVisible(true)

			CCCommonUtilsForLua:call("setSpriteGray", icon, false)
			if self.view.generalSeletedId == self.view.generalEnabledId then	--当前处于激活天赋列表
				self.m_btnLook:setVisible(false)
				self.m_labelBtn:setString(getLang("105460"))	--105460=使用
			else
				self.m_btnUse:setVisible(false)
				self.m_labelBtn:setString(getLang("118006"))	--118006=去看看
			end				
		else
			CCCommonUtilsForLua:call("setSpriteGray", icon, true)
			self.m_btnUse:setVisible(false)
			self.m_labelBtn:setString(getLang("118006"))	--118006=去看看
		end
		CCCommonUtilsForLua:call("setSpriteMaxSize", icon, 100, true)
	else
		self.m_nodeBtn:setVisible(false)
	end

	self:onEnterFrame()
end

-- 更新收藏标志
function NewActiveSkillGeneralGrid:updateCollect( )
	-- Dprint("NewActiveSkillGeneralGrid:updateCollect")
	if self.id then
		local _isCollect = NewActiveSkillController:isCollected(self.id)
		self.m_sprCollect:setVisible(_isCollect)
	end
end

-- 点击使用按钮
function NewActiveSkillGeneralGrid:onClickBtnUse()
	Dprint("NewActiveSkillGeneralGrid:onClickBtnUse")
	local generalInfo = GlobalData:call("getSelfGeneralInfo")
	if nil == generalInfo then
		return
	end

	self.view.selectedId = self.id
	if generalInfo:call("checkHaveStudy", self.id, self.view.generalSeletedId) and self.view.generalSeletedId == self.view.generalEnabledId then
		local cdinfo = GeneralManager:call("getSkillCDInfoById", self.id)
		local specialUse = false
		if self.id == "603100" or self.id == "602700" then
			if cdinfo and cdinfo:getProperty("stat") == 1 then
				-- 取消
				self:sendCancelSkill()
				return
			else
				specialUse = true
			end
		elseif self.id == "612400" then-- or self.id == "622700" 奋斗至虚脱技能取消道具使用按钮
			specialUse = true
		end

		if specialUse then
			local view = NewUseSkillViewItemView.create(self.id, self)
			PopupViewController:call("addPopupView", view)
			return
		end

		self:generalUseClick()
	else
		local from = CCCommonUtilsForLua:call("getPropById", self.id, "source")
		if from == "1" or from == "" then
			local isLua = CCCommonUtilsForLua:isFunOpenByKey("general_skill_new") -- 改为新的开关控制，启用lua代码 -- CCCommonUtilsForLua:call("isTestPlatformAndServer", "general_skill_list_view")
			if isLua then
				local t = {}
				t.abilityId = generalInfo:call("getAbilityBySkillId", self.id, self.view.generalEnabledId)
				t.skillId = self.id
				PopupViewController:call("removeAllPopupView")
				onFireEvent("open_GeneralSkillListPopUpView", t)
			else
				local dic = CCDictionary:create()
				dic:setObject(CCString:create("GeneralSkillListPopUpView"), "name")
				dic:setObject(CCString:create(generalInfo:call("getAbilityBySkillId", self.id, self.view.generalEnabledId)), "abilityId")
				dic:setObject(CCString:create(self.id), "skillId")
				PopupViewController:call("removeAllPopupView")
				LuaController:call("openPopViewInLua", dic)
			end
		elseif from == "2" then
			PopupViewController:call("removeAllPopupView")
			local dict = CCDictionary:create() 
			dict:setObject(CCString:create("ScienceListView"), "name")
			LuaController:call("openPopViewInLua", dict)
		elseif from == "3" then
			-- 列王传
			if require("game.activity.KingBiography.KingBiographyController").isOpen() then
				local view = Drequire("game.activity.KingBiography.KingBiographyView"):create()
				if view then
					PopupViewController:call("removeAllPopupView")
					PopupViewController:call("addPopupInView", view)
				end
			end
		end
	end
end

function NewActiveSkillGeneralGrid:addResourceFunction( useItem )
	Dprint("NewActiveSkillGeneralGrid:addResourceFunction", useItem)
	if self:skillCanUse() == false then
		return
	end

	local resourceType = 4
	if not useItem then
		local randomNum = math.random(0, 9999)
		resourceType = randomNum % 4
	end
	PopupViewController:call("forceClearAll", true)
	WorldController:call("getInstance"):setProperty("openAddResourceType", resourceType)
	local index = WorldController:call("getIndexByPoint", WorldController:call("getInstance"):getProperty("selfPoint"))
	-- if SceneController:call("getInstance"):getProperty("currentSceneId") == SCENE_ID_WORLD then
	if SceneController:call("getCurrentSceneId") == SCENE_ID_WORLD then
		WorldMapView:call("instance"):call("gotoTilePoint", WorldController:call("getInstance"):getProperty("selfPoint"))
	else
		SceneController:call("gotoScene", SCENE_ID_WORLD, false, true, index)
	end
end

-- 点击去看看按钮
function NewActiveSkillGeneralGrid:onClickBtnLook()
	self:onClickBtnUse()
end

function NewActiveSkillGeneralGrid:sendCancelSkill(  )
	local generalInfo = GlobalData:call("getSelfGeneralInfo")
	if nil == generalInfo then
		return
	end
	if self.id ~= "603100" and self.id ~= "602700" then
		return
	end

	local cmd = NewCancelSkillCommand.new(self.id)
	cmd:send()
end

function NewActiveSkillGeneralGrid:checkSkillActivating( skillId )
	local generalInfo = GlobalData:call("getSelfGeneralInfo")
	if nil == generalInfo then
		return false
	end
	local skillActivating = false
	if generalInfo:call("checkHaveStudy", skillId, generalInfo:getProperty("curMapIdx")) then
		local cdinfo = GeneralManager:call("getSkillCDInfoById", skillId)
		if cdinfo and cdinfo:getProperty("endTime") < 1 and cdinfo:getProperty("effectEndTime") < 1 and cdinfo:getProperty("stat") == 1 then
			skillActivating = true
		end
	end
	return skillActivating
end

function NewActiveSkillGeneralGrid:generalUseClick()
	local generalInfo = GlobalData:call("getSelfGeneralInfo")
	if nil == generalInfo then
		return
	end
	local cdinfo = GeneralManager:call("getSkillCDInfoById", self.id)

	local maxStan = GlobalData:call("shared"):getProperty("MaxStamina")

	if self.id == "622300" 
		and (WorldController:call("getInstance"):getProperty("currentStamine") + 30) > maxStan
		then
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("168034"))
		return
	end

	if self:skillCanUse() == false then
		return
	end

	if self.id == "603100" then
		if self:checkSkillActivating("603100") then
			YesNoDialog:call("show", getLang("168036"), cc.CallFunc:create(function (  )
				self:sendCancelSkill()
			end))
			return
		end
		if self:checkSkillActivating("602700") then
			YesNoDialog:call("show", getLang("150760"))
			return
		end
	elseif self.id == "602700" then
		if self:checkSkillActivating("603100") then
			YesNoDialog:call("show", getLang("150760"))
			return
		end
	elseif self.id == "622700" then
		if WorldController:call("getInstance"):getProperty("currentStamine") < 5 then
			YesNoDialog:call("show", getLang("150812"))
			return
		end
	elseif self.id == "622900" then -- 激活龙友好度回满技能
		if CCCommonUtilsForLua:call("isFunOpenByKey", "dragon_science_skill") == false then
			YesNoDialog:call("show", getLang("164662"))
			return
		else
			local info = DragonController:call("getActiveDragonInfo")
			if nil == info then
				YesNoDialog:call("show", getLang("164641"))
				return
			end
			if info:call("getInMarch") then
				YesNoDialog:call("show", getLang("164642"))
				return
			end
			if info:call("getIntimacy") > info:call("getIntimacyTopLimit") then
				YesNoDialog:call("show", getLang("164643"))
				return
			end
			-- 164640=当前守护龙为：{0}-{1}，友好度为{2}，是否对其使用“铁哥们！”立即补满友好度？
			local _total = tonumber(CCCommonUtilsForLua:call("getPropById", info:call("getItemId"), "friendship")) or 1
			local _percent = string.format('%0.1f%%', atoi(info:call("getIntimacy")) * 100 / _total)
			local des = getLang("164640", getLang(info:call("getName")), info:call("getNickName"), _percent)
			
			YesNoDialog:call("showYesNoFun", des, cc.CallFunc:create(function (  )
				self:sendUseSkillCommand()
				if CCCommonUtilsForLua:isFunOpenByKey("new_battle_view_lua") then
					CCSafeNotificationCenter:postNotification(MessageType.MSG_SEND_BATTLE_VIEW_BUFF_CMD)
				end
			end), getLang("confirm"), nil, getLang("cancel_btn_label"))
			return
		end
	elseif self.id == "613700" then --CD技能球		
		--para3是英雄
		--para2领主
		local genCDSkills = string.split(CCCommonUtilsForLua:call("getPropByIdGroup","sk",self.id,"para2"),";")
		local canUse = false
		local nowWorldTime = GlobalData:call("getWorldTime")
		--检查领主技能中是否有在CD中的
		for k,v in pairs(genCDSkills or {}) do
			local _info = GeneralManager:call("getSkillCDInfoById", v)
			if _info and _info:getProperty("endTime") ~= 0 then
				if _info:getProperty("endTime") - nowWorldTime > 0 then
					canUse = true
					break
				end
			end
		end
		--如果没有再检查英雄技能中是否有在CD中的
		if not canUse then
			local heroCDSkills = string.split(CCCommonUtilsForLua:call("getPropByIdGroup","sk",self.id,"para3"),";")
			for k,v in pairs(heroCDSkills or {}) do
				local info = HeroManager.getActiveSkillInfoById(v)
				if info and info:isInCD() then
					canUse = true
					break
				end
			end
		end
		if not canUse then
			YesNoDialog:call("show", getLang("9711179"))--9711179=当前无已进入CD的技能
			return
		end
	end
	-- 判断城市增益中有没有同组增益正在使用
	local actNumber = math.tonumber(CCCommonUtilsForLua:call("getPropById", self.id, "para1"))
	local group = math.tonumber(CCCommonUtilsForLua:call("getPropById", tostring(actNumber), "group"))
	local findSid = GlobalData:call("getActiveStatusByGroup", actNumber)
	local curStatusGid = 0
	if findSid > 0 then
		local findGroup = CCCommonUtilsForLua:call("getPropById", tostring(findSid), "group")
		curStatusGid = math.tonumber(findGroup)
	end
	if curStatusGid > 0 then
		if group >= curStatusGid then
			-- 可以覆盖//领主大人，此状态不可叠加，若使用该技能，之前的状态将被覆盖！
			YesNoDialog:call("show", getLang("101454"), cc.CallFunc:create(function (  )
				self:sendUseSkillCommand()
				if CCCommonUtilsForLua:isFunOpenByKey("new_battle_view_lua") then
					CCSafeNotificationCenter:postNotification(MessageType.MSG_SEND_BATTLE_VIEW_BUFF_CMD)
				end
			end))
		else
			YesNoDialog:call("showYesDialog", getLang("101433"))
		end
	else
		self:sendUseSkillCommand()
		if CCCommonUtilsForLua:isFunOpenByKey("new_battle_view_lua") then
			CCSafeNotificationCenter:postNotification(MessageType.MSG_SEND_BATTLE_VIEW_BUFF_CMD)
		end
	end
end

function NewActiveSkillGeneralGrid:skillCanUse()
	-- NOTE: self.skillId equal nil all the time 20180428
	if self.skillId ~= "603100" and self.skillId ~= "612400" and self.skillId ~= "622700" then
		return true
	end

	local tipsMessage = self:checkSkillOpen()
	if tipsMessage ~= "" then
		YesNoDialog:call("show", tipsMessage)
		return false
	end

-- 	    //判断是否处于跨服状态
-- //    SERVER_BATTLE_FIELD,//远古战场服务器
-- //    SERVER_DRAGON_BATTLE //巨龙战役服务器
	if GlobalData:call("getPlayerInfo"):getProperty("crossFightSrcServerId") > 0
		and GlobalData:call("getPlayerInfo"):getProperty("crossFightSrcServerId") ~= GlobalData:call("getPlayerInfo"):getProperty("selfServerId")
		then
		if self.id == "603100" 
			and GlobalData:call("shared"):getProperty("serverType") ~= ServerType.SERVER_BATTLE_FIELD
			and GlobalData:call("shared"):getProperty("serverType") ~= ServerType.SERVER_DRAGON_BATTLE
			then
			-- //如果是决斗技能，非远古和巨龙服务器，可以使用决斗
			return true
		end
		YesNoDialog:call("show", getLang("150811"))
		return false
	end

	return true
end

function NewActiveSkillGeneralGrid:checkSkillOpen(  )
	local tipsMessage = ""
	local skillSwitchKey = ""
	local externSwitchKey = ""
	if self.id == "603100" then
		skillSwitchKey = "45skill_combat"
		--决斗技能: 跨服王座战场有额外开关
		local crossThroneManager = require("game.crossThrone.CrossThroneManager")
		if crossThroneManager:isDespotServer() then
			externSwitchKey = "overlord_duel_off"
		elseif crossThroneManager:isEmpireServer() then
			externSwitchKey = "monarch_duel_off"
		end
	elseif self.id == "612400" then
		skillSwitchKey = "45skill_development"
	elseif self.id == "622700" then
		skillSwitchKey = "45skill_support"
	end
	if skillSwitchKey ~= "" then
		if CCCommonUtilsForLua:call("isFunOpenByKey", skillSwitchKey) == false then
			tipsMessage = getLang("150794")	--150794=当前技能暂时关闭，尽情期待下次开放。
		end
	end
	if externSwitchKey ~= "" then
		if CCCommonUtilsForLua:call("isFunOpenByKey", externSwitchKey) == true then
			tipsMessage = getLang("150811")	--150811=该技能无法在跨服使用。
		end
	end
	return tipsMessage
end

function NewActiveSkillGeneralGrid:sendUseSkillCommand(  )
	local generalInfo = GlobalData:call("getSelfGeneralInfo")
	if nil == generalInfo then
		return
	end

	local skillId = self.id
	local t = math.tonumber(CCCommonUtilsForLua:call("getPropById", self.id, "type"))
	local cdinfo = GeneralManager:call("getSkillCDInfoById", skillId)
	if t == 11 and cdinfo and cdinfo:getProperty("stat") ~= 0 then
		YesNoDialog:call("showYesDialog", getLang("105465"))
		return
	end

	local cmd = NewUseSkillCommand.new(self.id)
	if self.m_skillItemId and self.m_skillItemId ~= 0 and self.m_skillItemId ~= "" then
		local tinfo = ToolController:call("getToolInfoForLua", tonumber(self.m_skillItemId))
		if tinfo and tinfo:call("getCNT") > 0 then
			cmd:putParam("useItem", CCString:create(tinfo:getProperty("uuid")))
		end
	end
	cmd:send()
end



return NewActiveSkillGeneralGrid