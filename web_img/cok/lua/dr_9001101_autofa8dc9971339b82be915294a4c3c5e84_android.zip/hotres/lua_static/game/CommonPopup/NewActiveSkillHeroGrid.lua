--[[
	新技能面板：英雄技能单元格
]]
local NewActiveSkillHeroGrid = class("NewActiveSkillHeroGrid", function()
	return cc.TableViewCell:create()
end)

function NewActiveSkillHeroGrid:ctor(id, view)
	self.id = ""
	self.view = view

	local proxy = cc.CCBProxy:create()
	local ccbiUrl = "ActiveSkill_v2_Cell2"
	local node = CCBReaderLoad(ccbiUrl, proxy, self)
	self:addChild(node)

	local function onNodeEvent( event )
		if event == "enter" then
			self:onEnter()
		elseif event == "exit" then
			self:onExit()
		end
	end
	self:registerScriptHandler(onNodeEvent)

	self.touchLayer = cc.Layer:create()
	self:addChild(self.touchLayer)
	local function touchHandle(eventType, x, y)
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
			self:onTouchMoved(x, y)
		elseif eventType == "ended" then
			self:onTouchEnded(x, y)
		end
	end
	self.touchLayer:registerScriptTouchHandler(touchHandle)
	self.touchLayer:setTouchEnabled(true)
	self.touchLayer:setSwallowsTouches(false)

	self.m_sHeroNode:setVisible(true)
	self.m_nodeTime:setVisible(false)
	self.m_sprCollect:setVisible(false)

	self:setData(id)
end

function NewActiveSkillHeroGrid:onEnter()
	self:onEnterFrame()
	self.entry = tonumber(self:getScheduler():scheduleScriptFunc(function()
		self:onEnterFrame()
	end, 0.9, false))
end

function NewActiveSkillHeroGrid:onEnterFrame()
	self.m_nodeTime:setVisible(false)
	if self.view.page == "hero" then
		local info = HeroManager.getActiveSkillInfoById(self.id)
		if nil == info then
			return
		end
		if info:isObtain() then
			local nowTimeStamp = GlobalData:call("getTimeStamp")
			if info:isActive() then
				local left = info:getActEndtime() - nowTimeStamp
				left = math.max(0, left)
				self.m_timeLabel:setString(format_time(left))
				self.m_stateLabel:setString(getLang("169629"))
				self.m_nodeTime:setVisible(true)
				self.m_nodeBtn:setVisible(false)
				require("game.CommonPopup.NewActiveSkillHelper"):addSkAcParticle(self.m_particleNode)
			elseif info:isInCD() then
				local left = info:getCDEndTime() - nowTimeStamp
				left = math.max(0, left)
				self.m_timeLabel:setString(format_time(left))
				self.m_stateLabel:setString(getLang("169630"))
				self.m_nodeTime:setVisible(true)
				self.m_nodeBtn:setVisible(false)
				self.m_particleNode:removeAllChildren()
			else
				--
			end
		end
		self:updateCollect()
	end
end

function NewActiveSkillHeroGrid:onExit()
	if self.entry then
		self:getScheduler():unscheduleScriptEntry(self.entry)
	end
end

function NewActiveSkillHeroGrid:onTouchBegan(x, y)
	self.v_touchBeganX = x
	self.v_touchBeganY = y
	if self.view.page == "hero" and isTouchInside(self.m_skillTouchNode, x, y) then
		self.v_isMove = false
		return true
	end
	return false
end

function NewActiveSkillHeroGrid:onTouchMoved( x,y )
	if self.view.page == "hero" and isTouchInside(self.m_skillTouchNode, x, y) then
        if ccpSquareDistance(cc.p(self.v_touchBeganX, self.v_touchBeganY), cc.p(x, y)) > 50 then
			self.v_isMove = true
		end
	end
end

function NewActiveSkillHeroGrid:onTouchEnded(x, y)
	if self.v_isMove==false and isTouchInside(self.m_skillTouchNode, x, y) then
		if self.id ~= self.view.selectedId then
			self.view:onTouchGrid(self)
		end
	end

end

function NewActiveSkillHeroGrid:setData(id)
	self.m_selcetSprite:setVisible(false)
	self.id = id

	local showRedDot = require("game.CommonPopup.NewActiveSkillHelper"):isSkillInRecord(self.id)
	self.m_redDotSp:setVisible(showRedDot)
	self.m_particleNode:removeAllChildren()

	local info = HeroManager.getActiveSkillInfoById(self.id)
	if info ~= nil  then
		local pic = info:getIconStr()
		if CCLoadSprite:call("getSF",pic) == nil then
			pic = "dragon_skill_1.png"
		end
		local icon = CCLoadSprite:call("createSprite", pic)
		self.m_iconNode:removeAllChildren()
		self.m_iconNode:addChild(icon)

		self.m_nodeBtn:setVisible(true)
		self.m_btnUse:setVisible(true)
		self.m_btnLook:setVisible(true)
		if info:isObtain() then
			CCCommonUtilsForLua:call("setSpriteGray", icon, false)
			self.m_selcetSprite:setVisible(true)
			self.m_btnLook:setVisible(false)
			self.m_labelBtn:setString(getLang("105460"))	--105460=使用
		else
			CCCommonUtilsForLua:call("setSpriteGray", icon, true)
			self.m_btnUse:setVisible(false)
			self.m_labelBtn:setString(getLang("118006"))	--118006=去看看
		end
		CCCommonUtilsForLua:call("setSpriteMaxSize", icon, 100, true)

		local heroInfo = info:getHeroInfo()
		if heroInfo ~= nil then
			local heroHeadPic = CCCommonUtilsForLua:getPropById(heroInfo.id, "pic") .. ".png"
			if CCLoadSprite:call("getSF",heroHeadPic) == nil then
				heroHeadPic = "hero_head_1.png"
			end
			local heroHeadIcon = CCLoadSprite:createSprite(heroHeadPic)
			heroHeadIcon:setScale(0.35)
			self.m_headNode:removeAllChildren()
			self.m_headNode:addChild(heroHeadIcon)
		end
	end

	self:onEnterFrame()
end

-- 更新收藏标志
function NewActiveSkillHeroGrid:updateCollect( )
	-- Dprint("NewActiveSkillHeroGrid:updateCollect")
	if self.id then
		local _isCollect = NewActiveSkillController:isCollected(self.id)
		self.m_sprCollect:setVisible(_isCollect)
	end
end

-- 点击使用按钮
function NewActiveSkillHeroGrid:onClickBtnUse()
	Dprint("NewActiveSkillHeroGrid:onClickBtnUse")
	local info = HeroManager.getActiveSkillInfoById(self.id)
	if nil == info then
		return
	end
	self.view.selectedId = self.id
	if info:isObtain() == false then
		local heroInfo = info:getHeroInfo()
		if nil == heroInfo then
			return
		end

		local heroId = info:getHeroId()
		local general_ab = CCCommonUtilsForLua:call("getPropByIdGroup","general_base",heroId,"general_ab")
		local isTalent = false
		for i,v in ipairs(string.splitNSep(general_ab, ";") or {}) do
			local talent = CCCommonUtilsForLua:call("getPropByIdGroup","general_ab",v,"skill")
			if string.find(talent, self.id) then
				isTalent = true
				break
			end
		end
		PopupViewController:call("removeAllPopupView")
		if isTalent then
			local view = Drequire("game.hero.NewUI_v2.HeroTalentView"):create(heroId, self.id)
			PopupViewController:call("addPopupInView", view)
		else
			local view = myRequire("game.hero.NewUI_v2.HeroSkillView").create(heroId)
			PopupViewController:call("addPopupInView", view)
		end
	else
		local info = HeroManager.getActiveSkillInfoById(self.id)
		if nil == info then
			return
		end
		local heroInfo = info:getHeroInfo()
		if nil == heroInfo then
			return
		end
		if heroInfo.state == HeroState.Captured or heroInfo.state == HeroState.Dead then
			CCCommonUtilsForLua:call("flyHint", "", "", getLang("169734"))
			return
		end
		HeroManager.useSkill(tonumber(info:getHeroId()), self.id)
		if CCCommonUtilsForLua:isFunOpenByKey("new_battle_view_lua") then
			CCSafeNotificationCenter:postNotification(MessageType.MSG_SEND_BATTLE_VIEW_BUFF_CMD)
		end
	end
end

-- 点击去看看按钮
function NewActiveSkillHeroGrid:onClickBtnLook()
	self:onClickBtnUse()
end

return NewActiveSkillHeroGrid