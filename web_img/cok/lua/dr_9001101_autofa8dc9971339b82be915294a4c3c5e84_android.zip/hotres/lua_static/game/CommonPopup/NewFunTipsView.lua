NewFunTipsView = class("NewFunTipsView", function(  )
	return PopupBaseView:create()
end)

function NewFunTipsView:ctor( title, icon, des, sprNode)
    MyPrint("NewFunTipsView:ctor  ", title, icon, des)
	self.title = title
    self.icon = icon
    self.des = des
    self.sprNode = sprNode
end

function NewFunTipsView.create( title, icon, des, sprNode)
	local ret = NewFunTipsView.new(title, icon, des, sprNode)
	if ret:initView() == false then
		return nil
	end
	return ret
end

function NewFunTipsView:initView(  )
    MyPrint("NewFunTipsView:init")


	if self:init(true, 0) == false then
		MyPrint("NewFunTipsView init error")
    	return false	
	end

	self:setHDPanelFlag(true)
	local winsize = cc.Director:getInstance():getIFWinSize()
	self:setContentSize(winsize)

	local proxy = cc.CCBProxy:create()
    local ccbiUrl = "ccbi/NewFunTipsView.ccbi"
	local node = CCBReaderLoad(ccbiUrl, proxy, self)
    if nil == node then
        return false
    end
    if CCCommonUtilsForLua:call("isIosAndroidPad") == true then
    	self.m_mainNode:setScale(2)
    end

    self:addChild(node)

    self.m_titleLabel:setString(self.title)
    self.m_desLabel:setString(self.des)
    self.m_picNode:removeAllChildren()
    local spr
    if self.icon then
    	spr = CCLoadSprite:createSprite(self.icon)
    else
    	spr = self.sprNode
    end
    spr:setAnchorPoint(cc.p(0.5, 0.5))
    self.m_picNode:addChild(spr)
    CCCommonUtilsForLua:call("setSpriteMaxSize",spr,150,true)
    CCCommonUtilsForLua:call("setButtonTitle", self.m_okBtn, getLang("confirm"))
	
	local function onNodeEvent( event )
		if event == "enter" then
			self:onEnter()
	    elseif event == "exit" then
			self:onExit()
	    end
	end
	self:registerScriptHandler(onNodeEvent)

	self.touchLayer = cc.Layer:create()
	self:addChild(self.touchLayer)

	local function touchHandle( eventType, x, y )
        MyPrint("touchHandle" .. eventType)
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		else
			self:onTouchEnded(x, y)
		end
	end
	self.touchLayer:registerScriptTouchHandler(touchHandle)
	self.touchLayer:setTouchEnabled(true)
	self.touchLayer:setSwallowsTouches(true)

	return true
end

function NewFunTipsView:onClickCloseBtn()
	local pop = tolua.cast(self, "PopupBaseView")
    pop:call("closeSelf")
end

function NewFunTipsView:onOkClick()
    local pop = tolua.cast(self, "PopupBaseView")
    pop:call("closeSelf")
end

function NewFunTipsView:onEnter() 
    
end

function NewFunTipsView:onExit()
    
end

function NewFunTipsView:onTouchBegan(x, y) 
    MyPrint("NewFunTipsView:onTouchBegan")
    if isTouchInside(self.m_touchNode, x, y) then
        return false
    end
    return true
end

function NewFunTipsView:onTouchEnded(x, y)
    MyPrint("NewFunTipsView:onTouchEnded")
    if isTouchInside(self.m_touchNode, x, y) then
        return
    end
    self:onClickCloseBtn()
end
