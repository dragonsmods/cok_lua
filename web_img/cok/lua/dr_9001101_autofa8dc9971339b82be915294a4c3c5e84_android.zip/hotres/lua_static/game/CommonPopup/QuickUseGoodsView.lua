--[[
	使用加速道具界面
]]

local COLUMN_OF_TABLE = 4 -- 道具列表-列数

local QuickUseGoodsView = class("QuickUseGoodsView", function() return PopupBaseView:create() end)
QuickUseGoodsView.__index = QuickUseGoodsView


function QuickUseGoodsView:create(playerUid, callback)
	local view = QuickUseGoodsView.new()
	Drequire("game.CommonPopup.QuickUseGoodsView_ui"):create(view, 1)

	if view:initView(playerUid, callback) == false then
		return nil
	end
  	return view
end

function QuickUseGoodsView:initView(playerUid, callback)
    tolua.cast(self.ui.m_bar, "cc.ProgressTimer")
    self.m_playerUid = playerUid
    self.m_callback = callback
    self.m_itemList = {212999, 213000, 213001, 213002, 213003, 213004}
    self.m_itemId = nil

    self.ui.m_buyNode:setVisible(false)
    self.ui.m_btnMsgLabel:setString(getLang("104906"))

	self:initTableView()
    -- self:updateInfo()
    self.ui.m_btnUse:setEnabled(false)

	return true
end

function QuickUseGoodsView:onEnter()
	-- self:resetScheduler()
    -- registerScriptObserver(self, self.refreashData, 		  MSG_REFREASH_TOOL_DATA)
    if not self.m_itemId and self.m_itemList and #self.m_itemList > 0 then
        self:onSelect(self.m_itemList[1])
    end
end

function QuickUseGoodsView:onExit()
    unregisterScriptObserver(self, MSG_REFREASH_TOOL_DATA)
	-- self:removeScheduler()
end

function QuickUseGoodsView:resetScheduler()
    self:removeScheduler()
    self:onEnterFrame()
    self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(function() self:onEnterFrame() end, 1, false)
end

function QuickUseGoodsView:removeScheduler()
    if self.entry then
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
		self.entry = nil
	end
end

-- 添加列表
function QuickUseGoodsView:initTableView()
	local delegate = {}
	delegate.gridAtIndex              = function(tab, idx)  return self:gridAtIndexEx(tab, idx)           end
    delegate.numberOfCellsInTableView = function(tab)       return self:numberOfCellsInTableViewEx(tab)   end
    delegate.numberOfGridsInCell      = function(tab)       return self:numberOfGridsInCellEx(tab)        end
    delegate.gridSizeForTable         = function(tab, idx)  return self:cellSizeForTableEx(tab, idx)      end

    local list_size  = self.ui.m_nodeList:getContentSize()
	self.m_tableView = require("game.utility.TableViewMultiCol").new(CCSize(list_size.width,list_size.height))
	self.m_tableView:setDelegate(delegate)
	self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
	self.m_tableView:setVerticalFillOrder(kCCTableViewFillTopDown)
	self.m_tableView:setSwallowsTouches(true)
	self.ui.m_nodeList:addChild(self.m_tableView)
	self.m_tableView:setPosition(cc.p(0, 0))
    self.m_tableView:setAnchorPoint(cc.p(0, 0))
    self.m_tableView:reloadData()
end

function QuickUseGoodsView:updateInfo()
    self.ui.m_nameLabel:setString(getLang("102159"))
    self.m_sumTime = self:getTotalTime()
    self:onEnterFrame(0)
    self:refreashData()
end

function QuickUseGoodsView:gridAtIndexEx(tab, idx)
    idx = idx + 1
    if idx > #self.m_itemList then
        return nil
    end

    local itemId = self.m_itemList[idx]
	local grid = tab:dequeueGrid()
	if grid ~= nil then
		grid:setData(itemId, self)
	else
	 	grid = Drequire("game.CommonPopup.QuickUseGoodsCell"):create(itemId, self)
	end

	return grid
end

function QuickUseGoodsView:numberOfCellsInTableViewEx(tab)
    return math.ceil(#self.m_itemList/COLUMN_OF_TABLE)
end

function QuickUseGoodsView:numberOfGridsInCellEx(tab)
    return COLUMN_OF_TABLE
end

function QuickUseGoodsView:cellSizeForTableEx(tab, idx)
    return 120, 160
end

function QuickUseGoodsView:onSelect(itemId)
	if itemId then
        self.m_itemId = itemId
        self:updateUIAfterSelect()
        CCSafeNotificationCenter:postNotification("QuickUseGoodsCell:onSelect", CCString:create(self.m_itemId))
	end
end

function QuickUseGoodsView:updateUIAfterSelect()
    if self.m_itemId then
        local toolInfo = ToolController:call("getToolInfoByIdForLua", self.m_itemId)
        if toolInfo:call("getCNT") <= 0 then
            self.ui.m_buyNode:setVisible(false)
            self.ui.m_btnUse:setEnabled(false)
        else
            self.ui.m_buyNode:setVisible(false)
            self.ui.m_btnUse:setVisible(true)
            self.ui.m_btnUse:setEnabled(true)
        end
    end
end

function QuickUseGoodsView:onClickBtnUse()
    if self.m_itemId == nil then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("350038")) -- 350038=未选择
        return
    end

    local toolInfo = ToolController:call("getToolInfoByIdForLua", self.m_itemId)
    if toolInfo:call("getCNT") <= 0 then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("102198")) -- 102198=道具不足
        return
    else
        -- ToolController:call("useTool", self.m_itemId)
        -- local info = ToolController:call("getToolInfoByIdForLua", self.m_itemId)
        -- WorldController:call("sendAllianceShieldCommand", self.m_playerUid, tostring(info:getProperty("uuid")))
        if self.m_callback then
            self.m_callback(self.m_playerUid, self.m_itemId)
        end
        self:onCloseButtonClick()
    end
end

function QuickUseGoodsView:onClickBtnCancel()
    self:onCloseButtonClick()
end

function QuickUseGoodsView:onCloseButtonClick()
    PopupViewController:call("removePopupView", self)
end

return QuickUseGoodsView