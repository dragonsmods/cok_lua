NewToolNumSelectView = class("NewToolNumSelectView", function()
        return PopupBaseView:create()
    end
)
NewToolNumSelectView.__index = NewToolNumSelectView
------------------------------------------ ToolNumSelectView Start --------------------------------------------
local sliderMin = 1
-- Hero状态
ToolType = 
{
    HeroExp = 1, -- 英雄经验
	HeroFragment = 2, -- 英雄碎片
	PrestigeDonate = 3, -- 文明声望捐献
	EquipmentPaper = 4, -- 锻造装备时图纸数量选择
	Gold=5,
	Diamond=6,
}
function NewToolNumSelectView:create(itemId, minNum, maxNum, target, useType, useTitle, useButtonName, showChanges, messagePosted, singlePoint)
	local view = NewToolNumSelectView.new()
	if view:initView(itemId, minNum, maxNum, target, useType, useTitle, useButtonName, showChanges, messagePosted, singlePoint) == false then
		return nil
	end
  	return view
end

function NewToolNumSelectView:initView(itemId, minNum, maxNum, target, useType, useTitle, useButtonName, showChanges, messagePosted, singlePoint)
	MyPrint("NewToolNumSelectView:initView minNum maxNum",minNum, maxNum)
	if self:init(true, 0) == false then
		-- MyPrint("NewToolNumSelectView init error")
    	return false
	end
	self:setHDPanelFlag(true)
	--ccb
	local m_bIsPad = CCCommonUtilsForLua:isIosAndroidPad()
	local proxy = cc.CCBProxy:create()
	local ccbiURL = ""
	ccbiURL = "ccbi/ToolNumSelectForLua.ccbi"
  	self.m_bIsPad = m_bIsPad
  	local nodeccb = CCBReaderLoad(ccbiURL,proxy, self)
	if nodeccb == nil then
		-- MyPrint("NewToolNumSelectView loadccb error")
		return false
	end
	if m_bIsPad then
		nodeccb:setScale(2.0)
	end
	self:setContentSize(cc.Director:getInstance():getIFWinSize())
  	self:addChild(nodeccb)
	self.ccbNode = nodeccb
	--data
	self.m_itemId = itemId
	self.m_minNum = minNum
	self.m_maxNum = maxNum
	self.m_target = target
	self.m_useType = useType
	self.m_useTitle = useTitle
	self.m_useButtonName = useButtonName
	self.m_showChanges = showChanges
	self.m_messagePosted = messagePosted
	self.m_singlePoint = singlePoint
	self.m_curNum = minNum
	sliderMin = self.m_minNum
	if self.m_maxNum <= 0 then
		self.m_maxNum = 0
		self.m_curNum = 0
		sliderMin = 0
		self.m_useBtn:setEnabled(false)
	end
	if self.m_minNum <= 0 then
		self.m_minNum = 0
	end
	local goodUuid = ""
	if self.m_itemId ~= nil then
		local toolInfo = ToolController:call("getToolInfoForLua", tonumber(self.m_itemId))
		if toolInfo == nil then
			MyPrint("NewToolNumSelectView getToolInfo fail with itemId "..tostring(self.m_itemId))
		else
			goodUuid = toolInfo:getProperty("uuid")
		end
	end
	self.m_goodUuid = goodUuid
	self:initUI()
	self:refreshView()
	--event
	local function onNodeEvent(event)
		if event == "enter" then
			self:onEnter()
		elseif event == "exit" then
			self:onExit()
		end
	end
  	self.ccbNode:registerScriptHandler(onNodeEvent)
  	function onTouch(eventType, x, y)  
        if eventType == "began" then  
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)  
        else  
            return self:onTouchEnded(x, y)  
        end
    end
	local touchif = tolua.cast(self,"cc.CCIFTouchNode")
    if touchif ~= nil then
        local dic1 = CCDictionary:create()
        dic1:setObject(CCBool:create(true),"1")
        touchif:comFunc("setTouchEnabled", dic1)
        -- MyPrint("NewToolNumSelectView:registerScriptTouchHandler")
        touchif:registerScriptTouchHandler(onTouch)
    end
    return true
end

function NewToolNumSelectView:initUI()
	--文本框
	local img = CCLoadSprite:call("createScale9Sprite", "frame_text2.png")  
	img:setAnchorPoint(0.5, 0.5)
	self.m_editBox = cc.EditBox:create(self.m_editNode:getContentSize(), img)  --输入框尺寸，背景图片
	self.m_editBox:setPosition(self.m_editNode:getContentSize().width / 2,self.m_editNode:getContentSize().height / 2)
	self.m_editBox:setAnchorPoint(cc.p(0.5,0.5))
	self.m_editBox:setFontSize(22)
	self.m_editBox:setFontColor(cc.c3b(255,255,255))
	self.m_editBox:setReturnType(cc.KEYBOARD_RETURNTYPE_DONE ) --输入键盘返回类型，done，send，go等
	self.m_editBox:setInputMode(cc.EDITBOX_INPUT_MODE_NUMERIC) --输入模型，如整数类型，URL，电话号码等，会检测是否符合
	-- self.m_editBox:setText("0")
	self.m_editBox:setPlaceHolder(tostring(self.m_minNum))
	if self.m_maxNum <= 0 then
		self.m_editBox:setPlaceHolder("0")
	end 
	self.m_editLastTime = "0"--控制数字输出
	local function editCB (strEventName,pSender)
		if tostring(pSender) == "began" then
			-- sender:selectedAll() --光标进入，选中全部内容
		elseif tostring(pSender) == "ended" then
			-- 当编辑框失去焦点并且键盘消失的时候被调用
		elseif tostring(pSender) == "return" then
			-- 当用户点击编辑框的键盘以外的区域，或者键盘的Return按钮被点击时所调用			
			if self.m_editBox:getText() ~= nil then
				local num = tonumber(self.m_editBox:getText())
				num = math.max(math.min(num, self.m_maxNum), sliderMin)
				self.m_curNum = num
				self.m_controlSlider:setValue(self.m_curNum)
				self:changeTitle(self.m_curNum)
			end
		elseif tostring(pSender) == "changed" then
			if string.len(self.m_editBox:getText()) > 0 and tonumber(self.m_editBox:getText()) == nil then
				self.m_editBox:setText(self.m_editLastTime)
			end
			self.m_editLastTime = self.m_editBox:getText()
			-- 输入内容改变时调用		
			if tonumber(self.m_editBox:getText()) ~= nil then
				local num = tonumber(self.m_editBox:getText())
				num = math.min(num, self.m_maxNum)
				if num >= sliderMin then
					-- num = math.max(math.min(num, self.m_maxNum), sliderMin)
					self.m_curNum = num
					self.m_controlSlider:setValue(self.m_curNum)
					self:changeTitle(self.m_curNum)
				end
			end
		end
	end
	self.m_editBox:registerScriptEditBoxHandler(editCB) --输入框的事件，主要有光标移进去，光标移出来，以及输入内容改变等
	self.m_editNode:addChild(self.m_editBox)
	-- self.m_editBox:setHACenter() --输入的内容锚点为中心
	--滑动条
	local thunmImg = CCLoadSprite:createSprite("huadongtiao1.png")
	local progImg = CCLoadSprite:createSprite( "huadongtiao2.png") 
	local bgImg =  CCLoadSprite:createSprite( "huadongtiao3.png") 
	bgImg:setContentSize(self.m_barNode:getContentSize())
	bgImg:setVisible(false)
	self.m_controlSlider = cc.ControlSlider:create(bgImg,progImg,thunmImg)
	self.m_controlSlider:setAnchorPoint(CCPoint(0.5,0.5))
	self.m_controlSlider:setPosition(CCPoint(self.m_barNode:getContentSize().width / 2,self.m_barNode:getContentSize().height / 2))
	self.m_controlSlider:setEnabled( true )
	self.m_controlSlider:setMinimumValue( self.m_minNum )
	self.m_controlSlider:setMaximumValue( tonumber(self.m_maxNum) )
	--注册
  	local function valueChanged(pSender)
	    if nil == pSender then
	        return
	    end           
	    local pControl = pSender
	    -- print("XXXXXXX:"..pControl:getValue())
	    local changedInt = math.ceil(pControl:getValue())
	    self.m_editBox:setText(tostring(changedInt));
	    self.m_curNum = changedInt
		self:changeTitle(self.m_curNum)
	end
	self.m_controlSlider:addHandleOfControlEvent(valueChanged, 256) 
	self.m_barNode:addChild(self.m_controlSlider)
	--title
	if not self.m_useTitle then
		local para = CCCommonUtilsForLua:getPropById(tostring(self.m_itemId), "para")--100
		local name = CCCommonUtilsForLua:getPropById(tostring(self.m_itemId), "name")--{}经验
		name = getLang(name,para)
		self.m_infoLabel:setString(getLang("104955",name))
	else
		if self.m_useType == ToolType.EquipmentPaper then
			local name = CCCommonUtilsForLua:getPropById(tostring(self.m_itemId), "name")
			self.m_infoLabel:setString(getLang(self.m_useTitle, getLang(name)))
		elseif self.m_useType == ToolType.Gold then
			self.m_infoLabel:setString(getLang(self.m_useTitle))
		else
			if self.m_showChanges and type(self.m_showChanges) == "number" then
				self:changeTitle(self.m_curNum)
			else
				self.m_infoLabel:setString(getLang(self.m_useTitle))
			end
		end
	end
	self.m_numMaxText:setString("/"..tostring(self.m_maxNum))
	if not self.m_useButtonName then
		CCCommonUtilsForLua:setButtonTitle(self.m_useBtn, getLang("169631"))
	else
		CCCommonUtilsForLua:setButtonTitle(self.m_useBtn, getLang(self.m_useButtonName))
	end

	self.m_useBtn:setPositionX(0)
	self.m_btnMax:setVisible(false)
end

function NewToolNumSelectView:refreshView()
	
end

function NewToolNumSelectView:cmdCallBack()

end

function NewToolNumSelectView:onEnter()
	local function onRefresh( ref )
        self:cmdCallBack()
    end
    local t = tolua.cast(self, "cc.Node")
    local handler = t:registerHandler(onRefresh)
    CCSafeNotificationCenter:registerScriptObserver(self, handler, "hero_info_refresh")
end

function NewToolNumSelectView:onExit()
    CCSafeNotificationCenter:unregisterScriptObserver(self, "hero_info_refresh")
end

function NewToolNumSelectView:onTouchBegan(x, y)
	return true
end

function NewToolNumSelectView:onTouchMoved(x, y)
end

function NewToolNumSelectView:onTouchEnded(x, y)
	if touchInside(self.m_touchNode, x, y) == false then
		-- MyPrint("NewToolNumSelectView:onTouchEnded touchInside m_clickArea")
		self.m_editBox:unregisterScriptEditBoxHandler()
		self = tolua.cast(self, "PopupBaseView")
        self:call("closeSelf")						
	elseif touchInside(self.m_subArea, x, y) then
		self:opeSub()
	elseif touchInside(self.m_addArea, x, y) then
		self:opeAdd()
	end
end

function NewToolNumSelectView:opeSub()
	-- local num = self.m_curNum - 1
	-- num = math.max(num, 1)
	-- self.m_curNum = num
	-- MyPrint("NewToolNumSelectView:opeSub m_curNum is "..tostring(self.m_curNum))
	-- self.m_editBox:setString(tostring(self.m_curNum))
end

function NewToolNumSelectView:opeAdd()
	-- local num = self.m_curNum + 1
	-- num = math.min(num, self.m_maxNum)
	-- self.m_curNum = num
	-- MyPrint("NewToolNumSelectView:opeSub m_curNum is "..tostring(self.m_curNum))
	-- self.m_editBox:setString(tostring(self.m_curNum))
end

function NewToolNumSelectView:onUseClick()
	if self.m_useType == ToolType.HeroExp then
		local HeroManager = require("game.hero.HeroManager")
		HeroManager.addHeroExp(tonumber(self.m_target), tostring(self.m_goodUuid), tonumber(self.m_curNum))
		self.m_editBox:unregisterScriptEditBoxHandler()
		self = tolua.cast(self, "PopupBaseView")
        self:call("closeSelf")
		-- HeroManager.addHeroExp(tonumber(self.m_heroId), toolUuid, 1)
	elseif self.m_useType == ToolType.Gold then
		if self.m_messagePosted and self.m_messagePosted ~= "" then
			local function onOK()
				local dict = CCDictionary:create()
		    	dict:setObject( CCInteger:create(self.m_curNum), "num")
		    	CCSafeNotificationCenter:postNotification(self.m_messagePosted,dict)
		    	self.m_editBox:unregisterScriptEditBoxHandler()
				self = tolua.cast(self, "PopupBaseView")
		    	self:call("closeSelf")
			end
			if self.m_messagePosted == AuctionAckGrivePriceNow then
				local function callback() 
					 onOK()
				end
    			local ackTipInfo = _lang_2("176309", tostring(self.m_curNum), self.auctionGoodsName)    -- 176309=您确定花费{0}金币竞价购买{1}吗？
				local func = cc.CallFunc:create(callback)
				local dialog = YesNoDialog:call("showButtonAndGold", ackTipInfo, func, getLang("110031"), self.m_curNum)
			else
				onOK()
			end
		end
	elseif self.m_useType == ToolType.Diamond then
		if self.m_messagePosted and self.m_messagePosted ~= "" then
			local function onOK()
				local dict = CCDictionary:create()
		    	dict:setObject( CCInteger:create(self.m_curNum), "num")
		    	CCSafeNotificationCenter:postNotification(self.m_messagePosted,dict)
		    	self.m_editBox:unregisterScriptEditBoxHandler()
				self = tolua.cast(self, "PopupBaseView")
		    	self:call("closeSelf")
			end
			if self.m_messagePosted == AuctionAckGrivePriceNow then
				local function callback() 
					 onOK()
				end
    			local ackTipInfo = _lang_2("9900436", tostring(self.m_curNum), self.auctionGoodsName)    --9900436=您确定花费{0}钻石竞价购买{1}吗？
				YesNoDialog:show(ackTipInfo, callback) 
			else
				onOK()
			end
	    end
	elseif self.m_useType == ToolType.HeroFragment then
		-- local HeroManager = require("game.hero.HeroManager")
		-- HeroManager.buyHeroFragment(tonumber(self.m_target), tostring(self.m_goodUuid))
		-- self.m_editBox:unregisterScriptEditBoxHandler()
		-- self = tolua.cast(self, "PopupBaseView")
        -- self:call("closeSelf")	
    elseif self.m_useType == ToolType.PrestigeDonate then
    	local tinfo = ToolController:call("getToolInfoByIdForLua", self.m_itemId)
    	if tinfo ~= nil then
	    	local uuid = tinfo:getProperty("uuid")
			local pobj = CCDictionary:create()
			pobj:setObject(CCInteger:create(self.m_curNum), "count")
			pobj:setObject(CCString:create(uuid), "itemUUid")
			if self.m_messagePosted and self.m_messagePosted ~= "" then
	    		CCSafeNotificationCenter:postNotification(self.m_messagePosted,pobj)
	    	end
			self.m_editBox:unregisterScriptEditBoxHandler()
			self = tolua.cast(self, "PopupBaseView")
	        self:call("closeSelf")
	    end
    elseif self.m_useType == ToolType.EquipmentPaper then
    	-- local sliderValue = self.m_controlSlider:getValue()
    	local dict = CCDictionary:create()
    	dict:setObject( CCString:create(self.m_itemId), "id")
    	dict:setObject( CCInteger:create(self.m_curNum), "num")
    	-- MyPrint("NewToolNumSelectView:onUseClick", self.m_messagePosted, dict.id, dict.num)
    	CCSafeNotificationCenter:postNotification(self.m_messagePosted, dict)
    	self.m_editBox:unregisterScriptEditBoxHandler()
		self = tolua.cast(self, "PopupBaseView")
    	self:call("closeSelf")
	end
end

function NewToolNumSelectView:onSubClick()
	--print("NewToolNumSelectView:onSubClick")
	local sliderValue = self.m_controlSlider:getValue() - 1
	sliderValue = math.max(sliderMin,sliderValue)
	self.m_curNum = sliderValue
	self.m_controlSlider:setValue(sliderValue)
	self:changeTitle(self.m_curNum)
end

function NewToolNumSelectView:onAddClick()
	--print("NewToolNumSelectView:onAddClick")
	local sliderValue = self.m_controlSlider:getValue() + 1
	sliderValue = math.min(self.m_maxNum,sliderValue)
	self.m_curNum = sliderValue
	self.m_controlSlider:setValue(sliderValue)
	self:changeTitle(self.m_curNum)
end

function NewToolNumSelectView:changeTitle( num )
	if self.m_useType == ToolType.EquipmentPaper then 
	else
		if self.m_showChanges and type(self.m_showChanges) == "number" then
			self.m_infoLabel:setString(getLang(self.m_useTitle , num * self.m_singlePoint, self.m_showChanges))
		end
	end
end
return NewToolNumSelectView