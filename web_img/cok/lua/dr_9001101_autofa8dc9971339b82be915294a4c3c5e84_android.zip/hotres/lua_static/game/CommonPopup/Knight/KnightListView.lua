local knightIds = {}
local classOpenVec = {}
local KnightListGuideKey = ""
local KNIGHT_LIST_VIEW_UP = "knight.list.view.up"

local KnightListView = class("KnightListView",
	function()
		return PopupBaseView:create() 
	end
)
KnightListView.__index = KnightListView

Drequire("game.CommonPopup.Knight.KnightController")

local KnightBigCell = class("KnightBigCell",
	function()
		return cc.Layer:create() 
	end
)
KnightBigCell.__index = KnightBigCell

local KnightTitleCell = class("KnightTitleCell",
	function()
		return cc.Layer:create() 
	end
)
KnightTitleCell.__index = KnightTitleCell

local knightView
local knightViewOpen = false
local showDescFunc

function KnightListView:create()
	knightView = KnightListView.new()
	if knightView:initView() then return knightView end
end

function KnightListView.getView()
	if knightViewOpen then return knightView end
end

function KnightListView:initView()
	if (self:init(true, 0)) then
		self:setIsHDPanel(true)

		CCLoadSprite:call("doResourceByCommonIndex", 100, true)
		CCLoadSprite:call("doResourceByCommonIndex", 509, true)
		CCLoadSprite:call("doResourceByCommonIndex", 11, true)

		knightIds = {}
		classOpenVec = {}

		self.m_knightId = 0

		local ccbUri = "KnightListView_lua.ccbi"
		local proxy = cc.CCBProxy:create()
		local node = CCBReaderLoad(ccbUri, proxy, self)

		local function onNodeEvent(event)
			Dprint("@@ KnightListView", event)
			if event == "enter" then
				self:onEnter()
			elseif event == "exit" then
				self:onExit()
			elseif event == "cleanup" then
				self:onCleanup()
 			end
		end
		node:registerScriptHandler(onNodeEvent)
		self:addChild(node)

		local nodeSize = node:getContentSize()
		self:setContentSize(nodeSize)

		-- local winSize = cc.Director:sharedDirector():getIFWinSize()
		-- CCCommonUtilsForLua:call("makeBatchBG", self.m_bgNode, winSize, ccp(0.5, 1), 1)

		-- local extH = self:getExtendHeight()
		-- local listSize = self.m_infoList:getContentSize()
		-- self.m_infoList:setPositionY(self.m_infoList:getPositionY() - extH)
		-- self.m_infoList:setContentSize(cc.size(listSize.width, listSize.height + extH))
		self.oldSize = self.m_infoList:getContentSize()
		self.m_tableView = cc.TableView:create(self.oldSize)
		self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
		self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
		self.m_tableView:setDelegate()
		self.m_tableView:registerScriptHandler(function(tab, idx) return self:cellSizeForTable(tab, idx) end, cc.TABLECELL_SIZE_FOR_INDEX)
		self.m_tableView:registerScriptHandler(function(tab, idx) return self:tableCellAtIndex(tab, idx) end, cc.TABLECELL_SIZE_AT_INDEX)
		self.m_tableView:registerScriptHandler(function(tab) return self:numberOfCellsInTableView(tab) end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
		self.m_infoList:addChild(self.m_tableView)

		self.m_waitInterface = nil
		-- KnightTitleController:call("makeKnightList")
		-- self.m_curList = KnightTitleController:call("getInstance"):getProperty("m_knightShowTypeVec")
		--todo
		self.m_curList = KnightTitleController:call("getShowKnightListRank")
		local closeFlag=0
		if (GuideController:call("isInTutorial")) then closeFlag=1 end

		for i = 1, #self.m_curList do
			classOpenVec[#classOpenVec + 1] = closeFlag

			local rank = self.m_curList[i]
			--todo
			knightIds[rank] = KnightTitleController:call("getShowKnightIdsByRank", rank)
		end

		self.m_openNum = 0

		local touchLayer = cc.Layer:create()
		self:addChild(touchLayer)

		local function touchHandle( eventType, x, y )
			print("touchHandle", eventType, x, y)
			if eventType == "began" then
				return self:onTouchBegan(x, y)
			elseif eventType == "moved" then
			
			else
				self:onTouchEnded(x, y)
			end
		end
		touchLayer:registerScriptTouchHandler(touchHandle)
		touchLayer:setTouchEnabled(true)
		touchLayer:setSwallowsTouches(false)

		self:initKnightStorage()
		
		self.m_descNode:setVisible(false)
		showDescFunc = function(beShow, kid, x, y)
			self:showDescNode(beShow, kid, x, y)
		end

		return true
	end

	return false
end

function KnightListView:initKnightStorage()
	-- body
	self.storageView = Drequire("game.CommonPopup.Knight.KnightStorage"):create()
	self.m_pStorage:addChild(self.storageView)

	if CCCommonUtilsForLua:isFunOpenByKey("dragon_words_activate_memory") then
		self.storageView:setVisible(true)
	else
		self.storageView:setVisible(false)
	end

	self.storageView:setScale(0.8)

	if self.storageView:isStorageShow()  then 
		self.m_curKTouchNode:setVisible(false)
		self.m_msgLabel:setVisible(false)
		self.m_itemNode:setVisible(false)
		self.m_timeLabel1:setVisible(false)
		self.m_timeLabel2:setVisible(false)
	else
		self.m_curKTouchNode:setVisible(true)
		self.m_msgLabel:setVisible(true)
		self.m_itemNode:setVisible(true)
		self.m_timeLabel1:setVisible(true)
		self.m_timeLabel2:setVisible(true)
	end
end

function KnightListView:showDescNode(beShow, knightId, x, y)
    if beShow and knightId then
        dump(" showDescNode x:"..x.." y:"..y.." knightId is: "..knightId)
        self.m_descNode:setVisible(true)
        self.m_desContenNode:removeAllChildren()

        local kInfo = KnightTitleController:call("getKnightInfoById", knightId)
        local name = kInfo:call("getName")
        self.m_desNameTxt:setString(getLang(name))

        local showDias = kInfo:getProperty("showDias")
        dump(showDias, "showDias")
        local values = kInfo:getProperty("values")
        dump(values, "values")
        local maxWidth = 320
        local labelH = 0
        local curY = 0
        local labelLeftX = 230
        for i = 1, 10 do
            if (showDias[i] and values[i]) then
                local diaLabel = cc.Label:createWithSystemFont(getLang(showDias[i]), "Helvetica", 22, cc.size(maxWidth,0))
                diaLabel:setAnchorPoint(cc.p(0, 1))
                diaLabel:setColor(cc.c3b(197, 152, 15))
                local diaSize = diaLabel:getContentSize()
                self.m_desContenNode:addChild(diaLabel)
                diaLabel:setPosition(cc.p(0 - labelLeftX, curY))

                local valueInfo = ""
                local pf = kInfo:call("getEffFormatByOrd", i)
                local pm = kInfo:call("getEffPMByOrd", i)
                if (pf == "") then
                    valueInfo = valueInfo .. pm .. tostring(values[i]) .. pf
                else
                    valueInfo = valueInfo .. pm .. string.format("%.2f", values[i]) .. pf
                end
                local valLabel = cc.Label:createWithSystemFont(valueInfo, "Helvetica", 22, cc.size(0,0), cc.TEXT_ALIGNMENT_RIGHT)
                valLabel:setAnchorPoint(cc.p(1, 1))
                valLabel:setColor(cc.c3b(65, 183, 40))
                self.m_desContenNode:addChild(valLabel)
                valLabel:setPosition(cc.p(labelLeftX, curY))

                curY = curY - diaSize.height - 10
            else
                break
            end
        end
        local height = 0 - curY + 40 + 20
		self.m_desBg:setPreferredSize(cc.size(500, height))
        self.m_descNode:setPositionY(y + height - 120)
    else
        self.m_descNode:setVisible(false)
    end
end

function KnightListView:onEnterFrame(dt)
	local kInfo = KnightTitleController:call("getCurrentOnInfo")
	if (not kInfo) then
		self.m_timeLabel1:setString("")
		self.m_timeLabel2:setString("")
		return
	end

	local now = GlobalData:call("getTimeStamp")
	local left = kInfo:call("getEndTime") - now
	if (left > 0 and kInfo:call("getType") == 3) then
		--160515 契约时间:{0}
		self.m_timeLabel1:setString(getLang("160515", ""))
		self.m_timeLabel2:setString(format_time(left))

		local w1 = self.m_timeLabel1:getContentSize().width * self.m_timeLabel1:getScale()
		local w2 = self.m_timeLabel2:getContentSize().width * self.m_timeLabel2:getScale()
		self.m_timeLabel1:setPositionX(-(w1 + w2) * 0.5)
		self.m_timeLabel2:setPositionX(-(w1 + w2) * 0.5 + w1)
	else
		self.m_timeLabel1:setString("")
		self.m_timeLabel2:setString("")
	end
end

function KnightListView:scheduleUpdate()
	local function updatefunc(dt) self:onEnterFrame(dt) end 
	self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(updatefunc, 1.0, false)
end

function KnightListView:unscheduleUpdate()
	if self.entry then
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
		self.entry = nil
	end
end

function KnightListView:onEnter()

	Dprint("@@ KnightListView:onEnter")

	UIComponent:call("showEquipOrBagBtn", 3)
	local function callback1(pObj) self:updateInfoOnTouch(pObj) end
	local handler1 = self:registerHandler(callback1)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, KNIGHT_LIST_VIEW_UP)
	self:setTitleName(getLang("160297"))
	self.m_tableView:setTouchEnabled(false)
	self.m_tableView:setTouchEnabled(true)
	self:updateCurKnight()

	if (self.m_openNum == 0) then
		-- self.m_putonId = KnightTitleController:call("getInstance"):getProperty("m_curKnightTitleId")
		self.m_putonId = KnightTitleController:call("getCurrentOnId")
		self.m_tableView:reloadData()
	else
		local miny = self.m_tableView:minContainerOffset().y
		local pos = self.m_tableView:getContentOffset()
		self.m_tableView:reloadData()

		local mincurry = self.m_tableView:minContainerOffset().y
		pos.y = pos.y - miny + mincurry
		self.m_tableView:setContentOffset(pos)
		-- self.m_putonId = KnightTitleController:call("getInstance"):getProperty("m_curKnightTitleId")
		self.m_putonId = KnightTitleController:call("getCurrentOnId")
	end

	self.m_openNum = self.m_openNum + 1

	self:scheduleUpdate()
	self:onEnterFrame(0)

	knightViewOpen = true

	local function onRefresh(ref)
		-- body
		local ref = tolua.cast(ref, "CCString")
		if ref then 
			local strId = ref:getCString()
			Dprint("@@ onRefresh KnightListView ", strId)

			local titleView = Drequire("game.CommonPopup.Knight.KnightTitileView"):create(tonumber(strId))
			PopupViewController:addPopupInView(titleView)
		end
	end

	local handler = self:registerHandler(onRefresh)
	local key = KnightController.getInstance().m_Knight_Click_NotifyKey
    CCSafeNotificationCenter:registerScriptObserver(self, handler, key)
    self.storageView:onRefresh()


    local function onStorageVisibleChange(ref)
    	if self.storageView:isStorageShow()  then 
			self.m_curKTouchNode:setVisible(false)
			self.m_msgLabel:setVisible(false)
			self.m_itemNode:setVisible(false)
			self.m_timeLabel1:setVisible(false)
			self.m_timeLabel2:setVisible(false)
		else
			self.m_curKTouchNode:setVisible(true)
			self.m_msgLabel:setVisible(true)
			self.m_itemNode:setVisible(true)
			self.m_timeLabel1:setVisible(true)
			self.m_timeLabel2:setVisible(true)
		end
    end
    local handler2= self:registerHandler(onStorageVisibleChange)
    key = KnightController.getInstance().m_Knight_VisibleChange_NotifyKey
    CCSafeNotificationCenter:registerScriptObserver(self, handler2, key)
end

function KnightListView:onExit()

	Dprint("@@ KnightListView:onExit")
	if (self.m_waitInterface) then
		self.m_waitInterface:call("remove")
		self.m_waitInterface = nil
	end
	CCSafeNotificationCenter:unregisterScriptObserver(self, KNIGHT_LIST_VIEW_UP)
	UIComponent:call("showEquipOrBagBtn", 0)
	self:unscheduleUpdate()

	local key = KnightController.getInstance().m_Knight_Click_NotifyKey
    CCSafeNotificationCenter:unregisterScriptObserver(self, key)

    key = KnightController.getInstance().m_Knight_VisibleChange_NotifyKey
    CCSafeNotificationCenter:unregisterScriptObserver(self, key)

    KnightController.getInstance():saveData()

	knightViewOpen = false
end

function KnightListView:onCleanup()
	--self = nil
end

function KnightListView:showRank(rank)
	if (self.m_curList[rank] == nil) then return end

	if (#classOpenVec < #self.m_curList) then return end

	self.m_tableView:reloadData()

	local preH = 0
	local i = 1
	while(self.m_curList[i] ~= rank) 
	do
		if (CCCommonUtilsForLua:isIosAndroidPad()) then
			preH = preH + 150 + (#knightIds[self.m_curList[i]] * (340 + 78))
		else
			preH = preH + 70 + (#knightIds[self.m_curList[i]] * 210)
		end

		i = i + 1
	end

	local totalH = self.m_tableView:getContentSize().height
	local viewH = self.m_infoList:getContentSize().height
	self.m_tableView:setContentOffset(ccp(0, math.max(viewH - totalH, math.min(0, -(totalH - preH - viewH)))))	
end

function KnightListView:updateInfoOnTouch(pObj)
	local miny = self.m_tableView:minContainerOffset().y
	local pos = self.m_tableView:getContentOffset()
	self.m_tableView:reloadData()

	local mincurry = self.m_tableView:minContainerOffset().y
	pos.y = pos.y - miny + mincurry
	self.m_tableView:setContentOffset(pos)
end

function KnightListView:updateCurKnight(param)
	self.m_itemNode:removeAllChildren()
	self.m_titleLabel:setString("")

	--local curKid = KnightTitleController:call("getInstance"):getProperty("m_curKnightTitleId")
	local curInfo = KnightTitleController:call("getCurrentOnInfo")
	if (curInfo) then
		self.m_glowNode:setVisible(true)
		self.m_msgLabel:setString("")
		self.m_curKTouchNode:setVisible(true)
		self.m_knightNode:setVisible(true)

		if self.storageView:isStorageShow()  then 
			self.m_curKTouchNode:setVisible(false)
		else
			self.m_curKTouchNode:setVisible(true)
		end

		-- local kInfos = KnightTitleController:call("getInstance"):getProperty("KnightTitleInfoMap")
		-- local kInfo = kInfos[curKid]
		-- local name = kInfo:getProperty("name")
		-- self.m_titleLabel:setString(getLang(name))
		local classify = curInfo:call("getClassify")
		local rankName = KnightTitleController:call("getRankName", classify)
		local infoName = curInfo:call("getName") 
		self.m_titleLabel:setString(getLang(rankName) .. ":" .. getLang(infoName) .. "  ".. getLang("169629"))

		local cellW = 60
		-- local mateVec = kInfo:getProperty("mateVec")
		local mateVec = curInfo:getProperty("mateVec")
		if (#mateVec == 4) then
			cellW = 100
		elseif (#mateVec < 4) then
			cellW = 110
		end

		local halfNum = math.floor(#mateVec / 2)
		if (#mateVec % 2 == 0) then
			halfNum = halfNum - 0.5
		end

		local dt = 0.2
		if (#mateVec <= 3) then dt = 0.4 end

		for i = 1, #mateVec do
			local iconStr = CCCommonUtilsForLua:call("getPropById", tostring(mateVec[i]), "icon")
			iconStr = iconStr .. "_a" .. ".png"
			local icon = CCLoadSprite:call("createSprite", iconStr, CCLoadSpriteType_GOODS)
			icon:setOpacity(0)
			CCCommonUtilsForLua:setSpriteMaxSize(icon, 90, true)
			icon:setPosition((i - halfNum - 1) * cellW, 0)
			self.m_itemNode:addChild(icon)

			local delayT = cc.DelayTime:create((i - 1) * dt)
			local fadeIn = cc.FadeIn:create(0.4)
			icon:runAction(cc.Sequence:create(delayT, fadeIn))
		end

		self.m_infoList:setContentSize(self.oldSize)
	else
		self.m_msgLabel:setString(getLang("160478"))
		self.m_glowNode:setVisible(false)
	end

	self.m_tableView:setViewSize(self.m_infoList:getContentSize())
end

function KnightListView:getGuideNode(key)
	KnightListGuideKey = ""
	if (key == "KL_First") then
		local cell = self.m_tableView:cellAtIndex(0)
		if (cell) then
			local node = cell:getChildByTag(666)
			if (node) then
				KnightListGuideKey = key
				return node:getGuideNode()
			end
		end
	end
end

function KnightListView:onTouchBegan(x, y)
	local visible = self.m_curKTouchNode:isVisible()
	local touch = isTouchInside(self.m_curKTouchNode, x, y)
	if (visible and touch) then
		return true
	end

	if self.storageView:isVisible() and self.storageView:onTouchBegan(x,y) then
		return true
	end

	return false
end

function KnightListView:onTouchEnded(x, y)


	if self.storageView:isVisible() and self.storageView:onTouchEnded(x,y) then
		return true
	end

	local visible = self.m_curKTouchNode:isVisible()
	local touch = isTouchInside(self.m_curKTouchNode, x, y)
	if (visible and touch) then
		--local curKid = KnightTitleController:call("getInstance"):getProperty("m_curKnightTitleId")
		local curKid = KnightTitleController:call("getCurrentOnId")
		if (curKid > 0) then
			Dprint("@@ onTouchEnded", curKid)
			local view = Drequire("game.CommonPopup.Knight.KnightTitileView"):create(curKid)
			PopupViewController:addPopupInView(view)
		end
	end
end

function KnightListView:onHelpBtnClick()
	if (not isIOS()) then
		GlobalData:call("shared"):setProperty("isBind", true)
	end
	FaqHelper:call("showSingleFAQ", "45224")
end

function KnightListView:cellSizeForTable(table, idx)
	if (idx >= #self.m_curList) then return 0, 0 end
	if (classOpenVec[idx + 1] ~= 0) then
		-- local instance = KnightTitleController:call("getInstance")
		-- local map = instance:getProperty("m_knightShowTypeMap")
		local t = knightIds[self.m_curList[idx + 1]]
		local num = #t
		if (CCCommonUtilsForLua:isIosAndroidPad()) then
			return 1530, 150 + num * (340 + 78)
		else
			return 640, 70 + num * 210
		end
	else
		if (CCCommonUtilsForLua:isIosAndroidPad()) then
			return 1530, 150
		else
			return 640, 70
		end
	end
end

function KnightListView:tableCellAtIndex(table, idx)
	if (idx >= #self.m_curList) then return end

	local cell = table:dequeueCell()
	if (cell) then
		local node = cell:getChildByTag(666)
		if node then node:setData(self.m_curList[idx + 1], classOpenVec[idx + 1], idx + 1) end
	else
		cell = cc.TableViewCell:create()
		local node = KnightBigCell:create(self.m_curList[idx + 1], classOpenVec[idx + 1], idx + 1, self.m_infoList)
		node:setTag(666)
		cell:addChild(node)
	end

	return cell
end

function KnightListView:numberOfCellsInTableView(table)
	return #self.m_curList or 0
end

function KnightListView:isShowMsg(x, y)
	if (self.m_desNode:isVisible()) then
		if (isTouchInside(self.m_desNode, x, y)) then
			return true
		end
		self.m_desNode:setVisible(false)
		return true
	else
		return false
	end
end

function KnightListView:onShowMsg(knightId, pt)
	local fontSize = 22
	local sc = 1.0

	-- local kInfos = KnightTitleController:call("getInstance"):getProperty("KnightTitleInfoMap")
	-- local kInfo = kInfos[knightId]
	local kInfo = KnightTitleController:call("getKnightInfoById", knightId)
	if not kInfo then return end

	--显示属性
	local curY = 0
	local maxW1 = 0
	local maxW2 = 0
	local dimWidth = 350 * sc
	self.m_disLabelNode:removeAllChildren()
	self.m_disValueNode:removeAllChildren()

	--local name = kInfo:getProperty("name")
	local name = kInfo:call("getName")
	self.m_desName:setString(getLang(name))

	local showDias = kInfo:getProperty("showDias")
	--dump(showDias, "showDias")
	local values = kInfo:getProperty("values")
	--dump(values, "values")
	for i = 1, 30 do
		if (showDias[i] and values[i]) then
			local diaLabel = CCLabelIF:call("create8", getLang(showDias[i]), fontSize, cc.size(0, 0), 0, 0)
			diaLabel:call("setAnchorPoint", ccp(0, 1))
			diaLabel:call("setColor", cc.c3b(197, 152, 15))

			local labelH = diaLabel:call("getContentSize").height * diaLabel:call("getOriginScaleY")
			local labelW1 = diaLabel:call("getContentSize").width * diaLabel:call("getOriginScaleX")
			if (labelW1 > dimWidth) then
				diaLabel:call("setDimensions", cc.size(dimWidth, 0))
				labelH = diaLabel:call("getContentSize").height * diaLabel:call("getOriginScaleY")
				labelW1 = diaLabel:call("getContentSize").width * diaLabel:call("getOriginScaleX")
			end

			tolua.cast(diaLabel, "cc.Node"):setPosition(0, curY)
			self.m_disLabelNode:addChild(tolua.cast(diaLabel, "cc.Node"))

			labelH = labelH + 10
			maxW1 = math.max(maxW1, labelW1)

			local valueInfo = ""
			local pf = kInfo:call("getEffFormatByOrd", i)
			local pm = kInfo:call("getEffPMByOrd", i)
			if (pf == "") then
				valueInfo = valueInfo .. pm .. tostring(values[i]) .. pf .. "\n"
			else
				valueInfo = valueInfo .. pm .. string.format("%.2f", values[i]) .. pf .. "\n"
			end

			local valLabel = CCLabelIF:call("create8", valueInfo, fontSize, cc.size(0, 0), 2, 0)
			valLabel:call("setAnchorPoint", ccp(1, 1))
			valLabel:call("setColor", cc.c3b(65, 183, 40))
			
			local labelW2 = valLabel:call("getContentSize").width * valLabel:call("getOriginScaleX")
			maxW2 = math.max(maxW2, labelW2)

			tolua.cast(valLabel, "cc.Node"):setPosition(0, curY)
			self.m_disValueNode:addChild(tolua.cast(valLabel, "cc.Node"))

			curY = curY - labelH
		else
			break
		end
	end

	local funShowDias = kInfo:getProperty("funShowDias")
	--dump(funShowDias, "funShowDias")
	local funValues = kInfo:getProperty("funValues")
	--dump(funValues, "funValues")
	for i = 1, 7 do
		if (funShowDias[i] and funValues[i]) then
			local diaLabel = CCLabelIF:call("create8", getLang(funShowDias[i]), fontSize, cc.size(0, 0), 0, 0)
			tolua.cast(diaLabel, "cc.Node"):setPosition(0, curY)
			diaLabel:call("setAnchorPoint", ccp(0, 1))
			diaLabel:call("setColor", cc.c3b(197, 152, 15))
			self.m_disLabelNode:addChild(tolua.cast(diaLabel, "cc.Node"))

			local labelH = diaLabel:call("getContentSize").height * diaLabel:call("getOriginScaleY")
			local labelW1 = diaLabel:call("getContentSize").width * diaLabel:call("getOriginScaleX")
			if (labelW1 > dimWidth) then
				diaLabel:call("setDimensions", cc.size(dimWidth, 0))
				labelH = diaLabel:call("getContentSize").height * diaLabel:call("getOriginScaleY")
				labelW1 = diaLabel:call("getContentSize").width * diaLabel:call("getOriginScaleX")
			end
			maxW1 = math.max(maxW1, labelW1)

			local valueInfo = ""
			local pf = kInfo:call("getFunFormatByOrd", i)
			local pm = kInfo:call("getFunPMByOrd", i)
			if (#funValues > 0) then
				if (pf == "") then
					valueInfo = valueInfo .. pm .. tostring(funValues[i]) .. pf .. "\n"
				else
					valueInfo = valueInfo .. pm .. string.format("%.2f", funValues[i]) .. pf .. "\n"
				end
			end

			local valLabel = CCLabelIF:call("create8", valueInfo, fontSize, cc.size(0, 0), 2, 0)
			valLabel:call("setAnchorPoint", ccp(1, 1))
			valLabel:call("setColor", cc.c3b(65, 183, 40))
			tolua.cast(valLabel, "cc.Node"):setPosition(0, curY)
			self.m_disValueNode:addChild(tolua.cast(valLabel, "cc.Node"))

			local labelW2 = valLabel:call("getContentSize").width * valLabel:call("getOriginScaleX")
			maxW2 = math.max(maxW2, labelW2)

			curY = curY - labelH
		else
			break
		end
	end

	local sumW = 40 + maxW1 + 50 + maxW2 + 40
	local sumH = 40 + 30 + (-curY) + 30 + 40
	self.m_desNode:setContentSize(cc.size(sumW, sumH))
	self.m_desbg:setPreferredSize(cc.size(sumW, sumH))
	self.m_desbg:setPosition(sumW, 0)

	self.m_desBottomNode:setPosition(sumW / 2, 60)
	self.m_disLabelNode:setPosition(40, 60 - curY)
	self.m_disValueNode:setPosition(sumW - 40, 60 - curY)
	self.m_desTitleNode:setPosition(sumW / 2, 80 - curY)

	local lw = self.m_desLine1:getContentSize().width
	local lpro = sumW * 0.8 / lw
	self.m_desLine1:setScaleX(lpro)
	self.m_desLine2:setScaleX(lpro)
	self.m_desNode:setVisible(true)

	local tmpPt = self.m_desNode:getParent():convertToNodeSpace(pt)
	local screenSize = cc.Director:sharedDirector():getIFWinSize()
	if (pt.y > screenSize.height / 2) then
		tmpPt.y = tmpPt.y - self.m_desNode:getContentSize().height
	end
	self.m_desNode:setPosition(tmpPt)
end

------------------------KnightBigCell-----------------------------

function KnightBigCell:create(itemId, _type, idx, touchNode)
	local node = KnightBigCell.new()
	if (node:initNode(itemId, _type, idx, touchNode)) then
		return node
	end
end

function KnightBigCell:initNode(itemId, _type, idx, touchNode)
	local ccbUri = "KnightBigCell_lua.ccbi"
	local proxy = cc.CCBProxy:create()
	local node = CCBReaderLoad(ccbUri, proxy, self)
	self:addChild(node)
	self.m_titleLabel:setColor(cc.c3b(184, 172, 132))
	--self.m_floorLabel:setFntFile("Arial_Bold_Border.fnt")
	self.m_touchNode = touchNode
	self:setData(itemId, _type, idx)

	local touchLayer = cc.Layer:create()
	self:addChild(touchLayer)

	local function touchHandle( eventType, x, y )
		print("touchHandle", eventType, x, y)
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
			self:onTouchMoved(x, y)
		else
			self:onTouchEnded(x, y)
		end
	end
	touchLayer:registerScriptTouchHandler(touchHandle)
	touchLayer:setTouchEnabled(true)
	touchLayer:setSwallowsTouches(false)

	return true
end

function KnightBigCell:getGuideNode()
	local cellVec = self.m_listNode:getChildren()
	if (#cellVec > 0) then
		for i = 1, #cellVec do
			local cell = cellVec[i]
			if (cell and cell:getTag() == 1) then
				return cell.m_bgNode
			end
		end
	end 
end

function KnightBigCell:setData(itemId, _type, idx)
	self.m_itemId = itemId
	self.m_type = _type
	self.m_idx = idx

	-- local instance = KnightTitleController:call("getInstance")
	-- local map = instance:getProperty("m_knightShowTypeMap")
	-- local sidVec = map[itemId]
	-- if (#sidVec > 0) then
	-- 	local kid = sidVec[1]
	-- 	local kInfos = instance:getProperty("KnightTitleInfoMap")
	-- 	local kInfo = kInfos[kid]
	-- 	local classifyName = kInfo:getProperty("classifyName")
	-- 	self.m_titleLabel:setString(getLang(classifyName))
	-- end

	local rankName = KnightTitleController:call("getRankName", itemId)
	self.m_titleLabel:setString(getLang(rankName))

	self.m_listNode:removeAllChildren()

	local sidVec = knightIds[itemId]
	local curY = 0
	if (self.m_type == 0) then 
		self.m_jiantouSpr:setRotation(0)
	else
		self.m_jiantouSpr:setRotation(90)
		if (CCCommonUtilsForLua:call("isFlip")) then
			self.m_jiantouSpr:setRotation(-90)
		end
		for i = 1, #sidVec do
			local cell = KnightTitleCell:create(sidVec[i])
			if cell then
				cell:setTag(i)
				cell:setPosition(0, curY)
				self.m_listNode:addChild(cell)

				if (CCCommonUtilsForLua:isIosAndroidPad()) then
					curY = curY - 340 - 78
				else
					curY = curY - 210
				end
			end
		end
	end

	self.m_mainNode:setPositionY(70 + math.abs(curY))
	if (CCCommonUtilsForLua:isIosAndroidPad()) then
		self.m_mainNode:setPositionY(150 + math.abs(curY))
	end
end

function KnightBigCell:onTouchBegan(x, y)
	self.m_touchPoint = ccp(x, y)

	if (not isTouchInside(self.m_touchNode, x, y)) then
		return false
	end

	if (isTouchInside(self.m_myTouchNode, x, y)) then
		return true
	else
		local cellVec = self.m_listNode:getChildren()
		if (#cellVec > 0) then
			for i = 1, #cellVec do
				local cell = cellVec[i]
				if (cell and cell:isTouchInNode(x, y, self.m_touchPoint)) then
					cell:onTouchBegan(x, y)
					return true
				end
			end
		end
	end

	return false
end

function KnightBigCell:onTouchMoved(x, y)
	local cellVec = self.m_listNode:getChildren()
	if (#cellVec > 0) then
		for i = 1, #cellVec do
			local cell = cellVec[i]
			if cell then
				cell:onTouchMoved(x, y)
			end
		end
	end
end

function KnightBigCell:onTouchEnded(x, y)
	showDescFunc(false)

	local mv = y - self.m_touchPoint.y
	if (math.abs(mv) > 20) then return end

	local cellVec = self.m_listNode:getChildren()
	if (#cellVec) then
		for i = 1, #cellVec do
			local cell = cellVec[i]
			if (cell and cell:isTouchInNode(x, y)) then
				cell:onTouchEnded(x, y)
				return
			end
		end
	end

	if (self.m_type == 0) then
		self.m_type = 1
		classOpenVec[self.m_idx] = self.m_type
		self:onClickOpen(90)
		CCSafeNotificationCenter:postNotification(KNIGHT_LIST_VIEW_UP)
	else
		self.m_type = 0
		classOpenVec[self.m_idx] = self.m_type
		self:onClickOpen(0)
		CCSafeNotificationCenter:postNotification(KNIGHT_LIST_VIEW_UP)
	end
end

function KnightBigCell:onClickOpen(ration)
	if (CCCommonUtilsForLua:call("isFlip")) then
		ration = ration * (-1)
	end
	local rotateto = cc.RotateTo:create(0.2, ration)
	self.m_jiantouSpr:runAction(rotateto)
end


--------------------------KnightTitleCell-------------------------------

function KnightTitleCell:create(knightId)
	local node = KnightTitleCell.new()
	if (node:initNode(knightId)) then return node end
end

-- local haha = true

function KnightTitleCell:initNode(knightId)
	self.m_knightId = knightId

	local proxy = cc.CCBProxy:create()
	local ccbUri = "KnightListCell_lua.ccbi"
	local node = CCBReaderLoad(ccbUri, proxy, self)

	local function onNodeEvent(event)
		if event == "enter" then
			self:onEnter()
		elseif event == "exit" then
			self:onExit()
		end
	end
	node:registerScriptHandler(onNodeEvent)

	self:addChild(node)
	self.m_lockSpr:setVisible(false)

	local nodeSize = node:getContentSize()
	self:setContentSize(nodeSize)

	-- local instance = KnightTitleController:call("getInstance")
	-- local kInfos = instance:getProperty("KnightTitleInfoMap")
	-- local kInfo = kInfos[self.m_knightId]
	local kInfo = KnightTitleController:call("getKnightInfoById", knightId)
	if not kInfo then return false end

	local name = getLang(kInfo:call("getName"))
	--龙语偏向
	local tag = CCCommonUtilsForLua:getPropByIdGroup("dragon_words", tostring(knightId), "tag")
	local temp = name
	if tag ~= "" then
		temp = "(" .. getLang(tag) .. ")" .. name
	end
	self.m_titleLabel:setString(temp)
	self.m_titleLabel:setVisible(false)

	self:replaceRichText(self.m_titleLabel, name, tag)

	self.m_mateNode:removeAllChildren()

	local islock = false
	self.m_msgLabel:setColor(cc.c3b(235, 146, 0))

	local kType = kInfo:call("getType")
	local isUnlock = true
	if kType == 2 then --上古
		isUnlock = FunOpenController:isUnlock("fun_dragonStone2")
	else
		isUnlock = FunOpenController:isUnlock("fun_dragonStone")
	end

	if (not kInfo:call("isBuildLvConditionOkToUnlock")) or (not isUnlock) then
		islock = true
		self.m_lockSpr:setVisible(true)
		self.m_msgLabel:setColor(cc.c3b(180, 21, 21))
	end
	self.m_msgLabel:setString("")
	self.m_markSpr:setVisible(false)

	local itemId = kInfo:call("getItemId")
	local curKnightTitleId = KnightTitleController:call("getCurrentOnId")
	if (itemId == curKnightTitleId) then
		self.m_markSpr:setVisible(true)
	end

	if (kType == 2) then
		self.m_msgLabel:setString(getLang("160330"))
	elseif (kType == 3) then
		self.m_msgLabel:setString(getLang("160520"))
	end

	local cellW = 100
	local mateVec = kInfo:getProperty("mateVec")
	--dump(mateVec, "mateVec")
	if (#mateVec == 4) then
		cellW = 100
	elseif (#mateVec < 4) then
		cellW = 110
	end

	if (CCCommonUtilsForLua:isIosAndroidPad()) then
		cellW = cellW * 2
	end

	local bgSize = self.m_bgNode:getContentSize()
	local startX = (bgSize.width - #mateVec * cellW) / 2 + cellW / 2

	for i = 1, #mateVec do
		local node = cc.Node:create()
		local bedgeId = mateVec[i]

		local info = ToolController:call("getToolInfoByIdForLua", bedgeId)
		local iconStr = CCCommonUtilsForLua:call("getIcon", tostring(bedgeId))

		if (kInfo:call("getType") == 2 or kInfo:call("getType") == 3) then --消耗石头
			iconStr = CCCommonUtilsForLua:call("getPropById", tostring(bedgeId), "icon")
			iconStr = iconStr .. "_b" .. ".png"
		end

		local icon = CCLoadSprite:call("createSprite", iconStr, CCLoadSpriteType_GOODS)
		if (kInfo:call("getType") == 2 or kInfo:call("getType") == 3) then
			CCCommonUtilsForLua:setSpriteMaxSize(icon, 80, true)
		else
			CCCommonUtilsForLua:setSpriteMaxSize(icon, 90, true)
		end

		node:addChild(icon)

		local para4 = info:getProperty("para4")
		--MyPrint("para4", getLang(para4), startX)
		local label = CCLabelIF:call("create8", getLang(para4), 24, cc.size(0, 0), 1, 1)
		label:call("setColor", cc.c3b(235, 146, 0))
		node:setPosition((i - 1) * cellW + startX, 0)
		self.m_mateNode:addChild(node)

		if CCCommonUtilsForLua:isIosAndroidPad() then node:setScale(1.5) end

		if (islock or info:call("getCNT") <= 0) then
			if (kInfo:call("getType") == 1) then
				CCCommonUtilsForLua:setSpriteGray(icon, true)
				label:call("setColor", cc.c3b(255, 255, 255))
			elseif (kInfo:call("getType") == 2) then
				if (kInfo:call("getBeUnlocked") == false) then
					CCCommonUtilsForLua:setSpriteGray(icon, true)
					label:call("setColor", cc.c3b(255, 255, 255))
				end
			elseif (kInfo:call("getType") == 3) then
				local endTime = kInfo:call("getEndTime")
				local now = GlobalData:call("getTimeStamp")
				if (endTime < now) then
					CCCommonUtilsForLua:setSpriteGray(icon, true)
					label:call("setColor", cc.c3b(255, 255, 255))
				end
			end
		else
			local endTime = kInfo:call("getEndTime")
			local now = GlobalData:call("getTimeStamp")
			local _type = kInfo:call("getType")
			local visible = self.m_markSpr:isVisible()
			if (_type == 2 and (not visible) and kInfo:call("getBeUnlocked") == false)
				or (_type == 3 and (not visible) and endTime < now) then
				local fadeTo1 = cc.FadeTo:create(0.8, 120)
				local fadeTo2 = cc.FadeTo:create(0.8, 255)
				local seq = cc.Sequence:create(fadeTo1, fadeTo2)
				icon:runAction(cc.RepeatForever:create(seq))
			end
		end

		tolua.cast(label, "cc.Node"):setPosition(0, -60)
		node:addChild(tolua.cast(label, "cc.Node"))
	end
	--getOriginScaleX
	local tagPox = self.m_titleLabel:getContentSize().width * self.m_titleLabel:getScaleX()+20
	local sumW = tagPox + self.m_msgLabel:getContentSize().width * self.m_msgLabel:getScaleX()
	local newPox = self.m_bgNode:getContentSize().width / 2 - sumW / 2 + 30
	self.richText:setPositionX(newPox)
	self.m_msgLabel:setPositionX(newPox + tagPox)

	-- if haha then
	-- 	local node = cc.Node:create()
	-- 	self:addChild(node)
	-- 	local function callback() 
	-- 		local view = KnightListView.getView()
	-- 		if view then
	-- 			local winSize = cc.Director:sharedDirector():getIFWinSize()
	-- 			local tmp = ccp(self.m_mateNode:getPositionX() + winSize.width * 3 / 4, self.m_mateNode:getPositionY())
	-- 			local pt = self.m_mateNode:getParent():convertToWorldSpace(tmp)
	-- 			view:onShowMsg(self.m_knightId, pt)
	-- 		end
	-- 	end
	-- 	performWithDelay(node, callback, 2.0)

	-- 	haha = false
	-- end

	return true
end

function KnightTitleCell:replaceRichText(originText, name, tag)
	local x, y = originText:getPosition()
	local anchor = originText:getAnchorPoint()
	local isPad = CCCommonUtilsForLua:isIosAndroidPad()
	local fontSize = isPad and 44 or 22
	local width = isPad and 1536 or 640
    local parent = originText:getParent()

	local hyperText = "<s " .. fontSize .. "><c eb9200ff>" .. "(" .. getLang(tag) .. ")" .. "<c ffffffff>" .. name
	self.richText = IFHyperlinkText:call("create", hyperText, cc.size(width,0), false, false)
    self.richText:setAnchorPoint(anchor)
    self.richText:setPosition(x, y)
    parent:addChild(self.richText)
end

function KnightTitleCell:onEnterFrame(dt)
	local kInfo = KnightTitleController:call("getKnightInfoById", self.m_knightId)
	if (not kInfo) then
		self.m_timeLabel1:setString("")
		self.m_timeLabel2:setString("")
		return
	end

	local now = GlobalData:call("getTimeStamp")
	local left = kInfo:call("getEndTime") - now
	if (left > 0 and kInfo:call("getType") == 3) then
		--160515 契约时间:{0}
		self.m_timeLabel1:setString(getLang("160515", ""))
		self.m_timeLabel2:setString(format_time(left))

		local w1 = self.m_timeLabel1:getContentSize().width * self.m_timeLabel1:getScale()
		local w2 = self.m_timeLabel2:getContentSize().width * self.m_timeLabel2:getScale()
		self.m_timeLabel1:setPositionX(-(w1 + w2) * 0.5)
		self.m_timeLabel2:setPositionX(-(w1 + w2) * 0.5 + w1)

		self.m_mateNode:setPositionY(86.6)
		if (CCCommonUtilsForLua:isIosAndroidPad()) then
			self.m_mateNode:setPositionY(-20.0)
		end
	else
		self.m_timeLabel1:setString("")
		self.m_timeLabel2:setString("")
		self.m_mateNode:setPositionY(96.6)
		if (CCCommonUtilsForLua:isIosAndroidPad()) then
			self.m_mateNode:setPositionY(-20.0)
		end
	end
end

function KnightTitleCell:scheduleUpdate()
	local function updatefunc(dt) self:onEnterFrame(dt) end 
	self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(updatefunc, 1.0, false)
end

function KnightTitleCell:unscheduleUpdate()
	if self.entry then
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
		self.entry = nil
	end
end

function KnightTitleCell:onEnter()
	self:scheduleUpdate()
	self:onEnterFrame(0)
end

function KnightTitleCell:onExit()
	self:unscheduleUpdate()
end

function KnightTitleCell:isTouchInNode(x, y, touchPoint)
	if touchPoint then self.m_touchPoint = touchPoint end
	if (isTouchInside(self.m_bgNode, x, y)) then
		return true
	end

	return false
end

function KnightTitleCell:onTouchBegan(x, y)
	self.showDesc = false
	if isTouchInside(self.m_descIcon, x, y) then
		self.showDesc = true
		self.tPoint = ccp(x, y)
		showDescFunc(true, self.m_knightId, x, y)
	end
end

function KnightTitleCell:onTouchMoved(x, y)
	if self.showDesc and self.tPoint and ccpDistance(self.tPoint, ccp(x, y)) > 18 then
		self.showDesc = false
		showDescFunc(false)
	end
end

function KnightTitleCell:onTouchEnded(x, y)
	if self.showDesc then
		self.showDesc = false
		return
	end

	local mv = y - self.m_touchPoint.y
	if (math.abs(mv) > 20) then return end

	local view = KnightListView.getView()
	if (view and view:isShowMsg(x, y)) then return end
	self:onClickGotoBtn()
end

function KnightTitleCell:onClickGotoBtn()
	-- local kInfos = KnightTitleController:call("getInstance"):getProperty("KnightTitleInfoMap")
	-- local kInfo = kInfos[self.m_knightId]
	local kInfo = KnightTitleController:call("getKnightInfoById", self.m_knightId)
	if (not kInfo) then return end

	if kInfo:call("getType") == 2 then --上古
		if FunOpenController:isUnlock("fun_dragonStone2", true) == false then
			return
		end
	else
		if FunOpenController:isUnlock("fun_dragonStone", true) == false then
			return
		end
	end
	
	if (not kInfo:call("isBuildLvConditionOkToUnlock")) then
		local view = KnightListView.getView()
		if view then
			local winSize = cc.Director:sharedDirector():getIFWinSize()
			local tmp = ccp(self.m_mateNode:getPositionX() + winSize.width * 3 / 4, self.m_mateNode:getPositionY())
			local pt = self.m_mateNode:getParent():convertToWorldSpace(tmp)
			view:onShowMsg(self.m_knightId, pt)
		end
	else
		local titleView = Drequire("game.CommonPopup.Knight.KnightTitileView"):create(self.m_knightId)
		PopupViewController:addPopupInView(titleView)
		if (KnightListGuideKey == "KL_First") then
			CCSafeNotificationCenter:postNotification(GUIDE_INDEX_CHANGE, CCString:create(KnightListGuideKey))
		end
	end
end

return KnightListView