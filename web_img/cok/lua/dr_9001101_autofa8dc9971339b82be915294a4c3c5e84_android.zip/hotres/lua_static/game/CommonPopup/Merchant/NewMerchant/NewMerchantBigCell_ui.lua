----------------------------
-- Author: Elex
-- Date: 2017-09-29 18:26:31
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local NewMerchantBigCell_ui = class("NewMerchantBigCell_ui")

--#ui propertys


--#function
function NewMerchantBigCell_ui:create(owner, viewType)
	local ret = NewMerchantBigCell_ui.new()
	CustomUtility:DoRes(502, true)
	CustomUtility:LoadUi("NewMerchantBigCell.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	ret:initTableView()
	return ret
end

function NewMerchantBigCell_ui:initLang()
end

function NewMerchantBigCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function NewMerchantBigCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function NewMerchantBigCell_ui:initTableView()
	TableViewSmoker:createView(self, "m_infoList", "game.CommonPopup.Merchant.NewMerchant.NewMerchantSmallCell", 0, 5, "NewMerchantSmallCell")
end

function NewMerchantBigCell_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return NewMerchantBigCell_ui

