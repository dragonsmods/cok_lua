--前三名展示
local CommonRank3AllianceNode =
    class(
    "CommonRank3AllianceNode",
    function()
        return cc.Node:create()
    end
)

--头部排行
local rankNumPicNames = {
    "Alliance_Ranking2.png",
    "Alliance_Ranking3.png",
    "Alliance_Ranking4.png"
}
--包箱
local rankBoxPicNames = {
    "common11baoxiangjin.png",
    "common11baoxianglan.png",
    "common11baoxianghui.png"
}
--背景
local nodeBGNames = {
    "BG_Ranking_01.png",
    "BG_Ranking_02.png",
    "BG_Ranking_03.png"
}
function CommonRank3AllianceNode:create(rank, info, parent)
    local node = CommonRank3AllianceNode.new()
    Drequire("game.CommonPopup.commonRank.CommonRank3PlayerNode_ui"):create(node)
    node:initNode(rank, info, parent)
    return node
end

function CommonRank3AllianceNode:initNode(rank, info, parent)
    self.rank = rank
    self.info = info
    self.parent = parent
    local rankNumSprName = rankNumPicNames[rank]
    local sf = CCLoadSprite:call("getSF", rankNumSprName)
    if sf then
        self.ui.m_rankNumSpr:setSpriteFrame(sf)
    end

    local boxSprName = rankBoxPicNames[rank]
    sf = CCLoadSprite:call("getSF", boxSprName)
    if sf then
        self.ui.m_boxSpr:setSpriteFrame(sf)
    end

    local nodeBGName = nodeBGNames[rank]
    sf = CCLoadSprite:call("getSF", nodeBGName)
    if sf then
        self.ui.m_nodeBG:setSpriteFrame(sf)
    end

    self.ui["m_nameLabel"]:setString("")
    self.ui["m_powerLabel"]:setString("")
    self.ui["m_serverLabel"]:setString("")

    self:setNodeInfo()
end

function CommonRank3AllianceNode:setNodeInfo()
    -- 玩家是否隐藏名字
    -- if self.info.hideKing == "1" or self.info.anonymous_state == 1 then
    if not self.info then
        self.ui.m_nameLabel:setString("")
        self.ui.m_powerLabel:setString("")
        self.ui.m_serverLabel:setString("")
        return
    end
    if self:isHideKing() then
        self.ui["m_nameLabel"]:setString(getLang("9800070")) -- 9800070=联盟信息已隐藏
    else
        local name = string.join("", "(", self.info.abbr or "", ")", self.info.name or "")
        self.ui["m_nameLabel"]:setString(name)
    end
    local _score = tonumber(self.info.score) or 0
    self.ui["m_powerLabel"]:setString(CC_CMDITOAL(_score))

    local str = nil
    -- if self.info.hideKing == "1" or self.info.anonymous_state == 1 then  -- 玩家是否隐藏联盟
    if self:isHideKing() then
    else
        str = getLang("138027") .. ": " -- 138027=王国
        if self.info.sid and self.info.sid ~= "" then            
            local serverId = resetGreenServerId(self.info.sid)                              
            str = str .. serverId            
        end
    end

    if str then
        self.ui["m_serverLabel"]:setString(str)
    end

    self.ui["m_headNode"]:removeAllChildren()
    local pic = self.info.icon
    if (self:isHideKing() or (not pic) or pic == "") then
        pic = CCLoadSprite:call("createSprite", "Allance_flay.png")
        pic:setScale(0.5)
        self.ui["m_headNode"]:addChild(pic)
    else
        local mpic = pic .. ".png"
        local flag = AllianceFlagPar:call("create", mpic)
        local flagLayer = tolua.cast(flag, "cc.Layer")
        flagLayer:setScale(0.5)
        self.ui["m_headNode"]:addChild(flagLayer)
    end
end

function CommonRank3AllianceNode:onClickPicBtn()
    if self:isHideKing() or not self.info then
        return
    end
    if self.parent and self.parent.openAllianceViewByRankInfo then
        self.parent:openAllianceViewByRankInfo(self.info)
    end
end

function CommonRank3AllianceNode:onRewardButtonClick()
    self.parent:onRewardButtonClick(self.rank)
end

function CommonRank3AllianceNode:isHideKing()
    local info = self.info
    if not info then
        return true
    end
    if not info.config or not info.config.getAnonymousOpen or not info.config:getAnonymousOpen() then
        return false
    end
    if info.hideKing == "1" or tonumber(info.anonymous_state) == 1 then
        return true
    end
    return false
end

return CommonRank3AllianceNode
