
CheckedDataChangedMsg="Checked_Data_Changed_Msg"

SelectingViewController = class("SelectingViewController")

function SelectingViewController:ctor()
    self.maxCheckData = 1
end

function SelectingViewController:getMaxCheckedData( )
	return self.maxCheckData
end

function SelectingViewController:isDataChecked( data )
	if self.maxCheckData == 1 then 
		if self.checkData then 
			return self.checkData.itemId == data.itemId
		else
			return false
		end
	end
end

function  SelectingViewController:updateViewData( data )
	self.viewData = data
end

function SelectingViewController:addCheckedData( data,bchecked )
	if self.maxCheckData == 1 then 
		if bchecked then 
			self.checkData = data
		else
			self.checkData = nil 
		end
	end
	CCSafeNotificationCenter:postNotification(CheckedDataChangedMsg)
end

function SelectingViewController:getCheckedData()
	if self.maxCheckData == 1 then 
		return self.checkData
	end
	return nil
end

return SelectingViewController

