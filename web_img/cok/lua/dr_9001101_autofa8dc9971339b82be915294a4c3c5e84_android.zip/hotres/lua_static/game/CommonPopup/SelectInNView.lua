local SelectInNView = class("SelectInNView",
	function()
		return PopupBaseView:create()
	end
)
SelectInNView.__index = SelectInNView

local SelectInNViewBigCell = class("SelectInNViewBigCell",
	function()
		return cc.Layer:create()
	end
)
SelectInNViewBigCell.__index = SelectInNViewBigCell

local SelectInNViewRewardCell = class("SelectInNViewRewardCell",
	function()
		return cc.Layer:create()
	end
)
SelectInNViewRewardCell.__index = SelectInNViewRewardCell

function SelectInNView:create(itemId)
	local view = SelectInNView.new()
	Drequire("game.CommonPopup.SelectInNView_ui"):create(view)
	if view:initView(itemId) then
		return view
	end
end

function SelectInNView:initView(itemId)
	if self:init(true, 0) then

		self:setHDPanelFlag(true)

		self.config = dictToLuaTable(LocalController:call("DBXMLManager"):call("getGroupByKey", "convert"))
		self.itemId = itemId
		self.itemInfo = ToolController:call("getToolInfoForLua", itemId)

		self.m_toolNum = self.itemInfo:call("getCNT")
		local para1 = self.itemInfo:getProperty("para1")
		--MyPrint("para1", para1)
		local rewardIds = self.config[para1] and self.config[para1].reward or ""
		local rewardIcons = self.config[para1] and self.config[para1].icon or ""
		local rewardNames = self.config[para1] and self.config[para1].name or ""
		local desc = self.config[para1] and self.config[para1].desction or ""

		self.maxSelectNum = tonumber(self.config[para1] and self.config[para1].count or 0)

		local ids = string.split(rewardIds, ";")
		local icons = string.split(rewardIcons, ";")
		local names = string.split(rewardNames, ";")

		self.rewardInfo = {}

		for index = 1, #ids do
			self.rewardInfo[#self.rewardInfo + 1] = {
				id = ids[index],
				name = names[index],
				icon = icons[index],
				open = false,
				selected = false,
				count = 0,
			}
		end

		--MyPrint("self.rewardInfo", #self.rewardInfo, #ids, rewardIds)
		if CCCommonUtilsForLua:isIosAndroidPad() then
			self.ui.nodeccb:setScale(2)
		end

		self.selectNum = 0
		self.selectQueue = {}
		self.selectCell = {}
		self.ui.m_titleLabel:setString(getLang("175200"))
		self.ui.m_desLabel:setString(getLang(desc))
		self.ui.m_numLabel:setString(getLang("175201", tostring(self.selectNum), tostring(self.maxSelectNum)))
		self.ui.m_okButton:setEnabled(false)
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_okButton, getLang("confirm"))

		local listSize = self.ui.m_listNode:getContentSize()
		self.m_tableView = cc.TableView:create(listSize)
		self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
		self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
		self.m_tableView:setAnchorPoint(ccp(0, 0))
		self.m_tableView:setDelegate()
		self.m_tableView:registerScriptHandler(function(tab) return self:scrollViewDidScroll(tab) end, cc.SCROLLVIEW_SCRIPT_SCROLL)
		self.m_tableView:registerScriptHandler(function(tab, idx) return self:cellSizeForTable(tab, idx) end, cc.TABLECELL_SIZE_FOR_INDEX)
		self.m_tableView:registerScriptHandler(function(tab, idx) return self:tableCellAtIndex(tab, idx) end, cc.TABLECELL_SIZE_AT_INDEX)
		self.m_tableView:registerScriptHandler(function(tab) return self:numberOfCellsInTableView(tab) end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
		self.ui.m_listNode:addChild(self.m_tableView)
		self.m_tableView:reloadData()

		local touchLayer = cc.Layer:create()
		self:addChild(touchLayer)

		local function touchHandle( eventType, x, y )
			-- print("touchHandle", eventType, x, y)
			if eventType == "began" then
				return self:onTouchBegan(x, y)
			elseif eventType == "moved" then
			
			else
				self:onTouchEnded(x, y)
			end
		end
		touchLayer:registerScriptTouchHandler(touchHandle)
		touchLayer:setTouchEnabled(true)
		touchLayer:setSwallowsTouches(false)

		return true
	end

	return false
end

function SelectInNView:onTouchBegan(x, y)
	self.startPoint = ccp(x, y)
	return true
end

function SelectInNView:onTouchEnded(x, y)
	if ccpDistance(self.startPoint, ccp(x, y)) > 30 then return end

	if not isTouchInside(self.ui.m_clickArea, x, y) then
		PopupViewController:call("removePopupView", self)
	end
end

function SelectInNView:refreshView(open, count)
	local originOffset = self.m_tableView:getContentOffset()
	self.m_tableView:reloadData()
	self.m_tableView:setContentOffset(originOffset)

	local addHeight = open and -(10 + count * 46) or (count * 46)
	local mindy = self.m_tableView:minContainerOffset().y
	local maxdy = self.m_tableView:maxContainerOffset().y
	local dy = self.m_tableView:getContentOffset().y + addHeight
	self.m_tableView:setContentOffset(ccp(0, dy))

	if (dy < mindy) then
		self.m_tableView:setContentOffset(ccp(0, mindy))
	end


	-- if (dy > maxdy) then
	-- 	self.m_tableView:setContentOffset(ccp(0, maxdy))
	-- end
end

function SelectInNView:updateSelect(rewardId)
	local selectNum = 0
	local cancelId = ""
	for index = 1, #self.rewardInfo do
		local reward = self.rewardInfo[index]
		if reward.id == rewardId then
			reward.selected = not reward.selected
			self.selectCell[rewardId]:updateSelectState(reward.selected)
			if reward.selected then
				self.selectQueue[#self.selectQueue + 1] = rewardId
			else
				cancelId = rewardId
			end
			break
		end
	end

	local selectNum = #self.selectQueue
	if cancelId ~= "" then
		for i = 1, selectNum do
			local id = self.selectQueue[i]
			if cancelId == id then
				table.remove(self.selectQueue, i)
				break
			end
		end
	end

	if selectNum > self.maxSelectNum then
		local firstId = table.remove(self.selectQueue, 1)
		for index = 1, #self.rewardInfo do
			local reward = self.rewardInfo[index]
			if reward.id == firstId then
				reward.selected = false
				self.selectCell[firstId]:updateSelectState(false)
				break
			end
		end
	end

	if #self.selectQueue == self.maxSelectNum then
		self.ui.m_okButton:setEnabled(true)
	else
		self.ui.m_okButton:setEnabled(false)
	end

	self.ui.m_numLabel:setString(getLang("175201", tostring(#self.selectQueue), tostring(self.maxSelectNum)))
end

function SelectInNView:scrollViewDidScroll()
	local mindy = self.m_tableView:minContainerOffset().y
	local dy = self.m_tableView:getContentOffset().y
	if (dy < mindy) then
		self.m_tableView:setContentOffset(ccp(0, mindy))
	end
end

function SelectInNView:cellSizeForTable(tab, idx)
	local rewardInfo = self.rewardInfo[idx + 1]
	local open = rewardInfo.open
	local count = rewardInfo.count or 0
	if open then
		return 560, 90 + 46 * count + 10
	else
		return 560, 90
	end
end

function SelectInNView:tableCellAtIndex(tab, idx)
	local reward = self.rewardInfo[idx + 1]
	local node = SelectInNViewBigCell:create(reward, self)
	node:setTag(666)
	
	self.selectCell[reward.id] = node
	--self.roomCells[idx + 1] = node

	local cell = cc.TableViewCell:create()
	cell:addChild(node)
	return cell
end

function SelectInNView:numberOfCellsInTableView(tab)
	return type(self.rewardInfo) == "table" and #self.rewardInfo or 0
end

function SelectInNView:onEnter()
	local function callback1(param) self:closeSelf(param) end
	local handler1 = self:registerHandler(callback1)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, MSG_REFREASH_TOOL_DATA)
	registerScriptObserver(self, self.onUseToolSelectBack, "SelectInNView_UseItemSelect")
end

function SelectInNView:onExit()
	CCSafeNotificationCenter:unregisterScriptObserver(self, MSG_REFREASH_TOOL_DATA)
	CCSafeNotificationCenter:unregisterScriptObserver(self, "SelectInNView_UseItemSelect")
end

function SelectInNView:onUseToolSelectBack( dict )
	local tbl = dictToLuaTable(dict)
	if tbl.id and tbl.num then
		local rewardIds = table.concat(self.selectQueue, ";")
		ToolController:call("useTool", self.itemId, tonumber(tbl.num), true, false, rewardIds)
		self.waitInterface = GameController:call("showWaitInterface1", self.ui.m_okButton)
	end
end

function SelectInNView:closeSelf(param)
	local pInt = tolua.cast(param, "CCInteger")
	if pInt then
		local itemId= pInt:getValue()
		if itemId ~= self.itemId then return end
		PopupViewController:call("removePopupView", self)
	end
end

function SelectInNView:onOkButtonClick()
	if self.m_toolNum > 0 then
		if self.m_toolNum > 1 then
			local params = {}
			params.itemId = self.itemId
			params.maxNum = self.m_toolNum
			params.messagePosted = "SelectInNView_UseItemSelect"
			local UseItemSelectView = Drequire("game.CommonPopup.UseItemSelectView")
		    local view = UseItemSelectView:create(params)
			PopupViewController:addPopupView(view)
		else
			local rewardIds = table.concat(self.selectQueue, ";")
			ToolController:call("useTool", self.itemId, 1, true, false, rewardIds)
			self.waitInterface = GameController:call("showWaitInterface1", self.ui.m_okButton)
		end
	end
end

-----------------------SelectInNViewBigCell-----------------------
function SelectInNViewBigCell:create(rewardInfo, par)
	local cell = SelectInNViewBigCell.new()
	Drequire("game.CommonPopup.SelectInNCell_ui"):create(cell, 1)
	if cell:initCell(rewardInfo, par) then
		return cell
	end
end

function SelectInNViewBigCell:initCell(rewardInfo, par)
	self.ui.m_chanceLabel:setString(getLang("175202"))

	self.rewardInfo = rewardInfo
	self.par = par
	self.ui.m_yesSprite:setVisible(self.rewardInfo.selected)
	self.ui.m_chanceLabel:setVisible(self.rewardInfo.open)
	self.ui.m_arrowsSprite:setRotation(self.rewardInfo.open and 90 or -90)
	self.request = false

	local name = rewardInfo.name
	local icon = rewardInfo.icon .. ".png"

	self.ui.m_boxNameLabel:setString(getLang(name))
	
	local sf = CCLoadSprite:call("loadResource", icon)
	if sf then self.ui.m_iconSprite:setSpriteFrame(sf) end

	self.rewardInfo.rewardArr = self.rewardInfo.rewardArr or {}
	--MyPrint("self.rewardInfo.rewardArr ", #self.rewardInfo.rewardArr )

	local height = 0
	for index = 1, self.rewardInfo.count do
		local reward = self.rewardInfo.rewardArr[index]
		local rewardCell = SelectInNViewRewardCell:create(reward)
		rewardCell:setPosition(0, height)
		self:addChild(rewardCell)
		height = height + 46
	end

	height = (height == 0 and height or height + 10)
	self.ui.nodeccb:setPosition(0, height)

	local originSize = self.ui.m_bgSprite:getContentSize()
	self.ui.m_bgSprite:setContentSize(cc.size(originSize.width, originSize.height + height))

	local touchLayer = cc.Layer:create()
	self:addChild(touchLayer)

	local function touchHandle( eventType, x, y )
		-- print("touchHandle", eventType, x, y)
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		
		else
			self:onTouchEnded(x, y)
		end
	end
	touchLayer:registerScriptTouchHandler(touchHandle)
	touchLayer:setTouchEnabled(true)
	touchLayer:setSwallowsTouches(false)

	return true
end

function SelectInNViewBigCell:getRewardDetailBack(param)
	local pstr = tolua.cast(param, "CCString")
	if pstr then
		local rewardId = pstr:getCString()
		--MyPrint("getRewardDetailBack", rewardId, self.rewardInfo.id)
		if rewardId == "" or self.rewardInfo.id ~= rewardId then return end

		local rwd = GlobalData:call("getCachedRewardData", self.rewardInfo.id)
		self.rewardInfo.rewardArr = arrayToLuaTable(rwd)
		self.rewardInfo.count = #self.rewardInfo.rewardArr
		self.request = false
		self.par:refreshView(true, self.rewardInfo.count)
	end
end

function SelectInNViewBigCell:onEnter()
	local function onGetRwdDetailBack(param) self:getRewardDetailBack(param) end
    local handler1 = self:registerHandler(onGetRwdDetailBack)
    CCSafeNotificationCenter:registerScriptObserver(self, handler1, "MSG_GET_REWARD_DETAIL_BACK")
end

function SelectInNViewBigCell:onExit()
	CCSafeNotificationCenter:unregisterScriptObserver(self, "MSG_GET_REWARD_DETAIL_BACK")
end

function SelectInNViewBigCell:onTouchBegan(x, y)
	self.touchPoint = ccp(x, y)
	if self.request then return false end
	if isTouchInside(self.par.ui.m_listNode, x, y) then return true end
end

function SelectInNViewBigCell:onTouchEnded(x, y)
	if ccpDistance(self.touchPoint, ccp(x, y)) > 20 then return end
	if isTouchInside(self.ui.m_yesBg, x, y) then 
		self:select()
	elseif isTouchInside(self.ui.m_bgSprite, x, y) then 
		self:open() 
	end
end

function SelectInNViewBigCell:select()
	self.par:updateSelect(self.rewardInfo.id)
end

function SelectInNViewBigCell:updateSelectState(selected)
	self.ui.m_yesSprite:setVisible(selected)
end

function SelectInNViewBigCell:open()
	self.rewardInfo.open = not self.rewardInfo.open
	if self.rewardInfo.open then
		local rwd = GlobalData:call("getCachedRewardData", self.rewardInfo.id)
		self.rewardInfo.rewardArr = arrayToLuaTable(rwd)
		
		local count = #self.rewardInfo.rewardArr 
		if count == 0 then
			self.request = true
			GlobalData:call("checkAndRequestRewardData", self.rewardInfo.id)
		else
			self.rewardInfo.count = count
			self.par:refreshView(true, count)
		end
	else
		self.rewardInfo.count = 0
		self.par:refreshView(false, 0)
	end
end

-----------------------SelectInNViewBigCell-----------------------

-----------------------SelectInNViewRewardCell-----------------------
function SelectInNViewRewardCell:create(rewardInfo)
	local cell = SelectInNViewRewardCell.new()
	Drequire("game.CommonPopup.SelectInNResCell_ui"):create(cell, 1)
	if cell:initReward(rewardInfo) then
		return cell
	end
end

function SelectInNViewRewardCell:initReward(rewardInfo)
	local ccbSize = self.ui.nodeccb:getContentSize()
	self:setContentSize(ccbSize)

	local name = ""
	local icon  = ""

	local rewardType = tonumber(rewardInfo.type) or 0
    --MyPrint("rewardType", rewardType)
	local value = tonumber(rewardInfo.value) or 0
    local id = 0
	if rewardType == RewardTypeConfig.R_GOODS or rewardType == RewardTypeConfig.R_EQUIP then
        local valueObj = rewardInfo.value
        id = tonumber(valueObj.id) or 0
		name = RewardController:call("getNameByType", rewardType, id)
		icon = RewardController:call("getPicByType", rewardType, id)
        value = tonumber(valueObj.num) or 0
	elseif rewardType == RewardTypeConfig.R_EFFECT then
		name = CCCommonUtilsForLua:call("getNameById", tostring(value))
		if name == "" then
			if value == 502600 then
				name = getLang("138074")
			elseif value == 502601 then
				name = getLang("138075")
			elseif value == 502602 then
				name = getLang("138076")
			end
		end

		icon = CCCommonUtilsForLua:call("getICon", tostring(value))
		value = 1
	else
		if rewardType == RewardTypeConfig.R_DRAGON_MODEL then
			name = getLang("140357")
		elseif rewardType == RewardTypeConfig.R_DRAGON_RING then
			name = getLang("140358")
		else 
			name = RewardController:call("getNameByType", rewardType, id)
		end

		icon = RewardController:call("getPicByType", rewardType, value)
	end

	local t = " X" .. CC_CMDITOA(value)
    if rewardType ~= RewardTypeConfig.R_EFFECT then 
    	name = name .. t
   	end
	self.ui.m_resNameLabel:setString(name)
	self.ui.m_resIconNode:removeAllChildren()

	local color = 2
	
	if rewardType == RewardTypeConfig.R_GOODS then
		local toolInfo = ToolController:call("getToolInfoByIdForLua", id)
		if toolInfo then
        	color = toolInfo:getProperty("color")
        end
    elseif rewardType == RewardTypeConfig.R_EQUIP then
		local eInfo = EquipmentController:call("getInstance"):call("getEquipInfoById", id)
    	icon = eInfo:call("getIcon") .. ".png"
    	color = eInfo:call("getColor")
    elseif (rewardType == RewardTypeConfig.R_EFFECT or rewardType == RewardTypeConfig.R_CRYSTAL or rewardType == RewardTypeConfig.R_WIN_POINT 
    			or rewardType == RewardTypeConfig.R_GOLD or rewardType == RewardTypeConfig.R_DRAGON_MODEL or rewardType == RewardTypeConfig.R_DRAGON_RING) then
    	color = 5
    end

    local colorBg = CCCommonUtilsForLua:call("getToolBgByColor", color)
    local sf = CCLoadSprite:call("loadResource", colorBg)
	self.ui.m_colorBg:setSpriteFrame(sf)
	self.ui.m_colorBg:setScale(0.4)

	if rewardType == RewardTypeConfig.R_GOODS then
		local spr = CCLoadSprite:call("createSprite", icon, CCLoadSpriteType.CCLoadSpriteType_GOODS)
		self.ui.m_resIconNode:addChild(spr)
	elseif rewardType == RewardTypeConfig.R_EQUIP then
		local spr = CCLoadSprite:call("createSprite", icon, CCLoadSpriteType.CCLoadSpriteType_EQUIP)
		self.ui.m_resIconNode:addChild(spr)
	else
		local spr = CCLoadSprite:call("createSprite", icon)
		self.ui.m_resIconNode:addChild(spr)
	end

	return true
end

function SelectInNViewRewardCell:onEnter( ... )
	-- body
end

function SelectInNViewRewardCell:onExit( ... )
	-- body
end
-----------------------SelectInNViewRewardCell-----------------------

return SelectInNView