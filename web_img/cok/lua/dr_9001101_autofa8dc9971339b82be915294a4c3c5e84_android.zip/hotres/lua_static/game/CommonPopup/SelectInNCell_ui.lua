----------------------------
-- Author: Elex
-- Date: 2018-12-04 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local SelectInNCell_ui = class("SelectInNCell_ui")

--#ui propertys


--#function
function SelectInNCell_ui:create(owner, viewType, paramTable)
	local ret = SelectInNCell_ui.new()
	CustomUtility:DoRes(6, true)
	CustomUtility:LoadUi("SelectInNCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function SelectInNCell_ui:initLang()
end

function SelectInNCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function SelectInNCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return SelectInNCell_ui

