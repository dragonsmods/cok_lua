--[[
	新技能面板：龙技能单元格
]]
local NewActiveSkillDragonGrid = class("NewActiveSkillDragonGrid", function()
	return cc.TableViewCell:create()
end)

function NewActiveSkillDragonGrid:ctor(id, view)
	self.id = ""
	self.view = view

	local proxy = cc.CCBProxy:create()
	local ccbiUrl = "ActiveSkill_v2_Cell2"
	local node = CCBReaderLoad(ccbiUrl, proxy, self)
	self:addChild(node)

	local function onNodeEvent( event )
		if event == "enter" then
			self:onEnter()
		elseif event == "exit" then
			self:onExit()
		end
	end
	self:registerScriptHandler(onNodeEvent)

	self.touchLayer = cc.Layer:create()
	self:addChild(self.touchLayer)
	local function touchHandle(eventType, x, y)
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
			self:onTouchMoved(x, y)
		elseif eventType == "ended" then
			self:onTouchEnded(x, y)
		end
	end
	self.touchLayer:registerScriptTouchHandler(touchHandle)
	self.touchLayer:setTouchEnabled(true)
	self.touchLayer:setSwallowsTouches(false)

	self.m_sHeroNode:setVisible(false)
	self.m_nodeTime:setVisible(false)
	self.m_sprCollect:setVisible(false)

	self:setData(id)
end

function NewActiveSkillDragonGrid:onEnter()
	self:onEnterFrame()
	self.entry = tonumber(self:getScheduler():scheduleScriptFunc(function()
		self:onEnterFrame()
	end, 0.9, false))
end

function NewActiveSkillDragonGrid:onEnterFrame()
	self.m_nodeTime:setVisible(false)
	if self.view.page == "dragon" then
		local data = DragonActiveSkillManager.getInstance():getDataById(self.id)
		if nil == data then
			return
		end
		if data:getIsUnLocked() then
			local nowTimeStamp = GlobalData:call("getTimeStamp")
			if data:isActive() then
				local left = data:getActEndTime() - nowTimeStamp
				self.m_timeLabel:setString(format_time(left))
				self.m_stateLabel:setString(getLang("169629"))
				self.m_nodeTime:setVisible(true)
				self.m_nodeBtn:setVisible(false)
				require("game.CommonPopup.NewActiveSkillHelper"):addSkAcParticle(self.m_particleNode)
			elseif data:isInCD() then
				local left = data:getCDEndTime() - nowTimeStamp
				left = math.max(0, left)
				self.m_timeLabel:setString(format_time(left))
				self.m_stateLabel:setString(getLang("169630"))
				self.m_nodeTime:setVisible(true)
				self.m_nodeBtn:setVisible(false)
				self.m_particleNode:removeAllChildren()
			end
		end
		self:updateCollect()
	end
end

function NewActiveSkillDragonGrid:onExit()
	if self.entry then
		self:getScheduler():unscheduleScriptEntry(self.entry)
	end
end

function NewActiveSkillDragonGrid:onTouchBegan(x, y)
	self.v_touchBeganX = x
	self.v_touchBeganY = y
	if self:isVisible(true) and self.view.page == "dragon" and isTouchInside(self.m_skillTouchNode, x, y) then
		self.v_isMove = false
		return true
	end
	return false
end

function NewActiveSkillDragonGrid:onTouchMoved(x, y)
	if self:isVisible(true) and self.view.page == "dragon" and isTouchInside(self.m_skillTouchNode, x, y) then
        if ccpSquareDistance(cc.p(self.v_touchBeganX, self.v_touchBeganY), cc.p(x, y)) > 50 then
			self.v_isMove = true
		end
	end
end

function NewActiveSkillDragonGrid:onTouchEnded(x, y)
	if self.v_isMove==false and isTouchInside(self.m_skillTouchNode, x, y) then
		if self.id ~= self.view.selectedId then
			self.view:onTouchGrid(self)
		end
	end

end

function NewActiveSkillDragonGrid:setData(id)
	self.m_selcetSprite:setVisible(false)
	self.id = id

	local showRedDot = require("game.CommonPopup.NewActiveSkillHelper"):isSkillInRecord(self.id)
	self.m_redDotSp:setVisible(showRedDot)
	self.m_particleNode:removeAllChildren()

	local skillInfo = DragonActiveSkillManager.getInstance():getDataById(self.id)
	if nil ~= skillInfo then
		local pic = CCCommonUtilsForLua:call("getPropById", self.id, "icon") .. ".png"
		if CCLoadSprite:call("getSF", pic) == nil then
			pic = "dragon_skill_1.png"
		end
		local icon = CCLoadSprite:call("createSprite", pic)
		self.m_iconNode:removeAllChildren()
		self.m_iconNode:addChild(icon)

		self.m_nodeBtn:setVisible(true)
		self.m_btnUse:setVisible(true)
		self.m_btnLook:setVisible(true)
		-- 【awen】判断是否为新主动天赋
		if DragonActiveSkillManagerNew.getInstance():isNewSkillType(self.id) then
			local _curLevel = DragonActiveSkillManagerNew.getInstance():getCurLevel(self.id)
			CCCommonUtilsForLua:call("setSpriteGray", icon, _curLevel<1)
			if _curLevel < 1 then
				self.m_btnUse:setVisible(false)
				self.m_labelBtn:setString(getLang("118006"))	--118006=去看看
			else
				self.m_btnLook:setVisible(false)
				self.m_labelBtn:setString(getLang("105460"))	--105460=使用
				self.m_selcetSprite:setVisible(true)
			end
		else
			if skillInfo:getIsUnLocked() then
				CCCommonUtilsForLua:call("setSpriteGray", icon, false)
				self.m_selcetSprite:setVisible(true)
				self.m_btnLook:setVisible(false)
				self.m_labelBtn:setString(getLang("105460"))	--105460=使用
			else
				CCCommonUtilsForLua:call("setSpriteGray", icon, true)
				self.m_btnUse:setVisible(false)
				self.m_labelBtn:setString(getLang("118006"))	--118006=去看看
			end
		end
		CCCommonUtilsForLua:call("setSpriteMaxSize", icon, 100, true)
	end

	self:onEnterFrame()
end

-- 更新收藏标志
function NewActiveSkillDragonGrid:updateCollect( )
	-- Dprint("NewActiveSkillDragonGrid:updateCollect")
	if self.id then
		local _isCollect = NewActiveSkillController:isCollected(self.id)
		self.m_sprCollect:setVisible(_isCollect)
	end
end

-- 点击使用按钮
function NewActiveSkillDragonGrid:onClickBtnUse()
	-- Dprint("NewActiveSkillDragonGrid:onClickBtnUse")
	self.view.selectedId = self.id
	-- 【awen】判断是否为新主动天赋
	if DragonActiveSkillManagerNew.getInstance():isNewSkillType(self.id) then
		local _curLevel = DragonActiveSkillManagerNew.getInstance():getCurLevel(self.id)
		if _curLevel>0 then
			DragonActiveSkillManager.getInstance():startUseSkill(self.id)
			if CCCommonUtilsForLua:isFunOpenByKey("new_battle_view_lua") then
				CCSafeNotificationCenter:postNotification(MessageType.MSG_SEND_BATTLE_VIEW_BUFF_CMD)
			end
		else
			local dragonId = CCCommonUtilsForLua:call("getPropByIdGroup", "dragon_skill", self.id, "born_dragon")
			local dragonInfo = DragonController:call("getDragonInfoByDragonBaseId", dragonId)
			PopupViewController:call("removeAllPopupView")
			if CCCommonUtilsForLua:isFunOpenByKey("dragon_new_ui_switch") then
				local view = Drequire("game.NewDragon.NewDragon_V2.DragonListNewView"):create()			
				PopupViewController:call("addPopupInView", view)
				if nil ~= view then					
					local dragonView = view:openDragonViewByUuid(dragonInfo:call("getUuid"),dragonInfo:call("getBaseId"))
					if nil ~= dragonView then
						dragonView:OnClicktalent()
					end
				end
			else
				local view = Drequire("game.NewDragon.DragonCave_New"):create({uuid = dragonInfo:call("getUuid")})			
				PopupViewController:call("addPopupInView", view)
				if nil ~= view then
					view:OnClicktalent()
				end
			end			
		end
	else
		local data = DragonActiveSkillManager.getInstance():getDataById(self.id)
		if nil == data then
			return
		end
		if data:getIsUnLocked() == false then
			local skillInfo = DragonActiveSkillManager.getInstance():getDataById(self.id)
			if nil == skillInfo then
				return
			end
			local dragonInfo = skillInfo:getDragonInfo()
			if nil == dragonInfo then
				return
			end
			PopupViewController:call("removeAllPopupView")			
			if CCCommonUtilsForLua:isFunOpenByKey("dragon_new_ui_switch") then
				local view = Drequire("game.NewDragon.NewDragon_V2.DragonListNewView"):create()			
				PopupViewController:call("addPopupInView", view)
				if nil ~= view then					
					local dragonView = view:openDragonViewByUuid(dragonInfo:call("getUuid"),dragonInfo:call("getBaseId"))
					if nil ~= dragonView then
						dragonView:OnClicktalent()
					end
				end
			else
				local view = myRequire("game.NewDragon.DragonCave_New"):create({uuid = dragonInfo:call("getUuid")})
				if nil ~= view then
					PopupViewController:call("addPopupInView", view)
					view:OnClicktalent()
				end
			end
		else
			DragonActiveSkillManager.getInstance():startUseSkill(self.id)
			if CCCommonUtilsForLua:isFunOpenByKey("new_battle_view_lua") then
				CCSafeNotificationCenter:postNotification(MessageType.MSG_SEND_BATTLE_VIEW_BUFF_CMD)
			end
		end
	end
end

-- 点击去看看按钮
function NewActiveSkillDragonGrid:onClickBtnLook()
	self:onClickBtnUse()
end

return NewActiveSkillDragonGrid