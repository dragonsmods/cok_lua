-------------
--主界面添加按钮须知：
--初始化：在UiCompoentLuaLayer:onEnter依次添加初始化方法
--坐标：根据左上角位置或者左下角位置，在self:updateRightUpPos()或者self:updateDownLeftPos()中，累加offsetY
--如果需要判断isfunopenbykey的情况，要在self:initData()初始化
-------------

local DailyActivityManager = require("game.dailyActivity.DailyActivityManager")
require("game.fortress.FortressController")
local OnlineTimeController = require("game.controller.OnlineTimeController").getInstance()
local UiCompoentLuaLayer = class("UiCompoentLuaLayer", function()
        return CCLayer:create()
    end
)   --创建一个UiCompoentLuaLayer类

local IconWidth = 90
local IconHeight = 80
local IconOffset = 15

UiCompoentLuaLayer.dctrl = nil

-- needReload 当其为true用于新加函数的动态加载使用
local needReload = false  --false是否重新加载
-- 通用icon添加函数，无需注册onEnter和onExit
-- iconType 1 右上，2左下向上排列, 3左下向右排列, 4,其余位置, 5 （野外）左下向上排列, 6右上靠内第二列从上向下排
--     永夜城11 右上
-- alone：不进整合，单独显示【未调试右上情况】
-- iconName 对应的lua文件必须继承node，使用create函数创建，使用touchEvent接收点击事件， 若每秒更新，则实现update函数，
-- 当场景切换需要显隐控制时需要实现onSceneChanged函数
-- scene 单独放置的节点有效  不填或base为基础场景节点 night为永夜城 common两者公共节点

local iconListFileTbl = {
    {iconName = "game.UIComponent.GoldActivityBoxIcon", iconType = 1},
    --【Awen】已与贾琳&张旭沟通，将日常玩法去掉 
    -- {iconName = "game.UIComponent.TimePackageNodeIcon", iconType = 2, guide = "LUA_UI_dailyactivity"}, -- 日常玩法
    {iconName = "game.UIComponent.CityAssistIcon", iconType = 2, order = 2},--【Awen】领地辅助
    {iconName = "game.UIComponent.CrossServerActivityIcon", iconType = 2, order = 2.03, alone = 1}, -- 跨服活动：左下角传送门
    
    {iconName = "game.UIComponent.KingCompensateNodeIcon", iconType = 2, order = 2.06},--国王帮助
	{iconName = "game.UIComponent.WelfareIntegrateIcon", iconType = 1, guide = "LUA_UI_WelfareIntegrateIcon"},--日常奖励
    {iconName = "game.UIComponent.ActivityPageListIcon", iconType = 1, guide = "LUA_UI_activityPanel"},    -- 充值活动列表
    {iconName = "game.UIComponent.ActivityPageListIcon2", iconType = 1, guide = "LUA_UI_activityPanel"},    -- 消耗活动列表
	{iconName = "game.UIComponent.TalentPointTip", iconType = 4},
    {iconName = "game.UIComponent.DragonBattleRecordIcon", iconType = 1},
    {iconName = "game.UIComponent.DragonBattleDataIcon", iconType = 1},
    {iconName = "game.UIComponent.FeedBackNodeIcon", iconType = 2, order = 2.10},
    -- {iconName = "game.UIComponent.FourthAnniversaryIcon", iconType = 1}, -- 四周年活动入口      统一走新的节日活动入口了。删掉
    -- {iconName = "game.UIComponent.MidAutumnFestivalIcon", iconType = 1}, -- 中秋节活动入口       统一走新的节日活动入口了。删掉
    {iconName = "game.FestivalActivities.FestivalActivitiesIcon", iconType = 1}, -- 节日活动入口
    {iconName = "game.UIComponent.AllianceBossIcon", iconType = 5}, -- 联盟boss 逻辑判断较多，待细调整
    --[[改为计时器触发创建]]
    -- {iconName = "game.UIComponent.ChangeServerNodeIcon", iconType = 2, order = 2.09}, -- 付费转服

    -- 暂时废弃的功能。看情况目前不会开了。要开也得重新调整。
    -- {iconName = "game.UIComponent.CalendarNodeIcon", iconType = 1}, --活动日历
    --{iconName = "game.activity.RunningRingAct.RunningRingActIcon", iconType = 3, order = 2.05}, -- 跑环任务图标
    {iconName = "game.UIComponent.NewMergeActivityNodeIcon", iconType = 3, order = 2.07}, -- 新合服活动
    {iconName = "game.UIComponent.FestivalActivitiesBattlePassNodeIcon", iconType = 1}, --新 battlepass
    {iconName = "game.activity.ActivityPage.CrossServerPayInfoListIcon", iconType = 1}, --跨服充值列表
    {iconName = "game.CommonPopup.AuctionHouse.AuctionHouseNodeIcon", iconType = 3, order = 2.08}, -- 拍卖失败提示图标
    {iconName = "game.dragonWarmUpBattle.DragonWarmUpIcon.lua",iconType = 1},--巨龙演武场任务宝箱
    {iconName = "game.UIComponent.DragonBattleObMvpIcon",iconType = 1},--巨龙战场OB mvp界面icon
    {iconName = "game.KpiFestival2020.NewYearDay2020.NewYearDay2020Icon", iconType = 6}, -- 2020 元旦 入口
    {iconName = "game.UIComponent.FirstChargeIcon", iconType = 6},--【Awen】首充礼包入口
    {iconName = "game.UIComponent.AdVideoIcon", iconType = 1},--【Awen】视频广告入口
    {iconName = "game.UIComponent.QuickSwitchEquipmentNode", iconType = 4, scene = 'common'},--【Awen】切换装备快捷键
    {iconName = "game.LiBao.AnniversaryLibao.AnniversaryIcon", iconType = 6},--
    -- {iconName = "game.UIComponent.AllianceDuelTVIcon", iconType = 3, order = 2.14},--联盟对决TV     已整理。
    {iconName = "game.UIComponent.WorldGameSceneShareIcon", iconType = 5}, -- 世界场景截图分享
    {iconName = "game.UIComponent.AmazonActivityIcon", iconType = 1, order = 2}, -- 亚马逊图标
    {iconName = "game.UIComponent.ExploreRoadIcon", iconType = 1, order = 1}, -- 开拓之路图标
    -- {iconName = "game.greenServer.gameUIIcons.GreenServerIcon", iconType = 2, order = 1.02, alone = 1}--怀旧服切换

    --[[不要删除这块注释,以开关控制功能icon]]
    -- {iconName = "game.UIComponent.ReturnOfTheKingIcon", iconType = 2, order = 2.02},--王者归来
    -- {iconName = "game.UIComponent.LuckyReturnNodeIcon", iconType = 2, order = 2.12}, -- 幸运回归
    -- {iconName = "game.UIComponent.LuckyDayNodeIcon", iconType = 3, order = 2.04},--幸运日
    -- {iconName = "game.UIComponent.NewServerBuffIcon", iconType = 3, order = 2.04},--迁服buff
    -- {iconName = "game.UIComponent.KingdomMassNodeIcon", iconType = 2, order = 2.11},--王国集结
    -- {iconName = "game.UIComponent.SubscribeNodeIcon", iconType = 2, order = 2.01}, -- 订阅
    -- {iconName = "game.UIComponent.WorldBossComingIcon", iconType = 5}, -- 世界boss来袭
    -- {iconName = "game.darkCivilization.DarkCivNodeIcon", iconType = 4},--名城入口
    -- {iconName = "game.UIComponent.ThemeMonthIcon", iconType = 4} --主题月图标
    -- {iconName = "game.LiBao.LibaoPusher.LibaoPusherIcon", iconType = 6, order = 10000} -- 礼包推送
    -- {iconName = "game.commercialDarts.CommercialSpeIcon", iconType = 2}
    -- {iconName = "game.flower.FlowerEntryIcon", iconType = 6, order = 2}鲜花榜
    -- {iconName = "game.TimeLimitBuff.TimeLimitBuffIcon", iconType = 4, order = 2.02} --王国buff
    -- {iconName = "game.TimeLimitBuff.PlayerBuffIcon", iconType = 4, order = 2.02} --玩家buff
    -- {iconName = "game.activity.AllPeopleActivity.AllPeopleActIcon", iconType = 6, order = 2} -- 全民活动
    -- {iconName = "game.UIComponent.NewKingdomWarIcon", iconType = 4, order = 2.02} --王战Icon
    -- {iconName = "game.UIComponent.BanquetActivityIcon", iconType = 3, order = 2.13},    -- 犒赏三军，活动id 57434
    -- {iconName = "game.WelfareIntegrate.LuckyPlatinum.LuckyPlatinumNodeIcon", iconType = 1},-- 白金币转盘

    -- {iconName = "game.NightCity.nightHero.NightHeroIcon", iconType = 11, scene = 'night'},--  永夜英雄领取
    --[[end 不要删除这块注释,以开关控制功能icon]]

}

function UiCompoentLuaLayer:create(dict) 
	local view = UiCompoentLuaLayer.new()
	if view:initView(dict) == false then
		return nil
	end

  	return view
end

function UiCompoentLuaLayer:initView(dict)
	local  proxy = cc.CCBProxy:create()
    -- dump(tbl, "UiCompoentLuaLayer:initView tbl is: ")
    self.leftStartOffSetY = utils.getDictKeyValue(dict, "leftStartOffSetY", 0)
    self.leftPosOffsetY = utils.getDictKeyValue(dict, "leftPosOffsetY", 0)

	local function onNodeEvent(event)
		if event == "enter" then
			self:onEnter()
		elseif event == "exit" then
			self:onExit()
        elseif event == "cleanup" then
            self:onCleanup()
		end
	end
  	self:registerScriptHandler(onNodeEvent)

  	local function onTouch(eventType, x, y)  
        if eventType == "began" then  
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)  
        else  
            return self:onTouchEnded(x, y)  
        end
    end
    self:registerScriptTouchHandler(onTouch)

    self:setTouchEnabled(true)
    self:setSwallowsTouches(true)

    self.initTime = 0
    local parentNode = dict:objectForKey("node")
    local size = parentNode:getContentSize()
    if CCCommonUtilsForLua:isIosAndroidPad() then -- ipad适配
        local scalePad = CCCommonUtilsForLua:call("getPropByIdGroup", "data_config", "uicommon_pad_scale", "k1") or ""
        if scalePad ~= "" then
            scalePad = tonumber(scalePad)
            size = cc.size(size.width / scalePad, size.height / scalePad)
            self:setScale(scalePad)
            self:setAnchorPoint(cc.p(0, 0))
        end
    end
    self:setContentSize(size)

    self.m_UIQuestNode = dict:objectForKey("m_UIQuestNode")
    self.contentSize = size

    -- 世界左下的按钮的占位Node，用于左下幸运日在进入世界界面后，与搜索等按钮重叠的问题
    self.m_worldFaveNode = cc.Node:create()
    self:addChild(self.m_worldFaveNode)
    self.m_worldFaveNode:setContentSize(cc.size(IconWidth, IconHeight))
    self.m_worldFaveNode:setVisible(false)
    self.m_worldFaveNode:setPosition(cc.p(IconWidth*0.5, IconHeight*0.5))
    self.m_worldFaveNode:setAnchorPoint(cc.p(0.5, 0.5))

	-- 这里的章节要在2级显示，但是原有都是4级才开启的，所以这里新增一个同坐标系的node，特殊处理下
    -- 初始化章节node
    local m_chapterBaseNode = dict:objectForKey("m_chapterBaseNode")
    self.m_chapterBaseNode = tolua.cast(m_chapterBaseNode, "cc.Node")

    self.beIconScrollFunOn = CCCommonUtilsForLua:isFunOpenByKey("5th_main_UI_update")

    -- 独立显示的节点创建一个父节点
    self.m_aloneBaseNode = cc.Node:create()
    self:addChild(self.m_aloneBaseNode)
    -- 永夜城独立显示的节点
    self.m_aloneBaseNodeNC = cc.Node:create()
    self:addChild(self.m_aloneBaseNodeNC)
    -- 多城公用的节点
    self.m_aloneCommonNode = cc.Node:create()
    self:addChild(self.m_aloneCommonNode)

    -- 右上创建一个新的ScrollView,用于存储限时逻辑
    self:createRightUpPopList()

    -- 左下创建一个新的ScrollView
    self:createLeftDownPopList()


    -- 幸运日时间显示

    self.hasEnter = false

    -- 章节任务ICON显示标记
    self.isChapterShow = true

    --世界杯只显示战斗记录按钮
    self.showAllBtn = true
    self.onlyShowDBRecord = false
   
    --全球赛隐藏
    if (require("game.dragonWorldCup.DragonWorldCupManager").isDragonGlobalServer()) or GlobalData:call("shared"):getProperty("obing") then
    	self.onlyShowDBRecord = true
        self.showAllBtn = false
    end

    --防沉迷数据。
    self.dctrl = DataController
    self.iconListDataTbl = {}
    self.iconListAlone = {}

    self.m_isLocked = false
	-- local function laFunc( dictTable, dict )
 --    	MyPrint("IS LOCKING!!!!!  111 dictTable.locked", dictTable.locked)
	-- 	if tonumber(dictTable.locked) == 1 then
	-- 		MyPrint("IS LOCKING!!!!!   222")
	-- 		self.m_isLocked = true
	-- 		local view = Drequire("game.UsernameLock.UserLockedView"):create()
	-- 		PopupViewController:call("removeAllPopupView")
	-- 		PopupViewController:addPopupView(view)
	-- 	end
	-- end

 --    local dict = CCDictionary:create()
	-- local cmd = Drequire("game.command.UsernameLockCmd").create("accountLock.getUnlockView", dict, laFunc)
	-- cmd:sendAndRelease()
    if GlobalData:call("getPlayerInfo"):getProperty("officer") == "216000" then -- 国王上线提示
        local cmd = Drequire("game.command.KingNotifyCmd").create()
        cmd:send()

        --国王登陆提示 自己看到
        require("game.flyHint.FlyHintManager").getManager():addKingLoginTip()
    end
    self.reqData_lock = false

    if require("game.dragonBattle.DragonBattleOBController").getInstance():isNewOBOpen() then
        local newOBNode = UIComponent:call("getInstance"):getProperty("m_newOBNode")
        local mainUIComponent = newOBNode:getParent()
        self.upNode = Drequire("game.dragonBattle.DragonBattleOBUpNode"):create()
        newOBNode:addChild(self.upNode)

        self.downNode = Drequire("game.dragonBattle.DragonBattleOBDownNode"):create()
        newOBNode:addChild(self.downNode)
    end

    local VNAuditInfoTips = require("game.CommonPopup.VNAuditInfoTips")
    self.vnAuditInfoTips = VNAuditInfoTips.isOpen() and require("game.CommonPopup.VNAuditInfoTips"):create(self)

    self:requestPlayerStatus()

    UiCompoentControoller.getIconEvent():add(self.onIconEvent,self)
    return true
end

function UiCompoentLuaLayer:onIconEvent( tbl )
    repeat
        -- utils.dump( tbl, "onIconEvent,,,," )
        if table.isNilOrEmpty( tbl ) then
            break
        end

        if string.isNilOrEmpty(tbl.eventType) then
            break
        end

        if table.isNilOrEmpty( tbl.icon_cfg ) then
            break
        end

        if isFunOpenByKey("MainInterfaceConfig") and table.isNilOrEmpty(self.main_interface_config) == false then
            local _data = self.main_interface_config[tbl.icon_cfg.iconNameSub or tbl.icon_cfg.iconName]
            if _data then
                tbl.icon_cfg.iconType = _data.iconType
                tbl.icon_cfg.alone = _data.alone
                local now = getTimeStamp()
                if now >= _data.startTime and now < _data.endTime then
                    tbl.order = _data.order2
                else
                    tbl.order = _data.order
                end
            end
        end

        if tbl.eventType == "create" then
            if not self:findIcon(tbl.icon_cfg) then
                local tView = self:makeIcon(tbl.icon_cfg)
                if not tView then
                    break
                end

                if tView.tryListenEvent then
                    tView:tryListenEvent()
                end
                if tView.tryParseData and tbl.icon_cfg.data then
                    tView:tryParseData(tbl.icon_cfg.data)
                end
            end
            break
        end

        if tbl.eventType == "visibility" then
            local t_icon,t_idx,contain_list = self:findIcon(tbl.icon_cfg)
            if t_icon then
                t_icon:setVisible( not not tbl.visible )
            end
            break
        end

        if tbl.eventType == "destroy" then            
            local t_icon,t_idx,contain_list,aloneIdx,aloneList = self:findIcon(tbl.icon_cfg)
            if t_icon then
                table.remove(contain_list,t_idx)
                t_icon:removeFromParent(true)
                if aloneIdx then
                    table.remove(aloneList,aloneIdx)
                end
            end
            break
        end
    until true
end

function UiCompoentLuaLayer:ShowUserLockedView()
    if self.m_isLocked == false then
        local lockCtr = DataController.UserLockedController
        lockCtr:setCurrentState(0)
        lockCtr:addTimeEvent()
        lockCtr:getUserLockData()
        self.m_isLocked = true
    end
end

function UiCompoentLuaLayer:initData()
    if self.showAllBtn then

        
    end
end

function UiCompoentLuaLayer:firstPopupBlog()
    local view = Drequire("game.blog.PosterMainView"):create(2,true)
    PopupViewController:addPopupInView(view)
end

function UiCompoentLuaLayer:refreshChapgerNode(visiable_force)
    local _isUiOpen = FunBuildController:call("getInstance"):call("IsHaveRecordeByKey", "ui_chapter")
    -- MyPrint("UiCompoentLuaLayer refreshChapterNode", visiable_force, _isUiOpen)
    local mainCityLv = FunBuildController:call("getMainCityLv")
	if _isUiOpen or (mainCityLv > 1 and mainCityLv < 20) then
		local open = ChapterController:getInstance():isChapterOpen()
        -- MyPrint("UiCompoentLuaLayer refreshChapterNode open", open)
        if self.sceneId == SCENE_ID_MAIN and open and self.isChapterShow then
            self:createChapterNode()
            self.m_chapterNode:setVisible(true)
            
            self.m_chapterTaskNode:setVisible(true)
            --老账号不开启章节任务
            if visiable_force ~= nil  then
                self.m_chapterNode:setVisible(visiable_force)
                self.m_chapterTaskNode:setVisible(visiable_force)
            end
        else
            if self.m_chapterNode then
                self.m_chapterNode:setVisible(false)
                self.m_chapterTaskNode:setVisible(false)
            end
		end
	end
end

function UiCompoentLuaLayer:checkNewPlayBuff()
    -- 新手增益
    if CCCommonUtilsForLua:isFunOpenByKey("new_player_20210104_show") then
        local controller = require("game.CommonPopup.ItemStatusController_v2021").getInstance()
        if controller:getEndTime() - getTimeStamp() > 0 then
            local iconCfg = {iconName = "game.UIComponent.NewPlayerBuffIcon", iconType = 6, order = 1}
            UiCompoentControoller.getIconEvent():emit({icon_cfg = iconCfg, eventType = "create"})
        end
    end
end

function UiCompoentLuaLayer:onEnter()
    self.hasEnter = true
    if self.showAllBtn then
    	self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:update(dt) end, 1, false)

    	registerScriptObserver(self, self.onMsgInitNotify, "msg.activity.init")

        local function onFirstPopupBlog(ref)
            self:firstPopupBlog()
        end
        local handler = self:registerHandler(onFirstPopupBlog)
        CCSafeNotificationCenter:registerScriptObserver(self, handler, "blogView_firstPopup")

        local function onChapterInfo(ref)
            self:refreshChapterInfo()
        end
        local handler = self:registerHandler(onChapterInfo)
        CCSafeNotificationCenter:registerScriptObserver(self, handler, "chapterInfo_refresh")

    	local function onPayFinished( ref )
    		local itemId = ref:getCString()
    		local itemData = LiBaoController.getInstance():getGoldExchangeItemById(itemId)
    		local itemShowType = "0"
    		if itemData and itemData.type == "3" and itemData.show_type ~= "" then
    			itemShowType = itemData.show_type
    		end
    		LiBaoController.getInstance():getExchangeDataRefersh(itemShowType)

            -- 周年礼包双倍刷新放在主ui，防止特殊展示返回类型礼包漏处理
            local liaboMulIns = require('game.activity.LibaoMultiple.LibaoMultipleMgr').getInstance()
            if liaboMulIns:isStatusActive() then
                --先设置下status，礼包页可实时刷新。后再请求数据保证数据同步服务器。
                liaboMulIns:setMultipleStatus('2')
                CCSafeNotificationCenter:postNotification("Libao_Multiple_Status_Change_End")
                liaboMulIns:reqData()
            end
        end
        local t = tolua.cast(self, "cc.Node")
        local handler = t:registerHandler(onPayFinished)
        CCSafeNotificationCenter:registerScriptObserver(self, handler, PAYMENT_COMMAND_RETURN)

        --章节按钮
    	-- self:createChapterNode()

    	self:update()
    	registerScriptObserver(self, self.towardAfterGiftReward, "toward_after_giftReward")

    	registerScriptObserver(self, self.civLevelUp, "Civilization_group_level_up")
        registerScriptObserver(self, self.onKillMonsterBuff, "MSG_kill_monster_buff")
        registerScriptObserver(self, self.animChapter, "UiCompoentLuaLayer:animChapter")
        registerScriptObserver(self, self.animHideChapter, "UiCompoentLuaLayer:animHideChapter")
        registerScriptObserver(self, self.showPortalTips, "msg.UiCompoentLuaLayer.addDoorUINode")
        registerScriptObserver(self, self.triggerSceneChange, GUIDE_INDEX_CHANGE)
        registerScriptObserver(self, self.checkFunIconOpen, "CheckFunIconOpen")
        registerScriptObserver(self, self.goldListExchagneNotify, GOLDEXCHANGE_LIST_CHANGE)
        self:goldListExchagneNotify()
        
        local function onFlyGold(dict)
            local gold = dict:valueForKey("gold"):getCString()
            if gold ~= "" then
                GlobalData:call("shared"):getProperty("playerInfo"):setProperty("gold", tonumber(gold))
                CCSafeNotificationCenter:postNotification("city_resources_update")
                self:showGoldFly()
            end
        end
        local handler2 = self:registerHandler(onFlyGold)
        CCSafeNotificationCenter:registerScriptObserver(self, handler2, "MSG_show_gold_fly")        
        
        registerScriptObserver(self, self.updateLuckdayNotify, "LuckdayActivityEffectNotify")
    end
    registerScriptObserver(self, self.onMSGScreenShot, "MSG_ScreenShot")

    -- UiCompoentControoller.tryAddThemeMonthIcon(iconListFileTbl)
    self:reLoadIconTbl()

    if not self.reqData_lock then
        self:AFLoginGMReqData()
    end
    if CCCommonUtilsForLua:isFunOpenByKey("super_camp") then
        XEvtTimer:on("OnSuperCampAttackLastChanged", function(data)
            Drequire("game.Battlefield.SuperCampController").getInstance():setData(data)
        end)
    end
    XEvtTimer:on("msgSceneChangeFinish", function()
        self.sceneId = SceneController:call("getCurrentSceneId")
        self:onCheckShowWorldBossComingAni()
        self:onGetSuperCampAttacklastTimes()
    end)

    --【Awen】新手士兵援助
    require("game.army.ArmyAidController").getInstance():reqInfo()
    registerScriptObserver(self, self.updateServerStopNotice, "ServerStopNotice")
    registerScriptObserver(self, self.destroyNewPlayerBuffIcon, "NewPlayerBuffIcon.destroy")
    registerScriptObserver(self, self.destroyExploreRoadIcon, "ExploreRoadIcon.destroy")
    self:checkNewPlayBuff()
end

function UiCompoentLuaLayer:onExit()
    self.hasEnter = false;
    if self.showAllBtn then
    	self.m_timePackageInit = false
    	self:getScheduler():unscheduleScriptEntry(self.m_entryId)

    	CCSafeNotificationCenter:unregisterScriptObserver(self, GOLDEXCHANGE_LIST_CHANGE)
        CCSafeNotificationCenter:unregisterScriptObserver(self, PAYMENT_COMMAND_RETURN)
    	CCSafeNotificationCenter:unregisterScriptObserver(self, "msg.activity.init")
    	unregisterScriptObserver(self, MSG_REPAY_INFO_INIT)
    	unregisterScriptObserver(self, "Civilization_group_level_up")
        unregisterScriptObserver(self, "blogView_firstPopup")
        unregisterScriptObserver(self, "chapterInfo_refresh")
        CCSafeNotificationCenter:unregisterScriptObserver(self, "MSG_show_gold_fly")
        unregisterScriptObserver(self, "MSG_kill_monster_buff")
        unregisterScriptObserver(self, GUIDE_INDEX_CHANGE)
        unregisterScriptObserver(self, "CheckFunIconOpen")
        unregisterScriptObserver(self, "LuckdayActivityEffectNotify")
    end
    unregisterScriptObserver(self, "MSG_ScreenShot")
    unregisterScriptObserver(self, "UiCompoentLuaLayer:animChapter")
    unregisterScriptObserver(self, "UiCompoentLuaLayer:animHideChapter")
    unregisterScriptObserver(self, "msg.UiCompoentLuaLayer.addDoorUINode")

    UiCompoentControoller.exit()

    XEvtTimer:off("msgSceneChangeFinish")
    XEvtTimer:off("OnSuperCampAttackLastChanged")
    unregisterScriptObserver(self, "ServerStopNotice")
    unregisterScriptObserver(self, "NewPlayerBuffIcon.destroy")
    unregisterScriptObserver(self, "ExploreRoadIcon.destroy")
end

function UiCompoentLuaLayer:onCleanup()
    UiCompoentControoller.getIconEvent():remove(self.onIconEvent,self)
end

function UiCompoentLuaLayer:triggerSceneChange(ref)
    local ref = tolua.cast(ref, "CCString")
    if ref then 
        local postStr = ref:getCString()
        if postStr == "UI_world_back" then
            self.triggerMark = true
            self.triggerMarkTime = 0
            
        end
    end
end

--触发器时间阀值
local TriggerThreshold = 3.0
function UiCompoentLuaLayer:updateTrigger(dt)
    if self.triggerMark then
        self.triggerMarkTime = self.triggerMarkTime + dt
        if self.triggerMarkTime > TriggerThreshold then
            TriggerEventUtils.startSceneChange()
            self.triggerMark = false
        end
    end
end

function UiCompoentLuaLayer:checkFunIconOpen()
    -- Dprint('UiCompoentLuaLayer:checkFunIconOpen')
    if CCCommonUtilsForLua:isFunOpenByKey("new_story_guide") then
        self:onSceneChanged(self.sceneId)
        if FunOpenController:isOpen(FUN_ICON_UI_Skill) then
            CCSafeNotificationCenter:postNotification("UIComponent::showSkillAnim")
        end
    end
end

function UiCompoentLuaLayer:doAddShareLayer()
    local params = self.screenShotParams
    local sLayer = Drequire("game.CommonPopup.ShareLayer"):create(params)
    local uiLayer = SceneController:call("getCurrentLayerByLevel", LEVEL_MAX-1)
    -- MyPrint("sLayer,uiLayer:",sLayer,uiLayer)
    if sLayer and uiLayer then 
        sLayer:setZOrder(99999999)
        uiLayer:addChild(sLayer)
    end
end

function UiCompoentLuaLayer:onMSGScreenShot(ref)
    if not CCCommonUtilsForLua:isFunOpenByKey("share_image") or isCrossServerNow() then
        return
    end
    if ref then 
        local params = dictToLuaTable(ref) 
        params.imgFilePath = params.imageLocalPath
        self.screenShotParams = params
        self:doAddShareLayer()
    end
end

function UiCompoentLuaLayer:onKillMonsterBuff(ref)
    if not CCCommonUtilsForLua:isFunOpenByKey("samuraikill_monster") or isCrossServerNow() then
        return
    end
    if ref then
        local params = dictToLuaTable(ref) 
        self.m_killMonsterBuff = tonumber(params.buffEffect)
        self.m_killMonsterStartTime = tonumber(params.buffStartTime)/1000
        self.m_killMonsterEndTime = tonumber(params.buffEndTime)/1000
    end
    if self.m_killMonsterBuff and self.m_killMonsterStartTime and self.m_killMonsterEndTime then
        if DynamicResourceController2:call("checkDynamicResource", "SamuraiShodown_face") == false then return end
        if self.m_killMonsterBuffNode then self.m_killMonsterBuffNode:removeFromParent() end
        self.m_killMonsterBuffNode = cc.Node:create()
        local path = "Font_Samurai_" .. self.m_killMonsterBuff .. ".png"
        local spr = CCLoadSprite:createSprite(path)
        local sprGray = CCLoadSprite:createSprite(path)
        CCCommonUtilsForLua:call("setSpriteGray", sprGray, true)
        self.m_killMonsterBuffNode:setContentSize(spr:getContentSize())
        self.m_killMonsterClipNode = CCClipNode:call("create", self.m_killMonsterBuffNode:getContentSize().width, self.m_killMonsterBuffNode:getContentSize().height)
        self.m_killMonsterClipNode = tolua.cast(self.m_killMonsterClipNode, "cc.Node")
        self.m_killMonsterClipNode:setAnchorPoint(cc.p(0, 0.5))
        sprGray:setAnchorPoint(cc.p(0, 0.5))
        spr:setAnchorPoint(cc.p(0, 0))
        self.m_killMonsterTouchNode = cc.Node:create()
        self.m_killMonsterTouchNode:setAnchorPoint(cc.p(0, 0.5))
        self.m_killMonsterTouchNode:setContentSize(spr:getContentSize())
        self.m_killMonsterBuffNode:addChild(sprGray)
        self.m_killMonsterBuffNode:addChild(self.m_killMonsterClipNode)
        self.m_killMonsterBuffNode:addChild(self.m_killMonsterTouchNode)
        self.m_killMonsterClipNode:addChild(spr)
        self:addChild(self.m_killMonsterBuffNode)
        if CCCommonUtilsForLua:call("isIosAndroidPad") then
            self.m_killMonsterBuffNode:setPosition(self.contentSize.width -680, self.contentSize.height)
        else
            self.m_killMonsterBuffNode:setPosition(self.contentSize.width -550, self.contentSize.height)
        end
    end
end

function UiCompoentLuaLayer:reLoadIconTbl()
	-- dump(self.iconListDataTbl, "UiCompoentLuaLayer:reLoadIconTbl is: ")
	for i, icon in pairs(self.iconListDataTbl or {}) do
		icon:removeFromParent()
	end
	self.iconListDataTbl = {}
    if self.beIconScrollFunOn then
        if self.rightUpInfoDate then
            for i, icon in pairs(self.rightUpInfoDate.nodeList or {}) do
                icon:removeFromParent()         
            end
            self.rightUpInfoDate.nodeList = {}
        end

        if self.leftDownInfoData then
            for i, icon in pairs(self.leftDownInfoData.nodeList or {}) do
                icon:removeFromParent()         
            end
            self.leftDownInfoData.nodeList = {}
        end
    end
	local iconSize = cc.size(IconWidth, IconHeight)
	local contentSize = self.contentSize
	if needReload then
		local reloadNode = cc.Node:create()
		reloadNode:setContentSize(iconSize)
		local label = cc.Label:createWithSystemFont("重新加载", "Helvetica", 20, cc.size(0.0,0))
    	local bg = CCLoadSprite:createSprite("icon_BG.png")
    	reloadNode:addChild(bg)
    	bg:setScale(0.7)
    	bg:setPosition(cc.p(40, 40))
    	reloadNode:addChild(label)
    	label:setPosition(cc.p(40, 40))

		reloadNode.iconType = 1
		reloadNode.iconName = "testNode"
	    reloadNode:setAnchorPoint(cc.p(0.5, 0.5))
		reloadNode.touchEvent = function()
			self:reLoadIconTbl()
		end
        self:addIconListNode(reloadNode)
    end
	for i, fileData in pairs(iconListFileTbl) do
        self:makeIcon(fileData,iconSize, contentSize)
	end
    if self.showAllBtn then
       self:updateDownLeftPos()
    end
	self:updateRightUpPos()
end

function UiCompoentLuaLayer:makeIcon( fileData, iconSize, contentSize )
    iconSize = iconSize or cc.size(IconWidth, IconHeight)
    contentSize = contentSize or self.contentSize
    local view = nil
    if self.showAllBtn or (self.onlyShowDBRecord and (fileData.iconName == "game.UIComponent.DragonBattleRecordIcon"
            or fileData.iconName == "game.UIComponent.DragonBattleDataIcon"
            or fileData.iconName == "game.UIComponent.DragonBattleObMvpIcon"
            or (GlobalData:call("shared"):getProperty("obing") == false and 
                fileData.iconName == "game.UIComponent.QuickSwitchEquipmentNode")) ) then
        -- Dprint("fileData.iconName", fileData.iconName)
        view = Drequire(fileData.iconNameSub or fileData.iconName).create(iconSize, contentSize)
    end

    if view then
        local fo_MainInterfaceConfig = isFunOpenByKey("MainInterfaceConfig")
        if fo_MainInterfaceConfig then
            if table.isNilOrEmpty(self.main_interface_config) then
                self.main_interface_config = {}
                local xmlData = CCCommonUtilsForLua:getGroupByKey("main_interface_config")
                for k,v in pairs(xmlData or {}) do
                    local order1 = 0
                    local order2 = 0
                    if string.isNilOrEmpty(v.order) == false then
                        local orderList = string.splitNSep(v.order, ";")
                        order1 = atoi(orderList[1])
                        if #orderList >= 2 then
                            order2 = atoi(orderList[2])
                        end
                    end
                    self.main_interface_config[v.iconName] = {
                        iconType = atoi(v.iconType), 
                        order = order1, 
                        order2 = order2,
                        alone = atoi(v.alone),
                        startTime = atoi(v.startTime),
                        endTime = atoi(v.endTime),
                        scene = v.scene or 'base',
                    }
                end
            end

            local _data = self.main_interface_config[fileData.iconNameSub or fileData.iconName]
            if _data then
                fileData.iconType = _data.iconType
                fileData.alone = _data.alone
                fileData.scene = _data.scene
                local now = getTimeStamp()
                if now >= _data.startTime and now < _data.endTime then
                    fileData.order = _data.order2
                else
                    fileData.order = _data.order
                end
            end
        end

        view.m_fileData = fileData
        registerNodeEventHandler(view)
        -- MyPrint('UiCompoentLuaLayer:reLoadIconTbl icon', fileData.iconName)
        view.iconType = fileData.iconType
        view.iconName = fileData.iconName
        view.guide = fileData.guide
        view.order = fileData.order
        -- self:setPosition(cc.p(IconWidth*0.5, IconHeight*0.5))
        view:setAnchorPoint(cc.p(0.5, 0.5))
        self:addIconListNode(view, fileData, fo_MainInterfaceConfig)
    end
    return view
end

function UiCompoentLuaLayer:findIcon( tbl )
    if table.isNilOrEmpty( tbl ) then
        return
    end

    if string.isNilOrEmpty( tbl.iconName ) then
        return
    end

    local r = {}
    local iconAloneList = {} --补充新加的列表iconListAlone,不然在删除操作时会漏掉该列表中元素
    if self.beIconScrollFunOn then
        if tbl.iconType == 1 then
            r = self.rightUpInfoDate.nodeList
        elseif tbl.iconType == 2 or tbl.iconType == 3 then
            if tbl.alone == 1 then
                r = self.iconListDataTbl
                iconAloneList = self.iconListAlone
            else
                r = self.leftDownInfoData.nodeList
            end
        else
            r = self.iconListDataTbl
        end
    else
        r = self.iconListDataTbl
    end

    local iconName = tbl.iconName
    local findInfo,findidx = table.find(r,function ( cur )
        return cur.iconName == iconName
    end)
    local aloneIdx = table.findVar( iconAloneList,findInfo)
    return findInfo,findidx,r,aloneIdx,iconAloneList
end

function UiCompoentLuaLayer:getAloneParentBySceneType(tpe)
    -- 根据scenetype 获取单独节点的父节点
    if string.isNilOrEmpty(tpe) then
        tpe = 'base'
    end
    local TpeToNode = {
        base = self.m_aloneBaseNode,
        night = self.m_aloneBaseNodeNC,
        common = self.m_aloneCommonNode,
    }
    return TpeToNode[tpe] or self.m_aloneBaseNode
end

function UiCompoentLuaLayer:addIconListNode(node, config, isSort)
    if self.beIconScrollFunOn then
        if node.iconType == 1 then
            self.rightUpInfoDate.listBaseNode:addChild(node)
            if node.setIconScale then
                node:setIconScale()
            else
                node:setScale(0.875)        -- self.rightUpInfoDate.nodeHeight / IconHeight
            end
            node:setPositionX(1000)     -- 挂到右侧去
            self.rightUpInfoDate.nodeList[#self.rightUpInfoDate.nodeList + 1] = node
            -- 排序
            if isSort then
                table.sort(self.rightUpInfoDate.nodeList, 
                    function(a,b) 
                        if a and b then
                            return atoi(a.order) < atoi(b.order) 
                        end
                        return false 
                    end )
                return
            end
        elseif node.iconType == 2 or node.iconType == 3 then
            if config and config.alone == 1 then
                local aloneNode = self:getAloneParentBySceneType(config.scene)
                aloneNode:addChild(node)
                self.iconListAlone[#self.iconListAlone + 1] = node
                self.iconListDataTbl[#self.iconListDataTbl + 1] = node
            else
                self.leftDownInfoData.listBaseNode:addChild(node)
                node:setScale(0.875)        
                node:setPositionX(-1000)     
                self.leftDownInfoData.nodeList[#self.leftDownInfoData.nodeList + 1] = node
            end
        else
            local aloneNode = self:getAloneParentBySceneType(config.scene)
            aloneNode:addChild(node)
            self.iconListDataTbl[#self.iconListDataTbl + 1] = node
        end
    else
        local aloneNode = self:getAloneParentBySceneType(config.scene)
        aloneNode:addChild(node)
        self.iconListDataTbl[#self.iconListDataTbl + 1] = node
    end
    -- 排序
    table.sort(self.iconListDataTbl, 
        function(a,b) 
            if a and b then
                return atoi(a.order) < atoi(b.order) 
            end
            return false 
        end)
end

function UiCompoentLuaLayer:onTouchBegan(x, y)
    self.v_chapterCount = 0
    self.guideAwakeCount = 0
    self.guideRewardCount = 0

	if self.hasEnter == false then
		return
	end
    self.curTouchExtActId = nil
	local popupViewNum = PopupViewController:call("getInstance"):call("getCurrViewCount")
	if popupViewNum > 0 then
		return false
	end

	if self:isVisible(true) == false then
		if self.m_chapterNode and self.m_chapterNode:isVisible() and touchInside(self.m_chapterNode ,x,y) then
			self.touchType = 12
			return true
        elseif self.m_chapterTaskNode and self.m_chapterTaskNode:isVisible() and touchInside(self.m_chapterTaskBg ,x,y) then
            self.touchType = 13
            return true
		else
			return false
		end
	end

   if self.m_chapterNode and self.m_chapterNode:isVisible() and touchInside(self.m_chapterNode ,x,y) then
		self.touchType = 12
		return true
    elseif self.m_chapterTaskNode and self.m_chapterTaskNode:isVisible() and touchInside(self.m_chapterTaskBg ,x,y) then
        self.touchType = 13        
        return true
    elseif self.m_killMonsterTouchNode and self.m_killMonsterTouchNode:isVisible() and touchInside(self.m_killMonsterTouchNode, x, y) then
        self.touchType = 33
        if self.m_killMonsterBuff == 1 then
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("134072", getLang("101502")))
        else
            local now = getTimeStamp()
            local time = format_time(self.m_killMonsterEndTime-now)
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("134072", time))
        end
        return true
    elseif self.beIconScrollFunOn and isTouchInsideVis(self.rightUpInfoDate.baseNode, x, y) then
        -- 2000起为右上滑动专用
        self.touchType = 2000
        self.touchX = x
        self.touchY = y
        local infoData = self.rightUpInfoDate
        if infoData and infoData.touchArrowNode and infoData.touchArrowNode:isVisible() and touchInside(infoData.touchArrowNode, x, y) then
            infoData.touchArrowNode:setTouchScaled(true)
        end
        return true
    elseif self.beIconScrollFunOn and self.leftDownInfoData and self.leftDownInfoData.baseNode:isVisible() and touchInside(self.leftDownInfoData.baseNode, x, y) then
        -- 3000起为左下滑动专用
        self.touchType = 3000
        self.touchX = x
        self.touchY = y
        local infoData = self.leftDownInfoData
        if infoData and infoData.touchArrowNode and infoData.touchArrowNode:isVisible() and touchInside(infoData.touchArrowNode, x, y) then
            infoData.touchArrowNode:setTouchScaled(true)
        end
        return true
    else
    	-- 通用按钮触摸,已占用1000+
		for i, icon in pairs(self.iconListDataTbl) do
			if icon:isVisible(true) and touchInside(icon, x, y) then
				self.touchType = 1000 + i
				return true
			end
		end
	end
end


------onTouchBegan-------

function UiCompoentLuaLayer:onTouchMoved(x, y)
	-- dump(" UiCompoentLuaLayer:onTouchMoved() ~~~~~~~~~~~~~~BBBBBBBBBBBB")
    if self.touchType == 2000 or self.touchType == 3000 then
        if ccpSquareDistance(cc.p(self.touchX, self.touchY), cc.p(x, y)) > 100 then
            self.touchType = nil
        end
    end
end

--------------onTouchEnded------------
function UiCompoentLuaLayer:onTouchEnded(x, y)
    if self.touchType ~= 12 and self.touchType ~= 13 and GuideController:call("getCurGuideID") == '3919800' then
        GuideController:call("next")
    end

    if self.rightUpInfoDate and self.rightUpInfoDate.touchArrowNode then
        self.rightUpInfoDate.touchArrowNode:setTouchScaled(false)
    end
    if self.leftDownInfoData and self.rightUpInfoDate.touchArrowNode then
        self.leftDownInfoData.touchArrowNode:setTouchScaled(false)
    end

    if self.touchType == 12 and self.m_chapterNode and touchInside(self.m_chapterNode,x,y) then
        ChapterController.getInstance():openChapterView()
    elseif self.touchType == 13 and self.m_chapterTaskNode and touchInside(self.m_chapterTaskBg ,x,y) then
        ChapterController.getInstance():openChapterView()
    elseif self.touchType == 2000 then
        -- 右上触摸专用
        self:rightUpScrollTouchEvent(x, y)
    elseif self.touchType == 3000 then
        -- 左下触摸专用
        self:leftDownScrollTouchEvent(x, y)
    else
    	-- 通用按钮触摸,已占用1000+
    	if self.touchType and self.touchType > 1000 then
    		local index = self.touchType - 1000
    		local curIcon = self.iconListDataTbl[index]
    		if curIcon and touchInside(curIcon, x, y) then
    			if curIcon.touchEvent then
    				curIcon:touchEvent()
    				return
    			end
    		end
    	end
	end
    self.curTouchExtActId = nil
end
------------onTouchEnded-----------

function UiCompoentLuaLayer:onSceneChanged(sceneId)
	self.sceneId = sceneId
	if sceneId == SCENE_ID_WORLD then
		self.m_worldFaveNode:setVisible(true)
		
		if self.m_chapterNode ~= nil then
			self.m_chapterNode:setVisible(false)
		end
        
		if self.m_chapterTaskNode ~= nil then
            self.m_chapterTaskNode:setVisible(false)
        end

        if self.m_UIQuestNode then
            self.m_UIQuestNode:setVisible(false)
        end
	else
		self.m_worldFaveNode:setVisible(false)
        local _dict = CCDictionary:create()       
        COSDataController.getInstance():sendPushLimitInfo(_dict)
	end

    if self.beIconScrollFunOn and self.leftDownInfoData and self.leftDownInfoData.baseNode then
        if sceneId == SCENE_ID_WORLD then
            self:hideLeftDownNode()
        else
            -- self.leftDownInfoData.baseNode:setVisible(true)
        end
    end

	for i, icon in pairs(self.iconListDataTbl) do
		if icon.onSceneChanged then
			icon:onSceneChanged(sceneId)
		end
	end

    if self.beIconScrollFunOn then
        local infoData = self.rightUpInfoDate
        if infoData then
            for i, icon in pairs(infoData.nodeList) do
                if icon.onSceneChanged then
                    icon:onSceneChanged(sceneId)
                end
            end
        end
        infoData = self.leftDownInfoData
        if infoData then
            for i, icon in pairs(infoData.nodeList) do
                if icon.onSceneChanged then
                    icon:onSceneChanged(sceneId)
                end
            end
        end
    end
    
    local transDoorNode = self:getChildByTag(2525)
    if transDoorNode then
        transDoorNode:checkShow()
    end

    self:refreshChapgerNode()
    
    require("game.flyHint.FlyHintManager").getManager():onSceneChanged()

    if self.vnAuditInfoTips then
        self.vnAuditInfoTips:onSceneChanged(sceneId)
    end
    -- self:onCheckShowWorldBossComingAni(sceneId)

    require("game.buildingBtns.BuildingBtnManager").getInstance():clearShowBtn()

    self:requestPlayerStatus()

    self:checkNightCity()
end

function UiCompoentLuaLayer:checkNightCity()
    -- 监测永夜城 的节点显示
    if self.sceneId == SCENE_ID_NIGHTCITY then
        if self.beIconScrollFunOn then
            self.leftDownInfoData.baseNode:setVisible(false)
            self.rightUpInfoDate.baseNode:setVisible(false)
        end
        self.m_aloneBaseNode:setVisible(false)
        self.m_aloneBaseNodeNC:setVisible(true)
    else
        if self.beIconScrollFunOn then
            self.leftDownInfoData.baseNode:setVisible(self.sceneId ~= SCENE_ID_WORLD)
            self.rightUpInfoDate.baseNode:setVisible(true)
        end
        self.m_aloneBaseNode:setVisible(true)
        self.m_aloneBaseNodeNC:setVisible(false)
    end

end

function UiCompoentLuaLayer:update(t)
	if self:isVisible(true) then
		for i, icon in pairs(self.iconListDataTbl) do
			-- dump(icon.iconName, " icon listName is: ")
			if icon.updateEvent then
				icon:updateEvent()
			end
		end

		self:updateRightUpPos()
        self:updateDownLeftPos()
        self:updateNightCityPos()

        if self.m_killMonsterBuff and self.m_killMonsterEndTime and self.m_killMonsterStartTime and self.m_killMonsterBuffNode then
            if DynamicResourceController2:call("checkDynamicResource", "SamuraiShodown_face") == true then
                local now = getTimeStamp()
                if self.m_killMonsterBuff == 1 then
                    self.m_killMonsterClipNode:setContentSize(cc.size(self.m_killMonsterBuffNode:getContentSize().width, self.m_killMonsterBuffNode:getContentSize().height))
                else
                    if now < self.m_killMonsterEndTime then
                        local scale = (self.m_killMonsterEndTime-now)/(self.m_killMonsterEndTime-self.m_killMonsterStartTime)
                        self.m_killMonsterClipNode:setContentSize(cc.size(self.m_killMonsterBuffNode:getContentSize().width * scale, self.m_killMonsterBuffNode:getContentSize().height))
                    else
                        self.m_killMonsterClipNode:setContentSize(cc.size(self.m_killMonsterBuffNode:getContentSize().width, self.m_killMonsterBuffNode:getContentSize().height))
                        self.m_killMonsterBuff = 1
                        self.m_killMonsterStartTime = -1
                        self.m_killMonsterEndTime = -1
                        self:onKillMonsterBuff()
                    end
                end
            end
        end
	else
		if self.m_chapterNode and self.m_chapterNode:isVisible() then
    		local offsetY = IconHeight + IconOffset
			local posY = IconHeight*0.5
		    if not self.m_UIQuestNode:isVisible() then
		    	posY = posY - offsetY
		    end
			self.m_chapterNode:setPositionY(posY)
            self.m_chapterNode:setPositionX(IconWidth*0.5)
            self.m_chapterTaskNode:setPositionY(posY - IconHeight*0.5)
            self.m_chapterTaskNode:setPositionX(IconWidth*0.5 + 120)
		end
	end
    self:updateChapterGuide()    
    self.initTime = self.initTime+1
    DailyActivityManager.updateSpecialActivityEndtime()
    self:updateTrigger(t)

    if self.vnAuditInfoTips then
        self.vnAuditInfoTips:update(t)
    end
end

-- 左下逻辑
function UiCompoentLuaLayer:updateDownLeftPos()
	local count = 0
	local pos = IconWidth*0.5
	local posY = IconHeight*0.5
    local offset = IconWidth + IconOffset
    local offsetY = IconHeight + IconOffset
    if self.m_chapterNode and ChapterController:getInstance():isChapterOpen() then
        self.m_UIQuestNode:setVisible(false)
    end
    if not self.m_UIQuestNode:isVisible() then
    	posY = posY - offsetY
    end
    local initPosY = posY
    local initPosX = pos

    self.m_downLeftNodeNum = 0

    --新版任务系统
    if self.m_chapterNode and ChapterController:getInstance():isChapterOpen() then
        self.m_chapterNode:setPosition(initPosX, posY)
        self.m_chapterTaskNode:setPosition(initPosX + 120, posY - IconHeight*0.5)
        posY = posY + offsetY
        initPosY = initPosY + offsetY
        self.m_downLeftNodeNum = self.m_downLeftNodeNum + 1
    end

	for i, icon in pairs(self.iconListDataTbl) do
        if icon.iconType == 2 and icon:isVisible() then
            --注意: 如果要改为setPosition(float x, float y),得修改一下BattlefieldIcon setPosition接口
			icon:setPosition(cc.p(initPosX, posY))
			posY = posY + offsetY
		end
	end

    if self.beIconScrollFunOn then
        local node = self:getChildByTag(8932)
        if node then
            node:setPosition(cc.p(initPosX, posY - IconHeight*0.5))
            posY = posY + offsetY
            self:updateLeftDownScroll()
        end
    end

    pos = pos + offset
	-- 横向数据
	if self.m_worldFaveNode:isVisible() then
		self.m_worldFaveNode:setPosition(cc.p(pos, initPosY))
		pos = pos + offset
	end

	for i, icon in pairs(self.iconListDataTbl) do
		if icon.iconType == 3 and icon:isVisible() then
			icon:setPosition(cc.p(pos, initPosY))
			pos = pos + offset
		end
	end
    
    if self.sceneId == SCENE_ID_WORLD then
        posY = self.leftPosOffsetY - self.leftStartOffSetY
        for i, icon in pairs(self.iconListDataTbl) do
            if icon.iconType == 5 and icon:isVisible() then
                icon:setPosition(cc.p(initPosX, posY))
                posY = posY + offsetY
            end
        end
    end
    
    self:setLeftDownIconRedPot()
end

-- 右上逻辑
function UiCompoentLuaLayer:updateRightUpPos()
	local count = 0;
	local initPosY = self.contentSize.height - IconHeight*0.5;
	local posY = initPosY
    local offset = IconHeight+IconOffset;
    local initPosX = self.contentSize.width - IconWidth*0.5

	-- 纵向部分
    local visibleNum = 0 --第一列的可见数量
    if self.beIconScrollFunOn then
        self:updateRightUpScroll()
        for i, icon in pairs(self.rightUpInfoDate.nodeList) do
            if icon:isVisible() then
                visibleNum = visibleNum+1
            end
        end
        --隐藏掉列表
        if visibleNum <=0 then
            self.rightUpInfoDate.baseNode:setVisible(false)
        else
            self.rightUpInfoDate.baseNode:setVisible(true)
        end
        if self.sceneId == SCENE_ID_NIGHTCITY then
            self.rightUpInfoDate.baseNode:setVisible(false)
        end
    else
        for i, icon in pairs(self.iconListDataTbl) do
            if icon.iconType == 1 and icon:isVisible() then
                icon:setPosition(cc.p(initPosX, posY))
                posY = posY - offset
                visibleNum = visibleNum+1
            end
        end
    end

    --世界争霸隐藏右上角
    if GlobalData:call("shared"):getProperty("serverType") == ServerType.SERVER_WORLD_CRAFT then
        if self.rightUpInfoDate and self.rightUpInfoDate.baseNode then
            self.rightUpInfoDate.baseNode:setVisible(false)
        end
    end

    --横向部分 第二列
    local posX = initPosX - IconWidth - 10
    if visibleNum == 0 then
        --如果第一列为空，那么第二列将变为第一列
        posX = posX + IconWidth
    end
    posY = initPosY
    for i, icon in pairs(self.iconListDataTbl) do
        if icon.iconType == 6 and icon:isVisible() then
            icon:setPosition(cc.p(posX, posY))
            posY = posY - offset
        end
    end
end

function UiCompoentLuaLayer:updateNightCityPos()
    -- 永夜城按钮位置

    -- 右上
    local initPosY = self.contentSize.height - IconHeight*0.5;
	local posY = initPosY
    local offset = IconHeight+IconOffset;
    local initPosX = self.contentSize.width - IconWidth*0.5
    local posX = initPosX - 10

    for i, icon in pairs(self.iconListDataTbl) do
        if icon.iconType == 11 and icon:isVisible() then
            icon:setPosition(cc.p(posX, posY))
            posY = posY - offset
        end
    end
end

function UiCompoentLuaLayer:openActivityView(id)
    local pageId = nil
    if id < 0 then --pageId使用负数表示
        pageId = tostring(-id)
    else
        actId = tostring(id)
    end
    if pageId and pageId == "9012501" then
        require("game.LiBao.Repay.RepayController")
        if RepayController.getInstance():isBegin() then
            RepayController.getInstance():fireEvent("RepayViewCreate")
        end
    else
        ActivityController.getInstance():shouActUIById(actId)
    end
end

-----------------------------------章节按钮-----------------------------------
function  UiCompoentLuaLayer:createChapterNode()
	if not self.m_chapterBaseNode then
		return
	end
    if self.m_chapterNode then
        -- 已经存在，返回。
        return
    end
    -- 章节任务
    self.m_chapterTaskNode = cc.Node:create()
	self.m_chapterBaseNode:addChild(self.m_chapterTaskNode)
    self.m_chapterTaskNode:setVisible(false)
    self.m_chapterTaskNode:setPosition(cc.p(IconWidth*0.5 + 120, IconWidth - IconHeight*0.5))
    self.m_chapterTaskBg = CCLoadSprite:call("createSprite", "new_title_bg.png")
    if self.m_chapterTaskBg then
        self.m_chapterTaskNode:addChild(self.m_chapterTaskBg)
        self.m_chapterTaskBg:setScaleX(1.5)
        self.m_chapterTaskBg:setPosition(cc.p(-10, IconHeight*0.5))

        self.m_chapterTaskLabel = cc.Label:createWithSystemFont("", "Helvetica", 20, cc.size(0, 0))
        self.m_chapterTaskLabel:setPosition(cc.p(-60, IconHeight*0.5))
        self.m_chapterTaskLabel:setAnchorPoint(cc.p(0, 0.5))
        self.m_chapterTaskLabel:setColor(cc.c3b(236, 220, 170))
        self.m_chapterTaskLabel:setHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
        self.m_chapterTaskLabel:setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
        self.m_chapterTaskNode:addChild(self.m_chapterTaskLabel)

        -- 105036=领取奖励
        self.m_chapterTaskLabel2 = cc.Label:createWithSystemFont("["..getLang("105036").."]", "Helvetica", 20, cc.size(0, 0))
        self.m_chapterTaskLabel2:setPosition(cc.p(-60, IconHeight*0.5))
        self.m_chapterTaskLabel2:setAnchorPoint(cc.p(0, 0.5))
        self.m_chapterTaskLabel2:setColor(cc.c3b(208, 124, 68))
        self.m_chapterTaskLabel2:setHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
        self.m_chapterTaskLabel2:setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
        self.m_chapterTaskNode:addChild(self.m_chapterTaskLabel2)
    end    

	self.m_chapterNode = cc.Node:create()
	self.m_chapterNode:setContentSize(cc.size(IconWidth, IconHeight))
	self.m_chapterBaseNode:addChild(self.m_chapterNode)

	self.m_chapterNode:setPosition(cc.p(IconWidth*0.5, IconHeight*0.5));
    self.m_chapterNode:setAnchorPoint(cc.p(0.5, 0.5))
    self.m_chapterNode:setVisible(false)
    
   	self.m_chapterNode:setPositionY(IconWidth)
    CCLoadSprite:doResourceByCommonIndex(3,true)
    CCLoadSprite:doResourceByCommonIndex(304,true)
    local _iconBg = CCLoadSprite:call("createSprite", "princessTalkBg.png")
    if _iconBg then
        self.m_chapterNode:addChild(_iconBg)
        _iconBg:setPosition(cc.p(IconWidth*0.5 , IconHeight*0.5))
    end
	local icon = CCLoadSprite:call("createSprite", "story_icon.png")
	if icon then
		self.m_chapterNode:addChild(icon)
		local size = icon:getContentSize()
		icon:setPosition(cc.p(IconWidth*0.5 , IconHeight*0.5))
	end
    self.m_chapterGreenBallNode = cc.Node:create()
    local greenBall = CCLoadSprite:call("createSprite", "info_green.png")
    self.m_chapterGreenBallNode:addChild(greenBall)
    self.m_chapterLabel = cc.Label:createWithSystemFont("9", "Helvetica", 20, cc.size(0.0,0))
    self.m_chapterLabel:setColor(cc.c3b(255, 250, 230))
    self.m_chapterGreenBallNode:addChild(self.m_chapterLabel)
    self.m_chapterGreenBallNode:setPosition(cc.p(70, 60))
    self.m_chapterNode:addChild(self.m_chapterGreenBallNode)
    self.m_chapterGreenBallNode:setVisible(false)
    self.v_chapterCount = 0
    self.guideAwakeCount = 0
    self.guideRewardCount = 0
end

-- 章节任务图标和任务条动画
function UiCompoentLuaLayer:animChapter(  )
    self:createChapterNode()
    FunBuildController:call("SendRecordeToServer", 'ui_chapter')
    self.isChapterShow = true
    self.m_chapterNode:setVisible(self.isChapterShow)
    

    local _scale0 = cc.ScaleTo:create(0, 0, 1)
    local _show = cc.Show:create()
    local _scale1 = cc.ScaleTo:create(0.5, 1, 1)
    local _delay = cc.DelayTime:create(1)
    local function callback()
        GuideController:call("next")
    end
    local _callback = cc.CallFunc:create(callback)
    local _seq = cc.Sequence:create(_scale0, _show, _scale1, _delay, _callback)
    self.m_chapterTaskNode:runAction(_seq)
end

function UiCompoentLuaLayer:animHideChapter(  )
    self:createChapterNode()
    FunBuildController:call("SendRecordeToServer", 'ui_hide_chapter')
    self.isChapterShow = false
    self.m_chapterNode:setVisible(self.isChapterShow)
    
    
    local _scale0 = cc.ScaleTo:create(0, 1, 1)
    local _show = cc.Show:create()
    local _scale1 = cc.ScaleTo:create(0.5, 0, 1)
    local _hide = cc.Hide:create()
    local _delay = cc.DelayTime:create(1)
    local function callback()
        self.m_chapterNode:setVisible(false)
        GuideController:call("next")
    end
    local _callback = cc.CallFunc:create(callback)
    local _seq = cc.Sequence:create(_scale0, _show, _scale1, _hide, _delay, _callback)
    self.m_chapterTaskNode:runAction(_seq)
end

function  UiCompoentLuaLayer:refreshChapterInfo()
    if not self.m_chapterBaseNode then
        return
    end
    if not ChapterController:getInstance():isChapterOpen() then
        return
    end
    self:createChapterNode()
    local now = ChapterController:getInstance().m_completeCnt
    local _tip, _process, _total = ChapterController:getInstance():getChapterProString()
    self.m_chapterGreenBallNode:setVisible(now > 0)
    self.m_chapterTaskLabel2:setVisible(now > 0)
    if now > 0 then
        self.m_chapterLabel:setString(tostring(now))
        self.m_chapterTaskLabel:setString(_tip)
        self.m_chapterTaskLabel2:setPositionX(self.m_chapterTaskLabel:getPositionX()+self.m_chapterTaskLabel:getContentSize().width)
    else
        self.m_chapterTaskLabel:setString(string.format("%s[%d/%d]",_tip, _process, _total))
    end
end

function UiCompoentLuaLayer:updateChapterGuide()
    -- Dprint("UiCompoentLuaLayer:updateChapterGuide", ChapterController:getInstance():isChapterOpen(), 
    --     self.m_chapterNode:isVisible(), GuideController:call("getCurGuideID"), self.v_chapterCount)
    if self.sceneId == SCENE_ID_MAIN then
        if ChapterController:getInstance():isChapterOpen() then
            self:createChapterNode()
            if self.m_chapterNode:isVisible() then
                if GuideController:call("isInTutorial") == false and PopupViewController:call("getCurrentPopupView")==nil then
                    if isFunOpenByKey("story_awaken") then
                        OnlineTimeController:reqData()
                        local config = OnlineTimeController:getRewardConfig()
                        if config then
                            self.guideRewardCount = self.guideRewardCount + 1
                            if self.guideRewardCount > OnlineTimeController:getRewardNoOperation() then
                                self.guideRewardCount = 0
                                GuideController:call("setGuide", config.guideId)
                                config.sleep = getTimeStamp()
                                return
                            end
                        end

                        config = OnlineTimeController:getAwakeConfig()
                        if config then
                            self.guideAwakeCount = self.guideAwakeCount + 1
                            if self.guideAwakeCount > OnlineTimeController:getAwakeNoOperation() then
                                self.guideAwakeCount = 0
                                GuideController:call("setGuide", config.guideId)
                                config.sleep = getTimeStamp()
                                return
                            end
                        end
                    end

                    local _chapterSection = atoi(ChapterController:getInstance().index)
                    if _chapterSection < 5 then
                        self.v_chapterCount = self.v_chapterCount + 1
                        local _guideId = '3919800'
                        if self.v_chapterRestCount == nil then
                            self.v_chapterRestCount = atoi(CCCommonUtilsForLua:call("getPropByIdGroup","guide",_guideId,"para1"))
                        end
                        if self.v_chapterCount > self.v_chapterRestCount then
                            self.v_chapterCount = 0
                            GuideController:call("setGuide", _guideId)
                        end
                    end
                else
                    self.v_chapterCount = 0
                    self.guideAwakeCount = 0
                    self.guideRewardCount = 0
                end                    
            end
        end
    end
end

function UiCompoentLuaLayer:towardAfterGiftReward(Ref)
	local towardType = Ref:getValue()
	if towardType == 1 then
		local lua_path = "game.activity.GoldCoinCarnival.Activity_GoldCoinCarnival"
	    local view = Drequire(lua_path):create("57161", 1)
	    if view then
	    	PopupViewController:addPopupView(view)
    	end
    end
end

function UiCompoentLuaLayer:civLevelUp()
	CivilizationController:fireCommonEvent("openCivilizationUpgradeView")
end

function UiCompoentLuaLayer:getGuideNodeByKey( key )
    if self.initTime < 4 then
        return nil
    end
    if key == 'LUA_UI_chapter' then -- and self.m_chapterNode:isVisible()
        self:createChapterNode()
        local function callBack()
            GuideController:call("next")
        end
        GuideController:call("setCallback", cc.CallFunc:create(callBack))
        return self.m_chapterNode
    elseif key == 'LUA_UI_chapterRest' then
        self:createChapterNode()
        local function callBack()
            GuideController:call("next")
        end
        GuideController:call("setCallback", cc.CallFunc:create(callBack))
        return self.m_chapterNode
    elseif key == "LUA_UI_chapterTips" and self.m_chapterTaskNode then
        local function callBack()
            GuideController:call("next")
        end
        GuideController:call("setCallback", cc.CallFunc:create(callBack))
        return self.m_chapterTaskNode
    end

    if self.iconListDataTbl then
        for i, v in pairs(self.iconListDataTbl) do
            if v.guide == key then
                return v
            end
        end
    end
    if self.beIconScrollFunOn and self.rightUpInfoDate then
        for i, icon in pairs(self.rightUpInfoDate.nodeList) do
            if icon.guide == key then
                return icon
            end
        end
    end
    if self.beIconScrollFunOn and self.leftDownInfoData then
        for i, icon in pairs(self.leftDownInfoData.nodeList) do
            if icon.guide == key then
                return icon
            end
        end
    end
	return nil
end

--飞金币动画
function UiCompoentLuaLayer:showGoldFly()
    self:removeChildByTag(66666)
    local realSize = cc.Director:getInstance():getWinSize()
    local wid = self.contentSize.width
    local height = self.contentSize.height 
    local endPos = ccp(wid-30,height+100)
   
    local startPoint =ccp(wid/2,height/2)

    local randFunc = math.random

    local toX = endPos.x
    local toY = endPos.y
    local m_flyX = startPoint.x
    local m_flyY = startPoint.y   
    local endPoint = cc.p(endPos.x, endPos.y)

    for i=0,20,1 do
        local pNode = CCNode:create()
        pNode:setPosition(startPoint)
        local angle = cc.pGetAngle(startPoint, endPoint)
        local angle2 = math.abs(angle)
        local ball = CCLoadSprite:createSprite("GoldCoin_1.png")
        pNode:addChild(ball,1000)
        local sc1 = cc.Sequence:create(cc.DelayTime:create(0.5),cc.ScaleTo:create(1, 0.3))
        local sc2 = cc.Sequence:create(cc.DelayTime:create(0.5),cc.FadeOut:create(1))
        local swp = cc.Spawn:create(sc2,sc1)
        ball:runAction(swp)

        local beziercofig = {}
        local rand = randFunc(1,100)
        if (rand%2==0) then
            beziercofig[1] = cc.p(m_flyX+randFunc(30,60),m_flyY)
            beziercofig[2] = cc.p(toX+randFunc(30,60),toY)
        else
            beziercofig[1] = cc.p(m_flyX-randFunc(30,60),m_flyY)
            beziercofig[2] = cc.p(toX-randFunc(30,60),toY)
        end
        if (angle2<15) then
            angle = 0
        else
            angle = 90-angle
        end
        local useFactor = (toY - m_flyY) / 400.0
        useFactor = math.max(useFactor, 1)

        local useTime = 0.5 + i * 0.08
        beziercofig[3] = endPoint
        local forward = cc.BezierTo:create(useTime, beziercofig)
        forward = tolua.cast(forward, "cc.ActionInterval")
        local s1 = cc.Sequence:create(forward ,cc.DelayTime:create(0.05))
        local s2 = cc.Sequence:create(cc.RotateTo:create(useTime*0.7, angle))
        local sp = cc.Spawn:create(s1,s2)
        pNode:runAction(sp)
        self:addChild(pNode)
        pNode:setTag(66666)
    end
end

--登陆游戏后客户端主动向服务器拉取数据
function UiCompoentLuaLayer:AFLoginGMReqData()
    self.reqData_lock = true
    --阵法数据
    if CCCommonUtilsForLua:isFunOpenByKey("aormation") then        
        TacticalDepController.getInstance():reqData()
    end
    --联盟求援
    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
    if CCCommonUtilsForLua:isFunOpenByKey("alliance_help") and playerInfo:call("isInAlliance") and not isCrossServerNow() then
        require("game.alliance.AllianceAFHController").getInstance():reqPlayerAFHData()
    end
    --巨龙演武场
    if CCCommonUtilsForLua:isFunOpenByKey("wa_arms_drill_field") then
        DragonWarmUpManager:reqBattleLimitInfo()
    end
    
    --扩建资源田信息
    if CCCommonUtilsForLua:isFunOpenByKey("building_new") then
        local mainCityLv = FunBuildController:call("getMainCityLv")
        if mainCityLv > 14 then
            DataController.ExtensionDataController:reqResourceEffectInfo()
        end
    end

    --祷告礼堂
    local Glory6Manager = require("game.Glory6.Glory6Manager")
    local function reqGlory6Data()
        --判断祷告礼堂是否解锁
        if CCCommonUtilsForLua:isFunOpenByKey("11_p6_arms") and Glory6Manager.armyData == nil then
            local _buildId = FunBuildController:call("getMaxLvBuildByType", FUN_BUILD_NEWARMY_IMPROVE)
            if _buildId > 0 then
                local _buildInfo = FunBuildController:call("getInstance"):call("getFunbuildForLua", _buildId)
                if _buildInfo then
                    local gloryUnlockType = _buildInfo:getProperty("gloryUnlockType")
                    local gloryUnlockValue = _buildInfo:getProperty("gloryUnlockValue")
                    local gloryUnlock = _buildInfo:getProperty("gloryUnlock")
                    --获取祷告礼堂士兵的强化信息
                    if not (gloryUnlock == false and gloryUnlockType ~= "" and gloryUnlockValue ~= "") then
                        -- dump("hxq reqStrengthenInfo")
                        Glory6Manager.reqStrengthenInfo()
                    end
                end
            end
        end
    end
    reqGlory6Data()    
    
    -- 列王传
    if require("game.activity.KingBiography.KingBiographyController").isOpen() then
        require("game.activity.KingBiography.KingBiographyController"):getInstance():doReqData()
    end
    --藏宝图
    if CCCommonUtilsForLua:isFunOpenByKey("night_market") then
       require("game.FestivalActivities.TreasureMap.TreasureMapActCtr"):getInstance():reqData()
    end

    local TimeLimitBuffManager = require("game.TimeLimitBuff.TimeLimitBuffManager").getInstance()
    TimeLimitBuffManager:startCheckServerBuff()

    self:checkShowKingdomIcon()
end

function UiCompoentLuaLayer:requestPlayerStatus()
    -- 玩家状态设置（王国buff，联盟buff显示）
    if isFunOpenByKey("buff_show") 
        and not isCrossServerNow() 
        then
            local TimeLimitBuffManager = require("game.TimeLimitBuff.TimeLimitBuffManager").getInstance()
            local now = WorldController:call("getInstance"):call("getTime")
            TimeLimitBuffManager:requestPlayerStatus(true)
            TimeLimitBuffManager:setFirstRequestBuffTime(now)
    end
end

--传送门开启后的UI显示
function UiCompoentLuaLayer:showPortalTips()
    local node = Drequire("game.FestivalActivities.kingdomTrans.KingdomTransUINode"):create()
    if node then
        self:removeChildByTag(2525)
        self:addChild(node)
        node:setTag(2525)
        local size = self:getContentSize()
        node:setPosition(ccp(size.width/2,size.height))
    end
end

function UiCompoentLuaLayer:onCheckShowWorldBossComingAni()
    -- if self.worldBossComingAniView then
    --     self.worldBossComingAniView:close()
    --     self.worldBossComingAniView = nil
    -- end
    local bossAniCtl = Drequire("game.UIComponent.WorldBossComingAniController").getInstance()
    if self.sceneId == SCENE_ID_WORLD then
        bossAniCtl:showBossComingIcon()
    end
    if not self.worldBossComingAniView and bossAniCtl:getIconUserSetting() then
        local view = Drequire("game.UIComponent.WorldBossComingAniView"):create(self:getContentSize())
        -- PopupViewController:addPopupView(view)
        if view then
            self:addChild(view)
            self.worldBossComingAniView  = view
        end
    end
    if self.worldBossComingAniView then
        self.worldBossComingAniView:showAni()
    end
end

function UiCompoentLuaLayer:onGetSuperCampAttacklastTimes()
    if self.sceneId == SCENE_ID_WORLD then
        if CCCommonUtilsForLua:isFunOpenByKey("super_camp") then
            Drequire("game.Battlefield.SuperCampController").getInstance():reqAttackLastTimes()
        end
    end
end

---------------------------------- 右上滑动ICON组件 Start ----------------------------------
function UiCompoentLuaLayer:createRightUpPopList()
    local nodeTag = 8931
    self:removeChildByTag(nodeTag)
    if self.beIconScrollFunOn then
        local infoData = {}
        infoData.minUpIconNum = tonumber(CCCommonUtilsForLua:call("getPropByIdGroup", "data_config", "5th_Main_UI_update", "k1")) or 2
        infoData.maxUpIconNum = tonumber(CCCommonUtilsForLua:call("getPropByIdGroup", "data_config", "5th_Main_UI_update", "k2")) or 4
        local width = IconWidth
        local offset = 40
        -- 区域大小为，icon图标大小为90 * 80 
        -- 背景框在scrollview基础上增加了 40，用于显示下方的按钮

        -- 基点node
        local listHeight = (infoData.minUpIconNum + 0.5) * IconHeight + 10
        local baseNode = cc.Node:create()
        self:addChild(baseNode)
        baseNode:setTag(nodeTag)
        baseNode:setPosition(self.contentSize.width - IconWidth/2, self.contentSize.height)
        baseNode:setAnchorPoint(0.5, 1)
        local listSize = cc.size(width, listHeight + offset)
        baseNode:setContentSize(listSize)
        -- addTestLayerColor(baseNode)

        local imgBg = CCLoadSprite:call("createScale9Sprite", "popup_list_bg.png")
        imgBg:setContentSize(cc.size(width - 6, listHeight + offset*1.2))
        imgBg:setAnchorPoint(cc.p(0,0))
        imgBg:setPositionX(2)
        baseNode:addChild(imgBg)
        infoData.ListBg = imgBg
        infoData.beHide = true          -- 是否已经扩展

        -- 创建背景底框
        local listViewSize = cc.size(IconWidth, listHeight)
        local scrollView = cc.ScrollView:create()
        scrollView:setViewSize(listViewSize)
        scrollView:ignoreAnchorPointForPosition(true)
        scrollView:setPosition(cc.p(0,offset))
        scrollView:setDirection(kCCScrollViewDirectionVertical)
        scrollView:setClippingToBounds(true)
        scrollView:setBounceable(true)
        baseNode:addChild(scrollView)

        -- 添加右上的父node，用于控制显示位置
        local listBaseNode = cc.Node:create()
        scrollView:addChild(listBaseNode)
        infoData.listBaseNode = listBaseNode
        listBaseNode:setPositionX(IconWidth/2)

        infoData.listView = scrollView
        infoData.nodeList = {}
        infoData.nodeWidth = 60
        infoData.nodeHeight = 74
        infoData.baseNode = baseNode

        -- 三角的触摸node
        local touchArrowNode = cc.Node:create()
        touchArrowNode:setUseTouchScale(true)
        baseNode:addChild(touchArrowNode)
        touchArrowNode:setContentSize(cc.size(IconWidth, offset))
        local arrowSpr = CCLoadSprite:createSprite("popup_list_arrow.png")
        touchArrowNode:addChild(arrowSpr)
        arrowSpr:setPosition(ccp(IconWidth/2, offset / 2))
        infoData.touchArrowNode = touchArrowNode
        infoData.arrowSpr = arrowSpr
        -- 初始默认为收起状态
        arrowSpr:setScaleY(-1)

        self.rightUpInfoDate = infoData
        infoData.listView:setTouchEnabled(true)
    else
        -- self:addChild(self.rightUpNode)
        -- self.rightUpNode:setTag(nodeTag)
    end
end

-- 更新右上逻辑，此处需要更新pos和update俩项，
-- 此处的想法是：若收缩状态，只更新显示的前俩项！
-- 若是展开状态，则更新全部显示逻辑
function UiCompoentLuaLayer:updateRightUpScroll(isForce)
    local infoData = self.rightUpInfoDate
    -- local initPosX = IconWidth/2
    local posY = -IconHeight / 2

    local offset = IconHeight
    local curNum = 0
    local showMaxNum = #infoData.nodeList + 1       -- 展示的数目
    if infoData.beHide then
        showMaxNum = infoData.minUpIconNum + 1
    end
    local beVisibleNum = 0
    for i, icon in pairs(infoData.nodeList) do
        if icon.updateEvent then
            icon:updateEvent()
        end
        if icon:isVisible() then
            if curNum < showMaxNum then
                -- 此处位置下移10个点，用于显示高度超标的礼包icon图标显示，避免被裁切！
                icon:setPosition(cc.p(0, posY - 10))
                posY = posY - offset
                curNum = curNum + 1
            else
                -- 不在显示范围内的移到外面去
                icon:setPosition(cc.p(1000, 0))
            end
            beVisibleNum = beVisibleNum + 1
        end
    end
    if infoData.curShowNum ~= curNum or isForce then
        posY = posY + IconHeight / 2
        infoData.listBaseNode:setPositionY(0 - posY)
        infoData.listView:setContentSize(cc.size(IconWidth, 0 - posY))
        infoData.curShowNum = curNum
        if infoData.beHide then
            infoData.listView:setTouchEnabled(false)
        else
            infoData.listView:setTouchEnabled(true)
            infoData.listView:setSwallowsTouches(true)
        end
        local viewSize = infoData.listView:getViewSize()
        local offsetY = posY + viewSize.height
        infoData.listView:setContentOffset(ccp(0, offsetY))

        -- 数量小于等于1时，隐藏底板，
        -- 数量小于等于最小值。隐藏箭头
        if curNum <= 1 then
            infoData.ListBg:setVisible(false)
        else
            infoData.ListBg:setVisible(true)
        end
    end
    if beVisibleNum <= infoData.minUpIconNum then
        infoData.touchArrowNode:setVisible(false)
    else
        infoData.touchArrowNode:setVisible(true)
    end
end

function UiCompoentLuaLayer:rightUpScrollTouchEvent(x, y)
    local infoData = self.rightUpInfoDate
    if infoData.touchArrowNode:isVisible() and touchInside(infoData.touchArrowNode, x, y) then
        -- 点击收缩
        self:changeRightUpScrollState(infoData)
    else
        for i, icon in pairs(infoData.nodeList) do
            if icon:isVisible() and touchInside(icon, x, y) then
                if icon.touchEvent then
                    icon:touchEvent()
                    return
                end
            end
        end
    end
end

-- 更新右上List相关大小
function UiCompoentLuaLayer:changeRightUpScrollState(infoData)
    local showNum = 2
    if infoData.beHide then
        local _availableIcon = 0
        for _, icon in pairs(infoData.nodeList) do
            if icon:isVisible() then
                _availableIcon = _availableIcon + 1
            end
        end
        if _availableIcon <= infoData.maxUpIconNum then
            showNum = _availableIcon
        else
            showNum = infoData.maxUpIconNum + 0.5
        end
        infoData.beHide = false
        infoData.arrowSpr:setScaleY(1)
    else
        showNum = infoData.minUpIconNum + 0.5
        infoData.beHide = true
        infoData.arrowSpr:setScaleY(-1)
    end
    local listHeight = showNum * IconHeight + 10
    local offset = 40
    local listSize = cc.size(IconWidth, listHeight + offset)
    -- 基础Node向下扩展
    infoData.baseNode:setContentSize(listSize)
    infoData.ListBg:setContentSize(cc.size(IconWidth - 6, listHeight + offset*1.2))
    infoData.listView:setViewSize(cc.size(IconWidth, listHeight))

    self:updateRightUpScroll(true)
end
---------------------------------- 右上滑动ICON组件 Ended ----------------------------------

---------------------------------- 左下滑动ICON组件 Start ----------------------------------
function UiCompoentLuaLayer:getLeftDownStartY()
	local posX = IconWidth*0.5
	local posY = IconHeight*0.5
    local offsetX = IconWidth + IconOffset
    local offsetY = IconHeight + IconOffset
    if self.m_chapterNode and ChapterController:getInstance():isChapterOpen() then
        self.m_UIQuestNode:setVisible(false)
    end
    if not self.m_UIQuestNode:isVisible() then
    	posY = posY - offsetY
    end

    --新版任务系统
    if self.m_chapterNode and ChapterController:getInstance():isChapterOpen() then
        self.m_chapterNode:setPosition(initPosX, posY)
        self.m_chapterTaskNode:setPosition(initPosX + 120, posY - IconHeight*0.5)
        posY = posY + offsetY
    end
    return posX, posY
end

function UiCompoentLuaLayer:createLeftDownPopList()
    local nodeTag = 8932
    self:removeChildByTag(nodeTag)
    if self.beIconScrollFunOn then
        local infoData = {}
        local posX, posY = self:getLeftDownStartY()
        -- 基点node
        local baseNode = cc.Node:create()
        self:addChild(baseNode, 100)
        baseNode:setTag(nodeTag)
        baseNode:setPosition(cc.p(posX, posY - IconHeight*0.5 - IconOffset))
        baseNode:setAnchorPoint(0.5, 0)
        baseNode:setContentSize(cc.size(IconWidth, IconHeight))

        local imgBg = CCLoadSprite:call("createScale9Sprite", "popup_list_bg.png")
        imgBg:setContentSize(cc.size(IconWidth, IconHeight))
        imgBg:setAnchorPoint(cc.p(0,0))  
        imgBg:setPosition(ccp(2, IconHeight - IconOffset - 10))  
        baseNode:addChild(imgBg)
        infoData.ListBg = imgBg
        infoData.beHide = true          -- 是否已经扩展

        -- 创建背景底框
        local scrollView = cc.ScrollView:create()
        scrollView:setViewSize(cc.size(IconWidth, IconHeight))
        scrollView:ignoreAnchorPointForPosition(true)
        scrollView:setPosition(cc.p(4,IconHeight))
        scrollView:setDirection(kCCScrollViewDirectionVertical)
        scrollView:setClippingToBounds(true)
        scrollView:setBounceable(true)
        baseNode:addChild(scrollView)

        -- 添加左下的父node，用于控制显示位置
        local listBaseNode = cc.Node:create()
        scrollView:addChild(listBaseNode)
        infoData.listBaseNode = listBaseNode
        listBaseNode:setPositionX(IconWidth/2)

        infoData.listView = scrollView
        infoData.nodeList = {}
        infoData.baseNode = baseNode
        infoData.listView:setVisible(false)
        infoData.ListBg:setVisible(false)

        local touchArrowNode = cc.Node:create()
        touchArrowNode:setUseTouchScale(true)
        baseNode:addChild(touchArrowNode)
        touchArrowNode:setContentSize(cc.size(IconWidth, IconHeight))
        local arrowSpr = CCLoadSprite:createSprite("popup_list_btn_bg.png")
        touchArrowNode:addChild(arrowSpr)
        arrowSpr:setPosition(ccp(IconWidth/2, IconHeight/2))
        -- arrowSpr:setScale(1.2)
        local arrowSize = arrowSpr:getContentSize()
        local arrowSprIcon1 = CCLoadSprite:createSprite("popup_list_btn_icon1.png")
        arrowSpr:addChild(arrowSprIcon1);
        arrowSprIcon1:setName('top');
        arrowSprIcon1:setPosition(ccp(arrowSize.width/2, arrowSize.height/2));
        local arrowSprIcon2 = CCLoadSprite:createSprite("popup_list_btn_icon2.png")
        arrowSpr:addChild(arrowSprIcon2);
        arrowSprIcon2:setName('bottom');
        arrowSprIcon2:setPosition(ccp(arrowSize.width/2, arrowSize.height/2));
        arrowSprIcon2:setVisible(false);
        infoData.touchArrowNode = touchArrowNode
        infoData.arrowSpr = arrowSpr

        self.leftDownInfoData = infoData
        infoData.listView:setTouchEnabled(true)
    else
        
    end
end

function UiCompoentLuaLayer:leftDownScrollTouchEvent(x, y)
    local infoData = self.leftDownInfoData
    if touchInside(infoData.touchArrowNode, x, y) then
        -- 点击收缩
        self:changeLeftDownScrollState(infoData)
    else
        for i, icon in pairs(infoData.nodeList) do
            if icon:isVisible() and touchInside(icon, x, y) then
                if icon.touchEvent and infoData.listView:isVisible() then
                    icon:touchEvent()
                    return
                end
            end
        end
    end
end

-- 更新左下List相关大小
function UiCompoentLuaLayer:changeLeftDownScrollState(infoData)
    local i_Post = 0
    if infoData.beHide then
        i_Post = 1
        infoData.beHide = false
    else
        i_Post = 0
        infoData.beHide = true
    end
    --之后左下角只可能存在两个按钮，一个是跨服活动，一个是菜单按钮，而且他俩顺序调换了。
    -- for i,v in ipairs(self.iconListAlone or {}) do
    --     if v then
    --         v:setVisible(infoData.beHide)
    --     end
    -- end
    -- 通知UIComponent类显隐m_previewInfoNode
    CCSafeNotificationCenter:postNotification("update_preview_info_node", CCInteger:create(i_Post))
    
    local posY = 0 - IconHeight / 2
    local offset = IconHeight + IconOffset
    -- 排序
    table.sort( infoData.nodeList, function(a,b) return atoi(a.order) < atoi(b.order) end )
    local visibleCount = 0
    local redPotCount = 0
    for i, icon in pairs(infoData.nodeList) do
        if icon.updateEvent then
            icon:updateEvent()
        end
        if icon:isVisible() then
            visibleCount = visibleCount + 1
            if icon.checkRedPotVisible and icon:checkRedPotVisible() then
                redPotCount = redPotCount + 1
            end
            -- self:addRedPotToIcon(icon, 1)
            icon:setPosition(cc.p(0, posY))
            posY = posY - offset
        end
    end
    posY = posY + offset / 2
    self:addRedPotToIcon(infoData.touchArrowNode, redPotCount)
    local maxNum = math.min(3.5, visibleCount) -- 最多显示三个半
    local arrowSpr = infoData.arrowSpr;
    local arrowSprIcon1 = arrowSpr:getChildByName('top')
    local arrowSprIcon2 = arrowSpr:getChildByName('bottom')
    if infoData.beHide == false and maxNum > 0 then
        arrowSprIcon1:setVisible(false)
        arrowSprIcon2:setVisible(true)
        infoData.listView:setVisible(true)
        infoData.ListBg:setVisible(true)
        infoData.listView:setTouchEnabled(true)
        infoData.listView:setSwallowsTouches(true)

        infoData.listBaseNode:setPositionY(0 - posY)
        infoData.baseNode:setContentSize(cc.size(IconWidth, (offset + 10) * (maxNum + 1) - IconOffset)) -- +1是下面那个展开按钮
        infoData.ListBg:setContentSize(cc.size(IconWidth, (offset + 10)* maxNum + IconOffset))

        infoData.listView:setViewSize(cc.size(IconWidth, offset * maxNum))
        infoData.listView:setContentSize(cc.size(IconWidth, 0 - posY))
        local viewSize = infoData.listView:getViewSize()
        local offsetY = posY + viewSize.height
        infoData.listView:setContentOffset(ccp(0, offsetY))
        LogController:sendUserBehaviorEvent("cityLeft", 1, "btnOpen")
    else
        arrowSprIcon1:setVisible(true)
        arrowSprIcon2:setVisible(false)
        infoData.baseNode:setContentSize(cc.size(IconWidth, IconHeight))
        infoData.listView:setVisible(false)
        infoData.ListBg:setVisible(false)
        infoData.listView:setTouchEnabled(false)
        LogController:sendUserBehaviorEvent("cityLeft", 1, "btnClose")
    end
end

function UiCompoentLuaLayer:updateLeftDownScroll( ... )
    -- 更新左下滑动按钮
    local infoData = self.leftDownInfoData
    local posY = 0 - IconHeight / 2
    local offset = IconHeight + IconOffset
    local visibleCount = 0
    for i, icon in pairs(infoData.nodeList) do
        if icon:isVisible() then
            visibleCount = visibleCount+1
            icon:setPosition(cc.p(0, posY))
            posY = posY - offset
        end
    end
    posY = posY + offset / 2
    infoData.baseNode:setVisible(visibleCount>0)
    if self.sceneId == SCENE_ID_WORLD or self.sceneId == SCENE_ID_NIGHTCITY then
        infoData.baseNode:setVisible(false)
    end
    local maxNum = math.min(3.5, visibleCount) -- 最多显示三个半
    local currNum = infoData.currentNum or 0
    if infoData.beHide == false and maxNum > 0 and currNum~=visibleCount then
        infoData.listBaseNode:setPositionY(0 - posY)
        infoData.baseNode:setContentSize(cc.size(IconWidth, (offset + 10) * (maxNum + 1) - IconOffset)) -- +1是下面那个展开按钮
        infoData.ListBg:setContentSize(cc.size(IconWidth, (offset + 10)* maxNum + IconOffset))

        infoData.listView:setViewSize(cc.size(IconWidth, offset * maxNum))
        infoData.listView:setContentSize(cc.size(IconWidth, 0 - posY))
        local viewSize = infoData.listView:getViewSize()
        local offsetY = posY + viewSize.height
        infoData.listView:setContentOffset(ccp(0, offsetY))
    end
    infoData.currentNum = visibleCount;
end

function UiCompoentLuaLayer:hideLeftDownNode()
    local infoData = self.leftDownInfoData
    infoData.beHide = true
    infoData.baseNode:setVisible(false)
    infoData.baseNode:setContentSize(cc.size(IconWidth, IconHeight))
    infoData.listView:setVisible(false)
    infoData.ListBg:setVisible(false)
    infoData.listView:setTouchEnabled(false)
    CCSafeNotificationCenter:postNotification("update_preview_info_node", CCInteger:create(0))
end

function UiCompoentLuaLayer:setLeftDownIconRedPot()
    if self.beIconScrollFunOn and self.leftDownInfoData then
        local infoData = self.leftDownInfoData
        local redPotCount = 0
        for i, icon in pairs(infoData.nodeList) do
            if icon.updateEvent then
                icon:updateEvent()
            end
            if icon:isVisible() and icon.checkRedPotVisible and icon:checkRedPotVisible() then
                -- self:addRedPotToIcon(icon, 1)
                redPotCount = redPotCount + 1
            end
        end
        self:addRedPotToIcon(infoData.touchArrowNode, redPotCount)
    end
end

function UiCompoentLuaLayer:addRedPotToIcon(node, num)
    if node then
        local cntLabel = node:getChildByTag(20180815)
        local red = node:getChildByTag(20180816)
        if num > 0 then 
            if cntLabel and red then
                cntLabel:setString(tostring(num))
                cntLabel:setVisible(true)
                red:setVisible(true)
            else
                local red = CCLoadSprite:call("createSprite", "unlock_tipPt.png")
                local cntLabel = cc.Label:createWithSystemFont("", "Helvetica", 15, cc.size(0.0,0))
                cntLabel:setTag(20180815)
                red:setTag(20180816)
                red:setScale(1.3)
                node:addChild(red)
                node:addChild(cntLabel)
                red:setPosition(cc.p(node:getContentSize().width*0.8, node:getContentSize().height*0.8))
                cntLabel:setPosition(cc.p(red:getPositionX(), red:getPositionY() + 3))
                cntLabel:setString(tostring(num))
            end
        else
            if cntLabel and red then
                cntLabel:setVisible(false)
                red:setVisible(false)
            end
        end
    end
end

---------------------------------- 左下滑动ICON组件 Ended ----------------------------------

function UiCompoentLuaLayer:goldListExchagneNotify()
    local _icon_cfg = {iconName = "game.UIComponent.SubscribeNodeIcon", iconType = 2, order = 2.01} -- 订阅
	UiCompoentControoller.getIconEvent():emit({icon_cfg = _icon_cfg, eventType = "create"})
end

function UiCompoentLuaLayer:updateLuckdayNotify(ref)
    if not ref then
        return
    end
    local iLuckyId = ref:getValue()

    if self.m_iLuckyId ~= iLuckyId then
        self.m_iLuckyId = iLuckyId
        local leftTimes = CLuckdayController:call("getInstance"):call("getRemainTimes")
        local _icon_cfg = {iconName = "game.UIComponent.LuckyDayNodeIcon", iconType = 3, order = 2.04} --幸运日
        if leftTimes > 0 then
            UiCompoentControoller.getIconEvent():emit({icon_cfg = _icon_cfg, eventType = "create"})
        else
            UiCompoentControoller.getIconEvent():emit({icon_cfg = _icon_cfg, eventType = "destroy"})
        end
    end
end

function UiCompoentLuaLayer:onMsgInitNotify()
    DataController.LuaEffectController:pullEffectSystems()
    -- 活动激活逻辑判断
    ToNewServerController.getInstance():checkReturnIconShow()

    ActivityController.getInstance():tryInitSubActivity()

    local _icon_cfg = {iconName = "game.UIComponent.BanquetActivityIcon", iconType = 3, order = 2.13}    -- 犒赏三军，活动id 57434
    UiCompoentControoller.getIconEvent():emit({icon_cfg = _icon_cfg, eventType = "create"})
end


function UiCompoentLuaLayer:checkShowKingdomIcon()
    local serverType = PlayerInfoController:getServerType()
    local beShow = false
    if serverType == ServerType.SERVER_DESPOT or serverType == ServerType.SERVER_EMPIRE then
        -- 霸王争夺服 or 帝王争夺服
        beShow = true
    elseif serverType == ServerType.SERVER_NORMAL or serverType == ServerType.SERVER_TEST or serverType == ServerType.SERVER_INNER_TEST then
        -- 普通服 or 测试服 or 内网测试服
        if (GlobalData:call("shared"):getProperty("crossThroneObTag") == false)
            and (CCCommonUtilsForLua:isFunOpenByKey("wonder_rule_new") or CCCommonUtilsForLua:isFunOpenByKey("new_wonder_v2"))
            then
            beShow = true
        end
    end
    if beShow then
        -- 符合开启条件，就创建，然后再去判断显隐更新
		local _icon_cfg = {iconName = "game.UIComponent.NewKingdomWarIcon", iconType = 4, order = 2.02} --王战Icon
		UiCompoentControoller.getIconEvent():emit({icon_cfg = _icon_cfg, eventType = "create"})
    end
end

 -- 停服公告
function UiCompoentLuaLayer:updateServerStopNotice()
    local instance = require("game.CommonPopup.ServerStopNoticeController").getInstance()
    local notice = instance:getValidNotice()
    if notice then
        local iconCfg = {iconName = "game.UIComponent.ServerStopIcon", iconType = 6, order = 0}
        UiCompoentControoller.getIconEvent():emit({icon_cfg = iconCfg, eventType = "create"})
    end
end

-- 新手增益
function UiCompoentLuaLayer:destroyNewPlayerBuffIcon()
    local iconCfg = {iconName = "game.UIComponent.NewPlayerBuffIcon", iconType = 6, order = 1}
    UiCompoentControoller.getIconEvent():emit({icon_cfg = iconCfg, eventType = "destroy"})
end

-- 开拓之路
function UiCompoentLuaLayer:destroyExploreRoadIcon()
    local iconCfg = {iconName = "game.UIComponent.ExploreRoadIcon", iconType = 1, order = 1}
    UiCompoentControoller.getIconEvent():emit({icon_cfg = iconCfg, eventType = "visibility"})
end

return UiCompoentLuaLayer
