CommonChangeNameView = class("CommonChangeNameView", function()
        return PopupBaseView:create()
    end
)
CommonChangeNameView.__index = CommonChangeNameView

local ChangeNameType = {
	Dragon = 1, -- 龙
	KingdomMiracle = 2, -- 奇迹
}
local min_name_char = 3
local max_name_char = 16
local KingdomMiraclManager = require("game.KingdomMiracle.KingdomMiracleManager")
------------------------------------------ CommonChangeNameView Start --------------------------------------------

function CommonChangeNameView:create(dict)
	local view = CommonChangeNameView.new()
	if view:initView(dict) == false then
		return nil
	end
  	return view
end

function CommonChangeNameView:initView(dict)
	if self:init(true, 0) == false then
		MyPrint("CommonChangeNameView init error")
    	return false
	end

	self:setHDPanelFlag(true)
	CCLoadSprite:call("doResourceByCommonIndex", 502, true)
	local m_bIsPad = CCCommonUtilsForLua:isIosAndroidPad()
	local  proxy = cc.CCBProxy:create()
	local ccbiURL = ""
	ccbiURL = "ccbi/CommonChangeNameView.ccbi"
  	self.m_bIsPad = m_bIsPad
  	local nodeccb = CCBReaderLoad(ccbiURL,proxy, self)
	if nodeccb == nil then
		MyPrint("CommonChangeNameView loadccb error")
		return false
	end

	if m_bIsPad then
		nodeccb:setScale(2.0)
	end
	self:setContentSize(cc.Director:getInstance():getIFWinSize())
  	self:addChild(nodeccb)
  	
	self.ccbNode = nodeccb
	local function onNodeEvent(event)
		if event == "enter" then
			self:onEnter()
		elseif event == "exit" then
			self:onExit()
		end
	end
  	self.ccbNode:registerScriptHandler(onNodeEvent)

  	function onTouch(eventType, x, y)  
        if eventType == "began" then  
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)  
        else  
            return self:onTouchEnded(x, y)  
        end
    end
	local touchif = tolua.cast(self,"cc.CCIFTouchNode")
    if touchif ~= nil then
        local dic1 = CCDictionary:create()
        dic1:setObject(CCBool:create(true),"1")
        touchif:comFunc("setTouchEnabled", dic1)

        MyPrint("CommonChangeNameView:registerScriptTouchHandler")
        touchif:registerScriptTouchHandler(onTouch)
    end
    dump(dict, "CommonChangeNameView dump input data")

    self.m_changeType = dict.changeType
    self.m_target = dict.target
    self.m_targetNowName = dict.targetNowName
    self.m_isExist = false
    self.m_isOccupied = false
    self.m_lastName = ""
    self.m_share = true

    if self.m_changeType == ChangeNameType.Dragon then
    	self.m_finishShareNode:setVisible(true)
    else
    	self.m_finishShareNode:setVisible(false)
    end

    self.m_nameLabel:setString(_lang("164569"))
    self.m_msgLabel:setString(_lang("164571"))
    self.m_shareLab:setString(_lang("164572"))

	local size = self.m_nameNode:getContentSize()
	self.m_editBox = InputFieldMultiLine:call("create", size, "01_24.png", 30)
	self.m_editBox:call("setAddH", 5)
	self.m_editBox:call("setMaxChars", max_name_char)
	self.m_editBox:call("setLineNumber", 1)
	self.m_editBox:call("setFontColor", ccBLACK)	
	self.m_editBox:call("setSwallowsTouches", true)
	self.m_editBox:call("setMoveFlag", true)
	self.m_editBox:call("setcalCharLen", true)
	self.m_editBox:call("setOnlySingleLine", true)
	tolua.cast(self.m_editBox, "cc.Node"):setPosition(ccp(0, 0))
	tolua.cast(self.m_editBox, "cc.Node"):setAnchorPoint(ccp(0, 0))

	local nameTip = ""
	nameTip = nameTip .. getLang("164570")
	tolua.cast(self.m_editBox, "InputFieldMultiLine"):call("setPlaceHolder", nameTip)
	self.m_nameNode:addChild(tolua.cast(self.m_editBox, "cc.Node"))

	self.m_okBtn:setEnabled(false)
	CCCommonUtilsForLua:call("setButtonTitle", self.m_okBtn, "")
    self.m_btnText:setString(getLang("164573"))
    local gold = CCCommonUtilsForLua:call("getGoldBuyItem", "200021")
    self.m_goldNum:setString(tostring(gold))
    return true
end

function CommonChangeNameView:checkNameFun()
    self.m_editBox = tolua.cast(self.m_editBox, "InputFieldMultiLine")
	local str = self.m_editBox:call("getText")
    local length= string.len(str)
    
    local lastNum = max_name_char - length;
    if lastNum < 0 then
    	lastNum = 0
    end

    if length == max_name_char then
    	self.m_msgLabel:setString(getLang("106058"))
    	self.m_msgLabel:setColor(cc.c3b(96,49,0))
	end

	if self.m_lastName == str then
		return
	end    

	if str == self.m_targetNowName then
		self.m_msgLabel:setString(getLang("164584"))
		self.m_msgLabel:setColor(cc.c3b(96,49,0))
		return
	end    
    
    self.m_lastName = str

    if self.m_changeType == ChangeNameType.Dragon then
	    DragonController:call("checkDragonNickName", str)
	elseif self.m_changeType == ChangeNameType.KingdomMiracle then
        KingdomMiraclManager.checkMiracleName(str,tonumber(self.m_target))
	end
end

function CommonChangeNameView:checkSuccess(ref)
	local dictData = tolua.cast(ref, "CCDictionary")
	if dictData == nil then
		return
	end

	dictData = dictToLuaTable(dictData)
	if dictData == nil then
		return
	end

	local exist = tonumber(dictData.exist)
	local length = tonumber(dictData.length)
    local lastNum = max_name_char - length
    if lastNum < 0 then
    	lastNum = 0
    end

    self.m_msgLabel:setString(getLang("164571"))
    self.m_msgLabel:setColor(cc.c3b(96,49,0))
    self.m_msgLabel:setVisible(true)
    
    local ok = exist ~= -1 and length >= min_name_char and length <= max_name_char
    
    self.m_isExist = false
    self.m_isOccupied = false

    if exist == -1 then
    	self.m_isExist = true
    end
    self:onInputFieldCloseEvent()
end

function CommonChangeNameView:onEnter()
	self:register()
    dump(self, "CommonChangeNameView:onEnter dump self")
    local function onEnterFrame()
        MyPrint("CommonChangeNameView:onEnterFrame")
        self:checkNameFun()
    end
    local scheduler = cc.Director:getInstance():getScheduler()
    if self.entry ~= nil then
        scheduler:unscheduleScriptEntry(self.entry)
    end
    self.entry = scheduler:scheduleScriptFunc(onEnterFrame, 1.0, false)
end

function CommonChangeNameView:register()
	local function onHandleClose( ref )
        MyPrint("CommonChangeNameView:onHandleClose")
		self:onInputFieldCloseEvent()
	end
	local function onHandleBtnState( ref )
        MyPrint("CommonChangeNameView:onHandleBtnState")
		self:resetBtnState()
	end
	local function onHandleCheckSuccess( ref )
        MyPrint("CommonChangeNameView:onHandleCheckSuccess")
		self:checkSuccess(ref)
	end
	local t = tolua.cast(self, "cc.Node")
	local handler = t:registerHandler(onHandleClose)
	local handler1 = t:registerHandler(onHandleBtnState)
	local handler2 = t:registerHandler(onHandleCheckSuccess)
	CCSafeNotificationCenter:registerScriptObserver(self, handler, "InputFieldMultiLine.close")
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "msg_nickname_changed")
	CCSafeNotificationCenter:registerScriptObserver(self, handler2, "msg_nickname_checked")
	MyPrint("HeroSkillView:onEnter registerScriptObserver")
end

function CommonChangeNameView:onExit()
	CCSafeNotificationCenter:unregisterScriptObserver(self, "InputFieldMultiLine.close")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "msg_nickname_changed")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "msg_nickname_checked")
    local scheduler = cc.Director:getInstance():getScheduler()
    if self.entry ~= nil then
        scheduler:unscheduleScriptEntry(self.entry)
    end
end

function CommonChangeNameView:resetBtnState()
	self.m_okBtn:setEnabled(true)
    CCCommonUtilsForLua:call("flyHint", "", "", getLang("105227"))
    self = tolua.cast(self, "PopupBaseView")
	self:call("closeSelf")
end

function CommonChangeNameView:onTouchBegan(x, y)
	return true
end

function CommonChangeNameView:onTouchMoved(x, y)
end

function CommonChangeNameView:onTouchEnded(x, y)
	if touchInside(self.m_bg, x, y) == false then
		self = tolua.cast(self, "PopupBaseView")
		self:call("closeSelf")
	end

	if self.m_finishShareNode:isVisible() and touchInside(self.m_checkBox, x, y) then
		if self.m_share then
			self.m_share = false
			self.m_checkBox:setVisible(false)
		else
			self.m_share = true
			self.m_checkBox:setVisible(true)
		end
	end
end

function CommonChangeNameView:onOkBtnClick()
	local nickname = self.m_editBox:call("getText")
    if string.len(nickname) < 3 then
        CCCommonUtilsForLua:call("flyText", getLang("105223"))
    else
        local gold = CCCommonUtilsForLua:call("getGoldBuyItem", "200021")
        local function onOKCostGold()
        	self:costGold()
        end
        YesNoDialog:call("show", getLang("105219", tostring(gold)), cc.CallFunc:create(onOKCostGold))
    end
    self.m_editBox:call("closeIME")
end

function CommonChangeNameView:costGold()
	local gold = CCCommonUtilsForLua:call("getGoldBuyItem", "200021")
	local playerInfo = GlobalData:call("getPlayerInfo")
    if playerInfo == nil then
        MyPrint("CommonChangeNameView:costGold playerInfo is nil")
        return
    end
    if gold > playerInfo:getProperty("gold") then
        YesNoDialog:call("gotoPayTips")
        return
    end
    
    local nickname = self.m_editBox:call("getText")
    self.m_okBtn:setEnabled(false)
    if self.m_changeType == ChangeNameType.Dragon then
	    DragonController:call("dragonChangeNickName", self.m_target, nickname, self.m_share)
	elseif self.m_changeType == ChangeNameType.KingdomMiracle then
        KingdomMiraclManager.changeMiraclName(nickname, tonumber(self.m_target))
	end
end

function CommonChangeNameView:onInputFieldCloseEvent()
	local str = self.m_editBox:call("getText")
    MyPrint("CommonChangeNameView:onInputFieldCloseEvent str is "..str)
    local length = string.len(str)
    
    local isOK = true
    -- local find1, find2 = string.find(str, '(')
    if str ~= "" and find == 1 then
    	isOK = false
    	self.m_msgLabel:setString(getLang("113995"))
    elseif str == self.m_targetNowName then
    	isOK = false
    	self.m_msgLabel:setString(getLang("164584"))
    	self.m_msgLabel:setColor(cc.c3b(96,49,0))
    elseif length < min_name_char then
    	isOK = false
    	self.m_msgLabel:setString(getLang("105223"))
    	if str == "" then
    		local nameTip = getLang("164570")
    		self.m_editBox:call("setPlaceHolder", nameTip)
    	end
    elseif length > max_name_char then
    	isOK = false
    	self.m_msgLabel:setString(getLang("113988"))
    elseif self.m_isExist then
    	isOK = false
    	self.m_msgLabel:setString(getLang("105251"))
    end
    
    self.m_okBtn:setEnabled(isOK)
    self.m_nameOkNode:setVisible(true)
    self.m_nameOkNode:getChildByTag(0):setVisible(not isOK)
    self.m_nameOkNode:getChildByTag(1):setVisible(isOK)
    
    if isOK == false then
        self.m_msgLabel:setColor(cc.RED)
    else
        self.m_msgLabel:setString(getLang("164571"))
        self.m_msgLabel:setColor(cc.c3b(96,49,0))
    end

    if length == 0 then
        self.m_msgLabel:setString(getLang("164571"))
        self.m_msgLabel:setColor(cc.c3b(96,49,0))
        self.m_nameOkNode:setVisible(false)
    end
end

return CommonChangeNameView