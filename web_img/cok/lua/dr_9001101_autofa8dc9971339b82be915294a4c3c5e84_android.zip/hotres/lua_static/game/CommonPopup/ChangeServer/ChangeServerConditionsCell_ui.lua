----------------------------
-- Author: Elex
-- Date: 2018-08-02 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local ChangeServerConditionsCell_ui = class("ChangeServerConditionsCell_ui")

--#ui propertys


--#function
function ChangeServerConditionsCell_ui:create(owner, viewType, paramTable)
	local ret = ChangeServerConditionsCell_ui.new()
	CustomUtility:LoadUi("Lua_ChangeServerConditionsCell.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function ChangeServerConditionsCell_ui:initLang()
end

function ChangeServerConditionsCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function ChangeServerConditionsCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return ChangeServerConditionsCell_ui

