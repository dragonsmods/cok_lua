----------------------------
-- Author: Elex
-- Date: 2019-07-08 Monday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local ApplyRankView_ui = class("ApplyRankView_ui")

--#ui propertys


--#function
function ApplyRankView_ui:create(owner, viewType, paramTable)
	local ret = ApplyRankView_ui.new()
	CustomUtility:LoadUi("ApplyRankView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function ApplyRankView_ui:initLang()
end

function ApplyRankView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function ApplyRankView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function ApplyRankView_ui:onClickTip(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickTip", pSender, event)
end

function ApplyRankView_ui:initTableView()
	TableViewSmoker:createView(self, "m_listView", "game.CommonPopup.ChangeServer.ApplyRankCell", 1, 5, "ApplyRankCell")
end

function ApplyRankView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return ApplyRankView_ui

