--[[
	使用加速道具界面
]]

local QuickUseGoodsCell = class("QuickUseGoodsCell", cc.TableViewCell)

function QuickUseGoodsCell:create(itemId, parent)
	local view = QuickUseGoodsCell.new()
	Drequire("game.CommonPopup.QuickUseGoodsCell_ui"):create(view)
	if view:initView(itemId, parent) then
		return view
	end
end

function QuickUseGoodsCell:initView(itemId, parent)
    self:setData(itemId, parent)
    return true
end

function QuickUseGoodsCell:setData(itemId, parent)
    self.m_itemId = itemId
    self.m_parent = parent
    self.ui.m_sprSelect:setVisible(false)
	CCCommonUtilsForLua:createGoodsIcon(tonumber(self.m_itemId), self.ui.m_nodeIcon, CCSize(95, 95) )

	local tool_info = ToolController:call("getToolInfoByIdForLua", self.m_itemId)
	local time = tonumber(tool_info:getProperty("paras")[3]) or 0
	-- self.ui.m_labelName:setColor(self:getItemColor(tool_info:getProperty("color")))
	self.ui.m_labelName:setString(tool_info:call("getName"))
	self.ui.m_labelCount:setString(tool_info:call("getCNT"))
end

function QuickUseGoodsCell:onEnter()
    registerScriptObserver(self, self.onSelect, "QuickUseGoodsCell:onSelect")
	registerScriptObserver(self, self.refresh, "QuickUseGoodsCell:refresh")
end

function QuickUseGoodsCell:onExit()
    unregisterScriptObserver(self, "QuickUseGoodsCell:onSelect")
	unregisterScriptObserver(self, "QuickUseGoodsCell:refresh")
end

function QuickUseGoodsCell:onBtnClick()
	self.m_parent:onSelect(self.m_itemId)
end

function QuickUseGoodsCell:refresh()
	local tool_info = ToolController:call("getToolInfoByIdForLua", self.m_itemId)
	self.ui.m_labelCount:setString(tool_info:call("getCNT"))
end

function QuickUseGoodsCell:onSelect(data)
	local id = data:getCString()
	if self.m_itemId then
        self.ui.m_sprSelect:setVisible(tonumber(id) == self.m_itemId)
	end
end

return QuickUseGoodsCell
