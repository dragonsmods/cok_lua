local SuperDefenseView = class("SuperDefenseView", PopupBaseView)

function SuperDefenseView:ctor(data)
    Drequire("game.CommonPopup.SuperDefenseView_ui"):create(self, 1)
    
    local rallyMap = WorldController:call("getInstance"):getProperty("superRallyMap")
    local rallyArr = {}
    for k, v in ipairs4ScatteredT(rallyMap) do
        table.insert(rallyArr, {k, v})
    end

    if table.getn(rallyArr) > 0 then
        self.superRallyItem = atoi(rallyArr[1][1])
        self.superRallyNum = atoi(rallyArr[1][2])
    else
        self.superRallyItem = -1
    end

    self.marchUuid = data.marchUuid
    self.pointId = data.pointId
    self.duration = data.duration
    self.expireTime = data.expireTime
    self.itemId = data.itemId
    self.itemNum = data.itemNum

    self:refreshView()
end

function SuperDefenseView:refreshView()
    self.ui.m_moreBtn:setVisible(false)
    self.ui.m_openBtn:setEnabled(true)
    self.ui.m_extraNode:setVisible(false)

    local _total = WorldController:call("getInstance"):getProperty("superTotalCnt")
    _total = _total + CCCommonUtilsForLua:call("getEffectValueByNum", 5350)

    local left = _total - WorldController:call("getInstance"):getProperty("superRallyCnt")
    left = left > 0 and left or 0
    self.ui.m_leftTimes:setString(getLang("113070", left, _total))

    if left == 0 then self.ui.m_openBtn:setEnabled(false) end
    if self.superRallyItem > 0 then
        local tInfo = ToolController:call("getToolInfoForLua", self.superRallyItem)
        if tInfo then
            local cnt = tInfo:call("getCNT")
            self.ui.m_nameText:setString(tInfo:call("getName"))
            self.ui.m_numText:setString(getLang("102173", CC_CMDITOA(cnt), CC_CMDITOA(self.superRallyNum)))
            
            if cnt < self.superRallyNum then
                self.ui.m_moreBtn:setVisible(true)
                self.ui.m_openBtn:setEnabled(false)
                self.ui.m_numText:setColor(cc.c3b(255, 35, 35))
            else    
                self.ui.m_numText:setColor(cc.c3b(132, 233, 170))
            end
        end

        CCCommonUtilsForLua:call("createGoodsIcon", self.superRallyItem, self.ui.m_itemNode, CCSizeMake(38, 38))
    end

    self.ui.m_durationText:setString(getLang("113071", format_time( self.duration)))

    if self.itemId > 0 then
        self:refreshExtra()
    end

    registerTouchHandler(self)
end

function SuperDefenseView:refreshExtra()
    self.ui.m_extraNode:setVisible(true)
    self.ui.m_moreBtn1:setVisible(false)

    local tInfo = ToolController:call("getToolInfoForLua", self.itemId)
    if tInfo then
        local cnt = tInfo:call("getCNT")
        self.ui.m_nameText1:setString(tInfo:call("getName"))
        self.ui.m_numText1:setString(getLang("102173", CC_CMDITOA(cnt), CC_CMDITOA(self.itemNum)))
        
        if cnt < self.itemNum then
            self.ui.m_moreBtn1:setVisible(true)
            self.ui.m_numText1:setColor(cc.c3b(255, 35, 35))
            self.ui.m_openBtn:setEnabled(false)
        else    
            self.ui.m_numText1:setColor(cc.c3b(132, 233, 170))
        end
    end

    CCCommonUtilsForLua:call("createGoodsIcon", self.itemId, self.ui.m_itemNode1, CCSizeMake(38, 38))
end

function SuperDefenseView:activeHandler()
    self:call("closeSelf")
end

function SuperDefenseView:onEnter()
    registerScriptObserver(self, self.activeHandler, "msg.super.defense")
end

function SuperDefenseView:onExit()
    unregisterScriptObserver(self, "msg.super.defense")
end

function SuperDefenseView:onTouchBegan(x, y)
    if not isTouchInsideVis(self.ui.m_bg, x, y) then
        self.touchPoint = ccp(x, y)
        return true
    end
    return false
end

function SuperDefenseView:onTouchEnded(x, y)
    if ccpDistance(self.touchPoint, ccp(x ,y)) > 10 then 
    	return 
    end
    
    self:call("closeSelf")
end

function SuperDefenseView:onClickMore()
	local view = Drequire("game.CommonPopup.ItemGetMethodView"):create(self.superRallyItem)
	PopupViewController:call("addPopupView", view)
end

function SuperDefenseView:onClickMore1()
    local view = Drequire("game.CommonPopup.ItemGetMethodView"):create(self.itemId)
	PopupViewController:call("addPopupView", view)
end

function SuperDefenseView:onClickOpen()
    local function active()
        local activeCmd = Drequire("game.command.SuperDefenseActiveCmd"):create(atoi(self.pointId))
        activeCmd:send()

        self:call("closeSelf")
    end

    local now = getTimeStamp()
    if now < self.expireTime then
        YesNoDialog:show(getLang("6100052"), active)
    else
        YesNoDialog:show(getLang("6100047"), active)
    end
end

return SuperDefenseView
