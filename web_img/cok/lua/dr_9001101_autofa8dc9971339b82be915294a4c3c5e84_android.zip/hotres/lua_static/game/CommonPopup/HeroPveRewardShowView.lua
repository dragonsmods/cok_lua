HeroPveRewardShowView = class("HeroPveRewardShowView", function (  )
	return PopupBaseView:call("create")
end)
HeroPveRewardShowCell = class("HeroPveRewardShowCell", function (  )
	return cc.TableViewCell:create()
end)

local EFFECT_VALUE_HERO_PVE = 6001 -- 付费用：英雄试炼（含扫荡）奖励提高

function HeroPveRewardShowView.create( data, title, canReceive, callback )
	local ret = HeroPveRewardShowView.new(data, title, canReceive, callback)
	if ret:initSelf() == false then
		ret = nil
	end
	return ret
end

function HeroPveRewardShowView:ctor( data, title, canReceive, callback )
	self.data = data
	self.titlestr = title
	self.canReceive = canReceive or false
	self.callback = callback
end

function HeroPveRewardShowView:initSelf(  )
	MyPrint("HeroPveRewardShowView:initSelf")
	if self:init(true, 0) == false then
		MyPrint("HeroPveRewardShowView init error")
    	return false	
	end
	self:setHDPanelFlag(true)

	local winsize = getWinSize()

	self:setContentSize(winsize)

	local proxy = cc.CCBProxy:create()
    local ccbiUrl = "HeroPveRewardShowView"
	local node = CCBReaderLoad(ccbiUrl, proxy, self)
    self:addChild(node)

    if CCCommonUtilsForLua:call("isIosAndroidPad") then
    	self.m_mainNode:setScale(2)
    end
    if nil == self.data then
    	return false
    end

    local listHeight = 678

	if self.canReceive then
    	self.m_receiveBtn:setVisible(true)
    	CCCommonUtilsForLua:setButtonTitle(self.m_receiveBtn, getLang("101313"))
    	listHeight = listHeight - 80
    	self.m_statusCard:setPositionY(self.m_statusCard:getPositionY() + 80)
    else
    	self.m_receiveBtn:setVisible(false)
    end

	-- 特权周卡
	if CCCommonUtilsForLua:isFunOpenByKey("status_card") then
		self.m_statusCard:setVisible(true)
		listHeight = listHeight - 60
		local effctValue = CCCommonUtilsForLua:call("getEffectValueByNum", EFFECT_VALUE_HERO_PVE)
		if effctValue > 0 then
			self.m_statusCardYes:setVisible(true)
			self.m_statusCardNo:setVisible(false)
			self.m_statusCardYesTips:setString(getLang("301144", effctValue))
		else
			self.m_statusCardYes:setVisible(false)
			self.m_statusCardNo:setVisible(true)
			self.m_statusCardNoTips:setString(getLang("301141"))
			CCCommonUtilsForLua:setButtonTitle(self.m_statusCardBuy, getLang("301146"))
		end
	else
		self.m_statusCard:setVisible(false)
	end

    self.m_listNode:setContentSize(cc.size(500, listHeight))

    self.m_tableView = cc.TableView:create(self.m_listNode:getContentSize())
	self.m_listNode:addChild(self.m_tableView)
	self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
	self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
	self.m_tableView:setDelegate()
	local function scrollViewDidScroll( view )
		return self:scrollViewDidScroll(view)
	end

	local function cellSizeForTable( view, idx )
		return self:cellSizeForTable(view, idx)
	end

	local function tableCellAtIndex( view, idx )
		return self:tableCellAtIndex(view, idx)
	end

	local function numberOfCellsInTableView( view )
		return self:numberOfCellsInTableView(view)
	end

	self.m_tableView:registerScriptHandler(scrollViewDidScroll,cc.SCROLLVIEW_SCRIPT_SCROLL)
	self.m_tableView:registerScriptHandler(cellSizeForTable,cc.TABLECELL_SIZE_FOR_INDEX)
	self.m_tableView:registerScriptHandler(tableCellAtIndex,cc.TABLECELL_SIZE_AT_INDEX)
	self.m_tableView:registerScriptHandler(numberOfCellsInTableView,cc.NUMBER_OF_CELLS_IN_TABLEVIEW)

	self.m_tableView:setAnchorPoint(cc.p(0, 0))
	self.m_tableView:reloadData()
	self.m_tableView:setContentOffset(cc.p(0, self.m_listNode:getContentSize().height - self.m_tableView:getContentSize().height))


	self.startTouchPt = cc.p(0, 0)
	self.touchLayer = cc.Layer:create()
	self:addChild(self.touchLayer)
	local function touchHandle( eventType, x, y )
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		else
			self:onTouchEnded(x, y)
		end
	end
	self.touchLayer:registerScriptTouchHandler(touchHandle)
	self.touchLayer:setTouchEnabled(true)
	self.touchLayer:setSwallowsTouches(false)


	self.m_titleLabel:setString(self.titlestr)

	local PveDataController = require("game.Training.PveDataController").getInstance()
    if PveDataController:isInEndlessView() then
        self.m_statusCardNoTips:setVisible(false)
		self.m_statusCardBuy:setVisible(false)
		self.m_statusCardYesTips:setVisible(false)
    end


    return true
end

function HeroPveRewardShowView:scrollViewDidScroll( view )
	
end

function HeroPveRewardShowView:cellSizeForTable( view, idx )
	return 550, 60
end

function HeroPveRewardShowView:tableCellAtIndex( view, idx )
	idx = idx+1
    if idx > #self.data then
		return nil
    end
    local cell = view:dequeueCell()
    if cell ~= nil then 
		cell:setData(self.data[idx])
    else
        cell = HeroPveRewardShowCell.new(self.data[idx])
    end
    return cell
end

function HeroPveRewardShowView:numberOfCellsInTableView( view )
	return #self.data
end

function HeroPveRewardShowView:onTouchBegan( x, y )
	if isTouchInside(self.m_touchNode, x, y) then
		return false
	end
	return true
end

function HeroPveRewardShowView:onTouchEnded( x, y )
	if isTouchInside(self.m_touchNode, x, y) then
		return
	end
	self:call("closeSelf")
end

function HeroPveRewardShowView:onCloseBtnClick(  )
	self:call("closeSelf")
end

function HeroPveRewardShowView:onReveiveBtnClick()
	if self.callback then self.callback() end
	self:call("closeSelf")
end

function HeroPveRewardShowView:onStatusCardBuy()
	if CCCommonUtilsForLua:isFunOpenByKey("month_card") then
        CCCommonUtilsForLua.jumpToTarget(gtblGoType.integrateMainView_MonthCard)
	else
		local view = MonthCardView:call("create")
		PopupViewController:addPopupInView(view)
	end
	PopupViewController:call("removePopupView", self)
end

function HeroPveRewardShowCell:ctor( data )
	MyPrint("HeroPveRewardShowCell:ctor")
	
	local proxy = cc.CCBProxy:create()
    local ccbiUrl = "HeroPveRewardShowCell"
	local node = CCBReaderLoad(ccbiUrl, proxy, self)
    self:addChild(node)


    self:setData(data)

end

function HeroPveRewardShowCell:setData( data )
	MyPrint("HeroPveRewardShowCell:setData", data)
	if nil == data then
		return
	end
	self.m_iconNode:removeAllChildren()
	self.m_sprChestBg:setVisible(true)
	self.m_nameLabel:setHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
	self.m_nameLabel:setString("")
	self.m_cntLabel:setString("")

	local t = tonumber(data.type)

	-- 只显示label  类型是1000时
	if t == 1000 then
		self.m_nameLabel:setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
		self.m_sprChestBg:setVisible(false)
		if nil ~= data.label then
			self.m_nameLabel:setString(data.label)
		end
	elseif t == 7 or t == 14 then
		-- 道具 装备
		local value = data.value
	    if nil ~= value then
	    	local colorstr = CCCommonUtilsForLua:call("getToolBgByColor", tonumber(CCCommonUtilsForLua:call("getPropById", tostring(value.id), "color")) or 0)
	    	local colorSpr = CCLoadSprite:call("createSprite", colorstr)

	    	local icon = CCCommonUtilsForLua:call("getIcon", tostring(value.id))
		    local spr = CCLoadSprite:call("createSprite", icon)
		    spr:setAnchorPoint(cc.p(0.5, 0.5))
		    CCCommonUtilsForLua:call("setSpriteMaxSize", colorSpr, 48, true)
		    CCCommonUtilsForLua:call("setSpriteMaxSize", spr, 48, true)
		    self.m_iconNode:addChild(colorSpr)
		    self.m_iconNode:addChild(spr)
		    local dialog = CCCommonUtilsForLua:call("getPropById", tostring(value.id), "name")
		    self.m_nameLabel:setString(getLang(dialog))
		    if nil ~= value.num then
		    	self.m_cntLabel:setString(tostring(value.num))
		    end

			-- 特权周卡
			local PveDataController = require("game.Training.PveDataController").getInstance()
			if CCCommonUtilsForLua:isFunOpenByKey("status_card") 
			and not PveDataController:isInEndlessView() then
				local effctValue = CCCommonUtilsForLua:call("getEffectValueByNum", EFFECT_VALUE_HERO_PVE)
				if effctValue > 0 then
					local addLabel = cc.LabelBMFont:create("x" .. (1 + effctValue / 100), "pve_fnt_boss.fnt")
					if addLabel then
						addLabel:setScale(0.4)
						addLabel:setAnchorPoint(cc.p(1, 1))
						addLabel:setPosition(29, 29 + 4)
						self.m_iconNode:addChild(addLabel)
					end
				end
			end
	    end
	end
end