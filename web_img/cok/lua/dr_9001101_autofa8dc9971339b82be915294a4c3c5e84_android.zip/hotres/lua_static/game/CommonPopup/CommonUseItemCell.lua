local CommonUseItemCell = class("CommonUseItemCell", cc.TableViewCell)

function CommonUseItemCell:create()
    local cell = CommonUseItemCell.new()
    Drequire("game.CommonPopup.CommonUseItemCell_ui"):create(cell, 0)
    return cell
end

function CommonUseItemCell:refreshCell(info, idx)
    self.itemId = info

    LibaoCommonFunc.createDataItemTouchNode(
        {
            itemData = {
                            type = 0,
                            itemId = atoi(self.itemId),
                            desScale = isPad and 1.8 or 1,
                        },
            iconNode = self.ui.m_iconNode,
            iconSize = 56,
            beTouch = false,
        }
    )

    local tinfo = ToolController:call("getToolInfoForLua", atoi(self.itemId))
    if tinfo then
        local count = tinfo:call("getCNT")
        local name = tinfo:call("getName")
        local desc = tinfo:getProperty("des")
        self.ui.m_nameLabel:setString(name)
        self.ui.m_descLabel:setString(getLang(desc))
        self.ui.m_numLabel:setString(CC_CMDITOA(count))
    end

    CCCommonUtilsForLua:setButtonTitle(self.ui.m_useBtn, getLang("169852"))
end

function CommonUseItemCell:onEnter()
    local function callback1() self:removeWaitInterface() end
    local handler1 = self:registerHandler(callback1)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "CommonUseItemCell:removeWaitInterface")
end

function CommonUseItemCell:onExit()
	CCSafeNotificationCenter:unregisterScriptObserver(self, "CommonUseItemCell:removeWaitInterface")
end

function CommonUseItemCell:removeWaitInterface() 
    if self.m_waitInterface then
        self.m_waitInterface:call("remove")
        self.m_waitInterface = nil
    end
end

function CommonUseItemCell:onUseBtnClick()
    self.m_waitInterface = GameController:call("showWaitInterface1", self.ui.m_useBtn)
    ToolController:call("useTool", atoi(self.itemId), 1, true)
end

return CommonUseItemCell