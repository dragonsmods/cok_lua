--前三名展示
local CommonRank3PlayerNode = class("CommonRank3PlayerNode", cc.Node)

--头部排行
local rankNumPicNames = {
    "Alliance_Ranking2.png",
    "Alliance_Ranking3.png",
    "Alliance_Ranking4.png"
}
--包箱
local rankBoxPicNames = {
    "common11baoxiangjin.png",
    "common11baoxianglan.png",
    "common11baoxianghui.png"
}
--背景
local nodeBGNames = {
    "BG_Ranking_01.png",
    "BG_Ranking_02.png",
    "BG_Ranking_03.png"
}

function CommonRank3PlayerNode:create(rank, info, parent)
    local node = CommonRank3PlayerNode.new()
    Drequire("game.CommonPopup.commonRank.CommonRank3PlayerNode_ui"):create(node)
    node:initNode(rank, info, parent)
    return node
end

function CommonRank3PlayerNode:initNode(rank, info, parent)
    -- dump(info,"hxq info is ")
    self.rank = rank
    self.info = info
    self.parent = parent
    local rankNumSprName = rankNumPicNames[rank]
    local sf = CCLoadSprite:call("getSF", rankNumSprName)
    if sf then
        self.ui.m_rankNumSpr:setSpriteFrame(sf)
    end

    if self.parent:hasReward() then
        local boxSprName = rankBoxPicNames[rank]
        sf = CCLoadSprite:call("getSF", boxSprName)
        if sf then
            self.ui.m_boxSpr:setSpriteFrame(sf)
        end
    else
        self.ui.m_boxSpr:setVisible(false)
        self.ui.m_sprSearch:setVisible(false)
        self.ui.m_rankNumSpr:setPosition(self.ui.m_boxSpr:getPosition())
        self.ui.m_rankNumSpr:setScale(1)
    end

    local nodeBGName = nodeBGNames[rank]
    sf = CCLoadSprite:call("getSF", nodeBGName)
    if sf then
        self.ui.m_nodeBG:setSpriteFrame(sf)
    end

    self.ui["m_nameLabel"]:setString("")
    self.ui["m_powerLabel"]:setString("")
    self.ui["m_serverLabel"]:setString("")

    self:setNodeInfo()
end

function CommonRank3PlayerNode:setNodeInfo()
    if not self.info then
        self.ui.m_nameLabel:setString("")
        self.ui.m_powerLabel:setString("")
        self.ui.m_serverLabel:setString("")
    else
        -- 玩家是否隐藏名字
        -- if self.info.hideKing == "1" or self.info.anonymous_state == 1 or not self.info.u_info then
        if self:isHideKing() then
            self.ui["m_nameLabel"]:setString(getLang("140473")) -- 140473=领主ID已隐藏
        else
            local str = self.info.u_info.name or ""
            if self.info.u_info.abbr and self.info.u_info.abbr ~= "" then
                str = "(" .. self.info.u_info.abbr .. ") " .. str
            end
            self.ui["m_nameLabel"]:setString(str)
        end

        self:refreshScore()

        local str = nil
        -- if self.info.hideKing == "1" or self.info.anonymous_state == 1 then  -- 玩家是否隐藏联盟
        if self:isHideKing() then
        else
            local sid = nil
            if self.info.sid and self.info.sid ~= "" then
                sid = self.info.sid
            elseif self.info.u_info.sid and self.info.u_info.sid ~= "" then
                sid = self.info.u_info.sid
            end

            if sid then
                local serverId = resetGreenServerId(sid)
                str = string.format("%s: %d", getLang("138027"), serverId)  -- 138027=王国
            else
                str = string.format("%s:", getLang("138027"))               -- 138027=王国
            end
        end

        if str then
            self.ui["m_serverLabel"]:setString(str)
        end

        self.ui["m_headNode"]:removeAllChildren()
        
        local pic = self.info.u_info and self.info.u_info.pic
        if not pic or pic == "0" or self:isHideKing() then
            pic = "g044.png"
        else
            pic = pic .. ".png"
        end
        local head = CCLoadSprite:call("createSprite", pic)
        head:setScale(0.5)
        self.ui["m_headNode"]:addChild(head)
        if not self:isHideKing() then
            local picVer = tonumber(self.info.u_info and self.info.u_info.picVer or 0)
            local uid = self.info.uid
            local picfraId = self.info.u_info and self.info.u_info.picfraId
            picfraId = picfraId or ""
            
            local headIcon = CCCommonUtilsForLua:call("makeUserHeadIcon", uid, pic, picfraId, picVer, 68)
            self.ui.m_kuangNode:removeAllChildren()
            self.ui.m_kuangNode:addChild(headIcon)
        end
    end
end

function CommonRank3PlayerNode:refreshScore()
    local _score = atoi(self.info.score)
    self.ui["m_powerLabel"]:setString(CC_CMDITOAL(_score))
end

function CommonRank3PlayerNode:onClickPicBtn()
    if self:isHideKing() or not self.info then
        return
    end
    
    if self.info.config and self.info.config.rankName then
        if self.info.config.rankName == "BeautyValueRank" then
            require("game.flower.FlowerController").getInstance():openSendView(self.info)
            return 
        end
    end

    local dict = CCDictionary:create()
    dict:setObject(CCString:create("GeneralsPopupView"), "name")
    local uid = self.info.uid
    if uid == nil then
        uid = self.info.u_info.uid
    end
    dict:setObject(CCString:create(uid), "uid")
    LuaController:call("openPopViewInLua", dict)

    if self.info.config and self.info.config.rankName then
        if self.info.config.rankName == "KnightValueRank" then
            require("game.flower.FlowerController").getInstance():showKnightTip()
        end
    end
end

function CommonRank3PlayerNode:onRewardButtonClick()
    self.parent:onRewardButtonClick(self.rank)
end

function CommonRank3PlayerNode:isHideKing()
    local info = self.info
    if not info or not info.u_info then
        return true
    end
    if not info.config or not info.config.getAnonymousOpen or not info.config:getAnonymousOpen() then
        return false
    end

    if info.isShowName == "0" 
    or info.anonymous_state == "1" 
    or info.hideKing == "1" then
        return true
    end
    return false
end

return CommonRank3PlayerNode
