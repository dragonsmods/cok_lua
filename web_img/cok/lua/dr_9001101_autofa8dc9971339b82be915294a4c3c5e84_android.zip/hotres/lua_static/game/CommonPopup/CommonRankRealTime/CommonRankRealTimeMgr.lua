-- @Author:fenghaibin 
-- @Date: 2020-10-29
-- @Description: 实时排行榜 信息管理类
local CommonRankRealTimeMgr = class("CommonRankRealTimeMgr")
local _CommonRankRealTimeMgr = _CommonRankRealTimeMgr or nil

function CommonRankRealTimeMgr:ctor()
    self.m_refreshViewEvent = utils.getEventClass():new()
    self.m_refreshPageDataEvent = utils.getEventClass():new()
    self.m_setAnonymousStateEvent = utils.getEventClass():new()
end

function CommonRankRealTimeMgr.getInstance()
    if not _CommonRankRealTimeMgr then 
        _CommonRankRealTimeMgr = CommonRankRealTimeMgr.new() 
    end
    return _CommonRankRealTimeMgr
end

function CommonRankRealTimeMgr:requestInfo( params )
	utils.requestServer( 'syncRank.info', { 
        {"rankKey",CCString:create(params.type)},
        {"selfId",CCString:create(params.selfId)},
        {"rankType",CCString:create(params.group)},}, nil, function ( tbl )
		self.m_refreshViewEvent:emit(tbl)
	end )
end

function CommonRankRealTimeMgr:requestPageInfo(params)
    utils.requestServer( 'syncRank.page', { 
        {"rankKey",CCString:create(params.type)},
        {"selfId",CCString:create(params.selfId)},
        {"rankType",CCString:create(params.group)},
        {"page",CCInteger:create(tonumber(params.page))},}, nil, function ( tbl )
		self.m_refreshPageDataEvent:emit(tbl.rank)
	end )
end

function CommonRankRealTimeMgr:reqSetAnonymousState(params, show_state)
    utils.requestServer( 'syncRank.anonymous', { 
        {"rankKey",CCString:create(params.type)},
        {"selfId",CCString:create(params.selfId)},
        {"rankType",CCString:create(params.group)},
        {"state",CCBool:create(show_state)},}, nil, function ( tbl )
		self.m_setAnonymousStateEvent:emit(tbl)
	end )
end

return CommonRankRealTimeMgr