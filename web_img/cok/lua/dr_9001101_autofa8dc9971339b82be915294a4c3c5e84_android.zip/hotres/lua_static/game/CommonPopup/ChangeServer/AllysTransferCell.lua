local AllysTransferCell = class("AllysTransferCell", cc.TableViewCell)

function AllysTransferCell:create()
    local cell = AllysTransferCell.new()
    Drequire("game.CommonPopup.ChangeServer.AllysTransferCell_ui"):create(cell, 0)
    return cell
end

function AllysTransferCell:refreshCell(info, idx)
    self.ui.m_rankTxt:setString(tostring(idx + 1))

    if info.name and info.name ~= "" then
        self.ui.m_nameTxt:setString(info.name)
    else
        self.ui.m_nameTxt:setString(getLang("150687"))
    end

    local mark = os.date("!%m;%d", atoi(info.time) / 1000)
    local solts = splitString(mark, ";")
    self.ui.m_timeTxt:setString(tostring(solts[1]) .. "." .. tostring(solts[2]))
end

return AllysTransferCell