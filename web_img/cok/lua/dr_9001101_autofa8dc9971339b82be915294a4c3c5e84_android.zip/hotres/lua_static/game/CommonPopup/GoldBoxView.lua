GoldBoxView = class("GoldBoxView", function()
        return PopupBaseView:create()
    end
)
GoldBoxView.__index = GoldBoxView

local PI = 3.1415926
local maxPlateNum = 12
local oneCircleDegree = 360
local oneCircleRadius = 260
local angle = 0
local waittime = 0

local PLATE_TURN_STEP_0 = 0
local PLATE_TURN_STEP_1 = 1
local PLATE_TURN_STEP_2 = 2
local PLATE_TURN_STEP_3 = 3
local PLATE_TURN_STEP_4 = 4
local PLATE_TURN_STEP_END = 5
local PLATE_TURN_STEP_MOVING = 6
local noticesList = {}
local moveLimitSpeed = 100
local discountDeltaSmallY = 7
local discountDeltaBigY = 17
--------------------------- 转盘信息 Start ---------------------------
local GoldBoxInfoCmd = class("GoldBoxInfoCmd", LuaCommandBase)
function GoldBoxInfoCmd.create()
	local ret = GoldBoxInfoCmd.new()
	ret:initWithName("goldwheel.info")
	return ret
end

function GoldBoxInfoCmd:handleReceive(dict)
	local cmdname = dict:valueForKey("cmd"):getCString()
	if cmdname ~= "goldwheel.info" then
		return false
	end
	--dump("GoldBoxInfoCmd:handleReceive")
	local params = dict:objectForKey("params")
	if nil == params then
		--dump("GoldBoxInfoCmd.create no params...")
		return true
	end
	params = tolua.cast(params, "CCDictionary")
	local tbl = dictToLuaTable(params)
	-- dump(tbl,"GoldBoxInfoCmd:handleReceive")

	if tbl.errorCode and tbl.errorCode ~= "" then
		LuaController:flyHint("", "", getLang(tbl.errorCode))
		return true
	end
	CCSafeNotificationCenter:postNotification("goldbox_get_wheelInfo",params)

	return true
end
--------------------------- 转盘信息 End ---------------------------
--------------------------- 抽奖信息 Start ---------------------------
local GoldBoxUseItemCmd = class("GoldBoxUseItemCmd", LuaCommandBase)
function GoldBoxUseItemCmd.create(wheelId,wheelNum,adType)
	local ret = GoldBoxUseItemCmd.new()
	ret:initWithName("goldwheel.wheel")
	ret:putParam("num", CCInteger:create(wheelNum))
	ret:putParam("id", CCString:create(wheelId))
	if adType then
		ret:putParam("videoType", CCInteger:create(adType))
	end
	return ret
end

function GoldBoxUseItemCmd:handleReceive(dict)
	local cmdname = dict:valueForKey("cmd"):getCString()
	if cmdname ~= "goldwheel.wheel" then
		return false
	end
	local params = dict:objectForKey("params")
	if nil == params then
		--dump("GoldBoxUseItemCmd.create no params...")
		return true
	end
	params = tolua.cast(params, "CCDictionary")
	local tbl = dictToLuaTable(params)
	-- dump(tbl,"GoldBoxUseItemCmd:handleReceive")

	if tbl.errorCode and tbl.errorCode ~= "" then
		LuaController:flyHint("", "", getLang(tbl.errorCode))
		return true
	end

	if tbl.gold ~= nil then
		--MyPrint("cjy nowGold" ,tbl.gold)
		local nowGold = tonumber(tbl.gold)
		local playerInfo = GlobalData:call("getPlayerInfo")
		if playerInfo ~= nil then
			playerInfo:setProperty("gold", nowGold)
			CCSafeNotificationCenter:postNotification("city_resources_update")
		end
	end
	CCSafeNotificationCenter:postNotification("goldbox_get_wheelResult",params)
	require("game.controller.LuaAdController").getInstance():setData(tbl)
	return true
end
--------------------------- 抽奖信息 End ---------------------------
--------------------------- 积分奖励领取 Start ---------------------------
local GetScoreRewardNotify = "goldbox_get_scoreReward"
local GoldBoxGetScoreRewardCmd = class("GoldBoxGetScoreRewardCmd", LuaCommandBase)
function GoldBoxGetScoreRewardCmd.create(score)
	dump("GoldBoxGetScoreRewardCmd score is: "..tostring(score))
	local ret = GoldBoxGetScoreRewardCmd.new()
	ret:initWithName("goldwheel.recieve")
	ret.m_score = score
	ret:putParam("score", CCInteger:create(score))
	return ret
end

function GoldBoxGetScoreRewardCmd:handleReceive(dict)
	local tbl = self:parseMsg(dict)
    if type(tbl) == "boolean" then
        return tbl
    end
    dump(tbl, "GoldBoxGetScoreRewardCmd:handleReceive ")
    if tbl.reward then
        createTableFlyReward(tbl.reward)
    end

	CCSafeNotificationCenter:postNotification(GetScoreRewardNotify, CCInteger:create(self.m_score))

	return true
end
--------------------------- 积分奖励领取 End ---------------------------

--------------------------- GoldBoxFlySystem start ---------------------------
local GoldBoxFlySystem = class("GoldBoxFlySystem", function()
    return cc.Layer:create()
end)

GoldBoxView.GoldBoxFlySystem = GoldBoxFlySystem

function GoldBoxFlySystem:create(dataList)
    local ret = GoldBoxFlySystem.new()
    if ret:init(dataList) == false then
        return nil
    end
    return ret
end

function GoldBoxFlySystem:init(dataList)
    --初始化界面
    --MyPrint("GoldBoxFlySystem init start")
    local proxy = cc.CCBProxy:create()
    local ccbiURL = ""
    ccbiURL = "ccbi/GoldBoxFlySystem.ccbi"

    local nodeccb = CCBReaderLoad(ccbiURL,proxy, self)
    if nodeccb == nil then
        --MyPrint("GoldBoxFlySystem loadccb error")
        return false
    end

    self:setContentSize(nodeccb:getContentSize())
    self:addChild(nodeccb)

    local function onNodeEvent(event)
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end
    self.ccbNode = nodeccb
    self.ccbNode:registerScriptHandler(onNodeEvent)

    function onTouch(eventType, x, y)  
        if eventType == "began" then  
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)  
        else  
            return self:onTouchEnded(x, y)  
        end
    end
    self:setTouchEnabled(true)
    self:registerScriptTouchHandler(onTouch)

    self.m_dataList = dataList
    self.m_shakeSp:setVisible(false)
    self.m_btnClose:setVisible(false)
    self.ccbNode:setScaleY(0)
    self.ccbNode:runAction(cc.ScaleTo:create(0.5, 1))
    self:refreshCell()

    return true
end

function GoldBoxFlySystem:onTouchBegan(x, y)
    
end

function GoldBoxFlySystem:onTouchMoved(x, y)
end

function GoldBoxFlySystem:onTouchEnded(x, y)
end

function GoldBoxFlySystem:onCloseClick(  )
	
end
function GoldBoxFlySystem:refreshCell()
    --MyPrint("GoldBoxFlySystem setData start")
    local posX = self.m_bg:getContentSize().width
	local nodesize = self.m_bg:getContentSize()
	self.contentNode = cc.Node:create()
    self.clipNode = CCClipNode:call("create",nodesize.width, nodesize.height)
    self.clipNode = tolua.cast(self.clipNode, "cc.Node")
    self.clipNode:setAnchorPoint(cc.p(0.5, 0.5))
    self.clipNode:setPosition(cc.p(0, 0))
    self.clipNode:addChild(self.contentNode)
	self.m_container:addChild(self.clipNode)
    for i,v in ipairs(self.m_dataList) do
		local noticeLabel = cc.Label:createWithSystemFont(getLang(v.msgId,v.para[1],CCCommonUtilsForLua:call("getNameById", tostring(v.para[2]))), "Helvetica", 18, cc.size(0.0,0))
		noticeLabel:setPosition(cc.p(posX, 25))
		posX = posX + noticeLabel:getContentSize().width + 100
		noticeLabel:setAnchorPoint(cc.p(0, 0.5))
	    self.contentNode:addChild(noticeLabel)
    end
	local moveBy1 = cc.MoveBy:create(#self.m_dataList * 9, ccp(-posX, 0))
	local function callback() self:replaceNotice() end
	local funcall = cc.CallFunc:create(callback)
	local seq = cc.Sequence:create(moveBy1, funcall)
	local action = cc.RepeatForever:create(seq)
    self.contentNode:runAction(action)

	self.clipNode:setZOrder(999)
	self.contentNode:setZOrder(999)
end

function GoldBoxFlySystem:onEnter()
end

function GoldBoxFlySystem:replaceNotice(  )
	self.contentNode:setPositionX(200.0)
end

function GoldBoxFlySystem:onExit()
end
------------------------------------------ GoldBoxFlySystem End --------------------------------------------

------------------------------------------ GoldBoxView Start --------------------------------------------
local LuaAdController = require("game.controller.LuaAdController").getInstance()
function GoldBoxView:create(activityId)
	local view = GoldBoxView.new()
	if view:initView(activityId) == false then
		return nil
	end
  	return view
end

function GoldBoxView:initView(activityId)
	if self:init(true, 4) == false then
		--MyPrint("GoldBoxView init error")
    	return false
	end

	self.m_localCheckKey = "GoldBoxUseCheck"
	self.m_lotteryType = 3 --抽奖道具在shopmall 传的type
	self:setHDPanelFlag(true)
	self.serialOpen10Count = 10
	self.serialOpen100Count = tonumber(CCCommonUtilsForLua:getPropById("89602", "rewardtype2"))
    self.serialOpen500Count = tonumber(CCCommonUtilsForLua:getPropById("89602", "rewardtype3"))
	--MyPrint("GoldBoxView:initView")
	local obj = ActivityController:call("getInstance"):call("getActObj", tostring(activityId))
  	if obj and obj:getProperty("endTime") then
  		self.m_endTime = tonumber(obj:getProperty("endTime"))
  		local now = LuaController:call("getWorldTime")
  		if now >= obj:getProperty("endTime") then
	  		LuaController:flyHint("","",getLang("102517"))
	  		return false
	  	end
  	else
  		LuaController:flyHint("","",getLang("102517"))
  		return false
  	end
  	MyPrint("cjy initPanelData")
	callItSelfCallFunc(LuaController, "doResourceByCommonIndex", 7, true)
	callItSelfCallFunc(LuaController, "doResourceByCommonIndex", 11, true)
	callItSelfCallFunc(LuaController, "doResourceByCommonIndex", 100, true)
	callItSelfCallFunc(LuaController, "doResourceByCommonIndex", 310, true)

	local m_bIsPad = CCCommonUtilsForLua:isIosAndroidPad()
	local proxy = cc.CCBProxy:create()
	local ccbiURL = ""
	ccbiURL = "ccbi/GoldBoxView.ccbi"
  	self.m_bIsPad = m_bIsPad
  	local nodeccb = CCBReaderLoad(ccbiURL,proxy, self)
	if nodeccb == nil then
		--MyPrint("GoldBoxView loadccb error")
		return false
	end

	local realSize = cc.Director:getInstance():getIFWinSize()
	local screenSize
	if self.m_bIsPad then
		screenSize = CCSize(realSize.width/2.4, realSize.height/2.4)
		nodeccb:setScale(2.4)
  		nodeccb:setPosition((realSize.width-640)*0.5, (realSize.height-852)*0.5)
  		nodeccb:setAnchorPoint(0.5, 0.5)
	else
		screenSize = CCSize(realSize.width, realSize.height)
  		nodeccb:setPosition(0, (realSize.height-852))
  		nodeccb:setAnchorPoint(0.5, 0.5)
	end
	--dump(screenSize)
	self:setContentSize(realSize)

	local curSize = nodeccb:getContentSize()

	local layer = cc.LayerColor:create(cc.c4b(0, 0, 0, 255))
	layer:setContentSize(realSize)
	self:addChild(layer)
  	self:addChild(nodeccb)
  	self.nodeccb = nodeccb

	local descNode = callItSelfCallFunc(CommonItemDescNode, "create", "", "", false)
	descNode:setPosition(curSize.width*0.5, curSize.height*0.5)
	self.baseNode:addChild(descNode)
	self.descNode = descNode
	descNode:setVisible(false)

  	-- 屏幕适配
  	local offsetH = 85 -- 屏幕上方标题高
  	-- 是否开启积分宝箱
  	local hasScoreList = CCCommonUtilsForLua:isFunOpenByKey("golden_roulette_Integral_reward")
  	self.m_hasScoreList = hasScoreList
  	local allContentSize = self.m_baseScaleNode:getContentSize()
  	if hasScoreList then
  	else
  		local scorListSize = self.m_scoreListNode:getContentSize()
  		self.m_scoreListNode:setVisible(false)
  		allContentSize = cc.size(allContentSize.width, allContentSize.height - scorListSize.height)
  		self.m_middleNode:setPositionY(self.m_middleNode:getPositionY() + scorListSize.height)
  		self.m_bottomNode:setPositionY(self.m_bottomNode:getPositionY() + scorListSize.height)
  	end

  	--pad不用做以下调整
	if CCCommonUtilsForLua:call("checkBeIphoneX") then 
		self.m_bottomNode:setPositionY(self.m_bottomNode:getPositionY()-50)
		self.btn_goldBoxTips:setPositionY(self.btn_goldBoxTips:getPositionY()+30)
		self.m_nodeAd:setPositionY(self.m_nodeAd:getPositionY()+35)
		self.node_goldboxContent:setPositionY(self.node_goldboxContent:getPositionY()+20)
		self.node_btn1:setPositionY(self.node_btn1:getPositionY()+20)
		self.node_btn2:setPositionY(self.node_btn2:getPositionY()+20)
		self.node_btn100:setPositionY(self.node_btn100:getPositionY()-20)
		self.node_btn500:setPositionY(self.node_btn500:getPositionY()-20)
	end

  	if self.m_bIsPad then
  		offsetH = offsetH - 10
  		self.m_headLine:setPositionY(curSize.height - 64)
  		self.m_baseScaleNode:setPositionY(self.m_baseScaleNode:getPositionY() + 10)
  	end

  	local scale = (screenSize.height - offsetH)/allContentSize.height
  	if scale > 1 then
  		scale = 1
  	end
  	self.m_baseScaleNode:setScale(scale)

  	-- 砖底的位置
	local turnNodeSize = self.m_turnNode:getContentSize()
  	local wallPosY = 852 - offsetH - turnNodeSize.height*scale
  	self.m_wallNode:setPositionY(wallPosY)

  	-- 排行榜和加速位置
  	local btnPosY = 852 - offsetH - turnNodeSize.height*scale
  	self.m_btnNode:setPositionY(btnPosY)  	

  	self.plateState = PLATE_TURN_STEP_0
  	self.m_curIndex = 1 -- 青铜、白银、黄金 89600 89601 89602
  	self.m_allRewardData = {}
  	self.curRewardData = {}
	self.curRewardItemId = 0
	self.curMessageRet = nil
	self.state = 0
	self.thisRewardIndex = 0
	self.baodi_num = 10
	self.baodi_rewardId = nil
	self.actionNode = CCNode:create()
	self:addChild(self.actionNode)
	self.descNodeHightPos = cc.p(curSize.width*0.5, 852 - offsetH - turnNodeSize.height*scale*0.5)
	self.descNodeLowPos = cc.p(curSize.width*0.5, self.m_middleNode:getPositionY() - 150)
	self.txt_rankLabel:setString(getLang("150289"))
    self:setTitleName(getLang("140445"))
    self.m_activityId = activityId
    self.m_progress:setScaleX(0)
	self.m_limitlevel = 0
	self.txt_timeCount1:setVisible(false)
	self.getResult = false
  	self.m_disCount = self:isTicketOpen() and 1 or ActivityController.getInstance():getProperty("goldBoxCostDiscount") / 100
  	if self.m_disCount <= 0 or self.m_disCount > 1 then
  		self.m_disCount = 1
  	end

  	self:initPanelData()
	local function onNodeEvent(event)
		if event == "enter" then
			self:onEnter()
		elseif event == "exit" then
			self:onExit()
		end
	end
  	self.nodeccb:registerScriptHandler(onNodeEvent)

  	function onTouch(eventType, x, y)  
        if eventType == "began" then  
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)  
        else  
            return self:onTouchEnded(x, y)  
        end
    end
    self:setTouchEnabled(true)
    self:registerScriptTouchHandler(onTouch)

    self:initScoreList()
	self.txt_click100:setString(getLang("176078", self.serialOpen100Count)) --176078=连开{0}
	self.txt_click500:setString(getLang("176078", self.serialOpen500Count))

	if not CCCommonUtilsForLua:isFunOpenByKey("golden_roulette_5h_open") then
		self.node_btn100:setVisible(false)
		self.node_btn500:setVisible(false)
	end

	self.m_normalTime = 0
	self.m_silverTime = 0

	-- 视频广告
	self.m_nodeAd:setVisible(false)
	self.adType = AD_TYPE.GOLDBOX_DRAW
	self:initAd(self.adType)
	self:refresh()

	self:resetTicketIcon()
	self:refreshTicketNum()
	self:initCheckBox()
	self:requestServerTicketId()
    return true
end

function GoldBoxView:initAd( adType )
	local function callback( )
		local mlv = FunBuildController:call("getMainCityLv")
		if self.m_limitlevel <= tonumber(mlv) then
			self:startPanelRun(self.m_qingtongId,1,true,self.adType)
		else
			LuaController:flyHint("", "", getLang("103954",self.m_limitlevel))
		end
	end

	LuaAdController:initAd(self.adType)
	LuaAdController:getData({self.adType})
	LuaAdController:initTypViewMgr(self.adType, callback)
end

function GoldBoxView:refresh(  )
    -- cclog("GoldBasinNafu:refresh")
    -- 刷新广告
	local _isCanPlay = LuaAdController:isCanPlay(self.adType)
	if _isCanPlay then
		if self.m_adSchedule then
			self:getScheduler():unscheduleScriptEntry(self.m_adSchedule)
		end
		self:updateAd()
		self.m_adSchedule = self:getScheduler():scheduleScriptFunc(function(dt) self:updateAd() end, 1, false)
	end
end

-- 更新广告倒计时
function GoldBoxView:updateAd()
	local _offset = LuaAdController:getNextAdStamp() - getTimeStamp()
    local adInfo = LuaAdController:getDataByTypes(self.adType)
    -- utils.dump( adInfo, "updateAd~~~~~~~~~" )
	if adInfo and adInfo.open > 0 and adInfo.cur < adInfo.max and self.m_curIndex == 1 then
		self.m_nodeAd:setVisible(true)
		if self.plateState == PLATE_TURN_STEP_0 then 
			self.m_btnAd:setEnabled(_offset <= 0)
		else
			self.m_btnAd:setEnabled(false)
		end
		if _offset > 0 then
			self.m_labelAd:setString(format_time(_offset))
		else
			self.m_labelAd:setString(string.format('%d/%d', adInfo.max - adInfo.cur, adInfo.max))
		end
	else
		self.m_nodeAd:setVisible(false)
	end

	if self.m_nodeAd:isVisible() == false then
		if self.m_adSchedule then
			self:getScheduler():unscheduleScriptEntry(self.m_adSchedule)
		end
	end
end

--播放视频广告
function GoldBoxView:onClickBtnAd()
	LuaAdController:playVideo(self.adType)
	-- LuaAdController:callback( self.adType )
end

function GoldBoxView:requestServerTicketId(  )
	if self:isTicketOpen() then
		local ShopMallController = require("game.shop.ShopMallController")
		ShopMallController.showBuyTicketView( self.m_lotteryType,function ( tbl )
			self.m_lotteryId = tbl and tbl.goodsArray and tbl.goodsArray[1].targetId
			local _ = self and self.m_finishShareNode and self.m_finishShareNode:setVisible((not not self.m_lotteryId) and self:isTicketOpen())
		end)
	end
end

function GoldBoxView:getRewardDataInfo(ref)
	if nil == ref then 
        dump("OneRechargeView:getRewardDetailBack ref is nil")
        return 
    end
    local rwdId = ref:getCString()

    for i, data in pairs(self.m_scoreDataList or {}) do
        if rwdId == data.reward then
            local rwd = GlobalData:call("getCachedRewardData", data.reward)
            data.rewardData = arrayToLuaTable(rwd)
            break
        end
    end
end

function GoldBoxView:initScoreList()
	if self.m_hasScoreList == false then
		return
	end
	-- 仿最新代码逻辑实现tableview
	self.owner = self
    local TableViewSmoker = Drequire("Editor.TableViewSmoker")
    self.m_TableViewSmoker = TableViewSmoker
    TableViewSmoker:createView(self, "m_tableList", "game.CommonPopup.GoldBoxHeadCell", 0, 6, "ConsumeActivityPointCell")
end

function GoldBoxView:reloadScoreList(rewardFlags)
	if rewardFlags == nil then
		return
	end
	if self.m_hasScoreList == false then
		return
	end

	if self.m_scoreDataList == nil then
		if self.m_scoreList == nil then
			return
		end
		-- dump("self.m_scoreList is: "..self.m_scoreList)
		local tbl = string.split(self.m_scoreList, "|")
		local new = {}
		local keyTbl = {}
		for i, rwd in pairs(tbl) do
			local tmp = string.split(rwd, ";")
			new[i] = {score = tonumber(tmp[1]), reward = tmp[2], flag = "0"}
			
			if i > 1 then
				new[i].lastScore = new[i-1].score
			else
				new[i].lastScore = 0
			end
            local rwdArry = GlobalData:call("getCachedRewardData", tmp[2])
           	local rewardData = arrayToLuaTable(rwdArry)
            if #rewardData == 0 then
	            GlobalData:call("checkAndRequestRewardData", tmp[2])
            else
            	new[i].rewardData = rewardData
	        end
	        keyTbl[new[i].score] = new[i]
		end
		self.m_scoreDataList = new
		self.m_scoreKeyList = keyTbl
		-- dump(self.m_scoreDataList, "self.m_scoreDataList is: ")
	end

	local flagTbl = {}
	local tbl = string.split(rewardFlags, "|")
	for i, key in pairs(tbl) do
		if key ~= "" then
			local tmp = string.split(key, ";")
			-- 检测
			flagTbl[tonumber(tmp[1])] = tmp[2]
		end
	end

	for i, data in pairs(self.m_scoreDataList) do
		data.curScore = self.m_score
		if data.score <= self.m_score then
			if flagTbl[data.score] == "1" then
				data.status = 2 		-- 已领取
			else
				data.status = 1 		-- 可领取
			end
		else
			data.status = 0 		-- 不可领取
		end
	end

	self.m_TableViewSmoker:refreshTableView(self, "m_tableList", self.m_scoreDataList)
end

function GoldBoxView:tableCellTouched(tab, cell)
	dump("cell touched ")
	local info = cell:getInfo()

	if not info.rewardData then
		dump(info, " no has rewardData")
		return
	end
    local function callBack()
    	dump("getRewardTouch")
    	if info.status == 1 then
	    	local cmd = GoldBoxGetScoreRewardCmd.create(info.score)
	    	cmd:send()
	    end
        -- self:getRewardFun(self.upCellInfo)
    end
    local btnName = nil
    if info.status == 1 then
        btnName = getLang("138029")
    elseif info.status == 2 then
        btnName = getLang("140238")
    else
        btnName = getLang("101274")
    end
    local view = Drequire("commonView.RewardListShowView"):create({
            reward = info.rewardData,
            callBack = callBack,
            -- titleName = getLang("9440161"),
            btnName = btnName,
        })
    PopupViewController:addPopupView(view)
end

function GoldBoxView:getScoreReward(ref)
	local score = ref and ref:getValue() or 0
	if score == 0 then
		return
	end
	for i, data in pairs(self.m_scoreDataList) do
		if data.score == score then
			data.status = 2
		end
	end
	self.m_TableViewSmoker:refreshTableView(self, "m_tableList", self.m_scoreDataList)
end

function GoldBoxView:showNotices(  )
	local cell = GoldBoxFlySystem:create(noticesList)
	if cell then
		self.node_flySystem:addChild(cell)
	end
end
-- 刷新函数
function GoldBoxView:refreshRewardData(ref)
	local refTable = dictToLuaTable(ref)
	self.m_curResultDatas = refTable.items
	-- dump(self.m_curResultDatas,"cjy self.m_curResultDatas")
	if self.m_curResultDatas and #self.m_curResultDatas > 0 then
		self.getResult = true
		-- 选中索引
		self.m_curResultId = self.m_curResultDatas[1].id
		for i,v in ipairs(self.curRewardItemData) do
			if tonumber(v) == tonumber(self.m_curResultId) then
				self.selectPlateNum = i
				--MyPrint("self.selectPlateNum",self.selectPlateNum)
				self.selectPlateAngle = ((self.selectPlateNum-1) * oneCircleDegree / self.plateNum)
			end
		end
		if cc.UserDefault:getInstance():getBoolForKey("GOLDBOX_ISQUICK", true) then
			self.m_turnCenterNode:stopAllActions()
			self:showPlateResult()
		end
	end
	self:refreshPlateData(ref)
end

function GoldBoxView:changePlateData( changeIndex ,isPlay)
	self.m_curIndex = changeIndex
	self:refresh()
	local color1 = cc.c3b(43 , 94 , 97)
	local color2 = cc.c3b(43 , 94 , 97)
	local color3 = cc.c3b(43 , 94 , 97)
	if self.m_curIndex == 1 then
		color1 = cc.c3b(255,255,255)
	elseif self.m_curIndex == 2 then
		color2 = cc.c3b(255,255,255)
	elseif self.m_curIndex == 3 then
		color3 = cc.c3b(255,255,255)
	end
	self.txt_BtnContent1:setColor(color1)
	self.txt_BtnContent2:setColor(color2)
	self.txt_BtnContent3:setColor(color3)
	--动画
	if isPlay then
		local small = cc.ScaleTo:create(0.3, 0.1)--time scale
	    local big = cc.ScaleTo:create(0.3, 1)
	    local action = cc.Sequence:create( small,big)
	    self.m_turnCenterNode:runAction(action)
	end
	self:refreshTimeInmidia()
	self:changeGoldBoxParticle(changeIndex)
	self.curRewardData = self.m_allRewardData[self.m_curIndex]
	self.curRewardItemData = string.split(self.curRewardData.item,";")
	self.curRewardNumData = string.split(self.curRewardData.item_num,";")
	self.m_curWheelId = self.m_allRewardData[self.m_curIndex].id
	self.m_curWheelIndex = self.m_allRewardData[self.m_curIndex].index

	-- 计算间隔
	local angle = oneCircleDegree / maxPlateNum
	local x = 0;
	local y = 0;
	for i = 1, maxPlateNum do
		local angle1 = angle * (maxPlateNum - i + 1) * PI / 180
		x = math.sin(angle1) * oneCircleRadius
		y = math.cos(angle1) * oneCircleRadius
		local plateNode = self.plateNodeTbl[i]
		plateNode:setPosition(ccp(x, y))
		
		local bgSpr = plateNode:getChildByTag(1)
		local IconNode = plateNode:getChildByTag(2)
		IconNode:removeAllChildren(true)

		local color = CCCommonUtilsForLua:getPropById(tostring(self.curRewardItemData[i]), "color")
		local colorBg = CCLoadSprite:createSprite("color_c_"..color..".png")
		IconNode:addChild(colorBg)
		colorBg:setScale(1.08)

		CCCommonUtilsForLua:createGoodsIcon(tonumber(self.curRewardItemData[i]), IconNode, CCSize(88, 88) )
		IconNode:getChildByTag(GOODS_BG_TAG):setVisible(false)

		local numBg = CCLoadSprite:createSprite("frame_02png.png")
		IconNode:addChild(numBg)
		numBg:setPosition(0, 0 - self.itemBgSize.height*0.3)
		numBg:setScale(0.7)
		numBg:setOpacity(155)
		local numTxt = cc.Label:createWithSystemFont(self.curRewardNumData[i], "Helvetica", 24, cc.size(0.0,0))
		IconNode:addChild(numTxt)
		numTxt:setColor(cc.c3b(167, 127, 55))
		numTxt:setPosition(0,  0 - self.itemBgSize.height * 0.3)

		MyPrint("self.curRewardData.important",self.curRewardData.important)
		--dump(self.curRewardItemData,"self.curRewardItemData ",i)
		--dump(self.curRewardData,"self.curRewardItemData ",i)
		--dump(self.m_allRewardData,"self.curRewardItemData ",i)
	    if self.curRewardData.important then
	    	for a,v in ipairs(string.split(self.curRewardData.important,";")) do
	    		--MyPrint("cjy important1 ",v,self.curRewardItemData[i])
	    		if self.curRewardItemData[i] == tostring(v) then
		    		local particleNode = cc.Node:create()
		    		local PaticleEff = ParticleController:call("createParticle", "Upgradegift4_0")--1 紫色 2 蓝色 3金色 4 小
				    PaticleEff:setPosition(cc.p(0,0));
				    particleNode:addChild(PaticleEff);
				    local PaticleEff2 = ParticleController:call("createParticle", "Upgradegift4_1")
				    PaticleEff2:setPosition(cc.p(0,0));
				    particleNode:addChild(PaticleEff2);
				    -- local PaticleEff3 = ParticleController:call("createParticle", "Upgradegift4_2")
				    -- PaticleEff3:setPosition(cc.p(0,0));
				    -- particleNode:addChild(PaticleEff3);
				    IconNode:addChild(particleNode)
		    	end
	    	end
	    	
	    end
	end
	--MyPrint("cjy i am here1 ",self.silverUsable,self.goldUsable,self.normalFree,self.silverUsableFree)
    if self.m_disCount == 1 then    
    	self.node_hotPrice:setVisible(false)
    	self.node_hotPrice100:setVisible(false)
    	self.node_hotPrice500:setVisible(false)
    	self.txt_clickTenGold:setPositionY(self.m_hotpriceLabel1:getPositionY() + discountDeltaSmallY)
    	self.txt_click100Gold:setPositionY(self.m_hotpriceLabel100:getPositionY() + discountDeltaSmallY)
    	self.txt_click500Gold:setPositionY(self.m_hotpriceLabel500:getPositionY() + discountDeltaSmallY)
    else
    	self.node_hotPrice:setVisible(true)
    	self.node_hotPrice100:setVisible(true)
    	self.node_hotPrice500:setVisible(true)
    	self.txt_clickTenGold:setPositionY(self.m_hotpriceLabel1:getPositionY() + discountDeltaBigY)
    	self.txt_click100Gold:setPositionY(self.m_hotpriceLabel100:getPositionY() + discountDeltaBigY)
    	self.txt_click500Gold:setPositionY(self.m_hotpriceLabel500:getPositionY() + discountDeltaBigY)
    end

    local myGold
    if self:isTicketOpen() then
    	local p
	    p,myGold = utils.getItemNameByItemId(self:getTicketId())
	    myGold = myGold and myGold:call("getCNT") or 0
	else
		myGold = GlobalData:call("getPlayerInfo"):getProperty("gold")
    end

    self.m_clickBtn_Once.m_useFree = nil
	if self.plateState == PLATE_TURN_STEP_0  then
		if changeIndex == 3 then
			--MyPrint("cjy i am 3")
			self.txt_timeCount1:setVisible(false)
			self.m_curWheelId = self.m_huangjinId
			self.spr_goldBox1:setVisible(false)
			self.spr_goldBox2:setVisible(false)
			self.spr_goldBox3:setVisible(true)
			self.btn_wheel1:setEnabled(true)
			self.btn_wheel2:setEnabled(true)
			self.btn_wheel3:setEnabled(false)
		    self.txt_clickOnceGold:setString(self:getUnitPrice())

			--黄金没有免费次数
			self.txt_clickOnce:setString(getLang("140457"))
			self.txt_clickOnce:setPositionY(self.m_clickBtn_Once:getPositionY() + 15)
			self.node_btnOnceContent:setVisible(true)
			--enabled
			-- if self.goldUsable >= 1 and GlobalData:call("getPlayerInfo"):getProperty("gold") >= tonumber(self:getUnitPrice()) then	--开1		
			self.txt_clickOnceGold:setColor(myGold >= tonumber(self:getUnitPrice()) and cc.c3b(255,238,48) or cc.c3b(255,0,0))
		    if self.goldUsable >= 1 then	--开1		
				self.m_clickBtn_Once:setEnabled(true)
				-- self.m_clickBtn_Once.m_useFree = true
			else
				local f = self:isTicketOpen() and 1 or 0
				self.m_clickBtn_Once:setEnabled(self.goldUsable >= 1 and utils.numberToBool(f))
			end

		    local function ChangeButtonsInfo3(serialCount, serialButton, hotpriceLabel, serialClickGoldCountLabel)
			    local nowCost = tonumber(self:getUnitPrice()) * serialCount
				local discountCost = math.floor(nowCost * self.m_disCount)
			    hotpriceLabel:setString(nowCost)
			    serialClickGoldCountLabel:setString(discountCost)
				if self.goldUsable >= serialCount then --开10
					serialButton:setEnabled(true)
				else
					serialButton:setEnabled(false)
				end
			end
			ChangeButtonsInfo3(self.serialOpen10Count, self.m_clickBtn_serial, self.m_hotpriceLabel1, self.txt_clickTenGold)
			ChangeButtonsInfo3(self.serialOpen100Count, self.m_btn100Open, self.m_hotpriceLabel100, self.txt_click100Gold)
			ChangeButtonsInfo3(self.serialOpen500Count, self.m_btn500Open, self.m_hotpriceLabel500, self.txt_click500Gold)

		elseif changeIndex == 2 then
			self.m_curWheelId = self.m_baiyinId
			self.spr_goldBox1:setVisible(false)
			self.spr_goldBox2:setVisible(true)
			self.spr_goldBox3:setVisible(false)
			self.btn_wheel1:setEnabled(true)
			self.btn_wheel2:setEnabled(false)
			self.btn_wheel3:setEnabled(true)
			self.txt_clickOnceGold:setString(self:getUnitPrice())
			self.txt_clickOnceGold:setColor(myGold >= tonumber(self:getUnitPrice()) and cc.c3b(255,238,48) or cc.c3b(255,0,0))

		    local function ChangeButtonsInfo2(serialCount, serialButton, hotpriceLabel, serialClickGoldCountLabel)
			    local nowCost = tonumber(self:getUnitPrice()) * (serialCount)
				if self.silverUsableFree >= 1 then
					self.txt_timeCount1:setVisible(false)
					self.txt_clickOnce:setString(getLang("164536"))
					self.txt_clickOnce:setPositionY(self.m_clickBtn_Once:getPositionY())
					self.node_btnOnceContent:setVisible(false)
				elseif self.m_limitlevel <= tonumber(FunBuildController:call("getMainCityLv")) then
					self.txt_timeCount1:setVisible(true)
					self.txt_clickOnce:setString(getLang("140457"))
					self.txt_clickOnce:setPositionY(self.m_clickBtn_Once:getPositionY() + 15)
					self.node_btnOnceContent:setVisible(true)
					nowCost = tonumber(self:getUnitPrice()) * serialCount
				end
				local discountCost = math.floor(nowCost * self.m_disCount)
			    hotpriceLabel:setString(nowCost)
			    serialClickGoldCountLabel:setString(discountCost)

				--enabled
				if self.silverUsableFree >= 1 then	--开1		
					self.m_clickBtn_Once:setEnabled(true)
					self.m_clickBtn_Once.m_useFree = true
				elseif self.silverUsableFree < 1 and self.silverUsable > 0 then
					self.m_clickBtn_Once:setEnabled(true)
				else
					local f = self:isTicketOpen() and 1 or 0
					self.m_clickBtn_Once:setEnabled(self.goldUsable >= 1 and utils.numberToBool(f))
				end

				if self.silverUsableFree >= 1 then
					self.txt_timeCount1:setVisible(false)
				elseif self.m_limitlevel <= tonumber(FunBuildController:call("getMainCityLv")) then
					self.txt_timeCount1:setVisible(true)
				end
				if (self.silverUsableFree + self.silverUsable) >= serialCount then --开10
					
					serialButton:setEnabled(true)
				else
					serialButton:setEnabled(false)
				end
			end
			ChangeButtonsInfo2(self.serialOpen10Count, self.m_clickBtn_serial, self.m_hotpriceLabel1, self.txt_clickTenGold)
			ChangeButtonsInfo2(self.serialOpen100Count, self.m_btn100Open, self.m_hotpriceLabel100, self.txt_click100Gold)
			ChangeButtonsInfo2(self.serialOpen500Count, self.m_btn500Open, self.m_hotpriceLabel500, self.txt_click500Gold)

		elseif changeIndex == 1 then
			self.m_curWheelId = self.m_qingtongId
			self.spr_goldBox1:setVisible(true)
			self.spr_goldBox2:setVisible(false)
			self.spr_goldBox3:setVisible(false)
			self.btn_wheel1:setEnabled(false)
			self.btn_wheel2:setEnabled(true)
			self.btn_wheel3:setEnabled(true)
			self.txt_clickOnceGold:setString(self:getUnitPrice())
			self.txt_clickOnceGold:setColor(myGold >= tonumber(self:getUnitPrice()) and cc.c3b(255,238,48) or cc.c3b(255,0,0))

		    local function ChangeButtonsInfo1(serialCount, serialButton, hotpriceLabel, serialClickGoldCountLabel)
			    local nowCost = tonumber(self:getUnitPrice()) * (serialCount)
				if self.normalFree >=1 then
					self.txt_clickOnce:setString(getLang("164536"))
					self.txt_clickOnce:setPositionY(self.m_clickBtn_Once:getPositionY())
					self.node_btnOnceContent:setVisible(false)
				else
					self.txt_clickOnce:setString(getLang("140457"))
					self.txt_clickOnce:setPositionY(self.m_clickBtn_Once:getPositionY() + 15)
					self.node_btnOnceContent:setVisible(true)
					nowCost = tonumber(self:getUnitPrice()) * serialCount
				end
				local discountCost = math.floor(nowCost * self.m_disCount)
			    hotpriceLabel:setString(nowCost)
			    serialClickGoldCountLabel:setString(discountCost)
				--enabled
				if self.normalFree >= 1 then	--开1		
					self.m_clickBtn_Once:setEnabled(true)
					self.m_clickBtn_Once.m_useFree = true
				elseif self.normalFree < 1 then 
					self.m_clickBtn_Once:setEnabled(true)
				else
					local f = self:isTicketOpen() and 1 or 0
					self.m_clickBtn_Once:setEnabled(utils.numberToBool(f))
				end
				
				if myGold >= discountCost then --开10,100,500
					serialButton:setEnabled(true)
				else
					local f = self:isTicketOpen() and 1 or 0
					serialButton:setEnabled(utils.numberToBool(f))
				end
			end
			ChangeButtonsInfo1(self.serialOpen10Count, self.m_clickBtn_serial, self.m_hotpriceLabel1, self.txt_clickTenGold)
			ChangeButtonsInfo1(self.serialOpen100Count, self.m_btn100Open, self.m_hotpriceLabel100, self.txt_click100Gold)
			ChangeButtonsInfo1(self.serialOpen500Count, self.m_btn500Open, self.m_hotpriceLabel500, self.txt_click500Gold)
		end
	end
end

function GoldBoxView:initPanelData()
	-- 初始化盘子上的控件
	self.plateNodeTbl = {}
	self.m_turnCenterNode:setVisible(true)
	self.m_turnBaseNode:setScale(0.85)
	for i = 1, maxPlateNum do
		local plateNode = CCNode:create()
		self.plateNodeTbl[i] = plateNode
		self.m_turnCenterNode:addChild(self.plateNodeTbl[i])
		local bg = CCLoadSprite:createSprite("TreasureBoxItemBg.png")
		plateNode:addChild(bg)
		self.itemBgSize = bg:getContentSize()
		bg:setTag(1)
		local node = CCNode:create()
		plateNode:addChild(node)
		node:setTag(2)
	end

	--读取前台表 
    local xmlData = CCCommonUtilsForLua:getGroupByKey("golden_roulette")
    --dump(xmlData,"GoldBoxView golden_roulette")
    self.m_qingtongId = ""
    self.m_baiyinId = ""
    self.m_huangjinId = ""
    for k,v in pairs(xmlData) do
    	local tempData = {}
    	tempData.gold = v.gold
    	tempData.id = v.id
    	tempData.item = v.item
    	tempData.item_num = v.item_num
    	tempData.minlevel = v.minlevel
    	tempData.notice_item = v.notice_item
    	tempData.important = v.important
    	tempData.rate = v.rate
    	tempData.index = tonumber(v.index)
        self.m_allRewardData[tonumber(v.index)] = tempData
        
        --dump(tempData,"cjy tempData")
		if tonumber(v.index) == 1 then
			self.m_qingtongId = v.id
			if v.limitlevel then
				self.m_limitlevel = tonumber(v.limitlevel)
			end
		elseif tonumber(v.index) == 2 then
			self.m_baiyinId = v.id
			--MyPrint("cjy dd",v.index,v.id,v.gold)
		elseif tonumber(v.index) == 3 then
			self.m_huangjinId = v.id
			self.m_scoreList = v.rewardtype1
			--MyPrint("cjy dd",v.index,v.id,v.gold)
		end
    end
    --dump(self.m_allRewardData,"cjy m_allRewardData")
	
	self.plateNum = maxPlateNum
	self:setPlateRotation(0)
	self.turnRoundDirection = 1
    self.txt_BtnContent1:setString(getLang("140454"))
    self.txt_BtnContent2:setString(getLang("140455"))
    self.txt_BtnContent3:setString(getLang("140456"))
    self.txt_clickOnce:setString(getLang("140457"))
    self.txt_clickTen:setString(getLang("140458"))
    	
    self.m_clickBtn_Once:setEnabled(false)
    self.m_clickBtn_serial:setEnabled(false)
    self.m_btn100Open:setEnabled(false)
    self.m_btn500Open:setEnabled(false)
    self:createParticle(3)
    self.node_speed_particle:setVisible(false)
	local cmd = GoldBoxInfoCmd.create()
	cmd:send()

end

function GoldBoxView:createParticle( idx )
	if idx > 2 then
		local PaticleEff = ParticleController:call("createParticle", "speedBtn")
	    PaticleEff:setPosition(cc.p(0,0));
	    self.node_speed_particle:addChild(PaticleEff)
	-- else
	--     --进度条粒子效果
	--     local particleNode = cc.Node:create()
	--     for i=1,2 do
	-- 		local PaticleEff = ParticleController:call("createParticle", "chest_"..i)
	-- 	    PaticleEff:setPosition(cc.p(0,0));
	-- 	    particleNode:addChild(PaticleEff)
	--     end
	--     if idx == 1 then
	--     	--self.node_progress_particle1:removeAllChildren()
	--     	--self.node_progress_particle1:addChild(particleNode);
	--     else
	--     	--self.node_progress_particle2:removeAllChildren()
	--     	--self.node_progress_particle2:addChild(particleNode);
	--     end
	end
end
function GoldBoxView:setPlateRotation(rotation)
	self.m_turnCenterNode:setRotation(rotation)
	for i = 1, self.plateNum do
		self.plateNodeTbl[i]:setRotation(-rotation)
	end
	angle = rotation
end
function GoldBoxView:updatePlateTurn(dt  )
	self:setPlateRotation(self.m_turnCenterNode:getRotation())
	local maxSpeed = oneCircleRadius * 2
	if self.plateState == PLATE_TURN_STEP_1 then
		if self.m_speed < maxSpeed then
			self.m_speed = self.m_speed + dt * maxSpeed
		else
			self.m_speed = maxSpeed
			self.plateState = PLATE_TURN_STEP_2
			self.turnDelayTime = 0
		end

	elseif self.plateState == PLATE_TURN_STEP_2 then
		if self.turnDelayTime > 1 then
			if self.getResult == true then
				self.plateState = PLATE_TURN_STEP_3
			elseif self.turnDelayTime > 10 then
				-- 超时处理
				self:turnEnded()
				LuaController:flyHint("", "", getLang("E100168"))
			end
		end
		self.turnDelayTime = self.turnDelayTime + dt
	elseif self.plateState == PLATE_TURN_STEP_3 then
		-- 自己计算速度
		local curRotation = self.m_turnCenterNode:getRotation()
		local distance = oneCircleDegree*2 - (curRotation - self.selectPlateAngle)*self.turnRoundDirection
		self.speed_offset = distance/2
		self.m_speed = distance
		self.plateState = PLATE_TURN_STEP_4
	elseif self.plateState == PLATE_TURN_STEP_4 then
		if self.m_speed > moveLimitSpeed then
			self.m_speed = self.m_speed - self.speed_offset * dt
		elseif self.m_speed > 0 then--action
			self.plateState = PLATE_TURN_STEP_END
		-- else
		-- 	self:showPlateResult()
		-- 	return

		end
	elseif self.plateState == PLATE_TURN_STEP_END then--move func
		local rotation = self.m_turnCenterNode:getRotation()
		rotation = rotation + self.m_speed * 3 * dt * self.turnRoundDirection
		if rotation > oneCircleDegree then
			while (rotation > oneCircleDegree) do
				rotation = rotation - oneCircleDegree
			end
		elseif rotation < oneCircleDegree then
			while (rotation < 0) do
				rotation = rotation + oneCircleDegree
			end
		end
		self:setPlateRotation(rotation)

		local deltaMove = self.selectPlateAngle - self.m_turnCenterNode:getRotation()
		if deltaMove < 0 then
			deltaMove = deltaMove + 360
		end
		local rotate = cc.RotateBy:create( math.abs(deltaMove)/moveLimitSpeed, deltaMove)
		local function turnEnded1()
			self:showPlateResult()
		end
		local fun2 = cc.CallFunc:create(turnEnded1)
		local action = cc.Sequence:create(rotate, fun2)
	    self.m_turnCenterNode:runAction(action)
	    self.plateState = PLATE_TURN_STEP_MOVING
	else
		return
	end
	local rotation = self.m_turnCenterNode:getRotation()
	rotation = rotation + self.m_speed * dt * self.turnRoundDirection
	if rotation > oneCircleDegree then
		while (rotation > oneCircleDegree) do
			rotation = rotation - oneCircleDegree
		end
	elseif rotation < oneCircleDegree then
		while (rotation < 0) do
			rotation = rotation + oneCircleDegree
		end
	end
	self:setPlateRotation(rotation)
end

function GoldBoxView:update( dt )
	-- 0停止状态，1提速状态，2等待消息状态，3收尾状态
	if self.plateState > PLATE_TURN_STEP_0 then
		self:updatePlateTurn(dt)
	end

	self.m_updateTime = self.m_updateTime - 1
	if self.m_updateTime < 0 then
		self.m_updateTime = 10
	    self.m_deltTime = atoi(self.m_deltTime) - 1
	    if self.m_deltTime < 0 and self.m_curIndex ~= 3  then
	    	if self.m_curIndex == 1 then
	    		self.normalFree = 1
	    		-- self:changePlateData(1,false)
				self.m_deltTime = tonumber(self.m_normalTime) - tonumber(LuaController:call("getTimeStamp"))
			elseif self.m_curIndex == 2 then
	    		self.silverUsableFree = 1
				self.m_deltTime = tonumber(self.m_silverTime) - tonumber(LuaController:call("getTimeStamp"))
	    		-- self:changePlateData(2,false)
			end
	        self.m_deltTime = 0
	        self.txt_timeCount1:setVisible(false)

	    elseif self.m_curIndex == 3 then
	    	self.txt_timeCount1:setVisible(false)
	    elseif self.m_limitlevel <= tonumber(FunBuildController:call("getMainCityLv")) then
	    	self.txt_timeCount1:setVisible(true)
	    end
	    if self.m_deltTime >= 0 then
	    	self.txt_timeCount1:setString(format_time(self.m_deltTime))
	    end
	end
end
function GoldBoxView:refreshTimeInmidia( )
	if self.m_curIndex ~= 3  then
    	if self.m_curIndex == 1 then
			self.m_deltTime = tonumber(self.m_normalTime) - tonumber(LuaController:call("getTimeStamp"))
		elseif self.m_curIndex == 2 then
			self.m_deltTime = tonumber(self.m_silverTime) - tonumber(LuaController:call("getTimeStamp"))
		end
		if self.m_deltTime >= 0 then
    		self.txt_timeCount1:setString(format_time(self.m_deltTime))
    	end
    elseif self.m_curIndex == 3 then
    	self.txt_timeCount1:setVisible(false)
    end
end
function GoldBoxView:showFinalParticle()
	self.m_finalParticleNode:removeAllChildren(true)
    if nil~= self.m_finalParticleNode then
        for i=1,6 do
            local particle1 = callItSelfCallFunc(LuaController, "createParticleForLua", "particle/Capacity_"..i)
            if nil ~= particle1 then
              	-- particle1:setScale(0.5)
                self.m_finalParticleNode:addChild(particle1)
                particle1:setPosition(CCPoint(0, 0))
            end
        end
    end
end

function GoldBoxView:showRewardTip()
	local array = CCArray:create()
	local arrayRet = CCArray:create()
	if self.m_curResultDatas and #self.m_curResultDatas > 0 then
		--dump(self.m_curResultDatas,"self.m_curResultDatas is")
		local function isImportant(v,allImportants)
			if not v then 
				return false
			end
	    	local bIsImp = false
		 	for j,d in ipairs(allImportants) do
	    		if tonumber(d) == tonumber(v.id) then
	    			bIsImp = true
	    			break
	    		end
	    	end
	    	return bIsImp
		end
		local allImportants = string.split(self.curRewardData.important,";")
		if allImportants and #allImportants >= 1 and #self.m_curResultDatas > 1 then
			-- dump(self.m_curResultDatas, "sort self.m_curResultDatas+++") 
			table.sort( self.m_curResultDatas, 
			function(a,b)
				return isImportant(a,allImportants) and (not isImportant(b,allImportants))
			end )
		end
		for i,v in ipairs(self.m_curResultDatas) do
			local arrdic = CCDictionary:create()
	    	local value = CCDictionary:create()
	        value:setObject(CCString:create(tostring(v.id)), "id")
	        value:setObject(CCString:create(tostring(v.count)), "num")
			value:setObject(CCBool:create(true), "isGoldBox")
	    	for j,d in ipairs(string.split(self.curRewardData.important,";")) do
	    		if tonumber(d) == tonumber(v.id) then
	    			value:setObject(CCBool:create(true), "isImportant")
	    			break
	    		end
	    	end
		    arrdic:setObject(CCString:create("7"), "type")
		    value = tolua.cast(value, "cc.Ref")
		    arrdic:setObject(value, "value")
		    arrdic = tolua.cast(arrdic, "cc.Ref")
		    array:addObject(arrdic)
		    --ret
		    local valueRet = CCDictionary:create()
	        valueRet:setObject(CCString:create(tostring(v.id)), "itemId")
	    	local tinfo = ToolController:call("getToolInfoByIdForLua", tonumber(v.id))
	    	if tinfo then
	    		local uuid = tinfo:getProperty("uuid")
	    		if (uuid == nil or uuid=="") then
	    			uuid = v.uuid
	    			tinfo:setProperty("uuid",uuid)
	    		end
	    		valueRet:setObject(CCString:create(tostring(uuid)), "uuid")
	    		local cnt = tinfo:call("getCNT") + tonumber(v.count)
	    		valueRet:setObject(CCString:create(tostring(cnt)), "count")
	    	end
	        arrayRet:addObject(valueRet)
		end
	    local dic1 = CCDictionary:create()
	    dic1:setObject(array, "1")
	    dic1:setObject(CCBool:create(true), "2")
	    PortActController:comFunc("flyReward",dic1)
	    -- GCMRewardController:call("flyToolReward", goods)
	    local dic1 = CCDictionary:create()
	    dic1:setObject(arrayRet,"goods")
	    GCMRewardController:call("retReward", dic1)
	end
end

function GoldBoxView:showPlateResult()
	for k,v in pairs(self.m_curResultDatas) do
		if tonumber(self.curRewardData.important) == tonumber(v.id) then
			-- SoundController:call("sharedSound"):call("playEffects", "m_city_new")  --cjytest
			break
		end
	end
	self:setPlateRotation(self.selectPlateAngle)

	self:showRewardTip()

	local delay1 = cc.DelayTime:create(2.7)
	local function turnEnded()
		self:turnEnded()
	end
	local fun2 = cc.CallFunc:create(turnEnded)
	local action = cc.Sequence:create(delay1, fun2)
    self.actionNode:runAction(action)
    self.plateState = PLATE_TURN_STEP_0
    waittime = 0
    self.getResult = false
end

function GoldBoxView:turnEnded( )
	self:setPlateRotation(0)
	self.plateState = PLATE_TURN_STEP_0
  	self.btn_rankList:setEnabled(true)
  	self.btn_goldBoxTips:setEnabled(true)
	if self.m_curIndex == 1 then
		self:changePlateData(1,false)
	elseif self.m_curIndex == 2 then
		self:changePlateData(2,false)
	elseif self.m_curIndex == 3 then
		self:changePlateData(3,false)
	end
end
function GoldBoxView:startPanelRun(curWheelId,curWheelNum,skip_ticketBuy,adType)
	if self.plateState == PLATE_TURN_STEP_0 then
		if not adType and self:isTicketOpen() and not skip_ticketBuy then
			local unit_price = tonumber(self:getUnitPrice())
			local total = tonumber( curWheelNum) * unit_price
			if self:getMyTicketCount() < total then
				if self.m_isCheckFlag and self.m_lotteryId then
					local ShopMallController = require("game.shop.ShopMallController")
					ShopMallController.buyShopItem({retGetShopItemInfo=function (  )
					    self:startPanelRun(curWheelId,curWheelNum,true)
				    	end,m_mallId=ShopMallController.getTicketMallId()},self.m_lotteryId,total)
				else
					local shopMallCtrl = require("game.shop.ShopMallController")
					shopMallCtrl.showBuyTicketView(self.m_lotteryType)
					return
				end
			end
		end

		self.getResult = false
	 	-- 方案三，自己计算速度
	  	self.plateState = PLATE_TURN_STEP_1
	  	self.m_speed = 0
	  	self.m_clickBtn_Once:setEnabled(false)
	  	self.m_clickBtn_serial:setEnabled(false)
		self.m_btn100Open:setEnabled(false)
    	self.m_btn500Open:setEnabled(false)

	  	self.btn_rankList:setEnabled(false)
	  	self.btn_goldBoxTips:setEnabled(false)
		self.btn_wheel1:setEnabled(false)
		self.btn_wheel2:setEnabled(false)
		self.btn_wheel3:setEnabled(false)

	  	--MyPrint("cjy curWheelId curWheelNum ",tostring(curWheelId),tonumber(curWheelNum))
		local cmd = GoldBoxUseItemCmd.create(tostring(curWheelId),tonumber(curWheelNum),adType)
		cmd:send()
		return true
	end
end

function GoldBoxView:showParticle(node, name)
	node:removeAllChildren(true)
    for i=1,3 do
        local particle1 = callItSelfCallFunc(LuaController, "createParticleForLua", "particle/"..name..i)
        if nil ~= particle1 then
            node:addChild(particle1)
            particle1:setPosition(CCPoint(0, 0))
        end
    end
end

function GoldBoxView:onCheckTouchAngle(x, y)
	if self.touchDirection == -1 then
		if cc.pDistanceSQ(cc.p(self.touch_x, self.touch_y), cc.p(x,y)) > 900 then
			-- 滑动长度超过30，开始判断方向
			local beganPos = self.m_turnNode:getParent():convertToNodeSpace(cc.p(self.touch_x, self.touch_y))
			local pos = self.m_turnNode:getParent():convertToNodeSpace(cc.p(x,y))
   			local contentSize = self.m_turnNode:getContentSize()
   			local scale = self.m_turnNode:getScale()
   			local halfWidth = contentSize.width * scale * 0.5
   			local halfHeight = contentSize.height * scale * 0.5

   			local offsetX = pos.x - beganPos.x 
			local offsetY = pos.y - beganPos.y
			if math.abs(offsetX) > math.abs(offsetY) then
				self.touchDirection = 1
				-- 横向移动, 根据y值判断方向
				if beganPos.y > halfHeight then
					self.turnRoundDirection = 1
				else
					self.turnRoundDirection = -1
				end
			else
				-- 纵向移动, 根据x值判断方向
				self.touchDirection = 2
				if beganPos.x < halfWidth then
					self.turnRoundDirection = 1
				else
					self.turnRoundDirection = -1
				end
			end
		end
	else
		local offset
		if self.touchDirection == 1 then
			offset = x - self.touch_x
		else
			offset = y - self.touch_y
		end
		local new_angle = (offset * 270 / 640) * self.turnRoundDirection

		angle = self.touch_angle + new_angle
		self:setPlateRotation(angle)
	end
end
function GoldBoxView:changeGoldBoxParticle( curIndex)
		self.m_bigPNode:removeAllChildren(true)
	if curIndex == 1 then 
	    local PaticleEff = ParticleController:call("createParticle", "Upgradegift2_0")--1 紫色 2 蓝色 3金色 4 小
	    PaticleEff:setPosition(cc.p(0,0));
	    self.m_bigPNode:addChild(PaticleEff);
	    local PaticleEff2 = ParticleController:call("createParticle", "Upgradegift2_1")
	    PaticleEff2:setPosition(cc.p(0,0));
	    self.m_bigPNode:addChild(PaticleEff2);
    elseif curIndex == 2 then 
	    local PaticleEff = ParticleController:call("createParticle", "Upgradegift1_0")--1 紫色 2 蓝色 3金色 4 小
	    PaticleEff:setPosition(cc.p(0,0));
	    self.m_bigPNode:addChild(PaticleEff);
	    local PaticleEff2 = ParticleController:call("createParticle", "Upgradegift1_1")
	    PaticleEff2:setPosition(cc.p(0,0));
	    self.m_bigPNode:addChild(PaticleEff2);
    elseif curIndex == 3 then 
	    local PaticleEff = ParticleController:call("createParticle", "Upgradegift3_0")--1 紫色 2 蓝色 3金色 4 小
	    PaticleEff:setPosition(cc.p(0,0));
	    self.m_bigPNode:addChild(PaticleEff);
	    local PaticleEff2 = ParticleController:call("createParticle", "Upgradegift3_1")
	    PaticleEff2:setPosition(cc.p(0,0));
	    self.m_bigPNode:addChild(PaticleEff2);
	    local PaticleEff3 = ParticleController:call("createParticle", "Upgradegift3_2")
	    PaticleEff3:setPosition(cc.p(0,0));
	    self.m_bigPNode:addChild(PaticleEff3);
	end
end
function GoldBoxView:refreshPlateData( ref )
	self.tipMsgInHelpView={}
	local tbl = dictToLuaTable(ref)
	--dump(tbl,"GoldBoxView:refreshPlateData")
	if tbl.k2 and tbl.k1 then
		self.m_GoldLimitNum = tonumber(tbl.k2)
		self.m_GoldHalfNum = tonumber(tbl.k1)
	end
	if self.m_GoldHalfNum and self.m_GoldLimitNum then
		self.tipMsgInHelpView[1] = getLang("140448")..getLang("140452",self.m_GoldHalfNum)..getLang("140449")..getLang("140451")
		self.tipMsgInHelpView[2] = getLang("140448")..getLang("140452",self.m_GoldLimitNum)..getLang("140449")..getLang("140450")

		if self.m_normalTotalIndex and math.floor(tonumber(tbl.normalTotal) / self.m_GoldLimitNum) > self.m_normalTotalIndex then--重复刷新
			self.m_normalTotalIndex = math.floor(tonumber(tbl.normalTotal) / self.m_GoldLimitNum)
			-- self.m_progress:setScaleX(1)
			-- local scale1 = cc.ScaleTo:create(0.5, 1,0.5)
			-- local scale2 = cc.ScaleTo:create(0.5, 0,0.5)
			-- local function callback() self:actionForScaleProgress(tbl.normalTotal) end
			-- local funcall = cc.CallFunc:create(callback)
			-- local seq = cc.Sequence:create(scale1,scale2, funcall)
		 --    self.m_progress:runAction(seq)
		else--首次刷新
			self.m_normalTotalIndex = math.floor(tonumber(tbl.normalTotal) / self.m_GoldLimitNum)
			--self:actionForScaleProgress(tbl.normalTotal)
		end
	end
	
	self.m_score = tonumber(tbl.scores)
	self:reloadScoreList(tbl.rewardFlags)
	self.silverUsable = 0
	self.goldUsable = 0
	self.normalFree = 0
	self.silverUsableFree = 0
	if tbl.silverUsable then
		self.silverUsable = tonumber(tbl.silverUsable)
	end
	if tbl.silverUsableFree then
		self.silverUsableFree = tonumber(tbl.silverUsableFree)
	end
	if tbl.goldUsable then
		self.goldUsable = tonumber(tbl.goldUsable)
	end
	if tbl.normalFree then
		self.normalFree = tonumber(tbl.normalFree)
	end
	
    self.node_btnFlag1:setVisible(false)
    self.node_btnFlag2:setVisible(false)
    self.node_btnFlag3:setVisible(false)

	if tbl.silverUsable and tbl.silverUsableFree and (tonumber(tbl.silverUsable) > 0 or tonumber(tbl.silverUsableFree) > 0 )then
		self.node_btnFlag2:setVisible(true)
		local tempFlag2String = tonumber(tbl.silverUsable) + tonumber(tbl.silverUsableFree)
		if self.txt_BtnFlag2:getString() ~= tostring(tempFlag2String) then
			if self.txt_BtnFlag3:getString() ~= "" and self.m_curIndex == 1 then 
		        self.txt_BtnFlag2:stopAllActions()
	            local moveDown1 = cc.MoveBy:create(0.1, ccp(0, 8))
	            local delay1 = cc.DelayTime:create(0.1)
	            local actionMove = cc.Repeat:create(cc.Sequence:create(moveDown1, moveDown1:reverse(), delay1),4)
				local function callback() self:chanegTips2Num(tempFlag2String) end
				local func = cc.CallFunc:create(callback)
	            local actionSeq = cc.Sequence:create(actionMove, func)
	            self.txt_BtnFlag2:runAction(actionSeq)               
			else
				self:chanegTips2Num(tempFlag2String)
			end
		end
	end
	if tbl.goldUsable and tonumber(tbl.goldUsable) > 0 then
		self.node_btnFlag3:setVisible(true)
		local tempFlag3String = tonumber(tbl.goldUsable) 
		if self.txt_BtnFlag3:getString() ~= tostring(tempFlag3String) then
			if self.txt_BtnFlag3:getString() ~= "" and self.m_curIndex == 1 then
		        self.txt_BtnFlag3:stopAllActions()
	            local moveDown1 = cc.MoveBy:create(0.1, ccp(0, 8))
	            local delay1 = cc.DelayTime:create(0.1)
	            local actionMove = cc.Repeat:create(cc.Sequence:create(moveDown1, moveDown1:reverse(), delay1),4)
				local function callback() self:chanegTips3Num(tempFlag3String) end
				local func = cc.CallFunc:create(callback)
	            local actionSeq = cc.Sequence:create(actionMove, func)
	            self.txt_BtnFlag3:runAction(actionSeq)             
			else
				self:chanegTips3Num(tempFlag3String)
			end
		end
	end
	if tbl.normalFree and tonumber(tbl.normalFree) > 0 then
		self.node_btnFlag1:setVisible(true)
		self.txt_BtnFlag1:setString(tonumber(tbl.normalFree) )
	end

	if tbl.notices then
		noticesList = tbl.notices
		local delay1 = cc.DelayTime:create(2)
		local function showNotices()
			self:showNotices()
		end
		local fun2 = cc.CallFunc:create(showNotices)
		local action = cc.Sequence:create(delay1, fun2)
	    self:runAction(action)	
	end
	self.m_normalTime = 0
	if tbl.normalTime then
		self.m_normalTime = tonumber(tbl.normalTime)
	end
	self.m_silverTime=0
	if tbl.silverTime then
		self.m_silverTime = tonumber(tbl.silverTime)
	end

	if self.m_curIndex == 1 then
		self:changePlateData(1,false)
	elseif self.m_curIndex == 2 then
		self:changePlateData(2,false)
	elseif self.m_curIndex == 3 then
		self:changePlateData(3,false)
	end
end
function  GoldBoxView:chanegTips2Num( num )
	self.txt_BtnFlag2:setString(num)
	--self:createParticle(1)
end
function  GoldBoxView:chanegTips3Num( num )
	self.txt_BtnFlag3:setString(num)
	--self:createParticle(2)
end
-- function GoldBoxView:actionForScaleProgress( normalTotal  )
-- 	if self.m_GoldLimitNum ~= normalTotal then
-- 		local nowScale = (normalTotal % self.m_GoldLimitNum) / self.m_GoldLimitNum
-- 		nowScale = math.max(0,math.min(1,nowScale))
-- 		self.m_progress:runAction(cc.ScaleTo:create(0.5, nowScale,0.5))
-- 	end
-- end
function GoldBoxView:onEnter()
	UIComponent:call("showPopupView", 4)
	--MyPrint("GoldBoxView:onEnter")
	self.m_updateTime = 10
	self.m_entryId = self.actionNode:getScheduler():scheduleScriptFunc(function(dt) self:update(dt) end, 0.1, false)
	local function onGetWheelInfoBack(ref)
		self:refreshPlateData(ref)
	end
    local t = tolua.cast(self, "cc.Node")
	local handler = t:registerHandler(onGetWheelInfoBack)
	CCSafeNotificationCenter:registerScriptObserver(self, handler, "goldbox_get_wheelInfo")

	local function onGetWheelResultBack(ref)
		self:refreshRewardData(ref)
		self:refreshTicketNum()
	end
	local handler1 = t:registerHandler(onGetWheelResultBack)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "goldbox_get_wheelResult")

	self = tolua.cast(self, "PopupBaseView")
	self:setTitleName(getLang("140445"))
	--MyPrint("GoldBoxView:onEnter registerScriptObserver")

	cc.UserDefault:getInstance():setStringForKey("ACTIVITY_GOLDBOX", "1")

	registerScriptObserver(self, self.getRewardDataInfo, MSG_GET_REWARD_DETAIL_BACK)
	registerScriptObserver(self, self.getScoreReward, GetScoreRewardNotify)

	local shopMallCtrl = require("game.shop.ShopMallController")
	shopMallCtrl.getAfterBuyTicketEvent():add(self.afterBuyTicket,self)

	registerScriptObserver(self, self.refresh, 'msg.getAdReward.refresh')
	registerScriptObserver(self, self.refresh, "LuaAdController:adsFinishPreload")
end

function GoldBoxView:onExit()
	cc.UserDefault:getInstance():setBoolForKey("GOLDBOX_ISQUICK", false)
	if self.m_entryId ~= nil then
		self.actionNode:getScheduler():unscheduleScriptEntry(self.m_entryId)
		self.m_entryId = nil
	end
	CCSafeNotificationCenter:unregisterScriptObserver(self, "goldbox_get_wheelInfo")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "goldbox_get_wheelResult")
	cc.UserDefault:getInstance():setStringForKey("ACTIVITY_GOLDBOX", "0")
	unregisterScriptObserver(self, MSG_GET_REWARD_DETAIL_BACK)
	unregisterScriptObserver(self, GetScoreRewardNotify)

	local shopMallCtrl = require("game.shop.ShopMallController")
	shopMallCtrl.getAfterBuyTicketEvent():remove(self.afterBuyTicket,self)

	unregisterScriptObserver(self, 'msg.getAdReward.refresh')
	unregisterScriptObserver(self, "LuaAdController:adsFinishPreload")
	if self.m_adSchedule then
		self:getScheduler():unscheduleScriptEntry(self.m_adSchedule)
	end
end

function GoldBoxView:afterBuyTicket(  )
	self:refreshTicketNum()
end

function GoldBoxView:onTouchBegan(x, y)
	-- touchType 1 为跳过按钮, 2圆盘滑动, -1 为无效操作, 3,点击物品进行显示
	self.touchType = 0
	-- self.touchPos = cc.p(x,y)
	self.touch_x = x
	self.touch_y = y
	self.touchDirection = -1  	-- 拖动方向值， 1横向， 2纵向
	if self.plateState ~= PLATE_TURN_STEP_0  and touchInside(self.m_clickBtn_Quick, x, y) then
		self.touchType = 1
		return true
	elseif touchInside(self.m_turnNode, x, y) then
		if self.plateState > 0 then
			return false
		end

		for i = 1, maxPlateNum do
			local plateNode = self.plateNodeTbl[i]:getChildByTag(1)
			if touchInside(plateNode, x, y) then
				self.touchType = 3
				local descNode = self.descNode
				descNode:setVisible(true)
				local size = self.nodeccb:getContentSize()
				descNode:setPosition(self.descNodeHightPos)
				local data = clone(self.curRewardItemData[i])
				local name = CCCommonUtilsForLua:getPropById(tostring(data), "name")
				local content = CCCommonUtilsForLua:getPropById(tostring(data), "description")
				callItSelfCallFunc(self.descNode, "setItemNameAndContent", getLang(name), getLang(content))

				self.touch_began = os.time()
				self.touch_angle = angle
				return true
			end
		end

		self.turnRoundDirection = 1   -- 转动方向
		self.touchType = 2
		self.touch_began = os.time()
		self.touch_angle = angle
	end
	return true
end

function GoldBoxView:onTouchMoved(x, y)
	if self.touchType == 1 then
		
	elseif self.touchType == 2 then
		self:onCheckTouchAngle(x, y)
	elseif self.touchType == 3 then
		if cc.pGetDistance(cc.p(self.touch_x, self.touch_y), cc.p(x,y)) > 20 then
			self.touchType = 2
			local descNode = self.descNode
			descNode:setVisible(false)
		end
	end
end

function GoldBoxView:onTouchEnded(x, y)
	if self.touchType == 1 then
		if cc.pGetDistance(cc.p(self.touch_x, self.touch_y), cc.p(x,y)) <= 30 then
			self:onClickBtn_Quick()
		end
	elseif self.touchType == 2 then
		if self.touchDirection <= 0 then
			return
		end
		if (os.time() - self.touch_began) >= 1 then
			return
		end

		local offset
		if self.touchDirection == 1 then
			offset = x - self.touch_x
		else
			offset = y - self.touch_y
		end
		if math.abs(offset) >= 250 then
			if offset < 0 then
				self.turnRoundDirection = 0 - self.turnRoundDirection
			end
			-- self:startPanelRun(self.m_curWheelId,1)
		end

	elseif self.touchType == 3 or self.touchType == 4 then
		local descNode = self.descNode
		descNode:setVisible(false)
	end
end

function GoldBoxView:onClickBtn_Once( pSender )
	local mlv = FunBuildController:call("getMainCityLv")
	if self.m_limitlevel <= tonumber(mlv) then
		self:startPanelRun(self.m_curWheelId,1,pSender.m_useFree)
	else
		LuaController:flyHint("", "", getLang("103954",self.m_limitlevel))
	end

end

function GoldBoxView:onClickBtn_Serial(  )
	self:runSerialOpen(self.serialOpen10Count)
end

function GoldBoxView:onClickCehckBox( pSender )
	local preve_check = not not self.m_isCheckFlag
	self:setCheckBox(not preve_check)
end

function  GoldBoxView:runSerialOpen( count )
	local mlv = FunBuildController:call("getMainCityLv")
	if self.m_limitlevel <= tonumber(mlv) then
		self:startPanelRun(self.m_curWheelId, count)
	else
		LuaController:flyHint("", "", getLang("103954",self.m_limitlevel))
	end
end

function GoldBoxView:onClickRankList(  )
	local isQuick = cc.UserDefault:getInstance():getBoolForKey("GOLDBOX_ISQUICK", false)
	local mlv = FunBuildController:call("getMainCityLv")
	if self.m_limitlevel <= tonumber(mlv) then
		local lua_path = "game.CommonPopup.GoldBoxRankView"
		package.loaded[lua_path] = nil
		require(lua_path)
		PopupViewController:addPopupInView(GoldBoxRankView:create(self.m_activityId))
		if isQuick then 
			cc.UserDefault:getInstance():setBoolForKey("GOLDBOX_ISQUICK", true)
		end
	else
		LuaController:flyHint("", "", getLang("103954",self.m_limitlevel))
	end

end

function GoldBoxView:onClickQuick(  )
	if self.node_speed_particle:isVisible() then
		self.node_speed_particle:setVisible(false)
		cc.UserDefault:getInstance():setBoolForKey("GOLDBOX_ISQUICK", false)
	else
		self.node_speed_particle:setVisible(true)
		cc.UserDefault:getInstance():setBoolForKey("GOLDBOX_ISQUICK", true)
	end
	-- print("cjy nowquick is " ,( self.node_speed_particle:isVisible()))
	if self.getResult then
		self.m_turnCenterNode:stopAllActions()
		self:showPlateResult()
	end
end
function GoldBoxView:onClickWheel1( )
	self:changePlateData(1,true)
end
function GoldBoxView:onClickWheel2(  )
	self:changePlateData(2,true)
	
end
function GoldBoxView:onClickWheel3(  )
	self:changePlateData(3,true)
	
end
function GoldBoxView:onTipClick(  )
	local lua_path = "game.CommonPopup.GoldBoxTipsView"
    package.loaded[lua_path] = nil
    local view = require(lua_path):create(self.tipMsgInHelpView)
    PopupViewController:addPopupView(view)
end

function GoldBoxView:onSerial500Open( )
	self:doSerialOpen(self.serialOpen500Count)
end

function GoldBoxView:onSerial100Open( )
	self:doSerialOpen(self.serialOpen100Count)
end

function GoldBoxView:doSerialOpen( serialCount )
	dump(serialCount, "GoldBoxView:doSerialOpen+++")
	if serialCount == nil or serialCount < 1 then 
		return 
	end

	local function confirmFunc()
		if serialCount == self.serialOpen100Count then 
			g_SerialOpenGoldBox100IsClicked = true
		elseif serialCount == self.serialOpen500Count then
			g_SerialOpenGoldBox500IsClicked = true
		else
			return
		end
		self:runSerialOpen(serialCount)
	end

	local needAck = false
	if (serialCount == self.serialOpen100Count) and (not g_SerialOpenGoldBox100IsClicked) then 
		needAck = true
	elseif (serialCount == self.serialOpen500Count) and (not g_SerialOpenGoldBox500IsClicked) then 
		needAck = true
	end

	if needAck then 
		local tipInfo = getLang("176079", serialCount) --176079=确定开启{0}次连抽吗？
		local dia = YesNoDialog:show(tipInfo, confirmFunc)
		dia:call("showCancelButton")
	else
		self:runSerialOpen(serialCount)	
	end
end

function GoldBoxView:getTicketId(  )
	local ticketId = self.m_ticketId
	if not ticketId then
		ticketId = tonumber(CCCommonUtilsForLua:getPropById("89602", "ticket_id")) or 36000862
		self.m_ticketId = ticketId
	end
	return ticketId
end

function GoldBoxView:getUnitPrice( )
	if not self:isTicketOpen() then
		return self.curRewardData.gold
	end
	local index_to_price = self.m_index_to_price
	if not index_to_price then
		index_to_price = {
			tonumber(CCCommonUtilsForLua:getPropById("89600", "ticket_num")) or 1,
			tonumber(CCCommonUtilsForLua:getPropById("89601", "ticket_num")) or 5,
			tonumber(CCCommonUtilsForLua:getPropById("89602", "ticket_num")) or 50
		}
		self.m_index_to_price = index_to_price
	end

	return tostring(index_to_price[self.m_curIndex or 1])
end

function GoldBoxView:resetTicketIcon(  )
	if not self:isTicketOpen() then
		return
	end
	local r = {
		self.m_curr1,
		self.m_curr2,
		self.m_curr3,
		self.m_curr4,
		self.m_curr5
	}
	local itemId = self:getTicketId()
	for i,v in ipairs(r) do
		v:setScale(0.5)
		utils.resetItemIcon(v,itemId)
	end
end

function GoldBoxView:refreshTicketNum(  )
	if not self:isTicketOpen() then
		return
	end
	local myGold = self:getMyTicketCount()
    self.m_ticketCount:setString(CC_CMDITOA(myGold))
end

function GoldBoxView:initCheckBox(  )
	if self.m_finishShareNode then
		self.m_finishShareNode:setVisible(false)
		if self:isTicketOpen() then
			local check_s = utils.accessLocal(self.m_localCheckKey,nil,'0')
			local be_check = check_s == '1'
			self:setCheckBox(be_check)

			self.m_shareLab:setString(getLang("176939"))
		end
	end
end

function GoldBoxView:setCheckBox( isCheck )
	if self.m_isCheckFlag == isCheck then
		return
	end

	self.m_isCheckFlag = isCheck
	self.m_checkBox:setVisible(self.m_isCheckFlag)
	utils.accessLocal(self.m_localCheckKey,self.m_isCheckFlag and '1' or '0')
end

function GoldBoxView:getMyTicketCount(  )
	local _,myGold = utils.getItemNameByItemId(self:getTicketId())
    myGold = myGold and myGold:call("getCNT") or 0
    return myGold
end

function GoldBoxView:isTicketOpen(  )
	local shopMallCtrl = require("game.shop.ShopMallController")
	return shopMallCtrl.isTicketOpen()
end

return GoldBoxView







