local AuctionHouseNodeIcon = class("AuctionHouseNodeIcon", cc.Node)

function AuctionHouseNodeIcon.create(nodeSize, contentSize)
    -- 创建页面
    local view = AuctionHouseNodeIcon.new() -- 新建一个实例
    if view:initView(nodeSize, contentSize) then
        -- 设置view的尺寸属性
        return view
    end

    return false
end

function AuctionHouseNodeIcon:initView(nodeSize, contentSize)
    -- view初始化函数
    self:setContentSize(nodeSize)
    self:setVisible(false)  -- 初始不显示页面

    -- 显示图片
    local bg = CCLoadSprite:createSprite("AuctionHouse.png")
    bg:setPosition(nodeSize.width * 0.5, nodeSize.height * 0.5)
    bg:setScale(1.2)
    self:addChild(bg)
    self.isShow = false -- 变量，收到推送后设置为true，切会内城后如果为true则显示图标，并重置为false
    return true
end

function AuctionHouseNodeIcon:touchEvent() -- 点击图标
    local function fun() -- 点击前往后的方法
        AuctionHouseController:pullAuctionHouseViewData() -- 跳转界面
    end
    YesNoDialog:call("show", getLang("9440923"), cc.CallFunc:create(fun))
end

function AuctionHouseNodeIcon:onEnter()
    dump("cyt ------ onEnter")
    registerScriptObserver(self, self.onPriceReplace, AuctionPriceReplace)
    registerScriptObserver(self, self.onExitDataView, AuctionViewOnExit)
end

function AuctionHouseNodeIcon:onPriceReplace() -- 价格被超过
    dump("cyt ------ onPriceReplace")
    local currentSceneId = SceneController:call("getCurrentSceneId")
    if currentSceneId == 1 then
        -- 当前场景是主城，直接显示出图标来
        self:setVisible(true) -- 显示出被超越图标
    end
    self.wait2Show = true -- 设置wait2Show的值为true，等切换回主城后，显示图标
end

function AuctionHouseNodeIcon:onExitDataView() -- 退出拍卖行界面
    self.wait2Show = false;
    self:setVisible(false) -- 隐藏icon
end

function AuctionHouseNodeIcon:onExit()
    dump("cyt ------ onExit")
    unregisterScriptObserver(self, AuctionPriceReplace)
    unregisterScriptObserver(self, AuctionViewOnExit)
end

function AuctionHouseNodeIcon:onSceneChanged(sceneId)
    dump("cyt ------ onSceneChanged")
    if sceneId == 1 then
        -- 场景切换为主城，如果wait2Show为true，显示图标，不然不显示图标
        self:setVisible(self.wait2Show)
    else
        self:setVisible(false)
    end
end

return AuctionHouseNodeIcon