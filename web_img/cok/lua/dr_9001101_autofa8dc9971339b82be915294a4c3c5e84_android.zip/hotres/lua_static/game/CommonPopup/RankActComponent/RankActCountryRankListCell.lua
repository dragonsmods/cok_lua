--服务器排名信息
local RankActCountryRankListCell = class("RankActCountryRankListCell",
    function ()
        return cc.Layer:create()
    end)

RankActCountryRankListCell.__index = RankActCountryRankListCell
local cellHeight = 92
--奖励配置
local actIdToXML = {
	['57370'] = "consume_soldier_rank|20902000;20902001" --"20902000"个人本服排名奖励   "20902001"--个人全服排名奖励
}

--title配置
local actIdToTitle = {
	['57370'] = "182181;182183;182185"
}

function RankActCountryRankListCell:create(viewSize)
    local view = RankActCountryRankListCell.new()
    Drequire("game.CommonPopup.RankActComponent.RankActCountryRankListCell_ui"):create(view,0,viewSize)
    if view:initView() then
        return view
    end
end

function RankActCountryRankListCell:initView()
	CCLoadSprite:call("loadDynamicResourceByName", "AllServerRank_face")
	CCLoadSprite:call("doResourceByCommonIndex", 208, true)
	CCLoadSprite:call("doResourceByCommonIndex", 10, true)
    local function TouchEvent(eventType,x,y)
        if eventType == "began" then  
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)  
        else  
            return self:onTouchEnded(x, y)  
        end
    end
    self.ui.m_touchLayer:setTouchEnabled(true)
    self.ui.m_touchLayer:registerScriptTouchHandler(TouchEvent)
    self.ui.m_touchLayer:setSwallowsTouches(true)
    self.m_idx = -1
    self.m_countryPageIndex = 0 --服务器排行页
    self.m_countryMaxRank = 0 -- 当前最大的排名
    self.m_leftTime = 0
	self.ctl = require("game.CommonPopup.RankActComponent.RankActDataController").getInstance()
	self.actId = self.ctl.actId
    self:reqData()
    self.ui.m_tPowerLabel:setString(getLang("133114"))--积分
    self.ui.m_tServerLabel:setString(getLang("138108")) --奖励
    return true
end

function RankActCountryRankListCell:reqData()
	--override me!!!
	local params = CCDictionary:create()
    --type: 0 服务器排行  1:本服玩家排行  2:全服玩家排行
    params:setObject(CCString:create("0"),"type")
    params:setObject(CCInteger:create(0),"pageOn")
    CCSafeNotificationCenter:postNotification("msg.CommonRankAct.getRankInfo",params)
end

function RankActCountryRankListCell:onEnter()
    registerScriptObserver(self,self.getCountryRankData,"msg.RankActCountryRankListCell.getServerRank")
    registerScriptObserver(self,self.rankDataFail,"RankActCountryRankListCell.rankDataFail")
    local function onGetRewardDetailBack(ref)
		local rewardId = ""
		if ref then rewardId = ref:getCString() end
		if self.m_requestingRewardIdTab and #self.m_requestingRewardIdTab > 0 then
			for i = 1, #self.m_requestingRewardIdTab do
				if rewardId == self.m_requestingRewardIdTab[i] then
					table.remove(self.m_requestingRewardIdTab, i)
					break
				end
			end
			if #self.m_requestingRewardIdTab == 0 then
				GameController:call("removeWaitInterface")
				self:getRewardDataAndOpenView()
			end
		end
	end
	local handler = self:registerHandler(onGetRewardDetailBack)
	CCSafeNotificationCenter:registerScriptObserver(self, handler, "MSG_GET_REWARD_DETAIL_BACK")
	self:onEnterFrame(0)
	if self.entry then
		self:getScheduler():unscheduleScriptEntry(self.entry)
	end
	self.entry = tonumber(self:getScheduler():scheduleScriptFunc(function(dt)
		self:onEnterFrame(dt)
	end, 1, false))	
	registerScriptObserver(self,self.closeSelf,"msg.RankActCountryRankListCell.close")
end

function RankActCountryRankListCell:onExit()
    unregisterScriptObserver(self,"msg.RankActCountryRankListCell.getServerRank")  
    unregisterScriptObserver(self,"RankActCountryRankListCell.rankDataFail")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "MSG_GET_REWARD_DETAIL_BACK")  
	self:getScheduler():unscheduleScriptEntry(self.entry)
	unregisterScriptObserver(self,"msg.RankActCountryRankListCell.close") 
end

function RankActCountryRankListCell:closeSelf()
	self:removeFromParent()
end

function RankActCountryRankListCell:updateUI()
    if self.m_leftTime > 0 then
		self.ui.m_timeLabel:setString(getLang("182043", CC_SECTOA(self.m_leftTime)))	--182043={0}后发放奖励
	else
		self.ui.m_timeLabel:setString("")
	end
end

function RankActCountryRankListCell:onEnterFrame(dt)	
	if self.m_leftTime > 0 then
		self.m_leftTime = self.m_leftTime - dt
		self:updateUI()
	end
end

--服务器排行数据刷新
function RankActCountryRankListCell:getCountryRankData(dict)
    local tbl = self.ctl:getDataBykey("allServerRankData").countryRankData or {}
    -- dump(tbl,"hxq RankActCountryRankListCell countryData is ")
    self.countryData = tbl
    if tbl.endTime then
		local leftTime = (tbl.endTime / 1000) - LuaController:call("getWorldTime")
		if leftTime > 0 then
			self.m_leftTime = leftTime
		end
	end
    self:updateUI()

    local rankData = tbl.rank or {}
    local rankMap = {}
    if #rankData == 0 then
        LuaController:flyHint("", "", getLang("138130")) -- 138130=暂无记录
    else
        rankMap = tbl.rank
    end
    -- 计算我的排名
	local myRankMap = nil
	self.myServerRank = 0

	local myRankIndex = 0
	if tbl.myRank then
		myRankMap = tbl.myRank
		self.myServerRank = tonumber(myRankMap.rank)
		for i, v in ipairs(rankMap) do
			if v.uid == myRankMap.uid then
				myRankIndex = i
				break
			end
		end
	end

	if self.m_countryPageIndex == 0 then
		-- 初始化界面
		if not myRankMap or (1 <= myRankIndex and myRankIndex <= 3) then
			self:initTableViewByOwner(true)

		else
			self:initTableViewByOwner(false)

			local myRankNode = Drequire("game.CommonPopup.RankActComponent.RankActCountryRankTblCell"):create()
			self.ui.m_myCountryRankNode:addChild(myRankNode)
			myRankMap.callback = function(x) self:onRewardButtonClick(1,tonumber(x)) end
			myRankMap.dataType = 0 -- 排名数据
			myRankMap.showSearch = true
			myRankMap.searchCallback = function(x) self:searchRankInfo(tonumber(x)) end
			myRankNode:refreshCell(myRankMap)

		end

		-- 前三名初始化
		local len = 3
		if #rankMap < 3 then
			len = #rankMap
		end

		for i = 1, 3 do
			self.ui["m_countryName" .. i]:setString("")
			self.ui["m_countryPower" .. i]:setString("")
			self.ui["m_countryKing"..i]:setString("")
			self.ui["m_bannerNode"..i]:removeAllChildren()
		end    
		self._frontData1 = {}
		for i = 1, len do
            table.insert(self._frontData1, rankMap[i])
            local uid = tonumber(rankMap[i].uid) or 0
            local name = rankMap[i].name
            local str = name
            local banner = rankMap[i].banner
            local king = rankMap[i].king
            self.ui["m_countryKing"..i]:setString(king)
            self.ui["m_countryName" .. i]:setString(str)
			local _score = tonumber(rankMap[i].val) or 0
            self.ui["m_countryPower" .. i]:setString(CC_CMDITOAL(rankMap[i].val))
                    
            local index = uid%6 + 1
            local picFrame = "server_"..index..".png"
            local sf = CCLoadSprite:call("getSF", picFrame)
            if sf then
                self.ui["m_countrySpr"..i]:setSpriteFrame(sf)
			end
			local banner = rankMap[i].banner
			--大陆地区，看到台湾的，都成了大陆的国旗
			if banner == "TW" and CCCommonUtilsForLua:call("checkTaiWanFlag") then
				banner = "CN"
			elseif banner == "HK" then
				banner = CCCommonUtilsForLua:call("changeHKToChinaFlag",banner)
			end
			banner = CCCommonUtilsForLua:call("changeChinaFlag",banner)
			banner = banner..".png"
			local sf = CCLoadSprite:call("getSF", banner)
			if sf then
				local spr = CCFlagWaveSprite:call("create",sf)
				if spr then
					local polo = CCLoadSprite:createSprite("flag_banner.png")
					-- polo:setScale(3)
					polo:setPosition(ccp(-17,15))
					self.ui["m_bannerNode"..i]:addChild(polo)
					tolua.cast(spr, "cc.Sprite")
					spr:setScale(0.35)
					spr:setPositionY(30)
					self.ui["m_bannerNode"..i]:addChild(spr)
				end
			end
		end

		for i = 1, len do
			table.remove(rankMap, 1)
		end
	else
		table.remove(rankMap, myRankIndex)
	end

	self.m_countryRankMap = self.m_countryRankMap or {}
	local flag = 1
	if #self.m_countryRankMap >= 1 then
		table.remove(self.m_countryRankMap, #self.m_countryRankMap)
		flag = 0
	end

	if #rankMap > 0 then
		-- 为 cell 添加查看奖品的回调
		for i = 1, #rankMap do
			rankMap[i].callback = function(x) self:onRewardButtonClick(1,tonumber(x)) end
			rankMap[i].dataType = 0 -- 排名数据
			self.m_countryRankMap[#self.m_countryRankMap + 1] = rankMap[i]
		end
		self.m_countryRankMap[#self.m_countryRankMap + 1] = {dataType = 1, getMoreRank = function()
			self:getRankData()
		end} -- 获取更多
	else
		self.m_countryRankMap[#self.m_countryRankMap + 1] = {dataType = 2} -- 没有更多数据
		if self.m_isSearching then
			self.m_searchingRank = self.m_countryMaxRank
		end
	end

	local offset = self.ui.m_countryRankTbl:getContentOffset()
	self.ui:setTableViewDataSource("m_countryRankTbl", self.m_countryRankMap)
	offset.y = offset.y - cellHeight * (#rankMap + flag)
	self.ui.m_countryRankTbl:setContentOffset(offset)

	-- 增加页数
	self.m_countryPageIndex = self.m_countryPageIndex + 1

	self.m_countryMaxRank = #self.m_countryRankMap + 3 - 1
	if self.m_isSearching then
		if self.m_searchingRank <= self.m_countryMaxRank then
			GameController:call("getInstance"):call("removeWaitInterface")
			self.m_isSearching = false
			self:jumpToSearchingRank(self.m_searchingRank)
		else
			self:getRankData()
		end
	else
		GameController:call("getInstance"):call("removeWaitInterface")
	end

end

function RankActCountryRankListCell:onTouchBegan( x,y )
    if self:isVisible(true) and isTouchInside(self.ui.m_touchLayer,x,y) then
        return true
    end
end

function RankActCountryRankListCell:onTouchMoved(x,y)
end

function RankActCountryRankListCell:onTouchEnded( x,y )  
end



function RankActCountryRankListCell:initTableViewByOwner(flag)
	local listSize = self.ui.m_listNode:getContentSize()
	if flag then
		listSize.height = listSize.height + cellHeight
	end
    self.ui.m_countryRankTbl:setContentSize(listSize)   
    Drequire("Editor.TableViewSmoker"):createView(self.ui, "m_countryRankTbl", "game.CommonPopup.RankActComponent.RankActCountryRankTblCell", 1, 10, "RankActCountryRankTblCell")  
end


function RankActCountryRankListCell:onRewardButtonClick(type,idx)    
    self.m_idx = idx
	self:getRewardDataWithCheck()
end

-- 获取奖励数据（没有时向服务器请求）
function RankActCountryRankListCell:getRewardDataWithCheck()
	self:checkRewardData()

	if #self.m_requestingRewardIdTab == 0 then
		self:getRewardDataAndOpenView()
	else
        GameController:call("getInstance"):call("showWaitInterface")
        GlobalData:call("shared"):call("requestMultiRewardData", self.m_requestingRewardIdTab)
		-- for i = 1, #self.m_requestingRewardIdTab do
		-- 	GlobalData:call("requestRewardData", self.m_requestingRewardIdTab[i])
		-- end
	end
end

-- 检查奖励数据
function RankActCountryRankListCell:checkRewardData()
	self:parseRewardId()
    self.m_requestingRewardIdTab = {}
    for i = 1, #self.m_rewardIdTab.country do
        local rwdId = self.m_rewardIdTab.country[i].rewardId
		local rwd = GlobalData:call("getCachedRewardData", rwdId)
		local rwdData = arrayToLuaTable(rwd)
		dump(rwdData,"hxq rwdData is ")
		if #rwdData == 0 then			
			self.m_requestingRewardIdTab[#self.m_requestingRewardIdTab + 1] = rwdId
		end
    end
end

-- 解析奖励
function RankActCountryRankListCell:parseRewardId()
	if not self.m_rewardIdTab then
        self.m_rewardIdTab = {}
        self.m_rewardIdTab.country = {}
		local equipRewardId = ""		
		local xmlName
		local xmlInfo = string.split(actIdToXML[self.actId],"|") or {}		
		if xmlInfo[1] ~= "" then
			xmlName = xmlInfo[1]
			local rwdIds = string.split(xmlInfo[2],";") or {}
			equipRewardId = rwdIds[3] or "20902002" --"20902001"--个人全服排名奖励		
		else
			xmlName = "consume_soldier_rank"
			equipRewardId = "20902002"
		end

        local function getRwdInfo(xmlID)
            local res = {}
            local rwdTbl = {}
            local reward = CCCommonUtilsForLua:call("getPropByIdGroup", xmlName, xmlID, "reward")
            rwdTbl = string.split(reward, "|")
            for i = 1, #rwdTbl do
                local rwdItem = string.split(rwdTbl[i], ";")
                if #rwdItem >= 2 then
                    local rwdIdx = string.split(rwdItem[1], "-")
                    if #rwdIdx >= 2 then
                        res[#res+1] = {left = tonumber(rwdIdx[1]), right = tonumber(rwdIdx[2]), rewardId = rwdItem[2]}
                    elseif #rwdIdx >= 1 then
                        res[#res+1] = {left = tonumber(rwdIdx[1]), right = tonumber(rwdIdx[1]), rewardId = rwdItem[2]}
                    end
                end
            end
            return res
        end
        local countryData = getRwdInfo(equipRewardId)
        self.m_rewardIdTab.country = countryData		        
	end
end

-- 获取奖励数据并打开奖励界面
function RankActCountryRankListCell:getRewardDataAndOpenView()
	local myRank = self.myRank or 0
	local idx = self.m_idx or 1
	local found = false
	local index = 0
    local rewardTab = {}
    local rwdDataTbl = {}
	rwdDataTbl = self.m_rewardIdTab.country
	if myRank > 0 then
		for i = 1, #(rwdDataTbl or {}) do
			local left = rwdDataTbl[i].left
			local right = rwdDataTbl[i].right
			if left <= myRank and myRank <= right then
				if idx == myRank then
					found = true
					index = #rewardTab
				end

				local titleStr = getLang("221120") .. " (" .. getLang("170008") .. ": " .. myRank .. ")"
				rewardTab[#rewardTab + 1] = {type = 1000, label = titleStr}
				local rwd = GlobalData:call("getCachedRewardData", rwdDataTbl[i].rewardId)
				local rwdData = arrayToLuaTable(rwd)
				for _, v in pairs(rwdData) do
					rewardTab[#rewardTab + 1] = v
				end
				break
			end
		end
	end
	for i = 1, #(rwdDataTbl or {}) do
		local left = rwdDataTbl[i].left
		local right = rwdDataTbl[i].right
		if not found then
			if left <= idx and idx <= right then
				found = true
				index = #rewardTab
			end
		end

		local titleStr = ""
		if left ~= right then
			titleStr = getLang("221119", tostring(left), tostring(right))
		else
			titleStr = getLang("221121", tostring(left))
		end
		rewardTab[#rewardTab + 1] = {type = 1000, label = titleStr}
		local rwd = GlobalData:call("getCachedRewardData", rwdDataTbl[i].rewardId)
		local rwdData = arrayToLuaTable(rwd)
		for _, v in pairs(rwdData) do
			rewardTab[#rewardTab + 1] = v
		end
	end

	local titleInfo = string.split(actIdToTitle[self.actId],";")	
	local dialogId = titleInfo[3] or "140459"
	local titleName = getLang(dialogId) 		--140459=全服

	local view = Drequire("game.equipment.EquipRank.EquipmentRewardView"):create(rewardTab, index, titleName)
	PopupViewController:call("addPopupView", view)
end

--TODO
function RankActCountryRankListCell:onSearchButtonClick( )
	function callback(index)
		self:searchRankInfo(tonumber(index))
	end
	local view = Drequire("game.CommonPopup.CommonInputView"):create(getLang("221129"), callback)
	PopupViewController:call("addPopupView", view)
end

function RankActCountryRankListCell:searchRankInfo(idx)
	local maxRank = 500	
	if idx <= 3 then
		idx = 3 + 1
	elseif idx > maxRank then
		idx = maxRank
    end
    local maxIndex
	maxIndex = self.m_countryMaxRank
	if idx <= maxIndex then
		self:jumpToSearchingRank(idx)
	else
		self.m_isSearching = true
		self.m_searchingRank = idx
		self:getRankData()
	end
end
function RankActCountryRankListCell:rankDataFail(params)
	if self.m_isSearching then
        self.m_isSearching = false
        self:jumpToSearchingRank(self.m_countryMaxRank)
	end
end

--请求页面信息
function RankActCountryRankListCell:getRankData()
	Dprint("RankActCountryRankListCell:getRankData pageIndex = ", self.m_pageIndex)   
    local params = CCDictionary:create()
    --type: 0 服务器排行  1:本服玩家排行  2:全服玩家排行
    params:setObject(CCString:create("0"),"type")
	params:setObject(CCInteger:create(self.m_countryPageIndex),"pageOn")
	CCSafeNotificationCenter:postNotification("msg.CommonRankAct.getRankInfo",params)
end

function RankActCountryRankListCell:jumpToSearchingRank(idx)
    local minOffsetY = 0
    minOffsetY = self.ui.m_listNode:getContentSize().height - self.ui.m_countryRankTbl:getContentSize().height
	local maxOffsetY = self.ui.m_listNode:getContentSize().height
	local offsetY = minOffsetY + (idx - 3 - 1) * cellHeight
	if offsetY < minOffsetY then
		offsetY = minOffsetY
	elseif offsetY > maxOffsetY then
		offsetY = maxOffsetY
	end
	self.ui.m_countryRankTbl:setContentOffset(cc.p(0, offsetY))	
end

--查看领主信息
function RankActCountryRankListCell:showPlayerInfoByIndex(index)
    -- local uid = ""
    -- local dict = CCDictionary:create()
    -- dict:setObject(CCString:create("GeneralsPopupView"), "name")
    -- dict:setObject(CCString:create(uid), "uid")
    -- LuaController:call("openPopViewInLua", dict)
end
---------------------------监听界面按钮点击--------------------------
--查看奖励1
function RankActCountryRankListCell:onCountryRwdClick1( )
	self:onRewardButtonClick(1,1)
end
--查看奖励2
function RankActCountryRankListCell:onCountryRwdClick2( )
	self:onRewardButtonClick(1,2)
end
--查看奖励3
function RankActCountryRankListCell:onCountryRwdClick3( )
	self:onRewardButtonClick(1,3)
end
---------------------------监听界面按钮点击--------------------------
return RankActCountryRankListCell