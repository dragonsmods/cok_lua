--积分规则列表Cell
local RankActInfoCell = class("RankActInfoCell",
	function() 
		return cc.Layer:create()
	end
)
--积分规则表
local actIdToXML = {
    ["57370"] = "consume_soldier_fen",
    ["57405"] = "monster_hunter_fen",
    ["5740501"] = "monster_hunter_fen",
    ["57434"] = "alliance_banquet_effect",
}

function RankActInfoCell:create(idx)
    local view = RankActInfoCell.new()
    Drequire("game.CommonPopup.RankActComponent.RankActInfoCell_ui"):create(view, 0)
    return view
end

function RankActInfoCell:refreshCell(info, idx)    
    if idx % 2 == 0 then
        self.ui.m_bg:setVisible(false)
    else
        self.ui.m_bg:setVisible(true)
    end
    self.ui.m_titleNode:removeAllChildren()
    self.ui.m_labelName:setString("")
	self.ui.m_labelScore:setString("")
    self.activityId = info.activityId
    
    if info.go and info.gopos then
        self.m_go = info.go
        self.m_gopos = info.gopos
        if info.type == "0" then
            self.ui.m_btnNode:setVisible(false)
            local viewSize = self.ui.m_titleNode:getContentSize()
            local text = "<s " .. info.size .. "><c " .. info.color .. ">" .. getLang(info.des)
            local title = IFHyperlinkText:call("create", text, cc.size(viewSize.width, 0), true)
            title:setPosition(viewSize.width / 2, viewSize.height / 2)
            self.ui.m_titleNode:addChild(title)
        else
            self.ui.m_btnNode:setVisible(true)
            self.ui.m_labelName:setString(getLang(info.des))
        end
    else
        self.ui.m_btnNode:setVisible(false)
        if info.type == "0" then
            self.ui.m_btnNode:setVisible(false)
            local viewSize = self.ui.m_titleNode:getContentSize()
            local text = "<s " .. info.size .. "><c " .. info.color .. ">" .. getLang(info.des)
            local title = IFHyperlinkText:call("create", text, cc.size(viewSize.width, 0), true)
            title:setPosition(viewSize.width / 2, viewSize.height / 2)
            self.ui.m_titleNode:addChild(title)
        elseif info.type == "1" then
            local tbl = CCCommonUtilsForLua:getPropDictByIdGroup(actIdToXML[self.activityId], info.des)
            if tbl.para2 then
                self.ui.m_labelName:setString(getLang(tbl.name, getLang(tbl.para1), tbl.para2))
            else
                self.ui.m_labelName:setString(getLang(tbl.name, getLang(tbl.para1)))
            end
            local scoreStr = ""
            if show == "0" then
                scoreStr = "-" .. tbl.points
            else
                scoreStr = "+" .. tbl.points
            end
            self.ui.m_labelScore:setString(scoreStr)
        elseif info.type == "2" then
            local tbl = CCCommonUtilsForLua:getPropDictByIdGroup(actIdToXML[self.activityId], info.des)
            self.ui.m_labelName:setString(getLang(tbl.dialog, tbl.num))
            local scoreStr = "+"..tbl.value.."%"
            self.ui.m_labelScore:setString(scoreStr)
        end
    end
end

function RankActInfoCell:onClickBtn()
    if self.m_go and self.m_gopos then
        if self.m_go == "time_event_des" then
            local view = Drequire("game.CommonPopup.RankActComponent.RankActDesView").create(self.activityId)
            PopupViewController:addPopupView(view)
        elseif self.m_go == "time_event_info" then
            local view = Drequire("game.CommonPopup.RankActComponent.RankActDetailView").create(self.activityId)
            PopupViewController:addPopupView(view)
        end
    end
end

return RankActInfoCell
