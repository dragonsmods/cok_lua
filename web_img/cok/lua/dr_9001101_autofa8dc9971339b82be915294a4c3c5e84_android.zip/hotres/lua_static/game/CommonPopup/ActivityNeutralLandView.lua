
local Drequire = Drequire
require("game.CommonPopup.ActivityDetailBase")

local ActivityNeutralKingdomView = Drequire("game.NeutralLand.ActivityNeutralKingdomView")

ActivityNeutralLandView = class("ActivityNeutralLandView", ActivityDetailBase, ActivityShowCellViewDelegate)
ActivityNeutralLandCell = class("ActivityNeutralLandCell", ActivityShowCellModel)
-- 状态
ActivityNowState = 
{
    nowStateInit = 0, -- 初始
    nowStatePreFight = 1, -- 刷新争夺
    nowStateFight = 2, -- 争夺
    nowStatePreCarry = 3, -- 刷新采集
    nowStateCarry = 4 -- 采集
}
local stateLablePosY = 0


---------------------------信息 Start ---------------------------
ActivityNeutralKingdomCmd = class("ActivityNeutralKingdomCmd", LuaCommandBase)
function ActivityNeutralKingdomCmd.create()
    local ret = ActivityNeutralKingdomCmd.new()
    ret:initWithName("neutral.worldinfo.list")
    return ret
end

function ActivityNeutralKingdomCmd:handleReceive(dict)
    local flag, params = self:parseMsg(dict)
    Dprint("ActivityNeutralKingdomCmd:handleReceive | parse flag=", flag)
    if (type(flag) == "boolean") then
        return flag
    end
    CCSafeNotificationCenter:postNotification("activity_neutral_kingdome_info",params)
    return true
end
--------------------------- 信息 End ---------------------------


function ActivityNeutralLandView.create( id )
    MyPrint("ActivityNeutralLandView.create")
	local ret = ActivityNeutralLandView.new(id)
	if ret:initSelf() ~= true then
        MyPrint("not true !!!!!")
		ret = nil 
	end
    MyPrint("ActivityNeutralLandView.create end ", ret)
	return ret
end

function ActivityNeutralLandView:ctor( id )
	ActivityDetailBase.ctor(self, id)
    self.m_id = id
end

function ActivityNeutralLandView:initSelf(  )
	MyPrint("ActivityNeutralLandView:initSelf")
	local obj = self:getObj()
	if nil == obj then
		return false
	end
    self:setShowHelpBtn(true)
	local proxy = cc.CCBProxy:create()
    local ccbiUrl = "ccbi/ActivityNeutralLandView.ccbi"
    local node = CCBReaderLoad(ccbiUrl, proxy, self)
    self:addChild(node)
    local function onNodeEvent( event )
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(onNodeEvent)
    --UI
    self.m_cutDownTipLabel:setVisible(false)
    self.m_cutDownLabel:setVisible(false)
    self.txt_stage:setVisible(false)
    self.txt_cutDownLabel:setVisible(false)
    CCCommonUtilsForLua:call("setButtonTitle", self.m_btn, getLang("165273"))
    self.m_playerInfo = GlobalData:call("getPlayerInfo")
    self.m_isCrossServer = false
    self.m_btn:setVisible(false)
    if GlobalData:call("shared"):getProperty("serverType") == ServerType.SERVER_NEUTRAL_LAND then--跨服状态
        CCCommonUtilsForLua:call("setButtonTitle", self.m_btn, getLang("108572"))
        self.m_isCrossServer = true
        self.m_btn:setVisible(true)
    end
    MyPrint("ActivityNeutralLandView:initSelf self.m_isCrossServer is "..tostring(self.m_isCrossServer))
    CCCommonUtilsForLua:call("setButtonTitle", self.btn_kingdom, getLang("165142"))
    CCCommonUtilsForLua:call("setButtonTitle", self.btn_reward, getLang("165143"))
    self.m_nowState = ActivityController:call("getInstance"):getProperty("m_neutralState")--现在阶段
    self.m_nowStateEndTime = ActivityController:call("getInstance"):getProperty("m_neutralStateEndTime")--结束时间
    self.m_neutralCarry = ActivityController:call("getInstance"):getProperty("m_neutralCarry")--我的负重
    self.m_neutralTotalAdd = ActivityController:call("getInstance"):getProperty("m_neutralTotalAdd")--我的负重加成
    self.m_neutralScore = ActivityController:call("getInstance"):getProperty("m_neutralScore")--我的积分
    self.m_neutralRewardsVec = ActivityController:call("getInstance"):getProperty("m_neutralRewardsVec")--展示奖励
    self.m_neutralEnterCD = ActivityController:call("getInstance"):getProperty("m_neutralEnterCD")--进入中立地带的CD  
    self.m_neutralMyRank = ActivityController:call("getInstance"):getProperty("m_neutralMyRank")--我的积分排行 
    self.m_neutralLoadLimit = ActivityController:call("getInstance"):getProperty("m_neutralLoadLimit")--我的负重上限 
    if not self:changeState() then
        return false
    end
    MyPrint("ActivityNeutralLandView:initSelf end")	
    return true
end

function ActivityNeutralLandView:onClickBtn(  )
    MyPrint("onClick clickBtn") 
    -- PopupViewController:call("removeAllPopupView")
    if self.m_isCrossServer then--返回
        -- if SceneController:call("getCurrentSceneId") ~= SCENE_ID_WORLD then
            local serverId = self.m_playerInfo:getProperty("crossFightSrcServerId")
            if serverId ~= -1 then
                -- self.m_playerInfo:setProperty("currentServerId", serverId)
                -- SceneController:call("gotoScene", SCENE_ID_WORLD, false, true, 721201, MapType.NORMAL_MAP)
                local function leave()
                    NeutralLandManager.leaveNeutralLand() 
                end

                YesNoDialog:show(getLang("165271", format_time(NeutralLandManager.m_neutralEnterCD)), leave)
            end
        -- end
    else        
        MyPrint("ServerListPopUpView:open")
        self:onKingdomClick()
    end
end

function ActivityNeutralLandView:onKingdomClick( )
    MyPrint("onClick onKingdomClick") 
    --MM: 转接矿区列表
    local WorldMineListView = Drequire("game.city.WorldMineListView")
    local view = WorldMineListView:create()
    PopupViewController:addPopupView(view)
end
function ActivityNeutralLandView:onRewardClick( )
    MyPrint("onClick onRewardClick") 
    --MM:转接矿区排行榜
    PopupViewController:call("removeLastPopupView")
    local WorldMineRankView = Drequire("game.city.WorldMineRankView")
    local view = WorldMineRankView:create()
    PopupViewController:addPopupInView(view, true)
end
function ActivityNeutralLandView:callHelp(  )
    MyPrint("onClick onHelpBtnClick") 
    LuaController:call("showFAQ","45255")
end
function ActivityNeutralLandView:onTipBtnClick(  )
    local lua_path = "game.CommonPopup.TipsLongPopupView"
    package.loaded[lua_path] = nil
    require(lua_path)
    PopupViewController:addPopupView(TipsLongPopupView:create(getLang("165159"),getLang("165158")))
end

function ActivityNeutralLandView:changeState( )      
    local obj = self:getObj()
    if nil == obj then
        return false
    end
    MyPrint("ActivityNeutralLandView:changeState state is "..tostring(self.m_nowState))
    local contentWords = ""
    local nowtime = LuaController:call("getWorldTime")
    if obj:getProperty("endTime") and nowtime < obj:getProperty("endTime") then
        -- 此时活动进行中
        local stateWords = ""
        self.m_stateText = ""
        self.txt_myCarry:setVisible(false)
        self.txt_kingdomCarry:setVisible(false)
        self.m_tipBtn:setVisible(false)

        self.m_listNode:setVisible(false)
        self.m_jumpNode:setVisible(false)
        self.m_kingdomListNode:setVisible(true)

        if self.m_nowState == ActivityNowState.nowStateInit then--初始化
            stateWords = getLang("133083")
            contentWords = getLang("165148")
            self.m_stateText = getLang("133083")

            self.m_listNode:setVisible(true)
            self.m_jumpNode:setVisible(true)
            self.m_kingdomListNode:setVisible(false)

        elseif self.m_nowState == ActivityNowState.nowStatePreFight then--准备争夺
            stateWords = getLang("165150")
            contentWords = getLang("165148")
            self.m_stateText = getLang("165164",stateWords,getLang("165146"))
        elseif self.m_nowState == ActivityNowState.nowStateFight then--争夺
            stateWords = getLang("165146")
            contentWords = getLang("165148")
            self.m_stateText = getLang("165144",stateWords)
        elseif self.m_nowState == ActivityNowState.nowStatePreCarry then--保护
            stateWords = getLang("165151")
            contentWords = getLang("165149")
            self.m_stateText = getLang("165164",stateWords,getLang("165145"))
        elseif self.m_nowState == ActivityNowState.nowStateCarry then--采集
            stateWords = getLang("165145")
            contentWords = getLang("165149")

            local totalLoad = 0
            local mainCityLv = FunBuildController:call("getMainCityLv")
            mainCityLv = mainCityLv + FunBuildController:call("getMainCityHonorLv")
            local tempData = CCCommonUtilsForLua:getGroupByKey("sp_load")
            for key,value in pairs(tempData) do
                if tonumber(key) % 100 == mainCityLv then
                    totalLoad = value.load
                end
            end
            totalLoad = (100 + self.m_neutralTotalAdd) / 100 * totalLoad
            self.m_stateText = getLang("165144",stateWords)
            self.txt_myCarry:setVisible(true)
            self.txt_myCarry:setString(getLang("165153",CC_ITOA_K(self.m_neutralCarry).."/"..CC_ITOA_K(totalLoad)))
            self.txt_kingdomCarry:setVisible(true)
            self.txt_kingdomCarry:setString(getLang("165154",string.format("%0.1f", self.m_neutralTotalAdd)).."%")
            self.m_tipBtn:setVisible(true)
        end
        if self.m_kingdomListNode:isVisible() then
            --请求数据
            local cmd = ActivityNeutralKingdomCmd:create()
            cmd:send()
        else
            self.m_listNode:setContentSize(cc.size(self.m_listNode:getContentSize().width, 175))        
            local labelwidgt = ActivityScrollLabelwidget.new(contentWords, self.m_listNode:getContentSize(), cc.TEXT_ALIGNMENT_LEFT)
            self.m_listNode:addChild(labelwidgt)

            local view = ActivityShowCellView.new(self)
            view:setTitle(getLang("165444"))
            view:reloadData()
            self.m_jumpNode:addChild(view)
            MyPrint("ActivityNeutralLandView:initSelf__1") 
        end
    else 
        return false
    end

    -- 矿脉优化，适配tableview大小
    self:adaptTableViewContentSize()

    return true
end

function ActivityNeutralLandView:adaptTableViewContentSize()
    if not self.txt_myCarry:isVisible() and not self.txt_kingdomCarry:isVisible() then
        if not self.m_btn:isVisible() then
            self.m_kingdomListNode:setPositionY(self.m_kingdomListNode:getPositionY() - 110)
            self.m_kingdomListNode:setContentSize(cc.size(self.m_kingdomListNode:getContentSize().width, self.m_kingdomListNode:getContentSize().height + 100))
        else
            self.m_kingdomListNode:setPositionY(self.m_kingdomListNode:getPositionY() - 50)
            self.m_kingdomListNode:setContentSize(cc.size(self.m_kingdomListNode:getContentSize().width, self.m_kingdomListNode:getContentSize().height + 40))
        end
    end
end

function ActivityNeutralLandView:refreshView( ref )
    local tbl = dictToLuaTable(ref)
    local size = self.m_kingdomListNode:getContentSize()
    self.m_kingdomListNode:addChild(ActivityNeutralKingdomView:create(tbl, size))
end
-- 使用者必须重载
function ActivityNeutralLandView:cellCount(view)
    return math.max(#self.m_neutralRewardsVec,0)
end

function ActivityNeutralLandView:createCellAtIdx(view, idx)
    MyPrint("ActivityNeutralLandView:createCellAtIdx", idx)
	return ActivityNeutralLandCell.new(tostring(self.m_neutralRewardsVec[idx]))
end

function ActivityNeutralLandView:onEnterFrame(  )
	local obj = self:getObj()
    if nil == obj then
        return 
    end

    if self.m_id == "57131" then
        local nowTime = LuaController:call("getWorldTime")
        local actStartTime = obj:getProperty("startTime") 
        local actEndTime = obj:getProperty("endTime")
        MyPrint("nowTime", nowTime)
        MyPrint("actStartTime", actStartTime)
        MyPrint("actEndTime", actEndTime)
        if actEndTime then
            if self.m_nowState ~= ActivityNowState.nowStateInit then
                local str = "<s 18><c fdf2c0ff>"..self.m_stateText
                str = str.." <c 00cf00ff>"..format_time(actEndTime - nowTime)
                if self.m_nowState == ActivityNowState.nowStateCarry then
                    str = str.." <c fdf2c0ff>"..getLang("165147")
                elseif self.m_nowState == ActivityNowState.nowStateFight then
                    str = str.." <c fdf2c0ff>"..getLang("165147")
                    -- str = str.."<n>"..getLang("165221")..":"..tostring(self.m_neutralScore)
                end
                local dateLabel = IFHyperlinkText:call("create",str,cc.size(500,0),true)
                dateLabel:setAnchorPoint(cc.p(0.5,1))
                self.m_stateNode:removeAllChildren()
                self.m_stateNode:addChild(dateLabel)
                MyPrint("ActivityView:onEnterFrame6") 
            else
                self.txt_myCarry:setVisible(true)
                local selfRank = self.m_neutralMyRank
                if tonumber(selfRank) <= 0 then
                    selfRank = getLang("150290")
                end
                self.txt_myCarry:setString(getLang("165438" ,selfRank))
                self.txt_kingdomCarry:setVisible(true)
                local selfLoad = CC_ITOA_K(self.m_neutralLoadLimit)
                self.txt_kingdomCarry:setString(getLang("165153",selfLoad))
            end
 
        end        
        return
    end
end

function ActivityNeutralLandView:onEnter(  )
    registerScriptObserver(self, self.refreshView, "activity_neutral_kingdome_info")
    TipsEventController:call("getInstance"):call("setNeutralActivityCanOpen" , true)
	self:onEnterFrame()
	self.entry = tonumber(cc.Director:getInstance():getScheduler():scheduleScriptFunc(function() self:onEnterFrame() end, 0.5, false))
end

function ActivityNeutralLandView:onExit(  )
    unregisterScriptObserver(self, "activity_neutral_kingdome_info")
    TipsEventController:call("getInstance"):call("setNeutralActivityCanOpen" , false)
	cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
end

function ActivityNeutralLandView:createAd(  )
    local spr = ActivityDetailBase.createAd(self, createAd)

    local obj = self:getObj()
    if nil ~= obj and obj:getProperty("Advertise_pic") and obj:getProperty("Advertise_pic") ~= "" then
        local picPath = obj:getProperty("Advertise_pic") .. ".png"
        local cf = cc.SpriteFrameCache:getInstance():getSpriteFrame(picPath)
        if nil ~= cf then
            spr = CCLoadSprite:call("createSprite", picPath)
        end
    end
    
    spr:setPositionY(-100)
    spr:setAnchorPoint(cc.p(0, 0))

    return spr
end

--------------------------------------------ActivityNeutralLandCell----------------------------------

function ActivityNeutralLandCell:ctor( t )    
    CCLoadSprite:call("doResourceByCommonIndex", 308, true)
	self.m_itemId = t
    local iconStr = CCCommonUtilsForLua:call("getIcon", self.m_itemId)
    local color = CCCommonUtilsForLua:call("getPropById", self.m_itemId, "color")
    local colorStr = CCCommonUtilsForLua:call("getToolBgByColor", tonumber(color))
	ActivityShowCellModel.ctor(self, nil, iconStr, nil, colorStr)

    self.startTouchPt = cc.p(0, 0)
    local function touchHandle( eventType, x, y )
        if eventType == "began" then
            return self:onTouchBegan(x, y)
        elseif eventType == "moved" then
        else
            self:onTouchEnded(x, y)
        end
    end
    self:registerScriptTouchHandler(touchHandle)
    self:setTouchEnabled(true)
    self:setSwallowsTouches(false)
end

function ActivityNeutralLandCell:onTouchBegan( x, y )
    self.startTouchPt = cc.p(x, y)
    self:removeChildByTag(123123)
    if isTouchInside(self.m_touchNode, x, y) then
        local name = CCCommonUtilsForLua:call("getNameById", tostring(self.m_itemId))
        local desc = CCCommonUtilsForLua:call("getPropById", tostring(self.m_itemId), "description")
        desc = getLang(desc)
        local node = CommonItemDescNode:call("create", name, desc)
        local size = node:getContentSize()
        local selfposx = self:getPositionX()
        node:setPositionX(0)
        if selfposx - size.width * 0.5 < -538 / 2 then
            node:setPositionX(-538 / 2 - (selfposx - size.width * 0.5))
        end
        if selfposx + size.width * 0.5 > 538 / 2 then
            node:setPositionX(538 / 2 - (selfposx + size.width * 0.5))
        end
        node:setPositionY(size.height * 0.5 + 50)
        node:setTag(123123)
        self:addChild(node)
        return true
    end
    return false
end

function ActivityNeutralLandCell:onTouchEnded( x, y )
    self:removeChildByTag(123123)
end







