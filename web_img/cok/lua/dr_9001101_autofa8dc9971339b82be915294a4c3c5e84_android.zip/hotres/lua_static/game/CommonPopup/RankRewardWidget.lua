RankRewardWidget = class("RankRewardWidget", function (  )
	return cc.Node:create()
end)
RankRewardWidgetCell = class("RankRewardWidgetCell", function (  )
	return cc.TableViewCell:create()
end)
RankRewardWidgetData = class("RankRewardWidgetData")
function RankRewardWidgetData:ctor( bottomRank, topRank, rewardData, tipStr )
	
	self.bottomRank = tonumber(bottomRank)
	self.topRank = tonumber(topRank)
	self.rewardData = rewardData
	self.tipStr = tipStr
end

function RankRewardWidget.create( viewSize, initData )
 	local ret = RankRewardWidget.new(viewSize, initData)
 	if ret:initSelf() == false then
 		ret = nil
 	end
 	return ret
end 

function RankRewardWidget:ctor( viewSize, initData )
	self.initData = initData
	self.viewSize = viewSize
end

function RankRewardWidget:initSelf(  )
	if nil == self.initData then
		return false
	end

	if type(self.initData) ~= "table" then
		return false
	end

	self:setContentSize(self.viewSize)
	self:setAnchorPoint(cc.p(0, 0))

	self.data = {}
	for i=1,#self.initData do
		if self.initData[i].class ~= RankRewardWidgetData then
			return false
		end
		local t = {}
		t.bTitle = true
		t.bottomRank = tonumber(self.initData[i].bottomRank)
		t.topRank = tonumber(self.initData[i].topRank)
		t.tipStr = self.initData[i].tipStr
		self.data[#self.data + 1] = t
		if nil ~= self.initData[i].rewardData then
			for j=1,#self.initData[i].rewardData do
				local t = {}
				t.bTitle = false
				t.data = self.initData[i].rewardData[j]
				self.data[#self.data + 1] = t
			end
		end
	end

	self.m_tableView1 = cc.TableView:create(self:getContentSize())
	self.m_tableView1:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
	self.m_tableView1:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
	self.m_tableView1:setDelegate()
	self.m_tableView1:setAnchorPoint(cc.p(0, 0))
	self:addChild(self.m_tableView1)

	local function cellSizeForTable( view, idx )
		return self:cellSizeForTable(view, idx)
	end

	local function tableCellAtIndex( view, idx )
		return self:tableCellAtIndex(view, idx)
	end

	local function numberOfCellsInTableView( view )
		return self:numberOfCellsInTableView(view)
	end

	self.m_tableView1:registerScriptHandler(cellSizeForTable,cc.TABLECELL_SIZE_FOR_INDEX)
	self.m_tableView1:registerScriptHandler(tableCellAtIndex,cc.TABLECELL_SIZE_AT_INDEX)
	self.m_tableView1:registerScriptHandler(numberOfCellsInTableView,cc.NUMBER_OF_CELLS_IN_TABLEVIEW)

	self.m_tableView1:reloadData()
	self.m_tableView1:setContentOffset(cc.p(0, self:getContentSize().height - self.m_tableView1:getContentSize().height))

	return true
end

function RankRewardWidget:cellSizeForTable( view, idx )
	return 640, 60
end

function RankRewardWidget:tableCellAtIndex( view, idx )
	idx = idx+1
    if idx > self:numberOfCellsInTableView(view) then
		return nil
    end
    local cell = view:dequeueCell()
    if cell ~= nil then 
		cell:setData(self.data[idx])
    else
        cell = RankRewardWidgetCell.new(self.data[idx])
    end
    return cell
end

function RankRewardWidget:numberOfCellsInTableView( view )
	return #self.data
end


function RankRewardWidgetCell:ctor( data )
	local proxy = cc.CCBProxy:create()
    local ccbiUrl = "RankRewardCell.ccbi"
	local node = CCBReaderLoad(ccbiUrl, proxy, self)
    if nil == node then
        return false
    end
    self:addChild(node)

    self:setData(data)
end

function RankRewardWidgetCell:setData( data )
	if data.bTitle == true then
		self.m_titleNode:setVisible(true)
		self.m_itemNode:setVisible(false)

		if nil ~= data.tipStr then
			self.m_stateNode:setVisible(true)
			self.m_stateLabel:setString(data.tipStr)
		else
			self.m_stateNode:setVisible(false)
		end
		if nil ~= data.topRank then
			if data.topRank == data.bottomRank then
				--            171082=第{0}名：
				--            171083={0}-{1}名：
				local str = getLang("171082", tostring(data.topRank))
				self.m_titleLabel:setString(str)
			else
				local str = getLang("171083", tostring(data.bottomRank), tostring(data.topRank))
				self.m_titleLabel:setString(str)
			end
		else
			local str = getLang("171082", tostring(data.bottomRank) .. "+")
			self.m_titleLabel:setString(str)
		end
	else
		self.m_titleNode:setVisible(false)
		self.m_itemNode:setVisible(true)

		self.m_iconNode:removeAllChildren()
		if tonumber(data.data.type) == 7 or tonumber(data.data.type) == 14 then
			local value = data.data.value
		    if nil ~= value then
		    	local bgSpr = CCLoadSprite:call("createSprite", "icon_kuang.png")
		    	local colorstr = CCCommonUtilsForLua:call("getToolBgByColor", tonumber(CCCommonUtilsForLua:call("getPropById", tostring(value.id), "color")) or 0)
		    	local colorSpr = CCLoadSprite:call("createSprite", colorstr)
		    	local icon = CCCommonUtilsForLua:call("getIcon", tostring(value.id))
			    local spr = CCLoadSprite:call("createSprite", icon)
			    CCCommonUtilsForLua:call("setSpriteMaxSize", bgSpr, 55, true)
			    CCCommonUtilsForLua:call("setSpriteMaxSize", colorSpr, 50, true)
			    CCCommonUtilsForLua:call("setSpriteMaxSize", spr, 50, true)
			    self.m_iconNode:addChild(bgSpr)
			    self.m_iconNode:addChild(colorSpr)
			    self.m_iconNode:addChild(spr)
			    self.m_nameLabel:setString(getLang(CCCommonUtilsForLua:call("getPropById", tostring(value.id), "name")))
				if nil ~= value.num then
			    	self.m_numLabel:setString("×" .. CC_CMDITOA(value.num))
			    end
			end
		else
			local pic = CCLoadSprite:call("createSprite", RewardController:call("getPicByType", tonumber(data.data.type), -1), CCLoadSpriteType.CCLoadSpriteType_DEFAULT)
			CCCommonUtilsForLua:call("setSpriteMaxSize", pic, 50, true)
			self.m_iconNode:addChild(pic)

			local value = data.data.value
			if nil ~= value then
				value = tonumber(value)
				if nil ~= value then
					self.m_numLabel:setString("×" .. CC_CMDITOA(value))
				end
			end
		end
	end
end




