--队列都继承该类
local Cell_QueueFile = class("Cell_QueueFile")
Cell_QueueFile.__index = Cell_QueueFile

local FUN_BUILD_BARRACK1 = 423000	--兵营
local FUN_BUILD_BARRACK2 = 424000	--马厩
local FUN_BUILD_BARRACK3 = 425000	--靶场
local FUN_BUILD_BARRACK4 = 426000	--战车
local FUN_BUILD_NEWARMY = 439000  --荣耀6新兵营
local FUN_BUILD_HOSPITAL = 411000 --医院
local FUN_BUILD_SCIENE  = 403000 --学院
local FUN_BUILD_FORT = 416000 --战争堡垒
local FUN_BUILD_SACRIFICE = 428000 --许愿池
local FUN_BUILD_HALLOFHERO = 433000   --英雄殿堂
local FUN_BUILD_DRAGONTOWER = 432000 --龙塔
local FUN_BUILD_NEWARMY_IMPROVE = 440000 --新兵种强化所

--队列信息
local TYPE_BUILDING = 0 --建筑
local TYPE_FORT = 2 --陷阱
local TYPE_FORCE = 1 --步兵
local TYPE_HOSPITAL = 3 --医院
local TYPE_MARCH = 5 --出征
local TYPE_SCIENCE = 6 --科技
local TYPE_RIDE_SOLDIER = 8 --骑兵
local TYPE_BOW_SOLDIER = 9 --弓兵
local TYPE_CAR_SOLDIER = 10 --车兵
local TYPE_FORGE = 11 --锻造队列11
local TYPE_MATE = 12 --造材料
local TYPE_NEWARMY= 17 --新兵种训练17
local TYPE_NEWARMY_CURE = 18 --新兵种虚弱兵的恢复18

function Cell_QueueFile:ctor(id)
    if id == nil then
        return
    end
    self:initBaseById(id)
end

--主类别的基本信息获取
function Cell_QueueFile:initBaseById( id )
    self.id = id
    self.name = CCCommonUtilsForLua:call("getPropByIdGroup", "pandectType", self.id, "name")
    self.icon = CCCommonUtilsForLua:call("getPropByIdGroup", "pandectType", self.id, "icon")
    self.visible = CCCommonUtilsForLua:call("getPropByIdGroup", "pandectType", self.id, "visible")
    self.order = tonumber(CCCommonUtilsForLua:call("getPropByIdGroup", "pandectType", self.id, "order"))
    self.limitLv = tonumber(CCCommonUtilsForLua:call("getPropByIdGroup", "pandectType", self.id, "unlockLv"))
	self.edit = CCCommonUtilsForLua:call("getPropByIdGroup", "pandectType", self.id, "canEidt")
	local cellKey = "Preview_"..self.id.."_order"
	self.local_order = cc.UserDefault:getInstance():getIntegerForKey(cellKey,1)
    self.CellTbl = {key = self.id,icon = self.icon,local_order = self.local_order,order = self.order, name = self.name, edit = self.edit}
    --状态信息
    self.Queue_ST_Init = -1 
    self.Queue_ST_IDLE = 0 --空闲
    self.Queue_ST_WORK = 1 --工作
    self.Queue_ST_LOCK = 2	--未解锁
    self.mainCityLv = FunBuildController:call("getMainCityLv")

    self.allQueuesInfos = GlobalData:call("shared"):getProperty("allQueuesInfo") or {}
    return true
end

--获取队列 type, 状态，结束时间，显示文本，跳转目标 信息
function Cell_QueueFile:getCureQueueInfo ()
    --overwrite me!!!
end

--获取队列的状态信息
function Cell_QueueFile:getQueueState(queueInfo)
	if queueInfo then
		local curTime = getWorldTime()
		local totalTime = queueInfo:getProperty("totalTime")	
		local endTime = queueInfo:getProperty("endTime")
		local finishTime = queueInfo:getProperty("finishTime") --任务结束时间
		if endTime ~= 0 and endTime <= curTime then
			-- dump("hxq 未解锁 Queue_ST_LOCK")
			return self.Queue_ST_LOCK,0,0		
		elseif endTime == 0 or endTime > curTime then			
			local m_curTime = finishTime - curTime
			if m_curTime <= 0 then
				-- dump(" hxq 空闲中 Queue_ST_IDLE")			
				return self.Queue_ST_IDLE,-1,0
			else				
				if queueInfo:call("isDefendMarch") then
					-- dump("hxq 驻防中 Queue_ST_WORK")
					return self.Queue_ST_WORK,-1,0
				else
					-- dump(finishTime,"hxq 工作中 Queue_ST_WORK finishTime is")
					return self.Queue_ST_WORK,finishTime,totalTime
				end
			end						
		end
	else
		-- dump("QID is MAX 空闲中")
		return 2,-1,-1 --没有队列信息
	end
end

--判断主类别是否显示
function Cell_QueueFile:checkIsVisible()  
    local key = "Preview_"..self.id
    local userDefaultValue = cc.UserDefault:getInstance():getBoolForKey(key, true)
    if self.visible == "1" and self.mainCityLv >= self.limitLv and userDefaultValue == true then
        return true
    else
        return false
    end
end

--是否可编辑
function Cell_QueueFile:checkIsEdit( )
    if self.edit == "1" then
        return true
    else
        return false
    end
end

--根据子类别ID读取子表pandect的name,icon,visible
function Cell_QueueFile:getNameIconVisibleBySubId( subId )
    local name = CCCommonUtilsForLua:call("getPropByIdGroup", "pandect", subId, "name") or ""		
    local icon = CCCommonUtilsForLua:call("getPropByIdGroup", "pandect", subId, "icon") or ""
    local visible = CCCommonUtilsForLua:call("getPropByIdGroup", "pandect", subId, "visible") or "0"
    return name,icon,visible
end

--判断建筑是否已经解锁
function Cell_QueueFile:checkIsUnLock(type)
	local buildType
	local res = false
	if type == TYPE_NEWARMY then
		buildType = FUN_BUILD_NEWARMY
	elseif type == TYPE_FORCE then
		buildType = FUN_BUILD_BARRACK1
	elseif type == TYPE_RIDE_SOLDIER then
		buildType = FUN_BUILD_BARRACK2
	elseif type == TYPE_BOW_SOLDIER then
		buildType = FUN_BUILD_BARRACK3
	elseif type == TYPE_CAR_SOLDIER then
		buildType = FUN_BUILD_BARRACK4
	elseif type == TYPE_HOSPITAL then
		buildType = FUN_BUILD_HOSPITAL
	elseif type == TYPE_SCIENCE then
		buildType = FUN_BUILD_SCIENE
	elseif type == TYPE_FORT then
		buildType = FUN_BUILD_FORT
	else
		buildType = type
	end
	local buildId = FunBuildController:call("getMaxLvBuildByType", buildType)
	if buildId > 0 then
		local buildInfo = FunBuildController:call("getInstance"):call("getFunbuildForLua", buildId)
		--该建筑已有，判断是否解锁
		if buildInfo then
			local m_info_level = buildInfo:getProperty("level")
			local gloryUnlockType = buildInfo:getProperty("gloryUnlockType")
			local gloryUnlockValue = buildInfo:getProperty("gloryUnlockValue")
			local gloryUnlock = buildInfo:getProperty("gloryUnlock")
			local open = buildInfo:getProperty("open")
			--荣耀建筑解锁条件
			local gloryUnLock = gloryUnlock == false and gloryUnlockType ~= "" and gloryUnlockValue ~= ""
			--达到指定等级后开放条件（开放不一定解锁）
			local openUnLock = open > self.mainCityLv
			if gloryUnLock or openUnLock then	
				res = false
			else
				res = true
			end
			-- local name = buildInfo:getProperty("name")		
			-- dump(getLang(name),"hxq name is")
			-- dump(open,"hxq open is")
			-- dump(gloryUnlock,"hxq gloryUnlock is")
			-- dump(gloryUnlockType,"hxq gloryUnlockType is")		
		end
	end
	return res
end

--是否为世界队列
function Cell_QueueFile:isWorldMarch(type)
	local res = false
	--出征
	if type == 5 then
		res = true
	end
	--各种占领
	if (type >= 20 and type <= 31) or type ==34 then
		res = true
	end
	return res
end

--跳转供外接口
function Cell_QueueFile:OnClickJump(subId,state)
    -- override me!!!
end

--1:主城建筑 2:世界
function Cell_QueueFile:jumpByTypeAndTarget(type,targetId)
    local currentSceneId = SceneController:call("getCurrentSceneId")
    if type == 1 then
        if currentSceneId == SCENE_ID_MAIN then
            CCCommonUtilsForLua.jumpToTarget(1, targetId)
        else
            SceneController:call("gotoScene", SCENE_ID_MAIN)
        end
    elseif type == 2 then
        PopupViewController:call("forceClearAll", true)
        if SceneController:call("getCurrentSceneId") ~= 11 then
            SceneController:call("gotoScene", 11)
        end
    end
end
return Cell_QueueFile