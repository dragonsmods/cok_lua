--积分提升途径
local RankActMethodCell = class("RankActMethodCell",
function ()
    return cc.Layer:create()
end)

RankActMethodCell.__index = RankActMethodCell


function RankActMethodCell:create(viewSize, actInfo)
    local view = RankActMethodCell.new()
    Drequire("game.CommonPopup.RankActComponent.RankActMethodCell_ui"):create(view,0,viewSize)
    if view:initView(actInfo) then
        return view
    end
end

function RankActMethodCell:initView(actInfo)
    self.actInfo = actInfo
    CCLoadSprite:call("doResourceByCommonIndex", 204, true)
    self.ctl = require("game.CommonPopup.RankActComponent.RankActDataController").getInstance()
    self.data = self:getActData() -- self.ctl:getDataBykey("methodData")
    if actInfo and actInfo.title then
        self.ui.m_titleLabel:setString(getLang(tostring(actInfo.title)))
    end
    self.cellNums = 0
    if self.data then
        local methodSprNames = self.data.methodSprNames or {}
        self.cellNums = #methodSprNames
    end
    for index = self.cellNums+1, 4 do
        self.ui["m_methodNode"..index]:setVisible(false)
    end

    for index = 1, self.cellNums do
        self:setCellData(index)
    end
    return true
end

function RankActMethodCell:setCellData(index)
    local sprNames = self.data.methodSprNames
    local labelNames = self.data.methodNames
    local scores = self.data.methodPowers
    local btnLabels = self.data.btnLabels    
    
    local sf = CCLoadSprite:call("getSF", sprNames[index])
    if sf then
        self.ui["m_methodSpr"..index]:setSpriteFrame(sf)
    end
    
    self.ui["m_methodName"..index]:setString(getLang(labelNames[index]))
    self.ui["m_btnLabel"..index]:setString(getLang(btnLabels[index]))
    self.ui["m_methodPower"..index]:setString(CC_CMDITOAL(scores[index]))    
end
-- 跳转到指定建筑
function RankActMethodCell:onClickJump(index)
    local jumpInfo = self.data.btnJumps[index]
    PopupViewController:call("removeLastPopupView")
    CCCommonUtilsForLua.jumpToTarget(jumpInfo.go_type, jumpInfo.targetId)
end

function RankActMethodCell:onClickDesc(index)
    local actId = self:getActId() -- self.ctl.actId
    local view = Drequire("game.CommonPopup.RankActComponent.RankActDetailView").create(actId)
    PopupViewController:addPopupView(view)
end

function RankActMethodCell:onClickMethod1( )
	self:onClickJump(1)
end

function RankActMethodCell:onClickBtnDes1( )
	self:onClickDesc(1)
end

function RankActMethodCell:onClickMethod2( )
	self:onClickJump(2)
end

function RankActMethodCell:onClickBtnDes2( )
	self:onClickDesc(2)
end

function RankActMethodCell:onClickMethod3( )
	self:onClickJump(3)
end

function RankActMethodCell:onClickBtnDes3( )
	self:onClickDesc(3)
end

function RankActMethodCell:onClickMethod4( )
	self:onClickJump(4)
end

function RankActMethodCell:onClickBtnDes4( )
	self:onClickDesc(4)
end

function RankActMethodCell:getActId()
    if self.actInfo then
        return self.actInfo.actId
    else
        return self.ctl.actId
    end
end

function RankActMethodCell:getActData()
    if self.actInfo then
        return self.actInfo.data
    else
        return self.ctl:getDataBykey("methodData")
    end
end

return RankActMethodCell