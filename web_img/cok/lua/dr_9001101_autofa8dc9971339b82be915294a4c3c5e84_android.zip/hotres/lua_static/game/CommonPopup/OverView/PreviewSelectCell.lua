local PreviewSelectCell = class("PreviewSelectCell",function ( )
    return cc.TableViewCell:create()
end)
PreviewSelectCell.__index = PreviewSelectCell

function PreviewSelectCell:create( )
    local cell = PreviewSelectCell.new()
    Drequire("game.CommonPopup.OverView.PreviewSelectCell_ui"):create(cell)
    return cell
end

function PreviewSelectCell:refreshCell(info,idx)
    self.key = info.key
    self.parent = info.parent
    self.visible = info.visible
    self.ctl = self.parent.ctl
    self.ui.m_selectSpr:setVisible(self.visible)
    local name = info.name
    local icon = info.icon
    if self.visible then
        name = tostring(idx+1)..". "..getLang(name)
    else
        name = getLang(name)
    end
    self.ui.m_TitleText:setString(name)
    self.ui.m_headPicNode:removeAllChildren()
    if icon ~= "" then
        local headSpr = CCLoadSprite:call("createSprite", icon..".png")
        self.ui.m_headPicNode:addChild(headSpr)   
    end    
end

function PreviewSelectCell:onClickSelect( )   
    self.ui.m_selectBtn:setEnabled(false)
    self.visible = not self.visible
    -- self.ui.m_selectSpr:setVisible(self.visible)
    self.parent:onClickSelectCellSpr(self.key,self.visible)
    --保存按钮置亮
    self.parent.ui.m_saveSetBtn:setEnabled(true)
    self.ui.m_selectBtn:setEnabled(true)
end


return PreviewSelectCell