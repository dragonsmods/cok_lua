----------------------------
-- Author: Elex
-- Date: 2019-11-28 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local BattleViewActiveBuffCell_ui = class("BattleViewActiveBuffCell_ui")

--#ui propertys


--#function
function BattleViewActiveBuffCell_ui:create(owner, viewType, paramTable)
	local ret = BattleViewActiveBuffCell_ui.new()
	CustomUtility:LoadUi("MarchActiveBuffCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function BattleViewActiveBuffCell_ui:initLang()
end

function BattleViewActiveBuffCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function BattleViewActiveBuffCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return BattleViewActiveBuffCell_ui

