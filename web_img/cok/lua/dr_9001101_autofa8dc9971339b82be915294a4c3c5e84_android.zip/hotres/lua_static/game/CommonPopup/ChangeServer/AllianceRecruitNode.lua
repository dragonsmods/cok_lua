local AllianceRecruitNode = class("AllianceRecruitNode", PopupBaseView)

function AllianceRecruitNode:create(applyCb)
    local node = AllianceRecruitNode.new(applyCb)
    Drequire("game.CommonPopup.ChangeServer.AllianceRecruitNode_ui"):create(node, 1)
    node:initNode()
    return node
end

function AllianceRecruitNode:ctor(applyCb)
    self.token = -1
    self.loadByToken = false
    self.refreshTime = -1
    self.applyCb = applyCb
end

function AllianceRecruitNode:initNode()
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_refreshBtn, getLang("173226"))

    self:setScale(1)

    --拉数据
    self:addLoadingAni()
    require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance():getTransferAlliance(false)

    local fadeIn = cc.FadeIn:create(1)
    local fadeOut = cc.FadeOut:create(1)
    local seq = cc.Sequence:create(fadeIn, fadeOut)
    local forever = cc.RepeatForever:create(seq)
    self.ui.m_tokenSp:runAction(forever)
    self.ui.m_tokenSp:setVisible(false)
    self:call("setModelLayerDisplay", false)
	self:call("setViewSwallowTouch", false)
end

function AllianceRecruitNode:addLoadingAni()
	self:removeLoadingAni()

	self.m_loadingIcon = CCLoadSprite:call("createSprite", "loading_1.png")
	self.m_loadingIcon:setAnchorPoint(ccp(0.5, 0.5))

    local size = self.ui.m_listNode:getContentSize()
	self.m_loadingIcon:setPosition(ccp(size.width / 2, size.height / 2))

	local rotateAction = cc.RotateTo:create(0.5, 720)
	local rotateForever = cc.RepeatForever:create(rotateAction)
	self.m_loadingIcon:runAction(rotateForever)
	self.ui.m_listNode:addChild(self.m_loadingIcon, 1000000)
end

function AllianceRecruitNode:removeLoadingAni()
	if self.m_loadingIcon then
		self.m_loadingIcon:removeFromParent()
		self.m_loadingIcon = nil
    end
    
    if self.waitInterface then
        self.waitInterface:call("remove")
        self.waitInterface = nil
    end
end

function AllianceRecruitNode:onEnterFrame(dt)

end

function AllianceRecruitNode:onEnter()
    local function callback1(param) self:updateNode(param) end
	local handler1 = self:registerHandler(callback1)
    CCSafeNotificationCenter:registerScriptObserver(self, handler1, "AllianceRecruitNode:updateNode")
    
    local function callback2(param) self:search(param) end
	local handler2 = self:registerHandler(callback2)
    CCSafeNotificationCenter:registerScriptObserver(self, handler2, "changerServer.filter")

    self:onEnterFrame(0)
	self.entry = tonumber(self:getScheduler():scheduleScriptFunc(function(dt) self:onEnterFrame(dt) end, 1, false))
end

function AllianceRecruitNode:onExit()
    self:getScheduler():unscheduleScriptEntry(self.entry)
    CCSafeNotificationCenter:unregisterScriptObserver(self, "changerServer.filter") 
    CCSafeNotificationCenter:unregisterScriptObserver(self, "AllianceRecruitNode:updateNode") 
end

function AllianceRecruitNode:updateNode(param)
    self:removeLoadingAni()
    local data = dictToLuaTable(param)
    self.active = data.active
    self:updateActive()
    
    self.token = atoi(data.token)
    self.refreshTime = atoi(data.refreshTime)
    self.ui.m_tokenSp:setVisible(self.token > 0)

    if self.loadByToken then
        self.sourceData = self.sourceData or {}
        for _, alliance in ipairs(data.alliances) do
            table.insert(self.sourceData, alliance)
        end
    else
        self.sourceData = data.alliances or {}
    end

    self.ui:setTableViewDataSource("m_listView", self.sourceData)
end

function AllianceRecruitNode:updateActive()
    local info = "<s 18><c b8ac84ff>" .. getLang("173227") .. "<c d07c44ff> " .. getLang("173228")
    local richText = IFHyperlinkText:call("create", info, cc.size(320.00, 0), false, false)
    richText:setAnchorPoint(ccp(0.5, 0.5))
    richText:setPositionX(100)
    richText:ignoreAnchorPointForPosition(false)
    self.ui.m_richNode:removeAllChildren()
    self.ui.m_richNode:addChild(richText)
end

function AllianceRecruitNode:tableCellTouched(tab, cell)
    local detail = cell:getDetail()
    local view = Drequire("game.CommonPopup.ChangeServer.AllianceDetailView"):create(detail, self.applyCb)
    PopupViewController:addPopupInView(view)
end

function AllianceRecruitNode:scrollViewDidScroll(tab)
    local maxdy = self.ui.m_listView:minContainerOffset().y
    local dy = self.ui.m_listView:getContentOffset().y
    if dy > maxdy and self.token > 0 and not self.loadByToken then
        self.loadByToken = true
        self:addLoadingAni()
        require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance():getTransferAlliance(false, nil, nil, self.token)
    end
end

function AllianceRecruitNode:search(param)
    if param then
        local serverId = param:valueForKey("serverId"):getCString()
        local lan = param:valueForKey("lan"):getCString()
        if serverId == "nil" then return end
        if lan == "nil" then lan = "" end
        self:addLoadingAni()
        self.loadByToken = false
        require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance():getTransferAlliance(false, serverId, lan)
    end
end

function AllianceRecruitNode:refreshNotReady()
    local now = GlobalData:call("getTimeStamp")
    return now < self.refreshTime
end

function AllianceRecruitNode:onClickBtnRefresh()
    if self:refreshNotReady() then
        -- CCCommonUtilsForLua:call("flyHint", "", "", getLang("173247"))
        local tmpTime = self.refreshTime - GlobalData:call("getTimeStamp")
        YesNoDialog:call("showTimeWithDes", getLang("173247"), getLang("108659"), tmpTime)
        return 
    end
    
    self.waitInterface = GameController:call("showWaitInterface1", self.ui.m_refreshBtn)
    self:addLoadingAni()
    self.loadByToken = false
    require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance():getTransferAlliance(true)
end

function AllianceRecruitNode:onClickBtnSearch() 
    if self:refreshNotReady() then
        -- CCCommonUtilsForLua:call("flyHint", "", "", getLang("173247"))
        local tmpTime = self.refreshTime - GlobalData:call("getTimeStamp")
        YesNoDialog:call("showTimeWithDes", getLang("173247"), getLang("108659"), tmpTime)
        return 
    end

    local sourceData1 = {} 
    local groups = require("game.CommonPopup.ChangeServer.ChangeServerController").getInstance():getGroups()
    dump(groups, "groups")

    local function sort(a, b)
        return atoi(a) < atoi(b)
    end
    table.sort(groups, sort)

    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
    local serverId = playerInfo:getProperty("selfServerId")
    for k, v in ipairs(groups) do
        if serverId ~= atoi(v) then
            table.insert(sourceData1, {text = v, id = v})
        end
    end

    local sourceData2 = {}
    local xmlData = CCCommonUtilsForLua:getGroupByKey("language")
    for k, v in ipairs4ScatteredT(xmlData) do
        if v.mark then
            table.insert(sourceData2, {text = getLang(v.lang_id), id = v.lang_id})
        end
    end

    local view = Drequire("game.CommonPopup.ChangeServer.ApplySelectView"):create(sourceData1, sourceData2)
    PopupViewController:addPopupView(view)
end

return AllianceRecruitNode