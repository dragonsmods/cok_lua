----------------------------
-- Author: Elex
-- Date: 2019-02-26 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local ChangeServerConditions_ui = class("ChangeServerConditions_ui")

--#ui propertys


--#function
function ChangeServerConditions_ui:create(owner, viewType, paramTable)
	local ret = ChangeServerConditions_ui.new()
	CustomUtility:LoadUi("Lua_ChangeServerConditionsView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function ChangeServerConditions_ui:initLang()
end

function ChangeServerConditions_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function ChangeServerConditions_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function ChangeServerConditions_ui:onClickBack(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBack", pSender, event)
end

function ChangeServerConditions_ui:onClickGet(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickGet", pSender, event)
end

function ChangeServerConditions_ui:onClickSure(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickSure", pSender, event)
end

function ChangeServerConditions_ui:onClickClearMail(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickClearMail", pSender, event)
end

function ChangeServerConditions_ui:initTableView()
	TableViewSmoker:createView(self, "m_tableView", "game.CommonPopup.ChangeServer.ChangeServerConditionsCell", 1, 10, "Lua_ChangeServerConditionsCell")
	TableViewSmoker:createView(self, "m_tableViewNoItem", "game.CommonPopup.ChangeServer.ChangeServerConditionsCell", 1, 10, "Lua_ChangeServerConditionsCell")
end

function ChangeServerConditions_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return ChangeServerConditions_ui

