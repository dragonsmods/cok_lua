----------------------------
-- Author: Elex
-- Date: 2017-11-30 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local AuctionHouseRecordCell_ui = class("AuctionHouseRecordCell_ui")

--#ui propertys


--#function
function AuctionHouseRecordCell_ui:create(owner, viewType)
	local ret = AuctionHouseRecordCell_ui.new()
	CustomUtility:LoadUi("AuctionHouseRecordCell.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function AuctionHouseRecordCell_ui:initLang()
end

function AuctionHouseRecordCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function AuctionHouseRecordCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return AuctionHouseRecordCell_ui

