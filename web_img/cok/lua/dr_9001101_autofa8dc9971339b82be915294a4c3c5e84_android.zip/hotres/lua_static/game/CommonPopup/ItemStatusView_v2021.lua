--[[
    ItemStatusView_v2021
    增益界面 - 增加 新手增益
]]

local ItemStatusEntrance = {
    NORMAL = 0,
    FROM_BATTLE_VIEW = 1, -- 从出征界面跳转时，如果参数是1，则需要根据match_show判断是否显示该项目
    FROM_NEW_PLAYER = 2,  -- 从新手增益图标跳转
}

local ItemStatusView_v2021 = class("ItemStatusView_v2021",
    function()
        return PopupBaseView:create() 
    end
)

local LuaAdController = require("game.controller.LuaAdController").getInstance()

local ItemStatusTypeCell = class("ItemStatusTypeCell",
    function()
        return cc.Layer:create()
    end
)

local MSG_STATUS_PUSH = "MSG_STATUS_PUSH"
local MSG_STATUS_REMOVE_PUSH = "MSG_STATUS_REMOVE_PUSH"

ItemStatusTypeCellOwner = ItemStatusTypeCellOwner or {}
ccb["ItemStatusTypeCellOwner"] = ItemStatusTypeCellOwner

local ArtilleryBuffType = 9999
local ArtilleryBuffTimeType = 66

function ItemStatusView_v2021:create(dict)
    local view = ItemStatusView_v2021.new()
    if (view:initView(dict)) then return view end
end

function ItemStatusView_v2021:ctor()
    --额外状态
    self.extraStatus = {}
end

function ItemStatusView_v2021:initView(dict)
    if self:init(true, 0) and FunOpenController:isUnlock("fun_cityBuff", true) then
        -- self:setIsHDPanel(true)    
        local entrance = nil 
        if dict then
            local tbl = dictToLuaTable(dict)
            entrance = tbl.entrance
            if entrance == ItemStatusEntrance.FROM_BATTLE_VIEW then --参数是1，则需要根据match_show判断是否显示该项目
                self.filter_by_match_show=1 
            elseif entrance == ItemStatusEntrance.FROM_NEW_PLAYER then
                self.changeToNewUser = true
            end
        end
        local winSize = getWinSize()
        CCCommonUtilsForLua:call("makeBatchBG", self, winSize, ccp(0, 0), 1)
        if CCCommonUtilsForLua:isFunOpenByKey("new_expedition_extra") then
            CCLoadSprite:call("loadDynamicResourceByName", "fortress_face")
        end

        CCLoadSprite:call("doResourceByCommonIndex", 5, true)
       
        local proxy = cc.CCBProxy:create()
        local ccbUri = "ItemStatusView_lua_v2021.ccbi"
        local node = CCBReaderLoad(ccbUri, proxy, self)
        local size = node:getContentSize()
        self:setContentSize(size)
        -- CCCommonUtilsForLua:call("makeBatchBG", self.m_bgNode, winSize, ccp(0.5, 1), 1)

        CCLoadSprite:call("loadDynamicResourceByName", "artillery_face")

        local function onNodeEvent(event)
            if event == "enter" then
                self:onEnter()
            elseif event == "exit" then
                self:onExit()
            elseif event == "cleanup" then
                self:onCleanup()
             end
        end
        node:registerScriptHandler(onNodeEvent)
        self:addChild(node)

        -- local addHeight = self:getExtendHeight()
        -- local listSize = self.m_infoList:getContentSize()
        -- self.m_infoList:setPositionY(self.m_infoList:getPositionY() - addHeight)
        -- self.m_infoList:setContentSize(cc.size(listSize.width, listSize.height + addHeight))

        CCCommonUtilsForLua:setButtonTitle(self.m_btnCommon, getLang("104953"))
        CCCommonUtilsForLua:setButtonTitle(self.m_btnNew, getLang("683102"))

        self.m_btnCommon:setEnabled(false)
        self.m_btnNew:setEnabled(true)
        self.m_infoList:setVisible(true)
        self.m_infoListNew:setVisible(false)

        self.m_tableView = cc.TableView:create(self.m_infoList:getContentSize())
        self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
        self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
        self.m_tableView:setDelegate()
        self.m_tableView:registerScriptHandler(function(tab, cell) self:tableCellTouched(tab, cell) end, cc.TABLECELL_TOUCHED)
        self.m_tableView:registerScriptHandler(function(tab, idx) return self:cellSizeForTable(tab, idx) end, cc.TABLECELL_SIZE_FOR_INDEX)
        self.m_tableView:registerScriptHandler(function(tab, idx) return self:tableCellAtIndex(tab, idx) end, cc.TABLECELL_SIZE_AT_INDEX)
        self.m_tableView:registerScriptHandler(function(tab) return self:numberOfCellsInTableView(tab) end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
        self.m_infoList:addChild(self.m_tableView)

        self.m_tableViewNew = cc.TableView:create(self.m_infoListNew:getContentSize())
        self.m_tableViewNew:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
        self.m_tableViewNew:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
        self.m_tableViewNew:setDelegate()
        self.m_tableViewNew:registerScriptHandler(function(tab, cell) self:tableCellTouchedNew(tab, cell) end, cc.TABLECELL_TOUCHED)
        self.m_tableViewNew:registerScriptHandler(function(tab, idx) return self:cellSizeForTableNew(tab, idx) end, cc.TABLECELL_SIZE_FOR_INDEX)
        self.m_tableViewNew:registerScriptHandler(function(tab, idx) return self:tableCellAtIndexNew(tab, idx) end, cc.TABLECELL_SIZE_AT_INDEX)
        self.m_tableViewNew:registerScriptHandler(function(tab) return self:numberOfCellsInTableViewNew(tab) end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
        self.m_infoListNew:addChild(self.m_tableViewNew)

        self.m_adValid = self:checkAdValid()

        self.m_cityBuffData = CCCommonUtilsForLua:getGroupByKey("city_buff")
        if self.changeToNewUser then
            self:onClickNew()
        end

        return true
    end

    return false
end

function ItemStatusView_v2021:onClickCommon()
    self.m_btnCommon:setEnabled(false)
    self.m_btnNew:setEnabled(true)
    self.m_infoList:setVisible(true)
    self.m_infoListNew:setVisible(false)
end

function ItemStatusView_v2021:onClickNew()
    self.m_btnCommon:setEnabled(true)
    self.m_btnNew:setEnabled(false)
    self.m_infoList:setVisible(false)
    self.m_infoListNew:setVisible(true)
end

function ItemStatusView_v2021:updateLocalInfo()
    ToolController:call("getInstance"):setProperty("m_typeItems", {})
    self.m_statusIdItems = {}
    self.m_statusIdItemsNewPlayer = {}
    self.m_statusIdItemsNewPlayerMap = {}
    local serverType = GlobalData:call("shared"):getProperty("serverType")
    local forbidden_frozen = CCCommonUtilsForLua:isFunOpenByKey("forbidden_frozen")
    local statusItems = FunBuildController:call("getCityItemStatus")
    for index, buffId in ipairs(statusItems) do
        local newPlayer = CCCommonUtilsForLua:getPropByIdGroup("city_buff", buffId, "new_player")
        if newPlayer == "1" then
            table.insert(self.m_statusIdItemsNewPlayer, buffId)
            self.m_statusIdItemsNewPlayerMap[buffId] = true
        else
            -- 战场不支持冰冻弹
            if buffId == "108870" then
                if forbidden_frozen == true and serverType ~= ServerType.SERVER_NORMAL then
                    -- table.insert(self.m_statusIdItems, buffId)
                else
                    table.insert(self.m_statusIdItems, buffId)
                end
            else
                table.insert(self.m_statusIdItems, buffId)
            end
        end
    end

    -- 看广告获得buff
    if self.m_adValid then
        for key, value in pairs(self.m_cityBuffData) do
            if not self.m_statusIdItemsNewPlayerMap[key] then
                local buffGet = atoi(value.buff_get)
                if buffGet > 0 then
                    table.insert(self.m_statusIdItemsNewPlayer, key)
                end
            end
        end
    end

    table.sort(self.m_statusIdItemsNewPlayer, function (a, b)
        return atoi(a) < atoi(b)
    end)

    if self.filter_by_match_show == 1 then --需要过滤，根据march_show判断是否显示该项目
        local tmpStatusIdItems={}
        for i,v in ipairs(self.m_statusIdItems) do
            local march_show = CCCommonUtilsForLua:getPropById(v, "march_show")
            if march_show == "1" then
                tmpStatusIdItems[#tmpStatusIdItems + 1]=v
            end
        end
        self.m_statusIdItems=tmpStatusIdItems
    end

    local hasNewBuff = false
    local statusMap = GlobalData:call("shared"):getProperty("statusMap")
    for index, value in ipairs(self.m_statusIdItemsNewPlayer) do
        local statusId = CCCommonUtilsForLua:getPropByIdGroup("city_buff", value, "status")
        local slots = splitString(statusId, "|")
        local nowTime = GlobalData:call("getWorldTime")
        for _, sid in ipairs(slots) do
            local endTime = atoi(statusMap[atoi(sid)])
            local tempTime = endTime - nowTime
            if tempTime > 0 then
                hasNewBuff = true
                break
            end
        end
    end

    if hasNewBuff then
        self.m_tabNode:setVisible(true)
    else
        self.m_tabNode:setVisible(false)
        self.m_infoListNew:setVisible(false)
        self.m_infoList:setVisible(true)
        self.m_infoList:setContentSize(self.m_resizeNode:getContentSize())
        self.m_tableView:setViewSize(self.m_resizeNode:getContentSize())
    end
end

function ItemStatusView_v2021:checkAdValid()
    return LuaAdController:isShowCokVideo() or CCCommonUtilsForLua:isFunOpenByKey("google_ad_separate") or AdVideoController:call("getInstance"):call("isCanPlay")
end

function ItemStatusView_v2021:updateExtra(param)
    if param:objectForKey("extraStatus") then
        self.extraStatus = {}

        local extraStatus = arrayToLuaTable(param:objectForKey("extraStatus"))
        for _, status in ipairs(extraStatus) do
            self.extraStatus[status.id] = atoi(status.effect)
        end
    end
end

function ItemStatusView_v2021:updateInfo(dict)
    self:updateExtra(dict)
    self:updateLocalInfo()

    self.m_tableView:setBounceable(false)
    self.m_tableViewNew:setBounceable(false)
    local miny = self.m_tableView:minContainerOffset().y
    local pos = self.m_tableView:getContentOffset()
    self.m_tableView:reloadData()

    local mincurry = self.m_tableView:minContainerOffset().y
    pos.y = pos.y - miny + mincurry
    if pos.y < mincurry then
        pos.y = mincurry
    end
    self.m_tableView:setContentOffset(pos)

    self.m_tableViewNew:reloadData()
    self.m_tableView:setBounceable(true)
    self.m_tableViewNew:setBounceable(true)
end

function ItemStatusView_v2021:cellSizeForTable(tab, idx)
    if (CCCommonUtilsForLua:isIosAndroidPad()) then
        return 1496, 300
    else
        return 610, 145
    end
end

function ItemStatusView_v2021:tableCellAtIndex(tab, idx)
    if (idx >= #self.m_statusIdItems) then return end

    local cell = tab:dequeueCell()
    if (cell) then
        local node = cell:getChildByTag(666)
        node:setData(self.m_statusIdItems[idx + 1], self.extraStatus)
    else
        local node = ItemStatusTypeCell:create(self.m_statusIdItems[idx + 1], self.extraStatus)
        node:setTag(666)
        cell = cc.TableViewCell:create()
        cell:addChild(node)
    end

    return cell
end

function ItemStatusView_v2021:numberOfCellsInTableView(tab)
    return #self.m_statusIdItems
end

function ItemStatusView_v2021:tableCellTouched(tab, cell)
    if (cell) then
        local node = cell:getChildByTag(666)
        if (node and node.touchEnable) then
            if (node.m_type == 0 or node.m_type == ArtilleryBuffType or node.m_showIndepend == 1) then 
                return 
            end

            local typeNameS = getLang(CCCommonUtilsForLua:call("getPropById", node.m_statusId, "name"))
            local description = getLang(CCCommonUtilsForLua:call("getPropById", node.m_statusId, "tips"))

            local flag = (node.m_timeType == 0) and true or false
            local _type = flag and node.m_type or node.m_timeType
            local view = Drequire("game.CommonPopup.UseItemStatusView"):create(_type, typeNameS, description, flag)
            --83  typeNameS is 最强王国获取活动积分增加  description is 提示：大幅提高您在最强王国活动中获取积分的效率 flag is tru
            PopupViewController:addPopupInView(view)
        end
    end
end

function ItemStatusView_v2021:cellSizeForTableNew(tab, idx)
    if (CCCommonUtilsForLua:isIosAndroidPad()) then
        return 1496, 300
    else
        return 610, 145
    end
end

function ItemStatusView_v2021:tableCellAtIndexNew(tab, idx)
    if (idx >= #self.m_statusIdItemsNewPlayer) then return end

    local cell = tab:dequeueCell()
    if (cell) then
        local node = cell:getChildByTag(666)
        node:setData(self.m_statusIdItemsNewPlayer[idx + 1], self.extraStatus)
    else
        local node = ItemStatusTypeCell:create(self.m_statusIdItemsNewPlayer[idx + 1], self.extraStatus)
        node:setTag(666)
        cell = cc.TableViewCell:create()
        cell:addChild(node)
    end

    return cell
end

function ItemStatusView_v2021:numberOfCellsInTableViewNew(tab)
    return #self.m_statusIdItemsNewPlayer
end

function ItemStatusView_v2021:tableCellTouchedNew(tab, cell)
    if (cell) then
        local node = cell:getChildByTag(666)
        if (node and node.touchEnable) then
            local task_go_type = CCCommonUtilsForLua:getPropByIdGroup("city_buff", node.m_statusId, "task_go_type")
            local task_go = CCCommonUtilsForLua:getPropByIdGroup("city_buff", node.m_statusId, "task_go")
            CCCommonUtilsForLua.jumpToTarget(task_go_type, task_go)
        end
    end
end

function ItemStatusView_v2021:refreshStatusData()
    local cmd = require("game.command.ShowStatusItemCmd").create()
    cmd:send()
end

function ItemStatusView_v2021:onEnter()
    local cmd = require("game.command.ShowStatusItemCmd").create()
    cmd:send()

    self:setTitleName(getLang("102282"))
    registerScriptObserver(self, self.updateInfo, "status.item.refresh")
    registerScriptObserver(self, self.refreshStatusData, MSG_STATUS_PUSH)
    registerScriptObserver(self, self.refreshStatusData, MSG_STATUS_REMOVE_PUSH)
end

function ItemStatusView_v2021:onExit()
    unregisterScriptObserver(self, "status.item.refresh")
    unregisterScriptObserver(self, MSG_STATUS_PUSH)
    unregisterScriptObserver(self, MSG_STATUS_REMOVE_PUSH)
end

function ItemStatusView_v2021:onCleanup()
    self = nil
end


---------------------------ItemStatusTypeCell-----------------------------

function ItemStatusTypeCell:create(statusId, extraStatus)
    local node = ItemStatusTypeCell.new()
    if (node:initNode(statusId, extraStatus)) then
        return node
    end
end

function ItemStatusTypeCell:initNode(statusId, extraStatus)
    CCLoadSprite:call("doResourceByCommonIndex", 504, true)

    self.m_statusId = statusId
    self.extraStatus = extraStatus

    local ccbUri = "ItemStatusTypeCell02_lua.ccbi"
    local proxy = cc.CCBProxy:create()
    local node = CCBReaderLoad(ccbUri, proxy, self)

    local function onNodeEvent(event)
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        elseif event == "cleanup" then
            self:onCleanup()
        end
    end
    node:registerScriptHandler(onNodeEvent)
    self:addChild(node)

    if (CCCommonUtilsForLua:isIosAndroidPad()) then
        self:setContentSize(cc.size(1496, 300))
    else
        self:setContentSize(cc.size(605, 145))
    end

    self.animationManager = ccb["ItemStatusTypeCellOwner"]["mAnimationManager"]
    self:setData(self.m_statusId, extraStatus)
    self:ignoreAnchorPointForPosition(true)
    self.touchEnable = true
    --self.m_timeType = 0
    if  self.m_statusId == "108800" then
        --战争守护
        self:reqFortressData()
    end
        
    return true
end

function ItemStatusTypeCell:onEnter()
    -- body
    local function callback() self:resetTime() end
    local handler = self:registerHandler(callback)
    CCSafeNotificationCenter:registerScriptObserver(self, handler, MSG_ITME_STATUS_TIME_CHANGE)
    self:freshData()
    if self.entry then
        cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
        self.entry = nil
    end
    self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(function(dt) self:freshData(dt) end, 1, false)

    registerScriptObserver(self, self.refreshBroken, "msg_fortress_point_data_back") 
end

function ItemStatusTypeCell:onExit()
    CCSafeNotificationCenter:unregisterScriptObserver(self, MSG_ITME_STATUS_TIME_CHANGE)
    if self.entry then
        cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
        self.entry = nil
    end
    unregisterScriptObserver(self, "msg_fortress_point_data_back")
    if self.entry1 then
        self:getScheduler():unscheduleScriptEntry(self.entry1)
        self.entry1 = nil
     end   
end
function ItemStatusTypeCell:reqFortressData()
    local ctl = require("game.fortress.FortressController"):getInstance()
    if  ctl:isWarriorOpen() then
        -- 远征阶段 而且是周六 勇士奖励任务  破罩时间
        ctl:startGetPointData()
    end
end
function ItemStatusTypeCell:refreshBroken()
    if self.m_statusId ~= "108800" then return end
    local ctl = require("game.fortress.FortressController"):getInstance()
    if not ctl.endTime then return end
    local function updateBrokenTime(dt)
        -- body
        local leftTime = ctl.endTime - getTimeStamp()
        if leftTime > 0 then
            self.m_lbtask:setString(getLang("52022017",CC_SECTOA(leftTime)))
        else
            -- body
            self.m_nodeBroken:setVisible(false)
            if self.entry1 then
                self:getScheduler():unscheduleScriptEntry(self.entry1)
                self.entry1 = nil
             end   
        end
    end
    
    self.m_nodeBroken:setVisible(ctl.endTime > getTimeStamp())
    self.m_lbtaskDesc:setString(getLang("52022018"))
    self.m_barNode:setVisible(self.m_time > 0 and ctl.endTime <= getTimeStamp())
    if ctl.endTime > getTimeStamp() then
        if self.entry1 then
            self:getScheduler():unscheduleScriptEntry(self.entry1)
            self.entry1 = nil
         end 
        self.entry1 = tonumber(self:getScheduler():scheduleScriptFunc(function (dt)
            updateBrokenTime(dt)
         end, 1.0, false))
         updateBrokenTime(0)
    end
end

function ItemStatusTypeCell:onCleanup()
    -- body
    --self = nil
end

function ItemStatusTypeCell:resetTime(pObj)
    local integer = tolua.cast(pObj, "CCInteger")
    if integer == nil then
        return
    end
    if (integer:getValue() == self.m_type) then
        self:freshData()
        if self.entry then 
            cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry) 
            self.entry = nil
        end
        self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(function(dt) self:freshData(dt) end, 1, false)
    end
end

function ItemStatusTypeCell:setData(statusId, extraStatus)
    self.m_statusId = statusId
    self.extraStatus = extraStatus

    self.m_type = atoi(CCCommonUtilsForLua:call("getPropById", self.m_statusId, "type"))
    self.m_timeType = atoi(CCCommonUtilsForLua:call("getPropById", self.m_statusId, "itemtype"))
    self.m_showIndepend = atoi(CCCommonUtilsForLua:call("getPropById", self.m_statusId, "independent_display"))
    self.m_buffGetAd = CCCommonUtilsForLua:getPropByIdGroup("city_buff", self.m_statusId, "buff_get")
    self.m_iconNode:removeAllChildren()
    self.m_sprArrow:setVisible(true)

    local typeNameS = getLang(CCCommonUtilsForLua:call("getPropById", self.m_statusId, "name"))
    self.m_nameTxt:setString(typeNameS)
    self:resetDescText()
    
    if (self.m_type == 0 or self.m_type == ArtilleryBuffType or self.m_showIndepend == 1) then 
        self.m_sprArrow:setVisible(false) 
    end
    
    local task_go_type = CCCommonUtilsForLua:getPropByIdGroup("city_buff", self.m_statusId, "task_go_type")
    self.m_sprArrow:setVisible(task_go_type and task_go_type ~= "") 

    local iconPath = CCCommonUtilsForLua:call("getPropById", self.m_statusId, "icon") .. ".png"
    local color = atoi(CCCommonUtilsForLua:call("getPropById", self.m_statusId, "color"))
    local colorBgPath = CCCommonUtilsForLua:call("getToolBgByColor", color)
    local iconBg = CCLoadSprite:call("createSprite", colorBgPath)
    local iconSpr = CCLoadSprite:call("createSprite", iconPath, CCLoadSpriteType_GOODS)

    if (CCCommonUtilsForLua:isIosAndroidPad()) then
        CCCommonUtilsForLua:setSpriteMaxSize(iconBg, 140, true)
        CCCommonUtilsForLua:setSpriteMaxSize(iconSpr, 140, true)
    else
        CCCommonUtilsForLua:setSpriteMaxSize(iconBg, 92, true)
        CCCommonUtilsForLua:setSpriteMaxSize(iconSpr, 92, true)
    end

    self.m_iconNode:addChild(iconBg)
    self.m_iconNode:addChild(iconSpr)

    if (self.m_barNode:getChildByTag(100)) then self.m_barNode:removeChildByTag(100) end

    self.animationManager:runAnimationsForSequenceNamed("loop")

    --加进度条头上的光效
    self.m_headParticleNode = cc.Node:create()
    for i = 1, 3 do
        local path = string.format("Loading_%d", i)
        local particle = ParticleController:call("createParticle", path)
        self.m_headParticleNode:addChild(particle)
    end

    self.m_barNode:addChild(self.m_headParticleNode)
    self.m_headParticleNode:setTag(100)

    self:freshData()

    if self.entry then
        cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
        self.entry = nil
    end

    self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(function(dt) self:freshData(dt) end, 1, false)

    if (self.m_type == 16) then
        if (not CCCommonUtilsForLua:isIosAndroidPad()) then
            self.m_barNode:setPositionY(30)
        end
    else
        if (CCCommonUtilsForLua:isIosAndroidPad()) then
            self.m_cellBG:setPreferredSize(cc.size(1496, 300))
        else
            self.m_cellBG:setPreferredSize(cc.size(604, 145))
        end

        if (not CCCommonUtilsForLua:isIosAndroidPad()) then
            self.m_mainNode:setPositionY(0)
            self.m_barNode:setPositionY(40.2)
        end
    end
end

function ItemStatusTypeCell:resetDescText()
    local description = CCCommonUtilsForLua:call("getPropById", self.m_statusId, "description")
    local descValStr = CCCommonUtilsForLua:call("getPropById", self.m_statusId, "description_value")
    if descValStr and descValStr ~= "" then
        local descVal = string.split(descValStr, "|")
        self.m_descTxt:setString(getLang(description, unpack(descVal)))
    else
        self.m_descTxt:setString(getLang(description))
    end
    self.m_descTxt:setVisible(true)

    --清除富文本
    local parent = self.m_descTxt:getParent()
    parent:removeChildByTag(666)
end

function ItemStatusTypeCell:updateExtra()
    local statusId = CCCommonUtilsForLua:call("getPropById", self.m_statusId, "status")
    local slots = splitString(statusId, "|")
    local statusId
    local effect = 0
    for _, sid in ipairs(slots) do
        if self.extraStatus[sid] then
            statusId = sid
            effect = atoi(self.extraStatus[sid])
            break
        end
    end

    if statusId then
        local dialog = require("game.controller.StatusController").getInstance():getExtraDialog(statusId)
        local numStr = string.format("%.1f", effect)
        -- self.m_descTxt:setString(getLang(dialog, numStr))

        local rich = utils.getLinkTextStr(getLang(dialog), numStr, 18, "C1A77CFF", "3DA4C6FF")
        replaceRichText(self.m_descTxt, rich, 666)
    else
        self:resetDescText()
    end
end

function ItemStatusTypeCell:freshData()
    self.m_time = 0
    self.m_timeCDTxt:setVisible(false)
    self.m_CDBackLayer:setVisible(false)

    local max = 0

    if (self.m_timeType == ArtilleryBuffTimeType) or self.m_showIndepend == 1 then
        local statusMap = GlobalData:call("shared"):getProperty("statusMap")
        local statusId = CCCommonUtilsForLua:call("getPropById", self.m_statusId, "status")
        local slots = splitString(statusId, "|")
        local nowTime = GlobalData:call("getWorldTime")
        for _, sid in ipairs(slots) do
            local endTime = atoi(statusMap[atoi(sid)])
            self.m_time = endTime - nowTime
            if self.m_time > 0 then break end
        end

        max = atoi(CCCommonUtilsForLua:getPropByIdGroup("status", statusId, "time"))
    elseif (self.m_timeType == 0) then
        local items = ToolController:call("getInstance"):getProperty("m_statusItems")
        if (items[self.m_type]) then
            local item = items[self.m_type]
            local startTime = item:valueForKey("startTime"):doubleValue()
            local endTime = item:valueForKey("endTime"):doubleValue()
            local time = WorldController:call("getTime")
            self.m_time = (endTime - time) / 1000
            max = (endTime - startTime) / 1000
        end
    else
        local durationItems = ToolController:call("getInstance"):getProperty("m_durationItems")
        if (durationItems[self.m_timeType]) then
            local time = durationItems[self.m_timeType]
            if (#time == 2) then
                self.m_time = time[2] - GlobalData:call("getTimeStamp")
                max = time[2] - time[1]
            end
        end
    end

    self.m_adParentNode:setVisible(false)
    if (self.m_time > 0) then
        self.m_barNode:setVisible(true)
        max = math.max(max, 1)
        local len = self.m_time / max
        if (len > 1) then len = 1 end
        self.m_progress:setScaleX(len)
        self.m_barRight:setVisible(len > 0.99) --右箭头
        self.m_timeTxt:setString(getLang("105805", format_time(self.m_time)))
        self.m_receiveGlow:setVisible(true)

        local px = 0 --进度条头上的光效位置
        px = self.m_progress:getPositionX() + (self.m_progress:getContentSize().width * len)
        self.m_headParticleNode:setPositionX(px)
        self:updateExtra()
    else
        self:resetDescText()
        self.m_progress:setScaleX(0)
        self.m_timeTxt:setString(getLang("105805", format_time(0)))
        self.m_barNode:setVisible(false)
        self.m_receiveGlow:setVisible(false)
        self.touchEnable = true

        if self.m_buffGetAd and self.m_buffGetAd ~= "" then
            self.m_adParentNode:setVisible(true)
            if self.m_commonAdNode == nil then
                local callback = function ()
                    local LuaAdController = require("game.controller.LuaAdController").getInstance()
                    local adInfo = LuaAdController:getDataByTypes(atoi(self.m_buffGetAd))
                    local isShowRwd = adInfo and adInfo.showReward == '1' and true or false
                    require("game.command.LuaAdCommand"):reqADGoods(atoi(self.m_buffGetAd), isShowRwd)

                    -- 683104=恭喜您，已免费获得增益
                    CCCommonUtilsForLua:call("flyHint", "", "", getLang("683104"))

                    -- local cmd = require("game.command.ShowStatusItemCmd").create()
                    -- cmd:send()
                end

                self.m_commonAdNode = Drequire("utils.commonAdNode"):create(atoi(self.m_buffGetAd), callback)
                if self.m_commonAdNode then
                    self.m_adParentNode:removeAllChildren()
                    self.m_adParentNode:addChild(self.m_commonAdNode)
                end
            end
        end

        if (self.m_type == 1) then
            local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
            local protectCDTime = playerInfo:getProperty("protectCDTime")
            local worldTime = GlobalData:call("getWorldTime")
            local newTime = GlobalData:call("renewTime", worldTime * 1000) / 1000
            local cdTime = protectCDTime - newTime
            if (cdTime > 0) then
                self.m_timeCDTxt:setVisible(true)
                self.m_timeCDTxt:setString(getLang("105164", CCCommonUtilsForLua:call("timeLeftToCountDown", cdTime)))
                self.touchEnable = false
                self.m_CDBackLayer:setVisible(true)

                local txtSize = self.m_timeCDTxt:getContentSize()
                self.m_CDBackLayer:setContentSize(cc.size(txtSize.width + 10, txtSize.height))
            else
                self.m_timeCDTxt:setVisible(false)
                self.m_CDBackLayer:setVisible(false)
                if self.entry then 
                    cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry) 
                    self.entry = nil
                end
            end
        else
            if self.entry then 
                cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry) 
                self.entry = nil
            end
        end
    end
end

return ItemStatusView_v2021