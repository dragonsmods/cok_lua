require("game.command.TriggerActivityCmd")

ActivityViewPlus = class("ActivityViewPlus", function  (  )
    return PopupBaseView:call("create")
end)

function ActivityViewPlus:ctor( id, titleId, textId )
    self.m_id = id
    self.m_titleId = titleId
    self.m_textId = textId
    Dprint('ActivityViewPlus', id, textId)
end

function ActivityViewPlus.create( id, titleId, textId )
    local ret = ActivityViewPlus.new(id, titleId, textId)
    if ret:initView() ~= true then
        ret = nil
    end
    return ret
end

function ActivityViewPlus:getObj(  )
    return ActivityController:call("getActObj", self.m_id)
end

function ActivityViewPlus:initView(  )
    Dprint("ActivityViewPlus:initView")
    self:init(true, 0)
    self:setHDPanelFlag(true)

    local obj = self:getObj()
    if nil == obj then
        return false
    end
    CCLoadSprite:call("doResourceByCommonIndex", 310, true)
    CCLoadSprite:call("doResourceByCommonIndex", 500, true)
    CCLoadSprite:call("doResourceByCommonIndex", 506, true)
    CCLoadSprite:call("loadDynamicResourceByName", "activity_ad")
    CCLoadSprite:call("loadDynamicResourceByName", "activity_ad_2")
    CCLoadSprite:call("loadDynamicResourceByName", "activity_res")


    local size = getWinSize()
    self:setContentSize(size)
    local proxy = cc.CCBProxy:create()
    local ccbiUrl = "ActivityViewPlus"
    local node = CCBReaderLoad(ccbiUrl, proxy, self)
    if nil == node then
        MyPrint("nil == node")
        return false
    end
    self:addChild(node)

    if CCCommonUtilsForLua:call("isIosAndroidPad") then
        self.m_mainNode:setScale(2)
    end

    if self.m_titleId then
        self.m_titleLabel:setColor(cc.c3b(255, 238, 144))
        self.m_titleLabel:setString(getLang(self.m_titleId))
    else
        self.m_titleLabel:setString(obj:getProperty("name"))
    end

    local cell = self:createActivityDetail()
    if nil == cell then
        MyPrint("nil == cell")
        return false
    end

    self.m_cell = cell

    self.m_contentNode:addChild(cell)
    self.m_helpBtn:setVisible(cell:showHelpBtn())

    local bgsize = self.m_bgNode:getContentSize()
    local height = 0
    while height < bgsize.height do
        local spr = CCLoadSprite:call("createSprite", "technology_09.png")
        spr:setAnchorPoint(cc.p(0, 0))
        spr:setPositionX(0)
        spr:setPositionY(height)
        self.m_bgNode:addChild(spr)
        height = height + spr:getContentSize().height
    end

    local layer = cc.Layer:create()
    node:addChild(layer, -1)
    self.startTouchPt = cc.p(0, 0)
    local function touchHandle( eventType, x, y )
        if eventType == "began" then
            return self:onTouchBegan(x, y)
        elseif eventType == "moved" then
        else
            self:onTouchEnded(x, y)
        end
    end
    layer:registerScriptTouchHandler(touchHandle)
    layer:setTouchEnabled(true)
    layer:setSwallowsTouches(false)

    local nodesize = self.m_iconNode:getContentSize()
    self.clipNode = CCClipNode:call("create", nodesize.width, nodesize.height)
    local tnode = tolua.cast(self.clipNode, "cc.Node")
    tnode:setAnchorPoint(cc.p(0, 0))
    self.m_iconNode:addChild(tnode)

    local ad = self.m_cell:createAd()
    if nil ~= ad then
        if self.m_id == "57235" then --联盟竞技图片特殊处理下
            ad:setPositionY(ad:getPositionY()-40)
        end
        tnode:addChild(ad)
    end

    local topicon = self.m_cell:createTopIcon()
    if nil ~= topicon then
        self.m_topIconNode:addChild(topicon)
    end
    local beMerge = obj:call("getmerge")
    if beMerge then
        for i = 0, 1 do
            local fire1 = ParticleController:call("createParticle", "LimitActive2_"..i)
            self.m_topIconNode:addChild(fire1)
        end
    end

    return true
end

function ActivityViewPlus:getAdNodeSize(  )
    return self.m_iconNode:getContentSize()
end

--------------
function ActivityViewPlus:createActivityDetail()
    MyPrint("ActivityViewPlus:createActivityDetail")
    local ret = nil
    local obj = self:getObj()
    if nil == obj then
        MyPrint("obj ", obj)
        return nil
    end

    local objType = obj:getProperty("type")
    MyPrint("objType ", objType)
    local cell = nil
    if objType == 6 or objType == 58 or objType == 60 then
        if self.m_id == "57254" then -- 答题
            cell = Drequire("game.QuestionActivity.ActivityQuestionView").create(self.m_id)
        else
            Drequire("game.CommonPopup.ActivityCommonShowView")
            cell = ActivityCommonShowView.create(self.m_id)
        end
    else
        -- 根据id判断
        if self.m_id == "57103" then
            -- 资源战
            require("game.CommonPopup.ActivityResBattleView")
            cell = ActivityResBattleView.create(self.m_id)
        elseif self.m_id == "57127" then
            -- 
            require("game.CommonPopup.ActivityEggView")
            cell = ActivityEggView.create(self.m_id)
        elseif self.m_id == "57131" then--中立地带
            Drequire("game.CommonPopup.ActivityNeutralLandView")
            cell = ActivityNeutralLandView.create(self.m_id)
        elseif self.m_id == "57133" then -- 联盟团购
            local cellPath = "game.activity.57133.57133cell"
            package.loaded[cellPath] = nil
            local cellView = require(cellPath)
            if cellView.checkActivitOpen then
                if cellView.checkActivitOpen() == false then
                    return
                end
            end
            cell = cellView.new(self.m_id)
        elseif self.m_id == "57150" then
            myRequire("game.recall.RecallTaskView")
            cell = RecallTaskView.create(self.m_id)
        elseif self.m_id == "57155" then
            myRequire("game.fortress.FortressPrepareView")
            cell = FortressPrepareView.new(self.m_id, self.m_textId)
        elseif self.m_id == "57158" then
            myRequire("game.resBattleNew.NewResBattleActivityView")
            cell = NewResBattleActivityView.create(self.m_id)
        end
    end

    if nil ~= cell then
        cell:setFather(self)
    end

    return cell
end

function ActivityViewPlus:onHelpBtnClick(  )
    self.m_cell:callHelp()
end

function ActivityViewPlus:onTouchBegan( x, y )
    self.startTouchPt = cc.p(x, y)
    if isTouchInside(self.m_touchNode, x, y) then
        return false
    end
    return true
end

function ActivityViewPlus:onTouchEnded( x, y )
    if isTouchInside(self.m_touchNode, x, y) then
        return 
    end

    local dis = 10
    if CCCommonUtilsForLua:call("isIosAndroidPad") then
        dis = 20
    end
    if cc.pGetDistance(self.startTouchPt, cc.p(x, y)) > dis then
        return
    end

    self:call("closeSelf")
end

function ActivityViewPlus:onCloseBtnClick(  )
    self:call("closeSelf")
end



