local ApplyRankCell = class("ApplyRankCell", cc.TableViewCell)

function ApplyRankCell:create(idx)
    local cell = ApplyRankCell.new()
    Drequire("game.CommonPopup.ChangeServer.ApplyRankCell_ui"):create(cell, 0)
    return cell
end

function ApplyRankCell:ctor()

end

function ApplyRankCell:refreshCell(info, idx)
    self.ui.m_numspr1:setVisible(false)
    self.ui.m_numspr2:setVisible(false)
    self.ui.m_numspr3:setVisible(false)
    self.ui.m_numText:setString("")

    local rank = atoi(info.rank)
    if rank == 1 then
        self.ui.m_numspr1:setVisible(true)
    elseif rank == 2 then
        self.ui.m_numspr2:setVisible(true)
    elseif rank == 3 then 
        self.ui.m_numspr3:setVisible(true)
    else
        self.ui.m_numText:setString(tostring(rank))
    end

    self.ui.m_text1:setString(info.name)
    self.ui.m_text2:setString(CC_CMDITOA(info.power))
end 

return ApplyRankCell