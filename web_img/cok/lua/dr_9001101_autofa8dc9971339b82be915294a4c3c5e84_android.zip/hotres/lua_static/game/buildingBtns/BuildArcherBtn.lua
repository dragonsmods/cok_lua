--弓兵兵营
local BuildArcherBtn = class("BuildArcherBtn", Drequire("game.buildingBtns.BuildingAddBtn"))
function BuildArcherBtn:create(param)
    local btn = BuildArcherBtn.new(param)
    btn:initBtn()    
    return btn
end

function BuildArcherBtn:initBtn()
    self.buildKey = self.param:valueForKey("buildKey"):intValue()
    self:addExtensionBtn()

end

return BuildArcherBtn