--车兵兵营
local BuildVehicleBtn = class("BuildVehicleBtn", Drequire("game.buildingBtns.BuildingAddBtn"))
function BuildVehicleBtn:create(param)
    local btn = BuildVehicleBtn.new(param)
    btn:initBtn()    
    return btn
end

function BuildVehicleBtn:initBtn()
    self.buildKey = self.param:valueForKey("buildKey"):intValue()
    self:addExtensionBtn()

end

return BuildVehicleBtn