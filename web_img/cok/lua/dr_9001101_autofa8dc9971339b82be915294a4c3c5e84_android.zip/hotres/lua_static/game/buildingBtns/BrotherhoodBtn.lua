--兄弟会按钮
local BrotherhoodBtn = class("BrotherhoodBtn", Drequire("game.buildingBtns.SpeBuildingBtn"))

function BrotherhoodBtn:create(param)
    local btn = BrotherhoodBtn.new(param)
    btn:initBtn()    
    return btn
end

function BrotherhoodBtn:initBtn()   
    if not CCCommonUtilsForLua:isFunOpenByKey("MGPB_friends_button_628") and FunOpenController:isShow("fun_friend") then --敏感时期屏蔽,好友按钮
        --好友列表
        local callback = function()
            self:hideSelf()
        
            local view = Drequire("game.brotherhood.FriendsView"):create()
            PopupViewController:addPopupInView(view)
        end
        self:addBtn("Friend_list_icon_new.png", "132103", callback)--132103=好友
    end

    --宝藏
    if not GlobalData:call("isChinaPlatForm") and FunOpenController:isShow("fun_friendTreasure") then
        local callback = function()
            self:hideSelf()
        
            require "game.brotherhood.TreasureView"
            local view = TreasureView:create()
            PopupViewController:addPopupInView(view)
        end
        self:addBtn("icon_binding_FB.png", "107050", callback)  --107050=宝藏
    end

    --附近的人
    if CCCommonUtilsForLua:isFunOpenByKey("players_nearby") and FunOpenController:isShow("fun_nearby") then
        local callback = function()
            self:hideSelf()
            if FunOpenController:isUnlock("fun_nearby", true) then
                MailController:call("showNearByListPopupView")
            end
        end
        self:addBtn("near_by_user_icon.png", "132439", callback)--132439=附近的人
    end

    --召回
    if NewRecallController:getFunOpen() and NewRecallController:checkTimeRight() then
        local callback = function()
            self:hideSelf()
        
            NewRecallController:fireCommonEvent("createNewRecallView")
        end
        self:addBtn("new_recall_icon.png", "145024", callback)  --145024=召回
    end
    
    --联盟召回
    local open, festId, actId = require("game.FestivalActivities.FestivalActivitiesController").getInstance():isAllianceRecallActivityOpen()
    if open then
        local callback = function()
            self:hideSelf()
        
            require("game.FestivalActivities.FestivalActivitiesHelper").openFestivalView(festId, actId)
        end
        CCLoadSprite:call("loadDynamicResourceByName", "Common_209_face")
        self:addBtn("guozhan_allyGift.png", "4250154", callback) --4250154=盟友召集
    end

    --适配按钮位置
    self:adapt()
end

return BrotherhoodBtn