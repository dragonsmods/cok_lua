--校场按钮
local TrainFieldBtn = class("TrainFieldBtn", Drequire("game.buildingBtns.BuildingAddBtn"))
function TrainFieldBtn:create(param)
    local btn = TrainFieldBtn.new(param)
    btn:initBtn()    
    return btn
end

function TrainFieldBtn:initBtn()
    self.buildKey = self.param:valueForKey("buildKey"):intValue()
    self:addExtensionBtn()
    local mainCityLv = FunBuildController:call("getMainCityLv")
    --k1制造军械 k2武装军械 城堡限制等级
    local armamentOpenLv = tonumber(CCCommonUtilsForLua:getPropByIdGroup("data_config","make_armament_arms","k1")) or 30
    local armyReformOpenLv = tonumber(CCCommonUtilsForLua:getPropByIdGroup("data_config","make_armament_arms","k2")) or 30

    local buildInfo = FunBuildController:call("getFunbuildForLua", self.buildKey)
    local state = buildInfo:getProperty("state")
    --军械制造
    if FunOpenController:isShow("fun_makeArmament") and state == FUN_BUILD_NORMAL and mainCityLv >= armamentOpenLv and CCCommonUtilsForLua:isFunOpenByKey("make_armament") then
        CCLoadSprite:call("loadDynamicResourceByName", "armament_face")
        local callback = function()
            self:hideSelf()
            local view = Drequire("game.productionSoldier.armory.ProduceArmoryView"):create(self.buildKey)
            if view then
                PopupViewController:addPopupInView(view)
            end 
            LogController:sendUserBehaviorEvent("building", 2, tostring(math.floor(self.buildKey / 1000)), "makeArmament")
        end
        local iconName = "junxiezhizao.png"
        self:addBtn({
            icon = iconName,
            text = "9711477",--9711477=军械制造
            callback = callback,
            btnKey = "armament",
            })
    end
    --军械库
    if FunOpenController:isShow("fun_armory") and state == FUN_BUILD_NORMAL and mainCityLv >= armyReformOpenLv and CCCommonUtilsForLua:isFunOpenByKey("make_armament_arms") then
        local callback = function()
            self:hideSelf()
            local armyData = DataController.ArmyReformController:getArmysData()
            if #armyData > 0 then
                local view = Drequire("game.productionSoldier.armysReform.ArmysReformView"):create(self.buildKey)
                if view then
                    PopupViewController:addPopupInView(view)
                end
            else
                DataController.ArmyReformController:resetLockCacheData()
                CCCommonUtilsForLua:call("flyHint", "", "", getLang("165135"))--165135=未解锁
            end
            LogController:sendUserBehaviorEvent("building", 2, tostring(math.floor(self.buildKey / 1000)), "armory")
        end
        CCLoadSprite:call("loadDynamicResourceByName", "armament_face")
        local iconName = "junxieku.png"        
        self:addBtn({
            icon = iconName,
            text = "9711476",--9711476=军械库
            callback = callback,
            btnKey = "armament_arms",
            })
    end

    --领主对决
    if FunOpenController:isShow("fun_lordDuel") and CCCommonUtilsForLua:isFunOpenByKey("player_battle") then
        local callback = function()
            self:hideSelf()
            require("game.fightDeath.FightDeathController").getInstance():openListView()
            LogController:sendUserBehaviorEvent("building", 2, tostring(math.floor(self.buildKey / 1000)), "lordDuel")
        end
        CCLoadSprite:call("loadDynamicResourceByName", "FightDeath_face")
        self:addBtn({
            icon = "Icon_sidou_vs.png",
            text = "9900202",   --9900202=领主对决
            callback = callback,
            btnKey = "fightdeath",
            })
    end

    if FunOpenController:isShow("fun_knightHall") then
        local KnightActivityController = require("game.knightActivity.KnightActivityController"):getInstance()
        if KnightActivityController:checkIsOpen() then
            local function callback()
                self:hideSelf()
                KnightActivityController:openMainView()
                LogController:sendUserBehaviorEvent("building", 2, tostring(math.floor(self.buildKey / 1000)), "knightHall")
            end
            local KnightActConstData = Drequire("game.knightActivity.KnightActConstData")
            CCLoadSprite:call("loadDynamicResourceByName", KnightActConstData.dynamicRes.main)
            local iconName = "knightActivity_icon.png"   
                self:addBtn({
                    icon = iconName,
                    text = "681886",--骑士大厅
                    callback = callback,
                    btnKey = "knightAct_btn",
                    })
        end
    end
end



return TrainFieldBtn