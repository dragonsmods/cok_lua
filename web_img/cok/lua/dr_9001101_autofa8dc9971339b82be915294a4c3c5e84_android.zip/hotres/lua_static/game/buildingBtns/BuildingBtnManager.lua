local BuildingBtnManager = class("BuildingBtnManager")

local BuildingBtnManagerInstance = BuildingBtnManagerInstance or nil

local buildType2btn = {
	--医院
	["411000"] = "game.buildingBtns.HospitalBtn",
	--大使馆
	["402000"] = "game.buildingBtns.EmbassyBtn",
	--英雄殿堂
	["433000"] = "game.buildingBtns.HeroBuildingBtn",
	--城墙
	["419000"] = "game.buildingBtns.CityWallBtn",

	-- 主堡
	["400000"] = "game.buildingBtns.MainCityBtn",
	--校场
	["427000"] = "game.buildingBtns.TrainFieldBtn",
	--行军帐篷
	["410000"] = "game.buildingBtns.TroopsBtn",
	--许愿池
	["428000"] = "game.buildingBtns.SacrificeBtn",
	--学院
	["403000"] = "game.buildingBtns.MagicHouseBtn",
	--伐木场
	["413000"] = "game.buildingBtns.WoodFactoryBtn",
	--铁矿场
	["414000"] = "game.buildingBtns.IronFactoryBtn",
	--秘银矿
	["412000"] = "game.buildingBtns.SilverFactoryBtn",
	--箭塔
	["418000"] = "game.buildingBtns.ArrowTowerBtn",
	--农田
	["415000"] = "game.buildingBtns.FarmlandBtn",

	--工坊
	["430000"] = "game.buildingBtns.WorkShopBtn",
	--祷告礼堂
	["440000"] = "game.buildingBtns.Glory6BlessBtn",
	--部队旗帜
	["9990001"] = "game.buildingBtns.BuildFlagBtn",
	--铁匠铺
	["429000"] = "game.buildingBtns.BlacksmithBtn",
    
    --市场 
	["401000"] = "game.buildingBtns.MarketTreasureMapBtn",
	--战争大厅
	["407000"] = "game.buildingBtns.BuildWarBtn",
	--战争堡垒
	["416000"] = "game.buildingBtns.BuildFortBtn",
	--瞭望塔
	["417000"] = "game.buildingBtns.BuildWatchBtn",
	--步兵营
	["423000"] = "game.buildingBtns.BuildInfantryBtn",
	--骑兵营
	["424000"] = "game.buildingBtns.BuildCavalryBtn",
	--弓兵营
	["425000"] = "game.buildingBtns.BuildArcherBtn",
	--车兵营
	["426000"] = "game.buildingBtns.BuildVehicleBtn",
	--上古龙塔
	["432000"] = "game.buildingBtns.DragonTowerBtn",
	--贤者之塔
	["436000"] = "game.buildingBtns.HighTechBtn",
	--戒律大厅
	["439000"] = "game.buildingBtns.BuildNewArmsBtn",
	--庇护所
	["441000"] = "game.buildingBtns.BuildNewArmsRecoverBtn",
	--银行
	["438000"] = "game.buildingBtns.BankBuildingBtn",
	--仓库
	["404000"] = "game.buildingBtns.CellarBuildingBtn",
	--火器营
	["444000"] = "game.buildingBtns.ArtilleryBtn",
	-- ["425000"] = "game.buildingBtns.MainCityBtn",
	-- ["426000"] = "game.buildingBtns.MainCityBtn",
	-- ["424000"] = "game.buildingBtns.MainCityBtn",
	----------------[ 以下为特殊建筑 ]------------------ 
	--酒馆
	["9990005"] = "game.buildingBtns.TavernBtn",
	--旅行商人
	["9990008"] = "game.buildingBtns.MerchantBtn",
	--兄弟会
	["9990012"] = "game.buildingBtns.BrotherhoodBtn",	
	--喷泉/鼎
	["9990020"] = "game.buildingBtns.FlowerbedsBtn",
	--文明圣殿
	["9990027"] = "game.buildingBtns.PrestigeBtn",
	--码头
	["9990009"] = "game.buildingBtns.ShipsideBtn",
 }

--建筑升级中，btn1是否显示
local buildType2BtnShow = {
	["402000"] = true,
	["433000"] = true,
}

function BuildingBtnManager.getInstance()
    if BuildingBtnManagerInstance == nil then
		BuildingBtnManagerInstance = BuildingBtnManager.new()
	end
	return BuildingBtnManagerInstance
end

function BuildingBtnManager:ctor()
	
end

function BuildingBtnManager:fireCommonEvent(key, data)
	Dprint('BuildingBtnManager:fireCommonEvent', key)
	if key == "addBtn" then
		self:addBtn(data)
	elseif key == "clearBtn" then
		self:clearShowBtn()
	elseif key == "getBtnNum" then
		if self.showBtn then
			local btnNum = self.showBtn:getBtnNum()
			data:setObject(CCString:create(tostring(btnNum)), "btnNum")
		end
	end
end

function BuildingBtnManager:addBtn(param)
	if CCCommonUtilsForLua:isFunOpenByKey("lua_building_btn") == false then return end
	self:clearShowBtn()

	if param then
		local btnNode = param:objectForKey("btnNode")
		btnNode = tolua.cast(btnNode, "cc.Node")
		if btnNode then
			local buildType = param:valueForKey("buildType"):getCString()
			--工坊需要特殊处理下，本身是普通建筑但是不能升级和建造，只能放到SpeBuildingBtn处理
			if string.sub(buildType,1, 6) == "430000" then
				buildType = "430000"				
			end
			local btnFile = buildType2btn[buildType]
			if btnFile then
				self.showBtn = Drequire(btnFile):create(param)
				btnNode:addChild(self.showBtn)
			end

			if self.showBtn then
				local btnNum = self.showBtn:getBtnNum()
				param:setObject(CCString:create(tostring(btnNum)), "btnNum")
				local btnList = {}
				if self.showBtn.getBtnList then
					btnList = self.showBtn:getBtnList()
				end
				if #btnList > 0 then
					param:setObject(CCString:create(tostring(#btnList)), "addBtnNum")
					for i, btn in ipairs(btnList) do
						param:setObject(btn, "addBtn"..i)
					end
				end
			end
		end
	end
end

function BuildingBtnManager:getGuideNodeByKey(key)
	if CCCommonUtilsForLua:isFunOpenByKey("lua_building_btn") == false then return end
	if self.showBtn and self.showBtn.getGuideNodeByKey then return self.showBtn:getGuideNodeByKey(key) end
end

function BuildingBtnManager:clearShowBtn()
	self.showBtn = nil
end

function BuildingBtnManager:getBtn1State(key)	
	return buildType2BtnShow[key]
end

return BuildingBtnManager