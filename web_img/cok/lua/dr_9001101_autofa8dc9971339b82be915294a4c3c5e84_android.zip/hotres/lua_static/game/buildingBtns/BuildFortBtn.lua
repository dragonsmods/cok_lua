--战争堡垒
local BuildFortBtn = class("BuildFortBtn", Drequire("game.buildingBtns.BuildingAddBtn"))
function BuildFortBtn:create(param)
    local btn = BuildFortBtn.new(param)
    btn:initBtn()    
    return btn
end

function BuildFortBtn:initBtn()
    self.buildKey = self.param:valueForKey("buildKey"):intValue()
    self:addExtensionBtn()

end

return BuildFortBtn