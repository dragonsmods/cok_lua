--祷告礼堂
local Glory6BlessBtn = class("Glory6BlessBtn", Drequire("game.buildingBtns.BuildingBtn"))

function Glory6BlessBtn:create(param)
    local btn = Glory6BlessBtn.new(param)
    btn:initBtn()    
    return btn
end

function Glory6BlessBtn:initBtn()
    self.buildKey = self.param:valueForKey("buildKey"):intValue()
    --强化
    if FunOpenController:isShow("fun_enhance") then
        local callback = function()
            self:hideSelf()
            local view = Drequire("game.Glory6.Glory6StrengthenView"):create()
            PopupViewController:addPopupInView(view)
        end
        local Glory6Manager = require("game.Glory6.Glory6Manager")    
        local showRedPoint = Glory6Manager.chechShowRedPoint()
        self:addBtn("glory6Improve.png", "5000030", callback, showRedPoint)  --5000030=强化
    end
    
    --转化
    if isFunOpenByKey("tower_transfer") and FunOpenController:isShow("fun_transfer") then
        local callback2 = function()
            self:hideSelf()
            local view = Drequire("game.Glory6.Glory6SkillChangeView"):create()
            if view then
                PopupViewController:addPopupInView(view)
            end
        end
        self:addBtn("Glory6SkillTransfer.png", "101725", callback2)
    end
    --适配按钮位置
    self:adapt()
end

return Glory6BlessBtn