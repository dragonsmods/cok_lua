--市场  藏宝图活动 按钮添加
local MarketTreasureMapBtn = class("MarketTreasureMapBtn", Drequire("game.buildingBtns.BuildingAddBtn"))

function MarketTreasureMapBtn:create(param)
    local btn = MarketTreasureMapBtn.new(param)
    btn:initBtn()    
    return btn
end

function MarketTreasureMapBtn:initBtn()
    self.buildKey = self.param:valueForKey("buildKey"):intValue()
   -- self:addExtensionBtn()

    if isFunOpenByKey("functionopen") then
        if FunOpenController:isShow("fun_trade") and GlobalData:call("shared"):getProperty("serverType") ~= ServerType.SERVER_DRAGON_BATTLE_GLOBAL then
            self:addBtn({
                icon = "alliances_trade.png",
                text = "102280",    --102280=交易
                callback = function ()
                    self:hideSelf()

				    AllianceManager:call("getInstance"):call("openMarketView")
                    LogController:sendUserBehaviorEvent("building", 2, tostring(math.floor(self.buildKey / 1000)), "trade")
                end
            })
        end
    end

    if FunOpenController:isShow("fun_nightMarket") and CCCommonUtilsForLua:isFunOpenByKey("night_market")  then
        CCLoadSprite:call("loadDynamicResourceByName", "TreasureMap_face")
        local callback = function()
            self:hideSelf()
            LogController:sendUserBehaviorEvent("building", 2, tostring(math.floor(self.buildKey / 1000)), "nightMarket")

            if isCrossServerNow() then
                -- 137705=您当前处于跨服状态，无法使用该功能。
                CCCommonUtilsForLua:call("flyHint", "", "", getLang("137705"))
                return
            end

            local view = Drequire("game.FestivalActivities.TreasureMap.TreasureMapActView"):create()     
            if view then
                PopupViewController:addPopupInView(view)
            end
        end
        self:addBtn({
            icon = "treasureMap.png",
            text = "670063",    --670063=夜市
            callback = callback,
            btnKey = "buildRank",
            })
    end

    self:addExtensionBtn()
end

return MarketTreasureMapBtn