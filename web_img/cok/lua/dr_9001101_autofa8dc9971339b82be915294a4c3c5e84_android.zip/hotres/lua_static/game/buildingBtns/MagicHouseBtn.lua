--魔法学院
local MagicHouseBtn = class("MagicHouseBtn", Drequire("game.buildingBtns.BuildingAddBtn"))
function MagicHouseBtn:create(param)
    local btn = MagicHouseBtn.new(param)
    btn:initBtn()    
    return btn
end

function MagicHouseBtn:initBtn()
    local buildKey = self.param:valueForKey("buildKey"):intValue()
    local buildType = tostring(math.floor(buildKey / 1000))

    if isFunOpenByKey("functionopen") then
        if FunOpenController:isShow("fun_magicHouse") and isMagicDrawOpen() then
            local isResOk = DynamicResourceController2:call("checkDynamicResource", "magic_face") 
                            and CCLoadSprite:call("loadDynamicResourceByName", "magic_face")
            self:addBtn({
                icon = isResOk and "choukaIcon.png" or "glft003.png",
                text = "176403",    --176403=魔法屋
                redpoint = checkMagicLuckyDrawTips(),
                callback = function ()
                    self:hideSelf()

                    local view = Drequire("game.magic.LuckDraw.MagicLuckDrawView").create()
                    PopupViewController:call("addPopupInView", view)
                    LogController:sendUserBehaviorEvent("building", 2, buildType, "magicHouse")
                end
            })
            
            if FunOpenController:isShow("fun_magicBook") and isMagicBookOpen() then
                self:addBtn({
                    icon = isResOk and "modianIcon.png" or "glft003.png",
                    text = "176404",    --176404=魔典
                    redpoint = checkMagicBookTips(),
                    callback = function ()
                        self:hideSelf()
                        
                        local view = Drequire("game.magic.book.MagicBookView").create()
                        PopupViewController:call("addPopupInView", view)
                        LogController:sendUserBehaviorEvent("building", 2, buildType, "magicBook")
                    end
                })
    
            end
        end
    end

    self:addExtensionBtn()
end

return MagicHouseBtn