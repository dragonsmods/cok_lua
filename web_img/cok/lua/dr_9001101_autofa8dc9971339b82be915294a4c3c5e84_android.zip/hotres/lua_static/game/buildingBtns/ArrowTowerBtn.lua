--箭塔
local ArrowTowerBtn = class("ArrowTowerBtn", Drequire("game.buildingBtns.BuildingAddBtn"))
function ArrowTowerBtn:create(param)
    local btn = ArrowTowerBtn.new(param)
    btn:initBtn()    
    return btn
end

function ArrowTowerBtn:initBtn()
    self.buildKey = self.param:valueForKey("buildKey"):intValue()
    self:addExtensionBtn()

end

return ArrowTowerBtn