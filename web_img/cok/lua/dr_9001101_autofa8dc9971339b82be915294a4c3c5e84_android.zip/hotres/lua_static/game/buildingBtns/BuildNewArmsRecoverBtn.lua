--庇护所
local BuildNewArmsRecoverBtn = class("BuildNewArmsRecoverBtn", Drequire("game.buildingBtns.BuildingAddBtn"))
function BuildNewArmsRecoverBtn:create(param)
    local btn = BuildNewArmsRecoverBtn.new(param)
    btn:initBtn()    
    return btn
end

function BuildNewArmsRecoverBtn:initBtn()
    self.buildKey = self.param:valueForKey("buildKey"):intValue()
    self:addExtensionBtn()

end

return BuildNewArmsRecoverBtn