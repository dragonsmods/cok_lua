--农田
local FarmlandBtn = class("FarmlandBtn", Drequire("game.buildingBtns.BuildingAddBtn"))
function FarmlandBtn:create(param)
    local btn = FarmlandBtn.new(param)
    btn:initBtn()    
    return btn
end

function FarmlandBtn:initBtn()
    self.buildKey = self.param:valueForKey("buildKey"):intValue()
    self:addExtensionBtn()

end

return FarmlandBtn