local localize={
	["CN"]=1, 
	["TW"]=1, 
	["HK"]=1, 
	["JA"]=2, 
}
return localize
