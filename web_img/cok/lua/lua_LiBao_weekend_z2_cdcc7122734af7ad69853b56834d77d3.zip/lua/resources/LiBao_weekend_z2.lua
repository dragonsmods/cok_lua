cfg_table = {
	["layerX"] = -15,
	["layerY"] = -33,
	["layerScale"] = 1,
}