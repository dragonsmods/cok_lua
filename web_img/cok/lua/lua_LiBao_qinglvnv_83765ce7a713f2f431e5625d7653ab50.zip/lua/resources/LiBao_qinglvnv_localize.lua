local localize={
	["localize/%A6%A6%F1-ɦ%F1=˲%F1%D3.png"]=1, 
	["CN"]=2, 
	["TW"]=2, 
	["HK"]=2, 
	["JA"]=3, 
}
return localize
