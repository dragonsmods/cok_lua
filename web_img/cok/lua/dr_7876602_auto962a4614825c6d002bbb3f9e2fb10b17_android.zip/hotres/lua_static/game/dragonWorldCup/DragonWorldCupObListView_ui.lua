----------------------------
-- Author: Elex
-- Date: 2017-09-13 17:42:22
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local DragonWorldCupObListView_ui = class("DragonWorldCupObListView_ui")

--#ui propertys


--#function
function DragonWorldCupObListView_ui:create(owner, viewType)
	local ret = DragonWorldCupObListView_ui.new()
	CustomUtility:LoadUi("DragonWorldCupObListView.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function DragonWorldCupObListView_ui:initLang()
end

function DragonWorldCupObListView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function DragonWorldCupObListView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function DragonWorldCupObListView_ui:onSearchClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onSearchClick", pSender, event)
end

return DragonWorldCupObListView_ui

