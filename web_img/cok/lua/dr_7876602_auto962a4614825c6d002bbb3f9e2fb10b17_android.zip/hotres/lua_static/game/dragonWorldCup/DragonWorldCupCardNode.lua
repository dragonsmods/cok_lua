local DragonWorldCupCardNode = class("DragonWorldCupCardNode", cc.Layer)

function DragonWorldCupCardNode:create()
    local node = DragonWorldCupCardNode.new()
    Drequire("game.dragonWorldCup.DragonWorldCupCardNode_ui"):create(node, 0)
    if node:initNode() then return node end
end

function DragonWorldCupCardNode:ctor()
    self.manager = require("game.dragonWorldCup.DragonWorldCupManager")
    self.worldCupData = self.manager.getWorldCupData()
    self.rewardUp = self.worldCupData.rewardUp
    if self.worldCupData.mainStage == DRAGON_WORLDCUP_SIGNUP_STAGE 
        or self.worldCupData.mainStage == DRAGON_WORLDCUP_GROUP_STAGE then
        self.canBuy = true
    else
        self.canBuy = false
    end

    self.popTip = false
    -- self.rewardUp = false
    -- self.canBuy = false

    self.cardItem = CCCommonUtilsForLua:call("getPropByIdGroup", "data_config", "wag_pass", "k2")
    self.cardGiftId = CCCommonUtilsForLua:call("getPropByIdGroup", "data_config", "wag_pass", "k3")
end

function DragonWorldCupCardNode:initNode()
    if self.rewardUp == false and self.canBuy == false then return false end

    local tInfo = ToolController:call("getToolInfoForLua", atoi(self.cardItem))
    local name = tInfo and tInfo:call("getName") or ""
    self.descNode = CommonItemDescNode:call("create", name, getLang("9201320"), false)
    self.descNode:setAnchorPoint(ccp(1, 0))
    self.descNode:setVisible(false)
    self:addChild(self.descNode)

    utils.attachBgToLabel(self.ui.m_cardLabel, "frame_02png.png")

    local icon = tInfo and tInfo:getProperty("icon") or "wag_score_card"
    local sf = CCLoadSprite:call("loadResource", icon .. ".png")
    if sf then self.ui.m_cardSp:setSpriteFrame(sf) end

    if self.rewardUp then
        self.ui.m_cardLabel:setString(getLang("550077"))
    else
        self.ui.m_cardLabel:setString(getLang("9201321"))
    end

    registerTouchHandler(self)
    self:setSwallowsTouches(false)

    return true
end

function DragonWorldCupCardNode:useCard(param)
    local data = dictToLuaTable(param)
    if data.itemId == self.cardItem then
        self.rewardUp = true
        self.canBuy = false
        self.ui.m_cardLabel:setString(getLang("550077"))
    end
end

function DragonWorldCupCardNode:payFinished(ref)
    local id = ref and ref:getCString()
    if id and self.cardGiftId == id then
        self.popTip = true
    end
end

function DragonWorldCupCardNode:confirmUseCard()
    local function useCard()
        ToolController:call("useTool", atoi(self.cardItem), 1, true, false)
    end

    local tInfo = ToolController:call("getToolInfoForLua", atoi(self.cardItem))
    local name = tInfo and tInfo:call("getName") or ""
    YesNoDialog:show(getLang("9201322", name), useCard) 
end

function DragonWorldCupCardNode:closeGiftView()
    if self.popTip then 
        self.popTip = false
        self:confirmUseCard() 
    end
end

function DragonWorldCupCardNode:onEnter()
    registerScriptObserver(self, self.useCard, "msg.use.tool")
    registerScriptObserver(self, self.closeGiftView, "popup_view_out")
    registerScriptObserver(self, self.payFinished, PAYMENT_COMMAND_RETURN)
end

function DragonWorldCupCardNode:onExit()
    unregisterScriptObserver(self, "msg.use.tool")
    unregisterScriptObserver(self, "popup_view_out")
    unregisterScriptObserver(self, PAYMENT_COMMAND_RETURN)
end

function DragonWorldCupCardNode:onTouchBegan(x, y)
    if isTouchInside(self.ui.m_clickNode, x, y) then
        self.touchPoint = ccp(x, y)
        self.descNode:setVisible(self.rewardUp)
        return true
    end
end

function DragonWorldCupCardNode:onTouchMoved(x, y)
    if ccpDistance(self.touchPoint, ccp(x, y)) > 10 then 
        self.descNode:setVisible(false)
    end
end

function DragonWorldCupCardNode:onTouchEnded(x, y)
    self.descNode:setVisible(false)

    if ccpDistance(self.touchPoint, ccp(x, y)) > 10 then return end

    local tInfo = ToolController:call("getToolInfoForLua", atoi(self.cardItem))
    local cnt = tInfo and tInfo:call("getCNT") or 0

    if self.canBuy == true then
        if cnt > 0 then
            self:confirmUseCard()
        else
            local view = Drequire("game.CommonPopup.ItemGetMethodView"):create(self.cardItem)
            if view then
                PopupViewController:call("addPopupView", view)
            end
        end
    end
end

return DragonWorldCupCardNode
