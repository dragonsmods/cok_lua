local DragonWorldCupBarrcksCell = class("DragonWorldCupBarrcksCell", cc.TableViewCell)

function DragonWorldCupBarrcksCell:create()
    local cell = DragonWorldCupBarrcksCell.new()
    Drequire("game.dragonWorldCup.DragonWorldCupBarrcksCell_ui"):create(cell, 0)
    if cell:initUI() then return cell end
end

function DragonWorldCupBarrcksCell:initUI()
    --文本框
	local img = CCLoadSprite:call("createScale9Sprite", "frame_text2.png")  
	img:setAnchorPoint(0.5, 0.5)
	self.m_editBox = cc.EditBox:create(self.ui.m_editNode:getContentSize(), img)  --输入框尺寸，背景图片
	self.m_editBox:setPosition(self.ui.m_editNode:getContentSize().width / 2,self.ui.m_editNode:getContentSize().height / 2)
	self.m_editBox:setAnchorPoint(cc.p(0.5, 0.5))
	self.m_editBox:setFontSize(22)
	self.m_editBox:setFontColor(cc.c3b(255, 255, 255))
	self.m_editBox:setReturnType(cc.KEYBOARD_RETURNTYPE_DONE ) --输入键盘返回类型，done，send，go等
    self.m_editBox:setInputMode(cc.EDITBOX_INPUT_MODE_NUMERIC) --输入模型，如整数类型，URL，电话号码等，会检测是否符合
    local function editCB (strEventName, pSender)
		if tostring(pSender) == "return" then
			self:editBoxEvent()
		end
    end
    self.m_editBox:setPlaceHolder(tostring(self.chooseNum))
	self.m_editBox:registerScriptEditBoxHandler(editCB) --输入框的事件，主要有光标移进去，光标移出来，以及输入内容改变等
    self.ui.m_editNode:addChild(self.m_editBox)

    --滑动条
    local thunmImg = CCLoadSprite:createSprite("ICON_huakuai.png")
    local progImg = CCLoadSprite:createSprite( "PRO_lvse.png") 
    local m_sliderBg = CCLoadSprite:call("createScale9Sprite", "prestige_jindutiao_bg2.png")
    m_sliderBg:setContentSize(self.ui.m_sliderNode:getContentSize())
    m_sliderBg:setVisible(false)
    progImg:setScaleY((self.ui.m_sliderNode:getContentSize().height - 6) / progImg:getContentSize().height)
    self.m_controlSlider = CCSliderBar:call("createSlider",m_sliderBg,progImg,thunmImg) 
	self.m_controlSlider:call("setProgressScaleX", 290 / progImg:getContentSize().width)
	self.m_controlSlider:setAnchorPoint(CCPoint(0.5, 0.5))
	self.m_controlSlider:setPosition(CCPoint(self.ui.m_sliderNode:getContentSize().width / 2,self.ui.m_sliderNode:getContentSize().height / 2))
	self.m_controlSlider:setEnabled(true)
	self.m_controlSlider:setMinimumValue(0.0)
	self.m_controlSlider:setMaximumValue(1.0)
    self.m_controlSlider:call("setLimitMoveValueEx", 10)
    
    --注册
  	local function valueChanged(pSender) self:moveSlider() end
	self.m_controlSlider:addHandleOfControlEvent(valueChanged, 256) 
    self.ui.m_sliderNode:addChild(self.m_controlSlider)

    return true
end

function DragonWorldCupBarrcksCell:refreshCell(info, idx)
    self.info = info
    self.armyId = info.armyId
    self.maxNum = info.maxNum

    local aInfo = GlobalData:call("getArmyInfoById", self.armyId)
    if aInfo then
        local star = ArmyController:call("getStarlvById", self.armyId)
        local icon = SoldierIconCell:call("create", aInfo:call("getHeadIcon"), 110, self.armyId, true, star)
        self.ui.m_picNode:removeAllChildren()
        self.ui.m_picNode:addChild(icon)

        local num = CCCommonUtilsForLua:call("getPropByIdGroup", "arms", self.armyId, "level")
        local romanSp = CCCommonUtilsForLua:call("getRomanSprite", atoi(num))
        self.ui.m_levelNode:removeAllChildren()
        self.ui.m_levelNode:addChild(romanSp)

        local name = CCCommonUtilsForLua:call("getPropByIdGroup", "arms", self.armyId, "name")
        self.ui.m_nameLabel:setString(getLang(name))
    end

    self.ui.m_maxLabel:setString("/" .. CC_CMDITOA(info.maxNum))

    self:refreshUI()
end

function DragonWorldCupBarrcksCell:onEnter()
    registerScriptObserver(self, self.correctNum, "msg.worldcup.army.correct")
end

function DragonWorldCupBarrcksCell:onExit()
    unregisterScriptObserver(self, "msg.worldcup.army.correct")
end

function DragonWorldCupBarrcksCell:executeCb()
    if self.info.correctCb then 
        self.info.correctCb(self.armyId, self.info.selectNum)
    end

    self:refreshUI()
end

function DragonWorldCupBarrcksCell:refreshUI()
    self.m_editBox:setText(tostring(self.info.selectNum))

    local percent = 0
    if self.maxNum == 0 then
        percent = 1
    else
        percent = self.info.selectNum / self.maxNum
    end

    self.invalidSliderMove = true
    self.m_controlSlider:call("setValueForLua", percent)
    self.invalidSliderMove = false
end

function DragonWorldCupBarrcksCell:correctNum(obj)
    if obj then
        local data = dictToLuaTable(obj)
        if data.armyId == self.armyId then
            self.info.selectNum = atoi(data.correctNum)
            self:refreshUI()
        end
    end
end

function DragonWorldCupBarrcksCell:editBoxEvent()
    self.info.selectNum = math.floor(atoi(self.m_editBox:getText()))
    self:checkLimit()
    self:executeCb()
end

function DragonWorldCupBarrcksCell:moveSlider()
    if self.invalidSliderMove then return end
    local percent = self.m_controlSlider:call("getValueForLua")
    self.info.selectNum = math.ceil(self.maxNum * percent)
    self:executeCb()
end

function DragonWorldCupBarrcksCell:checkLimit()
    if self.info.selectNum < 0 then self.info.selectNum = 0 end
    if self.info.selectNum > self.maxNum then self.info.selectNum = self.maxNum end
end

function DragonWorldCupBarrcksCell:onAddClick()
    self.info.selectNum = self.info.selectNum + 1
    self:checkLimit()
    self:executeCb()
end

function DragonWorldCupBarrcksCell:onSubClick()
    self.info.selectNum = self.info.selectNum - 1
    self:checkLimit()
    self:executeCb()
end

return DragonWorldCupBarrcksCell


