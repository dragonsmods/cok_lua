----------------------------
-- Author: Elex
-- Date: 2017-05-15 11:53:17
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local DragonWorldCupPlayOffAwardCell_ui = class("DragonWorldCupPlayOffAwardCell_ui")

--#ui propertys


--#function
function DragonWorldCupPlayOffAwardCell_ui:create(owner, viewType)
	local ret = DragonWorldCupPlayOffAwardCell_ui.new()
	CustomUtility:DoRes(11, true)
	CustomUtility:LoadUi("DragonWorldCupPlayOffAwardCell.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function DragonWorldCupPlayOffAwardCell_ui:initLang()
end

function DragonWorldCupPlayOffAwardCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function DragonWorldCupPlayOffAwardCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return DragonWorldCupPlayOffAwardCell_ui

