local DragonWorldCupSelectZoneView = class("DragonWorldCupSelectZoneView", PopupBaseView)

local dragonWorldCupManager = require("game.dragonWorldCup.DragonWorldCupManager")

function DragonWorldCupSelectZoneView:create()
    local view = DragonWorldCupSelectZoneView.new()
    Drequire("game.dragonWorldCup.DragonWorldCupRoomListView_ui"):create(view, 0)
    if view:initView() then
        return view
    end
end

function DragonWorldCupSelectZoneView:ctor()
    self.areaInfo = {}
    self.ctrl = require("game.dragonWorldCup.DragonWorldCupManager")
end

function DragonWorldCupSelectZoneView:initView()
    --创建个空的tableview
    if self:init(true, 0) then
        self:setIsHDPanel(true)
        self:changeBGHeight(self.ui.m_viewBg)

        CCLoadSprite:call("loadDynamicResourceByName", "dragonGlobal")

        if CCCommonUtilsForLua:isIosAndroidPad() then
            self.ui.m_topNode:setScale(2.4)
            self.ui.m_bottomNode:setScale(2.4)
        end

        local addHeight = self:call("getExtendHeight")
        local listSize = self.ui.m_infoList:getContentSize()
        self.ui.m_infoList:setContentSize(cc.size(listSize.width, listSize.height + addHeight))
        self.m_tableView = cc.TableView:create(self.ui.m_infoList:getContentSize())
        self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
        self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
        self.m_tableView:setAnchorPoint(ccp(0, 0))
        self.m_tableView:setDelegate()
        self.m_tableView:registerScriptHandler(function(tab) return self:scrollViewDidScroll(tab) end, cc.SCROLLVIEW_SCRIPT_SCROLL)
        self.m_tableView:registerScriptHandler(function(tab, idx) return self:cellSizeForTable(tab, idx) end, cc.TABLECELL_SIZE_FOR_INDEX)
        self.m_tableView:registerScriptHandler(function(tab, idx) return self:tableCellAtIndex(tab, idx) end, cc.TABLECELL_SIZE_AT_INDEX)
        self.m_tableView:registerScriptHandler(function(tab) return self:numberOfCellsInTableView(tab) end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
        self.ui.m_infoList:addChild(self.m_tableView)

        if CCLoadSprite:call("loadDynamicResourceByName", "manual") then
            local newBg = CCLoadSprite:call("createSprite", "manual_dragon.png")
            local size = self.ui.m_dragonBg:getContentSize()
            local clipNode = CCClipNode:call("create", size.width, size.height)
            clipNode:setAnchorPoint(ccp(0, 0))
            clipNode:setPosition(0, 0)
            self.ui.m_dragonBg:addChild(clipNode)
            clipNode:addChild(newBg)
            newBg:setPosition(size.width / 2, size.height / 2 - 37)
        end

        self.ui.m_tipTxt:setString(getLang("9201242"))
        self.ui.m_timeTip:setString(getLang("140361"))

        self.roomCells = {}

        CCCommonUtilsForLua:setButtonTitle(self.ui.m_sureBtn, getLang("confirm"))

        self.ui.m_sureBtn:setEnabled(false)

        local area_info = self.ctrl:getAreaInfo()
        for k, v in ipairs4ScatteredT(area_info) do
            table.insert(self.areaInfo, v)
        end

        self.selectZone = ""
        self.m_tableView:reloadData()

        return true
    end

    return false
end

function DragonWorldCupSelectZoneView:confirmBack()
    PopupViewController:call("goBackPopupView")
end

function DragonWorldCupSelectZoneView:onEnter()
    self:setTitleName(getLang("9201245"))
    local function callback2() self:confirmBack() end
    local handler2 = self:registerHandler(callback2)
    CCSafeNotificationCenter:registerScriptObserver(self, handler2, "msg.worldcup.signup")
end

function DragonWorldCupSelectZoneView:onExit()
    CCSafeNotificationCenter:unregisterScriptObserver(self, "msg.worldcup.signup")
end

function DragonWorldCupSelectZoneView:scrollViewDidScroll(tab)
    local mindy = self.m_tableView:minContainerOffset().y
    local dy = self.m_tableView:getContentOffset().y
    if dy < mindy then
        self.m_tableView:setContentOffset(ccp(0, mindy))
    end
end

function DragonWorldCupSelectZoneView:cellSizeForTable(tab, idx)
    return 640, 130
end

function DragonWorldCupSelectZoneView:tableCellAtIndex(tab, idx)
    local worldcupInfo = self.ctrl.getWorldCupData()

    local node = Drequire("game.dragonWorldCup.DragonWorldCupSelectZoneCell"):create(self.areaInfo[idx + 1], worldcupInfo.zone, self)
    node:setTag(666)
    
    self.roomCells[idx + 1] = node

    local cell = cc.TableViewCell:create()
    cell:addChild(node)
    return cell
end

function DragonWorldCupSelectZoneView:numberOfCellsInTableView(tab)
    return type(self.areaInfo) == "table" and #self.areaInfo or 0
end

function DragonWorldCupSelectZoneView:clickSelect(zone)
    for _, room in ipairs(self.roomCells) do
        if room.zone == zone then
            self.selectZone = zone
        end
        room:updateCellSelectState(room.zone == zone)
    end
end

function DragonWorldCupSelectZoneView:updateSureBtnState()
    self.ui.m_sureBtn:setEnabled(true)
end

function DragonWorldCupSelectZoneView:onSureClick()
    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
    if playerInfo:call("isInAlliance") then
        local allianceInfo = playerInfo:getProperty("allianceInfo")
        local rank = allianceInfo:getProperty("rank")
        if rank < 4 then
            YesNoDialog:show(getLang("E100119"))
            return
        end
    end

    local function confirmCallback()
        local worldcupInfo = self.ctrl.getWorldCupData()
        if worldcupInfo.applyState then
            local reApplyCmd = Drequire("game.command.DragonWorldCupReApplyCmd").create(self.selectZone)
            reApplyCmd:send()
        else
            local signUpCommand = Drequire("game.command.DragonWorldCupSignUpCmd").create(self.selectZone)
            signUpCommand:send()
        end
    end

    --确认报名dialog
    local dialog = YesNoDialog:show(getLang("9201250"), confirmCallback)
    dialog:call("setYesButtonTitle", getLang("5200020"))
end

return DragonWorldCupSelectZoneView