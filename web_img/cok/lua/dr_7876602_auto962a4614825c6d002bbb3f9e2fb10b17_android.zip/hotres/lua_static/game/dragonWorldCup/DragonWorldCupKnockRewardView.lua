local DragonWorldCupKnockRewardView = class("DragonWorldCupKnockRewardView",
	function()
		return PopupBaseView:create()
	end
)
DragonWorldCupKnockRewardView.__index = DragonWorldCupKnockRewardView

local DragonWorldCupKnockPrizeCell = class("DragonWorldCupKnockPrizeCell",
	function()
		return cc.Node:create()
	end
)
DragonWorldCupKnockPrizeCell.__index = DragonWorldCupKnockPrizeCell

local dragonWorldCupManager = require("game.dragonWorldCup.DragonWorldCupManager")

function DragonWorldCupKnockRewardView:create(playOff)
	local view = DragonWorldCupKnockRewardView.new()
	Drequire("game.dragonWorldCup.DragonWorldCupKnockRewardView_ui"):create(view, 0)
	if view:initView(playOff) then
		return view
	end
end

function DragonWorldCupKnockRewardView:initView(playOff)
	if self:init(true, 0) then
		self:setHDPanelFlag(true)

		CCLoadSprite:call("doResourceByCommonIndex", 512, true)
		self.playOff = playOff

		if CCCommonUtilsForLua:isIosAndroidPad() then
			self.ui.m_topNode:setScale(2.4)
		end

		local ccbSize = self.ui.nodeccb:getContentSize()
		self:setContentSize(ccbSize)

		local dh = self:call("getExtendHeight")
		local nodeSize = self.ui.m_infoList:getContentSize()
		self.ui.m_infoList:setContentSize(cc.size(nodeSize.width, nodeSize.height + dh))

		self.scrollView = CCScrollView:create(self.ui.m_infoList:getContentSize())
		self.scrollView:setDirection(kCCScrollViewDirectionVertical)
		self.ui.m_infoList:addChild(self.scrollView, 100)
		self.ui.m_infoList:setPositionY(self.ui.m_infoList:getPositionY() - dh)

		self.scrollLayer = cc.Node:create()
		self.scrollView:setContainer(self.scrollLayer)

		if self.playOff then
			self.ui.m_playoffTitle:setString(getLang("140327"))
		else
			self.ui.m_playoffTitle:setString(getLang("5200128"))
		end
		GameController:call("showWaitInterface")

		if self.playOff then
			local rewardCommand = require("game.command.DragonworldCupPlayOffRewardCmd").create()
			rewardCommand:send()
		else
			local rewardCommand = require("game.command.DragonWorldCupChampionRewardCmd").create()
			rewardCommand:send()
		end
		
		--self:getPrizeDataBack()

		return true
	end

	return false
end

function DragonWorldCupKnockRewardView:getTestData()
	
end

function DragonWorldCupKnockRewardView:onEnter()
	self:setTitleName(getLang("5200016"))
	local function callback1() self:getPrizeDataBack() end
	local handler1 = self:registerHandler(callback1)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "dragon.worldcup.champion.reward")
end

function DragonWorldCupKnockRewardView:onExit()
	GameController:call("removeWaitInterface")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "dragon.worldcup.champion.reward")
end

function DragonWorldCupKnockRewardView:getPrizeDataBack()
	GameController:call("removeWaitInterface")

	if self.playOff then
		self.reward = dragonWorldCupManager.getPlayOffRewardData()
	else
		self.reward = dragonWorldCupManager.getChampionRewardData()
	end
	--self:getTestData()
	self.reward = self.reward.award

	local function sort(reward1, reward2)
		if reward1.round > reward2.round then
			return not self.playOff and true or false
		end
	end
	table.sort(self.reward, sort)
	--dump(self.reward, "DragonWorldCupKnockRewardView reward")
	if sizen(self.reward) == 0 then return end
	self:updateScrollView(self.reward)
end

function DragonWorldCupKnockRewardView:updateScrollView(data)
	self.scrollLayer:removeAllChildren()
	if data == nil then return end

	local rewardHeight = 0
	local count = #data
	for index = count, 1, -1 do
		local cell = DragonWorldCupKnockPrizeCell:create(data[index], self.playOff)
		self.scrollLayer:addChild(cell)
		cell:setPosition(ccp(23, rewardHeight + 8))
		rewardHeight = rewardHeight + cell:getContentSize().height + 8
	end

	local cellWidth = 598
	local viewSize = self.scrollView:getViewSize()
	self.scrollLayer:setContentSize(cc.size(598, rewardHeight + 10))
	self.scrollLayer:setPosition(ccp(0, viewSize.height - rewardHeight - 10))
	self.scrollView:updateInset()
end


-------------------------DragonWorldCupKnockPrizeCell-------------------------
function DragonWorldCupKnockPrizeCell:create(data, playOff)
	local node = DragonWorldCupKnockPrizeCell.new()
	if node:initNode(data, playOff) then
		return node
	end
end

function DragonWorldCupKnockPrizeCell:initNode(data, playOff)
	local cellHeight = 90
	local cellWidth = 600
	local cury = 0

	local node = cc.Node:create()
	if data.reward then	
		local count = #data.reward
		for index = 1, count, 1 do
			local reward = data.reward[index]
			cury = cury - cellHeight * 1.2
			local cell = require("game.dragonWorldCup.DragonWorldCupRewardCell"):create(reward)
			cell:setPosition(ccp(15, cury))
			cell:setScale(1.2)
			cell:setLabelColor(120, 97, 67)
			node:addChild(cell)
		end
	end

	node:setPosition(0, 20 + math.abs(cury))
	self:addChild(node)

	local bgTitle = CCLoadSprite:call("createScale9Sprite", "jlzy_xx_bg_1.png")
	self:addChild(bgTitle)
	bgTitle:setContentSize(cc.size(cellWidth - 2, 36))
	self:setContentSize(cc.size(cellWidth, math.abs(cury) + 56))
	bgTitle:setPosition(ccp(cellWidth / 2, math.abs(cury) + 33))


	local strRank = ""
	if tonumber(data.round) == 1 and playOff then
		strRank = getLang("140254")
	elseif tonumber(data.round) == 2 and playOff then
		strRank = getLang("140255")
	else
		strRank = getLang("140268", tostring(data.round))
	end

	local label = cc.Label:createWithSystemFont(strRank, "Helvetica", 20)
	label:setAnchorPoint(ccp(0, 0.5))
	bgTitle:addChild(label)
	label:setPosition(ccp(30, bgTitle:getContentSize().height / 2))
	label:setColor(cc.c3b(203, 139, 116))

	local spPoint = CCLoadSprite:call("createSprite", "jlzy_xx_dian.png")
	bgTitle:addChild(spPoint)
	spPoint:setPosition(ccp(10, bgTitle:getContentSize().height / 2))

	local bg = CCLoadSprite:call("createScale9Sprite", "jlzy_xx_bg.png")
	bg:setContentSize(self:getContentSize())
	self:addChild(bg, -1)
	bg:setAnchorPoint(ccp(0, 0))

	return true
end
-------------------------DragonWorldCupKnockPrizeCell-------------------------

return DragonWorldCupKnockRewardView
