----------------------------
-- Author: Elex
-- Date: 2017-06-14 21:02:40
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local DragonWorldCupRankView_ui = class("DragonWorldCupRankView_ui")

--#ui propertys


--#function
function DragonWorldCupRankView_ui:create(owner, viewType)
	local ret = DragonWorldCupRankView_ui.new()
	CustomUtility:DoRes(500, true)
	CustomUtility:DoRes(7, true)
	CustomUtility:LoadUi("DragonWorldCupRankView.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function DragonWorldCupRankView_ui:initLang()
end

function DragonWorldCupRankView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function DragonWorldCupRankView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function DragonWorldCupRankView_ui:onRewardClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onRewardClick", pSender, event)
end

return DragonWorldCupRankView_ui

