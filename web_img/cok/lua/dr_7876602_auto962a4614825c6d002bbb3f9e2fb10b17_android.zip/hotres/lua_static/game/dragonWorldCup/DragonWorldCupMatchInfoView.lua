local DragonWorldCupMatchInfoView = class("DragonWorldCupMatchInfoView",
	function()
		return PopupBaseView:create()
	end
)
DragonWorldCupMatchInfoView.__index = DragonWorldCupMatchInfoView

local dragonWorldCupManager = require("game.dragonWorldCup.DragonWorldCupManager")

function DragonWorldCupMatchInfoView:create()
	local view = DragonWorldCupMatchInfoView.new()
	Drequire("game.dragonWorldCup.DragonWorldCupMatchInfoView_ui"):create(view)
	if view:initView() then
		return view
	end
end

function DragonWorldCupMatchInfoView:initView()
	if self:init(true, 0) then

		self:setHDPanelFlag(true)

		if CCCommonUtilsForLua:isIosAndroidPad() then
			self.ui.nodeccb:setScale(2)
		end

		CCLoadSprite:call("doResourceByCommonIndex", 205, true)
		CCLoadSprite:call("doResourceByCommonIndex", 208, true)

		local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
		local selfAllianceId = playerInfo:call("getAllianceId")
		local getMatchInfoCmd = require("game.command.DragonWorldCupMatchInfoCmd").create(selfAllianceId)
		getMatchInfoCmd:send()
		MyPrint("DragonWorldCupMatchInfoView scale", self:getScale())

		self.ui.m_infoTxt:setString(getLang("140021"))

		local touchLayer = cc.Layer:create()
		self:addChild(touchLayer)

		local function touchHandle( eventType, x, y )
			-- print("touchHandle", eventType, x, y)
			if eventType == "began" then
				return self:onTouchBegan(x, y)
			elseif eventType == "moved" then
			
			else
				self:onTouchEnded(x, y)
			end
		end
		touchLayer:registerScriptTouchHandler(touchHandle)
		touchLayer:setTouchEnabled(true)
		touchLayer:setSwallowsTouches(false)

		return true
	end

	return false
end

function DragonWorldCupMatchInfoView:onTouchBegan(x, y)
	self.startPoint = ccp(x, y)
	return true
end

function DragonWorldCupMatchInfoView:onTouchEnded(x, y)
	if ccpDistance(self.startPoint, ccp(x, y)) > 30 then return end

	if not isTouchInside(self.ui.m_clickArea, x, y) then
		PopupViewController:call("removePopupView", self)
	end
end

function DragonWorldCupMatchInfoView:onEnterFrame()
	if self.matchInfo == nil then return end
	if self.matchInfo.battleBeginTime == nil then return end

	local now = LuaController:call("getTimeStamp")
	local remain = self.matchInfo.battleBeginTime - now
	remain = remain <= 0 and 0 or remain
	if remain == 0 then
		self.ui.m_timeTxt:setString("")
	else
		self.ui.m_timeTxt:setString(getLang("140022", format_time(remain)))
	end
end

function DragonWorldCupMatchInfoView:scheduleUpdate()
    local function updatefunc(dt) self:onEnterFrame(dt) end 
    self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(updatefunc, 1.0, false)
end

function DragonWorldCupMatchInfoView:unscheduleUpdate()
    if self.entry then
        cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
        self.entry = nil
    end
end

function DragonWorldCupMatchInfoView:refreshView()
	self.matchInfo = dragonWorldCupManager.getMatchData()

	local zone = self.matchInfo.zone
	local abbr = self.matchInfo.abbr
	local name = self.matchInfo.name
	local leader = self.matchInfo.leader
	local kingName = self.matchInfo.kingdomName
	local icon = (self.matchInfo.icon == "") and "Allance_flay" or self.matchInfo.icon
	local rank = tonumber(self.matchInfo.rank)
	local points = self.matchInfo.points
	local kingdom = self.matchInfo.kingdom
	local kingdomName = self.matchInfo.kingdomName
	local winRate = self.matchInfo.winRate
	local country = self.matchInfo.country 

	local allianceStr = name .. "(" .. abbr .. ")" 
	local kingdomStr = kingdomName
	local winStr = winRate .. "%"

	local zoneName = getLang(dragonWorldCupManager.getZoneName(zone))

	self.ui.m_allianceNameTxt:setString(name)
	self.ui.m_kingdomTxt:setString(getLang("140031", kingdomStr))

	if rank == 0 then
		self.ui.m_rankTxt:setString(getLang("140023", "10000+"))
	else
		self.ui.m_rankTxt:setString(getLang("140023", CC_CMDITOA(rank)))
	end
	
	self.ui.m_winTxt:setString(getLang("140033", winStr))
	self.ui.m_leaderTxt:setString(getLang("115015", leader))
	self.ui.m_allianceTxt:setString(getLang("108596", allianceStr))
	self.ui.m_scoreTxt:setString(getLang("103010") .. tostring(points))
	self.ui.m_areaTxt:setString(getLang("5200115", zoneName))

	self.ui.m_flagNode:removeAllChildren()

	local flag = AllianceFlagPar:call("create", icon .. ".png")
	flag = tolua.cast(flag, "cc.Node")
	--flag:setScale(0.6)
	self.ui.m_flagNode:addChild(flag)

	if DynamicResourceController2:call("checkDynamicResource", "dragonGlobal") 
			and CCLoadSprite:call("loadDynamicResourceByName", "dragonGlobal") then
		local miniTag = dragonWorldCupManager.getCountryIcon(country)
		local countryFlag = CCLoadSprite:call("createSprite", miniTag)
		self.ui.m_countryNode:addChild(countryFlag)
		self.ui.m_countryNode:setScale(1.0)
	else
		local countryFlag = CCLoadSprite:call("createSprite", country .. ".png", CCLoadSpriteType.CCLoadSpriteType_COUNTRY_ICON)
		self.ui.m_countryNode:addChild(countryFlag)
	end
end

function DragonWorldCupMatchInfoView:onEnter()
	self:scheduleUpdate()
	local function callback1() self:refreshView() end
	local handler1 = self:registerHandler(callback1)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "dragon.worldcup.matchInfo.back")
end

function DragonWorldCupMatchInfoView:onExit()
	self:unscheduleUpdate()
	CCSafeNotificationCenter:unregisterScriptObserver(self, "dragon.worldcup.matchInfo.back")
end

return DragonWorldCupMatchInfoView
