----------------------------
-- Author: Elex
-- Date: 2017-06-08 22:47:21
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local DragonWorldCupRewardCell_ui = class("DragonWorldCupRewardCell_ui")

--#ui propertys


--#function
function DragonWorldCupRewardCell_ui:create(owner, viewType)
	local ret = DragonWorldCupRewardCell_ui.new()
	CustomUtility:LoadUi("DragonWorldCupRewardCell.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function DragonWorldCupRewardCell_ui:initLang()
end

function DragonWorldCupRewardCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function DragonWorldCupRewardCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return DragonWorldCupRewardCell_ui

