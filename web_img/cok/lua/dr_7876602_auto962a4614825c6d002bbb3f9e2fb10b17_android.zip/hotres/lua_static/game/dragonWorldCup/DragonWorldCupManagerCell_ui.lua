----------------------------
-- Author: Elex
-- Date: 2017-05-30 01:38:15
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local DragonWorldCupManagerCell_ui = class("DragonWorldCupManagerCell_ui")

--#ui propertys


--#function
function DragonWorldCupManagerCell_ui:create(owner, viewType)
	local ret = DragonWorldCupManagerCell_ui.new()
	CustomUtility:DoRes(7, true)
	CustomUtility:LoadUi("DragonWorldCupManagerCell.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function DragonWorldCupManagerCell_ui:initLang()
end

function DragonWorldCupManagerCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function DragonWorldCupManagerCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function DragonWorldCupManagerCell_ui:onBattleBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBattleBtnClick", pSender, event)
end

function DragonWorldCupManagerCell_ui:onCancelBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onCancelBtnClick", pSender, event)
end

return DragonWorldCupManagerCell_ui

