local DragonWorldCupVictoryView = class("DragonWorldCupVictoryView",
	function()
		return PopupBaseView:create()
	end
)

local dragonWorldCupManager = require("game.dragonWorldCup.DragonWorldCupManager")

function DragonWorldCupVictoryView:create(marchData)
	local view = DragonWorldCupVictoryView.new()
	if view:initView(marchData) then
		return view
	end
end

function DragonWorldCupVictoryView:initView(marchData)
	if self:init(true, 0) then
		self:setIsHDPanel(true)
		self.padLike = CCCommonUtilsForLua:isIosAndroidPad()
		if self.padLike then self:setScale(2.4) end

		self.marchData = marchData
		--dump(self.marchData, "marchData")
		self.isWin = (marchData.isWin == "true" or marchData.isWin == "1")
		
		local success = self:addParticle()
		self:createResultView()
		if not success then self:showResultView() end

		return true
	end

	return false
end

function DragonWorldCupVictoryView:addParticle()
	self.effectNode = cc.Node:create()
	self:addChild(self.effectNode)

	local winSize = self.padLike and cc.size(640, 852) or cc.Director:sharedDirector():getIFWinSize()

	local localPath = CCFileUtils:sharedFileUtils():getWritablePath() .. "dresource/"
	local jsonPath = localPath .. "dragonUpDown.json"
	local atlasPath = localPath .. "dragonUpDown.atlas"

	if (CCFileUtils:sharedFileUtils():isFileExist(jsonPath) and CCFileUtils:sharedFileUtils():isFileExist(atlasPath)) then
		local aniObj = IFSkeletonAnimation:call("create", jsonPath, atlasPath)
		aniObj:setToSetupPose()

		local aniName = self.isWin and "bian1" or "bian2"
		aniObj:setAnimation(0, aniName, true)

		aniObj:setPosition(winSize.width / 2, winSize.height / 2) 
		self:addChild(aniObj)
	end

	local num = self.isWin and 3 or 2
	local prefix = self.isWin and "dragonBattleWin" or "dragonBattleLost"
	for index = 1, num do
		local par = ParticleController:call("createParticle", prefix .. index)
		par:setPosition(winSize.width / 2, winSize.height / 2)
		par:setScale(1.1)
		self.effectNode:addChild(par)
	end

	
	local jsonPath = localPath .. "dragonVictory.json"
	local atlasPath = localPath .. "dragonVictory.atlas"

	if (CCFileUtils:sharedFileUtils():isFileExist(jsonPath) and CCFileUtils:sharedFileUtils():isFileExist(atlasPath)) then
		local aniObj = IFSkeletonAnimation:call("create", jsonPath, atlasPath)
		aniObj:setToSetupPose()

		local aniName = self.isWin and "WIN_" or "LOST_"
		aniObj:setAnimation(0, aniName, true)
		aniObj:setPosition(winSize.width / 2, winSize.height / 2)

		local function complete() self:showResultView() end
		aniObj:registerSpineEventHandler(complete, spEventType.SP_ANIMATION_COMPLETE)
		self.effectNode:addChild(aniObj)

		return true
	else
		return false
	end
end

function DragonWorldCupVictoryView:showResultView()
	MyPrint("showResultView")

	self.viewNode:setVisible(true)

	local childTable = self.viewNode:getChildren()
	for index = 1, #childTable do
		local node = childTable[index]
		if (node) then
			node:setOpacity(0)
			local fadeIn = cc.FadeIn:create(1.5)
			node:runAction(fadeIn)
		end
	end

	self.effectNode:removeFromParent()
end

function DragonWorldCupVictoryView:createResultView()
	self.viewNode = cc.Node:create()
	self:addChild(self.viewNode)

	local winSize = self.padLike and cc.size(640, 852) or cc.Director:sharedDirector():getIFWinSize()

	CCLoadSprite:call("doResourceByCommonIndex", 505, true)
	self.confirmBtn = cc.ControlButton:create(getLang("confirm"), "", 22)
	self.confirmBtn:setPreferredSize(cc.size(244, 68))
	self.confirmBtn:setEnabled(true)
	CCCommonUtilsForLua:call("setButtonSprite", self.confirmBtn, "daily-btch.png")
	self.confirmBtn:addHandleOfControlEvent(
		function(eventName,sender)
        	self:leaveDragonBattle()
        end, 
    CCControlEventTouchUpInside)
    self.confirmBtn:setPosition(winSize.width / 2, winSize.height / 2 - 150)
    self.viewNode:addChild(self.confirmBtn)

    self.descLabel = cc.Label:create()
    self.descLabel:setSystemFontSize(22)
    self.descLabel:setPosition(winSize.width / 2, winSize.height / 2 + 50)
    self.descLabel:setColor(cc.c3b(230, 160, 88))
 	self.descLabel:setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    self.descLabel:setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
    self.descLabel:setDimensions(450, 0)
    self.descLabel:setString(getLang("5200141", self.marchData.score or "-1", self.marchData.teamScore or "-1"))
    self.viewNode:addChild(self.descLabel)


    local prefix = self.isWin and "jlzy_sl_" or "jlzy_sb_"
    CCLoadSprite:call("doResourceByCommonIndex", 512, true)
    for index = 1, 2 do
    	local path = prefix .. index .. ".png"
    	local icon = CCLoadSprite:call("createSprite", path)
    	icon:setPosition(winSize.width / 2, winSize.height / 2 + 300)
    	self.viewNode:addChild(icon)
    end 

    if self.isWin then
	    local parPrefix = "DragonBattleRewards_win_"
	    for index = 1, 2 do
	    	local par = ParticleController:call("createParticle", parPrefix .. (index - 1))
	    	par:setPosition(winSize.width / 2, winSize.height / 2 + 300)
	    	self.viewNode:addChild(par)
	    end
	else
		local par = ParticleController:call("createParticle", "DragonBattleRewards_lost")
    	par:setPosition(winSize.width / 2, winSize.height / 2 + 300)
    	self.viewNode:addChild(par)
	end

    self.viewNode:setVisible(false)
end

function DragonWorldCupVictoryView:leaveDragonBattle()
	--PopupViewController:call("removePopupView", self)
	if (self.m_waitInterface) then
		self.m_waitInterface:call("remove")
		self.m_waitInterface = nil
	end

	self.m_waitInterface = GameController:call("showWaitInterface1", self.confirmBtn)
	dragonWorldCupManager.leaveBattle()
end

return DragonWorldCupVictoryView