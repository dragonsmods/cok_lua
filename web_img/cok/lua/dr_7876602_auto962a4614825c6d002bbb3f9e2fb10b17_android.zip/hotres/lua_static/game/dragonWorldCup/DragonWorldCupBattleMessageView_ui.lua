----------------------------
-- Author: Elex
-- Date: 2017-06-09 11:32:40
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local DragonWorldCupBattleMessageView_ui = class("DragonWorldCupBattleMessageView_ui")

--#ui propertys


--#function
function DragonWorldCupBattleMessageView_ui:create(owner, viewType)
	local ret = DragonWorldCupBattleMessageView_ui.new()
	CustomUtility:DoRes(513, true)
	CustomUtility:DoRes(515, true)
	CustomUtility:LoadUi("DragonWorldCupBattleMessageView.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function DragonWorldCupBattleMessageView_ui:initLang()
end

function DragonWorldCupBattleMessageView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function DragonWorldCupBattleMessageView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function DragonWorldCupBattleMessageView_ui:onLeftTime1(pSender, event)
	ButtonSmoker:forwardFunction(self, "onLeftTime1", pSender, event)
end

function DragonWorldCupBattleMessageView_ui:onRightTime1(pSender, event)
	ButtonSmoker:forwardFunction(self, "onRightTime1", pSender, event)
end

function DragonWorldCupBattleMessageView_ui:onLeftTime2(pSender, event)
	ButtonSmoker:forwardFunction(self, "onLeftTime2", pSender, event)
end

function DragonWorldCupBattleMessageView_ui:onRightTime2(pSender, event)
	ButtonSmoker:forwardFunction(self, "onRightTime2", pSender, event)
end

function DragonWorldCupBattleMessageView_ui:onLeftTime3(pSender, event)
	ButtonSmoker:forwardFunction(self, "onLeftTime3", pSender, event)
end

function DragonWorldCupBattleMessageView_ui:onRightTime3(pSender, event)
	ButtonSmoker:forwardFunction(self, "onRightTime3", pSender, event)
end

return DragonWorldCupBattleMessageView_ui

