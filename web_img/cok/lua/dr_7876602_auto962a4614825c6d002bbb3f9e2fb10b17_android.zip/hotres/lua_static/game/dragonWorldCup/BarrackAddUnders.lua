local BarrackAddUnders = class("BarrackAddUnders", cc.Layer)

function BarrackAddUnders:ctor(cityInfo, luaMap )
    local frame = cc.SpriteFrameCache:getInstance():getSpriteFrame("dragon_b130.png")
    if frame then
        local icon = cc.Sprite:createWithSpriteFrame(frame)
        icon:setPositionY(68)
        self:addChild(icon)
    else
        local icon = CCLoadSprite:call("createSprite", "1800.png")
        icon:setPositionY(100)
        self:addChild(icon)
    end
end

function addBarrackAddUnders( index )
	local world = WorldMapView:call("instance")
    if nil == world then
        return nil
    end
    local cityInfo = WorldController:call("getCityInfoByIndex", index)
    if nil == cityInfo then
        return nil
    end
    if cityInfo:getProperty("luaType") ~= WorldCityType.barracks_new then
        return nil
    end
    local luaMap = cityInfo:call("getLuaMap")
    local pos = cityInfo:call("GetPositionInMap")
    local ret = CCArray:create()
    local under = BarrackAddUnders.new(cityInfo,luaMap )
    under:setTag(index)
    under:setPosition(cc.p(pos.x, pos.y))
    ret:addObject(under)
    world:call("getCityBatchNode"):addChild(under, index)

    -- 添加文本
    local labelBatch = WorldMapView:call("getUnBatchLabelNode")
    if labelBatch then
        local nameBgPic = "name_bg.png"
        local nameBg = CCLoadSprite:call("createSprite", nameBgPic)
        nameBg:setPosition(cc.p(0, -50))
        nameBg:setScaleX(1.2)
        under:addChild(nameBg)

        local nameLabel = cc.Label:createWithSystemFont(getLang("9201271"), "Helvetica", 18, cc.size(0.0,0))
        nameLabel:setColor(cc.c3b(242, 237, 222))
        nameLabel:setAnchorPoint(cc.p(0.5, 0.5))
        labelBatch:addChild(nameLabel, index)
        nameLabel:setPosition(pos.x, pos.y - 50)
        ret:addObject(nameLabel)
    end

    return ret
end

return BarrackAddUnders