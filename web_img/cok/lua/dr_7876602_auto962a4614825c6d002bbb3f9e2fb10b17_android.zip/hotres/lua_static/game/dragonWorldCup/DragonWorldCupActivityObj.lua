

local DragonWorldCupActivityObj = class("DragonWorldCupActivityObj", function (	)
	return ActivityEventObjForLua:call("create")
end)

local dragonWorldCupManager = require("game.dragonWorldCup.DragonWorldCupManager")

function DragonWorldCupActivityObj.create( params )
	MyPrint("DragonWorldCupActivityObj.create")
	local ret = DragonWorldCupActivityObj.new()
	if ret:init(params) == false then
		ret = nil
	end
	return ret
end

-- 可重载
function DragonWorldCupActivityObj:parse( params )
	MyPrint("ActivityEventObjForLua:parse")
	ActivityEventObjForLua.parse(self, params)
end

function DragonWorldCupActivityObj:getCurActivityStageAndLeftTime( )
	--MyPrint("DragonWorldCupActivityObj:getCurActivityStageAndLeftTime")
	return ActivityStage.ActivityStage_Running, -1
end

function DragonWorldCupActivityObj:getGameTickStr( )
	local worldCupData = dragonWorldCupManager.getWorldCupData()
	if sizen(worldCupData) == 0 then return "" end

	local now = LuaController:call("getTimeStamp")
	local applyStartTime = worldCupData.applyStartTime or 0
	local applyEndTime = worldCupData.applyEndTime or 0
	local matchStartTime = worldCupData.matchStartTime or 0
	local battleBeginTime = worldCupData.battleBeginTime or 0
	local battleEndTime = worldCupData.battleEndTime or 0
	local applyState = worldCupData.applyState
	local seasonOver = worldCupData.seasonOver
	--MyPrint("now, applyStartTime, applyEndTime, matchStartTime, battleBeginTime, battleEndTime", now, applyStartTime, applyEndTime, matchStartTime, battleBeginTime, battleEndTime)
	if seasonOver then
		return getLang("140225")
	elseif (applyStartTime > 0 and now < applyStartTime) then
		local left = applyStartTime - now 
		return getLang("140162", format_time(left))
	elseif (applyEndTime > 0 and now < applyEndTime) then
		local left = applyEndTime - now
		return getLang("140163", format_time(left))
	elseif (matchStartTime > 0 and now < matchStartTime and applyState) then
		local left = matchStartTime - now
		return getLang("140275", format_time(left))
	elseif (battleBeginTime > 0 and now < battleBeginTime and applyState) then
		local left = battleBeginTime - now
		return getLang("140276", format_time(left))
	elseif (battleEndTime > 0 and now < battleEndTime and applyState) then
		local left = battleEndTime - now
		return getLang("140093", format_time(left))
	else
		return ""
	end
end

function DragonWorldCupActivityObj:requestActivityDetail()
	if CCCommonUtilsForLua:isFunOpenByKey("wag_switch") then 
		dragonWorldCupManager.requestActivityData()
	end
end

return DragonWorldCupActivityObj