local DragonWorldCupAllianceMessageView = class("DragonWorldCupAllianceMessageView",
	function()
		return PopupBaseView:create()
	end
)
DragonWorldCupAllianceMessageView.__index = DragonWorldCupAllianceMessageView

local DragonWorldCupAllianceCell = class("DragonWorldCupAllianceCell",
	function()
		return cc.Layer:create()
	end
)
DragonWorldCupAllianceCell.__index = DragonWorldCupAllianceCell

local TOP_HEIGHT = 75
local TOP_HEIGHT_HD = 154

local dragonWorldCupManager = require("game.dragonWorldCup.DragonWorldCupManager")

function DragonWorldCupAllianceMessageView:create(allianceId)
	local view = DragonWorldCupAllianceMessageView.new()
	Drequire("game.dragonWorldCup.DragonWorldCupAllianceMessageView_ui"):create(view, 0)
	if view:initView(allianceId) then
		return view
	end
end

function DragonWorldCupAllianceMessageView:initView(allianceId)
	if self:init(true, 0) then
		self:setIsHDPanel(true)

		if CCCommonUtilsForLua:isIosAndroidPad() then
			self.ui.m_topNode:setScale(2.4)
		end

		CCLoadSprite:call("doResourceByCommonIndex", 205, true)
		CCLoadSprite:call("doResourceByCommonIndex", 208, true)

		local addHeight = self:call("getExtendHeight")
		local listSize = self.ui.m_listNode:getContentSize()
		self.ui.m_listNode:setContentSize(cc.size(listSize.width, listSize.height + addHeight))
		self.ui.m_listNode:setPositionY(self.ui.m_listNode:getPositionY()) 

		self.scrollView = CCScrollView:create(self.ui.m_listNode:getContentSize())
		self.scrollView:setDirection(kCCScrollViewDirectionVertical)
		self.ui.m_listNode:getParent():addChild(self.scrollView, 100)

		self.scrollLayer = cc.Node:create()
		self.scrollView:setContainer(self.scrollLayer)

		local x, y = self.ui.m_listNode:getPosition()
		self.scrollView:setPosition(ccp(x, y - addHeight - 15))

		self.allianceId = allianceId

		local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
		local selfAllianceId = playerInfo:call("getAllianceId")
		self.isMyTeam = (selfAllianceId == allianceId)
		GameController:call("showWaitInterface")

		MyPrint("selfAllianceId", selfAllianceId, allianceId, self.isMyTeam)

		local cmd = require("game.command.DragonWorldCupChampionDetailCmd").create(allianceId)
		cmd:send()
		--self:refreshView()

		return true
	end

	return false
end

function DragonWorldCupAllianceMessageView:getTestData()
	
end

function DragonWorldCupAllianceMessageView:onEnter()
	local function callback1() self:refreshView() end
	--local function callback2(pStr) self:cellClick(pStr) end
	local handler1 = self:registerHandler(callback1)
	--local handler2 = self:registerHandler(callback2)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "dragon.worldcup.championDetail.back")
	--CCSafeNotificationCenter:registerScriptObserver(self, handler2, "dragon.worldcup.rank.click") 
end

function DragonWorldCupAllianceMessageView:onExit()
	CCSafeNotificationCenter:unregisterScriptObserver(self, "dragon.worldcup.championDetail.back")
end

function DragonWorldCupAllianceMessageView:refreshView()
	self.detail = dragonWorldCupManager.getChampionDetailData()
	--self:getTestData()
	dump(self.detail, "self.detail")
	if sizen(self.detail) == 0 then return end

	local info = self.detail
	local enemy = self.detail.enemy
	local height = 0

	for index = 1, #enemy do
		local enemyInfo = enemy[index]
		local cell = DragonWorldCupAllianceCell:create(info, enemyInfo, self.isMyTeam)
		self.scrollLayer:addChild(cell)
		cell:setPosition(ccp(0, height))
		height = height + cell:getContentSize().height
	end

	local viewHeight = self.scrollView:getViewSize().height
	self.scrollLayer:setContentSize(cc.size(640, height))
	self.scrollLayer:setPosition(ccp(0, viewHeight - height))
end


----------------------DragonWorldCupAllianceCell-----------------------
function DragonWorldCupAllianceCell:create(info, enemyInfo, isMyTeam)
	local view = DragonWorldCupAllianceCell.new()
	Drequire("game.dragonWorldCup.DragonWorldCupAllianceCell_ui"):create(view, 1)
	if view:initView(info, enemyInfo, isMyTeam) then
		return view
	end
end

function DragonWorldCupAllianceCell:initView(info, enemyInfo, isMyTeam)
	local ccbSize = self.ui.nodeccb:getContentSize()
	self:setContentSize(ccbSize)

	self.info = info
	self.enemyInfo = enemyInfo
	self.isMyTeam = isMyTeam

	enemyInfo.result = tonumber(enemyInfo.result) or 0

	self.ui.m_fightNode:setVisible(enemyInfo ~= nil)
	self.ui.m_loseNode:setVisible(enemyInfo == nil)

	if enemyInfo then
		local title = getLang("140268", enemyInfo.round)
		self.ui.m_labelTitleWin:setString(title)

		if enemyInfo.result ~= 0 then
			self.ui.m_spriteWin:setVisible(enemyInfo.result == 1)
			self.ui.m_spriteLose:setVisible(enemyInfo.result ~= 1 and enemyInfo.result ~= -1)
			self.ui.m_spriteLose:setVisible(enemyInfo.result == -1)
			if enemyInfo.result == 1 then
				self:addParticleEffect()
			end
		end
		self.ui.m_loseNode:setVisible(false)

		self:setAllianceData(info, self.ui.m_labelAlaNameLeft, self.ui.m_kingNameLeft, self.ui.m_flagNodeLeft, self.ui.m_countryLeft)
		self:setAllianceData(enemyInfo, self.ui.m_labelAlaNameRight, self.ui.m_kingNameRight, self.ui.m_flagNodeRight, self.ui.m_countryRight)
	else
		local title = getLang("140268", enemyInfo.round)
		self.ui.m_labelTitleLose:setString(title)
		self.ui.m_loseDes:setString(getLang("140269"))
	end

	CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnFight, getLang("140013"))
	CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnSelectTime, getLang("140274"))

	--self:getTestData()
	self:onEnterFrame()

	return true
end

function DragonWorldCupAllianceCell:setAllianceData(info, alaNameTxt, kingNameTxt, flagNode, countryNode)
	local abbr = info.abbr
	local name = info.name 
	local allianceStr = name .. "(" .. abbr .. ")" 
	local kingdomStr = info.kingdomName

	alaNameTxt:setString(getLang("108596", allianceStr))
	kingNameTxt:setString(getLang("140031", kingdomStr))

	local icon = (info.icon == "") and "Allance_flay" or info.icon
	local flag = AllianceFlagPar:call("create", icon .. ".png")
	flag = tolua.cast(flag, "cc.Node")
	flag:setScale(0.71)
	flagNode:removeAllChildren()
	flagNode:addChild(flag)

	if DynamicResourceController2:call("checkDynamicResource", "dragonGlobal") 
			and CCLoadSprite:call("loadDynamicResourceByName", "dragonGlobal") then
		local miniTag = dragonWorldCupManager.getCountryIcon(info.country)
		local countryFlag = CCLoadSprite:call("createSprite", miniTag)
		countryNode:addChild(countryFlag)
		countryNode:setScale(1.0)
	else
		local countryFlag = CCLoadSprite:call("createSprite", info.country .. ".png", CCLoadSpriteType.CCLoadSpriteType_COUNTRY_ICON)
		countryNode:addChild(countryFlag)
	end
end

function DragonWorldCupAllianceCell:scheduleUpdate()
    local function updatefunc(dt) self:onEnterFrame(dt) end 
    self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(updatefunc, 1.0, false)
end

function DragonWorldCupAllianceCell:unscheduleUpdate()
    if self.entry then
        cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
        self.entry = nil
    end
end

function DragonWorldCupAllianceCell:addParticleEffect()
	local effect1 = ParticleController:call("createParticle", "DragonBattleRewards_win_0")
	local effect2 = ParticleController:call("createParticle", "DragonBattleRewards_win_1")
	self.ui.m_spriteWin:addChild(effect1)
	self.ui.m_spriteLose:addChild(effect2)

	local winSize = self.ui.m_spriteWin:getContentSize()
	effect1:setPosition(ccp(winSize.width / 2, winSize.height / 2))
	effect2:setPosition(ccp(winSize.width / 2, winSize.height / 2))
end

function DragonWorldCupAllianceCell:getTestData()
	-- body
	local now = LuaController:call("getTimeStamp")
	self.worldCupInfo = dragonWorldCupManager.getWorldCupData()
	self.worldCupInfo.matchStartTime = now - 7200
	self.worldCupInfo.battleBeginTime = now - 3600
	self.worldCupInfo.battleEndTime = now + 3600
	self.isMyTeam = true
end

function DragonWorldCupAllianceCell:onEnterFrame( )
	if not self.isMyTeam then return end
	self.worldCupInfo = dragonWorldCupManager.getWorldCupData()
	local matchStartTime = self.worldCupInfo.matchStartTime
	local battleStartTime = self.worldCupInfo.battleBeginTime
	local battleEndTime = self.worldCupInfo.battleEndTime

	if tonumber(self.enemyInfo.result) == 0 then
		local now = LuaController:call("getTimeStamp")
		self.ui.m_btnSelectTime:setVisible(now < matchStartTime and self.isMyTeam)
		self.ui.m_btnFight:setVisible(now > battleStartTime and now < battleEndTime and self.isMyTeam)
	end
end

function DragonWorldCupAllianceCell:onEnter()
	self:scheduleUpdate()
end

function DragonWorldCupAllianceCell:onExit()
	self:unscheduleUpdate()
end

function DragonWorldCupAllianceCell:onFightClick()
	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	local selfAllianceId = playerInfo:call("getAllianceId")
	dragonWorldCupManager.enterDragonBattle(selfAllianceId)
end

function DragonWorldCupAllianceCell:onSelectTimeClick()
	local lua_path = "game.dragonWorldCup.DragonWorldCupKPMatchView"
	package.loaded[lua_path] = nil
	local kpMatchView = require(lua_path):create()
	PopupViewController:addPopupView(kpMatchView)
end

return DragonWorldCupAllianceMessageView
