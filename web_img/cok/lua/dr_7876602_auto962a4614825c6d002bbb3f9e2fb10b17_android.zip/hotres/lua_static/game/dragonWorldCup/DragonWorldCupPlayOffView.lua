local DragonWorldCupPlayOffView = class("DragonWorldCupPlayOffView",
	function()
		return PopupBaseView:create()
	end
)
DragonWorldCupPlayOffView.__index = DragonWorldCupPlayOffView

DragonWorldCupPlayOffOwner = DragonWorldCupPlayOffOwner or {}
ccb["DragonWorldCupPlayOffOwner"] = DragonWorldCupPlayOffOwner 

local DragonWorldCupPlayOffAwardCell = class("DragonWorldCupPlayOffAwardCell",
	function()
		return cc.Layer:create()
	end
)
DragonWorldCupPlayOffAwardCell.__index = DragonWorldCupPlayOffAwardCell

local dragonWorldCupManager = require("game.dragonWorldCup.DragonWorldCupManager")

function DragonWorldCupPlayOffView:create()
	local view = DragonWorldCupPlayOffView.new()
	Drequire("game.dragonWorldCup.DragonWorldCupPlayOffView_ui"):create(view, 0)
	if view:initView() then
		return view
	end
end

function DragonWorldCupPlayOffView:initView()
	if self:init(true, 0) then
		
		self:setHDPanelFlag(true)
		self.obSwitch = CCCommonUtilsForLua:isFunOpenByKey("wag_ob")

		CCLoadSprite:call("doResourceByCommonIndex", 205, true)
		CCLoadSprite:call("doResourceByCommonIndex", 208, true)

		if CCCommonUtilsForLua:isIosAndroidPad() then
			self.ui.m_topNode:setScale(2.4)
			self.ui.m_bottomNode:setScale(2.4)

			self.ui.m_rewardNode:setVisible(false)
			self.ui.m_topNode:setPositionY(self.ui.m_topNode:getPositionY() + 25)
			self.ui.m_tipNode:setPositionY(self.ui.m_tipNode:getPositionY() + 170)
			self.ui.m_engageNode:setPositionY(self.ui.m_engageNode:getPositionY() + 220)
			self.ui.m_effectNode:setPositionY(self.ui.m_effectNode:getPositionY() + 220)
			self.ui.m_kingBg:setPositionY(self.ui.m_kingBg:getPositionY() + 30)
		end
		self.worldCupInfo = dragonWorldCupManager.getWorldCupData()
		self.playoffInfo = self.worldCupInfo.playoff
		--奖励信息
		self.rewardInfos = self.playoffInfo.reward
		--self:getTestData()

		--创建个空的tableview
	 	local addHeight = self:call("getExtendHeight")
		local listSize = self.ui.m_listNode:getContentSize()
		self.ui.m_listNode:setContentSize(cc.size(listSize.width, listSize.height))
		self.m_tableView = cc.TableView:create(self.ui.m_listNode:getContentSize())
		self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL)
		self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
		self.m_tableView:setAnchorPoint(ccp(0, 0))
		self.m_tableView:setDelegate()
		self.m_tableView:registerScriptHandler(function(tab) return self:scrollViewDidScroll(tab) end, cc.SCROLLVIEW_SCRIPT_SCROLL)
		self.m_tableView:registerScriptHandler(function(tab, idx) return self:cellSizeForTable(tab, idx) end, cc.TABLECELL_SIZE_FOR_INDEX)
		self.m_tableView:registerScriptHandler(function(tab, idx) return self:tableCellAtIndex(tab, idx) end, cc.TABLECELL_SIZE_AT_INDEX)
		self.m_tableView:registerScriptHandler(function(tab) return self:numberOfCellsInTableView(tab) end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
		self.ui.m_listNode:addChild(self.m_tableView)

		--self:runEffectAnima()
		self:addFireParticle()

		self:refreshView()
		
		local touchLayer = cc.Layer:create()
		self:addChild(touchLayer)

		local function touchHandle( eventType, x, y )
			-- print("touchHandle", eventType, x, y)
			if eventType == "began" then
				return self:onTouchBegan(x, y)
			elseif eventType == "moved" then
			
			else
				self:onTouchEnded(x, y)
			end
		end
		touchLayer:registerScriptTouchHandler(touchHandle)
		touchLayer:setTouchEnabled(true)
		touchLayer:setSwallowsTouches(false)

		self.animationCount = 0

		return true
	end

	return false 
end

function DragonWorldCupPlayOffView:getTestData()
end

function DragonWorldCupPlayOffView:setInFight()
	if self.playoffInfo == nil then return end
	if self.blue == nil then return end
	if self.red == nil then return end

	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	if not playerInfo:call("isInAlliance") then return end

	self.allianceId = playerInfo:call("getAllianceId")

	return self.blue.allianceId == self.allianceId or self.red.allianceId == self.allianceId
end

function DragonWorldCupPlayOffView:refreshView()
	--是否支付了OB票
	self.ticketPayed = (self.playoffInfo.ticketPayed ~= "0")
	--蓝方
	self.blue = self.playoffInfo.blue
	--红方
	self.red = self.playoffInfo.red
	--test
	--self:getTestData()
	--检查是否可以点赞
	self.blue.thumbUpState = self.blue.thumbUpState and self.blue.thumbUpState ~= "0"
	self.red.thumbUpState = self.red.thumbUpState and self.red.thumbUpState ~= "0"
	self.canThumbup = (self.blue.thumbUpState == false and self.red.thumbUpState == false)
	--self.canThumbup = true

	self.inFight = self:setInFight()
	
	--蓝色
	local zone = self.blue.zone
	local abbr = self.blue.abbr
	local allianceName = self.blue.allianceName
	local icon = (self.blue.icon == "") and "Allance_flay" or self.blue.icon
	--local rank = self.blue.rank
	--local points = self.blue.points
	local kingdom = self.blue.kingdom
	local kingdomName = self.blue.kingdomName
	--local winRate = self.blue.winRate
	local country = self.blue.country 
	local thumbUps = self.blue.thumbUps
	local thumbUpState = self.blue.thumbUpState
	local groupIndex = self.blue.groupIndex

	local allianceStr = allianceName .. "(" .. abbr .. ")" 
	local kingdomStr = kingdomName

	--local winStr = winRate .. "%"

	self.ui.m_leftGroupLabel:setString(getLang("5200107", string.char(65 + tonumber(groupIndex) - 1)))
	self.ui.m_leftName:setString(allianceStr)
	self.ui.m_leftKingdom:setString(getLang("140031", kingdomStr))
	--self.ui.m_rankTxt:setString(getLang("140023", CC_CMDITOA(rank)))
	--self.ui.m_winTxt:setString(getLang("140033", winStr))
	--self.ui.m_allianceTxt:setString(allianceName)
	--self.ui.m_scoreTxt:setString(getLang("103010", CC_CMDITOA(points)))
	self.ui.m_leftSupportLabel:setString(getLang("5200142", CC_CMDITOA(thumbUps)))

	self.ui.m_leftFlag:removeAllChildren()
	self.ui.m_LFlagNode:removeAllChildren()

	local flag = AllianceFlagPar:call("create", icon .. ".png")
	flag = tolua.cast(flag, "cc.Node")
	self.ui.m_leftFlag:addChild(flag)

	if DynamicResourceController2:call("checkDynamicResource", "dragonGlobal") 
			and CCLoadSprite:call("loadDynamicResourceByName", "dragonGlobal") then
		local miniTag = dragonWorldCupManager.getCountryIcon(country)
		local countryFlag = CCLoadSprite:call("createSprite", miniTag)
		self.ui.m_LFlagNode:addChild(countryFlag)
		self.ui.m_LFlagNode:setScale(1.0)
	else
		local countryFlag = CCLoadSprite:call("createSprite", country .. ".png", CCLoadSpriteType.CCLoadSpriteType_COUNTRY_ICON)
		self.ui.m_LFlagNode:addChild(countryFlag)
	end

	--红方
	local zone = self.red.zone
	local abbr = self.red.abbr
	local allianceName = self.red.allianceName
	local icon = (self.red.icon == "") and "Allance_flay" or self.red.icon
	--local rank = self.red.rank
	--local points = self.red.points
	local kingdom = self.red.kingdom
	local kingdomName = self.red.kingdomName
	--local winRate = self.red.winRate
	local country = self.red.country 
	local thumbUps = self.red.thumbUps
	local thumbUpState = self.red.thumbUpState
	local groupIndex = self.red.groupIndex

	local allianceStr = allianceName .. "(" .. abbr .. ")" 
	local kingdomStr = kingdomName
	--local winStr = winRate .. "%"

	self.ui.m_rightGroupLabel:setString(getLang("5200107", string.char(65 + tonumber(groupIndex) - 1)))
	self.ui.m_rightName:setString(allianceStr)
	self.ui.m_rightKingdom:setString(getLang("140031", kingdomStr))
	--self.ui.m_rankTxt:setString(getLang("140023", CC_CMDITOA(rank)))
	--self.ui.m_winTxt:setString(getLang("140033", winStr))
	--self.ui.m_allianceTxt:setString(allianceName)
	--self.ui.m_scoreTxt:setString(getLang("103010", CC_CMDITOA(points)))
	self.ui.m_rightSupportLabel:setString(getLang("5200142", CC_CMDITOA(thumbUps)))

	self.ui.m_rightFlag:removeAllChildren()
	self.ui.m_RFlagNode:removeAllChildren()

	local flag = AllianceFlagPar:call("create", icon .. ".png")
	flag = tolua.cast(flag, "cc.Node")
	self.ui.m_rightFlag:addChild(flag)

	if DynamicResourceController2:call("checkDynamicResource", "dragonGlobal") 
			and CCLoadSprite:call("loadDynamicResourceByName", "dragonGlobal") then
		local miniTag = dragonWorldCupManager.getCountryIcon(country)
		local countryFlag = CCLoadSprite:call("createSprite", miniTag)
		self.ui.m_RFlagNode:addChild(countryFlag)
		self.ui.m_RFlagNode:setScale(1.0)
	else
		local countryFlag = CCLoadSprite:call("createSprite", country .. ".png", CCLoadSpriteType.CCLoadSpriteType_COUNTRY_ICON)
		self.ui.m_RFlagNode:addChild(countryFlag)
	end
	--其他信息
	self.ui.m_FinalsLabel:setString(getLang("150301"))
	self.ui.m_tileLabel:setString(getLang("5200109"))
	self.ui.m_btnSelectTime:setEnabled(self.inFight)
	self.ui.m_btnManageFight:setEnabled(self.inFight)
	self.ui.m_btnFight:setEnabled(self.inFight)

	CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnSelectTime, getLang("140274"))
	CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnFight, getLang("140013"))
	CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnManageFight, getLang("140043"))
	CCCommonUtilsForLua:setButtonTitle(self.ui.m_rewardBtn, getLang("138003"))

	self.m_tableView:reloadData()
end

function DragonWorldCupPlayOffView:runEffectAnima()
	local animationManager = ccb["DragonWorldCupPlayOffOwner"]["mAnimationManager"]
	animationManager:runAnimationsForSequenceNamed("Effect")
	animationManager:setAnimationCompletedCallback(function() self:animationRunCallBack() end)
end

function DragonWorldCupPlayOffView:animationRunCallBack()
	self.ui.m_effectShowNode:removeAllChildren()

	for i = 0, 3 do
		local effect = ParticleController:call("createParticle", "DragonBattle_" .. i)
		self.ui.m_effectShowNode:addChild(effect)
	end
end

function DragonWorldCupPlayOffView:addFireParticle()
	self.ui.m_fireNode1:removeAllChildren()
	self.ui.m_fireNode2:removeAllChildren()

	for i = 1, 4 do
    	local fire1 = ParticleController:call("createParticle", string.format("UiFire_%d", i))
    	self.ui.m_fireNode1:addChild(fire1)

    	local fire2 = ParticleController:call("createParticle", string.format("UiFire_%d", i))
    	self.ui.m_fireNode2:addChild(fire2)
   	end

   	local p1 = ParticleController:call("createParticle", "VersusIce_hor")
   	p1:setPosition(0, -10)
   	self.ui.m_iceFireEffectNode:addChild(p1)

   	local p2 = ParticleController:call("createParticle", "VersusIce_hor")
   	p2:setAnchorPoint(ccp(1, 0))
   	p2:setPosition(-100, -220)
   	self.ui.m_iceFireEffectNode:addChild(p2)

   	local p3 = ParticleController:call("createParticle", "VersusIce_ver")
   	p3:setPosition(135, -110)
   	p3:setRotation(25)
   	self.ui.m_iceFireEffectNode:addChild(p3)

	local p1 = ParticleController:call("createParticle", "VersusFire_hor")
   	p1:setPosition(0, -10)
   	self.ui.m_hotFireEffectNode:addChild(p1)

   	local p2 = ParticleController:call("createParticle", "VersusFire_hor")
   	p2:setAnchorPoint(ccp(1, 0))
   	p2:setPosition(100, 200)
   	self.ui.m_hotFireEffectNode:addChild(p2)

   	local p3 = ParticleController:call("createParticle", "VersusFire_ver")
   	p3:setPosition(-149, 110)
   	p3:setRotation(25)
   	self.ui.m_hotFireEffectNode:addChild(p3)
end

function DragonWorldCupPlayOffView:onTouchBegan(x, y)
	self.startPoint = ccp(x, y)
	if isTouchInside(self.ui.m_leftHandTouchNode, x, y) then  
		self.supportTeam = self.blue
		return true 
	end
	if isTouchInside(self.ui.m_rightHandTouchNode, x, y) then 
		self.supportTeam = self.red
		return true 
	end
	return false
end

function DragonWorldCupPlayOffView:onTouchEnded(x, y)
	if ccpDistance(self.startPoint, ccp(x, y)) > 10 then return end

	local now = LuaController:call("getTimeStamp")
	local startTime = tonumber(self.playoffInfo.startTime)
	if now > startTime then
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("5200127"))
		return
	elseif self.supportTeam.thumbUpState then
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("5200035"))
		return
	elseif self.canThumbup == false then
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("5200034"))
		return
	end
	
	local supportView = require("game.dragonWorldCup.DragonWorldCupSupportView"):create(self.supportTeam.allianceId)
	PopupViewController:addPopupView(supportView)
end

--点赞
function DragonWorldCupPlayOffView:thumbUp(param)
	local pstr = tolua.cast(param, "CCString")
	if pstr then
		local allianceId = pstr:getCString()
		self:showThumpUpAction(allianceId == self.blue.allianceId)
		self.canThumbup = false
		self.supportTeam.thumbUpState = true
	end
end

--点赞动画
function DragonWorldCupPlayOffView:showThumpUpAction(left)
	local team = left and self.blue or self.red
	local thumbUps = left and self.blue.thumbUps or self.red.thumbUps
	local thumbUpsLabel = left and self.ui.m_leftSupportLabel or self.ui.m_rightSupportLabel
	local thumbUpsLabelSize = thumbUpsLabel:getContentSize()
	local thumb = left and self.ui.m_leftThumbupSp or self.ui.m_rightThumbupSp
	local hintColor = left and cc.c3b(144, 207, 224) or cc.c3b(236, 222, 156)
	local hintFontSize = 14
	
	thumbUpsLabel:setString(getLang("5200142", CC_CMDITOA(thumbUps + 1)))

	local hint = CCLabelIF:call("create")
	hint:call("setString", "+1")
	hint:call("setColor", hintColor)
	hint:call("setFontSize", hintFontSize)

	hint = tolua.cast(hint, "cc.Node")

	local posx, posy = thumbUpsLabel:getPosition()
	posx = posx + thumbUpsLabelSize.width / 2
	local par = thumbUpsLabel:getParent()
	par:addChild(hint)
	hint:setPosition(posx, posy)

	local moveTo = cc.MoveTo:create(0.5, ccp(posx, posy + 30))
	local fadeOut = cc.FadeOut:create(0.5)
	local spawn = cc.Spawn:create(moveTo, fadeOut)
	local function removeSelf() hint:removeFromParent() end
	local callfunc = cc.CallFunc:create(removeSelf)
	local seq = cc.Sequence:create(spawn, callfunc)
	hint:runAction(seq)	
end

function DragonWorldCupPlayOffView:scheduleUpdate()
    local function updatefunc(dt) self:onEnterFrame(dt) end 
    self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(updatefunc, 1.0, false)
end

function DragonWorldCupPlayOffView:unscheduleUpdate()
    if self.entry then
        cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
        self.entry = nil
    end
end

--计时器函数
function DragonWorldCupPlayOffView:onEnterFrame()
	--self.animationCount = self.animationCount + 1

	--if self.animationCount % 2 == 0 then self:runEffectAnima() end
	if self.playoffInfo == nil then return end

	local now = LuaController:call("getTimeStamp")
	local startTime = tonumber(self.playoffInfo.startTime)
	local endTime = tonumber(self.playoffInfo.endTime)
	local obEntryVisible = false

	self.ui.m_btnSelectTime:setVisible(false)
	self.ui.m_btnFight:setEnabled(false)

	if (startTime > 0 and now < startTime) then
		obEntryVisible = true
		local leftTime = startTime - now
		self.ui.m_timeLabel:setString(format_time(leftTime))
	elseif (now >= startTime and now < endTime) then
		obEntryVisible = true
		self.ui.m_timeLabel:setString(getLang("140364"))
		self.ui.m_btnFight:setEnabled(self.inFight or false)
	elseif (endTime > 0 and now >= endTime) then
		obEntryVisible = false
		self.ui.m_timeLabel:setString(getLang("5200048")) 	
	else
		obEntryVisible = false
		self.ui.m_timeLabel:setString("") 
	end

	--ob按钮
	if self.obSwitch then
		self.ui.m_btnLiveBlue:setVisible(obEntryVisible)
		self.ui.m_btnLiveRed:setVisible(obEntryVisible)
	else
		self.ui.m_btnLiveBlue:setVisible(false)
		self.ui.m_btnLiveRed:setVisible(false)
	end
end

function DragonWorldCupPlayOffView:onEnter()
	--UIComponent:call("showPopupView", 1)
	self:setTitleName(getLang("5200016"))
	self:scheduleUpdate()

	local function callback1() self:refreshView() end
	local function callback2(param) self:thumbUp(param) end
	local function callback3() self:shareSuccess() end
	local function callback4() self:shareSuccess() end
	local handler1 = self:registerHandler(callback1)
	local handler2 = self:registerHandler(callback2)
	local handler3 = self:registerHandler(callback3)
	local handler4 = self:registerHandler(callback4)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "dragon.worldcup.data.back")
	CCSafeNotificationCenter:registerScriptObserver(self, handler2, "dragon.worldcup.support.success")
	CCSafeNotificationCenter:registerScriptObserver(self, handler3, "MFBFeedDialogResult")
	CCSafeNotificationCenter:registerScriptObserver(self, handler4, "WeiBoFeedDialogResult")
end


function DragonWorldCupPlayOffView:onExit()
	self:unscheduleUpdate()
	CCSafeNotificationCenter:unregisterScriptObserver(self, "dragon.worldcup.data.back")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "dragon.worldcup.support.success")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "MFBFeedDialogResult")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "WeiBoFeedDialogResult")
end

function DragonWorldCupPlayOffView:shareSuccess()
	local function delayShowSuccess()
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("111137"))
	end

	local node = cc.Node:create()
	self:addChild(node)
	performWithDelay(node, delayShowSuccess, 0.5) 
end

function DragonWorldCupPlayOffView:scrollViewDidScroll(tab)
	local maxdx = self.m_tableView:maxContainerOffset().x
	local dx = self.m_tableView:getContentOffset().x
	if (dx > maxdx) then
		self.m_tableView:setContentOffset(ccp(maxdx, 0))
	end
end

function DragonWorldCupPlayOffView:cellSizeForTable(tab, idx)
	return 100.0, 106.0
end

function DragonWorldCupPlayOffView:tableCellAtIndex(tab, idx)
	local node = DragonWorldCupPlayOffAwardCell:create(self.rewardInfos[idx + 1])
	node:setTag(666)
	
	local cell = cc.TableViewCell:create()
	cell:addChild(node)
	return cell
end

function DragonWorldCupPlayOffView:numberOfCellsInTableView(tab)
	return type(self.rewardInfos) == "table" and #self.rewardInfos or 0
end

function DragonWorldCupPlayOffView:onBtnLiveBlueClick()
	local allianceId = self.blue.allianceId
	self:obBattle(allianceId)
end

function DragonWorldCupPlayOffView:onBtnLiveRedClick()
	local allianceId = self.red.allianceId
	self:obBattle(allianceId)
end

--ob比赛
function DragonWorldCupPlayOffView:obBattle(allianceId)
	local now = LuaController:call("getTimeStamp")
	if now < tonumber(self.playoffInfo.startTime) then
		local leftTime = self.playoffInfo.startTime - now
		YesNoDialog:call("show", getLang("140365", format_time(leftTime)))
	elseif now > tonumber(self.playoffInfo.endTime) then
		YesNoDialog:call("show", getLang("140367"))
	else
		if self.ticketPayed then
			self:sureToOB(allianceId)
		else
			local itemId = dragonWorldCupManager.getPlayOffObItemId()
			local info = ToolController:call("getToolInfoByIdForLua", itemId)
			local function callback() self:sureToOB(allianceId) end
			local callfunc = cc.CallFunc:create(callback)
			YesNoDialog:call("show", getLang("140366", info:call("getName"), tostring(info:call("getCNT"))), callfunc)
		end
	end
end

function DragonWorldCupPlayOffView:sureToOB(allianceId)
	dragonWorldCupManager.enterDragonBattle(allianceId, true)
end

function DragonWorldCupPlayOffView:onSelectTimeClick()
	local kpMatchView = require("game.dragonWorldCup.DragonWorldCupKPMatchView"):create()
	PopupViewController:addPopupInView(kpMatchView)
end

function DragonWorldCupPlayOffView:onFightClick()
	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	if playerInfo:call("isInAlliance") then
		local selfAllianceId = playerInfo:call("getAllianceId")
		dragonWorldCupManager.enterDragonBattle(selfAllianceId, false)
	end
end

function DragonWorldCupPlayOffView:onManageClick()
	local canNot = dragonWorldCupManager.canNotModifyBattleList()
	local managerView = require("game.dragonWorldCup.DragonWorldCupManagerView"):create(canNot)
	PopupViewController:addPopupInView(managerView)
end

function DragonWorldCupPlayOffView:onRewardClick()
	local playOffRewardView = require("game.dragonWorldCup.DragonWorldCupKnockRewardView"):create(true)
	PopupViewController:addPopupInView(playOffRewardView)
end

function DragonWorldCupPlayOffView:onShareBtnClick()
	local lua_path = "game.dragonWorldCup.DragonWorldCupShareView"
	package.loaded[lua_path] = nil
	local view = require(lua_path):create()
	PopupViewController:addPopupView(view)
end

----------------------DragonWorldCupPlayOffAwardCell----------------------

function DragonWorldCupPlayOffAwardCell:create(rewardInfo)
	local view = DragonWorldCupPlayOffAwardCell.new()
	Drequire("game.dragonWorldCup.DragonWorldCupPlayOffAwardCell_ui"):create(view, 1)
	if view:initView(rewardInfo) then
		return view
	end 
end

function DragonWorldCupPlayOffAwardCell:initView(rewardInfo)
	local name = ""
	local icon  = ""

	local rewardType = tonumber(rewardInfo.type) or 0
    MyPrint("rewardType", rewardType)
	local value = tonumber(rewardInfo.value) or 0
    local id = 0
	if rewardType == RewardTypeConfig.R_GOODS then
        local valueObj = rewardInfo.value
        id = tonumber(valueObj.id) or 0
		name = RewardController:call("getNameByType", rewardType, id)
		icon = RewardController:call("getPicByType", rewardType, id)
        value = tonumber(valueObj.num) or 0
	elseif rewardType == RewardTypeConfig.R_EFFECT then
		name = CCCommonUtilsForLua:call("getNameById", tostring(value))
		if name == "" then
			if value == 502600 then
				name = getLang("138074")
			elseif value == 502601 then
				name = getLang("138075")
			elseif value == 502602 then
				name = getLang("138076")
			end
		end

		icon = CCCommonUtilsForLua:call("getICon", tostring(value))
		value = 1
	else
		if rewardType == RewardTypeConfig.R_DRAGON_MODEL then
			name = getLang("140357")
		elseif rewardType == RewardTypeConfig.R_DRAGON_RING then
			name = getLang("140358")
		else 
			name = RewardController:call("getNameByType", rewardType, id)
		end

		icon = RewardController:call("getPicByType", rewardType, value)
	end

	--self.ui.m_nameTxt:setString(name)

	local t = "X" .. CC_CMDITOA(value)
    if rewardType == RewardTypeConfig.R_EFFECT then t = "" end
	self.ui.m_numLabel:setString(t)

	local color = 2
	if rewardType == RewardTypeConfig.R_GOODS then
        local toolInfo = ToolController:call("getToolInfoByIdForLua", id)
        if toolInfo then
        	color = toolInfo:getProperty("color")
        end
    elseif (rewardType == RewardTypeConfig.R_EFFECT or rewardType == RewardTypeConfig.R_CRYSTAL or rewardType == RewardTypeConfig.R_WIN_POINT 
    			or rewardType == RewardTypeConfig.R_GOLD or rewardType == RewardTypeConfig.R_DRAGON_MODEL or rewardType == RewardTypeConfig.R_DRAGON_RING) then
    	color = 5
    end
    local colorBg = CCCommonUtilsForLua:call("getToolBgByColor", color)

    self.ui.m_colorBg:setSpriteFrame(CCLoadSprite:call("loadResource", colorBg))
	self.ui.m_iconSp:setSpriteFrame(CCLoadSprite:call("loadResource", icon))

	return true
end

return DragonWorldCupPlayOffView