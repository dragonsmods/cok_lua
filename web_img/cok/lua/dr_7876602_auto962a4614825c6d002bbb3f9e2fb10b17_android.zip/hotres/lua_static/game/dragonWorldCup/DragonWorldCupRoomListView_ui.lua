----------------------------
-- Author: Elex
-- Date: 2017-05-23 22:44:23
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local DragonWorldCupRoomListView_ui = class("DragonWorldCupRoomListView_ui")

--#ui propertys


--#function
function DragonWorldCupRoomListView_ui:create(owner, viewType)
	local ret = DragonWorldCupRoomListView_ui.new()
	CustomUtility:DoRes(500, true)
	CustomUtility:DoRes(506, true)
	CustomUtility:DoRes(512, true)
	CustomUtility:DoRes(8, true)
	CustomUtility:LoadUi("DragonWorldCupRoomListView.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function DragonWorldCupRoomListView_ui:initLang()
end

function DragonWorldCupRoomListView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function DragonWorldCupRoomListView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function DragonWorldCupRoomListView_ui:onSureClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onSureClick", pSender, event)
end

return DragonWorldCupRoomListView_ui

