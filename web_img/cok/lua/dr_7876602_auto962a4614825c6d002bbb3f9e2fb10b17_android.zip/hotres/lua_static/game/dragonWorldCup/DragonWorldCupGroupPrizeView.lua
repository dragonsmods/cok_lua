local DragonWorldCupGroupPrizeView = class("DragonWorldCupGroupPrizeView",
	function()
		return PopupBaseView:create()
	end
)
DragonWorldCupGroupPrizeView.__index = DragonWorldCupGroupPrizeView

local DragonWorldCupGroupPrizeCell = class("DragonWorldCupGroupPrizeCell",
	function()
		return cc.Node:create()
	end
)
DragonWorldCupGroupPrizeCell.__index = DragonWorldCupGroupPrizeCell

local dragonWorldCupManager = require("game.dragonWorldCup.DragonWorldCupManager")

function DragonWorldCupGroupPrizeView:create()
	local view = DragonWorldCupGroupPrizeView.new()
	Drequire("game.dragonWorldCup.DragonWorldCupGroupPrizeView_ui"):create(view, 0)
	if view:initView() then
		return view
	end
end

function DragonWorldCupGroupPrizeView:initView()
	if self:init(true, 0) then
		self:setHDPanelFlag(true)
		self:setTitleName(getLang("5200016"))

		if CCCommonUtilsForLua:isIosAndroidPad() then
			self.ui.m_topNode:setScale(2.4)
		end

		-- local ccbSize = self.ui.nodeccb:getContentSize()
		-- self:setContentSize(ccbSize)

		local addHeight = self:call("getExtendHeight")
		local nodeSize = self.ui.m_listNode:getContentSize()
		self.ui.m_listNode:setContentSize(cc.size(nodeSize.width, nodeSize.height + addHeight))

		CCCommonUtilsForLua:setButtonTitle(self.ui.m_winBtn, getLang("140197"))
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_loseBtn, getLang("140198"))

		self.scrollView = CCScrollView:create(self.ui.m_listNode:getContentSize())
		self.scrollView:setDirection(kCCScrollViewDirectionVertical)
		self.ui.m_listNode:addChild(self.scrollView, 100)

		self.scrollLayer = cc.Node:create()
		self.scrollView:setContainer(self.scrollLayer)

		local rewardCommand = require("game.command.DragonWorldCupGroupRewardCmd").create()
		rewardCommand:send()
		-- self:refreshView()

		return true
	end

	return false
end

function DragonWorldCupGroupPrizeView:getTestData( )
	
end

function DragonWorldCupGroupPrizeView:onEnter()
	self:setTitleName(getLang("5200016"))
	local function callback1() self:refreshView() end
	local handler1 = self:registerHandler(callback1)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "dragon.worldcup.group.reward")
end

function DragonWorldCupGroupPrizeView:onExit()
	CCSafeNotificationCenter:unregisterScriptObserver(self, "dragon.worldcup.group.reward")
end

function DragonWorldCupGroupPrizeView:refreshView()
	self.reward = dragonWorldCupManager.getGroupRewardData()
	--self:getTestData()

	if sizen(self.reward) == 0 then return end

	if self.reward.win then
		self.winRewardData = self.reward.win
	end

	if self.reward.lose then
		self.loseRewardData = self.reward.lose
	end

	if (self.ui.m_winBtn:isEnabled() and self.ui.m_loseBtn:isEnabled()) then
		self:updateScrollView(self.winRewardData)
		self.ui.m_winBtn:setEnabled(false)
		self.ui.m_loseBtn:setEnabled(true)
		self.ui.m_winBtn:setColor(cc.c3b(255, 99, 71))
		self.ui.m_loseBtn:setColor(cc.c3b(255, 255, 255))
	else
		if self.ui.m_winBtn:isEnabled() then
			self:updateScrollView(self.loseRewardData)
		else
			self:updateScrollView(self.winRewardData)
		end
	end
end

function DragonWorldCupGroupPrizeView:onClickWin()
	self:updateScrollView(self.winRewardData)
	self.ui.m_winBtn:setEnabled(false)
	self.ui.m_loseBtn:setEnabled(true)
	self.ui.m_winBtn:setColor(cc.c3b(255, 99, 71))
	self.ui.m_loseBtn:setColor(cc.c3b(255, 255, 255))
end

function DragonWorldCupGroupPrizeView:onClickLose()
	self:updateScrollView(self.loseRewardData)
	self.ui.m_winBtn:setEnabled(true)
	self.ui.m_loseBtn:setEnabled(false)
	self.ui.m_winBtn:setColor(cc.c3b(255, 255, 255))
	self.ui.m_loseBtn:setColor(cc.c3b(255, 99, 71))
end

function DragonWorldCupGroupPrizeView:updateScrollView(data)
	self.scrollLayer:removeAllChildren()
	if data == nil then return end

	local rewardHeight = 0
	local count = #data
	for index = count, 1, -1 do
		local cell = DragonWorldCupGroupPrizeCell:create(data[index])
		self.scrollLayer:addChild(cell)
		cell:setPosition(ccp(23, 8 + rewardHeight))
		rewardHeight = rewardHeight + cell:getContentSize().height + 8
	end

	local cellWidth = 598
	local viewSize = self.scrollView:getViewSize()
	self.scrollLayer:setContentSize(cc.size(598, rewardHeight + 10))
	self.scrollLayer:setPosition(ccp(0, viewSize.height - rewardHeight - 10))
	self.scrollView:updateInset()
end


-------------------------DragonWorldCupGroupPrizeCell-------------------------
function DragonWorldCupGroupPrizeCell:create(data)
	local node = DragonWorldCupGroupPrizeCell.new()
	if node:initNode(data) then
		return node
	end
end

function DragonWorldCupGroupPrizeCell:initNode(data)
	local rewardHeight = 0
	local cellHeight = 90
	local cellWidth = 600

	if data.reward then
		local count = #data.reward
		for index = 1, count, 1 do
			local reward = data.reward[index]
			--dump(reward, "reward")
			local cell = require("game.dragonWorldCup.DragonWorldCupRewardCell"):create(reward)
			self:addChild(cell)
			cell:setPosition(ccp(15, 20 + (count - index) * 90 * 1.2))
			cell:setScale(1.2)
			rewardHeight = rewardHeight + cellHeight * 1.2
			cell:setLabelColor(120, 97, 67)
		end
	end

	local bgTitle = CCLoadSprite:call("createScale9Sprite", "jlzy_xx_bg_1.png")
	self:addChild(bgTitle)
	bgTitle:setContentSize(cc.size(cellWidth - 2, 36))
	self:setContentSize(cc.size(cellWidth, rewardHeight + 56))
	bgTitle:setPosition(ccp(cellWidth / 2, rewardHeight + 33))

	local strRank = ""
	if data.min and data.max then
		local min = tonumber(data.min) or 0
		local max = tonumber(data.max) or 0
		if max == -1 then
			strRank = getLang("140199", data.min)
		else
			strRank = getLang("140200", data.min, data.max)
		end
	end

	local label = cc.Label:createWithSystemFont(strRank, "Helvetica", 20)
	label:setAnchorPoint(ccp(0, 0.5))
	bgTitle:addChild(label)
	label:setPosition(ccp(30, bgTitle:getContentSize().height / 2))
	label:setColor(cc.c3b(203, 139, 116))

	local spPoint = CCLoadSprite:call("createSprite", "jlzy_xx_dian.png")
	bgTitle:addChild(spPoint)
	spPoint:setPosition(ccp(10, bgTitle:getContentSize().height / 2))

	local bg = CCLoadSprite:call("createScale9Sprite", "jlzy_xx_bg.png")
	bg:setContentSize(self:getContentSize())
	self:addChild(bg, -1)
	bg:setAnchorPoint(ccp(0, 0))

	return true
end
-------------------------DragonWorldCupGroupPrizeCell-------------------------

return DragonWorldCupGroupPrizeView
