local DragonWorldCupAgainstView = class("DragonWorldCupAgainstView",
	function()
		return PopupBaseView:create()
	end
)
DragonWorldCupAgainstView.__index = DragonWorldCupAgainstView

local DragonWorldCupAgainstCell = class("DragonWorldCupAgainstCell",
	function()
		return cc.Layer:create()
	end
)
DragonWorldCupAgainstCell.__index = DragonWorldCupAgainstCell

local dragonWorldCupManager = require("game.dragonWorldCup.DragonWorldCupManager")

local TOP_HEIGHT = 75
local TOP_HEIGHT_HD = 154


local BATTLE_WIN = 1
local BATTLE_LOSE = -1

local THUMBUP_TURN = true --每轮只能支持一个队伍

--翻页标准距离
local PAGE_DIF_STANDRD_DISTANCE = 15 

function DragonWorldCupAgainstView:create()
	local view = DragonWorldCupAgainstView.new()
	Drequire("game.dragonWorldCup.DragonWorldCupAgainstView_ui"):create(view, 0)
	if view:initView() then
		return view
	end
end

function DragonWorldCupAgainstView:initView()
	if self:init(true, 0) then
		-- body	
		self:setIsHDPanel(true)

		local dh = TOP_HEIGHT + 5
		local ccbSize = cc.size(640, 852)
		if CCCommonUtilsForLua:isIosAndroidPad() then
			dh = TOP_HEIGHT_HD + 5
			ccbSize = cc.size(1536, 2048)
		end

		CCLoadSprite:call("doResourceByCommonIndex", 208, true)

		local extHeight = self:call("getExtendHeight")
		self.ui.nodeccb:setPositionY(self.ui.nodeccb:getPositionY() - dh)

		--local ccbSize = self.ui.nodeccb:getContentSize()
		local winSize = cc.Director:sharedDirector():getIFWinSize()

		self:setContentSize(ccbSize)
		self.ui.m_bottomNode:setPositionY(dh + 10 - (winSize.height - ccbSize.height))

		local scaleY = winSize.height / 1136
		local scaleX = winSize.width / 640
		local scale = scaleX < scaleY and scaleX or scaleY
		local magrin = scaleX < scaleY and math.abs(scaleX - scaleY) * winSize.height / 2 or 0

		self.ui.m_baseMoveNode:setScale(scale)
		self.ui.m_baseMoveNode:setPositionY(self.ui.m_baseMoveNode:getPositionY() - extHeight + dh + magrin)
		self.ui.m_baseBackNode:setPositionY(self.ui.m_baseBackNode:getPositionY() - extHeight + dh)

		if CCCommonUtilsForLua:isIosAndroidPad() then
			self.ui.m_bottomNode:setScale(2.4)
		end 

		CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnAgainst, getLang("140267"))
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnSelectTime, getLang("140274"))
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnFight, getLang("140013"))
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnPrize, getLang("133005"))
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnManageFight, getLang("140043"))

		self.ui.m_battleTeamTitle:setString(getLang("103657", ""))

		self.ui.m_btnManageFight:setEnabled(false)
		self.ui.m_btnAgainst:setEnabled(false)
		self.ui.m_shareNode:setVisible(false)

		self.lineNodeList = {}
		self.lineNodeList[#self.lineNodeList + 1] = self.ui.m_line1
		self.lineNodeList[#self.lineNodeList + 1] = self.ui.m_line2
		self.lineNodeList[#self.lineNodeList + 1] = self.ui.m_line3
		self.lineNodeList[#self.lineNodeList + 1] = self.ui.m_line4
		self.lineNodeList[#self.lineNodeList + 1] = self.ui.m_line5
		self.lineNodeList[#self.lineNodeList + 1] = self.ui.m_line6
		self.lineNodeList[#self.lineNodeList + 1] = self.ui.m_line7
		self.lineNodeList[#self.lineNodeList + 1] = self.ui.m_line8

		self.allLinelist = {}
		for index = 1, #self.lineNodeList, 1 do
			self.allLinelist[#self.allLinelist + 1] = self.lineNodeList[index]
		end
		self.allLinelist[#self.allLinelist + 1] = self.ui.m_line12
		self.allLinelist[#self.allLinelist + 1] = self.ui.m_line34
		self.allLinelist[#self.allLinelist + 1] = self.ui.m_line56
		self.allLinelist[#self.allLinelist + 1] = self.ui.m_line78
		self.allLinelist[#self.allLinelist + 1] = self.ui.m_line1234
		self.allLinelist[#self.allLinelist + 1] = self.ui.m_line5678

		self.allPointList = {}
		self.allPointList[#self.allPointList + 1] = self.ui.m_point12
		self.allPointList[#self.allPointList + 1] = self.ui.m_point34
		self.allPointList[#self.allPointList + 1] = self.ui.m_point56
		self.allPointList[#self.allPointList + 1] = self.ui.m_point78
		self.allPointList[#self.allPointList + 1] = self.ui.m_point1234
		self.allPointList[#self.allPointList + 1] = self.ui.m_point5678
		self.allPointList[#self.allPointList + 1] = self.ui.m_point_final

		self.currSpList = {}
		self.currSpList[#self.currSpList + 1] = self.ui.m_currSp1
		self.currSpList[#self.currSpList + 1] = self.ui.m_currSp2
		self.currSpList[#self.currSpList + 1] = self.ui.m_currSp3
		self.currSpList[#self.currSpList + 1] = self.ui.m_currSp4
		self.currSpList[#self.currSpList + 1] = self.ui.m_currSp5
		self.currSpList[#self.currSpList + 1] = self.ui.m_currSp6
		self.currSpList[#self.currSpList + 1] = self.ui.m_currSp7
		self.currSpList[#self.currSpList + 1] = self.ui.m_currSp8

		self.currGroupCell = nil

		self.touching = false
		self.pageChanging = false
		self:resetLineAndPoint()
		--self:refreshView()

		local touchLayer = cc.Layer:create()
		self:addChild(touchLayer)

		local function touchHandle( eventType, x, y )
			-- print("touchHandle", eventType, x, y)
			if eventType == "began" then
				return self:onTouchBegan(x, y)
			elseif eventType == "moved" then
				self:onTouchMoved(x, y)
			else
				self:onTouchEnded(x, y)
			end
		end
		touchLayer:registerScriptTouchHandler(touchHandle)
		touchLayer:setTouchEnabled(true)
		touchLayer:setSwallowsTouches(false)

		return true
	end

	return false
end

function DragonWorldCupAgainstView:setInFight()
	if self.groups == nil then return end

	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	if not playerInfo:call("isInAlliance") then return end

	self.allianceId = playerInfo:call("getAllianceId")
	MyPrint("self.allianceId", self.allianceId)
	for i = 1, #self.groups, 1 do
		local data = self.groups[i]
		for j = 1, #data.teamArr, 1 do
			local team = data.teamArr[j]
			if team.allianceId == self.allianceId then
				self.currentIndex = i
				for l = 1, 3 do
					if tonumber(team["march" .. l]) == 0 then
						self.inFight = true
						break
					elseif tonumber(team["march" .. l]) == -1 then
						self.inFight = false
						break
					end
				end
				break
			end
		end
	end
end

function DragonWorldCupAgainstView:checkThumbState()
	if self.groups == nil then return end

	for i = 1, #self.groups, 1 do
		local data = self.groups[i]
		for j = 1, #data.teamArr, 1 do
			local team = data.teamArr[j]
			if team.thumbUpState == "1" or team.thumbUpState == true then
				THUMBUP_TURN = false
				return
			end
		end
	end
end

function DragonWorldCupAgainstView:scheduleUpdate()
    local function updatefunc(dt) self:onEnterFrame(dt) end 
    self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(updatefunc, 1.0, false)
end

function DragonWorldCupAgainstView:unscheduleUpdate()
    if self.entry then
        cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
        self.entry = nil
    end
end

function DragonWorldCupAgainstView:getTestData()
	
end

function DragonWorldCupAgainstView:refreshView()
	self.worldCupInfo = dragonWorldCupManager.getWorldCupData()
	self.groups = self.worldCupInfo.groups
	self.inFight = false


	self.currentIndex = 1
	self:setInFight()
	self:checkThumbState()
	--test
	--self:getTestData()
	MyPrint("self.inFight", self.inFight)
	self.ui.m_btnAgainst:setEnabled(self.inFight)
	self.ui.m_btnSelectTime:setEnabled(self.inFight)
	self.ui.m_btnManageFight:setEnabled(self.inFight)
	self.ui.m_btnFight:setEnabled(self.inFight)

	self:updateAgainstView()
	self:updateCurrSpList()
end

function DragonWorldCupAgainstView:updateShareNode()
	self.ui.m_shareNode:setVisible(true)

	for i = 1, 7 do
		local fieldName = "m_share" .. i .. "Button"
		local btn = self.ui[fieldName]
		if btn then btn:setVisible(false) end
	end

	local group = self.groups[self.currentIndex]
	local teamArr = group.teamArr 

	local turn = 1
	local turnT = {4, 6, 7}

	for index = 1, #teamArr do
		local team = teamArr[index]

		local march1 = tonumber(team.march1)
		local march2 = tonumber(team.march2)
		local march3 = tonumber(team.march3)

		local max = 0
		
		for l = 1, 3 do
			if tonumber(team["march" .. l]) ~= 0 then
				max = max + 1
			end
		end

		max = max + 1
		max = max > 3 and 3 or max

		if max > turn then
			turn = max
		end
	end

	for i = 1, turnT[turn] do
		local fieldName = "m_share" .. i .. "Button"
		local btn = self.ui[fieldName]
		if btn then btn:setVisible(true) end
	end
end

function DragonWorldCupAgainstView:onEnterFrame()
	if dragonWorldCupManager.isBeforeMatch() then
		self.ui.m_btnSelectTime:setVisible(true)
		self.ui.m_btnManageFight:setVisible(true)
		self.ui.m_btnFight:setVisible(false)
	elseif dragonWorldCupManager.isBeforeBattle() then
		self.ui.m_btnSelectTime:setVisible(false)
		self.ui.m_btnManageFight:setVisible(true)
		self.ui.m_btnFight:setVisible(true)
		self.ui.m_btnFight:setEnabled(false)
	elseif dragonWorldCupManager.isInBattle() then
		self.ui.m_btnSelectTime:setVisible(false)
		self.ui.m_btnManageFight:setVisible(true)
		self.ui.m_btnFight:setVisible(true)
		self.ui.m_btnFight:setEnabled(self.inFight)
	elseif dragonWorldCupManager.isBattleOver() then
		self.ui.m_btnSelectTime:setVisible(false)
		self.ui.m_btnManageFight:setVisible(false)
		self.ui.m_btnFight:setVisible(true)
		self.ui.m_btnFight:setEnabled(false)
	end


	if self.inFight then
		self.ui.m_timeBG:setVisible(true)
		self.ui.m_timeLabel:setVisible(true)

		local worldCupInfo = self.worldCupInfo
		local now = LuaController:call("getTimeStamp")
		local matchStartTime = worldCupInfo.matchStartTime
		local battleBeginTime = worldCupInfo.battleBeginTime
		local battleEndTime = worldCupInfo.battleEndTime

		if dragonWorldCupManager.isBeforeMatch() then
			local remain = matchStartTime - now
			self.ui.m_timeLabel:setString(getLang("140275", format_time(remain)))
		elseif dragonWorldCupManager.isBeforeBattle() then
			local remain = battleBeginTime - now
			self.ui.m_timeLabel:setString(getLang("140276", format_time(remain)))
		elseif dragonWorldCupManager.isInBattle() then
			local remain = battleEndTime - now
			self.ui.m_timeLabel:setString(getLang("140060", format_time(remain)))
		else
			self.ui.m_timeBG:setVisible(false)
			self.ui.m_timeLabel:setVisible(false)
		end

		--y延迟3秒刷新数据
		if matchStartTime + 3 == now then
			--请求比赛数据
			--dragonWorldCupManager.requestActivityData()
		end
	else
		self.ui.m_timeBG:setVisible(false)
		self.ui.m_timeLabel:setVisible(false)
	end
end

function DragonWorldCupAgainstView:onEnter()
	self:setTitleName(getLang("5200108"))
	self:scheduleUpdate()
	self:onEnterFrame()

	local function callback1() self:refreshView() end
	local function callback2() self:shareSuccess() end
	local function callback3() self:shareSuccess() end
	local handler1 = self:registerHandler(callback1)
	local handler2 = self:registerHandler(callback2)
	local handler3 = self:registerHandler(callback3)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "dragon.worldcup.data.back")
	CCSafeNotificationCenter:registerScriptObserver(self, handler2, "MFBFeedDialogResult")
	CCSafeNotificationCenter:registerScriptObserver(self, handler3, "WeiBoFeedDialogResult")
end

function DragonWorldCupAgainstView:onExit()
	GameController:call("removeWaitInterface")
	self:unscheduleUpdate()
	CCSafeNotificationCenter:unregisterScriptObserver(self, "dragon.worldcup.data.back")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "MFBFeedDialogResult")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "WeiBoFeedDialogResult")
end

function DragonWorldCupAgainstView:shareSuccess()
	local function delayShowSuccess()
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("111137"))
	end

	local node = cc.Node:create()
	self:addChild(node)
	performWithDelay(node, delayShowSuccess, 0.5) 
end

function DragonWorldCupAgainstView:resetLineAndPoint()
	for index = 1, #self.allLinelist, 1 do
		self.allLinelist[index]:setVisible(false)
		self:setLineColor(self.allLinelist[index], false)
	end

	for index = 1, #self.allPointList, 1 do
		self.allPointList[index]:setVisible(false)
	end
end

function DragonWorldCupAgainstView:setLineColor(lineNode, isGray)
	local childList = lineNode:getChildren()
	local color = cc.c3b(255, 255, 255)
	if isGray then color = cc.c3b(145, 145, 145) end

	for index = 1, #childList, 1 do
		local sp = childList[index]
		sp:setColor(color)
	end
end

function DragonWorldCupAgainstView:updateCurrSpList()
	if self.currentIndex < 1 then return end
	if self.currentIndex > #self.currSpList then return end

	for index = 1, #self.currSpList, 1 do
		self.currSpList[index]:setVisible(index ~= self.currentIndex)
	end
end

function DragonWorldCupAgainstView:addPlayerNode(parentNode, data, teamIndex)
	parentNode:removeAllChildren()

	local againstCell = DragonWorldCupAgainstCell:create(data, teamIndex, self)
	local cellSize = againstCell:getContentSize()
	parentNode:addChild(againstCell)
	againstCell:setPosition(ccp(-cellSize.width / 2, -cellSize.height / 2)) 

	self.currGroupCell[#self.currGroupCell + 1] = againstCell
end

function DragonWorldCupAgainstView:onTouchBegan(x, y)
	if self.groups == nil then return false end

	self.startPoint = ccp(x, y)
	return true
end

function DragonWorldCupAgainstView:onTouchMoved(x, y)
	if self.pageChanging then return end
	if self.touching then return end

	local dif = x - self.startPoint.x
	if math.abs(dif) > PAGE_DIF_STANDRD_DISTANCE then
		self:pageChange(dif < 0)
	end
end

function DragonWorldCupAgainstView:onTouchEnded(x, y)
	self.touching = false
end

function DragonWorldCupAgainstView:pageChange(left)
	self.pageChanging = true
	self.touching = true

	local posY = self.ui.m_baseMoveNode:getPositionY()
	local screenWidth = cc.Director:sharedDirector():getIFWinSize().width
	local posX1 = screenWidth * 1.5
	local posX2 = -screenWidth * 0.5  

	local index = -1
	if left then
		posX1 = -screenWidth / 2
		posX2 = screenWidth * 1.5
		index = 1
	end

	self.currentIndex = self.currentIndex + index
	if self.currentIndex == 0 then
		self.currentIndex = #self.currSpList
	elseif self.currentIndex > (#self.currSpList) then
		self.currentIndex = self.currentIndex % (#self.currSpList)
	end

	local move1 = cc.MoveTo:create(0.15, ccp(posX1, posY))
	local move2 = cc.MoveTo:create(0, ccp(posX2, posY))
	local function callback1() self:updateAgainstView() end
	local callfunc1 = cc.CallFunc:create(callback1)
	local move3 = cc.MoveTo:create(0.3, ccp(screenWidth / 2, posY))
	local function callback2() self:pageChangeFinish() end
	local callfunc2 = cc.CallFunc:create(callback2)

	local seq = cc.Sequence:create(move1, move2, callfunc1, move3, callfunc2)
	self.ui.m_baseMoveNode:runAction(seq)
	self:updateCurrSpList()
end

function DragonWorldCupAgainstView:pageChangeFinish()
	self.pageChanging = false
end

function DragonWorldCupAgainstView:onFrame(dt)
	local worldTime = GlobalData:call("getWorldTime")

end

function DragonWorldCupAgainstView:updateAgainstView()
	if self.groups == nil then return end
	if #self.groups == 0 then return end

	self:resetLineAndPoint()
	self:updateShareNode()

	local group = self.groups[self.currentIndex]
	local groupName = string.char(65 + group.groupIndex - 1)
	self.ui.m_battleTeamDesc:setString(groupName)

	self.currGroupCell = {}
	local teamArr = group.teamArr
	for index = 1, #teamArr do
		local data = teamArr[index]
		self:addPlayerNode(self.ui["m_playerNode_" .. index], data, index)
	end

	local winnerData = nil
	for index = 1, #teamArr do
		local team = teamArr[index]

		local march1 = tonumber(team.march1)
		local march2 = tonumber(team.march2)
		local march3 = tonumber(team.march3)

		if march1 == 1 then
			local lineNode0 = self:getLineNode(index, 0)
			lineNode0:setVisible(true)
			if march2 == 1 then
				local lineNode1 = self:getLineNode(index, 1)
				lineNode1:setVisible(true)
				if march3 == 1 then
					local lineNode2 = self:getLineNode(index, 2)
					lineNode2:setVisible(true)
					winnerData = team
					self.ui.m_point_final:setVisible(true)
				elseif march3 == -1 then
					local lineNode1 = self:getLineNode(index, 1)
					self:setLineColor(lineNode1, true)
				else
					local pointSprite1 = self:getPointSprite(index, 1)
					pointSprite1:setVisible(true)
				end
			elseif march2 == -1 then
				local lineNode0 = self:getLineNode(index, 0)
				self:setLineColor(lineNode0, true)
			else
				local pointSprite0 = self:getPointSprite(index, 0)
				pointSprite0:setVisible(true)
			end
		end
	end

	if winnerData then
		if DynamicResourceController2:call("checkDynamicResource", "dragonGlobal") 
				and CCLoadSprite:call("loadDynamicResourceByName", "dragonGlobal") then
			local miniTag = dragonWorldCupManager.getCountryIcon(winnerData.country)
			local countryFlag = CCLoadSprite:call("createSprite", miniTag)
			self.ui.m_winnerFlagNode:addChild(countryFlag)
			self.ui.m_winnerFlagNode:setScale(1.0)
		else
			local countryFlag = CCLoadSprite:call("createSprite", winnerData.country .. ".png", CCLoadSpriteType.CCLoadSpriteType_COUNTRY_ICON)
			self.ui.m_winnerFlagNode:addChild(countryFlag)
		end
		self.ui.m_winner_name:setString(winnerData.name .. "(" .. winnerData.abbr .. ")")
	else
		self.ui.m_winner_name:setString(getLang("140257"))
	end
end

function DragonWorldCupAgainstView:getLineNode(teamId, matchId)
	local lineNode = nil
	if matchId == 0 then
		lineNode = self.lineNodeList[teamId]
	elseif matchId == 1 then
		local tag = math.floor((teamId - 1) / 2)
		if tag == 0 then
			lineNode = self.ui.m_line12
		elseif tag == 1 then
			lineNode = self.ui.m_line34
		elseif tag == 2 then
			lineNode = self.ui.m_line56
		else
			lineNode = self.ui.m_line78
		end
	else
		local tag = math.floor((teamId - 1) / 4)
		if tag == 0 then
			lineNode = self.ui.m_line1234
		else
			lineNode = self.ui.m_line5678
		end
	end

	return lineNode
end

function DragonWorldCupAgainstView:getPointSprite(teamId, matchId)
	local battlePoint = nil
	if matchId == 0 then
		local tag = math.floor((teamId - 1) / 2)
		if tag == 0 then
			battlePoint = self.ui.m_point12
		elseif tag == 1 then
			battlePoint = self.ui.m_point34
		elseif tag == 2 then
			battlePoint = self.ui.m_point56
		else
			battlePoint = self.ui.m_point78
		end
	elseif matchId == 1 then
		local tag = math.floor((teamId - 1) / 4)
		if tag == 0 then
			battlePoint = self.ui.m_point1234
		else
			battlePoint = self.ui.m_point5678
		end
	end

	return battlePoint
end

function DragonWorldCupAgainstView:showLineAndPoint(teamId, matchId)
	local LineNode = nil
	local battlePoint = nil
	if matchId == 0 then
		local tag = math.floor((teamId - 1) / 2)
		if tag == 0 then
			battlePoint = self.ui.m_point12
		elseif tag == 1 then
			battlePoint = self.ui.m_point34
		elseif tag == 2 then
			battlePoint = self.ui.m_point56
		else
			battlePoint = self.ui.m_point78
		end
	elseif matchId == 1 then
		local tag = math.floor((teamId - 1) / 2)
		if tag == 0 then
			lineNode = self.ui.m_line12
		elseif tag == 1 then
			lineNode = self.ui.m_line34
		elseif tag == 2 then
			lineNode = self.ui.m_line56
		else
			lineNode = self.ui.m_line78
		end

		local tag0 = math.floor((teamId - 1) / 4)
		if tag0 == 0 then
			battlePoint = self.ui.m_point1234
		else
			battlePoint = self.ui.m_point5678
		end
	else
		local tag = math.floor((teamId - 1) / 4)
		if tag == 0 then
			lineNode = self.ui.m_line1234
		else
			lineNode = self.ui.m_line5678
		end
	end

	if lineNode then lineNode:setVisible(true) end
	if battlePoint then battlePoint:setVisible(true) end
end

function DragonWorldCupAgainstView:onSelectTimeClick()
	local lua_path = "game.dragonWorldCup.DragonWorldCupKPMatchView"
	package.loaded[lua_path] = nil
	local kpMatchView = require(lua_path):create()
	PopupViewController:addPopupView(kpMatchView)
end

function DragonWorldCupAgainstView:onFightClick()
	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	if playerInfo:call("isInAlliance") then
		local selfAllianceId = playerInfo:call("getAllianceId")
		dragonWorldCupManager.enterDragonBattle(selfAllianceId, false)
	end
end

function DragonWorldCupAgainstView:getEngageTeam(teamId, winTimes)
	local groups = self.groups[self.currentIndex]
	if groups == nil then return end
	local teamArr = groups.teamArr
	local engageTeamId = 0
	if teamArr == nil then return end
	if winTimes == 0 then
		local tag = math.floor(teamId % 2)
		engageTeamId = (tag == 0 and teamId - 1 or teamId + 1)
	elseif winTimes == 1 then
		local tag = math.floor((teamId - 1) / 4)
		local down = tag == 0 and 1 or 5
		local up = tag == 0 and 4 or 8
	
		for index = down, up do
			local teamCell = self.currGroupCell[index]
			if teamCell == nil then return end
			if index ~= teamId and teamCell.ui.m_failNode:isVisible() then
				engageTeamId = index
				break
			end
		end
	elseif winTimes == 2 then
		for index = 1, #self.currGroupCell do
			local teamCell = self.currGroupCell[index]
			if teamCell == nil then return end
			if index ~= teamId and teamCell.ui.m_failNode:isVisible()  then
				engageTeamId = index
				break
			end
		end
	end

	MyPrint("getEngageTeam", teamId, engageTeamId, winTimes)
	return teamArr[engageTeamId]
end

function DragonWorldCupAgainstView:onManageClick()
	local lua_path = "game.dragonWorldCup.DragonWorldCupManagerView"
	package.loaded[lua_path] = nil 
	local canNot = dragonWorldCupManager.canNotModifyBattleList()
	local managerView = require(lua_path):create(canNot)
	PopupViewController:addPopupInView(managerView)
end

function DragonWorldCupAgainstView:onAgainstClick()
	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	if playerInfo:call("isInAlliance") then
		local selfAllianceId = playerInfo:call("getAllianceId")
		local againstMessageView = require("game.dragonWorldCup.DragonWorldCupAllianceMessageView"):create(selfAllianceId)
		PopupViewController:addPopupInView(againstMessageView)
	end
end

function DragonWorldCupAgainstView:onPrizeClick()
	local lua_path = "game.dragonWorldCup.DragonWorldCupKnockRewardView"
	package.loaded[lua_path] = nil 
	local rewardView = require(lua_path):create()
	PopupViewController:addPopupInView(rewardView)
end

function DragonWorldCupAgainstView:onShare1ButtonClick()
	self:openShareView()
end

function DragonWorldCupAgainstView:onShare2ButtonClick()
	self:openShareView()
end

function DragonWorldCupAgainstView:onShare3ButtonClick()
	self:openShareView()
end

function DragonWorldCupAgainstView:onShare4ButtonClick()
	self:openShareView()
end

function DragonWorldCupAgainstView:onShare5ButtonClick()
	self:openShareView()
end

function DragonWorldCupAgainstView:onShare6ButtonClick()
	self:openShareView()
end

function DragonWorldCupAgainstView:onShare7ButtonClick()
	self:openShareView()
end

function DragonWorldCupAgainstView:openShareView()
	local lua_path = "game.dragonWorldCup.DragonWorldCupShareView"
	package.loaded[lua_path] = nil
	local view = require(lua_path):create()
	PopupViewController:addPopupView(view)
end

----------------DragonWorldCupAgainstCell----------------
function DragonWorldCupAgainstCell:create(data, teamIndex, par)
	local view = DragonWorldCupAgainstCell.new()
	Drequire("game.dragonWorldCup.DragonWorldCupAgainstCell_ui"):create(view, 1)
	if view:initView(data, teamIndex, par) then 
		return view 
	end
end

function DragonWorldCupAgainstCell:initView(data, teamIndex, par)
	self.data = data
	self.teamIndex = teamIndex
	self.par = par

	self:setContentSize(self.ui.nodeccb:getContentSize())
	self.ui.m_name1:setString(data.name .. "(" .. data.abbr .. ")")
	self.ui.m_name2:setString(data.kingdomName)
	self.ui.m_supportDesc:setString(getLang("5200142", CC_CMDITOA(data.thumbUps)))
	self.allianceId = data.allianceId

	if DynamicResourceController2:call("checkDynamicResource", "dragonGlobal") 
			and CCLoadSprite:call("loadDynamicResourceByName", "dragonGlobal") then
		local miniTag = dragonWorldCupManager.getCountryIcon(data.country)
		local countryFlag = CCLoadSprite:call("createSprite", miniTag)
		self.ui.m_flagNode:addChild(countryFlag)
		self.ui.m_flagNode:setScale(0.6)
	else
		local countryFlag = CCLoadSprite:call("createSprite", data.country .. ".png", CCLoadSpriteType.CCLoadSpriteType_COUNTRY_ICON)
		self.ui.m_flagNode:addChild(countryFlag)
	end

	local march1 = tonumber(data.march1) or 0
	local march2 = tonumber(data.march2) or 0
	local march3 = tonumber(data.march3) or 0

	self.data.thumbUps = tonumber(self.data.thumbUps) or 0
	MyPrint("self.data.thumbUpState", self.data.thumbUpState)
	self.data.thumbUpState = (self.data.thumbUpState ~= "0" and self.data.thumbUpState ~= false)


	self.ui.m_failNode:setVisible(not (march1 == BATTLE_LOSE or march2 == BATTLE_LOSE or march3 == BATTLE_LOSE))
	self.ui.m_winner:setVisible(march1 == BATTLE_WIN and march2 == BATTLE_WIN and march3 == BATTLE_WIN)

	self.ticketPayed = false
	if data.ticketPayed then self.ticketPayed = (data.ticketPayed == "true") end

	self.battleStartTime = tonumber(data.battleStartTime) or 0
	self.battleEndTime = tonumber(data.battleEndTime) or 0

	if CCCommonUtilsForLua:isFunOpenByKey("wag_ob") then
		local now = GlobalData:call("getTimeStamp")

		if (self.battleStartTime > 0 and now < self.battleStartTime) then
			--self:secondUpdate()

			-- local livePosX, livePosY = self.ui.m_liveDesc:getPosition()
			-- local timeSize = self.ui.m_iconTime:getContentSize()
			-- local timeScale = self.ui.m_iconTime:getScale()
			-- local liveSize = self.ui.m_liveDesc:getContentSize()
			-- self.ui.m_iconTime:setPosition(livePosX - liveSize.width / 2 + timeSize.width * timeScale / 2, livePosY)

			-- local dt = cc.DelayTime:create(1)
			-- local function callback() self:secondUpdate() end
			-- local callfunc = cc.CallFunc:create(callback)
			-- local repeatAc = cc.RepeatForever:create(cc.Sequence:create(dt, callfunc))
			-- self.ui.m_liveDesc:runAction(repeatAc)
			--self.ui.m_iconTime:setVisible(true)
			self.ui.m_btnLive:setVisible(true)
		elseif (now > self.battleStartTime and now < self.battleEndTime) then
			--self.ui.m_liveDesc:setString(getLang("140364"))
			self.ui.m_btnLive:setVisible(true)
		elseif (self.battleEndTime > 0 and now > self.battleEndTime) then
			--self.ui.m_liveDesc:setString(getLang("140364"))
		end
	end

	local touchLayer = cc.Layer:create()
	self:addChild(touchLayer)

	local function touchHandle( eventType, x, y )
		-- print("touchHandle", eventType, x, y)
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		
		else
			self:onTouchEnded(x, y)
		end
	end
	touchLayer:registerScriptTouchHandler(touchHandle)
	touchLayer:setTouchEnabled(true)
	touchLayer:setSwallowsTouches(false)

	return true
end

function DragonWorldCupAgainstCell:secondUpdate()
	local leftTime = self.battleStartTime -  GlobalData:call("getTimeStamp")
	if leftTime < 0 then
		self.ui.m_liveDesc:setString(getLang("140364"))
		self.ui.m_iconTime:setVisible(false)
		self.ui.m_liveDesc:stopAllActions()
	else
		self.ui.m_liveDesc:setString(format_time(leftTime))
	end
end

function DragonWorldCupAgainstCell:onEnter()
	local function callback1(param) self:thumbUpAct(param) end
	local handler1 = self:registerHandler(callback1)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "dragon.worldcup.support.success")
end

function DragonWorldCupAgainstCell:onExit()
	CCSafeNotificationCenter:unregisterScriptObserver(self, "dragon.worldcup.support.success")
end

function DragonWorldCupAgainstCell:onTouchBegan(x, y)
	self.startPoint = ccp(x, y)

	if isTouchInside(self.ui.m_btnLive, x, y) then return false end
	if isTouchInside(self.ui.m_handTouchNode, x, y) then return true end
	if isTouchInside(self.ui.nodeccb, x, y) then return true end

	return false
end

function DragonWorldCupAgainstCell:onTouchEnded(x, y)
	if ccpDistance(self.startPoint, ccp(x, y)) > 10 then return end

	if isTouchInside(self.ui.m_handTouchNode, x, y) then
		self:thumbUp()
	else
		local lua_path = "game.dragonWorldCup.DragonWorldCupAllianceMessageView"
		package.loaded[lua_path] = nil
		local kpEngageView = require(lua_path):create(self.allianceId)
		PopupViewController:addPopupInView(kpEngageView)
	end
end

function DragonWorldCupAgainstCell:onLiveClick()
	local now = GlobalData:call("getTimeStamp")
	--MyPrint("onLiveClick now", now, self.battleStartTime)
	if now < self.battleStartTime then
		local leftTime = self.battleStartTime - now
		YesNoDialog:call("show", getLang("140365", format_time(leftTime)))
	else
		local itemId = dragonWorldCupManager.getPlayOffObItemId()
		if self.ticketPayed then 
			self:sureToOB() 
		else
			local info = ToolController:call("getToolInfoByIdForLua", tonumber(itemId))
			local function confirm() self:sureToOB() end
			local confirmfunc = cc.CallFunc:create(confirm)
			local itemName = info:call("getName")
			local itemCnt = info:call("getCNT")
			YesNoDialog:call("show", getLang("140366", itemName, tostring(itemCnt)), confirmfunc)
		end
	end
end

function DragonWorldCupAgainstCell:thumbUp()
	if not self.ui.m_failNode:isVisible() then return end

	local winTimes = 0
	for index = 1, 3 do
		if tonumber(self.data["march" .. index]) == 1 then
			winTimes = winTimes + 1
		end
	end

	--已经决出冠军
	if winTimes == 3 then return end

	self.engageTeamData = self.par:getEngageTeam(self.teamIndex, winTimes)
	--特殊情况
	if self.engageTeamData == nil then return end
	self.canThumbUp = (self.data.thumbUpState == false and self.engageTeamData.thumbUpState == false) and THUMBUP_TURN

	MyPrint("thumbUp", self.canThumbUp, self.data.thumbUpState)

	local now =  LuaController:call("getTimeStamp")
	MyPrint("now", now, self.battleStartTime)
	if now > self.battleStartTime then
		MyPrint("hahahah")
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("5200127"))
		return
	end

	if self.canThumbUp then
		--self:thumbUpAct()
		local supportView = require("game.dragonWorldCup.DragonWorldCupSupportView"):create(self.allianceId)
		PopupViewController:addPopupView(supportView)
	elseif (not self.canThumbUp and self.data.thumbUpState) then
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("5200035"))
	else 
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("5200034"))
	end
end

function DragonWorldCupAgainstCell:thumbUpAct(param)
	local pstr = tolua.cast(param, "CCString")
	if pstr then
		local allianceId = pstr:getCString()
		if allianceId ~= self.allianceId then return end
		
		local thumbUpsLabel = self.ui.m_supportDesc
		local thumbUpsLabelSize = thumbUpsLabel:getContentSize()
		local hintColor = left and cc.c3b(144, 207, 224) or cc.c3b(236, 222, 156)
		local hintFontSize = 14
			
		THUMBUP_TURN = false
		self.data.thumbUpState = true
		self.data.thumbUps = self.data.thumbUps + 1
		thumbUpsLabel:setString(getLang("5200142", CC_CMDITOA(tostring(self.data.thumbUps))))

		local hint = CCLabelIF:call("create")
		hint:call("setString", "+1")
		hint:call("setColor", hintColor)
		hint:call("setFontSize", hintFontSize)

		hint = tolua.cast(hint, "cc.Node")

		local posx, posy = thumbUpsLabel:getPosition()
		posx = posx + thumbUpsLabelSize.width / 2
		local par = thumbUpsLabel:getParent()
		par:addChild(hint)
		hint:setPosition(posx, posy)

		local moveTo = cc.MoveTo:create(0.5, ccp(posx, posy + 30))
		local fadeOut = cc.FadeOut:create(0.5)
		local spawn = cc.Spawn:create(moveTo, fadeOut)
		local function removeSelf() hint:removeFromParent() end
		local callfunc = cc.CallFunc:create(removeSelf)
		local seq = cc.Sequence:create(spawn, callfunc)
		hint:runAction(seq)	
	end
end

function DragonWorldCupAgainstCell:sureToOB()
	GameController:call("showWaitInterface")
	dragonWorldCupManager.enterDragonBattle(self.allianceId, true)
end
----------------DragonWorldCupAgainstCell----------------

return DragonWorldCupAgainstView