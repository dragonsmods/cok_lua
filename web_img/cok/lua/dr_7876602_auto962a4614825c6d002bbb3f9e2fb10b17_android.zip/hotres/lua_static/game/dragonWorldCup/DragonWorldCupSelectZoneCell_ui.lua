----------------------------
-- Author: Elex
-- Date: 2020-02-25 Tuesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local DragonWorldCupSelectZoneCell_ui = class("DragonWorldCupSelectZoneCell_ui")

--#ui propertys


--#function
function DragonWorldCupSelectZoneCell_ui:create(owner, viewType, paramTable)
	local ret = DragonWorldCupSelectZoneCell_ui.new()
	CustomUtility:DoRes(306, true)
	CustomUtility:DoRes(504, true)
	CustomUtility:DoRes(512, true)
	CustomUtility:LoadUi("DragonWorldCupSelectZoneCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function DragonWorldCupSelectZoneCell_ui:initLang()
end

function DragonWorldCupSelectZoneCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function DragonWorldCupSelectZoneCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return DragonWorldCupSelectZoneCell_ui

