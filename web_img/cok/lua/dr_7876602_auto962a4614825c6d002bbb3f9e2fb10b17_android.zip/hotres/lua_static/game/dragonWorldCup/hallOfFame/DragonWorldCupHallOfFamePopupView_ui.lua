----------------------------
-- Author: Elex
-- Date: 2017-07-13 15:16:32
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local DragonWorldCupHallOfFamePopupView_ui = class("DragonWorldCupHallOfFamePopupView_ui")

--#ui propertys


--#function
function DragonWorldCupHallOfFamePopupView_ui:create(owner, viewType)
	local ret = DragonWorldCupHallOfFamePopupView_ui.new()
	CustomUtility:DoRes(208, true)
	CustomUtility:DoRes(7, true)
	CustomUtility:DoRes(205, true)
	CustomUtility:DoRes(500, true)
	CustomUtility:DoRes(7, true)
	CustomUtility:LoadUi("DragonWorldCupHallOfFamePopupView.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function DragonWorldCupHallOfFamePopupView_ui:initLang()
end

function DragonWorldCupHallOfFamePopupView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function DragonWorldCupHallOfFamePopupView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function DragonWorldCupHallOfFamePopupView_ui:onMyEditButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onMyEditButtonClick", pSender, event)
end

function DragonWorldCupHallOfFamePopupView_ui:onMySendButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onMySendButtonClick", pSender, event)
end

function DragonWorldCupHallOfFamePopupView_ui:onKingEditButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onKingEditButtonClick", pSender, event)
end

function DragonWorldCupHallOfFamePopupView_ui:onKingSendButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onKingSendButtonClick", pSender, event)
end

function DragonWorldCupHallOfFamePopupView_ui:onPlayButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onPlayButtonClick", pSender, event)
end

function DragonWorldCupHallOfFamePopupView_ui:onMatchButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onMatchButtonClick", pSender, event)
end

return DragonWorldCupHallOfFamePopupView_ui

