local DragonWorldCupShareView = class("DragonWorldCupShareView",
	function()
		return PopupBaseView:create()
	end
)
DragonWorldCupShareView.__index = DragonWorldCupShareView

local dragonWorldCupManager = require("game.dragonWorldCup.DragonWorldCupManager")

function DragonWorldCupShareView:create()
	local view = DragonWorldCupShareView.new()
	Drequire("game.dragonWorldCup.DragonWorldCupShareView_ui"):create(view, 1)
	if view:initView() then
		return view
	end
end

function DragonWorldCupShareView:initView()
	if self:init(true, 0) then
		
		self:setHDPanelFlag(true)

		if CCCommonUtilsForLua:isIosAndroidPad() then
			self.ui.nodeccb:setScale(2)
		end

		local listSize = self.ui.m_listNode:getContentSize()
		self.ui.m_listNode:setContentSize(cc.size(listSize.width, listSize.height))
		self.m_tableView = cc.TableView:create(self.ui.m_listNode:getContentSize())
		self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL)
		self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
		self.m_tableView:setAnchorPoint(ccp(0, 0))
		self.m_tableView:setDelegate()
		self.m_tableView:registerScriptHandler(function(tab) return self:scrollViewDidScroll(tab) end, cc.SCROLLVIEW_SCRIPT_SCROLL)
		self.m_tableView:registerScriptHandler(function(tab, idx) return self:cellSizeForTable(tab, idx) end, cc.TABLECELL_SIZE_FOR_INDEX)
		self.m_tableView:registerScriptHandler(function(tab, idx) return self:tableCellAtIndex(tab, idx) end, cc.TABLECELL_SIZE_AT_INDEX)
		self.m_tableView:registerScriptHandler(function(tab) return self:numberOfCellsInTableView(tab) end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
		self.ui.m_listNode:addChild(self.m_tableView)

		self.m_rewardWaitInterFace = GameController:call("showWaitInterface1", self.ui.m_listNode)
		self.m_rewardWaitInterFace:setPosition(listSize.width / 2, listSize.height / 2)

		local isChina = GlobalData:call("isChinaPlatForm")
		self.ui.m_shareNodeCN:setVisible(isChina)
		self.ui.m_shareNodeEN:setVisible(not isChina)

		self.ui.m_firstShare:setString(getLang("5200125"))
		self.ui.m_titleLabel:setString(getLang("5200123"))
		self.ui.m_terraceLabel:setString(getLang(""))

		CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnFBShare, getLang("107098"))
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnSinaShare, getLang("107098"))
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnWCShare, getLang("107098"))
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_okBtn, getLang("confirm"))

		local getRewardCmd = require("game.command.DragonWorldCupGetShareRewardCmd").create()
		getRewardCmd:send()

		local touchLayer = cc.Layer:create()
		self:addChild(touchLayer)

		local function touchHandle( eventType, x, y )
			-- print("touchHandle", eventType, x, y)
			if eventType == "began" then
				return self:onTouchBegan(x, y)
			elseif eventType == "moved" then
			
			else
				self:onTouchEnded(x, y)
			end
		end
		touchLayer:registerScriptTouchHandler(touchHandle)
		touchLayer:setTouchEnabled(true)
		touchLayer:setSwallowsTouches(false)

		return true
	end

	return false 
end

function DragonWorldCupShareView:onTouchBegan(x, y)
	self.startPoint = ccp(x, y)
	return true
end

function DragonWorldCupShareView:onTouchEnded(x, y)
	if ccpDistance(self.startPoint, ccp(x, y)) > 30 then return end

	if not isTouchInside(self.ui.m_clickArea, x, y) then
		PopupViewController:call("removePopupView", self)
	end
end

function DragonWorldCupShareView:onEnter()
	local function callback1(param) self:refreshView(param) end
	local function callback2(param) self:shareSuccess() end
	local function callback3(param) self:shareSuccess() end
	local handler1 = self:registerHandler(callback1)
	local handler2 = self:registerHandler(callback2)
	local handler3 = self:registerHandler(callback3)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "dragon.worldcup.share.reward")
	CCSafeNotificationCenter:registerScriptObserver(self, handler2, "MFBFeedDialogResult")
	CCSafeNotificationCenter:registerScriptObserver(self, handler3, "WeiBoFeedDialogResult")
end

function DragonWorldCupShareView:onExit()
	GlobalData:call("shared"):setProperty("isBind", false)
	CCSafeNotificationCenter:unregisterScriptObserver(self, "dragon.worldcup.share.reward")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "MFBFeedDialogResult")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "WeiBoFeedDialogResult")
end

function DragonWorldCupShareView:refreshView(param)
	self.m_rewardWaitInterFace:removeFromParent()
	local dict = tolua.cast(param, "CCDictionary")
	if dict then
		local infoTable = dictToLuaTable(dict)
		self.rewardInfos = infoTable.reward
		self.m_tableView:reloadData()
	end
end

function DragonWorldCupShareView:shareSuccess()
	local function delayShowSuccess()
		local command = require("game.command.DragonWorldCupShareCmd").create()
		command:send()

		PopupViewController:call("removePopupView", self)
	end

	local node = cc.Node:create()
	self:addChild(node)
	performWithDelay(node, delayShowSuccess, 0.5) 
end

function DragonWorldCupShareView:scrollViewDidScroll(tab)
	local maxdx = self.m_tableView:maxContainerOffset().x
	local dx = self.m_tableView:getContentOffset().x
	if (dx > maxdx) then
		self.m_tableView:setContentOffset(ccp(maxdx, 0))
	end
end

function DragonWorldCupShareView:cellSizeForTable(tab, idx)
	return 108.0, 110.0
end

function DragonWorldCupShareView:tableCellAtIndex(tab, idx)
	local node = require("game.dragonWorldCup.DragonWorldCupShareRewardCell"):create(self.rewardInfos[idx + 1])
	node:setTag(666)
	
	local cell = cc.TableViewCell:create()
	cell:addChild(node)
	return cell
end

function DragonWorldCupShareView:numberOfCellsInTableView(tab)
	return type(self.rewardInfos) == "table" and #self.rewardInfos or 0
end

--facebook分享
function DragonWorldCupShareView:onFaceBookShare()
	-- body
	local shareStr = "wag_fb"
	if not FBUtiliesInLua:call("fbIsLogin") then
		FBUtiliesInLua:call("fbLogin")
		return
	end

	self.ui.m_btnFBShare:setEnabled(false)

	GlobalData:call("shared"):setProperty("isBind", true)

	local shareFbmap = GlobalData:call("shared"):getProperty("shareFbmap")
	if shareFbmap[shareStr] then
		local dict = shareFbmap[shareStr]
		local name = getLang(dict:valueForKey("name"):getCString())
		local caption = getLang(dict:valueForKey("caption"):getCString())
		local linkDescription = dict:valueForKey("linkDescription"):getCString()
		local pictureUrl = dict:valueForKey("pictureUrl"):getCString()
		local link = dict:valueForKey("link"):getCString()
		local ref = dict:valueForKey("ref"):getCString()

		FBUtiliesInLua:call("fbPublishFeedDialog", name, caption, linkDescription, link, pictureUrl, 1, ref)
		AppLibHelper:call("triggerEventPromotionForAdwords", TriggerEventPromotionType.eTriggerEventPromotion_Share)
		self.m_waitInterFace = GameController:call("showWaitInterface1", self.ui.m_btnFBShare)

		if isAndroid() then
			local command = require("game.command.DragonWorldCupShareCmd").create()
			command:send()
		end
	end
end

--新浪微博分享
function DragonWorldCupShareView:onSinaShare()
	-- body
	SocialShareController:call("shareWeiBo", SocialShareTriggerType.eSocialShareTrigger_DragonBattle)
end

--微信聊天式分享
function DragonWorldCupShareView:onWebChatShare()
	-- body
	SocialShareController:call("shareWeiXin", SocialShareTriggerType.eSocialShareTrigger_DragonBattle)
end

function DragonWorldCupShareView:onOkBtnClick()
	PopupViewController:call("removePopupView", self)
end



return DragonWorldCupShareView