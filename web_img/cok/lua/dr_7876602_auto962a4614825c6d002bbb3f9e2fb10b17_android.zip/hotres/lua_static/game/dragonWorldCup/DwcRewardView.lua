--新版世界杯奖励页面
local DwcRewardView = class("DwcRewardView", PopupBaseView)

function DwcRewardView:create(playoff)
    local view = DwcRewardView.new(playoff)
    Drequire("game.dragonBattle.DragonBattleRewardView_ui"):create(view, 0)
    if view:initView() then return view end
end

function DwcRewardView:ctor(playoff)
    self.playoff = playoff or false
end

function DwcRewardView:initView()
    self.ui.m_titleTxt:setString(getLang("9201291"))
    self.ui.m_wlRewardTxt:setString(getLang("140779"))
    self.ui.m_rankRewardTxt:setString(getLang("9201292"))

    if self.playoff then
        self.ui.m_rankRewardTip:setString(getLang("9201290"))
    else
        self.ui.m_rankRewardTip:setString(getLang("9201252"))
    end
    
    self.ui.m_rankRewardTip:setPositionY(self.ui.m_rankRewardTip:getPositionY() + 18)
    local viewSize = self.ui.m_rankNode:getContentSize()
    viewSize.height = viewSize.height + 45
    self.ui.m_rankNode:setContentSize(viewSize)

    self:onBtnRankRewardClick()
    return true
end

function DwcRewardView:onEnter()
    UIComponent:call("showPopupView", 1)
end

function DwcRewardView:onExit()

end

function DwcRewardView:onBtnWlRewardClick()
    self.ui.m_rewardNode:setVisible(true)
    self.ui.m_rankRewardNode:setVisible(false)

    local x, y = self.ui.m_wlRewardBtn:getPosition()
    self.ui.m_btnSprite:setPosition(x, y)

    if self.wlRewardNode == nil then
        local viewSize = self.ui.m_rewardNode:getContentSize()
        self.wlRewardNode = Drequire("game.dragonWorldCup.DwcWLRewardNode"):create(viewSize)
        self.ui.m_rewardNode:addChild(self.wlRewardNode)
    end
end

function DwcRewardView:onBtnRankRewardClick()
    self.ui.m_rewardNode:setVisible(false)
    self.ui.m_rankRewardNode:setVisible(true)

    local x, y = self.ui.m_rankRewardBtn:getPosition()
    self.ui.m_btnSprite:setPosition(x, y)

    if self.rankRewardNode == nil then
        local viewSize = self.ui.m_rankNode:getContentSize()
        local params = {
            viewSize = viewSize,
            playoff = self.playoff,
            type = 1,
        }
        self.rankRewardNode = Drequire("game.dragonWorldCup.DwcTurnRewardNode"):create(params)
        self.ui.m_rankNode:addChild(self.rankRewardNode)
    end
end

return DwcRewardView