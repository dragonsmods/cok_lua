local DragonWorldCupExtraKnockView = class("DragonWorldCupExtraKnockView",
	function()
		return PopupBaseView:create()
	end
)
DragonWorldCupExtraKnockView.__index = DragonWorldCupExtraKnockView

local DragonWorldCupPVPCell = class("DragonWorldCupPVPCell",
	function()
		return CCLayer:create()
	end
)
DragonWorldCupPVPCell.__index = DragonWorldCupPVPCell

local TOP_HEIGHT = 75
local TOP_HEIGHT_HD = 154

local THUMBUP_TURN = true --每轮只能支持一个队伍 

local dragonWorldCupManager = require("game.dragonWorldCup.DragonWorldCupManager")

function DragonWorldCupExtraKnockView:create()
	-- body
	local view = DragonWorldCupExtraKnockView.new()
	Drequire("game.dragonWorldCup.DragonWorldCupAgainstView_ui"):create(view, 0)
	if view:initView() then
		return view
	end
end

function DragonWorldCupExtraKnockView:initView()
	if self:init(true, 0) then
		-- body	
		self:setIsHDPanel(true)

		CCLoadSprite:call("doResourceByCommonIndex", 205, true)

		local dh = TOP_HEIGHT + 5
		local ccbSize = cc.size(640, 852)
		if CCCommonUtilsForLua:isIosAndroidPad() then
			dh = TOP_HEIGHT_HD + 5
			ccbSize = cc.size(1536, 2048)
		end

		local extHeight = self:call("getExtendHeight")
		self.ui.nodeccb:setPositionY(self.ui.nodeccb:getPositionY() - dh)

		--local ccbSize = self.ui.nodeccb:getContentSize()
		local winSize = cc.Director:sharedDirector():getIFWinSize()

		self:setContentSize(ccbSize)
		self.ui.m_bottomNode:setPositionY(dh + 10 - (winSize.height - ccbSize.height))
		self.ui.m_baseBackNode:setPositionY(self.ui.m_baseBackNode:getPositionY() - extHeight + dh)

		if CCCommonUtilsForLua:isIosAndroidPad() then
			self.ui.m_bottomNode:setScale(2.4)
			self.ui.m_baseMoveNode:setScale(2.4)
			self.ui.m_baseMoveNode:setPositionY(self.ui.m_baseMoveNode:getPositionY() + 200)
		end 
		
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnAgainst, getLang("133005"))
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnSelectTime, getLang("140274"))
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnFight, getLang("140013"))
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnManageFight, getLang("140043"))
		
		self.ui.m_baseMoveNode:removeAllChildren()
		self.ui.m_timeBG:setPositionX(self.ui.m_timeBG:getPositionX() + 40)
		-- self.ui.m_btnFight:setPositionX(self.ui.m_btnFight:getPositionX() + 40)
		-- self.ui.m_btnSelectTime:setPositionX(self.ui.m_btnSelectTime:getPositionX() + 40)
		-- self.ui.m_btnAgainst:setPositionX(self.ui.m_btnAgainst:getPositionX() - 40)

		self.ui.m_currSp1:getParent():removeFromParent()
		self.ui.m_currSp2:getParent():removeFromParent()
		self.ui.m_currSp3:getParent():removeFromParent()
		self.ui.m_currSp4:getParent():removeFromParent()
		self.ui.m_currSp5:getParent():removeFromParent()
		self.ui.m_currSp6:getParent():removeFromParent()
		self.ui.m_currSp7:getParent():removeFromParent()
		self.ui.m_currSp8:getParent():removeFromParent()

		self.ui.m_fireNode:setVisible(true)

		--self:refreshView()
		self:addFireParticle()

		return true
	end

	return false
end

function DragonWorldCupExtraKnockView:scheduleUpdate()
    local function updatefunc(dt) self:onEnterFrame(dt) end 
    self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(updatefunc, 1.0, false)
end

function DragonWorldCupExtraKnockView:unscheduleUpdate()
    if self.entry then
        cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
        self.entry = nil
    end
end

function DragonWorldCupExtraKnockView:onEnterFrame( )
	if dragonWorldCupManager.isBeforeMatch() then
		self.ui.m_btnSelectTime:setVisible(true)
		self.ui.m_btnManageFight:setVisible(true)
		self.ui.m_btnFight:setVisible(false)
	elseif dragonWorldCupManager.isBeforeBattle() then
		self.ui.m_btnSelectTime:setVisible(false)
		self.ui.m_btnManageFight:setVisible(true)
		self.ui.m_btnFight:setVisible(true)
		self.ui.m_btnFight:setEnabled(false)
	elseif dragonWorldCupManager.isInBattle() then
		self.ui.m_btnSelectTime:setVisible(false)
		self.ui.m_btnManageFight:setVisible(true)
		self.ui.m_btnFight:setVisible(true)
		self.ui.m_btnFight:setEnabled(self.inFight)
	elseif dragonWorldCupManager.isBattleOver() then
		self.ui.m_btnSelectTime:setVisible(false)
		self.ui.m_btnManageFight:setVisible(false)
		self.ui.m_btnFight:setVisible(true)
		self.ui.m_btnFight:setEnabled(false)
	end

	if self.inFight then
		self.ui.m_timeBG:setVisible(true)
		self.ui.m_timeLabel:setVisible(true)

		local worldCupInfo = self.worldCupInfo
		local now = LuaController:call("getTimeStamp")
		local matchStartTime = worldCupInfo.matchStartTime
		local battleBeginTime = worldCupInfo.battleBeginTime
		local battleEndTime = worldCupInfo.battleEndTime

		if dragonWorldCupManager.isBeforeMatch() then
			local remain = matchStartTime - now
			self.ui.m_timeLabel:setString(getLang("140275", format_time(remain)))
		elseif dragonWorldCupManager.isBeforeBattle() then
			local remain = battleBeginTime - now
			self.ui.m_timeLabel:setString(getLang("140276", format_time(remain)))
		elseif dragonWorldCupManager.isInBattle() then
			local remain = battleEndTime - now
			self.ui.m_timeLabel:setString(getLang("140060", format_time(remain)))
		else
			self.ui.m_timeBG:setVisible(false)
			self.ui.m_timeLabel:setVisible(false)
		end
	else
		self.ui.m_timeBG:setVisible(false)
		self.ui.m_timeLabel:setVisible(false)
	end
end

function DragonWorldCupExtraKnockView:onEnter( )
	self:setTitleName(getLang("5200108"))
	self:scheduleUpdate()
	self:onEnterFrame()

	local function callback1() self:refreshView() end
	local function callback2() self:shareSuccess() end
	local function callback3() self:shareSuccess() end
	local handler1 = self:registerHandler(callback1)
	local handler2 = self:registerHandler(callback2)
	local handler3 = self:registerHandler(callback3)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "dragon.worldcup.data.back")
	CCSafeNotificationCenter:registerScriptObserver(self, handler2, "MFBFeedDialogResult")
	CCSafeNotificationCenter:registerScriptObserver(self, handler3, "WeiBoFeedDialogResult")
end

function DragonWorldCupExtraKnockView:onExit( )
	GameController:call("removeWaitInterface")
	self:unscheduleUpdate()
	CCSafeNotificationCenter:unregisterScriptObserver(self, "dragon.worldcup.data.back")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "MFBFeedDialogResult")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "WeiBoFeedDialogResult")
end

function DragonWorldCupExtraKnockView:shareSuccess()
	local function delayShowSuccess()
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("111137"))
	end

	local node = cc.Node:create()
	self:addChild(node)
	performWithDelay(node, delayShowSuccess, 0.5) 
end

function DragonWorldCupExtraKnockView:addFireParticle()
	self.ui.m_fireNode1:removeAllChildren()
	self.ui.m_fireNode2:removeAllChildren()

	if (DynamicResourceController2:call("checkDynamicResource", "dragonGlobal") and CCLoadSprite:call("loadDynamicResourceByName", "dragonGlobal")) then 
		self.ui.m_fireSp1:setSpriteFrame(CCLoadSprite:call("loadResource", "dragonFire.png"))
		self.ui.m_fireSp2:setSpriteFrame(CCLoadSprite:call("loadResource", "dragonFire.png"))

		local fire1 = ParticleController:call("createParticle", "RankingFirst4_fire")
		self.ui.m_fireNode1:addChild(fire1)

		local fire2 = ParticleController:call("createParticle", "RankingFirst4_fire")
		self.ui.m_fireNode2:addChild(fire2)

		self.ui.m_fireSp1:setPositionY(self.ui.m_fireSp1:getPositionY() + 80)
		self.ui.m_fireSp2:setPositionY(self.ui.m_fireSp2:getPositionY() + 80)
		self.ui.m_fireNode1:setPositionY(self.ui.m_fireNode1:getPositionY() + 20)
		self.ui.m_fireNode2:setPositionY(self.ui.m_fireNode2:getPositionY() + 20)
	else
		for i = 1, 4 do
			local fire1 = ParticleController:call("createParticle", "UiFire_" .. i)
			self.ui.m_fireNode1:addChild(fire1)

			local fire2 = ParticleController:call("createParticle", "UiFire_" .. i)
			self.ui.m_fireNode2:addChild(fire2)
		end
	end

   	local centerParticle = ParticleController:call("createParticle", "RankingFirst4_centre")
   	local contentSize = self.ui.m_baseMoveNode:getContentSize()
   	centerParticle:setPosition(contentSize.width / 2, contentSize.height / 2)
   	self.ui.m_baseMoveNode:addChild(centerParticle, 1, 666)
end


function DragonWorldCupExtraKnockView:refreshView()
	self.worldCupInfo = dragonWorldCupManager.getWorldCupData()
	self.groups = self.worldCupInfo.groups
	self.inFight = false
	self:setInFight()
	MyPrint("self.inFight", self.inFight)
	self:checkThumbState()
	self.ui.m_btnManageFight:setEnabled(self.inFight)
	self.ui.m_btnSelectTime:setEnabled(self.inFight)
	self.ui.m_btnFight:setEnabled(self.inFight)
	self:updateAgainstView()
end

function DragonWorldCupExtraKnockView:setInFight()
	if self.groups == nil then return end

	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	if not playerInfo:call("isInAlliance") then return end

	self.allianceId = playerInfo:call("getAllianceId")
	MyPrint("self.allianceId", self.allianceId)
	for i = 1, #self.groups, 1 do
		local data = self.groups[i]
		for j = 1, #data.teamArr, 1 do
			local team = data.teamArr[j]
			if team.allianceId == self.allianceId then
				self.inFight = true
				break
			end
		end
	end
end

function DragonWorldCupExtraKnockView:checkThumbState()
	if self.groups == nil then return end

	for i = 1, #self.groups, 1 do
		local data = self.groups[i]
		for j = 1, #data.teamArr, 1 do
			local team = data.teamArr[j]
			if team.thumbUpState == "1" or team.thumbUpState == true then
				THUMBUP_TURN = false
				return
			end
		end
	end
end

function DragonWorldCupExtraKnockView:updateAgainstView()
	local curY = 0
	local groupNum = #self.groups
	local node = cc.Node:create()
	MyPrint("groupNum", groupNum)
	for i = 1, groupNum do
		local group = self.groups[i]
		local teamArr = group.teamArr

		for j = #teamArr - 1, 1, -2 do
			local leftTeam = teamArr[j]
			local rightTeam = teamArr[j + 1]
			if leftTeam and rightTeam then
				local battleNode = DragonWorldCupPVPCell:create(leftTeam, rightTeam)
				battleNode:setPositionY(curY)
				node:addChild(battleNode)
				curY = curY + 220
			end
		end
	end

	node:setContentSize(cc.size(640, curY - 50))
	node:setAnchorPoint(ccp(0.5, 0.5))

	local contentSize = self.ui.m_baseMoveNode:getContentSize()
   	node:setPosition(contentSize.width / 2, contentSize.height / 2)
   	self.ui.m_baseMoveNode:addChild(node, 1, 444)
end

function DragonWorldCupExtraKnockView:onSelectTimeClick()
	local lua_path = "game.dragonWorldCup.DragonWorldCupKPMatchView"
	package.loaded[lua_path] = nil
	local kpMatchView = require(lua_path):create()
	PopupViewController:addPopupView(kpMatchView)
end

function DragonWorldCupExtraKnockView:onFightClick()
	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	if playerInfo:call("isInAlliance") then
		local selfAllianceId = playerInfo:call("getAllianceId")
		dragonWorldCupManager.enterDragonBattle(selfAllianceId, false)
	end
end

function DragonWorldCupExtraKnockView:onManageClick()
	local lua_path = "game.dragonWorldCup.DragonWorldCupManagerView"
	package.loaded[lua_path] = nil 
	local canNot = dragonWorldCupManager.canNotModifyBattleList()
	local managerView = require(lua_path):create(canNot)
	PopupViewController:addPopupInView(managerView)
end

function DragonWorldCupExtraKnockView:onAgainstClick()
	local lua_path = "game.dragonWorldCup.DragonWorldCupKnockRewardView"
	package.loaded[lua_path] = nil 
	local rewardView = require(lua_path):create()
	PopupViewController:addPopupInView(rewardView)
end


function DragonWorldCupPVPCell:create(leftTeam, rightTeam)
	local view = DragonWorldCupPVPCell.new()
	Drequire("game.dragonWorldCup.DragonWorldCupPVPCell_ui"):create(view, 1)
	if view:initView(leftTeam, rightTeam) then
		return view
	end
end

function DragonWorldCupPVPCell:initView(leftTeam, rightTeam)
	self.leftTeam = leftTeam
	self.rightTeam = rightTeam

	local groupIndex = tonumber(leftTeam.groupIndex) or 0
	if groupIndex > 0 then
		self.ui.m_leftGroup:setString(getLang("5200107", string.char(65 + (groupIndex) - 1)))
	end
	self.ui.m_leftName:setString("(" .. leftTeam.abbr .. ") " .. leftTeam.name)
	self.ui.m_leftKingdom:setString(leftTeam.kingdomName)
	self.ui.m_leftSupportLabel:setString(getLang("5200142", CC_CMDITOA(leftTeam.thumbUps)))

	local groupIndex = tonumber(rightTeam.groupIndex) or 0
	if groupIndex > 0 then
		self.ui.m_rightGroup:setString(getLang("5200107", string.char(65 + (groupIndex) - 1)))
	end
	self.ui.m_rightName:setString("(" .. rightTeam.abbr .. ") " .. rightTeam.name)
	self.ui.m_rightKingdom:setString(rightTeam.kingdomName)
	self.ui.m_rightSupportLabel:setString(getLang("5200142", CC_CMDITOA(rightTeam.thumbUps)))

	self.ticketPayed = (self.leftTeam.ticketPayed ~= "0" or self.rightTeam.ticketPayed ~= "0")
	self.obSwitch = CCCommonUtilsForLua:isFunOpenByKey("wag_ob")

	self:addFlag()
	self:addParticle()

	local touchLayer = cc.Layer:create()
	self:addChild(touchLayer)

	local function touchHandle( eventType, x, y )
		-- print("touchHandle", eventType, x, y)
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "moved" then
		
		else
			self:onTouchEnded(x, y)
		end
	end
	touchLayer:registerScriptTouchHandler(touchHandle)
	touchLayer:setTouchEnabled(true)
	touchLayer:setSwallowsTouches(false)

	return true
end

function DragonWorldCupPVPCell:addFlag()
	-- local leftCountry = self.leftTeam.country
	-- local rightCountry = self.rightTeam.country

	self.leftTeam.icon = (self.leftTeam.icon == "") and "Allance_flay" or self.leftTeam.icon
	self.rightTeam.icon = (self.rightTeam.icon == "") and "Allance_flay" or self.rightTeam.icon

	local flag = AllianceFlagPar:call("create", self.leftTeam.icon .. ".png")
	self.ui.m_leftFlagNode:addChild(flag)

	local flag = AllianceFlagPar:call("create", self.rightTeam.icon .. ".png")
	self.ui.m_rightFlagNode:addChild(flag) 
end

function DragonWorldCupPVPCell:addParticle()
	local ccbSize = self.ui.nodeccb:getContentSize()
	local up = ParticleController:call("createParticle", "RankingFirst4_up")
	up:setPositionX(-300)
	up:setPositionY(ccbSize.height / 2)
    self.ui.m_effectNode:addChild(up)

    local down = ParticleController:call("createParticle", "RankingFirst4_down")
    down:setPositionX(-300)
    down:setPositionY(-ccbSize.height / 2)
    self.ui.m_effectNode:addChild(down)
end
	
function DragonWorldCupPVPCell:onTouchBegan(x, y)
	self.startPoint = ccp(x, y)
	if isTouchInside(self.ui.m_leftHandTouchNode, x, y) then  
		self.supportTeam = self.leftTeam
		self.supportLeft = true
		self.supprtFlag = true
		return true 
	end
	if isTouchInside(self.ui.m_rightHandTouchNode, x, y) then 
		self.supportTeam = self.rightTeam
		self.supportLeft = false
		self.supprtFlag = true
		return true 
	end

	if isTouchInside(self.ui.m_leftTouchNode, x, y) then
		self.supprtFlag = false
		return true
	end

	if isTouchInside(self.ui.m_rightTouchNode, x, y) then
		self.supprtFlag = false
		return true
	end

	return false
end

function DragonWorldCupPVPCell:onTouchEnded(x, y)
	if ccpDistance(self.startPoint, ccp(x, y)) > 10 then return end

	if self.supprtFlag then
		self.canThumbUp = (self.leftTeam.thumbUpState == "0" and self.rightTeam.thumbUpState == "0") and THUMBUP_TURN

		local now = LuaController:call("getTimeStamp")
		local startTime = tonumber(self.supportTeam.battleStartTime)
		if now > startTime then
			CCCommonUtilsForLua:call("flyHint", "", "", getLang("5200127"))
			return
		end

		if self.canThumbUp then
			local supportView = require("game.dragonWorldCup.DragonWorldCupSupportView"):create(self.supportTeam.allianceId)
			PopupViewController:addPopupView(supportView)
		elseif (not self.canThumbUp and self.supportTeam.thumbUpState ~= "0") then
			CCCommonUtilsForLua:call("flyHint", "", "", getLang("5200035"))
		else
			CCCommonUtilsForLua:call("flyHint", "", "", getLang("5200034"))
		end
	else
		if isTouchInside(self.ui.m_leftTouchNode, x, y) then
			local againstMessageView = require("game.dragonWorldCup.DragonWorldCupAllianceMessageView"):create(self.leftTeam.allianceId)
			PopupViewController:addPopupInView(againstMessageView)
		end

		if isTouchInside(self.ui.m_rightTouchNode, x, y) then
			local againstMessageView = require("game.dragonWorldCup.DragonWorldCupAllianceMessageView"):create(self.rightTeam.allianceId)
			PopupViewController:addPopupInView(againstMessageView)
		end 
	end
end

function DragonWorldCupPVPCell:scheduleUpdate()
    local function updatefunc(dt) self:onEnterFrame(dt) end 
    self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(updatefunc, 1.0, false)
end

function DragonWorldCupPVPCell:unscheduleUpdate()
    if self.entry then
        cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
        self.entry = nil
    end
end

function DragonWorldCupPVPCell:onEnterFrame()
	local now = LuaController:call("getTimeStamp")
	local startTime = tonumber(self.leftTeam.battleStartTime)
	local endTime = tonumber(self.leftTeam.battleEndTime)
	local obEntryVisible = false

	if (startTime > 0 and now < startTime) then
		obEntryVisible = true
		local leftTime = startTime - now
		self.ui.m_liveTime:setString(format_time(leftTime))
		self.ui.m_iconTime:setVisible(true) 
	elseif (now >= startTime and now < endTime) then
		obEntryVisible = true
		self.ui.m_liveTime:setString(getLang("140364"))
		self.ui.m_iconTime:setVisible(true) 
	elseif (endTime > 0 and now >= endTime) then
		obEntryVisible = false
		self.ui.m_liveTime:setString(getLang("5200048"))
		self.ui.m_iconTime:setVisible(true) 	
	else
		obEntryVisible = false
		self.ui.m_liveTime:setString("")
		self.ui.m_iconTime:setVisible(false) 
	end

	--ob按钮
	if self.obSwitch then
		self.ui.m_btnLiveRed:setVisible(obEntryVisible)
	else
		self.ui.m_btnLiveRed:setVisible(false)
	end
end

function DragonWorldCupPVPCell:onEnter()
	self:scheduleUpdate()
	self:onEnterFrame()
	local function callback1(param) self:thumbUpAct(param) end
	local handler1 = self:registerHandler(callback1)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "dragon.worldcup.support.success")
end

function DragonWorldCupPVPCell:onExit()
	self:unscheduleUpdate()
	CCSafeNotificationCenter:unregisterScriptObserver(self, "dragon.worldcup.support.success")
end

function DragonWorldCupPVPCell:thumbUpAct(param)
	local pstr = tolua.cast(param, "CCString")
	if pstr then
		local allianceId = pstr:getCString()
		MyPrint("thumbUpAct allianceId", allianceId)
		
		if self.supportTeam == nil then return end

		MyPrint("supportTeam allianceId", self.supportTeam.allianceId)

		if allianceId ~= self.supportTeam.allianceId then return end
		
		local thumbUpsLabel = self.supportLeft and self.ui.m_leftSupportLabel or self.ui.m_rightSupportLabel
		local thumbUpsLabelSize = thumbUpsLabel:getContentSize()
		local hintColor = left and cc.c3b(144, 207, 224) or cc.c3b(236, 222, 156)
		local hintFontSize = 14
			
		THUMBUP_TURN = false
		self.supportTeam.thumbUps = tonumber(self.supportTeam.thumbUps)
		MyPrint("self.supportTeam.thumbUps", self.supportTeam.thumbUps)
		self.supportTeam.thumbUpState = "1"
		self.supportTeam.thumbUps = self.supportTeam.thumbUps + 1
		MyPrint("self.supportTeam.thumbUps", self.supportTeam.thumbUps)
		thumbUpsLabel:setString(getLang("5200142", CC_CMDITOA(tostring(self.supportTeam.thumbUps))))

		local hint = CCLabelIF:call("create")
		hint:call("setString", "+1")
		hint:call("setColor", hintColor)
		hint:call("setFontSize", hintFontSize)

		hint = tolua.cast(hint, "cc.Node")

		local posx, posy = thumbUpsLabel:getPosition()
		posx = posx + thumbUpsLabelSize.width / 2
		local par = thumbUpsLabel:getParent()
		par:addChild(hint)
		hint:setPosition(posx, posy)

		local moveTo = cc.MoveTo:create(0.5, ccp(posx, posy + 30))
		local fadeOut = cc.FadeOut:create(0.5)
		local spawn = cc.Spawn:create(moveTo, fadeOut)
		local function removeSelf() hint:removeFromParent() end
		local callfunc = cc.CallFunc:create(removeSelf)
		local seq = cc.Sequence:create(spawn, callfunc)
		hint:runAction(seq)	

		self.supportTeamc = nil
	end
end

function DragonWorldCupPVPCell:onClickShare()
	local shareView = require("game.dragonWorldCup.DragonWorldCupShareView"):create()
	PopupViewController:addPopupView(shareView)
end

function DragonWorldCupPVPCell:onLiveClickRed()
	local allianceId = self.leftTeam.allianceId
	local now = LuaController:call("getTimeStamp")
	if now < tonumber(self.leftTeam.battleStartTime) then
		local leftTime = self.leftTeam.battleStartTime - now
		YesNoDialog:call("show", getLang("140365", format_time(leftTime)))
	elseif now > tonumber(self.leftTeam.battleEndTime) then
		YesNoDialog:call("show", getLang("140367"))
	else
		if self.ticketPayed then
			self:sureToOB(allianceId)
		else
			local itemId = dragonWorldCupManager.getPlayOffObItemId()
			local info = ToolController:call("getToolInfoByIdForLua", itemId)
			local function callback() self:sureToOB(allianceId) end
			local callfunc = cc.CallFunc:create(callback)
			YesNoDialog:call("show", getLang("140366", info:call("getName"), tostring(info:call("getCNT"))), callfunc)
		end
	end
end

function DragonWorldCupPVPCell:sureToOB(allianceId)
	GameController:call("showWaitInterface")
	dragonWorldCupManager.enterDragonBattle(allianceId, true)
end

return DragonWorldCupExtraKnockView