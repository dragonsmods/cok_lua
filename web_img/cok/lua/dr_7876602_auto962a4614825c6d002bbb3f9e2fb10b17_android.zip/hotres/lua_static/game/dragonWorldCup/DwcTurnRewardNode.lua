--世界杯轮次奖励页签
local DwcTurnRewardNode = class("DwcTurnRewardNode", Drequire("game.dragonBattle.PlayOffRankRewardNode"))

function DwcTurnRewardNode:requestData()
    local cmd = Drequire("game.command.DragonWorldCupTurnRewardCmd"):create()
    cmd:send()
end

function DwcTurnRewardNode:getSingleRoundData()
    self.showData = {}
    
    local rewards = {}
    local textArr = {}
    local groupTurn = tonumber(self.sourceData.groupTurn) or 16
    dump(self.sourceData)
    if self.playoff then
        if self.sourceData.award then
            for i, v in ipairs(self.sourceData.award or {}) do
                if i > groupTurn then
                    table.insert(rewards, v)
                end
            end
        end

        if self.sourceData.final then
            for _, v in ipairs(self.sourceData.final or {}) do
                table.insert(rewards, v)
            end
        end

        textArr = 
        {
            getLang("9201285"), 
            getLang("9201286"), 
            getLang("9201287"), 
            getLang("9201288"), 
            getLang("9201289"), 
            getLang("9201293"),
            getLang("9201294"),
        }
    else
        if self.sourceData.award then
            for i, v in ipairs(self.sourceData.award or {}) do
                if i <= groupTurn then
                    table.insert(rewards, v)
                    table.insert(textArr, getLang("140268", i))
                end
            end
        end
    end

    for i = 1, #textArr do
        table.insert(self.showData, 
                { 
                    title2 = textArr[i], 
                    open = (self.showTitle == textArr[i]) 
                })

        if self.showTitle == textArr[i] and i <= #rewards then
            for _, reward in ipairs(rewards[i].reward or {}) do
                table.insert(self.showData, reward)
            end
        end
    end
end

function DwcTurnRewardNode:onEnter()
    registerScriptObserver(self, self.refreshRoundNode, "DwcTurnRewardNode:refreshRoundNode")
end

function DwcTurnRewardNode:onExit()
    registerScriptObserver(self, "DwcTurnRewardNode:refreshRoundNode")
end

return DwcTurnRewardNode