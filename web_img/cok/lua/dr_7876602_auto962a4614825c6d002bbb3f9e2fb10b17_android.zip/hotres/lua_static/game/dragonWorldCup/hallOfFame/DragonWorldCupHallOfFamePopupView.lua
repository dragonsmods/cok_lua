local DragonWorldCupHallOfFamePopupView = class("DragonWorldCupHallOfFamePopupView",
	function()
		return PopupBaseView:create()
	end
)

local DragonWorldCupHallOfFameCell = class("DragonWorldCupHallOfFameCell",
	function()
		return cc.Layer:create()
	end
)

local chinaUri = "http://cokindex.elex.com"
// local facebookUri = "http://f.elex.com/forums/1-clash-of-kings"

local dragonWorldCupManager = require("game.dragonWorldCup.DragonWorldCupManager")

function DragonWorldCupHallOfFamePopupView:create(rank, allianceData, callback)
	local view = DragonWorldCupHallOfFamePopupView.new()
	Drequire("game.dragonWorldCup.hallOfFame.DragonWorldCupHallOfFamePopupView_ui"):create(view, 1)
	if view:initView(rank, allianceData, callback) then
		return view
	end
end

function DragonWorldCupHallOfFamePopupView:initView(rank, allianceData, callback)
	if self:init(true, 0) then
		self:setHDPanelFlag(true)

		self.rank = rank
		self.allianceData = allianceData
		self.callback = callback

		if CCCommonUtilsForLua:isIosAndroidPad() then
			self.ui.m_topNode:setScale(2.4)
		end

		local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
		local selfAllianceId = playerInfo:call("getAllianceId")
		local allianceInfo = playerInfo:getProperty("allianceInfo")
		local rankLevel = allianceInfo:getProperty("rank")

		--MyPrint(selfAllianceId, allianceData.al)
		--是否是自己的联盟
		self.isMyAlli = (selfAllianceId == allianceData.allianceId)
		--是否在盟主
		self.isLeader = (rankLevel == 5)
		--是否在出战名单
		self.isInBattle = self:isInBattleList()
		--是否能够修改联盟宣言
		self.canEditAli = (self.isLeader and self.isMyAlli and self.isInBattle)
		--是否能够修改个人宣言
		self.canEditMySelf = (self.isMyAlli and self.isInBattle)

		--MyPrint("self.isLeader, self.isMyAlli, self.isInBattle",  self.isLeader, self.isMyAlli, self.isInBattle, rankLevel)

		self:setViewBg()
		self:setButtonTitle()
		self:setAlliNode()
		self:setAnnounceNode()
		self:initWebView()

		self.aliEditOpen = false
		self.myEditOpen = false
		self.announcement = ""

		return true
	end

	return false
end

function DragonWorldCupHallOfFamePopupView:setViewBg()
	local sf = CCLoadSprite:call("getSF", "57009_ad1.png")
	if sf then 
		local sp = CCLoadSprite:call("createSprite", "57009_ad1.png")
		self.ui.m_picNode:addChild(sp)
	end

	if DynamicResourceController2:call("checkDynamicResource", "dragonGlobal") 
			and CCLoadSprite:call("loadDynamicResourceByName", "dragonGlobal") then
		self.ui.m_picNode:removeAllChildren()

		local sp = CCLoadSprite:call("createSprite", "mingrentangBG.png")
		sp:setOpacity(0.3 * 255)
		self.ui.m_picNode:addChild(sp)

		local rbg1 = CCLoadSprite:call("createSprite", "mingrentangHong.png")
		self.ui.m_red1Node:addChild(rbg1)

		local rbg2 = CCLoadSprite:call("createSprite", "mingrentangHong.png")
		self.ui.m_red2Node:addChild(rbg2)
		rbg2:setPositionY(-1)

		local rbg3 = CCLoadSprite:call("createSprite", "mingrentangHong.png")
		self.ui.m_red3Node:addChild(rbg3)
		rbg3:setPositionY(0)
	end
end

function DragonWorldCupHallOfFamePopupView:setButtonTitle()
	CCCommonUtilsForLua:setButtonTitle(self.ui.m_matchButton, getLang("5200144"))
	CCCommonUtilsForLua:setButtonTitle(self.ui.m_kingEditButton, getLang("5200145"))
	CCCommonUtilsForLua:setButtonTitle(self.ui.m_myEditButton, getLang("5200145"))
	CCCommonUtilsForLua:setButtonTitle(self.ui.m_kingSendButton, getLang("5200146"))
	CCCommonUtilsForLua:setButtonTitle(self.ui.m_mySendButton, getLang("5200146"))
end

function DragonWorldCupHallOfFamePopupView:setAlliNode()
	local data = self.allianceData
	local flagNode = self.ui.m_flagNode
	local countryNode = self.ui.m_stateNode
	local nameLabel = self.ui.m_stateLabel
	local leaderLabel = self.ui.m_allianceLabel
	local kingdomLabel = self.ui.m_nameLabel


	nameLabel:setString("(" .. data.abbr .. ") " .. data.name)
	leaderLabel:setString(data.leader)
	kingdomLabel:setString(data.kingdomName)

	flagNode:removeAllChildren()
	countryNode:removeAllChildren()

	local flag = AllianceFlagPar:call("create", data.icon .. ".png")
	flagNode:addChild(flag)
	flagNode:setScale(0.71)

	if DynamicResourceController2:call("checkDynamicResource", "dragonGlobal") 
			and CCLoadSprite:call("loadDynamicResourceByName", "dragonGlobal") then
		local miniTag = dragonWorldCupManager.getCountryIcon(data.country)
		local countryFlag = CCLoadSprite:call("createSprite", miniTag)
		countryNode:addChild(countryFlag)
		countryNode:setScale(1.0)
	else
		local countryFlag = CCLoadSprite:call("createSprite", data.country .. ".png", CCLoadSpriteType.CCLoadSpriteType_COUNTRY_ICON)
		countryNode:addChild(countryFlag)
		countryNode:setScale(0.4)
	end

	local rankSp = "Alliance_Ranking" .. (self.rank + 1) .. ".png"
	local sf = CCLoadSprite:call("getSF", rankSp)
	if sf then self.ui.m_numSprite:setSpriteFrame(sf) end
end

function DragonWorldCupHallOfFamePopupView:setAnnounceNode()
	if self.canEditAli then
		self:setEditAlliNode()
	else
		self:setNormalNode()
	end

	self:setTableView()

	if self.canEditMySelf then
		self:setEditMySelfNode()
	else
		self.ui.m_myEditNode:removeFromParent()
	end
end

function DragonWorldCupHallOfFamePopupView:setEditAlliNode()
	local alliAnnouncement = self.allianceData.alliAnnouncement or ""
	self.ui.m_kingNode:setVisible(true)
	self.ui.m_peopleNode:setVisible(false)
	self.ui.m_kingTalkLabel:setString(alliAnnouncement ~= "" and alliAnnouncement or getLang("5200147"))

	local fontSize = 18 or self.ui.m_kingTalkLabel:getFontSize()
	local editSize = self.ui.m_kingTalkLabel:getContentSize()
	self.alliEdit = InputFieldMultiLine:call("create", editSize, "inputBg_grey.png", fontSize)
	self.alliEdit:call("setAddH", 0)
	self.alliEdit:call("setMaxChars", 300)
	self.alliEdit:call("setLineNumber", 3)
	self.alliEdit:call("setFontColor", cc.c3b(140, 140, 140))
	self.alliEdit:call("setSwallowsTouches", true)
	self.alliEdit:call("setMoveFlag", true)
	self.alliEdit:call("setcalCharLen", true)
    self.alliEdit:call("setEmojiCheckFlag", true)
	self.alliEdit:setPosition(ccp(0, 0))
	self.alliEdit:ignoreAnchorPointForPosition(false)
	self.alliEdit:setAnchorPoint(ccp(0.5, 0.5))
	self.alliEdit:setVisible(false)
	self.ui.m_kingNode:addChild(self.alliEdit)

	self.ui.m_kingEditButton:setVisible(true)
	self.ui.m_kingSendButton:setVisible(false)
end

function DragonWorldCupHallOfFamePopupView:setNormalNode()
	local announcement = self.allianceData.alliAnnouncement
	announcement = (announcement and announcement ~= "") and announcement or getLang("5200152")
	self.ui.m_kingNode:setVisible(false)
	self.ui.m_peopleNode:setVisible(true)
	self.ui.m_peopleLabel:setString(announcement)
end

function DragonWorldCupHallOfFamePopupView:setEditMySelfNode()
	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	local uid = playerInfo:getProperty("uid")
	local pic = playerInfo:getProperty("pic")
	local picVer = tonumber(playerInfo:getProperty("picVer"))
	local rankLevel = 5 or playerInfo:call("getAllianceRank")
	local name = playerInfo:getProperty("name")

	if (pic == "") then
		pic = "g044.png"
	else
		pic = pic .. ".png"
	end

	local icon = CCLoadSprite:call("createSprite", pic, CCLoadSpriteType.CCLoadSpriteType_HEAD_ICON)
	CCCommonUtilsForLua:setSpriteMaxSize(icon, 57, true)
	self.ui.m_myHeadNode:addChild(icon)

	if (CCCommonUtilsForLua:call("isUseCustomPic", picVer)) then
		self.m_headImgNode = HFHeadImgNode:call("create")

		local picUrl = CCCommonUtilsForLua:call("getCustomPicUrl", uid, picVer)
		self.m_headImgNode:call("initHeadImgUrl2", self.ui.m_myHeadNode, picUrl, 1.0, 57, true)
	end

	local rankIcon = "Alliance_R" .. rankLevel .. ".png"
	self.ui.m_myLvSprite:setSpriteFrame(CCLoadSprite:call("loadResource", rankIcon))
	self.ui.m_myNameLabel:setString(name)
	self.ui.m_myTalkLabel:setString(self.mineData.announcement ~= "" and self.mineData.announcement or getLang("5200148"))

	local fontSize = 18 or self.ui.m_myTalkLabel:getFontSize()
	local editSize = self.ui.m_myTalkLabel:getContentSize()
	self.myEdit = InputFieldMultiLine:call("create", editSize, "inputBg_grey.png", fontSize)
	self.myEdit:call("setAddH", 0)
	self.myEdit:call("setMaxChars", 300)
	self.myEdit:call("setLineNumber", 3)
	self.myEdit:call("setFontColor", cc.c3b(140, 140, 140))
	self.myEdit:call("setSwallowsTouches", true)
	self.myEdit:setTouchPriority(1)
	self.myEdit:call("setMoveFlag", true)
	self.myEdit:call("setcalCharLen", true)
    self.myEdit:call("setEmojiCheckFlag", true)
	self.myEdit:setPosition(ccp(0, 0))
	self.myEdit:setAnchorPoint(ccp(0.5, 0.5))
	self.myEdit:ignoreAnchorPointForPosition(false)
	self.myEdit:setVisible(false)
	self.ui.m_myTalkLabel:getParent():addChild(self.myEdit)

	self.ui.m_myEditButton:setVisible(true)
	self.ui.m_mySendButton:setVisible(false)
end

function DragonWorldCupHallOfFamePopupView:isInBattleList()
	local ret = false
	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	local uid = playerInfo:getProperty("uid")
	local battleMembers = self.allianceData.battleMembers
	for index, value in ipairs(battleMembers) do
		if value.uid == uid then
			ret = true
			self.mineData = value
			break
		end
	end

	return ret
end

function DragonWorldCupHallOfFamePopupView:setTableView()
	local function sort(mem1, mem2)
		return mem2.rank < mem1.rank
	end

	table.sort(self.allianceData.battleMembers, sort)

	if self.canEditMySelf then
		local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
		local uid = playerInfo:getProperty("uid")

		local mine = nil
		for index, value in ipairs(self.allianceData.battleMembers) do
			if value.uid == uid then
				mine = value
				table.remove(self.allianceData.battleMembers, index)
				break
			end
		end

		if mine then table.insert(self.allianceData.battleMembers, 1, mine) end
	end

	local addHeight = self:call("getExtendHeight")
	local listSize = self.ui.m_listNode:getContentSize()
	self.ui.m_listNode:setContentSize(cc.size(listSize.width, listSize.height + addHeight))
	self.m_tableView = cc.TableView:create(self.ui.m_listNode:getContentSize())
	self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
	self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
	self.m_tableView:setAnchorPoint(ccp(0, 0))
	self.m_tableView:setDelegate()
	self.m_tableView:registerScriptHandler(function(tab) return self:scrollViewDidScroll(tab) end, cc.SCROLLVIEW_SCRIPT_SCROLL)
	self.m_tableView:registerScriptHandler(function(tab, idx) return self:cellSizeForTable(tab, idx) end, cc.TABLECELL_SIZE_FOR_INDEX)
	self.m_tableView:registerScriptHandler(function(tab, idx) return self:tableCellAtIndex(tab, idx) end, cc.TABLECELL_SIZE_AT_INDEX)
	self.m_tableView:registerScriptHandler(function(tab) return self:numberOfCellsInTableView(tab) end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
	self.m_tableView:reloadData()
	self.ui.m_listNode:addChild(self.m_tableView)
end

function DragonWorldCupHallOfFamePopupView:initWebView()
	// local winSize = cc.Director:sharedDirector():getIFWinSize()
	// self.webVew = CCWebView:call("create",  cc.p(0,0), winSize, self)
	// self.webVew:call("setVisible", false)

	// self.uri = GlobalData:call("isChinaPlatForm") and chinaUri or facebookUri
end

function DragonWorldCupHallOfFamePopupView:onEnter()
	self.ui.m_myEditNode:retain()
	local function callback1() self:editBoxReturn() end
	local function callback2(param) self:editAliSuccess(param) end
	local function callback3(param) self:editMineSuccess(param) end
	local handler1 = self:registerHandler(callback1)
	local handler2 = self:registerHandler(callback2)
	local handler3 = self:registerHandler(callback3)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "InputFieldMultiLine.close")
	CCSafeNotificationCenter:registerScriptObserver(self, handler2, "dragon.worldcup.aliAnnounce")
	CCSafeNotificationCenter:registerScriptObserver(self, handler3, "dragon.worldcup.mineAnnounce")
end

function DragonWorldCupHallOfFamePopupView:onExit()
	self.ui.m_myEditNode:release()
	self.webVew:call("setVisible", false)
	CCSafeNotificationCenter:unregisterScriptObserver(self, "InputFieldMultiLine.close")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "dragon.worldcup.aliAnnounce")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "dragon.worldcup.mineAnnounce")
end

function DragonWorldCupHallOfFamePopupView:editBoxReturn()
	if self.aliEditOpen then
		self.alliEdit:call("closeIME")
		self.alliEdit:setVisible(false)
		self.aliEditOpen = false
		self.ui.m_kingTalkLabel:setString(self.alliEdit:call("getText"))
	end

	if self.myEditOpen then
		self.myEdit:call("closeIME")
		self.myEdit:setVisible(false)
		self.myEditOpen = false
		self.ui.m_myTalkLabel:setString(self.myEdit:call("getText"))
	end
end

function DragonWorldCupHallOfFamePopupView:editAliSuccess(param)
	if self.aliWaitInterface then
		self.aliWaitInterface:call("remove")
		self.aliWaitInterface = nil
	end

	self.ui.m_kingEditButton:setVisible(true)
	self.ui.m_kingSendButton:setVisible(false)

	local tbl = dictToLuaTable(param)
	dump(tbl, "editAliSuccess")
	self.allianceData.alliAnnouncement = tbl.infoDic.announcement
	self.allianceData.alliAnnounceCDEndTime = tonumber(tbl.alliAnnounceCDEndTime)
	if self.callback then self.callback(tbl.infoDic.announcement) end

	CCCommonUtilsForLua:call("flyHint", "", "", getLang("5200150"))
end

function DragonWorldCupHallOfFamePopupView:editMineSuccess(param)
	if self.myWaitInterface then
		self.myWaitInterface:call("remove")
		self.myWaitInterface = nil
	end

	self.ui.m_myEditButton:setVisible(true)
	self.ui.m_mySendButton:setVisible(false)

	local tbl = dictToLuaTable(param)
	dump(tbl, "editMineSuccess")
	self.mineData.announcement = tbl.infoDic.announcement

	CCCommonUtilsForLua:call("flyHint", "", "", getLang("5200151"))
end

function DragonWorldCupHallOfFamePopupView:scrollViewDidScroll(tab)
	-- body
	local mindy = self.m_tableView:minContainerOffset().y
	local dy = self.m_tableView:getContentOffset().y
	if (dy < mindy) then
		self.m_tableView:setContentOffset(ccp(0, mindy))
	end
end

function DragonWorldCupHallOfFamePopupView:cellSizeForTable(tab, idx)
	if (idx == 0 and self.canEditMySelf) then
		return 640, 180
	end

	return 640, 110
end

function DragonWorldCupHallOfFamePopupView:tableCellAtIndex(tab, idx)
	local node = (self.canEditMySelf and idx == 0) and self.ui.m_myEditNode or DragonWorldCupHallOfFameCell:create(self.allianceData.battleMembers[idx + 1])
	node:setTag(666)
	node:removeFromParent()
	
	local cell = cc.TableViewCell:create()
	cell:addChild(node)
	return cell
end

function DragonWorldCupHallOfFamePopupView:numberOfCellsInTableView(tab)
	MyPrint("numberOfCellsInTableView", type(self.allianceData.battleMembers) == "table" and #self.allianceData.battleMembers)
	return type(self.allianceData.battleMembers) == "table" and #self.allianceData.battleMembers or 0
end

function DragonWorldCupHallOfFamePopupView:onMatchButtonClick()
	MyPrint("onMatchButtonClick")
	self.webVew:call("loadUrl",  self.uri)
	self.webVew:call("setVisible", true)
end

function DragonWorldCupHallOfFamePopupView:onPlayButtonClick()
	MyPrint("onPlayButtonClick")
	self.webVew:call("loadUrl",  self.uri)
	self.webVew:call("setVisible", true)
end

function DragonWorldCupHallOfFamePopupView:onKingEditButtonClick()
	MyPrint("onKingEditButtonClick")
	-- local now = LuaController:call("getTimeStamp")
	-- if atoi(self.allianceData.alliAnnounceCDEndTime) > now then
	-- 	local leftTime = atoi(self.allianceData.alliAnnounceCDEndTime) - now
	-- 	YesNoDialog:call("show", getLang("5200149", CCCommonUtilsForLua:call("timeStampToUTCHSM", leftTime)))
	-- 	return
	-- end

	self.alliEdit:setVisible(true)
	self.alliEdit:call("setText", self.allianceData.alliAnnouncement)
	self.alliEdit:call("closeIME")
	self.alliEdit:call("openIME")

	self.ui.m_kingEditButton:setVisible(false)
	self.ui.m_kingSendButton:setVisible(true)

	self.aliEditOpen = true
end

function DragonWorldCupHallOfFamePopupView:onKingSendButtonClick()
	MyPrint("onKingSendButtonClick")
	if self.aliEditOpen then return end
	self.aliWaitInterface = GameController:call("showWaitInterface1", self.ui.m_kingSendButton)
	self:announce(true, self.ui.m_kingTalkLabel:getString())
end

function DragonWorldCupHallOfFamePopupView:onMyEditButtonClick()
	MyPrint("onMyEditButtonClick")
	self.myEdit:setVisible(true)
	self.myEdit:call("setText", self.mineData.announcement)
	self.myEdit:call("closeIME")
	self.myEdit:call("openIME")

	self.ui.m_myEditButton:setVisible(false)
	self.ui.m_mySendButton:setVisible(true)

	self.myEditOpen = true
end

function DragonWorldCupHallOfFamePopupView:onMySendButtonClick()
	MyPrint("onMySendButtonClick")
	if self.myEditOpen then return end
	self.myWaitInterface = GameController:call("showWaitInterface1", self.ui.m_kingSendButton)
	self:announce(false, self.ui.m_myTalkLabel:getString())
end

function DragonWorldCupHallOfFamePopupView:announce(flag, announce)
	local season = ActivityController:call("getInstance"):getProperty("dragonWorldCupSeason")
	local ancmd = require("game.command.DragonWorldCupAnnounceCmd").create(season, flag, announce)
	ancmd:send()
end


-------------------DragonWorldCupHallOfFameCell START-------------------
function DragonWorldCupHallOfFameCell:create(memberData)
	local view = DragonWorldCupHallOfFameCell.new()
	Drequire("game.dragonWorldCup.hallOfFame.DragonWorldCupHallOfFamePopupCell_ui"):create(view, 1)
	if view:initNode(memberData, parView) then
		return view
	end 
end

function DragonWorldCupHallOfFameCell:initNode(memberData)
	local uid = memberData.uid
	local pic = "g044" or memberData.pic
	local picVer = tonumber(memberData.picVer)
	local rankLevel = memberData.rank
	local name = memberData.name

	if (pic == "") then
		pic = "g044.png"
	else
		pic = pic .. ".png"
	end

	local icon = CCLoadSprite:call("createSprite", pic, CCLoadSpriteType.CCLoadSpriteType_HEAD_ICON)
	CCCommonUtilsForLua:setSpriteMaxSize(icon, 57, true)
	self.ui.m_headNode:addChild(icon)

	if (CCCommonUtilsForLua:call("isUseCustomPic", picVer)) then
		self.m_headImgNode = HFHeadImgNode:call("create")

		local picUrl = CCCommonUtilsForLua:call("getCustomPicUrl", uid, picVer)
		self.m_headImgNode:call("initHeadImgUrl2", self.ui.m_headNode, picUrl, 1.0, 57, true)
	end

	local announcement = (memberData.announcement and memberData.announcement ~= "") and memberData.announcement or getLang("5200153")
	local rankIcon = "Alliance_R" .. rankLevel .. ".png"
	self.ui.m_lvSprite:setSpriteFrame(CCLoadSprite:call("loadResource", rankIcon))
	self.ui.m_nameLabel:setString(name)
	self.ui.m_talkLabel:setString(announcement)

	return true 
end



-------------------DragonWorldCupHallOfFameCell END-------------------


return DragonWorldCupHallOfFamePopupView
