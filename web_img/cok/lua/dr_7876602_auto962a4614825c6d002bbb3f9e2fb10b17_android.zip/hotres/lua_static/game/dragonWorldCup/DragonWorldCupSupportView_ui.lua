----------------------------
-- Author: Elex
-- Date: 2017-06-15 16:47:51
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local DragonWorldCupSupportView_ui = class("DragonWorldCupSupportView_ui")

--#ui propertys


--#function
function DragonWorldCupSupportView_ui:create(owner, viewType)
	local ret = DragonWorldCupSupportView_ui.new()
	CustomUtility:LoadUi("DragonWorldCupSupportView.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function DragonWorldCupSupportView_ui:initLang()
end

function DragonWorldCupSupportView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function DragonWorldCupSupportView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function DragonWorldCupSupportView_ui:onSupportBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onSupportBtnClick", pSender, event)
end

return DragonWorldCupSupportView_ui

