----------------------------
-- Author: Elex
-- Date: 2017-08-10 16:17:42
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local DragonWorldCupPVPCell_ui = class("DragonWorldCupPVPCell_ui")

--#ui propertys


--#function
function DragonWorldCupPVPCell_ui:create(owner, viewType)
	local ret = DragonWorldCupPVPCell_ui.new()
	CustomUtility:DoRes(516, true)
	CustomUtility:LoadUi("DragonWorldCupPVPCell.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function DragonWorldCupPVPCell_ui:initLang()
end

function DragonWorldCupPVPCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function DragonWorldCupPVPCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function DragonWorldCupPVPCell_ui:onLiveClickRed(pSender, event)
	ButtonSmoker:forwardFunction(self, "onLiveClickRed", pSender, event)
end

function DragonWorldCupPVPCell_ui:onClickShare(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickShare", pSender, event)
end

return DragonWorldCupPVPCell_ui

