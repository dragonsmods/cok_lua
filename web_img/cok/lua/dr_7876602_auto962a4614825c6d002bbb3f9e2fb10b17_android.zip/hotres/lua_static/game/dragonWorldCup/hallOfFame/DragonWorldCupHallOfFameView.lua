local DragonWorldCupHallOfFameView = class("DragonWorldCupHallOfFamePopupView",
	function()
		return PopupBaseView:create()
	end
)

local dragonWorldCupManager = require("game.dragonWorldCup.DragonWorldCupManager")

function DragonWorldCupHallOfFameView:create()
 	local view = DragonWorldCupHallOfFameView.new()
	Drequire("game.dragonWorldCup.hallOfFame.DragonWorldCupHallOfFameView_ui"):create(view, 1)
	if view:initView() then
		return view
	end
 end 

 function DragonWorldCupHallOfFameView:initView( ... )
 	if self:init(true, 0) then
 		self:setHDPanelFlag(true)

 		CCLoadSprite:call("doResourceByCommonIndex", 205, true)

 		local winSize = cc.Director:sharedDirector():getIFWinSize()
 		-- self:setContentSize(winSize)

 		if CCCommonUtilsForLua:isIosAndroidPad() then
 			--self.ui.m_topNode:setPosition(winSize.width / 2, winSize.height)
			self.ui.m_topNode:setScale(2.4)
		end

		print("m_topNode position", self.ui.m_topNode:getPosition())

 		local touchLayer = cc.Layer:create()
		self:addChild(touchLayer)

		local function touchHandle( eventType, x, y )
			print("touchHandle", eventType, x, y)
			if eventType == "began" then
				return self:onTouchBegan(x, y)
			elseif eventType == "moved" then
			
			else
				self:onTouchEnded(x, y)
			end
		end
		touchLayer:registerScriptTouchHandler(touchHandle)
		touchLayer:setTouchEnabled(true)
		touchLayer:setSwallowsTouches(false)

		local sf = CCLoadSprite:call("getSF", "57009_ad1.png")
		if sf then 
			local sp = CCLoadSprite:call("createSprite", "57009_ad1.png")
			self.ui.m_picNode:addChild(sp)
		end

		if DynamicResourceController2:call("checkDynamicResource", "dragonGlobal") 
				and CCLoadSprite:call("loadDynamicResourceByName", "dragonGlobal") then
			self.ui.m_picNode:removeAllChildren()

			local sp = CCLoadSprite:call("createSprite", "mingrentangBG.png")
			self.ui.m_picNode:addChild(sp)

			local size1 = self.ui.m_red1Node:getContentSize()
			local rbg1 = CCLoadSprite:call("createSprite", "mingrentangHong.png")
			self.ui.m_red1Node:addChild(rbg1)
			rbg1:setPosition(size1.width / 2, size1.height / 2 + 10)

			local size2 = self.ui.m_red2Node:getContentSize()
			local rbg2 = CCLoadSprite:call("createSprite", "mingrentangHong.png")
			self.ui.m_red2Node:addChild(rbg2)
			rbg2:setPosition(size2.width / 2, size2.height / 2 + 10)
		end

		self:requestData()
		--self:refreshView()

 		return true
 	end

 	return false
 end

 function DragonWorldCupHallOfFameView:requestData()
 	local season = ActivityController:call("getInstance"):getProperty("dragonWorldCupSeason")
	local reqcmd = require("game.command.DragonWorldCupHallOfFameCmd").create(season)
	reqcmd:send()
 end

function DragonWorldCupHallOfFameView:refreshView(param)
	local tbl =  dictToLuaTable(param)
	self.alliances = tbl.alliance
	--dump(self.alliances, "DragonWorldCupHallOfFameView refreshView")
	--self:getTestData()
	--数据为空
	if sizen(self.alliances) == 0 then
		return
	end

	local announce = ""

	for index = 1, 2, 1 do
		local  allianceData = self.alliances[index]
		self:setAllianceData(allianceData, index)

		if index == 1 then
			announce = allianceData.alliAnnouncement
		end
	end

	self.ui.m_des1Label:setString(getLang("5200154"))
	--冠军联盟宣言
	self.ui.m_des2Label:setString(announce)
	--pad显示不了故隐藏
	if CCCommonUtilsForLua:isIosAndroidPad() then
		self.ui.m_des2Label:setVisible(false)
	end
end

function DragonWorldCupHallOfFameView:setAllianceData(data, index)
	local flagNode = self.ui["m_flag" .. index .. "Node"]
	local countryNode = self.ui["m_state" .. index .. "Node"]
	local nameLabel = self.ui["m_state" .. index .. "Label"]
	local leaderLabel = self.ui["m_alliance" .. index .. "Label"]
	local kingdomLabel = self.ui["m_name" .. index .. "Label"]


	nameLabel:setString("(" .. data.abbr .. ") " .. data.name)
	leaderLabel:setString(data.leader)
	kingdomLabel:setString(data.kingdomName)

	flagNode:removeAllChildren()
	countryNode:removeAllChildren()

	local flag = AllianceFlagPar:call("create", data.icon .. ".png")
	flagNode:addChild(flag)
	flagNode:setScale(0.71)

	if DynamicResourceController2:call("checkDynamicResource", "dragonGlobal") 
			and CCLoadSprite:call("loadDynamicResourceByName", "dragonGlobal") then
		local miniTag = dragonWorldCupManager.getCountryIcon(data.country)
		local countryFlag = CCLoadSprite:call("createSprite", miniTag)
		countryNode:addChild(countryFlag)
		countryNode:setScale(1.0)
	else
		local countryFlag = CCLoadSprite:call("createSprite", data.country .. ".png", CCLoadSpriteType.CCLoadSpriteType_COUNTRY_ICON)
		countryNode:addChild(countryFlag)
		countryNode:setScale(0.4)
	end
end

 function DragonWorldCupHallOfFameView:onTouchBegan(x, y)
 	self.startPoint = ccp(x, y)
 	if self.alliances == nil then return false end

 	if isTouchInside(self.ui.m_red1Node, x, y) then
 		return true
 	end

 	if isTouchInside(self.ui.m_red2Node, x, y) then
 		return true
 	end

 	return false
 end

 function DragonWorldCupHallOfFameView:onTouchEnded(x, y)
 	if ccpDistance(self.startPoint, ccp(x, y)) > 20 then return end

 	local rank = 0
 	if isTouchInside(self.ui.m_red1Node, x, y) then
 		rank = 1
 	end

 	if isTouchInside(self.ui.m_red2Node, x, y) then
 		rank = 2
 	end

 	if rank > 0 then
 		local function callback(aliAnnounce) 
 			self.ui.m_des2Label:setString(aliAnnounce)
 		end 
	 	local lua_path = "game.dragonWorldCup.hallOfFame.DragonWorldCupHallOfFamePopupView"
	 	package.loaded[lua_path] = nil
	 	local view = require(lua_path):create(rank, self.alliances[rank], callback)
	 	PopupViewController:addPopupInView(view)
	 end
 end

 function DragonWorldCupHallOfFameView:onEnter()
 	local function callback1(param) self:refreshView(param) end
 	local handler1 = self:registerHandler(callback1)
 	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "dragon.worldcup.halloffame")

 	self:setTitleName(getLang("110134"))
 end

 function DragonWorldCupHallOfFameView:onExit( )
 	CCSafeNotificationCenter:unregisterScriptObserver(self, "dragon.worldcup.halloffame")
 end

return DragonWorldCupHallOfFameView