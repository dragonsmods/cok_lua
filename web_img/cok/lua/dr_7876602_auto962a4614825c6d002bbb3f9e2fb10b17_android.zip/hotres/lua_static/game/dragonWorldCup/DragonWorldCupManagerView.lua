local DragonWorldCupManagerView = class("DragonWorldCupManagerView",
	function()
		return PopupBaseView:create()
	end
)
DragonWorldCupManagerView.__index = DragonWorldCupManagerView

local DragonWorldCupManagerCell = class("DragonWorldCupManagerCell",
	function()
		return cc.Layer:create()
	end
)
DragonWorldCupManagerCell.__index = DragonWorldCupManagerCell

local dragonWorldCupManager = require("game.dragonWorldCup.DragonWorldCupManager")

--未出战
local NOT_JOIN_BATTLE = 0
--出战
local JOIN_BATTLE = 1
--战斗中
local BATTLEING = 2

function DragonWorldCupManagerView:create(isInBattle)
	local view = DragonWorldCupManagerView.new()
	Drequire("game.dragonWorldCup.DragonWorldCupManagerView_ui"):create(view, 0)
	if view:initView(isInBattle) then
		return view
	end
end

function DragonWorldCupManagerView:initView(isInBattle)
	if self:init(true, 0) then
		self:setHDPanelFlag(true)

		if (CCCommonUtilsForLua:isIosAndroidPad()) then
			self.ui.m_topNode:setScale(2.4)
			self.ui.m_bottomNode:setScale(2.4)
		end

		--self.ui.m_titleTxt:setString(getLang("5200024"))
		self.ui.m_registerNode:setVisible(true)
		self.ui.m_battleManagerNode:setVisible(false)
		self.ui.m_allJoinBattleLabel:setString(getLang("5200022"))
		self.ui.m_allCanbattleLabel:setString(getLang("5200023"))
		self.ui.m_remar1kLabel:setString(getLang(""))

		self.ui.m_nameLabel:setString(getLang("140047"))
		self.ui.m_capacityLabel:setString(getLang("140038"))
		self.ui.m_situationLabel:setString(getLang("140048"))

		CCCommonUtilsForLua:setButtonTitle(self.ui.m_signUpButton, getLang("5200024"))

		CCLoadSprite:call("loadDynamicResourceByName", "activity_ad")

		local sf = CCLoadSprite:call("getSF", "57009_ad1.png")
	    if sf then self.ui.m_topBGSprite:setSpriteFrame(sf) end

    	--是否在战斗
		self.isInBattle = isInBattle
		--self.isInBattle = true
		MyPrint("self.isInBattle", self.isInBattle)

		self.m_listNode = self.isInBattle and self.ui.m_battleListNode or self.ui.m_signUpListNode
		if self.isInBattle then self.ui.m_bottomNode:setVisible(false) end

	    local addHeight = self:call("getExtendHeight")
		local listSize = self.m_listNode:getContentSize()
		self.m_listNode:setContentSize(cc.size(listSize.width, listSize.height + addHeight))

		--self.m_merbers = {}
		self.m_tableView = cc.TableView:create(self.m_listNode:getContentSize())
		self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
		self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
		self.m_tableView:setAnchorPoint(ccp(0, 0))
		self.m_tableView:setDelegate()
		self.m_tableView:registerScriptHandler(function(tab) return self:scrollViewDidScroll(tab) end, cc.SCROLLVIEW_SCRIPT_SCROLL)
		self.m_tableView:registerScriptHandler(function(tab, idx) return self:cellSizeForTable(tab, idx) end, cc.TABLECELL_SIZE_FOR_INDEX)
		self.m_tableView:registerScriptHandler(function(tab, idx) return self:tableCellAtIndex(tab, idx) end, cc.TABLECELL_SIZE_AT_INDEX)
		self.m_tableView:registerScriptHandler(function(tab) return self:numberOfCellsInTableView(tab) end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
		self.m_listNode:addChild(self.m_tableView)
		self.m_tableView:reloadData()

		-- --先看内存里面有没有该界面的数据,有的话直接显示
		-- self:getDataBack()

		--请求最新数据
		local getMemberListCommand = require("game.command.DragonWorldCupGetMemberListCmd").create()
		getMemberListCommand:send()

		--loading动画
		self:addLoadingAni()

		return true
	end

	return false
end

function DragonWorldCupManagerView:getManagerData()
	local isSelected = {}
	local isFirst = {}

	for i = 1, #self.m_merbers, 1 do
		local info = self.m_merbers[i]
		if info.isSelected then
			isSelected[#isSelected + 1] = info.uid
		end

		if info.isFirst then
			isFirst[#isFirst + 1] = info.uid
		end
	end

	return table.concat(isSelected, ";"), table.concat(isFirst, ";")
end

--更新出战信息
function DragonWorldCupManagerView:updateManagerTxt()
	local selectNum = 0
	local firstOnNum = 0

	for i = 1, #self.m_merbers, 1 do
		local info = self.m_merbers[i]
		if info.isSelected then
			selectNum = selectNum + 1
		end

		if info.isFirst then
			firstOnNum = firstOnNum + 1
		end
	end

	self.canSelect = selectNum < self.m_data.maxSelectNum
	self.canFirstOn = firstOnNum < self.m_data.maxFirstOnNum
	self.ui.m_allJoinBattleNum:setString(selectNum .. "/" .. self.m_data.maxSelectNum)
	self.ui.m_allCanbattleNum:setString(firstOnNum .. "/" .. self.m_data.maxFirstOnNum)
end

function DragonWorldCupManagerView:addLoadingAni()
	self:removeLoadingAni()

	self.m_loadingIcon = CCLoadSprite:call("createSprite", "loading_1.png")
	self.m_loadingIcon:setAnchorPoint(ccp(0.5, 0.5))

	local cSize = self.m_listNode:getContentSize()
	self.m_loadingIcon:setPosition(ccp(cSize.width / 2, cSize.height / 2))

	local rotateAction = cc.RotateTo:create(0.5, 720)
	local rotateForever = cc.RepeatForever:create(rotateAction)
	self.m_loadingIcon:runAction(rotateForever)
	self.m_listNode:addChild(self.m_loadingIcon, 1000000)
end

function DragonWorldCupManagerView:removeLoadingAni()
	if (self.m_loadingIcon) then
		self.m_listNode:removeChild(self.m_loadingIcon)
		self.m_loadingIcon = nil
	end
end

function DragonWorldCupManagerView:onEnter()
	self:setTitleName(getLang("140043"))
	local function callback1() self:getDataBack() end
	local function callback2() self:confirmBack() end
	local handler1 = self:registerHandler(callback1)
	local handler2 = self:registerHandler(callback2)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "dragon.worldcup.memberlist.data.back")
	CCSafeNotificationCenter:registerScriptObserver(self, handler2, "dragon.worldcup.memberlist.confirm.back")
end

function DragonWorldCupManagerView:onExit()
	CCSafeNotificationCenter:unregisterScriptObserver(self, "dragon.worldcup.memberlist.data.back")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "dragon.worldcup.memberlist.confirm.back")
end

function DragonWorldCupManagerView:scrollViewDidScroll(tab)
	local mindy = self.m_tableView:minContainerOffset().y
	local dy = self.m_tableView:getContentOffset().y
	if (dy < mindy) then
		self.m_tableView:setContentOffset(ccp(0, mindy))
	end
end

function DragonWorldCupManagerView:cellSizeForTable(tab, idx)
	return 640.0, 105.0
end

function DragonWorldCupManagerView:tableCellAtIndex(tab, idx)
	local node = DragonWorldCupManagerCell:create(self.m_merbers[idx + 1], self)
	node:setTag(666)
	
	local cell = cc.TableViewCell:create()
	cell:addChild(node)
	return cell
end

function DragonWorldCupManagerView:numberOfCellsInTableView(tab)
	return type(self.m_merbers) == "table" and #self.m_merbers or 0
end

function DragonWorldCupManagerView:getDataBack()
	self.m_data = dragonWorldCupManager.getManagerData()
	-- --内存里没有数据直接返回
	-- if not self.m_data.valid then return end
	--移除loading动画
	self:removeLoadingAni()	
	--战斗中只能修改参战人员状态
	if self.isInBattle then
		self.m_merbers = {}
		for index = 1, #self.m_data.members, 1 do
			local memberInfo = self.m_data.members[index]
			if memberInfo.isSelected then
				self.m_merbers[#self.m_merbers + 1] = memberInfo
			end
		end
	else
		self.m_merbers = self.m_data.members
	end

	local function sort(mem1, mem2)
		if mem1.rank ~= mem2.rank then
			return mem2.rank < mem1.rank
		else
			return tonumber(mem2.power) < tonumber(mem1.power)
		end
	end
	table.sort(self.m_merbers, sort)

	local selectNum = self.m_data.selectNum
	local firstOnNum = self.m_data.firstOnNum
	local maxSelectNum = self.m_data.maxSelectNum
	local maxFirstOnNum = self.m_data.maxFirstOnNum

	--相关状态
	self.canSelect = selectNum < maxSelectNum
	self.canFirstOn = firstOnNum < maxFirstOnNum

	self.ui.m_allJoinBattleNum:setString(selectNum .. "/" .. maxSelectNum)
	self.ui.m_allCanbattleNum:setString(firstOnNum .. "/" .. maxFirstOnNum)

	self.m_tableView:reloadData()
end

function DragonWorldCupManagerView:confirmBack()
	PopupViewController:call("goBackPopupView")
end

function DragonWorldCupManagerView:onSignUpButtonClick()
	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	if playerInfo:call("isInAlliance") then
		local allianceInfo = playerInfo:getProperty("allianceInfo")
		local rank = allianceInfo:getProperty("rank")
		if rank < 4 then
			YesNoDialog:show(getLang("E100119"))
			return
		end
	end

	-- body
	local isSelected, isFirst = self:getManagerData()
	local confirmCmd = require("game.command.DragonWorldCupMemberConfirmCmd").create(isSelected, isFirst)
	confirmCmd:send()
end

--------------------DragonWorldCupManagerCell--------------------
function DragonWorldCupManagerCell:create(info, parView)
	local view = DragonWorldCupManagerCell.new()
	Drequire("game.dragonWorldCup.DragonWorldCupManagerCell_ui"):create(view, 1)
	if view:initView(info, parView) then
		return view
	end
end

function DragonWorldCupManagerCell:initView(info, parView)
	registerTouchHandler(self)
	self:setTouchEnabled(true)

	self.m_info = info
	self.parView = parView
	self.m_listNode = parView.m_listNode
	self.isInBattle = parView.isInBattle

	--test
	-- self.isSelected = true
	-- self.isFirst = true

	if self.m_info == nil then return true end

	self.ui.m_nameLabel:setString(self.m_info.name)
	self.ui.m_powerLabel:setString(CC_CMDITOA(self.m_info.power))

	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	local uid = playerInfo:getProperty("uid")
	if self.m_info.uid == uid then
		self.ui.m_nameLabel:setColor(cc.c3b(255, 203, 0))
		self.ui.m_powerLabel:setColor(cc.c3b(255, 203, 0))
	else
		self.ui.m_nameLabel:setColor(cc.c3b(189, 176, 131))
		self.ui.m_powerLabel:setColor(cc.c3b(189, 176, 131))
	end
	
	if self.isInBattle then
		if self.m_info.fight == BATTLEING then
			self.ui.m_battleingNode:setVisible(true)
			self.ui.m_battleNode:setVisible(false)
			self.ui.m_joinBattleNode:setVisible(false)
			self.ui.m_battleTxt:setString(getLang("140080"))
		else
			self.ui.m_battleingNode:setVisible(false)
			self.ui.m_battleNode:setVisible(true)
			self.ui.m_joinBattleNode:setVisible(false)
		end

		if self.m_info.isFirst then
			self.ui.m_battleBtn:setVisible(false)
			self.ui.m_cancelBtn:setVisible(true)
		else
			self.ui.m_battleBtn:setVisible(true)
			self.ui.m_cancelBtn:setVisible(false)
		end

		CCCommonUtilsForLua:setButtonTitle(self.ui.m_battleBtn, getLang("140049"))
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_cancelBtn, getLang("140050"))
	else
		self.ui.m_battleNode:setVisible(false)
		self.ui.m_battleingNode:setVisible(false)
		self.ui.m_joinBattleNode:setVisible(true)
	end

	self.ui.m_joinBattleYesSprite:setVisible(self.m_info.isSelected)
	self.ui.m_canBattleYesSprite:setVisible(self.m_info.isFirst)

	self.isSelected = self.m_info.isSelected
	self.isFirst = self.m_info.isFirst

	self.ui.m_iconNode:removeAllChildren()
	local picPath = self.m_info.pic
	if (picPath == "") then
		picPath = "g044.png"
	else
		picPath = picPath .. ".png"
	end

	local icon = CCLoadSprite:call("createSprite", picPath, CCLoadSpriteType.CCLoadSpriteType_HEAD_ICON)
	CCCommonUtilsForLua:setSpriteMaxSize(icon, 57, true)
	self.ui.m_iconNode:addChild(icon)

	local picVer = self.m_info.picVer
	if (CCCommonUtilsForLua:call("isUseCustomPic", picVer)) then
		self.m_headImgNode = HFHeadImgNode:call("create")

		local uid = info:getProperty("uid")
		local picUrl = CCCommonUtilsForLua:call("getCustomPicUrl", uid, picVer)
		self.m_headImgNode:call("initHeadImgUrl2", self.ui.m_iconNode, picUrl, 1.0, 57, true)
	end

	local rankIcon = "Alliance_R" .. self.m_info.rank .. ".png"
	self.ui.m_lvSprite:setSpriteFrame(CCLoadSprite:call("loadResource", rankIcon))

	return true
end

function DragonWorldCupManagerCell:onTouchBegan(x, y)
	if self.isInBattle then return false end
	if not isTouchInside(self.m_listNode, x, y) then return false end

	self.m_touchPoint = ccp(x, y)

	if isTouchInside(self.ui.m_joinBattleSprite, x, y) then return true end
	if isTouchInside(self.ui.m_canBattleSprite, x, y) then return true end

	return false
end

function DragonWorldCupManagerCell:onTouchEnded(x, y)
	if (ccpDistance(self.m_touchPoint, ccp(x, y)) > 20) then return end

	if (isTouchInside(self.ui.m_joinBattleSprite, x, y)) then
		local visible = self.ui.m_joinBattleYesSprite:isVisible()
		if visible == false and self.parView.canSelect == false then
			CCCommonUtilsForLua:call("flyHint", "", "", getLang("140141"))
			return
		end
		self.ui.m_joinBattleYesSprite:setVisible(not visible)
		self.m_info.isSelected = not visible
		--没选择的话去掉后面的参战状态
		if self.m_info.isSelected == false then
			self.ui.m_canBattleYesSprite:setVisible(false)
			self.m_info.isFirst = false
		end
		self.parView:updateManagerTxt()
	end

	if (isTouchInside(self.ui.m_canBattleSprite, x, y)) then 
		local visible = self.ui.m_canBattleYesSprite:isVisible()
		--必须是选择的成员才可以改变后面是否参战的状态
		if self.m_info.isSelected == true then
			if visible == false and self.parView.canFirstOn == false then
				CCCommonUtilsForLua:call("flyHint", "", "", getLang("140141"))
				return
			end
			self.ui.m_canBattleYesSprite:setVisible(not visible)
			self.m_info.isFirst = not visible
		end
		self.parView:updateManagerTxt()
	end
end

function DragonWorldCupManagerCell:onEnter()
	local function callback1(param) self:successCallbak(param) end
	local handler1 = self:registerHandler(callback1)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "dragon.worldcup.join.battle")
end

function DragonWorldCupManagerCell:onExit()
	CCSafeNotificationCenter:unregisterScriptObserver(self, "dragon.worldcup.join.battle")
end

function DragonWorldCupManagerCell:successCallbak(param)
	local pCStr = tolua.cast(param, "CCString")
	if pCStr then
		if self.waitNode then
			self.waitNode:call("remove")
			self.waitNode = nil
		end

		local uid = pCStr:getCString()
		if self.m_info.uid ~= uid then return end

		self.m_info.isFight = (self.m_info.isFight == 0 and 1 or 0)
		self.m_info.isFirst = not self.m_info.isFirst
		self.ui.m_battleBtn:setVisible(not self.ui.m_battleBtn:isVisible())
		self.ui.m_cancelBtn:setVisible(not self.ui.m_cancelBtn:isVisible())

		local data = dragonWorldCupManager.getManagerData()
		if self.m_info.isFirst then
			data.firstOnNum = data.firstOnNum + 1
		else
			data.firstOnNum = data.firstOnNum - 1
		end

		self.parView:updateManagerTxt()
	end
end

function DragonWorldCupManagerCell:onBattleBtnClick()
	if self.parView.canFirstOn == false then
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("140141"))
		return
	end

	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	if playerInfo:call("isInAlliance") then
		local allianceInfo = playerInfo:getProperty("allianceInfo")
		local rank = allianceInfo:getProperty("rank")
		if rank < 4 then
			YesNoDialog:show(getLang("E100119"))
			return
		end
	end

	self.waitNode = GameController:call("showWaitInterface1", self.ui.m_battleBtn)
	local joinBattleCmd = require("game.command.DragonWorldCupJoinBattleCmd").create(self.m_info.uid, true)
	joinBattleCmd:send()
end

function DragonWorldCupManagerCell:onCancelBtnClick()
	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	if playerInfo:call("isInAlliance") then
		local allianceInfo = playerInfo:getProperty("allianceInfo")
		local rank = allianceInfo:getProperty("rank")
		if rank < 4 then
			YesNoDialog:show(getLang("E100119"))
			return
		end
	end

	self.waitNode = GameController:call("showWaitInterface1", self.ui.m_battleBtn)
	local cancelBattleCmd = require("game.command.DragonWorldCupJoinBattleCmd").create(self.m_info.uid, false)
	cancelBattleCmd:send()
end

--------------------DragonWorldCupManagerCell--------------------

return DragonWorldCupManagerView
