--世界杯胜负奖励页签
local DwcWLRewardNode = class("DwcWLRewardNode", Drequire("game.dragonBattle.PersonlyWLRewardNode"))

function DwcWLRewardNode:requestData()
    local cmd = Drequire("game.command.DragonWorldCupGroupRewardCmd"):create()
    cmd:send()
end

return DwcWLRewardNode