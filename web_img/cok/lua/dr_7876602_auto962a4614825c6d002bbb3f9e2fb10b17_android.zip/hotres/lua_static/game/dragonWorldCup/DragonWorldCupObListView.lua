--------------------------------command--------------------------------

------获取ob列表
local DragonWorldCupGetObListCmd = class("DragonWorldCupGetObListCmd", LuaCommandBase)

function DragonWorldCupGetObListCmd:create(keyword)
  local ret = DragonWorldCupGetObListCmd.new()
  ret:initWithName("worldcup.obList")
  if keyword then
  	ret:putParam("keyword", CCString:create(keyword))
  end
  return ret
end

function DragonWorldCupGetObListCmd:handleReceive( dict )
	Dprint("DragonWorldCupGetObListCmd:handleReceive")
	
	local tbl, params = self:parseMsg(dict, true)
    Dprint("DragonWorldCupGetObListCmd:handleReceive | parse tbl=", tbl)
    if (type(tbl) == "boolean") then
        return tbl
    end

	dump(tbl, "DragonWorldCupGetObListCmd params")

	CCSafeNotificationCenter:postNotification("worldcup.obList", params)

	return true
end
--------------------------------command--------------------------------

local DragonWorldCupObListView = class("DragonWorldCupObListView",
	function() 
		return PopupBaseView:create()
	end
)

local DragonWorldCupObCell = class("DragonWorldCupObCell",
	function()
		return cc.Layer:create()
	end
)

local dragonWorldCupManager = require("game.dragonWorldCup.DragonWorldCupManager")
--------------------------------declaration--------------------------------

function DragonWorldCupObListView:create()
	local view = DragonWorldCupObListView.new()
	Drequire("game.dragonWorldCup.DragonWorldCupObListView_ui"):create(view, 0)
	if view:initView() then
		return view
	end
end


function DragonWorldCupObListView:initView()
	if self:init(true, 0) == false then
		return false
	end

	self:setHDPanelFlag(true)
	self.ipadLike = CCCommonUtilsForLua:isIosAndroidPad()
	if self.ipadLike then
		self.ui.m_topNode:setScale(2.4)
		self.ui.m_listNode:setScale(2.4)
	end
	self.m_data = {}
	self.ui.m_listNode:removeAllChildren()

    local addHeight = self:call("getExtendHeight")
	local listSize = cc.size(640, 680)
	self.ui.m_listNode:setContentSize(cc.size(listSize.width, listSize.height + addHeight))
	Dprint("listSize", listSize.width, listSize.height, addHeight)
	local listSize = self.ui.m_listNode:getContentSize()
	self.m_tableView = cc.TableView:create(listSize)
	self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
	self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
	self.m_tableView:setDelegate()
	self.m_tableView:registerScriptHandler(function(tab, idx) return self:cellSizeForTable(tab, idx) end, cc.TABLECELL_SIZE_FOR_INDEX)
	self.m_tableView:registerScriptHandler(function(tab, idx) return self:tableCellAtIndex(tab, idx) end, cc.TABLECELL_SIZE_AT_INDEX)
	self.m_tableView:registerScriptHandler(function(tab) return self:numberOfCellsInTableView(tab) end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
	self.ui.m_listNode:addChild(self.m_tableView)
	

	self.searchTxt = ""
	self.tipLabel = cc.Label:createWithSystemFont(getLang("132493"), "Helvetica", 30)
	self.ui.m_listNode:addChild(self.tipLabel)
	self.tipLabel:setPosition(listSize.width / 2, listSize.height / 2)
	self.tipLabel:setVisible(false)

	local sprite9 = CCLoadSprite:call("createScale9Sprite", "world_title_3.png")
	local fontSize = 20
	local size = self.ui.m_searchNode:getContentSize()
	if self.ipadLike then
		fontSize = 40
	end
	self.m_editBox = CCEditBox:create(size, sprite9)
	self.m_editBox:setAnchorPoint(ccp(0, 0.5))
	self.m_editBox:setFontSize(fontSize)
	self.m_editBox:setPlaceHolder(getLang("5200226"))
	self.m_editBox:setPlaceholderFontColor(cc.c3b(0, 0, 0))
	self.m_editBox:setMaxLength(100)
	self.m_editBox:setFontColor(cc.c3b(0, 0, 0))
	self.m_editBox:setInputFlag(3)
	self.m_editBox:setReturnType(cc.KEYBOARD_RETURNTYPE_DONE ) --输入键盘返回类型，done，send，go等
	self.m_editBox:setPosition(ccp(0, 0))
	self.ui.m_searchNode:addChild(self.m_editBox)

	CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnSearch, getLang("115013"))

	self:addLoadingAni()

	local cmd = DragonWorldCupGetObListCmd:create()
	cmd:send()

	return true
end

function DragonWorldCupObListView:addLoadingAni()
	self:removeLoadingAni()

	self.m_loadingIcon = CCLoadSprite:call("createSprite", "loading_1.png")
	self.m_loadingIcon:setAnchorPoint(ccp(0.5, 0.5))

	local cSize = self.ui.m_listNode:getContentSize()
	self.m_loadingIcon:setPosition(ccp(cSize.width / 2, cSize.height / 2))

	local rotateAction = cc.RotateTo:create(0.5, 720)
	local rotateForever = cc.RepeatForever:create(rotateAction)
	self.m_loadingIcon:runAction(rotateForever)
	self.ui.m_listNode:addChild(self.m_loadingIcon, 1000000)
end

function DragonWorldCupObListView:removeLoadingAni()
	if (self.m_loadingIcon) then
		self.ui.m_listNode:removeChild(self.m_loadingIcon)
		self.m_loadingIcon = nil
	end
end

function DragonWorldCupObListView:refreshView(param)
	if param then
		local tbl = dictToLuaTable(param)
		if tbl.list then
			self.m_data = tbl.list
			self:removeLoadingAni()
			if self.m_waitInterface then
				self.m_waitInterface:call("remove")
				self.m_waitInterface = nil
			end
			self.m_tableView:reloadData()		
			
			if sizen(self.m_data) == 0 then
				self.tipLabel:setVisible(true)
			else
				self.tipLabel:setVisible(false)
			end
		end
	end
end

function DragonWorldCupObListView:onEnter()
	self:setTitleName(getLang("132483"))
	local function callback1(param) self:refreshView(param) end
	local handler1 = self:registerHandler(callback1)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "worldcup.obList") 
end

function DragonWorldCupObListView:onExit()
	CCSafeNotificationCenter:unregisterScriptObserver(self, "worldcup.obList")
end

function DragonWorldCupObListView:cellSizeForTable(tabView, idx)
	return 640, 175
end

function DragonWorldCupObListView:numberOfCellsInTableView(tabView)
	return sizen(self.m_data)
end

function DragonWorldCupObListView:tableCellAtIndex(tabView, idx)
	if idx >= sizen(self.m_data) then return end

	local cell = tabView:dequeueCell()

	if cell then
		local node = cell:getChildByTag(666)
		if node then node:setData(self.m_data[idx + 1]) end
	else
	 	local node = DragonWorldCupObCell:create(self.m_data[idx + 1])
		node:setTag(666)
		cell = cc.TableViewCell:create()
		cell:addChild(node)
	end

	return cell
end

function DragonWorldCupObListView:onSearchClick()
	local key = self.m_editBox:getText()
	if key == self.searchTxt then return end
	self.searchTxt = key

	self:addLoadingAni()

	if self.m_waitInterface then
		self.m_waitInterface:call("rmeove")
		self.m_waitInterface = nil
	end

	self.m_waitInterface = GameController:call("showWaitInterface1", self.ui.m_btnSearch)

	local cmd = DragonWorldCupGetObListCmd:create(key)
	cmd:send()
end

--------------------------DragonWorldCupObListView--------------------------
function DragonWorldCupObCell:create(matchData)
	local view = DragonWorldCupObCell.new()
	if view:initView(matchData) then
		return view
	end
end

function DragonWorldCupObCell:initView(matchData)
	local  proxy = cc.CCBProxy:create()
	local ccbiURL = "ccbi/DragonBattlePVPCell.ccbi"
	local nodeccb = CCBReaderLoad(ccbiURL,proxy, self)
	self:addChild(nodeccb)
	--self:setContentSize(nodeccb:getContentSize())
	self.obSwitch = CCCommonUtilsForLua:isFunOpenByKey("wag_ob")
	self:setData(matchData)
	registerNodeEventHandler(self)
	return true
end

function DragonWorldCupObCell:setData(matchData)
	self.matchData = matchData

	local team = matchData.team1
	if team ~= nil then
		self.m_leftRank:setString(getLang("132484",tostring(team.rank)))
		self.m_leftRate:setString(getLang("132485",tostring(team.rate)))
		self.m_leftScore:setString(getLang("132486",tostring(team.score)))
		local strAlaName = "("..tostring(team.abbr)..")"..tostring(team.name)

		if string.len(strAlaName) > 10 then
			strAlaName = CCCommonUtilsForLua:call("subStrByUtf8",strAlaName,0,10)
			strAlaName = strAlaName.."..."
		end
		self.m_leftAlaName:setString(strAlaName)

		local kingName = tostring(team.kingdomName)
		if string.len(kingName) > 15 then
			kingName = CCCommonUtilsForLua:call("subStrByUtf8",kingName,0,10)
			kingName = kingName.."..."
		end
		self.m_leftKingdom:setString(kingName)

		local flagScale = 1
		local flagName = tostring(team.icon)
		if flagName == "" then
			flagScale = 0.71
		end
		local flag = AllianceFlagPar:call("create",flagName..".png")
		flag = tolua.cast(flag, "cc.Node")
		flag:setScale(flagScale)
		self.m_leftFlagNode:removeAllChildren()
		self.m_leftFlagNode:addChild(flag)
	end

	team = matchData.team2
	if team ~= nil then
		self.m_rightRank:setString(getLang("132484",tostring(team.rank)))
		self.m_rightRate:setString(getLang("132485",tostring(team.rate)))
		self.m_rightScore:setString(getLang("132486",tostring(team.score)))

		local strAlaName = "("..tostring(team.abbr)..")"..tostring(team.name)
		if string.len(strAlaName) > 10 then
			strAlaName = CCCommonUtilsForLua:call("subStrByUtf8",strAlaName,0,10)
			strAlaName = strAlaName.."..."
		end
		self.m_rightAlaName:setString(strAlaName)

		local kingName = tostring(team.kingdomName)
		if string.len(kingName) > 15 then
			kingName = CCCommonUtilsForLua:call("subStrByUtf8",kingName,0,10)
			kingName = kingName.."..."
		end
		self.m_rightKingdom:setString(kingName)

		local flagScale = 1
		local flagName = tostring(team.icon)
		if flagName == "" then
			flagScale = 0.71
		end
		local flag = AllianceFlagPar:call("create",flagName..".png")
		flag = tolua.cast(flag, "cc.Node")
		flag:setScale(flagScale)
		self.m_rightFlagNode:removeAllChildren()
		self.m_rightFlagNode:addChild(flag)
	end
end

function DragonWorldCupObCell:onEnterFrame()
	local now = GlobalData:call("getTimeStamp")
	local battleStartTime = self.matchData.battleStartTime
	local battleEndTime = self.matchData.battleEndTime
	self.m_btnLiveRed:setVisible(false)
	self.m_liveTime:setVisible(false)
	self.m_iconTime:setVisible(false)
	if self.obSwitch == false then
		return 
	end
	self.m_liveTime:setVisible(true)
	if nil ~= battleStartTime and nil ~= battleEndTime and "" ~= battleStartTime and "" ~= battleEndTime then
		battleStartTime = tonumber(battleStartTime)
		battleEndTime = tonumber(battleEndTime)
		if battleEndTime > now then
			self.m_btnLiveRed:setVisible(true)
			if battleStartTime > now then
				self.m_iconTime:setVisible(true)
				self.m_liveTime:setString(format_time(battleStartTime - now))
				self.m_iconTime:setPositionX(self.m_liveTime:getPositionX() - self.m_liveTime:getContentSize().width * 0.5 - self.m_iconTime:getContentSize().width * 0.5)
			else
				-- 140364=比赛中
				self.m_liveTime:setString(getLang("140364"))
			end
		else
			-- 5200048=本轮对抗赛已结束
			self.m_liveTime:setString(getLang("5200048"))
		end
	end
end

function DragonWorldCupObCell:scheduleUpdate()
    local function updatefunc(dt) self:onEnterFrame(dt) end 
    self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(updatefunc, 1.0, false)
end

function DragonWorldCupObCell:unscheduleUpdate()
    if self.entry then
        cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
        self.entry = nil
    end
end

function DragonWorldCupObCell:onEnter( ... )
	self:onEnterFrame()
	self:scheduleUpdate()
end

function DragonWorldCupObCell:onExit( ... )
	self:unscheduleUpdate()
end

function DragonWorldCupObCell:onLiveClickRed()
	MyPrint("DragonWorldCupObCell:onLiveClickRed")
	local now = GlobalData:call("getTimeStamp")
	local battleStartTime = self.matchData.battleStartTime
	local battleEndTime = self.matchData.battleEndTime
	local ticketPayed = self.matchData.ticketPayed or "0"
	ticketPayed = tonumber(ticketPayed)
	local obAllianceId = self.matchData.team1.allianceId
	if nil ~= battleStartTime and nil ~= battleEndTime and "" ~= battleStartTime and "" ~= battleEndTime then
		battleStartTime = tonumber(battleStartTime)
		battleEndTime = tonumber(battleEndTime)
		if battleStartTime > now then
			local leftTime = battleStartTime - now
			YesNoDialog:call("show", _lang_1("140365", format_time(leftTime)))
		elseif battleEndTime > now then
			if ticketPayed ~= 0 then
				self:sureToOB(obAllianceId)
			else
				local itemId = dragonWorldCupManager:getNormalObItemId()
	            local info = ToolController:call("getToolInfoByIdForLua", itemId)
	            local function callback() self:sureToOB(obAllianceId) end
	            YesNoDialog:call("show", _lang_2("140366", info:call("getName"), tostring(info:call("getCNT"))), cc.CallFunc:create(callback))
			end
			
        end
	end
end

function DragonWorldCupObCell:sureToOB(allianceId)
	GameController:call("showWaitInterface")
	dragonWorldCupManager.enterDragonBattle(allianceId, true)
end


--------------------------DragonWorldCupObCell--------------------------


return DragonWorldCupObListView