local DragonWorldCupRoomListView = class("DragonWorldCupRoomListView",
	function()
		return PopupBaseView:create()
	end
)
DragonWorldCupRoomListView.__index = DragonWorldCupRoomListView

local DragonBattleRoomCell = class("DragonBattleRoomCell",
	function()
		return cc.Layer:create()
	end
)
DragonBattleRoomCell.__index = DragonBattleRoomCell

local dragonWorldCupManager = require("game.dragonWorldCup.DragonWorldCupManager")

function DragonWorldCupRoomListView:create(timeIndex, enabled)
	local view = DragonWorldCupRoomListView.new()
	Drequire("game.dragonWorldCup.DragonWorldCupRoomListView_ui"):create(view, 0)
	if view:initView(timeIndex, enabled) then
		return view
	end
end

function DragonWorldCupRoomListView:initView(timeIndex, enabled)
	--创建个空的tableview
	if self:init(true, 0) then
		self:setIsHDPanel(true)
		self:changeBGHeight(self.ui.m_viewBg)
				
		if CCCommonUtilsForLua:isIosAndroidPad() then
			self.ui.m_topNode:setScale(2.4)
			self.ui.m_bottomNode:setScale(2.4)
		end

		local addHeight = self:call("getExtendHeight")
		local listSize = self.ui.m_infoList:getContentSize()
		self.ui.m_infoList:setContentSize(cc.size(listSize.width, listSize.height + addHeight))
		self.m_tableView = cc.TableView:create(self.ui.m_infoList:getContentSize())
		self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
		self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
		self.m_tableView:setAnchorPoint(ccp(0, 0))
		self.m_tableView:setDelegate()
		self.m_tableView:registerScriptHandler(function(tab) return self:scrollViewDidScroll(tab) end, cc.SCROLLVIEW_SCRIPT_SCROLL)
		self.m_tableView:registerScriptHandler(function(tab, idx) return self:cellSizeForTable(tab, idx) end, cc.TABLECELL_SIZE_FOR_INDEX)
		self.m_tableView:registerScriptHandler(function(tab, idx) return self:tableCellAtIndex(tab, idx) end, cc.TABLECELL_SIZE_AT_INDEX)
		self.m_tableView:registerScriptHandler(function(tab) return self:numberOfCellsInTableView(tab) end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
		self.ui.m_infoList:addChild(self.m_tableView)

		if (CCLoadSprite:call("loadDynamicResourceByName", "manual")) then
			local newBg = CCLoadSprite:call("createSprite", "manual_dragon.png")
			local size = self.ui.m_dragonBg:getContentSize()
			local clipNode = CCClipNode:call("create", size.width, size.height)
			clipNode:setAnchorPoint(ccp(0, 0))
			clipNode:setPosition(0, 0)
			self.ui.m_dragonBg:addChild(clipNode)
			clipNode:addChild(newBg)
			newBg:setPosition(size.width / 2, size.height / 2 - 37)
		end

		self.ui.m_tipTxt:setString(getLang("140015"))
		self.ui.m_timeTip:setString(getLang("140361"))

		self.roomCells = {}

		CCCommonUtilsForLua:setButtonTitle(self.ui.m_sureBtn, getLang("confirm"))

		self.ui.m_sureBtn:setEnabled(enabled)

		self.selectIndex = -1
		self.timeIndex = timeIndex
		self.enabled = enabled

		local command = require("game.command.DragonWorldCupSignUpTimeCmd").create()
		command:send()
		--self:getDataBack()

		return true
	end

	return false
end

function DragonWorldCupRoomListView:getTestData()
	local now = LuaController:call("getTimeStamp")
	self.battleRoomInfo = {
		{
			index = 1,
			state = 0,
			beginTime = now,
			endTime = now + 7200,
			num = 432143214,
		},
		{
			index = 2,
			state = 0,
			beginTime = now + 7200,
			endTime = now + 14400,
			num = 53454235432,
		},
		{
			index = 3,
			state = 1,
			beginTime = now + 14400,
			endTime = now + 21600,
			num = 543543342,
		},
	}
end

function DragonWorldCupRoomListView:getDataBack()
	self.battleRoomInfo = dragonWorldCupManager.getBattleRoomInfo()
	if sizen(self.battleRoomInfo) == 0 then return end
	self.m_tableView:reloadData()
end

function DragonWorldCupRoomListView:confirmBack()
	self.ui.m_sureBtn:setEnabled(false)
	for _, room in ipairs(self.roomCells) do
		if room.index == self.selectIndex then
			room:showChoosed()
			break
		end
	end
end

function DragonWorldCupRoomListView:onEnter()
	--UIComponent:call("showPopupView", 1)
	self:setTitleName(getLang("5200029"))
	local function callback1() self:getDataBack() end
	local function callback2() self:confirmBack() end
	local handler1 = self:registerHandler(callback1)
	local handler2 = self:registerHandler(callback2)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "dragon.worldcup.signup.time")
	CCSafeNotificationCenter:registerScriptObserver(self, handler2, "dragon.worldcup.signup.time.done")
end

function DragonWorldCupRoomListView:onExit()
	CCSafeNotificationCenter:unregisterScriptObserver(self, "dragon.worldcup.signup.time")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "dragon.worldcup.signup.time.done")
end

function DragonWorldCupRoomListView:scrollViewDidScroll(tab)
	local mindy = self.m_tableView:minContainerOffset().y
	local dy = self.m_tableView:getContentOffset().y
	if (dy < mindy) then
		self.m_tableView:setContentOffset(ccp(0, mindy))
	end
end

function DragonWorldCupRoomListView:cellSizeForTable(tab, idx)
	return 640.0, 130.0
end

function DragonWorldCupRoomListView:tableCellAtIndex(tab, idx)
	local node = DragonBattleRoomCell:create(self.battleRoomInfo[idx + 1], self)
	node:setTag(666)
	
	self.roomCells[idx + 1] = node

	local cell = cc.TableViewCell:create()
	cell:addChild(node)
	return cell
end

function DragonWorldCupRoomListView:numberOfCellsInTableView(tab)
	return type(self.battleRoomInfo) == "table" and #self.battleRoomInfo or 0
end

function DragonWorldCupRoomListView:clickSelect(index)
	for _, room in ipairs(self.roomCells) do
		if room.index == index then
			self.selectIndex = index
		end
		room:updateCellSelectState(room.index == index)
	end
end

function DragonWorldCupRoomListView:updateSureBtnState(state)
	self.ui.m_sureBtn:setEnabled(self.enabled and state == "0")
end

function DragonWorldCupRoomListView:onSureClick()
	if self.selectIndex == -1 then
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("140273"))
		return
	end

	local showIndex = tonumber(self.selectIndex) + 1
	local desc = getLang("140019", tostring(showIndex))
	local callback = function() self:confirm() end
	local func = cc.CallFunc:create(callback)
	YesNoDialog:call("show", desc, func)
end

function DragonWorldCupRoomListView:confirm()
	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	if playerInfo:call("isInAlliance") then
		local allianceInfo = playerInfo:getProperty("allianceInfo")
		local rank = allianceInfo:getProperty("rank")
		if rank < 4 then
			YesNoDialog:show(getLang("E100119"))
			return
		end
	end
	
	local cmd = require("game.command.DragonWorldCupBattleTimeConfirmCmd").create(self.selectIndex, self.timeIndex)
	cmd:send()
end

--------------------DragonWorldCupCell--------------------
function DragonBattleRoomCell:create(roomInfo, parView)
	local view = DragonBattleRoomCell.new()
	Drequire("game.dragonWorldCup.DragonWorldCupCell_ui"):create(view, 1)
	if view:initView(roomInfo, parView) then
		return view
	end 
end

function DragonBattleRoomCell:initView(roomInfo, parView)
	registerTouchHandler(self)
	self:setTouchEnabled(true)
	self:setSwallowsTouches(false)

	self.parView = parView
	self.listNode = parView.ui.m_infoList
	self.ui.m_signTxt:setString(getLang("140018"))
	self:setData(roomInfo)

	return true
end

function DragonBattleRoomCell:setData(roomInfo)
	self.roomInfo = roomInfo
	if roomInfo == nil then return end

	self.index = self.roomInfo.index
	self.showIndex = tonumber(self.index) + 1
	self.ui.m_txt1:setString(getLang("140016") .. ": ")
	self.ui.m_txt2:setString(getLang("140017", CC_CMDITOA(self.roomInfo.num)))
	self.ui.m_txt3:setString(getLang("140168", tostring(self.showIndex)))
	self.ui.m_txt4:setString(tostring(self.showIndex))

	--只有区域小组赛显示时段的选择联盟数量
	if not dragonWorldCupManager.isGroupBattle() then
		self.ui.m_txt2:setVisible(false)
	end

	local time1 = CCCommonUtilsForLua:call("timeStampToUTCDate", tonumber(self.roomInfo.beginTime))
	local time2 = CCCommonUtilsForLua:call("timeStampToUTCDate", tonumber(self.roomInfo.endTime))
	self.ui.m_time1:setString(time1)
	self.ui.m_time2:setString(time2)

	local offx = self.ui.m_txt1:getPositionX() + self.ui.m_txt1:getContentSize().width * self.ui.m_txt1:getScaleX() + 20
	self.ui.m_time1:setPositionX(offx)
	self.ui.m_time2:setPositionX(offx)

	self.ui.m_selectNode:setVisible(false)
	self.ui.m_signNode:setVisible(roomInfo.state ~= "0")
end

function DragonBattleRoomCell:onTouchBegan(x, y)
	if not isTouchInside(self.listNode, x, y) then return false end

	self.touchPoint = ccp(x, y)
	if isTouchInside(self.ui.m_clickNode, x, y) then return true end

	return false
end

function DragonBattleRoomCell:onTouchEnded(x, y)
	if (ccpDistance(self.touchPoint, ccp(x, y)) > 30) then return end

	self.parView:clickSelect(self.index)
	self.parView:updateSureBtnState(self.roomInfo.state)
end

function DragonBattleRoomCell:updateCellSelectState(selected)
	self.ui.m_selectNode:setVisible(selected)
end

function DragonBattleRoomCell:showChoosed()
	self.roomInfo.num = tostring(tonumber(self.roomInfo.num) + 1)
	self.ui.m_txt2:setString(getLang("140017", CC_CMDITOA(self.roomInfo.num)))
	self.ui.m_signNode:setVisible(true)
end
--------------------DragonWorldCupCell--------------------

return DragonWorldCupRoomListView