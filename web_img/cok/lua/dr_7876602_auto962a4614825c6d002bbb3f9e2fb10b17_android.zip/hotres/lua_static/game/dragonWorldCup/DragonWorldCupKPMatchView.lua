local DragonWorldCupKPMatchView = class("DragonWorldCupKPMatchView",
	function()
		return PopupBaseView:create()
	end
)
DragonWorldCupKPMatchView.__index = DragonWorldCupKPMatchView

local dragonWorldCupManager = require("game.dragonWorldCup.DragonWorldCupManager")

local TOP_HEIGHT = 75
local TOP_HEIGHT_HD = 154

function DragonWorldCupKPMatchView:create()
	local view = DragonWorldCupKPMatchView.new()
	Drequire("game.dragonWorldCup.DragonWorldCupBattleMessageView_ui"):create(view, 1)
	if view:initView(allianceId) then
		return view
	end
end

function DragonWorldCupKPMatchView:initView()
	if self:init(true, 0) then
		
		self:setHDPanelFlag(true)

		local ccbSize = self.ui.nodeccb:getContentSize()
		self:setContentSize(ccbSize)

		-- local dh = TOP_HEIGHT + 15
		if CCCommonUtilsForLua:isIosAndroidPad() then 
		-- 	dh = TOP_HEIGHT_HD + 15
			self:setScale(2.4)
		end

		CCLoadSprite:call("doResourceByCommonIndex", 205, true)
		CCLoadSprite:call("doResourceByCommonIndex", 208, true)
		--self.ui.nodeccb:setPositionY(self.ui.nodeccb:getPositionY() + dh)

		self.ui.m_title:setString(getLang("140288"))
		self.ui.m_battleTime1:setString(getLang("140168", "1"))
		self.ui.m_battleTime2:setString(getLang("140168", "2"))
		self.ui.m_battleTime3:setString(getLang("140168", "3"))

		GameController:call("showWaitInterface")

		local kpCommand = require("game.command.DragonWorldCupKPMatchInfoCmd").create()
		kpCommand:send()
		--self:setView()

		local touchLayer = cc.Layer:create()
		self:addChild(touchLayer)

		local function touchHandle( eventType, x, y )
			if eventType == "began" then
				return self:onTouchBegan(x, y)
			elseif eventType == "moved" then
				self:onTouchMoved(x, y)
			else
				self:onTouchEnded(x, y)
			end
		end
		touchLayer:registerScriptTouchHandler(touchHandle)
		touchLayer:setTouchEnabled(true)
		touchLayer:setSwallowsTouches(false)

		return true
	end

	return false
end

function DragonWorldCupKPMatchView:onEnter()
	local function callback1() self:getDataBack() end
	local handler1 = self:registerHandler(callback1)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "dragon.worldcup.kpmatch.info")
end

function DragonWorldCupKPMatchView:onExit()
	CCSafeNotificationCenter:unregisterScriptObserver(self, "dragon.worldcup.kpmatch.info")
end

function DragonWorldCupKPMatchView:getDataBack()
	GameController:call("removeWaitInterface")
	self.kpMatchInfo = dragonWorldCupManager.getKpMatchData()
	if sizen(self.kpMatchInfo) == 0 then return end
	self:setView()
end

function DragonWorldCupKPMatchView:setView()
	if self.kpMatchInfo.self then
		local info = self.kpMatchInfo.self
		local abbr = info.abbr
		local name = info.name 
		local allianceStr = name .. "(" .. abbr .. ")" 
		local kingdomStr = info.kingdomName

		self.ui.m_alaNameLeft:setString(getLang("108596", allianceStr))
		self.ui.m_kingdomLeft:setString(getLang("140031", kingdomStr))

		self.chooseTimeState = (info.time1 ~= -1 and info.time2 ~= -1 and info.time3 ~= -1)

		local icon = (info.icon == "") and "Allance_flay" or info.icon
		local flag = AllianceFlagPar:call("create", icon .. ".png")
		flag = tolua.cast(flag, "cc.Node")
		flag:setScale(0.6657)
		self.ui.m_alaFlagLeft:addChild(flag)

		if DynamicResourceController2:call("checkDynamicResource", "dragonGlobal") 
				and CCLoadSprite:call("loadDynamicResourceByName", "dragonGlobal") then
			local miniTag = dragonWorldCupManager.getCountryIcon(info.country)
			local countryFlag = CCLoadSprite:call("createSprite", miniTag)
			self.ui.m_alaCountryFlagLeft:addChild(countryFlag)
			self.ui.m_alaCountryFlagLeft:setScale(1.0)
		else
			local countryFlag = CCLoadSprite:call("createSprite", info.country .. ".png", CCLoadSpriteType.CCLoadSpriteType_COUNTRY_ICON)
			self.ui.m_alaCountryFlagLeft:addChild(countryFlag)
		end

		self:setButtonTitle(self.ui.m_leftTime1, info.time1, true)
		self:setButtonTitle(self.ui.m_leftTime2, info.time2, true)
		self:setButtonTitle(self.ui.m_leftTime3, info.time3, true)
	else
		self:setButtonTitle(self.ui.m_leftTime1, -1, false)
		self:setButtonTitle(self.ui.m_leftTime2, -1, false)
		self:setButtonTitle(self.ui.m_leftTime3, -1, false)
	end

	if self.kpMatchInfo.other then
		local info = self.kpMatchInfo.other
		local abbr = info.abbr
		local name = info.name 
		local allianceStr = name .. "(" .. abbr .. ")" 
		local kingdomStr = info.kingdomName

		self.ui.m_alaNameRight:setString(getLang("108596", allianceStr))
		self.ui.m_kingdomRight:setString(getLang("140031", kingdomStr))

		local icon = (info.icon == "") and "Allance_flay" or info.icon
		local flag = AllianceFlagPar:call("create", icon .. ".png")
		flag = tolua.cast(flag, "cc.Node")
		flag:setScale(0.6657)
		self.ui.m_alaFlagRight:addChild(flag)

		if DynamicResourceController2:call("checkDynamicResource", "dragonGlobal") 
				and CCLoadSprite:call("loadDynamicResourceByName", "dragonGlobal") then
			local miniTag = dragonWorldCupManager.getCountryIcon(info.country)
			local countryFlag = CCLoadSprite:call("createSprite", miniTag)
			self.ui.m_alaCountryFlagRight:addChild(countryFlag)
			self.ui.m_alaCountryFlagRight:setScale(1.0)
		else
			local countryFlag = CCLoadSprite:call("createSprite", info.country .. ".png", CCLoadSpriteType.CCLoadSpriteType_COUNTRY_ICON)
			self.ui.m_alaCountryFlagRight:addChild(countryFlag)
		end

		self:setButtonTitle(self.ui.m_rightTime1, info.time1, false)
		self:setButtonTitle(self.ui.m_rightTime2, info.time2, false)
		self:setButtonTitle(self.ui.m_rightTime3, info.time3, false)
	else
		self:setButtonTitle(self.ui.m_rightTime1, -1, false)
		self:setButtonTitle(self.ui.m_rightTime2, -1, false)
		self:setButtonTitle(self.ui.m_rightTime3, -1, false)
	end
end

function DragonWorldCupKPMatchView:setButtonTitle(btn, index, isSelf)
	local btnText = ""
	local touchEnable = false
	if index == -1 then
		if isSelf then
			btnText = getLang("140274")
			touchEnable = true
		else
			btnText = getLang("140273")
		end
	else
		btnText = index * 2 .. ":00-" .. (index + 1) * 2 .. ":00"
	end
	btn:setEnabled(touchEnable)
	CCCommonUtilsForLua:setButtonTitle(btn, btnText)
end

function DragonWorldCupKPMatchView:onTouchBegan(x, y)
	self.touchStartPoint = ccp(x, y)
	return true
end

function DragonWorldCupKPMatchView:onTouchEnded(x, y)
	if ccpDistance(self.touchStartPoint, ccp(x, y)) > 30 then return end
	if not isTouchInside(self.ui.m_touchLayer, x, y) then
		PopupViewController:call("removePopupView", self)
	end
end

function DragonWorldCupKPMatchView:onLeftTime1()
	local roomListView = require("game.dragonWorldCup.DragonWorldCupRoomListView"):create(1, not self.chooseTimeState)
	PopupViewController:addPopupInView(roomListView)
	PopupViewController:call("removePopupView", self)
end

function DragonWorldCupKPMatchView:onLeftTime2()
	local roomListView = require("game.dragonWorldCup.DragonWorldCupRoomListView"):create(2, not self.chooseTimeState)
	PopupViewController:addPopupInView(roomListView)
	PopupViewController:call("removePopupView", self)
end

function DragonWorldCupKPMatchView:onLeftTime3()
	MyPrint("self.chooseTimeState3", self.chooseTimeState)
	local roomListView = require("game.dragonWorldCup.DragonWorldCupRoomListView"):create(3, not self.chooseTimeState)
	PopupViewController:addPopupInView(roomListView)
	PopupViewController:call("removePopupView", self)
end

return DragonWorldCupKPMatchView