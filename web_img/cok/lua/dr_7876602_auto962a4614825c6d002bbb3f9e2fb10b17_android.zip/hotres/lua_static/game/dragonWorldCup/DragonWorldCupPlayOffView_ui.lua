----------------------------
-- Author: Elex
-- Date: 2017-08-10 16:17:45
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local DragonWorldCupPlayOffView_ui = class("DragonWorldCupPlayOffView_ui")

--#ui propertys


--#function
function DragonWorldCupPlayOffView_ui:create(owner, viewType)
	local ret = DragonWorldCupPlayOffView_ui.new()
	CustomUtility:DoRes(205, true)
	CustomUtility:DoRes(500, true)
	CustomUtility:DoRes(513, true)
	CustomUtility:DoRes(515, true)
	CustomUtility:DoRes(516, true)
	CustomUtility:DoRes(7, true)
	CustomUtility:LoadUi("DragonWorldCupPlayOffView.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function DragonWorldCupPlayOffView_ui:initLang()
end

function DragonWorldCupPlayOffView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function DragonWorldCupPlayOffView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function DragonWorldCupPlayOffView_ui:onBtnLiveBlueClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBtnLiveBlueClick", pSender, event)
end

function DragonWorldCupPlayOffView_ui:onBtnLiveRedClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onBtnLiveRedClick", pSender, event)
end

function DragonWorldCupPlayOffView_ui:onShareBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onShareBtnClick", pSender, event)
end

function DragonWorldCupPlayOffView_ui:onRewardClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onRewardClick", pSender, event)
end

function DragonWorldCupPlayOffView_ui:onSelectTimeClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onSelectTimeClick", pSender, event)
end

function DragonWorldCupPlayOffView_ui:onFightClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onFightClick", pSender, event)
end

function DragonWorldCupPlayOffView_ui:onManageClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onManageClick", pSender, event)
end

return DragonWorldCupPlayOffView_ui

