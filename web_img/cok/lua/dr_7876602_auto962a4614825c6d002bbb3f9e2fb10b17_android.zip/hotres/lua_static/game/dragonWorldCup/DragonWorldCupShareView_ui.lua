----------------------------
-- Author: Elex
-- Date: 2017-06-15 16:48:44
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local DragonWorldCupShareView_ui = class("DragonWorldCupShareView_ui")

--#ui propertys


--#function
function DragonWorldCupShareView_ui:create(owner, viewType)
	local ret = DragonWorldCupShareView_ui.new()
	CustomUtility:DoRes(505, true)
	CustomUtility:DoRes(512, true)
	CustomUtility:LoadUi("DragonWorldCupShareView.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function DragonWorldCupShareView_ui:initLang()
end

function DragonWorldCupShareView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function DragonWorldCupShareView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function DragonWorldCupShareView_ui:onOkBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onOkBtnClick", pSender, event)
end

function DragonWorldCupShareView_ui:onFaceBookShare(pSender, event)
	ButtonSmoker:forwardFunction(self, "onFaceBookShare", pSender, event)
end

function DragonWorldCupShareView_ui:onSinaShare(pSender, event)
	ButtonSmoker:forwardFunction(self, "onSinaShare", pSender, event)
end

function DragonWorldCupShareView_ui:onWebChatShare(pSender, event)
	ButtonSmoker:forwardFunction(self, "onWebChatShare", pSender, event)
end

return DragonWorldCupShareView_ui

