BarrackTile = class("BarrackTile", function()
    return NewBaseTileLuaInfo:call("create")
end
)

function BarrackTile:create( index )
    local tile = BarrackTile.new(index)
    if tile:initView(index) then
        return tile
    end
end

function BarrackTile:ctor(index)
    self.cityIndex = index
end

function BarrackTile:initView( index )
    self:call("setCityIndex", index)
    if self:call("initTile", true) == false then return false  end

    local cityInfo = self:call("getCityInfo")
    if nil == cityInfo then return false end

    self.cityInfo = cityInfo

    self.dataBack = false
    registerNodeEventHandler(self)
    self:call("addToParent")
    self:refreshView()

    return true
end

function BarrackTile:onEnter()

end

function BarrackTile:onExit()
   
end

function BarrackTile:refreshView()
    local function setCallBack(name, index, func, state)
        local function callback() func(self) end
        self:call("setButtonName", index, name)
        self:call("setButtonState", index, state)
        self:call("setButtonCallback", index, cc.CallFunc:create(callback))
    end

    self:call("setButtonCount", 2)
    setCallBack(getLang("108730"), 2, self.information, TileButtonState.ButtonInformation) -- 108730=说明
    setCallBack(getLang("9201263"), 3, self.getArmy, TileButtonState.ButtonSupport) -- 9201263=调兵    
end

function BarrackTile:information()
    local view = Drequire("game.FestivalActivities.FestivalActivitiesExplainView"):create(getLang("9201270"))
    PopupViewController:addPopupView(view)
    self:closeTile()
end

function BarrackTile:getArmy()
    local index = WorldController:call("getSelfCityIndex")

    if require("game.dragonWorldCup.DragonWorldCupManager").isMyBarrck(self.cityIndex) == false then
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("9201283"))
    elseif CCCommonUtilsForLua:call("isDragonWcSafeZone", index) then
        local view = Drequire("game.dragonWorldCup.DragonWorldCupBarrcksView"):create()
        PopupViewController:addPopupInView(view)
    else
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("9201276"))
    end
    self:closeTile()
end

function BarrackTile:closeTile()
    self = tolua.cast(self, "NewBaseTileLuaInfo")
    
    self:call("closeThis")
end
