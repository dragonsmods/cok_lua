local DragonWorldCupBarrcksView = class("DragonWorldCupBarrcksView", PopupBaseView)

function DragonWorldCupBarrcksView:create()
    local view = DragonWorldCupBarrcksView.new()
    Drequire("game.dragonWorldCup.DragonWorldCupBarrcksView_ui"):create(view, 1)
    if view:initView() then return view end
end

function DragonWorldCupBarrcksView:ctor()
    self.armyMap = {}
    self.totalArmy = {}
    self.totalArmyMap = {}
    self.canGet = 0
    self.change = 0
    self.quickDirty = false
end

function DragonWorldCupBarrcksView:initView()
    local cmd = Drequire("game.command.DragonWorldCupArmyCmd").create()
    cmd:send()
    return true
end

local function sort(data1, data2)
    local lvRank1 = tonumber(CCCommonUtilsForLua:getPropByIdGroup("arms", data1.armyId, "level_rank")) or 0
    local lvRank2 = tonumber(CCCommonUtilsForLua:getPropByIdGroup("arms", data2.armyId, "level_rank")) or 0
    return lvRank2 < lvRank1
end

function DragonWorldCupBarrcksView:refreshView(param)
    if param then
        local data = dictToLuaTable(param)
        -- dump(data)
        -- data = {
        --     now = 0,
        --     capacity = 10000,
        --     armys = {
        --         ["107111"] = 50,
        --         ["40400101"] = 10000,
        --         ["40400104"] = 10000,
        --         ["40400105"] = 10000,
        --         ["107313"] = 10000,
        --         ["40400106"] = 10000,
        --         ["40400107"] = 10000,
        --         ["40400108"] = 10000,
        --         ["40400201"] = 10000,
        --         ["40400202"] = 10000,
        --         ["40400203"] = 10000,
        --     }
        -- }
        local now = atoi(data.now)
        local capacity = atoi(data.capacity)
        local remain = 0
        self.canGet = capacity - now
        if self.canGet < 0 then self.canGet = 0 end

        self.armyMap = {}
        self.totalArmy = {}
        self.totalArmyMap = {}

        local function correctCb(armyId, count)
            self:correct(armyId, count)
        end

        for armyId, count in pairs(data.armys or {}) do
            remain = remain + atoi(count)

            if atoi(count) > 0 then
                local armyInfo = {
                    ["armyId"] = armyId, 
                    ["maxNum"] = atoi(count),
                    ["selectNum"] = 0,
                    ["correctCb"] = correctCb,
                }
                table.insert(self.totalArmy, armyInfo)
                self.totalArmyMap[armyId] = armyInfo
            end
        end

        if self.canGet > remain then
            self.canGet = remain
        end
        table.sort(self.totalArmy, sort)

        self.ui.m_okBtn:setEnabled(self.canGet > 0)
        self.ui.m_quickBtn:setEnabled(self.canGet > 0)
        self.ui.m_change1:setString("")
        self.ui.m_change2:setString("")
        self.ui.m_text1:setString(getLang("9201268", CC_CMDITOA(remain)))
        self.ui.m_text2:setString(getLang("9201269", CC_CMDITOA(now), CC_CMDITOA(capacity)))
        self.ui:setTableViewDataSource("m_listView", self.totalArmy)

        if self.canGet > 0 then
            self.quickDirty = false
            self:onClickQuick()
        end
    end
end

function DragonWorldCupBarrcksView:correct(armyId, count)
    self.armyMap[armyId] = count

    local total = 0
    for _, num in pairs(self.armyMap) do
        total = total + num
    end
    if total > self.canGet then
        local overloap = total - self.canGet
        count = count - overloap
        self.armyMap[armyId] = count
        total = total - overloap

        local notifier = CCDictionary:create()
        notifier:setObject(CCString:create(armyId), "armyId")
        notifier:setObject(CCString:create(tostring(count)), "correctNum")
        CCSafeNotificationCenter:postNotification("msg.worldcup.army.correct", notifier)
    end

    self.ui.m_change1:setString("-" .. CC_CMDITOA(total))
    self.ui.m_change2:setString("+" .. CC_CMDITOA(total))
end

function DragonWorldCupBarrcksView:refreshChange()
    local total = 0
    for _, armyInfo in ipairs(self.totalArmy or {}) do
        total = total + armyInfo.selectNum
    end

    self.ui.m_change1:setString("-" .. CC_CMDITOA(total))
    self.ui.m_change2:setString("+" .. CC_CMDITOA(total))
end

function DragonWorldCupBarrcksView:onEnter()
    registerScriptObserver(self, self.refreshView, "msg.worldcup.army")
    registerScriptObserver(self, self.refreshView, "msg.worldcup.getArmy")
end

function DragonWorldCupBarrcksView:onExit()
    unregisterScriptObserver(self, "msg.worldcup.army")
    unregisterScriptObserver(self, "msg.worldcup.getArmy")
end

function DragonWorldCupBarrcksView:selectAll()
    local soldierCnt = #self.totalArmy <= 8 and #self.totalArmy or 8
    local preSoldierNum = math.ceil(self.canGet / soldierCnt)
    local _tmpLastNum = self.canGet
    
    for index, armyInfo in ipairs(self.totalArmy) do
        local tmpCntNum = armyInfo.maxNum
        tmpCntNum = tmpCntNum > preSoldierNum and preSoldierNum or tmpCntNum
        tmpCntNum = tmpCntNum > _tmpLastNum and _tmpLastNum or tmpCntNum
        _tmpLastNum = _tmpLastNum - tmpCntNum
        armyInfo.selectNum = tmpCntNum
        self.armyMap[armyInfo.armyId] = tmpCntNum
        
        if index >= soldierCnt then
            break
        end
    end

    self.ui.m_listView:reloadData()
end

function DragonWorldCupBarrcksView:unSelectAll()
    for _, armyInfo in ipairs(self.totalArmy or {}) do
        armyInfo.selectNum = 0
        self.armyMap[armyInfo.armyId] = 0
    end

    self.ui.m_listView:reloadData()
end

function DragonWorldCupBarrcksView:onClickQuick()
    self.quickDirty = not self.quickDirty

    if self.quickDirty then
        self:selectAll()
    else
        self:unSelectAll()
    end

    self:refreshChange()
end

function DragonWorldCupBarrcksView:onClickOk()
    if sizen(self.armyMap) == 0 then return end

    local cmd = Drequire("game.command.DragonWorldCupGetArmyCmd").create(self.armyMap)
    cmd:send()

    self.ui.m_okBtn:setEnabled(false)
    self.ui.m_quickBtn:setEnabled(false)
end

function DragonWorldCupBarrcksView:changeFormation(format)
    if self.canGet == 0 then return end

    local method = ""
    local mode = TroopsController:call("getFormatModeByIndex", format)
    if mode == 1 then
        method = TroopsController:call("resetFormatStrByIndex", format, self.canGet)
    else
        method = TroopsController:call("getFormatStrByIndex", format)
    end

    local armys = {}

    local _tmpLastNum = self.canGet
    local solts1 = splitString(method, "|")
    for _, data in ipairs(solts1) do
        local solts2 = splitString(data, ",")
        if #solts2 == 2 then
            local armyId = solts2[1]
            local tmpCntNum = atoi(solts2[2])
            local capacity = self.totalArmyMap[armyId] and self.totalArmyMap[armyId].maxNum or 0
            tmpCntNum = tmpCntNum > capacity and capacity or tmpCntNum
            tmpCntNum = tmpCntNum > _tmpLastNum and _tmpLastNum or tmpCntNum
            _tmpLastNum = _tmpLastNum - tmpCntNum
            armys[armyId] = tmpCntNum
        end
    end

    for _, armyInfo in ipairs(self.totalArmy or {}) do
        armyInfo.selectNum = 0
        self.armyMap[armyInfo.armyId] = 0

        if armys[armyInfo.armyId] then
            local armyNum = armys[armyInfo.armyId]
            armyInfo.selectNum = armyNum
            self.armyMap[armyInfo.armyId] = armyNum
        end
    end 

    self.ui.m_listView:reloadData()
    self:refreshChange()
end

function DragonWorldCupBarrcksView:onFormation1Click()
    self:changeFormation(1)
end

function DragonWorldCupBarrcksView:onFormation2Click()
    self:changeFormation(2)
end

function DragonWorldCupBarrcksView:onFormation3Click()
    self:changeFormation(3)
end

function DragonWorldCupBarrcksView:onFormation4Click()
    self:changeFormation(4)
end

function DragonWorldCupBarrcksView:onFormation5Click()
    self:changeFormation(5)
end

return DragonWorldCupBarrcksView