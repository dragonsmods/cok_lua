local DragonWorldCupManager = DragonWorldCupManager or {}

--主状态
DRAGON_WORLDCUP_UNOPEN_STAGE = 0 --未开启阶段
DRAGON_WORLDCUP_SIGNUP_STAGE = 1 --报名阶段
DRAGON_WORLDCUP_GROUP_STAGE = 2 --小组赛阶段
DRAGON_WORLDCUP_KNOCK_STAGE = 3 --淘汰赛阶段
DRAGON_WORLDCUP_PLAYOFF_STAGE = 4 --决赛阶段
DRAGON_WORLDCUP_SLEEP_STAGE = 5 --赛季冷却阶段

--子状态
DRAGON_WORLDCUP_READY_SUBSTAGE = 1 --准备阶段
DRAGON_WORLDCUP_MATCH_SUBSTAGE = 2 --匹配完成
DRAGON_WORLDCUP_BATTLE_SUBSTAGE = 3 --战斗阶段
DRAGON_WORLDCUP_REWARD_SUBSTAGE = 4 --发奖

--报名状态
DRAGON_WORLDCUP_SIGNUPED = true --已经报名
DRAGON_WORLDCUP_NOT_SIGNUP = false --未报名

--是否满足报名状态
DRAGON_WORLDCUP_MATCH_SIGNUP = true --满足报名条件
DRAGON_WORLDCUP_NOT_MATCH_SIGNUP = false --不满足报名条件

--选择时间状态
DRAGON_WORLDCUP_CHOOSED = true --已经选择
DRAGON_WORLDCUP_NOT_CHOOSE = false --未选择

-- 世界杯常规赛OB券  ItemSpec  211661
-- 世界杯16强决赛OB券  ItemSpec  211662 
local group_ob_item = 211661
local playoff_ob_item = 211662

function DragonWorldCupManager.initConfig()
	-- body
end

----------------SHP START----------------
--区域配置
local wag_areaInfo = nil
-- 世界杯信息
local worldCupInfo = nil
-- 出站管理信息
local managerInfo = nil
--区域排名信息
local worldCupRankInfo = nil
--冠军赛对阵详情信息
local worldCupChampionEngageInfo = nil
--冠军赛和决赛选择时间入口界面信息
local worldCupKpMatchInfo = nil
--区域赛奖励界面信息
local worldCupGroupRewardInfo = nil
--冠军赛奖励信息
local worldCupChampionRewardInfo = nil
--决赛奖励信息
local worldCupPlayOffRewardInfo = nil
--是否打开赛程界面
local dragonMarchOpenFlag = true

function DragonWorldCupManager.initConfig()
	-- body
	if wag_areaInfo == nil then
		wag_areaInfo = dictToLuaTable(LocalController:call("DBXMLManager"):call("getGroupByKey", "wag_area"))

		-- dump(wag_areaInfo, "wag_areaInfo")
	end
end

function DragonWorldCupManager.getZoneName(zoneId)
	return wag_areaInfo[zoneId] and wag_areaInfo[zoneId].name or ""
end

function DragonWorldCupManager.getZoneOrder(zoneId)
	return wag_areaInfo[zoneId] and wag_areaInfo[zoneId].order or 0
end

function DragonWorldCupManager.isDragonGlobalServer()
	local serverType = GlobalData:call("shared"):getProperty("serverType")
	MyPrint("isDragonGlobalServer", serverType == ServerType.SERVER_DRAGON_BATTLE_GLOBAL)
	return serverType == ServerType.SERVER_DRAGON_BATTLE_GLOBAL
end

--请求巨龙世界杯活动数据
function DragonWorldCupManager.requestActivityData(open)
	open = open or false
	dragonMarchOpenFlag = open

	if CCCommonUtilsForLua:isFunOpenByKey("wag_switch") then
		-- body
		--请求比赛数据
		local command = require("game.command.DragonWorldCupInfoCmd").create()
		command:send()
	else
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("102192"))
	end
end

--打开巨龙界面
function DragonWorldCupManager.openDragonBattleView()
	--test
	-- worldCupInfo.mainStage = 3
	-- worldCupInfo.extra_knock_out = true

	if worldCupInfo.mainStage == DRAGON_WORLDCUP_SIGNUP_STAGE or worldCupInfo.mainStage == DRAGON_WORLDCUP_GROUP_STAGE  or worldCupInfo.seasonOver then
		local view = Drequire("game.dragonWorldCup.DragonWorldCupView"):create()
		PopupViewController:call("addPopupInView", view)
	elseif worldCupInfo.mainStage == DRAGON_WORLDCUP_KNOCK_STAGE and worldCupInfo.extra_knock_out then
		local lua_path = "game.dragonWorldCup.DragonWorldCupExtraKnockView"
		package.loaded[lua_path] = nil
		local view = require(lua_path):create()
		PopupViewController:call("addPopupInView", view)
	elseif worldCupInfo.mainStage == DRAGON_WORLDCUP_KNOCK_STAGE then
		local view = require("game.dragonWorldCup.DragonWorldCupAgainstView"):create()
		PopupViewController:call("addPopupInView", view)
	elseif worldCupInfo.mainStage == DRAGON_WORLDCUP_PLAYOFF_STAGE then
		local view = require("game.dragonWorldCup.DragonWorldCupPlayOffView"):create()
		PopupViewController:call("addPopupInView", view)
	end
end

--小组赛信息
function DragonWorldCupManager.parseWorldCupData(infoTable)
	--世界杯信息
	worldCupInfo = {}
	--世界杯主状态
	worldCupInfo.mainStage = tonumber(infoTable.mainState)
	--世界杯子状态
	worldCupInfo.subStage = tonumber(infoTable.subState)
	--是否报名
	worldCupInfo.applyState = (infoTable.applyState and infoTable.applyState ~= "0")

	if worldCupInfo.mainStage  == DRAGON_WORLDCUP_SIGNUP_STAGE and worldCupInfo.applyState then
		worldCupInfo.mainStage = DRAGON_WORLDCUP_GROUP_STAGE
		worldCupInfo.subStage = DRAGON_WORLDCUP_READY_SUBSTAGE
	end

	--显示未报名界面
	worldCupInfo.showNoJoinTag = (worldCupInfo.mainStage == DRAGON_WORLDCUP_GROUP_STAGE and worldCupInfo.applyState == false)
	--赛季结束
	worldCupInfo.seasonOver = (worldCupInfo.mainStage == DRAGON_WORLDCUP_UNOPEN_STAGE) or (worldCupInfo.mainStage == DRAGON_WORLDCUP_SLEEP_STAGE) or (worldCupInfo.subStage == DRAGON_WORLDCUP_REWARD_SUBSTAGE)

	local now = LuaController:call("getTimeStamp")

	--区域
	worldCupInfo.zone = infoTable.zone or "-1"
	--区域丢失(服务器历史遗留问题)
	worldCupInfo.missZone = (worldCupInfo.zone == "-1")
	--是否满足报名条件
	worldCupInfo.canApply = (infoTable.canApply and infoTable.canApply ~= "0")
	--报名战力
	worldCupInfo.applyPower = tonumber(infoTable.applyPower) or 8888888888
	--是否选择比赛时间
	worldCupInfo.chooseTimeState = (infoTable.chooseTimeState and infoTable.chooseTimeState ~= "0")
	--报名开始时间
	worldCupInfo.applyStartTime = tonumber(infoTable.applyStartTime) or 0
	--报名结束时间
	worldCupInfo.applyEndTime = tonumber(infoTable.applyEndTime) or 0
	--匹配结束时间 
	worldCupInfo.matchStartTime = tonumber(infoTable.matchStartTime) or 0
	--战场开启前{0}分钟无法修改出战名单
	worldCupInfo.managerTime = tonumber(infoTable.managerTime) or 0
	--修改名单结束时间
	worldCupInfo.battleManagerEndTime = tonumber(infoTable.battleManagerEndTime) or -1
	--是否在出战名单
	worldCupInfo.canEnterBattle = (infoTable.canEnterBattle ~= "0")
	--战斗准备时间
	worldCupInfo.battleReadyTime = tonumber(infoTable.battleReadyTime) or 0
	--战斗开始时间
	worldCupInfo.battleBeginTime = tonumber(infoTable.battleBeginTime) or 0
	--战斗结束时间
	worldCupInfo.battleEndTime = tonumber(infoTable.battleEndTime) or 0
	--本轮结束时间
	worldCupInfo.turnEndTime = tonumber(infoTable.turnEndTime) or 0
	--休息状态
	worldCupInfo.restState = (now > worldCupInfo.battleEndTime) and (now < worldCupInfo.turnEndTime) and (worldCupInfo.subStage == DRAGON_WORLDCUP_BATTLE_SUBSTAGE)
	--当前比赛轮数
	worldCupInfo.rounds = tonumber(infoTable.rounds) or 0
	--剩余比赛轮数
	worldCupInfo.leftRounds = tonumber(infoTable.leftRounds) or 0
	--32强赛信息
	worldCupInfo.groups = infoTable.groups
	--4强比赛
	worldCupInfo.extra_knock_out = (infoTable.extra_knock_out  and infoTable.extra_knock_out ~= "0" )
	--小组赛轮空
	worldCupInfo.miss = (infoTable.miss and infoTable.miss ~= "0")
	--决赛信息
	worldCupInfo.playoff = infoTable.playoff
	--根据类型打开页面
	if dragonMarchOpenFlag then DragonWorldCupManager.openDragonBattleView() end
end

--匹配之前
function DragonWorldCupManager.isBeforeMatch()
	if worldCupInfo == nil then return false end
	if worldCupInfo.matchStartTime == nil then return false end

	local now = LuaController:call("getTimeStamp")
	return worldCupInfo.matchStartTime > now
end

--匹配之后,战斗之前
function DragonWorldCupManager.isBeforeBattle()
	if worldCupInfo == nil then return false end
	if worldCupInfo.matchStartTime == nil then return false end
	if worldCupInfo.battleBeginTime == nil then return false end

	local now = LuaController:call("getTimeStamp")
	return now >= worldCupInfo.matchStartTime and now < worldCupInfo.battleBeginTime
end

--正在战斗
function DragonWorldCupManager.isInBattle()
	if worldCupInfo == nil then return false end
	if worldCupInfo.battleBeginTime == nil then return false end
	if worldCupInfo.battleEndTime == nil then return false end

	local now = LuaController:call("getTimeStamp")
	return now >= worldCupInfo.battleBeginTime and now < worldCupInfo.battleEndTime
end

--能否修改出战名单
function DragonWorldCupManager.canNotModifyBattleList()
	if worldCupInfo == nil then return false end
	if worldCupInfo.battleManagerEndTime == nil then return false end
	if worldCupInfo.battleManagerEndTime == -1 then return false end

	local now = LuaController:call("getTimeStamp")
	return now >= worldCupInfo.battleManagerEndTime
end

--战斗结束
function DragonWorldCupManager.isBattleOver()
	if worldCupInfo == nil then return end
	if worldCupInfo.battleEndTime == nil then return false end

	local now = LuaController:call("getTimeStamp")
	return now >= worldCupInfo.battleEndTime
end

--报名成功
function DragonWorldCupManager.applySuccess(infoTable)
	--世界杯主状态
	worldCupInfo.mainStage = DRAGON_WORLDCUP_GROUP_STAGE
	--世界杯子状态
	worldCupInfo.subStage = DRAGON_WORLDCUP_READY_SUBSTAGE
	--报名成功
	worldCupInfo.applyState = true
end

--选择时间
function DragonWorldCupManager.chooseTimeSuccess(infoTable)
	--改变状态
	worldCupInfo.chooseTimeState = true
end

--比赛时间选择
function DragonWorldCupManager.parseBattleRoomData(infoTable)
	--战斗房间信息
	battleRoomInfo = infoTable.rooms
end

--匹配信息
function DragonWorldCupManager.parseMatchData(infoTable, allianceId)
	--匹配信息
	matchInfo = {}
	--战斗开始时间戳
	matchInfo.battleBeginTime = tonumber(infoTable.battleBeginTime)
	--联盟ID
	matchInfo.allianceId = infoTable.allianceId
	--区域ID
	matchInfo.zone = infoTable.zone
	--排名
	matchInfo.rank = tonumber(infoTable.rank)
	--积分
	matchInfo.points = tonumber(infoTable.points)
	--联盟abbr
	matchInfo.abbr = infoTable.abbr
	--联盟name
	matchInfo.name = infoTable.name
	--联盟icon
	matchInfo.icon = infoTable.icon
	--联盟countryzz
	matchInfo.country = infoTable.country
	--联盟leader
	matchInfo.leader = infoTable.leaderName
	--所在服务器编号
	matchInfo.kingdom = tonumber(infoTable.kingdom)
	--服务器名字
	matchInfo.kingdomName = infoTable.kingdomName
	--胜率
	matchInfo.winRate = tonumber(infoTable.kingdomWinPercentage)
end

--出站管理
function DragonWorldCupManager.parseManagerData(infoTable)
	--重置报名信息
	managerInfo = {}
	--最大选中人数
	managerInfo.maxSelectNum = tonumber(infoTable.maxSelectNum) or 15
	--最大先发人数
	managerInfo.maxFirstOnNum = tonumber(infoTable.maxFirstOnNum) or 10
	--已选人数
	managerInfo.selectNum = 0
	--已选先发人数
	managerInfo.firstOnNum = 0
	--联盟成员信息
	managerInfo.members = {}
	--标记数据有效
	managerInfo.valid = true

	if type(infoTable.list) == "table" then
		for _, info in ipairs(infoTable.list) do
			--战斗状态  0未出战、1出战、2战斗中、 -1未选择
			info.fight = tonumber(info.fight) or -1

			info.isSelected = (info.fight ~= -1)
			info.isFirst = (info.fight == 1 or info.fight == 2)
			info.isInBattle = (info.fight == 2)

			if (info.isSelected) then
				managerInfo.selectNum = managerInfo.selectNum + 1
			end

			if (info.isFirst) then
				managerInfo.firstOnNum = managerInfo.firstOnNum + 1
			end

			
			managerInfo.members[#managerInfo.members + 1] = info
		end
	end
end

function DragonWorldCupManager.parseRankData(infoTable)
	---排名信息
	worldCupRankInfo = {}
	--本联盟排名
	worldCupRankInfo.selfRank = tonumber(infoTable.selfRank) or 0
	--区域排名信息
	worldCupRankInfo.rank = infoTable.rank
end

function DragonWorldCupManager.parseChampionDetailData(infoTable)
	worldCupChampionEngageInfo = {}
	--查询联盟Id
	worldCupChampionEngageInfo.allianceId = infoTable.allianceId
	--查询联盟名字
	worldCupChampionEngageInfo.name = infoTable.name
	--查询联盟缩写
	worldCupChampionEngageInfo.abbr = infoTable.abbr
	--查询联盟旗帜
	worldCupChampionEngageInfo.icon = infoTable.icon
	--查询联盟国家
	worldCupChampionEngageInfo.country = infoTable.country
	--查询联盟区域ID
	worldCupChampionEngageInfo.zone = infoTable.zone
	--查询联盟服务器
	worldCupChampionEngageInfo.kingdom = tonumber(infoTable.kingdom) or 0
	--查询联盟服务器名字
	worldCupChampionEngageInfo.kingdomName = infoTable.kingdomName
	--根据轮数排序
	local function sort(team1, team2)
		return team1.round < team2.round
	end
	--查询服务器对阵信息
	table.sort(infoTable.enemy, sort)
	worldCupChampionEngageInfo.enemy = infoTable.enemy
end

function DragonWorldCupManager.parseKpMatchData(infoTable)
	worldCupKpMatchInfo = {}
	--自己
	if (infoTable.self and type(infoTable.self) == "table") then
		worldCupKpMatchInfo.self = {}
		worldCupKpMatchInfo.self.name = infoTable.self.abbr
		worldCupKpMatchInfo.self.abbr = infoTable.self.abbr
		worldCupKpMatchInfo.self.kingdom = tonumber(infoTable.self.kingdom)
		worldCupKpMatchInfo.self.kingdomName = infoTable.self.kingdomName
		worldCupKpMatchInfo.self.icon = infoTable.self.icon
		worldCupKpMatchInfo.self.country = infoTable.self.country
		worldCupKpMatchInfo.self.zone = infoTable.self.zone
		worldCupKpMatchInfo.self.time1 = tonumber(infoTable.self.time1)
		worldCupKpMatchInfo.self.time2 = tonumber(infoTable.self.time2)
		worldCupKpMatchInfo.self.time3 = tonumber(infoTable.self.time3)
	end
	--对方
	worldCupKpMatchInfo.other = {}
	if (infoTable.other and type(infoTable.other) == "table") then
		worldCupKpMatchInfo.other = {}
		worldCupKpMatchInfo.other.name = infoTable.other.abbr
		worldCupKpMatchInfo.other.abbr = infoTable.other.abbr
		worldCupKpMatchInfo.other.kingdom = tonumber(infoTable.other.kingdom)
		worldCupKpMatchInfo.other.kingdomName = infoTable.other.kingdomName
		worldCupKpMatchInfo.other.icon = infoTable.other.icon
		worldCupKpMatchInfo.other.country = infoTable.other.country
		worldCupKpMatchInfo.other.zone = infoTable.other.zone
		worldCupKpMatchInfo.other.time1 = tonumber(infoTable.other.time1)
		worldCupKpMatchInfo.other.time2 = tonumber(infoTable.other.time2)
		worldCupKpMatchInfo.other.time3 = tonumber(infoTable.other.time3)
	end
end

function DragonWorldCupManager.parseGroupRewardData(infoTable)
	worldCupGroupRewardInfo = infoTable
end

function DragonWorldCupManager.parseChampionRewardData(infoTable)
	worldCupChampionRewardInfo = infoTable
end

function DragonWorldCupManager.parsePlayOffRewardData(infoTable)
	worldCupPlayOffRewardInfo = infoTable
end

--加入巨龙战场
function DragonWorldCupManager.enterDragonBattle(allianceId, isOb)
	isOb = isOb or false

	local serverType = GlobalData:call("shared"):getProperty("serverType")
	if serverType == ServerType.SERVER_DRAGON_BATTLE_GLOBAL then

	elseif isOb then

	else
		--if not DragonWorldCupManager.isInBattle() then
			--return
		--end

		--不在出战名单
		if not worldCupInfo.canEnterBattle then
			CCCommonUtilsForLua:call("flyHint", "", "", getLang("5200224"))
			return
		end

		--local serverType = GlobalData:call("shared"):getProperty("serverType")
		--local totalDead = ArmyController:call("getTotalDead")
		--local queueNum = QueueController:call("getQueueNumByType", TYPE_HOSPITAL)
		--if ( (serverType ~= ServerType.SERVER_DRAGON_BATTLE or serverType ~= ServerType.SERVER_DRAGON_BATTLE_GLOBAL) and (totalDead > 0 or queueNum > 0)) then
			-- local function callback() DragonWorldCupManager.healSoldier() end
			-- local callfunc = cc.CallFunc:create(callback)
			-- local diaglog = YesNoDialog:call("show", getLang("140146"), callfunc)
			-- diaglog:call("setYesButtonTitle", getLang("138113"))
			-- return		
		--end
	end

	-- local now = LuaController:call("getTimeStamp")
	-- local left = worldCupInfo.battleEndTime - now
	-- if left > 0 then 
	-- 	local minute = math.floor(left / 60)
	-- 	minute = math.max(minute, 1)
	-- 	YesNoDialog:call("show", getLang("140169", tostring(minute)))
	-- 	return
	-- end
	if DynamicResourceController2:call("checkDynamicResource", "dragon_map") and DynamicResourceController2:call("checkDynamicResource", "dragonGlobal") then 
		GameController:call("showWaitInterface")
		DragonWorldCupManager.sendEnterDragonCommand(allianceId, isOb)
	else
		--doubt
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("140218"), 3, 0, true)
	end

end

--退出战场
function DragonWorldCupManager.leaveBattle()
	local leaveCmd = require("game.command.DragonWorldCupLeaveCmd").create()
	leaveCmd:send()
end

--加入巨龙战场请求
function DragonWorldCupManager.sendEnterDragonCommand(allianceId, isOb)
	local enterCommand = require("game.command.DragonWorldCupEnterCmd").create(allianceId, isOb)
	enterCommand:send()
end

--数据对比请求
function DragonWorldCupManager.reqComparisonData()
	local cmd = require("game.command.DragonBattleComparisonCmd"):create()
	cmd:send()
end

--双方MVP数据对比展示
function DragonWorldCupManager.reqObMvpCmpData()
	local cmd = require("game.command.DragonBattleObMvpCmpCmd"):create()
	cmd:send()
end

--进入巨龙战场
function DragonWorldCupManager.enterDragonBattleWorld(infoTable)
	if infoTable == nil then return end
	if infoTable.serverInfo == nil then return end

	GameController:call("removeWaitInterface")

	CCSafeNotificationCenter:postNotification("removeAllHint")

	SceneController:call("clearShowBG")

 	local instance = WorldMapView:call("instance")
 	if instance then
 		instance:call("removeCover")
 	end

 	-- 原生界面打开或进程进入onpause后，就不做操作
 	local scene = CCDirector:sharedDirector():getRunningScene()
    if cc.Texture2D:getIsOnPause() == false then
    	local winSize = CCDirector:sharedDirector():getIFWinSize()
        local texture = cc.RenderTexture:create(winSize.width, winSize.height)
        texture:beginWithClear(0, 0, 0, 1.0)
        scene:visit()
        texture:endToLua()
        SceneController:call("setShowBG", texture)
    end

 	local originalGameUid = CCUserDefault:sharedUserDefault():getStringForKey("game_uid", "")
 	local originalPort = CCUserDefault:sharedUserDefault():getIntegerForKey("account_port", 0)
 	local originalServerIp = CCUserDefault:sharedUserDefault():getStringForKey("account_ip", "")
 	local originalServerZone = CCUserDefault:sharedUserDefault():getStringForKey("account_zone", "")
 	local originAccountUuid = CCUserDefault:sharedUserDefault():getStringForKey("account_uuid", "")
 	CCUserDefault:sharedUserDefault():setStringForKey("original_account_ip", originalServerIp)
 	CCUserDefault:sharedUserDefault():setStringForKey("original_account_zone", originalServerZone)
 	CCUserDefault:sharedUserDefault():setIntegerForKey("original_account_port", originalPort)
 	CCUserDefault:sharedUserDefault():setStringForKey("original_account_game_uid", originalGameUid)
 	CCUserDefault:sharedUserDefault():setStringForKey("original_account_uuid", originAccountUuid)
 	CCUserDefault:sharedUserDefault():flush()

 	local serverInfo = infoTable.serverInfo
 	local ip = serverInfo.ip
 	local zone = serverInfo.zone
 	local port = tonumber(serverInfo.port) or 8088
 	local gameUid = infoTable.uid

 	CCUserDefault:sharedUserDefault():setStringForKey("account_ip", ip)
 	CCUserDefault:sharedUserDefault():setStringForKey("account_zone", zone)
 	CCUserDefault:sharedUserDefault():setIntegerForKey("account_port", port)
 	CCUserDefault:sharedUserDefault():setStringForKey("game_uid", gameUid)

 	if (CCCommonUtilsForLua:call("getIsUseDES")) then
        DESUserDefault:call("setValueForKey", "game_uid", gameUid)
    end

    CCUserDefault:sharedUserDefault():flush()
    GameController:call("ResetGame")
end

--离开巨龙战场
function DragonWorldCupManager.leaveDragonBattle(infoTable)
	if infoTable == nil then return end
	if infoTable.serverInfo == nil then return end

	CCSafeNotificationCenter:postNotification("removeAllHint")

	SceneController:call("clearShowBG")

 	local instance = WorldMapView:call("instance")
 	if instance then
 		instance:call("removeCover")
 	end

 	--原生界面打开或进程进入onpause后，就不做操作
   local scene = CCDirector:sharedDirector():getRunningScene()
    if cc.Texture2D:getIsOnPause() == false then
    	local winSize = CCDirector:sharedDirector():getIFWinSize()
        local texture = cc.RenderTexture:create(winSize.width, winSize.height)
        texture:beginWithClear(0, 0, 0, 1.0)
        scene:visit()
        texture:endToLua()
        SceneController:call("setShowBG", texture)
   	end


 	local serverInfo = infoTable.serverInfo
 	local ip = serverInfo.ip
 	local zone = serverInfo.zone
 	local port = tonumber(serverInfo.port) or 8088
 	local gameUid = infoTable.uid

 	CCUserDefault:sharedUserDefault():setStringForKey("account_ip", ip)
 	CCUserDefault:sharedUserDefault():setStringForKey("account_zone", zone)
 	CCUserDefault:sharedUserDefault():setIntegerForKey("account_port", port)
 	CCUserDefault:sharedUserDefault():setStringForKey("game_uid", gameUid)

 	if (CCCommonUtilsForLua:call("getIsUseDES")) then
        DESUserDefault:call("setValueForKey", "game_uid", gameUid)
    end

    CCUserDefault:sharedUserDefault():flush()
    GameController:call("ResetGame")
end

--必须修复伤兵才能进
function DragonWorldCupManager.healSoldier( )
	local buildId = FunBuildController:call("getMaxLvBuildByType", FUN_BUILD_HOSPITAL)
	if buildId <= 0 then return end

	if QueueController:call("getQueueNumByType", TYPE_HOSPITAL) > 0 then
		local buildType = math.floor(buildId / 1000)
		local qid = 0
		local qType = CCCommonUtilsForLua:call("getQueueTypeByBuildType", buildType)
		if qType ~= -1 then
			qid = QueueController:call("getMinTimeQidByType", qType)
		end

		local qInfos = GlobalData:call("shared"):getProperty("allQueuesInfo")
		local qInfo = qInfos[qid]
		if qInfo then
			local lastTime = qInfo:getProperty("finishTime") - qInfo:getProperty("startTime")
			local costGold = CCCommonUtilsForLua:call("getGoldByTime", lastTime)

			if PopupViewController:call("getCanPopPushView") then
				local function callback() DragonWorldCupManager.onCostGoldBack(qid, costGold) end
				local callfunc = cc.CallFunc:create(callback)
				YesNoDialog:call("showTime", getLang("140147"), callfunc, lastTime, getLang("104903"), false)
			else
				if costGold > 0 then
					local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
					local gold = playerInfo:getProperty("gold")
					if gold < costGold then
						YesNoDialog:call("gotoPayTips")
						return
					end
				end
				
				QueueController:call("startCCDQueue", qid, "", false, costGold "", 1)
			end

			return
		end
	else
		local buildInfo = FunBuildController:call("getFunbuildById", buildId)
		PopupViewController:call("removeAllPopupView")

		local dict = CCDictionary:create()
		dict:setObject(buildInfo, "buildInfo")
		dict:setObject(CCString:create("BuildingHospitalPopUpView"), "name")
		LuaController:call("openPopViewInLua", dict) 
	end	
end

function DragonWorldCupManager.onCostGoldBack(qid, costGold)
	if costGold > 0 then
		local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
		local gold = playerInfo:getProperty("gold")
		if gold < costGold then
			YesNoDialog:call("gotoPayTips")
			return
		end
	end

	QueueController:call("startCCDQueue", qid, "", false, costGold, "", 1)
end

function DragonWorldCupManager.getWorldCupData()
	--test
	--worldCupInfo = {}
	return worldCupInfo or {}
end

--是否是区域小组赛
function DragonWorldCupManager.isGroupBattle()
	return worldCupInfo.mainStage == DRAGON_WORLDCUP_GROUP_STAGE or false
end

--是否是淘汰赛
function DragonWorldCupManager.isKnockBattle()
	return worldCupInfo.mainStage == DRAGON_WORLDCUP_KNOCK_STAGE or false
end

--是否是决赛
function DragonWorldCupManager.isPlayOff()
	return worldCupInfo.mainStage == DRAGON_WORLDCUP_PLAYOFF_STAGE or false
end

function DragonWorldCupManager.getNormalObItemId()
	return group_ob_item
end

function DragonWorldCupManager.getPlayOffObItemId()
	return playoff_ob_item
end

function DragonWorldCupManager.getCountryIcon(country)
	country = CCCommonUtilsForLua:call("getCountryIconByName", country)
	local miniTag = "TAG_" .. country
	if not CCLoadSprite:call("getSF", miniTag) then
		miniTag = "TAG_UN.png"
	end
	return miniTag
end

function DragonWorldCupManager.getManagerData()
	return managerInfo or {}
end

function DragonWorldCupManager.getMatchData()
	return matchInfo or {}
end

function DragonWorldCupManager.getBattleRoomInfo()
	return battleRoomInfo or {}
end

function DragonWorldCupManager.getRankData()
	return worldCupRankInfo or {}
end

function DragonWorldCupManager.getChampionDetailData()
	return worldCupChampionEngageInfo or {}
end

function DragonWorldCupManager.getKpMatchData()
	return worldCupKpMatchInfo or {}
end

function DragonWorldCupManager.getGroupRewardData()
	return worldCupGroupRewardInfo or {}
end

function DragonWorldCupManager.getChampionRewardData()
	return worldCupChampionRewardInfo or {}
end

function DragonWorldCupManager.getPlayOffRewardData()
	return worldCupPlayOffRewardInfo or {}
end
----------------SHP END----------------



----------------XXR START----------------


----------------XXR END----------------

function DragonWorldCupManager.purge()
	wag_areaInfo = nil
	worldCupInfo = nil
	managerInfo = nil	
	matchInfo = nil
	worldCupRankInfo = nil
	worldCupChampionEngageInfo = nil
	worldCupKpMatchInfo = nil
	worldCupGroupRewardInfo = nil
	worldCupChampionRewardInfo = nil
	dragonMarchOpenFlag = nil
end

return DragonWorldCupManager
