----------------------------
-- Author: Elex
-- Date: 2017-06-29 16:54:50
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local DragonWorldCupAgainstView_ui = class("DragonWorldCupAgainstView_ui")

--#ui propertys


--#function
function DragonWorldCupAgainstView_ui:create(owner, viewType)
	local ret = DragonWorldCupAgainstView_ui.new()
	CustomUtility:DoRes(513, true)
	CustomUtility:DoRes(515, true)
	CustomUtility:DoRes(7, true)
	CustomUtility:LoadUi("DragonWorldCupAgainstView.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function DragonWorldCupAgainstView_ui:initLang()
end

function DragonWorldCupAgainstView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function DragonWorldCupAgainstView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function DragonWorldCupAgainstView_ui:onPrizeClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onPrizeClick", pSender, event)
end

function DragonWorldCupAgainstView_ui:onShare1ButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onShare1ButtonClick", pSender, event)
end

function DragonWorldCupAgainstView_ui:onShare2ButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onShare2ButtonClick", pSender, event)
end

function DragonWorldCupAgainstView_ui:onShare3ButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onShare3ButtonClick", pSender, event)
end

function DragonWorldCupAgainstView_ui:onShare4ButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onShare4ButtonClick", pSender, event)
end

function DragonWorldCupAgainstView_ui:onShare5ButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onShare5ButtonClick", pSender, event)
end

function DragonWorldCupAgainstView_ui:onShare6ButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onShare6ButtonClick", pSender, event)
end

function DragonWorldCupAgainstView_ui:onShare7ButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onShare7ButtonClick", pSender, event)
end

function DragonWorldCupAgainstView_ui:onManageClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onManageClick", pSender, event)
end

function DragonWorldCupAgainstView_ui:onSelectTimeClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onSelectTimeClick", pSender, event)
end

function DragonWorldCupAgainstView_ui:onAgainstClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onAgainstClick", pSender, event)
end

function DragonWorldCupAgainstView_ui:onFightClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onFightClick", pSender, event)
end

return DragonWorldCupAgainstView_ui

