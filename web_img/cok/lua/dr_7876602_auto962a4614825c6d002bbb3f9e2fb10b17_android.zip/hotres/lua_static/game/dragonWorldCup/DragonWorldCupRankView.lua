local DragonWorldCupRankView = class("DragonWorldCupRankView",
	function()
		return PopupBaseView:create()
	end
)
DragonWorldCupRankView.__index = DragonWorldCupRankView

local DragonWorldCupRankAreaCell = class("DragonWorldCupRankAreaCell",
	function()
		return cc.Layer:create()
	end
)
DragonWorldCupRankAreaCell.__index = DragonWorldCupRankAreaCell 

local DragonWorldCupRankCell = class("DragonWorldCupRankCell",
	function()
		return cc.Layer:create()
	end
)
DragonWorldCupRankCell.__index = DragonWorldCupRankCell 

local dragonWorldCupManager = require("game.dragonWorldCup.DragonWorldCupManager")

function DragonWorldCupRankView:create()
	local view = DragonWorldCupRankView.new()
	Drequire("game.dragonWorldCup.DragonWorldCupRankView_ui"):create(view, 0)
	if view:initView() then
		return view
	end
end

function DragonWorldCupRankView:initView()
	if self:init(true, 0) then

		self:setIsHDPanel(true)
		self.ipadLike = CCCommonUtilsForLua:isIosAndroidPad()
		if self.ipadLike then
			self.ui.m_topNode:setScale(2.4)
			self.ui.m_bottomNode:setScale(2.4)
		end

		CCLoadSprite:call("doResourceByCommonIndex", 205, true)
		CCLoadSprite:call("doResourceByCommonIndex", 208, true)

		local tbg = CCLoadSprite:call("createSprite", "technology_09.png")
		local tbgHeight = tbg:getContentSize().height
		local tBatchNode = CCSpriteBatchNode:createWithTexture(tbg:getTexture())
		local winSize = cc.Director:sharedDirector():getIFWinSize()
		local maxHight = winSize.height
		local curHight = -500

		while curHight < maxHight do
			local bg = CCLoadSprite:call("createSprite", "technology_09.png")
			bg:setAnchorPoint(ccp(0, 1))
			bg:setPosition(ccp(0, curHight))
			curHight = curHight + tbgHeight
			--tBatchNode:addChild(bg)
		end

		if self.ipadLike then
			tBatchNode:setScaleX(1536 / 640)
			tBatchNode:setScaleY(2048 / 852)
		end

		self:addChild(tBatchNode, - 10)
		self:changeBGHeight(self.ui.m_viewBg)
		self.ui.m_viewBg:setVisible(false)

		local addHeight = self:call("getExtendHeight")
		local listSize = self.ui.m_listNode:getContentSize()

		local worldcupInfo = dragonWorldCupManager.getWorldCupData()
		if worldcupInfo.applyState then
			self.ui.m_listNode:setContentSize(cc.size(listSize.width, listSize.height + addHeight))
			self.ui.m_listNode:setPositionY(self.ui.m_listNode:getPositionY())
		else
			self.ui.m_listNode:setContentSize(cc.size(listSize.width, listSize.height + addHeight + self.ui.m_listNode:getPositionY()))
			self.ui.m_listNode:setPositionY(0)
			self.ui.m_rankNode:setVisible(false)
		end

		self.ui.m_myGradeLabel:setString(getLang("5200115", ""))
		self.ui.m_myRankLabel:setString(getLang("140071", ""))

		CCCommonUtilsForLua:setButtonTitle(self.ui.m_rewardBtn, getLang("138003"))

		-- self.m_tableView = cc.TableView:create(self.ui.m_listNode:getContentSize())
		-- self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
		-- self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
		-- self.m_tableView:setAnchorPoint(ccp(0, 0))
		-- self.m_tableView:setDelegate()
		-- self.m_tableView:registerScriptHandler(function(tab) return self:scrollViewDidScroll(tab) end, cc.SCROLLVIEW_SCRIPT_SCROLL)
		-- self.m_tableView:registerScriptHandler(function(tab, idx) return self:cellSizeForTable(tab, idx) end, cc.TABLECELL_SIZE_FOR_INDEX)
		-- self.m_tableView:registerScriptHandler(function(tab, idx) return self:tableCellAtIndex(tab, idx) end, cc.TABLECELL_SIZE_AT_INDEX)
		-- self.m_tableView:registerScriptHandler(function(tab) return self:numberOfCellsInTableView(tab) end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
		-- self.ui.m_listNode:addChild(self.m_tableView)
		--self.m_tableView:reloadData()

		self:addLoadingAni()
		self.areaCells = {}
		local getRankListCmd = require("game.command.DragonWorldCupGetRankListCmd").create()
		getRankListCmd:send()
		--self:refreshView()

		return true
	end
end

function DragonWorldCupRankView:addLoadingAni()
	self:removeLoadingAni()

	self.m_loadingIcon = CCLoadSprite:call("createSprite", "loading_1.png")
	self.m_loadingIcon:setAnchorPoint(ccp(0.5, 0.5))

	local cSize = self.ui.m_listNode:getContentSize()
	self.m_loadingIcon:setPosition(ccp(cSize.width / 2, cSize.height / 2))

	local rotateAction = cc.RotateTo:create(0.5, 720)
	local rotateForever = cc.RepeatForever:create(rotateAction)
	self.m_loadingIcon:runAction(rotateForever)
	self.ui.m_listNode:addChild(self.m_loadingIcon, 1000000)
end

function DragonWorldCupRankView:removeLoadingAni()
	if (self.m_loadingIcon) then
		self.ui.m_listNode:removeChild(self.m_loadingIcon)
		self.m_loadingIcon = nil
	end
end

function DragonWorldCupRankView:getTestData()
	
end

function DragonWorldCupRankView:refreshView()
	self:removeLoadingAni()
	self.worldCupRankInfo = dragonWorldCupManager.getRankData()
    --dump(self.worldCupRankInfo, "DragonWorldCupRankView:refreshView")
	if sizen(self.worldCupRankInfo) == 0 then return end 

	local areaRanks = self.worldCupRankInfo.rank
	self.rank = self.worldCupRankInfo.selfRank

	self.areaRanks = {}
	for k, v in pairs(areaRanks) do
		v.id = k
		self.areaRanks[#self.areaRanks + 1] = v
	end

	local function sort(zone1, zone2)
		local order1 = dragonWorldCupManager.getZoneOrder(zone1.id)
		local order2 = dragonWorldCupManager.getZoneOrder(zone2.id)
		return tonumber(order1) < tonumber(order2)
	end

	table.sort(self.areaRanks, sort)

	local worldcupInfo = dragonWorldCupManager.getWorldCupData()
	local zone = worldcupInfo.zone
	local zoneName = dragonWorldCupManager.getZoneName(zone)
	self.ui.m_myGradeNumLabel:setString(getLang(zoneName))

	if self.rank == 0 then
		self.ui.m_myRankNumLabel:setString("10000+")
	else
		self.ui.m_myRankNumLabel:setString(tostring(self.rank))
	end

	self.ui.m_listNode:removeAllChildren()

	local listSize = self.ui.m_listNode:getContentSize()
	if sizen(self.areaRanks) == 0 then
		local label = cc.Label:create()
		label:setAnchorPoint(ccp(0.5, 0.5))
   		label:setColor(cc.c3b(255, 217, 157))
   		label:setDimensions(400, 0)
   		label:setSystemFontSize(27)
   		label:setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
   		label:setString(getLang("170042"))
   		label:setPosition(listSize.width / 2, listSize.height / 2)
   		self.ui.m_listNode:addChild(label)
   		return
	end

	self.scrollView = CCScrollView:create(listSize)
	self.scrollView:setDirection(kCCScrollViewDirectionVertical)
	self.ui.m_listNode:addChild(self.scrollView)

	local pos  = 1
    local index = 0
	for k, v in ipairs4ScatteredT(self.areaRanks) do
        index = index + 1
        local zoneId = v.id
        if zoneId == zone then pos = index end
		local areaCell = DragonWorldCupRankAreaCell:create(v, index, zoneId, self.ui.m_listNode)
		self.areaCells[#self.areaCells + 1] = areaCell
		self.scrollView:addChild(areaCell)
	end

	self:updatePosition(pos)
--	self.ui.m_belowNode:setVisible(false)
end

function DragonWorldCupRankView:cellClick(pStr)
	local strObj = tolua.cast(pStr, "CCString")
	if strObj then
		local _type = strObj:intValue()
		self:updatePosition(_type)
	end
end

function DragonWorldCupRankView:updatePosition(_type)
	local total = 0
	local num = sizen(self.areaRanks)
	local subOpenFlag = false

	local offPos = self.scrollView:getContentOffset()
	for index = 1, num do
		local areaCell = self.areaCells[index]
		if (_type == index and not areaCell.isOpen) then
			subOpenFlag = areaCell:showMembers(index)
		else 
			areaCell:reset()
		end

		total = total + areaCell:getCellHeight()
	end

	self.totalH = total

	MyPrint("totalH", self.totalH)

	total = total - 94

	for index = 1, num do
		local areaCell = self.areaCells[index]
		areaCell:setPositionY(total)
		total = total - areaCell:getCellHeight()
		MyPrint("total", total)
	end

	MyPrint("scrollView", not subOpenFlag)
	self.scrollView:setTouchEnabled(false)
	self.scrollView:setTouchEnabled(not subOpenFlag)

	local listSize = self.ui.m_listNode:getContentSize()
	local offy = listSize.height - self.totalH + (_type - 1) * 94
	local maxy = self.scrollView:maxContainerOffset().y
	offy = offy > maxy and maxy or offy
	self.scrollView:setContentOffset(ccp(0, offy))
	self.scrollView:setContentSize(cc.size(listSize.width, self.totalH))
end

function DragonWorldCupRankView:onEnter()
	self:setTitleName(getLang("140034"))

	local function callback1() self:refreshView() end
	local function callback2(pStr) self:cellClick(pStr) end
	local handler1 = self:registerHandler(callback1)
	local handler2 = self:registerHandler(callback2)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "dragon.worldcup.rank.info")
	CCSafeNotificationCenter:registerScriptObserver(self, handler2, "dragon.worldcup.rank.click")
end

function DragonWorldCupRankView:onExit()
	CCSafeNotificationCenter:unregisterScriptObserver(self, "dragon.worldcup.rank.info")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "dragon.worldcup.rank.click")
end

function DragonWorldCupRankView:onRewardClick()
	local lua_path = "game.dragonWorldCup.DragonWorldCupGroupPrizeView"
	package.loaded[lua_path] = nil
	local rewardView = require(lua_path):create()
	PopupViewController:addPopupInView(rewardView)
end

function DragonWorldCupRankAreaCell:create(rankInfos, index, zoneId, clickArea)
	local view = DragonWorldCupRankAreaCell.new()
	Drequire("game.dragonWorldCup.DragonWorldCupRankAreaCell_ui"):create(view, 1)
	if view:initView(rankInfos, index, zoneId, clickArea) then
		return view
	end 
end

function DragonWorldCupRankAreaCell:initView(rankInfos, index, zoneId, clickArea)
	self.rankInfos = rankInfos
	self.index = index
	self.clickArea = clickArea

	--self.ui.m_iconSprite:setSpriteFrame()
	local zoneName = dragonWorldCupManager.getZoneName(zoneId)
	self.ui.m_titleTxt:setString(getLang(zoneName))


	self.container = cc.Node:create()
	self:addChild(self.container)

	self.isOpen = false

	local winSize = cc.Director:sharedDirector():getIFWinSize()
	local tableHeight = winSize.height - 260

	local isIpad = CCCommonUtilsForLua:isIosAndroidPad()
	local w = isIpad and winSize.height or 640

	self.contentNode = cc.Node:create()
	self.contentNode:setContentSize(cc.size(w, tableHeight))
	self.contentNode:setAnchorPoint(ccp(0, 0))
	self.container:addChild(self.contentNode)
	self.contentNode:setPositionY(-tableHeight)

	self.m_tableView = cc.TableView:create(self.contentNode:getContentSize())
	self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
	self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
	self.m_tableView:setAnchorPoint(ccp(0, 0))
	self.m_tableView:setDelegate()
	self.m_tableView:registerScriptHandler(function(tab) return self:scrollViewDidScroll(tab) end, cc.SCROLLVIEW_SCRIPT_SCROLL)
	self.m_tableView:registerScriptHandler(function(tab, idx) return self:cellSizeForTable(tab, idx) end, cc.TABLECELL_SIZE_FOR_INDEX)
	self.m_tableView:registerScriptHandler(function(tab, idx) return self:tableCellAtIndex(tab, idx) end, cc.TABLECELL_SIZE_AT_INDEX)
	self.m_tableView:registerScriptHandler(function(tab) return self:numberOfCellsInTableView(tab) end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
	self.contentNode:addChild(self.m_tableView)
	self.m_tableView:setTouchEnabled(false)

  	local touchLayer = cc.Layer:create()
    self:addChild(touchLayer, -1)
    local function touchHandle( eventType, x, y )
        if eventType == "began" then
            return self:onTouchBegan(x, y)
        elseif eventType == "moved" then
        else
            self:onTouchEnded(x, y)
        end
    end
    touchLayer:registerScriptTouchHandler(touchHandle)
    touchLayer:setTouchEnabled(true)
    touchLayer:setSwallowsTouches(false) 

	return true
end

function DragonWorldCupRankAreaCell:onTouchBegan(x, y)
	if not isTouchInside(self.clickArea, x, y) then return false end
	if not isTouchInside(self.ui.m_bg, x, y) then return false end

	self.startPoint = ccp(x, y)

	return true
end

function DragonWorldCupRankAreaCell:onTouchEnded(x, y)
	if not isTouchInside(self.clickArea, x, y) then return end
	if not isTouchInside(self.ui.m_bg, x, y) then return end
	if ccpDistance(self.startPoint, ccp(x, y)) > 20 then return end

	CCSafeNotificationCenter:postNotification("dragon.worldcup.rank.click", CCString:create(tostring(self.index)))
end

function DragonWorldCupRankAreaCell:showMembers()
	self.isOpen = true
	self.ui.m_arrow:setRotation(90)
	self.m_tableView:reloadData()
	self.m_tableView:setTouchEnabled(true)
	self.m_tableView:setVisible(true)

	return true
end

function DragonWorldCupRankAreaCell:getCellHeight()
	return self.isOpen and 666666 or 94
end

function DragonWorldCupRankAreaCell:reset()
	self.isOpen = false
	self.ui.m_arrow:setRotation(0)
	self.m_tableView:reloadData()
	self.m_tableView:setTouchEnabled(false)
	self.m_tableView:setVisible(false)
end

function DragonWorldCupRankAreaCell:scrollViewDidScroll(tab)
	local mindy = self.m_tableView:minContainerOffset().y
	local dy = self.m_tableView:getContentOffset().y
	if dy < mindy then
		self.m_tableView:setContentOffset(ccp(0, mindy))
	end
end

function DragonWorldCupRankAreaCell:cellSizeForTable(tab, idx)
	return 640.0, 180
end

function DragonWorldCupRankAreaCell:tableCellAtIndex(tab, idx)
	local node = DragonWorldCupRankCell:create(self.rankInfos[idx + 1])
	node:setTag(666)
	
	local cell = cc.TableViewCell:create()
	cell:addChild(node)
	return cell
end

function DragonWorldCupRankAreaCell:numberOfCellsInTableView(tab)
	if self.isOpen == false then 
		return 0 
	else
		return type(self.rankInfos) == "table" and #self.rankInfos or 0
	end
end


--------------------DragonWorldCupRankCell---------------------------
function DragonWorldCupRankCell:create(rankInfo)
	local view = DragonWorldCupRankCell.new()
	Drequire("game.dragonWorldCup.DragonWorldCupRankCell_ui"):create(view, 1)
	if view:initView(rankInfo) then
		return view
	end 
end

function DragonWorldCupRankCell:initView(rankInfo)
	self.rankInfo = rankInfo
	local abbr = self.rankInfo.abbr
	local name = self.rankInfo.name
	local kingName = self.rankInfo.kingdomName
	local icon = (self.rankInfo.icon == "") and "Allance_flay" or self.rankInfo.icon
	--local icon = "Allance_flay.png"
	local rank = self.rankInfo.rank or 1
	local points = self.rankInfo.points
	local kingdom = self.rankInfo.kingdom
	local kingdomName = self.rankInfo.kingdomName
	local winRate = self.rankInfo.winRate
	local country = self.rankInfo.country
	local newPoint = self.rankInfo.pointsd

	local allianceStr = name .. "(" .. abbr .. ")" 
	local kingdomStr = kingdomName
	local winStr = winRate .. "%"

	self.ui.m_allianceNameTxt:setString(name)
	self.ui.m_kingdomTxt:setString(getLang("140031", kingdomStr))
	self.ui.m_rankTxt:setString(getLang("140023", CC_CMDITOA(rank)))
	self.ui.m_winTxt:setString(getLang("140033", winStr))
	self.ui.m_pointTxt:setString(string.format("%.3f", newPoint))
	self.ui.m_stateLabel:setString(getLang("108533"))

	self.ui.m_flagNode:removeAllChildren()
	self.ui.m_stateNode:removeAllChildren()

	local flag = AllianceFlagPar:call("create", icon .. ".png")
	flag = tolua.cast(flag, "cc.Node")
	flag:setScale(0.5)
	self.ui.m_flagNode:addChild(flag)

	if DynamicResourceController2:call("checkDynamicResource", "dragonGlobal") 
			and CCLoadSprite:call("loadDynamicResourceByName", "dragonGlobal") then
		local miniTag = dragonWorldCupManager.getCountryIcon(country)
		local countryFlag = CCLoadSprite:call("createSprite", miniTag)
		self.ui.m_stateNode:addChild(countryFlag)
		self.ui.m_stateNode:setScale(1.0)
	else
		local countryFlag = CCLoadSprite:call("createSprite", country .. ".png", CCLoadSpriteType.CCLoadSpriteType_COUNTRY_ICON)
		self.ui.m_stateNode:addChild(countryFlag)
	end

	return true
end



return DragonWorldCupRankView
