local DragonWorldCupView = class("DragonWorldCupView",
	function()
		return PopupBaseView:create()
	end
)
DragonWorldCupView.__index = DragonWorldCupView

local dragonWorldCupManager = require("game.dragonWorldCup.DragonWorldCupManager")

function DragonWorldCupView:create()
	local view = DragonWorldCupView.new()
	Drequire("game.dragonWorldCup.DragonWorldCupView_ui"):create(view, 0)
	if view:initView() then
		return view
	end
end

function DragonWorldCupView:initView()
	if self:init(true, 0) then
		self:setHDPanelFlag(true)

		if (CCLoadSprite:call("loadDynamicResourceByName", "manual")) then
			local newBg = CCLoadSprite:call("createSprite", "manual_dragon.png")
			local size = self.ui.m_dragonBg:getContentSize()
			local clipNode = CCClipNode:call("create", size.width, size.height)
			clipNode:setAnchorPoint(ccp(0, 0))
			clipNode:setPosition(0, 0)
			self.ui.m_dragonBg:addChild(clipNode)
			clipNode:addChild(newBg)
			newBg:setPosition(size.width / 2, size.height / 2 - 50)
		end

		if (DynamicResourceController2:call("checkDynamicResource", "dragonGlobal") and CCLoadSprite:call("loadDynamicResourceByName", "dragonGlobal")) then 
			local sf = CCLoadSprite:call("getSF", "dragonWorldCupDesktop.png")
			if sf then self.ui.m_fixbg:setSpriteFrame(sf) end
		end
		
		local serverType = GlobalData:call("shared"):getProperty("serverType")

		CCCommonUtilsForLua:setButtonTitle(self.ui.m_signUpBtn, getLang("5200020"))
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_selectTimeBtn, getLang("5200029"))
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_engageInfoBtn, getLang("140021"))

		if serverType == ServerType.SERVER_DRAGON_BATTLE_GLOBAL then
			CCCommonUtilsForLua:setButtonTitle(self.ui.m_enterBattleBtn, getLang("140061"))
		else
			CCCommonUtilsForLua:setButtonTitle(self.ui.m_enterBattleBtn, getLang("140013"))
		end
		
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_helpBtn, getLang("132483"))
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_historyBtn, getLang("140034"))
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_manageBtn, getLang("140043"))

		local addHeight = self:call("getExtendHeight")
		MyPrint("addHeight", addHeight)
		if CCCommonUtilsForLua:isIosAndroidPad() then
			self.ui.m_topNode:setScale(2.4)
			self.ui.m_topNode:setPositionY(self.ui.m_topNode:getPositionY() + 80)
			self.ui.m_titleNode:setPositionY(self.ui.m_titleNode:getPositionY() - 25)
			self.ui.m_bottomNode:setScale(2.4)
			self.ui.m_detailsNode:setPositionY(self.ui.m_detailsNode:getPositionY() + 80)
			self.ui.m_hdbg:setVisible(false)
			self.ui.m_selectInfoNode:setPositionY(self.ui.m_selectInfoNode:getPositionY() - 20)
			self.ui.m_infoNode:setPositionY(self.ui.m_infoNode:getPositionY() - 40)
			self.ui.m_zoneNode:setPositionY(self.ui.m_zoneNode:getPositionY() - 64)
		else
			--self.ui.m_detailsNode:setPositionY(self.ui.m_detailsNode:getPositionY() - 80)
		end
		self.ui.m_missLabel:setDimensions(470, 0)

		self:hideAllStageView()		
		--请求数据
		--dragonWorldCupManager.requestActivityData()
		--self:getDataBack()
		--加载动画
		--self:addLoadingAni()

		return true
	end

	return false
end

function DragonWorldCupView:getTestData()
	local now = LuaController:call("getTimeStamp")
	self.worldCupInfo = dragonWorldCupManager.getWorldCupData()
	self.worldCupInfo.mainStage = 2
	self.worldCupInfo.subStage = 2
	self.worldCupInfo.applyState = true
	self.worldCupInfo.chooseTimeState = false
	self.worldCupInfo.applyStartTime = now + 1800
	self.worldCupInfo.applyEndTime = now + 3600
	self.worldCupInfo.applyPower = 10000000
	self.worldCupInfo.matchStartTime = now + 3600
	self.worldCupInfo.managerTime = 60
	self.worldCupInfo.battleBeginTime = now + 20
	self.worldCupInfo.battleEndTime = now + 40
	self.worldCupInfo.miss = false
	self.worldCupInfo.showNoJoinTag = false
end

function DragonWorldCupView:addLoadingAni()
	self:removeLoadingAni()

	self.m_loadingIcon = CCLoadSprite:call("createSprite", "loading_1.png")
	self.m_loadingIcon:setAnchorPoint(ccp(0.5, 0.5))

	local cSize = self.ui.m_listNode:getContentSize()
	self.m_loadingIcon:setPosition(ccp(cSize.width / 2, cSize.height / 2))

	local rotateAction = cc.RotateTo:create(0.5, 720)
	local rotateForever = cc.RepeatForever:create(rotateAction)
	self.m_loadingIcon:runAction(rotateForever)
	self.ui.m_listNode:addChild(self.m_loadingIcon, 1000000)
	self.ui.m_listNode:setVisible(true)
end

function DragonWorldCupView:removeLoadingAni()
	if (self.m_loadingIcon) then
		self.ui.m_listNode:removeChild(self.m_loadingIcon)
		self.m_loadingIcon = nil
	end
end

function DragonWorldCupView:getDataBack()
	MyPrint("DragonWorldCupView:getDataBack")
	self.worldCupInfo = dragonWorldCupManager.getWorldCupData()
	self:refreshView()
end

function DragonWorldCupView:signupSuccess()
	self:removeLoadingAni()
	self.worldCupInfo = dragonWorldCupManager.getWorldCupData()
	self:refreshView()
end

function DragonWorldCupView:refreshView()
	self:unscheduleUpdate()
	self:scheduleUpdate()

	self:removeLoadingAni()
	MyPrint("self.worldCupInfo.mainStage", self.worldCupInfo.mainStage, self.worldCupInfo.subStage)

	--test
	-- self.worldCupInfo.mainStage = 1
	-- self.worldCupInfo.subStage = 1
	-- self.worldCupInfo.miss = false
	-- self.worldCupInfo.showNoJoinTag = false
	-- self.worldCupInfo.applyState = true
	-- self.worldCupInfo.chooseTimeState = true

	local remainRounds = tonumber(self.worldCupInfo.leftRounds)
	if remainRounds > 0 then
		self.ui.m_battleProgress:setString(getLang("5200114", tostring(remainRounds)))
	else
		self.ui.m_battleProgress:setString(getLang("5200116"))
	end

	local zone = self.worldCupInfo.zone
	local zoneName = dragonWorldCupManager.getZoneName(zone)
	self.ui.m_zoneLabel:setString(getLang(zoneName))

	if self.worldCupInfo.seasonOver then
		self:showSeasonOverView()
	elseif self.worldCupInfo.missZone then
		self:showMissZoneView()
	elseif self.worldCupInfo.showNoJoinTag then
		self:showNoSignUpStageView()	
	--轮空
	elseif self.worldCupInfo.miss then
		self:showMissStageView()
	elseif self.worldCupInfo.mainStage == DRAGON_WORLDCUP_SIGNUP_STAGE then
		self:showSignUpStageView()
	elseif self.worldCupInfo.mainStage == DRAGON_WORLDCUP_GROUP_STAGE then
		self:showGroupStageView()
	elseif self.worldCupInfo.mainStage == DRAGON_WORLDCUP_KNOCK_STAGE then
		--打开冠军赛界面
		self:showChampionStageView()
	elseif self.worldCupInfo.mainStage == DRAGON_WORLDCUP_PLAYOFF_STAGE then
		--打开决赛界面
		self:showPlayOffStageView()
	end

	self:onEnterFrame()
end

function DragonWorldCupView:onEnterFrame(dt)
	if self.worldCupInfo == nil then return end
	--轮空不刷新状态
	if self.worldCupInfo.miss == true then return end
	--赛季结束
	if self.worldCupInfo.seasonOver == true then return end
	--没报名
	if self.worldCupInfo.showNoJoinTag == true then return end

	local now = LuaController:call("getTimeStamp")
	if self.worldCupInfo.mainStage == DRAGON_WORLDCUP_SIGNUP_STAGE then
		local applyStartTime = self.worldCupInfo.applyStartTime
		local applyEndTime = self.worldCupInfo.applyEndTime
		if applyStartTime > now then
			local remainTime = applyStartTime - now
			self.ui.m_signUpTimeLabel2:setString(getLang("140162", format_time(remainTime)))
			self.ui.m_signUpBtn:setEnabled(false)
		elseif applyEndTime >= now then
			local remainTime = applyEndTime - now
			self.ui.m_signUpTimeNumLabel:setString(format_time(remainTime))
			self.ui.m_signUpTimeLabel:setString(getLang("5200018"))
			self.ui.m_signUpBtn:setEnabled(true)
		else
			self.ui.m_signUpBtn:setEnabled(false)
		end
		
	elseif self.worldCupInfo.mainStage == DRAGON_WORLDCUP_GROUP_STAGE then
		if self.worldCupInfo.restState then
			local remainTime = self.worldCupInfo.turnEndTime - now
			if remainTime > 0 then
				self.ui.m_missLabel:setString(getLang("5200139", format_time(remainTime)))
			else
				self.worldCupInfo.restState = false
				dragonWorldCupManager.requestActivityData()
			end
		elseif self.worldCupInfo.subStage == DRAGON_WORLDCUP_READY_SUBSTAGE then
			--local managerRemainTime = self.worldCupInfo.battleManagerEndTime - now
			local matchRemainTime = self.worldCupInfo.matchStartTime - now
			self.ui.m_matchTimeLabel:setString(format_time(matchRemainTime))
			--是否可以选择时间
			if matchRemainTime > 0 then
				self.ui.m_selectTimeBtn:setVisible(true)
			elseif matchRemainTime == 0 then
				dragonWorldCupManager.requestActivityData()
			else
				--self.ui.m_selectTimeBtn:setVisible(false)
				self.ui.m_matchTimeLabel:setString("")
			end
		elseif self.worldCupInfo.subStage == DRAGON_WORLDCUP_MATCH_SUBSTAGE or self.worldCupInfo.subStage == DRAGON_WORLDCUP_BATTLE_SUBSTAGE then
			local battleBeginTime = self.worldCupInfo.battleBeginTime
			local battleEndTime = self.worldCupInfo.battleEndTime
			if (battleBeginTime > 0  and now < battleBeginTime)then
				self.ui.m_signUpTimeLabel:setString(getLang("5200103"))
				self.ui.m_signUpTimeNumLabel:setString(format_time(battleBeginTime - now))
				self.ui.m_enterBattleBtn:setEnabled(false)
			elseif (battleEndTime > 0 and now < battleEndTime) then
				self.ui.m_signUpTimeLabel:setString(getLang("5200102"))
				self.ui.m_signUpTimeNumLabel:setString(format_time(battleEndTime - now))
				self.ui.m_enterBattleBtn:setEnabled(true)
			else
				self.worldCupInfo.restState = true
				self:showRestView()
				--self.ui.m_enterBattleBtn:setEnabled(true)
			end
		end
	end

	self.ui.m_manageBtn:setVisible(self.worldCupInfo.applyState)
end

--隐藏所有界面状态
function DragonWorldCupView:hideAllStageView()
	self.ui.m_signUpAndBattleNode:setVisible(false)
	self.ui.m_selectNode:setVisible(false)
	self.ui.m_listNode:setVisible(false)
	--self.ui.m_threeButton:setVisible(false)
end

--显示zone丢失界面
function DragonWorldCupView:showMissZoneView()
	self:hideAllStageView()
	self.ui.m_zoneBg:setVisible(false)
	self.ui.m_missNode:setVisible(true)
	self.ui.m_missLabel:setString(getLang("5200130"))
	self.ui.m_manageBtn:setVisible(false)
end

--报名界面状态
function DragonWorldCupView:showSignUpStageView()
	if self.worldCupInfo.applyState == DRAGON_WORLDCUP_NOT_SIGNUP then	
		self.ui.m_signUpAndBattleNode:setVisible(true)
		self.ui.m_signUpNode:setVisible(true)
		self.ui.m_selectNode:setVisible(false)
		self.ui.m_battleNode:setVisible(false)
	end

	--self.ui.m_textLabel:setString(getLang("5200016"))
	self.ui.m_eventLabel:setString(getLang("5200017"))
end

--轮空界面
function DragonWorldCupView:showMissStageView()
	self:hideAllStageView()
	self.ui.m_missNode:setVisible(true)
	self.ui.m_missLabel:setString(getLang("140137"))
end

--报名结束未报名界面
function DragonWorldCupView:showNoSignUpStageView()
	-- body
	self:hideAllStageView()
	self.ui.m_missNode:setVisible(true)
	self.ui.m_missLabel:setString(getLang("140138"))
	self.ui.m_manageBtn:setVisible(false)
end

--休息界面
function DragonWorldCupView:showRestView()
	self:hideAllStageView()
	self.ui.m_missNode:setVisible(true)
end

--赛季结束页面
function DragonWorldCupView:showSeasonOverView()
	self.ui.m_missNode:setVisible(true)
	self.ui.m_missLabel:setString(getLang("140225"))
	self.ui.m_manageBtn:setVisible(false)
	self.ui.m_battleProgress:setVisible(false)
end

--小组赛界面状态
function DragonWorldCupView:showGroupStageView()
	-- body
	if self.worldCupInfo.restState then
		self:showRestView()
	elseif self.worldCupInfo.subStage == DRAGON_WORLDCUP_READY_SUBSTAGE then
		self.ui.m_signUpAndBattleNode:setVisible(false)
		self.ui.m_selectNode:setVisible(true)
		if self.worldCupInfo.chooseTimeState == DRAGON_WORLDCUP_NOT_CHOOSE then
			self.ui.m_selectTimeNode:setVisible(true)
			self.ui.m_matchNode:setVisible(false)
		else
			self.ui.m_selectTimeNode:setVisible(false)
			self.ui.m_selectTimeBtn:retain()
			self.ui.m_selectTimeBtn:removeFromParent()
			self.ui.m_matchNode:setVisible(true)
			self.ui.m_matchNode:addChild(self.ui.m_selectTimeBtn)
			self.ui.m_selectTimeBtn:release()
		end
		self.ui.m_managerLabel:setString(getLang("5200104", tostring(self.worldCupInfo.managerTime)))
		self.ui.m_matchLabel:setString(getLang("5200028"))
	elseif self.worldCupInfo.subStage == DRAGON_WORLDCUP_MATCH_SUBSTAGE or self.worldCupInfo.subStage == DRAGON_WORLDCUP_BATTLE_SUBSTAGE then
		self.ui.m_signUpAndBattleNode:setVisible(true)
		self.ui.m_selectNode:setVisible(false)
		self.ui.m_battleNode:setVisible(true)
		self.ui.m_signUpNode:setVisible(false)

		self.ui.m_engageInfoBtn:setEnabled(true)
		self.ui.m_enterBattleBtn:setEnabled(true)

		--self.ui.m_textLabel:setString(getLang("5200016"))
		self.ui.m_eventLabel:setString(getLang("5200017"))

		self.ui.m_signUpTimeLabel:setString(getLang("5200102"))
	end
end

--冠军赛界面状态
function DragonWorldCupView:showChampionStageView()
	local function delay()
		-- body
		PopupViewController:call("removePopupView", self)

		local lua_path = "game.dragonWorldCup.DragonWorldCupAgainstView"
		package.loaded[lua_path] = nil
		local againistView = require(lua_path):create()
		PopupViewController:addPopupInView(againistView)
	end

	local node = cc.Node:create()
	self:addChild(node)
	performWithDelay(node, delay, 0.2)
end

--决赛界面状态
function DragonWorldCupView:showPlayOffStageView()
	local function delay()
		-- body
		PopupViewController:call("removePopupView", self)

		local lua_path = "game.dragonWorldCup.DragonWorldCupPlayOffView"
		package.loaded[lua_path] = nil
		local playOffView = require(lua_path):create()
		PopupViewController:addPopupInView(playOffView)
	end

	local node = cc.Node:create()
	self:addChild(node)
	performWithDelay(node, delay, 0.2)
end

function DragonWorldCupView:scheduleUpdate()
    local function updatefunc(dt) self:onEnterFrame(dt) end 
    self.entry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(updatefunc, 1.0, false)
end

function DragonWorldCupView:unscheduleUpdate()
    if self.entry then
        cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.entry)
        self.entry = nil
    end
end

function DragonWorldCupView:onEnter()
	UIComponent:call("showPopupView", 1)
	self.ui.m_titleTxt:setString(getLang("5200016"))
	self.ui.m_tileLabel:setString(getLang("5200025"))
	local function callback1() self:getDataBack() end
	local function callback2() self:signupSuccess() end
	local function callback3() self:refreshView() end
	local handler1 = self:registerHandler(callback1)
	local handler2 = self:registerHandler(callback2)
	local handler3 = self:registerHandler(callback3)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "dragon.worldcup.data.back")
	CCSafeNotificationCenter:registerScriptObserver(self, handler2, "dragon.worldcup.signup.back")
	CCSafeNotificationCenter:registerScriptObserver(self, handler3, "dragon.worldcup.signup.time.done")
end

function DragonWorldCupView:onExit()
	CCSafeNotificationCenter:unregisterScriptObserver(self, "dragon.worldcup.data.back")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "dragon.worldcup.signup.back")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "dragon.worldcup.signup.time.done")
	self:unscheduleUpdate()
end

--报名按钮
function DragonWorldCupView:onClickSignUpBtn()
	MyPrint("DragonWorldCupView:onClickSignUp")
	if self.worldCupInfo == nil then return end
	if self.worldCupInfo.mainStage ~= DRAGON_WORLDCUP_SIGNUP_STAGE then return end
	if self.worldCupInfo.applyState == DRAGON_WORLDCUP_SIGNUPED then return end

	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	if playerInfo:call("isInAlliance") then
		local allianceInfo = playerInfo:getProperty("allianceInfo")
		local rank = allianceInfo:getProperty("rank")
		if rank < 5 then
			YesNoDialog:show(getLang("E100119"))
			return
		end
	else
		YesNoDialog:show(getLang("E100119"))
		return
	end

	--todo
	--if self.worldCupInfo.canApply then 

	local function confirmCallback()
		--self:addLoadingAni()
		local signUpCommand = require("game.command.DragonWorldCupSignUpCmd").create()
		signUpCommand:send()
	end

	--确认报名dialog
	local dialog = YesNoDialog:show(getLang("5200019"), confirmCallback)
	dialog:call("setYesButtonTitle", getLang("5200020"))
	-- else
	-- 	--您的联盟不满足参与条件，需要联盟战力达到{0}
	-- 	CCCommonUtilsForLua:call("flyText", getLang("5200021", CC_CMDITOA(self.worldCupInfo.applyPower)))
	-- end
end

--选择时间按钮
function DragonWorldCupView:onClickSelectTime()
	MyPrint("DragonWorldCupView:onClickSelectTime")

	if self.worldCupInfo == nil then return end
	--if self.worldCupInfo.chooseTimeState == DRAGON_WORLDCUP_CHOOSED then return end

	local enabled = not (self.worldCupInfo.chooseTimeState == DRAGON_WORLDCUP_CHOOSED)
	--MyPrint("enabled", enabled, self.worldCupInfo.chooseTimeState)
	local lua_path = "game.dragonWorldCup.DragonWorldCupRoomListView"
	package.loaded[lua_path] = nil
	local roomListView = require(lua_path):create(nil, enabled)
	PopupViewController:addPopupInView(roomListView)
end

--对阵信息按钮
function DragonWorldCupView:onClickEngage()
	local lua_path = "game.dragonWorldCup.DragonWorldCupMatchInfoView"
	package.loaded[lua_path] = nil
	local engageView = require(lua_path):create()
	PopupViewController:addPopupView(engageView)
end

--进入战场
function DragonWorldCupView:onClickEnter()
	local serverType = GlobalData:call("shared"):getProperty("serverType")
	if serverType == ServerType.SERVER_DRAGON_BATTLE_GLOBAL then
		if dragonWorldCupManager.isInBattle() then
			local function callback() dragonWorldCupManager.leaveBattle() end
			YesNoDialog:show(getLang("140157"), callback)
		else
			dragonWorldCupManager.leaveBattle()
		end
		--GameController:call("showWaitInterface1", self.ui.m_enterBattleBtn)
	else
		local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
		if playerInfo:call("isInAlliance") then
			local selfAllianceId = playerInfo:call("getAllianceId") 
			dragonWorldCupManager.enterDragonBattle(selfAllianceId)
		end
	end
end

--其他对阵按钮
function DragonWorldCupView:onClickHelp()
	local obListView = Drequire("game.dragonWorldCup.DragonWorldCupObListView"):create()
	PopupViewController:addPopupInView(obListView)
end

--帮忙按钮
function DragonWorldCupView:onTipBtnClick()
	MyPrint("DragonWorldCupView:onTipBtnClick")
	FaqHelper:call("showSingleFAQ", "45265")
end


--当前排名按钮
function DragonWorldCupView:onWarRankClick()
	local lua_path = "game.dragonWorldCup.DragonWorldCupRankView"
	package.loaded[lua_path] = nil
	local rankView = require(lua_path):create()
	PopupViewController:addPopupInView(rankView)
end

--出战管理按钮
function DragonWorldCupView:onClickManager()
	local managerViewPath = "game.dragonWorldCup.DragonWorldCupManagerView"
	package.loaded[managerViewPath] = nil
	local canNot = dragonWorldCupManager.canNotModifyBattleList()
	local view = require(managerViewPath):create(canNot)
	PopupViewController:addPopupInView(view)
end

return DragonWorldCupView
