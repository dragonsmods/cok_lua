----------------------------
-- Author: Elex
-- Date: 2020-03-04 Wednesday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local DragonWorldCupBarrcksCell_ui = class("DragonWorldCupBarrcksCell_ui")

--#ui propertys


--#function
function DragonWorldCupBarrcksCell_ui:create(owner, viewType, paramTable)
	local ret = DragonWorldCupBarrcksCell_ui.new()
	CustomUtility:LoadUi("DragonWorldCupBarrcksCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function DragonWorldCupBarrcksCell_ui:initLang()
end

function DragonWorldCupBarrcksCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function DragonWorldCupBarrcksCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function DragonWorldCupBarrcksCell_ui:onSubClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onSubClick", pSender, event)
end

function DragonWorldCupBarrcksCell_ui:onAddClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onAddClick", pSender, event)
end

return DragonWorldCupBarrcksCell_ui

