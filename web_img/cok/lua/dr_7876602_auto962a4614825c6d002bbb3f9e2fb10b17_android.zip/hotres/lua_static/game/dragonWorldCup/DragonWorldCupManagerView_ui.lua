----------------------------
-- Author: Elex
-- Date: 2017-05-24 14:32:29
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local DragonWorldCupManagerView_ui = class("DragonWorldCupManagerView_ui")

--#ui propertys


--#function
function DragonWorldCupManagerView_ui:create(owner, viewType)
	local ret = DragonWorldCupManagerView_ui.new()
	CustomUtility:DoRes(506, true)
	CustomUtility:DoRes(7, true)
	CustomUtility:LoadUi("DragonWorldCupManagerView.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function DragonWorldCupManagerView_ui:initLang()
end

function DragonWorldCupManagerView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function DragonWorldCupManagerView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function DragonWorldCupManagerView_ui:onSignUpButtonClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onSignUpButtonClick", pSender, event)
end

return DragonWorldCupManagerView_ui

