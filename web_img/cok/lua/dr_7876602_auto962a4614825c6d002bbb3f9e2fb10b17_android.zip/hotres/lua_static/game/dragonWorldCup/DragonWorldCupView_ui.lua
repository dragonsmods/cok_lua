----------------------------
-- Author: Elex
-- Date: 2017-09-13 17:38:15
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local DragonWorldCupView_ui = class("DragonWorldCupView_ui")

--#ui propertys


--#function
function DragonWorldCupView_ui:create(owner, viewType)
	local ret = DragonWorldCupView_ui.new()
	CustomUtility:DoRes(500, true)
	CustomUtility:DoRes(506, true)
	CustomUtility:DoRes(512, true)
	CustomUtility:DoRes(7, true)
	CustomUtility:DoRes(8, true)
	CustomUtility:LoadUi("DragonWorldCupView.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function DragonWorldCupView_ui:initLang()
end

function DragonWorldCupView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function DragonWorldCupView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function DragonWorldCupView_ui:onClickEngage(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickEngage", pSender, event)
end

function DragonWorldCupView_ui:onClickEnter(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickEnter", pSender, event)
end

function DragonWorldCupView_ui:onClickSignUpBtn(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickSignUpBtn", pSender, event)
end

function DragonWorldCupView_ui:onClickSelectTime(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickSelectTime", pSender, event)
end

function DragonWorldCupView_ui:onTipBtnClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onTipBtnClick", pSender, event)
end

function DragonWorldCupView_ui:onClickHelp(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickHelp", pSender, event)
end

function DragonWorldCupView_ui:onWarRankClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onWarRankClick", pSender, event)
end

function DragonWorldCupView_ui:onClickManager(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickManager", pSender, event)
end

return DragonWorldCupView_ui

