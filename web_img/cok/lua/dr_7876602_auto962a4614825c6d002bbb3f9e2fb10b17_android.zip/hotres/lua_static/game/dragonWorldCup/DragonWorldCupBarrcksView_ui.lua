----------------------------
-- Author: Elex
-- Date: 2020-04-09 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local DragonWorldCupBarrcksView_ui = class("DragonWorldCupBarrcksView_ui")

--#ui propertys


--#function
function DragonWorldCupBarrcksView_ui:create(owner, viewType, paramTable)
	local ret = DragonWorldCupBarrcksView_ui.new()
	CustomUtility:DoRes(504, true)
	CustomUtility:LoadUi("DragonWorldCupBarrcksView.ccbi", ret, owner, true, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	if owner ~= nil and "function" == type(owner.initTableViewByOwner) then
		owner:initTableViewByOwner()
	else
		ret:initTableView()
	end
	return ret
end

function DragonWorldCupBarrcksView_ui:initLang()
	LabelSmoker:setText(self.m_titleTxt, "9201263")
	ButtonSmoker:setText(self.m_quickBtn, "105149")
	ButtonSmoker:setText(self.m_okBtn, "confirm")
end

function DragonWorldCupBarrcksView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function DragonWorldCupBarrcksView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function DragonWorldCupBarrcksView_ui:onClickTip(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickTip", pSender, event)
end

function DragonWorldCupBarrcksView_ui:onFormation5Click(pSender, event)
	ButtonSmoker:forwardFunction(self, "onFormation5Click", pSender, event)
end

function DragonWorldCupBarrcksView_ui:onFormation4Click(pSender, event)
	ButtonSmoker:forwardFunction(self, "onFormation4Click", pSender, event)
end

function DragonWorldCupBarrcksView_ui:onFormation3Click(pSender, event)
	ButtonSmoker:forwardFunction(self, "onFormation3Click", pSender, event)
end

function DragonWorldCupBarrcksView_ui:onFormation2Click(pSender, event)
	ButtonSmoker:forwardFunction(self, "onFormation2Click", pSender, event)
end

function DragonWorldCupBarrcksView_ui:onFormation1Click(pSender, event)
	ButtonSmoker:forwardFunction(self, "onFormation1Click", pSender, event)
end

function DragonWorldCupBarrcksView_ui:onControlButton78(pSender, event)
	ButtonSmoker:forwardFunction(self, "onControlButton78", pSender, event)
end

function DragonWorldCupBarrcksView_ui:onClickQuick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickQuick", pSender, event)
end

function DragonWorldCupBarrcksView_ui:onClickOk(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickOk", pSender, event)
end

function DragonWorldCupBarrcksView_ui:initTableView()
	TableViewSmoker:createView(self, "m_listView", "game.dragonWorldCup.DragonWorldCupBarrcksCell", 1, 4, "DragonWorldCupBarrcksCell")
end

function DragonWorldCupBarrcksView_ui:setTableViewDataSource(tvName, data)
	TableViewSmoker:refreshTableView(self, tvName, data)
end

return DragonWorldCupBarrcksView_ui

