----------------------------
-- Author: Elex
-- Date: 2017-07-05 11:54:41
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local DragonWorldCupHallOfFamePopupCell_ui = class("DragonWorldCupHallOfFamePopupCell_ui")

--#ui propertys


--#function
function DragonWorldCupHallOfFamePopupCell_ui:create(owner, viewType)
	local ret = DragonWorldCupHallOfFamePopupCell_ui.new()
	CustomUtility:LoadUi("DragonWorldCupHallOfFamePopupCell.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function DragonWorldCupHallOfFamePopupCell_ui:initLang()
end

function DragonWorldCupHallOfFamePopupCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function DragonWorldCupHallOfFamePopupCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return DragonWorldCupHallOfFamePopupCell_ui

