----------------------------
-- Author: Elex
-- Date: 2017-06-09 16:53:57
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local DragonWorldCupAllianceCell_ui = class("DragonWorldCupAllianceCell_ui")

--#ui propertys


--#function
function DragonWorldCupAllianceCell_ui:create(owner, viewType)
	local ret = DragonWorldCupAllianceCell_ui.new()
	CustomUtility:DoRes(513, true)
	CustomUtility:DoRes(515, true)
	CustomUtility:DoRes(516, true)
	CustomUtility:LoadUi("DragonWorldCupAllianceCell.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function DragonWorldCupAllianceCell_ui:initLang()
end

function DragonWorldCupAllianceCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function DragonWorldCupAllianceCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function DragonWorldCupAllianceCell_ui:onSelectTimeClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onSelectTimeClick", pSender, event)
end

function DragonWorldCupAllianceCell_ui:onFightClick(pSender, event)
	ButtonSmoker:forwardFunction(self, "onFightClick", pSender, event)
end

return DragonWorldCupAllianceCell_ui

