--------------------DragonWorldCupSelectZoneCell--------------------
local DragonWorldCupSelectZoneCell = class("DragonWorldCupSelectZoneCell", cc.Layer)

function DragonWorldCupSelectZoneCell:create(zoneInfo, applyZone, parView)
    local view = DragonWorldCupSelectZoneCell.new()
    Drequire("game.dragonWorldCup.DragonWorldCupSelectZoneCell_ui"):create(view, 1)
    if view:initView(zoneInfo, applyZone, parView) then
        return view
    end 
end

function DragonWorldCupSelectZoneCell:initView(zoneInfo, applyZone, parView)
    registerTouchHandler(self)
    self:setTouchEnabled(true)
    self:setSwallowsTouches(false)

    self.parView = parView
    self.listNode = parView.ui.m_infoList
    self.ui.m_signTxt:setString(getLang("140018"))
    self:setData(zoneInfo, applyZone)

    return true
end

function DragonWorldCupSelectZoneCell:setData(zoneInfo, applyZone)
    self.zoneInfo = zoneInfo
    self.zone = self.zoneInfo.id
    
    self.ui.m_text1:setString(getLang(zoneInfo.name))
    self.ui.m_text2:setString(getLang("9201267", zoneInfo.area_time))
    local icon = CCLoadSprite:call("createSprite", zoneInfo.icon .. ".png")
    self.ui.m_iconNode:removeAllChildren()
    self.ui.m_iconNode:addChild(icon)

    if atoi(self.zone) == atoi(applyZone) then
        self.ui.m_signNode:setVisible(true)
    else
        self.ui.m_signNode:setVisible(false)
    end
end

function DragonWorldCupSelectZoneCell:onTouchBegan(x, y)
    if not isTouchInside(self.listNode, x, y) then return false end

    self.touchPoint = ccp(x, y)
    if isTouchInside(self.ui.m_clickNode, x, y) then return true end

    return false
end

function DragonWorldCupSelectZoneCell:onTouchEnded(x, y)
    if (ccpDistance(self.touchPoint, ccp(x, y)) > 30) then return end

    self.parView:clickSelect(self.zone)
    self.parView:updateSureBtnState(true)
end

function DragonWorldCupSelectZoneCell:updateCellSelectState(selected)
    self.ui.m_selectNode:setVisible(selected)
end

function DragonWorldCupSelectZoneCell:showChoosed(choose)
    self.ui.m_signNode:setVisible(choose)
end

return DragonWorldCupSelectZoneCell
--------------------DragonWorldCupSelectZoneCell--------------------