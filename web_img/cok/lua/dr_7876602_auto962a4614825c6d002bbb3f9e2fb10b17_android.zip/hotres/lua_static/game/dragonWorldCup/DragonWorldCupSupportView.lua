local DragonWorldCupSupportView = class("DragonWorldCupSupportView",
	function()
		return PopupBaseView:create()
	end
)
DragonWorldCupSupportView.__index = DragonWorldCupSupportView

local DragonWorldCupShareRewardCell = class("DragonWorldCupShareRewardCell",
	function()
		return cc.Layer:create()
	end
)
DragonWorldCupShareRewardCell.__index = DragonWorldCupShareRewardCell

local dragonWorldCupManager = require("game.dragonWorldCup.DragonWorldCupManager")

function DragonWorldCupSupportView:create(allianceId)
	local view = DragonWorldCupSupportView.new()
	Drequire("game.dragonWorldCup.DragonWorldCupSupportView_ui"):create(view, 1)
	if view:initView(allianceId) then
		return view
	end
end

function DragonWorldCupSupportView:initView(allianceId)
	if self:init(true, 0) then
		
		self:setHDPanelFlag(true)

		if CCCommonUtilsForLua:isIosAndroidPad() then
			self.ui.nodeccb:setScale(2)
		end

		self.supportAllianceId = allianceId

		local listSize = self.ui.m_listNode:getContentSize()

		 local delegate = {}
	    delegate.gridAtIndex = function(tab, idx) return self:gridAtIndex(tab, idx) end
	    delegate.numberOfCellsInTableView = function(tab) return self:numberOfCellsInTableView(tab) end
	    delegate.numberOfGridsInCell = function(tab) return self:numberOfGridsInCell(tab) end
	    delegate.gridSizeForTable = function(tab, idx) return self:gridSizeForTable(tab, idx) end

	    self.m_tableView = require("game.utility.TableViewMultiCol").new(listSize)
	    self.m_tableView:setDelegate(delegate)
	   	self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
		self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
		self.ui.m_listNode:addChild(self.m_tableView)

		self.ui.m_titleLable:setString(getLang("5200124"))
		self.ui.m_detailLable:setString(getLang("5200036"))
		self.ui.m_supportLable:setString(getLang(""))

		self.m_waitInterFace = GameController:call("showWaitInterface1", self.ui.m_listNode)
		self.m_waitInterFace:setPosition(listSize.width / 2, listSize.height / 2)	

		CCCommonUtilsForLua:setButtonTitle(self.ui.m_supportBtn, getLang("5200124"))

		local getRewardCmd = require("game.command.DragonWorldCupGetSupportRewardCmd").create()
		getRewardCmd:send()

		local touchLayer = cc.Layer:create()
		self:addChild(touchLayer)

		local function touchHandle( eventType, x, y )
			-- print("touchHandle", eventType, x, y)
			if eventType == "began" then
				return self:onTouchBegan(x, y)
			elseif eventType == "moved" then
			
			else
				self:onTouchEnded(x, y)
			end
		end
		touchLayer:registerScriptTouchHandler(touchHandle)
		touchLayer:setTouchEnabled(true)
		touchLayer:setSwallowsTouches(false)

		return true
	end

	return false 
end

function DragonWorldCupSupportView:onTouchBegan(x, y)
	self.startPoint = ccp(x, y)
	return true
end

function DragonWorldCupSupportView:onTouchEnded(x, y)
	if ccpDistance(self.startPoint, ccp(x, y)) > 30 then return end

	if not isTouchInside(self.ui.m_clickArea, x, y) then
		PopupViewController:call("removePopupView", self)
	end
end

function DragonWorldCupSupportView:onEnter()
	local function callback1(param) self:refreshView(param) end
	local function callback2(param) self:supportSuccess() end
	local handler1 = self:registerHandler(callback1)
	local handler2 = self:registerHandler(callback2)
	CCSafeNotificationCenter:registerScriptObserver(self, handler1, "dragon.worldcup.support.reward")
	CCSafeNotificationCenter:registerScriptObserver(self, handler2, "dragon.worldcup.support.success")
end

function DragonWorldCupSupportView:onExit()
	CCSafeNotificationCenter:unregisterScriptObserver(self, "dragon.worldcup.support.reward")
	CCSafeNotificationCenter:unregisterScriptObserver(self, "dragon.worldcup.support.success")
end

function DragonWorldCupSupportView:refreshView(param)
	if self.m_waitInterFace then
		self.m_waitInterFace:call("remove")
		self.m_waitInterFace = nil
	end

	local dict = tolua.cast(param, "CCDictionary")
	if dict then
		local infoTable = dictToLuaTable(dict) 
		self.rewardInfos = infoTable.reward
		self.m_tableView:reloadData()
	end
end

function DragonWorldCupSupportView:supportSuccess()
	PopupViewController:call("removePopupView", self)
end

function DragonWorldCupSupportView:gridAtIndex(tab, idx)
	if (idx >= #self.rewardInfos) then return end
	local node = require("game.dragonWorldCup.DragonWorldCupShareRewardCell"):create(self.rewardInfos[idx + 1])
	node:setTag(666)
	
	local cell = cc.TableViewCell:create()
	cell:addChild(node)
	return cell
end

function DragonWorldCupSupportView:numberOfCellsInTableView(tab)
	local cellNum = #self.rewardInfos
	return math.floor(cellNum /4 + (cellNum % 4 == 0 and 0 or 1))
end

function DragonWorldCupSupportView:numberOfGridsInCell(tab)
	return 4
end

function DragonWorldCupSupportView:gridSizeForTable(tab)
	return 108.0, 110.0
end

function DragonWorldCupSupportView:onSupportBtnClick()
	local desc = getLang("5200129")
	local callback = function() self:confirm() end
	local func = cc.CallFunc:create(callback)
	YesNoDialog:call("show", desc, func)
end

function DragonWorldCupSupportView:confirm()
	local command = require("game.command.DragonWorldCupSupportCmd").create(self.supportAllianceId)
	command:send()
end

return DragonWorldCupSupportView