----------------------------
-- Author: Elex
-- Date: 2017-06-21 16:24:06
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local DragonWorldCupGroupPrizeView_ui = class("DragonWorldCupGroupPrizeView_ui")

--#ui propertys


--#function
function DragonWorldCupGroupPrizeView_ui:create(owner, viewType)
	local ret = DragonWorldCupGroupPrizeView_ui.new()
	CustomUtility:DoRes(512, true)
	CustomUtility:LoadUi("DragonWorldCupGroupPrizeView.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function DragonWorldCupGroupPrizeView_ui:initLang()
end

function DragonWorldCupGroupPrizeView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function DragonWorldCupGroupPrizeView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function DragonWorldCupGroupPrizeView_ui:onClickWin(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickWin", pSender, event)
end

function DragonWorldCupGroupPrizeView_ui:onClickLose(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickLose", pSender, event)
end

return DragonWorldCupGroupPrizeView_ui

