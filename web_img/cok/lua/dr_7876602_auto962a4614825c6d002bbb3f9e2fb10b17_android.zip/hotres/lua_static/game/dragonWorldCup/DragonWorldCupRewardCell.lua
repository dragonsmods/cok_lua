local DragonWorldCupRewardCell = class("DragonWorldCupRewardCell",
	function()
		return cc.Node:create()
	end
)
DragonWorldCupRewardCell.__index = DragonWorldCupRewardCell

function DragonWorldCupRewardCell:create(rewardInfo)
	local cell = DragonWorldCupRewardCell.new()
	Drequire("game.dragonWorldCup.DragonWorldCupRewardCell_ui"):create(cell, 1)
	if cell:initReward(rewardInfo) then
		return cell
	end
end

function DragonWorldCupRewardCell:initReward(rewardInfo)
	local ccbSize = self.ui.nodeccb:getContentSize()
	self:setContentSize(ccbSize)
	self:setLabelColor(213, 233, 247)

	local name = ""
	local icon  = ""

	local rewardType = tonumber(rewardInfo.type) or 0
    --MyPrint("rewardType", rewardType)
	local value = tonumber(rewardInfo.value) or 0
    local id = 0
	if rewardType == RewardTypeConfig.R_GOODS then
        local valueObj = rewardInfo.value
        id = tonumber(valueObj.id) or 0
		name = RewardController:call("getNameByType", rewardType, id)
		icon = RewardController:call("getPicByType", rewardType, id)
        value = tonumber(valueObj.num) or 0
	elseif rewardType == RewardTypeConfig.R_EFFECT then
		name = CCCommonUtilsForLua:call("getNameById", tostring(value))
		if name == "" then
			if value == 502600 then
				name = getLang("138074")
			elseif value == 502601 then
				name = getLang("138075")
			elseif value == 502602 then
				name = getLang("138076")
			end
		end

		icon = CCCommonUtilsForLua:call("getICon", tostring(value))
		value = 1
	else
		if rewardType == RewardTypeConfig.R_DRAGON_MODEL then
			name = getLang("140357")
		elseif rewardType == RewardTypeConfig.R_DRAGON_RING then
			name = getLang("140358")
		else 
			name = RewardController:call("getNameByType", rewardType, id)
		end

		icon = RewardController:call("getPicByType", rewardType, value)
	end

	self.ui.m_nameTxt:setString(name)

	local t = "X" .. CC_CMDITOA(value)
    if rewardType == RewardTypeConfig.R_EFFECT then t = "" end
	self.ui.m_numTxt:setString(t)
	self.ui.m_numTxt:setPositionX(self.ui.m_numTxt:getPositionX() + 60)

	local color = 2
	if rewardType == RewardTypeConfig.R_GOODS then
        local toolInfo = ToolController:call("getToolInfoByIdForLua", id)
        if toolInfo then
        	color = toolInfo:getProperty("color")
        end
    elseif (rewardType == RewardTypeConfig.R_EFFECT or rewardType == RewardTypeConfig.R_CRYSTAL or rewardType == RewardTypeConfig.R_WIN_POINT 
    			or rewardType == RewardTypeConfig.R_GOLD or rewardType == RewardTypeConfig.R_DRAGON_MODEL or rewardType == RewardTypeConfig.R_DRAGON_RING) then
    	color = 5
    end
    --MyPrint("DragonWorldCupRewardCell color", color)
    local colorBg = CCCommonUtilsForLua:call("getToolBgByColor", color)
    local iconBg = CCLoadSprite:call("createSprite", colorBg)
    CCCommonUtilsForLua:setSpriteMaxSize(iconBg, 60, true)
    self.ui.m_iconNode:addChild(iconBg, -100)

    local spr = CCLoadSprite:call("createSprite", icon)
    CCCommonUtilsForLua:setSpriteMaxSize(spr, 50)
    self.ui.m_iconNode:addChild(spr)

	return true
end

function DragonWorldCupRewardCell:setLabelColor(r, g, b)
	self.ui.m_nameTxt:setColor(cc.c3b(r, g, b))
	self.ui.m_numTxt:setColor(cc.c3b(r, g, b))
end

return DragonWorldCupRewardCell
