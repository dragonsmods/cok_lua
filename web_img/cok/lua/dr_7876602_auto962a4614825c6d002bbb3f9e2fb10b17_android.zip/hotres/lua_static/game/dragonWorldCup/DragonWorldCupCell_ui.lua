----------------------------
-- Author: Elex
-- Date: 2017-05-23 22:11:46
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local DragonWorldCupCell_ui = class("DragonWorldCupCell_ui")

--#ui propertys


--#function
function DragonWorldCupCell_ui:create(owner, viewType)
	local ret = DragonWorldCupCell_ui.new()
	CustomUtility:DoRes(306, true)
	CustomUtility:DoRes(504, true)
	CustomUtility:DoRes(512, true)
	CustomUtility:LoadUi("DragonWorldCupCell.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function DragonWorldCupCell_ui:initLang()
end

function DragonWorldCupCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function DragonWorldCupCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return DragonWorldCupCell_ui

