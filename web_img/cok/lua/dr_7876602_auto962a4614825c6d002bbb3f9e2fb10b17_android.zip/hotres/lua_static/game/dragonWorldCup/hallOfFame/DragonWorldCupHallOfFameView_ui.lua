----------------------------
-- Author: Elex
-- Date: 2017-07-13 14:08:04
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local DragonWorldCupHallOfFameView_ui = class("DragonWorldCupHallOfFameView_ui")

--#ui propertys


--#function
function DragonWorldCupHallOfFameView_ui:create(owner, viewType)
	local ret = DragonWorldCupHallOfFameView_ui.new()
	CustomUtility:DoRes(208, true)
	CustomUtility:DoRes(516, true)
	CustomUtility:DoRes(7, true)
	CustomUtility:DoRes(205, true)
	CustomUtility:LoadUi("DragonWorldCupHallOfFameView.ccbi", ret, owner, false, viewType)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function DragonWorldCupHallOfFameView_ui:initLang()
end

function DragonWorldCupHallOfFameView_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function DragonWorldCupHallOfFameView_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return DragonWorldCupHallOfFameView_ui

