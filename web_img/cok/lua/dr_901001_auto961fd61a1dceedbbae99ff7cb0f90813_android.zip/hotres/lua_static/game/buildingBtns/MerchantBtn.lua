--旅行商人
local MerchantBtn = class("MerchantBtn", Drequire("game.buildingBtns.SpeBuildingBtn"))

function MerchantBtn:create(param)
    local btn = MerchantBtn.new(param)
    btn:initBtn()    
    return btn
end

function MerchantBtn:initBtn()
    local buildType = self.param:valueForKey("buildType"):getCString()
    --阵法拍卖行
    if isFunOpenByKey("formation_train_auction") and FunOpenController:isShow("fun_trainAuction") then
        CCLoadSprite:call("loadDynamicResourceByName", "FormationTrainAuct_face")
        local callback = function()
            -- 6100015=跨服无法使用拍卖行
            self:hideSelf()
            if isCrossServerNow() then
                LuaController:flyHint("", "", getLang("6100015"))
                return
            end
            local view = Drequire('game.formationTrain.auction.FTAuctionView'):create();
            PopupViewController:addPopupInView(view);
            LogController:sendUserBehaviorEvent("building", 2, buildType, "trainAuction")
        end 
        self:addBtn("ftAuct_btnIcon.png", "9440888", callback)  --9440888=拍卖行
    end
    -- 
    --拍卖行
    if FunOpenController:isShow("fun_auction") and CCCommonUtilsForLua:isFunOpenByKey("auction") then
        local callback = function()
            self:hideSelf()
            open_AuctionHouseView()
			LogController:sendUserBehaviorEvent("building", 2, buildType, "auction")
        end 
        self:addBtn("AuctionHouse.png", "9440888", callback)  --9440888=拍卖行
    end
    
    --旅行商人
    local callback = function()
        self:hideSelf()
        
        if CCCommonUtilsForLua:isFunOpenByKey("hotstore_new") then
            open_NewMerchantView()
        else
            local MerchantView = Drequire("game.CommonPopup.Merchant.MerchantView")
            local view = MerchantView:create()
            PopupViewController:addPopupInView(view)
        end
		LogController:sendUserBehaviorEvent("building", 2, buildType, "hotstore")
    end 
    self:addBtn("icon_merchante_rukou.png", "133178", callback) --133178=旅行商人

    --装扮商城
    if FunOpenController:isShowAndDef("fun_avatarStore", FunBuildController:call("getMainCityLv") >= 5) then
        local callback = function()
            self:hideSelf()

            local shopV1Ins = require("game.LiBao.AvatarShop.AvatarShopV1Mgr").getInstance()
            if shopV1Ins:isOpen() then
                shopV1Ins:showMainView()
            else
                local AvatarViewEx = Drequire("game.avatar.AvatarViewEx")
                local view = AvatarViewEx.create()
                PopupViewController:call("addPopupInView", view)
            end
		    LogController:sendUserBehaviorEvent("building", 2, buildType, "avatar")
        end
        local fileName = CCLoadSprite:call("loadDynamicResourceByName", "AvatarShopV1_face") and "AvatarShopV1_09.png" or "cityskin_status.png"
        self:addBtn(fileName, "9900289", callback)--9900289=装扮商城
    end

    --银行
    if CCCommonUtilsForLua:isFunOpenByKey("bank") and FunBuildController:call("getInvestBankState") then
        local callback = function()
            self:hideSelf()
            
            local bank = Drequire("game.activity.bank.ActivityBankView"):create()
            PopupViewController:addPopupInView(bank)
		    LogController:sendUserBehaviorEvent("building", 2, buildType, "bank")
        end 
        self:addBtn("icon_investEntrance.png", "9400563", callback) --9400563=投资商会
    end

    --商城
    if CCCommonUtilsForLua:isFunOpenByKey("mall_integration") then
        local callback = function()
            self:hideSelf()
            
            openAllStoreView()
		    LogController:sendUserBehaviorEvent("building", 2, buildType, "store")
        end 
        self:addBtn("icon_investEntrance.png", "104900", callback)  --104900=商城
    end


    if CCCommonUtilsForLua:isFunOpenByKey("csmod_points_store") then
        if FunOpenController:isShow("fun_caravanStore") then
            local callback = function()
                self:hideSelf()
                
                local view = Drequire("game.activity.CsmodItemStore.CsmodItemStoreView"):create()
                PopupViewController:addPopupInView(view)
                LogController:sendUserBehaviorEvent("building", 2, buildType, "caravanStore")
            end 
            CCLoadSprite:call("doResourceByCommonIndex", 520, true)
            self:addBtn("icon_ScoreMall.png", "42803400", callback)--42803400=商旅商城
        end
    end

    if CCCommonUtilsForLua:isFunOpenByKey("csmod_premium_store") then
        if FunOpenController:isShow("fun_caravanStore") then
            local callback = function()
                self:hideSelf()
                
                local view = Drequire("game.CsmodShop.CsmodShopEnterView"):create()
                PopupViewController:addPopupInView(view)
                LogController:sendUserBehaviorEvent("building", 2, buildType, "caravanStore")
            end 
            CCLoadSprite:call("doResourceByCommonIndex", 520, true)
            self:addBtn("icon_ScoreMall.png", "42803400", callback)--42803400=商旅商城
        end
    end

    --适配按钮位置
    self:adapt()
end

function MerchantBtn:getGuideNodeByKey(key)
    if key == "commercial_camel" and self.guideIndex then
        return self:getBtn(self.guideIndex)
    end
end

return MerchantBtn