--@author: mm
--@date: 2016-12-13

--pre decl
-- local Drequire = Drequire
-- local Dprint = Dprint

-- local math = math
-- local string = string
-- local cc = cc
-- local _lang = _lang
-- local _lang_1 = _lang_1
-- local _lang_2 = _lang_2
-- local CCLoadSprite = CCLoadSprite
-- local isTouchInside = isTouchInside
-- local CCCommonUtilsForLua = CCCommonUtilsForLua
-- local CC_ITOA = CC_ITOA
-- local CC_SECTOA = CC_SECTOA
-- local CC_CMDITOAL = CC_CMDITOAL
-- local gc = GlobalData:call("shared")

local gal_cmd_path = "game.command.GetAllianceListCommand"
-- package.loaded[gal_cmd_path] = nil

--class
local AllianceRankListCell = class("AllianceRankListCell",
    function()
        return cc.Layer:create()
    end
)

--fields
AllianceRankListCell.m_numText = nil --CCSafeObject<CCLabelIF> 
AllianceRankListCell.m_text1 = nil --CCSafeObject<Label> 
AllianceRankListCell.m_text2 = nil --CCSafeObject<CCLabelIF> 
AllianceRankListCell.m_text3 = nil --CCSafeObject<CCLabelIF> 

AllianceRankListCell.m_sprBG1 = nil --CCSafeObject<CCScale9Sprite> 
AllianceRankListCell.m_sprBG2 = nil --CCSafeObject<CCScale9Sprite> 
AllianceRankListCell.m_sprBG3 = nil --CCSafeObject<CCScale9Sprite> 
AllianceRankListCell.m_numspr1 = nil --CCSafeObject<CCSprite> 
AllianceRankListCell.m_numspr2 = nil --CCSafeObject<CCSprite> 
AllianceRankListCell.m_numspr3 = nil --CCSafeObject<CCSprite> 
AllianceRankListCell.m_sprBG4 = nil --CCSafeObject<CCScale9Sprite> 
AllianceRankListCell.m_selfheadSpr = nil --CCSafeObject<CCSprite> 
AllianceRankListCell.m_otherheadSpr = nil --CCSafeObject<CCSprite> 
AllianceRankListCell.m_Starsprite = nil --CCSafeObject<CCSprite> 

AllianceRankListCell.m_headNode = nil --CCSafeObject<CCNode> 
AllianceRankListCell.m_rankNode = nil --CCSafeObject<CCNode>
AllianceRankListCell.m_hintBGNode = nil --CCSafeObject<CCNode> 
AllianceRankListCell.m_headImgNode = nil --CCSafeObject<HFHeadImgNode> 
AllianceRankListCell.m_info = nil --PlayerRankInfo* 
AllianceRankListCell.m_index = 0 --int 
AllianceRankListCell.m_startPoint = cc.p(0,0) --CCPoint 
AllianceRankListCell.m_type = 0 --int 
AllianceRankListCell.m_touchNode = nil --CCNode*
AllianceRankListCell.fixedSize = cc.size(100, 100)

--functions
function AllianceRankListCell:create(info, index, type, touchNode) -- AllianceRankInfo | PlayerRankInfo*,int,int,Node*
    local view = AllianceRankListCell.new()
    if view:initView(info, index, type, touchNode) == false then
        return nil
    end
    return view
end


function AllianceRankListCell:initView(info, index, type, touchNode)
    if info == nil or index == nil or type == nil or touchNode == nil then
        return false
    end

    self.m_info = info
    self.m_index = index
    self.m_type = type
    self.m_touchNode = touchNode

    local proxy = cc.CCBProxy:create()
    local ccbiURL = "AllianceRankCell_Lua.ccbi"
    local nodeccb = CCBReaderLoad(ccbiURL, proxy, self)
    if nodeccb == nil then
        Dprint("AllianceRankListCell loadccb error")
        return false
    else
        Dprint("AllianceRankListCell loadccb done")
    end

    self.ccbNode = nodeccb
    self:addChild(nodeccb)
    
    self:setData(info,index,self.m_type)

    self.m_headNode:setAnchorPoint(cc.p(0.5, 0.5))
    self.m_headNode:setContentSize(self.fixedSize)

    registerNodeEventHandler(self)
    registerTouchHandler(self)

    return true
end

function AllianceRankListCell:setData(info, index, type) -- void|AllianceRankInfo*,int,int
    self.m_info = info
    self.m_index = index
    self.m_type = type
    self.m_headNode:removeAllChildren()

    local info_uid = self.m_info:getProperty("uid") --string
    local info_alliancename = self.m_info:getProperty("alliancename") --str
    local info_abbr = self.m_info:getProperty("abbr") --str
    local info_armyKill = self.m_info:getProperty("armyKill") --ulong
    local info_leader = self.m_info:getProperty("leader") --str
    local info_icon = self.m_info:getProperty("icon") --str
    local info_fightpower = self.m_info:getProperty("fightpower") --ulong
    local info_score = self.m_info:getProperty("score") -- int

    local pic --Sprite*
    if (info_icon=="") then
        pic = CCLoadSprite:call("createSprite", "Allance_flay.png")
        pic:setScale(0.6)
        self.m_headNode:addChild(pic)
        pic:setPosition(self.fixedSize.width * 0.5, self.fixedSize.height * 0.5)
    else
        local mpic = info_icon .. ".png"
        local flag = AllianceFlagPar:call("create", mpic)
-- //        pic = CCLoadSprite:createSprite(mpic.c_str())
        local flagLayer = tolua.cast(flag, "cc.Layer")
        flagLayer:setScale(0.6)
        self.m_headNode:addChild(flagLayer)
        flagLayer:setPosition(self.fixedSize.width * 0.5, self.fixedSize.height * 0.5)
    end

-- //    CCCommonUtils:setSpriteMaxSize(pic, 60) 
-- //    string rankstr = "Alliance_R"
-- //    rankstr.append(CC_ITOA(self.m_info:rank))
-- //    rankstr.append(".png")
-- //    auto rankpic = CCLoadSprite:createSprite(rankstr.c_str())
-- //    m_rankNode:addChild(rankpic)
-- //    rankpic:setScale(0.5)
    self.m_sprBG1:setVisible(false)
    self.m_sprBG2:setVisible(false)
    self.m_sprBG3:setVisible(false)
    self.m_numText:setVisible(false)
    self.m_numspr1:setVisible(false)
    self.m_numspr2:setVisible(false)
    self.m_numspr3:setVisible(false)

    if(self.m_index==0) then
        self.m_sprBG1:setVisible(true)
        self.m_numspr1:setVisible(true)
    elseif(self.m_index==1) then
        self.m_sprBG2:setVisible(true)
        self.m_numspr2:setVisible(true)
    elseif(self.m_index==2) then
        self.m_sprBG3:setVisible(true)
        self.m_numspr3:setVisible(true)
    else
        self.m_numText:setVisible(true)
        self.m_numText:setString(CC_ITOA(self.m_index+1))
    end

    local gc = GlobalData:call("shared")
    if ( info_uid==gc:getProperty("playerInfo"):getProperty("allianceInfo"):getProperty("uid") ) then
-- //        m_selfheadSpr:setVisible(true)
-- //        m_otherheadSpr:setVisible(false)
        self.m_sprBG4:setVisible(true)
        self.m_sprBG1:setVisible(false)
        self.m_sprBG2:setVisible(false)
        self.m_sprBG3:setVisible(false)
-- //        self.m_text1:setColor({250,224,143})
-- //        self.m_text2:setColor({250,224,143})
-- //        self.m_text3:setColor({250,224,143})
    else
-- //        m_selfheadSpr:setVisible(false)
-- //        m_otherheadSpr:setVisible(true)
        self.m_sprBG4:setVisible(false)
-- //        self.m_text1:setColor({201,188,149})
-- //        self.m_text2:setColor({201,188,149})
-- //        self.m_text3:setColor({201,188,149})
    end

    local name = "(" .. info_abbr .. ")" .. info_alliancename
    self.m_text1:setString(name)
    local leader =_lang("105403") .. info_leader
    self.m_text2:setString(leader)
    if (self.m_type==1) then
        self.m_text3:setString(CC_CMDITOAL(info_fightpower))
    elseif(self.m_type==2) then
        self.m_text3:setString(CC_CMDITOAL(info_armyKill))
    elseif(self.m_type==3) then 
        self.m_text3:setString(CC_CMDITOAL(info_score))
    end
end

function AllianceRankListCell:onEnter()
    -- CCNode:onEnter()
    self:setTouchEnabled(true)
    self:setSwallowsTouches(false)
    -- //CCDirector:sharedDirector():getTouchDispatcher():addTargetedDelegate(this, Touch_Default, false)//
end

function AllianceRankListCell:onExit()
    self:setTouchEnabled(false)
    -- CCNode:onExit()
end

function AllianceRankListCell:onTouchBegan(x, y)
    if (not isTouchInside(self.m_touchNode, x, y)) then
        return false
    end

    if (isTouchInside(self.m_hintBGNode, x, y)) then
        self.m_startPoint = cc.p(x, y)
        return true
    end
    return false
end

function AllianceRankListCell:onTouchEnded(x, y)
    if (math.abs(y-self.m_startPoint.y) >20 or math.abs(x-self.m_startPoint.x) > 20) then
        return
    end
    if (isTouchInside(self.m_hintBGNode, x, y)) then
        local GetAllianceListCommand = Drequire(gal_cmd_path)
        local callback = function (data)
            self:showAllianceInfo(data)
        end
        local auid = self.m_info:getProperty("uid")
        local cmd = GetAllianceListCommand.create(self.m_info:getProperty("alliancename"), auid, 1, 1, callback)
        -- cmd:setSuccessCallback(CCCallFuncO:create(this, callfuncO_selector(AllianceRankListCell:showAllianceInfo), NULL))
        cmd:send()
    end
end

function AllianceRankListCell:showAllianceInfo(data) -- void | dictTable
    local arr = data["list"]
    if (arr == nil) then
        return
    end
    local num = #arr
    for i = 1, num, 1 do
        local dicAllianceTable = arr[i] --dictTable
        local dicAlliance = luaToDict(dicAllianceTable) --ccdict*

        --记得导出后开放。
        local alliance = AllianceInfo:call("create") --AllianceInfo*
        alliance:call("updateAllianceInfo", dicAlliance)
        if ( alliance:getProperty("name") == self.m_info:getProperty("alliancename") ) then
            local dict = CCDictionary:create()
            dict:setObject(CCString:create("CheckAllianceInfoView"), "name")
            dict:setObject(alliance, "AllianceInfo") --??may be not?
            LuaController:call("openPopViewInLua", dict)
            -- PopupViewController:getInstance():addPopupInView(CheckAllianceInfoView:create(alliance))
            -- alliance:release()
            break
        end
        -- alliance:release()
    end
end

return AllianceRankListCell

