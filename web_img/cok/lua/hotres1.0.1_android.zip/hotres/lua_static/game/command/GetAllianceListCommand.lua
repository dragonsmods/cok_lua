--@author: mm
--@date: 2016-12-14

--pre decl
local print = print
local math = math
local loprint = function(...)
    -- print(...)
end
local CC_ITOA = CC_ITOA
local LocalController = LocalController
local tostring = tostring
local string = string

--class
local GetAllianceListCommand = class("GetAllianceListCommand", LuaCommandBase)

--const
local GET_ALLIANCE_LIST = "al.search"

--fields
GetAllianceListCommand.m_key = "" -- str
GetAllianceListCommand.m_auid = "" -- str
GetAllianceListCommand.m_page = 0 --int
GetAllianceListCommand.m_type = 0 --int

--functions
-- cmd | string, int, int, function
function GetAllianceListCommand.create(key, auid, page, type, callback)
    local ret = GetAllianceListCommand.new()
    ret:initWithName(GET_ALLIANCE_LIST)
    ret.m_key = key
    ret.m_auid = auid
    ret.m_page = page
    ret.m_type = type
    ret.cmdCallback = callback
    ret:setup()

    loprint("GetAllianceListCommand | create")
    --ret.callback=func
    return ret
end

function GetAllianceListCommand:setup()
    self:putParam("key", CCString:create(self.m_key))
    self:putParam("page", CCInteger:create(self.m_page))
    self:putParam("type", CCInteger:create(self.m_type))
    if self.m_auid and self.m_auid ~= "" then
        self:putParam("auid", CCString:create(self.m_auid))
    end
    
    if (self.m_type==0) then
        local langId = ""
        
        local dic_all = LocalController:call("shared"):call("DBXMLManager"):call("getGroupByKey", "language") --ccdict*
        local dictTable = dictToLuaTable(dic_all)
        local idx = 9500
        local num = #dictTable --dic_all:count()
        local curLang = LocalController:call("shared"):call("getLanguageFileName") --string
        -- local clLen = string.len(curLang)
        --意思就是找到吧……用各种length的话……
        if (string.find(curLang, "zh_CN") or string.find(curLang, "zh-Hans") or string.find(curLang, "zh_TW") or string.find(curLang, "zh-Hant")) then
            curLang = "zh"
        end

        for i = 0, num - 1, 1 do
            local dic_one = dictTable[CC_ITOA(idx + i)]
            local mark = tostring(dic_one["mark"])
            local lang_ma = tostring(dic_one["lang_ma"])
            local lang_id = tostring(dic_one["lang_id"])
            if (mark ~= "" and lang_ma ~= "" and string.find(curLang, lang_ma)) then
                langId = lang_id
                break
            end
        end

        if (langId == "") then
            langId = "115601"
        end
        self:putParam("language", CCString:create(langId))
    end
end

function GetAllianceListCommand:handleReceive( dict )
    loprint("GetAllianceListCommand: handleReceive")

    local flag, params = self:parseMsg(dict)
    if (type(flag) == "boolean") then 
        return flag
    end

    if (self.m_key ~="") then
        AllianceManager:call("getInstance"):call("clearData", "allianceList")
    end
    self.cmdCallback(flag) --falg=dictTable

    return true
end

return GetAllianceListCommand


