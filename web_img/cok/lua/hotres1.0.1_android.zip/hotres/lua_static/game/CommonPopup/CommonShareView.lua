local CommonShareView = class("CommonShareView", function()
	return PopupBaseView:create()
end)
--分享成功后告知后端，分享任务需要
local ShareResultCmd = class("ShareResultCmd", LuaCommandBase)
function ShareResultCmd.create(activityId)
	local ret = ShareResultCmd.new()
	ret:initWithName("triggertask.share")
	return ret
end

function ShareResultCmd:handleReceive(dict)
	local tbl, params = self:parseMsg(dict, true)
	if type(tbl) == "boolean" then
		return tbl
	end
end





--[[
	参数及含义
	必选
	shareType : 分享类型, 1、普通分享, 2、网页分享, 3、图片分享
	shareId : 分享 id，用于取前端表 game_share 中的数据 (网页或图片分享时可以不传)
	可选
	shareLink : 分享链接, shareType 为 2 时表示网页链接, 为 3 时表示图片的本地路径
	callback : 回调函数, 分享回调该函数并在分享成功时关闭当前页面
	shareTag : 标签, 用于数据统计
	addErWeiMa: 图片分享时那些需要添加二维码 {1:weixin，2:weibo，3:pengyouquan}
	addLogoPic: 图片分享时那些需要Logo图 {1:weixin，2:weibo，3:pengyouquan}
--]]
local shareToType = {
	weixin = 1,
	weibo = 2,
	pengyouquan = 3,
	facebook = 4,
	vk = 5,
	twitter = 6,
	messenger = 7,
	savePng = 8
}

local shareBtnOrder = {
	weixin = 3,
	weibo = 5,
	pengyouquan = 4,
	facebook = 2,
	vk = 1,
	twitter = 0,
	messenger = 6, 
	savePng = 10,
}

local platform = {
	weixin = "weixin",
	weibo = "weibo",
	pengyouquan = "pengyouquan",
	facebook = "facebook",
	vk = "vk",
	twitter = "twitter",
	messenger = "messenger",
	savePng = "savePng",
}

function CommonShareView:create(shareType, shareId, shareLink, callback, shareTag, shareDescription)
	local view = CommonShareView.new()
	Drequire("game.CommonPopup.CommonShareView_ui"):create(view, 0)
	if view:initView(shareType, shareId, shareLink, callback, shareTag, shareDescription) then
		return view
	end
end

function CommonShareView:createEx(params)
	local view = CommonShareView.new()
	Drequire("game.CommonPopup.CommonShareView_ui"):create(view, 0)
	if view:initViewEx(params) then
		return view
	end
end

function CommonShareView:initViewEx(params)
	self.initParams = params
	return self:initView(params.shareType, params.shareId, params.shareLink, params.callback, params.shareTag)
end

function CommonShareView:initView(shareType, shareId, shareLink, callback, shareTag, shareDescription)
	self.m_shareType = tonumber(shareType)
	self.m_shareId   = tostring(shareId)
	self.m_shareLink = tostring(shareLink)
	self.m_callback  = callback
	self.m_shareTag  = tostring(shareTag)
	self.m_shareDescription = shareDescription
	self.platform = ""
	if not self.m_shareType then
		return false
	end

	-- 检查数据有效性
	if self.m_shareType == 1 then
		if not self.m_shareId or self.m_shareId == "" then
			return false
		end
	elseif self.m_shareType == 2 or self.m_shareType == 3 then
		if not self.m_shareLink or self.m_shareLink == "" then
			return false
		end
	end

	if type(self.m_callback) ~= "function" then
		self.m_callback = nil
	end

	-- 分享奖励 UI
	local offsetY = 0
	self.shareCtlInstance = require("game.controller.ShareController").getInstance()
	if self.shareCtlInstance:isCanGetReward() then
		self.ui.m_firstShareNode:setVisible(true)
		self.m_webNode = self.ui.m_webNodeSmall
		self.m_touchNode = self.ui.m_touchNodeSmall

		self.ui.m_rewardNotReceivedNode:setVisible(true)
		self.ui.m_rewardReceivedNode:setVisible(false)
		self.ui.m_rewardNode:removeAllChildren()
		local rewards = self.shareCtlInstance:getRewards()
		local tempTbl = string.split(rewards, "|")
		if #tempTbl >= 2 then
			local tbl = {
				itemId = tempTbl[1], -- "211452";
				num = tonumber(tempTbl[2]), -- "100";
				type = 0,
			}
			local node = LibaoCommonFunc.createCommonItem(tbl, 76, self.ui.m_rewardNode)
			self.ui.m_rewardNode:addChild(node)
		end
	else
		self.ui.m_firstShareNode:setVisible(false)
		self.m_webNode = self.ui.m_webNodeBig
		self.m_touchNode = self.ui.m_touchNodeBig
	end

	self.m_webView = nil

	if self.m_shareType == 1 then
		self.ui.m_maskLayer:setVisible(false)
		self.ui.m_uiTitle:setVisible(false)

	elseif self.m_shareType == 2 then
		self.ui.m_maskLayer:setVisible(true)
		self.ui.m_uiTitle:setVisible(true)

		local webSize = self.m_webNode:getContentSize()
		local scale = 1
		if CCCommonUtilsForLua:isIosAndroidPad() then
			scale = 2.4
		end
		local webViewPosition = cc.p(0, (1 - scale) * webSize.height)
		local webViewSize = cc.size(webSize.width * scale, webSize.height * scale)
		self.m_webView = CCWebView:call("create", webViewPosition, webViewSize, self.m_webNode)
		self.m_webView:call("loadUrl", self.m_shareLink)
		self.m_webView:call("setVisible", true)

		-- 转圈动画
		local waitInterface = GameController:call("getInstance"):call("showWaitInterface1", self.m_webNode)
		waitInterface:setPosition(ccp(webSize.width / 2, webSize.height / 2))

	elseif self.m_shareType == 3 then
		self.ui.m_maskLayer:setVisible(true)
		self.ui.m_uiTitle:setVisible(true)

		local x, y = self.m_webNode:getPosition()
		local webSize = self.m_webNode:getContentSize()
		local fullPath = cc.FileUtils:getInstance():fullPathForFilename(self.m_shareLink)
		if fullPath and fullPath ~= "" then
			local spr = cc.Sprite:create(self.m_shareLink)
			if spr then
				spr:setPosition(cc.p(x + webSize.width / 2, y + webSize.height / 2))
				local sprSize = spr:getContentSize()
				local scaleX = webSize.width / sprSize.width
				local scaleY = webSize.height / sprSize.height
				spr:setScale(math.min(scaleX, scaleY))			
				self:addChild(spr)
			end
			if self.initParams and self.initParams.delImgAfterShare then 
				self.tblFilesWaitForRemove = { self.m_shareLink }
			end
		end
	else
		return false
	end

	self.touchLayer = cc.Layer:create()
	self:addChild(self.touchLayer)
	local function touchHandle(eventType, x, y)
		if eventType == "began" then
			return self:onTouchBegan(x, y)
		elseif eventType == "ended" then
			self:onTouchEnded(x, y)
		end
	end
	self.touchLayer:registerScriptTouchHandler(touchHandle)
	self.touchLayer:setTouchEnabled(true)
	self.touchLayer:setSwallowsTouches(false)

	CCCommonUtilsForLua:call("setButtonSprite", self.ui.m_weixinBtn, "icon_pengyouquan.png")
	self.ui.m_weixinBtn:setPreferredSize(cc.size(64,64))
	self:recalBtns()
	return true
end

function CommonShareView:checkBtnVisible(share2type)
	local analyticID = GlobalData:call("shared"):getProperty("analyticID")
	local isXiaoMiPlatForm = GlobalData:call("isXiaoMiPlatForm")
	local langCode = CCCommonUtilsForLua:call("getLanguage")
	if share2type == shareToType.weibo then
		--百度渠道,开关打开则屏蔽分享,过审后再关闭
		if (analyticID == "cn_baidu" or analyticID == "cn_uc") 
		and CCCommonUtilsForLua:isFunOpenByKey("close_china_channel_share") then
			return false
		end
		if self:isWeiboEnableChannel() then
			return true
		end
		-- 除了部分开放微信分享的渠道包外，其它渠道包都开放微博分享
		if not self:isWechatEnableChannel() then
			return true
		end
	elseif share2type == shareToType.weixin or share2type == shareToType.pengyouquan then
		if analyticID == "cn_uc" and CCCommonUtilsForLua:isFunOpenByKey("close_china_channel_share") then
			return false
		end
		if self:isWechatEnableChannel() then
			return true
		end
		-- 除了渠道包外，都开放微信分享
		if not isXiaoMiPlatForm then
			return true
		end
	elseif share2type == shareToType.facebook then
		if not (analyticID == "cn1" or isXiaoMiPlatForm) then
			return true
		end
	elseif share2type == shareToType.vk then
		if not (analyticID == "cn1" or isXiaoMiPlatForm) and langCode == "ru" then
			return true
		end
	elseif share2type == shareToType.twitter then
		if not (analyticID == "cn1" or isXiaoMiPlatForm) and langCode ~= "zh_CN" and CCCommonUtilsForLua:isFunOpenByKey("share_twitter") then
			return true
		end
	elseif share2type == shareToType.messenger then
		if CCCommonUtilsForLua:isFunOpenByKey("messenger_share") and (not (analyticID == "cn1" or isXiaoMiPlatForm)) then
			return true
		end
	elseif share2type == shareToType.savePng then
		if self.m_shareType == 3 and CCCommonUtilsForLua:isFunOpenByKey("picture_report_share") then
			return true
		end		
	end
	return false
end

-- 部分开放微博分享的渠道
function CommonShareView:isWeiboEnableChannel()
	local analyticID = GlobalData:call("shared"):getProperty("analyticID")
	if analyticID == "cn_ewan" or analyticID == "cn_mi" then
		return true
	end
	return false
end

-- 部分开放微信分享的渠道
function CommonShareView:isWechatEnableChannel()
	local analyticID = GlobalData:call("shared"):getProperty("analyticID")
	if analyticID == "cn_mi" or analyticID == "cn_mihy" or analyticID == "cn_uc" or analyticID == "cn_huawei" or analyticID == "cn_vivo" or analyticID == "cn_ewan" then
		return true
	end
	return false
end

function CommonShareView:recalBtns()
	local shareBtns = {
		self.ui.m_weixinChatBtn,
		self.ui.m_weiboBtn,
		self.ui.m_weixinBtn,
		self.ui.m_fbBtn,
		self.ui.m_shareVKBtn,
		self.ui.m_shareTwitterBtn,
		self.ui.m_FBMessengerBtn,
		self.ui.m_savePNGBtn, --图片分享，保存本地
	}
    local btnTbl = {}
    local nousebtnTbl = {}
    for k,v in pairs(shareToType) do 
    	local isVisible = self:checkBtnVisible(v)
    	if isVisible then 
    		btnTbl[#btnTbl+1] = {btn=shareBtns[v],order=shareBtnOrder[k],type=k}
    	else
    		nousebtnTbl[#nousebtnTbl+1] = shareBtns[v]
    	end
    end
    table.sort( btnTbl, function( a,b )
    	return tonumber(a.order) < tonumber(b.order)
    end )
    -- dump(btnTbl, "btnTbl+++",10)

    for k,btn in pairs(nousebtnTbl) do 
    	if btn then 
    		btn:setVisible(false)
    	end
    end
	local dis = 640/(#btnTbl+1)
	for k,item in pairs(btnTbl) do 
    	item.btn:setVisible(true)
    	item.btn:setPositionX(k*dis-320)
	end
	
	--按钮过多，加个scrollview
	if dis < 100 then
		dis = 120
		local scrollView = cc.ScrollView:create()
		scrollView:setViewSize(cc.size(640,140))
		scrollView:ignoreAnchorPointForPosition(true)
		scrollView:setPosition(cc.p(0,20))
		scrollView:setDirection(0)
		scrollView:setClippingToBounds(true)
		scrollView:setBounceable(true)
		self:addChild(scrollView)
		local offset_x = 50
		for k,item in ipairs(btnTbl) do 			
			item.btn:retain()
			item.btn:removeFromParent()
			scrollView:addChild(item.btn)			
			item.btn:setPositionX(offset_x)
			item.btn:setAnchorPoint(ccp(0.5,0))
			item.btn:release()
			offset_x = offset_x + dis
			
		end
		scrollView:setContentSize(cc.size(dis*#btnTbl,140))
	end  
end

function CommonShareView:onEnter()
--@region 分享回调通知 MSG_SHARE_RESULT
	-- shareResult: 成功-1 失败-2 取消-3
	local function callback(dict)
		local tblData = dictToLuaTable(dict)
		-- 数据统计	
		local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
		local mAllianceId = playerInfo:call("getAllianceId")	
		LogController:postEventLog("LogShareResult", {	STAG=self.m_shareTag, 
														STYPE=tblData.shareType, 
														SRESULT=tblData.shareResult,
														uid = GlobalData:call("shared"):getProperty("playerInfo"):getProperty("uid"), 
														platform = self.platform, 
														timeStamp = getTimeStamp(),
														allianceId = mAllianceId,
													})
		self.platform = ""
		-- 分享奖励
		if tblData.shareResult == 1 and self.shareCtlInstance:isCanGetReward() then
			self.shareCtlInstance:reqFirstShareRewards()
			self.ui.m_rewardNotReceivedNode:setVisible(false)
			self.ui.m_rewardReceivedNode:setVisible(true)
			CCCommonUtilsForLua:call("flyHint", "", "", getLang("4100026"))
		end
		-- 回调
		if self.m_callback then
			self.m_callback(tblData)
			if tblData.shareResult == 1 then
				PopupViewController:call("removePopupView", self)
			end
		end
		local cmd = ShareResultCmd.create()
		cmd:send()--分享成功后告知后端
	end
	local handler = self:registerHandler(callback)
	CCSafeNotificationCenter:registerScriptObserver(self, handler, "MSG_SHARE_RESULT")
--@endregion
	
--@region 图片本地保存通知
	local function callback2(Ref)
		local success = Ref ~= nil and Ref:getValue()
		if success then
			CCCommonUtilsForLua:call("flyHint", "", "", getLang("115894"))
			PopupViewController:call("removePopupView", self)
		else
			CCCommonUtilsForLua:call("flyHint", "", "", getLang("115893"))
		end
	end
	local handler2 = self:registerHandler(callback2)
	CCSafeNotificationCenter:registerScriptObserver(self, handler2, SAVE_IMAGE_TO_ALBUM_RES)
--@endregion
end

function CommonShareView:onExit()
	self:statrCheckImage(false)
	if self.tblFilesWaitForRemove and #self.tblFilesWaitForRemove > 0 then 
		for k, imgFile in pairs(self.tblFilesWaitForRemove) do 
			MyPrint("remove file after share00+++",imgFile)
			local bFileExited = cc.FileUtils:getInstance():isFileExist(imgFile)
			if bFileExited then 
				MyPrint("remove file after share11+++",imgFile)
				os.remove(imgFile)
			end
		end 
		self.tblFilesWaitForRemove = nil
	end
	if self.m_webView then
		self.m_webNode:removeAllChildren()
		-- self.m_webView:call("setVisible", false)
	end
	CCSafeNotificationCenter:unregisterScriptObserver(self, "MSG_SHARE_RESULT")
	CCSafeNotificationCenter:unregisterScriptObserver(self, SAVE_IMAGE_TO_ALBUM_RES)
end

function CommonShareView:onTouchBegan(x, y)
	if self.m_shareType == 1 then
		self.m_touchPoint = ccp(x, y)
		return true
	end
	return false
end

function CommonShareView:onTouchEnded(x, y)
	if isTouchInside(self.m_touchNode, x, y) and ccpSquareDistance(ccp(x, y), self.m_touchPoint) < 100 then
		PopupViewController:call("removePopupView", self)
	end
end

function CommonShareView:isNeedErWeiMa(shareTo)
	if not CCCommonUtilsForLua:isFunOpenByKey("share_image_qd") then
		return false
	end
	if self.initParams and self.initParams.addErWeiMa and self.initParams.addErWeiMa ~= "" then 
		local tbl = string.split(self.initParams.addErWeiMa, ",")
		for k,t in pairs(tbl) do
			if tonumber(t) == shareTo then 
				return true
			end
		end
	end
	return false
end

function CommonShareView:isNeedLogo(shareTo)
	if not CCCommonUtilsForLua:isFunOpenByKey("share_image_logo") then
		return false
	end
	if self.initParams and self.initParams.addLogoPic and self.initParams.addLogoPic ~= "" then 
		local tbl = string.split(self.initParams.addLogoPic, ",")
		for k,t in pairs(tbl) do
			if tonumber(t) == shareTo then 
				return true
			end
		end
	end
	return false
end

function CommonShareView:makeNewSharePic(shareTo, orgFilePath)
	MyPrint("CommonShareView:makeNewSharePic+++:", shareTo, orgFilePath)
	local bNeedErWeiMa = self:isNeedErWeiMa(shareTo)
	local bNeedLogo = self:isNeedLogo(shareTo)
	local newFilePath = orgFilePath
	MyPrint("bNeedLogo,bNeedErWeiMa:", bNeedLogo, bNeedErWeiMa)
	if not bNeedLogo and not bNeedErWeiMa then 
		return orgFilePath		
	end
	MyPrint("make new pic+++")
	local recordNode = cc.Node:create()
	local spr = cc.Sprite:create(orgFilePath)
	local picSize = spr:getContentSize()
    local winSize = cc.Director:getInstance():getIFWinSize()
    dump(picSize, "picSize1+++")
    dump(winSize, "winSize+++")
    local sx = winSize.width/picSize.width
    local sy = winSize.height/picSize.height
    local realScale = math.min(sx,sy)
    dump(realScale, "realScale+++")

    spr:setScale(realScale)
    picSize.width = picSize.width*realScale
    picSize.height = picSize.height*realScale
    dump(picSize, "picSize2+++")

	recordNode:setContentSize(picSize)
	recordNode:addChild(spr)
	spr:setPosition(picSize.width/2.0, picSize.height/2.0)

	if bNeedErWeiMa then 
		local iconErWeiMa = "icon_image_share_ewm.png"
		local sf = CCLoadSprite:call("getSF", iconErWeiMa)
        if not sf then
        	CCLoadSprite:call("loadDynamicResourceByName", "goods")
        	sf = CCLoadSprite:call("getSF", iconErWeiMa)
        end
        MyPrint("sf ewm:",sf)
        local sprPic = CCLoadSprite:call("createSprite",iconErWeiMa)
        if sprPic then 
        	MyPrint("sprPic ewm:",sf)
        	recordNode:addChild(sprPic)
        	sprPic:setAnchorPoint(0, 0)
        	sprPic:setPosition(2,2)
        	sprPic:setScale(0.5) 
        end
	end

	if bNeedLogo then 
		local isChina = GlobalData:call("isChinaPlatForm")
    	local langCode = CCCommonUtilsForLua:call("getLanguage") 
		local acId = GlobalData:call("shared"):getProperty("analyticID")
		MyPrint("isChina,langCode,acId:",isChina,langCode,acId)

		local iconLogo = nil
		if isChina or (langCode == "zh_CN") or (acId == "common") then 
			iconLogo = "logo_only.png"
    	elseif CCCommonUtilsForLua:isVietnam() then
    		CCLoadSprite:call("doResourceByCommonIndex", 7, true)
        	iconLogo = "logo_vietnam.png"
		else
			iconLogo = "logo.png"
		end
		local sfLogo = CCLoadSprite:call("getSF", iconLogo)
        if sfLogo then 
        	MyPrint("sf logo:",sfLogo)
        	local sprPic = CCLoadSprite:call("createSprite",iconLogo)
	        if sprPic then 
        		MyPrint("sprPic logo:",sprPic)
	        	recordNode:addChild(sprPic)
	        	sprPic:setAnchorPoint(1, 0)
	        	sprPic:setPosition(picSize.width,0)
	        	sprPic:setScale(0.5) 
	        end
	    end
	end

	local texture = cc.RenderTexture:create(picSize.width, picSize.height)
	texture:beginWithClear(0, 0, 0, 1.0)
	recordNode:visit()
	texture:endToLua()
	local fileName = "sharePic" .. getTimeStamp() .. ".png"
	local picPath = CCFileUtils:sharedFileUtils():getWritablePath() .. fileName
	texture:saveToFile(fileName, false)
	MyPrint("new file path:", picPath)
	if not self.tblFilesWaitForRemove then 
		self.tblFilesWaitForRemove = {}
	end
	self.tblFilesWaitForRemove[#self.tblFilesWaitForRemove+1] = picPath
	return picPath
end

function CommonShareView:onPopupReturnClick()
	PopupViewController:call("removePopupView", self)
end

function CommonShareView:onFbClick()
	if self:checkShareData() then
		self.platform = platform.facebook
		local caption = getLang(CCCommonUtilsForLua:call("getPropByIdGroup", "game_share", self.m_shareId, "caption"))
		local description = self.m_shareDescription or getLang(CCCommonUtilsForLua:call("getPropByIdGroup", "game_share", self.m_shareId, "description"))
		local link = ""
		local pictureUrl = ""		
		if self.m_shareType == 1 then
			link = CCCommonUtilsForLua:call("getPropByIdGroup", "game_share", self.m_shareId, "link_facebook")
			FBUtiliesInLua:call("fbPublishFeedDialog", "", caption, description, link, pictureUrl, 0)

		elseif self.m_shareType == 2 then
			if string.find(self.m_shareLink, ToNewServerController.getInstance().m_shareUrl) then
				LogController:postEventLog("LogRecruitmentShareUrl", {uid = GlobalData:call("shared"):getProperty("playerInfo"):getProperty("uid"), platform = platform.facebook})
			end
			link = self.m_shareLink .. "&pf=" .. platform.facebook
			FBUtiliesInLua:call("fbPublishFeedDialog", "", caption, description, link, pictureUrl, 0)

		elseif self.m_shareType == 3 then
			-- pictureUrl = self.m_shareLink
			pictureUrl = self:makeNewSharePic(shareToType.facebook, self.m_shareLink)
			local fileOk = cc.FileUtils:getInstance():isFileExist(pictureUrl)
			dump(fileOk, "facebook fileOk1+++")
			if fileOk then 
				local targetPlatform = cc.Application:getInstance():getTargetPlatform()
				if targetPlatform == cc.PLATFORM_OS_IPHONE or targetPlatform == cc.PLATFORM_OS_IPAD then
					FBUtiliesInLua:call("fbPublishFeedDialog", "", caption, description, pictureUrl, "", 0)
				elseif targetPlatform == cc.PLATFORM_OS_ANDROID then
					FBUtiliesInLua:call("fbSharePhotosByUrl", pictureUrl, caption .. description)
				end
			else
				self.ui.m_fbBtn:setEnabled(false)
				dump("facebook delay clicked+++")
				local function callbackDoShare( params )
					dump(params, "facebook delay callbackDoShare+++")
					self.ui.m_fbBtn:setEnabled(true)
					if params.isIOS then 
						FBUtiliesInLua:call(params.parma1,params.parma2,params.parma3,params.parma4,params.parma5,params.parma6,params.parma7)
					else
						FBUtiliesInLua:call(params.parma1, params.parma2, params.parma3)
					end
				end
				local tblParams = {}
				local targetPlatform = cc.Application:getInstance():getTargetPlatform()
				if targetPlatform == cc.PLATFORM_OS_IPHONE or targetPlatform == cc.PLATFORM_OS_IPAD then
					-- FBUtiliesInLua:call("fbPublishFeedDialog", "", caption, description, pictureUrl, "", 0)
					tblParams.isIOS = true 
					tblParams.parma1 = "fbPublishFeedDialog"
					tblParams.parma2 = ""
					tblParams.parma3 = caption
					tblParams.parma4 = description
					tblParams.parma5 = pictureUrl
					tblParams.parma6 = ""
					tblParams.parma7 = 0
				elseif targetPlatform == cc.PLATFORM_OS_ANDROID then
					-- FBUtiliesInLua:call("fbSharePhotosByUrl", pictureUrl, caption .. description)
					tblParams.isIOS = false 
					tblParams.parma1 = "fbSharePhotosByUrl"
					tblParams.parma2 = pictureUrl
					tblParams.parma3 = caption .. description
				end
				self:statrCheckImage(false)
				self:statrCheckImage(true, callbackDoShare, tblParams, pictureUrl)
			end	
		end
	end
end

function CommonShareView:onWeixinChatClick()
	if self:checkShareData() then
		self.platform = platform.weixin
		local caption = getLang(CCCommonUtilsForLua:call("getPropByIdGroup", "game_share", self.m_shareId, "caption"))
		local description = self.m_shareDescription or getLang(CCCommonUtilsForLua:call("getPropByIdGroup", "game_share", self.m_shareId, "description"))
		local link = ""
		local pictureUrl = ""

		if self.m_shareType == 1 then
			link = CCCommonUtilsForLua:call("getPropByIdGroup", "game_share", self.m_shareId, "link_weixin")
			SNSUtiliesForLua:call("shareHtmlWeiXin", "weiXin", caption, description, link, 0)

		elseif self.m_shareType == 2 then
			if string.find(self.m_shareLink, ToNewServerController.getInstance().m_shareUrl) then
				LogController:postEventLog("LogRecruitmentShareUrl", {uid = GlobalData:call("shared"):getProperty("playerInfo"):getProperty("uid"), platform = platform.weixin})
			end
			link = self.m_shareLink .. "&pf=" .. platform.weixin
			SNSUtiliesForLua:call("shareHtmlWeiXin", "weiXin", caption, description, link, 0)

		elseif self.m_shareType == 3 then
			if self.m_shareTag == "FestivalActivities_57326" then
				link = CCCommonUtilsForLua:call("getPropByIdGroup", "game_share", self.m_shareId, "link_weixin")
				SNSUtiliesForLua:call("shareHtmlWeiXin", "weiXin", caption, description, link, 0)
			else
				pictureUrl = self:makeNewSharePic(shareToType.weixin, self.m_shareLink)
				-- SNSUtiliesForLua:call("shareWeiXin", "", caption .. description, pictureUrl, 0);
				local fileOk = cc.FileUtils:getInstance():isFileExist(pictureUrl)
				dump(fileOk, "fileOk1+++")
				if fileOk then 
					SNSUtiliesForLua:call("shareWeiXin", "", caption .. description, pictureUrl, 0);
					return 
				end 
				self.ui.m_weixinChatBtn:setEnabled(false)
				dump("weixin clicked+++")
				local function callbackDoShare( params )
					dump(params, "weixin callbackDoShare+++")
					self.ui.m_weixinChatBtn:setEnabled(true)
					SNSUtiliesForLua:call(params.parma1,params.parma2,params.parma3,params.parma4,params.parma5)
				end
				local tblParams = {}
				tblParams.parma1 = "shareWeiXin"
				tblParams.parma2 = ""
				tblParams.parma3 = caption .. description
				tblParams.parma4 = pictureUrl
				tblParams.parma5 = 0
				self:statrCheckImage(false)
				self:statrCheckImage(true, callbackDoShare, tblParams, pictureUrl)
			end
		end
	end
end

function CommonShareView:onWeixinClick() -- 朋友圈
	if self:checkShareData() then
		self.platform = platform.pengyouquan
		local caption = getLang(CCCommonUtilsForLua:call("getPropByIdGroup", "game_share", self.m_shareId, "caption"))
		local description = self.m_shareDescription or getLang(CCCommonUtilsForLua:call("getPropByIdGroup", "game_share", self.m_shareId, "description_wechat"))
		if description == nil or description == "" then
			description = getLang(CCCommonUtilsForLua:call("getPropByIdGroup", "game_share", self.m_shareId, "description"))
		end
		local link = ""
		local pictureUrl = ""

		if self.m_shareType == 1 then
			link = CCCommonUtilsForLua:call("getPropByIdGroup", "game_share", self.m_shareId, "link_weixin_friends")
			SNSUtiliesForLua:call("shareHtmlWeiXin", "weiXin", caption, description, link, 1)

		elseif self.m_shareType == 2 then
			if string.find(self.m_shareLink, ToNewServerController.getInstance().m_shareUrl) then
				LogController:postEventLog("LogRecruitmentShareUrl", {uid = GlobalData:call("shared"):getProperty("playerInfo"):getProperty("uid"), platform = platform.pengyouquan})
			end
			link = self.m_shareLink .. "&pf=" .. platform.pengyouquan
			SNSUtiliesForLua:call("shareHtmlWeiXin", "weiXin", caption, description, link, 1)

		elseif self.m_shareType == 3 then
			if self.m_shareTag == "FestivalActivities_57326" then
				link = CCCommonUtilsForLua:call("getPropByIdGroup", "game_share", self.m_shareId, "link_weixin_friends")
				SNSUtiliesForLua:call("shareHtmlWeiXin", "weiXin", caption, description, link, 1)
			else
				pictureUrl = self:makeNewSharePic(shareToType.pengyouquan, self.m_shareLink)
				-- SNSUtiliesForLua:call("shareWeiXin", "", caption .. description, pictureUrl, 1);
				local fileOk = cc.FileUtils:getInstance():isFileExist(pictureUrl)
				dump(fileOk, "fileOk2+++")
				if fileOk then 
					SNSUtiliesForLua:call("shareWeiXin", "", caption .. description, pictureUrl, 1);
					return 
				end 
				self.ui.m_weixinBtn:setEnabled(false)
				local function callbackDoShare( params )
					dump(params, "pengyouquan callbackDoShare+++")
					self.ui.m_weixinBtn:setEnabled(true)
					SNSUtiliesForLua:call(params.parma1,params.parma2,params.parma3,params.parma4,params.parma5)
				end
				local tblParams = {}
				tblParams.parma1 = "shareWeiXin"
				tblParams.parma2 = ""
				tblParams.parma3 = caption .. description
				tblParams.parma4 = pictureUrl
				tblParams.parma5 = 1
				self:statrCheckImage(false)
				self:statrCheckImage(true, callbackDoShare, tblParams, pictureUrl)
			end
		end
	end
end

function CommonShareView:onWeiboClick()
	if self:checkShareData() then
		self.platform = platform.weibo
		local caption = getLang(CCCommonUtilsForLua:call("getPropByIdGroup", "game_share", self.m_shareId, "caption"))
		local description = self.m_shareDescription or getLang(CCCommonUtilsForLua:call("getPropByIdGroup", "game_share", self.m_shareId, "description"))
		local link = ""
		local pictureUrl = ""

		if self.m_shareType == 1 then
			link = CCCommonUtilsForLua:call("getPropByIdGroup", "game_share", self.m_shareId, "link_weibo")
			SNSUtiliesForLua:call("shareWeiBo", "weibo", caption .. description .. link, pictureUrl)

		elseif self.m_shareType == 2 then
			if string.find(self.m_shareLink, ToNewServerController.getInstance().m_shareUrl) then
				LogController:postEventLog("LogRecruitmentShareUrl", {uid = GlobalData:call("shared"):getProperty("playerInfo"):getProperty("uid"), platform = platform.weibo})
			end
			link = self.m_shareLink .. "&pf=" .. platform.weibo
			SNSUtiliesForLua:call("shareWeiBo", "weibo", caption .. description .. link, pictureUrl)

		elseif self.m_shareType == 3 then
			pictureUrl = self:makeNewSharePic(shareToType.weibo, self.m_shareLink)
			-- SNSUtiliesForLua:call("shareWeiBo", "weibo", caption .. description .. link, pictureUrl)
			local fileOk = cc.FileUtils:getInstance():isFileExist(pictureUrl)
			dump(fileOk, "fileOk3+++")
			if fileOk then 
				SNSUtiliesForLua:call("shareWeiBo", "weibo", caption .. description .. link, pictureUrl)
				return 
			end 
			self.ui.m_weiboBtn:setEnabled(false)
			local function callbackDoShare( params )
				dump(params, "weibo callbackDoShare+++")
				self.ui.m_weiboBtn:setEnabled(true)
				SNSUtiliesForLua:call(params.parma1,params.parma2,params.parma3,params.parma4)
			end
			local tblParams = {}
			tblParams.parma1 = "shareWeiBo"
			tblParams.parma2 = "weibo"
			tblParams.parma3 = caption .. description .. link
			tblParams.parma4 = pictureUrl
			self:statrCheckImage(false)
			self:statrCheckImage(true, callbackDoShare, tblParams, pictureUrl)
		end
	end
end

function CommonShareView:onVKClick()
	if self:checkShareData() then
		self.platform = platform.vk
		local caption = getLang(CCCommonUtilsForLua:call("getPropByIdGroup", "game_share", self.m_shareId, "caption"))
		local description = self.m_shareDescription or getLang(CCCommonUtilsForLua:call("getPropByIdGroup", "game_share", self.m_shareId, "description"))
		local link = ""
		local pictureUrl = ""

		if self.m_shareType == 1 then
			link = CCCommonUtilsForLua:call("getPropByIdGroup", "game_share", self.m_shareId, "link_vk")
			SNSUtiliesForLua:call("shareVK", caption .. description, pictureUrl, link)

		elseif self.m_shareType == 2 then
			if string.find(self.m_shareLink, ToNewServerController.getInstance().m_shareUrl) then
				LogController:postEventLog("LogRecruitmentShareUrl", {uid = GlobalData:call("shared"):getProperty("playerInfo"):getProperty("uid"), platform = platform.vk})
			end
			link = self.m_shareLink .. "&pf=" .. platform.vk
			SNSUtiliesForLua:call("shareVK", caption .. description, pictureUrl, link)

		elseif self.m_shareType == 3 then
			-- pictureUrl = self.m_shareLink
			-- SNSUtiliesForLua:call("shareVK", caption .. description, pictureUrl, link)
			pictureUrl = self:makeNewSharePic(shareToType.vk, self.m_shareLink)
			local fileOk = cc.FileUtils:getInstance():isFileExist(pictureUrl)
			dump(fileOk, "vk fileOk3+++")
			if fileOk then 
				SNSUtiliesForLua:call("shareVK", caption .. description, pictureUrl, link)
			else
				dump("vk delay clicked+++")
				self.ui.m_shareVKBtn:setEnabled(false)
				local function callbackDoShare( params )
					dump(params, "vk delay callbackDoShare+++")
					self.ui.m_shareVKBtn:setEnabled(true)
					SNSUtiliesForLua:call(params.parma1, params.parma2, params.parma3, params.parma4)
				end
				local tblParams = {}
				tblParams.parma1 = "shareVK"
				tblParams.parma2 = caption .. description
				tblParams.parma3 = pictureUrl
				tblParams.parma4 = link
				self:statrCheckImage(false)
				self:statrCheckImage(true, callbackDoShare, tblParams, pictureUrl)
			end 
		end
	end
end

function CommonShareView:onTwitterClick() --推特
	MyPrint("CommonShareView:onTwitterClick+++",self.m_shareType, self.m_shareId)
	if self:checkShareData() then
		self.platform = platform.twitter
		local caption = getLang(CCCommonUtilsForLua:call("getPropByIdGroup", "game_share", self.m_shareId, "caption"))
		local description = self.m_shareDescription or getLang(CCCommonUtilsForLua:call("getPropByIdGroup", "game_share", self.m_shareId, "description"))
		local link = ""
		local pictureUrl = ""
		if self.m_shareType == 1 then
			link = CCCommonUtilsForLua:call("getPropByIdGroup", "game_share", self.m_shareId, "link_twitter")
			MyPrint("type1+++",caption .. description, pictureUrl, link)
			SNSUtiliesForLua:call("shareTwitter", caption .. description, pictureUrl, link)
		elseif self.m_shareType == 2 then
			if string.find(self.m_shareLink, ToNewServerController.getInstance().m_shareUrl) then
				LogController:postEventLog("LogRecruitmentShareUrl", {uid = GlobalData:call("shared"):getProperty("playerInfo"):getProperty("uid"), platform = platform.twitter})
			end
			link = self.m_shareLink .. "&pf=" .. platform.twitter
			MyPrint("type2+++",caption .. description, pictureUrl, link)
			SNSUtiliesForLua:call("shareTwitter", caption .. description, pictureUrl, link)
		elseif self.m_shareType == 3 then
			pictureUrl = self:makeNewSharePic(shareToType.twitter, self.m_shareLink)
			local fileOk = cc.FileUtils:getInstance():isFileExist(pictureUrl)
			dump(fileOk, "twitter fileOk3+++")
			MyPrint("type3+++",caption .. description, pictureUrl, link)
			if fileOk then 
				SNSUtiliesForLua:call("shareTwitter", caption .. description, pictureUrl, link)
			else
				dump("twitter delay clicked+++")
				self.ui.m_shareTwitterBtn:setEnabled(false)
				local function callbackDoShare( params )
					dump(params, "twitter delay callbackDoShare+++")
					self.ui.m_shareTwitterBtn:setEnabled(true)
					SNSUtiliesForLua:call(params.parma1, params.parma2, params.parma3, params.parma4)
				end
				local tblParams = {}
				tblParams.parma1 = "shareTwitter"
				tblParams.parma2 = caption .. description
				tblParams.parma3 = pictureUrl
				tblParams.parma4 = link
				self:statrCheckImage(false)
				self:statrCheckImage(true, callbackDoShare, tblParams, pictureUrl)
			end 
		end
	end
end

--Facebook messenger分享
function CommonShareView:onFBMessengerClick()
	if self:checkShareData() then	
		self.platform = platform.messenger	
		local caption = getLang(CCCommonUtilsForLua:call("getPropByIdGroup", "game_share", self.m_shareId, "caption"))
		local description = self.m_shareDescription or getLang(CCCommonUtilsForLua:call("getPropByIdGroup", "game_share", self.m_shareId, "description"))
		local link = ""
		local pictureUrl = ""
		local pictureTitle = ""
		local imageSize = 1 --分享出去的图片类型 1/1:1    2/2:1
		local gameLogic = 2 --区分游戏分享还是H5网页分享
		--messenger分享title必须有，且不能为空
		if caption == "" then
			caption = getLang("4100033")--4100033=列王的纷争
		end
		if self.m_shareType == 1 then
			link = CCCommonUtilsForLua:call("getPropByIdGroup", "game_share", self.m_shareId, "link_facebookmessenger")
			imageSize = tonumber(CCCommonUtilsForLua:call("getPropByIdGroup", "game_share", self.m_shareId, "image_size")) or 1			
			pictureTitle = getLang(CCCommonUtilsForLua:call("getPropByIdGroup", "game_share", self.m_shareId, "facebookmessenger_button"))			
			pictureUrl = CCCommonUtilsForLua:call("getPropByIdGroup", "game_share", self.m_shareId, "pictureUrl")			
			FBUtiliesInLua:call("fbShareMessenger",link,pictureTitle,caption,description,pictureUrl,gameLogic,imageSize)
		elseif self.m_shareType == 2 then
			link = self.m_shareLink .. "&pf=" .. platform.messenger			
			FBUtiliesInLua:call("fbShareMessenger",link,pictureTitle,caption,description,pictureUrl,gameLogic,imageSize)
		elseif self.m_shareType == 3 then			
			pictureUrl = self:makeNewSharePic(shareToType.messenger, self.m_shareLink)
			local fileOk = cc.FileUtils:getInstance():isFileExist(pictureUrl)			
			if fileOk then 
				FBUtiliesInLua:call("fbShareMessenger",link,pictureTitle,caption,description,pictureUrl,gameLogic,imageSize)
			else
				self.ui.m_FBMessengerBtn:setEnabled(false)				
				local function callbackDoShare( params )
					dump(params, "fbShareMessenger callbackDoShare+++")
					self.ui.m_weixinBtn:setEnabled(true)
					FBUtiliesInLua:call(params.parma1,params.parma2,params.parma3,params.parma4,params.parma5,params.parma6,params.parma7,params.parma8)
				end
				local tblParams = {}
				tblParams.parma1 = "fbShareMessenger"
				tblParams.parma2 = link
				tblParams.parma3 = pictureTitle
				tblParams.parma4 = caption
				tblParams.parma5 = description
				tblParams.parma6 = pictureUrl
				tblParams.parma7 = gameLogic
				tblParams.parma8 = imageSize				
				self:statrCheckImage(false)
				self:statrCheckImage(true, callbackDoShare, tblParams, pictureUrl)
			end			
		end
	end
end

--图片本地保存
function CommonShareView:onClickSavePNGBtn( )
	if self.m_shareType ~= 3 or string.isNilOrEmpty(self.m_shareLink) then
		return
	end
	CCCommonUtilsForLua:call("saveImageToAlbum",self.m_shareLink)
end

function CommonShareView:statrCheckImage(bStart, callbackFun, callbackParams, imageFile)
    if self.entryId then
        self:getScheduler():unscheduleScriptEntry(self.entryId)
        self.entryId = nil
    	self.checkImageFile = nil
    end
    if bStart then
    	self.checkImageFile = imageFile
    	self.entryId = self:getScheduler():scheduleScriptFunc(
    		function(dt) 
    			if cc.FileUtils:getInstance():isFileExist(self.checkImageFile) then
    				dump("found file ok:"..self.checkImageFile) 
    				self:statrCheckImage(false)
    				callbackFun(callbackParams) 
    			else
    				dump("found file fail:"..self.checkImageFile) 
    			end
    		end, 0.01, false)
    end
end

function CommonShareView:checkShareData()
	if self.m_shareType == 1 then
		local data = CCCommonUtilsForLua:getPropDictByIdGroup("game_share", self.m_shareId)
		if table_is_empty(data)then
			CCCommonUtilsForLua:call("flyHint", "", "", getLang("132371"))
			return false
		end
	end
	return true
end

return CommonShareView