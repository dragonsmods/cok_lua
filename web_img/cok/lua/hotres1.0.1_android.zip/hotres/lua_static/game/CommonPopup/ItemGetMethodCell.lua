--modify by yanwei
local FestalActMakexxxCtl = require("game.FestivalActivities.FestivalActivitiesMakexxxController").getInstance()
local deltaPosY = 20
local originPosY = 35
------------------------------------------ ItemGetMethodCell Start --------------------------------------------
local ItemGetMethodCell = class("ItemGetMethodCell", function()
    return cc.Node:create()
end)

local ItemGetType =
{
    GoldExchange = 1, --礼包
    DragonTower = 2, --龙塔
    Activity = 3, --活动中心
    Merchant = 4, --旅行商人
    Store = 5, --商城
    DragonExplore = 6, --龙游历
    HeroBuyFragment = 7, -- 英雄碎片购买
    JumpToBuild = 8, -- 跳转建筑物
    OpenDailyActivity = 9, -- 打开日常任务界面
    JumpToWorld = 10, -- 跳转世界
    OpenHeroTowerHomeView = 11, -- 龙试炼界面
    DragonBag = 12, -- 龙背包
    AllianceTreasure = 13, -- 联盟宝藏
    AllianceQuest = 14, -- 联盟任务
    StoreBagView = 15, -- 背包
    ActivityView = 16, -- 打开活动界面
    AllianceShop = 17,
    KingdomLiBao = 18, --国王礼包
    HeroGetRolate = 19, -- 英雄转盘
    CivPrestage = 20, -- 文明声望
    CivShop = 21,
    HeroRecruit = 22, --英雄招募
    ShuiJingBox = 23, --水晶宝箱
    ItemExchange = 24, -- 道具兑换
    TreasureShop = 25, --秘境商店
    AuctionHouse = 26, --拍卖行
    MagicDrawView = 27, --魔法屋
    MakexxxReqHelp = 28, --活动中的制作xxx“求助”
    JumpToWorldResource = 29, -- 查找世界资源点 走IFFindResTileCmd消息，默认为查找世界上奇迹资源，其余为自带参数
    JumpToForge = 30, -- 装备锻造
    CrystalRoulette = 31, -- 水晶转盘
    JumpToRepay = 32, -- 累计充值
    HeroRecruitActivity = 33, --英雄招募活动（限时招募）
    AllianceBoss = 34, --联盟Boss
    AvatarStoreFragment = 35, --【Awen】装扮商城碎片页签
    AvatarStoreDiamond = 36, --【Awen】装扮商城钻石页签
    TournamentAddNum = 37, --【tw】竞技场增加次数道具
    NationalWarResource = 38, -- 神秘海域矿产道具，黑白金石
    MateCreate = 39, -- 材料合成界面 -- 2019-10-16 hyp
    KingBiographyRoulette = 40, -- 列王传转盘
    KingBiographyView = 41, -- 列王传界面
    onFestivalMainView = 42, --节日主题活动跳转
    DarkCivListView = 43,--名城跳转
}

-- sourceType 跳转来源，1: 龙语界面跳转，
function ItemGetMethodCell:create(data, param, fromView, sourceType, parent_view)
    local ret = ItemGetMethodCell.new()
    if ret:init(data, param, fromView, sourceType, parent_view) == false then
        return nil
    end
    return ret
end

function ItemGetMethodCell:init(data, param, fromView, sourceType, parent_view)
    MyPrint("ItemGetMethodCell:init ", param)
    --初始化界面
    MyPrint("ItemGetMethodCell init start")
    local proxy = cc.CCBProxy:create()
    local ccbiURL = ""
    ccbiURL = "ccbi/ItemGetMethodCell.ccbi"
    local nodeccb = CCBReaderLoad(ccbiURL, proxy, self)
    if nodeccb == nil then
        MyPrint("ItemGetMethodCell loadccb error")
        return false
    end
    
    self:setContentSize(nodeccb:getContentSize())
    self:addChild(nodeccb)
    registerNodeEventHandler(self)
    
    self.m_data = data
    self.m_itemId = data.id
    self.m_param = param
    self.m_fromView = fromView
    self.m_sourceType = sourceType
    self.parent_view = parent_view
    local pic = CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", self.m_itemId, "icon") .. ".png"
    local spr = nil
    local getType = tonumber(CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", self.m_itemId, "type"))
    
    if getType == ItemGetType.ActivityView then
        local actId = CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", self.m_itemId, "para1")
        local obj = ActivityController:call("getActObj", actId)
        if nil ~= obj then
            local fra = obj:getIconFrame()
            if fra then
                spr = cc.Sprite:createWithSpriteFrame(fra)
            end
        else
            local dypath = cc.FileUtils:getInstance():getWritablePath()
            local path1 = table.concat({dypath, "lua/", actId, "/resources/activity_", actId, "_new.plist"})
            if cc.FileUtils:getInstance():isFileExist(path1) then
                cc.SpriteFrameCache:getInstance():addSpriteFrames(path1)
            end
            spr = CCLoadSprite:call("createSprite", pic)
        end
    else
        spr = CCLoadSprite:call("createSprite", pic)
    end
    
    self.m_picNode:removeAllChildren()
    if spr then
        self.m_picNode:addChild(spr)
        CCCommonUtilsForLua:call("setSpriteMaxSize", spr, 80, true)
    end
    
    local desc = CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", self.m_itemId, "desc")
    local t = string.split(desc, ";")
    local param0 = t[1]
    local param1 = t[2]
    local param2 = t[3]
    local param3 = t[4]
    self.m_titleTxt:setString(getLang(param0, param1, param2, param3))
    CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("164952"))
    
    if getType == 0 then
        local itemId = CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", self.m_itemId, "para1")
        local toolInfo = ToolController:call("getToolInfoForLua", tonumber(itemId))
        if toolInfo == nil then
            self.m_titleTxt:setString("")
            MyPrint("HeroUseItemView getToolInfo fail with itemId "..tostring(self.m_itemId))
        else
            local count = toolInfo:call("getCNT")
            desc = CCCommonUtilsForLua:call("getPropById", tostring(itemId), "name")--50体力
            self.m_titleTxt:setString(getLang(desc) .. "    x" .. count)
            CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("169631"))
            if count <= 0 then
                self.m_getBtn:setEnabled(false)
                self:removeBtnPar(self.m_getBtn)
            else
                self.m_getBtn:setEnabled(true)
                self:addBtnPar(self.m_getBtn)
            end
        end
    end
    
    -- 特殊处理 ItemGetType.ActivityView
    if getType == ItemGetType.ActivityView then
        local actId = CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", self.m_itemId, "para1")
        local obj = ActivityController:call("getActObj", actId)
        if obj then
            CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("164952")) -- 164952=前往
            self.m_getBtn:setEnabled(true)
        else
            CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("101465")) -- 101465=未开启
            self.m_getBtn:setEnabled(false)
        end
    elseif getType == ItemGetType.JumpToRepay then
        require("game.LiBao.Repay.RepayController")
        if RepayController.getInstance():isBegin() then
            CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("164952")) -- 164952=前往
            self.m_getBtn:setEnabled(true)
        else
            CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("101465")) -- 101465=未开启
            self.m_getBtn:setEnabled(false)
        end
        
    elseif getType == ItemGetType.HeroRecruitActivity then -- 英雄限时招募
        local heroName = CCCommonUtilsForLua:getPropById(self.m_param, "title")
        self.m_titleTxt:setString(getLang(param0, param1, param2, param3) .. ":" .. getLang(heroName))
        self.txt_timeDesc:setString(getLang("103073"))-- 103073=敬请期待
        -- endTime
        self.m_countEndTime = 0
        local xmlData = CCCommonUtilsForLua:getGroupByKey("general_draw")
        if xmlData then
            local endTime = 0
            for k, v in pairs(xmlData) do
                if v.activity_type and v.activity_type == "1" and tonumber(v.item_id) == tonumber(self.m_param) then
                    endTime = tonumber(v.end_time)
                    break
                end
            end
            if endTime > 0 then -- 倒计时
                self.m_countEndTime = endTime / 1000
            end
        end
        self:addCountDownUpdater(true)
    elseif getType == ItemGetType.AllianceBoss then
        if CCCommonUtilsForLua:isFunOpenByKey("allianceboss_open") then
            CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("164952")) -- 164952=前往
            self.m_getBtn:setEnabled(true)
        else
            CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("101465")) -- 101465=未开启
            self.m_getBtn:setEnabled(false)
        end
    elseif getType == ItemGetType.TournamentAddNum then
        CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("102137"))
        local isEnable = TournamentControllerInst:hasEnoughAddItem(1)
        self.m_getBtn:setEnabled(isEnable)
    elseif getType == ItemGetType.NationalWarResource then
        self.m_picNode:setScale(0.5)
        if CCCommonUtilsForLua:isFunOpenByKey("ek_war_main") then
            CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("164952")) -- 164952=前往
            self.m_getBtn:setEnabled(true)
        else
            CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("101465")) -- 101465=未开启
            self.m_getBtn:setEnabled(false)
        end
    elseif getType == ItemGetType.MateCreate then -- 2019-10-16 hyp 新增获取途径——材料合成/分解
        CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("164952")) -- 164952=前往
        self.m_getBtn:setEnabled(true)
    end
    
    self:addHelpTime()
    
    if data.use_when_get then
        self:onClickGet()
    end
    return true
end

function ItemGetMethodCell:addBtnPar(btn)
    local tmpStart = "ShowFire_"
    local tmpStart1 = "ShowFireUp_"
    local s9 = CCLoadSprite:call("createScale9Sprite", "sel_general.png")

    local size = btn:getPreferredSize()
    s9:setPreferredSize(CCSize(30 + size.width, 30 + size.height))
    s9:setPosition(CCSize(size.width / 2, size.height / 2))
    s9:setAnchorPoint(ccp(0.05, 0.15))
    s9:setTag(8000)
    btn:addChild(s9)
    for i = 1, 5 do
        local particle = ParticleController:call("createParticle", tmpStart .. i, CCPointZero, size.width * 0.3)
        particle:setPosition(ccp(size.width / 2, -3))
        particle:setPosVar(ccp(size.width / 2, 0))
        particle:setTag(8000 + i * 10 + 1)
        btn:addChild(particle)
        
        local particle1 = ParticleController:call("createParticle", tmpStart .. i, CCPointZero, size.width * 0.3)
        particle1:setPosition(ccp(size.width / 2, size.height - 3))
        particle1:setPosVar(ccp(size.width / 2, 0))
        particle1:setTag(8000 + i * 10 + 2)
        btn:addChild(particle1)
        
        local particle2 = ParticleController:call("createParticle", tmpStart1 .. i, CCPointZero, size.height * 0.3)
        particle2:setPosition(ccp(0, size.height / 2))
        particle2:setPosVar(ccp(0, size.height / 2))
        particle2:setTag(8000 + i * 10 + 3)
        btn:addChild(particle2)
        
        local particle3 = ParticleController:call("createParticle", tmpStart1 .. i, CCPointZero, size.height * 0.3)
        particle3:setPosition(ccp(size.width, size.height / 2))
        particle3:setPosVar(ccp(0, size.height / 2))
        particle3:setTag(8000 + i * 10 + 4)
        btn:addChild(particle3)
    end
end

function ItemGetMethodCell:removeBtnPar(btn)
    local nodeBg = btn:getChildByTag(8000)
    if nodeBg then
        btn:removeChild(nodeBg, true)
    end
    
    for i = 1, 5 do
        for j = 1, 4 do
            local node = btn:getChildByTag(8000 + i * 10 + j)
            if node then
                btn:removeChild(node, true)
            end
        end
    end
end

function ItemGetMethodCell:updateHelpTime(dt)
    if self:isHelpItem() then
        if self:isCanReqHelp() then
            self:addHelpTimeUpdater(false)
            self.nodeHelpTime:setVisible(false)
            CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("4249715"))
        else
            if not self.nodeHelpTime:isVisible() then
                self.nodeHelpTime:setVisible(true)
                CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, "")
            end
            local lastReqHelpTime = cc.UserDefault:getInstance():getIntegerForKey(gtblTimeoutKey.makeXXXReqHelp, 0)
            local worldTime = getWorldTime()
            local difTime = worldTime - lastReqHelpTime
            self.m_timeLabel:setString(format_time(FestalActMakexxxCtl.minReqHelpIntervalTime - difTime))
        end
    end
end

function ItemGetMethodCell:addCountDownUpdater(flag)
    Dprint("addCountDownUpdater ", flag, self.m_countEndTime)
    if self.m_entryCountDownId then
        self:getScheduler():unscheduleScriptEntry(self.m_entryCountDownId)
        self.m_entryCountDownId = nil
    end
    if not flag then
        self.m_countEndTime = 0
    end
    local difTime = self.m_countEndTime - getTimeStamp()
    if difTime > 0 then -- 倒计时
        self.node_updateCountDown:setVisible(true)
        self.m_titleTxt:setPositionY(self.m_titleTxt:getPositionY() + deltaPosY)
        self.m_entryCountDownId = self:getScheduler():scheduleScriptFunc(function(dt) self:updateCountDown(dt) end, 1.0, false)
    end
    self:updateCountDown(0)
end

function ItemGetMethodCell:updateCountDown(dt)
    local difTime = self.m_countEndTime - getTimeStamp()
    Dprint("updateCountDown difTime", difTime, format_time(difTime))
    if difTime > 0 then -- 倒计时
        self.txt_timeCountDown:setString(format_time(difTime))
    else
        self.txt_timeDesc:setVisible(true)
        self.m_getBtn:setVisible(false)
        self.node_updateCountDown:setVisible(false)
        self.m_titleTxt:setPositionY(originPosY)
    end
end

function ItemGetMethodCell:isCanReqHelp()
    return getTimeoutForKey(gtblTimeoutKey.makeXXXReqHelp, FestalActMakexxxCtl.minReqHelpIntervalTime)
end

function ItemGetMethodCell:onEnter()
    if self:isHelpItem() then
        if self:isCanReqHelp() then
            self:addHelpTimeUpdater(false)
            CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, getLang("4249715"))
        else
            CCCommonUtilsForLua:call("setButtonTitle", self.m_getBtn, "")
            self:addHelpTimeUpdater(true)
        end
    end
end

function ItemGetMethodCell:onExit()
    self:addHelpTimeUpdater(false)
    self:addCountDownUpdater(false)
end

function ItemGetMethodCell:addHelpTimeUpdater(bAdd)
    if self.m_entryId then
        self:getScheduler():unscheduleScriptEntry(self.m_entryId)
        self.m_entryId = nil
    end
    if bAdd then
        self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:updateHelpTime(dt) end, 1.0, false)
        self:updateHelpTime()
    end
end

function ItemGetMethodCell:addHelpTime()
    if self:isHelpItem() then
        if self.nodeHelpTime then
            self.nodeHelpTime:removeAllChildren()
        else
            self.nodeHelpTime = cc.Node:create()
            self.m_getBtn:addChild(self.nodeHelpTime)
            local size = self.m_getBtn:getContentSize()
            self.nodeHelpTime:setPosition(size.width / 2, size.height / 2)
        end
        local label = cc.Label:createWithSystemFont(itmeName, "Helvetica", 22, cc.size(0.0, 0))
        self.nodeHelpTime:addChild(label)
        self.m_timeLabel = label
    end
end

--活动中的“求助”
function ItemGetMethodCell:isHelpItem()
    return (self.m_data.type == tostring(ItemGetType.MakexxxReqHelp)) and (self.m_data.para1 == "208")
end

function ItemGetMethodCell:onClickGet()
    local flag = PopupViewController:call("isLastLevel4PopupView")
    self:onClickGetExtra()
    -- 当前弹出框为半屏幕弹出框
    -- 最后打开的弹出框为全屏弹出框
    if flag and (not PopupViewController:call("isLastLevel4PopupView")) then
        -- 移除所有半屏弹出框
        PopupViewController:call("removeLevel4PopupView")
    end
end

--main: 0, 1
--sub: 1,2,3,4,5
function ItemGetMethodCell:openBagViewEx(main, sub)
    MyPrint(main, sub, self.m_itemId, "main,sub+++")
    main = main or 0
    sub = sub or 5
    LuaController:call("openBagView", main)
    local para1 = CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", self.m_itemId, "para1")
    dump(para1, "para1+++")
    if para1 and para1 ~= "" then
        sub = para1
    end
    MyPrint(self.m_data.itemIdWanted, para1, "itemIdWanted+++")
    local dict = CCDictionary:create()
    dict:setObject(CCString:create(tostring(main)), 'main')
    dict:setObject(CCString:create(tostring(sub)), 'sub')
    dict:setObject(CCString:create(self.m_data.itemIdWanted), 'highLightItem')
    CCSafeNotificationCenter:postNotification("MSG_CHANGE_BAG_VIEW", dict)
end

function ItemGetMethodCell:onClickGetExtra()
    MyPrint("ItemGetMethodCell:onClickGet ", self.m_itemId)
    local getType = tonumber(CCCommonUtilsForLua:call("getPropById", self.m_itemId, "type"))
    local popViewName = ""
    local beCloseSelf = false
    if getType == ItemGetType.GoldExchange then
        popViewName = "GoldExchangeView_NEW";
    elseif getType == ItemGetType.DragonTower then
        local buildId = FunBuildController:call("getMaxLvBuildByType", 432000)
        if buildId == 0 then
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("169042"))
            return
        end
        
        PopupViewController:call("removeAllPopupView")
        FunBuildController:call("moveToBuildByBuildType", 432000)
    elseif getType == ItemGetType.Activity then
        PopupViewController:call("removeAllPopupView")
        ActivityController:call("openActivityView")
    elseif getType == ItemGetType.Merchant then
        local mainCityLv = FunBuildController:call("getMainCityLv")
        if mainCityLv < 6 then
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("169042"))
            return
        end
        
        popViewName = "MerchantView"
    elseif getType == ItemGetType.Store then
        self.parent_view:closeSelf()
        -- PopupViewController:call("removeAllPopupView")
        -- LuaController:call("openBagView", 1)
        self:openBagViewEx(1, nil)
        return
    elseif getType == ItemGetType.DragonExplore then
        if CCCommonUtilsForLua:isFunOpenByKey("dragon_lua") then
            PopupViewController:call("removeAllPopupView")
            local dragonInfo = DragonController:call("getActiveDragonInfo")
            if dragonInfo == nil then
                return
            end
            if CCCommonUtilsForLua:isFunOpenByKey("dragon_new_ui_switch") then
                local view = Drequire("game.NewDragon.NewDragon_V2.DragonListNewView"):create()
                PopupViewController:call("addPopupInView", view)
                if nil ~= view then
                    view:openDragonViewByUuid(dragonInfo:call("getUuid"), dragonInfo:call("getBaseId"))
                end
            else
                local DragonCave_New = Drequire("game.NewDragon.DragonCave_New")
                local view = DragonCave_New:create({uuid = dragonInfo:call("getUuid")})
                PopupViewController:call("addPopupInView", view)
            end
            return
        else
            popViewName = "DragonIntimacyView"
        end
    elseif getType == ItemGetType.HeroBuyFragment then
        MyPrint("self.m_param ", self.m_param)
        -- 参数有两种类型
        -- 1.纯数值 heroId
        -- 2.表结构 {heroId, needNum}
        local param1 = nil
        local param2 = nil
        if type(self.m_param) == "table" then
            param1 = self.m_param.heroId
            param2 = self.m_param.needNum
        else
            param1 = self.m_param
        end
        PopupViewController:call("removeLastPopupView")
        package.loaded["game.hero.HeroBuyFragmentView"] = nil
        local HeroBuyFragmentView = require("game.hero.HeroBuyFragmentView")
        local useItemView = HeroBuyFragmentView:create(param1, param2)
        PopupViewController:addPopupInView(useItemView)
    elseif getType == ItemGetType.JumpToBuild then
        local data = self.m_data
        PopupViewController:call("removeAllPopupView")
        local speBuild = false
        if data.para2 == "1" then
            speBuild = true
        end
        FunBuildController:call("moveToBuildByBuildType", tonumber(data.para1), speBuild)
    elseif getType == ItemGetType.OpenDailyActivity then
        PopupViewController:call("removeAllPopupView")
        if CCCommonUtilsForLua:isFunOpenByKey("new_daily_active_switch") then
            local view = Drequire("game.NewDailyActive.NewDailyActiveFrameView"):create()
            PopupViewController:addPopupInView(view)
        else
            local view = Drequire("game.Tavern.DailyActiveView"):create()
            PopupViewController:addPopupInView(view)
        end
        
    elseif getType == ItemGetType.JumpToWorld then
        local itemId = self.itemId
        
        local function findBuild()
            local buildType = CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", tostring(itemId), "para1")
            if buildType and buildType ~= "" then
                local level = CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", tostring(itemId), "para2")
                if not level or level == "" then
                    local key = "FindResTile_";
                    key = key..CC_ITOA(buildType);
                    level = cc.UserDefault:getInstance():getIntegerForKey(key, 1);
                end
                local cmd = Drequire("game.command.IFFindResTileCmd").create(tonumber(buildType), tonumber(level or 1))
                cmd:send()
            end
        end
        
        PopupViewController:call("removeAllPopupView")
        -- 世界
        if SceneController:call("getCurrentSceneId") ~= 11 then
            require("game.CommonPopup.CommonEventController"):once("msgSceneChangeFinish", function ()
                if SceneController:call("getCurrentSceneId") == 11 then
                    findBuild()
                end
            end)
            SceneController:call("gotoScene", 11)
        else
            findBuild()
        end
    elseif getType == ItemGetType.OpenHeroTowerHomeView then
        if CCCommonUtilsForLua.isHeroChallengeOpen() then
            popViewName = "HeroTowerHomeView"
        else
            -- 169042=该功能暂未开启，敬请期待
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("169042"))
        end
    elseif getType == ItemGetType.DragonBag then
        if CCCommonUtilsForLua:call("isFunOpenByKey", "dragon_friendship") then
            PopupViewController:call("removeLastPopupView")
            popViewName = "DragonBagView"
        else
            -- 169042=该功能暂未开启，敬请期待
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("169042"))
        end
    elseif getType == ItemGetType.AllianceTreasure then
        if CCCommonUtilsForLua:call("isKuaFu") then
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("102531"))
            return
        end
        
        local mycitylv = FunBuildController:call("getMainCityLv")
        local limit = AllianceDailyController:call("getInstance"):getProperty("conditionPublishLevel")
        if limit and mycitylv < limit then
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("134068", tostring(limit)))
            return
        end
        beCloseSelf = true
        popViewName = "AllianceDailyPublishView"
    elseif getType == ItemGetType.AllianceQuest then
        beCloseSelf = true
        popViewName = "AllianceQuestView"
    elseif getType == ItemGetType.StoreBagView then
        -- PopupViewController:call("removeAllPopupView")
        beCloseSelf = true
        -- LuaController:call("openBagView", 0)
        self:openBagViewEx(0, nil)
    elseif getType == ItemGetType.ActivityView then
        local actId = CCCommonUtilsForLua:call("getPropById", tostring(self.m_itemId), "para1")
        local obj = ActivityController:call("getActObj", actId)
        if nil == obj then
            -- 176074=活动暂未开启
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("176074"))
        else
            beCloseSelf = true
            -- PopupViewController:call("removeAllPopupView")
            -- ActivityController:call("shouActUIById", actId)
            ActivityController.getInstance():shouActUIById(actId)
        end
    elseif getType == ItemGetType.AllianceShop then
        local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
        local hasAlliance = playerInfo:call("isInAlliance")
        if hasAlliance then
            beCloseSelf = true;
            popViewName = "AllianceShopView"
        else
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("132360"))
        end
    elseif getType == ItemGetType.KingdomLiBao then
        PopupViewController:call("removeAllPopupView")
        local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
        local serverId = playerInfo:getProperty("selfServerId")
        local dict = CCDictionary:create()
        dict:setObject(CCString:create("KingsGiftView"), "name")
        dict:setObject(CCString:create(tostring(serverId)), "serverId")
        LuaController:call("openPopViewInLua", dict)
        return
    elseif getType == ItemGetType.HeroGetRolate then
        if CCCommonUtilsForLua:isFunOpenByKey("hero_roulette") then
            PopupViewController:call("removeAllPopupView")
            local prlvPath = "game.hero.NewUI.HeroGetRotateView"
            local view = Drequire(prlvPath)
            PopupViewController:call("addPopupInView", view:create("89699", "hero_type"))
        end
    elseif getType == 0 then
        local itemId = tonumber(CCCommonUtilsForLua:call("getPropById", tostring(self.m_itemId), "para1"))
        if itemId == 200380 or itemId == 213739 then
            local dict = CCDictionary:create()
            dict:setObject(CCString:create("ToolNumSelectView"), "name")
            dict:setObject(CCString:create(tostring(itemId)), "itemId")
            dict:setObject(CCString:create(tostring(0)), "opFrom")
            dict:setObject(CCString:create(""), "targetId")
            LuaController:call("openPopViewInLua", dict)
        else
            ToolController:call("useTool", itemId, 1, true, false)
        end
    elseif getType == ItemGetType.CivPrestage then
        PopupViewController:call("removeAllPopupView")
        local CivilizationDonateView = Drequire("game.civilization.prestige.CivilizationDonateView")
        local view = CivilizationDonateView:create()
        PopupViewController:addPopupInView(view, true)
        return
    elseif getType == ItemGetType.CivShop then
        PopupViewController:call("removeAllPopupView")
        local view = myRequire("game.civilization.prestige.CivilizationShopView").create()
        PopupViewController:addPopupInView(view)
        return
    elseif getType == ItemGetType.HeroRecruit or getType == ItemGetType.HeroRecruitActivity then
        -- PopupViewController:call("removeAllPopupView")
        self.parent_view:closeSelf()
        local view = Drequire("game.hero.LuckDraw.HeroLuckDrawView").create()
        PopupViewController:addPopupInView(view)
        return
    elseif getType == ItemGetType.ShuiJingBox then
        -- dump("hanxiao12345 in open ShuiJingBox")
        LogController:call("getInstance"):call("postEventLog", "shuijing")
        
        local dict = CCDictionary:create()
        dict:setObject(CCString:create(USE_TOOL_SHUIJING), "type")
        dict:setObject(CCString:create("138523"), "title")
        CCSafeNotificationCenter:call("postNotification", "ItemGetMethodView_closeself")
        local view = Drequire("game.CommonPopup.UseToolView"):create(USE_TOOL_SHUIJING, dict, "138523")
        PopupViewController:addPopupInView(view)
        return
    elseif getType == ItemGetType.ItemExchange then
        local lua_path = "game.store.BagExchangeView"
        package.loaded[lua_path] = nil
        require(lua_path)
        local itemId = CCCommonUtilsForLua:call("getPropById", self.m_itemId, "para1")
        MyPrint("go to more for itemid = ", itemId, "and self = ", self.parent_view)
        local view = BagExchangeView:create(itemId)
        if view == nil then
            MyPrint("BagExchangeView is nil ")
        end
        PopupViewController:addPopupInView(view)
        PopupViewController:call("removePopupView", self.parent_view)
        PopupViewController:call("removePopupView", self.m_fromView)
        return
    elseif getType == ItemGetType.TreasureShop then
        if CCCommonUtilsForLua:isFunOpenByKey("treasure_fam_on_1") then
            CCSafeNotificationCenter:call("postNotification", "ItemGetMethodView_closeself")
            TreasureFamManager:getTreasureFamInfo()
            local view = Drequire("game.TreasureFam.TreasureFamShopView"):create()
            PopupViewController:addPopupInView(view)
        else
            LuaController:flyHint("", "", getLang("E100008"))
        end
        return
    elseif getType == ItemGetType.AuctionHouse then
        if not CCCommonUtilsForLua:isFunOpenByKey("auction") then
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("169042")) --活动未开启
            return
        end
        local cross = GlobalData:call("getPlayerInfo"):getProperty("crossFightSrcServerId")
        if cross and cross ~= -1 then
            if cross then dump(cross, "cross+++") end
            CCCommonUtilsForLua:call("flyHint", "", "", getLang("9440926")) --跨服状态,不能开启拍卖行
            return
        end
        --先获取数据，活动不开启，inActivity=0
        CCSafeNotificationCenter:call("postNotification", "ItemGetMethodView_closeself")
        AuctionHouseController:pullAuctionHouseViewData()
        return
    elseif getType == ItemGetType.MagicDrawView then
        CCSafeNotificationCenter:call("postNotification", "ItemGetMethodView_closeself")
        if CCCommonUtilsForLua:isFunOpenByKey("magic_skill") then
            local poolIndex = atoi(CCCommonUtilsForLua:call("getPropById", tostring(self.m_itemId), "para1"))
            local cardIndex = atoi(CCCommonUtilsForLua:call("getPropById", tostring(self.m_itemId), "para2"))
            local view = Drequire("game.magic.LuckDraw.MagicLuckDrawView"):create(cardIndex, poolIndex)
            PopupViewController:call("addPopupInView", view)
        end
        return
    elseif getType == ItemGetType.MakexxxReqHelp then
        if self:isHelpItem() then
            if self:isCanReqHelp() then
                self:addHelpTimeUpdater(false)
                setTimeoutForKey(gtblTimeoutKey.makeXXXReqHelp, false)
                self.parent_view:closeSelf()
                CCSafeNotificationCenter:call("postNotification", MSG_MAKE_XXX_REQ_HELP)
                LuaController:flyHint("", "", getLang("4249724")) -- 4249724=求助成功，在联盟聊天中查看
            else
                LuaController:flyHint("", "", getLang("4249726"))
            end
        end
    elseif getType == ItemGetType.JumpToWorldResource then
        PopupViewController:call("removeAllPopupView")
        if self.m_param == nil then
            self.m_param = {}
        end
        local cmd = Drequire("game.command.IFFindResTileCmd").create(self.m_param.buildType or 9, self.m_param.level or 1)
        cmd:send()
        return
    elseif getType == ItemGetType.JumpToForge then
        local vipView = Drequire("game.equipment.NewEquip.NewEquipMainView"):create()
        PopupViewController:addPopupInView(vipView)
    elseif getType == ItemGetType.CrystalRoulette then
        local view = Drequire("game.hero.NewUI.HeroGetRotateView"):create("89698", "crystal_type")
        PopupViewController:call("addPopupInView", view)
        self.parent_view:closeSelf()
    elseif getType == ItemGetType.JumpToRepay then
        require("game.LiBao.Repay.RepayController")
        if RepayController.getInstance():isBegin() then
            RepayController.getInstance():fireEvent("RepayViewCreate")
            self.parent_view:closeSelf()
        end
    elseif getType == ItemGetType.AllianceBoss then
        PopupViewController:call("addPopupInView", myRequire("game.allianceBoss.AllianceBossView").create())
        self.parent_view:closeSelf()
    elseif getType == ItemGetType.AvatarStoreFragment then --【Awen】装扮商城碎片页签
        PopupViewController:call("removeAllPopupView")
        local AvatarViewEx = Drequire("game.avatar.AvatarViewEx")
        local view = AvatarViewEx.create(AvatarType_MysteryPiece)
        PopupViewController:call("addPopupInView", view)
        self.parent_view:closeSelf()
    elseif getType == ItemGetType.AvatarStoreDiamond then --【Awen】装扮商城钻石页签
        PopupViewController:call("removeAllPopupView")
        local AvatarViewEx = Drequire("game.avatar.AvatarViewEx")
        local view = AvatarViewEx.create(AvatarType_Diamond)
        PopupViewController:call("addPopupInView", view)
        self.parent_view:closeSelf()
    elseif getType == ItemGetType.TournamentAddNum then
        TournamentControllerInst:requestAddFightNum()
    elseif getType == ItemGetType.NationalWarResource then
        PopupViewController:call("removeAllPopupView")
        local view = Drequire("game.NationalWar.NationalWarMainView"):create()
        PopupViewController:call("addPopupInView", view)
        self.parent_view:closeSelf()
    elseif getType == ItemGetType.MateCreate then -- 2019-10-16 hyp 新增获取途径——材料合成/分解
        local info = ToolController:call("getToolInfoByIdForLua", tonumber(self.m_data.itemIdWanted))
        local color = atoi(info:getProperty("color"))
        local realItemId = 0
        if color > 0 then -- 0 = WHITE
            realItemId = self.m_data.itemIdWanted - 1
        else
            realItemId = self.m_data.itemIdWanted
        end
        
        local dict = CCDictionary:create()
        dict:setObject(CCString:create("MateCreateView"), "name")
        dict:setObject(CCString:create(tostring(realItemId)), "itemId")
        dict:setObject(CCString:create("0"), "type")
        dict:setObject(CCString:create("0"), "count")
        dict:setObject(CCString:create("0"), "nextCount")
        LuaController:call("openPopViewInLua", dict)
    elseif getType == ItemGetType.KingBiographyRoulette then
        require("game.activity.KingBiography.KingBiographyController").createKingBiographyRotate()
    elseif getType == ItemGetType.KingBiographyView then
        require("game.activity.KingBiography.KingBiographyController").createKingBiographyView()
    elseif getType == ItemGetType.onFestivalMainView then
        local festivalId = CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", self.m_itemId, "para1")
        local actId = CCCommonUtilsForLua:call("getPropByIdGroup", "staff_get_method", self.m_itemId, "para2")
        local festivalCtl = require("game.FestivalActivities.FestivalActivitiesController").getInstance()
        if festivalCtl:isFestivalActivityOpenById(festivalId,actId) then
            PopupViewController:call("removeAllPopupView")        
            require("game.FestivalActivities.FestivalActivitiesHelper").openFestivalView(festivalId, actId)
            return
        else
            LuaController:flyHint("", "", getLang("10200044"))
        end  
    elseif getType == ItemGetType.DarkCivListView then
        -- 跳转到名城列表
        local view = Drequire("game.darkCivilization.DarkCivListView"):create(0)
        PopupViewController:call("addPopupView", view)
        self.parent_view:closeSelf()      
    end
    
    if popViewName ~= "" then
        if beCloseSelf then
            self.parent_view:closeSelf()
        else
            if self.m_fromView == "DragonInfo_New" then
                PopupViewController:call("removeLastPopupView")
            else
                PopupViewController:call("removeAllPopupView")
            end
        end
        local dict = CCDictionary:create()
        dict:setObject(CCString:create(popViewName), "name")
        LuaController:call("openPopViewInLua", dict)
    end
    
    if self.m_sourceType and tostring(self.m_sourceType) ~= "" then
        local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
        local uid = playerInfo:getProperty("uid")
        
        LogController:postEventLog("itmeGetMethodShow_leaveTo", {time = getWorldTime(), UID = uid, sourceType = self.m_sourceType, btnId = getType})
    end
    
end

return ItemGetMethodCell, ItemGetType
------------------------------------------ ItemGetMethodCell End --------------------------------------------
