-- 加速界面，应用于各种加速场景
local UseMultySpeedView = class("UseMultySpeedView", function()
    return PopupBaseView:create()
end
)
UseMultySpeedView.__index = UseMultySpeedView

require "game.ImperialScene.ImperialSceneLuaManager"

local UseSpeedTag = {
    Building = 0,       -- 建筑
    Science = 1,      -- 学院
    HighTech = 2,       -- 贤者
    Hospital = 3,       -- 医疗
    Fort = 4,     -- 陷阱
    Soldier = 5,       -- 造兵
    UpStar = 6,       -- 升星
    Glory6 = 7,       -- 荣6造兵
    Tactical = 8,     --阵法研习
    Forging = 9,      --锻造
    RaceScience = 10, --先祖之魂
    Extension = 11, --扩建
    Armament = 12,--军械制造
    ArmyReform = 13,--士兵改造
}

local SPECIALGOODSTBL = "specialGoodsTbl"
local COMMONGOODSTBL = "commonGoodsTbl"
local touchDelta = 100
------------------------------------------ UseMultySpeedView Start --------------------------------------------
function UseMultySpeedView:create(useTag, timeCost, qid, speedTypeId)
    dump(useTag,"UseMultySpeedView:create")
    local view = UseMultySpeedView.new()
    Drequire("game.CommonPopup.UseMultySpeedView_ui"):create(view, 0)
    if view:initView(useTag, timeCost, qid, speedTypeId) == false then
        return nil
    end
    return view
end

function UseMultySpeedView:initView(useTag, timeCost, qid, speedTypeId)
    registerTouchHandler(self)
    self:setTouchEnabled(true)

    self.m_useTag = tonumber(useTag)
    self.m_timeCost = tonumber(timeCost)
    self.v_qid = qid
    self.m_speedTypeId = speedTypeId or ""
    Dprint("UseMultySpeedView , m_useTag, m_timeCost, m_speedTypeId ", self.m_useTag, self.m_timeCost, self.m_speedTypeId)

    self.m_multySpeedType = "0"
    self.m_containCommon = false
    self.m_controller = require("game.controller.MultySpeedController").getInstance()
    self:initUI()
    self:refreshData()
    return true
end

function UseMultySpeedView:onAndroidKeyBack(  )
    self:onNoButtonClick()
end

function UseMultySpeedView:onEnter()
    dump("UseMultySpeedView:onEnter")
    registerScriptObserver(self, self.onAndroidKeyBack, "msg.notify.keyBack.Clicked")
end

function UseMultySpeedView:onExit()
    unregisterScriptObserver(self, "msg.notify.keyBack.Clicked")
end

function UseMultySpeedView:onTouchBegan(x, y)
    self.touchType = 1
    self.m_startTouchPt = cc.p(x, y)
    return true
end

function UseMultySpeedView:onTouchMoved(x, y)
    if self.touchType == 1 then
        if ccpSquareDistance(self.m_startTouchPt, cc.p(x, y)) > touchDelta then
            self.touchType = 0
        end
    end
end

function UseMultySpeedView:onTouchEnded(x, y)
    if not isTouchInside(self.ui.m_touchNode, x, y) and self.touchType == 1 then
        self:onNoButtonClick()
    end
end

function UseMultySpeedView:getMultyGoodsContainTime(multyType)
    Dprint("UseMultySpeedView:getMultyGoodsContainTime", multyType, self.m_useTag, CCCommonUtilsForLua:isFunOpenByKey("use_multy_speed_v2"))
    local allTimeStr = ""
    local goodsParaStr = ""

    if not CCCommonUtilsForLua:isFunOpenByKey("use_multy_speed_v2") then
        if multyType == 0 then
            allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Building
            goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Building
        elseif multyType == 1 then
            allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Science
            goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Science
        elseif multyType == 2 then
            allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Hightech
            goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Hightech
        elseif multyType == 3 then
            allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Hospital
            goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Hospital
        elseif multyType == 4 then
            allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Fort
            goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Fort
        elseif multyType == 5 then
            allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Soldier
            goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Soldier
        elseif multyType == 6 then
            allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_UpStar
            goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_UpStar
        elseif multyType == 7 then
            allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Glory6
            goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Glory6
        elseif multyType == 8 then
            allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Tactical
            goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Tactical
        elseif multyType == UseSpeedTag.Forging then
            allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Forging
            goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Forging
        elseif multyType == UseSpeedTag.RaceScience then
            allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_RaceScience
            goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_RaceScience  
        elseif multyType == UseSpeedTag.Extension then
            allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Extension
            goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Extension 
        elseif multyType == UseSpeedTag.Armament then
            allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_Armament
            goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_Armament
        elseif multyType == UseSpeedTag.ArmyReform then
            allTimeStr = ImperialSceneLuaManager.getInstance().use_multy_speed_ArmyReform
            goodsParaStr = ImperialSceneLuaManager.getInstance().use_multy_goods_ArmyReform
        end
    else
        --queueType -- items
        local finalQueueType = ToolController:getfinalQueueType(self.m_useTag)
        local queueSpeed = CCCommonUtilsForLua:getGroupByKey("queueSpeed")
        for k,v in pairs(queueSpeed) do
            if tonumber(v.queueType) == finalQueueType then
                allTimeStr = v.items
                break
            end
        end

    end
    dump(allTimeStr, "allTimeStrallTimeStr")
    local tempTbl = string.split(allTimeStr, ";")-- 211525;211524;211523;200254;200253;200216;200252

    if CCCommonUtilsForLua:isFunOpenByKey("use_multy_speed_v2") and 
        (self.m_useTag == 0 or self.m_useTag == 6) 
        then
        --建筑有免费加速
        table.insert(tempTbl,0)
    end
    local goodsParaTbl = {}
    if goodsParaStr ~= "" then
        goodsParaTbl = string.split(goodsParaStr, ";")
    end
    local allTime = 0
    local commonGoodsTbl = {}
    local specialGoodsTbl = {}
    local freeGoodsTbl = {}
    local allGoodsTbl = {}
    for i,v in ipairs(tempTbl) do
        if tonumber(v) == 0 then
            --免费加速
        --填充table
            local tempAllTimeTbl = {}
            tempAllTimeTbl["itemId"] = 0
            tempAllTimeTbl["itemNum"] = 1
            tempAllTimeTbl["timeCost"] =  GlobalData:call("shared"):getProperty("freeSpdT") 
            table.insert(freeGoodsTbl, tempAllTimeTbl) 
            allTime = allTime + tempAllTimeTbl["timeCost"]        
            
        end
        local tinfo = ToolController:call("getToolInfoByIdForLua", tonumber(v))
        if tinfo and tinfo:call("getCNT") > 0 then
            local cnt = tinfo:call("getCNT")
            local goodsType = CCCommonUtilsForLua:call("getPropByIdGroup", "goods", tostring(v), "type")
            local tempPara = CCCommonUtilsForLua:call("getPropByIdGroup", "goods", tostring(v), "para")-- 1;1;28800
            if cnt > 0 and tonumber(goodsType) == 2 and tempPara then 
                local paraTbl = string.split(tempPara, ";")
                if not paraTbl or #paraTbl ~= 3 then
                    -- 如果配置错误，直接返回
                    return false
                end
                -- 判断道具具体类型：”专有加速“或者”普通加速“
                local isParasContainType = false
                if CCCommonUtilsForLua:isFunOpenByKey("use_multy_speed_v2") then
                    isParasContainType = true
                else
                    for k,v in pairs(goodsParaTbl) do
                        if v == paraTbl[1] then -- 道具具体类型
                            isParasContainType = true
                            break
                        end
                    end
                end
                if isParasContainType then
                    allTime = allTime + tonumber(paraTbl[3]) * cnt

                    --填充table
                    local tempAllTimeTbl = {}
                    tempAllTimeTbl["itemId"] = v
                    tempAllTimeTbl["itemNum"] = cnt
                    tempAllTimeTbl["timeCost"] = paraTbl[3]
                    tempAllTimeTbl["para1"] = paraTbl[1]
                    if CCCommonUtilsForLua:isFunOpenByKey("use_multy_speed_v2") then
                        if tonumber(paraTbl[1]) > 1 then
                            table.insert(specialGoodsTbl, tempAllTimeTbl)
                        else
                            table.insert(commonGoodsTbl, tempAllTimeTbl)
                        end
                    else
                        table.insert(allGoodsTbl, tempAllTimeTbl)
                    end
                    
                end
            end
        end
    end
    --排序规则：先按照时间降序排列，再按照具体加速类型降序排列，专有加速类型大于普通加速类型
    if CCCommonUtilsForLua:isFunOpenByKey("use_multy_speed_v2") then
        function sortById( a,b )
            return tonumber(a.timeCost) > tonumber(b.timeCost)
        end
        table.sort(specialGoodsTbl,sortById)
        table.sort(commonGoodsTbl,sortById)
        local allTimeTbl = {}
        allTimeTbl[SPECIALGOODSTBL] = specialGoodsTbl
        allTimeTbl[COMMONGOODSTBL] = commonGoodsTbl
        allTimeTbl["free"] = freeGoodsTbl

        Dprint("cjy allTime ", allTime)
        return allTime, allTimeTbl
    else
        table.sort(allGoodsTbl, function(a, b)
            if tonumber(a.timeCost) > tonumber(b.timeCost) then
                return true
            elseif tonumber(a.timeCost) == tonumber(b.timeCost) and tonumber(a.para1) > tonumber(b.para1) then
                return true
            else
                return false
            end
        end)
        return allTime, allGoodsTbl
    end
end

function UseMultySpeedView:getDecSpeedGoodsTbl(multyType, needTime)
    Dprint(needTime, "cjy needTime")
    -- 时间小于0
    if needTime <= 0 then
        Dprint("needTime is less than 0 ")
        return nil
    end

    local allTime ,allTimeTbl = self:getMultyGoodsContainTime(multyType)

     
       dump(allTimeTbl,"allTimeTbl-------")
    --找不到需要的加速道具
    if nil == allTimeTbl then
        Dprint("can not find goods with multyType ")
        return nil
    end
    -- 道具时间少于需要时间
    if needTime > allTime then 
        Dprint("goods time is less than need time  ", allTime, needTime)
        return nil

    elseif needTime == allTime then
        -- 全部覆盖
        if CCCommonUtilsForLua:isFunOpenByKey("use_multy_speed_v2") then
            return allTimeTbl[SPECIALGOODSTBL], allTimeTbl[COMMONGOODSTBL],allTimeTbl["free"]
        else
            return allTimeTbl
        end
    end

    local nowNeedTbl = {}
    local finalNeedTbl = nil
    if CCCommonUtilsForLua:isFunOpenByKey("use_multy_speed_v2") then
        --是否能使用免费道具
        local freetime = 0
        if allTimeTbl["free"] and  #allTimeTbl["free"] > 0 then
             for i,v in ipairs(allTimeTbl["free"]) do
                 freetime = freetime + tonumber(v.timeCost) * tonumber(v.itemNum)
             end
        end     

        local specialAllTime = 0
        for k,v in pairs(allTimeTbl[SPECIALGOODSTBL]) do
            local tinfo = ToolController:call("getToolInfoByIdForLua", tonumber(v.itemId))
            if tinfo and tinfo:call("getCNT") > 0 then
                specialAllTime = specialAllTime + tonumber(v.timeCost) * tonumber(v.itemNum)
            end
        end
        -- 如果specialTbl足够，全部用特殊道具
        if needTime <= freetime then
            return {}, {},allTimeTbl["free"]  
        elseif needTime <= specialAllTime + freetime then
            nowNeedTbl = allTimeTbl[SPECIALGOODSTBL]
            needTime = needTime - freetime
        else
            -- 否则用普通道具
            self.m_containCommon = true
            nowNeedTbl = allTimeTbl[COMMONGOODSTBL]
            finalNeedTbl = allTimeTbl[SPECIALGOODSTBL]
            needTime = needTime - specialAllTime - freetime

        end
    else
        nowNeedTbl = allTimeTbl
    end

    --选出起始值
    local nowIndex = 0
    for k,v in pairs(nowNeedTbl) do
        --遍历时间，筛选数据
        if tonumber(v.timeCost) <= needTime then
            nowIndex = k
            break
        end
    end

    local maxIndex = #nowNeedTbl    
    local speedGoodsTbl = {}
    if nowIndex > 1 then
        --能找到中间的起始值，判断用低等加速是否满足条件
        local checkNum = 0
        for i=nowIndex,maxIndex do
            checkNum = checkNum + tonumber(nowNeedTbl[i].timeCost) * tonumber(nowNeedTbl[i].itemNum)
        end
        if checkNum < needTime then
            --取上限
            local lastGoodsTbl = nowNeedTbl[nowIndex - 1]
            return finalNeedTbl, self:getDecSpeedGoodsMapForOneSpecial(nowNeedTbl, speedGoodsTbl, tonumber(lastGoodsTbl.timeCost)),allTimeTbl["free"]
        end
    elseif nowIndex == 0 then
        -- 所需时间极小，直接取最后一个道具
        local lastGoodsTbl = nowNeedTbl[maxIndex]
        return finalNeedTbl, self:getDecSpeedGoodsMapForOneSpecial(nowNeedTbl, speedGoodsTbl, tonumber(lastGoodsTbl.timeCost)),allTimeTbl["free"]
    end

    -- 遍历填充speedGoodsTbl
    while needTime > 0 and nowIndex <= maxIndex do
        local nowTbl = nowNeedTbl[nowIndex]
        local goodsId = nowTbl.itemId
        local goodsNum = tonumber(nowTbl.itemNum)
        local goodsTimeCost = tonumber(nowTbl.timeCost)
        local needNum = math.floor(needTime / goodsTimeCost)
        -- 不能超过拥有的最大数量
        if needNum > goodsNum then
            needNum = goodsNum
        end
        if needNum > 0 then
            --填充数组
            local tempTbl = {}
            tempTbl["itemId"] = goodsId
            tempTbl["itemNum"] = needNum
            tempTbl["timeCost"] = goodsTimeCost
            table.insert(speedGoodsTbl, tempTbl)
            -- 更新道具个数
            nowTbl.itemNum = tonumber(nowTbl.itemNum) - needNum
            --更新时间
            needTime = needTime - goodsTimeCost * needNum
        end
        nowIndex = nowIndex + 1
    end

    if needTime <= 0 then
        --查找成功 返回
        return finalNeedTbl, speedGoodsTbl,allTimeTbl["free"]
    else
        --填装最后一个
        return finalNeedTbl, self:getDecSpeedGoodsMapForOneSpecial(nowNeedTbl, speedGoodsTbl, -1),allTimeTbl["free"]
    end
end

function UseMultySpeedView:getDecSpeedGoodsTblNew(multyType, needTime)
    -- 时间小于0
    if needTime <= 0 then
        Dprint("needTime is less than 0 ")
        return nil
    end

    local allTime, allTimeTbl = self:getMultyGoodsContainTime(multyType)

    -- dump(allTimeTbl,"allTimeTbl-------")
    --找不到需要的加速道具
    if nil == allTimeTbl then
        Dprint("can not find goods with multyType ")
        return nil
    end
    -- 道具时间少于需要时间
    if needTime > allTime then 
        Dprint("goods time is less than need time  ", allTime, needTime)
        return nil
    elseif needTime == allTime then
        -- 全部覆盖
        if CCCommonUtilsForLua:isFunOpenByKey("use_multy_speed_v2") then
            return allTimeTbl[SPECIALGOODSTBL], allTimeTbl[COMMONGOODSTBL], allTimeTbl["free"]
        else
            return allTimeTbl
        end
    end

    --是否能使用免费道具
    local freetime = 0
    if allTimeTbl["free"] and  #allTimeTbl["free"] > 0 then
         for i,v in ipairs(allTimeTbl["free"]) do
             freetime = freetime + tonumber(v.timeCost) * tonumber(v.itemNum)
         end
    end

    -- 免费够用
    if needTime <= freetime then
        return {}, {}, allTimeTbl["free"] 
    end

    -- 免费不够用
    needTime = needTime - freetime

    local allTimeMap = {}
    local totalTime = 0
    -- 按加速时长分类存储
    for _, value in ipairs(allTimeTbl[SPECIALGOODSTBL] or {}) do
        value.timeCost = tonumber(value.timeCost)
        if not allTimeMap[value.timeCost] then
            allTimeMap[value.timeCost] = {
                count = 0,
                time = value.timeCost,
                total = 0,
                itemArr = {}
            }
        end

        totalTime = totalTime + value.itemNum * value.timeCost
        local info = allTimeMap[value.timeCost]
        info.count = info.count + value.itemNum
        info.total = info.total + value.itemNum * value.timeCost
        table.insert(info.itemArr, value)
    end

    -- 专有道具总时间够用
    if needTime == totalTime then
        return {}, allTimeTbl[SPECIALGOODSTBL], allTimeTbl["free"]
    elseif needTime < totalTime then
        -- 计算浪费的时间，使其尽量小
        local _, finalSpecialTbl, wastedTime = self:calculateToolsCount(allTimeMap, needTime)
        local lastTool = finalSpecialTbl[#finalSpecialTbl] -- 最后一个使用的道具
        if lastTool then
            local lastCalTime = lastTool.timeCost + wastedTime -- 最后一次计算道具时，剩余时间
            
            allTimeMap = {}
            local tempTotalTime = 0
            for _, value in ipairs(allTimeTbl[COMMONGOODSTBL] or {}) do
                value.timeCost = tonumber(value.timeCost)
                -- 只选取小于最后一个使用的专有道具加速时长的通用道具
                if value.timeCost < lastTool.timeCost then
                    if not allTimeMap[value.timeCost] then
                        allTimeMap[value.timeCost] = {
                            count = 0,
                            time = value.timeCost,
                            total = 0,
                            itemArr = {}
                        }
                    end
            
                    tempTotalTime = tempTotalTime + value.itemNum * value.timeCost
                    local info = allTimeMap[value.timeCost]
                    info.count = info.count + value.itemNum
                    info.total = info.total + value.itemNum * value.timeCost
                    table.insert(info.itemArr, value)
                end
            end

            -- 通用道具总时间够用才会进行检测
            if tempTotalTime >= lastCalTime then
                local finalCommonTbl, _, wastedTimeNew = self:calculateToolsCount(allTimeMap, lastCalTime)
                -- 选择浪费时间少的一个
                if #finalCommonTbl > 0 and wastedTime <= 0 and wastedTimeNew <= 0 and wastedTime < wastedTimeNew then
                    lastTool.itemNum = lastTool.itemNum - 1
                    if lastTool.itemNum <= 0 then
                        table.remove(finalSpecialTbl)
                    end
                    return finalCommonTbl, finalSpecialTbl, allTimeTbl["free"]
                end
            end

            return {}, finalSpecialTbl, allTimeTbl["free"]
        end

        return {}, finalSpecialTbl, allTimeTbl["free"]
    end

    -- 专有道具不够用
    needTime = needTime - totalTime
    allTimeMap = {}
    -- local tempTotalTime = 0 -- 能走到这里，时间一定够用
    for _, value in ipairs(allTimeTbl[COMMONGOODSTBL] or {}) do
        value.timeCost = tonumber(value.timeCost)
        if not allTimeMap[value.timeCost] then
            allTimeMap[value.timeCost] = {
                count = 0,
                time = value.timeCost,
                total = 0,
                itemArr = {}
            }
        end

        -- tempTotalTime = tempTotalTime + value.itemNum * value.timeCost
        local info = allTimeMap[value.timeCost]
        info.count = info.count + value.itemNum
        info.total = info.total + value.itemNum * value.timeCost
        table.insert(info.itemArr, value)
    end

    -- 实际使用的道具
    local finalCommonTbl = self:calculateToolsCount(allTimeMap, needTime)
    return finalCommonTbl, allTimeTbl[SPECIALGOODSTBL], allTimeTbl["free"]
end

function UseMultySpeedView:calculateToolsCount(allTimeMap, needTime)
    -- 暂时保留这一段逻辑
    -- 时长从大到小排序
    -- local timeArr = {604800, 259200, 172800, 86400, 28800, 10800, 7200, 3600, 1800, 900, 600, 300, 60}
    local timeArr = {}
    for _, value in pairs(allTimeMap) do
        table.insert(timeArr, value.time)
    end

    table.sort(timeArr, function (a, b)
        return a > b
    end)


    -- 实际使用的道具
    local finalSpecialTbl = {}
    local finalCommonTbl = {}

    local function generateItemTbl (index, lastTime)
        if index > #timeArr or lastTime <= 0 then
            return lastTime
        end

        local nextIndex = index + 1
        local itemByTime = allTimeMap[timeArr[index]]

        if not itemByTime then
            return generateItemTbl(nextIndex, lastTime)
        end

        if itemByTime.total == lastTime then
            -- 剩余时间
            lastTime = lastTime - itemByTime.total
            -- 把道具和数量塞进去
            for _, value in ipairs(itemByTime.itemArr) do
                if tonumber(value.para1) > 1 then
                    table.insert(finalSpecialTbl, value)
                else
                    table.insert(finalCommonTbl, value)
                end
            end
        elseif itemByTime.total > lastTime then
            local useCount = math.floor(lastTime/itemByTime.time)

            -- 剩下道具的总时间
            local totalLastTime = 0
            for i = nextIndex, #timeArr do
                if timeArr[i] and allTimeMap[timeArr[i]] then
                    totalLastTime = totalLastTime + allTimeMap[timeArr[i]].total
                end
            end

            -- 如果剩下道具的总时间不够用，本道具useCount+1，并终止结算
            local finalFlag = totalLastTime < lastTime - useCount * itemByTime.time
            if finalFlag then
                useCount = useCount + 1
            end

            if useCount > 0 then
                -- 剩余时间
                lastTime = lastTime - useCount * itemByTime.time
                -- 把道具和数量塞进去
                for _, value in ipairs(itemByTime.itemArr) do
                    if value.itemNum >= useCount then
                        value.itemNum = useCount
                        if tonumber(value.para1) > 1 then
                            table.insert(finalSpecialTbl, value)
                        else
                            table.insert(finalCommonTbl, value)
                        end
                        break
                    else -- 不够数
                        if tonumber(value.para1) > 1 then
                            table.insert(finalSpecialTbl, value)
                        else
                            table.insert(finalCommonTbl, value)
                        end
                        useCount = useCount - value.itemNum
                    end
                end
            end

            if finalFlag then
                return lastTime
            else
                -- 继续查找
                return generateItemTbl(nextIndex, lastTime)
            end
        else
            -- 剩余时间
            lastTime = lastTime - itemByTime.total
            -- 把道具和数量塞进去
            for _, value in ipairs(itemByTime.itemArr) do
                if tonumber(value.para1) > 1 then
                    table.insert(finalSpecialTbl, value)
                else
                    table.insert(finalCommonTbl, value)
                end
            end
            -- 继续查找
            return generateItemTbl(nextIndex, lastTime)
        end
    end

    -- wastedTime 浪费的时间（非正数，<=0）
    local wastedTime = generateItemTbl(1, needTime)
    return finalCommonTbl, finalSpecialTbl, wastedTime
end

function UseMultySpeedView:getDecSpeedGoodsMapForOneSpecial( allTimeTbl, speedGoodsTbl, needTime )
    if nil == allTimeTbl or #allTimeTbl <= 0 then
        return nil
    end
    local needTbl = {}
    if needTime == -1 then
        -- 不给定时间：代表所需时间无法被整除，取当前最小，并且需要重置allTimeTbl
        local allTimeTblNew = {}
        for k,v in pairs(allTimeTbl) do
            if tonumber(v.itemNum) > 0 then
                table.insert(allTimeTblNew, v)
            end
        end
        --取出最后一个可用的最小时间
        local lastTime = tonumber(allTimeTblNew[#allTimeTblNew].timeCost)
        for k,v in pairs(allTimeTblNew) do
            if tonumber(v.timeCost) == lastTime then
                needTbl = v
                break
            end
        end
    else
        -- 给定时间
        for k,v in pairs(allTimeTbl) do
            if tonumber(v.timeCost) == needTime and tonumber(v.itemNum) > 0 then
                --找到制定时间的加速道具，并且是优先”专属加速“
                needTbl = v
                break
            end
        end
    end
    if nil == needTbl then
        -- 未找到制定加速道具
        return nil
    end
    
    --找到制定时间的加速道具，并且是优先”专属加速“
    if #speedGoodsTbl <= 0 then
       needTbl.itemNum = 1
        table.insert(speedGoodsTbl, needTbl)
    else
        for i,v in ipairs(speedGoodsTbl) do
            if v.itemId == needTbl.itemId then
                v.itemNum = tonumber(v.itemNum) + 1
                return speedGoodsTbl
            end
        end
        needTbl.itemNum = 1
        table.insert(speedGoodsTbl, needTbl)
    end
    return speedGoodsTbl
end

function UseMultySpeedView:checkItemNumEnough( tbl )
    if nil ~= tbl and #tbl > 0 then
        for k,v in pairs(tbl) do
            local tinfo = ToolController:call("getToolInfoByIdForLua", tonumber(v.itemId))
            if tinfo and tinfo:call("getCNT") < v.itemNum then
                return false
            end
        end
    end
    return true
end

function UseMultySpeedView:refreshData(  )
    local tempComman = nil
    local tempSpecial = nil
    local tempFree = nil
    if CCCommonUtilsForLua:isFunOpenByKey("use_multy_speed_v3") then
        tempComman, tempSpecial, tempFree  = self:getDecSpeedGoodsTblNew(self.m_useTag, self.m_timeCost)
    else
        tempComman, tempSpecial, tempFree  = self:getDecSpeedGoodsTbl(self.m_useTag, self.m_timeCost)
    end

    -- 检查道具数量是否匹配
    if not self:checkItemNumEnough(tempSpecial) or not self:checkItemNumEnough(tempComman) then
        return false
    end

    self.m_info = {}
    if tempFree and #tempFree > 0 then
        for k,v in pairs(tempFree) do
            table.insert(self.m_info, v)
        end
    end
    if tempSpecial and #tempSpecial > 0 then
        for k,v in pairs(tempSpecial) do
            table.insert(self.m_info, v)
        end
    end
    if tempComman and #tempComman > 0 then
        for k,v in pairs(tempComman) do
            table.insert(self.m_info, v)
        end
    end
    dump(self.m_info, "UseMultySpeedView:refreshData")
    if nil ~= self.m_info and #self.m_info > 0 then
        self.ui:setTableViewDataSource("m_listTableView", self.m_info)
    end

    --今日不再提示
    if CCCommonUtilsForLua:isFunOpenByKey("accelerate_optimize") and (UseSpeedTag.Fort == self.m_useTag
        or UseSpeedTag.Soldier == self.m_useTag) then

        self.ui.m_selectSpr:setVisible(self.m_controller._noTips)
    else
        local multyType = CCUserDefault:sharedUserDefault():getIntegerForKey("UseMultySpeedTimeStamp", 0)
        local isToday = ActivityController:call("checkIsToday", multyType)
        if isToday then
            self.ui.m_selectSpr:setVisible(true)
        else
            self.ui.m_selectSpr:setVisible(false)
        end
    end
end

function UseMultySpeedView:initUI(  )
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_noButton, getLang("108532"))
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_okButton, getLang("4249153"))
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_setButton, getLang("106228"))
    self.ui.m_desLabel:setString(getLang("4249152"))
    self.ui.m_setLabel:setString(getLang("4249155"))
    if CCCommonUtilsForLua:isFunOpenByKey("accelerate_optimize") and (UseSpeedTag.Fort == self.m_useTag
        or UseSpeedTag.Soldier == self.m_useTag) then
        
        self.ui.txt_check:setString(getLang("660980"))
    else
        self.ui.txt_check:setString(getLang("169809"))
    end
end

function UseMultySpeedView:onSetButtonClick(  )
    self:onNoButtonClick()
    local lua_path = "game.setting.InnerSettingView"
    local view = Drequire(lua_path):create()
    PopupViewController:call("addPopupInView", view)
end

function UseMultySpeedView:onNoButtonClick(  )
    dump("UseMultySpeedView onNoButtonClick")
    self:postNotifWithType(self.m_multySpeedType)
    self:closeSelf()
end

function UseMultySpeedView:onOkButtonClick(  )
    self.m_multySpeedType = "1"
    self:postNotifWithType(self.m_multySpeedType)

    if self.m_controller._noTips and self.m_containCommon then      --本次使用了通用道具时，不再提示
        self.m_controller:setCommonConfirmed(true)
    end

    self:closeSelf()
end

function UseMultySpeedView:onCheckButtonClick(  )
    if CCCommonUtilsForLua:isFunOpenByKey("accelerate_optimize") and (UseSpeedTag.Fort == self.m_useTag
        or UseSpeedTag.Soldier == self.m_useTag) then

        --兵营训练走这里
        self.ui.m_selectSpr:setVisible(not self.ui.m_selectSpr:isVisible())
        self.m_controller:setNoTips(self.ui.m_selectSpr:isVisible())
    else
        if self.ui.m_selectSpr:isVisible() then
            self.ui.m_selectSpr:setVisible(false)
            cc.UserDefault:getInstance():setIntegerForKey("UseMultySpeedTimeStamp", 0)
            CCUserDefault:sharedUserDefault():flush()
        else
            local now = GlobalData:call("getTimeStamp")
            self.ui.m_selectSpr:setVisible(true)
            cc.UserDefault:getInstance():setIntegerForKey("UseMultySpeedTimeStamp", now)
            cc.UserDefault:getInstance():flush()
        end
    end
end

function UseMultySpeedView:postNotifWithType( multySpeedType )
    -- dump("UseMultySpeedView postNotifWithType ", multySpeedType)

    LogController:postEventLog("UseMultySpeedView", {multySpeedType = multySpeedType, useTag = self.m_useTag})

    local dict = CCDictionary:create() 
    dict:setObject(CCString:create(multySpeedType), "multySpeedType")
    dict:setObject(CCString:create(self.m_speedTypeId), "speedTypeId")
    if CCCommonUtilsForLua:isFunOpenByKey("use_multy_speed_v2") then
        local tempGoodsStr = ""
        local isFirstIn = true
        for k,v in pairs(self.m_info) do
            if  v.itemId ~= 0 then
                if isFirstIn then
                   isFirstIn = false
                else
                    tempGoodsStr = tempGoodsStr .. "|"
                end
                tempGoodsStr = tempGoodsStr .. v.itemId .. ";" .. v.itemNum
            end
           
        end
        --dump(tempGoodsStr,"tempGoodsStr----")
        dict:setObject(CCString:create(tempGoodsStr), "tempGoodsStr")
    end
   -- dump( self.m_useTag," self.m_useTag-------")
    if self.m_useTag == UseSpeedTag.Building then
        CCSafeNotificationCenter:postNotification("useMultySpeed_Building", dict)
    
    elseif self.m_useTag == UseSpeedTag.UpStar then
        CCSafeNotificationCenter:postNotification("useMultySpeed_UpStar", dict)

    elseif self.m_useTag == UseSpeedTag.Science then
        CCSafeNotificationCenter:postNotification("useMultySpeed_Science", dict)

    elseif self.m_useTag == UseSpeedTag.HighTech then
        CCSafeNotificationCenter:postNotification("useMultySpeed_HighTech", dict)

    elseif self.m_useTag == UseSpeedTag.Hospital then
        CCSafeNotificationCenter:postNotification("useMultySpeed_Hospital", dict)

    elseif self.m_useTag == UseSpeedTag.Fort then
        CCSafeNotificationCenter:postNotification("useMultySpeed_Fort", dict)

    elseif self.m_useTag == UseSpeedTag.Soldier then
        CCSafeNotificationCenter:postNotification("useMultySpeed_Soldier", dict)

    elseif self.m_useTag == UseSpeedTag.Glory6 then
        CCSafeNotificationCenter:postNotification("useMultySpeed_Glory6", dict)

    elseif self.m_useTag == UseSpeedTag.Tactical then
        CCSafeNotificationCenter:postNotification("useMultySpeed_Tactical", dict)

    elseif self.m_useTag == UseSpeedTag.Forging then
        CCSafeNotificationCenter:postNotification("useMultySpeed_Forging", dict)

    elseif self.m_useTag == UseSpeedTag.RaceScience then
        CCSafeNotificationCenter:postNotification("useMultySpeed_RaceScience", dict)
    elseif self.m_useTag == UseSpeedTag.Extension then
        CCSafeNotificationCenter:postNotification("useMultySpeed_Extension", dict)
    elseif self.m_useTag == UseSpeedTag.Armament then
        CCSafeNotificationCenter:postNotification("useMultySpeed_Armament", dict)
    elseif self.m_useTag == UseSpeedTag.ArmyReform then
        CCSafeNotificationCenter:postNotification("useMultySpeed_ArmyReform", dict)
    end  

    -- 【Awen】新加速界面特殊处理
    if CCCommonUtilsForLua:isFunOpenByKey("speedup_UI") then
        dict:setObject(CCString:create(self.v_qid), "qid")
        CCSafeNotificationCenter:postNotification("ImperialScene:onMultySpeedCD", dict)
    end  
end

return UseMultySpeedView
