
---拜访古迹  奖励展示 页面

local FestivalActVisiteSiteRewardView = class("FestivalActVisiteSiteRewardView", function()
	return PopupBaseView:create()
end)

FestivalActVisiteSiteRewardView.__index = FestivalActVisiteSiteRewardView
 
function FestivalActVisiteSiteRewardView:create(data)
	local view = FestivalActVisiteSiteRewardView.new()
	Drequire("game.FestivalActivities.FestivalActVisiteSiteRewardView_ui"):create(view, 0)
	if view:initView(data) then
		return view
	end
end

function FestivalActVisiteSiteRewardView:initView(data)
   
   
    if data.title then

       local str = string.split( data.title,"|")
       if #str > 3 then
          self.ui.m_titleLabel:setString(getLang(str[1]))
          self.ui.m_descLabel:setString(getLang(str[2]))
          self.ui.m_lbsubTile:setString(getLang(str[3]))
          self.rewardTitle = string.split(str[4],";")

          local scrollView = cc.ScrollView:create()
          local viewSize = self.ui.m_nodeDesc:getContentSize()
          viewSize = CCSize(viewSize.width, viewSize.height)
          scrollView:setViewSize(viewSize)
          scrollView:setPosition(CCPoint(0,0))
          scrollView:setScale(1.0)
          scrollView:ignoreAnchorPointForPosition(true)
          scrollView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
          scrollView:setClippingToBounds(true)
          scrollView:setBounceable(false)
          self.ui.m_nodeDesc:addChild(scrollView)  
      
          local desLabel = cc.Label:createWithSystemFont(getLang(str[2]), "Helvetica", 18, cc.size(viewSize.width,0))
          desLabel:setColor(cc.c3b(147, 147, 147))
          scrollView:addChild(desLabel)
          scrollView:setContentSize(desLabel:getContentSize())
          scrollView:setContentOffset(cc.p(0, viewSize.height - desLabel:getContentSize().height))
        end
       
    end
    self.rewardIds = data.rewardIds
    self:getRewardback()
    return true
end

function FestivalActVisiteSiteRewardView:getRewardback()    
    local list = {}
    local  rewardData = {}
    if self.rewardIds then
        for i = 1, #self.rewardIds do      
            local rwdData = GlobalData:call("getCachedRewardData",self.rewardIds[i])
            rwdData = arrayToLuaTable(rwdData)   
           
            if rwdData and #rwdData > 0 then
                 local data = {}
                 data.items = rwdData
                 data.title = self.rewardTitle[i]   or ""

                 table.insert(rewardData,data)   
            else
              table.insert(list,self.rewardIds[i])
            end
           
       end

   end
   

   if  #list > 0 then
      GlobalData:call("shared"):call("requestMultiRewardData", list)
   end 
    self.ui:setTableViewDataSource("m_tableview", rewardData)
   
end


function FestivalActVisiteSiteRewardView:onEnter()
  
    registerScriptObserver(self, self.getRewardback, 'MSG_GET_MULTY_REWARD_DETAIL_BACK')
end

function FestivalActVisiteSiteRewardView:onExit()
   
    unregisterScriptObserver(self, 'MSG_GET_MULTY_REWARD_DETAIL_BACK')
end

function FestivalActVisiteSiteRewardView:onCloseButtonClick()
	self:call("closeSelf")
end

return FestivalActVisiteSiteRewardView