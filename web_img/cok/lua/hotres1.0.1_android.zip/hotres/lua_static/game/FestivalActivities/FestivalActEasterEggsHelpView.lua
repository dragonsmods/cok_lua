-- @Author: haoyanwei
-- @Date:   2020-03-27 14:47:19
-- @Last Modified by:   haoyanwei
-- @Last Modified time: 2020-04-01 17:54:32
-- @复活节彩蛋帮助界面
local CELL_SIZE = {width = 640, height = 140}
local FestivalActEasterEggsCtr = require('game.FestivalActivities.FestivalActEasterEggsCtr')
local FestivalActEasterEggsHelpView = class('FestivalActEasterEggsHelpView', function ( ... )
	return PopupBaseView:create()
end)

function FestivalActEasterEggsHelpView:create()
    local view = FestivalActEasterEggsHelpView.new()
    CCBLoadFile('FestivalActEasterEggsHelpView', view)
    if view:initView() then
        return view
    end
end

function FestivalActEasterEggsHelpView:initView(  )
    self:registerTouchFuncs()
    registerNodeEventHandler(self)
    --适配
    if CCCommonUtilsForLua:call("checkBeIphoneX") then
		self.m_buttonNode:setPositionY(self.m_buttonNode:getPositionY() + Cocos_iPhoneXBottomSpace)
		self.m_infoList:setPositionY(self.m_infoList:getPositionY() + Cocos_iPhoneXBottomSpace)
			
		local listSize = self.m_infoList:getContentSize()
		self.m_infoList:setContentSize(cc.size(listSize.width, listSize.height - Cocos_iPhoneXBottomSpace))
	end
	self.controller = FestivalActEasterEggsCtr:getInstance()
	self.dataList = self.controller:getHelpList()
	self.m_titleTxt:setString(getLang("681790"))--681790=联盟爱心频道
	CCCommonUtilsForLua:setButtonTitle(self.m_helpAll, getLang('681792'))--681792=帮助所有
	self.m_noAllianeNode:setVisible(false)
	self:createList()
	self:updateUI()
	self.actId = self.controller:getActivityId()
	if self.controller:getActData().todayLogin then
		self.m_lbDesc:setString(getLang(681808,self.controller:getActData().todayLogin))
	end
	self.controller:reqData(self.actId)
    return true
end

function FestivalActEasterEggsHelpView:updateUI( dic )
	if dic then
		local tbl = dictToLuaTable(dic)
		if tbl.activityId ~= self.actId  then 
			return 
		end
	
	end
	self.dataList = self.controller:getHelpList()
	self.m_tableView:reloadData()
	local isHelpAll = false
	if #self.dataList > 0 then
		for i = 1, #self.dataList do
			if self.dataList[i].userData.uid ~= PlayerInfoController:getUid() then
			   isHelpAll = true
			   break
		   end
	   end
	end
	
	self.m_helpAll:setEnabled(isHelpAll)
end

function FestivalActEasterEggsHelpView:createList( ... )
	-- 创建列表
	local scrollAreaHeight = self.m_infoList:getContentSize().height
	self.m_tableView = cc.TableView:create(self.m_infoList:getContentSize())
	self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
	self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
	self.m_tableView:setAnchorPoint(ccp(0, 0))
	self.m_tableView:setDelegate()
	self.m_tableView:registerScriptHandler(function(tab, idx) return self:cellSizeForTable(tab, idx) end, cc.TABLECELL_SIZE_FOR_INDEX)
	self.m_tableView:registerScriptHandler(function(tab, idx) return self:tableCellAtIndex(tab, idx) end, cc.TABLECELL_SIZE_AT_INDEX)
	self.m_tableView:registerScriptHandler(function(tab) return self:numberOfCellsInTableView(tab) end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
	self.m_infoList:addChild(self.m_tableView)
end

function FestivalActEasterEggsHelpView:cellSizeForTable(table)

	return CELL_SIZE.width, CELL_SIZE.height
end

function FestivalActEasterEggsHelpView:tableCellAtIndex(table, idx)
	local cell = table:dequeueCell()
	if not cell then
		local HelpCell = Drequire('game.FestivalActivities.FestivalActEasterEggsHelpCell')
		cell = HelpCell:create()
	end
	local info = self.dataList[idx+1]
	cell:refreshCell(info, idx)
	return cell	
end

function FestivalActEasterEggsHelpView:numberOfCellsInTableView(table)
	return #self.dataList
end

function FestivalActEasterEggsHelpView:onClickHelpAll( ... )
	-- 帮助所有
	self.controller:reqHelpAllAlliance()
end

function FestivalActEasterEggsHelpView:onClickBack( ... )
	-- 返回
	self:call("closeSelf")
end

function FestivalActEasterEggsHelpView:openJoinAlliance( ... )
	-- 加入公会
end

function FestivalActEasterEggsHelpView:onHelpAlliance( params )
	-- 帮助好友
	
	self:updateUI()

	--奖励
	local tbl = dictToLuaTable(params)
	local rewardArray = tbl.rewardArray
	local totalArray = tbl.totalArray
	if rewardArray then
		createTableFlyReward(rewardArray)
	elseif totalArray then
		--一键领取，数组的数组
		local list = {}
		local rewardArray = {}
		
		for i,rwds in ipairs(totalArray) do
			for j,rwd in ipairs(rwds) do
				if list[rwd.value.itemId] then
				local add = tonumber(list[rwd.value.itemId].value.rewardAdd) + tonumber(rwd.value.rewardAdd)
				list[rwd.value.itemId].value.rewardAdd = tostring(add)	
				list[rwd.value.itemId].value.count = rwd.value.count
				else
					list[rwd.value.itemId] = rwd
				end
			
			end
		end
		
		for k,v in pairs(list) do
			table.insert(rewardArray,v)
		end
		
		if next(rewardArray) ~= nil then
			createTableFlyReward(rewardArray)
		end
		
	end
end

function FestivalActEasterEggsHelpView:onEnter( ... )
	registerScriptObserver(self,self.onHelpAlliance, "MSG_HelpAlliance")
	registerScriptObserver(self,self.updateUI, "MSG_FESTIVAL_ACTIVITIES_DATA")
end

function FestivalActEasterEggsHelpView:onExit( ... )
	unregisterScriptObserver(self, "MSG_HelpAlliance")
	unregisterScriptObserver(self, "MSG_FESTIVAL_ACTIVITIES_DATA")
end

return FestivalActEasterEggsHelpView