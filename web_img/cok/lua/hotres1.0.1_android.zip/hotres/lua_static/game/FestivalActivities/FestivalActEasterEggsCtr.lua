-- @Author: haoyanwei
-- @Date:   2020-03-27 13:44:23
-- @Last Modified by:   haoyanwei
-- @Last Modified time: 2020-04-01 18:52:04
-- 复活节开彩蛋活动
local FestivalActEasterEggsCtr = class('FestivalActEasterEggsCtr')
local Default_MaxNum = 6
--[[放置彩蛋
festivalview.data1
参数
index 彩蛋位置从0开始
itemId 道具Id
]]
local PlaceEggsCmd = class("PlaceEggsCmd",LuaCommandBase)
function PlaceEggsCmd.create(activityId, index, itemId)
	local ret = PlaceEggsCmd.new()
	ret:initWithName("festivalview.data1")
	ret:putParam("activityId", CCString:create(activityId))
	ret:putParam("index", CCInteger:create(index-1))
	ret:putParam("itemId", CCString:create(itemId))
	ret.activityId = activityId
	ret.actIndex = index
	ret.actItemId = itemId
	ret:send() 
end

function PlaceEggsCmd:handleReceive( dict )
   local tbl = self:parseMsg(dict)
    if type(tbl) == "boolean" then
        return tbl
    end
    local dict = CCDictionary:create()
    dict:setObject(CCString:create(tostring(self.actIndex)), "index")
    dict:setObject(CCString:create(tostring(self.actItemId)), "itemId")
    postNotification('MSG_PlaceEggs', dict)
    return true
end

--[[求助
festivalview.data2
参数
index 彩蛋位置
]]
local SeekHelpCmd = class("SeekHelpCmd",LuaCommandBase)
function SeekHelpCmd.create(activityId, index)
	local ret = SeekHelpCmd.new()
	ret:initWithName("festivalview.data2")
	ret:putParam("activityId", CCString:create(activityId))
	ret:putParam("index", CCInteger:create(index-1))
	ret.activityId = activityId
	ret.actIndex = index
	ret:send() 
end

function SeekHelpCmd:handleReceive( dict )
   local tbl = self:parseMsg(dict)
    if type(tbl) == "boolean" then
        return tbl
    end
    local control = FestivalActEasterEggsCtr:getInstance()
    control:parseSeekHelp(self.actIndex)
    local dict = CCDictionary:create()
    dict:setObject(CCString:create(tostring(self.actIndex)), "index")
    postNotification('MSG_SeekHelp', dict)
    return true
end

--[[打开彩蛋
festivalview.reward
参数
index 彩蛋位置

返回
rewardArray
]]
local OpenEggCmd = class("OpenEggCmd",LuaCommandBase)
function OpenEggCmd.create(activityId, index)
	local ret = OpenEggCmd.new()
	ret:initWithName("festivalview.reward")
	ret:putParam("activityId", CCString:create(activityId))
	ret:putParam("index", CCInteger:create(index-1))
	ret.activityId = activityId
	ret.actIndex = index
	ret:send() 
end

function OpenEggCmd:handleReceive( dict )
   local tbl = self:parseMsg(dict)
    if type(tbl) == "boolean" then
        return tbl
    end
    local control = FestivalActEasterEggsCtr:getInstance()
    control:parseOpenEgg(tbl)

    --重新请求一下活动
    local control = FestivalActEasterEggsCtr:getInstance()
    control:reqData(self.activityId)
    return true
end

--[[帮助
festivalview.data3
参数
index 彩蛋位置从0开始
destUid 帮助玩家的uid

返回 rewardArray
]]
local HelpAllianceCmd = class("HelpAllianceCmd",LuaCommandBase)
function HelpAllianceCmd.create(activityId, index, destUid)
	local ret = HelpAllianceCmd.new()
	ret:initWithName("festivalview.data3")
	ret:putParam("activityId", CCString:create(activityId))
	ret:putParam("index", CCInteger:create(index))
	ret:putParam("destUid", CCString:create(destUid))
	ret.activityId = activityId
	ret.actIndex = index
	ret.actDestUid = destUid
	ret:send() 
end

function HelpAllianceCmd:handleReceive( dict )
   local tbl, params = self:parseMsg(dict)
    if type(tbl) == "boolean" then
        return tbl
    end
    local control = FestivalActEasterEggsCtr:getInstance()
    control:parseHelpAlliance(self.actIndex, self.actDestUid)
    postNotification('MSG_HelpAlliance', params)
    return true
end
--[[帮助所有
festivalview.otherdata
参数
helps数组
[uid;index,
uid;index]
]]
local HelpAllAllianceCmd = class("HelpAllAllianceCmd",LuaCommandBase)
function HelpAllAllianceCmd.create(activityId, arr)
	local ret = HelpAllAllianceCmd.new()
	ret:initWithName("festivalview.otherdata")
	ret:putParam("activityId", CCString:create(activityId))
	ret:putParam("helps", arr)
	ret:send() 
end

function HelpAllAllianceCmd:handleReceive( dict )
   local tbl, params = self:parseMsg(dict)
    if type(tbl) == "boolean" then
        return tbl
	end
    local control = FestivalActEasterEggsCtr:getInstance()
    control:parseHelpAllAlliance(params)
 
    return true
end

local _instance = _instance or nil

function FestivalActEasterEggsCtr:getInstance( ... )
	if not _instance then
		_instance = FestivalActEasterEggsCtr.new()
	end
	return _instance
end

function FestivalActEasterEggsCtr:ctor( ... )
	-- body
	self.actData = {}--主界面数据
	self.activityId = nil
end

function FestivalActEasterEggsCtr:purge( ... )
	_instance = nil
end

function FestivalActEasterEggsCtr:checkHaveAlliance(  )
	-- 是否有联盟
	local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
	--跳转加入联盟
	if not playerInfo:call("isInAlliance") then
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("111138"))
		PopupViewController:call("removeAllPopupView")
    	LuaController:call("openJoinAllianceView")
		return false
    end
    return true
end

function FestivalActEasterEggsCtr:getActData(  )
	-- 活动数据
	return self.actData
end

function FestivalActEasterEggsCtr:getEggarray(  )
	-- 放置的彩蛋数据
	return self.actData.eggarray or {}
end

function FestivalActEasterEggsCtr:getHelpList(  )
	-- 帮助列表
	return self.actData.helpList or {}
end

function FestivalActEasterEggsCtr:getActConfig(  )
	-- 固定配置
	return self.actData.config or {}
end

function FestivalActEasterEggsCtr:getItemsList(  )
	-- 道具列表
	local config = self:getActConfig()
	local ids = config.para1 or ''
	local maxNums = config.para4 or ''
	ids = string.split(ids, ';')
	maxNums = string.split(maxNums, ';')
	local res = {}
	for i,id in ipairs(ids) do
		local info = {itemId = id, maxNum = maxNums[i] or Default_MaxNum}
		res[i] = info
	end
	return res
end

function FestivalActEasterEggsCtr:getMaxNumByItemId( itemId )
	-- 获取道具的最大帮助次数
	local config = self:getActConfig()
	local ids = config.para1 or ''
	local maxNums = config.para4 or ''
	ids = string.split(ids, ';')
	maxNums = string.split(maxNums, ';')
	for i,id in ipairs(ids) do
		if id == itemId then
			return maxNums[i] or Default_MaxNum
		end
	end
	return Default_MaxNum
end

function FestivalActEasterEggsCtr:checkHaveItems(  )
	-- 检查是否还有空闲道具
	local config = self:getActConfig()
	local ids = config.para1 or ''
	ids = string.split(ids, ';')
	for i,id in ipairs(ids) do
		local toolInfo = ToolController:call("getToolInfoForLua", atoi(id))
	    if toolInfo then
	        local num = toolInfo:call("getCNT")
	        if num>0 then
	        	return true
	        end
	    end
	end
	return false
end

function FestivalActEasterEggsCtr:setActivityId( actId )
	self.activityId = activityId
end

function FestivalActEasterEggsCtr:getActivityId(  )
	-- 活动id
	return self.activityId
end

function FestivalActEasterEggsCtr:reqData(activityId)
	--请求主界面数据
	local festivalCmdHelper = require("game.FestivalActivities.FestivalActivitiesCommandHelper")
	festivalCmdHelper:reqData(tostring(activityId))
end
--[[活动数据
eggarray彩蛋列表
	[
		itemId 彩蛋ID，可能为空
		state 0空的1未开启2可领奖
		helpCount 已求助次数
		openTime 开启倒计时秒
		canSendHelp 0不可以求助 1可以求助
	]
helpList帮助列表
	[
		userData	object 玩家信息 参考al.showhelp 包含name pic 等
		itemId	String 彩蛋ID
		index	int	彩蛋位置
		helpCount	int	帮助数量
	]
config 彩蛋活动的前后端共用配置
	{
		para1 三个彩蛋Id 36004387;36004388;36004389
		para3 三个彩蛋的奖励
		para4 每个彩蛋可被加速次数 6;6;6
	}
]]
function FestivalActEasterEggsCtr:parseData(tbl)
	--收到活动数据
	local activityId = tbl.infoDic.activityId
	if not activityId or activityId == "" then
		return
	end
	dump(tbl, 'parseData--')
	self.activityId = activityId	
	self.actData = tbl

	local dict = CCDictionary:create()
	dict:setObject(CCString:create(activityId), "activityId")
	CCSafeNotificationCenter:postNotification("MSG_FESTIVAL_ACTIVITIES_DATA", dict)
    CCSafeNotificationCenter:postNotification("MSG_FESTIVAL_ACTIVITIES_RED_DOT", dict)
end

function FestivalActEasterEggsCtr:findEmptyIdx(  )
	-- 找到一个空的位置
	local eggarray = self.actData.eggarray or {}
	for i=1,#eggarray do
		local state = tonumber(eggarray[i].state)
		if state == 0 then
			return i
		end
	end
	return -1
end

--放置彩蛋
function FestivalActEasterEggsCtr:reqPlaceEggs( activityId, index, itemId )
	PlaceEggsCmd.create(activityId, index, itemId)
end

--请求帮助
function FestivalActEasterEggsCtr:reqSeekHelp( activityId, index )
	SeekHelpCmd.create(activityId, index)
end
function FestivalActEasterEggsCtr:parseSeekHelp( index )
	local eggarray = self.actData.eggarray
	if eggarray and eggarray[index] then
		eggarray[index].canSendHelp = 0
	end
end

--打开彩蛋
function FestivalActEasterEggsCtr:reqOpenEgg( activityId, index )
	OpenEggCmd.create(activityId, index)
end
function FestivalActEasterEggsCtr:parseOpenEgg( tbl )
	--领取成功
	local allRewards = tbl.rewardArray
	local function callBack()	
			createTableFlyReward(allRewards)
	end
	local view = Drequire("game.CommonPopup.RewardShowAndGetNewView").create(allRewards, getLang("9200137"))
	if not view then
		callBack() 
		return 
	end
	view:setCalllBack(callBack)
	PopupViewController:call("addPopupView", view) 
end

--帮助盟友
function FestivalActEasterEggsCtr:reqHelpAlliance( activityId, index, destUid )
	HelpAllianceCmd.create(activityId, index, destUid)
end
function FestivalActEasterEggsCtr:parseHelpAlliance( index, destUid )
	Dprint('parseHelpAlliance--', index, destUid)
	local helpList = self:getHelpList()
	for i,info in ipairs(helpList) do
		if tonumber(info.index) == index and info.userData.uid == destUid then
			table.remove(helpList, i)
			break
		end
	end
end

--帮助所有
function FestivalActEasterEggsCtr:reqHelpAllAlliance()
	local arr = CCArray:create()
	local helpList = self:getHelpList()
	for i,info in ipairs(helpList) do
		local index = tostring(info.index)
		local uid = info.userData.uid or ''
		local res = table.concat({uid, ';', index}, '')
		arr:addObject(CCString:create(res))
	end
	HelpAllAllianceCmd.create(self.activityId, arr)
end
function FestivalActEasterEggsCtr:parseHelpAllAlliance(params)
    local mytbl = {}
	local myUid = PlayerInfoController:getUid()

	for i,v in ipairs(	self.actData.helpList) do
		if v.userData.uid == myUid then
			table.insert(mytbl,v)
		end
	end
	self.actData.helpList = mytbl
	postNotification('MSG_HelpAlliance', params)
end


--[[
玩家拥有彩蛋 && 有空闲位置。在空闲位置上，增加红点提示。
玩家有可以开启的彩蛋。在可以的彩蛋上，增加特效引导开启。
有同盟玩家需要爱心加速。在爱心标记上，增加红点提示
]]
function FestivalActEasterEggsCtr:getRedDotNum(actId, activityType)
	-- 获取红点的数量
	local dotNum = 0
	local eggarray = self:getEggarray()
	for i, egg in ipairs(eggarray) do
		local state = tonumber(egg.state)
		if state == 0 and self:checkHaveItems() then
			dotNum = dotNum+1
		elseif state == 2 then
			dotNum = dotNum+1
		end
	end
	local helpList = self:getHelpList()
	if #helpList>0 then
		dotNum = dotNum+1
	end
	return dotNum
end

return FestivalActEasterEggsCtr