-- @Author: haoyanwei
-- @Date:   2020-03-27 15:32:59
-- @Last Modified by:   haoyanwei
-- @Last Modified time: 2020-04-01 11:04:41
-- @复活节彩蛋帮助界面cell
local FestivalActEasterEggsCtr = require('game.FestivalActivities.FestivalActEasterEggsCtr')
local FestivalActEasterEggsHelpCell = class('FestivalActEasterEggsHelpCell', CCTableViewCell)

function FestivalActEasterEggsHelpCell:create(  )
	local view = FestivalActEasterEggsHelpCell.new()
	CCBLoadFile('FestivalActEasterEggsHelpCell', view)
	view:initView()
	return view
end

function FestivalActEasterEggsHelpCell:initView( )
	self.controller = FestivalActEasterEggsCtr:getInstance()
	local function onNodeEvent(event)
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(onNodeEvent)
	CCCommonUtilsForLua:setButtonTitle(self.m_helpBtn, getLang('108541'))--108541=帮助
	
end
--[[
userData	object 玩家信息 参考al.showhelp 包含name pic 等
itemId	String 彩蛋ID
index	int	彩蛋位置
helpCount	int	帮助数量
]]
function FestivalActEasterEggsHelpCell:refreshCell(info , idx)
	--刷新基础
	self.m_info = info
	self.m_idx = idx
	local helpInfo = info.userData
	
	--头像
	self.m_picNode:removeAllChildren()
	local portrait = nil
	if (helpInfo.pic == "" or helpInfo.pic == "0") then
		portrait = CCLoadSprite:call("createSprite", "g044.png", CCLoadSpriteType_HEAD_ICON)
	else
		local pic = helpInfo.pic .. ".png"
		portrait = CCLoadSprite:call("createSprite", pic, CCLoadSpriteType_HEAD_ICON)
	end
	self.m_picNode:addChild(portrait)
	CCCommonUtilsForLua:setSpriteMaxSize(portrait, 95, false)
	local m_headImgNode = HFHeadImgNode:call("create")
	if (CCCommonUtilsForLua:call("isUseCustomPic", helpInfo.picVer)) then
		m_headImgNode:call("initHeadImgUrl2", self.m_picNode, CCCommonUtilsForLua:call("getCustomPicUrl", helpInfo.senderId, helpInfo.picVer), 1.0, 95, true)
	end
	self.m_nameLabel:setString(helpInfo.name)

	local itemId = info.itemId
	local toolInfo = ToolController:call("getToolInfoForLua", atoi(itemId))
	if toolInfo then
		local name = toolInfo:call("getName")
		self.m_descTxt:setString(getLang('681791', name))--681791=帮助加速开启{0}
	end
	local helpCount = tonumber(info.helpCount)
	local maxCount = self.controller:getMaxNumByItemId(itemId)
	local len = helpCount/maxCount
	len = math.min(len, 1)
	len = math.max(len, 0)
	self.m_progressTxt:setString(table.concat({helpCount, '/', maxCount}, ''))
	self.m_progress:setPreferredSize(cc.size(286 * len, 16))
 
    self.m_helpBtn:setVisible(helpInfo.uid ~=  PlayerInfoController:getUid())
end

function FestivalActEasterEggsHelpCell:onHelpClick( ... )
	local actId = self.controller:getActivityId()
	local index = tonumber(self.m_info.index)
	local destUid = self.m_info.userData.uid
	self.controller:reqHelpAlliance(actId, index, destUid)
end

function FestivalActEasterEggsHelpCell:onEnter(  )
	
end

function FestivalActEasterEggsHelpCell:onExit(  )
	
end

return FestivalActEasterEggsHelpCell
