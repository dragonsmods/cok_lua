----敲钟活动界面
local FestivalActBellNode = class("FestivalActBellNode", cc.Node)



function FestivalActBellNode:ctor(actId, ccb_ui)
	CCLoadSprite:call("loadDynamicResourceByName","bell_face")
	ccb_ui = ccb_ui or "game.FestivalActivities.FestivalActBellNode_ui"
	Drequire(ccb_ui):create(self, 0)
	self.actId = actId
	self.controller = require("game.FestivalActivities.FestivalActBellNodeCtr").getInstance()
end

function FestivalActBellNode:create(actId, ccb_ui)
	local node = FestivalActBellNode.new(actId, shareId, ccb_ui)
	if node:initNode() then return node end
end

function FestivalActBellNode:initNode( )
  
    local para1 = CCCommonUtilsForLua:call("getPropByIdGroup", "activity_panel", self.actId, "para1")
    --para1 = "bell.json|sk_bell.atlas|start,click,end|13,-140|1"
    local str = string.split(para1,"|")
    if #str > 4 then
       self.aniName = string.split(str[3],",")
       local start =  self.aniName[1] or ""
       self.animationObj = self:createAniamtion(str[1],str[2],start)
        if  self.animationObj then
            self.ui.m_bgNode:addChild(self.animationObj)
            local pos = string.split(str[4],",")
            if #pos > 1 then
                self.animationObj:setPosition(cc.p(pos[1],pos[2]))
            end
            self.animationObj:setScale(tonumber(str[5]))

            local function animationCallBack( event )
	             	
                if  event ~= nil and  self.aniName[2] and event.animation == self.aniName[2] then
                     if event.type == "complete" then
                       
                        self.ui.m_btnBell:setEnabled(not self.controller.isBell)
                        self:onClickBox()
                     end
               end   
           end 
           self.animationObj:registerSpineEventHandler(animationCallBack, spEventType.SP_ANIMATION_COMPLETE)
        end
    else
        local bgName = str[1] or "activity_ad_beiyong.png"
        local bg = CCLoadSprite:createSprite(bgName)
        self.ui.m_bgNode:addChild(bg)

    end

     self.help = CCCommonUtilsForLua:call("getPropByIdGroup", "activity_panel", self.actId, "help")

    self.ui.m_btnBox:setEnabled(false)
    self.controller:reqData(self.actId)
    return true
end
function FestivalActBellNode:createAniamtion( json ,atlas,aniName )
    -- body
   
    local dpath = CCFileUtils:sharedFileUtils():getWritablePath() .. "dresource/"
    local json = dpath .. json
    local atlas = dpath ..  atlas
   
    if cc.FileUtils:getInstance():isFileExist(atlas) and cc.FileUtils:getInstance():isFileExist(json) then
       local animationObj = IFSkeletonAnimation:call("create", json, atlas) 
       if animationObj then
          animationObj:setAnimation(0, aniName, true)
          return animationObj
       end
    end
    return nil

end


function FestivalActBellNode:onEnter( )
	registerScriptObserver(self, self.refreshUI, "FestivalActBellNodeCtr_refresh")
	registerScriptObserver(self, self.playAnimation, "FestivalActBellNodeCtr_playAnimation")
end

function FestivalActBellNode:onExit( )
   unregisterScriptObserver(self, "FestivalActBellNodeCtr_refresh")
   unregisterScriptObserver(self, "FestivalActBellNodeCtr_playAnimation")
end

function FestivalActBellNode:refreshUI()
    self.ui.m_btnBell:setEnabled(not self.controller.isBell)
    self.ui.m_btnShare:setEnabled(not self.controller.isShare)
    self.ui.m_nodeScore:setVisible(self.controller.awards ~= nil)
    self.ui.m_nodeTask:setVisible(self.controller.taskInfo ~= nil)
    if self.controller.awards and #self.awards > 0 then
        local progressBarSize = self.ui.m_progressNode:getContentSize()
        local viewWidth = progressBarSize.width - 60
        self.progressView =
            createACommonProgressView(
            self.controller.awards,
            self.controller.pro,
            function(one)
               self.controller:reqReward(self.actId,one.index)
            end,
            viewWidth
        )
        if  self.progressView then
            self.ui.m_progressNode:removeAllChildren()
            self.progressView:setPosition(ccp(progressBarSize.width * 0.5, progressBarSize.height * 0.35))
            self.ui.m_progressNode:addChild(self.progressView)
        end
    end
    local taskInfo = self.controller.taskInfo
    if  taskInfo then
        
        local para3 = CCCommonUtilsForLua:call("getPropByIdGroup", "activity_panel", self.actId, "para3")
        --para3 = "670840;670836;670841"
        self.ui.m_lbTask:setString(getLang("670835",taskInfo.taskPro,taskInfo.taskTarget))
        local finishNum = math.min(taskInfo.finishNum,taskInfo.finishLimit)
        self.ui.m_lbTaskPro:setString(finishNum.."/"..taskInfo.finishLimit)
        self.ui.m_lbLeftTimes:setString(getLang("670834")..self.controller.leftBellTimes)
        -- local  desc = string.split(para3,";")
        -- local state = self.controller.state +1
        -- if #desc > 0 and desc[state]then
        --    self.ui.m_lbDesc:setString(getLang(desc[state]))
        -- end
      
    end
   
end
function FestivalActBellNode:playAnimation( ... )
    -- body

	if self.animationObj and self.aniName and self.aniName[2]then
		self.animationObj:setAnimation(0, self.aniName[2], false)
        --self.ui.m_btnBox:setEnabled(true)
        self.ui.m_btnBell:setEnabled(false)
	end
end
function FestivalActBellNode:onClickBell( ... )
	self.ui.m_btnBell:setEnabled(false)
	self.controller:reqBell(self.actId)
end

function FestivalActBellNode:onClickShare()
	self.ui.m_btnShare:setEnabled(fasle)
	self.controller:reqShare(self.actId)
	
end
function FestivalActBellNode:onClickBox( ... )
	if self.animationObj then
		self.animationObj:setAnimation(0, self.aniName[1], true)
		self.ui.m_btnBox:setEnabled(false)
	end
    if self.controller.reward then
         local awards = self.controller.reward
        if awards and #awards > 0 then
            createTableFlyReward(awards)
        end   

    else
        CCCommonUtilsForLua:call("flyHint", "", "", getLang("670723"))

    end
	

end
function FestivalActBellNode:onClickReward( ... )
    -- body
    local para2 = CCCommonUtilsForLua:call("getPropByIdGroup", "activity_panel", self.actId, "para2")
   -- para2 ="251025"

    local rwd = GlobalData:call("getCachedRewardData", para2)
    local rwdData = arrayToLuaTable(rwd)

    if #rwdData == 0 then
        GlobalData:call("checkAndRequestRewardData", para2)
    end
    local view = Drequire("commonView.RewardListShowView"):create({
                rewardId = para2,
                reward = rwdData
            })
    PopupViewController:addPopupView(view)

end
function FestivalActBellNode:onClickDetailBtn(...)
    if  self.help ~= "" then
        local view = Drequire('game.FestivalActivities.FestivalActivitiesExplainView'):create(getLang(self.help))
        PopupViewController:addPopupView(view)
    end
    
end
return FestivalActBellNode