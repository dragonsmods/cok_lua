-- @Author: haoyanwei
-- @Date:   2020-03-26 18:19:28
-- @Last Modified by:   haoyanwei
-- @Last Modified time: 2020-04-07 17:51:30
--复活节彩蛋上边cell
local FestivalActEasterEggsCtr = require('game.FestivalActivities.FestivalActEasterEggsCtr')
local FestivalActEasterEggsCell1 = class('FestivalActEasterEggsCell1', cc.Node)

function FestivalActEasterEggsCell1:create(  )
	local cell = FestivalActEasterEggsCell1.new()
	CCBLoadFile('FestivalActEasterEggsCell1', cell)
	cell:initView()
	return cell
end

function FestivalActEasterEggsCell1:initView(  )
	--初始化
	self.controller = FestivalActEasterEggsCtr:getInstance()
	local function onNodeEvent(event)
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(onNodeEvent)
    self.m_lblNo:setString(getLang('681788'))--681788=空闲
    CCCommonUtilsForLua:setButtonTitle(self.m_btnHelp, getLang('681789'))--681789=求助
    CCCommonUtilsForLua:setButtonTitle(self.m_btnOpen, getLang('107097'))--107097=打开
end

function FestivalActEasterEggsCell1:getEggNode( ... )
	-- 返回蛋的图片
	return self.m_sprIcon
end
--[[info
itemId 彩蛋ID，可能为空
state 0空的1未开启2可领奖
helpCount 已求助次数
openTime 开启倒计时秒
canSendHelp 0不可以求助 1可以求助
]]
function FestivalActEasterEggsCell1:refreshCell( info, idx )
	-- 刷新的方法
	self.m_info = info
	self.m_idx = idx
	--道具
	local state = tonumber(self.m_info.state)
	local path = "caidan_none.png"
	if state ~= 0 then
		local itemId = self.m_info.itemId
		path = table.concat({'caidan_', itemId, '.png'}, '')
	end
	self.m_sprIcon:setSpriteFrame(CCLoadSprite:call("loadResource", path))

	self:updateUI()
end

function FestivalActEasterEggsCell1:updateUI(  )
	-- 刷新ui
	if self.m_entryId then
        self:getScheduler():unscheduleScriptEntry(self.m_entryId)
    end
    local state = tonumber(self.m_info.state)
    self.endTime = tonumber(self.m_info.openTime) or 0
    local nowTime = getTimeStamp()
	local leftTime = atoi(self.endTime)-nowTime

	self.m_nodeTime:setVisible(false)
	self.m_nodeState:setVisible(true)
	self.m_btnHelp:setVisible(false)
	self.m_btnOpen:setVisible(false)
	self.m_sprRed:setVisible(false)
	if state == 0 then
		--未放置
		self.m_nodeState1:setVisible(false)
		self.m_nodeState2:setVisible(true)
		--有道具则显示红点
		self.m_sprRed:setVisible(self.controller:checkHaveItems())
	elseif state==1 and leftTime>0 then
		--未开启
		local helpCount = self.m_info.helpCount
		self.m_nodeTime:setVisible(true)
		self.m_nodeState1:setVisible(true)
		self.m_nodeState2:setVisible(false)
		self.m_lblHelpNum:setString(helpCount)
		--请求按钮状态
		local canSendHelp = tonumber(self.m_info.canSendHelp)
		self.m_btnHelp:setVisible(true)
		self.m_btnHelp:setEnabled(canSendHelp == 1)
		--倒计时
		self:updateCutDown()
	    self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:updateCutDown(dt) end, 1, false)

	else
		--开启
		self.m_nodeState:setVisible(false)
		self.m_btnOpen:setVisible(true)
		self.m_btnOpen:setEnabled(true)
		--self.m_sprRed:setVisible(true)
		self:showWaitAni()
	end

	self:playAnimtion(state)
	
end

function FestivalActEasterEggsCell1:updateCutDown( dt )
	-- body
	local nowTime = getTimeStamp()
	local leftTime = atoi(self.endTime)-nowTime;
	if leftTime < 0 then
		self:updateUI()
	else
		local _stamp = format_time(leftTime)
		self.m_lblTime:setString(_stamp)
	end
end

function FestivalActEasterEggsCell1:playAnimtion( state )
	
    for i=1,2 do
    	if self["partical"..i] then
    		self["partical"..i]:setVisible(false)
        end
    	if self["animationObj"..i] then
    		self["animationObj"..i]:setVisible(false)
    	end
    end
 
    local nowTime = getTimeStamp()
	local leftTime = atoi(self.endTime) - getTimeStamp()
	if state == 1 and leftTime > 0 then
        self:showAnimation(1,self.m_nodeAni1)
    elseif state == 2 then
        self:showAnimation(2,self.m_nodeAni2)
        self:showPartical(1,self.m_nodePartical)
    end
end
function FestivalActEasterEggsCell1:showPartical( type,parent)
	-- body
	local para = type == 1 and "para5" or "para6"
	local objName = "partical"..type
	if not self[objName] then
		para =  CCCommonUtilsForLua:call("getPropByIdGroup", "activity_panel", self.controller.activityId, para)
		--para = "looplizi.plist;0,0"
		--para = "openlizi1.plist;0,0|openlizi2.plist;0,0|openlizi3.plist;0,0|openlizi4.plist;0,0|openlizi5.plist;0,0"
	    local params = {}
	    params.isCreateNewParNode = true
	    params.tblParticles = {}
	    params.tblPositions= {}

		  local effectData = string.split(para,"|") 
		 
		  if  #effectData > 0 then
		  	 for i,v in ipairs(effectData) do
		  	 	
		  	 	 local effect = string.split(v,";")
		         if #effect > 1 then
			  	  	 local  pos = string.split(effect[2],",")
			  	  	
			  	  	  table.insert( params.tblParticles,effect[1])
			  	  	  table.insert( params.tblPositions,cc.p(tonumber(pos[1]),tonumber(pos[2])))
		  	     end
		     end
		  end
		
		  self[objName] = createParticlesNode(params)
		 parent:addChild(self[objName]) 
	end

	if self[objName] then
		self[objName]:setVisible(true)
   
	end
  
end
function FestivalActEasterEggsCell1:showAnimation( state,parent)
	-- body
	local aniName = ""
	
	 local objName = "animationObj"..state
	if not self[objName] then
		local para4 = CCCommonUtilsForLua:call("getPropByIdGroup", "activity_panel",  self.controller.activityId, "para4")
	   -- local para4 = "sk_EasterEggs.atlas;easterEggs.json;countdown;self.m_nodeAni|sk_EasterEggs.atlas;easterEggs.json;loop;self.m_nodeAni"
	    local spineData = string.split(para4,"|")
	  
	    if #spineData > 0 then
	    	local  data = string.split(spineData[state],";")
	    	if #data < 3 then return end
	    	
	    	local rootPath = CCFileUtils:sharedFileUtils():getWritablePath() .. "dresource/"
		    local json = rootPath .. data[2]
		    local atlas = rootPath .. data[1]
           
	        if cc.FileUtils:getInstance():isFileExist(atlas) and cc.FileUtils:getInstance():isFileExist(json) then
				self[objName]= IFSkeletonAnimation:call("create", json, atlas)		
				if self[objName] then
				   aniName = data[3]
                   parent:addChild(self[objName])
					
				end
		    end
         end
     end
	if self[objName] then
	   self[objName]:setAnimation(0, aniName, true)		
	   self[objName]:setVisible(true)
	end
end


function FestivalActEasterEggsCell1:showWaitAni(  )
	-- 等待打开状态的动画
end

function FestivalActEasterEggsCell1:showOpenAni(  )
	-- 打开动画
	for i=1,2 do
    	if self["partical"..i] then
    		self["partical"..i]:setVisible(false)
    	end
    end
	self:showPartical(2,self.m_nodePartical)
  
end

function FestivalActEasterEggsCell1:onClickHelp(  )
	-- 帮助
	if self.controller:checkHaveAlliance() then
		self.m_btnHelp:setEnabled(false)
		local actId = self.controller:getActivityId()
		self.controller:reqSeekHelp(actId, self.m_idx)
	end
end

function FestivalActEasterEggsCell1:onClickOpen(  )
	-- 打开
	self:showOpenAni()
	self.m_btnOpen:setEnabled(false)
	local actId = self.controller:getActivityId()
	self.controller:reqOpenEgg(actId, self.m_idx)
end

function FestivalActEasterEggsCell1:onSeekHelp( dict )
	-- 请求帮助
	local index = dict:valueForKey("index"):intValue()
	if index == self.m_idx then
		self:updateUI()
		CCCommonUtilsForLua:call("flyHint", "", "", getLang("115095"))--115095=已经向全体盟友请求帮助
	end
end

function FestivalActEasterEggsCell1:onEnter(  )
	  registerScriptObserver(self,self.onSeekHelp, "MSG_SeekHelp")
end

function FestivalActEasterEggsCell1:onExit(  )
	if self.m_entryId then
        self:getScheduler():unscheduleScriptEntry(self.m_entryId)
    end
    unregisterScriptObserver(self, "MSG_SeekHelp")
end

return FestivalActEasterEggsCell1