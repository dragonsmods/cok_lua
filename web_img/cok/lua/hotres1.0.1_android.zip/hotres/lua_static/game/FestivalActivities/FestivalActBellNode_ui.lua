----------------------------
-- Author: Elex
-- Date: 2020-05-28 Thursday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local FestivalActBellNode_ui = class("FestivalActBellNode_ui")

--#ui propertys


--#function
function FestivalActBellNode_ui:create(owner, viewType, paramTable)
	local ret = FestivalActBellNode_ui.new()
	CustomUtility:LoadUi("FestivalActBellNode.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function FestivalActBellNode_ui:initLang()
	LabelSmoker:setText(self.m_shareTimeLabel, "670477")
	LabelSmoker:setText(self.m_lbDesc, "670836")
	ButtonSmoker:setText(self.m_btnBell, "670719")
	ButtonSmoker:setText(self.m_btnShare, "107098")
end

function FestivalActBellNode_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function FestivalActBellNode_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

function FestivalActBellNode_ui:onClickBell(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBell", pSender, event)
end

function FestivalActBellNode_ui:onClickShare(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickShare", pSender, event)
end

function FestivalActBellNode_ui:onClickDetailBtn(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickDetailBtn", pSender, event)
end

function FestivalActBellNode_ui:onClickBox(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickBox", pSender, event)
end

function FestivalActBellNode_ui:onClickReward(pSender, event)
	ButtonSmoker:forwardFunction(self, "onClickReward", pSender, event)
end

return FestivalActBellNode_ui

