local Glory6Manager = Glory6Manager or {}

--作用号
local FORCE_PRODUCT_SPEED_EFFECT = 66 --全兵种训练加速作用号
local PRODUCT_TRAIN_NUM_EFFECT = 131 --全兵种训练数量作用号
local PRODUCT_TRAIN_RES_EFFECT = 167 --全兵种训练所需资源作用号
local WHOLE_KINGDOM_FORCE_PRODUCT_SPEED_EFFECT = 301 --全服训练加速作用号

local KNIGHT_UPKEEP_REDUCE_EFFECT = 2024--骑士的粮食消耗减少%
local WHOLE_NIGHT_TRAIN_SPPED_EFFECT = 2037 --所有新兵种训练速度作用号

local KNIGHT_STREN_LIMIT_EFFECT = 2081 --祷告礼堂内可强化士兵等级上限提高

local KNIGHT_TRAIN_IRON_EFFECT = 3500 --圣骑士训练消耗精铁减少
local LION_TRAIN_IRON_EFFECT = 3501 --狮鹫突袭者训练消耗精铁减少
local OIL_TRAIN_IRON_EFFECT = 3502 --德尔掷油兵训练消耗精铁减少
local HAMMER_TRAIN_IRON_EFFECT = 3503 --格朗达重锤训练消耗精铁减少
local ELEPHANT_TRAIN_IRON_EFFECT = 5065 --战象训练消耗精铁减少

local KNIGHT_TRAIN_TIME_EFFECT = 3508 --圣骑士训练消耗时间减少
local LION_TRAIN_TIME_EFFECT = 3509 --狮鹫突袭者训练消时间铁减少
local OIL_TRAIN_TIME_EFFECT = 3510 --德尔掷油兵训练消耗时间减少
local HAMMER_TRAIN_TIME_EFFECT = 3511 --格朗达重锤训练消耗时间减少
local ELEPHANT_TRAIN_TIME_EFFECT = 5067 --象兵训练消耗时间减少

local FUN_BUILD_BARRACK = 410000

local NEW_ARMY_TYPE = 1
--没有粮食的时间计时
local LACK_OF_FOOD_TIME = nil

--兵种虚弱信息
local armyWeakInfo = {}

--同步时间误差
local syncWeakTime1 = nil
local syncWeakTime2 = nil

--先虚弱总兵数最少得新兵种
local function sort(armyInfo1, armyInfo2)
	local total1 = armyInfo1.free + armyInfo1.march
	local total2 = armyInfo2.free + armyInfo2.march
	if (total1 < total2) then 
		return true 
	elseif (total1 == total2) then
		local armyId1 = armyInfo1.armyId
		local armyId2 = armyInfo2.armyId
		if (armyId1 < armyId2) then
			return true
		else
			return false
		end
	else
		return false
	end
end

--强化状态
StrenType = 
{
	normal = 1, -- 正常状态
	tempMax = 2, -- 达到建筑限制上限
	TopMax = 3, -- 达到配置上限
}

--强化兵种依赖类型
StrenLockType =
{
	highTech = 1, --贤者之塔
	normal_science = 2, --普通科技(学院)
	civi_science = 3, --文明科技(先祖之魂)
	building = 4, --建筑
}

--------------------------SHP START--------------------------
function Glory6Manager.initConfig(params)
	local dataConfig = params:objectForKey("dataConfig")
	-- local t = dictToLuaTable(params)
	-- dump(t, "Glory6Manager")
    if dataConfig ~= nil then
        dataConfig = tolua.cast(dataConfig, "CCDictionary")

        local weakDataConfig = dataConfig:objectForKey("week_info")
        if nil ~= weakDataConfig then
        	weakDataConfig = tolua.cast(weakDataConfig, "CCDictionary")
        	if nil ~= weakDataConfig then
        		weakDataConfig = dictToLuaTable(weakDataConfig)
        		if nil ~= weakDataConfig then
        			Glory6Manager.weak_interval = tonumber(weakDataConfig.k1) --粮食耗尽多长时间开始虚弱
        			Glory6Manager.weak_permillage = tonumber(weakDataConfig.k2) --每次虚弱当前兵种的千分比数量
        			MyPrint("weak_interval", Glory6Manager.weak_interval)
        			MyPrint("weak_permillage", Glory6Manager.weak_permillage)
        		end
        	end
        end

		local glory6Data = dataConfig:objectForKey("p6_arms")
		if nil ~= glory6Data then
			glory6Data = tolua.cast(glory6Data, "CCDictionary")
			if nil ~= glory6Data then
				glory6Data = dictToLuaTable(glory6Data)
				if nil ~= glory6Data then
					Glory6Manager.strenItemId = tonumber(glory6Data.k1) --强化道具id
					Glory6Manager.strenCost = tonumber(glory6Data.k2) --基础花费
					Glory6Manager.strenAddK2 = tonumber(glory6Data.k3) --k2增加值
					Glory6Manager.strenExp = tonumber(glory6Data.k4) --基础经验
					Glory6Manager.strenAddK4 = tonumber(glory6Data.k5) --k4增加值
					--Glory6Manager.strenTopMaxLevel = tonumber(glory6Data.k7) --配表上限
					Glory6Manager.transferAddExp = tonumber(glory6Data.k8) --技能转化增加的经验
					Glory6Manager.transferItemUse = tonumber(glory6Data.k9) --技能转化消耗的道具数量
					Glory6Manager.transferLimitLv = tonumber(glory6Data.k10) --转换，需要的源技能等级
				end
			end
		end
    end

    local weakInfos = params:objectForKey("weakling")
    if (weakInfos ~= nil) then
    	MyPrint("weakInfos count", weakInfos:count())
    	--local weakConfig = dictToLuaTable(weakInfo)
    	local count = weakInfos:count()
    	for i = 0, count - 1 do
    		local info = weakInfos:objectAtIndex(i)
    		info = dictToLuaTable(info)
    		armyWeakInfo[info.id] = {}
    		armyWeakInfo[info.id].id = info.id
    		armyWeakInfo[info.id].weakNum = tonumber(info.weakness) or 0
    		armyWeakInfo[info.id].weakNumOutside = tonumber(info.marchWeakness) or 0 --外面虚弱的兵
    		armyWeakInfo[info.id].heal = tonumber(info.heal) or 0
    		armyWeakInfo[info.id].finishTime = tonumber(info.finish) or 0 
    		armyWeakInfo[info.id].prepareToCure = 0
    	end
    end

    local lack_of_food_time = params:objectForKey("weaknessTime")
    if (lack_of_food_time) then
    	LACK_OF_FOOD_TIME = math.ceil(params:valueForKey("weaknessTime"):doubleValue() / 1000)
    	syncWeakTime1 = LuaController:call("getWorldTime")
    	syncWeakTime2 = syncWeakTime1
    	MyPrint("LACK_OF_FOOD_TIME", LACK_OF_FOOD_TIME)
    end
end

function Glory6Manager.isFunOpenByKey(key)
	--总开关
	local p6_all = CCCommonUtilsForLua:call("isFunOpenByKey", "p6_all")
	if (p6_all == false) then return false end

	return CCCommonUtilsForLua:call("isFunOpenByKey", key)
end

function Glory6Manager.isNewArmyBuildUnlock()
	local buildId = FunBuildController:call("getMaxLvBuildByType", FUN_BUILD_NEWARMY)
	if (buildId ~= 0) then
		local buildInfo = FunBuildController:call("getFunbuildForLua", buildId)
		local unlockType = buildInfo:getProperty("gloryUnlockType")
		local unlockValue = buildInfo:getProperty("gloryUnlockValue")
		local unlockFlag = buildInfo:getProperty("gloryUnlock")

		return ((unlockType == "") and (unlockValue == "")) or (unlockFlag == true)
	else
		return false
	end
end

function Glory6Manager.getNewArmysInfo()
	local newArmys = {}
	local total = 0
	local armyList = GlobalData:call("shared"):getProperty("armyList")
	for armyId, armyInfo in pairs(armyList) do 
		local new_arms = tonumber(CCCommonUtilsForLua:call("getPropById", armyId, "new_arms"))
		if new_arms == NEW_ARMY_TYPE then
			local free = armyInfo:getProperty("free")
			local march = armyInfo:getProperty("march")
			newArmys[#newArmys + 1] = {
				armyId = armyId,
				free = free,
				march = march,
			}
			total = total + free + march
		end
	end

	return newArmys, total
end

function Glory6Manager.getNewArmsTotalUpkeep()
	local totalUpkeep = 0
	local armyList = GlobalData:call("shared"):getProperty("armyList")
	local effect1 = CCCommonUtilsForLua:call("getEffectValueByNum", 64)
	local effect2 = CCCommonUtilsForLua:call("getEffectValueByNum", KNIGHT_UPKEEP_REDUCE_EFFECT)
	local effect3 = 0
	for armyId, armyInfo in pairs(armyList) do 
		local new_arms = tonumber(CCCommonUtilsForLua:call("getPropById", armyId, "new_arms"))
		local armyType = tonumber(CCCommonUtilsForLua:call("getPropById", armyId, "arm"))
		local flag = 0
		if (armyType == 1 or armyType == 2) then
			effect3 = CCCommonUtilsForLua:call("getEffectValueByNum", 2804)
			flag = 2804
		elseif (armyType == 3 or armyType == 4) then
			effect3 = CCCommonUtilsForLua:call("getEffectValueByNum", 2805)
			flag = 2805
		elseif (armyType == 5 or armyType == 6) then
			effect3 = CCCommonUtilsForLua:call("getEffectValueByNum", 2806)
			flag = 2806
		elseif (armyType == 7 or armyType == 8) then
			effect3 = CCCommonUtilsForLua:call("getEffectValueByNum", 2807)
			flag = 2807
		end
		-- MyPrint("isisisisisiis num value", effect3, CCCommonUtilsForLua:call("getEffectValueByNum", effect3))
		-- MyPrint("isisisisisiis1 armyType num value",armyType,flag , effect3)
		if new_arms == NEW_ARMY_TYPE then
			local free = armyInfo:getProperty("free")
			local march = armyInfo:getProperty("march")
			local upkeep = armyInfo:getProperty("upkeep")
			-- upkeep = upkeep * math.max(0, 1 - (effect1 + effect2) / 100) * (1 / (1 + effect3 / 100))
			upkeep = upkeep * math.max(0, 1 - (effect1 + effect2) / 100) * math.max(0.01, (1 - effect3 / 100))
			totalUpkeep = totalUpkeep + (upkeep * (free + march))
		end
	end

	
	return math.ceil(totalUpkeep)
end

function Glory6Manager.syncArmyTrain(armyId, num)
	local armyInfo = GlobalData:call("getArmyInfoById", armyId)
	if armyInfo then
		armyInfo:setProperty("train", num)
	end
end

function Glory6Manager.getTrainNumEffectByArmyId(armyId,buildId)
	local effectNum = -1
	local armyInfo = GlobalData:call("getArmyInfoById", armyId)
	local new_arms = tonumber(CCCommonUtilsForLua:call("getPropById", armyId, "new_arms"))

	if new_arms ~= NEW_ARMY_TYPE then return 0 end


	if armyId == "107010" then
		effectNum = 2016
	elseif armyId == "107110" then
		effectNum = 2017
	elseif armyId == "107210" then
		effectNum = 2018
	elseif armyId == "107310" then
		effectNum = 2019
	elseif armyId == "107313" then
		effectNum = 5051
	end

	local total = CCCommonUtilsForLua:call("getEffectValueByNum", effectNum)
	local num_e1 = CCCommonUtilsForLua:call("getEffectValueByNum", 6666, true, buildId)
	if num_e1 and num_e1 > 0 then 
		total = total + num_e1
	end
	return total
end

function Glory6Manager.getTrainSpeedEffectByArmyId(armyId)
	local effectNum = -1
	--最后的作用号
	local finalEffectNum = -1
	local armyInfo = GlobalData:call("getArmyInfoById", armyId)
	local new_arms = tonumber(CCCommonUtilsForLua:call("getPropById", armyId, "new_arms"))

	if new_arms ~= NEW_ARMY_TYPE then return 0 end

	if armyId == "107010" then
		effectNum = 2020
		finalEffectNum = KNIGHT_TRAIN_TIME_EFFECT
	elseif armyId == "107110" then
		effectNum = 2021
		finalEffectNum = LION_TRAIN_TIME_EFFECT
	elseif armyId == "107210" then
		effectNum = 2022
		finalEffectNum = OIL_TRAIN_TIME_EFFECT
	elseif armyId == "107310" then
		effectNum = 2023
		finalEffectNum = HAMMER_TRAIN_TIME_EFFECT
	elseif armyId == "107313" then
		effectNum = 5050
		finalEffectNum = ELEPHANT_TRAIN_TIME_EFFECT
	end

	local effect = CCCommonUtilsForLua:call("getEffectValueByNum", effectNum)
	effect = effect + CCCommonUtilsForLua:call("getEffectValueByNum", WHOLE_NIGHT_TRAIN_SPPED_EFFECT)

	local finalEffect = 0
	if finalEffectNum > 0 then
		finalEffect = CCCommonUtilsForLua:call("getEffectValueByNum", finalEffectNum)
	end

 	return effect, finalEffect
end

function Glory6Manager.getTrainMax(buildId, armyId)
	--todo 新兵种科技
	local buildInfo = FunBuildController:call("getFunbuildForLua", buildId)
	if not buildInfo then 
		return 911
	end
	MyPrint("getTrainMax", buildInfo:getProperty("para2"), Glory6Manager.getTrainNumEffectByArmyId(armyId,buildId))
	return buildInfo:getProperty("para2") + Glory6Manager.getTrainNumEffectByArmyId(armyId,buildId)
end

--默认的训练数量根据玩家精铁情况而定，小于最大数量，取精铁满足的数量，否则取最大可训练数量
function Glory6Manager.getDefaultTrainNum(buildId, armyId)
	local trainMax = Glory6Manager.getTrainMax(buildId, armyId)
	
	local toolInfo = ToolController:call("getToolInfoByIdForLua", 211508)
	local fine_iron_cnt = toolInfo:call("getCNT")

	local armyInfo = GlobalData:call("getArmyInfoById", armyId)
	local fine_iron_per_army = armyInfo:getProperty("fine_iron") / 100
	local trainNumByFineIron = math.floor(fine_iron_cnt / fine_iron_per_army)

	if trainNumByFineIron < trainMax then
		return trainNumByFineIron
	else
		return trainMax
	end
end

function Glory6Manager.getTrainTime(armyId, num, buildUuid)
	local armyInfo = GlobalData:call("getArmyInfoById", armyId)

	if armyInfo then
		local total = 0
		local imperialInfos = GlobalData:call("shared"):getProperty("imperialInfo")
		for buildId, buildInfo in pairs(imperialInfos) do
			if (math.floor(buildId / 1000) == FUN_BUILD_BARRACK) then
				total = total + buildInfo:getProperty("para2")
			end
			--
			if (math.floor(buildId / 1000) == FUN_BUILD_NEWARMY) then
				total = total + buildInfo:getProperty("para3")
				MyPrint("FUN_BUILD_NEWARMY train speed para3", buildInfo:getProperty("para3"))
			end
		end

		local sumTime = 0
		local time = armyInfo:getProperty("time")
		local sumTime = (num * time / (1 + total / 100)) * 1000
		MyPrint("getTrainTime num time", num, time, sumTime)
		local effect1 = CCCommonUtilsForLua:call("getEffectValueByNum", FORCE_PRODUCT_SPEED_EFFECT, true, buildUuid)
		local effect2 = CCCommonUtilsForLua:call("getEffectValueByNum", WHOLE_KINGDOM_FORCE_PRODUCT_SPEED_EFFECT)
		local effect3, finalEffect = Glory6Manager.getTrainSpeedEffectByArmyId(armyId)

		sumTime = sumTime / (1 + (effect1 + effect2 + effect3) / 100) / 1000


		Dprint("getTrainTime total", total, effect1, effect2, effect3, sumTime, finalEffect)
		sumTime = math.ceil(sumTime / (1 + finalEffect / 100))

		return sumTime
	else
		return 0
	end
end

function Glory6Manager.getTrainFineIron(armyId, num)
	local armyInfo = GlobalData:call("getArmyInfoById", armyId)

	if armyInfo then
		local new_arms = tonumber(CCCommonUtilsForLua:call("getPropById", armyId, "new_arms"))
		local effectNum = -1
		if new_arms ~= NEW_ARMY_TYPE then return 0 end

		if armyId == "107010" then
			effectNum = KNIGHT_TRAIN_IRON_EFFECT
		elseif armyId == "107110" then
			effectNum = LION_TRAIN_IRON_EFFECT
		elseif armyId == "107210" then
			effectNum = OIL_TRAIN_IRON_EFFECT
		elseif armyId == "107310" then
			effectNum = HAMMER_TRAIN_IRON_EFFECT
		elseif armyId == "107313" then 
			effectNum = ELEPHANT_TRAIN_IRON_EFFECT
		end

		local fine_iron = armyInfo:getProperty("fine_iron") / 100
		local effect = 0
		if effectNum > 0 then
			effect = CCCommonUtilsForLua:call("getEffectValueByNum", effectNum)
		end
		local sum = math.ceil((fine_iron * num) / (1 + effect / 100))
		Dprint("getTrainFineIron", sum, effect)
		return sum
	else
		return 0
	end
end

function Glory6Manager.getTrainResEffect(uuid)
	return CCCommonUtilsForLua:call("getEffectValueByNum", PRODUCT_TRAIN_RES_EFFECT, true, uuid) / 100
end

function Glory6Manager.getTrainScienceInfo(armyId)
	local armyInfo = GlobalData:call("getArmyInfoById", armyId)
	local unlockLevel = armyInfo:getProperty("unlockLevel")
	local unlockScience = armyInfo:getProperty("science")
	local scienceT = splitString(unlockScience, ";")
	local scienceId = tonumber(scienceT[1])
	local scienceLv = tonumber(scienceT[2])

	return scienceId, scienceLv
end

function Glory6Manager.isNeedUnlock(uuid)
	local buildInfo = FunBuildController:call("getFunBuildInfoByUuid", uuid)
	local starNum = buildInfo:getProperty("starNum")
	if starNum ~= 5 then return false end

	local gloryUnlockType = buildInfo:getProperty("gloryUnlockType")
	local gloryUnlockValue = buildInfo:getProperty("gloryUnlockValue")
	
	--不需要解锁
	if (gloryUnlockType == "") or (gloryUnlockValue == "") then return false end

	local gloryUnlock = buildInfo:getProperty("gloryUnlock")
	local isNeedUnlock = false
	if gloryUnlock == true then
		isNeedUnlock = false
	else
		isNeedUnlock = true
	end

	return isNeedUnlock
end

function Glory6Manager.getNewArmyFactoryLv()
	local buildId = FunBuildController:call("getMaxLvBuildByType", FUN_BUILD_NEWARMY)
	if buildId ~= 0 then
		local buildInfo = FunBuildController:call("getFunbuildForLua", buildId)
		local level = buildInfo:getProperty("level")
		return level
	end
	assert(false, "no this build")
	return 0
end

function Glory6Manager.getCureSoilderWeakNum(all)
	local total = 0
	for k, v in pairs(armyWeakInfo) do
		if all then
			v.prepareToCure = v.weakNum
		else
			v.prepareToCure = 0
		end
		
		total = total + v.prepareToCure
	end

	return total
end

--虚弱

function Glory6Manager.sendArmyToWeakBuild(armyInfo, weakNum)
	local armyId = armyInfo:getProperty("armyId")
	local free = armyInfo:getProperty("free")
	local march = armyInfo:getProperty("march")
	local total = free + march
	local subNum = 0

	local remainCapacity = Glory6Manager.getCureRemainCapacity()
	if remainCapacity == 0 then return 0 end

	local deadNum = 0
	if weakNum > remainCapacity then
		deadNum = weakNum - remainCapacity
		weakNum = remainCapacity
	end

	local result = 0

	if (armyWeakInfo[armyId] == nil) then
		armyWeakInfo[armyId] = {}
		armyWeakInfo[armyId].id = armyId
		armyWeakInfo[armyId].weakNum = 0
		armyWeakInfo[armyId].weakNumOutside = 0 --外面虚弱的兵
		armyWeakInfo[armyId].heal = 0
		armyWeakInfo[armyId].finishTime = 0 
		armyWeakInfo[armyId].prepareToCure = 0
	end

	if (weakNum > 0) then
		if (free >= weakNum) then
			armyInfo:setProperty("free", free - weakNum)
			armyWeakInfo[armyId].weakNum = armyWeakInfo[armyId].weakNum + weakNum
			subNum = subNum + weakNum
			-- armyWeakInfo[armyId].weakNumOutside = 0
		else
			armyInfo:setProperty("free", 0)
			armyWeakInfo[armyId].weakNum = armyWeakInfo[armyId].weakNum + free
			subNum = subNum + free
			armyWeakInfo[armyId].weakNumOutside = armyWeakInfo[armyId].weakNumOutside + weakNum - free
		end
	end

	if (deadNum > 0) then
		if (free >= dead) then
			armyInfo:setProperty("free", free - dead)
			subNum = subNum + dead
		else
			armyInfo:setProperty("free", 0)
			subNum = subNum + free
		end
	end

	local power = armyInfo:getProperty("power")
	return math.floor(subNum * power)
end

--客户端同步每秒计时同步虚弱兵
function Glory6Manager.updateWeakInClient()
	if Glory6Manager.weak_interval == nil then 
		return 
	end
	if Glory6Manager.weak_permillage == nil then 
		return 
	end

	if LACK_OF_FOOD_TIME == nil then 
		return 
	end
	--新兵营未解锁返回
	if Glory6Manager.isNewArmyBuildUnlock() == false then 
		return 
	end

	--虚弱兵开关
	local p6_weak = Glory6Manager.isFunOpenByKey("p6_weak")
	if p6_weak == false then 
		return 
	end

	local resource = GlobalData:call("shared"):getProperty("resourceInfo")
	local lFood = resource:getProperty("lFood")
	local lFood_bind = resource:getProperty("lFood_bind")

	if (lFood <= 0 and lFood_bind <= 0) then
		Glory6Manager.syncWeakOutSide()
	end

	if (lFood > 0 or lFood_bind > 0) then
		local now = LuaController:call("getWorldTime")
		local pass = now - syncWeakTime2
		syncWeakTime1 = syncWeakTime1 + pass
		--MyPrint("syncWeakTime1", syncWeakTime1)
		syncWeakTime2 = now
	else
		local now = LuaController:call("getWorldTime")
		local lackTime = LACK_OF_FOOD_TIME + now - syncWeakTime1
		syncWeakTime2 = now
		-- MyPrint("lackTime", lackTime)

		if (lackTime >= Glory6Manager.weak_interval) then
			local newArmys = Glory6Manager.getNewArmysInfo()
			table.sort(newArmys, sort)

			local subPower = 0
			
			for index, army in ipairs(newArmys) do
				
				local armyId = army.armyId
				local free = army.free
				local march = army.march
				local total = free + march

				if (armyWeakInfo[armyId]) then
					local weakNumOutside = armyWeakInfo[armyId].weakNumOutside
					total = total - weakNumOutside
				end

				local weakNum = math.ceil(total * Glory6Manager.weak_permillage / 1000)
				MyPrint("armyId, weakNum", armyId, weakNum)

				local armyInfo = GlobalData:call("getArmyInfoById", armyId)
				subPower = subPower + Glory6Manager.sendArmyToWeakBuild(armyInfo, weakNum)
			end

			if (subPower > 0) then
				local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
				local armyPower = playerInfo:getProperty("armyPower")
				playerInfo:setProperty("armyPower", armyPower - subPower)

				CCSafeNotificationCenter:postNotification(MSG_COLLECT_SOLDIER_ADD_POWER)
				CCSafeNotificationCenter:postNotification(MSG_UPDATE_ARMY_DATA) 
			end

			LACK_OF_FOOD_TIME = lackTime - Glory6Manager.weak_interval
			syncWeakTime1 = now
		end
	end
end

--每秒同步外面的虚弱兵,拿相同兵种的兵来抵消
function Glory6Manager.syncWeakOutSide()
	local subPower = 0
	local newArmys = Glory6Manager.getNewArmysInfo()
	table.sort(newArmys, sort) 

	for k, army in ipairs(newArmys) do
		if (armyWeakInfo[army.armyId]) then
			local v = armyWeakInfo[army.armyId]
			local weakNumOutside = v.weakNumOutside
			local armyId = v.id
			local armyInfo = GlobalData:call("getArmyInfoById", armyId)
			local free = armyInfo:getProperty("free")

			if (weakNumOutside > 0 and free > 0) then
				local power = armyInfo:getProperty("power")
				--偿还的兵
				local payback = 0
				
				local remainCapacity = Glory6Manager.getCureRemainCapacity()
				if (free >= weakNumOutside) then
					payback = weakNumOutside
				else
					payback = free
				end

				--实际进庇护所的兵
				local paybackReal = 0
				if (remainCapacity >= payback) then
					paybackReal = payback
				else
					paybackReal = remainCapacity
				end

				armyInfo:setProperty("free", free - payback)
				armyWeakInfo[armyId].weakNum = armyWeakInfo[armyId].weakNum + paybackReal
				armyWeakInfo[armyId].weakNumOutside = armyWeakInfo[armyId].weakNumOutside - payback
				subPower = subPower + math.floor(payback * power)
			end
		end
	end

	if (subPower > 0) then
		local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
		local armyPower = playerInfo:getProperty("armyPower")
		playerInfo:setProperty("armyPower", armyPower - subPower)

		CCSafeNotificationCenter:postNotification(MSG_COLLECT_SOLDIER_ADD_POWER)
		CCSafeNotificationCenter:postNotification(MSG_UPDATE_ARMY_DATA)
	end
end

function Glory6Manager.getWeakListData()
	local data = {}
	for k, v in ipairs4ScatteredT(armyWeakInfo) do
		local weakNum = v.weakNum
		if (weakNum > 0) then
			data[#data + 1] = armyWeakInfo[k]
		end
	end

	return data
end

function Glory6Manager.getWeakTotalNum()
	local total = 0
	for k, v in ipairs4ScatteredT(armyWeakInfo) do
		local weakNum = v.weakNum
		local heal = v.heal
		-- local weakNumOutside = v.weakNumOutside or 0
		total = total + weakNum + heal
	end

	return total
end

function Glory6Manager.getTotalCure()
	local total = 0
	for k, v in ipairs4ScatteredT(armyWeakInfo) do
		if (v.heal > 0) then
			total = total + v.heal
		end
	end

	return total
end

function Glory6Manager.getCureCapacity()
	local buildId = FunBuildController:call("getMaxLvBuildByType", FUN_BUILD_NEWARMY_CURE)
	if buildId ~= 0 then
		local buildInfo = FunBuildController:call("getFunbuildForLua", buildId)
		return buildInfo:getProperty("para1")
	end

	return 0
end

--获取庇护所剩余容量
function Glory6Manager.getCureRemainCapacity()
	local totalCapacity = Glory6Manager.getCureCapacity()
	local totalWeakNum = Glory6Manager.getWeakTotalNum()
	local remainCapacity = totalCapacity - totalWeakNum
	return remainCapacity > 0 and remainCapacity or 0
end

function Glory6Manager.getCureFood(armyId, num)
	-- body
	local armyInfo = GlobalData:call("getArmyInfoById", armyId)
	if not armyInfo then return 0 end

	local food = armyInfo:getProperty("food")
	local resPercent = armyInfo:getProperty("weak_res") / 100
	local effectNum = 0
	local effectNum2 = 0

	if armyId == "107010" then
		effectNum = 2808 --圣骑士虚弱恢复消耗降低-粮木铁银
		effectNum2 = 3364 --圣骑士虚弱恢复资源减少除精铁(%)
	elseif armyId == "107110" then
		effectNum = 2809 --狮鹫突袭者虚弱恢复消耗降低-粮木铁银
		effectNum2 = 3365 --狮鹫突袭者虚弱恢复资源减少除精铁((%)
	elseif armyId == "107210" then
		effectNum = 2810 --德尔掷油兵虚弱恢复消耗降低-粮木铁银
		effectNum2 = 3366 --德尔掷油兵虚弱恢复资源减少除精铁((%)
	elseif armyId == "107310" then
		effectNum = 2811 --格朗达重锤虚弱恢复消耗降低-粮木铁银
		effectNum2 =  3367 --格朗达重锤虚弱恢复资源减少除精铁((%)
	elseif armyId == "107313" then
		effectNum = 5071 --战象虚弱恢复消耗降低-粮木铁银
		effectNum2 =  5070 --战象虚弱恢复资源减少除精铁((%)
	end
	-- MyPrint("isisisisisiis2 armyType num value",armyType, effectNum, CCCommonUtilsForLua:call("getEffectValueByNum", effectNum))
	local resEffect = CCCommonUtilsForLua:call("getEffectValueByNum", effectNum)
	local resEffect2 = CCCommonUtilsForLua:call("getEffectValueByNum", effectNum2)
	-- food = food * (1 / (1 + resEffect / 100))
	food = food * math.max(0.01, 1 - resEffect / 100)
	food = food / math.max(1, 1 + resEffect2/100 )
	return math.floor(food * resPercent * num)
end

function Glory6Manager.getCureWood(armyId, num)
	-- body
	local armyInfo = GlobalData:call("getArmyInfoById", armyId)
	if not armyInfo then return 0 end

	local wood = armyInfo:getProperty("wood")
	local resPercent = armyInfo:getProperty("weak_res") / 100
	local effectNum = 0
	local effectNum2 = 0

	if armyId == "107010" then
		effectNum = 2808 --圣骑士虚弱恢复消耗降低-粮木铁银
		effectNum2 = 3364 --圣骑士虚弱恢复资源减少除精铁(%)
	elseif armyId == "107110" then
		effectNum = 2809 --狮鹫突袭者虚弱恢复消耗降低-粮木铁银
		effectNum2 = 3365 --狮鹫突袭者虚弱恢复资源减少除精铁((%)
	elseif armyId == "107210" then
		effectNum = 2810 --德尔掷油兵虚弱恢复消耗降低-粮木铁银
		effectNum2 = 3366 --德尔掷油兵虚弱恢复资源减少除精铁((%)
	elseif armyId == "107310" then
		effectNum = 2811 --格朗达重锤虚弱恢复消耗降低-粮木铁银
		effectNum2 =  3367 --格朗达重锤虚弱恢复资源减少除精铁((%)
	elseif armyId == "107313" then
		effectNum = 5071 --战象虚弱恢复消耗降低-粮木铁银
		effectNum2 =  5070 --战象虚弱恢复资源减少除精铁((%)
	end

	local resEffect = CCCommonUtilsForLua:call("getEffectValueByNum", effectNum)
	local resEffect2 = CCCommonUtilsForLua:call("getEffectValueByNum", effectNum2)
	-- wood = wood * (1 / (1 + resEffect / 100))
	wood = wood * math.max(0.01, 1 - resEffect / 100)
	wood = wood / math.max(1, 1 + resEffect2/100 )
	return math.floor(wood * resPercent * num)
end

function Glory6Manager.getCureIron(armyId, num)
	-- body
	local armyInfo = GlobalData:call("getArmyInfoById", armyId)
	if not armyInfo then return 0 end

	local iron = armyInfo:getProperty("iron")
	local resPercent = armyInfo:getProperty("weak_res") / 100
	local effectNum = 0
	local effectNum2 = 0

	if armyId == "107010" then
		effectNum = 2808 --圣骑士虚弱恢复消耗降低-粮木铁银
		effectNum2 = 3364 --圣骑士虚弱恢复资源减少除精铁(%)
	elseif armyId == "107110" then
		effectNum = 2809 --狮鹫突袭者虚弱恢复消耗降低-粮木铁银
		effectNum2 = 3365 --狮鹫突袭者虚弱恢复资源减少除精铁((%)
	elseif armyId == "107210" then
		effectNum = 2810 --德尔掷油兵虚弱恢复消耗降低-粮木铁银
		effectNum2 = 3366 --德尔掷油兵虚弱恢复资源减少除精铁((%)
	elseif armyId == "107310" then
		effectNum = 2811 --格朗达重锤虚弱恢复消耗降低-粮木铁银
		effectNum2 =  3367 --格朗达重锤虚弱恢复资源减少除精铁((%)
	elseif armyId == "107313" then
		effectNum = 5071 --战象虚弱恢复消耗降低-粮木铁银
		effectNum2 =  5070 --战象虚弱恢复资源减少除精铁((%)
	end

	local resEffect = CCCommonUtilsForLua:call("getEffectValueByNum", effectNum)
	local resEffect2 = CCCommonUtilsForLua:call("getEffectValueByNum", effectNum2)
	-- iron = iron * (1 / (1 + resEffect / 100))
	iron = iron * math.max(0.01, 1 - resEffect / 100)
	iron = iron / math.max(1, 1 + resEffect2 / 100)
	return math.floor(iron * resPercent * num)
end

function Glory6Manager.getCureStone(armyId, num)
	-- body
	local armyInfo = GlobalData:call("getArmyInfoById", armyId)
	if not armyInfo then return 0 end

	local stone = armyInfo:getProperty("stone")
	local resPercent = armyInfo:getProperty("weak_res") / 100
	local effectNum = 0
	local effectNum2 = 0
	
	if armyId == "107010" then
		effectNum = 2808 --圣骑士虚弱恢复消耗降低-粮木铁银
		effectNum2 = 3364 --圣骑士虚弱恢复资源减少除精铁(%)
	elseif armyId == "107110" then
		effectNum = 2809 --狮鹫突袭者虚弱恢复消耗降低-粮木铁银
		effectNum2 = 3365 --狮鹫突袭者虚弱恢复资源减少除精铁((%)
	elseif armyId == "107210" then
		effectNum = 2810 --德尔掷油兵虚弱恢复消耗降低-粮木铁银
		effectNum2 = 3366 --德尔掷油兵虚弱恢复资源减少除精铁((%)
	elseif armyId == "107310" then
		effectNum = 2811 --格朗达重锤虚弱恢复消耗降低-粮木铁银
		effectNum2 =  3367 --格朗达重锤虚弱恢复资源减少除精铁((%)
	elseif armyId == "107313" then
		effectNum = 5071 --战象虚弱恢复消耗降低-粮木铁银
		effectNum2 =  5070 --战象虚弱恢复资源减少除精铁((%)
	end

	local resEffect = CCCommonUtilsForLua:call("getEffectValueByNum", effectNum)
	local resEffect2 = CCCommonUtilsForLua:call("getEffectValueByNum", effectNum2)
	-- stone = stone * (1 / (1 + resEffect / 100))
	stone = stone * math.max(0.01, 1 - resEffect / 100)
	stone = stone / math.max(1, 1 + resEffect2/100 )
	return math.floor(stone * resPercent * num)
end

function Glory6Manager.getCureItem(armyId, num)
	-- body
	local armyInfo = GlobalData:call("getArmyInfoById", armyId)
	if not armyInfo then return 0 end

	local fine_iron = armyInfo:getProperty("fine_iron") / 100
	local resPercent = armyInfo:getProperty("weak_res") / 100
	local effectNum = 0
	local effectNum2 = 0
	
	if armyId == "107010" then
		effectNum = 2812--圣骑士虚弱恢复消耗降低-精铁
		effectNum2 = 3368 --圣骑士虚弱恢复精铁减少(%)
	elseif armyId == "107110" then
		effectNum = 2813--狮鹫突袭者虚弱恢复消耗降低-精铁
		effectNum2 = 3369 --狮鹫突袭者虚弱恢复精铁减少((%)
	elseif armyId == "107210" then
		effectNum = 2814--德尔掷油兵虚弱恢复消耗降低-精铁
		effectNum2 = 3370 --德尔掷油兵虚弱恢复精铁减少((%)
	elseif armyId == "107310" then
		effectNum = 2815--格朗达重锤虚弱恢复消耗降低-精铁
		effectNum2 = 3371 --格朗达重锤虚弱恢复精铁减少((%)	
	elseif armyId == "107313" then
		effectNum = 5069 --战象虚弱恢复消耗降低-精铁
		effectNum2 = 5064 --战象虚弱恢复精铁减少((%)	
	end
	-- MyPrint("isisisisisiis3 armyType num value",armyType, effectNum, CCCommonUtilsForLua:call("getEffectValueByNum", effectNum))
	local resEffect = CCCommonUtilsForLua:call("getEffectValueByNum", effectNum)
	local resEffect2 = CCCommonUtilsForLua:call("getEffectValueByNum", effectNum2)
	-- fine_iron = fine_iron * (1 / (1 + resEffect / 100))
	fine_iron = fine_iron * math.max(0.01, 1 - resEffect / 100 )
	fine_iron = fine_iron / math.max(1, 1 + resEffect2 / 100)
	return math.ceil(fine_iron * resPercent * num) --向上取整
end

function Glory6Manager.getCureTime(armyId, num)
	-- body
	local armyInfo = GlobalData:call("getArmyInfoById", armyId)
	if not armyInfo then return 0 end

	local time = armyInfo:getProperty("time")
	local timePercent = armyInfo:getProperty("weak_time") / 100
	
	local effectNum = 0
	local effectNum13 = 0

	if tonumber(armyId) == 107010 then
		effectNum13 = 5324 --13步虚弱时间减少%
		effectNum = 3360--圣骑士虚弱恢复时间减少(%)
	elseif tonumber(armyId) == 107110 then
		effectNum13 = 5325 --13骑虚弱时间减少%
		effectNum = 3361--狮鹫虚弱恢复时间减少(%)
	elseif tonumber(armyId) == 107210 then
		effectNum13 = 5326 --13弩虚弱时间减少%
		effectNum = 3362--投掷兵虚弱恢复时间减少(%)
	elseif tonumber(armyId) == 107310 then
		effectNum13 = 5327 --13车虚弱时间减少%
		effectNum = 3363--格朗达虚弱恢复时间减少(%)
	elseif tonumber(armyId) == 107313 then
		effectNum13 = 5055 --13🐘虚弱时间减少%
		effectNum = 5063 --战象虚弱恢复时间减少(%)
	end

	local resEffect = CCCommonUtilsForLua:call("getEffectValueByNum", effectNum)
	local resEffect13 = 0
	if effectNum13 then
		resEffect13 = CCCommonUtilsForLua:call("getEffectValueByNum", effectNum13)
	end
	time = time / math.max(1, 1 + resEffect / 100) / math.max(1, 1 + resEffect13 / 100)
	return math.floor(time * timePercent * num)
end

function Glory6Manager.cancelCure()
	for k, v in pairs(armyWeakInfo) do
		armyWeakInfo[k].weakNum = armyWeakInfo[k].weakNum + armyWeakInfo[k].heal 
		armyWeakInfo[k].heal = 0
	end
end

function Glory6Manager.syncWeakArmy(dict)
	local weakT = dictToLuaTable(dict)

	if not weakT then return end
	if not weakT.weakling then return end
	local weaks = weakT.weakling
	for k, v in pairs(weaks) do
		if armyWeakInfo[v.id] then
			armyWeakInfo[v.id].weakNum = tonumber(v.weakness) or 0
			armyWeakInfo[v.id].weakNumOutside = tonumber(v.marchWeakness) or 0
		else
			armyWeakInfo[v.id] = {}
			armyWeakInfo[v.id].id = v.id
    		armyWeakInfo[v.id].weakNum = tonumber(v.weakness) or 0
    		armyWeakInfo[v.id].weakNumOutside = tonumber(v.marchWeakness) or 0
    		armyWeakInfo[v.id].heal = tonumber(v.heal) or 0
    		armyWeakInfo[v.id].finishTime = tonumber(v.finish) or 0 
    		armyWeakInfo[v.id].prepareToCure = 0
    	end
	end
end

function Glory6Manager.syncWeakArmyByCure(armys)
	local tempList = splitString(armys, "|")
	local armyList = {}
	for i, v in ipairs(tempList) do
		local t = splitString(v, ";")
		armyList[#armyList + 1] = t
	end

	for i, v in ipairs(armyList) do
		local armyId = v[1]
		local num = tonumber(v[2])
		armyWeakInfo[armyId].heal = num
		armyWeakInfo[armyId].weakNum = armyWeakInfo[armyId].weakNum - num
	end
end

function Glory6Manager.cureComplete(uuid)
	local cmd = require("game.command.Glory6CureCompleteCmd").create(uuid)
	cmd:send()
end

function Glory6Manager.weakCureComplete(params)
	if not params then return end
	local t = dictToLuaTable(params)
	local armyT = t.army
	if not armyT then return end
	for i, v in ipairs(armyT) do
		local id = v.id
		local free = tonumber(v.free)
		local armyInfo = GlobalData:call("getArmyInfoById", id)
		armyInfo:setProperty("free", free)

		armyWeakInfo[id].heal = 0
		armyWeakInfo[id].prepareToCure = 0
	end

end

function Glory6Manager.finishCureNewArmy()
	for k, v in pairs(armyWeakInfo) do
		local armyInfo = GlobalData:call("getArmyInfoById", k)
		local heal = v.heal
		local free = armyInfo:getProperty("free")
		armyInfo:setProperty("free", free + heal)

		armyWeakInfo[k].heal = 0
		armyWeakInfo[k].prepareToCure = 0
	end
end

function Glory6Manager.getArmyWeakMsg()
	--虚弱兵开关
	local p6_weak = Glory6Manager.isFunOpenByKey("p6_weak")
	if p6_weak == false then return "" end

	local msg = getLang("5000075")
	local weakNum = Glory6Manager.getWeakTotalNum()
	local total = Glory6Manager.getCureCapacity()
	local result = msg .. CC_CMDITOA(weakNum) .. "/" .. CC_CMDITOA(total)
	return string.gsub(result, ":", " ")
end

function Glory6Manager.purge()
	--虚弱信息清空	
	armyWeakInfo = {}
	--虚弱配置清空
	Glory6Manager.weak_interval = nil
	Glory6Manager.weak_permillage = nil
	--粮食为空持续时间清空
	LACK_OF_FOOD_TIME = nil
	--同步时间误差
	syncWeakTime1 = nil
	syncWeakTime2 = nil
	Glory6Manager.reduceCount = 0
	Glory6Manager.reduceNum = 0
	Glory6Manager.blessBuffId = ""
	Glory6Manager.blessBuffValue = 0
	Glory6Manager.blessCount = 0
	Glory6Manager.blessCost = 0
end

--------------------------SHP END--------------------------

--------------------------CJY BEGIN--------------------------
function Glory6Manager.getTodayStrenCount(  )
	return Glory6Manager.todayStrenCount 
end
function Glory6Manager.setTodayStrenCount( count )
	Glory6Manager.todayStrenCount = count
end

function Glory6Manager.getStrenMaxLevel()
	Glory6Manager.buildStrenMaxLevel = 0

	local buildId = FunBuildController:call("getMaxLvBuildByType", FUN_BUILD_NEWARMY_IMPROVE)
 	if buildId ~= 0 then
	    local buildInfo = FunBuildController:call("getFunbuildForLua", buildId)
	    --local extraLimit = CCCommonUtilsForLua:call("getEffectValueByNum", KNIGHT_STREN_LIMIT_EFFECT)
	    Glory6Manager.buildStrenMaxLevel = buildInfo:getProperty("para1")
	end
	
end

function Glory6Manager.RefreshArmyData( skillTbl ,count)
    
    if not Glory6Manager.armyData then
        Glory6Manager.armyData = {}
    end
    Glory6Manager.getStrenMaxLevel()

    if #skillTbl > 0 then
	    for i,v in ipairs(skillTbl) do
	        Glory6Manager.refreshDataTbl(v)
	    end
	else
  		Glory6Manager.refreshDataTbl(skillTbl)
	end

    if nil ~= count then
    	Glory6Manager.setTodayStrenCount(count)
    end
end

function Glory6Manager.isSkillExist(skillId)
	local id = CCCommonUtilsForLua:getPropByIdGroup('p6_arms', tostring(skillId) , "id")
	return id ~= ""
end

function Glory6Manager.refreshDataTbl( skillTbl )
	local v = skillTbl
	local tempSkillTbl = {}
	tempSkillTbl.level = tonumber(v.level) or 0
	tempSkillTbl.origonSkillId = v.skillId
	tempSkillTbl.exp = tonumber(v.exp)
	tempSkillTbl.uuid = v.uuid
	tempSkillTbl.uid = v.uid
	tempSkillTbl.armyId = v.armyId
	tempSkillTbl.nowSkillId = ""
	-- tempSkillTbl.preSkillId = ""
	tempSkillTbl.nextSkillId = ""
	tempSkillTbl.nextLevel = 0
	tempSkillTbl.preLevel = 0
	tempSkillTbl.showEffect = false
	if v.effectLv then tempSkillTbl.showEffect = true end
	tempSkillTbl.effectLv = atoi(v.effectLv)

	if v.level and tempSkillTbl.level >= 10 then
		tempSkillTbl.nowSkillId = string.sub(v.skillId,1,5)..v.level
	elseif tempSkillTbl.level > 0 then
		tempSkillTbl.nowSkillId = string.sub(v.skillId,1,6)..v.level
	end

	if v.level and tempSkillTbl.level >= 10 then
	  if Glory6Manager.isSkillExist(atoi(tempSkillTbl.nowSkillId) + 1) then
	      tempSkillTbl.nextLevel = tempSkillTbl.level + 1
		if tonumber(tempSkillTbl.nextLevel) >= 10 then
			tempSkillTbl.nextSkillId = string.sub(v.skillId,1,5)..tempSkillTbl.nextLevel
		elseif tonumber(tempSkillTbl.nextLevel) < 10 then
			tempSkillTbl.nextSkillId = string.sub(v.skillId,1,6)..tempSkillTbl.nextLevel
		end
	  end
	--   if (tempSkillTbl.level > 2) then
	--   	tempSkillTbl.preLevel = tempSkillTbl.level - 1
	--   	if tonumber(tempSkillTbl.preLevel) >= 10 then
	--   		tempSkillTbl.preSkillId = string.sub(v.skillId,1,5)..tempSkillTbl.preLevel
	-- 		elseif tonumber(tempSkillTbl.preLevel) < 10 then
	--   		tempSkillTbl.preSkillId = string.sub(v.skillId,1,6)..tempSkillTbl.preLevel
	-- 		end
	--   end

	elseif tempSkillTbl.level > 0 then
	  if Glory6Manager.isSkillExist(atoi(tempSkillTbl.nowSkillId) + 1) then
	      tempSkillTbl.nextLevel = tempSkillTbl.level + 1
		if tonumber(tempSkillTbl.nextLevel) >= 10 then
			tempSkillTbl.nextSkillId = string.sub(v.skillId,1,5)..tempSkillTbl.nextLevel
		elseif tonumber(tempSkillTbl.nextLevel) < 10 then
			tempSkillTbl.nextSkillId = string.sub(v.skillId,1,6)..tempSkillTbl.nextLevel
		end
	  end
	--   if tempSkillTbl.level > 2 then
	--   	tempSkillTbl.preLevel = tempSkillTbl.level - 1
	--   	if tonumber(tempSkillTbl.preLevel) >= 10 then
	--   		tempSkillTbl.preSkillId = string.sub(v.skillId,1,5)..tempSkillTbl.preLevel
	-- 		elseif tonumber(tempSkillTbl.preLevel) < 10 then
	--   		tempSkillTbl.preSkillId = string.sub(v.skillId,1,6)..tempSkillTbl.preLevel
	-- 		end
	--   end
	end
	--dump(tempSkillTbl, "cjy tempSkillTbl ")
	Glory6Manager.armyData[tempSkillTbl.origonSkillId] = tempSkillTbl
	--end
end

function Glory6Manager.checkIsHaveArmy(nowArmyId)
	local isHave = false
    for k,v in pairs(Glory6Manager.armyData) do
    	if tostring(v.armyId) == tostring(nowArmyId) then
	    	isHave = true
	    	break
	    end
    end
    return isHave
end

function Glory6Manager.getStrenType( skillId )
    local strenType = StrenType.normal

	local skillLv = atoi(skillId) % 100
	local maxLv = atoi(CCCommonUtilsForLua:getPropByIdGroup("p6_arms", tostring(skillId), "max_lv"))
	if skillLv == maxLv or Glory6Manager.isSkillExist(atoi(skillId) + 1) == false then
    	strenType = StrenType.TopMax
    elseif skillLv >= Glory6Manager.buildStrenMaxLevel then
    	strenType = StrenType.tempMax
    end
    
    -- MyPrint("cjy nowLevel ",nowLevel , Glory6Manager.buildStrenMaxLevel , skillId, strenType)
    return strenType
end

function Glory6Manager.checkIsUnLock(ArmyId) --false:已解锁

	local armyInfo = GlobalData:call("getArmyInfoById", ArmyId)

	if nil == armyInfo then
		return true
	end
	local showUnlock = false
	local scienceId, scienceLv = Glory6Manager.getTrainScienceInfo(ArmyId)
	if scienceId ~=nil and scienceLv ~= nil  then
		local highTechData = HighTechController.getInstance():getScienceDataById(scienceId)
		local highTechLv = 0
		if highTechData then
			highTechLv = highTechData:getCurLevel()
		else
			return showUnlock
		end

	    --荣耀6解锁
		if scienceLv and (highTechLv < scienceLv) then showUnlock = true end
		return showUnlock
	end

	local unlock_science = CCCommonUtilsForLua:getPropByIdGroup("arms",ArmyId,"unlock_science")
	local unlock_civi_science = CCCommonUtilsForLua:getPropByIdGroup("arms",ArmyId,"unlock_civi_science")
	if unlock_science ~= "" then
		local sciencevec = CCCommonUtilsForLua:splitString(unlock_science,"|")
		for i=1,#sciencevec do
			local scienceCell = {}
			scienceCell = CCCommonUtilsForLua:splitString(sciencevec[i],";")
			if #scienceCell ==2 then
				local scienceId = tonumber(scienceCell[1])
				local value = tonumber(scienceCell[2])
				local scienceInfo = GlobalData:getProperty("scienceInfo")
				if scienceId ~= nil and value~=nil then
					local getName = scienceInfo:call("getInfoMapNameForLua",scienceId,value)
					if getName ~= "" then
						showUnlock = true
					end
				end
			end
		end
	end
	if unlock_civi_science ~= "" then 
		local sciencevec = CCCommonUtilsForLua:splitString(unlock_civi_science,"|")
		for i=1,#sciencevec do
			local scienceCell = {}
			scienceCell = CCCommonUtilsForLua:splitString(sciencevec[i],";")
			if #scienceCell ==2 then
				local scienceId = tonumber(scienceCell[1])
				local value = tonumber(scienceCell[2])
				local scienceInfo = GlobalData:call("shared"):getProperty("scienceInfo")				
				if scienceId ~= nil and value~=nil then
					local getName = scienceInfo:call("getInfoRaceMapNameForLua",scienceId,value)
					if getName ~= "" then
						showUnlock = true
					end
				end

			end
		end
	end

	return showUnlock
end

function Glory6Manager.getLockDataByArmyId(armyId)
	local lockData = {}

	--armyInfo为空
	local armyInfo = GlobalData:call("getArmyInfoById", armyId)
	if armyInfo == nil then 
		--新兵种的话是戒律大厅未解锁
		local new_arms = tonumber(CCCommonUtilsForLua:call("getPropById", armyId, "new_arms"))
		if new_arms == NEW_ARMY_TYPE then
			local open_arms = CCCommonUtilsForLua:call("getPropByIdGroup", "building", tostring(FUN_BUILD_NEWARMY), "open_arms")
			local solts = splitString(open_arms, "|")
			local unlockMap = {}
			for _, v in ipairs(solts) do
				local sl = splitString(v, ";")
				if #sl == 2 then
					unlockMap[sl[2]] = sl[1]
				end
			end
			table.insert(lockData, {
				id = FUN_BUILD_NEWARMY,
				lv = unlockMap[armyId],
				lockType = StrenLockType.building,
			})
		end
		return lockData 
	end

	local scienceId, scienceLv = Glory6Manager.getTrainScienceInfo(armyId)
	if scienceId and scienceLv then
		local highTechData = HighTechController.getInstance():getScienceDataById(scienceId)
		local highTechLv = 0
		if highTechData then
			highTechLv = highTechData:getCurLevel()
			if highTechLv < scienceLv then
				table.insert(lockData, {
											id = scienceId,
											lv = scienceLv,
											lockType = StrenLockType.highTech,
											name = highTechData:getName(),
											bookId = highTechData:getBookId(),
											chapterId = highTechData:getChapterId(),
										})
			end
		end
	end

	local unlock_science = CCCommonUtilsForLua:getPropByIdGroup("arms",armyId,"unlock_science")
	if unlock_science ~= "" then
		local sciencevec = CCCommonUtilsForLua:splitString(unlock_science,"|")
		for i=1,#sciencevec do
			local scienceCell = {}
			scienceCell = CCCommonUtilsForLua:splitString(sciencevec[i],";")
			if #scienceCell ==2 then
				local scienceId = tonumber(scienceCell[1])
				local value = tonumber(scienceCell[2])
				local scienceInfo = GlobalData:getProperty("scienceInfo")
				if scienceId ~= nil and value ~= nil then
					local getName = scienceInfo:call("getInfoMapNameForLua",scienceId,value)
					if getName ~= "" then
						table.insert(lockData, {
													id = scienceId,
													lv = value,
													lockType = StrenLockType.normal_science,
													name = getName,
												})
					end
				end
			end
		end
	end

	local unlock_civi_science = CCCommonUtilsForLua:getPropByIdGroup("arms",armyId,"unlock_civi_science")
	if unlock_civi_science ~= "" then 
		local sciencevec = CCCommonUtilsForLua:splitString(unlock_civi_science,"|")
		for i=1,#sciencevec do
			local scienceCell = {}
			scienceCell = CCCommonUtilsForLua:splitString(sciencevec[i],";")
			if #scienceCell ==2 then
				local scienceId = tonumber(scienceCell[1])
				local value = tonumber(scienceCell[2])
				local scienceInfo = GlobalData:call("shared"):getProperty("scienceInfo")				
				if scienceId ~= nil and value ~= nil then
					local getName = scienceInfo:call("getInfoRaceMapNameForLua",scienceId,value)
					if getName ~= "" then
						table.insert(lockData, {
													id = scienceId,
													lv = value,
													lockType = StrenLockType.civi_science,
													name = getName,
												})
					end
				end

			end
		end
	end

	return lockData
end

--------------------------CJY END--------------------------
function Glory6Manager.updateReduceData(data)
	if not data then return end

	if data.reduceCount then
		Glory6Manager.reduceCount = atoi(data.reduceCount)
	end

	if data.reduceNum then
		Glory6Manager.reduceNum = atoi(data.reduceNum)
	end
end

--每日祝福数据,forceClear/如果没有数据就置为0
function Glory6Manager.updateBlessData(data,forceClear)
	if not data then
		return
	end
	if not data.blessBuffValue and forceClear then
		Glory6Manager.blessBuffValue = 0
	elseif data.blessBuffValue then
		Glory6Manager.blessBuffValue = tonumber(data.blessBuffValue)
	end
	if data.blessBuffId then
		Glory6Manager.blessBuffId = data.blessBuffId
	end

	if data.blessCount then
		Glory6Manager.blessCount = tonumber(data.blessCount)
	end

	if data.blessCost then
		Glory6Manager.blessCost = tonumber(data.blessCost)
	end
end

--请求祷告礼堂基础数据
function Glory6Manager.reqStrengthenInfo()
	local cmd = Drequire("game.command.Glory6StrengthenInfoCmd").create()
	cmd:send()
end
--是否免费
function Glory6Manager.chechShowRedPoint()
	if Glory6Manager.blessCount and Glory6Manager.blessCost then
		if Glory6Manager.blessCount > 0 and Glory6Manager.blessCost == 0 then
			return true
		end		
	end
	return false
end

return Glory6Manager
