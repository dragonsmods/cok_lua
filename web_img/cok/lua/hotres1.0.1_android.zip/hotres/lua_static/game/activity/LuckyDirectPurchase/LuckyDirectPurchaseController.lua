-- @Author:fenghaibin 
-- @Date: 2020-04-27
-- @Description: 幸运直购控制类

local superClass = require("game.controller.KpiActMgr")
local LuckyDirectPurchaseController = class("LuckyDirectPurchaseController",superClass)

local _instance = nil
function LuckyDirectPurchaseController.getInstance()
    if _instance == nil then
        _instance = LuckyDirectPurchaseController.new()
        guiCommonGlobal.controllerAutoPurge(_instance)
    end
    return _instance
end

function LuckyDirectPurchaseController:ctor()
    superClass.ctor(self,"57530","LuckyDirectPurchase_face","lucky_lottery_buy")
	self.m_refreshViewEvent = utils.getEventClass():new()
	self.m_lotteryEvent = utils.getEventClass():new()
	self.m_rwdRefreshEvent = utils.getEventClass():new()
end

function LuckyDirectPurchaseController:getCurTicketId()
	return "36004934"
end

function LuckyDirectPurchaseController:showView( )
	if self:isOpen() and not isCrossServerNow() then
		if CCLoadSprite:call("loadDynamicResourceByName", self.m_dynRes) then
            local view = Drequire("game.activity.LuckyDirectPurchase.LuckyDirectPurchaseView"):create()
    		PopupViewController:addPopupInView(view)
        else
            self:getResNoticer():showNotice()
        end
    end
end

function LuckyDirectPurchaseController:requestInfo(  )
	utils.requestServer( 'luckylotterybuy.data', nil, nil, function ( tbl )
		-- utils.dump( tbl, 'luckylotterybuy.data,,,' )
		self.m_curData = tbl
		self:parseData()
		self:reqRewards()
		if self:isShowCanLottery() then
			self:showRedDot(true)
		end
		self.m_refreshViewEvent:emit(tbl)
	end )
end

function LuckyDirectPurchaseController:requestFreeRwd()
	utils.requestServer( 'luckylotterybuy.daily_reward', nil, nil, function ( tbl )
		-- utils.dump( tbl, 'luckylotterybuy.daily_reward,,,' )
		self.m_curData.nextFreeTime = tbl.nextFreeTime
		if not self:isShowCanLottery() then
			self:showRedDot(false)
		end
		createTableFlyReward(tbl.rewardArray)
		self.m_rwdRefreshEvent:emit()
	end )
end

function LuckyDirectPurchaseController:requestLoterry( num )
	utils.requestServer( 'luckylotterybuy.lottery', {{"num",CCInteger:create(num)}}, nil, function ( tbl )
		-- utils.dump( tbl, 'luckylotterybuy.lottery,,,' )
		if not table.isNilOrEmpty( tbl ) then
			if not self:isShowCanLottery() then
				self:showRedDot(false)
			end
			self.m_lotteryEvent:emit(tbl)
		end
	end )
end

function LuckyDirectPurchaseController:parseData( )
	if self.m_curData then
		if not table.isNilOrEmpty(self.m_curData.goodsArray) then
			table.sort(self.m_curData.goodsArray, function(a,b)
				return a.index and b.index and atoi(a.index) < atoi(b.index)
			end)
		end

		local firstRwd = self.m_curData.goodsArray[1]
		local firstItem_cp = utils.getExtendClass( 'itemComponent' ):create(nil, firstRwd.goodsType,firstRwd.goodsId)
		-- local info = ToolController:call("getToolInfoForLua",  atoi(firstRwd.goodsId))
		self.bigRwdName = firstItem_cp:getName()
	end
end

function LuckyDirectPurchaseController:reqRewards()
    local rewardIdList = {}
    local idRwd = self.m_curData.dailyRewardId
    if not string.isNilOrEmpty( idRwd ) then
        if not self:getRewards( idRwd ) then
            table.insert(rewardIdList,idRwd)
        end
    end
    if not table.isNilOrEmpty(rewardIdList) 
        and self:getRewardRequester() 
        and self:getRewardRequester().startReqIds then
        self:getRewardRequester():startReqIds(rewardIdList)
    end
end

function LuckyDirectPurchaseController:getRewardRequester()
    local rewardRequster = utils.getReqMultiRewardImplClass():new()
    rewardRequster.onGetRewardDetailBack = function ( rewardRequsterSelf,data,fromType )
        self:onGetRewardDetailBack(data,fromType)
    end
    return rewardRequster
end

function LuckyDirectPurchaseController:onGetRewardDetailBack(data,fromType)
    self.rewardList = data
end

function LuckyDirectPurchaseController:getRewards( rwdId )
    if self.rewardList then 
        return table.find(self.rewardList, function(cur)
            return cur.id == rwdId
        end)
    else 
        return nil
    end
end

function LuckyDirectPurchaseController:getRedDotCount(  )
    if not self.m_curData then
        self:requestInfo()
        return 0
    else
        local tn = self:isShowCanLottery() and 1 or 0
        return tn
    end
end

function LuckyDirectPurchaseController:isShowCanLottery()
	if table.isNilOrEmpty(self.m_curData) then
		return false
	end
	if self:canGetFreeeRwd() then
		return true
	end
	if self:tiemNotOpen() then
		local toolInfo = ToolController:call("getToolInfoForLua", tonumber(self.m_curData.luckyIconId))
		if toolInfo then
			local stoneCount = toolInfo:call("getCNT")
			if tonumber(stoneCount) >= tonumber(self.m_curData.lotteryCost) then
				return true
			end
		end
	end
	return false
end

function LuckyDirectPurchaseController:canGetFreeeRwd(  )
	if self.m_curData then
		local curTime = getTimeStamp()
		local nextFreeTime = tonumber(self.m_curData.nextFreeTime) / 1000
		if curTime > nextFreeTime then
			return true
		end
	end
	return false
end

function LuckyDirectPurchaseController:showRedDot( isShow )
	if self.m_redDotShow == isShow then
		return
	end

	self.m_redDotShow = isShow
	if isShow then
		self:addDotAfterCheck()
	else
		self:removeDot(true)
	end
end

function LuckyDirectPurchaseController:tiemNotOpen()
	local actId = self:getActId()
	return not ActivityController.getInstance():isActivityOpenWithTime(actId)
end

function LuckyDirectPurchaseController:canBuyExchange()
	if self.m_curData then
		local curTime = getTimeStamp()
		local midEndTime = tonumber(self.m_curData.midEndTime) / 1000
		if midEndTime > curTime then
			return true
		end
	end
	return false
end

return LuckyDirectPurchaseController