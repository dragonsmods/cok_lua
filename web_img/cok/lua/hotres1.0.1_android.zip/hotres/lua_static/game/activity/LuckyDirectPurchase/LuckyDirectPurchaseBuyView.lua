-- @Author:fenghaibin 
-- @Date: 2020-05-07
-- @Description: 幸运直购 礼包购买页

local LuckyDirectPurchaseBuyView = class("LuckyDirectPurchaseBuyView", function()
    return cc.Layer:create() 
end)

local tabInterval = 185
local selectScale = 1.5
local commScale = 1
local selectPosX = 0
function LuckyDirectPurchaseBuyView:create(viewSize)
	local view = LuckyDirectPurchaseBuyView.new()
    utils.getExtendClass( "Template_ui" ):create(view,"LuckyDirectPurchaseBuyView.ccbi",0,viewSize,true,
    	{ "onBtnRight", "onBtnLeft", "onBtnBuy", "onFreeBoxBtn" })
    view.ctl = require("game.activity.LuckyDirectPurchase.LuckyDirectPurchaseController").getInstance()
	if view:initView() then 
    	return view 
    end
end

function LuckyDirectPurchaseBuyView:onEnter()
	registerScriptObserver(self, self.onPayBack, PAYMENT_COMMAND_RETURN)
	self.ctl.m_refreshViewEvent:add(self.refreshView, self)
	self.ctl.m_rwdRefreshEvent:add(self.refreshView,self)
	self.m_entryId = self:getScheduler():scheduleScriptFunc(function(dt) self:update(dt) end, 0, false)
end

function LuckyDirectPurchaseBuyView:onExit()
	unregisterScriptObserver(self, PAYMENT_COMMAND_RETURN)
	self.ctl.m_refreshViewEvent:remove(self.refreshView,self)
	self.ctl.m_rwdRefreshEvent:remove(self.refreshView,self)
    self:getScheduler():unscheduleScriptEntry(self.m_entryId)
end

function LuckyDirectPurchaseBuyView:update()
    local nowtime = tonumber(getTimeStamp())
    if not self.m_data.endTime and not self.m_data.taskEndTime then 
    	return 
    end

    local lastTime = 0
	local midEndTime = tonumber(self.m_data.midEndTime) / 1000
	local endtime = tonumber(self.m_data.endTime) / 1000

    if midEndTime > nowtime then
    	lastTime = format_time(midEndTime - nowtime)
    	self.ui.m_duringTimeTxt:setString(getLang("4249502", lastTime))
    else
		if not self.setDuringTime then
			self.ui.m_duringTimeTxt:setString(getLang("105801"))
			self.setDuringTime = true
		end
	end

	for k,v in ipairs(self.m_boxSprTbl) do
		local pos_x = v.boxSpr:getPositionX()
		if pos_x < -270 or pos_x > 270 then
			v.boxSpr:setVisible(false)
		else
			v.boxSpr:setVisible(true)
		end
	end 
end

function LuckyDirectPurchaseBuyView:closeSelf()
	PopupViewController:call("removePopupView", self)
end

function LuckyDirectPurchaseBuyView:initView()
	self.m_data = self.ctl.m_curData
	if table.isNilOrEmpty(self.m_data) then
		return true
	end
	self:initAnimAndParticle()
	self:initTableView()
	self.ui.m_freeBoxOpen:setVisible( false )
	self.ui.m_particle:setVisible( true )
	self.ui.m_labelBought:setString(getLang("660802"))  -- 660802=已结束
	self.ui.m_perSymbolTxt:setString("%")
	self.ui.m_offTxt:setString("OFF")
	self.ui.m_desTxt:setString(getLang("9461394"))
	-- self:registerTouchFuncs()
	local touchLayer = cc.Layer:create()
    function onTouch(eventType, x, y)
        if eventType == "began" then  
            return self:onTouchBegan(x, y)  
        elseif eventType == "moved" then  
            return self:onTouchMoved(x, y)  
        else  
            return self:onTouchEnded(x, y)  
        end
    end
    self:addChild(touchLayer)
    touchLayer:setTouchEnabled(true)
    touchLayer:registerScriptTouchHandler(onTouch)
    touchLayer:setSwallowsTouches(false)
    self._touchLayer = touchLayer

	self.m_boxSprTbl = {
		{boxSpr = self.ui.m_box1, isRuningAction = false},
		{boxSpr = self.ui.m_box2, isRuningAction = false},
		{boxSpr = self.ui.m_box3, isRuningAction = false},
		{boxSpr = self.ui.m_box4, isRuningAction = false},
		{boxSpr = self.ui.m_box5, isRuningAction = false}
	}
	-- self.m_curSelectBox = 1
	self:initCurSelectBox()
	self.m_boxCount = self.m_data.exchangeDataArray and #self.m_data.exchangeDataArray
	self:initActTime()
    self:refreshView()
	return true
end

function LuckyDirectPurchaseBuyView:initCurSelectBox( )
	if table.isNilOrEmpty(self.m_data) and table.isNilOrEmpty(self.m_data.exchangeDataArray) then
		return
	end
	local _,idxs = table.find(self.m_data.exchangeDataArray, function(cur)
		return cur.nowBuyTimes ~= cur.buyTimes
	end)
	self.m_curSelectBox = idxs and idxs or 1
end

function LuckyDirectPurchaseBuyView:initAnimAndParticle( )
    self.ui.m_particle:removeAllChildren()
    local rootPath = CCFileUtils:sharedFileUtils():getWritablePath().."dresource/"
    local plistPath = rootPath.."skinparticle/"
    local particles={"richangfulibaoxiang3_star","richangfulibaoxiang3fx4"}
    for k,v in pairs(particles) do
        local particle = ParticleController:call("createParticleForLua", plistPath..v..".plist")
        if particle then 
            self.ui.m_particle:addChild(particle)
        end
    end
    self.ui.m_boxParticle:removeAllChildren()
    local particleLoop = ParticleController:call("createParticleForLua", plistPath.."LuckyDirectPurchase_xhlizi.plist")
    if particleLoop then 
        self.ui.m_boxParticle:addChild(particleLoop)
    end	
    self.ui.m_boxAnim:removeAllChildren()
	local animaObj = utils.createSpine( 'LuckyDirectPurchase_face', 'animation' )
	if animaObj then
		animaObj:setScale( 0.9 )
		self.ui.m_boxAnim:addChild(animaObj)
	end
end

function LuckyDirectPurchaseBuyView:initActTime()
	local obj = ActivityController:call("getActObj", self.ctl:getActId())
	local nowtime = getWorldTime()
	if obj then
		local startTime = tonumber(obj:getProperty("startTime"))
		local endTime = tonumber(obj:getProperty("endTime"))
		local s_time = startTime
		local e_time = endTime - 1	--活动结束时间临界值处理
		local s_mStr = os.date("!%Y.%m.%d",s_time)
		local e_mStr = os.date("!%Y.%m.%d",e_time)
		local timeStr = s_mStr .. "-" .. e_mStr
		-- self.ui.m_duringTimeTxt:setString(timeStr)
	end
end

function LuckyDirectPurchaseBuyView:refreshView( tbl )
	if not table.isNilOrEmpty(tbl) then
		self.m_data = self.ctl.m_curData
	end
    if not self.ctl:canGetFreeeRwd() then
        self.ui.m_freeBoxOpen:setVisible( true )
        self.ui.m_freeBoxClosed:setVisible( false )
        self.ui.m_particle:setVisible( false )
        self.ui.m_FreeBoxBtn:setEnabled( false )
        self.ui.m_pLabelGetFree:setString(getLang("101312"))
    else
        self.ui.m_freeBoxOpen:setVisible( false )
        self.ui.m_freeBoxClosed:setVisible( true )
        self.ui.m_particle:setVisible( true )
        self.ui.m_FreeBoxBtn:setEnabled( true )
        self.ui.m_pLabelGetFree:setString(getLang("137702"))
	end

	self:refreshBoxList()
	local nowBuyTimes = self.m_data.exchangeDataArray[self.m_curSelectBox].nowBuyTimes
	local maxBuyTimes = self.m_data.exchangeDataArray[self.m_curSelectBox].buyTimes
	self.ui.m_limitBuyTxt:setString(getLang("9461393", nowBuyTimes,maxBuyTimes))	-- 9461393=每日限购次数：{0}/{1}
	if string.isNilOrEmpty(nowBuyTimes) or string.isNilOrEmpty(maxBuyTimes) then
		self.ui.m_btnBuy:setEnabled(false)
	else
		local canBuyTimes = tonumber(maxBuyTimes) - tonumber(nowBuyTimes)
		self.ui.m_btnBuy:setEnabled(canBuyTimes > 0 and self.ctl:canBuyExchange())
	end

	local exchange_id = self.m_data.exchangeDataArray[self.m_curSelectBox].exchangeId
	local exchangeData = LiBaoController.getInstance():getGoldExchangeItemById(exchange_id)
	if exchangeData then
		self.exchangeData = exchangeData
		self:refreshLibaoItems(exchangeData)
		self.m_tableView:setVisible(true)
		self.ui.m_labelBought:setVisible(false)
		self.ui.m_discountNode:setVisible(true)
		self.ui.m_limitBuyTxt:setVisible(true)
	else
		self.exchangeData = nil
		self.m_tableView:setVisible(false)
		CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnBuy, getLang("660802"))  -- 660802=已结束
		self.ui.m_labelBought:setVisible(true)
		self.ui.m_discountNode:setVisible(false)
		self.ui.m_limitBuyTxt:setVisible(false)
	end
end

function LuckyDirectPurchaseBuyView:onBtnRight( )
	if self:isAciontRun() then
		return
	end
	self:spinNodes(true)
end

function LuckyDirectPurchaseBuyView:onBtnLeft( )
	if self:isAciontRun() then
		return
	end
	self:spinNodes(false)
end

function LuckyDirectPurchaseBuyView:onBtnBuy( pSender )
	if utils.delayClickBtn( pSender, 1.5 ) then
		return
	end
	if self.exchangeData then
		self.ui.m_btnBuy:setEnabled(false)
		LiBaoController.getInstance():callPayment(self.exchangeData.id)
	end
end

function LuckyDirectPurchaseBuyView:onTouchBegan(x, y)
	if touchInside(self.ui.m_touchLayer, x, y) then
		local pos = cc.p(x,y)
		self.m_Boxoffset = 0
        self.touchPos = pos
    	self.touchedIn = true
    end
    return true
end

function LuckyDirectPurchaseBuyView:onTouchMoved(x, y)
	if self.touchedIn then
		local pos = cc.p(x,y)
		local distance = ccpSquareDistance(self.touchPos, pos)
		if distance > 100 and not self:isAciontRun() then
			self:spinNodes(pos.x > self.touchPos.x)
			self.touchPos = pos
		end
	end
end

function LuckyDirectPurchaseBuyView:onTouchEnded(x, y)
    if self.touchedIn then 
		self.touchedIn = false
    end
end

function LuckyDirectPurchaseBuyView:spinNodes( isToRight )
	-- self.isRuningAction = true
	if isToRight then
		if self.m_curSelectBox == 1 then
			self.m_curSelectBox = self.m_boxCount
		else
			self.m_curSelectBox = self.m_curSelectBox - 1
		end
	else
		if self.m_curSelectBox == self.m_boxCount then
			self.m_curSelectBox = 1
		else
			self.m_curSelectBox = self.m_curSelectBox + 1
		end
	end

	local actionTime = 0.4
	local endPos = tabInterval * 2
	local startPos = - tabInterval * 2
	local nodeTbl = self.m_boxSprTbl
	for _,v in ipairs(nodeTbl) do
		v.isRuningAction = true
		local v_x = v.boxSpr:getPositionX()
		local afterX = 0
		if isToRight then
			if v_x == endPos then
				afterX = v_x
			else
				afterX = v_x + tabInterval
			end
		else
			if v_x == startPos then
				afterX = v_x
			else
				afterX = v_x - tabInterval
			end
		end
		local afterScale = afterX == selectPosX and selectScale or commScale
		local moveto = cc.MoveTo:create(actionTime, cc.p(afterX, 0))
		local scaleto = cc.ScaleTo:create(actionTime, afterScale)
		local function callback()
			v.isRuningAction = false
			if not self:isAciontRun() then
				-- self:refreshBoxList( )
				self:refreshView( )
				self:resetSelectPar( )
			end
		end
		local func = cc.CallFunc:create(callback)
		local spa = cc.Spawn:create(moveto, scaleto)
		local seq1 = cc.Sequence:create(spa, func)
		v.boxSpr:runAction(seq1)
	end
end

function LuckyDirectPurchaseBuyView:isAciontRun( )
	return table.find(self.m_boxSprTbl, function ( cur )
		return cur.isRuningAction
	end)
end

function LuckyDirectPurchaseBuyView:refreshBoxList( )
	local nodeTbl = self.m_boxSprTbl
	for k,v in ipairs(nodeTbl) do
		local boxNameNum = 1 
		if k > 3 then
			v.boxSpr:setPositionX(tabInterval*(k-6))
			boxNameNum = self.m_boxCount + k - 5
			boxNameNum = math.mod((boxNameNum + self.m_curSelectBox - 1), self.m_boxCount)
		else
			v.boxSpr:setPositionX(tabInterval*(k-1))
			boxNameNum = math.mod(self.m_curSelectBox + k - 1, self.m_boxCount)
		end
		if boxNameNum == 0 then
			boxNameNum = self.m_boxCount
		end
		-- local picName = string.format("LuckyDirectPurchaseBox%d.png", boxNameNum)
		local picNameTbl = { "item791.png","item608.png","item609.png","item610.png","item302.png" }
		local picName = picNameTbl[boxNameNum]
		local sf = utils.getSafeSpriteFrame( picName, 'blankFrame.png' )
		v.boxSpr:setSpriteFrame(sf)

		local pos_x = v.boxSpr:getPositionX()
		if pos_x == selectPosX then
			v.boxSpr:setScale( selectScale )
		else
			v.boxSpr:setScale( commScale )
		end
		if pos_x < -270 or pos_x > 270 then
			v.boxSpr:setVisible(false)
		else
			v.boxSpr:setVisible(true)
		end
	end
end

function LuckyDirectPurchaseBuyView:resetSelectPar( )
	local rootPath = CCFileUtils:sharedFileUtils():getWritablePath().."dresource/"
    local plistPath = rootPath.."skinparticle/"
    local particleSelect1 = ParticleController:call("createParticleForLua", plistPath.."LuckyDirectPurchase_xuanzhong1.plist")
	local particleSelect2 = ParticleController:call("createParticleForLua", plistPath.."LuckyDirectPurchase_xuanzhong2.plist")
	if particleSelect1 and particleSelect2 then
		self.ui.m_boxSelcectPar:removeAllChildren()
		self.ui.m_boxSelcectPar:addChild(particleSelect1)
		self.ui.m_boxSelcectPar:addChild(particleSelect2)
	end
end

function LuckyDirectPurchaseBuyView:refreshLibaoItems( exchangeItem )
	local price = LuaController:call("getDollarString", exchangeItem.dollar, exchangeItem.product_id)
	CCCommonUtilsForLua:setButtonTitle(self.ui.m_btnBuy, price)
	local percent = exchangeItem.percent and tonumber(exchangeItem.percent) or 1000
	local offNum = 100 - percent / 100
	self.ui.m_offNum:setString(string.format("%d", offNum))

	local p_arr = string.splitNSep( exchangeItem.item, "|;" )
	local rewardData = {}
	for k,v in ipairs(p_arr) do
		local data = {
			type = v[3] or "7",
			value = {
				id = v[1],
				num = v[2] or "1"
			}
		}
		table.insert(rewardData,data)
	end
	-- utils.dump(rewardData,"refreshLibaoItems~~~")
	self.m_exchageData = rewardData
	self.m_tableView:reloadData()
end

function LuckyDirectPurchaseBuyView:initTableView( )
	local delegate = {}
    delegate.gridAtIndex = function(tab, idx) return self:gridAtIndex(tab, idx) end
    delegate.numberOfCellsInTableView = function(tab) return self:numberOfCellsInTableView(tab) end
    delegate.numberOfGridsInCell = function(tab) return self:numberOfGridsInCell(tab) end
    delegate.gridSizeForTable = function(tab, idx) return self:gridSizeForTable(tab, idx) end

    self.ui.m_listNode:removeAllChildren()
    local size = self.ui.m_listNode:getContentSize()
    self.m_tableView = Drequire("game.utility.TableViewMultiCol").new(size)
    self.m_tableView:setDelegate(delegate)
    self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
    self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
    -- self.m_tableView:reloadData()
    self.ui.m_listNode:addChild(self.m_tableView)
end

function LuckyDirectPurchaseBuyView:gridAtIndex(tab, idx)
    local luaIdx = idx + 1
    if luaIdx > #self.m_exchageData then return end
    
    local cell = tab:dequeueGrid()
    if not cell then 
        cell = Drequire("game.activity.LuckyDirectPurchase.LuckyDirectPurchaseCell"):create() 
    end

    local newTbl = LibaoCommonFunc.changeRewardToTbl(self.m_exchageData[luaIdx])
    cell:refreshCell(newTbl)
    return cell
end

function LuckyDirectPurchaseBuyView:numberOfCellsInTableView()
    -- cclog("numberOfCellsInTableView %s",#self.m_exchageData)
    return math.ceil(#self.m_exchageData / 4)
end

function LuckyDirectPurchaseBuyView:numberOfGridsInCell()
    return 4
end

function LuckyDirectPurchaseBuyView:gridSizeForTable()
    return 140, 140
end

function LuckyDirectPurchaseBuyView:onPayBack()
	self.ctl:requestInfo()
end

function LuckyDirectPurchaseBuyView:onFreeBoxBtn()
	self.ctl:requestFreeRwd()
end

return LuckyDirectPurchaseBuyView