-- @Author: tangwen
-- @Date:   2019-06-03 16:14:07
-- @Last Modified by:   tangwen
-- @Last Modified time: 2020-02-04 11:04:47
local MultiplyGiftView = class("MultiplyGiftView", cc.Layer, utils.getAutoManageClass(),
	utils.getExtendClass("adaptPadClass"))

local MultiplyGiftBox = class("MultiplyGiftBox",cc.Node)

local YesNoDialogSuper = require("game.CommonPopup.YesNoDialog2")
local YesNoDialog2 = class("YesNoDialog_MultiplyGiftView",YesNoDialogSuper)

local GiftBoxType = utils.toNumberEnum({
	{"Mul_1",1},
	{"Mul_2"},
	{"Mul_4"},
	{"Mul_8"},
	{"Mul_16"},
	{"Mul_32"},
})

local GiftBoxConfig = {
	[GiftBoxType.Mul_1] =  {picName="mul_gi_01.png",greayName="mul_gi_10.png",mulPic="mul_gi_m1.png",mulName="x1" ,mulPos = cc.p(20 , -19)},
	[GiftBoxType.Mul_2] =  {picName="mul_gi_01.png",greayName="mul_gi_10.png",mulPic="mul_gi_m2.png",mulName="x2" ,mulPos = cc.p(-10 , -57)},
	[GiftBoxType.Mul_4] =  {picName="mul_gi_01.png",greayName="mul_gi_10.png",mulPic="mul_gi_m4.png",mulName="x4" ,mulPos = cc.p(18 , -29)},
	[GiftBoxType.Mul_8] =  {picName="mul_gi_01.png",greayName="mul_gi_10.png",mulPic="mul_gi_m8.png",mulName="x8" ,mulPos = cc.p(20 , -28)},
	[GiftBoxType.Mul_16] = {picName="mul_gi_01.png",greayName="mul_gi_10.png",mulPic="mul_gi_16.png",mulName="x16",mulPos = cc.p(1 , -30)},
	[GiftBoxType.Mul_32] = {picName="mul_gi_01.png",greayName="mul_gi_10.png",mulPic="mul_gi_32.png",mulName="x32",mulPos = cc.p(1 , -34)},
}

function YesNoDialog2.create(title, content, okCallback)
	local view = YesNoDialog2.new()
	Drequire("game.CommonPopup.YesNoDialog2_ui"):create(view, 0)

	view:initView(title, content, okCallback)
  	return view
end

function YesNoDialog2:initView(title, content, okCallback)
	YesNoDialogSuper.initView(self,title, content, okCallback)

	local r = {
		{self.ui.m_btnCancel,{self.ui.m_btnOK:getPosition()},getLang("9900159")},
		{self.ui.m_btnOK,{self.ui.m_btnCancel:getPosition()},getLang("9900158")},
	}

	for _,v in ipairs(r) do
		v[1]:setPosition(cc.p(v[2][1],v[2][2]))
		CCCommonUtilsForLua:setButtonTitle(v[1], v[3])
	end
end

function MultiplyGiftBox:ctor(boxType)
	boxType = boxType or GiftBoxType.Purple
	local  proxy = cc.CCBProxy:create()
    local ccbiURL = ""

    ccbiURL = "ccbi/MultiplyGiftBox.ccbi"
    local ccbNode = CCBReaderLoad(ccbiURL,proxy, self)
    if ccbNode == nil then
        dump("MultiplyGiftBox loadccb error")
        return false
    end

    self.m_startY = 115

    self.m_picName = "mag_ca01.png"
    self.m_defName = "blankFrame.png"

    local btn = self.m_boxBtn
    btn:addHandleOfControlEvent(handler(self,self.onBoxClick), cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE)
	btn:addHandleOfControlEvent(function ( pSender,event_type )
		pSender.m_hadTouched = false
	end, cc.CONTROL_EVENTTYPE_DRAG_OUTSIDE)

	btn:addHandleOfControlEvent(function ( pSender,event_type )
		pSender.m_hadTouched = true
	end, cc.CONTROL_EVENTTYPE_TOUCH_DOWN)

    -- self.m_ropePool = Drequire("utils.nodePool").new(self.m_ropeRoot,function (  )
    -- 	return utils.getSafeSprite( self.m_picName,self.m_defName )
    -- end)
    self:addChild(ccbNode)
	self:setboxType(boxType)
end

function MultiplyGiftBox:onBoxClick( pSender )
	if self.m_isCan then
		cclog("onBoxClick,,,")
		local view = YesNoDialog2.create(getLang("107527"), getLang("9900155"), function (  )
			require("game.activity.MultiplyGift.MultiplyGiftMgr").getInstance():requestReward()	
		end)

		PopupViewController:addPopupView(view)
	end
end

function MultiplyGiftBox:setboxType( boxType )
	if self.m_boxType == boxType then
		return
	end

	self.m_boxType = boxType

	local gc = GiftBoxConfig[boxType]
	self.m_gc = gc
	local s1,s2 = gc.picName,"blankFrame.png"
	local sf = utils.getSafeSpriteFrame(s1,s2)
	self.m_boxPic:setSpriteFrame(sf)

	s1 = gc.mulPic
	local sf = utils.getSafeSpriteFrame(s1,s2)
	self.m_mulpic:setSpriteFrame(sf)
	self.m_mulpic:setPosition(gc.mulPos)


	-- local sf = self.m_curCardBubble
	-- if not sf then
	-- 	sf = utils.getSafeSprite(s1,s2)
	-- 	self:addChild(sf)
	-- else
	-- 	sf:setSpriteFrame(s1,s2)
	-- end

	-- cclog("will setbox name %s",gc.mulName)
	-- self.m_txt2:setString(gc.mulName)
end

function MultiplyGiftBox:setGray( bGray )
	-- CCCommonUtilsForLua:call("setSpriteGray", self.m_boxPic, bGray)
	self.m_boxPic:setSpriteFrame(bGray and self.m_gc.greayName or self.m_gc.picName)
end

function MultiplyGiftBox:animateBox( isAnimate )
    local boxRoot = self.m_boxPic
    boxRoot:stopAllActions()
    boxRoot:setRotation(0)

    local hdScale = 1.0
    boxRoot:setScale(1.0 * hdScale)

    self:setGray(not isAnimate)
    if isAnimate then
        local dely = cc.DelayTime:create(1.0)
        local scaleTo1 = cc.ScaleTo:create(0.2, 1.0 * hdScale + 0.1)
        local scaleTo2 = cc.ScaleTo:create(0.2, 1.0 * hdScale)
        local ro1 = cc.RotateTo:create(0.1, -7.5)
        local ro2 = cc.RotateTo:create(0.1, 7.5)
        local ro3 = cc.RotateTo:create(0.1, 0)

        local seq = cc.Sequence:create(scaleTo1, ro1, ro2, ro3, scaleTo2, dely)
        boxRoot:runAction(CCRepeatForever:create(seq))
    end
end

function MultiplyGiftBox:setCanGetReward( isCan,hadTaken )
	if self.m_isCan == isCan then
		return
	end
	self.m_isCan = isCan
	self:animateBox(isCan)
	-- self.m_awardStatus:setString(isCan and getLang("133251") or (hadTaken and getLang("140238") or getLang("133268")))
end

function MultiplyGiftBox:setBoxInfo( bInfo )
	self.m_boxInfo = bInfo
end


function MultiplyGiftView:ctor(data,viewSize)
    CCLoadSprite:call("loadDynamicResourceByName", "MulGift_face")
    utils.getExtendClass( "Template_ui", true ):create(self,"MultiplyGiftView.ccbi",0,viewSize,false,{"onBuyBtnClick","onFinalClick","onHelpClick"})
    self:initView(data)
end

function MultiplyGiftView:closeSelf(  )
	PopupViewController:call("removePopupView", self)
end

function MultiplyGiftView:onExit()
  
end

function MultiplyGiftView:onCleanup()
	self.m_mgrIns:getEnergyEvent():remove(self.onEnergyResp,self)
	unregisterScriptObserver(self, PAYMENT_COMMAND_RETURN)
end

function MultiplyGiftView:onEnergyResp( data )
	self.m_data = data
	self:refreshCurMul(data)
	self:refreshBuyBtn(data)
	self:refreshBoxState(data)
	self:refreshReward(data)
	self:refreshFinalBtn(data)

	if self.m_mgrIns:isLastBuyEnable(data) then
		self.m_mgrIns:showFinalLibao(data)
	elseif self.m_mgrIns:isLastBuyOverTime(data) then
		self:hanldeFinalOverTime(data)
	end

	self:tryGetLastReward()
end

function MultiplyGiftView:onPaymentBack(  )
	self:runAction(utils.getDelayAction(2,function (  )
		self.m_mgrIns:requestInfo("MultiplyGiftView")	
	end))
end

function MultiplyGiftView:initView(data)
	self.m_data = data
	self.m_mgrIns = require("game.activity.MultiplyGift.MultiplyGiftMgr").getInstance()
	self.m_mgrIns:getEnergyEvent():add(self.onEnergyResp,self)
	registerScriptObserver(self, self.onPaymentBack, PAYMENT_COMMAND_RETURN)

	local staticTextArr = {
		{self.ui.m_curGiftDesc,"9900149"},
	}

	for i,v in ipairs(staticTextArr) do
		v[1]:setString(getLang(v[2],v[3]) )
	end

	utils.getExtendClass( 'adaptLabelTTF' ).attachToLabel(self.ui.m_dailyDesc,getLang( '9900154' ))

	local buttonTextArr = {
		{self.ui.m_buyBtn,""},
		{self.ui.m_switchBtn2,getLang( "176884" ) },
	}

	for _,v in ipairs(buttonTextArr) do
		CCCommonUtilsForLua:setButtonTitle(v[1], v[2])
	end

	local blankFrameArr = {
		self.ui.m_mul_x,self.ui.m_mulNumSpr
	}

	for _,v in ipairs(blankFrameArr) do
		v:setSpriteFrame(utils.getSafeSpriteFrame( 'blankFrame.png', 'blankFrame.png' ))
	end

	local dy = 30
	local box_config = {
		{cc.p(66 , -718  + dy), GiftBoxType.Mul_1},
		{cc.p(185 , -560 + dy),GiftBoxType.Mul_2},
		{cc.p(296 , -688 + dy),GiftBoxType.Mul_4},
		{cc.p(463 , -578 + dy),GiftBoxType.Mul_8},
		{cc.p(334 , -416 + dy),GiftBoxType.Mul_16},
		{cc.p(495 , -273 + dy),GiftBoxType.Mul_32},
	}

	if CCCommonUtilsForLua:isIosAndroidPad() then
		box_config[#box_config][1] = cc.p(334 + 220 , -416 + dy)
		box_config[#box_config - 1][1].y = box_config[#box_config - 1][1].y - 25
	end

	local boxArr = {}
	for i,v in ipairs(box_config) do
		local tn = MultiplyGiftBox:create(v[2])
		tn:setPosition(v[1])
		self.ui.m_boxRoot1:addChild(tn)
		tn.m_curLevel = i
		table.insert(boxArr,tn)
	end
	self.m_boxArr = boxArr

	if not table.isNilOrEmpty( data ) then
		self:refreshCurMul(data)
		self:refreshBuyBtn(data)
		self:refreshBoxState(data)
		self:refreshReward(data)
		self:refreshFinalBtn(data)

		if self.m_mgrIns:isLastBuyEnable(data) then
			self.m_mgrIns:showFinalLibao(data)
		elseif self.m_mgrIns:isLastBuyOverTime(data) then
			self:hanldeFinalOverTime(data)
		end
	end

	self:tryGetLastReward()

	local ts = 0.9
	self:adaptForPad(
	{
		{node=self.ui.m_boxRoot1,offy=20 + 150},
		{node=self.ui.m_arrowPic,offy=150},
		{node=self.ui.m_finalNode,offy=-20},
		{node=self.ui.m_bottom,offy=-20,offx=self.ui.m_sprBg2:getContentSize(  ).width * (1 - ts) / 2},
	}
    )

    if CCCommonUtilsForLua:isIosAndroidPad() then
    	self.ui.m_bottom:setScale( ts )
	end

    self:removeRedDot()

	if not self.m_mgrIns:getOneTimeFlag():getFlag() then
		self:runAction(utils.getDelayAction( 1, function (  )
			CCSafeNotificationCenter:call("postNotification", MSG_UPDATE_TIP_COUNT_MAIN)
		end ))
	end

	local _,leftTime = ActivityController.getInstance():isActivityOpenWithTime(self.m_mgrIns:getActId())
	if leftTime then
		self.ui.m_actTimeTxt:setLocalZOrder( 2 )
		utils.attachCDForLabel( self.ui.m_actTimeTxt, leftTime, nil, nil, nil,  '105805' )
		utils.attachBgToLabel( self.ui.m_actTimeTxt )
	end

	local actId = self.m_mgrIns:getActId()
    LogController:postEventLog("LogActivityEntrance", {actId = actId, pos = 1 , TIME = getTimeStamp()})


	self:runAction(utils.getDelayAction(1,function (  )
		local todayNotice = self.m_mgrIns:getTodayNotice()
		if todayNotice:canSetOneDayFlagTrue() then
			self:showHelp()
			todayNotice:setFlag(true)
		end
	end))
    return true
end

function MultiplyGiftView:hanldeFinalOverTime( data )
	self.ui.m_buyBtn:setEnabled(false)
	if tonumber(data.canResetTimes) > 0 then
		self.m_mgrIns:requestReset()
	end
end

function MultiplyGiftView:tryGetLastReward(  )

	if not table.isNilOrEmpty( self.m_data ) and self.m_mgrIns:isLastRewardEnable(self.m_data) then
		self.m_mgrIns:requestReward()
	end
end

function MultiplyGiftView:_getCurMulCfg( data )
	local tc = data.configArray
	local tl = data.level
	-- tostring(math.numInRange(tonumber(data.level) + 1,1,7 ))
	local find_info = table.find(tc,function ( cur )
		return cur.level == tl
	end)
	return find_info
end

function MultiplyGiftView:_getNextMulCfg( data )
	local tc = data.configArray
	local tl = tostring(math.numInRange(tonumber(data.level) + 1,1,7 ))
	local find_info = table.find(tc,function ( cur )
		return cur.level == tl
	end)
	return find_info
end

function MultiplyGiftView:refreshReward( data )
	local find_info = self:_getCurMulCfg(data)
	local rid = find_info.rewardId
	if self.m_lastReqRwId == rid then
		return
	end

	self.m_lastReqRwId = rid
	local rewards = {}
	table.insert(rewards,rid)
	self:getRewardRequester():startReqIds(rewards)
end


function MultiplyGiftView:refreshBoxState( data )
	local find_info = self:_getCurMulCfg(data)
	local tl = data.level
	for i,v in ipairs(self.m_boxArr) do
		v:setBoxInfo(data.configArray[i+1])
		v:setCanGetReward(tostring(i) == tl and data.rewarded =='0',tostring(i) == tl and data.rewarded =='1')
	end
end

function MultiplyGiftView:removeRedDot(  )
	self.m_mgrIns:tryRemoveRedDot()
end

function MultiplyGiftView:refreshFinalBtn( data )
	local lastBuyEnable = self.m_mgrIns:isLastBuyEnable(data)
	self.ui.m_finalNode:setVisible(lastBuyEnable)
	if lastBuyEnable and not self.m_finalComp then
		local lt = (tonumber(data.timeLimitEnd) or 0) / 1000
		local cp = utils.attachCDForLabel(self.ui.m_finalTime,lt,{{func=function (  )
			self.ui.m_finalNode:setVisible(false)
			if tonumber(data.canResetTimes) > 0 then
				self.m_mgrIns:requestReset()
			else
				self.ui.m_buyBtn:setEnabled(false)
			end
		end}})
		self.m_finalComp = cp
		self:autoManageNode(cp)
	end
end

function MultiplyGiftView:refreshBuyBtn( data )
	local find_info = self:_getCurMulCfg(data)

	local can_buy = true
	local en = data.exchangeBuyNum or {}
	for k,v in pairs(en) do
		if self:tellLibaoIsNormal(k) then
			can_buy = v == '0'
			break
		end
	end
	can_buy = can_buy and data.rewarded == '0'

	self.ui.m_buyBtn:setEnabled(true)
	self.ui.m_leftReset:setVisible(false)
	local label
	if can_buy then
		local pLibao = LiBaoController.getInstance():getGoldExchangeItemById(find_info.exchangeId)
		label = pLibao and LuaController:call("getDollarString", pLibao.dollar, pLibao.product_id) or getLang("103073")
    else
    	local can_reset = data.rewarded == '1'
    	label = can_reset and getLang("250056") or getLang("169108")
    	self.ui.m_buyBtn:setEnabled(can_reset)
    	self.ui.m_leftReset:setVisible(can_reset)
    	if can_reset then
    		self.ui.m_leftReset:setString(getLang("9400599",data.canResetTimes))
    	end
    end
    self.ui.m_buyBtn.m_canBuy = can_buy
    CCCommonUtilsForLua:setButtonTitle(self.ui.m_buyBtn, label)
end

function MultiplyGiftView:refreshCurMul( data )
	local find_info = self:_getCurMulCfg(data)
	local tp = find_info and find_info.multiple or "0"
	-- self.ui.m_curMul:setString(getLang("9900152",tp))
	local sf = tp == '0' and 'mul_gi_mx1.png' or utils.getSafeSpriteFrame( string.format('mul_gi_mx%s.png',tp), 'blankFrame.png' )
	self.ui.m_mulNumSpr:setSpriteFrame(sf)
	if not self.m_had_set_x then
		self.m_had_set_x = true
		self.ui.m_mul_x:setSpriteFrame(utils.getSafeSpriteFrame( 'mul_gi_mx.png', 'blankFrame.png' ))
	end
end

function MultiplyGiftView:onBuyBtnClick(pSender, event)
	if pSender.m_canBuy then
		local find_info = self:_getCurMulCfg(self.m_data)
		local eid = find_info.exchangeId
	    LiBaoController.getInstance():callPayment(eid)
	    LogController:postEventLog("MultiplyGiftView")
	else
		self.m_mgrIns:requestReset()
    end
end

function MultiplyGiftView:onFinalClick(pSender, event)
	self.m_mgrIns:showFinalLibao(self.m_data)
end

function MultiplyGiftView:onHelpClick(pSender, event)
	if utils.delayClickBtn(pSender,1) then
		return
	end
	
	self:showHelp()
end

function MultiplyGiftView:showHelp(  )
	utils.showHelp(getLang("9900154"),getLang("50000001"))
end

function MultiplyGiftView:getRewardRequester(  )
    local rewardRequster = utils.getReqMultiRewardImplClass():new()
    rewardRequster.onGetRewardDetailBack = function ( rewardRequsterSelf,data,fromType )
        self:onGetRewardDetailBack(data,fromType)
    end
    return rewardRequster
end

function MultiplyGiftView:tellLibaoIsNormal( exchangeId )
	return exchangeId == self.m_data.configArray[1].exchangeId
end

function MultiplyGiftView:onGetRewardDetailBack( data,fromType )
	self.m_rewardBack = data

	local backData = data
	if not backData then
		return
	end

	local find_info = backData[1]
	-- table.find(backData,function ( cur )
	-- 	return cur.id == rid
	-- end)
	self.ui.m_rwdNode:removeAllChildren()
	local backData = find_info and find_info.data and find_info.data[1]
	if backData then
		local a_icon = utils.makeGoodsIcon( backData.value.id,backData.value.num,backData.type )
		self.ui.m_rwdNode:addChild(a_icon)
	end
end

return MultiplyGiftView