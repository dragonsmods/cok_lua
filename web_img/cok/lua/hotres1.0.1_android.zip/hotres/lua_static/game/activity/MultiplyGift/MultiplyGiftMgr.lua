-- @Author: tangwen
-- @Date:   2019-06-03 16:14:07
-- @Last Modified by:   tangwen
-- @Last Modified time: 2020-01-14 09:53:14

-- kpi 倍享好礼活动 管理类
local superClass = require("game.controller.KpiActMgr")

local MultiplyGiftMgr = class("MultiplyGiftMgr",superClass)

local GemIndex = utils.toNumberEnum({
    {"White",1},
    {"Green"},
    {"Blue"},
    {"Purple"},
    {"Orange"},
    {"Golden"}
})

local mergeKeys = {"rewarded","level","canResetTimes","exchangeBuyNum"}

local _instance = nil
function MultiplyGiftMgr.getInstance()
    if _instance == nil then
        _instance = MultiplyGiftMgr.new()
        guiCommonGlobal.controllerAutoPurge(_instance)
    end
    return _instance
end

function MultiplyGiftMgr:ctor()
    superClass.ctor(self,"57457","MulGift_face","multiple_gift")
    self.m_onEnergyEvent =      utils.getEventClass():new()
end

function MultiplyGiftMgr:getEnergyEvent(  )
    return self.m_onEnergyEvent
end

function MultiplyGiftMgr:reset(  )
    self.m_curData = nil
end

function MultiplyGiftMgr:requestInfo( from )
    -- cclog("MultiplyGiftMgr:requestInfo,,, %s",from)
    utils.requestServer("multiplegift.data",nil,nil,function ( tbl )
        self.m_curData = tbl
        -- if from == "MultiplyGiftView" then
            self.m_onEnergyEvent:emit(self.m_curData)
        -- else
        --     self:showMainView(self.m_curData)
        -- end
    end)
end

function MultiplyGiftMgr:requestReward(  )
    utils.requestServer("multiplegift.reward",nil,nil,function ( tbl )
        -- createTableFlyReward(tbl.rewardArray)
        -- utils.dump(tbl,"MultiplyGiftMgr:requestReward,,,")
        self:showReward(tbl.rewardArray)
        for _,v in ipairs(mergeKeys) do
            if tbl[v] then
                self.m_curData[v] = tbl[v]
            end
        end
        self.m_onEnergyEvent:emit(self.m_curData)
    end)
end

function MultiplyGiftMgr:requestReset(  )
    utils.requestServer("multiplegift.reset",nil,nil,function ( tbl )
        -- utils.dump(tbl,"MultiplyGiftMgr:requestReset,,,")
        for _,v in ipairs(mergeKeys) do
            if tbl[v] then
                self.m_curData[v] = tbl[v]
            end
        end
        self.m_onEnergyEvent:emit(self.m_curData)
    end)
end


function MultiplyGiftMgr:showMainView( data )
    if not isCrossServerNow() then
        if CCLoadSprite:call("loadDynamicResourceByName", "MulGift_face") then
            data = data or self.m_curData
            local view = Drequire("game.activity.MultiplyGift.MultiplyGiftView"):create(data)
            -- PopupViewController:addPopupInView(view)
            return view
        else
            -- CCCommonUtilsForLua:call("flyHint", "", "", getLang("5530050",50))
            self:getResNoticer():showNotice()
        end
    end
end

function MultiplyGiftMgr:isOpen(  )
    return superClass.isOpen(self) and (not isCrossServerNow()) and ActivityController.getInstance():isActivityOpenWithTime(self:getActId())
end

function MultiplyGiftMgr:showFinalLibao( data )
    local view = Drequire("game.activity.MultiplyGift.MultiplyGiftFinal"):create(data)
    PopupViewController:addPopupView(view)
end

function MultiplyGiftMgr:showReward( data )
    local tbl = data
    local rwdArr = luaToArray(tbl)    
    -- PortActController:call("flyReward", rwdArr, showBg)
    local rwdInfo = RewardController:call("retReward", rwdArr)
    -- CCCommonUtilsForLua:call("flyHint", "", "", rwdInfo)
    CCSafeNotificationCenter:call("postNotification", MSG_REFREASH_TOOL_DATA)

    for _,v in ipairs(data or {}) do
        v.value.id = v.value.itemId
        v.value.num = v.value.rewardAdd
    end

    local view = require("game.CommonPopup.RewardShowView").create(data,getLang("169846"))
    PopupViewController:addPopupView(view)
end


function MultiplyGiftMgr:getTicketId(  )
    return self.m_curData and 
    self.m_curData.timeAndSpaceTreasureArray and 
    tonumber(self.m_curData.timeAndSpaceTreasureArray[1].currId) or 36001624
end

function MultiplyGiftMgr:getGemIndex(  )
    return GemIndex
end

function MultiplyGiftMgr:showItemGetMethodView(  )
    local ItemGetMethodView = Drequire("game.CommonPopup.ItemGetMethodView")
    PopupViewController:call("addPopupView", ItemGetMethodView:create(self:getTicketId()))
end

function MultiplyGiftMgr:tellLibaoIsNormal( exchangeId,data )
    data = data or self.m_curData
    return exchangeId == data.configArray[1].exchangeId
end

function MultiplyGiftMgr:isLastBuyEnable( data )
    data = data or self.m_curData
    return data.level == '6' and data.rewarded == '0' and utils.timeNow() < (tonumber(data.timeLimitEnd) or 0) / 1000
end

function MultiplyGiftMgr:isLastBuyOverTime( data )
    data = data or self.m_curData
    return data.level == '6' and data.rewarded == '0' and utils.timeNow() >= (tonumber(data.timeLimitEnd) or 0) / 1000
end

function MultiplyGiftMgr:isLastRewardEnable( data )
    data = data or self.m_curData
    return data.level == '7' and data.rewarded == '0'
end

function MultiplyGiftMgr:getRedDotCount(  )
    if not self.m_curData then
        if self:isOpen() then
            utils.requestServer("multiplegift.data",nil,nil,function ( tbl )
                self.m_curData = tbl
            end)
        end
        return 0
    else
        self:tryAddRedDot()
        return self:getOneTimeFlag():getFlag() and 1 or 0
    end
end

function MultiplyGiftMgr:tryAddRedDot(  )
    if not table.isNilOrEmpty( self.m_curData ) then
        if self.m_curData and self.m_curData.rewarded == '0' and self.m_curData.level ~= '0' then
            local tf = self:getOneTimeFlag()
            if tf and (tf:getFlag() or (not tf:getFlag() and tf:canSetOneDayFlagTrue())) then
                tf:setFlag(true)
            end
        end
    end
end

function MultiplyGiftMgr:tryRemoveRedDot(  )
    local tf = self:getOneTimeFlag()
    if tf:getFlag() then
        self:getOneTimeFlag():setFlag(false)
        return true
    end
    return false
end

function MultiplyGiftMgr:getOneTimeFlag(  )
    local oneTimeFlag = self.m_oneTimeFlag
    if not oneTimeFlag then
        oneTimeFlag = utils.getExtendClass("localOneTimeFlag"):create("")
        self.m_oneTimeFlag = oneTimeFlag
    end
    return oneTimeFlag
end

function MultiplyGiftMgr:getRedDotKey(  )
    return 'mul_red'
end

function MultiplyGiftMgr:getTodayNoticeName(  )
	return 'mul_noti'
end

function MultiplyGiftMgr:getTodayNotice(  )
	local todayCheckFlag = self.m_todayCheckFlag
	if not todayCheckFlag then
	    todayCheckFlag = utils.getExtendClass( 'localOneTimeFlag' ):create(self:getTodayNoticeName())
	    self.m_todayCheckFlag = todayCheckFlag
	end
	return todayCheckFlag
end

return MultiplyGiftMgr