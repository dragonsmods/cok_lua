--[[ 
    战报详情界面
    @author: Awen
    @date: 2020-05-15
 ]]
local MailBattleReportDetailView = class("MailBattleReportDetailView", function() return PopupBaseView:create() end)
local json = require("CommonLib.dkjson")
local TypeHandle = {}

local T_INFO = 0                    --说明
local T_FLAG_ATK = T_INFO + 1       --攻击方标志
local T_FLAG_DEF = T_FLAG_ATK + 1   --防守方标志
local T_END_EARLY = T_FLAG_DEF + 1  --提前结束战斗
local T_NAME = T_END_EARLY + 1      --昵称
local T_USER = T_NAME + 1           --领主（gm可见）
local T_DRAGON = T_USER + 1         --龙
local T_HERO = T_DRAGON + 1         --英雄
local T_CONFIG = T_HERO + 1         --配置
local T_ARMY = T_CONFIG + 1         --部队
local T_FORT = T_ARMY + 1           --陷阱
local T_TOWER = T_FORT + 1          --箭塔

function MailBattleReportDetailView.create(mailUid)
    local view = MailBattleReportDetailView.new()
    Drequire("game.Mail.detail.MailBattleReportDetailView_ui"):create(view, 0)
    if view:initView(mailUid) == false then
        return nil
    end
    return view
end

function MailBattleReportDetailView:initView(mailUid)
    -- Dprint("MailBattleReportDetailView:initView", mailUid)
    if string.isNilOrEmpty((mailUid)) then
        return
    end

    self.mailInfo = MailController:call("getMailInfoByMailUid", mailUid)
	
	if self.mailInfo == nil then
		print('MailBattleReportDetailView:initView [mailInfo is nil]')
		return
    end
    
    CCLoadSprite:call("doResourceByCommonIndex", 8, true)
    CCLoadSprite:call("doResourceByCommonIndex", 105, true)
    CCLoadSprite:call("doResourceByCommonIndex", 204, true)
    CCLoadSprite:call("doResourceByCommonIndex", 502, true)
	CCLoadSprite:call("doResourceByCommonIndex", 200, true)
	CCLoadSprite:call("doResourceByCommonIndex", 202, true)
    CCLoadSprite:call("loadDynamicResourceByName", "magic_face")
    registerTouchHandler(self)
    
    local viewSize = self.ui.m_nodeList:getContentSize()
	self.m_tableView = cc.TableView:create(viewSize)

	local contentCellSizeForTable = function(tab, idx)
		return self:contentCellSizeForTable(tab, idx)
	end
	local contentTableCellAtIndex = function(tab, idx)
		return self:contentTableCellAtIndex(tab, idx)
	end
	local contentNumberOfCellsInTableView = function(tab)
		return self:contentNumberOfCellsInTableView(tab)
	end

	self.m_tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
	self.m_tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
	self.m_tableView:setDelegate()
	self.m_tableView:registerScriptHandler(contentCellSizeForTable,cc.TABLECELL_SIZE_FOR_INDEX)
	self.m_tableView:registerScriptHandler(contentNumberOfCellsInTableView,cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
	self.m_tableView:registerScriptHandler(contentTableCellAtIndex,cc.TABLECELL_SIZE_AT_INDEX)
	self.ui.m_nodeList:addChild(self.m_tableView)   

    self.fo_dragon_skill_report = isFunOpenByKey("dragon_skill_report")
    self.fo_dragon_skill_report_detail = isFunOpenByKey("dragon_skill_report_detail")
    self.fo_mail_general_skill = isFunOpenByKey("mail_general_skill")
    self.is_p6_army = ArmyController:call('getInstance'):call("isNewArmsFunOn", "p6_strong") and isFunOpenByKey("p6_mails")

    self:generateData()
    require("game.Mail.MailManager").getInstance():reqBattleHelpDetail(self.mailInfo:getProperty("combatReportId"))
    return true
end

function MailBattleReportDetailView:generateData()
    self.data = {}
    self.dataPlayers = {{}, {}}
    local isGm1 = PlayerInfoController:getGmFlag() == 1
    -- 概述
    table.insert(self.data, {type = T_INFO})
    
    local not_dragon_skill_report_detail = not isFunOpenByKey("dragon_skill_report_detail")
    -- 攻击者
    local attReport = self.mailInfo:getProperty("attReport")
    if attReport then
        table.insert(self.data, {type = T_FLAG_ATK})

        local attUser = dictToLuaTable(self.mailInfo:getProperty("attUser"))
        -- dump(attUser, 'MailBattleReportDetailView:generateData attUser', 10)
        local userHead = {name = attUser.name, uid = attUser.uid, pic = attUser.pic, picVer = attUser.picVer, picfraId = attUser.picfraId}
        table.insert(self.dataPlayers[1], userHead)

        -- 名称
        table.insert(self.data, {type = T_NAME, userName = attUser.name, isAtt = true})
        -- 领主
        local atkGenKill = self.mailInfo:getProperty("atkGenKill")
        if isGm1 and atkGenKill then
            table.insert(self.data, {type = T_USER, isAtt = true, userHead = userHead, mainGenKill = arrayToLuaTable(atkGenKill)})
        end
        -- 龙
        local atkDrag = self.mailInfo:getProperty("atkDrag")
        if atkDrag then
            for _,v in ipairs(arrayToLuaTable(atkDrag) or {}) do
                v.type = T_DRAGON
                v.isAtt = true
                if not_dragon_skill_report_detail then
                    v.talentSkillArray = nil
                end
                table.insert(self.data, v)
            end
        end
        -- 英雄
        local atkBattleGenerals = self.mailInfo:getProperty("atkBattleGenerals")
        if atkBattleGenerals then
            for _,v in ipairs(arrayToLuaTable(atkBattleGenerals) or {}) do
                v.type = T_HERO
                v.isAtt = true
                table.insert(self.data, v)
            end
        end        
        -- 战报配置
        local atkConfig = self.mailInfo:getProperty("atkConfig")
        if atkConfig then
            atkConfig = arrayToLuaTable(atkConfig)
            if table.isNilOrEmpty(atkConfig) then
                table.insert(self.data, {type = T_CONFIG, isAtt = true, config = atkConfig})
            end
        end
        -- 部队
        local armList = self:mergeArmy( arrayToLuaTable(attReport) )
        for i,v in ipairs(armList or {}) do
            v.type = T_ARMY
            v.isAtt = true
            v.race = attUser.race
            v.userName = attUser.name
            table.insert(self.data, v)
        end
    end

    -- 攻击队伍
    local atkHelpReport = self.mailInfo:getProperty("atkHelpReport")
    if atkHelpReport then
        atkHelpReport = arrayToLuaTable(atkHelpReport)
        -- dump(atkHelpReport, 'MailBattleReportDetailView:generateData atkHelpReport   ' .. self.mailInfo:getProperty("combatReportId"), 10)
        for _,v in ipairs(atkHelpReport or {}) do
            -- 名称
            table.insert(self.data, {type = T_NAME, userName = v.name, isAtt = true})
            -- 领主
            if isGm1 and v.genKill then
                table.insert(self.data, {type = T_USER, userName = v.name, isAtt = true, mainGenKill = v.genKill})
            end
            -- 龙
            for _,v in ipairs(arrayToLuaTable(v.dragonInfo) or {}) do
                v.type = T_DRAGON
                v.isAtt = true
                if not_dragon_skill_report_detail then
                    v.talentSkillArray = nil
                end
                table.insert(self.data, v)
            end
            -- 英雄
            for _,vv in ipairs(arrayToLuaTable(v.helperBattleGenerals) or {}) do
                vv.type = T_HERO
                vv.isAtt = true
                table.insert(self.data, vv)
            end
            -- 战报配置
            if table.isNilOrEmpty(v.mConfig) == false then
                table.insert(self.data, {type = T_CONFIG, isAtt = true, config = v.mConfig})
            end
            -- 部队
            local armList = self:mergeArmy(v.armyInfo)
            for _,vv in ipairs(armList or {}) do
                vv.type = T_ARMY
                vv.isAtt = true
                vv.race = v.race
                vv.userName = v.name
                table.insert(self.data, vv)
            end

            table.insert(self.dataPlayers[1], {name = v.name})
        end
    end

    -- 防守者
    local defReport = self.mailInfo:getProperty("defReport")
    if defReport then
        table.insert(self.data, {type = T_FLAG_DEF})

        local defUser = dictToLuaTable(self.mailInfo:getProperty("defUser"))
        -- dump(defUser, 'MailBattleReportDetailView:generateData defUser ', 10)
        local userHead = {name = defUser.name, uid = defUser.uid, pic = defUser.pic, picVer = defUser.picVer, picfraId = defUser.picfraId}
        table.insert(self.dataPlayers[2], userHead)

        -- 名称
        table.insert(self.data, {type = T_NAME, userName = defUser.name})

        -- 领主
        local defGenKill = self.mailInfo:getProperty("defGenKill")
        if isGm1 and defGenKill then
            table.insert(self.data, {type = T_USER, userHead = userHead, mainGenKill = arrayToLuaTable(defGenKill)})
        end
        -- 龙
        local defDrag = self.mailInfo:getProperty("defDrag")
        if defDrag then
            for _,v in ipairs(arrayToLuaTable(defDrag) or {}) do
                v.type = T_DRAGON
                if not_dragon_skill_report_detail then
                    v.talentSkillArray = nil
                end
                table.insert(self.data, v)
            end
        end 
        -- 英雄
        local defBattleGenerals = self.mailInfo:getProperty("defBattleGenerals")
        if defBattleGenerals then
            for _,v in ipairs(arrayToLuaTable(defBattleGenerals) or {}) do
                v.type = T_HERO
                table.insert(self.data, v)
            end
        end
        -- 战报配置
        local defConfig = self.mailInfo:getProperty("defConfig")
        if defConfig then
            defConfig = arrayToLuaTable(defConfig)
            if table.isNilOrEmpty(defConfig) == false then
                table.insert(self.data, {type = T_CONFIG, config = defConfig})
            end
        end
        -- 部队
        local userName = ""
        local pointType = self.mailInfo:getProperty("pointType")
        if pointType == WorldCityType.Barbarian then
            local barbarionConfigId = self.mailInfo:getProperty("barbarionConfigId")
            userName = CCCommonUtilsForLua:call("getNameById", tostring(barbarionConfigId))

        elseif pointType == WorldCityType.Throne then
            local name = CCCommonUtilsForLua:call("getNameById", tostring(defUser.npcId))
            
            local difficulty = atoi(CCCommonUtilsForLua:call("getPropById", defUser.npcId, "difficulty"))
            local difficultyStr = getLang("169031")  --169031=简单
            if difficulty == 2 then
                difficultyStr = getLang("169032")   --169032=中等
            elseif diffculty == 3 then
                difficultyStr = getLang("169033")  --169033=困难
            end
            userName = string.format("%s%s", name, difficultyStr)
        else
            userName = defUser.name
        end
        local armList = self:mergeArmy( arrayToLuaTable(defReport) )
        for i,v in ipairs(armList or {}) do
            v.type = T_ARMY
            v.race = defUser.race
            v.userName = userName
            table.insert(self.data, v)
        end
        -- 陷阱
        local defFortLost = self.mailInfo:getProperty("defFortLost")
        if defFortLost then
            for i,v in ipairs(arrayToLuaTable(defFortLost) or {}) do
                v.type = T_FORT
                table.insert(self.data, v)
            end
        end
        -- 箭塔
        local defTowerKill = self.mailInfo:getProperty("defTowerKill")
        if defTowerKill then
            for i,v in ipairs(arrayToLuaTable(defTowerKill) or {}) do
                v.type = T_TOWER
                table.insert(self.data, v)
            end
        end
    end

    -- 防守队伍
    local defHelpReport = self.mailInfo:getProperty("defHelpReport")
    if defHelpReport then
        defHelpReport = arrayToLuaTable(defHelpReport)
        -- dump(defHelpReport, 'MailBattleReportDetailView:generateData defHelpReport', 10)
        for _,v in ipairs(defHelpReport or {}) do
            -- 名称
            table.insert(self.data, {type = T_NAME, userName = v.name})
            -- 领主
            if isGm1 and v.genKill then
                table.insert(self.data, {type = T_USER, userName = v.name, mainGenKill = v.genKill})
            end
            -- 龙
            for _,v in ipairs(arrayToLuaTable(v.dragonInfo) or {}) do
                v.type = T_DRAGON
                if not_dragon_skill_report_detail then
                    v.talentSkillArray = nil
                end
                table.insert(self.data, v)
            end
            -- 英雄
            for _,vv in ipairs(arrayToLuaTable(v.helperBattleGenerals) or {}) do
                vv.type = T_HERO
                table.insert(self.data, vv)
            end
            -- 战报配置
            if table.isNilOrEmpty(v.mConfig) == false then
                table.insert(self.data, {type = T_CONFIG, config = v.mConfig})
            end
            -- 部队
            local armList = self:mergeArmy(v.armyInfo)
            for _,vv in ipairs(armList or {}) do
                vv.type = T_ARMY
                vv.race = v.race
                vv.userName = v.name
                table.insert(self.data, vv)
            end

            table.insert(self.dataPlayers[2], {name = v.name})
        end
    end
    -- 
    if self.mailInfo:getProperty("isShowDefEndTxt") then
        table.insert(self.data, {type = T_END_EARLY, isAtt = false})
    end

    -- dump(self.data, 'MailBattleReportDetailView:generateData', 10)
    self.m_tableView:reloadData()

    self.ui:setTableViewDataSource("m_tableViewAtk", self.dataPlayers[1])
    self.ui:setTableViewDataSource("m_tableViewDef", self.dataPlayers[2])
end

-- 合并部队
function MailBattleReportDetailView:mergeArmy(armyInfo)
    local armyList = {}
    local armyIndex = {}
    for _,v in ipairs(armyInfo or {}) do
        if v.skills then
            v.skills = json.decode(v.skills)
        end
        local isAdd = false
        local table = self:getArmyTable(v.armId)

        -- 寻找可以合并的部队
        for kk,vv in pairs(table or {}) do
            if armyIndex[kk] then
                isAdd = true
                local data = armyList[armyIndex[kk]]
                if data.list == nil then
                    local _self = clone(data)
                    data.list = {}
                    data.list[1] = _self
                end
                data.list[#data.list + 1] = v
                break
            end
        end

        if isAdd == false then
            local index = #armyList + 1
            armyIndex[v.armId] = index
            armyList[index] = v
        end
    end

    for _,v in ipairs(armyList or {}) do
        if v.list then
            v.fold = true  --是否折叠
            v.dead = 0
            v.heal = 0
            v.hurt = 0
            v.kill = 0
            v.num = 0
            v.magicKill = 0
            for _,vv in ipairs(v.list or {}) do
                v.dead = v.dead + atoi(vv.dead)
                v.heal = v.heal + atoi(vv.heal)
                v.hurt = v.hurt + atoi(vv.hurt)
                v.kill = v.kill + atoi(vv.kill)
                v.num = v.num + atoi(vv.num)
                v.magicKill = v.magicKill + atoi(vv.magicKill)
            end
        end
    end

    return armyList
end

-- 普通兵与军械兵对应列表
function MailBattleReportDetailView:getArmyTable(armyId)
    if self.armyTable == nil then
        self.armyTable = {}
        local xmlData = CCCommonUtilsForLua:getGroupByKey("make_armament_arms")
        for _,v in pairs(xmlData or {}) do
            local aid = v.arms_id
            local aid2 = v.new_arms_id

            self.armyTable[aid] = self.armyTable[aid] or {}
            self.armyTable[aid][aid2] = true

            self.armyTable[aid2] = self.armyTable[aid2] or {}
            self.armyTable[aid2][aid] = true
        end
        for k,v in pairs(self.armyTable or {}) do
            for kk,vv in pairs(v or {}) do
                for kkk,vvvv in pairs(self.armyTable[kk] or {}) do
                    if k ~= kkk then
                        v[kkk] = true
                    end
                end
            end
        end
    end
    return self.armyTable[armyId]
end

function MailBattleReportDetailView:contentCellSizeForTable(tab, idx)
    idx = idx + 1
	if (idx > #self.data) then
		return 0, 0
    end
    
    local data = self.data[idx]
    if data == nil then
		return 0, 0
    end

    local width, height = TypeHandle[data.type](data)
    if width == nil or height == nil then
        return 640, 120
    else
        return width, height
    end
end

function MailBattleReportDetailView:contentTableCellAtIndex(tab, idx)
    idx = idx + 1
    if (idx > #self.data) then
		return nil
	end

	local cell = tab:dequeueCell()
    if cell then
		cell:setData(self.data[idx])
	else
		cell = Drequire("game.Mail.detail.MailBattleReportDetailCell").create(self.data[idx])
	end
	return cell
end

function MailBattleReportDetailView:contentNumberOfCellsInTableView(tab)
	if self.data then
		return #self.data
	end
	return 0
end

function MailBattleReportDetailView:refresh(data)
    local offsetY = tolua.cast(data,"CCInteger"):getValue()
    local offset = self.m_tableView:getContentOffset()
    self.m_tableView:reloadData()
    self.m_tableView:setContentOffset(ccp(offset.x, offset.y + offsetY))
end

function MailBattleReportDetailView:refreshHead(dict)
	local data = tolua.cast(dict, "CCDictionary")
    data = dictToLuaTable(data)
    if data then
        local isAtkReload = false
        for _,v in ipairs(data.atkHelperList or {}) do
            for _,vv in ipairs(self.dataPlayers[1] or {}) do
                if v.name == vv.name then
                    vv.pic = v.pic
                    vv.picVer = v.picVer
                    vv.picfraId = v.picfraId
                    vv.uid = v.uid
                    isAtkReload = true
                    break
                end
            end
        end

        if isAtkReload then
            local offset = self.ui.m_tableViewAtk:getContentOffset()
            self.ui.m_tableViewAtk:reloadData()
            self.ui.m_tableViewAtk:setContentOffset(offset)
        end

        local isDefReload = false
        for _,v in ipairs(data.defHelperList or {}) do
            for _,vv in ipairs(self.dataPlayers[2] or {}) do
                if v.name == vv.name then
                    vv = v
                    isDefReload = true
                    break
                end
            end
        end
        if isDefReload then
            local offset = self.ui.m_tableViewDef:getContentOffset()
            self.ui.m_tableViewDef:reloadData()
            self.ui.m_tableViewDef:setContentOffset(offset)
        end

        if PlayerInfoController:getGmFlag() == 1 then
            for _,v in ipairs(self.data or {}) do
                if v.type == T_USER then
                    if v.userHead == nil then
                        for _,vv in ipairs(data.atkHelperList or {}) do
                            if v.userName == vv.name then
                                v.userHead = {pic = vv.pic, picVer = vv.picVer, picfraId = vv.picfraId, uid = vv.uid}
                                break
                            end
                        end
                    end
                end
            end
        end
    end
end

-- 滚到列表到指定玩家
function MailBattleReportDetailView:scrollView(data)
    local userName = tolua.cast(data, "CCString"):getCString()
    if userName then
        local contentSize = self.m_tableView:getContentSize()
        local viewSize = self.m_tableView:getViewSize()
        if contentSize.height > viewSize.height then
            local offset = viewSize.height - contentSize.height
            for i,v in ipairs(self.data or {}) do
                if userName == v.userName then
                    break
                else
                    local x,y = self:contentCellSizeForTable(self.data, i - 1)
                    offset = offset + y
                end
            end

            self.m_tableView:setContentOffset(ccp(0, offset))
        end
    end
end
-------------------------------------------------------------- 
function MailBattleReportDetailView:onEnter()
    registerScriptObserver(self, self.refresh, "MailBattleReportDetailView:refresh")
    registerScriptObserver(self, self.refreshHead, "MailBattleReportDetailView:refreshHead")
    registerScriptObserver(self, self.scrollView, "MailBattleReportDetailView:scrollView")
end

function MailBattleReportDetailView:onExit()
    unregisterScriptObserver(self, "MailBattleReportDetailView:refresh")
    unregisterScriptObserver(self, "MailBattleReportDetailView:refreshHead")
    unregisterScriptObserver(self, "MailBattleReportDetailView:scrollView")
end

function MailBattleReportDetailView:onClickBtnClose()
    self:closeSelf()
end

-------------------------------------------------------------- 
function MailBattleReportDetailView:onTouchBegan(x, y)
    self.touchX = x
    self.touchY = y
    return true
end

function MailBattleReportDetailView:onTouchMoved(x, y)
end

function MailBattleReportDetailView:onTouchEnded(x, y)
    if (not isTouchInsideVis(self.ui.m_nodeBg, x, y)) and (not isTouchInsideVis(self.ui.m_nodeBg, self.touchX, self.touchY)) then
        self:closeSelf()
    end
end

--说明
TypeHandle[T_INFO] = function(data)
    if isFunOpenByKey("dragon_battle") then
        return 610, 240
    end
    return 610, 120
end

--攻击方标志
TypeHandle[T_FLAG_ATK] = function(data)
    return 610, 100
end

--防守方标志
TypeHandle[T_FLAG_DEF] = function(data)
    return 610, 100
end

--提前结束战斗
TypeHandle[T_END_EARLY] = function(data)
    return 610, 130
end

--昵称
TypeHandle[T_NAME] = function(data)
    return 610, 36
end

--领主（GM=1可见）
TypeHandle[T_USER] = function(data)
    return 610, 120
end

--龙
TypeHandle[T_DRAGON] = function(data)
    if table.isNilOrEmpty(data.talentSkillArray) then
        return 610, 120 + 75
    else
        return 610, 120 + 75 + (#data.talentSkillArray) * 80
    end
end

--英雄
TypeHandle[T_HERO] = function(data)
    if table.isNilOrEmpty(data.skillList) then
        return 610, 120
    else
        return 610, 120 + math.ceil((#data.skillList) / 5) * 80
    end
end

--配置
TypeHandle[T_CONFIG] = function(data)
    return 610, require("game.Mail.MailConfigManager").getManager():getConfigHeightByLua(data)
end

--部队
TypeHandle[T_ARMY] = function(data)
    local height = 120
    if table.isNilOrEmpty(data.list) then
        if table.isNilOrEmpty(data.skills) == false then
            height = height + 140
        end
        if atoi(data.magicKill) > 0 then
            height = height + 55
        end
        -- 战地医疗
        height = height + 55
    else
        local size = #data.list
        if data.fold then
            height = height + (size - 2) * 100 + 80
            if size == 2 then
                if atoi(data.magicKill) > 0 then
                    height = height + 20
                    if table.isNilOrEmpty(data.skills) == false then
                        height = height + 150
                    end
                elseif table.isNilOrEmpty(data.skills) == false then
                    height = height + 130
                end
            elseif size == 3 then
                if table.isNilOrEmpty(data.skills) == false then
                    height = height + 20
                    if atoi(data.magicKill) > 0 then
                        height = height + 55
                    end
                end
            end
        else
            height = height + (size - 1) * 150 + 50
            for _,vv in ipairs(data.list or {}) do
                if atoi(vv.magicKill) > 0 then
                    height = height + 55
                end
            end
            if table.isNilOrEmpty(data.skills) == false then
                height = height + 150
            end
        end
    end
    return 610, height
end

--陷阱
TypeHandle[T_FORT] = function(data)
    return 610, 120
end

--箭塔
TypeHandle[T_TOWER] = function(data)
    return 610, 120
end


return MailBattleReportDetailView