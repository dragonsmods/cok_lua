----------------------------
-- Author: Elex
-- Date: 2020-05-29 Friday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local MailBattleReportDetailCell_ui = class("MailBattleReportDetailCell_ui")

--#ui propertys


--#function
function MailBattleReportDetailCell_ui:create(owner, viewType, paramTable)
	local ret = MailBattleReportDetailCell_ui.new()
	CustomUtility:DoRes(6, true)
	CustomUtility:DoRes(8, true)
	CustomUtility:LoadUi("MailBattleReportDetailCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function MailBattleReportDetailCell_ui:initLang()
	LabelSmoker:setText(self.m_endTxt, "105151")
	LabelSmoker:setText(self.m_numTxt3, "114113")
	LabelSmoker:setText(self.m_killTxt3, "105543")
	LabelSmoker:setText(self.m_lostTxt3, "105544")
	LabelSmoker:setText(self.m_hurtTxt3, "105545")
	LabelSmoker:setText(self.m_healTxt3, "113038")
	LabelSmoker:setText(self.m_intimacyTxt3, "164325")
	LabelSmoker:setText(self.m_intimacyDecTxt3, "169095")
	LabelSmoker:setText(self.m_skillTimesTxt3, "165063")
	LabelSmoker:setText(self.m_skillFroundTxt3, "165064")
	LabelSmoker:setText(self.m_numTxt2, "114113")
	LabelSmoker:setText(self.m_killTxt2, "105543")
	LabelSmoker:setText(self.m_lostTxt2, "105544")
	LabelSmoker:setText(self.m_hurtTxt2, "105545")
	LabelSmoker:setText(self.m_intimacyTxt2, "164325")
	LabelSmoker:setText(self.m_intimacyDecTxt2, "169095")
	LabelSmoker:setText(self.m_numTxt, "114113")
	LabelSmoker:setText(self.m_killTxt, "105543")
	LabelSmoker:setText(self.m_lostTxt, "105544")
	LabelSmoker:setText(self.m_hurtTxt, "105545")
end

function MailBattleReportDetailCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function MailBattleReportDetailCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return MailBattleReportDetailCell_ui

