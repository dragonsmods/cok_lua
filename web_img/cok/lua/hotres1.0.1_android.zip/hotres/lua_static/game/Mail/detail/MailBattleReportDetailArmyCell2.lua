--[[ 
    战报详情：部队单元2
    @author: Awen
    @date: 2020-05-29
 ]]
local MailBattleReportDetailArmyCell2 = class("MailBattleReportDetailArmyCell2", function() return CCLayer:create() end)

function MailBattleReportDetailArmyCell2.create(data)
    local cell = MailBattleReportDetailArmyCell2.new()
    Drequire("game.Mail.detail.MailBattleReportDetailArmyCell_ui"):create(cell, 0)
    cell:initView(data)
    return cell
end

function MailBattleReportDetailArmyCell2:initView(data)
    -- dump(data, "MailBattleReportDetailArmyCell2:initView")
    self.data = data

    if data.name then
        self.ui.m_labelName:setString(data.name)
    end
    -- 存活
    if string.isNilOrEmpty(data.item.num) then
        self.ui.m_labelLive:setString("~")
    else
        self.ui.m_labelLive:setString(data.item.num)
    end
    -- 损失
    if string.isNilOrEmpty(data.item.dead) then
        self.ui.m_labelLost:setString("~")
    else
        self.ui.m_labelLost:setString(data.item.dead)
    end    
    -- 消灭
    if string.isNilOrEmpty(data.item.kill) then
        self.ui.m_labelKill:setString("~")
    else
        self.ui.m_labelKill:setString(data.item.kill)
    end
    -- 受伤
    if string.isNilOrEmpty(data.item.hurt) then
        self.ui.m_labelHurt:setString("~")
    else
        self.ui.m_labelHurt:setString(data.item.hurt)
    end
    
    -- 头像
    if string.isNilOrEmpty(data.icon) == false then
        local iconNode = nil
        if string.isNilOrEmpty(data.item.armId) then
            iconNode = CCLoadSprite:createSprite(data.icon)
            CCCommonUtilsForLua:call('setSpriteMaxSize', iconNode, 90)
        else
            if GlobalDataCtr.getPlayerName() == data.playerName then
                local star = ArmyController:call('getStarlvById', data.item.armId)
                iconNode = SoldierIconCell:call("create", data.icon, 90, data.item.armId, true, star)
            else
                iconNode = SoldierIconCell:call("create", data.icon, 90, data.item.armId, false, data.item.star)
            end
        end
        self.ui.m_nodeIcon:addChild(iconNode)
    end

    -- 等级
    if string.isNilOrEmpty(data.icon1) then
        self.ui.m_levelSprNode:setVisible(false)
    else
        self.ui.m_levelSprNode:setVisible(true)
        local spr = CCLoadSprite:createSprite(data.icon1)
        self.ui.m_levelSprNode:addChild(spr)
        self.ui.m_labelName:setString("")
    end

    return true
end

-- 领主头像
function MailBattleReportDetailArmyCell2:setUserHead(info)
    if info then
        local head = info.pic or "g044"
        local picSpr = CCCommonUtilsForLua:call("makeUserHeadIcon", info.uid, string.format("%s.png", head), info.picfraId, info.picVer, 95)
        self.ui.m_nodeIcon:removeAllChildren()
        self.ui.m_nodeIcon:addChild(picSpr)
    end
end

function MailBattleReportDetailArmyCell2:setTextColor(color)
    self.ui.m_labelLive:setColor(color)
    self.ui.m_labelLost:setColor(color)
    self.ui.m_labelKill:setColor(color)
    self.ui.m_labelHurt:setColor(color)    
end

return MailBattleReportDetailArmyCell2