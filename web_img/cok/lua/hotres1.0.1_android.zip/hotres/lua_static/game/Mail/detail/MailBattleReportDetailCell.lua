--[[ 
    战报详情：单元格
    @author: Awen
    @date: 2020-05-15
 ]]
local MailBattleReportDetailCell = class("MailBattleReportDetailCell", function() return cc.Layer:create() end)
local COLOR_ATT = cc.c3b(112,0,0)
local COLOR_DEF = cc.c3b(0,0,105)
local TypeHandle = {}

local T_INFO = 0                    --说明
local T_FLAG_ATK = T_INFO + 1       --攻击方标志
local T_FLAG_DEF = T_FLAG_ATK + 1   --防守方标志
local T_END_EARLY = T_FLAG_DEF + 1  --提前结束战斗
local T_NAME = T_END_EARLY + 1      --昵称
local T_USER = T_NAME + 1           --领主（GM=1可见）
local T_DRAGON = T_USER + 1         --龙
local T_HERO = T_DRAGON + 1         --英雄
local T_CONFIG = T_HERO + 1         --配置
local T_ARMY = T_CONFIG + 1         --部队
local T_FORT = T_ARMY + 1           --陷阱
local T_TOWER = T_FORT + 1          --箭塔

function MailBattleReportDetailCell.create(data)
    local cell = MailBattleReportDetailCell.new()
    Drequire("game.Mail.detail.MailBattleReportDetailCell_ui"):create(cell)
    cell:setData(data)
    return cell
end

function MailBattleReportDetailCell:setData(data)
    -- dump(data, 'MailBattleReportDetailCell:setData', 10)
    self.ui.m_nodeTitle:setVisible(false)
    self.ui.m_nodeUser:setVisible(false)

    self.ui.m_nodeEnd:setVisible(false)
    self.ui.m_nodeInfo:setVisible(false)
    self.ui.m_nodeInfo2:setVisible(false)
    self.ui.m_nodeInfo3:setVisible(false)
    self.ui.m_nodeFlag:setVisible(false)
    self.ui.m_nodeCell:removeAllChildren()

    TypeHandle[data.type](self, data)
end

--说明
TypeHandle[T_INFO] = function(self, data)
    local fo_dragon_battle = isFunOpenByKey("dragon_battle")
    if fo_dragon_battle and isFunOpenByKey("dragon_skill_report") then
        self.ui.m_nodeInfo3:setVisible(true)
    elseif fo_dragon_battle then
        self.ui.m_nodeInfo2:setVisible(true)
    else
        self.ui.m_nodeInfo:setVisible(true)
    end
end

--攻击方标志
TypeHandle[T_FLAG_ATK] = function(self, data)
    self.ui.m_nodeFlag:setVisible(true)
    self.ui.m_labelTitle:setColor(COLOR_ATT)
    self.ui.m_labelTitle:setString(getLang("105559"))   --105559=进攻方
end

--防守方标志
TypeHandle[T_FLAG_DEF] = function(self, data)
    self.ui.m_nodeFlag:setVisible(true)
    self.ui.m_labelTitle:setColor(COLOR_DEF)
    self.ui.m_labelTitle:setString(getLang("105560"))   --105560=防守方
end

--提前结束战斗
TypeHandle[T_END_EARLY] = function(self, data)
    self.ui.m_nodeEnd:setVisible(true)
    self.ui.m_endTxt:setString(getLang("105151"))       --105151=由于攻防双方大本营等级差距过大，战斗提前结束。
end

--昵称
TypeHandle[T_NAME] = function(self, data)
    self.ui.m_nodeTitle:setVisible(true)
    self.ui.m_sprAtk:setVisible(data.isAtt)
    self.ui.m_sprDef:setVisible(not data.isAtt)
    self.ui.m_labelName:setString(data.userName)
    self.ui.m_labelName:setColor(data.isAtt and COLOR_ATT or COLOR_DEF)
end

--领主（GM=1可见）
TypeHandle[T_USER] = function(self, data)
    local total = 0
    for i,v in ipairs(data.mainGenKill or {}) do
        total = total + atoi(v)
    end

    local cell = Drequire("game.Mail.detail.MailBattleReportDetailArmyCell2").create({item = {kill = total}})
    cell:setTextColor(data.isAtt and COLOR_ATT or COLOR_DEF)
    cell:setUserHead(data.userHead)
    self.ui.m_nodeCell:addChild(cell)
end

--龙
TypeHandle[T_DRAGON] = function(self, data)
    for i,v in ipairs(data.talentSkillArray or {}) do
        local cell = Drequire("game.Mail.detail.MailBattleReportDetailDragonSkillCell").create(v)
        self.ui.m_nodeCell:addChild(cell)
        cell:setTextColor(data.isAtt and COLOR_ATT or COLOR_DEF)
        cell:setPositionY(80 * i - 75)
    end
    
    local friendly = atoi(data.friendly)
    local friendship = atoi(CCCommonUtilsForLua:call("getPropByIdGroup","dragon_new",data.dragonId,"friendship"))
    friendship = math.max(friendship, 1)
    friendly = math.floor(friendly * 100 / friendship)
    friendly = math.min(100, friendly)
    
    local dragonTimes = 0
    local dragonFround = 0
    local nLevel = -1
    local nSkillId = 0
    if table.isNilOrEmpty(data.dragonReport) == false then
        local item = data.dragonReport[1]
        dragonTimes = item.dragonTimes
        dragonFround = item.dragonFround
        nSkillId = item.dragonSkillId
        if item.level then
            nLevel = atoi(item.level)
        end
    end

    local decFri = data.decFriendly
    if isFunOpenByKey("dragon_friend_polish") then
        decFri = data.decFriNum and data.decFriNum or "0%"
    end

    local cell = Drequire("game.Mail.detail.MailBattleReportDetailDragonCell").create(
        {id = data.dragonId, level = data.level, friendly = friendly, kill = data.kill, decFri = decFri, 
        dragonTimes = dragonTimes, dragonFround = dragonFround, skinId = data.skinId})
    cell:setTextColor(data.isAtt and COLOR_ATT or COLOR_DEF)
            
    if isFunOpenByKey("dragon_skill_report_detail") and nLevel >= 0 then
        cell:setSkill(nSkillId, nLevel)
    end
    if table.isNilOrEmpty(data.talentSkillArray) == false then
        cell:setPositionY(80 * (#data.talentSkillArray))
    end
    self.ui.m_nodeCell:addChild(cell)
end

--英雄
TypeHandle[T_HERO] = function(self, data)
    local cell = Drequire("game.Mail.detail.MailBattleReportDetailHeroCell").create(
        {id = data.generalId, level = data.level, skills = data.skillList, skinId = data.marchSkinId})
    cell:setTextColor(data.isAtt and COLOR_ATT or COLOR_DEF)
    self.ui.m_nodeCell:addChild(cell)
end

--配置
TypeHandle[T_CONFIG] = function(self, data)
    local node,height = require("game.Mail.MailConfigManager").getManager():getConfigNodeByLua({config=data.config, attack=data.isAtt})
    if node and height then
        self.ui.m_nodeCell:addChild(node)
    end
end

--部队
TypeHandle[T_ARMY] = function(self, data)
    local isNormalServer = (not GlobalDataCtr.checkIsGreenServer())
    local race = atoi(data.race)
    local isP6 = ArmyController:call('getInstance'):call("isNewArmsFunOn", "p6_strong") and isFunOpenByKey("p6_mails")
    local armName = ArmyController:call("getArmyNameById", data.armId, race)
    local armIcon = ArmyController:call("getArmyIconById", data.armId, race)
    local armLevel = CCCommonUtilsForLua:call("getPropByIdGroup","arms",data.armId,"level")
    local armIcon1 = string.format("Roman_%s.png", armLevel)
    local armSkills = isP6 and data.skills or nil

    local cell = nil
    if table.isNilOrEmpty(data.list) then
        cell = Drequire("game.Mail.detail.MailBattleReportDetailArmyCell").create({
            name = armName, playerName = data.userName, icon = armIcon, icon1 = armIcon1, skills = armSkills, isHeal = isNormalServer, item = data
        })
    else
        cell = Drequire("game.Mail.detail.MailBattleReportDetailMoreArmyCell").create({
            name = armName, playerName = data.userName, icon = armIcon, icon1 = armIcon1, skills = armSkills, isHeal = isNormalServer, item = data
        })
    end

    cell:setTextColor(data.isAtt and COLOR_ATT or COLOR_DEF)
    local offset = cell:getHeight()
    cell:setPositionY(offset)
    self.ui.m_nodeCell:addChild(cell)
end

--陷阱
TypeHandle[T_FORT] = function(self, data)
    local armName = CCCommonUtilsForLua:call("getNameById", tostring(data.armId))
    local cell = Drequire("game.Mail.detail.MailBattleReportDetailArmyCell2").create({name = armName, item = data, icon = string.format("ico%s.png", data.armId)})
    cell:setTextColor(data.isAtt and COLOR_ATT or COLOR_DEF)
    self.ui.m_nodeCell:addChild(cell)
end

--箭塔
TypeHandle[T_TOWER] = function(self, data)
    local armName = ""
    if atoi(data.star) >= 1 then
        armName = string.format("%s %s%s", getLang("102016"), getLang("160001"), data.star)   --102016=箭塔   160001=荣耀
    else
        armName = string.format("%sLv%s", getLang("102016"), data.level)
    end

    local cell = Drequire("game.Mail.detail.MailBattleReportDetailArmyCell2").create({name = armName, item = data, icon = "battle_tower.png"})
    cell:setTextColor(data.isAtt and COLOR_ATT or COLOR_DEF)
    self.ui.m_nodeCell:addChild(cell)
end

return MailBattleReportDetailCell