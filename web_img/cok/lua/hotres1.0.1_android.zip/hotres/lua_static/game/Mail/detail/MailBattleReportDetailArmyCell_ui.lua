----------------------------
-- Author: Elex
-- Date: 2020-05-29 Friday
----------------------------

--#pre
local Drequire = Drequire
local Dprint = Dprint

local CustomUtility = Drequire("Editor.CustomUtility")
local ButtonSmoker = Drequire("Editor.ButtonSmoker")
local TableViewSmoker = Drequire("Editor.TableViewSmoker")
local LabelSmoker = Drequire("Editor.LabelSmoker")
local MarqueeSmoker = Drequire("Editor.MarqueeSmoker")
local NodeSmoker = Drequire("Editor.NodeSmoker")
local ParticleSmoker = Drequire("Editor.ParticleSmoker")
local GroupSmoker = Drequire("Editor.GroupSmoker")

--#class
local MailBattleReportDetailArmyCell_ui = class("MailBattleReportDetailArmyCell_ui")

--#ui propertys


--#function
function MailBattleReportDetailArmyCell_ui:create(owner, viewType, paramTable)
	local ret = MailBattleReportDetailArmyCell_ui.new()
	CustomUtility:DoRes(510, true)
	CustomUtility:DoRes(6, true)
	CustomUtility:LoadUi("MailBattleReportDetailArmyCell.ccbi", ret, owner, false, viewType, paramTable)
	NodeSmoker:registerNodeEvent(ret)
	ret:initLang()
	return ret
end

function MailBattleReportDetailArmyCell_ui:initLang()
end

function MailBattleReportDetailArmyCell_ui:onEnter()
	NodeSmoker:forwardFunction(self, "onEnter")
end

function MailBattleReportDetailArmyCell_ui:onExit()
	NodeSmoker:forwardFunction(self, "onExit")
end

return MailBattleReportDetailArmyCell_ui

