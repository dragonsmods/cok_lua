FindResTileViewCCB = FindResTileViewCCB or {}
ccb["FindResTileViewCCB"] = FindResTileViewCCB

local CC_ITOA = tostring
local ccud = cc.UserDefault:getInstance()

local FindResTileViewV4_41 = class("FindResTileViewV4_41", function() return PopupBaseView:call("create") end)
FindResTileViewV4_41.__index = FindResTileViewV4_41

local searchType = {
    WOOD                = 0,
    FOOD                = 1,
    IRON                = 2,
    STONE               = 3,
    GOLD                = 4,
    MONSTER             = 5,
    MONSTER_ORDINARY    = 6, -- 普通怪
    MONSTER_ACTIVITY    = 7, -- 活动怪
    CAMP                = 8, -- 营地
    MIRACLE_TRASURE     = 9, -- 奇迹宝藏
    SUPER_CAMP          = 10, -- 超级营地
    NATIONALWAR_BLACKSTONE    = 11, -- 神秘海域黑晶石
    NATIONALWAR_WHITESTONE    = 12, -- 神秘海域白晶石
    NATIONALWAR_CIVILIZATIONCRYSTAL    = 13, -- 神秘海域结晶矿
    REFINED_IRON        = 14,   --【Awen】精铁矿
}

local DefaultSType = 6

-- 自4.42版本开始有此新界面。同时由开关super_camp控制。
function FindResTileViewV4_41:create()
    local ret = FindResTileViewV4_41.new()
    if ret:initView() == false then
      return nil
    end
    return ret
end

function FindResTileViewV4_41:initView()
    if (self:init(true,0) == false) then
        return false;
    end

    self:initConfig()
    self:setHDPanelFlag(true);
    self:call("setOriginScale", true)
    CCLoadSprite:call("doResourceByCommonIndex",101, true);

    local proxy = cc.CCBProxy:create()
    local ccbiUrl = "FindResTileView_lua.ccbi"
    local tmpCCB = CCBReaderLoad(ccbiUrl, proxy, self)
    self:addChild(tmpCCB)
    self:setContentSize(CCDirector:sharedDirector():getIFWinSize())
    self:call("setModelLayerOpacity",0)

    self.animationManager = ccb["FindResTileViewCCB"]["mAnimationManager"]
    self.m_scrollView = CCScrollView:create(cc.size(self.m_infoList:getContentSize().width+10, self.m_infoList:getContentSize().height+10))
    self.m_scrollView:setDirection(kCCScrollViewDirectionHorizontal);
    self.m_scrollView:setTouchEnabled(true)
    self.m_scrollView:setPosition(ccp(-15,0))
    self.m_infoList:addChild(self.m_scrollView)

    self.m_mosterLv = 30
    local serverOpenTime = GlobalData:call("shared"):getProperty("serverOpenTime")
    local gap = GlobalData:call("shared"):call("getTimeStamp") - serverOpenTime
    gap = gap/3600
    gap = gap/24
    for i = 9450, 9474 do
        local day = tonumber(CCCommonUtilsForLua:call("getPropById", tostring(i), "day"))
        local level = tonumber(CCCommonUtilsForLua:call("getPropById", tostring(i), "level"))
        if day then
            if gap < day then
                self.m_mosterLv = level
                break
            end
        end
    end

    local worldConfig           = GlobalData:call("shared"):getProperty("worldConfig")
    self.city_barracks_maxLevel  = worldConfig:getProperty("city_barracks_maxLevel")

    self.m_canClose = true

    -- self.iconArr = self:loadConfig()
    self.iconArr = self:parseConfig(self:loadConfig())
    -- dump(self.iconArr, "iconArr", 6)
 
    table.sort(self.iconArr, function(a, b)
        if a.order then
            if b.order then
                return a.order < b.order
            else
                return true
            end
        else
            if b.order then
                return false
            else
                return a.type < b.type
            end
        end
    end)

    self:initSliderBar()
    -- self.m_buildType = ccud:getIntegerForKey("FindResTile_Type", 6)
    self:loadSelType()
    self:loadSelSubType()
    self:loadSelCurLv()

    self.itemMap = {}
    for k, v in ipairs(self.iconArr) do
        local result = self:createFindNode(v)
        self.m_scrollView:addChild(result.node)
        self.itemMap[v.type] = result
    end
    self:updateLayout()
    self:loadSelText()
    
    -- self.m_dataCount = cnt
    -- self.m_scrollView:setContentSize(cc.size(cellW*self.m_dataCount + 10, self.m_infoList:getContentSize().height))


    self.m_info1Label:setString(getLang("102203"))
    self.m_info4Label:setString(getLang("113232"))
    local w1 = self.m_info4Label:getContentSize().width --*self.m_info4Label:getOriginScaleX()
    local w2 = self.m_findIcon:getContentSize().width --*self.m_findIcon:getScaleX()
    local ptX = (w1+w2)/2 - w1
    self.m_info4Label:setPositionX(ptX)
    self.m_findIcon:setPositionX(ptX)
    
    local maxSearchCount = WorldController:call("getInstance"):getProperty("maxSearchCount")
    local resSearchCount = WorldController:call("getInstance"):getProperty("resSearchCount")
    local lastCnt = maxSearchCount - resSearchCount
    if lastCnt > 0 then
        self.m_info2Label:setString(getLang("113227", CC_ITOA(lastCnt)))
    else
        self.m_info2Label:setString(getLang("113227", CC_ITOA(0)))
    end
    
    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
    local vipEndTime = playerInfo:getProperty("vipEndTime")
    local curTime = GlobalData:call("shared"):call("getWorldTime")
    if CCCommonUtilsForLua:call("isFunOpenByKey", "find_vip") and vipEndTime > curTime then
        self.m_info2Label:setString(getLang("113230"))
    end
    
    local tmp = CCCommonUtilsForLua:call("getVersionName")
    if tmp == "2.6.0" then
        ccud:setBoolForKey("FindResTileOpen", false);
        ccud:flush();
    end

    local function onNodeEvent( event )
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        elseif event == "cleanup" then
            self:onCleanUp()
        end
    end
    self:registerScriptHandler(onNodeEvent)
    
    local function touchHandle( eventType, x, y )
        if eventType == "began" then
            return self:onTouchBegan(x, y)
        elseif eventType == "moved" then

        else
            self:onTouchEnded(x, y)
        end
    end
    self:registerScriptTouchHandler(touchHandle)
    self:checkAutoQueue()

    return true;
end

function FindResTileViewV4_41:initConfig()
    -- 年兽等级配置
    self.m_monster_level = {}
    local monster_str = CCCommonUtilsForLua:getPropByIdGroup("data_config", "special_monster_level", "k1")
    if monster_str and monster_str ~= "" then
        self.m_monster_level = string.split(monster_str, "|")
        for index, value in ipairs(self.m_monster_level) do
            self.m_monster_level[index] = atoi(value)
        end
    end
end

function FindResTileViewV4_41:initSliderBar()
    self.m_maxLevelNum = 7;
    local str3 = "/";
    self.m_info3Label:setString(str3..CC_ITOA(self.m_maxLevelNum));
    self.m_invalidSliderMove = false;

    local sliderWidth = 260
    local m_sliderBg = CCLoadSprite:call("createScale9Sprite","huadongtiao3.png");
    m_sliderBg:setInsetBottom(5);
    m_sliderBg:setInsetLeft(5);
    m_sliderBg:setInsetRight(5);
    m_sliderBg:setInsetTop(5);
    m_sliderBg:setAnchorPoint(ccp(0.5,0.5));
    m_sliderBg:setPosition(ccp(sliderWidth/2, 25));
    m_sliderBg:setContentSize(cc.size(sliderWidth,18));
    
    local bgSp = CCLoadSprite:call("createSprite","huadongtiao4.png");
    bgSp:setVisible(false);
    local proSp = CCLoadSprite:call("createSprite","huadongtiao4.png");
    local thuSp = CCLoadSprite:call("createSprite","huadongtiao1.png");
    
    self.m_trainSlider = CCSliderBar:call("createSlider",m_sliderBg, proSp, thuSp);
    self.m_trainSlider:setMinimumValue(0.0);
    self.m_trainSlider:setMaximumValue(1.0);
    self.m_trainSlider:call("setProgressScaleX",sliderWidth/proSp:getContentSize().width);
    self.m_trainSlider:setTag(1);
    self.m_trainSlider:call("setLimitMoveValueEx",2);

    local function valueChanged(pSender)
        self:sliderCallBack()
    end
    self.m_trainSlider:addHandleOfControlEvent(valueChanged, CCControlEventValueChanged)
    self.m_sliderNode:addChild(self.m_trainSlider, 1);

    local editSize = self.m_useEditNode:getContentSize();
    local editpic = CCLoadSprite:call("createScale9Sprite","frame_3.png");
    editpic:setContentSize(editSize);
    editpic:setInsetBottom(1);
    editpic:setInsetTop(1);
    editpic:setInsetRight(1);
    editpic:setInsetLeft(1);
    self.m_editBox = CCEditBox:create(editSize,editpic);
    self.m_editBox:setInputMode(cc.EDITBOX_INPUT_MODE_NUMERIC);
    self.m_editBox:setText("0");
    self.m_editBox:setMaxLength(12);
    self.m_editBox:setReturnType(cc.KEYBOARD_RETURNTYPE_DONE);
    self.m_editBox:setPosition(ccp(editSize.width/2, editSize.height/2));
    self.m_useEditNode:addChild(self.m_editBox);

    local function editCB (strEventName,pSender)
        if tostring(pSender) == "began" then
            --光标进入，选中全部内容
            -- print("self.m_editOpen = true")
            self.m_editOpen = true
        elseif tostring(pSender) == "ended" then
            -- 当编辑框失去焦点并且键盘消失的时候被调用
        elseif tostring(pSender) == "return" then
            -- 当用户点击编辑框的键盘以外的区域，或者键盘的Return按钮被点击时所调用
            self:editBoxReturn(self.m_editBox:getText())         
        elseif tostring(pSender) == "changed" then
            -- 输入内容改变时调用
            self:editBoxTextChanged(self.m_editBox:getText())     
        end
    end
    self.m_editBox:registerScriptEditBoxHandler(editCB) --输入框的事件，主要有光标移进去，光标移出来，以及输入内容改变等
end

function FindResTileViewV4_41:onEnter()
    self:call("setTouchEnabled",true)
    -- self:SetUpdateSliderValue()

    self.m_canClose = false
    local callback = function()
        if GuideController:call("isInTutorial") then
            GuideController:call("next")

            --【Awen】如果是搜索怪引导，强制选择怪物及配置的等级
            if CCCommonUtilsForLua:isFunOpenByKey("new_story_guide") then
                local _guideId = GuideController:call("getCurGuideID")
                local _guideArea = CCCommonUtilsForLua:call("getPropByIdGroup","guide",_guideId,"area")
                if _guideArea == 'LUA_search_monster' then
                    local _para = CCCommonUtilsForLua:call("getPropByIdGroup","guide",_guideId,"para1")
                    _para = tonumber(_para) or 1
                    self.selectedType = searchType.MONSTER_ORDINARY
                    self.selectedSubType = searchType.MONSTER_ORDINARY
                    self.m_curLv = tonumber(_para or 1)
                    -- local key = "FindResTile_"..CC_ITOA(self.m_buildType)
                    -- local value = ccud:setIntegerForKey(key, _para);
                    self:saveSelType()
                    self:saveSelSubType()
                    self:loadSelText()
                    self:saveSelCurLv()
                    self:SetUpdateSliderValue()

                    self.m_selIcon1:setVisible(true)
                    self.m_selIcon2:setVisible(false)
                    self.m_scrollView:setContentOffset(cc.p(0, 0))
                end
            end
        end
        self:onAniFadeInEnd()
    end
    self.animationManager:setAnimationCompletedCallback(callback)
    self.animationManager:runAnimationsForSequenceNamed("fadeIn")
end

function FindResTileViewV4_41:onExit()
    self:call("setTouchEnabled",false);
end

function FindResTileViewV4_41:onCleanUp()
    CCLoadSprite:call("doResourceByCommonIndex",101, false);
end


function FindResTileViewV4_41:SetUpdateSliderValue()

    -- local selectedType = self.selectedType --self.iconArr[self.m_buildType+1].type

    self.m_maxLevelNum = 1
    self.levelsCanBeSelect = nil
    if self.itemMap 
        and self.selectedType 
        and self.itemMap[self.selectedType] 
        and self.itemMap[self.selectedType].config then
        local config = self.itemMap[self.selectedType].config
        self.m_maxLevelNum = config.maxLevel or self.m_maxLevelNum
        if config.expand and self.selectedSubType then
            for _, v in pairs(config.expand) do
                if v.subType == self.selectedSubType then
                    if v.maxLevel then
                        self.m_maxLevelNum = v.maxLevel
                    end
                end
            end
        end
    end

    local  str3 = "/";
    self.m_info3Label:setString(str3..CC_ITOA(self.m_maxLevelNum))

    self:setSliderAndEdit()
end

function FindResTileViewV4_41:setSliderAndEdit()
    -- self:loadSelCurLv()
    if self.m_curLv > self.m_maxLevelNum then
        self.m_curLv = self.m_maxLevelNum
        self:saveSelCurLv()
    end
    self.m_trainSlider:setValue(self.m_curLv / self.m_maxLevelNum)
    self.m_editBox:setText(CC_ITOA(self.m_curLv))
end

function FindResTileViewV4_41:onFindBtnClick()

    function doFind()
        -- self:saveSelType()
        -- self:saveSelCurLv()

        local buildType = self.selectedSubType or self.selectedType
        local item = self.m_itemId or ""
        local curLv = self.m_curLv
        local cmd = Drequire("game.command.IFFindResTileCmd").create(buildType, curLv, item)
        cmd:send()

        self:call("closeSelf")
    end

    local playerInfo = GlobalData:call("shared"):getProperty("playerInfo")
    local vipEndTime = playerInfo:getProperty("vipEndTime")
    local curTime = GlobalData:call("shared"):call("getWorldTime")
    if CCCommonUtilsForLua:call("isFunOpenByKey", "find_vip") and vipEndTime > curTime then
        doFind()
    else
        local maxSearchCount = WorldController:call("getInstance"):getProperty("maxSearchCount")
        local resSearchCount = WorldController:call("getInstance"):getProperty("resSearchCount")
        local lastCnt = maxSearchCount - resSearchCount
        if lastCnt > 0 then  
            doFind()
        else
            if CCCommonUtilsForLua:call("isFunOpenByKey", "find_vip") then
                CCCommonUtilsForLua:call("flyHint", "", "", getLang("113228"))
            else
                CCCommonUtilsForLua:call("flyHint", "", "", getLang("113231"))
            end
        end
    end
end

function FindResTileViewV4_41:editBoxTextChanged(text)
    local temp = ""
    for s in string.gmatch(text, "%d") do
        temp = temp .. s
    end
    if temp == "" then
        temp = "0"
    end
    local a = tonumber(temp);
    local aaaa = CC_CMDITOA(a);
    self.m_editBox:setText(aaaa);
end

function FindResTileViewV4_41:editBoxReturn()
    local numStr = self.m_editBox:getText();
    numStr = string.gsub(numStr, ",", "");
    local num = tonumber(numStr);
    num = math.ceil(num-0.5)
    if(num > self.m_maxLevelNum)then
        num = self.m_maxLevelNum;
    end
    if(num < 1) then
        num = 1;
    end
    self.m_curLv = num
    self:saveSelCurLv()
    self:setSliderAndEdit()
    self.m_trainSlider:setValue(num / self.m_maxLevelNum);
end

function FindResTileViewV4_41:sliderCallBack(sender, even)
    if (self.m_invalidSliderMove) then
        self.m_invalidSliderMove = false
        return
    end

    self.m_curLv = self.m_trainSlider:getValue() * self.m_maxLevelNum
    local buildType = self.selectedSubType or self.selectedType
    if buildType == searchType.MONSTER_ACTIVITY and CCCommonUtilsForLua:isFunOpenByKey("special_monster_level") then
        local count = #self.m_monster_level
        if count > 0 then
            -- 年兽只搜索配置等级
            if count == 1 or self.m_curLv <= self.m_monster_level[1] then
                self.m_curLv = self.m_monster_level[1]
            elseif self.m_curLv >= self.m_monster_level[count] then
                self.m_curLv = self.m_monster_level[count]
            else
                for i = 1, count-1 do
                    if self.m_curLv >= self.m_monster_level[i] and self.m_curLv <= self.m_monster_level[i+1] then
                        if self.m_curLv - self.m_monster_level[i] < self.m_monster_level[i+1] - self.m_curLv then
                            self.m_curLv = self.m_monster_level[i]
                        else
                            self.m_curLv = self.m_monster_level[i+1]
                        end
                        break
                    end
                end
            end
        else
            self.m_curLv = math.ceil(self.m_curLv-0.5)
        end
    else
        self.m_curLv = math.ceil(self.m_curLv-0.5)
    end

    if(self.m_curLv > self.m_maxLevelNum)then
        self.m_curLv = self.m_maxLevelNum;
    end
    if(self.m_curLv < 1) then
        self.m_curLv = 1;
    end

    self:saveSelCurLv()
    self.m_editBox:setText(CC_ITOA(self.m_curLv))
    self.m_invalidSliderMove = true
    self.m_trainSlider:setValue(self.m_curLv * 1.0 / self.m_maxLevelNum)
end

function FindResTileViewV4_41:onAddClick()
    local buildType = self.selectedSubType or self.selectedType
    local count = #self.m_monster_level
    if buildType == searchType.MONSTER_ACTIVITY and CCCommonUtilsForLua:isFunOpenByKey("special_monster_level") and count > 0 then
        local index = -1
        if count == 1 or self.m_curLv <= self.m_monster_level[1] then
            index = 1
        elseif self.m_curLv >= self.m_monster_level[count] then
            index = count
        else
            for i = 1, count-1 do
                if self.m_curLv >= self.m_monster_level[i] and self.m_curLv <= self.m_monster_level[i+1] then
                    if self.m_curLv - self.m_monster_level[i] < self.m_monster_level[i+1] - self.m_curLv then
                        index = i
                    else
                        index = i + 1
                    end
                    break
                end
            end
        end

        if index < count then
            self.m_curLv = self.m_monster_level[index+1]
            self:saveSelCurLv()
            self:setSliderAndEdit()
            self.m_trainSlider:setValue(1.0 * self.m_curLv / self.m_maxLevelNum);
            self.m_editBox:setText(CC_ITOA(self.m_curLv))
        end
    else
        local value = self.m_curLv + 1
        if (self.m_maxLevelNum < value) then
            return
        else
            self.m_curLv = math.ceil(value-0.5)
            self:saveSelCurLv()
            self:setSliderAndEdit()
            self.m_trainSlider:setValue(1.0 * self.m_curLv / self.m_maxLevelNum);
            self.m_editBox:setText(CC_ITOA(self.m_curLv))
        end
    end
end

function FindResTileViewV4_41:onReduceClick()
    local buildType = self.selectedSubType or self.selectedType
    local count = #self.m_monster_level
    if buildType == searchType.MONSTER_ACTIVITY and CCCommonUtilsForLua:isFunOpenByKey("special_monster_level") and count > 0 then
        local index = -1
        if count == 1 or self.m_curLv <= self.m_monster_level[1] then
            index = 1
        elseif self.m_curLv >= self.m_monster_level[count] then
            index = count
        else
            for i = 1, count-1 do
                if self.m_curLv >= self.m_monster_level[i] and self.m_curLv <= self.m_monster_level[i+1] then
                    if self.m_curLv - self.m_monster_level[i] < self.m_monster_level[i+1] - self.m_curLv then
                        index = i
                    else
                        index = i + 1
                    end
                    break
                end
            end
        end

        if index > 1 then
            self.m_curLv = self.m_monster_level[index-1]
            self:saveSelCurLv()
            self:setSliderAndEdit()
            self.m_trainSlider:setValue(1.0 * self.m_curLv / self.m_maxLevelNum);
            self.m_editBox:setText(CC_ITOA(self.m_curLv));
        end
    else
        local value = self.m_curLv - 1
        if (1 > value) then
            return
        else
            self.m_curLv = math.ceil(value-0.5)
            self:saveSelCurLv()
            self:setSliderAndEdit()
            self.m_trainSlider:setValue(1.0 * self.m_curLv / self.m_maxLevelNum);
            self.m_editBox:setText(CC_ITOA(self.m_curLv));
        end
    end
end

function FindResTileViewV4_41:onAniFadeInEnd()
    self.m_canClose = true
    self.animationManager:setAnimationCompletedCallback(nil)
end
function FindResTileViewV4_41:onAniFadeOutEnd()
    self.m_canClose = true
    self:call("closeSelf")
end

function FindResTileViewV4_41:getGuideNode( key )
    if key == 'LUA_UI_searchBtn' or key == 'LUA_search_monster' then
        local function callBack()
            self:onFindBtnClick()
            GuideController:call("next")
        end
        GuideController:call("setCallback", cc.CallFunc:create(callBack))
        return self.m_findBtn
    end
    return nil
end

function FindResTileViewV4_41:onTouchBegan(x, y)
    self.startX = x
    self.startY = y
    return true
end

function FindResTileViewV4_41:onTouchEnded(x, y)
    if (isTouchInside(self.m_touchNode, x, y)) then
        local moveX = x - self.startX
        if math.abs(moveX) < 20 then
            for _, v in pairs(self.itemMap) do
                v.methods.onTouchSelectType(x, y)
            end
        end
    elseif self.m_canClose == true then
        if not isTouchTriggered(x, y, cc.p(self.startX, self.startY)) then
            return
        end
        self.m_canClose = false;
        local callback = function()
            self:onAniFadeOutEnd()
        end
        self.animationManager:setAnimationCompletedCallback(callback)
        self.animationManager:runAnimationsForSequenceNamed("fadeOut")
    end
end


function FindResTileViewV4_41:createFindNode(config)
    local node = cc.Node:create()
    node:setAnchorPoint(ccp(0, 0.5))

    local bg = CCLoadSprite:call("createSprite","circle_bg_l.png")
    CCCommonUtilsForLua:call("setSpriteMaxSize", bg, 100, true)
    bg:setAnchorPoint(ccp(0, 0))
    node:addChild(bg)
    
    local buildIcon = CCLoadSprite:call("createSprite",config.icon)
    CCCommonUtilsForLua:call("setSpriteMaxSize", buildIcon, 100, true)

    buildIcon:setPosition(ccp(bg:getPositionX()+50, bg:getPositionY()+60))
    node:addChild(buildIcon)

    -- 黑白晶石icon太大
    if config.itemid and (config.itemid == "36000116" or 
                          config.itemid == "36000117" or 
                          config.itemid == "212069"
                         ) then
        buildIcon:setScale(0.6)
        buildIcon:setPosition(ccp(bg:getPositionX()+50, bg:getPositionY()+50))
    end

    local selFrame = CCLoadSprite:call("createSprite","tips_kuang_xuan.png")
    selFrame:setAnchorPoint(ccp(0,0))
    CCCommonUtilsForLua:call("setSpriteMaxSize", selFrame, 130, true)
    selFrame:setVisible(false)
    selFrame:setPosition(ccp(-15, -15))
    node:addChild(selFrame)
    
    local nodeWidth = 104
    local nodeExpandWidth = 0
    -- local options = nil
    local subSelTypeNodes = nil

    local menuNode = nil
    if config.expand then
        menuNode = cc.Node:create()
        
        node:addChild(menuNode)
        menuNode:setPosition(ccp(nodeWidth, 0))

        subSelTypeNodes = {}
        -- options = {}
        for k, v in ipairs(config.expand) do
            local y = (2 - k) * 50
            local mbg1 = CCLoadSprite:call("createSprite","circle_bg_l.png")
            CCCommonUtilsForLua:call("setSpriteMaxSize", mbg1, 40, true)
            mbg1:setAnchorPoint(ccp(0, 0))
            mbg1:setPosition(ccp(10, y))
            menuNode:addChild(mbg1)

            local mIcon1 = CCLoadSprite:call("createSprite","green_yes.png")
            CCCommonUtilsForLua:call("setSpriteMaxSize", mIcon1, 40, true)
            mIcon1:setAnchorPoint(ccp(0, 0))
            mIcon1:setPosition(ccp(15, y + 5))
            menuNode:addChild(mIcon1)
            mIcon1:setVisible(false)

            local mLabel1 = cc.Label:createWithSystemFont(getLang(v.dialog or "149701"), "Helvetica", 22, cc.size(0,0)) -- 149701=普通
            mLabel1:setColor(cc.c3b(81, 50, 2))
            mLabel1:setPosition(ccp(55,y + 20))
            mLabel1:setAnchorPoint(ccp(0,0.5))
            menuNode:addChild(mLabel1)

            local width = 60 + mLabel1:getContentSize().width
            if width > nodeExpandWidth then
                nodeExpandWidth = width
            end

            -- table.insert(subSelTypeNodes, {
            --     subType = v.subType,
            --     selBg = mbg1,
            --     selIcon = mIcon1,
            -- })
            subSelTypeNodes[v.subType] = {
                subType = v.subType,
                selBg = mbg1,
                selIcon = mIcon1,
            }

        end
    end

    ------------------------------------------------------------------------------

    local state = {}
    local function isSelected()
        if self.selectedType == config.type then
            return true
        else
            return false
        end
    end
    local function checkExpand()
        if isSelected() and config.expand then
            return true
        else
            return false
        end
    end
    local function updateExpand()
        if menuNode then
            menuNode:setVisible(checkExpand())
        end
        selFrame:setVisible(isSelected())
    end
    local function getWidth()
        if checkExpand() then
            return nodeWidth + nodeExpandWidth
        else
            return nodeWidth
        end
    end

    local function updateSubType()
        if subSelTypeNodes then
            for _, v in pairs(subSelTypeNodes) do
                v.selIcon:setVisible(v.subType == self.selectedSubType)
            end
        end
    end

    local function getFirstExpandSubType()
        if  config.expand and config.expand[1] then
            return config.expand[1].subType
        end
    end

    ------------------------------------------------------------------------------

    local function onTouchSelectType(x, y)
        if isTouchInside(bg, x, y) then
            if not self.selectedType or self.selectedType ~= config.type then
                self.selectedSubType = nil
                self.selectedType = config.type 
                self:saveSelType()
                self:loadSelSubType()
                self:loadSelText()
                self:loadSelCurLv()
                self:updateLayout()
            end
        elseif subSelTypeNodes then
            for _, v in pairs(subSelTypeNodes) do
                if self.selectedSubType ~= v.subType and isTouchInside(v.selBg, x, y) then
                    self.selectedSubType = v.subType
                    self:saveSelSubType()
                    self:loadSelCurLv()
                    self:loadSelText()
                    self:updateLayout()
                    break
                end
            end
        end
    end

    ------------------------------------------------------------------------------
    return {
        node = node, 
        config = config,
        state = state,
        methods = {
            isSelected = isSelected,
            checkExpand = checkExpand,
            updateExpand = updateExpand,
            updateSubType = updateSubType,
            getWidth = getWidth,
            onTouchSelectType = onTouchSelectType,
            getFirstExpandSubType = getFirstExpandSubType,
        }
    }
end

function FindResTileViewV4_41:updateLayout()
    local selItem = self.itemMap[self.selectedType or DefaultSType]
    if selItem and selItem.methods.checkExpand() then
        if not self.selectedSubType then
            self.selectedSubType = selItem.methods.getFirstExpandSubType()
            self:saveSelSubType()
            self:loadSelCurLv()
        end
    else
        self.selectedSubType = nil
    end

    -- itemid
    if selItem and selItem.config then
        self.m_itemId = selItem.config.itemid or ""
    end

    local x = 0
    local y = 15
    for k, v in ipairs(self.iconArr) do
        local type = v.type
        local item = self.itemMap[type]
        if item then
            item.node:setPosition(ccp(x, y))
            item.methods.updateExpand()
            item.methods.updateSubType()
            local width = item.methods.getWidth()
            x = x + width
        end
    end
    self.m_scrollView:setContentSize(cc.size(x, self.m_infoList:getContentSize().height))
    self:SetUpdateSliderValue()
end

function FindResTileViewV4_41:saveSelType()
    ccud:setIntegerForKey("FindResTile_SelectedType", self.selectedType or DefaultSType)
    ccud:flush()
end

function FindResTileViewV4_41:loadSelType()
    self.selectedType = ccud:getIntegerForKey("FindResTile_SelectedType", DefaultSType)
end

function FindResTileViewV4_41:saveSelSubType()
    ccud:setIntegerForKey("FindResTile_SelectedSubType_"..tostring(self.selectedType or DefaultSType), self.selectedSubType or -1)
    ccud:flush()
end

function FindResTileViewV4_41:loadSelSubType()
    local subType = ccud:getIntegerForKey("FindResTile_SelectedSubType_"..tostring(self.selectedType or DefaultSType), -1)
    if subType ~= -1 then
        self.selectedSubType = subType
    else
        self.selectedSubType = nil
    end
end 

function FindResTileViewV4_41:saveSelCurLv()
    ccud:setIntegerForKey("FindResTile_LvOfType_"..tostring(self.selectedSubType or self.selectedType or DefaultSType), self.m_curLv or 1)
    ccud:flush()
end

function FindResTileViewV4_41:loadSelCurLv()
    self.m_curLv = ccud:getIntegerForKey("FindResTile_LvOfType_"..tostring(self.selectedSubType or self.selectedType or DefaultSType), 1)
end

function FindResTileViewV4_41:loadSelText()
    local desc = ""
    if self.itemMap 
        and self.selectedType 
        and self.itemMap[self.selectedType] 
        and self.itemMap[self.selectedType].config then
        local config = self.itemMap[self.selectedType].config
        desc = config.desc
        if config.expand and self.selectedSubType then
            for _, v in pairs(config.expand) do
                if v.subType == self.selectedSubType then
                    desc = v.desc
                    break
                end
            end
        end
    end
    if desc and desc ~= "" then
        self.m_info5Label:setString(getLang(desc))
    else
        self.m_info5Label:setString("")
    end
end

-- 筛选数据
function FindResTileViewV4_41:parseConfig(result)
    local mapTypeData = {}
    local baseData = {}
    local needData = {}
    for k, v in pairs(result) do
        if  v.mapType and v.mapType ~= "" then
            table.insert( mapTypeData, #mapTypeData+1, v)
        else
            table.insert( baseData, #baseData+1, v)
        end
    end

    -- 神秘海域
    if CCCommonUtilsForLua:call("isFunOpenByKey", "ek_map_search") and  WorldController:call("getInstance"):getProperty("currentMapType") == MapType.NATIONALWAR_MAP then
        for k, v in pairs(mapTypeData) do
            local arr = string.split(v.mapType, ";")
            if  table.contains(arr, tostring(MapType.NATIONALWAR_MAP)) then
                table.insert( needData, #needData+1, v)
            end
        end
       return needData
    end
    return baseData
end

function FindResTileViewV4_41:loadConfig()
 
    local xmlGroup = CCCommonUtilsForLua:getGroupByKey("map_search")
    if xmlGroup and next(xmlGroup) ~= nil then
        local result = {}
        for _, v in pairs(xmlGroup) do
            if v.funtion_on == nil or CCCommonUtilsForLua:isFunOpenByKey(v.funtion_on) then
                local one = {}
                one.icon = v.icon..".png"
                one.id = tonumber(v.id)
                one.order = tonumber(v.order)
                
                -- 新增字段mapType,itemid
                one.mapType = v.mapType or ""
                one.itemid = v.itemid or ""

                -- one.type = tonumber(v.id)
                local arr = string.split(v.subType, ";")
                if #arr > 1 then
                    one.expand = {}
                    for k2, v2 in ipairs(arr) do
                        one.expand[k2] = {}
                        one.expand[k2].subType = tonumber(v2)
                        if not one.type then
                            one.type = tonumber(v2)
                        end
                    end
                    arr = string.split(v.maxLevel, ";")
                    for k2, v2 in ipairs(arr) do
                        if not one.expand[k2] then
                            break
                        end
                        one.expand[k2].maxLevel = tonumber(v2)
                    end
                    arr = string.split(v.dialog, ";")
                    for k2, v2 in ipairs(arr) do
                        if not one.expand[k2] then
                            break
                        end
                        one.expand[k2].dialog = v2
                    end

                    local solts = string.split(v.desc, ";")
                    for k2, v2 in ipairs(solts) do
                        if not one.expand[k2] then
                            break
                        end
                        one.expand[k2].desc = v2
                    end
                else
                    one.maxLevel = tonumber(v.maxLevel)
                    one.type = tonumber(v.subType)
                    one.desc = v.desc or ""
                end
                table.insert(result, one)
            end
        end
        return result
    else
        return {
            {icon = "w_res_wood.png",       type = searchType.WOOD, maxLevel = 9},
            {icon = "w_res_food.png",       type = searchType.FOOD, maxLevel = 9},
            {icon = "w_res_iron.png",       type = searchType.IRON, maxLevel = 9},
            {icon = "w_res_stone.png",      type = searchType.STONE, maxLevel = 9},
            {
                icon = "yingdi.png",
                type = searchType.CAMP,
                order = 2,
                expand = {
                    {dialog = "149701", subType = searchType.CAMP, maxLevel = tonumber(self.city_barracks_maxLevel),},
                    {dialog = "149700", subType = searchType.SUPER_CAMP, maxLevel = 3},
                }
            },
            {icon = "qijibaozang.png",      type = searchType.MIRACLE_TRASURE, maxLevel = 1},
            {icon = "w_res_gold.png",       type = searchType.GOLD, maxLevel = 7},
            -- {icon = "w_res_monster.png",    type = searchType.MONSTER},
            {
                icon = "w_res_monster.png",
                type = searchType.MONSTER_ORDINARY, 
                order = 1, 
                expand = {
                    {dialog = "149701", subType = searchType.MONSTER_ORDINARY, maxLevel = 30},
                    {dialog = "149700", subType = searchType.MONSTER_ACTIVITY, maxLevel = 30},
                }
            },
        }
    end
end

function FindResTileViewV4_41:checkAutoQueue()
    local autoCtrl = require("game.autoQueue.AutoQueueController").getInstance()
    if autoCtrl:isFunOpen() then
        -- self.m_findNode:setPositionX(-158)
        -- self.m_autoNode:setPositionX(158)
        self.m_autoNode:setVisible(true)
        self.m_autoText:setString(getLang("681262"))

        -- local size = self.m_autoBtn:getContentSize()
        -- self.m_findBtn:setPreferredSize(size)

        if autoCtrl:isOpen() then
            local rootPath = CCFileUtils:sharedFileUtils():getWritablePath() .. "dresource/"
            local skin_file = rootPath .. "sk_autoQueue.atlas" 
            local skin_json = rootPath .. "sk_autoQueue.json"
            if cc.FileUtils:getInstance():isFileExist(skin_file) 
                and cc.FileUtils:getInstance():isFileExist(skin_json) 
                then
                local spine = IFSkeletonAnimation:call("create", skin_json, skin_file)
                if spine then
                    spine:setAnimation(0, "tubiao", true)
                    spine:setContentSize(100, 888)
                    self.m_autoSpineNode:removeAllChildren()
                    self.m_autoSpineNode:addChild(spine)
                end
            end
        end
    end
end

function FindResTileViewV4_41:onClickAuto()
    self:call("closeSelf")
    require("game.autoQueue.AutoQueueController").getInstance():openSet()
end

return FindResTileViewV4_41
