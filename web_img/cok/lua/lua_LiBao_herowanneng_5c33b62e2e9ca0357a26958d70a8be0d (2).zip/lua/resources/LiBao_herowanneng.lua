cfg_table = {
	["layerX"] = -10,
	["layerY"] = -40,
	["layerScale"] = 1
}