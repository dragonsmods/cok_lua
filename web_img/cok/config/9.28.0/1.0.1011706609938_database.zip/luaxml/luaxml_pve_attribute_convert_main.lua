-- luaxml_pve_attribute_convert_main
local luaxml_pve_attribute_convert_main = {
	["53810001"] = {
		["id"] = "53810001",
		["name"] = "52630605",
		["desc"] = "52630606",
	},
	["53810002"] = {
		["id"] = "53810002",
		["name"] = "52630605",
		["desc"] = "52630606",
	},
}
return luaxml_pve_attribute_convert_main
