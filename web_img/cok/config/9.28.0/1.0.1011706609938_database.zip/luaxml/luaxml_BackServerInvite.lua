-- luaxml_BackServerInvite
local luaxml_BackServerInvite = {
	["54081001"] = {
		["type"] = "1",
		["id"] = "54081001",
		["rewardid"] = "45049658",
		["title"] = "364016",
	},
	["54081002"] = {
		["title"] = "364017",
		["type"] = "2",
		["id"] = "54081002",
		["icons"] = "backserver_btn_buff;364019|backserver_icon_activity;364020",
	},
	["54081003"] = {
		["title"] = "364018",
		["type"] = "2",
		["id"] = "54081003",
		["icons"] = "backserver_icon_changeserver;364021",
	},
}
return luaxml_BackServerInvite
