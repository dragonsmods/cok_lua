-- luaxml_minigame
local luaxml_minigame = {
	["53809101"] = {
		["url"] = "http://47.92.107.65:81/builds/web-mobile-02/",
		["id"] = "53809101",
		["param"] = "",
		["name"] = "9900753",
	},
	["53809102"] = {
		["url"] = "http://47.92.107.65:81/builds/web-mobile-04/",
		["id"] = "53809102",
		["param"] = "",
		["name"] = "80000080",
	},
	["53809103"] = {
		["url"] = "http://47.92.107.65:81/builds/web-mobile-05/",
		["id"] = "53809103",
		["param"] = "",
		["name"] = "52376540",
	},
	["53809104"] = {
		["url"] = "http://cok.eleximg.com/cok/h5/builds3/web-mobile-07/",
		["id"] = "53809104",
		["param"] = "",
		["name"] = "52376540",
	},
	["53809105"] = {
		["url"] = "http://cok.eleximg.com/cok/h5/builds3/web-mobile-06/",
		["id"] = "53809105",
		["param"] = "",
		["name"] = "52376540",
	},
	["53809106"] = {
		["url"] = "http://47.92.107.65:81/builds/web-mobile-10/",
		["id"] = "53809106",
		["param"] = "",
		["name"] = "52376540",
	},
	["53809107"] = {
		["url"] = "http://cok.eleximg.com/cok/h5/builds3/web-mobile-11/",
		["id"] = "53809107",
		["param"] = "",
		["name"] = "52376540",
	},
	["53809108"] = {
		["url"] = "http://cok.eleximg.com/cok/h5/builds3/web-mobile-12/",
		["id"] = "53809108",
		["param"] = "",
		["name"] = "52376540",
	},
}
return luaxml_minigame
