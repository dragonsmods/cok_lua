-- luaxml_new_year_dinner_activation
local luaxml_new_year_dinner_activation = {
	["53055071"] = {
		["score"] = "40",
		["disheCount"] = "150",
		["id"] = "53055071",
		["disheId"] = "36012675",
	},
	["53055072"] = {
		["score"] = "18",
		["disheCount"] = "300",
		["id"] = "53055072",
		["disheId"] = "36012676",
	},
	["53055073"] = {
		["score"] = "12",
		["disheCount"] = "450",
		["id"] = "53055073",
		["disheId"] = "36012677",
	},
	["53055074"] = {
		["score"] = "8",
		["disheCount"] = "600",
		["id"] = "53055074",
		["disheId"] = "36012678",
	},
	["53055075"] = {
		["score"] = "6",
		["disheCount"] = "750",
		["id"] = "53055075",
		["disheId"] = "36012679",
	},
	["53055076"] = {
		["score"] = "5",
		["disheCount"] = "900",
		["id"] = "53055076",
		["disheId"] = "36012680",
	},
	["53055077"] = {
		["score"] = "4",
		["disheCount"] = "1050",
		["id"] = "53055077",
		["disheId"] = "36012681",
	},
	["53055078"] = {
		["score"] = "3",
		["disheCount"] = "1200",
		["id"] = "53055078",
		["disheId"] = "36012682",
	},
	["53055079"] = {
		["score"] = "2",
		["disheCount"] = "1350",
		["id"] = "53055079",
		["disheId"] = "36012683",
	},
	["53055080"] = {
		["score"] = "2",
		["disheCount"] = "1500",
		["id"] = "53055080",
		["disheId"] = "36012685",
	},
}
return luaxml_new_year_dinner_activation
