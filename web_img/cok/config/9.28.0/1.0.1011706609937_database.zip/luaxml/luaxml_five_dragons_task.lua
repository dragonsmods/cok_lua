-- luaxml_five_dragons_task
local luaxml_five_dragons_task = {
	["53055091"] = {
		["task_go"] = "415000",
		["id"] = "53055091",
		["task_name"] = "52512532",
		["task_go_type"] = "14",
	},
	["53055092"] = {
		["task_go"] = "2",
		["id"] = "53055092",
		["task_name"] = "52512533",
		["task_go_type"] = "2",
	},
	["53055093"] = {
		["task_go"] = "428000",
		["id"] = "53055093",
		["task_name"] = "52512534",
		["task_go_type"] = "14",
	},
	["53055094"] = {
		["task_go"] = "2",
		["id"] = "53055094",
		["task_name"] = "52512535",
		["task_go_type"] = "2",
	},
	["53055095"] = {
		["task_go"] = "9990011",
		["id"] = "53055095",
		["task_name"] = "52512536",
		["task_go_type"] = "4",
	},
	["53055096"] = {
		["task_go"] = "402000",
		["id"] = "53055096",
		["task_name"] = "52512537",
		["task_go_type"] = "14",
	},
}
return luaxml_five_dragons_task
