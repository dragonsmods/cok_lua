-- luaxml_relic_group
local luaxml_relic_group = {
	["52634921"] = {
		["name"] = "52376391",
		["value"] = "450000",
		["num"] = "1",
		["type"] = "340",
		["id"] = "52634921",
		["desc"] = "52376511",
	},
	["52634922"] = {
		["name"] = "52376392",
		["value"] = "450000",
		["num"] = "20",
		["type"] = "340",
		["id"] = "52634922",
		["desc"] = "52376511",
	},
}
return luaxml_relic_group
