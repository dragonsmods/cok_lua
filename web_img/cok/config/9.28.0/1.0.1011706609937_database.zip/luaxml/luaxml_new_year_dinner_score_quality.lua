-- luaxml_new_year_dinner_score_quality
local luaxml_new_year_dinner_score_quality = {
	["53055031"] = {
		["name"] = "80000470",
		["id"] = "53055031",
		["score"] = "0|1000",
		["rewardId"] = "45048443",
		["quality"] = "0",
		["activationNum"] = "0",
	},
	["53055032"] = {
		["name"] = "80000471",
		["id"] = "53055032",
		["score"] = "1001|11000",
		["rewardId"] = "45048444",
		["quality"] = "1",
		["activationNum"] = "1",
	},
	["53055033"] = {
		["name"] = "80000472",
		["id"] = "53055033",
		["score"] = "11001|19000",
		["rewardId"] = "45048445",
		["quality"] = "2",
		["activationNum"] = "3",
	},
	["53055034"] = {
		["name"] = "80000473",
		["id"] = "53055034",
		["score"] = "19001|35000",
		["rewardId"] = "45048446",
		["quality"] = "3",
		["activationNum"] = "5",
	},
	["53055035"] = {
		["name"] = "80000474",
		["id"] = "53055035",
		["score"] = "35001|45000",
		["rewardId"] = "45048447",
		["quality"] = "4",
		["activationNum"] = "8",
	},
	["53055036"] = {
		["name"] = "80000475",
		["id"] = "53055036",
		["score"] = "45001|99999999",
		["rewardId"] = "45048448",
		["quality"] = "5",
		["activationNum"] = "10",
	},
}
return luaxml_new_year_dinner_score_quality
