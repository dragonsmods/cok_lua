-- luaxml_dress_attribute_new
local luaxml_dress_attribute_new = {
	["54084400"] = {
		["level"] = "1",
		["skill_dialog"] = "9200702;2|155072;1|139253;15000",
		["exp"] = "50",
		["skill"] = "5134;2|1230;1|144;15000",
		["add_pic"] = "skill2_610100",
		["id"] = "54084400",
	},
	["54084401"] = {
		["level"] = "2",
		["skill_dialog"] = "9200703;2|101559;1",
		["exp"] = "60",
		["skill"] = "5135;2|1031;1|1032;1",
		["add_pic"] = "skill2_610101",
		["id"] = "54084401",
	},
	["54084402"] = {
		["level"] = "3",
		["skill_dialog"] = "9200704;2|101559;1",
		["exp"] = "70",
		["skill"] = "5136;2|1035;1036;1;1",
		["add_pic"] = "skill2_610102",
		["id"] = "54084402",
	},
}
return luaxml_dress_attribute_new
