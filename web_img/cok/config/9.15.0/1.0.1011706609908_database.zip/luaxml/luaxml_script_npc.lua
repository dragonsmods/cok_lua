-- luaxml_script_npc
local luaxml_script_npc = {
	["53707001"] = {
		["skinconfig"] = "WaterElement_face_out",
		["animation"] = "dj",
		["type"] = "2",
		["id"] = "53707001",
	},
	["53707002"] = {
		["skinconfig"] = "pve_kongluo_boss_face_out",
		["type"] = "2",
		["id"] = "53707002",
	},
	["53707003"] = {
		["skinconfig"] = "pve_kongluo_boss_face_outgongji",
		["type"] = "2",
		["id"] = "53707003",
	},
	["53707004"] = {
		["skinconfig"] = "pve_kongluo_boss_face_outfeiru",
		["type"] = "2",
		["id"] = "53707004",
	},
	["53707005"] = {
		["skinconfig"] = "pve_kongluo_boss_face_outfeichu",
		["type"] = "2",
		["id"] = "53707005",
	},
}
return luaxml_script_npc
