-- luaxml_pve_rank
local luaxml_pve_rank = {
	["53966201"] = {
		["monsterIds"] = "53941249",
		["name"] = "52630722",
		["subName"] = "52630725",
		["icon"] = "PVE_paihangbai_icon_shanghai",
		["type"] = "1",
		["id"] = "53966201",
		["desc"] = "52630728",
	},
	["53966202"] = {
		["monsterIds"] = "53941249",
		["name"] = "52630723",
		["subName"] = "52630726",
		["icon"] = "PVE_paihangbai_icon_jisha",
		["type"] = "2",
		["id"] = "53966202",
		["desc"] = "52630729",
	},
	["53966203"] = {
		["monsterIds"] = "53941249",
		["name"] = "52630724",
		["subName"] = "52630727",
		["icon"] = "PVE_paihangbai_icon_shanghai",
		["type"] = "3",
		["id"] = "53966203",
		["desc"] = "52630730",
	},
}
return luaxml_pve_rank
