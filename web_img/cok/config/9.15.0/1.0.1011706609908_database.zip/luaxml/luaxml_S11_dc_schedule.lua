-- luaxml_S11_dc_schedule
local luaxml_S11_dc_schedule = {
	["53055311"] = {
		["timestamp"] = "1732268296",
		["id"] = "53055311",
		["name"] = "52525516",
		["icon"] = "DBS11_julongzhuye_yure",
	},
	["53055312"] = {
		["timestamp"] = "1701619200",
		["id"] = "53055312",
		["name"] = "52525517",
		["icon"] = "DBS11_julongzhuye_julongbang",
	},
	["53055313"] = {
		["timestamp"] = "1701878400",
		["id"] = "53055313",
		["name"] = "52525518",
		["icon"] = "DBS11_julongzhuye_xiaozusai",
	},
	["53055314"] = {
		["timestamp"] = "1702224000",
		["id"] = "53055314",
		["name"] = "52525519",
		["icon"] = "DBS11_julongzhuye_taotaisai",
	},
	["53055315"] = {
		["timestamp"] = "1703865600",
		["id"] = "53055315",
		["name"] = "52525520",
		["icon"] = "DBS11_julongzhuye_juesai",
	},
	["53055316"] = {
		["timestamp"] = "1703952000",
		["id"] = "53055316",
		["name"] = "52525521",
		["icon"] = "DBS11_julongzhuye_shujuban",
	},
}
return luaxml_S11_dc_schedule
