-- luaxml_relic_building
local luaxml_relic_building = {
	["52636921"] = {
		["maxNum"] = "4",
		["name"] = "52226921",
		["effect"] = "52642936;52642936;52642936",
		["value"] = "1;2;2",
		["relicNum"] = "1;2;3",
		["id"] = "52636921",
		["icon"] = "pic450000",
	},
	["52636922"] = {
		["maxNum"] = "4",
		["name"] = "52226924",
		["effect"] = "52642937;52642937;52642937",
		["value"] = "1;2;2",
		["relicNum"] = "1;2;3",
		["id"] = "52636922",
		["icon"] = "pic451000",
	},
}
return luaxml_relic_building
