-- luaxml_year_sign
local luaxml_year_sign = {
	["30437101"] = {
		test = "6666666666666",
		reward_herotimes = "15",
		id = "30437101",
		reward_item = "252686",
		hero_id = "53544",
	},
}
return luaxml_year_sign
